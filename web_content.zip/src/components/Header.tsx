import React, { useState } from 'react';
import {
  Play,
  Download,
  Sparkles,
  Columns2,
  Rows2,
  Maximize2,
  Palette,
  FolderOpen,
  Plus,
  Radio,
  Menu,
  ChevronDown,
  Layers,
  Code2
} from 'lucide-react';
import { Project, StudioTheme } from '../types';

interface HeaderProps {
  projects: Project[];
  activeProject: Project;
  onSelectProject: (id: string) => void;
  onNewProject: () => void;
  onRunPreview: () => void;
  onExportZip: () => void;
  onToggleAiPanel: () => void;
  isAiPanelOpen: boolean;
  layout: 'split-h' | 'split-v' | 'editor-only' | 'preview-only';
  onChangeLayout: (layout: 'split-h' | 'split-v' | 'editor-only' | 'preview-only') => void;
  theme: StudioTheme;
  onChangeTheme: (theme: StudioTheme) => void;
  aiAvailable: boolean;
  onToggleSidebar: () => void;
  mobileTab?: 'code' | 'preview';
  onChangeMobileTab?: (tab: 'code' | 'preview') => void;
}

export const Header: React.FC<HeaderProps> = ({
  projects,
  activeProject,
  onSelectProject,
  onNewProject,
  onRunPreview,
  onExportZip,
  onToggleAiPanel,
  isAiPanelOpen,
  layout,
  onChangeLayout,
  theme,
  onChangeTheme,
  aiAvailable,
  onToggleSidebar,
  mobileTab = 'code',
  onChangeMobileTab,
}) => {
  const [showProjMenu, setShowProjMenu] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [showLayoutMenu, setShowLayoutMenu] = useState(false);

  const themeLabels: Record<StudioTheme, { name: string; color: string }> = {
    cyberpunk: { name: 'Cyberpunk', color: 'bg-cyan-500' },
    dark: { name: 'Dark Pro', color: 'bg-slate-400' },
    neon: { name: 'Neon Synth', color: 'bg-pink-500' },
    matrix: { name: 'Matrix Green', color: 'bg-emerald-500' },
    light: { name: 'Clean Light', color: 'bg-blue-500' },
  };

  return (
    <header className="h-14 bg-[#090d18] border-b border-slate-800 px-3 md:px-5 flex items-center justify-between select-none shrink-0 z-30">
      {/* Left: Hamburger & Brand & Project Selector */}
      <div className="flex items-center gap-2 md:gap-4">
        {/* Mobile menu toggle */}
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle explorer sidebar"
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Brand logo */}
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-950/80 border border-cyan-500/50 shadow-sm shadow-cyan-500/20">
            <Code2 className="w-4 h-4 text-cyan-400" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-cyan-400 animate-ping opacity-75" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-cyan-400" />
          </div>
          <div className="hidden sm:block">
            <span className="font-extrabold text-sm tracking-wider text-white">
              CODE<span className="text-cyan-400">VERSE</span>
            </span>
            <span className="ml-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 text-cyan-300 border border-cyan-800/40">
              STUDIO
            </span>
          </div>
        </div>

        {/* Project Selector dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowProjMenu(!showProjMenu);
              setShowThemeMenu(false);
              setShowLayoutMenu(false);
            }}
            aria-label="Select active project"
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#111728] border border-slate-700/80 hover:border-cyan-500/50 text-xs font-semibold text-slate-200 transition-all max-w-[140px] sm:max-w-[200px] truncate"
          >
            <FolderOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">{activeProject.name}</span>
            <ChevronDown className="w-3 h-3 text-slate-400 shrink-0 ml-1" />
          </button>

          {showProjMenu && (
            <div className="absolute left-0 top-full mt-1 w-64 bg-[#0d1322] border border-slate-700 rounded-xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="text-[11px] font-bold text-slate-400 px-2 py-1 mb-1 uppercase tracking-wider flex justify-between items-center">
                <span>Projects ({projects.length})</span>
                <button
                  onClick={() => {
                    setShowProjMenu(false);
                    onNewProject();
                  }}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5 text-[10px]"
                >
                  <Plus className="w-3 h-3" /> New
                </button>
              </div>
              <div className="max-h-60 overflow-y-auto space-y-1">
                {projects.map(proj => (
                  <button
                    key={proj.id}
                    onClick={() => {
                      onSelectProject(proj.id);
                      setShowProjMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                      proj.id === activeProject.id
                        ? 'bg-cyan-500/15 text-cyan-300 font-semibold border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="truncate mr-2">
                      <div className="truncate">{proj.name}</div>
                      <div className="text-[10px] text-slate-400 truncate capitalize">{proj.category}</div>
                    </div>
                    {proj.id === activeProject.id && (
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Center / Right: Action Controls */}
      <div className="flex items-center gap-1.5 md:gap-3">
        {/* Mobile Code / Preview toggle */}
        {onChangeMobileTab && (
          <div className="flex md:hidden items-center bg-[#050811] rounded-lg p-0.5 border border-slate-700/80 text-[11px] font-semibold">
            <button
              onClick={() => onChangeMobileTab('code')}
              className={`px-2 py-1 rounded-md transition-colors ${
                mobileTab === 'code' ? 'bg-cyan-500/25 text-cyan-300' : 'text-slate-400'
              }`}
            >
              Code
            </button>
            <button
              onClick={() => onChangeMobileTab('preview')}
              className={`px-2 py-1 rounded-md transition-colors ${
                mobileTab === 'preview' ? 'bg-cyan-500/25 text-cyan-300' : 'text-slate-400'
              }`}
            >
              Preview
            </button>
          </div>
        )}

        {/* Run Button */}
        <button
          onClick={onRunPreview}
          aria-label="Run live preview"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-emerald-500/25 active:scale-95"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span className="hidden sm:inline">Run</span>
        </button>

        {/* AI Assistant Toggle Button */}
        <button
          onClick={onToggleAiPanel}
          aria-label="Toggle AI coding assistant"
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            isAiPanelOpen
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
              : 'bg-[#111728] border border-cyan-500/40 text-cyan-300 hover:bg-cyan-950/40'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">AI Studio</span>
        </button>

        {/* Export ZIP */}
        <button
          onClick={onExportZip}
          aria-label="Export project as ZIP"
          title="Export project as ZIP"
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>ZIP</span>
        </button>

        {/* Layout Switcher */}
        <div className="relative hidden lg:block">
          <button
            onClick={() => {
              setShowLayoutMenu(!showLayoutMenu);
              setShowThemeMenu(false);
              setShowProjMenu(false);
            }}
            aria-label="Change layout arrangement"
            title="Change studio layout"
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
          >
            {layout === 'split-h' ? (
              <Columns2 className="w-4 h-4" />
            ) : layout === 'split-v' ? (
              <Rows2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>

          {showLayoutMenu && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-[#0d1322] border border-slate-700 rounded-xl shadow-2xl p-1.5 z-50">
              <button
                onClick={() => {
                  onChangeLayout('split-h');
                  setShowLayoutMenu(false);
                }}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs ${
                  layout === 'split-h' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Columns2 className="w-3.5 h-3.5" /> Split Horizontal
              </button>
              <button
                onClick={() => {
                  onChangeLayout('split-v');
                  setShowLayoutMenu(false);
                }}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs ${
                  layout === 'split-v' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Rows2 className="w-3.5 h-3.5" /> Split Vertical
              </button>
              <button
                onClick={() => {
                  onChangeLayout('editor-only');
                  setShowLayoutMenu(false);
                }}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs ${
                  layout === 'editor-only' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Code2 className="w-3.5 h-3.5" /> Editor Only
              </button>
              <button
                onClick={() => {
                  onChangeLayout('preview-only');
                  setShowLayoutMenu(false);
                }}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs ${
                  layout === 'preview-only' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Play className="w-3.5 h-3.5" /> Preview Only
              </button>
            </div>
          )}
        </div>

        {/* Theme Switcher */}
        <div className="relative">
          <button
            onClick={() => {
              setShowThemeMenu(!showThemeMenu);
              setShowLayoutMenu(false);
              setShowProjMenu(false);
            }}
            aria-label="Change studio theme"
            title="Studio Theme"
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
          >
            <Palette className="w-4 h-4" />
          </button>

          {showThemeMenu && (
            <div className="absolute right-0 top-full mt-1 w-40 bg-[#0d1322] border border-slate-700 rounded-xl shadow-2xl p-1.5 z-50">
              <div className="text-[10px] font-bold text-slate-400 px-2 py-1 mb-1 uppercase tracking-wider">Themes</div>
              {(Object.keys(themeLabels) as StudioTheme[]).map(key => (
                <button
                  key={key}
                  onClick={() => {
                    onChangeTheme(key);
                    setShowThemeMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs capitalize ${
                    theme === key ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${themeLabels[key].color}`} />
                    <span>{themeLabels[key].name}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Server AI Status indicator */}
        <div
          title={aiAvailable ? 'Gemini 3.8 Flash AI Connected' : 'Offline Heuristic Assistant Active'}
          className="hidden sm:flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px]"
        >
          <span className={`w-2 h-2 rounded-full ${aiAvailable ? 'bg-cyan-400 animate-pulse' : 'bg-amber-400'}`} />
          <span className="font-mono text-slate-400">{aiAvailable ? 'AI Live' : 'Offline'}</span>
        </div>
      </div>
    </header>
  );
};
