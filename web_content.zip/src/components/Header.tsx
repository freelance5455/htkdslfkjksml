import React, { useState, useEffect } from 'react';
import { Flame, Bell, BellOff, Volume2, Database, ShieldCheck } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { SyncStatusIndicator } from './SyncStatusIndicator';
import { getNotificationPermissionStatus, requestNotificationPermission } from '../utils/notificationService';
import { alarmAudio } from '../utils/audioAlarm';

interface HeaderProps {
  onOpenBackup: () => void;
  todayCount: number;
  overdueCount: number;
  lastSaved: Date | null;
  isSaving?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenBackup,
  todayCount,
  overdueCount,
  lastSaved,
  isSaving = false,
}) => {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  useEffect(() => {
    setPermission(getNotificationPermissionStatus());
  }, []);

  const handleRequestPermission = async () => {
    const res = await requestNotificationPermission();
    setPermission(res);
  };

  const handleTestAlarm = () => {
    setIsPlayingTest(true);
    alarmAudio.playUrgentAlarm();
    setTimeout(() => setIsPlayingTest(false), 1200);
  };

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 text-white shadow-md">
      <div className="max-w-4xl mx-auto px-3.5 py-2.5 sm:px-4 sm:py-3">
        <div className="flex items-center justify-between gap-2">
          {/* Brand & Title */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-white/15 backdrop-blur-xs border border-white/20 shadow-inner shrink-0">
              <Flame className="w-6 h-6 text-yellow-300 animate-pulse fill-yellow-400" />
              {(todayCount > 0 || overdueCount > 0) && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-300 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-red-600 text-[10px] font-bold text-white items-center justify-center">
                    {todayCount + overdueCount}
                  </span>
                </span>
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-bold tracking-tight truncate leading-tight">
                  गैस ग्राहक रिकॉर्ड
                </h1>
                <SyncStatusIndicator lastSaved={lastSaved} isSaving={isSaving} />
              </div>
              <p className="text-[11px] sm:text-xs text-orange-100 flex items-center gap-1 font-medium truncate mt-0.5">
                <span>26वां दिन सुबह 9:00 अलार्म</span>
              </p>
            </div>
          </div>

          {/* Action buttons on Header */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Install PWA Button */}
            <PWAInstallButton />

            {/* Test Alarm Sound */}
            <button
              onClick={handleTestAlarm}
              title="अलार्म व घंटी टेस्ट करें"
              className={`p-2 rounded-lg bg-white/15 hover:bg-white/25 active:scale-95 transition border border-white/20 text-white cursor-pointer ${
                isPlayingTest ? 'ring-2 ring-yellow-300 bg-white/30 scale-105' : ''
              }`}
            >
              <Volume2 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            </button>

            {/* Notification Permission Indicator */}
            {permission !== 'granted' ? (
              <button
                onClick={handleRequestPermission}
                title="रिमाइंडर नोटिफिकेशन चालू करें"
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-300 shadow-sm transition active:scale-95 cursor-pointer"
              >
                <BellOff className="w-3.5 h-3.5 text-slate-950" />
                <span className="hidden sm:inline">नोटिफिकेशन चालू करें</span>
                <span className="sm:hidden">अनुमति दें</span>
              </button>
            ) : (
              <div
                title="नोटिफिकेशन सक्रिय है (सुबह 9:00 बजे अलार्म आएगा)"
                className="p-2 rounded-lg bg-emerald-500/30 border border-emerald-300/40 text-emerald-100"
              >
                <Bell className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-yellow-300" />
              </div>
            )}

            {/* Backup / Export Menu */}
            <button
              onClick={onOpenBackup}
              title="डेटा बैकअप व रीस्टोर"
              className="p-2 rounded-lg bg-white/15 hover:bg-white/25 active:scale-95 transition border border-white/20 text-white cursor-pointer"
            >
              <Database className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            </button>
          </div>
        </div>

        {/* Permission Advisory Banner if not granted yet */}
        {permission !== 'granted' && (
          <div className="mt-2 pt-2 border-t border-white/15 flex items-center justify-between text-xs text-orange-100 bg-white/10 px-2.5 py-1.5 rounded-lg">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
              <span>26वें दिन का ऑटो अलार्म पाने के लिए नोटिफिकेशन ऑन करें:</span>
            </span>
            <button
              onClick={handleRequestPermission}
              className="ml-2 font-bold underline text-white hover:text-yellow-200 cursor-pointer"
            >
              यहाँ क्लिक करें
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
