import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AppLanguage } from '../types';
import {
  Search,
  ShoppingCart,
  Heart,
  Bell,
  User,
  Menu,
  BookOpen,
  ChevronDown,
  Sparkles,
  ShieldCheck,
  CheckCircle,
  X
} from 'lucide-react';

interface HeaderProps {
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch }) => {
  const {
    t,
    language,
    setLanguage,
    cart,
    wishlist,
    setActiveTab,
    activeTab,
    setSideDrawerOpen,
    notifications,
    markNotificationsAsRead,
    setAuthModalOpen,
    userProfile,
    isLoggedIn
  } = useApp();

  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const cartCount = cart.length;
  const wishlistCount = wishlist.length;
  const unreadNotifs = notifications.filter((n) => !n.read).length;

  const languages: { code: AppLanguage; label: string; script: string }[] = [
    { code: 'en', label: 'English', script: 'EN' },
    { code: 'as', label: 'অসমীয়া', script: 'AS' },
    { code: 'hi', label: 'हिंदी', script: 'HI' },
    { code: 'bn', label: 'বাংলা', script: 'BN' },
  ];

  const currentLangObj = languages.find((l) => l.code === language) || languages[0];

  return (
    <header className="sticky top-0 z-40 bg-[#0B192C] text-white shadow-lg border-b border-[#1E3E62]">
      {/* Top micro bar for announcements */}
      <div className="bg-[#07111E] text-slate-300 text-xs py-1.5 px-4 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
          <span className="inline-flex items-center gap-1 bg-amber-500/20 text-amber-300 text-[11px] font-semibold px-2 py-0.5 rounded">
            <Sparkles className="w-3 h-3 text-amber-400" />
            OFFER
          </span>
          <span className="text-[11px] sm:text-xs">
            Use Code <strong className="text-amber-400 font-bold">NEXA20</strong> for 20% OFF on all Railway & Police combos!
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-[11px] text-slate-300">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            100% Verified Official Syllabus
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-amber-400">Assam & All India Exams</span>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 sm:gap-4">
        {/* Left: Mobile Drawer Trigger + Brand Logo */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => setSideDrawerOpen(true)}
            className="p-1.5 text-slate-200 hover:text-white hover:bg-slate-800/60 rounded-lg transition-colors focus:outline-none"
            title="Menu"
            aria-label="Open Navigation Drawer"
          >
            <Menu className="w-6 h-6" />
          </button>

          <button
            onClick={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-[#0B192C]" strokeWidth={2.5} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-xl tracking-tight text-white group-hover:text-amber-400 transition-colors">
                  NEXA
                </span>
                <span className="text-xs sm:text-sm font-semibold tracking-wider text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                  EXAM BOOKS
                </span>
              </div>
              <p className="text-[10px] text-slate-300 hidden sm:block tracking-wide font-medium">
                Premier Govt Exam Study Materials
              </p>
            </div>
          </button>
        </div>

        {/* Center: Search trigger input for desktop */}
        <div className="flex-1 max-w-xl mx-2 hidden md:block">
          <button
            onClick={onOpenSearch}
            className="w-full flex items-center gap-3 bg-slate-900/90 hover:bg-slate-900 text-slate-400 hover:text-slate-200 px-4 py-2.5 rounded-full border border-slate-700/80 transition-all text-left shadow-inner group"
          >
            <Search className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-xs sm:text-sm truncate">
              {t.searchPlaceholder}
            </span>
            <kbd className="hidden lg:inline-block ml-auto text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700">
              Ctrl + K
            </kbd>
          </button>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Mobile search button */}
          <button
            onClick={onOpenSearch}
            className="md:hidden p-2 text-slate-200 hover:text-white hover:bg-slate-800/60 rounded-full transition-colors"
            aria-label="Search"
          >
            <Search className="w-5 h-5 text-amber-400" />
          </button>

          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
              title="Change Language"
            >
              <span className="text-amber-400 font-bold">{currentLangObj.script}</span>
              <span className="hidden sm:inline">{currentLangObj.label}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {langMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setLangMenuOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-44 bg-[#0F172A] border border-slate-700 rounded-xl shadow-2xl py-1 z-50 text-slate-200 divide-y divide-slate-800">
                  <div className="px-3 py-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Select App Language
                  </div>
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                        language === l.code ? 'text-amber-400 font-bold bg-slate-800/40' : ''
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="w-6 text-[10px] font-mono text-slate-400 bg-slate-800 px-1 py-0.5 rounded text-center">
                          {l.script}
                        </span>
                        {l.label}
                      </span>
                      {language === l.code && <CheckCircle className="w-3.5 h-3.5 text-amber-400" />}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => {
                setNotifOpen(!notifOpen);
                if (!notifOpen) markNotificationsAsRead();
              }}
              className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-full transition-colors"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifs > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotifs}
                </span>
              )}
            </button>

            {notifOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0F172A] border border-slate-700 rounded-xl shadow-2xl p-3 z-50 text-slate-200">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
                    <span className="font-bold text-sm text-white flex items-center gap-1.5">
                      <Bell className="w-4 h-4 text-amber-400" /> Notifications & Alerts
                    </span>
                    <button
                      onClick={() => setNotifOpen(false)}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="max-h-80 overflow-y-auto space-y-2">
                    {notifications.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors"
                      >
                        <div className="flex items-center justify-between text-xs font-semibold text-amber-400 mb-1">
                          <span>{item.title}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{item.time}</span>
                        </div>
                        <p className="text-xs text-slate-300 leading-snug">{item.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Wishlist Icon */}
          <button
            onClick={() => setActiveTab('my-books')}
            className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-full transition-colors hidden sm:block"
            title="Wishlist"
          >
            <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'text-rose-400 fill-rose-400/20' : ''}`} />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
