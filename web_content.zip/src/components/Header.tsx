import React from 'react';
import {
  Sparkles,
  Bot,
  Zap,
  Brain,
  Code2,
  Palette,
  Volume2,
  VolumeX,
  Menu,
  Plus,
  Share2,
  Trash2,
  Cpu
} from 'lucide-react';
import { playSound } from '../utils/soundEffects';

export type ChatMode = 'standard' | 'fast' | 'reasoning' | 'code' | 'creative';

interface HeaderProps {
  currentMode: ChatMode;
  onSelectMode: (mode: ChatMode) => void;
  soundMuted: boolean;
  onToggleSound: () => void;
  onNewChat: () => void;
  onClearChat: () => void;
  onOpenSidebar: () => void;
  onExportChat: () => void;
  hasMessages: boolean;
  isGenerating: boolean;
}

const MODES: { id: ChatMode; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'standard', label: 'Standard', icon: <Bot className="w-3.5 h-3.5" />, desc: 'Polyvalent & Fluide' },
  { id: 'fast', label: 'Flash', icon: <Zap className="w-3.5 h-3.5" />, desc: 'Ultra-rapide & Concis' },
  { id: 'reasoning', label: 'Raisonnement', icon: <Brain className="w-3.5 h-3.5" />, desc: 'Pensée pas-à-pas' },
  { id: 'code', label: 'Code', icon: <Code2 className="w-3.5 h-3.5" />, desc: 'Architecture & Dev' },
  { id: 'creative', label: 'Créatif', icon: <Palette className="w-3.5 h-3.5" />, desc: 'Idées & Rédaction' },
];

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  soundMuted,
  onToggleSound,
  onNewChat,
  onClearChat,
  onOpenSidebar,
  onExportChat,
  hasMessages,
  isGenerating,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-cyan-500/15 bg-[#0e1626]/90 backdrop-blur-md px-3 sm:px-6 py-2.5 transition-all">
      <div className="flex items-center justify-between gap-2 max-w-7xl mx-auto">
        {/* Left: Sidebar toggle + Logo */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => {
              playSound('click', soundMuted);
              onOpenSidebar();
            }}
            className="p-2 rounded-xl text-slate-300 hover:text-cyan-400 hover:bg-slate-800/60 border border-slate-700/50 transition-colors"
            title="Historique des conversations"
            aria-label="Ouvrir le menu"
          >
            <Menu className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-600 shadow-md shadow-cyan-500/25 p-0.5">
              <div className="w-full h-full rounded-[10px] bg-[#0c1220] flex items-center justify-center">
                <span className="text-base sm:text-lg">🤖</span>
              </div>
              <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-extrabold tracking-tight bg-gradient-to-r from-cyan-300 via-sky-200 to-blue-400 bg-clip-text text-transparent">
                  GPT-6
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 text-[10px] font-semibold text-cyan-300">
                  <Cpu className="w-2.5 h-2.5" />
                  Quantum Core
                </span>
              </div>
              <p className="hidden md:block text-[10px] text-slate-400">
                Modèle neural de 6e génération
              </p>
            </div>
          </div>
        </div>

        {/* Center: Mode Selector Pills */}
        <div className="hidden lg:flex items-center p-1 rounded-xl bg-slate-900/90 border border-cyan-500/20 shadow-inner">
          {MODES.map((mode) => {
            const isActive = currentMode === mode.id;
            return (
              <button
                key={mode.id}
                onClick={() => {
                  playSound('switch', soundMuted);
                  onSelectMode(mode.id);
                }}
                disabled={isGenerating}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                } ${isGenerating ? 'opacity-60 cursor-not-allowed' : ''}`}
                title={mode.desc}
              >
                {mode.icon}
                <span>{mode.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Audio toggle */}
          <button
            onClick={() => {
              onToggleSound();
              if (soundMuted) playSound('click', false);
            }}
            className={`p-2 rounded-xl border transition-colors ${
              soundMuted
                ? 'text-slate-500 border-slate-800 hover:text-slate-300'
                : 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20'
            }`}
            title={soundMuted ? 'Activer le son' : 'Désactiver le son'}
            aria-label="Contrôle audio"
          >
            {soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* New Chat */}
          <button
            onClick={() => {
              playSound('click', soundMuted);
              onNewChat();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 transition-all transform active:scale-95"
            title="Nouvelle conversation"
          >
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
            <span className="hidden xs:inline">Nouveau chat</span>
          </button>

          {/* Export button */}
          {hasMessages && (
            <button
              onClick={() => {
                playSound('click', soundMuted);
                onExportChat();
              }}
              className="p-2 rounded-xl text-slate-300 hover:text-cyan-300 hover:bg-slate-800 border border-slate-700/50 transition-colors"
              title="Exporter la conversation"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}

          {/* Clear chat */}
          {hasMessages && (
            <button
              onClick={() => {
                playSound('click', soundMuted);
                onClearChat();
              }}
              disabled={isGenerating}
              className="p-2 rounded-xl text-rose-400/80 hover:text-rose-300 hover:bg-rose-950/40 border border-rose-500/20 transition-colors"
              title="Effacer les messages"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Mobile Mode selector pills */}
      <div className="flex lg:hidden overflow-x-auto py-2 gap-1.5 mt-1 -mx-2 px-2 scrollbar-none">
        {MODES.map((mode) => {
          const isActive = currentMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => {
                playSound('switch', soundMuted);
                onSelectMode(mode.id);
              }}
              disabled={isGenerating}
              className={`flex items-center shrink-0 gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'bg-slate-900/80 text-slate-400 border border-slate-800'
              }`}
            >
              {mode.icon}
              <span>{mode.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
