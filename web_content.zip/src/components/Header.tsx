import React from 'react';
import { Menu, Plus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SULogo } from './Logo';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  onOpenMobileNav: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMobileNav }) => {
  const { activeRoute, setActiveRoute, snapshot, setSettingsSection } = useApp();
  const { settings, modules } = snapshot;

  const getSectionTitle = (): string => {
    if (activeRoute === 'dashboard') return 'Financial Dashboard';
    if (activeRoute === 'loans') return 'Loan Management';
    if (activeRoute === 'committees') return 'Committee Management';
    if (activeRoute === 'reports') return 'Reports & Analytics';
    if (activeRoute === 'settings') return 'Settings & Dynamic App Builder';
    if (activeRoute === 'backup') return 'Backup & Restore';
    if (activeRoute === 'recycle-bin') return 'Recycle Bin';
    if (activeRoute === 'audit-log') return 'Audit Log';
    if (activeRoute.startsWith('module:')) {
      const modId = activeRoute.replace('module:', '');
      return modules.find((m) => m.id === modId)?.name || 'Custom Module';
    }
    return 'Dashboard';
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 px-4 sm:px-6 py-3 no-print">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile Menu + Brand/Page Context */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onOpenMobileNav}
            aria-label="Open navigation menu"
            className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 cursor-pointer shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="lg:hidden">
            <SULogo size="sm" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-sm sm:text-lg font-bold text-slate-900 truncate">
              {getSectionTitle()}
            </h1>
            <div className="text-[11px] sm:text-xs text-slate-500 truncate">
              {settings.appName} · {settings.appSubtitle}
            </div>
          </div>
        </div>

        {/* Right: PWA Install + Single Primary Action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <PWAInstallButton />
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('modules');
            }}
            className="inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs sm:text-sm font-semibold text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            style={{ backgroundColor: settings.theme.buttonColor }}
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span className="hidden sm:inline">App Builder</span>
            <span className="sm:hidden">Builder</span>
          </button>
        </div>
      </div>
    </header>
  );
};
