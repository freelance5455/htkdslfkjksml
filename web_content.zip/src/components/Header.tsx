import React from 'react';
import { Menu, Plus, Download, Lightbulb, BookOpenCheck, Zap } from 'lucide-react';
import { TUTOR_PERSONAS, TutorPersonaId, TeachingMode, AcademicLevel } from '../utils/tutor-prompts';

interface HeaderProps {
  onToggleSidebar: () => void;
  currentPersona: TutorPersonaId;
  teachingMode: TeachingMode;
  level: AcademicLevel;
  onChangeTeachingMode: (mode: TeachingMode) => void;
  onChangeLevel: (level: AcademicLevel) => void;
  onNewChat: () => void;
  onExportNotes: () => void;
  hasMessages: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  currentPersona,
  teachingMode,
  level,
  onChangeTeachingMode,
  onChangeLevel,
  onNewChat,
  onExportNotes,
  hasMessages,
}) => {
  const persona = TUTOR_PERSONAS[currentPersona] || TUTOR_PERSONAS.general;

  return (
    <header className="h-16 border-b border-slate-200 bg-white/95 backdrop-blur-md sticky top-0 z-20 px-3 sm:px-4 flex items-center justify-between gap-2">
      {/* Left: Mobile Toggle & Title */}
      <div className="flex items-center space-x-2.5 min-w-0">
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle navigation menu"
          className="md:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg shrink-0 transition"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <div className="flex items-center space-x-2">
            <h1 className="text-sm font-bold text-slate-800 truncate">
              {persona.name}
            </h1>
            <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
              {persona.shortName}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 truncate hidden md:block">
            {persona.subtitle}
          </p>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
        {/* Teaching Mode Selector: Visible on all screens! */}
        <div className="flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50 text-xs">
          <button
            onClick={() => onChangeTeachingMode('direct')}
            aria-label="Direct teaching mode"
            className={`px-2 py-1 rounded-md text-[11px] font-medium transition flex items-center space-x-1 ${
              teachingMode === 'direct'
                ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Comprehensive step-by-step answers"
          >
            <Zap className={`w-3 h-3 ${teachingMode === 'direct' ? 'text-indigo-600' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">Direct</span>
          </button>
          <button
            onClick={() => onChangeTeachingMode('socratic')}
            aria-label="Socratic teaching mode"
            className={`px-2 py-1 rounded-md text-[11px] font-medium flex items-center space-x-1 transition ${
              teachingMode === 'socratic'
                ? 'bg-white text-amber-900 shadow-2xs font-semibold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Guides with questions and hints rather than giving the answer away"
          >
            <Lightbulb className={`w-3 h-3 ${teachingMode === 'socratic' ? 'text-amber-500' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">Socratic</span>
          </button>
          <button
            onClick={() => onChangeTeachingMode('quiz_prep')}
            aria-label="Quiz prep teaching mode"
            className={`px-2 py-1 rounded-md text-[11px] font-medium flex items-center space-x-1 transition ${
              teachingMode === 'quiz_prep'
                ? 'bg-white text-indigo-900 shadow-2xs font-semibold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Active recall with comprehension checks"
          >
            <BookOpenCheck className={`w-3 h-3 ${teachingMode === 'quiz_prep' ? 'text-indigo-500' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">Quiz Prep</span>
          </button>
        </div>

        {/* Audience Level Selector */}
        <div className="relative">
          <select
            value={level}
            onChange={(e) => onChangeLevel(e.target.value as AcademicLevel)}
            aria-label="Select student academic level"
            className="text-xs bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-medium py-1.5 px-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 transition cursor-pointer max-w-[110px] sm:max-w-none truncate"
          >
            <option value="elementary">Middle School</option>
            <option value="high_school">High School</option>
            <option value="undergrad">College</option>
            <option value="expert">Advanced</option>
          </select>
        </div>

        {/* Export Notes: Always interactive */}
        <button
          onClick={onExportNotes}
          aria-label="Export conversation notes"
          className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg transition flex items-center space-x-1.5"
          title={hasMessages ? 'Export Study Notes as Markdown' : 'Start a chat to export notes'}
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span className="hidden sm:inline">Export</span>
        </button>

        {/* New Chat Button */}
        <button
          onClick={onNewChat}
          aria-label="New chat session"
          className="px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition flex items-center space-x-1.5 shadow-2xs shrink-0"
          title="Start fresh conversation"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New Chat</span>
        </button>
      </div>
    </header>
  );
};
