import React from 'react';
import { PWAInstallButton } from './PWAInstallButton';
import { Zap, MessageSquare } from 'lucide-react';

interface HeaderProps {
  onOpenCoach: () => void;
  gpsAccuracy: number | null;
  onOpenRecovery: () => void;
  recoveryScore?: number; // 1-10
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCoach,
  gpsAccuracy,
  onOpenRecovery,
  recoveryScore = 8,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0a0a0a]/90 backdrop-blur-md border-b border-zinc-800/80 px-4 py-3">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Logo and Tagline */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-[#00FF66]/30 flex items-center justify-center relative shadow-sm">
            <Zap className="w-5 h-5 text-[#00FF66] fill-[#00FF66]/20" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#00FF66] rounded-full border-2 border-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-athletic text-lg font-black tracking-tight text-white uppercase">
                JAAT RUNNER
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#00FF66]/15 text-[#00FF66] border border-[#00FF66]/30">
                1600M
              </span>
            </div>
            <p className="text-[10px] tracking-wider uppercase text-zinc-400 font-semibold">
              Discipline &bull; Purpose
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Recovery Check-in Quick Pill */}
          <button
            onClick={onOpenRecovery}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-700/80 hover:border-zinc-500 transition text-[11px] font-medium text-zinc-300"
            title="Log recovery check-in"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                recoveryScore >= 7
                  ? 'bg-[#00FF66]'
                  : recoveryScore >= 4
                  ? 'bg-amber-400'
                  : 'bg-rose-500 animate-pulse'
              }`}
            />
            <span>Recovery</span>
          </button>

          {/* Coach Jaat Chat button */}
          <button
            onClick={onOpenCoach}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 border border-[#00FF66]/40 text-[#00FF66] text-xs font-semibold hover:bg-zinc-800 transition active:scale-95"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Coach</span>
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
};
