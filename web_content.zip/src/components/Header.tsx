import React from 'react';
import { ShoppingBag, Heart, Download, Laptop, Database, Globe, User as UserIcon, ShieldCheck, LogIn } from 'lucide-react';
import { CurrencyCode, User } from '../types';
import { CURRENCIES } from '../utils/currency';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  activeCurrency: CurrencyCode;
  currentUser: User | null;
  onCurrencyChange: (curr: CurrencyCode) => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenWindowsGuide: () => void;
  onOpenBackup: () => void;
  onOpenRoomPlanner: () => void;
  onOpenUploadProduct: () => void;
  onOpenAuth: () => void;
  onDownloadZip: () => void;
  onScrollToCatalog: () => void;
  onScrollToHeritage: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  activeCurrency,
  currentUser,
  onCurrencyChange,
  onOpenCart,
  onOpenWishlist,
  onOpenWindowsGuide,
  onOpenBackup,
  onOpenRoomPlanner,
  onOpenUploadProduct,
  onOpenAuth,
  onDownloadZip,
  onScrollToCatalog,
  onScrollToHeritage
}) => {
  const isOwner = currentUser?.role === 'owner';

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-stone-200/80 transition-all">
      {/* Top micro-announcement banner */}
      <div className="bg-[#2D2A26] text-[#FAF8F5] text-xs py-1.5 px-4 text-center tracking-wide">
        <span className="font-medium">Free Nationwide & Regional Delivery</span>
        <span className="mx-2 text-stone-400">·</span>
        {isOwner ? (
          <span className="text-amber-300 font-semibold">
            👑 Signed in as Store Owner ({currentUser.name}) · Uploading Enabled
          </span>
        ) : (
          <span className="text-stone-300">
            100% Offline Local Data Safe · No Cloud Subscription Required
          </span>
        )}
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a 
          href="#" 
          className="group text-left cursor-pointer"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <span className="block font-serif text-2xl sm:text-3xl font-semibold tracking-wider text-stone-900 group-hover:text-stone-700 transition-colors">
            BAIT UL UKASHA
          </span>
          <span className="block text-[10px] tracking-[0.25em] text-stone-500 uppercase -mt-1 font-sans">
            Home Essentials · بيت عكاشة
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-700">
          <button 
            onClick={onScrollToCatalog}
            className="hover:text-stone-950 transition-colors whitespace-nowrap cursor-pointer hover:underline decoration-stone-400 underline-offset-4"
          >
            Essentials Catalog
          </button>
          <button 
            onClick={onOpenRoomPlanner}
            className="hover:text-stone-950 transition-colors whitespace-nowrap cursor-pointer hover:underline decoration-stone-400 underline-offset-4"
          >
            Room Planner
          </button>
          <button 
            onClick={onScrollToHeritage}
            className="hover:text-stone-950 transition-colors whitespace-nowrap cursor-pointer hover:underline decoration-stone-400 underline-offset-4"
          >
            Our Heritage
          </button>
          <button 
            onClick={onOpenWindowsGuide}
            className="flex items-center gap-1.5 hover:text-stone-950 transition-colors whitespace-nowrap cursor-pointer hover:underline decoration-stone-400 underline-offset-4 text-amber-900"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>Windows Setup</span>
          </button>
          <button 
            onClick={onOpenBackup}
            className="flex items-center gap-1.5 hover:text-stone-950 transition-colors whitespace-nowrap cursor-pointer hover:underline decoration-stone-400 underline-offset-4 text-stone-600"
          >
            <Database className="w-3.5 h-3.5" />
            <span>Backup Data</span>
          </button>
        </nav>

        {/* Zone 3: Actions, Auth & Shopping Bag */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
          {/* Only Owner can see the Upload Product action button */}
          {isOwner && (
            <button
              onClick={onOpenUploadProduct}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-950 bg-amber-300 hover:bg-amber-400 border border-amber-400 px-3 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-2xs"
              title="Upload your own custom products & photos"
            >
              <span className="text-sm leading-none font-bold">+</span>
              <span>Upload Product</span>
            </button>
          )}

          {/* User Sign In / Account Button */}
          {currentUser ? (
            <button
              onClick={onOpenAuth}
              className={`inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                isOwner
                  ? 'bg-amber-50 border-amber-200 text-amber-900 hover:bg-amber-100'
                  : 'bg-stone-100 border-stone-200 text-stone-800 hover:bg-stone-200'
              }`}
              title="Manage your account & sign out"
            >
              {isOwner ? (
                <ShieldCheck className="w-3.5 h-3.5 text-amber-800" />
              ) : (
                <UserIcon className="w-3.5 h-3.5 text-stone-600" />
              )}
              <span className="max-w-[100px] truncate">{currentUser.name}</span>
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-800 bg-white border border-stone-300 hover:border-stone-400 hover:bg-stone-50 px-3 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-2xs"
            >
              <LogIn className="w-3.5 h-3.5 text-stone-600" />
              <span>Sign In</span>
            </button>
          )}

          {/* Currency Switcher */}
          <div className="relative flex items-center bg-stone-100 rounded-md border border-stone-200/80 px-2 py-1 text-xs">
            <Globe className="w-3.5 h-3.5 text-stone-500 mr-1.5" />
            <select
              value={activeCurrency}
              onChange={(e) => onCurrencyChange(e.target.value as CurrencyCode)}
              className="bg-transparent text-stone-800 font-medium cursor-pointer outline-none focus:ring-0 text-xs"
              title="Select currency"
            >
              {Object.keys(CURRENCIES).map((code) => (
                <option key={code} value={code} className="bg-white text-stone-800">
                  {code} ({CURRENCIES[code as CurrencyCode].symbol.trim()})
                </option>
              ))}
            </select>
          </div>

          {/* Download Source ZIP Button */}
          <button
            onClick={onDownloadZip}
            className="hidden sm:inline-flex items-center gap-1.5 text-xs font-medium text-stone-700 bg-white border border-stone-300 hover:border-stone-400 hover:bg-stone-50 px-2.5 py-2 rounded-lg transition-colors shadow-2xs cursor-pointer whitespace-nowrap"
            title="Download full project source code as a ZIP archive"
          >
            <Download className="w-3.5 h-3.5 text-stone-600" />
            <span>Export ZIP</span>
          </button>

          {/* Wishlist Button */}
          <button
            onClick={onOpenWishlist}
            className="relative p-2 text-stone-700 hover:text-stone-900 transition-colors rounded-lg hover:bg-stone-100 cursor-pointer"
            title="View saved wishlist"
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 bg-stone-800 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Primary Action: Shopping Bag Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-2 bg-[#2D2A26] text-white hover:bg-stone-800 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all shadow-sm cursor-pointer whitespace-nowrap"
            aria-label="Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Bag</span>
            <span className="bg-stone-700 text-stone-200 text-xs px-1.5 py-0.2 rounded-full tabular-nums">
              {cartCount}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
