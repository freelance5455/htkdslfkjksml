import React from 'react';
import { Volume2, VolumeX, ScrollText, Smartphone, Monitor, Crown, Sparkles } from 'lucide-react';
import { audioService } from '../services/audioService';

interface HeaderProps {
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenHistory: () => void;
  historyCount: number;
  phoneFrameMode: boolean;
  onTogglePhoneFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  soundEnabled,
  onToggleSound,
  onOpenHistory,
  historyCount,
  phoneFrameMode,
  onTogglePhoneFrame,
}) => {
  return (
    <header className="px-4 py-3 bg-gradient-to-r from-[#0d0f17] via-[#141724] to-[#0d0f17] border-b border-amber-500/20 select-none relative z-20 shadow-lg">
      <div className="flex items-center justify-between gap-2">
        {/* VIP Brand Title */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 p-[1px] shadow-lg shadow-amber-500/20">
              <div className="w-full h-full bg-[#0a0c13] rounded-[7px] flex items-center justify-center">
                <Crown className="w-4 h-4 text-amber-400" />
              </div>
            </div>
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-vip text-xs md:text-sm font-extrabold tracking-wider gold-gradient-text uppercase">
                VIP CALCULATOR
              </span>
              <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-amber-500/15 border border-amber-400/30 text-amber-300">
                PRO AI
              </span>
            </div>
            <p className="text-[10px] text-amber-200/50 font-mono tracking-widest flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-amber-400/70" />
              FORMULA MASTER AI
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              audioService.triggerHaptic('light');
            }}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-medium transition-all duration-150 flex items-center gap-1.5 border ${
              soundEnabled
                ? 'bg-amber-500/15 border-amber-400/40 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.2)]'
                : 'bg-zinc-900/80 border-zinc-700/50 text-zinc-400 hover:text-zinc-200'
            }`}
            title={soundEnabled ? 'Mute Web Audio' : 'Enable Tactile Audio'}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Audio</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mute</span>
              </>
            )}
          </button>

          {/* History Tape Drawer Button */}
          <button
            onClick={() => {
              audioService.playKeyClick();
              onOpenHistory();
            }}
            className="relative px-2.5 py-1.5 rounded-lg text-xs font-mono font-medium bg-zinc-900/90 hover:bg-zinc-800 border border-amber-400/30 text-amber-300 transition-all flex items-center gap-1.5 shadow-sm hover:border-amber-400/60"
            title="Open Calculation Tape History"
          >
            <ScrollText className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Tape</span>
            {historyCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-500 text-black font-mono">
                {historyCount > 99 ? '99+' : historyCount}
              </span>
            )}
          </button>

          {/* Device Frame View Switcher (Android preview toggle) */}
          <button
            onClick={() => {
              audioService.playKeyClick();
              onTogglePhoneFrame();
            }}
            className="p-1.5 rounded-lg bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700/60 text-zinc-300 hover:text-amber-300 transition-all"
            title={phoneFrameMode ? 'Switch to Fullscreen Layout' : 'Preview in Android Smartphone Frame'}
          >
            {phoneFrameMode ? (
              <Monitor className="w-4 h-4" />
            ) : (
              <Smartphone className="w-4 h-4 text-amber-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
