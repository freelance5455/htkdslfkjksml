import React, { useState } from 'react';
import { Calendar, CloudCheck, LogOut, RefreshCw } from 'lucide-react';
import { calculateDaysLeft, getActiveStreakCount, getCompletedChaptersCount } from '../utils/trackerLogic';
import { StartedChaptersStore, StatusStore, StreakData, SubItemStore } from '../types';
import { User } from '../firebase';

export type CloudSyncState = 'idle' | 'syncing' | 'synced' | 'error';

interface HeaderProps {
  statusStore: StatusStore;
  subItemStore?: SubItemStore;
  startedStore: StartedChaptersStore;
  streak: StreakData | null;
  targetDate: string;
  backlogCount: number;
  cloudUser: User | null;
  cloudSyncState?: CloudSyncState;
  onSignOut: () => void;
  onOpenBacklog: () => void;
  onChangeTargetDate: (newDate: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  statusStore,
  subItemStore = {},
  startedStore,
  streak,
  targetDate,
  backlogCount,
  cloudUser,
  cloudSyncState = 'synced',
  onSignOut,
  onOpenBacklog,
  onChangeTargetDate,
}) => {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showAccountMenu, setShowAccountMenu] = useState(false);
  const [tempDate, setTempDate] = useState(targetDate);

  const daysLeft = calculateDaysLeft(targetDate);
  const activeStreak = getActiveStreakCount(streak);
  const { done: chDone, started: chStarted } = getCompletedChaptersCount(
    statusStore,
    startedStore,
    subItemStore
  );

  const handleSaveDate = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempDate) {
      onChangeTargetDate(tempDate);
      setShowDatePicker(false);
    }
  };

  return (
    <header className="mb-3.5 relative">
      {/* Top Title Bar */}
      <div className="flex items-center justify-between gap-2 mb-4">
        <h1 className="text-[18px] sm:text-[19px] font-extrabold tracking-[-0.4px] text-white flex items-center gap-2 leading-tight">
          <span>📚</span>
          <span>NEET Study Material Tracker</span>
        </h1>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              setShowDatePicker(!showDatePicker);
              setShowAccountMenu(false);
            }}
            title="Set Target Exam Date"
            aria-label="Set Target Exam Date"
            className="w-[38px] h-[38px] rounded-full bg-white/[0.09] hover:bg-white/[0.15] text-zinc-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
          </button>

          {/* Signed-in Google Profile & Auto-Sync Badge */}
          {cloudUser && (
            <button
              type="button"
              onClick={() => {
                setShowAccountMenu(!showAccountMenu);
                setShowDatePicker(false);
              }}
              title={`Signed in as ${cloudUser.email || cloudUser.displayName || 'User'}`}
              aria-label="Google Account & Sync Status"
              className="h-[38px] pl-1.5 pr-2.5 rounded-full bg-white/[0.09] hover:bg-white/[0.15] border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {cloudUser.photoURL ? (
                <img
                  src={cloudUser.photoURL}
                  alt={cloudUser.displayName || 'Account'}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full border border-purple-400/50"
                />
              ) : (
                <div className="w-6 h-6 rounded-full bg-purple-600 text-white font-bold text-[11px] flex items-center justify-center">
                  {(cloudUser.displayName || cloudUser.email || 'U')[0].toUpperCase()}
                </div>
              )}
              {cloudSyncState === 'syncing' ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-purple-300" />
              ) : (
                <CloudCheck className="w-3.5 h-3.5 text-emerald-400" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Account Popover Drawer */}
      {showAccountMenu && cloudUser && (
        <div className="mb-3 p-3 rounded-2xl bg-[#141419]/95 border border-[#2a2438] flex items-center justify-between gap-3 text-xs">
          <div className="min-w-0">
            <div className="font-bold text-white truncate">
              {cloudUser.displayName || 'NEET Aspirant'}
            </div>
            <div className="text-[11px] text-zinc-400 truncate">{cloudUser.email}</div>
            <div className="text-[10px] text-emerald-400 font-semibold mt-0.5 flex items-center gap-1">
              <span>●</span>
              <span>
                {cloudSyncState === 'syncing'
                  ? 'Saving changes to Google Cloud...'
                  : 'Auto-synced with your Google account'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setShowAccountMenu(false);
              onSignOut();
            }}
            className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      )}

      {/* Date Picker Drawer */}
      {showDatePicker && (
        <form
          onSubmit={handleSaveDate}
          className="mb-3 p-3 rounded-2xl bg-[#141419]/95 border border-[#2a2438] flex flex-wrap items-center justify-between gap-2 text-xs"
        >
          <div className="flex items-center gap-2">
            <span className="text-zinc-300 font-medium">Target NEET Date:</span>
            <input
              type="date"
              value={tempDate}
              onChange={(e) => setTempDate(e.target.value)}
              className="bg-[#0e0e13] border border-[#2a2438] rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="px-3 py-1 rounded-lg bg-white text-[#0b0b0f] font-bold hover:bg-zinc-200 transition-colors cursor-pointer"
            >
              Save
            </button>
            <button
              type="button"
              onClick={() => setShowDatePicker(false)}
              className="px-2.5 py-1 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700 transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Dashboard Tiles (Moctale Style) */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        {/* Days to NEET */}
        <div
          onClick={() => setShowDatePicker(true)}
          className="rounded-2xl border border-[#2a2438] bg-[#141419]/85 py-3.5 px-1.5 text-center cursor-pointer hover:border-purple-500/40 transition-all backdrop-blur-sm"
        >
          <div className="moc-num text-[32px] sm:text-[34px] font-extrabold tracking-[-1.5px] leading-none">
            {daysLeft}
          </div>
          <div className="text-[10px] font-semibold text-[#9a9aa8] uppercase tracking-[0.6px] mt-1.5">
            Days to NEET
          </div>
        </div>

        {/* Day Streak */}
        <div className="rounded-2xl border border-[#2a2438] bg-[#141419]/85 py-3.5 px-1.5 text-center backdrop-blur-sm">
          <div className="moc-num-streak text-[32px] sm:text-[34px] font-extrabold tracking-[-1.5px] leading-none">
            {activeStreak > 0 ? activeStreak : '—'}
          </div>
          <div className="text-[10px] font-semibold text-[#9a9aa8] uppercase tracking-[0.6px] mt-1.5">
            Day Streak
          </div>
        </div>

        {/* Chapters Done */}
        <div className="rounded-2xl border border-[#2a2438] bg-[#141419]/85 py-3.5 px-1.5 text-center backdrop-blur-sm">
          <div className="moc-num text-[32px] sm:text-[34px] font-extrabold tracking-[-1.5px] leading-none">
            {chStarted > 0 ? `${chDone}/${chStarted}` : '—'}
          </div>
          <div className="text-[10px] font-semibold text-[#9a9aa8] uppercase tracking-[0.6px] mt-1.5">
            Ch. Done
          </div>
        </div>
      </div>

      {/* Backlog Flashcards Button */}
      <button
        type="button"
        onClick={onOpenBacklog}
        style={{
          background: 'linear-gradient(180deg, #2b1445 0%, #1b0d2c 100%)',
        }}
        className="w-full py-[13px] px-4 rounded-2xl border border-[#452473] text-white font-semibold text-[14px] flex items-center justify-center gap-2 hover:border-purple-400/70 transition-all shadow-lg shadow-purple-950/40 active:scale-[0.99] cursor-pointer"
      >
        <span>⚡ Backlog flashcards</span>
        <span className="px-2.5 py-0.5 rounded-full text-[12px] font-bold bg-[#e0533c] text-white">
          {backlogCount}
        </span>
      </button>
    </header>
  );
};
