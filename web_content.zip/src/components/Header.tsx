import React from 'react';
import { PWAInstallButton } from './PWAInstallButton';
import { Moon, Clock, Sliders } from 'lucide-react';

interface Props {
  activeTab: 'player' | 'library' | 'playlists' | 'dsp' | 'search' | 'widgets';
  onSelectTab: (tab: 'player' | 'library' | 'playlists' | 'dsp' | 'search' | 'widgets') => void;
  onOpenSleepTimer: () => void;
  sleepRemaining: number | null;
  onOpenWidgetSim: () => void;
}

export const Header: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  onOpenSleepTimer,
  sleepRemaining,
  onOpenWidgetSim,
}) => {
  const formatSleep = (sec: number) => {
    const m = Math.floor(sec / 60);
    return `${m}m`;
  };

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 sm:gap-8 px-4 py-3">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <button
          onClick={() => onSelectTab('player')}
          className="text-lg font-bold tracking-tight text-white flex items-center gap-2 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
        >
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-500 to-pink-500 flex items-center justify-center text-white text-xs font-black shadow-md shadow-indigo-500/30">
            AS
          </div>
          <span>AuraSound</span>
        </button>

        {/* Zone 2: 4-5 concise single-line navigation links */}
        <nav className="flex items-center gap-1 sm:gap-6 text-xs sm:text-sm font-medium text-slate-400 overflow-x-auto py-1">
          <button
            onClick={() => onSelectTab('player')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'player'
                ? 'text-white font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Reproductor
          </button>
          <button
            onClick={() => onSelectTab('library')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'library'
                ? 'text-white font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Biblioteca
          </button>
          <button
            onClick={() => onSelectTab('playlists')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'playlists'
                ? 'text-white font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Listas
          </button>
          <button
            onClick={() => onSelectTab('dsp')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'dsp'
                ? 'text-white font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Ecualizador
          </button>
          <button
            onClick={() => onSelectTab('search')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'search'
                ? 'text-white font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Buscar
          </button>
        </nav>

        {/* Zone 3: 1 primary action + PWA install */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Sleep Timer Indicator */}
          <button
            onClick={onOpenSleepTimer}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition whitespace-nowrap shrink-0 ${
              sleepRemaining !== null
                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Temporizador de apagado automático"
          >
            <Moon className="w-3.5 h-3.5" />
            {sleepRemaining !== null && (
              <span className="font-mono tabular-nums text-[11px]">
                {formatSleep(sleepRemaining)}
              </span>
            )}
          </button>

          {/* In-App PWA Install and Widget Sim button */}
          <PWAInstallButton onOpenWidgetSim={onOpenWidgetSim} />
        </div>
      </div>
    </header>
  );
};
