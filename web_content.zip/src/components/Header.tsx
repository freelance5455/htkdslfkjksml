"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";

type InstallEvent = Event & { prompt: () => Promise<void> };

export default function Header() {
  const { lang, setLang, t } = useLang();
  const [installEvt, setInstallEvt] = useState<InstallEvent | null>(null);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as InstallEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link href="/" className="flex items-center gap-2 font-extrabold text-slate-900">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-indigo-600 to-fuchsia-500 text-lg text-white shadow">
            ✈
          </span>
          <span className="text-lg tracking-tight">{t("brand")}</span>
        </Link>
        <nav className="flex items-center gap-1 text-sm font-medium sm:gap-2">
          <Link href="/" className="hidden rounded-lg px-3 py-2 text-slate-600 hover:bg-slate-100 sm:block">
            {t("home")}
          </Link>
          <Link href="/bookings" className="rounded-lg px-3 py-2 text-slate-600 hover:bg-slate-100">
            {t("myBookings")}
          </Link>
          {installEvt && (
            <button
              onClick={() => installEvt.prompt().then(() => setInstallEvt(null))}
              className="hidden rounded-lg bg-indigo-50 px-3 py-2 text-indigo-700 hover:bg-indigo-100 sm:block"
            >
              ⬇ {t("installApp")}
            </button>
          )}
          <button
            onClick={() => setLang(lang === "ar" ? "en" : "ar")}
            className="rounded-lg border border-slate-200 px-3 py-2 text-slate-700 hover:bg-slate-50"
            aria-label="Language"
          >
            {lang === "ar" ? "EN" : "عربي"}
          </button>
        </nav>
      </div>
    </header>
  );
}
