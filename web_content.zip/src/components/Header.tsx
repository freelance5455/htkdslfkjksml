import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { NavTab } from '../types/index.ts';

export const Header: React.FC = () => {
  const { currentTab, setCurrentTab, coins, diamonds, ign, uid, setIsDepositModalOpen, setIsAuthModalOpen, showToast } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { key: NavTab; label: string }[] = [
    { key: 'home', label: 'Home' },
    { key: 'tournaments', label: 'Tournaments' },
    { key: 'match-room', label: 'Match Room' },
    { key: 'wallet', label: 'Add Coins / Wallet' },
    { key: 'player-profile', label: 'Player Profile' },
  ];

  const handleNavClick = (tab: NavTab) => {
    setCurrentTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header className="fixed top-0 left-0 w-full z-50 bg-[#0b0e14]/90 backdrop-blur-xl shadow-[0_4px_24px_rgba(0,0,0,0.6)]">
        <div className="h-20 w-full px-4 sm:px-6 lg:px-10 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2 group text-left cursor-pointer"
            >
              <img
                alt="IGNITE FF Logo"
                className="h-8 w-auto object-contain"
                src="https://lh3.googleusercontent.com/aida/AEtjO1WMrXVu8fq9UEA1qAUOQXaV0jhcKmyCRUyUCl8tv1bn-tN29ljALZMSW_Na1O_g7VmSpzJW8MT2ty0xPq0aBe6V7_4XZK6j2GYJtpCfhaNa39x8G_LzdrMLBC5HmT1n04PPQZjMVbs-mh7YfWOK6z3MLGUrOVHsSGfvq4RvqjP41LUeyVAqKLdQ6AsF2mStlWPOcH9kOofWJF4BE_BMa0Y8wbeSmB855rvv-fPNrfspxJDPgtYDQi4ngD-1"
              />
              <div className="flex flex-col">
                <span className="font-headline-sm text-headline-sm uppercase tracking-wider text-on-surface group-hover:text-primary transition-colors">
                  IGNITE <span className="text-[#ff5e00]">FF</span>
                </span>
                <span className="font-label-sm text-label-sm uppercase text-tertiary-fixed tracking-widest">
                  Esports Protocol
                </span>
              </div>
            </button>

            <div className="h-8 w-[1px] bg-surface-container-highest hidden lg:block"></div>

            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = currentTab === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => handleNavClick(item.key)}
                    className={`px-4 py-2 uppercase transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#ff5e00] text-[#531900] font-headline-sm rounded font-bold shadow-[0_0_12px_rgba(255,94,0,0.3)]'
                        : 'rounded font-label-md text-label-md text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            {/* Currency Pill */}
            <div
              onClick={() => handleNavClick('wallet')}
              className="cursor-pointer hidden sm:flex items-center gap-2 bg-[#1d2026] px-3.5 py-1.5 rounded shadow-inner hover:bg-[#272a31] transition-colors"
              title="Click to manage coins & wallet"
            >
              <div className="flex items-center gap-1">
                <span className="text-base">💎</span>
                <span className="font-label-md text-label-md text-[#00dbe9] font-bold">{diamonds}</span>
              </div>
              <span className="text-surface-variant">|</span>
              <div className="flex items-center gap-1">
                <span className="text-base">🪙</span>
                <span className="font-label-md text-label-md text-[#ffcb8d] font-bold">{coins}</span>
              </div>
            </div>

            {/* Deposit CTA */}
            <button
              onClick={() => handleNavClick('wallet')}
              className="hidden md:flex items-center justify-center px-4 py-1.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-md text-label-md uppercase rounded transition-colors shadow-[0_0_12px_rgba(255,94,0,0.35)] cursor-pointer font-bold"
            >
              <span className="material-symbols-outlined text-base mr-1">add_circle</span>Deposit
            </button>

            {/* Auth / Command Center Shortcut */}
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="hidden lg:flex items-center justify-center px-3 py-1.5 bg-surface-container hover:bg-surface-container-high text-tertiary-fixed font-label-sm text-label-sm uppercase rounded transition-colors border border-tertiary/20"
              title="Command Center Auth Terminal"
            >
              <span className="material-symbols-outlined text-sm mr-1">key</span>Terminal
            </button>

            {/* Notifications */}
            <button
              onClick={() => showToast('Match Notification: Solo #1042 custom room unlocks in 15 mins!')}
              className="relative p-2 text-on-surface-variant hover:text-primary transition-colors flex items-center justify-center rounded bg-[#191c22] cursor-pointer"
              title="Notifications"
            >
              <span className="material-symbols-outlined text-xl">notifications</span>
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#ff5e00] ring-2 ring-[#0b0e14] animate-pulse"></span>
            </button>

            {/* Profile Pill */}
            <button
              onClick={() => handleNavClick('player-profile')}
              className="flex items-center gap-2 bg-[#191c22] p-1 pr-3 rounded hover:bg-[#1d2026] transition-colors cursor-pointer"
            >
              <div className="relative">
                <img
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuC9zYtka30OJFJCZywUUT7H_O8UHMa9dUGVrz81Gyq5ojHWZZuyBcsqe49S5rUqaK-s1Yztco1pUz7Lv2k-iRJG9ptLhxXRMKeAeJ2eA6bkh9UlseNNjZ7JEhPpbrxNF0CZd81nTM2SyfynjuVQ8hNDUagGNByNnPKa8km6ELoXqqJHawOSEcGua1MT6iYDHhFn0WME2EQgcTbPHLzrMJlwWbiXFi7larHDVMX8sFjPxHwNX9W1fjj1zw"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-[#00a3ad] rounded-full ring-2 ring-[#0b0e14]"></span>
              </div>
              <div className="hidden xl:flex flex-col text-left">
                <span className="font-label-md text-label-md text-on-surface uppercase leading-none">{ign}</span>
                <span className="font-label-sm text-label-sm text-primary uppercase leading-none mt-1">UID: {uid}</span>
              </div>
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded bg-surface-container text-on-surface hover:text-primary transition-colors cursor-pointer"
              aria-label="Toggle Navigation Menu"
            >
              <span className="material-symbols-outlined text-2xl">
                {mobileMenuOpen ? 'close' : 'menu'}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#0b0e14] border-t border-surface-container-high px-4 py-4 flex flex-col gap-2 shadow-2xl">
            {/* Mobile Currency Strip */}
            <div className="flex sm:hidden items-center justify-between bg-[#191c22] p-3 rounded mb-2">
              <div className="flex items-center gap-1.5">
                <span className="text-base">💎</span>
                <span className="font-label-md text-[#00dbe9] font-bold">{diamonds} Diamonds</span>
              </div>
              <span className="text-surface-variant">|</span>
              <div className="flex items-center gap-1.5">
                <span className="text-base">🪙</span>
                <span className="font-label-md text-[#ffcb8d] font-bold">{coins} Coins</span>
              </div>
            </div>

            {navItems.map((item) => {
              const isActive = currentTab === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => handleNavClick(item.key)}
                  className={`px-4 py-2.5 text-left uppercase transition-all rounded font-label-md text-label-md ${
                    isActive
                      ? 'bg-[#ff5e00] text-[#531900] font-bold shadow-md'
                      : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}

            <div className="pt-2 border-t border-surface-container-high flex gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleNavClick('wallet');
                }}
                className="flex-1 py-2.5 bg-[#ff5e00] text-[#531900] font-label-md text-label-md uppercase font-bold text-center rounded"
              >
                Deposit Coins
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsAuthModalOpen(true);
                }}
                className="py-2.5 px-4 bg-surface-container text-tertiary font-label-md text-label-md uppercase font-bold text-center rounded border border-tertiary/30"
              >
                Terminal
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
