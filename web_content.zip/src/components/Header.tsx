import React from "react";
import { Sparkles, Images, Lightbulb, Smartphone, ImagePlus, ShieldCheck, ShieldAlert, BrainCircuit } from "lucide-react";
import { ActiveTab } from "../types";

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  galleryCount: number;
  hasApiKey: boolean | null;
  userApiKey: string;
  onOpenApkModal: () => void;
  onOpenKeyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  galleryCount,
  hasApiKey,
  userApiKey,
  onOpenApkModal,
  onOpenKeyModal,
}) => {
  const isKeyActive = Boolean(userApiKey.trim() || hasApiKey);
  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Brand Logo & Title */}
        <div className="flex items-center justify-between w-full sm:w-auto">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab("studio")}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 shadow-lg shadow-purple-500/20 text-white font-bold">
              <Sparkles className="w-5 h-5 animate-pulse" />
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  Text to Image AI
                </h1>
                <span className="px-1.5 py-0.5 text-[10px] font-semibold tracking-wide uppercase rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  v2.5 APK
                </span>
              </div>
              <p className="text-xs text-slate-400">Generative Image Studio & Prompt Suite</p>
            </div>
          </div>

          {/* Mobile APK Action Button */}
          <button
            onClick={onOpenApkModal}
            className="sm:hidden flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium hover:bg-emerald-500/20 transition"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>APK App</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center p-1 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-medium w-full sm:w-auto justify-center overflow-x-auto">
          <button
            onClick={() => setActiveTab("studio")}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
              activeTab === "studio"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 font-semibold"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Studio</span>
          </button>

          <button
            onClick={() => setActiveTab("mindmap")}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
              activeTab === "mindmap"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 font-semibold"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <BrainCircuit className="w-4 h-4 text-emerald-400" />
            <span>Mind Map</span>
          </button>

          <button
            onClick={() => setActiveTab("editor")}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
              activeTab === "editor"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 font-semibold"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <ImagePlus className="w-4 h-4" />
            <span>Image Edit</span>
          </button>

          <button
            onClick={() => setActiveTab("gallery")}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all relative ${
              activeTab === "gallery"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 font-semibold"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <Images className="w-4 h-4" />
            <span>Gallery</span>
            {galleryCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 text-[10px] rounded-full bg-purple-500 text-white font-bold">
                {galleryCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("inspiration")}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
              activeTab === "inspiration"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 font-semibold"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <Lightbulb className="w-4 h-4" />
            <span>Prompts</span>
          </button>
        </nav>

        {/* Right Actions: APK Info & API Key Badge */}
        <div className="hidden sm:flex items-center gap-2">
          <button
            onClick={onOpenKeyModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
              isKeyActive
                ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20"
                : "bg-purple-500/10 text-purple-300 border-purple-500/30 hover:bg-purple-500/20 animate-pulse"
            }`}
            title="Configure Free Gemini API Key"
          >
            {isKeyActive ? <ShieldCheck className="w-4 h-4 text-emerald-400" /> : <ShieldAlert className="w-4 h-4 text-purple-400" />}
            <span>{userApiKey ? "Custom Key Active" : isKeyActive ? "AI Engine Ready" : "Free Key Setup"}</span>
          </button>

          <button
            onClick={onOpenApkModal}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600/20 to-teal-600/20 hover:from-emerald-600/30 hover:to-teal-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold shadow-sm transition"
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>Get Mobile APK</span>
          </button>
        </div>
      </div>
    </header>
  );
};
