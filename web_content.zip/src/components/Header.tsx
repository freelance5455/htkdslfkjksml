import React from 'react';
import { useApp } from '../context/AppContext';
import { SecretGossipLogo } from './SecretGossipLogo';
import { 
  ChevronLeft, 
  Search, 
  Plus,
  Globe 
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    user, 
    activeTab, 
    setActiveTab, 
    setIsCreateOpen, 
    searchQuery, 
    setSearchQuery, 
    language, 
    setIsLanguageModalOpen, 
    t 
  } = useApp();

  const SCREEN_TITLES: Record<string, { title: string; icon: string }> = {
    feed: { title: t.home, icon: '🔥' },
    explore: { title: t.explore, icon: '🧭' },
    chat: { title: t.chat, icon: '💬' },
    games: { title: t.games, icon: '🎮' },
    leaderboard: { title: t.leaderboard, icon: '🏆' },
    referral: { title: t.referral, icon: '🎁' },
    profile: { title: t.profile, icon: '👤' },
  };

  const currentScreen = SCREEN_TITLES[activeTab] || SCREEN_TITLES.feed;

  return (
    <header className="sticky top-0 z-30 bg-[#090b14]/98 backdrop-blur-md border-b border-slate-800/80 px-2.5 sm:px-4 py-2 transition-all w-full overflow-hidden select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-3">
        
        {/* Left Section: [+] Add Whisper Button + Back Button + Brand Logo */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0 min-w-0">
          
          {/* TOP LEFT QUICK "+" ADD WHISPER BUTTON */}
          <button
            onClick={() => setIsCreateOpen(true)}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-bold shadow-md shadow-cyan-500/25 active:scale-95 transition-all flex items-center justify-center shrink-0 group"
            title="Whisper a new confession / Add Whisper"
          >
            <Plus className="w-5 h-5 text-slate-950 group-hover:rotate-90 transition-transform duration-200 stroke-[3]" />
          </button>

          {/* Back Button Arrow (Visible when user is NOT on Home Feed) */}
          {activeTab !== 'feed' ? (
            <button
              onClick={() => setActiveTab('feed')}
              className="flex items-center gap-1 px-2 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 transition-all shadow-md group active:scale-95 shrink-0"
              title={t.backToFeeds}
            >
              <ChevronLeft className="w-4 h-4 text-cyan-300 stroke-[3] group-hover:-translate-x-0.5 transition-transform" />
              <span className="text-xs font-bold text-slate-200 group-hover:text-white hidden sm:inline">
                {t.back}
              </span>
            </button>
          ) : null}

          {/* Brand Logo & Active Screen Title */}
          <div 
            onClick={() => setActiveTab('feed')}
            className="cursor-pointer flex items-center gap-1.5 group min-w-0"
          >
            <div className="flex items-center gap-1.5">
              <SecretGossipLogo size="sm" className="sm:hidden" showText={activeTab === 'feed'} />
              <SecretGossipLogo size="md" className="hidden sm:flex" />
            </div>

            {/* If on a subscreen, show page name badge */}
            {activeTab !== 'feed' && (
              <div className="flex items-center gap-1 pl-1.5 border-l border-slate-800 min-w-0">
                <span className="text-xs shrink-0">{currentScreen.icon}</span>
                <span className="font-display font-bold text-xs text-slate-200 truncate max-w-[90px] sm:max-w-none">
                  {currentScreen.title}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Center: Search input (hidden on mobile, visible on tablet/desktop) */}
        <div className="flex-1 max-w-sm relative hidden md:block mx-2">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-slate-900/90 border border-slate-800 text-xs rounded-full pl-8 pr-3 py-1.5 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/60 focus:ring-1 focus:ring-cyan-500/30 transition-all"
          />
        </div>

        {/* Right Zone: Clean & Minimal (Language Switcher & User Profile) */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          
          {/* Language Switcher Pill */}
          <button
            onClick={() => setIsLanguageModalOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-[10.5px] sm:text-xs font-bold text-slate-300 transition-all shrink-0 active:scale-95 shadow-sm"
            title="Switch Language (Hinglish / English / हिन्दी)"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-cyan-300 uppercase text-[9.5px] sm:text-[10px]">
              {language === 'hi' ? 'हिन्दी' : language === 'hinglish' ? 'HING' : 'EN'}
            </span>
          </button>

          {/* User Persona Profile Button */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-1.5 p-1 sm:pl-1.5 sm:pr-2.5 rounded-full border transition-all shrink-0 ${
              activeTab === 'profile' 
                ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-500/20' 
                : 'bg-slate-900/90 border-slate-800 hover:border-cyan-500/50 text-slate-200'
            }`}
            title="My Anonymous Profile & Masked ID"
          >
            <span className="text-sm">{user.avatarEmoji}</span>
            <span className="text-xs font-medium hidden sm:inline truncate max-w-[70px]">
              {user.avatarName.split(' ')[0]}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
