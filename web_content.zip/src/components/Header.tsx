import React from 'react';
import {
  Settings,
  HardDrive,
  Search,
  Sparkles,
  Menu,
  ShieldCheck,
  Bot,
  Sliders,
  Plus,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { ChatSettings, ChatSession } from '../types/index.ts';
import { TokenUsageWidget } from './TokenUsageWidget.tsx';
import { getModelDisplayName } from '../utils/models.ts';

interface HeaderProps {
  currentSession: ChatSession | null;
  settings: ChatSettings;
  effectiveSettings: ChatSettings;
  isStreaming?: boolean;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
  chatWidth?: 'standard' | 'full';
  onToggleChatWidth?: () => void;
  onOpenSettings: () => void;
  onOpenStorage: () => void;
  onOpenSearch: () => void;
  onToggleSidebar: () => void;
  onNewChat: () => void;
  onUpdateSessionSettings: (updated: Partial<ChatSettings>) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentSession,
  settings,
  effectiveSettings,
  isStreaming,
  isFullscreen,
  onToggleFullscreen,
  chatWidth,
  onToggleChatWidth,
  onOpenSettings,
  onOpenStorage,
  onOpenSearch,
  onToggleSidebar,
  onNewChat,
  onUpdateSessionSettings,
}) => {
  const currentModelName = getModelDisplayName(effectiveSettings.model);

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between z-20 shrink-0">
      {/* Left: Mobile sidebar toggle + Title & Local Badge */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        <button
          onClick={onToggleSidebar}
          aria-label="Buka menu riwayat"
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 sm:gap-2.5">
          <div className="w-9 h-9 rounded-xl overflow-hidden bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 shrink-0">
            {effectiveSettings.botAvatar && (effectiveSettings.botAvatar.startsWith('data:') || effectiveSettings.botAvatar.startsWith('http')) ? (
              <img src={effectiveSettings.botAvatar} alt="Bot Avatar" className="w-full h-full object-cover" />
            ) : effectiveSettings.botAvatar ? (
              <span className="text-base">{effectiveSettings.botAvatar}</span>
            ) : (
              <Bot className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-base tracking-tight">NexusAI</span>
              <button
                onClick={onOpenStorage}
                title="Semua obrolan & data Anda 100% tersimpan di browser lokal Anda (Klik untuk rincian)"
                className="hidden xl:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-950/70 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/60 transition cursor-pointer"
              >
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>100% Data Lokal</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-[140px] sm:max-w-[220px]">
              {currentSession ? currentSession.title : 'Chatbot AI Pribadi'}
            </p>
          </div>
        </div>
      </div>

      {/* Center: Token Usage Stats & Indicator */}
      <div className="flex items-center gap-2">
        <TokenUsageWidget
          tokenStats={currentSession?.tokenStats}
          settings={effectiveSettings}
          onOpenSettings={onOpenSettings}
          isStreaming={isStreaming}
        />
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1 sm:gap-2">
        {/* Quick Model badge */}
        <button
          onClick={onOpenSettings}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-xs text-slate-300 hover:text-white transition"
          title="Ganti model Gemini atau konfigurasi parameter"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-medium text-xs">{currentModelName}</span>
        </button>

        <button
          onClick={onOpenSearch}
          title="Cari riwayat pesan (Ctrl+K)"
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <Search className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenStorage}
          title="Manajemen Penyimpanan & Cadangan Lokal"
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition"
        >
          <HardDrive className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden md:inline">Penyimpanan</span>
        </button>

        {/* Chat Width Toggle (Full Screen Widescreen vs Standard) */}
        {onToggleChatWidth && (
          <button
            onClick={onToggleChatWidth}
            title={chatWidth === 'full' ? 'Beralih ke Lebar Standar (Terpusat)' : 'Beralih ke Lebar Penuh (Full Screen Widescreen)'}
            className="hidden lg:flex items-center gap-1 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            {chatWidth === 'full' ? (
              <Minimize2 className="w-4 h-4 text-indigo-400" />
            ) : (
              <Maximize2 className="w-4 h-4 text-slate-400" />
            )}
          </button>
        )}

        {/* Fullscreen Mode Toggle */}
        {onToggleFullscreen && (
          <button
            onClick={onToggleFullscreen}
            title={isFullscreen ? 'Keluar dari Layar Penuh (Esc)' : 'Mode Layar Penuh (Full Screen)'}
            className={`p-2 rounded-lg transition cursor-pointer ${
              isFullscreen
                ? 'text-amber-300 bg-amber-950/60 border border-amber-600/40 hover:bg-amber-900/50 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {isFullscreen ? (
              <Minimize className="w-4 h-4" />
            ) : (
              <Maximize className="w-4 h-4" />
            )}
          </button>
        )}

        <button
          onClick={onOpenSettings}
          title="Buka Pengaturan AI & Sensor"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-indigo-600/90 hover:bg-indigo-600 text-white shadow-sm shadow-indigo-600/30 transition"
        >
          <Settings className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Pengaturan</span>
        </button>

        <button
          onClick={onNewChat}
          title="Buat Percakapan Baru"
          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition sm:hidden"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
