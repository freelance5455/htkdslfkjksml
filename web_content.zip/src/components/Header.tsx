import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { 
  Phone, 
  MessageCircle, 
  Clock, 
  Search, 
  ShoppingCart, 
  ShieldCheck, 
  DownloadCloud, 
  Menu, 
  X, 
  HelpCircle,
  Wrench,
  Sparkles,
  MapPin,
  Laptop
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    t, 
    cartCount, 
    setIsCartOpen, 
    setIsAdminModalOpen,
    setIsPWAGuideOpen,
    searchQuery,
    setSearchQuery,
    shopSettings,
    openServiceModal
  } = useApp();

  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showSearchMobile, setShowSearchMobile] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
      {/* Top micro bar for Indian store trust */}
      <div className="bg-slate-900 border-b border-slate-800/80 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Numbers & Working Hours */}
          <div className="flex items-center gap-3 sm:gap-6 text-slate-300 flex-wrap">
            <div className="flex items-center gap-1.5 font-medium">
              <Phone className="w-3.5 h-3.5 text-blue-400" />
              <span>{language === 'hi' ? 'फोन:' : 'Call:'}</span>
              <a href={`tel:${shopSettings.phone1}`} className="hover:text-blue-400 transition font-semibold text-white">
                {shopSettings.phone1}
              </a>
              <span className="text-slate-500">|</span>
              <a href={`tel:${shopSettings.phone2}`} className="hover:text-blue-400 transition font-semibold text-white">
                {shopSettings.phone2}
              </a>
            </div>

            <div className="hidden md:flex items-center gap-1.5 text-slate-400">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{shopSettings.openingHours[language]}</span>
            </div>
          </div>

          {/* Right side utilities: Language Switcher, PWA Guide */}
          <div className="flex items-center gap-3">
            {/* PWA Help button */}
            <button
              onClick={() => setIsPWAGuideOpen(true)}
              className="flex items-center gap-1 text-blue-300 hover:text-white transition font-medium"
              title="PWA Android Install & Free Guide"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'hi' ? 'ऐप कैसे लगाएं?' : 'App Guide'}</span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2 py-0.5 rounded text-xs font-semibold transition ${
                  language === 'hi'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                हिंदी
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded text-xs font-semibold transition ${
                  language === 'en'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-3 sm:gap-6">
          {/* Logo & Brand Name */}
          <a href="#" className="flex items-center gap-3 group flex-shrink-0">
            <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 via-blue-700 to-slate-900 border border-blue-400/30 shadow-lg shadow-blue-500/20 group-hover:border-blue-400 transition">
              <img src="/icon.svg" alt="AK Golu Computer" className="h-8 w-8 object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-extrabold tracking-tight text-white group-hover:text-blue-400 transition">
                  A K Golu Computer
                </span>
                <span className="hidden lg:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  CCTV & IT Hub
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block truncate max-w-xs">
                {language === 'hi' ? 'लैपटॉप, पीसी, सीसीटीवी व प्रिंटर रिपेयर' : 'Laptops, PCs, CCTV & Printers'}
              </p>
            </div>
          </a>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2 bg-slate-900/90 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right Action Icons & Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Mobile Search Toggle */}
            <button
              onClick={() => setShowSearchMobile(!showSearchMobile)}
              className="md:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Quick Service Book Trigger */}
            <button
              onClick={() => openServiceModal()}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-blue-400 border border-blue-500/30 text-xs font-semibold transition"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'रिपेयर बुक करें' : 'Book Repair'}</span>
            </button>

            {/* In-App PWA Install Button (Mandatory as per skill) */}
            {isInstallable && !isInstalled && (
              <button
                onClick={install}
                className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/30 transition animate-pulse"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>{language === 'hi' ? 'ऐप लगाएं' : 'Install App'}</span>
              </button>
            )}

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 border border-slate-700/80 transition flex items-center justify-center"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="w-5 h-5 text-blue-400" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-[11px] font-bold text-white shadow-md animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Admin Access Button */}
            <button
              onClick={() => setIsAdminModalOpen(true)}
              className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition"
              title={t.admin.title}
              aria-label="Admin Area"
            >
              <ShieldCheck className="w-5 h-5" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input dropdown */}
        {showSearchMobile && (
          <div className="mt-3 md:hidden">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
                autoFocus
              />
            </div>
          </div>
        )}

        {/* Mobile Navigation Dropdown */}
        {isMobileMenuOpen && (
          <div className="mt-3 pt-3 border-t border-slate-800 md:hidden flex flex-col gap-2">
            <a
              href="#products"
              onClick={() => setIsMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 font-medium text-sm flex items-center justify-between"
            >
              <span>{t.products}</span>
              <Laptop className="w-4 h-4 text-blue-400" />
            </a>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openServiceModal();
              }}
              className="px-3 py-2 rounded-lg text-left text-slate-200 hover:bg-slate-800 font-medium text-sm flex items-center justify-between"
            >
              <span>{t.services}</span>
              <Wrench className="w-4 h-4 text-emerald-400" />
            </button>
            <a
              href="#offers"
              onClick={() => setIsMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 font-medium text-sm flex items-center justify-between"
            >
              <span>{t.offers}</span>
              <Sparkles className="w-4 h-4 text-amber-400" />
            </a>
            <a
              href="#contact"
              onClick={() => setIsMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 font-medium text-sm flex items-center justify-between"
            >
              <span>{t.contact}</span>
              <MapPin className="w-4 h-4 text-rose-400" />
            </a>

            {/* Mobile PWA Install trigger */}
            {isInstallable && !isInstalled && (
              <button
                onClick={() => {
                  install();
                  setIsMobileMenuOpen(false);
                }}
                className="mt-1 w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-sm shadow-lg"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>{language === 'hi' ? 'फोन में ऐप इनस्टॉल करें' : 'Install App on Phone'}</span>
              </button>
            )}

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                setIsPWAGuideOpen(true);
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-blue-300 font-medium text-xs"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{language === 'hi' ? 'ऐप इनस्टॉल करने की गाइड' : 'How to Install App Guide'}</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
