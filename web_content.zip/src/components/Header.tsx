import React, { useState } from 'react';
import { Settings, Volume2, Calendar, Compass, Moon, Download } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenTimetable: () => void;
  onOpenQibla: () => void;
  onOpenNightTimings: () => void;
  onTestAudio: () => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  onOpenTimetable,
  onOpenQibla,
  onOpenNightTimings,
  onTestAudio,
  activeSection,
  setActiveSection,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-emerald-900/60 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text wordmark */}
        <button
          onClick={() => setActiveSection('prayers')}
          className="text-left group cursor-pointer focus:outline-none"
        >
          <span className="text-xl font-bold tracking-tight text-emerald-400 group-hover:text-emerald-300 transition-colors">
            Salat Sathi
          </span>
        </button>

        {/* Zone 2: 4 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => setActiveSection('prayers')}
            className={`cursor-pointer transition-colors hover:text-white ${
              activeSection === 'prayers' ? 'text-emerald-400 underline decoration-2 underline-offset-8' : ''
            }`}
          >
            Today's Prayers
          </button>
          <button
            onClick={onOpenTimetable}
            className="cursor-pointer transition-colors hover:text-white flex items-center gap-1.5"
          >
            <Calendar className="w-3.5 h-3.5 text-emerald-400" />
            October Timetable
          </button>
          <button
            onClick={onOpenNightTimings}
            className="cursor-pointer transition-colors hover:text-white flex items-center gap-1.5"
          >
            <Moon className="w-3.5 h-3.5 text-emerald-400" />
            Night Timings
          </button>
          <button
            onClick={onOpenQibla}
            className="cursor-pointer transition-colors hover:text-white flex items-center gap-1.5"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            Qibla
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Audio Quick Test */}
          <button
            onClick={onTestAudio}
            title="Test Adhan & Alarm Audio"
            className="flex items-center gap-1.5 rounded-lg border border-emerald-800/80 bg-emerald-950/50 px-3 py-1.5 text-xs font-medium text-emerald-300 hover:bg-emerald-900/60 hover:text-emerald-200 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Test Audio</span>
          </button>

          {/* PWA Install Button */}
          {!isInstalled && isInstallable && (
            <button
              onClick={install}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-emerald-500 transition cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>
          )}

          {!isInstalled && isIOS && (
            <button
              onClick={() => setShowIOSGuide(true)}
              className="flex items-center gap-1.5 rounded-lg border border-emerald-800 bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-emerald-300 hover:bg-slate-800 transition cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install PWA</span>
            </button>
          )}

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            title="Settings & Alarm Delay"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white transition cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* iOS Safari Installation Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-emerald-800/60 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-base font-semibold text-white">Install Salat Sathi on iPhone / iPad</h3>
            <p className="mt-3 text-sm text-slate-300 leading-relaxed">
              To enable reliable offline prayer timetable and standalone audio alerts:
            </p>
            <ol className="mt-3 space-y-2 text-xs text-slate-300 list-decimal list-inside bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <li>Tap the <strong className="text-emerald-400">Share</strong> icon at the bottom of Safari toolbar.</li>
              <li>Scroll down and tap <strong className="text-emerald-400">Add to Home Screen</strong>.</li>
              <li>Tap <strong className="text-emerald-400">Add</strong> in the top-right corner.</li>
            </ol>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-xl bg-emerald-600 py-2.5 text-xs font-semibold text-white hover:bg-emerald-500 transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
