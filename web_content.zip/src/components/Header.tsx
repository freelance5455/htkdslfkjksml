import React, { useState, useRef } from "react";
import {
  Search,
  X,
  Sun,
  Moon,
  Shield,
  Plus,
  User,
  Stamp,
  Check,
  ChevronDown,
  LayoutGrid,
  Grid2X2,
  List,
  Rows3,
  FolderKanban,
  History,
  BrainCircuit,
  Tags,
  SlidersHorizontal,
  Star,
  CheckSquare,
  Trash2
} from "lucide-react";
import { ActiveTab, SortOption, FilterOption, ViewLayout, SectionItem, UserProfile, ThemeAccent } from "../types";
import { THEME_ACCENTS } from "../utils/theme";

interface HeaderProps {

  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  themeAccent: ThemeAccent;
  setThemeAccent: (accent: ThemeAccent) => void;
  sortOption: SortOption;
  setSortOption: (sort: SortOption) => void;
  filterOption: FilterOption;
  setFilterOption: (filter: FilterOption) => void;
  viewLayout: ViewLayout;
  setViewLayout: (l: ViewLayout) => void;
  onOpenNewNote: () => void;
  onOpenCreateMenu: () => void;
  onOpenTrash: () => void;
  onOpenSideGallery: () => void;
  onOpenDocumentHub?: () => void;
  onOpenCommandPalette?: () => void;
  clipsCount: number;
  totalNotesCount: number;
  vaultNotesCount: number;
  trashCount: number;
  sections?: SectionItem[];
  selectedSection?: string;
  onSelectSection?: (sec: string) => void;
  onOpenSectionManager?: () => void;
  profile?: UserProfile;
  onSecretVaultTrigger?: () => void;
  isVaultUnlocked?: boolean;
  onOpenAuthModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  darkMode,
  setDarkMode,
  themeAccent,
  setThemeAccent,
  sortOption,
  setSortOption,
  filterOption,
  setFilterOption,
  viewLayout,
  setViewLayout,
  onOpenNewNote,
  onOpenCreateMenu,
  onOpenTrash,
  onOpenSideGallery,
  onOpenDocumentHub,
  onOpenCommandPalette,
  clipsCount,
  totalNotesCount,
  vaultNotesCount,
  trashCount,
  sections = [],
  selectedSection = "Tümü",
  onSelectSection,
  onOpenSectionManager,
  profile,
  onSecretVaultTrigger,
  isVaultUnlocked = false,
  onOpenAuthModal,
}) => {
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const longPressTimer = useRef<any>(null);

  const startLongPress = () => {
    longPressTimer.current = setTimeout(() => {
      onSecretVaultTrigger?.();
    }, 1500);
  };

  const endLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  const accentList: Array<{ id: ThemeAccent; name: string; hex: string }> = [
    { id: "teal", name: "Zümrüt Teal", hex: "#0d9488" },
    { id: "emerald", name: "Orman Yeşili", hex: "#059669" },
    { id: "blue", name: "Klasik Mavi", hex: "#2563eb" },
    { id: "ocean", name: "Derin Okyanus", hex: "#0284c7" },
    { id: "purple", name: "Ametist Moru", hex: "#9333ea" },
    { id: "rose", name: "Yakut Gül", hex: "#e11d48" },
    { id: "amber", name: "Sıcak Kehribar", hex: "#d97706" },
    { id: "slate", name: "Arduvaz Gri", hex: "#475569" },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-2.5 space-y-2.5">
        
        {/* ROW 1: BRAND LOGO + SEARCH + CREATE BUTTON + PROFILE (NoteSync Minimal Style) */}
        <div className="flex items-center justify-between gap-2 sm:gap-3">
          
          {/* Logo & Section/Workspace Selector */}
          <div className="flex items-center gap-2 select-none shrink-0">
            <div
              onClick={() => setActiveTab("home")}
              onDoubleClick={onSecretVaultTrigger}
              title="VERİTAS (Çift tıklama gizli kasayı tetikler)"
              className="relative w-9 h-9 rounded-2xl overflow-hidden shadow-md ring-1 ring-amber-400/40 transition-transform hover:scale-105 active:scale-95 cursor-pointer shrink-0 bg-[#0a1931]"
            >
              <img
                src="/veritas_logo.jpg"
                alt="VERİTAS Logo"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex flex-col">
              <div
                onClick={() => setActiveTab("home")}
                onDoubleClick={onSecretVaultTrigger}
                className="flex items-center gap-1.5 cursor-pointer"
              >
                <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-wider leading-none">
                  VERİTAS
                </h1>
                <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-md ${themeDef.badgeBg} ${themeDef.badgeText} border`}>
                  {profile?.aiModeEnabled ? "AI Pro" : "Pro"}
                </span>
              </div>

              {/* Workspace / Active Section Subtitle */}
              <div
                onClick={onOpenSectionManager}
                className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 font-medium hover:text-teal-600 dark:hover:text-teal-400 cursor-pointer mt-0.5"
                title="Bölüm değiştir veya yönet"
              >
                <span>{selectedSection === "Tümü" ? "Tüm Notlar" : selectedSection}</span>
                <ChevronDown className="w-2.5 h-2.5 opacity-70" />
              </div>
            </div>
          </div>

          {/* Central Omnibar Search (Streamlined) */}
          <div className="relative flex-1 max-w-lg hidden md:block">
            <div
              onMouseDown={startLongPress}
              onMouseUp={endLongPress}
              onMouseLeave={endLongPress}
              onTouchStart={startLongPress}
              onTouchEnd={endLongPress}
              title="Arama İkonuna Uzun Basma Gizli Kasayı Açar"
              className="absolute left-3 top-1/2 -translate-y-1/2 p-1 cursor-pointer rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700/60 text-slate-400 hover:text-slate-600 transition-all"
            >
              <Search className="w-4 h-4" />
            </div>
            <input
              id="header-omnibar-search"
              type="text"
              value={searchQuery}
              onChange={(e) => {
                const val = e.target.value;
                setSearchQuery(val);
                if (val.trim() === "#kasa" || val.trim() === "#kasa-ac") {
                  setSearchQuery("");
                  onSecretVaultTrigger?.();
                }
              }}
              placeholder="Notlar, görevler, belgeler ve etiketlerde ara... (Gizli Kasa için #kasa yazın)"
              className={`w-full pl-10 pr-14 py-1.5 bg-slate-100/90 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-2xl text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 ${themeDef.ring} transition-all`}
            />
            <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {searchQuery ? (
                <button
                  onClick={() => setSearchQuery("")}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              ) : (
                <kbd
                  onClick={onOpenCommandPalette}
                  className="px-1.5 py-0.2 rounded bg-slate-200/80 dark:bg-slate-700 text-[10px] font-mono text-slate-500 dark:text-slate-400 cursor-pointer"
                >
                  ⌘K
                </kbd>
              )}
            </div>
          </div>

          {/* Right Action Tools & "+ New" Primary Button */}
          <div className="flex items-center gap-1.5 shrink-0">
            
            {/* Theme Accent Picker */}
            <div className="relative">
              <button
                id="theme-accent-btn"
                onClick={() => setShowThemePicker(!showThemePicker)}
                title={`Vurgu Rengi: ${themeDef.name}`}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
              >
                <div
                  className="w-3.5 h-3.5 rounded-full ring-2 ring-white dark:ring-slate-900 shadow-xs"
                  style={{ backgroundColor: themeDef.preview }}
                />
              </button>

              {showThemePicker && (
                <div className="absolute right-0 top-full mt-2 w-52 p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 animate-in fade-in zoom-in-95">
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 px-1">
                    Vurgu Rengi
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {accentList.map((acc) => {
                      const isSelected = themeAccent === acc.id;
                      return (
                        <button
                          key={acc.id}
                          onClick={() => {
                            setThemeAccent(acc.id);
                            setShowThemePicker(false);
                          }}
                          title={acc.name}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                            isSelected ? "ring-2 ring-offset-2 ring-slate-900 dark:ring-white scale-105" : "hover:scale-105 opacity-85 hover:opacity-100"
                          }`}
                          style={{ backgroundColor: acc.hex }}
                        >
                          {isSelected && <Check className="w-4 h-4 text-white drop-shadow-xs" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Dark / Light Mode */}
            <button
              id="theme-toggle-btn"
              onClick={() => setDarkMode(!darkMode)}
              title={darkMode ? "Gündüz Moduna Geç" : "Gece Moduna Geç"}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-amber-500 dark:text-slate-400 dark:hover:text-amber-400 bg-slate-50 dark:bg-slate-800/80 transition-colors cursor-pointer"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Elements & Stickers Library (Goodnotes Style) */}
            <button
              id="open-side-gallery-btn"
              onClick={onOpenSideGallery}
              title="Öğeler (Elements) & Çıkartma Kütüphanesi"
              className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 bg-slate-50 dark:bg-slate-800/80 transition-colors hidden sm:flex items-center gap-1 cursor-pointer"
            >
              <Stamp className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              {clipsCount > 0 && (
                <span className={`w-3.5 h-3.5 ${themeDef.buttonBg} text-[9px] font-extrabold rounded-full flex items-center justify-center text-white`}>
                  {clipsCount}
                </span>
              )}
            </button>

            {/* Vault / Kasa Menu Button */}
            <button
              id="open-vault-btn"
              onClick={() => {
                setActiveTab("vault");
                onSecretVaultTrigger?.();
              }}
              title={
                isVaultUnlocked
                  ? `Şifreli Kasa: Kilit Açık (${vaultNotesCount} Not)`
                  : `Şifreli Kasa: Korumalı (${vaultNotesCount} Not)`
              }
              className={`p-2 sm:px-2.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer relative ${
                activeTab === "vault" || isVaultUnlocked
                  ? "bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 dark:border-emerald-600 text-emerald-700 dark:text-emerald-300 shadow-xs ring-1 ring-emerald-500/30"
                  : "bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:text-emerald-600 dark:hover:text-emerald-400 hover:border-emerald-300 dark:hover:border-emerald-700"
              }`}
            >
              <Shield className={`w-4 h-4 ${activeTab === "vault" || isVaultUnlocked ? "text-emerald-600 dark:text-emerald-400 fill-emerald-500/20" : "text-emerald-600 dark:text-emerald-400"}`} />
              <span className="hidden sm:inline text-xs font-bold text-slate-800 dark:text-slate-100">Kasa</span>
              {vaultNotesCount > 0 && (
                <span className="w-4 h-4 bg-emerald-600 text-white rounded-full text-[9px] font-extrabold flex items-center justify-center">
                  {vaultNotesCount}
                </span>
              )}
            </button>

            {/* User Profile Avatar / Status */}
            <button
              onClick={() => {
                if (!profile?.isLoggedIn && onOpenAuthModal) {
                  onOpenAuthModal();
                } else {
                  setActiveTab("profile");
                }
              }}
              title={
                profile?.isLoggedIn
                  ? `${profile.email} (${profile.aiModeEnabled ? "AI Aktif" : "Klasik"})`
                  : "Giriş Yap / Kayıt Ol (AI Aktifleştir)"
              }
              className={`flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                profile?.isLoggedIn
                  ? "bg-teal-50 dark:bg-teal-950/60 border-teal-300 dark:border-teal-700 text-teal-700 dark:text-teal-300 shadow-xs"
                  : "bg-teal-600/10 hover:bg-teal-600/20 dark:bg-teal-900/30 border-teal-400 dark:border-teal-600 text-teal-700 dark:text-teal-300 shadow-xs"
              }`}
            >
              <div className="relative">
                <User className="w-4 h-4" />
                <span
                  className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${
                    profile?.isLoggedIn && profile?.aiModeEnabled
                      ? "bg-emerald-500 animate-pulse"
                      : profile?.isLoggedIn
                      ? "bg-blue-400"
                      : "bg-amber-400 animate-ping"
                  }`}
                />
              </div>
              <span className="hidden lg:inline text-[11px] font-extrabold truncate max-w-[90px]">
                {profile?.isLoggedIn ? profile.name?.split(" ")[0] || "Hesap" : "Giriş Yap"}
              </span>
            </button>

            {/* PRIMARY "+ NEW / + YENİ" BUTTON (Photo NoteSync Style - hidden on mobile since floating dock has thumb button) */}
            <button
              id="header-create-new-btn"
              onClick={onOpenCreateMenu}
              className={`hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 sm:py-2 bg-gradient-to-r ${themeDef.gradient} ${themeDef.gradientHover} text-white rounded-2xl text-xs font-extrabold shadow-md transition-all active:scale-95 cursor-pointer`}
              style={{ boxShadow: `0 4px 14px -2px ${themeDef.preview}50` }}
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span className="font-bold">Yeni</span>
            </button>
          </div>
        </div>

        {/* MOBILE SEARCH BAR (Visible only on small screens) */}
        <div className="md:hidden relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Notlarda veya etiketlerde ara..."
            className={`w-full pl-9 pr-9 py-1.5 bg-slate-100/90 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 ${themeDef.ring}`}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* ROW 2: ALL VIEW LAYOUTS & FILTER CONTROLS */}
        {activeTab === "home" && (
          <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100 dark:border-slate-800/70">
            {/* View Layout Switcher (All Listing Varieties) */}
            <div className="flex items-center gap-1 overflow-x-auto py-0.5 no-scrollbar flex-1">
              <div className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0">
                <button
                  onClick={() => setViewLayout("grid")}
                  title="Izgara Görünümü (3 Sütun)"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "grid"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden sm:inline">Izgara</span>
                </button>
                <button
                  onClick={() => setViewLayout("largeGrid")}
                  title="Büyük Izgara (2 Sütun)"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "largeGrid"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <Grid2X2 className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden sm:inline">Büyük</span>
                </button>
                <button
                  onClick={() => setViewLayout("list")}
                  title="Liste Görünümü"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "list"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <List className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden sm:inline">Liste</span>
                </button>
                <button
                  onClick={() => setViewLayout("details")}
                  title="Ayrıntılar Görünümü"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "details"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <Rows3 className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden md:inline">Ayrıntılar</span>
                </button>
                <button
                  onClick={() => setViewLayout("kanban")}
                  title="📋 Kanban Pano"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "kanban"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <FolderKanban className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden sm:inline">Kanban</span>
                </button>
                <button
                  onClick={() => setViewLayout("timeline")}
                  title="⏳ Zaman Çizelgesi"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "timeline"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden md:inline">Zaman</span>
                </button>
                <button
                  onClick={() => setViewLayout("mindmap_canvas")}
                  title="🧠 Zihin Haritası"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "mindmap_canvas"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <BrainCircuit className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden md:inline">Zihin</span>
                </button>
                <button
                  onClick={() => setViewLayout("compact_strip")}
                  title="🏷️ Kompakt Şerit"
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors cursor-pointer text-xs ${
                    viewLayout === "compact_strip"
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                  }`}
                >
                  <Tags className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-medium hidden md:inline">Kompakt</span>
                </button>
                <button
                  onClick={() => setShowViewModal(true)}
                  title="Tüm Görünüm Seçenekleri Rehberi"
                  className="p-1.5 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 border-l border-slate-200 dark:border-slate-700 ml-0.5 cursor-pointer"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>

              {/* View Options Modal / Dialog */}
              {showViewModal && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
                  <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto scrollbar-thin">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 sticky top-0 bg-white dark:bg-slate-900 z-10">
                      <div className="flex items-center gap-2">
                        <LayoutGrid className="w-5 h-5 text-teal-600" />
                        <h3 className="font-bold text-base text-slate-900 dark:text-white">
                          Görünüm Modu Seçin
                        </h3>
                      </div>
                      <button
                        onClick={() => setShowViewModal(false)}
                        className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Notlarınızın ana ekranda görsel, zamansal ve anlamsal olarak nasıl görüntüleneceğini seçin:
                    </p>

                    <div className="space-y-2.5">
                      {/* Option: Kanban Pano */}
                      <button
                        onClick={() => {
                          setViewLayout("kanban");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "kanban"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2.5 bg-teal-100 dark:bg-teal-900/60 rounded-xl text-teal-700 dark:text-teal-300 shrink-0">
                          <FolderKanban className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">📋 Kanban Pano (Süreç Panosu)</span>
                            {viewLayout === "kanban" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Kategorilere veya durumlara göre yatayda kaydırılabilir sütunlar. Sürükle-bırak ile notları düzenleme imkanı sağlar.
                          </p>
                        </div>
                      </button>

                      {/* Option: Zaman Çizelgesi */}
                      <button
                        onClick={() => {
                          setViewLayout("timeline");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "timeline"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2.5 bg-blue-100 dark:bg-blue-900/60 rounded-xl text-blue-700 dark:text-blue-300 shrink-0">
                          <History className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">⏳ Zaman Çizelgesi (Timeline / Feed)</span>
                            {viewLayout === "timeline" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Sosyal medya akışı tarzında dikey zaman çizgisi. Günlük, kronolojik takip ve geçmiş notlar için idealdir.
                          </p>
                        </div>
                      </button>

                      {/* Option: Zihin Haritası */}
                      <button
                        onClick={() => {
                          setViewLayout("mindmap_canvas");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "mindmap_canvas"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2.5 bg-purple-100 dark:bg-purple-900/60 rounded-xl text-purple-700 dark:text-purple-300 shrink-0">
                          <BrainCircuit className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">🧠 Zihin Haritası (Anlamsal Tuval)</span>
                            {viewLayout === "mindmap_canvas" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            2B sonsuz tuval üzerinde düğümler ve bağlantı çizgileri ile anlamsal ilişkiler ağını görselleştirir.
                          </p>
                        </div>
                      </button>

                      {/* Option: Kompakt Şerit */}
                      <button
                        onClick={() => {
                          setViewLayout("compact_strip");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "compact_strip"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2.5 bg-amber-100 dark:bg-amber-900/60 rounded-xl text-amber-700 dark:text-amber-300 shrink-0">
                          <Tags className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">🏷️ Kompakt Şerit (Yüksek Yoğunluk)</span>
                            {viewLayout === "compact_strip" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Renkli küçük etiketler ve rozetler. Tek bir ekranda yüzlerce notu kaydırma yapmadan incelemenize olanak tanır.
                          </p>
                        </div>
                      </button>

                      {/* Option: Liste */}
                      <button
                        onClick={() => {
                          setViewLayout("list");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "list"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/60 rounded-xl text-teal-700 dark:text-teal-300 shrink-0">
                          <List className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">Liste (List View)</span>
                            {viewLayout === "list" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Notlar tek sütun halinde alt alta dizilir. Başlık ve renk şeridi görünür.
                          </p>
                        </div>
                      </button>

                      {/* Option: Ayrıntılar */}
                      <button
                        onClick={() => {
                          setViewLayout("details");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "details"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/60 rounded-xl text-teal-700 dark:text-teal-300 shrink-0">
                          <Rows3 className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">Ayrıntılar (Details View)</span>
                            {viewLayout === "details" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Not Başlığı, Tarih ve 1-2 satırlık kısa metin önizlemesi.
                          </p>
                        </div>
                      </button>

                      {/* Option: Izgara */}
                      <button
                        onClick={() => {
                          setViewLayout("grid");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "grid"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/60 rounded-xl text-teal-700 dark:text-teal-300 shrink-0">
                          <LayoutGrid className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">Izgara (Grid View)</span>
                            {viewLayout === "grid" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Varsayılan 3 sütunlu kare/dikdörtgen kart dizilimi.
                          </p>
                        </div>
                      </button>

                      {/* Option: Büyük Izgara */}
                      <button
                        onClick={() => {
                          setViewLayout("largeGrid");
                          setShowViewModal(false);
                        }}
                        className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                          viewLayout === "largeGrid"
                            ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 text-slate-900 dark:text-white"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/60 rounded-xl text-teal-700 dark:text-teal-300 shrink-0">
                          <Grid2X2 className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">Büyük Izgara (Large Grid)</span>
                            {viewLayout === "largeGrid" && <Check className="w-4 h-4 text-teal-600" />}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            2 sütunlu geniş ve detaylı kartlar.
                          </p>
                        </div>
                      </button>
                    </div>

                    <div className="pt-2 flex justify-end sticky bottom-0 bg-white dark:bg-slate-900">
                      <button
                        onClick={() => setShowViewModal(false)}
                        className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                      >
                        Kapat
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Controls: Sort Menu + Quick Filters + Trash */}
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Sort Menu */}
              <div className="relative">
                <button
                  id="sort-menu-btn"
                  onClick={() => setShowSortMenu(!showSortMenu)}
                  className="p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  title="Sırala"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                </button>

                {showSortMenu && (
                  <div className="absolute right-0 top-full mt-1.5 w-48 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1 z-40 text-xs animate-in fade-in zoom-in-95">
                    <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Sıralama Ölçütü
                    </div>
                    {[
                      { id: "updated", label: "Düzenlenme Tarihi (Varsayılan)" },
                      { id: "newest", label: "Oluşturulma (En Yeni)" },
                      { id: "oldest", label: "Oluşturulma (En Eski)" },
                      { id: "alphabetical", label: "Alfabetik (A-Z)" },
                      { id: "color", label: "Renge Göre Sırala" },
                    ].map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          setSortOption(s.id as SortOption);
                          setShowSortMenu(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 flex items-center justify-between cursor-pointer ${
                          sortOption === s.id
                            ? `${themeDef.text} ${themeDef.textDark} font-bold bg-slate-50 dark:bg-slate-700/50`
                            : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                        }`}
                      >
                        <span>{s.label}</span>
                        {sortOption === s.id && <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Quick Filter: Favorites */}
              <button
                onClick={() => setFilterOption(filterOption === "favorites" ? "all" : "favorites")}
                className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                  filterOption === "favorites"
                    ? "bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-950/80 dark:text-amber-300 dark:border-amber-800 font-bold shadow-2xs"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
                title="Favoriler"
              >
                <Star className="w-3.5 h-3.5" />
              </button>

              {/* Quick Filter: Tasks */}
              <button
                onClick={() => setFilterOption(filterOption === "tasks" ? "all" : "tasks")}
                className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                  filterOption === "tasks"
                    ? "bg-teal-100 text-teal-700 border-teal-300 dark:bg-teal-950/80 dark:text-teal-300 dark:border-teal-800 font-bold shadow-2xs"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
                title="Görevler"
              >
                <CheckSquare className="w-3.5 h-3.5" />
              </button>

              {/* Trash */}
              <button
                id="trash-quick-btn"
                onClick={onOpenTrash}
                title="Çöp Kutusu"
                className="relative p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-rose-600 bg-slate-50 dark:bg-slate-800/80 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                {trashCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 text-white text-[9px] font-extrabold rounded-full flex items-center justify-center">
                    {trashCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
