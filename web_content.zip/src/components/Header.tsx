import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BookOpen,
  NotebookPen,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  Sun,
  Moon,
} from 'lucide-react';
import type { TabId } from '../types';
import { TactileButton } from './InteractiveButton';
import { ProgressCelebrationBurst } from './ProgressCelebrationBurst';
import { celebrateDailyGoal100 } from '../lib/confetti';

export interface ProgressToastPayload {
  key: number;
  message: string;
  isGoalComplete?: boolean;
}

interface HeaderProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  onSecretAdminTrigger: () => void;
  isAdminOpen: boolean;
  isAdminSignedIn: boolean;
  onToggleAdminView: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  progressPercent: number;
  progressToast: ProgressToastPayload | null;
}

const TABS: Array<{ id: TabId; label: string; shortLabel: string; icon: typeof BookOpen }> = [
  { id: 'study', label: 'موادي ومهامي', shortLabel: 'موادي ومهامي', icon: BookOpen },
  { id: 'notes', label: 'دفتر الملاحظات', shortLabel: 'الملاحظات', icon: NotebookPen },
  {
    id: 'hub',
    label: 'المعلم الذكي و ما الجديد',
    shortLabel: 'الذكي وما الجديد',
    icon: Sparkles,
  },
];

function getMotivationalSentence(percent: number): string {
  if (percent <= 0) return 'ابدأ بسؤال المعلم (+2%) أو مذاكرة ملف (+3%)!';
  if (percent < 40) return 'بداية قوية! كل خطوة صغيرة تقرّبك من هدفك.';
  if (percent < 80) return 'أداء رائع! استمر بنفس الحماس والتركيز.';
  if (percent < 100) return 'ممتاز جداً! لم يتبقَّ سوى القليل لإتمام يومك.';
  return 'عاش يا بطل! خلصت هدف النهاردة 🎉';
}

export function Header({
  activeTab,
  onSelectTab,
  onSecretAdminTrigger,
  isAdminOpen,
  isAdminSignedIn,
  onToggleAdminView,
  theme,
  onToggleTheme,
  progressPercent,
  progressToast,
}: HeaderProps) {
  const tapTimestamps = useRef<number[]>([]);
  const [celebrationKey, setCelebrationKey] = useState<number | null>(null);
  const prevProgressRef = useRef({
    percent: progressPercent,
    toastKey: progressToast?.key ?? null,
  });
  const celebrationTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const prev = prevProgressRef.current;
    const currentToastKey = progressToast?.key ?? null;
    const toastTriggered =
      currentToastKey !== null && currentToastKey !== prev.toastKey;
    const stepIncreased = progressPercent > prev.percent;

    prevProgressRef.current = {
      percent: progressPercent,
      toastKey: currentToastKey,
    };

    if (toastTriggered || stepIncreased) {
      const nextKey = Date.now();
      setCelebrationKey(nextKey);
      if (progressToast?.isGoalComplete) {
        celebrateDailyGoal100();
      }
      if (celebrationTimerRef.current !== null) {
        window.clearTimeout(celebrationTimerRef.current);
      }
      celebrationTimerRef.current = window.setTimeout(() => {
        setCelebrationKey(null);
      }, 1300);
    }
  }, [progressToast, progressPercent]);

  useEffect(() => {
    return () => {
      if (celebrationTimerRef.current !== null) {
        window.clearTimeout(celebrationTimerRef.current);
      }
    };
  }, []);

  const handleBrandTap = () => {
    const now = Date.now();
    const recent = tapTimestamps.current.filter((t) => now - t < 2500);
    recent.push(now);
    tapTimestamps.current = recent;

    if (recent.length >= 5) {
      tapTimestamps.current = [];
      onSecretAdminTrigger();
    }
  };

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors pt-4">
        {/* Top Bar: 3 balanced zones with 16px top clearance */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-2.5 flex items-center justify-between gap-3 sm:gap-6">
          {/* Right (RTL start): Brand Wordmark (5 quick taps opens Admin Login) */}
          <motion.button
            type="button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleBrandTap}
            className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-violet-700 dark:text-violet-400 whitespace-nowrap shrink-0 select-none cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-xl px-1.5 py-1 active:shadow-none"
          >
            نذاكر
          </motion.button>

          {/* Center: Exactly 3 Navigation Tabs */}
          <nav
            aria-label="التنقل الرئيسي"
            className="hidden md:flex flex-1 items-center justify-center gap-6 lg:gap-8"
          >
            {TABS.map((tab) => {
              const isActive = !isAdminOpen && activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onSelectTab(tab.id)}
                  className={`relative py-2 text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-lg px-2 active:shadow-none ${
                    isActive
                      ? 'text-violet-700 dark:text-violet-400'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {tab.label}
                  {isActive && (
                    <motion.span
                      layoutId="desktop-nav-indicator"
                      transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-600 dark:bg-violet-400 rounded-full"
                    />
                  )}
                </motion.button>
              );
            })}
          </nav>

          {/* Left (RTL end): Clear Dark/Light Toggle + Admin toggle when signed in */}
          <div className="flex items-center gap-2 shrink-0">
            {(isAdminOpen || isAdminSignedIn) && (
              <TactileButton
                type="button"
                onClick={onToggleAdminView}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 min-h-[40px]"
              >
                {isAdminOpen ? (
                  <>
                    <ArrowRight className="w-4 h-4" />
                    <span>العودة</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>المشرف</span>
                  </>
                )}
              </TactileButton>
            )}

            <TactileButton
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'التبديل للوضع النهاري' : 'التبديل للوضع الليلي'}
              title={theme === 'dark' ? 'الوضع النهاري' : 'الوضع الليلي'}
              className="inline-flex items-center justify-center gap-1.5 px-3 min-w-[42px] min-h-[42px] rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-amber-300 text-xs font-bold whitespace-nowrap"
            >
              <AnimatePresence mode="wait" initial={false}>
                {theme === 'dark' ? (
                  <motion.span
                    key="sun"
                    initial={{ rotate: -90, opacity: 0, scale: 0.6 }}
                    animate={{ rotate: 0, opacity: 1, scale: 1 }}
                    exit={{ rotate: 90, opacity: 0, scale: 0.6 }}
                    transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                    className="inline-flex items-center gap-1.5"
                  >
                    <Sun className="w-4 h-4 shrink-0" />
                    <span className="hidden sm:inline">نهاري</span>
                  </motion.span>
                ) : (
                  <motion.span
                    key="moon"
                    initial={{ rotate: 90, opacity: 0, scale: 0.6 }}
                    animate={{ rotate: 0, opacity: 1, scale: 1 }}
                    exit={{ rotate: -90, opacity: 0, scale: 0.6 }}
                    transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                    className="inline-flex items-center gap-1.5"
                  >
                    <Moon className="w-4 h-4 shrink-0" />
                    <span className="hidden sm:inline">ليلي</span>
                  </motion.span>
                )}
              </AnimatePresence>
            </TactileButton>
          </div>
        </div>

        {/* Standalone Sticky Progress Bar Row */}
        <div className="relative border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/95 dark:bg-slate-900/95">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 space-y-1">
            <div className="flex items-center gap-3 sm:gap-4">
              {/* Right: "التقدم اليومي" + Large Percentage */}
              <div className="flex items-baseline gap-2 whitespace-nowrap shrink-0">
                <span className="text-xs sm:text-sm font-extrabold text-slate-800 dark:text-slate-100">
                  التقدم اليومي
                </span>
                <motion.span
                  key={celebrationKey ?? 'idle'}
                  animate={
                    celebrationKey !== null
                      ? { scale: [1, 1.24, 1] }
                      : { scale: 1 }
                  }
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  className="font-mono-num text-base sm:text-xl font-extrabold text-violet-700 dark:text-violet-400 inline-block"
                >
                  {progressPercent}%
                </motion.span>
              </div>

              {/* Center: Thick Gradient Bar + Celebratory Hearts & Stars */}
              <div className="relative flex-1">
                <div className="w-full h-3.5 sm:h-4 bg-slate-200/90 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                  <motion.div
                    initial={false}
                    animate={{ width: `${progressPercent}%` }}
                    transition={{ type: 'spring', stiffness: 220, damping: 22 }}
                    className="h-full rounded-full bg-gradient-to-l from-violet-600 via-blue-500 to-emerald-500"
                  />
                </div>
                <ProgressCelebrationBurst burstKey={celebrationKey} />
              </div>
            </div>

            {/* Small Motivational Sentence Under the Bar */}
            <p
              className={`text-[11px] sm:text-xs font-semibold truncate ${
                progressPercent >= 100
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {getMotivationalSentence(progressPercent)}
            </p>
          </div>

          <AnimatePresence>
            {progressToast && (
              <motion.div
                key={progressToast.key}
                initial={{ opacity: 0, y: -10, scale: 0.92 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.92 }}
                transition={{ type: 'spring', stiffness: 420, damping: 24 }}
                role="status"
                aria-live="polite"
                className={`pointer-events-none absolute left-1/2 -translate-x-1/2 top-full mt-2 z-40 px-4 py-1.5 rounded-2xl text-white text-xs sm:text-sm font-extrabold shadow-lg whitespace-nowrap ${
                  progressToast.isGoalComplete ? 'bg-violet-600' : 'bg-emerald-600'
                }`}
              >
                {progressToast.message}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Mobile Bottom Tab Bar */}
      <nav
        aria-label="التنقل السفلي"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 pb-[env(safe-area-inset-bottom)]"
      >
        <div className="grid grid-cols-3 items-center h-14">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = !isAdminOpen && activeTab === tab.id;
            return (
              <motion.button
                key={tab.id}
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onSelectTab(tab.id)}
                className={`flex flex-col items-center justify-center min-h-[44px] rounded-xl transition-colors active:shadow-none ${
                  isActive
                    ? 'text-violet-700 dark:text-violet-400'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.9]'}`} />
                <span className="text-[11px] font-bold mt-0.5 whitespace-nowrap truncate max-w-[110px]">
                  {tab.shortLabel}
                </span>
              </motion.button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
