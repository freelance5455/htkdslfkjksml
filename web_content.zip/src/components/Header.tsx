import React from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { 
  ShieldCheck, Smartphone, Lock, Unlock, Volume2, 
  Battery, Plus, Terminal, Bell, PackageCheck, Cloud, KeyRound,
  Moon, Sun, Sparkles, QrCode
} from 'lucide-react';

interface HeaderProps {
  onOpenPairModal: () => void;
  onOpenFlutterCode: () => void;
  onOpenChildMode: () => void;
  onOpenPinModal: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onOpenPairModal, 
  onOpenFlutterCode,
  onOpenChildMode,
  onOpenPinModal,
  activeTab,
  setActiveTab 
}) => {
  const { 
    devices, 
    activeDeviceId, 
    setActiveDeviceId, 
    activeDevice,
    language, 
    toggleLanguage,
    setIsSimulatorOpen,
    setDeviceLockdown,
    triggerEmergencySiren,
    stopEmergencySiren,
    sirenPlaying,
    unreadAlertsCount,
    cloudSyncStatus,
    lockParentDashboard,
    themeMode,
    isDarkMode,
    toggleTheme
  } = useParentControl();

  const isAr = language === 'ar';
  const isLocked = activeDevice?.settings.screenLocked;

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-1.5 sm:gap-3">
          
          {/* Brand Logo */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 p-0.5 shadow-xs flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-white dark:bg-slate-900 rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600 dark:text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-extrabold text-sm sm:text-base tracking-tight text-slate-900 dark:text-white font-sans">
                  Parent<span className="text-indigo-600 dark:text-indigo-400">Guard</span>
                </span>
                <span className="text-[9px] sm:text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800 font-semibold hidden xs:inline-block">
                  v2.5
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden md:block">
                {isAr ? 'منظومة التحكم الأبوي الشامل عن بُعد' : 'Comprehensive Parental Control'}
              </p>
            </div>
          </div>

          {/* Device Selector & Status */}
          <div className="flex items-center gap-1 sm:gap-2 max-w-[130px] xs:max-w-[170px] sm:max-w-none shrink">
            <div className="relative flex items-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl py-1 px-1.5 sm:px-2.5 hover:border-slate-300 dark:hover:border-slate-600 transition-colors shadow-xs w-full sm:w-auto">
              <span className="flex h-2 w-2 relative me-1 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              
              <select
                id="active-child-device-select"
                value={activeDeviceId}
                onChange={(e) => setActiveDeviceId(e.target.value)}
                className="bg-transparent text-[11px] sm:text-sm font-semibold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer pe-0.5 sm:pe-1 appearance-none truncate max-w-[65px] xs:max-w-[100px] sm:max-w-[200px]"
                title={isAr ? 'اختر جهاز الطفل' : 'Select Child Device'}
              >
                {devices.map((device) => (
                  <option key={device.id} value={device.id} className="bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100">
                    {device.childNameAr} ({device.deviceName})
                  </option>
                ))}
              </select>

              {/* Battery Badge */}
              {activeDevice && (
                <div className="flex items-center gap-0.5 sm:gap-1 text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-300 ps-1 border-s border-slate-200 dark:border-slate-700 shrink-0">
                  <Battery className={`w-3 h-3 sm:w-3.5 sm:h-3.5 ${activeDevice.batteryLevel < 25 ? 'text-rose-600' : 'text-emerald-500'}`} />
                  <span className="font-mono font-medium">{activeDevice.batteryLevel}%</span>
                </div>
              )}
            </div>

            {/* Add Device Button (Desktop) */}
            <button
              id="add-device-btn"
              onClick={onOpenPairModal}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors hidden lg:flex items-center gap-1 text-xs shadow-xs"
              title={isAr ? 'ربط جهاز طفل جديد' : 'Pair New Child Device'}
            >
              <Plus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="font-medium">{isAr ? 'إقران' : 'Pair'}</span>
            </button>

            {/* Quick QR Pairing Button */}
            <button
              id="header-qr-code-btn"
              onClick={onOpenPairModal}
              className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 transition-colors hidden sm:flex items-center gap-1 text-xs shadow-xs"
              title={isAr ? 'إقران عبر رمز QR' : 'Pair via QR Code'}
            >
              <QrCode className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="font-bold hidden xl:inline">{isAr ? 'رمز QR' : 'QR Code'}</span>
            </button>
          </div>

          {/* Quick Remote Action Buttons */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Live Child Simulator Launcher (Both Mobile & Desktop!) */}
            <button
              id="open-simulator-btn"
              onClick={() => setIsSimulatorOpen(true)}
              className="relative p-2 sm:px-3 sm:py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs active:scale-95 transition-all"
              title={isAr ? 'فتح محاكي هاتف الطفل' : 'Open Child Phone Simulator'}
            >
              <Smartphone className="w-4 h-4 sm:w-3.5 sm:h-3.5 animate-pulse" />
              <span className="hidden sm:inline">{isAr ? 'محاكي الطفل' : 'Simulator'}</span>
              <span className="hidden sm:flex h-2 w-2 rounded-full bg-emerald-300" />
            </button>

            {/* Instant Screen Lockdown Toggle */}
            <button
              id="instant-lock-header-btn"
              onClick={() => setDeviceLockdown(!isLocked)}
              className={`p-2 sm:px-3 sm:py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all active:scale-95 shadow-xs ${
                isLocked
                  ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700'
              }`}
              title={isLocked ? (isAr ? 'إلغاء قفل الجهاز' : 'Unlock Device') : (isAr ? 'قفل شاشة الجهاز فوراً' : 'Instant Lock Screen')}
            >
              {isLocked ? (
                <>
                  <Lock className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                  <span className="hidden md:inline text-rose-700 dark:text-rose-300 font-semibold">{isAr ? 'الشاشة مقفلة' : 'Screen Locked'}</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
                  <span className="hidden md:inline font-medium">{isAr ? 'قفل فوري' : 'Instant Lock'}</span>
                </>
              )}
            </button>

            {/* Siren Button */}
            <button
              id="siren-header-btn"
              onClick={sirenPlaying ? stopEmergencySiren : triggerEmergencySiren}
              className={`p-2 rounded-xl text-xs border transition-all active:scale-95 shadow-xs ${
                sirenPlaying
                  ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
              }`}
              title={isAr ? 'صفارة إنذار ورنين الهاتف للعثور عليه' : 'Loud Finder Siren'}
            >
              <Volume2 className="w-4 h-4" />
            </button>

            {/* Alerts Quick Tab (Desktop/Tablet) */}
            <button
              id="header-alerts-btn"
              onClick={() => setActiveTab('alerts')}
              className="relative p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors shadow-xs hidden sm:flex"
              title={isAr ? 'مركز التنبيهات' : 'Alerts Center'}
            >
              <Bell className="w-4 h-4" />
              {unreadAlertsCount > 0 && (
                <span className="absolute -top-1 -end-1 bg-rose-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {unreadAlertsCount}
                </span>
              )}
            </button>

            {/* Dark/Night Mode Toggle */}
            <button
              id="theme-toggle-header-btn"
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-semibold transition-colors shadow-xs flex items-center gap-1"
              title={
                themeMode === 'light'
                  ? (isAr ? 'الوضع النهاري (انقر للتبديل للداكن)' : 'Light Mode (Click for Dark)')
                  : themeMode === 'dark'
                  ? (isAr ? 'الوضع الليلي (انقر للتبديل للتلقائي)' : 'Dark Mode (Click for Auto)')
                  : (isAr ? 'الوضع التلقائي المسائي (انقر للتبديل للنهاري)' : 'Auto Night Mode (Click for Light)')
              }
            >
              {themeMode === 'light' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : themeMode === 'dark' ? (
                <Moon className="w-4 h-4 text-indigo-400" />
              ) : (
                <div className="flex items-center gap-0.5">
                  {isDarkMode ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                  <span className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 font-mono">A</span>
                </div>
              )}
            </button>

            {/* Firebase Cloud Sync Status */}
            <div 
              className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 shadow-xs"
              title={cloudSyncStatus === 'connected' ? (isAr ? 'متصل بقاعدة بيانات Firebase السحابية حياً' : 'Connected to Firebase Cloud Firestore') : (isAr ? 'جارِ المزامنة السحابية' : 'Syncing')}
            >
              <Cloud className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 animate-pulse" />
              <span className="font-mono text-[11px] text-slate-600 dark:text-slate-400">Cloud</span>
              <span className={`w-2 h-2 rounded-full ${cloudSyncStatus === 'connected' ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </div>

            {/* Real Child Mode Launcher Button (Desktop/Tablet) */}
            <button
              id="header-child-mode-btn"
              onClick={onOpenChildMode}
              className="px-2.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/50 hover:bg-purple-100 dark:hover:bg-purple-900/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-bold transition-colors hidden md:flex items-center gap-1 shadow-xs active:scale-95"
              title={isAr ? 'فتح وضع هاتف الطفل الفعلي على هذا الجهاز أو محاكاته' : 'Open Real Child Companion Screen'}
            >
              <Smartphone className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
              <span className="text-[11px]">{isAr ? 'هاتف الطفل' : 'Child Device'}</span>
            </button>

            {/* Parent PIN Lock Button */}
            <button
              id="header-lock-dashboard-btn"
              onClick={lockParentDashboard}
              className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-semibold transition-colors shadow-xs"
              title={isAr ? 'قفل لوحة التحكم برمز PIN' : 'Lock Parent Dashboard'}
            >
              <KeyRound className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            </button>

            {/* Flutter Code Exporter (Desktop) */}
            <button
              id="header-flutter-code-btn"
              onClick={onOpenFlutterCode}
              className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 transition-colors hidden lg:flex items-center gap-1 text-xs font-semibold shadow-xs"
              title={isAr ? 'عرض كود وبنية Flutter' : 'View Flutter Architecture'}
            >
              <Terminal className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="font-mono text-[11px]">Flutter</span>
            </button>

            {/* APK Direct Export Button (Tablet/Desktop) */}
            <button
              id="header-apk-btn"
              onClick={() => setActiveTab('apk')}
              className={`p-2 rounded-xl border transition-colors hidden sm:flex items-center gap-1 text-xs font-semibold shadow-xs ${
                activeTab === 'apk'
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
              }`}
              title={isAr ? 'استخراج وتحميل ملف APK' : 'Export & Build APK'}
            >
              <PackageCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span className="font-bold text-[11px]">APK</span>
            </button>

            {/* Language Switch (Desktop/Tablet) */}
            <button
              id="language-toggle-btn"
              onClick={toggleLanguage}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-bold transition-colors shadow-xs hidden sm:block"
              title={isAr ? 'Switch to English' : 'التحويل للغة العربية'}
            >
              <span className="uppercase">{isAr ? 'EN' : 'عربي'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
