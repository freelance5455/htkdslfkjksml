import React, { useState, useEffect } from 'react';
import { Clock, Moon, Sun, Bell, ShieldCheck, ShieldAlert, Sparkles } from 'lucide-react';
import { Alarm, AppSettings } from '../types/alarm';
import { getNextUpcomingAlarm, formatCountdown, formatAlarmTime } from '../utils/alarmEngine';

interface HeaderProps {
  alarms: Alarm[];
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onRequestPermissions: () => void;
  permissionGranted: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  alarms,
  settings,
  onUpdateSettings,
  onRequestPermissions,
  permissionGranted,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const upcoming = getNextUpcomingAlarm(alarms);

  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  const formattedTime = formatAlarmTime(
    currentTime.getHours(),
    currentTime.getMinutes(),
    settings.timeFormat === '24h'
  );

  const toggleDarkMode = () => {
    const newDark = !settings.darkMode;
    onUpdateSettings({ ...settings, darkMode: newDark });
    if (newDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <header className="w-full bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors duration-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-4xl mx-auto px-4 py-3 sm:px-6">
        {/* Top Wordmark & Quick Actions */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/file_00000000ef4c8211bafeca7fec614b22_95cdb1d5.png"
              alt="WakeUp Logo"
              className="w-12 h-12 rounded-2xl shadow-sm object-cover shrink-0 border border-slate-200/50 dark:border-slate-800"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white font-sans">
                  WakeUp
                </h1>
                <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full border border-slate-200/60 dark:border-slate-700/60">
                  Android Native
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Your mornings, your music.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!permissionGranted && (
              <button
                onClick={onRequestPermissions}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/80 rounded-xl hover:bg-amber-100 transition-all cursor-pointer"
                title="Grant Notification & Exact Alarm permissions"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Enable Alerts</span>
              </button>
            )}

            <button
              onClick={toggleDarkMode}
              className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title={settings.darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {settings.darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-700" />}
            </button>
          </div>
        </div>

        {/* Live Clock & Next Scheduled Alarm Hero Card */}
        <div className="mt-4 p-4 sm:p-5 rounded-2xl bg-slate-900 dark:bg-slate-950 text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-slate-800/40 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            {/* Live Clock Display */}
            <div>
              <span className="text-xs font-medium text-slate-400 tracking-wide">
                {formattedDate}
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-4xl sm:text-5xl font-extrabold tracking-tight font-mono">
                  {formattedTime.timeStr}
                </span>
                {formattedTime.period && (
                  <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">
                    {formattedTime.period}
                  </span>
                )}
              </div>
            </div>

            {/* Next Alarm Banner */}
            <div className="bg-slate-800/80 dark:bg-slate-900/90 border border-slate-700/60 rounded-xl p-3 sm:px-4 sm:py-3 min-w-[220px]">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                <Bell className="w-3.5 h-3.5 text-blue-400" />
                <span>Next Alarm</span>
              </div>

              {upcoming ? (
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-bold font-mono text-white">
                      {formatAlarmTime(upcoming.alarm.hour, upcoming.alarm.minute, settings.timeFormat === '24h').timeStr}{' '}
                      <span className="text-xs text-slate-400 font-sans font-medium">
                        {formatAlarmTime(upcoming.alarm.hour, upcoming.alarm.minute, settings.timeFormat === '24h').period}
                      </span>
                    </span>
                    <span className="text-xs font-medium text-blue-400 truncate max-w-[120px]">
                      {upcoming.alarm.alarmLabel || 'Alarm'}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 font-medium mt-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
                    <span>{formatCountdown(upcoming.nextDate, currentTime)}</span>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-400 font-medium py-1">
                  No active alarms scheduled. Tap + to set one!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
