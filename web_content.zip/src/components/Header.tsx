"use client";

import { Activity, Bot, Lock, Wallet, Zap } from "lucide-react";
import { getEquity, useTradingStore } from "@/services/useTradingStore";
import { FMT, SYMBOLS, SYMBOL_META } from "@/types";

export default function Header() {
  const prices = useTradingStore((s) => s.prices);
  const priceDir = useTradingStore((s) => s.priceDir);
  const selected = useTradingStore((s) => s.selectedSymbol);
  const setSelected = useTradingStore((s) => s.setSelectedSymbol);
  const balance = useTradingStore((s) => s.balance);
  const positions = useTradingStore((s) => s.positions);
  const isBotActive = useTradingStore((s) => s.isAutoBotActive);
  const setBotActive = useTradingStore((s) => s.setBotActive);
  const bestFeed = useTradingStore((s) => s.bestFeed);
  const feeds = useTradingStore((s) => s.feeds);
  const feedMode = useTradingStore((s) => s.feedMode);
  const setLocked = useTradingStore((s) => s.setLocked);
  const riskHalted = useTradingStore((s) => s.riskHalted);

  const equity = getEquity({ balance, positions });
  const bestLat = feeds.find((f) => f.exchange === bestFeed)?.latencyMs;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-[#0f172a]/95 backdrop-blur">
      <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2.5 lg:px-5">
        {/* logo + title */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 shadow-lg shadow-emerald-500/20">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-black leading-tight text-white lg:text-base">
              Crypto Day Trading <span className="text-emerald-400">&</span> AI Hub
            </h1>
            <p className="text-[10px] leading-tight text-slate-400">
              מנוע נתונים רב-בורסתי • בוט לומד אוטונומי • מצב דמו
            </p>
          </div>
        </div>

        {/* master bot toggle */}
        <button
          onClick={() => setBotActive(!isBotActive)}
          className={`flex items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-bold transition ${
            isBotActive
              ? riskHalted
                ? "border-red-500/60 bg-red-500/10 text-red-400"
                : "pulse-live border-emerald-500/60 bg-emerald-500/10 text-emerald-400"
              : "border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-500"
          }`}
        >
          <Bot className="h-4 w-4" />
          {isBotActive ? (riskHalted ? "בוט מושהה" : "בוט פעיל") : "הפעל בוט"}
          <span className={`h-2 w-2 rounded-full ${isBotActive ? (riskHalted ? "bg-red-500" : "bg-emerald-400 blink") : "bg-slate-600"}`} />
        </button>

        {/* latency status */}
        <div className="hidden items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900/70 px-2.5 py-1.5 text-[11px] md:flex">
          <Activity className={`h-3.5 w-3.5 ${feedMode === "LIVE" ? "text-emerald-400" : "text-amber-400"}`} />
          <span className={feedMode === "LIVE" ? "text-emerald-400" : "text-amber-400"}>
            {feedMode === "LIVE" ? "🟢" : "🟡"} {bestFeed}
          </span>
          <span className="num text-slate-400">{bestLat != null ? `${bestLat}ms` : feedMode === "SIM" ? "SIM" : "--"}</span>
        </div>

        <div className="mx-auto" />

        {/* ticker selector */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {SYMBOLS.map((s) => {
            const p = prices[s];
            const dir = priceDir[s];
            return (
              <button
                key={s}
                onClick={() => setSelected(s)}
                className={`rounded-lg border px-2 py-1 text-right transition ${
                  selected === s
                    ? "border-emerald-500/50 bg-emerald-500/10"
                    : "border-slate-800 bg-slate-900/60 hover:border-slate-600"
                }`}
              >
                <div className="text-[10px] font-bold" style={{ color: SYMBOL_META[s].color }}>
                  {s.replace("USDT", "")}
                </div>
                <div
                  key={Math.round(p * 100)}
                  className={`num text-[11px] font-semibold ${
                    dir === 1 ? "flash-up text-emerald-400" : dir === -1 ? "flash-down text-red-400" : "text-slate-300"
                  }`}
                >
                  ${FMT.price(p)}
                </div>
              </button>
            );
          })}
        </div>

        {/* demo balance */}
        <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-1.5">
          <Wallet className="h-4 w-4 text-emerald-400" />
          <div className="text-right">
            <div className="text-[9px] text-slate-400">יתרת דמו (Equity)</div>
            <div className="num text-xs font-bold text-white">${FMT.usd(equity)}</div>
          </div>
          <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-400">DEMO</span>
        </div>

        {/* lock */}
        <button
          onClick={() => setLocked(true)}
          title="נעילה"
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900/70 px-2.5 py-2 text-xs text-slate-300 transition hover:border-red-500/50 hover:text-red-400"
        >
          <Lock className="h-4 w-4" />
          <span className="hidden lg:inline">נעילה</span>
        </button>
      </div>
    </header>
  );
}
