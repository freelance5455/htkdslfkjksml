import React, { useState } from 'react';
import { 
  Bell, 
  User as UserIcon, 
  Flame, 
  ChevronDown, 
  ShieldCheck, 
  Briefcase, 
  Layers, 
  CheckSquare, 
  Users, 
  FileText, 
  BarChart3,
  RotateCcw,
  Plus,
  Menu,
  X,
  Settings as SettingsIcon
} from 'lucide-react';
import { useApp, AppView } from '../context/AppContext';
import { PersonaSwitcherModal } from './PersonaSwitcherModal';

interface HeaderProps {
  onOpenNewProjectModal: () => void;
  onOpenZohoModal: () => void;
  onOpenNewTaskModal?: () => void;
  onOpenPersonaModal?: () => void;
  mobileMenuOpen?: boolean;
  setMobileMenuOpen?: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onOpenNewProjectModal, 
  onOpenZohoModal,
  onOpenNewTaskModal,
  onOpenPersonaModal,
  mobileMenuOpen: controlledMobileMenuOpen,
  setMobileMenuOpen: controlledSetMobileMenuOpen
}) => {
  const { 
    currentUser, 
    users, 
    switchUser, 
    activeView, 
    setActiveView, 
    notifications, 
    markNotificationAsRead,
    markAllNotificationsAsRead,
    resetToDefaultData
  } = useApp();

  const [internalPersonaModalOpen, setInternalPersonaModalOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [internalMobileMenuOpen, setInternalMobileMenuOpen] = useState(false);

  const mobileMenuOpen = controlledMobileMenuOpen !== undefined ? controlledMobileMenuOpen : internalMobileMenuOpen;
  const setMobileMenuOpen = controlledSetMobileMenuOpen || setInternalMobileMenuOpen;

  const handleOpenPersonas = () => {
    if (onOpenPersonaModal) {
      onOpenPersonaModal();
    } else {
      setInternalPersonaModalOpen(true);
    }
  };

  const unreadNotifications = notifications.filter(n => !n.read);

  // Quick 1-tap target users for the 3 main roles
  const defaultAdmin = users.find(u => u.role === 'Admin') || users[0];
  const defaultEmployee = users.find(u => u.role === 'Employee') || users[1];
  const defaultClient = users.find(u => u.role === 'Client') || users[4];

  // Role-specific nav links complying with Top Bar Contract
  const navLinks: { id: AppView; label: string; allowedRoles: string[] }[] = [
    { id: 'dashboard', label: 'Dashboard', allowedRoles: ['Admin'] },
    { id: 'projects', label: 'Projects', allowedRoles: ['Admin'] },
    { id: 'tasks', label: 'Tasks', allowedRoles: ['Admin', 'Employee'] },
    { id: 'clients', label: 'Clients', allowedRoles: ['Admin'] },
    { id: 'employees', label: 'Employees', allowedRoles: ['Admin'] },
    { id: 'documents', label: 'Documents', allowedRoles: ['Admin', 'Employee'] },
    { id: 'reports', label: 'Reports', allowedRoles: ['Admin'] },
    { id: 'settings', label: 'Settings', allowedRoles: ['Admin'] },
    // Dedicated client / employee views
    { id: 'client-portal', label: 'My Projects', allowedRoles: ['Client'] },
    { id: 'employee-portal', label: 'My Workspace', allowedRoles: ['Employee'] },
  ];

  const visibleLinks = navLinks.filter(l => l.allowedRoles.includes(currentUser.role));

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* Test / Demo Persona Switcher Banner (1-tap switches for Admin, Employee, Client) */}
      <div className="bg-slate-900 text-slate-300 px-2 sm:px-4 py-1.5 text-xs flex items-center justify-between border-b border-slate-800 gap-1.5 sm:gap-2">
        <div className="flex items-center gap-1 sm:gap-2 min-w-0">
          <span className="text-[10px] sm:text-[11px] font-bold text-red-400 uppercase tracking-wider shrink-0">
            Role:
          </span>

          {/* 1-Tap Quick Persona Switcher Buttons - Available across mobile and desktop */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            <button
              type="button"
              onClick={() => switchUser(defaultAdmin.id)}
              title={`Switch to Admin: ${defaultAdmin.name}`}
              className={`px-2 sm:px-2.5 py-0.5 rounded text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 border shrink-0 ${
                currentUser.role === 'Admin'
                  ? 'bg-red-600 text-white border-red-500 shadow-xs'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              <span>🛡️ <span className="hidden xs:inline">Admin</span><span className="xs:hidden">Adm</span></span>
            </button>

            <button
              type="button"
              onClick={() => switchUser(defaultEmployee.id)}
              title={`Switch to Employee: ${defaultEmployee.name}`}
              className={`px-2 sm:px-2.5 py-0.5 rounded text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 border shrink-0 ${
                currentUser.role === 'Employee'
                  ? 'bg-blue-600 text-white border-blue-500 shadow-xs'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              <span>👷 <span className="hidden xs:inline">Employee</span><span className="xs:hidden">Emp</span></span>
            </button>

            <button
              type="button"
              onClick={() => switchUser(defaultClient.id)}
              title={`Switch to Client: ${defaultClient.name}`}
              className={`px-2 sm:px-2.5 py-0.5 rounded text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 border shrink-0 ${
                currentUser.role === 'Client'
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              <span>🏢 Client</span>
            </button>

            <button
              type="button"
              onClick={handleOpenPersonas}
              title="View all 6 personas and switch specific user"
              className="text-[10px] sm:text-[11px] text-slate-400 hover:text-white flex items-center gap-0.5 px-1 py-0.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 cursor-pointer shrink-0 ml-0.5"
            >
              <span className="hidden sm:inline">All ({users.length})</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          <span className="hidden lg:inline text-[11px] text-slate-400">
            Phoenix Fire Safety Chennai
          </span>
          <button
            onClick={resetToDefaultData}
            title="Reset system data to initial state"
            className="text-[10px] sm:text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer hover:underline"
          >
            <RotateCcw className="w-2.5 h-2.5 sm:w-3 sm:h-3 shrink-0" />
            <span className="hidden sm:inline">Reset Demo</span>
            <span className="sm:hidden">Reset</span>
          </button>
        </div>
      </div>

      {/* Main Top Bar: Exactly 3 Zones as mandated by Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-15 flex items-center justify-between gap-2 sm:gap-4 lg:gap-8">
        {/* Zone 1: Brand title, one line */}
        <div 
          onClick={() => {
            if (currentUser.role === 'Admin') setActiveView('dashboard');
            else if (currentUser.role === 'Employee') setActiveView('employee-portal');
            else setActiveView('client-portal');
          }}
          className="flex items-center gap-2 sm:gap-2.5 cursor-pointer shrink-0"
        >
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-xs shrink-0">
            <Flame className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm sm:text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
              Phoenix PM
            </span>
            <span className="hidden sm:inline-block text-[11px] text-slate-500 font-medium border-l border-slate-200 pl-2">
              Fire Safety Operations
            </span>
          </div>
        </div>

        {/* Zone 2: 4-5 Navigation Links, 1-2 word labels, single line */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          {visibleLinks.map(link => {
            const isActive = activeView === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveView(link.id)}
                className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                  isActive 
                    ? 'text-red-600 font-semibold border-b-2 border-red-600' 
                    : 'hover:text-slate-900 border-b-2 border-transparent'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action + Utility Icons */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors relative cursor-pointer"
              aria-label="View notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifications.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-600 rounded-full" />
              )}
            </button>

            {/* Notification Drawer Popover */}
            {showNotifications && (
              <div 
                className="fixed sm:absolute inset-x-3 sm:inset-x-auto sm:right-0 top-16 sm:top-auto sm:mt-2 w-auto sm:w-96 bg-white rounded-xl shadow-2xl border border-slate-200 py-2 z-50 max-h-[80vh] flex flex-col"
                onMouseLeave={() => setShowNotifications(false)}
              >
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between shrink-0">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Notifications</h4>
                    <span className="text-[11px] text-slate-500">{unreadNotifications.length} unread updates</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {unreadNotifications.length > 0 && (
                      <button
                        onClick={markAllNotificationsAsRead}
                        className="text-[11px] text-red-600 hover:text-red-700 font-medium cursor-pointer"
                      >
                        Mark all read
                      </button>
                    )}
                    <button
                      onClick={() => setShowNotifications(false)}
                      className="sm:hidden text-slate-400 hover:text-slate-600 text-xs p-1"
                    >
                      ✕
                    </button>
                  </div>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <p className="p-4 text-xs text-slate-500 text-center">No notifications</p>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          markNotificationAsRead(n.id);
                          setShowNotifications(false);
                        }}
                        className={`p-3 text-xs transition-colors cursor-pointer ${
                          !n.read ? 'bg-red-50/40' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className={`font-semibold ${!n.read ? 'text-red-900' : 'text-slate-900'}`}>
                            {n.title}
                          </p>
                          <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp.split(' ')[1]}</span>
                        </div>
                        <p className="text-slate-600 mt-0.5 text-[11px] leading-relaxed">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Primary Action Button (Complying with Zone 3) */}
          {currentUser.role === 'Admin' ? (
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={onOpenZohoModal}
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Zoho Sync</span>
              </button>
              <button
                onClick={onOpenNewProjectModal}
                className="px-2.5 sm:px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-xs flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">New Project</span>
                <span className="sm:hidden">New</span>
              </button>
            </div>
          ) : currentUser.role === 'Employee' ? (
            <button
              onClick={() => setActiveView('tasks')}
              className="px-2.5 sm:px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-xs flex items-center gap-1"
            >
              <span>My Tasks</span>
            </button>
          ) : (
            <button
              onClick={() => setActiveView('client-portal')}
              className="px-2.5 sm:px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-xs"
            >
              <span>View Projects</span>
            </button>
          )}

          {/* Mobile hamburger menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer & Backdrop */}
      {mobileMenuOpen && (
        <>
          <div 
            onClick={() => setMobileMenuOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 md:hidden transition-opacity"
            aria-hidden="true"
          />

          <div 
            className="fixed inset-x-0 top-0 max-h-[90vh] overflow-y-auto bg-white shadow-2xl z-50 md:hidden rounded-b-2xl border-b border-slate-200 flex flex-col animate-in slide-in-from-top duration-200"
          >
            {/* Drawer Header */}
            <div className="px-4 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-xs">
                  <Flame className="w-4 h-4 fill-white" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-xs sm:text-sm">Phoenix PM</h3>
                  <p className="text-[10px] text-slate-500">Phoenix Fire Safety · Chennai</p>
                </div>
              </div>

              <button
                onClick={() => setMobileMenuOpen(false)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold"
                aria-label="Close menu"
              >
                ✕
              </button>
            </div>

            <div className="p-4 space-y-4 text-xs">
              {/* Persona / Role Quick Switcher inside Mobile Drawer */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Switch Test Persona
                  </span>
                  <span className="text-[10px] text-red-600 font-semibold font-mono">
                    Active: {currentUser.role}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {users.slice(0, 3).map(u => {
                    const isSelected = u.id === currentUser.id;
                    return (
                      <button
                        key={u.id}
                        onClick={() => {
                          switchUser(u.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`p-2 rounded-lg text-left transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-white border-red-500 shadow-xs ring-1 ring-red-500'
                            : 'bg-white/80 border-slate-200 hover:bg-white'
                        }`}
                      >
                        <span className={`inline-block text-[9px] font-bold px-1.5 py-0.2 rounded mb-1 ${
                          u.role === 'Admin' ? 'bg-red-100 text-red-700' : u.role === 'Employee' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'
                        }`}>
                          {u.role}
                        </span>
                        <p className="font-bold text-[11px] text-slate-900 truncate">{u.name.split(' ')[0]}</p>
                        <p className="text-[9px] text-slate-400 truncate">{u.designation.split(' ')[0]}</p>
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    handleOpenPersonas();
                  }}
                  className="w-full mt-2.5 py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-center text-[11px] font-semibold text-slate-700 cursor-pointer transition-colors flex items-center justify-center gap-1"
                >
                  <UserIcon className="w-3 h-3 text-red-600" />
                  <span>Browse All Personas & Roles ({users.length})</span>
                </button>
              </div>

              {/* Navigation Links Grid */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  All Application Modules
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {visibleLinks.map(link => {
                    const isActive = activeView === link.id;
                    return (
                      <button
                        key={link.id}
                        onClick={() => {
                          setActiveView(link.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`text-left px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-between border ${
                          isActive 
                            ? 'bg-red-600 text-white border-red-600 shadow-xs' 
                            : 'text-slate-700 bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <span>{link.label}</span>
                        {isActive && <span className="w-1.5 h-1.5 rounded-full bg-white shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Quick Actions Strip */}
              {currentUser.role === 'Admin' && (
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Quick Admin Actions
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        onOpenNewProjectModal();
                        setMobileMenuOpen(false);
                      }}
                      className="py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg text-center cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>New Project</span>
                    </button>
                    {onOpenNewTaskModal && (
                      <button
                        onClick={() => {
                          onOpenNewTaskModal();
                          setMobileMenuOpen(false);
                        }}
                        className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-center cursor-pointer shadow-xs"
                      >
                        Assign Task
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setActiveView('client-import');
                        setMobileMenuOpen(false);
                      }}
                      className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-center cursor-pointer"
                    >
                      Batch Import CSV
                    </button>
                    <button
                      onClick={() => {
                        onOpenZohoModal();
                        setMobileMenuOpen(false);
                      }}
                      className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-center cursor-pointer"
                    >
                      Zoho Books Sync
                    </button>
                  </div>
                </div>
              )}

              {/* Reset Data Footer */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Emergency Help: +91 98401 22841</span>
                <button
                  onClick={() => {
                    resetToDefaultData();
                    setMobileMenuOpen(false);
                  }}
                  className="text-red-600 hover:underline flex items-center gap-1 font-medium cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Demo Data</span>
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Fallback Internal Persona Switcher Modal */}
      <PersonaSwitcherModal
        isOpen={internalPersonaModalOpen}
        onClose={() => setInternalPersonaModalOpen(false)}
      />
    </header>
  );
};
