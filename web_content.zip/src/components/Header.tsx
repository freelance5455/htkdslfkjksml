import { useEffect, useRef, useState } from "react";
import { useAppState, type Screen } from "../state/AppState";

function SunIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </svg>
  );
}
function MoonIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
    </svg>
  );
}
function BackIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}
function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.3-4.3" />
    </svg>
  );
}
function StarIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.1 6.5L12 17.6l-5.8 2.9 1.1-6.5-4.8-4.6 6.6-.9L12 2.5Z" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 3" />
    </svg>
  );
}
function SolverIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="2" width="16" height="20" rx="2" />
      <path d="M8 7h8M8 11h8M8 15h4" />
    </svg>
  );
}
function HistoryIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3v5h5" />
      <path d="M3.05 13a9 9 0 1 0 2.13-6.36L3 8" />
      <path d="M12 7v5l4 2" />
    </svg>
  );
}
function QuizIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </svg>
  );
}
function AiIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a7 7 0 0 0-7 7c0 2.5 1.3 4.3 3 5.5V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.5c1.7-1.2 3-3 3-5.5a7 7 0 0 0-7-7Z" />
      <path d="M9 21h6" />
    </svg>
  );
}
function MoreIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="5" cy="12" r="1.5" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
      <circle cx="19" cy="12" r="1.5" fill="currentColor" stroke="none" />
    </svg>
  );
}

function NavButton({ active, onClick, label, children }: { active: boolean; onClick: () => void; label: string; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-lg p-2 transition hover:bg-slate-100 dark:hover:bg-slate-800 ${
        active ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400" : "text-slate-500 dark:text-slate-400"
      }`}
      aria-label={label}
      title={label}
    >
      {children}
    </button>
  );
}

export default function Header() {
  const { theme, toggleTheme, screen, navigate, back, canGoBack, board, setBoard } = useAppState();
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) setMoreOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  function go(s: Screen) {
    setMoreOpen(false);
    navigate(s);
  }

  const inMoreGroup = screen.name === "favorites" || screen.name === "recent" || screen.name === "history";

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur-md dark:border-slate-800 dark:bg-slate-950/80">
      <div className="mx-auto flex max-w-6xl items-center gap-2 px-4 py-3 sm:px-6">
        {canGoBack ? (
          <button
            onClick={back}
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            aria-label="Go back"
          >
            <BackIcon />
          </button>
        ) : null}
        <button onClick={() => go({ name: "home" })} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/30">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 19.5V6a2 2 0 0 1 2-2h12v15" />
              <path d="M6 22a2 2 0 0 1-2-2V6" />
              <path d="M9 7h7M9 11h5" />
            </svg>
          </div>
          <div className="hidden sm:block">
            <div className="text-base font-bold leading-none tracking-tight text-slate-900 dark:text-white">FormulaVerse</div>
            <div className="text-[11px] leading-none text-slate-400 dark:text-slate-500">Class 8–10 Formula Library</div>
          </div>
        </button>

        <button
          onClick={() => setBoard(board === "CBSE" ? "ICSE" : "CBSE")}
          className="ml-1 shrink-0 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-semibold text-slate-600 transition hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          title="Switch board (tap to toggle CBSE / ICSE)"
        >
          {board}
        </button>

        <div className="ml-auto flex items-center gap-0.5">
          <NavButton active={screen.name === "ai"} onClick={() => go({ name: "ai" })} label="AI Tutor">
            <AiIcon />
          </NavButton>
          <NavButton active={screen.name === "quiz"} onClick={() => go({ name: "quiz" })} label="Quiz">
            <QuizIcon />
          </NavButton>
          <NavButton active={screen.name === "solver"} onClick={() => go({ name: "solver" })} label="Problem solver">
            <SolverIcon />
          </NavButton>
          <NavButton active={screen.name === "search"} onClick={() => go({ name: "search" })} label="Search">
            <SearchIcon />
          </NavButton>

          <div className="relative" ref={moreRef}>
            <NavButton active={moreOpen || inMoreGroup} onClick={() => setMoreOpen((v) => !v)} label="More">
              <MoreIcon />
            </NavButton>
            {moreOpen && (
              <div className="absolute right-0 top-full mt-1 w-48 overflow-hidden rounded-xl border border-slate-200 bg-white py-1 shadow-lg dark:border-slate-700 dark:bg-slate-900">
                <DropdownItem onClick={() => go({ name: "favorites" })} active={screen.name === "favorites"}>
                  <StarIcon /> Favorites
                </DropdownItem>
                <DropdownItem onClick={() => go({ name: "recent" })} active={screen.name === "recent"}>
                  <ClockIcon /> Recently Viewed
                </DropdownItem>
                <DropdownItem onClick={() => go({ name: "history" })} active={screen.name === "history"}>
                  <HistoryIcon /> Formula History
                </DropdownItem>
              </div>
            )}
          </div>

          <button
            onClick={toggleTheme}
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <SunIcon /> : <MoonIcon />}
          </button>
        </div>
      </div>
    </header>
  );
}

function DropdownItem({ onClick, active, children }: { onClick: () => void; active: boolean; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition hover:bg-slate-50 dark:hover:bg-slate-800 ${
        active ? "text-indigo-600 dark:text-indigo-400" : "text-slate-600 dark:text-slate-300"
      }`}
    >
      {children}
    </button>
  );
}
