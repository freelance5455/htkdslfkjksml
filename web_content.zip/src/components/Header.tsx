import React from 'react';
import { Menu, Plus, Sparkles, BookOpen, Trash2, Smartphone } from 'lucide-react';

interface HeaderProps {
  onToggleSidebar: () => void;
  onNewChat: () => void;
  onClearChat: () => void;
  onOpenGuide: () => void;
  hasMessages: boolean;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  onNewChat,
  onClearChat,
  onOpenGuide,
  hasMessages,
  isOnline,
}) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-[#0B132B]/90 backdrop-blur-md border-b border-blue-900/40 px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Left Side: Sidebar Toggle & App Title */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onToggleSidebar}
            aria-label="القائمة الجانبية"
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-blue-950/60 active:scale-95 transition-all border border-blue-900/30"
          >
            <Menu className="w-5 h-5 text-blue-400" />
          </button>

          <div className="flex items-center gap-2">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-700 via-blue-600 to-cyan-500 shadow-md shadow-blue-600/30 text-white font-bold text-lg">
              <Sparkles className="w-5 h-5" />
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#0B132B]" title="متصل بالإنترنت" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-blue-100 to-blue-400 bg-clip-text text-transparent">
                  Mostafa AI
                </h1>
                <span className="hidden sm:inline-block text-[10px] font-semibold tracking-wide uppercase px-1.5 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Gemini Flash
                </span>
              </div>
              <p className="text-[11px] text-blue-300/70 font-medium">
                شات الذكاء الاصطناعي العربي
              </p>
            </div>
          </div>
        </div>

        {/* Right Side: Quick Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Step-by-Step Deploy Guide Button */}
          <button
            onClick={onOpenGuide}
            title="دليل التشغيل والنشر خطوة بخطوة"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-blue-900/30 hover:bg-blue-800/40 text-blue-300 hover:text-blue-100 text-xs font-medium border border-blue-700/40 active:scale-95 transition-all shadow-sm"
          >
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span className="hidden md:inline">دليل التشغيل والنشر</span>
          </button>

          {/* New Chat Button */}
          <button
            onClick={onNewChat}
            title="محادثة جديدة"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white text-xs font-semibold shadow-md shadow-blue-600/30 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">محادثة جديدة</span>
          </button>

          {/* Clear Current Chat */}
          {hasMessages && (
            <button
              onClick={onClearChat}
              title="مسح الرسائل الحالية"
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 border border-transparent hover:border-rose-900/40 transition-all active:scale-95"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
