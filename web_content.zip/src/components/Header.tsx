import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { ArrowRight, Close, LogoMark, Menu, Play } from "./Icons";

const LINKS = [
  { id: "play", label: "The run" },
  { id: "story", label: "Story" },
  { id: "garage", label: "Garage" },
  { id: "circuit", label: "Circuit" },
  { id: "how-to-play", label: "How to play" },
];

export function Header({ onStart }: { onStart: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("play");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const sections = LINKS.map((link) => document.getElementById(link.id)).filter(
      (node): node is HTMLElement => Boolean(node),
    );
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-35% 0px -55% 0px", threshold: [0.01, 0.2, 0.5] },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener("resize", close);
    return () => window.removeEventListener("resize", close);
  }, [open]);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-500",
        scrolled || open ? "border-b border-white/8 bg-ink-950/85 backdrop-blur-xl" : "border-b border-transparent",
      )}
    >
      <div className="mx-auto flex h-[68px] max-w-[1360px] items-center justify-between gap-4 px-4 sm:h-[76px] sm:px-6 lg:px-10">
        <a
          href="#top"
          onClick={(event) => {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
            setOpen(false);
          }}
          className="group flex items-center gap-2.5"
          aria-label="VANTA — back to top"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-volt text-ink-950 transition group-hover:rotate-[-6deg]">
            <LogoMark className="h-5 w-5" />
          </span>
          <span className="leading-none">
            <span className="block text-[17px] font-bold uppercase tracking-[0.2em] text-bone">Vanta</span>
            <span className="mt-1 block font-mono text-[7px] uppercase tracking-[0.24em] text-moss-500">Highway division</span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {LINKS.map((link) => (
            <button
              key={link.id}
              type="button"
              onClick={() => go(link.id)}
              className={cn(
                "relative rounded-full px-3.5 py-2 text-[12px] font-medium tracking-tight transition-colors",
                active === link.id ? "text-bone" : "text-moss-400 hover:text-bone",
              )}
            >
              {link.label}
              <span
                className={cn(
                  "absolute inset-x-3.5 -bottom-0.5 h-px origin-left bg-volt transition-transform duration-300",
                  active === link.id ? "scale-x-100" : "scale-x-0",
                )}
              />
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <span className="mr-1 hidden items-center gap-2 font-mono text-[9px] uppercase tracking-[0.16em] text-moss-500 xl:flex">
            <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" />
            Highway online
          </span>
          <button
            type="button"
            onClick={onStart}
            className="group hidden items-center gap-2 rounded-full bg-bone px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-950 transition hover:bg-volt sm:inline-flex"
          >
            <Play className="h-2.5 w-2.5" />
            Start a run
            <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
          </button>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/12 bg-white/5 text-bone lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <Close /> : <Menu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/8 bg-ink-950/95 px-4 pb-5 pt-3 backdrop-blur-xl lg:hidden">
          <nav className="flex flex-col" aria-label="Mobile">
            {LINKS.map((link, index) => (
              <button
                key={link.id}
                type="button"
                onClick={() => go(link.id)}
                className="flex items-center justify-between border-b border-white/6 py-3.5 text-left"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-bone">
                  <span className="font-mono text-[9px] text-moss-500">0{index + 1}</span>
                  {link.label}
                </span>
                <ArrowRight className="h-4 w-4 text-moss-500" />
              </button>
            ))}
          </nav>
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              onStart();
            }}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-volt px-4 py-3.5 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-950"
          >
            Start a run <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </header>
  );
}
