import React from 'react';
import { Sun, Moon, Flame, Sparkles, Globe } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HeaderProps {
  onOpenInstallModal?: () => void;
}

export const Header: React.FC<HeaderProps> = () => {
  const { profile, t, theme, toggleTheme, language, setLanguage, todayMetrics, setActiveTab } = useApp();

  // Greeting based on current hour
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return t.greetingMorning;
    if (hour >= 12 && hour < 17) return t.greetingAfternoon;
    if (hour >= 17 && hour < 21) return t.greetingEvening;
    return t.greetingNight;
  };

  // Formatted date
  const now = new Date();
  const dateOptions: Intl.DateTimeFormatOptions = {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  };
  const formattedDate = now.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', dateOptions);

  return (
    <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-100 dark:border-slate-800/80 px-4 py-3 transition-colors">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        {/* Brand & Greeting */}
        <div className="flex items-center gap-3 min-w-0">
          <button 
            onClick={() => setActiveTab('profile')}
            className="relative shrink-0 group focus:outline-hidden"
            aria-label="Profile"
          >
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-10 h-10 rounded-2xl object-cover ring-2 ring-violet-500/25 group-hover:ring-violet-500 transition-all shadow-xs"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900" />
          </button>

          <div 
            onClick={() => setActiveTab('profile')}
            className="min-w-0 cursor-pointer group"
            title={language === 'bn' ? 'প্রোফাইল পরিবর্তন করুন' : 'View & Edit Profile'}
          >
            <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium overflow-hidden">
              <span className="shrink-0">{getGreeting()}</span>
              <span className="shrink-0 text-slate-300 dark:text-slate-600">•</span>
              <span className="truncate">{formattedDate}</span>
            </div>
            <h1 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white truncate tracking-tight flex items-center gap-1.5 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
              <span>{profile.name}</span>
            </h1>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Streak Badge */}
          <div 
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800/50 text-amber-600 dark:text-amber-400 text-xs font-bold shadow-xs"
            title={`${todayMetrics.currentStreak} ${t.days}`}
          >
            <Flame size={14} className="fill-amber-500 text-amber-500" />
            <span>{todayMetrics.currentStreak}</span>
            <span className="hidden sm:inline font-normal">{t.days}</span>
          </div>

          {/* Language Switcher */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors"
            title={language === 'en' ? 'বাংলায় পরিবর্তন করুন' : 'Switch to English'}
            aria-label="Toggle Language"
          >
            <Globe size={13} className="text-violet-500" />
            <span>{language === 'en' ? 'বাং' : 'EN'}</span>
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? (
              <Sun size={15} className="text-amber-400" />
            ) : (
              <Moon size={15} className="text-violet-600" />
            )}
          </button>

          {/* AI Assistant Icon */}
          <button
            onClick={() => setActiveTab('ai')}
            className="p-2 rounded-xl bg-linear-to-r from-violet-500/10 to-indigo-500/10 hover:from-violet-500/20 hover:to-indigo-500/20 text-violet-600 dark:text-violet-400 border border-violet-500/20 transition-all relative"
            aria-label="AI Assistant"
            title={t.aiTitle}
          >
            <Sparkles size={15} />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-violet-600" />
          </button>
        </div>
      </div>
    </header>
  );
};

