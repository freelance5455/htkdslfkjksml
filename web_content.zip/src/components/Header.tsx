import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { t } from '../utils/translations';
import {
  BookOpen,
  Lock,
  Globe,
  Plus,
  Users,
  ChevronDown,
  Check,
  Calculator,
  ShieldCheck
} from 'lucide-react';

interface HeaderProps {
  onOpenQuickAdd: () => void;
  onOpenCalculator: () => void;
  onOpenDownloadApp?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenQuickAdd, onOpenCalculator, onOpenDownloadApp }) => {
  const {
    language,
    setLanguage,
    currentUser,
    users,
    setCurrentUserId,
    lockApp
  } = useApp();

  const [showUserDropdown, setShowUserDropdown] = useState(false);

  return (
    <header className="khatavahi-cover text-white sticky top-0 z-40 print-hide">
      {/* Auspicious Khatavahi Top Bar */}
      <div className="bg-red-950/70 border-b border-amber-600/30 px-3 py-1 text-center text-[11px] font-medium tracking-wider text-amber-300 flex items-center justify-between">
        <span className="hidden sm:inline opacity-80">|| શ્રી સવા ૧ ||</span>
        <span className="mx-auto font-semibold">{t('auspiciousHeader', language)}</span>
        <span className="hidden sm:inline opacity-80">|| લાભ-શુભ ||</span>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo & Khatavahi Book Identity */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative flex-shrink-0 w-9 h-10 sm:w-11 sm:h-12 rounded-lg bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 p-0.5 shadow-md flex items-center justify-center border border-amber-300/60">
              <div className="w-full h-full rounded-[6px] bg-red-950 flex flex-col items-center justify-center text-amber-400">
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6" />
                <span className="text-[9px] font-bold tracking-tighter text-amber-300">ખાતા</span>
              </div>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="text-base sm:text-xl font-bold tracking-tight text-amber-100 truncate">
                  {language === 'gu' ? 'ખાતાવહી' : 'Khatavahi'}
                </h1>
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  ૧૦૦% ઓફલાઇન
                </span>
              </div>
              <p className="text-[11px] text-amber-200/80 truncate hidden sm:block">
                {t('appSubtitle', language)}
              </p>
            </div>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* APK & EXE Download Button */}
            {onOpenDownloadApp && (
              <button
                type="button"
                onClick={onOpenDownloadApp}
                title={language === 'gu' ? 'એન્ડ્રોઇડ APK અને વિન્ડોઝ EXE ડાઉનલોડ' : 'Download Android APK & Windows EXE'}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-800/90 border border-emerald-400/50 text-emerald-100 hover:bg-emerald-700 hover:text-white text-xs font-bold transition-all shadow-sm"
              >
                <span className="text-amber-300">⬇</span>
                <span className="hidden sm:inline">APK / EXE</span>
                <span className="sm:hidden text-[11px]">એપ</span>
              </button>
            )}

            {/* Quick Vyaj Calculator Button */}
            <button
              type="button"
              onClick={onOpenCalculator}
              title={t('instantCalculator', language)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-900/80 border border-amber-500/40 text-amber-200 hover:bg-red-800 hover:text-white text-xs font-medium transition-all shadow-sm"
            >
              <Calculator className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">{t('instantCalculator', language)}</span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center rounded-lg bg-red-950/80 border border-amber-500/30 p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setLanguage('gu')}
                className={`px-2 py-1 rounded transition-all ${
                  language === 'gu'
                    ? 'bg-amber-500 text-red-950 shadow-sm font-bold'
                    : 'text-amber-200 hover:text-white'
                }`}
              >
                ગુજરાતી
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded transition-all ${
                  language === 'en'
                    ? 'bg-amber-500 text-red-950 shadow-sm font-bold'
                    : 'text-amber-200 hover:text-white'
                }`}
              >
                English
              </button>
            </div>

            {/* User Profile Switcher */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-red-900/60 border border-amber-500/30 text-amber-100 hover:bg-red-800 text-xs font-medium transition-all max-w-[140px] sm:max-w-[180px]"
              >
                <Users className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                <span className="truncate">{currentUser.name}</span>
                <ChevronDown className="w-3 h-3 text-amber-300 flex-shrink-0" />
              </button>

              {showUserDropdown && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setShowUserDropdown(false)}
                  />
                  <div className="absolute right-0 mt-1 w-56 rounded-xl bg-stone-900 border border-amber-500/40 shadow-2xl py-1 z-40 text-stone-100 text-xs">
                    <div className="px-3 py-1.5 border-b border-stone-800 text-[10px] text-stone-400 font-semibold uppercase tracking-wider">
                      {t('switchUser', language)}
                    </div>
                    {users.map((u) => (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => {
                          setCurrentUserId(u.id);
                          setShowUserDropdown(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-red-950/60 flex items-center justify-between text-stone-200 transition-colors"
                      >
                        <span className="truncate font-medium">{u.name}</span>
                        {u.id === currentUser.id && (
                          <Check className="w-3.5 h-3.5 text-amber-400" />
                        )}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Lock Button (if PIN is enabled) */}
            {currentUser.pinEnabled && (
              <button
                type="button"
                onClick={lockApp}
                title={t('lockNow', language)}
                className="p-1.5 rounded-lg bg-red-900/80 border border-amber-500/40 text-amber-300 hover:bg-amber-600 hover:text-red-950 transition-all shadow-sm"
              >
                <Lock className="w-4 h-4" />
              </button>
            )}

            {/* Quick Add Button */}
            <button
              type="button"
              onClick={onOpenQuickAdd}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-red-950 hover:from-amber-400 hover:to-amber-500 font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">{t('newTransaction', language)}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
