import React from 'react';
import { Camera, Settings, RotateCcw, Sparkles } from 'lucide-react';
import { CameraState } from '../types';

interface HeaderProps {
  cameraState: CameraState;
  onOpenScanner: () => void;
  onOpenSettings: () => void;
  onCleanSession: () => void;
  hasSavedKey: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  cameraState,
  onOpenScanner,
  onOpenSettings,
  onCleanSession,
  hasSavedKey,
}) => {
  const isCameraLive = cameraState === 'CAMERA_ACTIVE';

  return (
    <header className="w-full flex flex-col space-y-2.5 px-4 pt-3 pb-2 z-20 shrink-0">
      {/* Top Branding Row */}
      <div className="w-full flex items-center justify-between">
        <div className="flex items-center space-x-1.5">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent flex items-center">
            AI.P
            <span className="text-pink-400 ml-1 text-lg sm:text-xl animate-pulse">💜</span>
          </h1>
        </div>

        {/* Action Controls: Sitting + Camera + Refresh/Reset */}
        <div className="flex items-center space-x-2">
          {/* CAMERA SECTION: Premium realistic glass/neon camera frame, never a black box */}
          <button
            onClick={onOpenScanner}
            title={isCameraLive ? 'Camera Active - Tap to View' : 'Camera - Tap to Open Scanner'}
            className={`group relative flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border transition-all duration-300 active:scale-95 ${
              isCameraLive
                ? 'bg-gradient-to-r from-emerald-950/60 to-cyan-950/60 border-emerald-500/60 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                : 'bg-gradient-to-r from-[#121832]/80 to-[#181f3e]/80 border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_0_12px_rgba(6,182,212,0.15)]'
            }`}
          >
            {/* Viewfinder reticle corners on hover / active */}
            <span className="absolute top-0.5 left-0.5 w-1.5 h-1.5 border-t border-l border-cyan-400/80 rounded-tl" />
            <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 border-t border-r border-cyan-400/80 rounded-tr" />
            <span className="absolute bottom-0.5 left-0.5 w-1.5 h-1.5 border-b border-l border-cyan-400/80 rounded-bl" />
            <span className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 border-b border-r border-cyan-400/80 rounded-br" />

            <div className="relative flex items-center justify-center">
              <Camera
                className={`w-3.5 h-3.5 transition-colors duration-200 ${
                  isCameraLive ? 'text-emerald-400 animate-pulse' : 'text-cyan-300'
                }`}
              />
            </div>

            <div className="flex flex-col items-start leading-none text-left">
              <span className="text-[11px] font-semibold text-white tracking-wide">
                Camera
              </span>
              <span
                className={`text-[9px] font-medium mt-0.5 flex items-center space-x-1 ${
                  isCameraLive ? 'text-emerald-300' : 'text-slate-400'
                }`}
              >
                <span
                  className={`w-1 h-1 rounded-full ${
                    isCameraLive ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'
                  }`}
                />
                <span>{isCameraLive ? 'Active' : 'Ready'}</span>
              </span>
            </div>
          </button>

          {/* SITTING (SETTINGS) SECTION */}
          <button
            onClick={onOpenSettings}
            title="Settings"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#14152e]/80 to-[#1e1c3e]/80 border border-purple-500/30 hover:border-purple-400/60 text-slate-200 transition-all duration-300 active:scale-95 shadow-[0_0_12px_rgba(168,85,247,0.15)]"
          >
            <Settings className="w-3.5 h-3.5 text-purple-300 group-hover:rotate-45 transition-transform" />
            <div className="flex flex-col items-start leading-none text-left">
              <span className="text-[11px] font-semibold text-white tracking-wide">
                Settings
              </span>
              <span className="text-[9px] font-medium text-slate-400 mt-0.5 flex items-center space-x-1">
                <span
                  className={`w-1 h-1 rounded-full ${
                    hasSavedKey ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
                <span>{hasSavedKey ? 'Configured' : 'Key Needed'}</span>
              </span>
            </div>
          </button>

          {/* REFRESH / RESET BUTTON (Beside Sitting + Camera section) */}
          <button
            onClick={onCleanSession}
            title="Start Fresh (Reset Session)"
            className="p-2 rounded-xl bg-[#0f1428] border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 hover:text-white transition-all duration-300 active:scale-90 shadow-md shadow-cyan-950/40"
          >
            <RotateCcw className="w-3.5 h-3.5 hover:rotate-180 transition-transform duration-500" />
          </button>
        </div>
      </div>
    </header>
  );
};
