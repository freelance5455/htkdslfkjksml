import React, { useState } from 'react';
import {
  Clock,
  Bell,
  RefreshCw,
  Moon,
  Sun,
  LayoutGrid,
  CalendarDays,
  List,
  MapPin,
  Smartphone,
  Layers,
  ChevronDown,
  ChevronUp,
  Globe,
  Flame,
  Sliders,
  Languages,
} from 'lucide-react';
import { CalendarDay, LocationPreset, UserSettings, ZmanItem, Language } from '../types';
import { LOCATION_PRESETS } from '../services/hebrewCalendarService';
import { getTranslations } from '../services/i18n';

interface HeaderProps {
  currentDate?: Date;
  onDateChange?: (date: Date) => void;
  todayDay: CalendarDay;
  selectedDate?: Date;
  viewMode: UserSettings['viewMode'];
  onViewModeChange: (mode: UserSettings['viewMode']) => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  currentLocation?: LocationPreset;
  onLocationChange?: (loc: LocationPreset) => void;
  eventsCount?: number;
  nextZman: ZmanItem | null;
  onOpenSyncModal: () => void;
  onOpenAlertsModal?: () => void;
  onOpenNotifModal?: () => void;
  onOpenEventsModal: () => void;
  onOpenWidgetModal: () => void;
  onOpenConverterModal: () => void;
  onOpenZmanimModal: () => void;
  onOpenManualLocationModal?: () => void;
  onOpenSettingsModal?: () => void;
  syncConnected?: boolean;
  unreadNotifsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  todayDay,
  viewMode,
  onViewModeChange,
  settings,
  onUpdateSettings,
  currentLocation = settings.location,
  onLocationChange,
  nextZman,
  onOpenSyncModal,
  onOpenAlertsModal,
  onOpenNotifModal,
  onOpenEventsModal,
  onOpenWidgetModal,
  onOpenConverterModal,
  onOpenZmanimModal,
  onOpenManualLocationModal,
  onOpenSettingsModal,
  syncConnected = false,
  unreadNotifsCount = 0,
}) => {
  const [showLocationDropdown, setShowLocationDropdown] = useState(false);
  const [showViewDropdown, setShowViewDropdown] = useState(false);
  const [showToolsDropdown, setShowToolsDropdown] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const currentLang: Language = settings.language || 'en';
  const t = getTranslations(currentLang);
  const isRtl = currentLang === 'he';

  const toggleDarkMode = () => {
    const isDark = settings.darkMode !== false;
    onUpdateSettings({ theme: isDark ? 'light' : 'dark', darkMode: !isDark });
  };

  const toggleLanguage = () => {
    const nextLang: Language = currentLang === 'he' ? 'en' : 'he';
    onUpdateSettings({ language: nextLang });
  };

  const handleLocationSelect = (loc: LocationPreset) => {
    if (onLocationChange) {
      onLocationChange(loc);
    } else {
      onUpdateSettings({ location: loc });
    }
    setShowLocationDropdown(false);
  };

  // Dual GPS + IP Geolocation auto-detect fallback
  const handleUseGps = async () => {
    setGpsLoading(true);

    const tryIPFallback = async (reason: string) => {
      console.log(`GPS failed (${reason}). Trying secure IP fallback...`);
      try {
        // Try FreeIPAPI
        const res = await fetch('https://freeipapi.com/api/json');
        if (!res.ok) throw new Error('freeipapi failed');
        const data = await res.json();
        
        const detectedLat = Number(data.latitude || 31.7683);
        const detectedLong = Number(data.longitude || 35.2137);
        const inIsrael = detectedLat > 29 && detectedLat < 33.5 && detectedLong > 34 && detectedLong < 36;
        
        const ipLoc: LocationPreset = {
          id: `gps-ip-${Date.now()}`,
          name: data.cityName ? `${data.cityName} (IP)` : 'My Location (IP)',
          nameHe: inIsrael ? 'מיקום נוכחי (IP)' : 'מיקום נוכחי',
          country: data.countryName || (inIsrael ? 'Israel' : 'Local'),
          lat: detectedLat,
          long: detectedLong,
          elevation: 0,
          timezone: data.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem',
          isIsrael: inIsrael,
          candleLightingOffset: inIsrael ? 20 : 18,
        };
        handleLocationSelect(ipLoc);
        setGpsLoading(false);
      } catch (err1) {
        console.warn('FreeIPAPI failed, trying IPAPI.co fallback...', err1);
        try {
          // Secondary fallback
          const res = await fetch('https://ipapi.co/json/');
          if (!res.ok) throw new Error('ipapi.co failed');
          const data = await res.json();
          
          const detectedLat = Number(data.latitude || 31.7683);
          const detectedLong = Number(data.longitude || 35.2137);
          const inIsrael = detectedLat > 29 && detectedLat < 33.5 && detectedLong > 34 && detectedLong < 36;
          
          const ipLoc: LocationPreset = {
            id: `gps-ip-${Date.now()}`,
            name: data.city ? `${data.city} (IP)` : 'My Location (IP)',
            nameHe: inIsrael ? 'מיקום נוכחי (IP)' : 'מיקום נוכחי',
            country: data.country_name || (inIsrael ? 'Israel' : 'Local'),
            lat: detectedLat,
            long: detectedLong,
            elevation: 0,
            timezone: data.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem',
            isIsrael: inIsrael,
            candleLightingOffset: inIsrael ? 20 : 18,
          };
          handleLocationSelect(ipLoc);
          setGpsLoading(false);
        } catch (err2) {
          console.error('All location detection methods failed:', err2);
          setGpsLoading(false);
          alert(
            currentLang === 'he'
              ? 'לא הצלחנו לזהות את המיקום באופן אוטומטי. אנא בחר אחת מהערים המוצעות או הזן מיקום ידנית.'
              : 'Could not automatically detect location. Please choose a preset city or enter your custom location manually.'
          );
        }
      }
    };

    if (!navigator.geolocation) {
      await tryIPFallback('Geolocation API not supported');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const detectedLat = Number(pos.coords.latitude.toFixed(4));
        const detectedLong = Number(pos.coords.longitude.toFixed(4));
        const detectedElev = pos.coords.altitude ? Math.round(pos.coords.altitude) : 0;
        
        const inIsrael =
          detectedLat > 29 &&
          detectedLat < 33.5 &&
          detectedLong > 34 &&
          detectedLong < 36;

        const gpsLoc: LocationPreset = {
          id: `gps-custom-${Date.now()}`,
          name: `Current Location (${detectedLat}°, ${detectedLong}°)`,
          nameHe: 'מיקום נוכחי',
          country: 'Local',
          lat: detectedLat,
          long: detectedLong,
          elevation: detectedElev,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem',
          isIsrael: inIsrael,
          candleLightingOffset: inIsrael ? 20 : 18,
        };
        handleLocationSelect(gpsLoc);
        setGpsLoading(false);
      },
      async (err) => {
        console.warn('Native GPS failed, triggering IP fallback', err);
        await tryIPFallback(err.message || 'Permission denied/timeout');
      },
      { timeout: 6000, enableHighAccuracy: true }
    );
  };

  const handleNotificationClick = () => {
    if (onOpenAlertsModal) onOpenAlertsModal();
    else if (onOpenNotifModal) onOpenNotifModal();
  };

  return (
    <header className="h-auto min-h-16 border-b border-[#2A2A2A] bg-[#161616] sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Left: Brand Emblem & Hebrew Date Title */}
        <div className="flex items-center justify-between w-full md:w-auto gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl overflow-hidden border border-[#C5A267]/40 shadow-sm shrink-0 bg-[#1A1A1A] flex items-center justify-center">
              <img
                src="/app-icon.jpg"
                alt="לוחות בה"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  if (target.parentElement) {
                    target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold font-serif-hebrew text-sm">בה</div>';
                  }
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-[#EAEAEA] font-serif-hebrew">
                  {t.appName}
                </h1>
                <span className="text-xs px-2 py-0.5 rounded-sm font-semibold bg-[#252525] border border-[#3A3A3A] text-[#C5A267] font-hebrew">
                  {todayDay.hebrewYearLetters}
                </span>
              </div>
              <p className="text-xs text-[#888888] font-hebrew flex items-center gap-1.5">
                <span className="font-semibold text-[#D1D1D1]" dir="rtl">{todayDay.hebrewDateStrHe}</span>
                {!isRtl && (
                  <>
                    <span className="text-[#555555]">•</span>
                    <span>{todayDay.hebrewDateStr}</span>
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Location Selector Dropdown trigger */}
          <div className="relative">
            <button
              id="location-picker-btn"
              onClick={() => setShowLocationDropdown(!showLocationDropdown)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#D1D1D1] transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-[#C5A267] shrink-0" />
              <span className="truncate max-w-[100px] sm:max-w-[140px]">
                {isRtl ? currentLocation.nameHe || currentLocation.name : currentLocation.name}
              </span>
              <ChevronDown className="w-3 h-3 text-[#666666]" />
            </button>

            {showLocationDropdown && (
              <div className="absolute left-0 sm:right-0 sm:left-auto mt-2 w-72 bg-[#161616] rounded-xl shadow-2xl border border-[#2A2A2A] py-2 z-50 animate-in fade-in duration-150">
                <div className="px-3 py-1.5 border-b border-[#2A2A2A] flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#888888] uppercase tracking-wider">
                    {t.selectLocation}
                  </span>
                   <button
                    onClick={handleUseGps}
                    disabled={gpsLoading}
                    className="text-xs text-[#C5A267] hover:underline flex items-center gap-1.5 font-medium disabled:opacity-50"
                  >
                    <Globe className={`w-3 h-3 ${gpsLoading ? 'animate-spin' : ''}`} />
                    <span>{gpsLoading ? (currentLang === 'he' ? 'מזהה...' : 'Detecting...') : t.gps}</span>
                  </button>
                </div>

                {/* Custom / Manual Location Button */}
                {onOpenManualLocationModal && (
                  <div className="p-2 border-b border-[#2A2A2A] bg-[#1A1A1A]/80">
                    <button
                      onClick={() => {
                        setShowLocationDropdown(false);
                        onOpenManualLocationModal();
                      }}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-[#252525] hover:bg-[#303030] text-[#C5A267] border border-[#3A3A3A] text-xs font-semibold transition-colors"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{t.setManualLocation}</span>
                    </button>
                  </div>
                )}

                <div className="max-h-60 overflow-y-auto py-1">
                  {LOCATION_PRESETS.map((loc) => (
                    <button
                      key={loc.id}
                      onClick={() => handleLocationSelect(loc)}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                        loc.id === currentLocation.id
                          ? 'bg-[#252525] text-[#C5A267] font-semibold'
                          : 'text-[#D1D1D1] hover:bg-[#202020]'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span>{loc.name}</span>
                        <span className="text-[10px] text-[#666666] font-hebrew text-right" dir="rtl">
                          {loc.nameHe} • {loc.country}
                        </span>
                      </div>
                      {loc.isIsrael && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#252525] text-[#C5A267] border border-[#3A3A3A]">
                          Israel
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: View Switcher & Action Icons consolidated as Dropdowns */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          {/* 1. View Mode Dropdown */}
          <div className="relative">
            <button
              id="view-mode-dropdown-btn"
              onClick={() => {
                setShowViewDropdown(!showViewDropdown);
                setShowToolsDropdown(false);
                setShowLocationDropdown(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-semibold text-[#D1D1D1] transition-colors"
            >
              <span>
                {currentLang === 'he'
                  ? `תצוגה: ${
                      viewMode === 'month'
                        ? t.viewMonth
                        : viewMode === 'week'
                        ? t.viewWeek
                        : viewMode === 'day'
                        ? t.viewDay
                        : t.viewAgenda
                    }`
                  : `View: ${
                      viewMode === 'month'
                        ? t.viewMonth
                        : viewMode === 'week'
                        ? t.viewWeek
                        : viewMode === 'day'
                        ? t.viewDay
                        : t.viewAgenda
                    }`}
              </span>
              <ChevronDown className="w-3 h-3 text-[#888888]" />
            </button>

            {showViewDropdown && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowViewDropdown(false)} 
                />
                <div className="absolute right-0 mt-2 w-40 bg-[#161616] rounded-xl shadow-2xl border border-[#2A2A2A] py-1 z-50 animate-in fade-in duration-150">
                  {[
                    { id: 'month', label: t.viewMonth },
                    { id: 'week', label: t.viewWeek },
                    { id: 'day', label: t.viewDay },
                    { id: 'agenda', label: t.viewAgenda },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => {
                        onViewModeChange(item.id as any);
                        setShowViewDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-xs flex items-center justify-between transition-colors ${
                        viewMode === item.id
                          ? 'bg-[#252525] text-[#C5A267] font-semibold'
                          : 'text-[#D1D1D1] hover:bg-[#202020]'
                      }`}
                    >
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* 2. Tools & Actions Dropdown */}
          <div className="relative">
            <button
              id="tools-dropdown-btn"
              onClick={() => {
                setShowToolsDropdown(!showToolsDropdown);
                setShowViewDropdown(false);
                setShowLocationDropdown(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-semibold text-[#C5A267] transition-colors relative"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{currentLang === 'he' ? 'כלים ופעולות' : 'Tools & Actions'}</span>
              {unreadNotifsCount > 0 && (
                <span className="w-2 h-2 bg-[#C5A267] rounded-full animate-ping shrink-0" />
              )}
              <ChevronDown className="w-3 h-3 text-[#888888]" />
            </button>

            {showToolsDropdown && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowToolsDropdown(false)} 
                />
                <div className="absolute right-0 mt-2 w-56 bg-[#161616] rounded-xl shadow-2xl border border-[#2A2A2A] py-1.5 z-50 animate-in fade-in duration-150">
                  {/* Quick Language Switcher */}
                  <button
                    onClick={() => {
                      toggleLanguage();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <Languages className="w-4 h-4 text-[#888888]" />
                    <span>{currentLang === 'he' ? 'English (LTR)' : 'עברית (RTL)'}</span>
                  </button>

                  {/* Date Converter */}
                  <button
                    onClick={() => {
                      onOpenConverterModal();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <Layers className="w-4 h-4 text-[#888888]" />
                    <span>{t.dateConverter}</span>
                  </button>

                  {/* Personal Events */}
                  <button
                    onClick={() => {
                      onOpenEventsModal();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <Flame className="w-4 h-4 text-[#C5A267]" />
                    <span>{t.eventsManager || 'Personal Events'}</span>
                  </button>

                  {/* Home Screen Widget */}
                  <button
                    onClick={() => {
                      onOpenWidgetModal();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <Smartphone className="w-4 h-4 text-[#888888]" />
                    <span>{t.homeWidget}</span>
                  </button>

                  {/* Notifications */}
                  <button
                    onClick={() => {
                      handleNotificationClick();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center justify-between text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Bell className="w-4 h-4 text-[#888888]" />
                      <span>{t.notifications}</span>
                    </div>
                    {unreadNotifsCount > 0 && (
                      <span className="px-1.5 py-0.5 bg-[#C5A267] text-[#0F0F0F] rounded-full text-[10px] font-bold">
                        {unreadNotifsCount}
                      </span>
                    )}
                  </button>

                  {/* Sync Devices */}
                  <button
                    onClick={() => {
                      onOpenSyncModal();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center justify-between text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <RefreshCw className={`w-4 h-4 ${syncConnected ? 'text-emerald-400' : 'text-[#888888]'}`} />
                      <span>{t.syncDevices}</span>
                    </div>
                    {syncConnected && (
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                    )}
                  </button>

                  {/* Settings */}
                  {onOpenSettingsModal && (
                    <button
                      onClick={() => {
                        onOpenSettingsModal();
                        setShowToolsDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                    >
                      <Sliders className="w-4 h-4 text-[#888888]" />
                      <span>{t.settings}</span>
                    </button>
                  )}

                  {/* Toggle Dark Mode */}
                  <button
                    onClick={() => {
                      toggleDarkMode();
                      setShowToolsDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 text-[#D1D1D1] hover:bg-[#202020] transition-colors border-t border-[#2A2A2A] mt-1.5 pt-2.5"
                  >
                    {settings.darkMode !== false ? (
                      <>
                        <Sun className="w-4 h-4 text-[#C5A267]" />
                        <span>{currentLang === 'he' ? 'ערכת נושא: בהיר' : 'Theme: Light'}</span>
                      </>
                    ) : (
                      <>
                        <Moon className="w-4 h-4 text-[#888888]" />
                        <span>{currentLang === 'he' ? 'ערכת נושא: כהה' : 'Theme: Dark'}</span>
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

