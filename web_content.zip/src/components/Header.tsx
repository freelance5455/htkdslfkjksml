import React from 'react';
import { UserProfile, MarketItem } from '../types';
import { Coins, Flame, Award, Ticket, LogOut, Volume2, VolumeX, Wifi, WifiOff } from 'lucide-react';

interface HeaderProps {
  user: UserProfile;
  marketItems?: MarketItem[];
  isOnline: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenCouponModal: () => void;
  onOpenEquipment: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  marketItems = [],
  isOnline,
  soundEnabled,
  onToggleSound,
  onOpenCouponModal,
  onOpenEquipment,
  onLogout,
}) => {
  const activeCustomFrame = marketItems.find((i) => i.id === user.frame && i.customFrameConfig);

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        
        {/* User Mini Profile with Animated Frame & Title */}
        <div 
          onClick={onOpenEquipment}
          className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group p-1 -m-1 rounded-2xl hover:bg-slate-900/60 transition-colors"
          title="انقر لفتح مركز التجهيز والبروفايل"
        >
          {/* Avatar with equipped glowing frame */}
          <div className="relative">
            <div
              style={
                activeCustomFrame?.customFrameConfig
                  ? {
                      borderWidth: `${activeCustomFrame.customFrameConfig.borderWidth || 3}px`,
                      borderStyle: 'solid',
                      borderColor: activeCustomFrame.customFrameConfig.borderColor1,
                      boxShadow: `0 0 20px ${activeCustomFrame.customFrameConfig.glowColor}`,
                    }
                  : undefined
              }
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden flex items-center justify-center bg-slate-900 shadow-md ${
                activeCustomFrame?.customFrameConfig
                  ? activeCustomFrame.customFrameConfig.animation === 'spin'
                    ? 'animate-spin'
                    : 'animate-pulse'
                  : user.frame && user.frame !== 'none'
                  ? user.frame
                  : 'border-2 border-slate-700'
              }`}
            >
              {user.customAvatarUrl ? (
                <img
                  src={user.customAvatarUrl}
                  alt={user.name}
                  className="w-full h-full object-cover"
                />
              ) : user.avatar && user.avatar.startsWith('data:image/') ? (
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-full h-full object-contain p-0.5"
                />
              ) : (
                <span className="text-xl sm:text-2xl select-none">{user.avatar || '🦅'}</span>
              )}
            </div>

            {/* Level badge */}
            <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full border border-slate-950 shadow">
              {user.level}
            </div>
          </div>

          {/* User Name & Title */}
          <div className="text-right">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs sm:text-sm text-slate-100 group-hover:text-indigo-300 transition-colors truncate max-w-[110px] sm:max-w-[150px]">
                {user.name}
              </span>
              {user.role === 'founder' && (
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] px-1.5 py-0.5 rounded-full font-black tracking-wide">
                  👑 مؤسس
                </span>
              )}
            </div>
            
            {/* Equipped Title */}
            <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-amber-400 font-semibold truncate max-w-[130px] sm:max-w-[180px]">
              <Award className="w-3 h-3 text-amber-400 shrink-0" />
              <span>{user.title || 'منجز واعد'}</span>
            </div>
          </div>
        </div>

        {/* Right Stats & Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          
          {/* Streak indicator */}
          <div className="flex items-center gap-1 bg-amber-950/40 border border-amber-600/30 px-2 py-1 rounded-xl text-amber-300 text-xs font-bold" title="أيام متتالية من الإنجاز">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-pulse" />
            <span>{user.streak}</span>
          </div>

          {/* Coins balance pill */}
          <div 
            onClick={onOpenCouponModal}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/40 px-2.5 py-1 rounded-xl text-amber-300 text-xs sm:text-sm font-extrabold shadow-sm hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title="رصيد النقاط - انقر لاسترداد كود كوبون"
          >
            <Coins className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>{user.coins.toLocaleString('ar-EG')}</span>
          </div>

          {/* Redeem coupon icon button */}
          <button
            onClick={onOpenCouponModal}
            className="p-1.5 sm:p-2 rounded-xl bg-slate-900/90 border border-slate-800 text-indigo-300 hover:text-white hover:bg-indigo-600 transition-all cursor-pointer"
            title="شحن كود كوبون هدية 🎟️"
          >
            <Ticket className="w-4 h-4" />
          </button>

          {/* Sound toggle */}
          <button
            onClick={onToggleSound}
            className="p-1.5 sm:p-2 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            title={soundEnabled ? 'كتم المؤثرات الصوتية' : 'تفعيل المؤثرات الصوتية'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Hybrid connection status indicator */}
          <div
            className={`hidden sm:flex items-center gap-1 px-2 py-1 rounded-xl text-[10px] font-bold border ${
              isOnline
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
            }`}
            title={isOnline ? 'متصل بالسحابة وتتم المزامنة لحظياً' : 'وضع غير متصل - الحفظ محلي'}
          >
            {isOnline ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-amber-400" />}
            <span>{isOnline ? 'سحابي' : 'محلي'}</span>
          </div>

          {/* Logout button */}
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
            title="تسجيل الخروج من الحساب"
          >
            <LogOut className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[11px] font-black">خروج</span>
          </button>

        </div>

      </div>
    </header>
  );
};
