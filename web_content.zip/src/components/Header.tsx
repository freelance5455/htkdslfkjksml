import React from 'react';
import { Volume2, VolumeX, Rotate3d, Globe, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  soundEnabled: boolean;
  onSoundToggle: () => void;
  animationEnabled: boolean;
  onAnimationToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  soundEnabled,
  onSoundToggle,
  animationEnabled,
  onAnimationToggle,
}) => {
  const tr = t[language];

  return (
    <header className="relative overflow-hidden pt-6 pb-5 px-4 text-center bg-gradient-to-r from-[#07182c] via-[#152e50] to-[#07182c] border-b-2 border-[#00dcff] shadow-[0_4px_30px_rgba(0,220,255,0.18)]">
      {/* Background glow lines */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#00dcff_1px,transparent_1px)] [background-size:16px_16px]" />

      {/* Control Utility Toolbar */}
      <div className="max-w-2xl mx-auto flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-1.5 bg-[#091526]/80 border border-[#208fc0]/40 rounded-lg p-1 backdrop-blur-sm">
          <button
            onClick={() => {
              sounds.playClick();
              onLanguageChange(language === 'ur' ? 'en' : 'ur');
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded text-cyan-200 hover:text-white hover:bg-cyan-900/40 transition-colors font-medium cursor-pointer"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === 'ur' ? 'English' : 'اردو'}</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5 bg-[#091526]/80 border border-[#208fc0]/40 rounded-lg p-1 backdrop-blur-sm">
          <button
            onClick={() => {
              onAnimationToggle();
              sounds.playClick();
            }}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors cursor-pointer ${
              animationEnabled ? 'text-cyan-300 bg-cyan-950/60' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle 3D Rotation"
          >
            <Rotate3d className={`w-3.5 h-3.5 ${animationEnabled ? 'text-cyan-400' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">{tr.animToggle}</span>
          </button>

          <button
            onClick={() => {
              onSoundToggle();
            }}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors cursor-pointer ${
              soundEnabled ? 'text-cyan-300 bg-cyan-950/60' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Audio Feedback"
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span className="hidden sm:inline">{tr.soundToggle}</span>
          </button>
        </div>
      </div>

      {/* 3D Spinning AKS Logo */}
      <div className="perspective-1000 my-2 select-none">
        <div
          className={`inline-block preserve-3d cursor-pointer ${animationEnabled ? 'spin-slow' : ''}`}
          onClick={() => {
            sounds.playSuccess();
          }}
          title="AKS 3D Emblem"
        >
          <div className="px-6 py-1 rounded-2xl border-2 border-cyan-400/40 bg-gradient-to-b from-[#16365c]/80 to-[#0b172a]/90 backdrop-blur-md shadow-[0_0_20px_rgba(0,220,255,0.35)]">
            <span
              className="font-black text-5xl sm:text-6xl tracking-wider text-[#39eaff] inline-block font-sans"
              style={{
                textShadow: '0 0 10px #00cfff, 0 0 30px #008cff, 0 0 50px rgba(0,140,255,0.5)',
              }}
            >
              AKS
            </span>
          </div>
        </div>
      </div>

      {/* Subtitles matching the exact style and upgraded */}
      <div className="tracking-[5px] sm:tracking-[7px] text-[#b5eaff] text-xs sm:text-sm font-bold uppercase mt-2">
        {tr.systemTitle}
      </div>
      <p className="text-[#a7eaff] text-xs sm:text-sm tracking-wider mt-1 font-medium flex items-center justify-center gap-1.5">
        <Sparkles className="w-3.5 h-3.5 text-cyan-400 opacity-80" />
        {tr.systemSub}
        <Sparkles className="w-3.5 h-3.5 text-cyan-400 opacity-80" />
      </p>
    </header>
  );
};
