import React from "react";
import { Sparkles, Wifi, WifiOff, ShieldCheck, Globe, Info, Zap } from "lucide-react";
import { Language } from "../types";

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  onOpenAbout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  isOffline,
  onToggleOffline,
  onOpenAbout,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-white/10 px-4 py-3 sm:px-6 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 p-[1.5px] shadow-lg shadow-indigo-500/20 shrink-0">
            <div className="w-full h-full bg-[#0d1322] rounded-[14px] flex items-center justify-center">
              <span className="font-extrabold text-lg text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 to-cyan-200">
                R
              </span>
            </div>
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </span>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white truncate">
                Ranabir
              </h1>
              <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shrink-0">
                AI Assistant
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium truncate">
              সর্বদা সাহায্য করার জন্য প্রস্তুত
            </p>
          </div>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Speed badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
            <Zap className="w-3.5 h-3.5" />
            <span>&lt;2s Engine</span>
          </div>

          {/* Offline / Online toggle */}
          <button
            onClick={onToggleOffline}
            title={isOffline ? "অনলাইনে সুইচ করুন" : "অফলাইন মোড পরীক্ষা করুন"}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all duration-200 ${
              isOffline
                ? "bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-sm"
                : "bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 text-slate-300"
            }`}
          >
            {isOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">Offline Mode</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">Online</span>
              </>
            )}
          </button>

          {/* Language selector */}
          <div className="relative flex items-center bg-slate-800/80 rounded-xl p-0.5 border border-white/10">
            <button
              onClick={() => onLanguageChange("bn")}
              className={`px-2 py-1 text-xs font-semibold rounded-lg transition-colors ${
                language === "bn"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              বাংলা
            </button>
            <button
              onClick={() => onLanguageChange("en")}
              className={`px-2 py-1 text-xs font-semibold rounded-lg transition-colors ${
                language === "en"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onLanguageChange("hi")}
              className={`px-2 py-1 text-xs font-semibold rounded-lg transition-colors hidden sm:block ${
                language === "hi"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              हिं
            </button>
          </div>

          {/* Privacy & About button */}
          <button
            onClick={onOpenAbout}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 text-slate-300 hover:text-white transition-colors"
            title="Privacy & About Ranabir"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
