import React, { useRef, useEffect, useState } from 'react';
import {
  Play,
  Pause,
  Square,
  Circle,
  Repeat,
  Volume2,
  FolderOpen,
  Download,
  FilePlus,
  Sliders,
  Music,
  Grid,
  Radio,
  Layers,
  ChevronDown
} from 'lucide-react';
import { Project, ViewMode } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';
import { DEMO_PROJECTS } from '../data/demoProjects';

interface HeaderProps {
  project: Project;
  activeView: ViewMode;
  playhead: PlayheadState;
  onViewChange: (view: ViewMode) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
  onLoadProject: (proj: Project) => void;
  onOpenExportModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  project,
  activeView,
  playhead,
  onViewChange,
  onUpdateProject,
  onLoadProject,
  onOpenExportModal,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [metronomeOn, setMetronomeOn] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [tempName, setTempName] = useState(project.name);

  // Sync metronome state with audio engine
  const toggleMetronome = () => {
    const next = !metronomeOn;
    setMetronomeOn(next);
    engine.setMetronome(next);
  };

  // Tap tempo helper
  const tapTimesRef = useRef<number[]>([]);
  const handleTapTempo = () => {
    const now = performance.now();
    const times = tapTimesRef.current;
    times.push(now);
    if (times.length > 4) times.shift();

    if (times.length >= 2) {
      let totalDiff = 0;
      for (let i = 1; i < times.length; i++) {
        totalDiff += times[i] - times[i - 1];
      }
      const avgDiffMs = totalDiff / (times.length - 1);
      const calculatedBpm = Math.round(60000 / avgDiffMs);
      if (calculatedBpm >= 60 && calculatedBpm <= 220) {
        onUpdateProject(p => ({ ...p, bpm: calculatedBpm }));
      }
    }
  };

  // Real-time Visualizer Animation
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const data = engine.getVisualizerData();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const numBars = 18;
      const barWidth = Math.max(2, (canvas.width / numBars) - 1.5);
      const step = Math.floor(data.length / numBars);

      for (let i = 0; i < numBars; i++) {
        const val = data[i * step] || 0;
        const barHeight = Math.max(2, (val / 255) * canvas.height);
        const x = i * (barWidth + 1.5);
        const y = canvas.height - barHeight;

        // FL Studio Orange to Neon Yellow-Green Gradient
        const grad = ctx.createLinearGradient(0, canvas.height, 0, 0);
        grad.addColorStop(0, '#ff7700');
        grad.addColorStop(0.7, '#ffb300');
        grad.addColorStop(1, '#00e676');

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, barHeight);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  const handlePlayToggle = () => {
    if (playhead.isPlaying) {
      engine.pausePlayback();
    } else {
      engine.startPlayback(false);
    }
  };

  const handleRecordToggle = () => {
    if (playhead.isPlaying && playhead.isRecording) {
      engine.stopPlayback();
    } else {
      engine.startPlayback(true);
    }
  };

  const handleStop = () => {
    engine.stopPlayback();
  };

  const handleLoopToggle = () => {
    onUpdateProject(p => ({ ...p, isLooping: !p.isLooping }));
  };

  const handleBpmChange = (delta: number) => {
    onUpdateProject(p => ({
      ...p,
      bpm: Math.max(60, Math.min(220, p.bpm + delta)),
    }));
  };

  return (
    <header className="h-14 bg-[#15181f] border-b border-[#262c38] px-3 sm:px-4 flex items-center justify-between gap-2 shrink-0 z-30 select-none">
      {/* Zone 1: FL Studio Fruit Wordmark & Project Selector */}
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="relative">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#1e232e] hover:bg-[#282e3c] border border-[#2f3747] text-white transition-colors"
            title="Project Menu & Demo Tracks"
          >
            {/* Custom FL Fruit Icon */}
            <svg
              className="w-5 h-5 drop-shadow-[0_0_8px_rgba(255,119,0,0.5)]"
              viewBox="0 0 24 24"
              fill="none"
            >
              {/* Green leaf */}
              <path
                d="M12 2C13 4 15 5 18 4C17 7 15 8 13 8C13 6 12 4 12 2Z"
                fill="#00e676"
              />
              {/* Juicy Orange Tangerine Body */}
              <path
                d="M6 10C6 6.5 9 6.5 12 8C15 6.5 18 6.5 18 10C19 14.5 16 21 12 22C8 21 5 14.5 6 10Z"
                fill="url(#flOrangeGrad)"
              />
              <defs>
                <linearGradient id="flOrangeGrad" x1="6" y1="8" x2="18" y2="22">
                  <stop stopColor="#ff9100" />
                  <stop offset="0.6" stopColor="#ff6d00" />
                  <stop offset="1" stopColor="#e65100" />
                </linearGradient>
              </defs>
            </svg>
            <span className="font-bold text-xs tracking-wider text-slate-100 hidden sm:inline">
              FL STUDIO <span className="text-[#ff7700]">MOBILE</span>
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Project Dropdown Menu */}
          {menuOpen && (
            <div className="absolute left-0 top-full mt-2 w-64 bg-[#1a1f29] border border-[#2f3747] rounded-xl shadow-2xl py-2 z-50 text-xs">
              <div className="px-3 py-1.5 border-b border-[#282e3c]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Project Name:</span>
                  <button
                    onClick={() => {
                      setRenameOpen(true);
                      setMenuOpen(false);
                    }}
                    className="text-[#ff7700] hover:underline"
                  >
                    Rename
                  </button>
                </div>
                <p className="font-semibold text-slate-100 truncate text-sm mt-0.5">
                  {project.name}
                </p>
              </div>

              <div className="py-1">
                <div className="px-3 py-1 text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Demo Tracks
                </div>
                {DEMO_PROJECTS.map(demo => (
                  <button
                    key={demo.id}
                    onClick={() => {
                      onLoadProject(demo);
                      setMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-[#282e3c] flex items-center justify-between transition-colors ${
                      project.id === demo.id ? 'text-[#ff7700] font-semibold bg-[#232936]' : 'text-slate-300'
                    }`}
                  >
                    <span>{demo.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono tabular-nums">{demo.bpm} BPM</span>
                  </button>
                ))}
              </div>

              <div className="border-t border-[#282e3c] pt-1 mt-1">
                <button
                  onClick={() => {
                    const newProj: Project = {
                      id: `proj_${Date.now()}`,
                      name: 'New Beat',
                      bpm: 130,
                      timeSignature: [4, 4],
                      swing: 0,
                      masterVolume: 0.85,
                      loopStart: 0,
                      loopEnd: 16,
                      isLooping: true,
                      tracks: [
                        {
                          id: `trk_${Date.now()}_1`,
                          name: 'Drum Kit',
                          type: 'drums',
                          color: '#ff7700',
                          volume: 0.85,
                          pan: 0,
                          muted: false,
                          soloed: false,
                          synthConfig: DEMO_PROJECTS[0].tracks[0].synthConfig,
                          fx: DEMO_PROJECTS[0].tracks[0].fx,
                          clips: [
                            {
                              id: `clip_${Date.now()}`,
                              trackId: `trk_${Date.now()}_1`,
                              name: 'Drum Pattern 1',
                              startBeat: 0,
                              durationBeats: 4,
                              color: '#ff7700',
                              drumSteps: [
                                { step: 0, drum: 'kick', velocity: 1 },
                                { step: 4, drum: 'snare', velocity: 0.9 },
                                { step: 8, drum: 'kick', velocity: 1 },
                                { step: 12, drum: 'snare', velocity: 0.9 },
                              ],
                            },
                          ],
                        },
                      ],
                    };
                    onLoadProject(newProj);
                    setMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 text-slate-300 hover:bg-[#282e3c] flex items-center gap-2"
                >
                  <FilePlus className="w-3.5 h-3.5 text-slate-400" />
                  <span>New Empty Project</span>
                </button>

                <button
                  onClick={() => {
                    onOpenExportModal();
                    setMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 text-slate-200 hover:bg-[#282e3c] flex items-center gap-2"
                >
                  <Download className="w-3.5 h-3.5 text-[#00e676]" />
                  <span className="font-medium text-[#00e676]">Export Song to WAV</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Zone 2: Transport & Timeline Position */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Play / Record / Stop Controls */}
        <div className="flex items-center bg-[#1b202a] border border-[#2f3747] rounded-lg p-0.5">
          <button
            onClick={handlePlayToggle}
            className={`w-9 h-8 sm:w-10 sm:h-9 rounded-md flex items-center justify-center transition-all ${
              playhead.isPlaying && !playhead.isRecording
                ? 'bg-[#00e676] text-black shadow-lg shadow-[#00e676]/30'
                : 'text-slate-300 hover:text-white hover:bg-[#282e3c]'
            }`}
            title="Play / Pause (Spacebar)"
          >
            {playhead.isPlaying && !playhead.isRecording ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            onClick={handleRecordToggle}
            className={`w-9 h-8 sm:w-10 sm:h-9 rounded-md flex items-center justify-center transition-all ${
              playhead.isRecording
                ? 'bg-[#ff1744] text-white animate-pulse shadow-lg shadow-[#ff1744]/40'
                : 'text-red-400 hover:text-red-300 hover:bg-[#282e3c]'
            }`}
            title="Record Notes Live"
          >
            <Circle className={`w-3.5 h-3.5 ${playhead.isRecording ? 'fill-current' : 'fill-red-500'}`} />
          </button>

          <button
            onClick={handleStop}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-md flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#282e3c] transition-colors"
            title="Stop & Rewind"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
          </button>

          <button
            onClick={handleLoopToggle}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-md flex items-center justify-center transition-colors ${
              project.isLooping
                ? 'text-[#ff7700] bg-[#ff7700]/15'
                : 'text-slate-500 hover:text-slate-300 hover:bg-[#282e3c]'
            }`}
            title="Loop Playback"
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={toggleMetronome}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-md flex items-center justify-center text-xs font-mono font-bold transition-colors ${
              metronomeOn
                ? 'text-[#00e5ff] bg-[#00e5ff]/15'
                : 'text-slate-500 hover:text-slate-300 hover:bg-[#282e3c]'
            }`}
            title="Metronome Click"
          >
            CLICK
          </button>
        </div>

        {/* Bar & Beat Digital Display */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-[#101319] border border-[#242a36] rounded-lg font-mono tabular-nums">
          <span className="text-[10px] text-slate-500 tracking-wider">BAR</span>
          <span className="text-sm font-bold text-[#ff9100]">
            {String(playhead.bar).padStart(2, '0')}
          </span>
          <span className="text-slate-600">:</span>
          <span className="text-sm font-semibold text-slate-200">{playhead.beatInBar}</span>
          <span className="text-slate-600">:</span>
          <span className="text-xs text-slate-400">{playhead.sixteenth}</span>
        </div>

        {/* BPM & Tap */}
        <div className="flex items-center bg-[#1b202a] border border-[#2f3747] rounded-lg px-2 py-1 gap-1.5">
          <button
            onClick={handleTapTempo}
            className="px-1.5 py-0.5 rounded text-[10px] font-bold text-slate-400 hover:text-slate-100 bg-[#282e3c] active:bg-[#ff7700] active:text-black transition-colors"
            title="Tap Tempo"
          >
            TAP
          </button>
          <div className="flex items-center gap-1">
            <span className="font-mono text-xs font-bold text-slate-100 tabular-nums">
              {project.bpm}
            </span>
            <span className="text-[10px] text-slate-500 font-medium">BPM</span>
          </div>
          <div className="flex flex-col">
            <button
              onClick={() => handleBpmChange(1)}
              className="text-[9px] text-slate-400 hover:text-white leading-none px-0.5"
            >
              ▲
            </button>
            <button
              onClick={() => handleBpmChange(-1)}
              className="text-[9px] text-slate-400 hover:text-white leading-none px-0.5"
            >
              ▼
            </button>
          </div>
        </div>

        {/* Real-time Spectrum Analyzer */}
        <div className="hidden lg:flex items-center bg-[#101319] border border-[#242a36] rounded-lg px-2 py-1 h-9">
          <canvas ref={canvasRef} width={80} height={22} className="rounded" />
        </div>
      </div>

      {/* Zone 3: Workspace View Mode Tabs (FL Studio Signature) */}
      <div className="flex items-center gap-1 bg-[#1b202a] border border-[#2f3747] rounded-lg p-1">
        <button
          onClick={() => onViewChange('playlist')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-all ${
            activeView === 'playlist'
              ? 'bg-[#ff7700] text-black shadow-md'
              : 'text-slate-400 hover:text-slate-100 hover:bg-[#282e3c]'
          }`}
          title="Playlist Arranger"
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Playlist</span>
        </button>

        <button
          onClick={() => onViewChange('pianoroll')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-all ${
            activeView === 'pianoroll'
              ? 'bg-[#00e5ff] text-black shadow-md'
              : 'text-slate-400 hover:text-slate-100 hover:bg-[#282e3c]'
          }`}
          title="Piano Roll"
        >
          <Music className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Piano Roll</span>
        </button>

        <button
          onClick={() => onViewChange('stepseq')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-all ${
            activeView === 'stepseq'
              ? 'bg-[#ffca28] text-black shadow-md'
              : 'text-slate-400 hover:text-slate-100 hover:bg-[#282e3c]'
          }`}
          title="16-Step Drum Sequencer"
        >
          <Grid className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Drums</span>
        </button>

        <button
          onClick={() => onViewChange('play')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-all ${
            activeView === 'play'
              ? 'bg-[#e040fb] text-white shadow-md'
              : 'text-slate-400 hover:text-slate-100 hover:bg-[#282e3c]'
          }`}
          title="Touch Keyboard & MPC Pads"
        >
          <Radio className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Keyboard/Pads</span>
        </button>

        <button
          onClick={() => onViewChange('mixer')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-all ${
            activeView === 'mixer'
              ? 'bg-[#00e676] text-black shadow-md'
              : 'text-slate-400 hover:text-slate-100 hover:bg-[#282e3c]'
          }`}
          title="Mixer & FX Rack"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Mixer & FX</span>
        </button>
      </div>

      {/* Rename Dialog */}
      {renameOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1b202a] border border-[#2f3747] rounded-xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="text-sm font-bold text-white mb-3">Rename Project</h3>
            <input
              type="text"
              value={tempName}
              onChange={e => setTempName(e.target.value)}
              className="w-full bg-[#121418] border border-[#333b4d] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#ff7700]"
              autoFocus
            />
            <div className="flex items-center justify-end gap-2 mt-4">
              <button
                onClick={() => setRenameOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (tempName.trim()) {
                    onUpdateProject(p => ({ ...p, name: tempName.trim() }));
                  }
                  setRenameOpen(false);
                }}
                className="px-4 py-1.5 rounded-lg bg-[#ff7700] text-black font-semibold text-xs hover:bg-[#ff8800]"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
