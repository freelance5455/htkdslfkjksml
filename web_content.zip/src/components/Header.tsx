import React from 'react';
import {
  Timer,
  Lightbulb,
  Headphones,
  MessageCircle,
  User,
  ShieldCheck,
  LogIn,
} from 'lucide-react';
import { audioSynth } from '../services/audioSynth';
import { AuthUser } from './PhoneLoginModal';

interface HeaderProps {
  title: string;
  subtitle: string;
  onStartFocus: () => void;
  onOpenFeynman: () => void;
  onOpenSoundModal: () => void;
  onOpenWhatsApp: () => void;
  onOpenLogin: () => void;
  currentUser: AuthUser | null;
  isTimerRunning: boolean;
  timerMinutes: number;
  timerSeconds: number;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  onStartFocus,
  onOpenFeynman,
  onOpenSoundModal,
  onOpenWhatsApp,
  onOpenLogin,
  currentUser,
  isTimerRunning,
  timerMinutes,
  timerSeconds,
}) => {
  const currentSound = audioSynth.getCurrentTrack();

  return (
    <header className="h-16 md:h-18 px-3 sm:px-6 md:px-8 pr-14 md:pr-8 border-b border-slate-800/60 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between sticky top-0 z-20">
      <div className="flex items-center gap-2.5 min-w-0 flex-1 mr-2">
        <img
          src="/logo.png"
          alt="XITRES MIND"
          className="w-8 h-8 rounded-lg object-cover ring-1 ring-amber-400/40 md:hidden shrink-0"
        />
        <div className="min-w-0">
          <h2 className="text-base sm:text-lg md:text-xl font-black text-white tracking-tight flex items-center gap-2 truncate">
            <span className="font-cinzel text-sm sm:text-base md:text-lg gold-gradient-text tracking-wide truncate">
              {title}
            </span>
          </h2>
          <p className="text-[10px] sm:text-xs text-slate-400 truncate">{subtitle}</p>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
        {/* WhatsApp Contact Creator Trigger (hidden on mobile, in drawer) */}
        <button
          onClick={onOpenWhatsApp}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition group shadow-sm"
          title="Chat with @xitres_maker on WhatsApp"
        >
          <MessageCircle className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20 group-hover:scale-110 transition-transform" />
          <span className="hidden md:inline">WhatsApp</span>
          <span className="font-mono text-[10px] text-emerald-400 font-bold hidden lg:inline">@xitres_maker</span>
        </button>

        {/* Feynman Explainer Trigger (hidden on mobile, in drawer) */}
        <button
          onClick={onOpenFeynman}
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-violet-500/10 hover:bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold transition group shadow-sm"
        >
          <Lightbulb className="w-3.5 h-3.5 text-violet-400 group-hover:scale-110 transition-transform" />
          <span>Feynman</span>
        </button>

        {/* Ambient Soundscape Quick Button (hidden on mobile, in drawer) */}
        <button
          onClick={onOpenSoundModal}
          className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition ${
            currentSound
              ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Headphones className={`w-3.5 h-3.5 ${currentSound ? 'text-amber-400 animate-bounce' : ''}`} />
          <span className="hidden md:inline">{currentSound ? `Audio: ${currentSound}` : 'Sound'}</span>
        </button>

        {/* Quick Pomodoro Button (visible on all screens) */}
        <button
          onClick={onStartFocus}
          className={`flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition shadow-md ${
            isTimerRunning
              ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30'
              : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-amber-500/20'
          }`}
        >
          <Timer className={`w-3.5 h-3.5 ${isTimerRunning ? 'animate-spin' : ''}`} />
          <span>
            {isTimerRunning
              ? `${String(timerMinutes).padStart(2, '0')}:${String(timerSeconds).padStart(2, '0')}`
              : 'Focus 25m'}
          </span>
        </button>

        {/* Phone Login Profile Trigger */}
        <button
          onClick={onOpenLogin}
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition ${
            currentUser
              ? 'bg-slate-900 border-amber-500/40 text-amber-300'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
          }`}
          title={currentUser ? `Logged in: ${currentUser.phone}` : 'Sign In with Phone'}
        >
          {currentUser ? (
            <>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="max-w-[70px] truncate">{currentUser.name}</span>
            </>
          ) : (
            <>
              <LogIn className="w-3.5 h-3.5 text-amber-400" />
              <span>Login</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
