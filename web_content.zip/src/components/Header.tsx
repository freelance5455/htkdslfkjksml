import React from 'react';
import {
  Brain,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Flame,
  Zap,
  Gamepad2,
  Bot,
  BarChart3,
  Smartphone,
  SlidersHorizontal,
  Menu
} from 'lucide-react';
import { UserProfile } from '../types';
import { HeaderCustomization } from './RightOptionsBar';

interface HeaderProps {
  profile: UserProfile;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onToggleTheme: () => void;
  onOpenProfile: () => void;
  onOpenGame: () => void;
  onOpenChat: () => void;
  onOpenStreak: () => void;
  onOpenAnalytics: () => void;
  onOpenApkModal: () => void;
  onOpenOptions: () => void;
  headerConfig: HeaderCustomization;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  soundEnabled,
  onToggleSound,
  onToggleTheme,
  onOpenProfile,
  onOpenGame,
  onOpenChat,
  onOpenStreak,
  onOpenAnalytics,
  onOpenApkModal,
  onOpenOptions,
  headerConfig,
}) => {
  const avatarLetter = (profile.name?.charAt(0) || 'A').toUpperCase();

  return (
    <header className="bg-white/95 dark:bg-[#0f172a]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 safe-top shrink-0 transition-colors">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        
        {/* Left: Brand Identity & Subtitle (Clean, Unboxed) */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-[0_3px_0_0_#059669] shrink-0">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-slate-900 dark:text-white">
                Vocab<span className="text-emerald-500">Muse</span>
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium leading-none truncate max-w-[130px] sm:max-w-xs">
              By <span className="font-semibold text-slate-600 dark:text-slate-300">Md. Jahid Hasan</span> · SUST
            </p>
          </div>
        </div>

        {/* Right: Core Motivation Badges + User-Pinned Options + Right Bar Toggle */}
        <div className="flex items-center gap-1.5 sm:gap-2">

          {/* User-Pinned Quick Buttons (Adjustable from Right Bar) */}
          {headerConfig.showGame && (
            <button
              onClick={onOpenGame}
              className="p-2 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 hover:scale-105 active:scale-95 transition-all"
              title="Cadre Runner 3D"
              aria-label="3D Game"
            >
              <Gamepad2 className="w-4 h-4" />
            </button>
          )}

          {headerConfig.showChat && (
            <button
              onClick={onOpenChat}
              className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 hover:scale-105 active:scale-95 transition-all"
              title="Professor Cadre AI"
              aria-label="AI Chat"
            >
              <Bot className="w-4 h-4" />
            </button>
          )}

          {headerConfig.showAnalytics && (
            <button
              onClick={onOpenAnalytics}
              className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 hover:scale-105 active:scale-95 transition-all"
              title="Mastery Analytics"
              aria-label="Analytics"
            >
              <BarChart3 className="w-4 h-4" />
            </button>
          )}

          {headerConfig.showApk && (
            <button
              onClick={onOpenApkModal}
              className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:scale-105 active:scale-95 transition-all"
              title="Download Android APK"
              aria-label="Android APK"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          )}

          {headerConfig.showSound && (
            <button
              onClick={onToggleSound}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-emerald-400 hover:scale-105 active:scale-95 transition-all"
              title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
              aria-label="Toggle Sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
            </button>
          )}

          {headerConfig.showTheme && (
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-amber-400 hover:scale-105 active:scale-95 transition-all"
              title="Toggle Theme"
              aria-label="Toggle Theme"
            >
              {profile.theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          )}

          {/* Interactive Daily Streak Counter */}
          <button
            onClick={onOpenStreak}
            className="group relative flex items-center gap-1.5 bg-gradient-to-r from-amber-500/10 via-orange-500/15 to-amber-500/20 dark:from-amber-950/70 dark:via-orange-950/60 dark:to-amber-950/70 border border-amber-300 dark:border-amber-700/80 px-2 sm:px-2.5 py-1 rounded-xl text-amber-700 dark:text-amber-300 font-black text-xs hover:scale-105 active:scale-95 transition-all shadow-xs hover:shadow-orange-400/20 cursor-pointer"
            title={`${profile.streak} Day Study Streak • Click to view calendar and celebratory animation`}
            aria-label="Streak Counter"
          >
            <div className="relative flex items-center justify-center">
              <span className="absolute -inset-1 rounded-full bg-orange-400/30 blur-xs group-hover:bg-orange-400/50 animate-pulse transition-all" />
              <Flame className="w-3.5 h-3.5 fill-amber-500 text-orange-600 relative z-10 transition-transform group-hover:scale-110 group-active:rotate-12 animate-[bounce_2s_infinite]" />
            </div>
            <span className="font-black text-xs tracking-tight text-orange-700 dark:text-orange-300">
              {profile.streak}
            </span>
            {(profile.streakFreezes ?? 0) > 0 && (
              <span
                className="hidden xs:inline-flex items-center text-[10px] text-cyan-700 dark:text-cyan-300 font-semibold pl-1 border-l border-amber-300/80 dark:border-amber-700/60"
                title={`${profile.streakFreezes} Streak Freeze(s) armed`}
              >
                <span className="text-[9px] mr-0.5">🛡️</span>
                {profile.streakFreezes}
              </span>
            )}
          </button>

          {/* Experience Points Counter */}
          <div
            className="flex items-center gap-1 bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800/80 px-2 py-1 rounded-xl text-blue-600 dark:text-blue-400 font-extrabold text-xs"
            title={`${profile.xp} Experience Points`}
          >
            <Zap className="w-3.5 h-3.5 fill-current text-blue-500" />
            <span>{profile.xp}</span>
          </div>

          {/* Right Toggle Button: Opens the Slide-Over Options Bar */}
          <button
            onClick={onOpenOptions}
            className="flex items-center gap-1.5 p-1 pl-2 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-all cursor-pointer group active:scale-95 shadow-xs"
            title="Open Quick Tools & Options Bar"
            aria-label="Open Options Menu"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 group-hover:text-emerald-500 transition-colors" />
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white font-black text-xs flex items-center justify-center shadow-xs">
              {avatarLetter}
            </div>
          </button>

        </div>

      </div>
    </header>
  );
};
