import React from 'react';
import { Feather, Sparkles, Volume2, Bot, RotateCcw, Share2, Check, BookOpen } from 'lucide-react';

interface HeaderProps {
  onReset: () => void;
  onCopyStory: () => void;
  copied: boolean;
  hasStory: boolean;
  onToggleChat: () => void;
  chatOpen: boolean;
  hasAudio: boolean;
  onDownloadStory: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onReset,
  onCopyStory,
  copied,
  hasStory,
  onToggleChat,
  chatOpen,
  hasAudio,
  onDownloadStory,
}) => {
  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-stone-950/85 border-b border-stone-800/80 px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 via-amber-600/10 to-stone-900 border border-amber-500/30 shadow-lg shadow-amber-950/20">
            <Feather className="w-5 h-5 text-amber-400" />
            <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display text-lg tracking-wider font-bold text-stone-100 flex items-center gap-1.5">
                AETHERIA
                <span className="text-amber-400/80 text-xs px-2 py-0.5 rounded-full border border-amber-500/30 bg-amber-500/10 font-sans font-medium">
                  Studio
                </span>
              </h1>
            </div>
            <p className="text-xs text-stone-400 font-sans hidden sm:block">
              Vision-to-Prose Ghostwriter & Expressive Voice Narration
            </p>
          </div>
        </div>

        {/* Model Chips */}
        <div className="hidden md:flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-stone-300">
            <Sparkles className="w-3 h-3 text-amber-400" />
            Vision: <strong className="text-amber-300 font-medium">gemini-4-argon</strong>
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-stone-300">
            <Volume2 className="w-3 h-3 text-emerald-400" />
            Voice: <strong className="text-emerald-300 font-medium">gemini-3.8-flash-tts</strong>
          </span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {hasStory && (
            <>
              <button
                onClick={onCopyStory}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700/60 transition-all active:scale-95"
                title="Copy opening paragraph to clipboard"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5 text-stone-400" />
                    <span className="hidden sm:inline">Copy Text</span>
                  </>
                )}
              </button>

              <button
                onClick={onDownloadStory}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700/60 transition-all active:scale-95"
                title="Download story as Markdown"
              >
                <BookOpen className="w-3.5 h-3.5 text-stone-400" />
                <span className="hidden sm:inline">Export MD</span>
              </button>
            </>
          )}

          <button
            onClick={onToggleChat}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95 border ${
              chatOpen
                ? 'bg-amber-500/20 text-amber-200 border-amber-500/50 shadow-sm shadow-amber-500/20'
                : 'bg-stone-900 hover:bg-stone-800 text-stone-300 border-stone-700/60'
            }`}
            title="Toggle Ghostwriter Co-Author Chat"
          >
            <Bot className="w-3.5 h-3.5 text-amber-400" />
            <span>Co-Author</span>
          </button>

          {hasStory && (
            <button
              onClick={onReset}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-stone-400 hover:text-stone-200 hover:bg-stone-800/80 transition-all"
              title="Start a new world with another image"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
