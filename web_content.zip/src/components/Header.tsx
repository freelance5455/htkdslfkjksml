import React from 'react';
import { Maximize2, Minimize2, Moon, Sparkles } from 'lucide-react';
import { DarkModeType, themeService } from '../utils/theme';
import { soundService } from '../utils/sound';

interface HeaderProps {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  darkMode: DarkModeType;
  onToggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isFullscreen,
  onToggleFullscreen,
  activeTab,
  onSelectTab,
  darkMode,
  onToggleDarkMode,
}) => {
  const isOled = darkMode === 'oled-true-black';

  return (
    <header
      className={`flex items-center justify-between gap-6 px-4 sm:px-8 py-3.5 border-b sticky top-0 z-30 transition-colors ${
        isOled
          ? 'bg-black/95 border-neutral-900 backdrop-blur-md'
          : 'bg-[#070b14]/95 border-slate-800/80 backdrop-blur-md'
      }`}
    >
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2.5 shrink-0">
        <span
          className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_10px_#00F0FF]"
          aria-hidden="true"
        />
        <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
          NeonBeam
        </span>
      </div>

      {/* Zone 2: Navigation links, single-line text links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => {
            soundService.playTick();
            onSelectTab('main');
          }}
          className={`hover:text-white transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'main' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Hlavní svítilna
        </button>
        <button
          onClick={() => {
            soundService.playTick();
            onSelectTab('screen');
          }}
          className={`hover:text-white transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'screen' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Světlo displeje
        </button>
        <button
          onClick={() => {
            soundService.playTick();
            onSelectTab('strobe');
          }}
          className={`hover:text-white transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'strobe' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Stroboskop & SOS
        </button>
        <button
          onClick={() => {
            soundService.playTick();
            onSelectTab('hazard');
          }}
          className={`hover:text-white transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'hazard' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Výstražný maják
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => {
            soundService.playTick();
            onToggleDarkMode();
          }}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
            isOled
              ? 'bg-neutral-950 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.2)]'
              : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
          }`}
          title={isOled ? 'Aktivní: OLED True Black (Pixely vypnuté)' : 'Přepnout na OLED True Black'}
          aria-label="Přepnout OLED režim"
        >
          <Moon className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">
            {isOled ? 'OLED Black' : 'Cyber Slate'}
          </span>
          {isOled && (
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => {
            soundService.playTick();
            onToggleFullscreen();
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
            isOled
              ? 'bg-neutral-950 border-neutral-800 text-slate-200 hover:text-white'
              : 'bg-slate-900 border-slate-700/80 text-slate-200 hover:text-white'
          }`}
          title={isFullscreen ? 'Zmenšit' : 'Celá obrazovka'}
          aria-label={isFullscreen ? 'Zmenšit' : 'Celá obrazovka'}
        >
          {isFullscreen ? (
            <>
              <Minimize2 className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Zmenšit</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Full-screen</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
