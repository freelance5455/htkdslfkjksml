import React from 'react';
import { Plus } from 'lucide-react';
import { NavTab } from './BottomNavBar';

interface HeaderProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onQuickAdd: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onQuickAdd,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-900">
      <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-emerald-400 flex items-center justify-center text-slate-950 font-black text-sm">
            P
          </div>
          <span className="text-base font-bold text-white tracking-tight">
            PoketSafe
          </span>
        </div>

        {/* Desktop / Tablet Nav Links (hidden on mobile since bottom nav is active) */}
        <nav className="hidden sm:flex items-center gap-5 text-xs font-medium text-slate-400">
          <button
            onClick={() => onSelectTab('home')}
            className={`transition-colors ${activeTab === 'home' ? 'text-emerald-400 font-bold' : 'hover:text-white'}`}
          >
            Home
          </button>
          <button
            onClick={() => onSelectTab('transactions')}
            className={`transition-colors ${activeTab === 'transactions' ? 'text-emerald-400 font-bold' : 'hover:text-white'}`}
          >
            Transactions
          </button>
          <button
            onClick={() => onSelectTab('payments')}
            className={`transition-colors ${activeTab === 'payments' ? 'text-emerald-400 font-bold' : 'hover:text-white'}`}
          >
            Payments
          </button>
          <button
            onClick={() => onSelectTab('savings')}
            className={`transition-colors ${activeTab === 'savings' ? 'text-emerald-400 font-bold' : 'hover:text-white'}`}
          >
            Savings
          </button>
          <button
            onClick={() => onSelectTab('profile')}
            className={`transition-colors ${activeTab === 'profile' ? 'text-emerald-400 font-bold' : 'hover:text-white'}`}
          >
            Profile
          </button>
        </nav>

        {/* Quick Add CTA */}
        <button
          onClick={onQuickAdd}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-sm"
        >
          <Plus className="w-3.5 h-3.5 stroke-[3]" />
          <span>Add</span>
        </button>
      </div>
    </header>
  );
};
