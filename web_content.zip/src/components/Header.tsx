import React from 'react';
import { Database, User, Sun, Moon, ArrowLeft } from 'lucide-react';
import { useClimbing } from '../context/ClimbingContext';

export type ActiveTab = 'dashboard' | 'log' | 'checklist' | 'history' | 'centres' | 'profile';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenExportImport: () => void;
  candidateLevel: number;
  candidateName: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onOpenExportImport,
  candidateLevel,
  candidateName
}) => {
  const { theme, toggleTheme } = useClimbing();
  const isDark = theme === 'dark';

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200 dark:border-slate-800 w-full max-w-full transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 sm:gap-6 h-14 sm:h-16">
          {/* Zone 1: Wordmark & In-App Back Button */}
          <div className="flex items-center gap-2 shrink-0">
            {activeTab !== 'dashboard' && (
              <button
                type="button"
                onClick={() => onSelectTab('dashboard')}
                className="flex items-center gap-1 px-2 py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                title="Go back to Dashboard"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Back</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => onSelectTab('dashboard')}
              className="text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap text-left hover:text-orange-600 transition-colors flex items-center gap-2"
            >
              <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-orange-600 text-white flex items-center justify-center font-extrabold text-xs sm:text-sm tracking-wider shadow-xs">
                N
              </span>
              <span>NICAS</span>
            </button>
            <span className="hidden sm:inline-block text-[11px] font-mono text-orange-800 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/60 border border-orange-200 dark:border-orange-800 px-2 py-0.5 rounded">
              Level {candidateLevel} {candidateName ? `· ${candidateName}` : ''}
            </span>
          </div>

          {/* Zone 2: Navigation Links for Desktop */}
          <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => onSelectTab('dashboard')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'dashboard' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              Dashboard
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('log')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'log' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              Log Climb
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('checklist')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'checklist' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              Checklist
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('history')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'history' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              History
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('centres')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'centres' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              Centres
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('profile')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'profile' ? 'text-orange-600 dark:text-orange-400 font-bold border-b-2 border-orange-600' : ''
              }`}
            >
              Profile
            </button>
          </nav>

          {/* Zone 3: Actions (Theme Toggle & PDF/Backup) */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDark ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>

            <button
              type="button"
              onClick={() => onSelectTab('profile')}
              aria-label="Climber Profile"
              className={`p-2 rounded-lg border text-xs font-semibold md:hidden transition-colors ${
                activeTab === 'profile'
                  ? 'bg-orange-50 dark:bg-orange-950 border-orange-300 dark:border-orange-800 text-orange-700 dark:text-orange-400'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              <User className="w-4 h-4 text-orange-600" />
            </button>

            <button
              type="button"
              onClick={onOpenExportImport}
              className="px-2.5 sm:px-3.5 py-1.5 sm:py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Database className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PDF & Backup</span>
              <span className="sm:hidden">Reports</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Scrollbar */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto py-1.5 border-t border-slate-100 dark:border-slate-800 text-xs no-scrollbar">
          <button
            type="button"
            onClick={() => onSelectTab('dashboard')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'dashboard' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            Dashboard
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('log')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'log' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            Log Climb
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('checklist')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'checklist' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            Checklist
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('history')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'history' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            History
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('centres')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'centres' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            Centres
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('profile')}
            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium text-[11px] ${
              activeTab === 'profile' ? 'bg-orange-600 text-white' : 'text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800'
            }`}
          >
            Profile
          </button>
        </div>
      </div>
    </header>
  );
};
