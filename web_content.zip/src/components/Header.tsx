import React from 'react';
import { Flame, Bell, Moon, Sun, Plus, Sparkles, Settings } from 'lucide-react';
import { UserProfile } from '../types';
import { playChimeSound, requestNotificationPermission, sendLocalNotification } from '../utils/notifications';

interface HeaderProps {
  profile: UserProfile;
  dayNumber: number;
  streak: number;
  activeDateStr: string;
  onOpenAddModal: () => void;
  onOpenSettings: () => void;
  onToggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  dayNumber,
  streak,
  activeDateStr,
  onOpenAddModal,
  onOpenSettings,
  onToggleDarkMode,
}) => {
  const handleTestNotification = async () => {
    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      sendLocalNotification('GlowUp 90 Reminder', {
        body: 'Time for your next scheduled glow-up habit! Stay consistent.',
      });
    } else {
      playChimeSound('reminder');
    }
  };

  const formattedDate = new Date(activeDateStr + 'T00:00:00').toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header className="sticky top-0 z-30 bg-white/85 dark:bg-[#0B0C10]/90 backdrop-blur-md border-b border-slate-100 dark:border-slate-800/80 px-3 sm:px-4 py-2.5 transition-colors">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Brand & Day Tracker */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-700 dark:from-purple-600 dark:to-blue-600 flex items-center justify-center text-white shadow-sm shrink-0">
            <Sparkles className="w-4 h-4 text-purple-300 dark:text-white" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-nowrap">
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
                GlowUp 90
              </h1>
              <span className="text-[10px] sm:text-xs font-semibold px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-100 dark:border-purple-800/50 tabular-nums shrink-0">
                Day {dayNumber}/90
              </span>
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5 whitespace-nowrap">
              <span className="truncate">{formattedDate}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-0.5 text-amber-600 dark:text-amber-400 font-medium shrink-0">
                <Flame className="w-3 h-3 fill-amber-500 text-amber-500" />
                <span className="tabular-nums">{streak}d</span> streak
              </span>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Add Activity Button */}
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-medium rounded-xl transition-all shadow-sm active:scale-95"
            aria-label="Add custom habit activity"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add Habit</span>
            <span className="inline sm:hidden">Add</span>
          </button>

          {/* Test reminder / notification bell */}
          <button
            onClick={handleTestNotification}
            title="Test reminder chime & notifications"
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Test reminder notification"
          >
            <Bell className="w-3.5 h-3.5" />
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={onToggleDarkMode}
            title={profile.darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle color theme"
          >
            {profile.darkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
          </button>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            title="Open settings"
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Open settings"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
