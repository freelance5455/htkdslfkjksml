import React from 'react';
import { Sparkles, Mic, Music, ScrollText, Compass, Edit3, Film, Radio } from 'lucide-react';

interface HeaderProps {
  activeTab: 'director' | 'tts' | 'music' | 'prompter' | 'compass' | 'editor';
  setActiveTab: (tab: 'director' | 'tts' | 'music' | 'prompter' | 'compass' | 'editor') => void;
  isGeneratingAny: boolean;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, isGeneratingAny }) => {
  const tabs = [
    { id: 'director', labelBn: 'দৃশ্য ও স্টুডিও', labelEn: 'Scenes & Director', icon: Film },
    { id: 'tts', labelBn: 'Gemini 3.8 TTS', labelEn: 'Voiceover Studio', icon: Mic, highlight: true },
    { id: 'music', labelBn: 'Lyria মিউজিক', labelEn: 'Music Generator', icon: Music, highlight: true },
    { id: 'prompter', labelBn: 'টেলিপম্পটার', labelEn: 'Teleprompter', icon: ScrollText },
    { id: 'compass', labelBn: 'স্কিল কম্পাস', labelEn: '2027 Career Compass', icon: Compass },
    { id: 'editor', labelBn: 'স্ক্রিপ্ট এডিটর', labelEn: 'Script Editor', icon: Edit3 },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-bold">
              <Sparkles className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-heading font-extrabold text-lg sm:text-xl text-white tracking-tight">
                  Skill<span className="text-emerald-400">2027</span>
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/80">
                  AI Creator Suite
                </span>
              </div>
              <p className="text-xs text-slate-400 font-bengali truncate max-w-[200px] sm:max-w-xs">
                শীর্ষ ৫ ইন-ডিমান্ড স্কিল ভিডিও ও অডিও স্টুডিও
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-1 scrollbar-none flex-shrink min-w-0" aria-label="Main Navigation">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1 sm:gap-2 px-2.5 py-1.5 sm:px-3.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer flex-shrink-0 ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-900/40'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                  aria-label={tab.labelEn}
                >
                  <Icon className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isActive ? 'text-white' : tab.highlight ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span className="font-bengali text-xs sm:text-sm">{tab.labelBn}</span>
                  {tab.highlight && !isActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Status Indicator */}
          <div className="hidden lg:flex items-center gap-2">
            {isGeneratingAny ? (
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono">
                <Radio className="w-3.5 h-3.5 animate-spin text-amber-400" />
                <span>AI Processing...</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Studio Ready</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
