import PoliceIcon from './PoliceIcon';

const Header = ({ onSearchOpen }: { onSearchOpen: () => void }) => (
  <header className="site-header">
    <div className="header-title"><span>UK POLICE</span><strong>Operational Knowledge Base</strong></div>
    <div className="header-actions">
      <button onClick={onSearchOpen}><PoliceIcon name="search" className="h-5 w-5" /><span>Search</span><kbd>Ctrl K</kbd></button>
      <button onClick={() => window.print()}><PoliceIcon name="print" className="h-5 w-5" /><span>Print page</span></button>
    </div>
  </header>
);

export default Header;