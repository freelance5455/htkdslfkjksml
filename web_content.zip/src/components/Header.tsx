import React, { useState } from 'react';
import { 
  GraduationCap, 
  Globe, 
  Search, 
  Upload, 
  Bell, 
  MessageSquare, 
  User as UserIcon, 
  ShieldCheck, 
  LogOut, 
  Sparkles,
  ChevronDown,
  Menu,
  X,
  CheckCircle2
} from 'lucide-react';
import { Language, User, UserRole, Notification } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  currentUser: User;
  onRoleChange: (role: UserRole) => void;
  onOpenUpload: () => void;
  onOpenAuth: () => void;
  onOpenMessages: () => void;
  notifications: Notification[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onAiSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  currentUser,
  onRoleChange,
  onOpenUpload,
  onOpenAuth,
  onOpenMessages,
  notifications,
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  onAiSearch
}) => {
  const t = TRANSLATIONS[language];
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.isRead).length;

  const rolesList: { role: UserRole; label: string }[] = [
    { role: 'STUDENT', label: t.roleStudent },
    { role: 'TEACHER', label: t.roleTeacher },
    { role: 'MODERATOR', label: t.roleModerator },
    { role: 'ADMIN', label: t.roleAdmin },
    { role: 'SUPER_ADMIN', label: t.roleSuperAdmin }
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('papers')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 bg-clip-text text-transparent">
                  LankaPaperHub
                </span>
                <span className="hidden sm:inline-block text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  🇱🇰 Sri Lanka
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                {language === 'EN' ? 'National Educational Repository' : 'ජාතික අධ්‍යාපනික ප්‍රශ්න පත්‍ර එකතුව'}
              </p>
            </div>
          </div>

          {/* Center Search Input */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-slate-800/80 text-sm text-slate-100 placeholder-slate-400 pl-10 pr-24 py-2 rounded-xl border border-slate-700/80 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <button
              onClick={onAiSearch}
              className="absolute right-1.5 top-1.5 px-2.5 py-1 text-xs font-medium bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-lg flex items-center gap-1 shadow-sm transition-all cursor-pointer"
              title="AI Search Parser"
            >
              <Sparkles className="w-3 h-3" />
              <span>AI Search</span>
            </button>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Language Switcher */}
            <div className="flex items-center bg-slate-800 rounded-lg p-1 border border-slate-700">
              <button
                onClick={() => onLanguageChange('EN')}
                className={`px-2 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  language === 'EN'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => onLanguageChange('SI')}
                className={`px-2 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  language === 'SI'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                සිංහල
              </button>
            </div>

            {/* Upload Button */}
            <button
              onClick={onOpenUpload}
              className="hidden lg:flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 transition-all shadow-md shadow-amber-500/10 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{t.uploadBtn}</span>
            </button>

            {/* Notifications Button */}
            <div className="relative">
              <button
                onClick={() => setShowNotifDropdown(!showNotifDropdown)}
                className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl relative transition-all cursor-pointer"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifs > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 text-[10px] bg-red-500 text-white font-bold rounded-full flex items-center justify-center animate-pulse">
                    {unreadNotifs}
                  </span>
                )}
              </button>

              {/* Notifications Popover */}
              {showNotifDropdown && (
                <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-4 z-50">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Bell className="w-4 h-4 text-amber-400" />
                      <span>Notifications</span>
                    </h4>
                    <span className="text-xs text-amber-400 font-medium">
                      {notifications.length} total
                    </span>
                  </div>
                  <div className="divide-y divide-slate-800 max-h-64 overflow-y-auto my-2">
                    {notifications.map((n) => (
                      <div key={n.id} className="py-2.5 px-1 hover:bg-slate-800/50 rounded-lg transition-colors">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold text-amber-300">{n.title}</p>
                          <span className="text-[10px] text-slate-500">Just now</span>
                        </div>
                        <p className="text-xs text-slate-300 mt-0.5">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Messages Button */}
            <button
              onClick={onOpenMessages}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl relative transition-all cursor-pointer"
              aria-label="Messages"
            >
              <MessageSquare className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full"></span>
            </button>

            {/* User Profile & Role Switcher */}
            <div className="relative">
              <button
                onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition-all cursor-pointer"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-lg object-cover ring-2 ring-amber-500/40"
                />
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-bold text-slate-100 line-clamp-1">{currentUser.name}</p>
                  <p className="text-[10px] font-semibold text-amber-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>{currentUser.role}</span>
                  </p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {/* Role Switcher Menu */}
              {showRoleDropdown && (
                <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-2 z-50">
                  <div className="px-3 py-2 border-b border-slate-800">
                    <p className="text-xs text-slate-400">Testing Switch Role</p>
                    <p className="text-xs font-bold text-amber-400">{currentUser.name}</p>
                  </div>
                  <div className="py-1">
                    {rolesList.map((r) => (
                      <button
                        key={r.role}
                        onClick={() => {
                          onRoleChange(r.role);
                          setShowRoleDropdown(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 text-xs rounded-lg flex items-center justify-between transition-all cursor-pointer ${
                          currentUser.role === r.role
                            ? 'bg-amber-500/20 text-amber-300 font-bold'
                            : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span>{r.label} ({r.role})</span>
                        {currentUser.role === r.role && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    ))}
                  </div>
                  <div className="pt-2 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setShowRoleDropdown(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2 cursor-pointer"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                      <span>View Full Profile</span>
                    </button>
                    <button
                      onClick={onOpenAuth}
                      className="w-full text-left px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/10 rounded-lg flex items-center gap-2 mt-1 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Switch Account / Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Menu Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 py-3 space-y-3">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-slate-800 text-xs text-white placeholder-slate-400 pl-8 pr-16 py-2 rounded-xl border border-slate-700"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => {
                onOpenUpload();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{t.uploadBtn}</span>
            </button>
            <button
              onClick={() => {
                onAiSearch();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2 bg-slate-800 text-amber-400 border border-amber-500/40 font-bold text-xs rounded-xl flex items-center justify-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI Search</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
