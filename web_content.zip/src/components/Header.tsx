import React, { useRef, useEffect } from 'react';
import { Volume2, VolumeX, Music, Settings } from 'lucide-react';
import { useAudio } from '../context/GameContext';

interface HeaderProps {
  openSettings: () => void;
}

export const Header = React.memo(function Header({ openSettings }: HeaderProps) {
  const { soundEnabled, setSoundEnabled, musicEnabled, toggleMusic } = useAudio();
  const headerRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;

    const preventPull = (e: TouchEvent) => {
      if (e.cancelable) {
        e.preventDefault();
      }
    };

    const handleTouchStart = (e: TouchEvent) => {
      // Prevent multi-touch gesture from starting on header
      if (e.touches.length > 1 && e.cancelable) {
        e.preventDefault();
      }
    };

    el.addEventListener('touchmove', preventPull, { passive: false, capture: true });
    el.addEventListener('touchstart', handleTouchStart, { passive: false, capture: true });
    return () => {
      el.removeEventListener('touchmove', preventPull, { capture: true });
      el.removeEventListener('touchstart', handleTouchStart, { capture: true });
    };
  }, []);

  return (
    <header
      ref={headerRef}
      className="sticky top-0 z-50 bg-slate-950 border-b border-amber-900/30 px-3 sm:px-6 h-[52px] flex items-center shadow-md select-none touch-none"
      style={{
        backgroundColor: '#020617',
        transform: 'translate3d(0, 0, 0)',
        WebkitTransform: 'translate3d(0, 0, 0)',
        backfaceVisibility: 'hidden',
        WebkitBackfaceVisibility: 'hidden',
        contain: 'paint',
        touchAction: 'none',
        overscrollBehavior: 'none',
        overscrollBehaviorY: 'none',
      }}
    >
      <div className="flex items-center justify-between w-full max-w-6xl mx-auto gap-2 sm:gap-4">
        <h1 className="font-cinzel text-lg min-[380px]:text-xl sm:text-2xl md:text-[1.65rem] font-bold tracking-wide sm:tracking-wider text-amber-300 [text-shadow:0_1px_2px_rgba(0,0,0,0.85)] select-none whitespace-nowrap leading-none shrink-0">
          Mana Clicker-IdleRPG
        </h1>

        <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800 shrink-0">
          <button
            onClick={toggleMusic}
            title={musicEnabled ? 'Fantasy Theme Music: Playing (Click to Mute)' : 'Fantasy Theme Music: Muted (Click to Play)'}
            aria-label={musicEnabled ? 'Mute Fantasy Theme Music' : 'Play Fantasy Theme Music'}
            className={`flex items-center gap-1.5 px-2 py-1 rounded-lg transition-colors cursor-pointer border ${
              musicEnabled
                ? 'border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                : 'border-slate-800 bg-slate-900/50 text-slate-500 hover:text-slate-400 hover:bg-slate-900'
            }`}
          >
            {musicEnabled ? (
              <div className="flex items-end gap-[2px] h-3.5 w-3.5 pb-0.5" aria-hidden="true">
                <span className="w-1 bg-amber-400 rounded-sm animate-pulse h-3" />
                <span className="w-1 bg-amber-300 rounded-sm animate-pulse h-2" />
                <span className="w-1 bg-amber-400 rounded-sm animate-pulse h-3.5" />
              </div>
            ) : (
              <Music className="w-3.5 h-3.5" />
            )}
            <span className="text-[11px] font-semibold hidden md:inline">
              {musicEnabled ? 'Music On' : 'Music Off'}
            </span>
          </button>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'Mute Sound Effects' : 'Unmute Sound Effects'}
            aria-label={soundEnabled ? 'Mute Sound Effects' : 'Unmute Sound Effects'}
            className="p-1.5 text-slate-400 hover:text-amber-300 hover:bg-slate-900 rounded-lg transition-colors cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
          <button
            onClick={openSettings}
            title="Realm Settings"
            aria-label="Realm Settings"
            className="p-1.5 text-slate-400 hover:text-amber-300 hover:bg-slate-900 rounded-lg transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
});
