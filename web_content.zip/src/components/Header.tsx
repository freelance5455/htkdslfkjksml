import React from 'react';
import { ShieldCheck, MessageCircle, Phone, Printer } from 'lucide-react';

interface HeaderProps {
  onOpenPrintSlip: () => void;
  hasRecords: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onOpenPrintSlip, hasRecords }) => {
  return (
    <header className="w-full bg-[#087d3e] text-white shadow-md border-b border-[#066a34]">
      <div className="max-w-6xl mx-auto px-4 py-4 sm:py-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Brand Area */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center border border-white/25 shadow-inner shrink-0">
            <ShieldCheck className="w-7 h-7 text-emerald-100" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                JazzCash CNIC Checker
              </h1>
              <span className="text-[11px] font-semibold bg-emerald-950/40 text-emerald-200 px-2 py-0.5 rounded border border-emerald-400/30">
                v2.4 Pro
              </span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-100/90 font-medium mt-0.5">
              CNIC Verification & Report System · NADRA Format Compliant
            </p>
          </div>
        </div>

        {/* Action Affordances */}
        <div className="flex items-center flex-wrap gap-2.5">
          {hasRecords && (
            <button
              onClick={onOpenPrintSlip}
              className="px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors flex items-center gap-1.5 border border-white/20 shadow-sm"
              title="Print official verification summary slip"
            >
              <Printer className="w-4 h-4 text-emerald-200" />
              <span>Print Slip</span>
            </button>
          )}

          <a
            href="https://wa.me/923333997576?text=Hello%20JazzCash%20CNIC%20Checker%20Support%2C%20I%20need%20assistance%20with%20batch%20verification."
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-2 text-xs sm:text-sm font-bold rounded-lg bg-[#159b50] hover:bg-[#128846] text-white transition-all flex items-center gap-2 shadow-sm border border-emerald-400/40 hover:scale-[1.02] active:scale-[0.98]"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>WhatsApp: 03333997576</span>
          </a>
        </div>
      </div>
    </header>
  );
};
