import React from 'react';
import { 
  ShoppingCart, 
  ReceiptText, 
  Package, 
  BarChart3, 
  BookOpen, 
  ShieldCheck, 
  UserCheck, 
  Cloud, 
  Database, 
  Settings,
  ShoppingBag,
  Plus
} from 'lucide-react';
import { UserRole, StoreProfile } from '../types';

interface HeaderProps {
  activeTab: 'pos' | 'invoices' | 'inventory' | 'dashboard' | 'duebook';
  setActiveTab: (tab: 'pos' | 'invoices' | 'inventory' | 'dashboard' | 'duebook') => void;
  cartCount: number;
  openMobileCart: () => void;
  activeRole: UserRole;
  onSwitchRole: () => void;
  onOpenSettings: () => void;
  onOpenAddProduct: () => void;
  storeProfile: StoreProfile;
  lowStockCount: number;
  isFirebaseConfigured: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  openMobileCart,
  activeRole,
  onSwitchRole,
  onOpenSettings,
  onOpenAddProduct,
  storeProfile,
  lowStockCount,
  isFirebaseConfigured,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-emerald-800 text-white shadow-md border-b border-emerald-900 no-print">
      {/* Top Banner with Store Name and Quick Status */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Store Wordmark & Offline Indicator */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20 text-emerald-200 shadow-inner">
              <ShoppingBag className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg leading-tight tracking-tight text-white">
                  {storeProfile.name || 'মুদির দোকানদার'}
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-200 border border-emerald-700/50">
                  <Database className="w-3 h-3 text-emerald-400" />
                  অফলাইন সুরক্ষিত
                </span>
                {isFirebaseConfigured && (
                  <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-blue-900/60 text-blue-200 border border-blue-700/50">
                    <Cloud className="w-3 h-3 text-blue-300" />
                    ক্লাউড সিঙ্ক
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-200/80 truncate max-w-[200px] sm:max-w-xs">
                {storeProfile.tagline || 'স্মার্ট ক্যাশ মেমো ও হিসাব'}
              </p>
            </div>
          </div>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => setActiveTab('pos')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'pos'
                  ? 'bg-emerald-900 text-white shadow-sm'
                  : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white'
              }`}
            >
              <ShoppingCart className="w-4 h-4 text-emerald-300" />
              <span>দ্রুত বিক্রয় (POS)</span>
            </button>

            <button
              onClick={() => setActiveTab('invoices')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'invoices'
                  ? 'bg-emerald-900 text-white shadow-sm'
                  : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white'
              }`}
            >
              <ReceiptText className="w-4 h-4 text-emerald-300" />
              <span>মেমো ও ইনভয়েস</span>
            </button>

            <button
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors relative ${
                activeTab === 'inventory'
                  ? 'bg-emerald-900 text-white shadow-sm'
                  : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white'
              }`}
            >
              <Package className="w-4 h-4 text-emerald-300" />
              <span>পণ্য ও স্টক</span>
              {lowStockCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[10px] font-bold bg-amber-500 text-slate-900 rounded-full animate-bounce">
                  {lowStockCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'dashboard'
                  ? 'bg-emerald-900 text-white shadow-sm'
                  : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-emerald-300" />
              <span>লাভ-ক্ষতি ও রিপোর্ট</span>
            </button>

            <button
              onClick={() => setActiveTab('duebook')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'duebook'
                  ? 'bg-emerald-900 text-white shadow-sm'
                  : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4 text-emerald-300" />
              <span>বাকির খাতা</span>
            </button>
          </nav>

          {/* Zone 3: Add Product, Role Switcher, Settings & Mobile Cart */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Add Product Button */}
            <button
              onClick={onOpenAddProduct}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold shadow-sm transition"
              title="নতুন পণ্য যুক্ত করুন"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>+ পণ্য যোগ</span>
            </button>

            {/* Role indicator / switch */}
            <button
              onClick={onSwitchRole}
              title={activeRole === 'OWNER' ? 'দোকান মালিক মোড (সব তথ্য দৃশ্যমান)' : 'ক্যাশিয়ার মোড (লাভ গোপন)'}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                activeRole === 'OWNER'
                  ? 'bg-amber-400 text-slate-900 border-amber-300 hover:bg-amber-300 shadow-sm'
                  : 'bg-emerald-700 text-emerald-100 border-emerald-600 hover:bg-emerald-600'
              }`}
            >
              {activeRole === 'OWNER' ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-slate-900" />
                  <span className="hidden sm:inline">মালিক মোড</span>
                </>
              ) : (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-emerald-200" />
                  <span className="hidden sm:inline">ক্যাশিয়ার মোড</span>
                </>
              )}
            </button>

            {/* Settings & Backup Modal */}
            <button
              onClick={onOpenSettings}
              title="ব্যাকআপ, ক্লাউড সিঙ্ক ও দোকান সেটিং"
              className="p-2 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-700/60 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>

            {/* Mobile Cart Button */}
            <button
              onClick={openMobileCart}
              className="md:hidden relative flex items-center justify-center p-2 rounded-lg bg-emerald-700 text-white hover:bg-emerald-600"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-400 text-slate-900 rounded-full font-bold text-xs flex items-center justify-center shadow">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Navigation Bar */}
      <div className="md:hidden border-t border-emerald-700/70 bg-emerald-900/95 px-2 py-1.5 flex items-center justify-around text-xs">
        <button
          onClick={() => setActiveTab('pos')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'pos' ? 'text-amber-300 font-bold' : 'text-emerald-200'
          }`}
        >
          <ShoppingCart className="w-4 h-4 mb-0.5" />
          <span>বিক্রয়</span>
        </button>
        <button
          onClick={() => setActiveTab('invoices')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'invoices' ? 'text-amber-300 font-bold' : 'text-emerald-200'
          }`}
        >
          <ReceiptText className="w-4 h-4 mb-0.5" />
          <span>মেমো</span>
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex flex-col items-center py-1 px-2 rounded relative ${
            activeTab === 'inventory' ? 'text-amber-300 font-bold' : 'text-emerald-200'
          }`}
        >
          <Package className="w-4 h-4 mb-0.5" />
          <span>স্টক</span>
          {lowStockCount > 0 && (
            <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'dashboard' ? 'text-amber-300 font-bold' : 'text-emerald-200'
          }`}
        >
          <BarChart3 className="w-4 h-4 mb-0.5" />
          <span>হিসাব</span>
        </button>
        <button
          onClick={() => setActiveTab('duebook')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'duebook' ? 'text-amber-300 font-bold' : 'text-emerald-200'
          }`}
        >
          <BookOpen className="w-4 h-4 mb-0.5" />
          <span>বাকি</span>
        </button>
      </div>
    </header>
  );
};
