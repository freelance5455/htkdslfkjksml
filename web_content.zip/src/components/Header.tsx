import React from 'react';
import { Sparkles, Calendar, Receipt, BarChart3, Image as ImageIcon, ShieldCheck, Flame } from 'lucide-react';
import { formatINR } from '../data/pujaData';

interface HeaderProps {
  activeTab: 'tracker' | 'summary' | 'ai-studio' | 'receipts';
  setActiveTab: (tab: 'tracker' | 'summary' | 'ai-studio' | 'receipts') => void;
  totalCollected: number;
  totalBudget: number;
  paidCount: number;
  totalCount: number;
  isUnlocked: boolean;
  onToggleLock: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  totalCollected,
  totalBudget,
  paidCount,
  totalCount,
  isUnlocked,
  onToggleLock,
}) => {
  const percentage = totalBudget > 0 ? Math.round((totalCollected / totalBudget) * 100) : 0;

  return (
    <header className="relative bg-gradient-to-r from-red-900 via-rose-950 to-amber-950 text-white shadow-xl border-b border-amber-600/30 overflow-hidden">
      {/* Subtle traditional decorative pattern overlay */}
      <div 
        className="absolute inset-0 opacity-10 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 relative z-10">
        {/* Top bar with committee details and quick status */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-500/20 pb-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center p-1.5 bg-amber-500/20 border border-amber-400/40 rounded-lg text-amber-300">
              <Flame className="w-4 h-4 animate-pulse text-amber-400" />
            </span>
            <div>
              <p className="text-xs uppercase tracking-wider text-amber-300 font-semibold flex items-center gap-1.5">
                <span>সর্বজনীন শ্রী শ্রী দুর্গাপূজা সমিতি</span>
                <span className="text-amber-500/60">•</span>
                <span className="text-stone-300 font-normal">Sharadotsav 2026 / ১৪৩৩ বঙ্গাব্দ</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-stone-900/60 backdrop-blur-md px-3 py-1 rounded-full border border-amber-500/30 text-xs">
              <span className="text-stone-400">Target:</span>
              <span className="font-bold text-amber-200">₹{formatINR(totalBudget)}</span>
              <span className="text-amber-500/40">|</span>
              <span className="text-emerald-400 font-medium">{paidCount}/{totalCount} Paid ({percentage}%)</span>
            </div>

            <button
              onClick={onToggleLock}
              className={`text-xs px-2.5 py-1 rounded-full border transition flex items-center gap-1.5 ${
                isUnlocked 
                  ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/70' 
                  : 'bg-stone-900/80 border-stone-700 text-stone-300 hover:border-amber-500'
              }`}
              title={isUnlocked ? "Committee admin mode active" : "View-only mode"}
            >
              <ShieldCheck className={`w-3.5 h-3.5 ${isUnlocked ? 'text-emerald-400' : 'text-stone-400'}`} />
              <span className="hidden xs:inline">{isUnlocked ? 'Admin Mode' : 'View Mode'}</span>
            </button>
          </div>
        </div>

        {/* Main Title and Bengali Festive banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="text-2xl sm:text-3xl font-bold font-festive tracking-wide text-amber-100 flex items-center gap-2.5">
                <span>🪔</span>
                <span>Durga Puja Subscription</span>
              </h1>
              <span className="text-sm font-bengali text-amber-300/90 font-medium hidden md:inline">
                চাঁদা ও অনুদান রেজিস্টার
              </span>
            </div>
            <p className="text-xs sm:text-sm text-amber-200/70 mt-0.5">
              Unit-wise subscription management, instant printable receipts, summary reports & AI banner studio
            </p>
          </div>

          {/* Quick Collection KPI chip */}
          <div className="flex items-center gap-3 bg-gradient-to-br from-amber-950/80 to-stone-900/90 border border-amber-500/40 px-4 py-2 rounded-xl shadow-inner">
            <div>
              <p className="text-[11px] uppercase tracking-wider text-amber-300/80">Collected So Far</p>
              <p className="text-xl sm:text-2xl font-black text-amber-400">₹{formatINR(totalCollected)}</p>
            </div>
            <div className="w-12 h-12 relative flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-stone-800"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-amber-400 transition-all duration-700 ease-out"
                  strokeDasharray={`${percentage}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-[11px] font-bold text-amber-200">{percentage}%</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1.5 sm:gap-2 mt-4 pt-2 border-t border-amber-500/20 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveTab('tracker')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium text-xs sm:text-sm whitespace-nowrap transition-all ${
              activeTab === 'tracker'
                ? 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/30'
                : 'text-stone-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Unit Tracker</span>
          </button>

          <button
            onClick={() => setActiveTab('summary')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium text-xs sm:text-sm whitespace-nowrap transition-all ${
              activeTab === 'summary'
                ? 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/30'
                : 'text-stone-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Unit Summary & Table</span>
          </button>

          <button
            onClick={() => setActiveTab('ai-studio')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium text-xs sm:text-sm whitespace-nowrap transition-all relative ${
              activeTab === 'ai-studio'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 font-bold shadow-md shadow-amber-500/30'
                : 'text-amber-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>AI Festive Image Studio</span>
            <span className="bg-rose-600 text-white text-[9px] uppercase px-1.5 py-0.2 rounded-full font-bold">New</span>
          </button>

          <button
            onClick={() => setActiveTab('receipts')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium text-xs sm:text-sm whitespace-nowrap transition-all ${
              activeTab === 'receipts'
                ? 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/30'
                : 'text-stone-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Receipt Book</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
