import React from "react";
import { Sparkles, Settings, Feather, CheckCircle2, AlertCircle } from "lucide-react";
import { AppSettings } from "../types";

interface HeaderProps {
  settings: AppSettings;
  onOpenSettings: () => void;
  onToggleFont: () => void;
  hasApiKey: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onOpenSettings,
  onToggleFont,
  hasApiKey
}) => {
  return (
    <header className="sticky top-0 z-40 bg-stone-900/90 backdrop-blur-md border-b border-emerald-900/40 shadow-lg">
      {/* Android-style simulated status bar accent line */}
      <div className="h-1 w-full bg-gradient-to-r from-amber-600 via-emerald-500 to-amber-500" />
      
      <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* App Title & Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-800 to-stone-900 border border-amber-500/30 shadow-md">
            <Feather className="w-5 h-5 text-amber-400 -rotate-12" />
            <Sparkles className="w-3 h-3 text-emerald-300 absolute -top-1 -right-1 animate-pulse" />
          </div>

          <div>
            <h1 className="text-base sm:text-lg font-bold font-ui text-amber-200 tracking-wide leading-tight">
              Hassan's MisraSaaz AI
            </h1>
            <p className="text-[11px] font-urdu-sans text-emerald-300/90 leading-none mt-0.5">
              حسنؔ کا مصرع ساز AI • اردو شاعری و نغمہ نگار
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Font Toggle Button */}
          <button
            onClick={onToggleFont}
            id="font-toggle-button"
            title="خط تبدیل کریں (Nastaliq / Sans)"
            className="px-2.5 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700/60 text-xs font-urdu-sans text-amber-300 transition-colors flex items-center gap-1 shadow-sm"
          >
            <span>خط:</span>
            <span className="font-semibold text-emerald-300">
              {settings.selectedFont === "nastaliq" ? "نستعلیق" : "نسخ/سادہ"}
            </span>
          </button>

          {/* API Status Indicator & Settings Trigger */}
          <button
            onClick={onOpenSettings}
            id="open-settings-button"
            className={`p-2 rounded-xl border transition-all flex items-center gap-1.5 ${
              hasApiKey
                ? "bg-emerald-950/60 border-emerald-700/50 text-emerald-300 hover:bg-emerald-900/50"
                : "bg-amber-950/60 border-amber-700/50 text-amber-300 hover:bg-amber-900/50 animate-pulse"
            }`}
            title="سیٹنگز اور API Key"
          >
            {hasApiKey ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-400" />
            )}
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
