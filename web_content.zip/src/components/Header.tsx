import React from 'react';
import {
  Sparkles,
  Trash2,
  HelpCircle,
  BookOpen,
  ChevronDown,
  MessageSquare,
  Wand2,
  DollarSign
} from 'lucide-react';
import { PersonaMode, ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  mode: PersonaMode;
  onModeChange: (mode: PersonaMode) => void;
  onOpenGuide: () => void;
  onOpenDictionary: () => void;
  onOpenClearModal: () => void;
  onOpenImageSetup: () => void;
  messageCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  mode,
  onModeChange,
  onOpenGuide,
  onOpenDictionary,
  onOpenClearModal,
  onOpenImageSetup,
  messageCount,
}) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-[#0a0418]/95 backdrop-blur-md border-b border-purple-900/40 px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5 sm:gap-2">
        {/* Top line: Brand & Mode/Tabs */}
        <div className="w-full sm:w-auto flex items-center justify-between sm:justify-start gap-2.5 sm:gap-4">
          {/* Brand info */}
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-purple-700 via-fuchsia-600 to-violet-500 shadow-[0_0_15px_rgba(168,85,247,0.4)] shrink-0">
              <Sparkles className="w-4 h-4 text-white" />
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#0a0418] rounded-full animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base sm:text-lg font-extrabold tracking-tight bg-gradient-to-r from-white via-purple-100 to-purple-300 bg-clip-text text-transparent">
                  HANN AI
                </h1>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-purple-900/60 text-purple-300 border border-purple-500/30">
                  STUDIO
                </span>
              </div>
            </div>
          </div>

          {/* Tab Switcher Pills */}
          <div className="inline-flex items-center p-1 rounded-xl bg-[#140828] border border-purple-800/40 shadow-inner">
            <button
              onClick={() => onTabChange('chat')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'chat'
                  ? 'bg-gradient-to-r from-purple-700 to-fuchsia-700 text-white shadow-md shadow-purple-900/50 scale-[1.02]'
                  : 'text-purple-300/70 hover:text-purple-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Sembang</span>
            </button>
            <button
              onClick={() => onTabChange('image')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'image'
                  ? 'bg-gradient-to-r from-purple-700 to-fuchsia-700 text-white shadow-md shadow-purple-900/50 scale-[1.02]'
                  : 'text-purple-300/70 hover:text-purple-200'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 text-fuchsia-300" />
              <span>Editor Imej</span>
              <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 animate-ping" />
            </button>
          </div>
        </div>

        {/* Action Controls for Active Tab */}
        <div className="w-full sm:w-auto flex items-center justify-end gap-1.5 sm:gap-2">
          {activeTab === 'chat' ? (
            <>
              {/* Dialect Mode Selector */}
              <div className="relative inline-flex items-center rounded-xl bg-purple-950/60 border border-purple-800/40 p-0.5">
                <select
                  aria-label="Pilih Gaya Perbualan"
                  value={mode}
                  onChange={(e) => onModeChange(e.target.value as PersonaMode)}
                  className="appearance-none bg-transparent text-xs font-semibold text-purple-200 pl-2.5 pr-6 py-1 rounded-lg focus:outline-none cursor-pointer"
                >
                  <option value="utara" className="bg-[#150a2e] text-purple-200">🌾 Loghat Utara</option>
                  <option value="santai" className="bg-[#150a2e] text-purple-200">☕ BM Santai</option>
                  <option value="formal" className="bg-[#150a2e] text-purple-200">🎓 Ilmiah/Formal</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-purple-400 pointer-events-none absolute right-1.5" />
              </div>

              {/* Dictionary Button */}
              <button
                onClick={onOpenDictionary}
                className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 text-xs font-medium text-purple-300 border border-purple-800/30 transition-colors"
                title="Kamus Loghat Utara"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Kamus</span>
              </button>

              {/* Testing Guide Button */}
              <button
                onClick={onOpenGuide}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-xs font-semibold text-purple-200 border border-purple-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                title="Arahan Mudah Menguji Chatbot"
              >
                <HelpCircle className="w-3.5 h-3.5 text-purple-300" />
                <span className="hidden xs:inline sm:inline">Panduan Ujian</span>
              </button>

              {/* Padam Chat Button */}
              <button
                onClick={onOpenClearModal}
                disabled={messageCount === 0}
                className={`flex items-center justify-center p-2 rounded-xl transition-all ${
                  messageCount > 0
                    ? 'text-red-300 hover:text-red-200 hover:bg-red-950/40 border border-red-500/20 active:scale-95'
                    : 'text-slate-600 border border-transparent cursor-not-allowed opacity-50'
                }`}
                title="Padam Semua Chat"
                aria-label="Padam Chat"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              {/* Image Editor Help & Cost Info Button */}
              <button
                onClick={onOpenImageSetup}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 text-xs font-semibold text-purple-200 border border-purple-500/30 transition-all hover:scale-[1.02]"
              >
                <DollarSign className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>Info Setup & Kos</span>
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
