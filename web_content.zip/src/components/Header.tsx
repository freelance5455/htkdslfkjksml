import React from 'react';
import { Sparkles, Settings, Zap, Globe, Shield } from 'lucide-react';
import { ModelSettings } from '../types';

interface HeaderProps {
  freeMessages: number;
  modelSettings: ModelSettings;
  onOpenModelModal: () => void;
  onOpenSettings: () => void;
  onOpenProModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  freeMessages,
  modelSettings,
  onOpenModelModal,
  onOpenSettings,
  onOpenProModal,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-pink-500/20 px-4 py-3 flex items-center justify-between text-white">
      {/* Right side in RTL: Title and Brand Logo */}
      <div className="flex items-center space-x-2 space-x-reverse">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-600 via-purple-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-pink-500/25">
          <Sparkles className="w-5 h-5 text-white animate-pulse" />
        </div>
        <div>
          <h1 className="text-lg font-bold bg-gradient-to-r from-pink-400 via-purple-300 to-indigo-300 bg-clip-text text-transparent tracking-wide">
            PinkVerse AI
          </h1>
          <span className="text-[10px] text-pink-300/80 font-medium block -mt-1">
            شخصيات ودردشات ذكية
          </span>
        </div>
      </div>

      {/* Left side in RTL: Actions & Badge */}
      <div className="flex items-center space-x-2 space-x-reverse">
        {/* Model Badge */}
        <button
          onClick={onOpenModelModal}
          className="hidden sm:flex items-center space-x-1 space-x-reverse bg-slate-800/80 hover:bg-slate-700/80 text-pink-300 text-xs px-2.5 py-1 rounded-full border border-pink-500/30 transition-all"
        >
          <Globe className="w-3.5 h-3.5 text-pink-400" />
          <span>{modelSettings.chatModel}</span>
        </button>

        {/* Free Messages Counter Pill */}
        <button
          onClick={onOpenProModal}
          className="flex items-center space-x-1 space-x-reverse bg-gradient-to-r from-pink-500/20 to-purple-500/20 hover:from-pink-500/30 hover:to-purple-500/30 text-pink-200 text-xs font-semibold px-3 py-1 rounded-full border border-pink-500/40 shadow-sm transition-all"
        >
          <Zap className="w-3.5 h-3.5 text-pink-400 fill-pink-400" />
          <span>{freeMessages} رسالة مجانية</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
          title="الإعدادات"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
