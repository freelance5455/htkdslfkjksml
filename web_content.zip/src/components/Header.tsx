import React from 'react';
import { Menu, ShoppingBag, Boxes, CreditCard, Sparkles, PlusCircle } from 'lucide-react';
import { useStore, AppView } from '../context/StoreContext';

interface HeaderProps {
  onOpenSidebar: () => void;
  onOpenAddProduct?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSidebar, onOpenAddProduct }) => {
  const { 
    currentView, 
    setCurrentView, 
    cartCount, 
    setIsCartOpen, 
    userCredits,
    products
  } = useStore();

  const lowStockCount = products.filter(p => p.stock <= p.minStockAlert).length;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
        
        {/* Zone 1: Brand Wordmark (Single text element as required by Top Bar Contract) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenSidebar}
            className="p-2 -ml-2 text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            aria-label="Abrir navegação principal"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <button 
            onClick={() => setCurrentView('store')}
            className="flex items-center gap-2 text-left group focus-visible:outline-none"
          >
            <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-sm shadow-xs group-hover:bg-emerald-700 transition-colors">
              E
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
              EscaleBuilder
            </span>
          </button>
        </div>

        {/* Zone 2: Clean Single-Line Nav Links */}
        <nav className="hidden md:flex items-center gap-5 lg:gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setCurrentView('store')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentView === 'store' 
                ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' 
                : 'hover:text-slate-900'
            }`}
          >
            Loja
          </button>

          <button
            onClick={() => setCurrentView('inventory')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              currentView === 'inventory' 
                ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' 
                : 'hover:text-slate-900'
            }`}
          >
            <span>Estoque</span>
            {lowStockCount > 0 && (
              <span className="text-[11px] font-mono px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
                {lowStockCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setCurrentView('orders')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentView === 'orders' 
                ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' 
                : 'hover:text-slate-900'
            }`}
          >
            Vendas
          </button>

          <button
            onClick={() => setCurrentView('payouts')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              currentView === 'payouts' 
                ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' 
                : 'hover:text-slate-900'
            }`}
          >
            <span>Como Recebo (Saques)</span>
          </button>

          <button
            onClick={() => setCurrentView('plans')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentView === 'plans' 
                ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' 
                : 'hover:text-slate-900'
            }`}
          >
            Planos
          </button>
        </nav>

        {/* Zone 3: Primary Action & Quick Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Credit status button matching screenshots: '💳 Sem créditos' or '💳 X créditos' */}
          <button
            onClick={() => setCurrentView('plans')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors whitespace-nowrap"
            title="Clique para gerenciar ou adquirir créditos"
          >
            <span>💳</span>
            <span>{userCredits > 0 ? `${userCredits} créditos` : 'Sem créditos'}</span>
          </button>

          {/* Cart button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 text-slate-700 hover:text-emerald-700 rounded-lg hover:bg-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            aria-label="Abrir carrinho de compras"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-600 text-white font-mono text-[11px] font-bold h-5 min-w-5 px-1 rounded-full flex items-center justify-center shadow-xs">
                {cartCount}
              </span>
            )}
          </button>

          {/* User profile avatar badge matching screenshots */}
          <button 
            onClick={onOpenSidebar}
            className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center justify-center hover:bg-emerald-200 transition-colors"
            title="Conta: Momade Cássimo Sumaila"
          >
            M
          </button>
        </div>

      </div>
    </header>
  );
};
