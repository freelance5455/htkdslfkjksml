import React from 'react';
import { Volume2, VolumeX, Sliders, Shield, Zap, Sparkles, Mic, MicOff } from 'lucide-react';
import { soundManager } from '../utils/soundEffects';

interface HeaderProps {
  soundEnabled: boolean;
  onToggleSound: () => void;
  voiceEnabled?: boolean;
  onToggleVoice?: () => void;
  onOpenSettings: () => void;
  strongSniperMode: boolean;
  onToggleSniperMode: () => void;
  balance: number;
  activeTradersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  soundEnabled,
  onToggleSound,
  voiceEnabled = true,
  onToggleVoice,
  onOpenSettings,
  strongSniperMode,
  onToggleSniperMode,
  balance,
  activeTradersCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0d0407]/95 backdrop-blur-md border-b border-[#30101d] px-3.5 py-2.5">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Brand & Badge */}
        <div className="flex items-center gap-2">
          {/* Logo Crest */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 via-rose-900 to-black p-0.5 shadow-lg shadow-red-950/60 flex items-center justify-center shrink-0 border border-red-500/40">
            <span className="text-[11px] font-black tracking-tighter text-red-200">QX</span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <h1 className="text-sm sm:text-base font-extrabold tracking-wider text-slate-100 uppercase">
              AXILER <span className="text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]">QUANTUM</span>
            </h1>

            <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800/60 shadow-sm">
              V2.4.7
            </span>

            {/* Live AI Pulse */}
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 pl-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="tracking-wide text-[10px] uppercase hidden xs:inline">LIVE AI</span>
            </div>

            {/* Active Traders */}
            <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-400 pl-1">
              <span className="text-red-500 text-xs">((•))</span>
              <span className="tabular-nums font-semibold">{activeTradersCount}</span>
            </div>
          </div>
        </div>

        {/* Right Controls: 99% Sniper Toggle + Balance + Indicator Config */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* 99% Strong Sniper Mode Pill Toggle */}
          <button
            onClick={() => {
              onToggleSniperMode();
              soundManager.playPip();
            }}
            className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold transition-all border ${
              strongSniperMode
                ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white border-red-400/80 shadow-[0_0_12px_rgba(239,68,68,0.4)]'
                : 'bg-[#1e0a13] text-zinc-400 border-[#3b1223] hover:text-zinc-200'
            }`}
            title="Toggle 99% Strong Single Bot Mode"
          >
            <Zap className={`w-3 h-3 ${strongSniperMode ? 'text-amber-300 fill-amber-300 animate-pulse' : 'text-zinc-500'}`} />
            <span className="text-[11px] tracking-tight whitespace-nowrap">99% BOT</span>
          </button>

          {/* Balance Pill */}
          <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-[#1a0810] border border-[#3b1223] rounded-md text-xs font-mono">
            <span className="text-[10px] text-zinc-400 font-sans">DEMO</span>
            <span className="text-emerald-400 font-bold tabular-nums">
              ${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          {/* Sound Effects Toggle */}
          <button
            onClick={onToggleSound}
            className="p-1.5 rounded-md bg-[#1a0810] border border-[#3b1223] text-zinc-400 hover:text-zinc-200 transition-colors"
            title={soundEnabled ? 'Mute sound alerts' : 'Enable sound alerts'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5 text-zinc-500" />}
          </button>

          {/* Voice Narrator Toggle */}
          {onToggleVoice && (
            <button
              onClick={onToggleVoice}
              className={`p-1.5 rounded-md border transition-colors flex items-center justify-center ${
                voiceEnabled
                  ? 'bg-purple-950/80 border-purple-500/70 text-purple-300 shadow-[0_0_10px_rgba(168,85,247,0.35)]'
                  : 'bg-[#1a0810] border-[#3b1223] text-zinc-500'
              }`}
              title={voiceEnabled ? 'Voice Narrator Active (Telling What Market Is Saying)' : 'Voice Narrator Muted'}
            >
              {voiceEnabled ? <Mic className="w-3.5 h-3.5 text-purple-300 animate-pulse" /> : <MicOff className="w-3.5 h-3.5 text-zinc-500" />}
            </button>
          )}

          {/* Bot & Indicator Studio Settings */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-md bg-[#1a0810] border border-[#3b1223] text-zinc-400 hover:text-zinc-200 hover:border-red-500/50 transition-colors"
            title="Custom Technical Analysis Indicators & Bot Config"
          >
            <Sliders className="w-3.5 h-3.5 text-red-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
