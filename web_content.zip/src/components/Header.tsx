import React from 'react';
import { SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { DownloadCloud, Globe, Code2, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentLang: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onOpenExportModal: () => void;
  historyCount: number;
  onScrollToSection: (id: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onLanguageChange,
  onOpenExportModal,
  historyCount,
  onScrollToSection,
}) => {
  const t = translations[currentLang];

  const languages: { code: SupportedLanguage; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'ur', label: 'اردو (Urdu)' },
    { code: 'hi', label: 'हिन्दी (Hindi)' },
    { code: 'es', label: 'Español' },
    { code: 'ar', label: 'العربية' },
  ];

  return (
    <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
        {/* Brand Logo: SL TIK TOK Video */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2.5 group text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-sky-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/25 group-hover:scale-105 transition-transform duration-200">
              <span className="text-white font-black text-sm tracking-wider">SL</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  SL TIK TOK <span className="text-cyan-400">Video</span>
                </span>
              </div>
              <p className="text-[11px] text-cyan-300 font-medium leading-none">
                This app developer Saleem Zakhme
              </p>
            </div>
          </button>
        </div>

        {/* Navigation & Action Controls */}
        <div className="flex items-center gap-2 sm:gap-4">
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-300">
            <button
              onClick={() => onScrollToSection('how-to')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              How to Download
            </button>
            <button
              onClick={() => onScrollToSection('features')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              onClick={() => onScrollToSection('faq')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              FAQ
            </button>
            {historyCount > 0 && (
              <button
                onClick={() => onScrollToSection('history')}
                className="hover:text-cyan-400 transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>History</span>
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs flex items-center justify-center font-bold">
                  {historyCount}
                </span>
              </button>
            )}
          </nav>

          {/* Standalone Export Button - Hidden as requested */}
          <button
            onClick={onOpenExportModal}
            className="hidden items-center gap-2 px-3 py-2 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-500/20 via-teal-500/15 to-cyan-500/20 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 hover:text-emerald-200 text-xs sm:text-sm font-bold shadow-sm hover:shadow-emerald-500/20 transition-all cursor-pointer"
            title="Download or copy the 1-file index.html code"
          >
            <Code2 className="w-4 h-4 text-emerald-400 group-hover:rotate-12 transition-transform" />
            <span className="hidden md:inline">Single index.html Code</span>
            <span className="md:hidden">HTML Code</span>
            <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.2 rounded-md bg-emerald-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
              <Sparkles className="w-2.5 h-2.5" /> 100% Free
            </span>
          </button>

          {/* Language Selector */}
          <div className="relative flex items-center">
            <Globe className="w-4 h-4 text-slate-400 absolute left-2.5 pointer-events-none" />
            <select
              value={currentLang}
              onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
              className="bg-slate-900 border border-slate-700/80 rounded-xl pl-8 pr-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer transition appearance-none"
            >
              {languages.map((l) => (
                <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                  {l.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
