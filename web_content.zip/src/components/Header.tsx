import React from 'react';
import { Sparkles, Sliders, History, Info, Volume2, ShieldCheck, Zap, Smartphone, ArrowDownToLine } from 'lucide-react';
import { TTSEngineType } from '../types/tts';

interface HeaderProps {
  currentTab: 'studio' | 'sentences' | 'history' | 'about';
  setCurrentTab: (tab: 'studio' | 'sentences' | 'history' | 'about') => void;
  activeEngine: TTSEngineType;
  setActiveEngine: (engine: TTSEngineType) => void;
  onOpenSettings: () => void;
  onOpenPronunciation: () => void;
  onOpenDownloadApk: () => void;
  historyCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  activeEngine,
  setActiveEngine,
  onOpenSettings,
  onOpenPronunciation,
  onOpenDownloadApk,
  historyCount,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#0a0d14]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Subtitle */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentTab('studio')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-white/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-400">
                  YiuVoice
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  తెలుగు AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Professional Telugu AI Voice Studio
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              id="nav-tab-studio"
              onClick={() => setCurrentTab('studio')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'studio'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              Voice Studio
            </button>

            <button
              id="nav-tab-sentences"
              onClick={() => setCurrentTab('sentences')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'sentences'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              వాక్య నియంత్రణ (Sentences)
            </button>

            <button
              id="nav-tab-history"
              onClick={() => setCurrentTab('history')}
              className={`relative px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'history'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center gap-1.5">
                <History className="w-4 h-4" />
                <span className="hidden sm:inline">చరిత్ర</span>
                {historyCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-cyan-500/20 text-cyan-300 font-mono">
                    {historyCount}
                  </span>
                )}
              </div>
            </button>

            <button
              id="nav-tab-about"
              onClick={() => setCurrentTab('about')}
              className={`p-2 rounded-lg text-sm transition-all ${
                currentTab === 'about'
                  ? 'bg-slate-800 text-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
              title="About YiuVoice"
            >
              <Info className="w-4 h-4" />
            </button>
          </nav>

          {/* Right Tools: Engine Selector & Settings */}
          <div className="flex items-center gap-2">
            {/* Engine Badge Selector */}
            <div className="hidden lg:flex items-center bg-slate-900/90 rounded-lg p-1 border border-slate-800">
              <button
                id="engine-select-edge"
                onClick={() => setActiveEngine('edge-neural')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeEngine === 'edge-neural'
                    ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
                title="Realistic Neural Studio (Hyper-realistic Telugu human voice)"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Realistic Neural</span>
              </button>

              <button
                id="engine-select-gemini"
                onClick={() => setActiveEngine('gemini-neural')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeEngine === 'gemini-neural'
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
                title="Gemini 3.1 Flash Neural Studio TTS (24kHz Studio Audio)"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Gemini Neural</span>
              </button>

              <button
                id="engine-select-native"
                onClick={() => setActiveEngine('native-telugu')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeEngine === 'native-telugu'
                    ? 'bg-slate-800 text-slate-100 border border-slate-700'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
                title="Google Native te-IN Engine"
              >
                <Volume2 className="w-3.5 h-3.5 text-blue-400" />
                <span>Native te-IN</span>
              </button>
            </div>

            {/* Download Android APK / App button */}
            <button
              id="header-download-apk-btn"
              onClick={onOpenDownloadApk}
              className="px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-cyan-500/20 text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-500/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm shadow-emerald-950/40 cursor-pointer active:scale-95"
              title="Download Android APK / Install App (ఆండ్రాయిడ్ యాప్ డౌన్‌లోడ్)"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>APK డౌన్‌లోడ్</span>
            </button>

            {/* Pronunciation Dictionary button */}
            <button
              id="header-pronunciation-btn"
              onClick={onOpenPronunciation}
              className="px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:text-cyan-400 hover:border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-all"
              title="Pronunciation / Custom Dictionary (ఉచ్చారణ నిఘంటువు)"
            >
              <span className="font-telugu text-sm">అ-ఆ</span>
              <span className="hidden md:inline">డిక్షనరీ</span>
            </button>

            {/* Advanced Settings Button */}
            <button
              id="header-settings-btn"
              onClick={onOpenSettings}
              className="p-2 rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:text-cyan-400 hover:border-slate-700 transition-all"
              title="Advanced Settings (సెట్టింగ్‌లు)"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
