import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  Database, 
  Settings, 
  Code2, 
  Eye, 
  GitBranch, 
  Search, 
  ChevronDown, 
  Compass,
  Bell,
  PanelRightOpen,
  PanelRightClose,
  Activity,
  X,
  Radio,
  Cpu,
  Sun,
  Moon,
  ArrowRight,
  User, 
  Sliders,
  Download
} from 'lucide-react';
import { ExecutionMode, TaskState, WorkspaceViewMode, ActivityLogItem } from '../types';
import { OperationState } from '../godex/operationState';
import { GodexLogo } from './GodexLogo';

interface HeaderProps {
  currentProjectTitle: string;
  activeWorkspaceView: WorkspaceViewMode;
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  executionMode: ExecutionMode;
  onToggleExecutionMode: () => void;
  taskState: TaskState;
  onOpenCheckpoints: () => void;
  onOpenMemory: () => void;
  onOpenModelSettings: () => void;
  onOpenTemplates: () => void;
  onOpenImportProject?: () => void;
  onOpenExportModal?: () => void;
  onOpenCommandPalette: () => void;
  onRunVerification: () => void;
  isVerifying: boolean;
  isInspectorOpen?: boolean;
  onToggleInspector?: () => void;
  currentOperationState?: OperationState;
  activityLogs?: ActivityLogItem[];
  onPromptAgent?: (prompt: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentProjectTitle,
  activeWorkspaceView,
  onSelectWorkspaceView,
  executionMode,
  onToggleExecutionMode,
  taskState,
  onOpenCheckpoints,
  onOpenMemory,
  onOpenModelSettings,
  onOpenTemplates,
  onOpenImportProject,
  onOpenExportModal,
  onOpenCommandPalette,
  onRunVerification,
  isVerifying,
  isInspectorOpen = true,
  onToggleInspector,
  currentOperationState,
  activityLogs = [],
  onPromptAgent
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) {
      onOpenCommandPalette();
      return;
    }
    if (onPromptAgent) {
      onPromptAgent(searchInput.trim());
      setSearchInput('');
      onSelectWorkspaceView('studio');
    } else {
      onOpenCommandPalette();
    }
  };

  return (
    <header 
      id="godex-main-header"
      className="h-12 sm:h-13 border-b border-[#18233C] bg-[#0A0F1C] px-3 sm:px-4 flex items-center justify-between shrink-0 select-none z-30 font-sans"
    >
      {/* LEFT: Logo & Project Title */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <div 
          onClick={() => onSelectWorkspaceView('home')} 
          className="flex items-center gap-2 cursor-pointer group shrink-0"
        >
          <GodexLogo size={24} showText={false} />
          <span className="font-bold text-xs sm:text-sm text-white font-mono tracking-wider">
            GODEX
          </span>
        </div>

        <div className="h-4 w-px bg-[#18233C] hidden sm:block" />

        <div 
          onClick={onOpenTemplates}
          className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-[#0F1629] border border-[#1E2B47] text-neutral-300 text-xs font-mono hover:border-cyan-500/40 cursor-pointer transition-colors max-w-[200px]"
          title="Switch Project Template"
        >
          <span className="truncate">{currentProjectTitle}</span>
          <ChevronDown className="w-3 h-3 text-neutral-500 shrink-0" />
        </div>
      </div>

      {/* CENTER: Global Command & Search Bar */}
      <div className="flex-1 max-w-sm md:max-w-md lg:max-w-xl mx-2 sm:mx-4">
        <form onSubmit={handleSearchSubmit} className="relative flex items-center w-full">
          <div className="w-full flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-xl bg-[#0F1629] border border-[#1F2C4A] focus-within:border-indigo-500/60 focus-within:shadow-[0_0_16px_rgba(99,102,241,0.2)] transition-all">
            <Search className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              placeholder="Ask GODEX... (⌘ K)"
              className="w-full bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none font-sans"
              onClick={(e) => {
                if (e.metaKey || e.ctrlKey) {
                  onOpenCommandPalette();
                }
              }}
            />
            <button
              type="submit"
              className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 flex items-center justify-center text-white shrink-0 shadow-xs transition-all"
              title="Submit prompt or command"
            >
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </form>
      </div>

      {/* RIGHT: Notifications, Status & Inspector Toggle */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-[#121A2E] transition-colors relative"
            title="System Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-rose-500 text-white text-[8px] font-bold font-mono flex items-center justify-center shadow-[0_0_8px_rgba(239,68,68,0.6)]">
              9
            </span>
          </button>

          {/* Notifications Flyout */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-72 sm:w-80 rounded-2xl bg-[#0F1629] border border-[#202D49] shadow-2xl p-3 z-50 space-y-2 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-[#1A243B]">
                <span className="text-xs font-mono font-bold text-white">SYSTEM EVENTS</span>
                <button 
                  onClick={() => setShowNotifications(false)}
                  className="text-neutral-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-1.5 text-xs max-h-60 overflow-y-auto no-scrollbar">
                <div className="p-2 rounded-lg bg-[#0A0E1A] border border-[#1A243B]">
                  <div className="text-[11px] font-medium text-emerald-300">Verification Passed</div>
                  <div className="text-[9px] font-mono text-neutral-400">All 5 AST integrity rules certified.</div>
                </div>
                <div className="p-2 rounded-lg bg-[#0A0E1A] border border-[#1A243B]">
                  <div className="text-[11px] font-medium text-cyan-300">Digital Twin Synchronized</div>
                  <div className="text-[9px] font-mono text-neutral-400">Indexed symbols across active workspace.</div>
                </div>
                <div className="p-2 rounded-lg bg-[#0A0E1A] border border-[#1A243B]">
                  <div className="text-[11px] font-medium text-purple-300">Self-Healing Runtime Ready</div>
                  <div className="text-[9px] font-mono text-neutral-400">Diagnostic telemetry listening.</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Export Project ZIP */}
        {onOpenExportModal && (
          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-xl bg-[#121A2E] border border-[#1F2C4A] hover:border-cyan-500/40 text-neutral-300 hover:text-cyan-300 transition-colors"
            title="Export Project ZIP Archive"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline text-xs font-mono">Export</span>
          </button>
        )}

        {/* Settings & OS Status */}
        <button
          onClick={onOpenModelSettings}
          className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-xl bg-[#121A2E] border border-[#1F2C4A] hover:border-cyan-500/40 transition-colors"
          title="System Settings"
        >
          <Settings className="w-3.5 h-3.5 text-neutral-400" />
          <span className="hidden md:inline text-xs font-mono text-neutral-200">AI Studio</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        </button>

        {/* Right Inspector Toggle */}
        {onToggleInspector && (
          <button
            onClick={onToggleInspector}
            className={`p-1.5 rounded-xl border transition-colors ${
              isInspectorOpen 
                ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300' 
                : 'bg-[#0F1629] border-[#1F2C4A] text-neutral-400 hover:text-white'
            }`}
            title={isInspectorOpen ? 'Collapse Inspector' : 'Expand Inspector'}
          >
            {isInspectorOpen ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
          </button>
        )}
      </div>
    </header>
  );
};
