import React from 'react';
import { Coins, Volume2, VolumeX, BookOpen, Settings, Moon, Clock } from 'lucide-react';
import { formatGameTime } from '../game/engine';
import { playClickSound, toggleSound, isSoundEnabled } from '../utils/audio';

interface HeaderProps {
  playerName: string;
  money: number;
  day: number;
  hour: number;
  timeSpeed: 'slow' | 'normal';
  onOpenTutorial: () => void;
  onOpenRename: () => void;
  onSleep: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  playerName,
  money,
  day,
  hour,
  timeSpeed,
  onOpenTutorial,
  onOpenRename,
  onSleep
}) => {
  const [soundOn, setSoundOn] = React.useState(isSoundEnabled());
  const { timeStr } = formatGameTime(hour);

  const handleSoundToggle = () => {
    const newState = toggleSound();
    setSoundOn(newState);
    if (newState) playClickSound();
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 py-2.5 px-4 mb-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Brand & Player */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center text-slate-950 font-black text-lg shadow-md shadow-amber-500/20">
            🌙
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-sm text-amber-300">لعبة الحياة</span>
              <span className="text-[10px] text-slate-400">• كفاح {playerName}</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">اليوم {day}</span>
              <span>•</span>
              <span className="flex items-center gap-1 text-cyan-300">
                <Clock className="w-3 h-3 text-cyan-400" />
                {timeStr}
              </span>
              {timeSpeed === 'slow' && (
                <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 text-[9px] border border-cyan-800/50">
                  وقت هادئ
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Money and Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Money badge */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-300 font-bold text-xs sm:text-sm shadow-sm">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>{Math.floor(money).toLocaleString('en-US')} ج.م</span>
          </div>

          {/* Quick sleep button */}
          <button
            onClick={() => { playClickSound(); onSleep(); }}
            title="نوم للصباح واستعادة الطاقة"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-indigo-300 hover:bg-slate-800 transition"
          >
            <Moon className="w-4 h-4" />
          </button>

          {/* Tutorial button */}
          <button
            onClick={() => { playClickSound(); onOpenTutorial(); }}
            title="دليل وتوتوريل اللعبة"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-amber-400 hover:bg-slate-800 transition"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {/* Rename/Settings button */}
          <button
            onClick={() => { playClickSound(); onOpenRename(); }}
            title="تغيير وتعديل الأسماء"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 transition"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Sound button */}
          <button
            onClick={handleSoundToggle}
            title={soundOn ? 'كتم الصوت' : 'تشغيل الصوت'}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>
    </header>
  );
};
