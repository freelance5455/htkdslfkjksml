import React from 'react';
import { Volume2, VolumeX, Info, Download } from 'lucide-react';
import { useAudioFeedback } from '../hooks/useAudioFeedback';

interface HeaderProps {
  coins: number;
  pkrBalance: number;
  soundMuted: boolean;
  onToggleSound: () => void;
  hapticsEnabled: boolean;
  onToggleHaptics: () => void;
  onOpenRules: () => void;
  onOpenInstallModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  coins,
  pkrBalance,
  soundMuted,
  onToggleSound,
  onOpenRules,
  onOpenInstallModal,
}) => {
  const { playButtonClick, playCoinCollect } = useAudioFeedback();

  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-2.5 sm:px-4 py-2 transition-colors">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Zone 1: Brand wordmark */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-sm shadow-amber-500/20 flex items-center justify-center shrink-0">
            <span className="text-slate-950 font-black text-xs font-display">TC</span>
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-tight text-white font-display leading-tight truncate">
              Tap Tap Cash
            </h1>
          </div>
        </div>

        {/* Zone 2: Live Balance Display */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2 py-1 rounded-full text-xs shrink-0">
          <span className="text-amber-400 font-bold font-mono-num">
            🪙 {coins.toLocaleString()}
          </span>
          <span className="text-slate-700 text-[10px]" aria-hidden="true">|</span>
          <span className="text-emerald-400 font-bold font-mono-num">
            Rs. {pkrBalance.toFixed(1)}
          </span>
        </div>

        {/* Zone 3: Controls (Download/Install button ALWAYS visible + Sound + Rules) */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => {
              playButtonClick();
              onOpenInstallModal();
            }}
            title="Download / Install Mobile App"
            className="px-2 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 hover:text-white hover:bg-emerald-500/30 text-xs font-extrabold flex items-center gap-1 active:scale-95 transition-all shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[11px]">Download</span>
          </button>

          <button
            onClick={() => {
              playButtonClick();
              onToggleSound();
            }}
            title={soundMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            aria-label="Toggle sound"
          >
            {soundMuted ? <VolumeX className="w-3.5 h-3.5 text-slate-500" /> : <Volume2 className="w-3.5 h-3.5 text-amber-400" />}
          </button>

          <button
            onClick={() => {
              playCoinCollect(1);
              onOpenRules();
            }}
            title="How Payouts Work"
            className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            aria-label="How it works"
          >
            <Info className="w-3.5 h-3.5 text-slate-300" />
          </button>
        </div>
      </div>
    </header>
  );
};
