import React from 'react';
import { Bot, Coins, ShieldCheck, Sparkles, Instagram } from 'lucide-react';

interface HeaderProps {
  coins: number;
  onOpenChat: () => void;
  onOpenCoinsModal: () => void;
  isAdminUnlocked: boolean;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  coins,
  onOpenChat,
  onOpenCoinsModal,
  isAdminUnlocked,
  onOpenAdmin,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/80 border-b border-purple-500/15">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Left: Chatbot Support Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenChat}
            className="group relative flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-900/60 to-pink-900/40 hover:from-purple-800/80 hover:to-pink-800/60 border border-purple-500/30 hover:border-pink-500/50 text-purple-200 transition-all shadow-lg shadow-purple-950/50 hover:shadow-purple-700/20 active:scale-95"
            title="Open Support Chatbot & Admin Access"
          >
            <div className="relative">
              <Bot className="w-5 h-5 text-pink-400 group-hover:text-pink-300 transition-colors" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-slate-950" />
            </div>
            <span className="text-xs font-semibold tracking-wide hidden sm:inline text-purple-100">
              Support Bot
            </span>
            <span className="text-[10px] bg-purple-500/30 text-purple-200 font-mono px-1.5 py-0.5 rounded-md border border-purple-500/20">
              AI / Admin
            </span>
          </button>

          {isAdminUnlocked && (
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-medium hover:bg-emerald-900/80 transition-all animate-pulse"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Admin Panel</span>
            </button>
          )}
        </div>

        {/* Center: Brand */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg shadow-rose-500/25 ring-2 ring-white/10">
            <Instagram className="w-5 h-5 text-white" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-purple-100 to-pink-200 bg-clip-text text-transparent">
                InstaBoost
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-bold tracking-wider uppercase rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/30 text-pink-300">
                PRO
              </span>
            </div>
          </div>
        </div>

        {/* Right: Coins Display */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCoinsModal}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-500/20 border border-amber-500/30 hover:border-amber-400/60 text-amber-200 transition-all hover:scale-105 active:scale-95 shadow-md shadow-amber-950/40"
            title="View Coins Balance & Claim Daily Free Coins"
          >
            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-inner">
              <Coins className="w-3.5 h-3.5 text-amber-950" />
            </div>
            <div className="flex flex-col items-start leading-none">
              <span className="text-xs font-mono font-bold text-amber-300">
                {coins.toLocaleString()}
              </span>
              <span className="text-[9px] uppercase tracking-wider text-amber-400/70 font-semibold">
                Coins
              </span>
            </div>
            <Sparkles className="w-3.5 h-3.5 text-amber-400/80 animate-spin" style={{ animationDuration: '6s' }} />
          </button>
        </div>
      </div>
    </header>
  );
};
