import React from "react";
import { Calculator, Settings, Sparkles, PhoneCall, Download } from "lucide-react";

interface HeaderProps {
  onOpenRates: () => void;
  onOpenContact: () => void;
  onOpenAi: () => void;
  onGoHome: () => void;
  onInstallApp?: () => void;
  isInstalled?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenRates,
  onOpenContact,
  onOpenAi,
  onGoHome,
  onInstallApp,
  isInstalled,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-indigo-600 text-white border-b border-indigo-700 shadow-md">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <button
          onClick={onGoHome}
          className="flex items-center gap-3 text-left focus:outline-none group active:scale-95 transition-transform"
        >
          <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center shadow-inner overflow-hidden p-1">
            <img
              src="/icon.svg"
              alt="Ceiling Calculation"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="font-extrabold text-lg sm:text-xl tracking-tight leading-none text-white group-hover:text-indigo-100 transition-colors">
              Ceiling Calculation
            </h1>
            <p className="text-[11px] text-indigo-100 font-medium tracking-wide mt-0.5">
              Professional Cost Estimator
            </p>
          </div>
        </button>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Install App Button in Header (if not running installed) */}
          {!isInstalled && onInstallApp && (
            <button
              onClick={onInstallApp}
              id="header-install-btn"
              className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-slate-950 font-black px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm shadow-sm active:scale-95 transition-all"
              title="📲 Install App on Phone"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span className="hidden sm:inline">📲 Install App</span>
              <span className="sm:hidden">Install</span>
            </button>
          )}

          {/* Direct Call Button in Header */}
          <a
            href="tel:9068926728"
            className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs sm:text-sm shadow-sm active:scale-95 transition-all"
            title="Call 9068926728"
          >
            <PhoneCall className="w-4 h-4 fill-slate-950" />
            <span className="hidden sm:inline">📞 9068926728</span>
            <span className="sm:hidden">Call</span>
          </a>

          {/* AI Help Button */}
          <button
            onClick={onOpenAi}
            className="flex items-center gap-1.5 bg-white text-indigo-700 hover:bg-indigo-50 font-bold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs sm:text-sm shadow-sm active:scale-95 transition-all"
            title="Ask AI Assistant"
          >
            <Sparkles className="w-4 h-4 fill-indigo-600 text-indigo-600" />
            <span className="hidden xs:inline">Smart AI</span>
          </button>

          {/* Rate Management */}
          <button
            onClick={onOpenRates}
            className="px-2 sm:px-2.5 py-1.5 sm:py-2 text-indigo-100 hover:text-white hover:bg-indigo-700 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors"
            title="Manage Rates"
          >
            <Settings className="w-4 h-4" />
            <span className="hidden md:inline">Rates</span>
          </button>

          {/* Contact Contractor */}
          <button
            onClick={onOpenContact}
            className="px-2 sm:px-2.5 py-1.5 sm:py-2 text-indigo-100 hover:text-white hover:bg-indigo-700 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors"
            title="Contact Contractor"
          >
            <PhoneCall className="w-4 h-4 text-emerald-300" />
            <span className="hidden md:inline">Contact</span>
          </button>
        </div>
      </div>
    </header>
  );
};
