import React from 'react';
import { ArrowRight, BookOpen, Feather } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  onBack?: () => void;
  onOpenSettings?: () => void;
  showBack?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title = 'الكلمات المتقاطعة',
  subtitle = 'الجريدة اليومية للألغاز والمطالعة - الطبعة الأولى',
  onBack,
  showBack = false,
}) => {
  return (
    <header className="w-full bg-[#ede9e1] pt-2.5 pb-2 px-3 border-b-2 border-[#2c2c2c] newspaper-border-double shadow-xs select-none">
      <div className="max-w-3xl mx-auto flex items-center justify-between gap-2">
        {/* Right side: Back button or Decorative Newspaper/Book Icon */}
        <div className="flex items-center gap-1 min-w-[40px]">
          {showBack && onBack ? (
            <button
              type="button"
              onClick={() => {
                soundManager.playButtonClick();
                onBack();
              }}
              className="p-1.5 rounded-xs hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] flex items-center gap-1 font-bold text-sm transition-colors border border-transparent hover:border-[#2c2c2c]"
              aria-label="رجوع"
            >
              <ArrowRight className="w-5 h-5" />
              <span className="hidden sm:inline">رجوع</span>
            </button>
          ) : (
            <div className="p-1 text-[#2c2c2c] opacity-80 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
          )}
        </div>

        {/* Center: Classic Newspaper Banner Title */}
        <div className="text-center flex-1">
          <h1 className="newspaper-font text-xl sm:text-3xl font-bold tracking-tight text-[#1a1a1a] leading-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="text-[10px] sm:text-xs text-[#2c2c2c] font-semibold tracking-wider mt-0.5 border-t border-b border-[#2c2c2c]/30 py-0.5 max-w-xs sm:max-w-md mx-auto">
              {subtitle}
            </p>
          )}
        </div>

        {/* Left side: Matching decorative icon (Feather/Pen) */}
        <div className="flex items-center gap-1 min-w-[40px] justify-end">
          <div className="p-1 text-[#2c2c2c] opacity-80 flex items-center justify-center">
            <Feather className="w-5 h-5" />
          </div>
        </div>
      </div>
    </header>
  );
};
