import React from 'react';
import {
  Plus,
  FileText,
  Wrench,
  Images,
  Layers,
  ArrowLeft,
  Home,
  Smartphone,
  Share2,
  Database,
  Monitor
} from 'lucide-react';

interface Props {
  activeView: 'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria';
  onSelectView: (view: 'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria') => void;
  onNewPaintingReport: () => void;
  onNewMaintenance: () => void;
  onNewProcedure: () => void;
  onOpenBackup: () => void;
  isPixel9Preview: boolean;
  onTogglePixel9Preview: () => void;
}

export const Header: React.FC<Props> = ({
  activeView,
  onSelectView,
  onNewPaintingReport,
  onNewMaintenance,
  onNewProcedure,
  onOpenBackup,
  isPixel9Preview,
  onTogglePixel9Preview
}) => {
  return (
    <header className="h-16 px-4 sm:px-6 bg-white border-b border-neutral-200 flex items-center justify-between gap-3 sm:gap-6 shrink-0 no-print z-30 sticky top-0">
      {/* Left Area: Back to Menu on mobile/fullscreen or Brand Logo */}
      <div className="flex items-center gap-2.5 sm:gap-3 whitespace-nowrap shrink-0">
        {activeView !== 'menu' ? (
          <button
            onClick={() => onSelectView('menu')}
            className="inline-flex items-center gap-2 px-3 py-2 bg-neutral-900 hover:bg-neutral-800 active:bg-black text-white rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="inline font-bold">Menù</span>
            <span className="hidden sm:inline text-neutral-300 font-normal">Principale</span>
          </button>
        ) : (
          <button
            onClick={() => onSelectView('menu')}
            className="flex items-center gap-2.5 text-left group"
          >
            <div className="w-8 h-8 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-bold text-xs tracking-tight font-mono shadow-xs group-hover:bg-neutral-800 transition-colors">
              SF
            </div>
            <div>
              <span className="text-sm sm:text-base font-extrabold tracking-tight text-neutral-900 block leading-tight">
                Sfiller
              </span>
              <span className="text-[10px] text-neutral-500 font-medium hidden sm:block">
                Sabbiatura & Verniciatura
              </span>
            </div>
          </button>
        )}

        {/* Indicator Pixel 9 */}
        <span className="hidden lg:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-neutral-100 text-[10px] font-mono text-neutral-600 border border-neutral-200">
          <Smartphone className="w-3 h-3 text-neutral-700" />
          <span>Pixel 9 Ready</span>
        </span>
      </div>

      {/* Center Navigation (Desktop): Concise links */}
      <nav className="hidden md:flex items-center gap-5 text-xs font-semibold text-neutral-600">
        <button
          onClick={() => onSelectView('menu')}
          className={`hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
            activeView === 'menu' ? 'text-neutral-900 font-bold border-b-2 border-neutral-900' : ''
          }`}
        >
          <Home className="w-3.5 h-3.5" />
          <span>Menù Hub</span>
        </button>

        <button
          onClick={() => onSelectView('painting')}
          className={`hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
            activeView === 'painting' ? 'text-neutral-900 font-bold border-b-2 border-neutral-900' : ''
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Painting Reports</span>
        </button>

        <button
          onClick={() => onSelectView('manutenzioni')}
          className={`hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
            activeView === 'manutenzioni' ? 'text-neutral-900 font-bold border-b-2 border-neutral-900' : ''
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          <span>Manutenzioni</span>
        </button>

        <button
          onClick={() => onSelectView('procedure')}
          className={`hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
            activeView === 'procedure' ? 'text-neutral-900 font-bold border-b-2 border-neutral-900' : ''
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Schede Libere</span>
        </button>

        <button
          onClick={() => onSelectView('galleria')}
          className={`hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
            activeView === 'galleria' ? 'text-neutral-900 font-bold border-b-2 border-neutral-900' : ''
          }`}
        >
          <Images className="w-3.5 h-3.5" />
          <span>Foto</span>
        </button>
      </nav>

      {/* Right Area: Pixel 9 Simulator Toggle & Quick Actions */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Toggle Pixel 9 View Frame on desktop */}
        <button
          onClick={onTogglePixel9Preview}
          title={isPixel9Preview ? 'Disattiva anteprima Pixel 9 (Schermo intero)' : 'Simula Schermo Google Pixel 9 (412x924)'}
          className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-xl font-mono font-bold transition-all border ${
            isPixel9Preview
              ? 'bg-amber-100 text-amber-900 border-amber-300 shadow-xs'
              : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border-neutral-200'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Simulatore Pixel 9</span>
          <span className="md:hidden">Pixel 9</span>
        </button>

        {/* View-specific New Actions */}
        {activeView === 'painting' && (
          <button
            onClick={onNewPaintingReport}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-neutral-900 rounded-xl hover:bg-neutral-800 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nuovo Report</span>
            <span className="sm:hidden">Nuovo</span>
          </button>
        )}

        {activeView === 'manutenzioni' && (
          <button
            onClick={onNewMaintenance}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-neutral-900 rounded-xl hover:bg-neutral-800 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nuova Manutenzione</span>
            <span className="sm:hidden">Nuova</span>
          </button>
        )}

        {activeView === 'procedure' && (
          <button
            onClick={onNewProcedure}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-neutral-900 rounded-xl hover:bg-neutral-800 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nuova Scheda</span>
            <span className="sm:hidden">Nuova</span>
          </button>
        )}

        {activeView === 'menu' && (
          <button
            onClick={onOpenBackup}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors border border-neutral-200"
          >
            <Database className="w-3.5 h-3.5 text-neutral-600" />
            <span className="hidden sm:inline">Dati & Backup</span>
            <span className="sm:hidden">Dati</span>
          </button>
        )}
      </div>
    </header>
  );
};
