import React from 'react';
import { Clock, Settings } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  return (
    <header className="flex items-center justify-between pb-3 pt-1">
      <div className="flex items-center gap-3">
        {/* Blue Circular Clock Icon container */}
        <div className="w-11 h-11 rounded-full bg-[#e3edfc] flex items-center justify-center text-[#2563eb] shadow-xs">
          <Clock className="w-6 h-6 stroke-[2.2]" />
        </div>
        
        {/* Title & Subtitle */}
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight leading-tight">
            Time Converter
          </h1>
          <p className="text-xs font-normal text-slate-500">
            New York ⇄ India (IST)
          </p>
        </div>
      </div>

      {/* Settings Icon */}
      <button
        type="button"
        onClick={onOpenSettings}
        className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-colors active:scale-95"
        aria-label="Settings"
      >
        <Settings className="w-5 h-5 stroke-[1.8]" />
      </button>
    </header>
  );
};
