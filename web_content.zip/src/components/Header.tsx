import React from 'react';
import { useApp, MainPillar } from '../context/AppContext';
import { ShoppingBag, ChevronDown, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentPillar,
    setCurrentPillar,
    cart,
    setIsCartOpen,
    currentUser,
    switchUser,
    availableUsers,
    walletBalance,
  } = useApp();

  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const pillars: { id: MainPillar; label: string }[] = [
    { id: 'communication', label: 'Communication & Calls' },
    { id: 'ecommerce', label: 'E-Commerce & Orders' },
    { id: 'education', label: 'School Education Hub' },
    { id: 'office', label: 'Office & Management' },
    { id: 'wallet', label: 'Earnings & Gigs' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single element) */}
        <div className="flex items-center gap-3 shrink-0">
          <img
            src="/assets/aistudio/1793372617949_97205839.jpg"
            alt="Make friend Crest"
            className="w-9 h-9 rounded-lg object-cover shadow-xs border border-slate-200"
          />
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            Make friend
          </span>
        </div>

        {/* Zone 2: 4 Primary Nav Links (Single line, text-only with active underline) */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          {pillars.map((pillar) => {
            const isActive = currentPillar === pillar.id;
            return (
              <button
                key={pillar.id}
                onClick={() => setCurrentPillar(pillar.id)}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                  isActive
                    ? 'text-indigo-600 font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {pillar.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 -mb-5" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action Area (Cart + Persona Selector) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Quick Wallet Link */}
          <button
            onClick={() => setCurrentPillar('wallet')}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors"
            title="View Campus Wallet & Gigs"
          >
            <span>${walletBalance.toFixed(2)}</span>
          </button>

          {/* Cart Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            title="Open Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {totalCartItems > 0 && (
              <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[11px] font-bold rounded-full h-5 w-5 flex items-center justify-center shadow-sm">
                {totalCartItems}
              </span>
            )}
          </button>

          {/* User Persona Switcher */}
          <div className="relative group">
            <button className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-white transition-all text-left">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-full object-cover border border-slate-200"
              />
              <div className="hidden sm:block text-left">
                <div className="text-xs font-semibold text-slate-900 truncate max-w-[120px]">
                  {currentUser.name}
                </div>
                <div className="text-[11px] text-slate-500 truncate max-w-[120px]">
                  {currentUser.title}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600" />
            </button>

            {/* Dropdown Menu */}
            <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 hidden group-hover:block hover:block z-50">
              <div className="px-3 py-2 border-b border-slate-100 text-xs text-slate-400 font-medium">
                Switch Role Persona
              </div>
              {availableUsers.map((user) => (
                <button
                  key={user.id}
                  onClick={() => switchUser(user.id)}
                  className={`w-full text-left px-3 py-2 flex items-center gap-2.5 text-xs hover:bg-slate-50 transition-colors ${
                    currentUser.id === user.id ? 'bg-indigo-50/60 font-medium text-indigo-900' : 'text-slate-700'
                  }`}
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-full object-cover"
                  />
                  <div className="truncate">
                    <div className="font-semibold text-slate-900 truncate">{user.name}</div>
                    <div className="text-[11px] text-slate-500 truncate">{user.title}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex overflow-x-auto border-t border-slate-200 px-4 py-2 gap-4 text-xs font-medium bg-slate-50">
        {pillars.map((pillar) => (
          <button
            key={pillar.id}
            onClick={() => setCurrentPillar(pillar.id)}
            className={`whitespace-nowrap shrink-0 py-1 px-2 rounded-md ${
              currentPillar === pillar.id
                ? 'bg-indigo-600 text-white font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {pillar.label}
          </button>
        ))}
      </div>
    </header>
  );
};
