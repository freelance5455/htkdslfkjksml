import React from 'react';
import { Camera, Crown } from 'lucide-react';
import { TierLevel } from '../types';
import { TIERS_CONFIG } from '../data/tiers';

interface HeaderProps {
  currentTier: TierLevel;
  activeTab: 'dashboard' | 'tiers' | 'analytics' | 'coach';
  setActiveTab: (tab: 'dashboard' | 'tiers' | 'analytics' | 'coach') => void;
  onOpenScanModal: () => void;
  onOpenPaywall: () => void;
  isDirectlySubscribed: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTier,
  activeTab,
  setActiveTab,
  onOpenScanModal,
  onOpenPaywall,
  isDirectlySubscribed,
}) => {
  const tierConfig = TIERS_CONFIG[currentTier];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-md shadow-emerald-500/10">
            <span className="text-lg">🥑</span>
          </div>
          <button
            onClick={() => setActiveTab('dashboard')}
            className="text-left cursor-pointer focus:outline-none"
          >
            <div className="text-lg font-black tracking-tight text-white flex items-center gap-1.5 font-sans">
              <span>Cal AI</span>
              <span className="text-xs px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-400 font-semibold border border-emerald-500/20">
                PRO
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'dashboard'
                ? 'text-emerald-400 font-bold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            الرئيسية واليوميات
          </button>

          <button
            onClick={() => setActiveTab('tiers')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 flex items-center gap-1.5 ${
              activeTab === 'tiers'
                ? 'text-emerald-400 font-bold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <span>نظام المستويات والدعوات</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-mono">
              L{currentTier}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'analytics'
                ? 'text-emerald-400 font-bold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            المغذيات والتنبؤ
          </button>

          <button
            onClick={() => setActiveTab('coach')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'coach'
                ? 'text-emerald-400 font-bold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            موجه الذكاء الاصطناعي
          </button>
        </nav>

        {/* Zone 3: Primary Action & Tier Indicator */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Tier badge trigger */}
          <button
            onClick={() => {
              if (currentTier < 3) {
                onOpenPaywall();
              } else {
                setActiveTab('tiers');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
            title="عرض نظام المستويات والدعوات"
          >
            <span>{tierConfig.badge}</span>
            <span className="hidden sm:inline">{tierConfig.nameAr.split(':')[0]}</span>
            {isDirectlySubscribed ? (
              <Crown className="w-3.5 h-3.5 text-amber-400" />
            ) : null}
          </button>

          {/* Primary Quick Scan CTA */}
          <button
            onClick={onOpenScanModal}
            className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer shadow-md shadow-emerald-500/20"
          >
            <Camera className="w-4 h-4" />
            <span>مسح وجبة</span>
          </button>
        </div>
      </div>
    </header>
  );
};
