/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Check, Edit3, RotateCcw, Smartphone } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle?: string;
  isEditMode?: boolean;
  onToggleEditMode?: () => void;
  showEditButton?: boolean;
  onBack?: () => void;
  showResetButton?: boolean;
  onReset?: () => void;
  onOpenApkGuide?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  isEditMode = false,
  onToggleEditMode,
  showEditButton = true,
  onBack,
  showResetButton = false,
  onReset,
  onOpenApkGuide,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white shadow-md transition-colors duration-200">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        {/* Left Section: Back button or Title */}
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              aria-label="পেছনে যান"
              className="p-2 -ml-2 rounded-full hover:bg-slate-800 active:bg-slate-700 transition-colors text-slate-200 hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div className="truncate">
            <h1 className="text-lg font-bold tracking-tight text-white truncate flex items-center gap-2">
              {isEditMode ? (
                <span className="text-amber-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  এডিট মোড
                </span>
              ) : (
                title
              )}
            </h1>
            {subtitle && !isEditMode && (
              <p className="text-xs text-slate-400 truncate">{subtitle}</p>
            )}
          </div>
        </div>

        {/* Right Section: Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {/* APK Guide Button */}
          {onOpenApkGuide && (
            <button
              type="button"
              onClick={onOpenApkGuide}
              aria-label="APK তৈরির নিয়মাবলী"
              title="APK ইনস্টল নির্দেশিকা"
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 transition-colors active:scale-95 text-xs flex items-center gap-1"
            >
              <Smartphone className="w-4 h-4" />
              <span className="hidden sm:inline font-medium">APK</span>
            </button>
          )}

          {/* Reset Button (e.g. inside Work group) */}
          {showResetButton && onReset && (
            <button
              type="button"
              onClick={onReset}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 hover:text-rose-200 text-xs font-semibold flex items-center gap-1 active:scale-95 transition-all border border-slate-700/60"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>রিসেট</span>
            </button>
          )}

          {/* Edit / Done Button */}
          {showEditButton && onToggleEditMode && (
            <button
              type="button"
              onClick={onToggleEditMode}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 active:scale-95 transition-all ${
                isEditMode
                  ? 'bg-amber-400 hover:bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
              }`}
            >
              {isEditMode ? (
                <>
                  <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>সম্পন্ন</span>
                </>
              ) : (
                <>
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>এডিট</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
