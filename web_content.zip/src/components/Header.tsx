import React from 'react';
import {
  Heart,
  MessageCircleHeart,
  BookMarked,
  Moon,
  Sun,
  User,
  Globe,
  Users,
  Sparkles,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SpaceType, UserProfile } from '../types/index.ts';
import { supportedLanguages, changeAppLanguage } from '../i18n/index.ts';

interface HeaderProps {
  currentSpace: SpaceType;
  onSelectSpace: (space: SpaceType) => void;
  onOpenChat: () => void;
  onOpenHistory: () => void;
  onOpenAuth: () => void;
  userProfile: UserProfile | null;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentSpace,
  onSelectSpace,
  onOpenChat,
  onOpenHistory,
  onOpenAuth,
  userProfile,
  isDarkMode,
  onToggleDarkMode,
}) => {
  const { t, i18n } = useTranslation();

  return (
    <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-rose-100/80 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5 flex items-center justify-between gap-3">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 via-rose-400 to-amber-300 text-white flex items-center justify-center shadow-md shadow-rose-200 dark:shadow-none shrink-0">
            <Heart className="w-5 h-5 fill-current" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100 tracking-tight">
                {t('app.name')}
              </span>
              <span className="hidden sm:inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 dark:bg-slate-800 dark:text-rose-300 border border-rose-100 dark:border-slate-700">
                Thérapeutique
              </span>
            </div>
            <p className="hidden md:block text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {t('app.subtitle')}
            </p>
          </div>
        </div>

        {/* Space Navigation Switcher Tabs (Adult vs Parents) */}
        <nav aria-label="Espaces de régulation" className="flex items-center p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <button
            onClick={() => onSelectSpace('adult')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentSpace === 'adult'
                ? 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('nav.adultSpace')}</span>
          </button>

          <button
            onClick={() => onSelectSpace('parents')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentSpace === 'parents'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{t('nav.parentsSpace')}</span>
          </button>
        </nav>

        {/* Right utility buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* AI Therapist Chat Button */}
          <button
            onClick={onOpenChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-teal-500 hover:from-rose-600 hover:to-teal-600 text-white font-bold text-xs shadow-sm transition-all"
            title={t('nav.therapistChat')}
          >
            <MessageCircleHeart className="w-4 h-4" />
            <span className="hidden sm:inline">{t('nav.therapistChat')}</span>
          </button>

          {/* History / Journal */}
          <button
            onClick={onOpenHistory}
            className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 font-semibold text-xs transition-colors flex items-center gap-1"
            title={t('nav.mySessions')}
          >
            <BookMarked className="w-4 h-4 text-slate-500" />
            <span className="hidden md:inline">{t('nav.mySessions')}</span>
          </button>

          {/* Language Selector Dropdown */}
          <div className="relative flex items-center">
            <select
              value={i18n.language.substring(0, 2)}
              onChange={(e) => changeAppLanguage(e.target.value)}
              className="text-xs font-semibold pl-2 pr-4 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none"
              title={t('nav.language')}
            >
              {supportedLanguages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.flag} {lang.code.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition-colors"
            title={isDarkMode ? t('nav.lightMode') : t('nav.darkMode')}
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-500" />}
          </button>

          {/* User Account / Profile */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 text-xs font-semibold transition-colors"
            title={userProfile?.fullName || 'Compte / Invité'}
          >
            <div className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 flex items-center justify-center">
              <User className="w-3 h-3" />
            </div>
            <span className="hidden lg:inline">
              {userProfile ? (userProfile.fullName || 'Mon Compte') : t('nav.guestBadge')}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
