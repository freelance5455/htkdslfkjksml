import React from 'react';
import { StoreSettings, AppLanguage } from '../types';
import { Phone, MessageCircle, ShoppingBag, ShieldCheck, Globe, MapPin, Sparkles } from 'lucide-react';
import { formatPKR } from '../utils/storage';

interface HeaderProps {
  settings: StoreSettings;
  language: AppLanguage;
  onLanguageToggle: () => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  language,
  onLanguageToggle,
  cartCount,
  cartTotal,
  onOpenCart,
  onOpenAdmin
}) => {
  const isUrdu = language === 'ur';

  return (
    <header className="sticky top-0 z-30 bg-emerald-800 text-white shadow-md border-b border-emerald-900/40">
      {/* Top Village Delivery Ticker */}
      <div className="bg-emerald-950 px-3 py-1 text-xs flex items-center justify-between text-emerald-200">
        <div className="flex items-center gap-1.5 overflow-hidden text-ellipsis whitespace-nowrap">
          <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="font-medium text-[11px] truncate">
            {isUrdu 
              ? "ہمارا گاؤں اور تمام قریبی دیہات کے لیے ہوم ڈیلیوری | محمد اویس بلال"
              : "Home Delivery in Village & Surrounding Areas | Owais Bilal"}
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onLanguageToggle}
            className="flex items-center gap-1 bg-emerald-900/80 hover:bg-emerald-800 px-2 py-0.5 rounded text-[11px] border border-emerald-700/60 font-semibold text-emerald-100 transition active:scale-95"
            title="زبان تبدیل کریں / Change Language"
          >
            <Globe className="w-3 h-3 text-emerald-300" />
            <span>{isUrdu ? 'English' : 'اردو'}</span>
          </button>
          <button
            onClick={onOpenAdmin}
            className="flex items-center gap-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 px-2 py-0.5 rounded text-[11px] border border-amber-500/40 font-medium transition active:scale-95"
            title="ایڈمن پینل (برائے محمد اویس بلال)"
          >
            <ShieldCheck className="w-3 h-3 text-amber-400" />
            <span>{isUrdu ? 'ایڈمن' : 'Admin'}</span>
          </button>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Owner Name */}
        <div className="flex items-center gap-2.5">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-emerald-950 font-black shadow-inner shadow-amber-200 text-lg border-2 border-amber-300 shrink-0">
            <span>اویس</span>
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold leading-tight tracking-tight text-white flex items-center gap-1.5">
              <span>{isUrdu ? settings.storeUrduName : settings.storeName}</span>
            </h1>
            <div className="flex items-center gap-2 text-xs text-emerald-100/90 mt-0.5">
              <span className="font-semibold text-amber-300">
                {isUrdu ? "پروپرائیٹر:" : "Prop:"} {settings.ownerName}
              </span>
              <span className="hidden sm:inline text-emerald-400">•</span>
              <span className="font-mono text-emerald-200 bg-emerald-900/60 px-1.5 py-0.2 rounded text-[11px]">
                {settings.phone}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons: Direct WhatsApp Call & Cart */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick WhatsApp Contact Button */}
          <a
            href={`https://wa.me/92${settings.whatsappNumber.replace(/\D/g, '').replace(/^0/, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden xs:flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-emerald-50 border border-emerald-600 shadow-sm transition active:scale-95"
            title="اویس بلال سے واٹس ایپ پر بات کریں"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-300 fill-emerald-300" />
            <span className="text-[11px] font-medium">{isUrdu ? 'واٹس ایپ' : 'WhatsApp'}</span>
          </a>

          {/* Quick Phone Call Button */}
          <a
            href={`tel:${settings.phone}`}
            className="flex items-center gap-1 bg-emerald-700/80 hover:bg-emerald-600 p-2 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-semibold text-emerald-50 border border-emerald-600 shadow-sm transition active:scale-95"
            title="اویس بلال کو فون کریں"
          >
            <Phone className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline text-[11px]">{settings.phone}</span>
          </a>

          {/* Cart Button with Badge */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-emerald-950 font-bold px-3 py-1.5 sm:py-2 rounded-xl shadow-md transition transform active:scale-95"
            aria-label="کھولیں کارٹ"
          >
            <ShoppingBag className="w-4 h-4 text-emerald-950" />
            <div className="flex flex-col text-left leading-none">
              <span className="text-[10px] uppercase font-bold text-emerald-900">
                {isUrdu ? 'تھیلا' : 'Cart'}
              </span>
              <span className="text-xs font-extrabold text-emerald-950">
                {cartCount > 0 ? formatPKR(cartTotal, false) : '0'}
              </span>
            </div>
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white font-black text-[11px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-emerald-800 animate-pulse">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Announcement bar */}
      <div className="bg-emerald-700/70 border-t border-emerald-700/50 px-3 py-1 text-center text-xs text-emerald-50">
        <div className="flex items-center justify-center gap-1.5 max-w-4xl mx-auto truncate">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
          <span className="truncate">
            {isUrdu ? settings.announcementUrdu : settings.announcement}
          </span>
        </div>
      </div>
    </header>
  );
};
