import React, { useState } from 'react';
import { X, Plus, Check } from 'lucide-react';
import { Playlist } from '../../types';

interface AddToPlaylistModalProps {
  playlists: Playlist[];
  onClose: () => void;
  onSelectPlaylist: (playlistId: string) => void;
  onCreatePlaylist: (name: string) => void;
}

export const AddToPlaylistModal: React.FC<AddToPlaylistModalProps> = ({
  playlists,
  onClose,
  onSelectPlaylist,
  onCreatePlaylist,
}) => {
  const [showNew, setShowNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onCreatePlaylist(newTitle.trim());
    setNewTitle('');
    setShowNew(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-[#12181F] border border-slate-700 rounded-2xl p-5 shadow-2xl animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-base font-bold text-slate-100">Add to Playlist</h3>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg"
          >
            <X size={20} />
          </button>
        </div>

        {!showNew ? (
          <div className="mt-4 space-y-3">
            <button
              onClick={() => setShowNew(true)}
              className="flex items-center gap-2 w-full p-2.5 rounded-xl border border-dashed border-emerald-500/40 text-emerald-400 hover:bg-emerald-950/30 text-xs font-semibold transition-colors"
            >
              <Plus size={16} />
              <span>Create New Playlist</span>
            </button>

            <div className="max-h-60 overflow-y-auto space-y-1 pr-1">
              {playlists.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-4">
                  No playlists yet. Create one above!
                </p>
              ) : (
                playlists.map((pl) => (
                  <button
                    key={pl.id}
                    onClick={() => {
                      onSelectPlaylist(pl.id);
                      onClose();
                    }}
                    className="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-slate-800/60 text-left transition-colors"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-200">
                        {pl.name}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {pl.songIds.length} tracks
                      </p>
                    </div>
                    <span className="text-xs text-emerald-400 font-medium">Add</span>
                  </button>
                ))
              )}
            </div>
          </div>
        ) : (
          <form onSubmit={handleCreate} className="space-y-4 mt-4">
            <div>
              <label className="text-xs font-medium text-slate-400">
                New Playlist Name
              </label>
              <input
                type="text"
                autoFocus
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g., Night Drive"
                className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowNew(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200"
              >
                Back
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
              >
                Create & Add
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
