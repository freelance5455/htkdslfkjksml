import React, { useState } from 'react';
import { X, Upload, Trash2 } from 'lucide-react';
import { Song } from '../../types';
import { ArtworkImage } from '../ArtworkImage';

interface EditMetadataModalProps {
  song: Song;
  onClose: () => void;
  onSave: (updated: Partial<Song>) => void;
}

export const EditMetadataModal: React.FC<EditMetadataModalProps> = ({
  song,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState(song.title);
  const [artist, setArtist] = useState(song.artist);
  const [album, setAlbum] = useState(song.album);
  const [genre, setGenre] = useState(song.genre);
  const [year, setYear] = useState(song.year?.toString() || '');
  const [artworkUrl, setArtworkUrl] = useState(song.artworkUrl || '');

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setArtworkUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title: title.trim() || 'Untitled',
      artist: artist.trim() || 'Unknown Artist',
      album: album.trim() || 'Unknown Album',
      genre: genre.trim(),
      year: year ? parseInt(year, 10) : undefined,
      artworkUrl: artworkUrl || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#12181F] border border-slate-700 rounded-2xl p-6 shadow-2xl animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-base font-bold text-slate-100">Edit Song Metadata</h3>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Artwork Preview & Upload */}
          <div className="flex items-center gap-4">
            <ArtworkImage
              artworkUrl={artworkUrl}
              alt={title}
              className="w-20 h-20 rounded-xl"
              iconSize={28}
            />
            <div className="space-y-2">
              <label className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-emerald-500 text-xs font-semibold text-slate-200 cursor-pointer transition-colors">
                <Upload size={14} />
                <span>Change Artwork</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </label>
              {artworkUrl && (
                <button
                  type="button"
                  onClick={() => setArtworkUrl('')}
                  className="flex items-center gap-1.5 text-xs text-rose-400 hover:underline"
                >
                  <Trash2 size={13} />
                  <span>Remove Artwork</span>
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400">Song Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400">Artist</label>
            <input
              type="text"
              required
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400">Album</label>
            <input
              type="text"
              value={album}
              onChange={(e) => setAlbum(e.target.value)}
              className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-400">Genre</label>
              <input
                type="text"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                placeholder="e.g., Chillhop"
                className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400">Year</label>
              <input
                type="number"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                placeholder="2026"
                className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
