import React from 'react';
import { X, Moon, Clock, StopCircle } from 'lucide-react';

interface SleepTimerModalProps {
  currentTimerMinutes: number | null;
  onClose: () => void;
  onSetTimer: (minutes: number) => void;
  onCancelTimer: () => void;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({
  currentTimerMinutes,
  onClose,
  onSetTimer,
  onCancelTimer,
}) => {
  const options = [10, 15, 30, 45, 60, 90];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-xs bg-[#12181F] border border-slate-700 rounded-2xl p-5 shadow-2xl animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-emerald-400">
            <Moon size={18} />
            <h3 className="text-base font-bold text-slate-100">Sleep Timer</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg"
          >
            <X size={20} />
          </button>
        </div>

        <div className="py-4 space-y-2">
          {options.map((mins) => (
            <button
              key={mins}
              onClick={() => {
                onSetTimer(mins);
                onClose();
              }}
              className="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-slate-800/80 text-xs font-semibold text-slate-200 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Clock size={15} className="text-slate-400" />
                <span>{mins} minutes</span>
              </div>
              {currentTimerMinutes === mins && (
                <span className="text-emerald-400 text-[11px] font-bold">Active</span>
              )}
            </button>
          ))}
        </div>

        {currentTimerMinutes !== null && (
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                onCancelTimer();
                onClose();
              }}
              className="flex items-center justify-center gap-2 w-full py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/40 text-rose-300 font-bold text-xs transition-colors"
            >
              <StopCircle size={15} />
              <span>Turn Off Timer</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
