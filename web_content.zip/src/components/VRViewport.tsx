import React, { useEffect, useImperativeHandle, useRef } from 'react';
import * as THREE from 'three';
import {
  clampPitchRadians,
  computeStereoViewports,
  createInitialGazeState,
  deviceOrientationToQuaternion,
  shortestAngleDiffRadians,
  stepGaze,
} from '../vr/gazeEngine';
import {
  applyKeyboardKey,
  BrowserState,
  CINEMA_MOVIES,
  CINEMA_SCREEN_OPTIONS,
  CinemaScreenSize,
  clampScrollOffset,
  clampVolume,
  createBuiltinGalleryItems,
  createInitialBrowserState,
  CURATED_WEBSITES,
  cycleCinemaScreenSize,
  cycleGalleryFilter,
  cycleIndex,
  cycleTheaterLightMode,
  ENVIRONMENT_OPTIONS,
  filterGalleryItems,
  formatPlaybackTime,
  formatVolumePercent,
  GalleryItem,
  GalleryViewState,
  getNextGalleryItem,
  isBookmarkSaved,
  mapBrowserUvToGazeId,
  mapGalleryUvToGazeId,
  MediaFileKind,
  persistSavedBookmarks,
  resolveBrowserInput,
  SceneEnvironmentId,
  stepVolume,
  THEATER_LIGHT_OPTIONS,
  TheaterLightMode,
  toggleBookmark,
  VIDEO_360_SCENES,
  Video360Projection,
  VRMode,
} from '../vr/vrState';
import {
  Procedural360Renderer,
  ProceduralCinemaRenderer,
  SpatialAudioEngine,
} from '../vr/proceduralMedia';
import { BrowserScreenRenderer } from '../vr/browserCanvas';
import { GalleryScreenRenderer } from '../vr/galleryCanvas';
import { buildVRScene, VRSceneBundle } from '../vr/sceneBuilder';

export interface VRViewportHandle {
  setMode: (mode: VRMode) => void;
  setEnvironment: (envId: SceneEnvironmentId) => void;
  recenter: () => void;
  loadVideoSource: (
    target: '360' | 'cinema',
    src: string,
    label: string,
    projection?: Video360Projection,
    kind?: MediaFileKind
  ) => void;
  triggerBrowserSearch: (query: string) => Promise<void>;
  openBrowserTarget: (input: string) => Promise<void>;
  enableGyro: () => Promise<boolean>;
  lookAtAngles: (yawDeg: number, pitchDeg: number) => void;
}

interface VRViewportProps {
  mode: VRMode;
  stereo: boolean;
  environment?: SceneEnvironmentId;
  ipdMm: number;
  dwellMs: number;
  galleryItems: GalleryItem[];
  onModeChange: (mode: VRMode) => void;
  onEnvironmentChange?: (envId: SceneEnvironmentId) => void;
  onBrowserUrlChange?: (url: string) => void;
  onStereoToggle: () => void;
  onDwellCycle: () => void;
  onOpenGalleryPicker: () => void;
  onGazeUpdate: (hoveredId: string | null, progress: number) => void;
  onGyroStateChange: (enabled: boolean) => void;
  onStatusInfo: (info: string) => void;
}

const _rayOrigin = new THREE.Vector2(0, 0);
const _upAxis = new THREE.Vector3(0, 1, 0);
const _euler = new THREE.Euler(0, 0, 0, 'YXZ');
const _tempEuler = new THREE.Euler(0, 0, 0, 'YXZ');
const _gyroQuat = new THREE.Quaternion();
const _recenterQuat = new THREE.Quaternion();
const _targetQuat = new THREE.Quaternion();

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export const VRViewport = React.forwardRef<VRViewportHandle, VRViewportProps>(
  (
    {
      mode,
      stereo,
      environment = 'observatory',
      ipdMm,
      dwellMs,
      galleryItems,
      onModeChange,
      onEnvironmentChange,
      onBrowserUrlChange,
      onStereoToggle,
      onDwellCycle,
      onOpenGalleryPicker,
      onGazeUpdate,
      onGyroStateChange,
      onStatusInfo,
    },
    ref
  ) => {
    const mountRef = useRef<HTMLDivElement | null>(null);

    // Keep latest props in refs so WebGL scene never tears down on React updates
    const stateRef = useRef({
      mode,
      stereo,
      environment,
      ipdMm,
      dwellMs,
      galleryItems,
      onModeChange,
      onEnvironmentChange,
      onBrowserUrlChange,
      onStereoToggle,
      onDwellCycle,
      onOpenGalleryPicker,
      onGazeUpdate,
      onGyroStateChange,
      onStatusInfo,
    });
    stateRef.current = {
      mode,
      stereo,
      environment,
      ipdMm,
      dwellMs,
      galleryItems,
      onModeChange,
      onEnvironmentChange,
      onBrowserUrlChange,
      onStereoToggle,
      onDwellCycle,
      onOpenGalleryPicker,
      onGazeUpdate,
      onGyroStateChange,
      onStatusInfo,
    };

    // Mutable simulation & playback state inside Three.js loop
    const simRef = useRef({
      yaw: 0,
      pitch: 0.18,
      targetYaw: 0,
      targetPitch: 0.18,
      isDragging: false,
      lastPointerX: 0,
      lastPointerY: 0,
      keys: {} as Record<string, boolean>,
      gyroActive: false,
      gyroHasData: false,
      gyroRawQuat: new THREE.Quaternion(),
      gyroYawOffset: 0,
      gaze: createInitialGazeState(dwellMs),
      lastHoveredId: null as string | null,
      environment: environment as SceneEnvironmentId,
      player360Idx: 0,
      player360Playing: true,
      player360Time: 0,
      player360CustomLabel: null as string | null,
      player360Projection: '360-mono' as Video360Projection,
      cinemaIdx: 0,
      cinemaPlaying: true,
      cinemaTime: 0,
      cinemaCustomLabel: null as string | null,
      cinemaLightMode: 'cinematic' as TheaterLightMode,
      cinemaScreenSize: 'imax' as CinemaScreenSize,
      muted: false,
      volume: 0.8,
      browser: createInitialBrowserState(),
      gallery: {
        items: createBuiltinGalleryItems(),
        filter: 'all',
        folderFilter: 'all',
        scrollOffset: 0,
        preferredTarget: 'auto',
        hoveredSlot: null,
      } as GalleryViewState,
      activeMediaTarget: null as '360' | 'cinema' | null,
      activeMediaKind: 'video' as MediaFileKind,
      activeGalleryItemUrl: null as string | null,
      videoElement: null as HTMLVideoElement | null,
      videoTexture: null as THREE.VideoTexture | null,
      imageTexture: null as THREE.Texture | null,
    });

    const sceneBundleRef = useRef<VRSceneBundle | null>(null);
    const browserCanvasRef = useRef<BrowserScreenRenderer | null>(null);
    const galleryCanvasRef = useRef<GalleryScreenRenderer | null>(null);
    const audioRef = useRef<SpatialAudioEngine | null>(null);

    const syncAudioVolume = () => {
      const sim = simRef.current;
      const bundle = sceneBundleRef.current;
      const audio = audioRef.current;
      const isEffectivelyMuted = sim.muted || sim.volume <= 0;

      if (audio) {
        audio.muted = sim.muted;
        audio.setVolume(sim.volume);
      }
      if (sim.videoElement) {
        sim.videoElement.volume = sim.volume;
        sim.videoElement.muted = isEffectivelyMuted;
      }
      bundle?.updateVolumeSliders(sim.volume, sim.muted);
      const muteLabel = isEffectivelyMuted ? 'icon:volume-off' : 'icon:volume-on';
      bundle?.updateButtonLabel('360:mute', muteLabel);
      bundle?.updateButtonLabel('cinema:mute', muteLabel);
    };

    const activateMediaSource = (
      target: '360' | 'cinema',
      src: string,
      label: string,
      projection?: Video360Projection,
      kind: MediaFileKind = 'video'
    ) => {
      const sim = simRef.current;
      const bundle = sceneBundleRef.current;
      if (!bundle) return;

      sim.activeMediaTarget = target;
      sim.activeMediaKind = kind;
      sim.activeGalleryItemUrl = src;

      if (kind === 'image') {
        if (sim.videoElement && !sim.videoElement.paused) {
          sim.videoElement.pause();
        }
        const img = new Image();
        if (/^https?:\/\//i.test(src)) {
          img.crossOrigin = 'anonymous';
        }
        img.onload = () => {
          sim.imageTexture?.dispose();
          let tex: THREE.Texture;
          if (target === 'cinema') {
            const fitCanvas = document.createElement('canvas');
            fitCanvas.width = 1280;
            fitCanvas.height = 720;
            const ctx = fitCanvas.getContext('2d');
            if (ctx) {
              ctx.fillStyle = '#060911';
              ctx.fillRect(0, 0, fitCanvas.width, fitCanvas.height);
              const scale = Math.min(
                fitCanvas.width / Math.max(1, img.width),
                fitCanvas.height / Math.max(1, img.height)
              );
              const dw = img.width * scale;
              const dh = img.height * scale;
              ctx.drawImage(
                img,
                (fitCanvas.width - dw) / 2,
                (fitCanvas.height - dh) / 2,
                dw,
                dh
              );
              tex = new THREE.CanvasTexture(fitCanvas);
            } else {
              tex = new THREE.Texture(img);
            }
          } else {
            tex = new THREE.Texture(img);
          }
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.minFilter = THREE.LinearFilter;
          tex.magFilter = THREE.LinearFilter;
          tex.needsUpdate = true;
          sim.imageTexture = tex;

          if (target === '360') {
            bundle.set360Texture(tex);
          } else {
            bundle.cinemaScreenMat.map = tex;
            bundle.cinemaScreenMat.needsUpdate = true;
          }
        };
        img.src = src;

        if (target === '360') {
          sim.player360CustomLabel = `صورة: ${label}`;
          sim.player360Playing = false;
          if (projection) {
            sim.player360Projection = projection;
            bundle.set360Projection(projection);
          }
          stateRef.current.onModeChange('player360');
        } else {
          sim.cinemaCustomLabel = `صورة: ${label}`;
          sim.cinemaPlaying = false;
          stateRef.current.onModeChange('cinema');
        }
        return;
      }

      if (!sim.videoElement) return;
      if (/^https?:\/\//i.test(src)) {
        sim.videoElement.crossOrigin = 'anonymous';
      } else {
        sim.videoElement.removeAttribute('crossorigin');
      }
      sim.videoElement.src = src;
      sim.videoElement.load();
      sim.videoElement.play().catch(() => {});

      if (!sim.videoTexture) {
        const vTex = new THREE.VideoTexture(sim.videoElement);
        vTex.colorSpace = THREE.SRGBColorSpace;
        vTex.minFilter = THREE.LinearFilter;
        vTex.magFilter = THREE.LinearFilter;
        sim.videoTexture = vTex;
      }

      if (target === '360') {
        sim.player360CustomLabel = label;
        sim.player360Playing = true;
        if (projection) {
          sim.player360Projection = projection;
          bundle.set360Projection(projection);
        }
        bundle.set360Texture(sim.videoTexture);
        stateRef.current.onModeChange('player360');
      } else {
        sim.cinemaCustomLabel = label;
        sim.cinemaPlaying = true;
        bundle.cinemaScreenMat.map = sim.videoTexture;
        bundle.cinemaScreenMat.needsUpdate = true;
        stateRef.current.onModeChange('cinema');
      }
    };

    const runBrowserSearch = async (rawQuery: string) => {
      const q = rawQuery.trim();
      if (!q) return;

      const resolved = resolveBrowserInput(q);
      if (resolved.type === 'url') {
        await openBrowserPage(resolved.url);
        return;
      }

      const sim = simRef.current;
      sim.browser = {
        ...sim.browser,
        query: q,
        inputText: q,
        view: 'results',
        loading: true,
        scrollOffset: 0,
        history: [
          ...sim.browser.history,
          {
            view: sim.browser.view,
            query: sim.browser.query,
            results: sim.browser.results,
            currentPage: sim.browser.currentPage,
          },
        ],
      };
      browserCanvasRef.current?.render(sim.browser);

      try {
        const res = await fetch(`/api/browser/search?q=${encodeURIComponent(q)}`);
        const data = (await res.json()) as { results?: BrowserState['results'] };
        sim.browser = {
          ...sim.browser,
          loading: false,
          results: data.results ?? [],
        };
      } catch {
        sim.browser = {
          ...sim.browser,
          loading: false,
          results: [
            {
              id: 'offline-1',
              title: `نتائج البحث: ${q}`,
              url: `https://ar.wikipedia.org/wiki/${encodeURIComponent(q)}`,
              snippet: 'تعذر الوصول للخادم، يمكنك المحاولة مرة أخرى.',
              domain: 'wikipedia.org',
            },
          ],
        };
      }
      browserCanvasRef.current?.render(sim.browser);
    };

    const openBrowserPage = async (url: string) => {
      const sim = simRef.current;
      stateRef.current.onBrowserUrlChange?.(url);
      sim.browser = {
        ...sim.browser,
        inputText: url,
        view: 'article',
        loading: true,
        scrollOffset: 0,
        hoveredSlot: null,
        history: [
          ...sim.browser.history,
          {
            view: sim.browser.view,
            query: sim.browser.query,
            url: sim.browser.currentPage?.url,
            results: sim.browser.results,
            currentPage: sim.browser.currentPage,
          },
        ],
      };
      browserCanvasRef.current?.render(sim.browser);

      try {
        const res = await fetch(`/api/browser/page?url=${encodeURIComponent(url)}`);
        const page = (await res.json()) as BrowserState['currentPage'];
        sim.browser = {
          ...sim.browser,
          loading: false,
          currentPage: page,
        };
        const saved = page ? isBookmarkSaved(sim.browser.savedBookmarks, page.url) : false;
        sceneBundleRef.current?.updateButtonLabel(
          'browser:save',
          saved ? 'icon:star-filled' : 'icon:star-outline',
          undefined,
          saved
        );
      } catch {
        sim.browser = {
          ...sim.browser,
          loading: false,
          currentPage: {
            title: 'تعذر تحميل الصفحة',
            url,
            blocks: [{ type: 'paragraph', text: 'حدث خطأ أثناء جلب محتوى الصفحة.' }],
            links: [],
            live: false,
          },
        };
      }
      browserCanvasRef.current?.render(sim.browser);
    };

    const handleGazeTrigger = (id: string) => {
      const sim = simRef.current;
      const bundle = sceneBundleRef.current;
      const audio = audioRef.current;

      if (id === 'common:go-hub') {
        audio?.playBack();
        if (sim.videoElement && !sim.videoElement.paused) {
          sim.videoElement.pause();
        }
        sim.targetYaw = 0;
        sim.targetPitch = 0.18;
        stateRef.current.onModeChange('hub');
        stateRef.current.onStatusInfo('القائمة الرئيسية التفاعلية');
        return;
      }

      if (id === 'common:recenter' || id === 'hub:recenter') {
        audio?.playSelect();
        if (sim.gyroHasData) {
          const euler = new THREE.Euler().setFromQuaternion(sim.gyroRawQuat, 'YXZ');
          sim.gyroYawOffset = -euler.y;
        }
        const neutralPitch = stateRef.current.mode === 'hub' ? 0.18 : 0.04;
        sim.targetYaw = 0;
        sim.targetPitch = neutralPitch;
        sim.yaw = 0;
        sim.pitch = neutralPitch;
        if (bundle) {
          bundle.player360MenuGroup.rotation.y = 0;
          bundle.player360ShowGroup.rotation.y = 0;
        }
        stateRef.current.onStatusInfo('تمت إعادة تمركز زاوية النظر');
        return;
      }

      if (id === 'portal:360') {
        audio?.playSelect();
        sim.targetYaw = 0;
        sim.targetPitch = 0.14;
        if (bundle) {
          bundle.player360MenuGroup.rotation.y = 0;
          bundle.player360ShowGroup.rotation.y = 0;
          bundle.set360MenuVisible(true);
        }
        document.body.setAttribute('data-360-menu', 'visible');
        stateRef.current.onModeChange('player360');
        stateRef.current.onStatusInfo('تم الدخول إلى مشغل فيديو 360°');
        return;
      }

      if (id === 'portal:cinema') {
        audio?.playSelect();
        sim.targetYaw = 0;
        sim.targetPitch = 0.14;
        stateRef.current.onModeChange('cinema');
        stateRef.current.onStatusInfo('تم الدخول إلى السينما الافتراضية');
        return;
      }

      if (id === 'portal:browser') {
        audio?.playSelect();
        sim.targetYaw = 0;
        sim.targetPitch = 0.14;
        stateRef.current.onModeChange('browser');
        stateRef.current.onStatusInfo('تم فتح متصفح جوجل VR');
        return;
      }

      if (id === 'hub:toggle-stereo') {
        audio?.playSelect();
        stateRef.current.onStereoToggle();
        return;
      }

      if (id === 'hub:dwell-speed') {
        audio?.playSelect();
        stateRef.current.onDwellCycle();
        return;
      }

      if (id.startsWith('hub:env:') || id.startsWith('cinema:env:')) {
        audio?.playSelect();
        const nextEnv = id.split(':').pop() as SceneEnvironmentId;
        sim.environment = nextEnv;
        bundle?.setEnvironment(nextEnv, stateRef.current.mode);
        document.body.setAttribute('data-environment', nextEnv);
        stateRef.current.onEnvironmentChange?.(nextEnv);
        const opt = ENVIRONMENT_OPTIONS.find((o) => o.id === nextEnv);
        stateRef.current.onStatusInfo(`تم تغيير البيئة إلى ${opt?.hubLabel ?? nextEnv}`);
        return;
      }

      if (id === 'hub:open-gallery') {
        audio?.playSelect();
        sim.targetYaw = 0;
        sim.targetPitch = 0.0;
        sim.yaw = 0;
        sim.pitch = 0.0;
        sim.gaze = createInitialGazeState(stateRef.current.dwellMs);
        stateRef.current.onModeChange('gallery');
        stateRef.current.onStatusInfo('تم فتح المعرض ومتصفح الملفات داخل VR');
        return;
      }

      // 360 Player Controls
      if (id === '360:play-pause') {
        audio?.playSelect();
        sim.player360Playing = !sim.player360Playing;
        if (
          sim.activeMediaTarget === '360' &&
          sim.activeMediaKind === 'video' &&
          sim.videoElement
        ) {
          if (sim.player360Playing) sim.videoElement.play().catch(() => {});
          else sim.videoElement.pause();
        }
        bundle?.updateButtonLabel(
          '360:play-pause',
          sim.player360Playing ? 'icon:pause' : 'icon:play'
        );
        return;
      }
      if (id === '360:hide-menu') {
        audio?.playBack();
        if (bundle) {
          bundle.player360ShowGroup.rotation.y = sim.yaw;
          bundle.set360MenuVisible(false);
        }
        document.body.setAttribute('data-360-menu', 'hidden');
        stateRef.current.onStatusInfo('تم إخفاء القائمة — انظر لزر العين لإظهارها');
        return;
      }
      if (id === '360:show-menu') {
        audio?.playSelect();
        if (bundle) {
          bundle.player360MenuGroup.rotation.y = sim.yaw;
          bundle.set360MenuVisible(true);
        }
        document.body.setAttribute('data-360-menu', 'visible');
        stateRef.current.onStatusInfo('تم إظهار قائمة 360°');
        return;
      }
      if (id === '360:seek-back' || id === '360:seek-fwd') {
        audio?.playSelect();
        const delta = id === '360:seek-fwd' ? 10 : -10;
        if (
          sim.activeMediaTarget === '360' &&
          sim.activeMediaKind === 'video' &&
          sim.videoElement &&
          sim.videoElement.duration
        ) {
          sim.videoElement.currentTime = Math.max(
            0,
            Math.min(sim.videoElement.duration, sim.videoElement.currentTime + delta)
          );
        } else {
          sim.player360Time = Math.max(0, sim.player360Time + delta);
        }
        return;
      }
      if (id === '360:next-scene') {
        audio?.playSelect();
        const deviceItems = sim.gallery.items.filter((i) => i.sourceType === 'device');
        if (sim.activeMediaTarget === '360' && deviceItems.length > 1) {
          const nextItem = getNextGalleryItem(deviceItems, sim.activeGalleryItemUrl, 1);
          if (nextItem) {
            activateMediaSource(
              '360',
              nextItem.url,
              nextItem.name,
              nextItem.defaultProjection,
              nextItem.kind
            );
            stateRef.current.onStatusInfo(`تم فتح ${nextItem.name}`);
            return;
          }
        }
        if (sim.activeMediaTarget === '360') {
          sim.activeMediaTarget = null;
          sim.activeMediaKind = 'video';
          sim.activeGalleryItemUrl = null;
          sim.player360CustomLabel = null;
        }
        sim.player360Idx = cycleIndex(sim.player360Idx, VIDEO_360_SCENES.length, 1);
        sim.player360Time = 0;
        sim.player360Playing = true;
        return;
      }
      if (id === '360:mute' || id === 'cinema:mute') {
        sim.muted = !sim.muted;
        if (!sim.muted && sim.volume <= 0) {
          sim.volume = 0.5;
        }
        syncAudioVolume();
        audio?.playSelect();
        stateRef.current.onStatusInfo(
          sim.muted
            ? 'تم كتم الصوت'
            : `مستوى الصوت: ${formatVolumePercent(sim.volume, false)}`
        );
        return;
      }
      if (id === '360:vol-down' || id === 'cinema:vol-down') {
        sim.muted = false;
        sim.volume = stepVolume(sim.volume, -0.1);
        syncAudioVolume();
        audio?.playSelect();
        stateRef.current.onStatusInfo(
          `مستوى الصوت: ${formatVolumePercent(sim.volume, sim.muted)}`
        );
        return;
      }
      if (id === '360:vol-up' || id === 'cinema:vol-up') {
        sim.muted = false;
        sim.volume = stepVolume(sim.volume, 0.1);
        syncAudioVolume();
        audio?.playSelect();
        stateRef.current.onStatusInfo(
          `مستوى الصوت: ${formatVolumePercent(sim.volume, sim.muted)}`
        );
        return;
      }
      if (id.startsWith('360:vol-set:') || id.startsWith('cinema:vol-set:')) {
        const pct = Number(id.split(':').pop() || '80');
        sim.muted = false;
        sim.volume = clampVolume(pct / 100);
        syncAudioVolume();
        audio?.playSelect();
        stateRef.current.onStatusInfo(
          `مستوى الصوت: ${formatVolumePercent(sim.volume, sim.muted)}`
        );
        return;
      }

      if (id.startsWith('360:proj:')) {
        audio?.playSelect();
        const proj = id.replace('360:proj:', '') as Video360Projection;
        sim.player360Projection = proj;
        bundle?.set360Projection(proj);
        stateRef.current.onStatusInfo(`نمط العرض: ${proj}`);
        return;
      }

      // Cinema Controls
      if (id === 'cinema:play-pause') {
        audio?.playSelect();
        sim.cinemaPlaying = !sim.cinemaPlaying;
        if (
          sim.activeMediaTarget === 'cinema' &&
          sim.activeMediaKind === 'video' &&
          sim.videoElement
        ) {
          if (sim.cinemaPlaying) sim.videoElement.play().catch(() => {});
          else sim.videoElement.pause();
        }
        bundle?.updateButtonLabel(
          'cinema:play-pause',
          sim.cinemaPlaying ? 'icon:pause' : 'icon:play'
        );
        return;
      }
      if (id === 'cinema:seek-back' || id === 'cinema:seek-fwd') {
        audio?.playSelect();
        const delta = id === 'cinema:seek-fwd' ? 10 : -10;
        if (
          sim.activeMediaTarget === 'cinema' &&
          sim.activeMediaKind === 'video' &&
          sim.videoElement &&
          sim.videoElement.duration
        ) {
          sim.videoElement.currentTime = Math.max(
            0,
            Math.min(sim.videoElement.duration, sim.videoElement.currentTime + delta)
          );
        } else {
          sim.cinemaTime = Math.max(0, sim.cinemaTime + delta);
        }
        return;
      }
      if (id === 'cinema:lights') {
        audio?.playSelect();
        const next = cycleTheaterLightMode(sim.cinemaLightMode);
        sim.cinemaLightMode = next;
        bundle?.setTheaterLighting(next);
        const opt = THEATER_LIGHT_OPTIONS.find((o) => o.id === next);
        bundle?.updateButtonLabel(
          'cinema:lights',
          `icon:sun|${opt?.shortLabel ?? 'سينمائية'}`
        );
        return;
      }
      if (id === 'cinema:screen-size') {
        audio?.playSelect();
        const next = cycleCinemaScreenSize(sim.cinemaScreenSize);
        sim.cinemaScreenSize = next;
        bundle?.setCinemaScreenScale(next);
        const opt = CINEMA_SCREEN_OPTIONS.find((o) => o.id === next);
        bundle?.updateButtonLabel(
          'cinema:screen-size',
          `icon:expand|${opt?.shortLabel ?? 'IMAX'}`
        );
        return;
      }
      if (id === 'cinema:next-movie') {
        audio?.playSelect();
        const deviceItems = sim.gallery.items.filter((i) => i.sourceType === 'device');
        if (sim.activeMediaTarget === 'cinema' && deviceItems.length > 1) {
          const nextItem = getNextGalleryItem(deviceItems, sim.activeGalleryItemUrl, 1);
          if (nextItem) {
            activateMediaSource(
              'cinema',
              nextItem.url,
              nextItem.name,
              nextItem.defaultProjection,
              nextItem.kind
            );
            stateRef.current.onStatusInfo(`تم فتح ${nextItem.name}`);
            return;
          }
        }
        if (sim.activeMediaTarget === 'cinema') {
          sim.activeMediaTarget = null;
          sim.activeMediaKind = 'video';
          sim.activeGalleryItemUrl = null;
          sim.cinemaCustomLabel = null;
        }
        sim.cinemaIdx = cycleIndex(sim.cinemaIdx, CINEMA_MOVIES.length, 1);
        sim.cinemaTime = 0;
        sim.cinemaPlaying = true;
        return;
      }

      // Browser Controls & 3D Keyboard
      if (id.startsWith('browser:key:')) {
        audio?.playSelect();
        const action = id.replace('browser:key:', '');
        sim.browser = {
          ...sim.browser,
          inputText: applyKeyboardKey(sim.browser.inputText, action),
        };
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id === 'browser:lang') {
        audio?.playSelect();
        const nextLang = sim.browser.keyboardLang === 'ar' ? 'en' : 'ar';
        sim.browser = { ...sim.browser, keyboardLang: nextLang };
        bundle?.rebuildKeyboard(nextLang);
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id === 'browser:search') {
        audio?.playSelect();
        void runBrowserSearch(sim.browser.inputText);
        return;
      }
      if (id === 'browser:home') {
        audio?.playSelect();
        sim.browser = {
          ...sim.browser,
          view: 'home',
          scrollOffset: 0,
        };
        bundle?.updateButtonLabel('browser:save', 'icon:star-outline', undefined, false);
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id === 'browser:bookmarks') {
        audio?.playSelect();
        sim.browser = {
          ...sim.browser,
          history: [
            ...sim.browser.history,
            {
              view: sim.browser.view,
              query: sim.browser.query,
              results: sim.browser.results,
              currentPage: sim.browser.currentPage,
            },
          ],
          view: 'bookmarks',
          scrollOffset: 0,
        };
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id === 'browser:save') {
        audio?.playSelect();
        let candidate: { title: string; url: string } | null = null;
        if (sim.browser.view === 'article' && sim.browser.currentPage) {
          candidate = {
            title: sim.browser.currentPage.title,
            url: sim.browser.currentPage.url,
          };
        } else if (sim.browser.view === 'results' && sim.browser.results[0]) {
          candidate = {
            title: sim.browser.results[0].title,
            url: sim.browser.results[0].url,
          };
        } else if (sim.browser.inputText.trim()) {
          const q = sim.browser.inputText.trim();
          const resolved = resolveBrowserInput(q);
          candidate =
            resolved.type === 'url'
              ? { title: resolved.url, url: resolved.url }
              : {
                  title: `بحث: ${q}`,
                  url: `https://ar.wikipedia.org/wiki/${encodeURIComponent(q)}`,
                };
        }
        if (candidate) {
          const { nextBookmarks, saved } = toggleBookmark(
            sim.browser.savedBookmarks,
            candidate
          );
          sim.browser = { ...sim.browser, savedBookmarks: nextBookmarks };
          persistSavedBookmarks(nextBookmarks);
          bundle?.updateButtonLabel(
            'browser:save',
            saved ? 'icon:star-filled' : 'icon:star-outline',
            undefined,
            saved
          );
          stateRef.current.onStatusInfo(
            saved ? 'تم حفظ الموقع في المحفوظات' : 'تمت إزالة الموقع من المحفوظات'
          );
          browserCanvasRef.current?.render(sim.browser);
        }
        return;
      }
      if (id === 'browser:back') {
        audio?.playBack();
        const prev = sim.browser.history.pop();
        const nextView = prev ? prev.view : 'home';
        const nextPage = prev?.currentPage ?? sim.browser.currentPage;
        sim.browser = {
          ...sim.browser,
          view: nextView,
          query: prev?.query ?? sim.browser.query,
          results: prev?.results ?? sim.browser.results,
          currentPage: nextPage,
          scrollOffset: 0,
        };
        const saved =
          nextView === 'article' && nextPage
            ? isBookmarkSaved(sim.browser.savedBookmarks, nextPage.url)
            : false;
        bundle?.updateButtonLabel(
          'browser:save',
          saved ? 'icon:star-filled' : 'icon:star-outline',
          undefined,
          saved
        );
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id === 'browser:scroll-up' || id === 'browser:scroll-down') {
        audio?.playSelect();
        const dir = id === 'browser:scroll-down' ? 1 : -1;
        if (sim.browser.view === 'home') {
          const maxHomeOffset = Math.max(0, CURATED_WEBSITES.length - 4);
          const nextOffset = clampScrollOffset(sim.browser.scrollOffset + dir * 4, maxHomeOffset);
          sim.browser = { ...sim.browser, scrollOffset: nextOffset, hoveredSlot: null };
          browserCanvasRef.current?.render(sim.browser);
          return;
        }
        const maxOffset =
          sim.browser.view === 'results'
            ? Math.max(0, sim.browser.results.length - 4)
            : sim.browser.view === 'bookmarks'
              ? Math.max(0, sim.browser.savedBookmarks.length - 4)
              : Math.max(0, (sim.browser.currentPage?.blocks.length ?? 0) - 3);
        sim.browser = {
          ...sim.browser,
          scrollOffset: clampScrollOffset(sim.browser.scrollOffset + dir, maxOffset),
        };
        browserCanvasRef.current?.render(sim.browser);
        return;
      }
      if (id.startsWith('browser:open-')) {
        audio?.playSelect();
        const slot = Number(id.replace('browser:open-', '')) - 1;
        if (sim.browser.view === 'home') {
          const site = CURATED_WEBSITES[sim.browser.scrollOffset + slot];
          if (site) void openBrowserPage(site.url);
        } else if (sim.browser.view === 'results') {
          const targetResult = sim.browser.results[sim.browser.scrollOffset + slot];
          if (targetResult) void openBrowserPage(targetResult.url);
        } else if (sim.browser.view === 'bookmarks') {
          const savedBm = sim.browser.savedBookmarks[sim.browser.scrollOffset + slot];
          if (savedBm) void openBrowserPage(savedBm.url);
        } else if (sim.browser.view === 'article') {
          const pageLink = sim.browser.currentPage?.links?.[slot];
          if (pageLink) void openBrowserPage(pageLink.url);
        }
        return;
      }

      // 3D VR Gallery & File Browser Controls
      if (id === 'gallery:filter') {
        audio?.playSelect();
        const nextFilter = cycleGalleryFilter(sim.gallery.filter);
        sim.gallery = { ...sim.gallery, filter: nextFilter, scrollOffset: 0, hoveredSlot: null };
        const label =
          nextFilter === 'all'
            ? 'الكل'
            : nextFilter === 'video'
              ? 'فيديو'
              : 'صور';
        bundle?.updateButtonLabel('gallery:filter', label);
        galleryCanvasRef.current?.render(sim.gallery);
        return;
      }
      if (id === 'gallery:target') {
        audio?.playSelect();
        const nextTarget =
          sim.gallery.preferredTarget === 'auto'
            ? 'cinema'
            : sim.gallery.preferredTarget === 'cinema'
              ? '360'
              : 'auto';
        sim.gallery = { ...sim.gallery, preferredTarget: nextTarget };
        const label =
          nextTarget === 'auto'
            ? 'تلقائي'
            : nextTarget === 'cinema'
              ? 'السينما'
              : '360°';
        bundle?.updateButtonLabel('gallery:target', label);
        galleryCanvasRef.current?.render(sim.gallery);
        return;
      }
      if (id === 'gallery:scroll-up' || id === 'gallery:scroll-down') {
        audio?.playSelect();
        const filtered = filterGalleryItems(
          sim.gallery.items,
          sim.gallery.filter,
          sim.gallery.folderFilter
        );
        const dir = id === 'gallery:scroll-down' ? 1 : -1;
        const maxOffset = Math.max(0, filtered.length - 4);
        sim.gallery = {
          ...sim.gallery,
          scrollOffset: clampScrollOffset(sim.gallery.scrollOffset + dir, maxOffset),
          hoveredSlot: null,
        };
        galleryCanvasRef.current?.render(sim.gallery);
        return;
      }
      if (id === 'gallery:import') {
        audio?.playSelect();
        stateRef.current.onOpenGalleryPicker();
        return;
      }
      if (id.startsWith('gallery:open-')) {
        audio?.playSelect();
        const slot = Number(id.replace('gallery:open-', '')) - 1;
        const filtered = filterGalleryItems(
          sim.gallery.items,
          sim.gallery.filter,
          sim.gallery.folderFilter
        );
        const item = filtered[sim.gallery.scrollOffset + slot];
        if (!item) return;

        const target: '360' | 'cinema' =
          sim.gallery.preferredTarget === 'auto'
            ? item.defaultTarget
            : sim.gallery.preferredTarget;

        if (item.sourceType === 'builtin' && typeof item.builtinIndex === 'number') {
          sim.activeMediaTarget = null;
          sim.activeMediaKind = 'video';
          sim.activeGalleryItemUrl = item.url;
          if (item.defaultTarget === '360') {
            sim.player360Idx = item.builtinIndex;
            sim.player360CustomLabel = null;
            sim.player360Time = 0;
            sim.player360Playing = true;
            stateRef.current.onModeChange('player360');
          } else {
            sim.cinemaIdx = item.builtinIndex;
            sim.cinemaCustomLabel = null;
            sim.cinemaTime = 0;
            sim.cinemaPlaying = true;
            stateRef.current.onModeChange('cinema');
          }
          return;
        }

        activateMediaSource(
          target,
          item.url,
          item.name,
          item.defaultProjection,
          item.kind
        );
        stateRef.current.onStatusInfo(`تم فتح ${item.name}`);
      }
    };

    // Sync React prop updates into the persistent Three.js scene
    useEffect(() => {
      simRef.current.gaze = {
        ...simRef.current.gaze,
        dwellDurationMs: dwellMs,
      };
      const label =
        dwellMs <= 950
          ? 'السرعة: سريع'
          : dwellMs <= 1400
            ? 'السرعة: عادي'
            : 'السرعة: مريح';
      sceneBundleRef.current?.updateButtonLabel('hub:dwell-speed', label);
    }, [dwellMs]);

    useEffect(() => {
      simRef.current.gallery = {
        ...simRef.current.gallery,
        items: galleryItems,
        scrollOffset: 0,
      };
      galleryCanvasRef.current?.render(simRef.current.gallery);
    }, [galleryItems]);

    useEffect(() => {
      sceneBundleRef.current?.setActiveModeVisibility(mode);
      if (mode === 'player360' && sceneBundleRef.current) {
        document.body.setAttribute(
          'data-360-menu',
          sceneBundleRef.current.is360MenuVisible() ? 'visible' : 'hidden'
        );
      } else {
        document.body.removeAttribute('data-360-menu');
      }
      if (mode === 'browser') {
        browserCanvasRef.current?.render(simRef.current.browser);
      } else if (mode === 'gallery') {
        galleryCanvasRef.current?.render(simRef.current.gallery);
      }
    }, [mode]);

    useEffect(() => {
      simRef.current.environment = environment;
      sceneBundleRef.current?.setEnvironment(environment, stateRef.current.mode);
      document.body.setAttribute('data-environment', environment);
    }, [environment]);

    useEffect(() => {
      sceneBundleRef.current?.updateButtonLabel(
        'hub:toggle-stereo',
        stereo ? 'VR Box ✓' : 'وضع \u2066VR Box\u2069'
      );
    }, [stereo]);

    useImperativeHandle(ref, () => ({
      setMode: (nextMode: VRMode) => {
        simRef.current.targetYaw = 0;
        simRef.current.targetPitch =
          nextMode === 'hub' ? 0.18 : nextMode === 'gallery' ? 0.0 : 0.14;
        simRef.current.yaw = simRef.current.targetYaw;
        simRef.current.pitch = simRef.current.targetPitch;
        simRef.current.gaze = createInitialGazeState(stateRef.current.dwellMs);
        stateRef.current.onModeChange(nextMode);
      },
      setEnvironment: (envId: SceneEnvironmentId) => {
        simRef.current.environment = envId;
        sceneBundleRef.current?.setEnvironment(envId, stateRef.current.mode);
        document.body.setAttribute('data-environment', envId);
        stateRef.current.onEnvironmentChange?.(envId);
      },
      recenter: () => {
        handleGazeTrigger('common:recenter');
      },
      loadVideoSource: (target, src, label, projection, kind = 'video') => {
        activateMediaSource(target, src, label, projection, kind);
      },
      triggerBrowserSearch: async (query: string) => {
        stateRef.current.onModeChange('browser');
        await runBrowserSearch(query);
      },
      openBrowserTarget: async (input: string) => {
        stateRef.current.onModeChange('browser');
        await runBrowserSearch(input);
      },
      enableGyro: async () => {
        const sim = simRef.current;
        try {
          const DevOrient = DeviceOrientationEvent as unknown as {
            requestPermission?: () => Promise<'granted' | 'denied'>;
          };
          if (typeof DevOrient?.requestPermission === 'function') {
            const resp = await DevOrient.requestPermission();
            if (resp !== 'granted') return false;
          }
          sim.gyroActive = true;
          stateRef.current.onGyroStateChange(true);
          return true;
        } catch {
          return false;
        }
      },
      lookAtAngles: (yawDeg: number, pitchDeg: number) => {
        const sim = simRef.current;
        sim.targetYaw = THREE.MathUtils.degToRad(yawDeg);
        sim.targetPitch = clampPitchRadians(THREE.MathUtils.degToRad(pitchDeg));
        sim.yaw = sim.targetYaw;
        sim.pitch = sim.targetPitch;
      },
    }));

    // Mount WebGLRenderer + Three.js Scene ONCE
    useEffect(() => {
      const container = mountRef.current;
      if (!container) return;

      const isSoftwareGl = detectSoftwareWebGL();
      const renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;
      renderer.setPixelRatio(
        isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
      );
      renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      renderer.domElement.setAttribute('data-testid', 'vr-webgl-canvas');
      container.appendChild(renderer.domElement);

      const camera = new THREE.PerspectiveCamera(
        76,
        (container.clientWidth || window.innerWidth) /
          Math.max(1, container.clientHeight || window.innerHeight),
        0.1,
        150
      );
      camera.position.set(0, 1.65, 0);

      const stereoCam = new THREE.StereoCamera();
      stereoCam.aspect = 0.5;

      const bundle = buildVRScene(renderer, isSoftwareGl);
      sceneBundleRef.current = bundle;

      const proc360 = new Procedural360Renderer(isSoftwareGl);
      const procCinema = new ProceduralCinemaRenderer(isSoftwareGl);
      const browserCanvas = new BrowserScreenRenderer(isSoftwareGl);
      const galleryCanvas = new GalleryScreenRenderer(isSoftwareGl);
      browserCanvasRef.current = browserCanvas;
      galleryCanvasRef.current = galleryCanvas;

      const audio = new SpatialAudioEngine();
      audioRef.current = audio;

      bundle.set360Texture(proc360.texture);
      bundle.set360Projection(simRef.current.player360Projection);
      bundle.setTheaterLighting(simRef.current.cinemaLightMode);
      bundle.setCinemaScreenScale(simRef.current.cinemaScreenSize);
      bundle.cinemaScreenMat.map = procCinema.texture;
      bundle.cinemaScreenMat.needsUpdate = true;
      bundle.browserScreenMat.map = browserCanvas.texture;
      bundle.browserScreenMat.needsUpdate = true;
      bundle.galleryScreenMat.map = galleryCanvas.texture;
      bundle.galleryScreenMat.needsUpdate = true;
      browserCanvas.render(simRef.current.browser);
      galleryCanvas.render(simRef.current.gallery);
      bundle.setActiveModeVisibility(stateRef.current.mode);

      // Hidden HTML5 Video element for local MP4/WebM & URL playback
      const videoEl = document.createElement('video');
      videoEl.playsInline = true;
      videoEl.crossOrigin = 'anonymous';
      videoEl.loop = true;
      videoEl.volume = simRef.current.volume;
      simRef.current.videoElement = videoEl;
      syncAudioVolume();

      if (!isSoftwareGl) {
        renderer.compile(bundle.scene, camera);
      }

      const raycaster = new THREE.Raycaster();
      let lastTickMs = performance.now();
      let frameId = 0;
      let disposed = false;
      let lastHudEmitMs = 0;
      let lastProcRenderMs = 0;
      let lastVisibleMode: VRMode | null = null;
      let lastStereoState: boolean | null = null;

      // Pointer Drag Look Controls (Desktop + Touch fallback)
      const onPointerDown = (e: PointerEvent) => {
        simRef.current.isDragging = true;
        simRef.current.lastPointerX = e.clientX;
        simRef.current.lastPointerY = e.clientY;
      };
      const onPointerMove = (e: PointerEvent) => {
        if (!simRef.current.isDragging) return;
        const dx = e.clientX - simRef.current.lastPointerX;
        const dy = e.clientY - simRef.current.lastPointerY;
        simRef.current.lastPointerX = e.clientX;
        simRef.current.lastPointerY = e.clientY;
        simRef.current.targetYaw += dx * 0.0042;
        simRef.current.targetPitch = clampPitchRadians(
          simRef.current.targetPitch + dy * 0.0042
        );
      };
      const onPointerUp = () => {
        simRef.current.isDragging = false;
      };

      const onKeyDown = (e: KeyboardEvent) => {
        simRef.current.keys[e.code] = true;
      };
      const onKeyUp = (e: KeyboardEvent) => {
        simRef.current.keys[e.code] = false;
      };

      const onDeviceOrientation = (e: DeviceOrientationEvent) => {
        if (e.alpha == null || e.beta == null || e.gamma == null) return;
        const sim = simRef.current;
        if (!sim.gyroActive) {
          sim.gyroActive = true;
          stateRef.current.onGyroStateChange(true);
        }
        const screenAngle =
          typeof window.screen?.orientation?.angle === 'number'
            ? window.screen.orientation.angle
            : ((window.orientation as number) || 0);
        const q = deviceOrientationToQuaternion(e.alpha, e.beta, e.gamma, screenAngle);
        sim.gyroRawQuat.set(q.x, q.y, q.z, q.w);
        sim.gyroHasData = true;
      };

      const onResize = () => {
        if (!container) return;
        const w = container.clientWidth || window.innerWidth;
        const h = Math.max(1, container.clientHeight || window.innerHeight);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };

      const onContextLost = (ev: Event) => {
        ev.preventDefault();
      };

      renderer.domElement.addEventListener('pointerdown', onPointerDown);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);
      window.addEventListener('deviceorientation', onDeviceOrientation);
      window.addEventListener('resize', onResize);
      renderer.domElement.addEventListener('webglcontextlost', onContextLost);

      const afterDraw = (cb: () => void) => {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (!gl || typeof gl.fenceSync !== 'function') {
          frameId = window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) {
            if (sync) gl.deleteSync(sync);
            return;
          }
          const status = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
          if (status === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      };

      const tick = () => {
        if (disposed) return;
        const nowMs = performance.now();
        const deltaSec = Math.min(0.25, Math.max(0.001, (nowMs - lastTickMs) / 1000));
        lastTickMs = nowMs;
        const sim = simRef.current;
        const currentMode = stateRef.current.mode;

        if (lastVisibleMode !== currentMode) {
          bundle.setActiveModeVisibility(currentMode);
          bundle.setEnvironment(sim.environment, currentMode);
          document.body.setAttribute('data-environment', sim.environment);
          sim.gaze = createInitialGazeState(stateRef.current.dwellMs);
          if (currentMode === 'gallery') {
            sim.targetPitch = 0.0;
            sim.pitch = 0.0;
          }
          if (currentMode === 'browser') {
            browserCanvas.render(sim.browser);
          } else if (currentMode === 'gallery') {
            galleryCanvas.render(sim.gallery);
          }
          lastVisibleMode = currentMode;
        }

        if (lastStereoState !== stateRef.current.stereo) {
          camera.fov = stateRef.current.stereo ? 84 : 74;
          camera.updateProjectionMatrix();
          lastStereoState = stateRef.current.stereo;
        }

        // Keyboard look support (WASD / Arrow keys)
        const keySpeed = 1.45 * deltaSec;
        if (sim.keys['ArrowLeft'] || sim.keys['KeyA']) sim.targetYaw += keySpeed;
        if (sim.keys['ArrowRight'] || sim.keys['KeyD']) sim.targetYaw -= keySpeed;
        if (sim.keys['ArrowUp'] || sim.keys['KeyW']) {
          sim.targetPitch = clampPitchRadians(sim.targetPitch + keySpeed);
        }
        if (sim.keys['ArrowDown'] || sim.keys['KeyS']) {
          sim.targetPitch = clampPitchRadians(sim.targetPitch - keySpeed);
        }

        // Smooth camera orientation (Gyroscope or damped pointer/keyboard look)
        if (sim.gyroActive && sim.gyroHasData) {
          _recenterQuat.setFromAxisAngle(_upAxis, sim.gyroYawOffset);
          _gyroQuat.multiplyQuaternions(_recenterQuat, sim.gyroRawQuat);
          camera.quaternion.slerp(_gyroQuat, 1 - Math.exp(-14 * deltaSec));
        } else {
          const damp = 1 - Math.exp(-12 * deltaSec);
          sim.yaw = THREE.MathUtils.lerp(sim.yaw, sim.targetYaw, damp);
          sim.pitch = THREE.MathUtils.lerp(sim.pitch, sim.targetPitch, damp);
          _euler.set(sim.pitch, sim.yaw, 0, 'YXZ');
          _targetQuat.setFromEuler(_euler);
          camera.quaternion.copy(_targetQuat);
        }

        // Animate Scene Environment (Ocean Waves, Earthrise, Tiki Torches) & Hub Props
        bundle.updateEnvironment(deltaSec, nowMs);
        if (currentMode === 'hub') {
          bundle.animatedProps.hubGlobe.rotation.y += deltaSec * 0.55;
          bundle.animatedProps.hubCinemaIcon.rotation.y = Math.sin(nowMs * 0.0007) * 0.28;
          bundle.animatedProps.hubBrowserIcon.rotation.y -= deltaSec * 0.65;
          bundle.animatedProps.stars.rotation.y += deltaSec * 0.015;
        }

        // Update 360 & Cinema Media Playback
        if (currentMode === 'player360') {
          const sceneItem = VIDEO_360_SCENES[sim.player360Idx];
          if (sim.activeMediaTarget === '360') {
            const targetTex =
              sim.activeMediaKind === 'image' ? sim.imageTexture : sim.videoTexture;
            if (targetTex && bundle.sphere360Mat.uniforms.uMap.value !== targetTex) {
              bundle.set360Texture(targetTex);
            }
          } else {
            if (bundle.sphere360Mat.uniforms.uMap.value !== proc360.texture) {
              bundle.set360Texture(proc360.texture);
            }
            if (sim.player360Playing) {
              sim.player360Time =
                (sim.player360Time + deltaSec) % sceneItem.durationSeconds;
            }
            if (nowMs - lastProcRenderMs > (isSoftwareGl ? 140 : 45)) {
              proc360.render(sceneItem.theme, sim.player360Time, sim.player360Projection);
              lastProcRenderMs = nowMs;
            }
          }
        }

        if (currentMode === 'cinema') {
          const movieItem = CINEMA_MOVIES[sim.cinemaIdx];
          if (sim.activeMediaTarget === 'cinema') {
            const targetTex =
              sim.activeMediaKind === 'image' ? sim.imageTexture : sim.videoTexture;
            if (targetTex && bundle.cinemaScreenMat.map !== targetTex) {
              bundle.cinemaScreenMat.map = targetTex;
              bundle.cinemaScreenMat.needsUpdate = true;
            }
            bundle.cinemaBounceLight.color.set('#38bdf8');
          } else {
            if (bundle.cinemaScreenMat.map !== procCinema.texture) {
              bundle.cinemaScreenMat.map = procCinema.texture;
              bundle.cinemaScreenMat.needsUpdate = true;
            }
            if (sim.cinemaPlaying) {
              sim.cinemaTime = (sim.cinemaTime + deltaSec) % movieItem.durationSeconds;
            }
            if (nowMs - lastProcRenderMs > (isSoftwareGl ? 140 : 45)) {
              procCinema.render(movieItem, sim.cinemaTime, sim.cinemaPlaying);
              bundle.cinemaBounceLight.color.copy(procCinema.dominantColor);
              if (sim.cinemaLightMode === 'cinematic') {
                bundle.setTheaterLighting('cinematic', procCinema.dominantColor);
              }
              lastProcRenderMs = nowMs;
            }
          }
        }

        // Update 3D HUD Banners (~4Hz max)
        const scene360 = VIDEO_360_SCENES[sim.player360Idx];
        const movie = CINEMA_MOVIES[sim.cinemaIdx];
        const p360TimeStr =
          sim.activeMediaTarget === '360'
            ? sim.activeMediaKind === 'image'
              ? 'صورة المعرض'
              : sim.videoElement
                ? `${formatPlaybackTime(sim.videoElement.currentTime)} / ${formatPlaybackTime(
                    sim.videoElement.duration || 0
                  )}`
                : '00:00 / 00:00'
            : `${formatPlaybackTime(sim.player360Time)} / ${formatPlaybackTime(
                scene360.durationSeconds
              )}`;
        const cineTimeStr =
          sim.activeMediaTarget === 'cinema'
            ? sim.activeMediaKind === 'image'
              ? 'صورة المعرض'
              : sim.videoElement
                ? `${formatPlaybackTime(sim.videoElement.currentTime)} / ${formatPlaybackTime(
                    sim.videoElement.duration || 0
                  )}`
                : '00:00 / 00:00'
            : `${formatPlaybackTime(sim.cinemaTime)} / ${formatPlaybackTime(
                movie.durationSeconds
              )}`;

        bundle.updateDynamicHudTextures(
          {
            title: sim.player360CustomLabel ?? scene360.title,
            timeText: p360TimeStr,
            isPlaying: sim.player360Playing,
          },
          {
            title: sim.cinemaCustomLabel ?? movie.title,
            timeText: cineTimeStr,
            isPlaying: sim.cinemaPlaying,
          }
        );

        // Gaze Raycasting from Center Reticle
        camera.updateMatrixWorld();
        raycaster.setFromCamera(_rayOrigin, camera);
        const targets = bundle.getActiveInteractables(currentMode);
        const hits = raycaster.intersectObjects(targets, false);
        let hoveredId: string | null = null;

        if (hits.length > 0) {
          const hit = hits[0];
          if (hit.object === bundle.browserScreenMesh && hit.uv) {
            const mapped = mapBrowserUvToGazeId(hit.uv.x, hit.uv.y, sim.browser);
            hoveredId = mapped.gazeId;
            if (mapped.slot !== (sim.browser.hoveredSlot ?? null)) {
              sim.browser = { ...sim.browser, hoveredSlot: mapped.slot };
              browserCanvas.render(sim.browser);
            }
          } else if (hit.object === bundle.galleryScreenMesh && hit.uv) {
            const mapped = mapGalleryUvToGazeId(hit.uv.x, hit.uv.y, sim.gallery);
            hoveredId = mapped.gazeId;
            if (mapped.slot !== (sim.gallery.hoveredSlot ?? null)) {
              sim.gallery = { ...sim.gallery, hoveredSlot: mapped.slot };
              galleryCanvas.render(sim.gallery);
            }
          } else {
            hoveredId = (hit.object.userData.gazeId as string) || null;
          }
        }

        if (hits[0]?.object !== bundle.browserScreenMesh && (sim.browser.hoveredSlot ?? null) !== null) {
          sim.browser = { ...sim.browser, hoveredSlot: null };
          browserCanvas.render(sim.browser);
        }
        if (hits[0]?.object !== bundle.galleryScreenMesh && (sim.gallery.hoveredSlot ?? null) !== null) {
          sim.gallery = { ...sim.gallery, hoveredSlot: null };
          galleryCanvas.render(sim.gallery);
        }

        // Keep floating 360 show-menu button comfortably within reach when turning 360°
        if (
          currentMode === 'player360' &&
          !bundle.is360MenuVisible() &&
          hoveredId !== '360:show-menu'
        ) {
          _tempEuler.setFromQuaternion(camera.quaternion, 'YXZ');
          const yawDiff = shortestAngleDiffRadians(
            _tempEuler.y,
            bundle.player360ShowGroup.rotation.y
          );
          if (Math.abs(yawDiff) > 1.05) {
            bundle.player360ShowGroup.rotation.y += yawDiff * (1 - Math.exp(-5 * deltaSec));
          }
        }

        if (hoveredId !== sim.lastHoveredId) {
          if (hoveredId) {
            audio.playHover();
          }
          sim.lastHoveredId = hoveredId;
        }

        const gazeStep = stepGaze(sim.gaze, hoveredId, deltaSec * 1000, nowMs);
        sim.gaze = gazeStep.nextState;

        // Animate button scale & border glow
        bundle.buttons.forEach((btn) => {
          const isHovered = btn.id === hoveredId;
          if (btn.isSliderSegment) {
            btn.borderMat.opacity = isHovered ? 0.28 : 0;
            return;
          }
          const targetScale = isHovered ? 1.08 : 1.0;
          const nextScale = THREE.MathUtils.lerp(
            btn.group.scale.x,
            targetScale,
            1 - Math.exp(-14 * deltaSec)
          );
          btn.group.scale.set(nextScale, nextScale, 1);
          btn.borderMat.color.set(isHovered ? btn.accentHex : '#26344a');
        });

        if (gazeStep.triggeredId) {
          handleGazeTrigger(gazeStep.triggeredId);
        }

        if (nowMs - lastHudEmitMs > 90) {
          stateRef.current.onGazeUpdate(hoveredId, gazeStep.progress);
          lastHudEmitMs = nowMs;
        }

        // Render Mono or Stereo VR Box Side-by-Side
        const canvasW = renderer.domElement.clientWidth || window.innerWidth;
        const canvasH = renderer.domElement.clientHeight || window.innerHeight;
        if (stateRef.current.stereo) {
          const spec = computeStereoViewports(
            canvasW,
            canvasH,
            stateRef.current.ipdMm
          );
          stereoCam.eyeSep = spec.eyeOffsetMeters * 2;
          stereoCam.aspect = spec.eyeAspect;
          stereoCam.update(camera);

          renderer.setScissorTest(true);
          bundle.set360Eye(0);
          renderer.setScissor(
            spec.leftViewport.x,
            spec.leftViewport.y,
            spec.leftViewport.width,
            spec.leftViewport.height
          );
          renderer.setViewport(
            spec.leftViewport.x,
            spec.leftViewport.y,
            spec.leftViewport.width,
            spec.leftViewport.height
          );
          renderer.render(bundle.scene, stereoCam.cameraL);

          bundle.set360Eye(1);
          renderer.setScissor(
            spec.rightViewport.x,
            spec.rightViewport.y,
            spec.rightViewport.width,
            spec.rightViewport.height
          );
          renderer.setViewport(
            spec.rightViewport.x,
            spec.rightViewport.y,
            spec.rightViewport.width,
            spec.rightViewport.height
          );
          renderer.render(bundle.scene, stereoCam.cameraR);
        } else {
          bundle.set360Eye(0);
          renderer.setScissorTest(false);
          renderer.setViewport(0, 0, canvasW, canvasH);
          renderer.render(bundle.scene, camera);
        }

        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      };

      tick();

      return () => {
        disposed = true;
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);

        renderer.domElement.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
        window.removeEventListener('deviceorientation', onDeviceOrientation);
        window.removeEventListener('resize', onResize);
        renderer.domElement.removeEventListener('webglcontextlost', onContextLost);

        if (simRef.current.videoElement) {
          simRef.current.videoElement.pause();
          simRef.current.videoElement.src = '';
        }
        simRef.current.videoTexture?.dispose();
        simRef.current.imageTexture?.dispose();
        proc360.dispose();
        procCinema.dispose();
        browserCanvas.dispose();
        galleryCanvas.dispose();
        audio.dispose();
        bundle.dispose();
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
      };
    }, []);

    return (
      <div
        ref={mountRef}
        className="fixed inset-0 z-0 w-full h-full bg-[#070b12]"
        aria-label="منفذ العرض ثلاثي الأبعاد للواقع الافتراضي"
      />
    );
  }
);
VRViewport.displayName = 'VRViewport';
