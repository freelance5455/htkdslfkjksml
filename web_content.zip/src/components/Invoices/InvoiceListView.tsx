import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Receipt, 
  Printer, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Banknote, 
  X,
  Eye,
  Trash2,
  DollarSign
} from 'lucide-react';
import { SaleInvoice, UserRole } from '../../types';
import { formatBengaliDateTime, formatTaka, toBnNum } from '../../utils/formatters';

interface InvoiceListViewProps {
  invoices: SaleInvoice[];
  onViewReceipt: (invoice: SaleInvoice) => void;
  onPayDue: (invoiceId: string, amount: number, notes?: string) => void;
  activeRole: UserRole;
  onDeleteInvoice?: (invoiceId: string) => void;
}

export const InvoiceListView: React.FC<InvoiceListViewProps> = ({
  invoices,
  onViewReceipt,
  onPayDue,
  activeRole,
  onDeleteInvoice,
}) => {
  const [search, setSearch] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<'all' | 'today' | 'yesterday' | 'month' | 'due'>('today');

  // Due Payment modal state
  const [selectedDueInvoice, setSelectedDueInvoice] = useState<SaleInvoice | null>(null);
  const [payAmount, setPayAmount] = useState<string>('');
  const [payNote, setPayNote] = useState<string>('');

  // Date filters
  const now = new Date();
  const todayStr = now.toDateString();
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toDateString();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const invDate = new Date(inv.createdAt);
      
      // Period filter
      if (filterPeriod === 'today') {
        if (invDate.toDateString() !== todayStr) return false;
      } else if (filterPeriod === 'yesterday') {
        if (invDate.toDateString() !== yesterday) return false;
      } else if (filterPeriod === 'month') {
        if (invDate.getMonth() !== currentMonth || invDate.getFullYear() !== currentYear) return false;
      } else if (filterPeriod === 'due') {
        if (inv.dueAmount <= 0) return false;
      }

      // Search filter
      const q = search.toLowerCase().trim();
      if (!q) return true;

      return (
        inv.invoiceNo.toLowerCase().includes(q) ||
        (inv.customerName && inv.customerName.toLowerCase().includes(q)) ||
        (inv.customerPhone && inv.customerPhone.includes(q)) ||
        inv.items.some((i) => i.nameBn.toLowerCase().includes(q))
      );
    });
  }, [invoices, filterPeriod, search, todayStr, yesterday, currentMonth, currentYear]);

  // Aggregate stats for filtered list
  const stats = useMemo(() => {
    return filteredInvoices.reduce(
      (acc, inv) => {
        acc.totalSales += inv.netTotal;
        acc.totalPaid += inv.paidAmount;
        acc.totalDue += inv.dueAmount;
        acc.totalProfit += inv.grossProfit;
        return acc;
      },
      { totalSales: 0, totalPaid: 0, totalDue: 0, totalProfit: 0 }
    );
  }, [filteredInvoices]);

  const handleOpenDuePay = (inv: SaleInvoice) => {
    setSelectedDueInvoice(inv);
    setPayAmount(String(inv.dueAmount));
    setPayNote('');
  };

  const handleSubmitDuePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDueInvoice) return;
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('সঠিক টাকার অঙ্ক লিখুন');
      return;
    }
    onPayDue(selectedDueInvoice.id, amt, payNote);
    setSelectedDueInvoice(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      
      {/* Title & Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            ডিজিটাল ক্যাশ মেমো ও বিক্রয় ইনভয়েস
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            দোকানের সকল পূর্ববর্তী বিক্রয়ের ডিজিটাল রশিদ ও বাকির রেকর্ড
          </p>
        </div>

        {/* Period Filter Buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200 overflow-x-auto max-w-full">
          <button
            onClick={() => setFilterPeriod('today')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              filterPeriod === 'today' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            আজকের বিক্রি
          </button>
          <button
            onClick={() => setFilterPeriod('yesterday')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              filterPeriod === 'yesterday' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            গতকাল
          </button>
          <button
            onClick={() => setFilterPeriod('month')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              filterPeriod === 'month' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            এই মাস
          </button>
          <button
            onClick={() => setFilterPeriod('due')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              filterPeriod === 'due' ? 'bg-amber-500 text-white shadow-xs' : 'text-amber-700 hover:text-amber-900'
            }`}
          >
            বাকি মেমো
          </button>
          <button
            onClick={() => setFilterPeriod('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              filterPeriod === 'all' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সকল মেমো
          </button>
        </div>
      </div>

      {/* Quick Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500">মোট বিক্রয় বিল</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-0.5 tabular-nums">
            ৳ {toBnNum(stats.totalSales)}
          </div>
          <span className="text-[11px] text-slate-400">মোট {toBnNum(filteredInvoices.length)} টি মেমো</span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500">নগদ সংগৃহীত</span>
          <div className="text-lg font-bold font-mono text-emerald-700 mt-0.5 tabular-nums">
            ৳ {toBnNum(stats.totalPaid)}
          </div>
          <span className="text-[11px] text-emerald-600">ক্যাশ ইন হ্যান্ড</span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500">মোট বাকি টাকা</span>
          <div className="text-lg font-bold font-mono text-amber-700 mt-0.5 tabular-nums">
            ৳ {toBnNum(stats.totalDue)}
          </div>
          <span className="text-[11px] text-amber-600">পাওনা বকেয়া</span>
        </div>

        {activeRole === 'OWNER' && (
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-xs text-slate-500">মোট লাভ (মুনাফা)</span>
            <div className="text-lg font-bold font-mono text-emerald-800 mt-0.5 tabular-nums">
              ৳ {toBnNum(stats.totalProfit)}
            </div>
            <span className="text-[11px] text-slate-400">বিক্রয় - পণ্যের ক্রয়মূল্য</span>
          </div>
        )}
      </div>

      {/* Search Bar */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="মেমো নং, কাস্টমারের নাম, ফোন অথবা পণ্যের নাম দিয়ে খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:bg-white"
          />
        </div>
      </div>

      {/* Invoices List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <tr>
                <th className="py-3 px-4">মেমো নং ও সময়</th>
                <th className="py-3 px-4">কাস্টমারের তথ্য</th>
                <th className="py-3 px-4">পণ্যসমূহ</th>
                <th className="py-3 px-4 text-right">মোট বিল</th>
                <th className="py-3 px-4 text-right">পরিশোধ</th>
                <th className="py-3 px-4 text-right">বকেয়া / বাকি</th>
                <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                <th className="py-3 px-4 text-center">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Receipt className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                    <p className="font-medium text-slate-600">কোনো মেমো পাওয়া যায়নি</p>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/70 transition">
                    
                    {/* Invoice No & Date */}
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-slate-900">{inv.invoiceNo}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {formatBengaliDateTime(inv.createdAt)}
                      </div>
                    </td>

                    {/* Customer */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">
                        {inv.customerName || 'বেনামী কাস্টমার'}
                      </div>
                      {inv.customerPhone && (
                        <div className="text-[11px] text-slate-500 font-mono">
                          {inv.customerPhone}
                        </div>
                      )}
                    </td>

                    {/* Items Summary */}
                    <td className="py-3 px-4">
                      <div className="text-xs text-slate-700 max-w-xs truncate">
                        {inv.items.map((i) => `${i.nameBn} (${toBnNum(i.quantity)} ${i.unit})`).join(', ')}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        মোট {toBnNum(inv.items.length)} টি পণ্য
                      </div>
                    </td>

                    {/* Net Total */}
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      ৳{toBnNum(inv.netTotal)}
                    </td>

                    {/* Paid */}
                    <td className="py-3 px-4 text-right font-mono text-emerald-700 font-semibold tabular-nums">
                      ৳{toBnNum(inv.paidAmount)}
                    </td>

                    {/* Due */}
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {inv.dueAmount > 0 ? (
                        <span className="text-amber-700 font-bold">
                          ৳{toBnNum(inv.dueAmount)}
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-4 text-center">
                      {inv.dueAmount <= 0 ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                          পরিশোধিত
                        </span>
                      ) : inv.paidAmount > 0 ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-100 text-blue-800">
                          আংশিক বাকি
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800">
                          সম্পূর্ণ বাকি
                        </span>
                      )}
                    </td>

                    {/* Action buttons */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        
                        {/* View & Print Memo */}
                        <button
                          onClick={() => onViewReceipt(inv)}
                          className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 border border-emerald-200 transition"
                          title="মেমো দেখুন ও প্রিন্ট করুন"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        {/* Pay Due Button if invoice has due */}
                        {inv.dueAmount > 0 && (
                          <button
                            onClick={() => handleOpenDuePay(inv)}
                            className="px-2 py-1 bg-amber-600 text-white rounded-md text-xs font-semibold hover:bg-amber-700 transition"
                            title="বাকি টাকা পরিশোধ গ্রহণ করুন"
                          >
                            বাকি আদায়
                          </button>
                        )}

                        {/* Delete (Owner only) */}
                        {activeRole === 'OWNER' && onDeleteInvoice && (
                          <button
                            onClick={() => {
                              if (confirm('আপনি কি নিশ্চিত যে এই মেমোটি মুছে ফেলতে চান?')) {
                                onDeleteInvoice(inv.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-600"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Due Payment Modal */}
      {selectedDueInvoice && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">বাকি টাকা পরিশোধ গ্রহণ</h3>
                <p className="text-xs text-slate-500">মেমো: {selectedDueInvoice.invoiceNo}</p>
              </div>
              <button
                onClick={() => setSelectedDueInvoice(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
              <div className="flex justify-between">
                <span>ক্রেতার নাম:</span>
                <span className="font-semibold text-slate-800">{selectedDueInvoice.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span>বর্তমান বাকি টাকা:</span>
                <span className="font-bold text-amber-700 font-mono text-sm">
                  ৳ {toBnNum(selectedDueInvoice.dueAmount)}
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmitDuePay} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  পরিশোধের পরিমাণ (টাকা):
                </label>
                <input
                  type="number"
                  max={selectedDueInvoice.dueAmount}
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 text-base font-bold font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  নোট / মন্তব্য (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  placeholder="যেমন: নগদ ৫০০ টাকা দিল"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedDueInvoice(null)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  পরিশোধ নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
