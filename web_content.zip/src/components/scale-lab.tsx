import { useEffect, useRef, useState } from "react";

const WORLDS = [
  { name: "Sun", km: 1_392_700, au: 0 },
  { name: "Mercury", km: 4_879, au: 0.387 },
  { name: "Venus", km: 12_104, au: 0.723 },
  { name: "Earth", km: 12_742, au: 1 },
  { name: "Mars", km: 6_779, au: 1.524 },
  { name: "Jupiter", km: 139_820, au: 5.203 },
  { name: "Saturn", km: 116_460, au: 9.537 },
  { name: "Uranus", km: 50_724, au: 19.19 },
  { name: "Neptune", km: 49_244, au: 30.07 },
];

const SUN_PX = 220;

export function ScaleLab() {
  const [t, setT] = useState(0.35);
  const span = 0.45 * 70 ** t;
  const box = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(640);

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const measure = () => setWidth(el.clientWidth);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const pxPerAu = width / span;
  const sunR = Math.max(pxPerAu / 215, 0.6);

  return (
    <div className="grid gap-6">
      <figure className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
        <figcaption className="text-xs uppercase tracking-widest text-gold">Sizes, if the Sun is this circle</figcaption>
        <p className="mt-2 max-w-xl text-sm text-muted">
          Earth is the speck under the tick. Jupiter, the giant, is still a marble next to that Sun. Distances are ignored here — that lie is corrected below.
        </p>
        <div className="mt-5 overflow-x-auto pb-2">
          <div className="flex items-end gap-6" style={{ minWidth: SUN_PX + 420 }}>
            <div className="shrink-0 text-center">
              <div className="rounded-full bg-gold" style={{ width: SUN_PX, height: SUN_PX }} />
              <p className="mt-2 text-sm text-fg">Sun</p>
            </div>
            <ul className="flex items-end gap-4 pb-8">
              {WORLDS.filter((w) => w.name !== "Sun").map((w) => {
                const d = Math.max(3, (w.km / 1_392_700) * SUN_PX);
                return (
                  <li key={w.name} className="flex w-16 flex-col items-center gap-2">
                    <span className="block rounded-full bg-fg" style={{ width: d, height: d }} />
                    <span className="text-center text-xs text-muted">{w.name}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </figure>

      <figure className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
        <figcaption className="text-xs uppercase tracking-widest text-gold">Distances, at the same scale as the sizes</figcaption>
        <p className="mt-2 text-sm text-muted">
          The window shows {span < 10 ? span.toFixed(1) : span.toFixed(0)} AU. One AU is the Earth–Sun distance. At true scale the planets shrink to dots. That emptiness is the solar system.
        </p>
        <div ref={box} className="relative mt-4 h-48 overflow-hidden rounded-xl bg-bg">
          <div
            className="absolute top-1/2 rounded-full bg-gold"
            style={{
              width: sunR * 2,
              height: sunR * 2,
              left: 0,
              transform: "translateY(-50%)",
            }}
          />
          {WORLDS.filter((w) => w.au > 0 && w.au <= span * 1.02).map((w) => {
            const x = w.au * pxPerAu;
            const r = Math.max(1.5, (w.km / 1_392_700) * sunR);
            return (
              <div key={w.name} className="absolute top-1/2" style={{ left: x, transform: "translate(-50%, -50%)" }}>
                <span className="block rounded-full bg-fg" style={{ width: r * 2, height: r * 2 }} />
                <span className="absolute top-4 left-1/2 -translate-x-1/2 text-xs whitespace-nowrap text-muted">{w.name}</span>
              </div>
            );
          })}
        </div>
        <label className="mt-4 block text-sm text-muted">
          <span className="flex justify-between">
            Zoom out
            <span className="text-fg tabular-nums">to {span < 10 ? span.toFixed(1) : Math.round(span)} AU</span>
          </span>
          <input className="mt-2 w-full" type="range" min={0} max={1} step={0.01} value={t} onChange={(e) => setT(Number(e.target.value))} />
        </label>
        <p className="mt-3 text-sm text-fg">
          Light takes 8.3 minutes to cross 1 AU. Neptune, at 30 AU, is about 4 hours of light away — and still inside the Solar System.
        </p>
      </figure>
    </div>
  );
}
