import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { SPECIES_MAP } from '../data/species.ts';
import { Waves, Utensils, Sparkles, DollarSign, Wind, Wrench, Clock } from 'lucide-react';

export const Zone3Pond: React.FC = () => {
  const {
    player,
    aquaticTanks,
    feedAquatic,
    harvestAquatic,
    sellAquatic,
    toggleAquaticAerator,
    cleanAquaticFilter,
    collectMineralMud,
  } = useGame();

  const [waterFilterTab, setWaterFilterTab] = useState<'all' | 'freshwater' | 'shallow_sea' | 'moonlight_lake'>('all');
  const [sellModalSpecies, setSellModalSpecies] = useState<string | null>(null);
  const [sellCount, setSellCount] = useState<number>(1);
  const [feedModalSpecies, setFeedModalSpecies] = useState<string | null>(null);

  const tanksList = Object.values(aquaticTanks).filter((t) => {
    if (waterFilterTab === 'all') return true;
    return t.waterZone === waterFilterTab;
  });

  const now = Date.now();

  return (
    <div className="space-y-4">
      {/* Action Bar & Water Management System */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🐟</span>
            <div>
              <h2 className="text-base font-bold text-sky-300">Khu 3: Hồ Thủy Sinh & Đầm Sen</h2>
              <p className="text-xs text-stone-400">
                Quản lý 3 vùng nước • Máy sục khí oxy & Lọc bùn khoáng hữu cơ
              </p>
            </div>
          </div>

          {/* Lake Systems Controls */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Aerator Button */}
            <button
              type="button"
              onClick={toggleAquaticAerator}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-semibold transition ${
                player.aquaticAeratorOn
                  ? 'bg-sky-600/30 text-sky-300 border-sky-500/50'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
              title="Máy sục khí Oxy duy trì sự sống thủy sinh"
            >
              <Wind className={`w-3.5 h-3.5 ${player.aquaticAeratorOn ? 'text-sky-400 animate-spin-slow' : ''}`} />
              <span>Sục Khí: {player.aquaticAeratorOn ? 'Đang Bật' : 'Tắt'}</span>
            </button>

            {/* Filter Cleaning */}
            <button
              type="button"
              onClick={cleanAquaticFilter}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 transition"
              title="Làm sạch bộ lọc nước hồ"
            >
              <Wrench className="w-3.5 h-3.5 text-amber-400" />
              <span>Bộ Lọc: {Math.round(player.aquaticFilterDurability)}%</span>
            </button>

            {/* Mineral Mud Collection */}
            <button
              type="button"
              onClick={collectMineralMud}
              disabled={player.aquaticMineralMudReady <= 0}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-bold transition ${
                player.aquaticMineralMudReady > 0
                  ? 'bg-amber-600/30 text-amber-300 border-amber-500/50 hover:bg-amber-600/50'
                  : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
              }`}
              title="Thu gom bùn khoáng đáy hồ dùng ủ phân bón ở Khu 6"
            >
              <span>🏺 Thu Bùn Khoáng ({player.aquaticMineralMudReady})</span>
            </button>
          </div>
        </div>

        {/* 3 Water Zone Filters */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-stone-800 text-xs">
          <span className="text-stone-400 font-semibold mr-1">Vùng nước:</span>
          {[
            { id: 'all', label: 'Tất Cả Hồ' },
            { id: 'freshwater', label: '🏞️ Hồ Nước Ngọt' },
            { id: 'shallow_sea', label: '🏖️ Vùng Biển Cạn' },
            { id: 'moonlight_lake', label: '🌙 Hồ Nguyệt Quang' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setWaterFilterTab(tab.id as any)}
              className={`px-2.5 py-1 rounded-lg border font-semibold transition ${
                waterFilterTab === tab.id
                  ? 'bg-sky-500/20 text-sky-300 border-sky-400 shadow-sm'
                  : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {tanksList.length === 0 ? (
        <div className="text-center py-12 bg-stone-900/60 rounded-xl border border-stone-800 text-stone-400 text-sm">
          <p>Chưa có loài thủy sinh nào trong vùng nước này!</p>
          <p className="mt-1 text-sky-400">Hãy đến Khu 7 (Thương Cảng) để mua cá giống, tôm, cua.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {tanksList.map((tank) => {
            const sp = SPECIES_MAP.get(tank.speciesId);
            if (!sp) return null;

            const isRipe = tank.readyAt && now >= tank.readyAt;
            const remainingSec = tank.readyAt ? Math.max(0, Math.ceil((tank.readyAt - now) / 1000)) : 0;

            const favBonus =
              tank.favoriteFoodLevel >= 100
                ? 20
                : tank.favoriteFoodLevel >= 75
                ? 15
                : tank.favoriteFoodLevel >= 50
                ? 10
                : tank.favoriteFoodLevel >= 25
                ? 5
                : 0;

            return (
              <div
                key={tank.speciesId}
                className={`bg-stone-900/90 border-2 rounded-2xl p-3.5 shadow-md flex flex-col justify-between space-y-3 transition ${
                  isRipe ? 'border-sky-400 ring-2 ring-sky-400/40 bg-sky-950/20' : 'border-stone-800'
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl p-1.5 bg-stone-800 rounded-xl border border-stone-700">
                      {sp.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-bold text-stone-100 text-sm sm:text-base">{sp.name}</h3>
                        <span className="text-[10px] px-1.5 py-0.2 bg-sky-950 text-sky-300 rounded border border-sky-600/50 font-bold">
                          Bậc {sp.tier}
                        </span>
                      </div>
                      <p className="text-xs text-stone-400">
                        Đang nuôi: <strong className="text-sky-400">{tank.count}/10 con</strong> • Cho ra: {sp.harvestProductIcon} {sp.harvestProductName}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSellModalSpecies(tank.speciesId);
                      setSellCount(1);
                    }}
                    className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-rose-300 border border-stone-700 transition"
                  >
                    <DollarSign className="w-3 h-3 text-rose-400" />
                    <span>Bán Bớt</span>
                  </button>
                </div>

                {/* Status Bars: Hunger & Favorite Food Milestones */}
                <div className="space-y-2.5 bg-stone-950/60 p-2.5 rounded-xl border border-stone-800/80 text-xs">
                  {/* Hunger Bar */}
                  <div>
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="flex items-center gap-1 text-stone-300 font-semibold">
                        <Utensils className="w-3 h-3 text-amber-400" />
                        Độ No (Cần no 100% để tạo sản phẩm)
                      </span>
                      <strong className={tank.hunger >= 100 ? 'text-emerald-400' : 'text-amber-400'}>
                        {tank.hunger}%
                      </strong>
                    </div>
                    <div className="w-full bg-stone-800 rounded-full h-2 overflow-hidden border border-stone-700">
                      <div
                        className="bg-sky-500 h-full transition-all duration-300"
                        style={{ width: `${tank.hunger}%` }}
                      />
                    </div>
                  </div>

                  {/* Favorite Food Milestones */}
                  <div>
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="flex items-center gap-1 text-stone-300 font-semibold">
                        <Sparkles className="w-3 h-3 text-emerald-400" />
                        Mức Thức Ăn Yêu Thích (Cột mốc vĩnh viễn)
                      </span>
                      <strong className="text-emerald-300 font-bold">
                        {tank.favoriteFoodLevel}% (+{favBonus}% Sản Lượng)
                      </strong>
                    </div>
                    <div className="w-full bg-stone-800 rounded-full h-2 overflow-hidden border border-stone-700">
                      <div
                        className="bg-emerald-500 h-full transition-all duration-300"
                        style={{ width: `${tank.favoriteFoodLevel}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[9px] text-stone-400 mt-1 font-semibold px-0.5">
                      <span className={tank.favoriteFoodLevel >= 25 ? 'text-emerald-400' : ''}>25% (+5%)</span>
                      <span className={tank.favoriteFoodLevel >= 50 ? 'text-emerald-400' : ''}>50% (+10%)</span>
                      <span className={tank.favoriteFoodLevel >= 75 ? 'text-emerald-400' : ''}>75% (+15%)</span>
                      <span className={tank.favoriteFoodLevel >= 100 ? 'text-emerald-400 font-bold' : ''}>100% (Tối đa +20%)</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    disabled={tank.hunger >= 100}
                    onClick={() => setFeedModalSpecies(tank.speciesId)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition ${
                      tank.hunger < 100
                        ? 'bg-sky-600 hover:bg-sky-500 text-white border-sky-500 shadow'
                        : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
                    }`}
                  >
                    <Utensils className="w-3.5 h-3.5" />
                    <span>{tank.hunger >= 100 ? 'Đã No Đủ' : `Cho Ăn (${tank.count} phần)`}</span>
                  </button>

                  {isRipe ? (
                    <button
                      type="button"
                      onClick={() => harvestAquatic(tank.speciesId)}
                      className="flex items-center gap-1 px-4 py-1.5 rounded-xl bg-sky-400 hover:bg-sky-300 text-stone-950 font-black border border-sky-300 shadow-lg ring-2 ring-sky-300/60"
                    >
                      <Waves className="w-3.5 h-3.5" />
                      <span>✨ Kéo Lưới!</span>
                    </button>
                  ) : tank.readyAt ? (
                    <div className="flex items-center gap-1 text-xs text-stone-400 font-semibold bg-stone-800 px-2.5 py-1.5 rounded-xl border border-stone-700">
                      <Clock className="w-3.5 h-3.5 text-sky-400" />
                      <span>{remainingSec}s</span>
                    </div>
                  ) : (
                    <span className="text-[11px] text-stone-500 italic">Đang đói - cần cho ăn</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Feed Aquatic Modal */}
      {feedModalSpecies && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-sky-300 text-sm flex items-center gap-1.5">
                <span>🥣</span> Cho Đàn Cá Ăn
              </h3>
              <button
                type="button"
                onClick={() => setFeedModalSpecies(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  feedAquatic(feedModalSpecies, 'basic');
                  setFeedModalSpecies(null);
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-left text-stone-200"
              >
                <div>
                  <div className="font-bold text-sky-300">Thức Ăn Thủy Sinh Cơ Bản</div>
                  <div className="text-[10px] text-stone-400">Làm no đàn cá • Tích lũy +5% yêu thích</div>
                </div>
                <span className="font-bold text-sky-400">Cho Ăn</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  feedAquatic(feedModalSpecies, 'favorite');
                  setFeedModalSpecies(null);
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-stone-800 hover:bg-stone-700 border border-emerald-500/50 text-left text-emerald-200"
              >
                <div>
                  <div className="font-bold text-emerald-300">✨ Mồi Đặc Biệt Khoái Khẩu</div>
                  <div className="text-[10px] text-stone-400">Tăng vọt +25% vào mốc sản lượng vĩnh viễn!</div>
                </div>
                <span className="font-bold text-emerald-400">Cho Ăn</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Sell Aquatic */}
      {sellModalSpecies && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-rose-300 text-sm flex items-center gap-1.5">
                <span>💰</span> Bán Bớt Thủy Hải Sản
              </h3>
              <button
                type="button"
                onClick={() => setSellModalSpecies(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            {(() => {
              const tank = aquaticTanks[sellModalSpecies];
              const sp = SPECIES_MAP.get(sellModalSpecies);
              if (!tank || !sp) return null;

              return (
                <div className="space-y-3 text-xs">
                  <p className="text-stone-300">
                    Chọn số lượng <strong>{sp.name}</strong> muốn bán (Hiện có {tank.count} con trong bể):
                  </p>

                  <div className="flex items-center justify-center gap-3 py-2 bg-stone-950 rounded-xl border border-stone-800">
                    <button
                      type="button"
                      onClick={() => setSellCount(Math.max(1, sellCount - 1))}
                      className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                    >
                      -
                    </button>
                    <span className="text-lg font-black text-sky-400 w-12 text-center">{sellCount}</span>
                    <button
                      type="button"
                      onClick={() => setSellCount(Math.min(tank.count, sellCount + 1))}
                      className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                    >
                      +
                    </button>
                    <button
                      type="button"
                      onClick={() => setSellCount(tank.count)}
                      className="px-2 py-1 text-[11px] rounded bg-sky-600 hover:bg-sky-500 font-bold text-stone-950"
                    >
                      Tất Cả
                    </button>
                  </div>

                  <div className="text-center text-stone-400">
                    Thu về: <strong className="text-amber-400 font-bold">{(sp.baseSellPrice * 5 * sellCount).toLocaleString()} 🪙 Vàng</strong>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-stone-800">
                    <button
                      type="button"
                      onClick={() => setSellModalSpecies(null)}
                      className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold"
                    >
                      Hủy
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        sellAquatic(sellModalSpecies, sellCount);
                        setSellModalSpecies(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold"
                    >
                      Xác Nhận Bán
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
