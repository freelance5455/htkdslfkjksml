/**
 * GODEX v0.0.1 - Project Explorer & File Tree
 */

import React, { useState } from 'react';
import { 
  FileCode, FileJson, FileText, Folder, FolderOpen, 
  Plus, Trash2, Edit2, Search, File, Layers, ChevronRight, ChevronDown,
  FolderArchive
} from 'lucide-react';

interface SidebarProjectTreeProps {
  files: Record<string, string>;
  activeFile: string;
  onSelectFile: (path: string) => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (path: string) => void;
  onRenameFile: (oldPath: string, newPath: string) => void;
  onOpenTemplates: () => void;
  onOpenImportProject?: () => void;
}

export const SidebarProjectTree: React.FC<SidebarProjectTreeProps> = ({
  files,
  activeFile,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onOpenTemplates,
  onOpenImportProject
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [collapsedFolders, setCollapsedFolders] = useState<Record<string, boolean>>({});

  const filePaths = Object.keys(files).sort();

  const getFileIcon = (path: string) => {
    if (path.endsWith('.tsx') || path.endsWith('.ts')) return <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />;
    if (path.endsWith('.json')) return <FileJson className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
    if (path.endsWith('.css')) return <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0" />;
    if (path.endsWith('.py')) return <FileCode className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
    return <File className="w-3.5 h-3.5 text-neutral-400 shrink-0" />;
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    let path = newFileName.trim();
    if (!path.startsWith('src/') && !path.includes('/')) {
      path = 'src/' + path;
    }
    onCreateFile(path);
    setNewFileName('');
    setIsCreatingFile(false);
  };

  const filteredFiles = filePaths.filter(path => 
    path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full md:w-56 lg:w-64 h-full border-r border-[#1C2230] bg-[#090B10] flex flex-col shrink-0 select-none">
      {/* Explorer Header */}
      <div className="h-9 px-3 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017]">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 font-mono">
            REPO_FILES
          </span>
          <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-[#151B27] text-cyan-400 border border-[#222A3C]">
            {filteredFiles.length}
          </span>
        </div>
        <div className="flex items-center gap-1">
          {onOpenImportProject && (
            <button
              onClick={onOpenImportProject}
              className="p-1 rounded text-neutral-400 hover:text-cyan-300 hover:bg-[#161C2A] transition-colors"
              title="Import Project (ZIP)"
            >
              <FolderArchive className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => setIsCreatingFile(true)}
            className="p-1 rounded text-neutral-400 hover:text-cyan-300 hover:bg-[#161C2A] transition-colors"
            title="New File"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onOpenTemplates}
            className="p-1 rounded text-neutral-400 hover:text-cyan-300 hover:bg-[#161C2A] transition-colors"
            title="Starter Templates"
          >
            <Layers className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-2 border-b border-[#1C2230] bg-[#090B10]">
        <div className="relative flex items-center">
          <Search className="w-3 h-3 text-neutral-500 absolute left-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="filter files..."
            className="w-full h-6 pl-7 pr-2 bg-[#0E121A] border border-[#1C2333] rounded text-xs font-mono text-neutral-300 placeholder-neutral-600 focus:outline-none focus:border-cyan-500/50"
          />
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5 font-mono text-xs">
        {/* New File Inline Form */}
        {isCreatingFile && (
          <form onSubmit={handleCreateSubmit} className="mb-2 p-1.5 bg-[#0E121A] border border-cyan-500/60 rounded flex items-center gap-1.5">
            <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <input
              type="text"
              autoFocus
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="e.g. src/components/Button.tsx"
              className="flex-1 bg-transparent text-xs text-white placeholder-neutral-600 focus:outline-none font-mono"
            />
            <button type="submit" className="text-[9px] text-cyan-400 font-bold px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800">
              ADD
            </button>
            <button 
              type="button" 
              onClick={() => setIsCreatingFile(false)} 
              className="text-[10px] text-neutral-500 hover:text-neutral-300"
            >
              ✕
            </button>
          </form>
        )}

        {filteredFiles.map(path => {
          const isSelected = activeFile === path;
          const fileSize = files[path]?.length || 0;
          return (
            <div
              key={path}
              onClick={() => onSelectFile(path)}
              className={`group flex items-center justify-between px-2 py-1.5 rounded cursor-pointer transition-colors ${
                isSelected 
                  ? 'bg-[#151C2A] text-cyan-300 font-semibold border border-[#232F46]' 
                  : 'text-neutral-400 hover:bg-[#0E121A] hover:text-neutral-200 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2 overflow-hidden truncate">
                {getFileIcon(path)}
                <span className="truncate">{path}</span>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[9px] text-neutral-600 font-mono group-hover:hidden">
                  {(fileSize / 1024).toFixed(1)}k
                </span>
                
                {/* Action buttons on hover */}
                <div className="hidden group-hover:flex items-center gap-1">
                  {path !== 'src/App.tsx' && path !== 'package.json' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete ${path}?`)) onDeleteFile(path);
                      }}
                      className="p-0.5 text-neutral-500 hover:text-rose-400 transition-colors"
                      title="Delete File"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
