import React, { useState } from 'react';
import {
  Package,
  Plus,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  Sparkles,
  CheckCircle,
  Truck,
  FileText,
  Clock,
  ShieldCheck,
  Search,
  ExternalLink,
  ChevronRight,
  UploadCloud,
  Store,
  Trash2,
} from 'lucide-react';
import { Product, Seller, Order, SettlementLedgerEntry } from '../../types';

interface SellerPortalProps {
  currentSeller?: Seller | null;
  sellers?: Seller[];
  products: Product[];
  orders: Order[];
  settlements: SettlementLedgerEntry[];
  onAddProduct: (product: Product) => void;
  onUpdateStock: (productId: string, variantId: string | undefined, newStock: number) => void;
  onShipOrderItem: (orderId: string, productId: string, awbNumber: string) => void;
  onSelectSeller?: (sellerId: string) => void;
  onOpenRegistration?: () => void;
  onDeleteSeller?: (sellerId: string) => void;
}

export const SellerPortal: React.FC<SellerPortalProps> = ({
  currentSeller,
  sellers = [],
  products,
  orders,
  settlements,
  onAddProduct,
  onUpdateStock,
  onShipOrderItem,
  onSelectSeller,
  onOpenRegistration,
  onDeleteSeller,
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'guide' | 'products' | 'orders' | 'settlements' | 'kyc'>('dashboard');

  // Product Creation Modal & AI Drafter
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('Audio');
  const [newPrice, setNewPrice] = useState<number>(1499);
  const [newMrp, setNewMrp] = useState<number>(2999);
  const [newStock, setNewStock] = useState<number>(50);
  const [newImageUrl, setNewImageUrl] = useState<string>(
    'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80'
  );
  const [newDescription, setNewDescription] = useState<string>('');
  const [newHook, setNewHook] = useState<string>('');
  const [isAiDrafting, setIsAiDrafting] = useState<boolean>(false);
  const [aiDraftError, setAiDraftError] = useState<string | null>(null);

  // Filter seller's products
  const sellerProducts = currentSeller ? products.filter((p) => p.sellerId === currentSeller.id) : [];

  // Filter orders containing items from this seller
  const sellerOrders = currentSeller
    ? orders.filter((o) => o.items.some((item) => item.sellerId === currentSeller.id))
    : [];

  // Compute metrics
  const totalRevenue = currentSeller
    ? sellerOrders
        .filter((o) => o.status !== 'CANCELLED')
        .reduce((sum, o) => {
          const itemsSum = o.items
            .filter((it) => it.sellerId === currentSeller.id)
            .reduce((sub, it) => sub + it.totalPrice, 0);
          return sum + itemsSum;
        }, 0)
    : 0;

  const pendingDispatches = currentSeller
    ? sellerOrders.filter((o) =>
        o.items.some((it) => it.sellerId === currentSeller.id && it.status === 'CONFIRMED')
      ).length
    : 0;

  const lowStockCount = sellerProducts.filter((p) => p.stock < 10).length;

  // Gemini AI Product Auto-Drafter
  const handleAiDraft = async () => {
    setIsAiDrafting(true);
    setAiDraftError(null);
    try {
      const res = await fetch('/api/ai/describe-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle || 'Wireless Noise Cancelling Studio Headphones',
          category: newCategory,
          initialFeatures: 'High-res audio, 40-hour battery, plush memory foam earcups, Bluetooth 5.3',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        const d = data.data;
        if (d.productTitle) setNewTitle(d.productTitle);
        if (d.shortHook) setNewHook(d.shortHook);
        if (d.bulletPoints) setNewDescription(d.bulletPoints.join('\n'));
        if (d.suggestedSellingPrice) setNewPrice(d.suggestedSellingPrice);
        if (d.suggestedMmr) setNewMrp(d.suggestedMmr);
      }
    } catch (err: any) {
      setAiDraftError('Could not connect to Gemini AI draft engine. Filled standard draft template.');
      setNewHook('Engineered for premium performance and verified by PCMART standard.');
      setNewDescription('• 40mm Dynamic Neodymium Drivers\n• Ultra-soft memory cushions\n• Type-C fast recharge');
    } finally {
      setIsAiDrafting(false);
    }
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const prod: Product = {
      id: `pcm_prod_${Date.now().toString().slice(-5)}`,
      title: newTitle || 'PCMART Verified Audio Headphones',
      shortHook: newHook || 'Premium choice audio equipment with manufacturer warranty.',
      description: newDescription || 'Standard high quality build.',
      category: newCategory,
      brand: currentSeller?.storeName ? currentSeller.storeName.split(' ')[0] : 'PCMART',
      sellerId: currentSeller?.id || 'seller_new',
      sellerName: currentSeller?.storeName || 'Registered Merchant',
      sellerRating: currentSeller?.rating || 5.0,
      price: Number(newPrice),
      mrp: Number(newMrp),
      discountPercentage: Math.round(((newMrp - newPrice) / newMrp) * 100),
      rating: 5.0,
      ratingCount: 1,
      images: [newImageUrl],
      variants: [
        {
          id: `var_${Date.now()}`,
          name: 'Standard Edition',
          sku: `SKU-${Date.now().toString().slice(-4)}`,
          price: Number(newPrice),
          mrp: Number(newMrp),
          stock: Number(newStock),
        },
      ],
      stock: Number(newStock),
      inStock: true,
      codAvailable: true,
      deliveryDays: 3,
      tags: ['seller-exclusive', newCategory.toLowerCase(), 'pcmart-choice'],
      specifications: {
        Warranty: '1 Year Brand Warranty',
        Origin: 'Made in India',
      },
      warranty: '1 Year Brand Warranty',
      returnPolicy: '7 Days Return / Refund',
      approvalStatus: 'APPROVED',
      createdAt: new Date().toISOString(),
    };

    onAddProduct(prod);
    setShowAddModal(false);
    // Reset
    setNewTitle('');
    setNewHook('');
    setNewDescription('');
  };

  // If no seller account exists, render pristine empty state with registration action
  if (!currentSeller) {
    return (
      <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 p-6 overflow-y-auto items-center justify-center min-h-[600px]">
        <div className="max-w-xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-6 shadow-2xl">
          <div className="w-20 h-20 rounded-3xl bg-blue-950/80 border border-blue-500/40 text-blue-400 flex items-center justify-center mx-auto shadow-inner">
            <Store className="w-10 h-10 text-[#FFD447]" />
          </div>

          <div className="space-y-2">
            <span className="bg-amber-950/80 text-[#FFD447] border border-amber-500/40 text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full inline-block">
              0 Active Sellers • All Old Accounts Removed
            </span>
            <h2 className="text-2xl font-black text-white">PCMART Seller Portal</h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Abhi app me koi seller account nahi hai (sab remove kar diye gaye hain). Agar aapko apna saman bechna hai to niche diye button se turant apni nayi dukan kholein:
            </p>
          </div>

          {/* 3 Step Visual Guide */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-black text-[#FFD447] uppercase">Kadam 1</span>
              <h4 className="text-xs font-bold text-white">Dukan Registration</h4>
              <p className="text-[11px] text-slate-400 leading-snug">Dukan ka naam, GSTIN/PAN aur Bank account details dalein.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-black text-[#FFD447] uppercase">Kadam 2</span>
              <h4 className="text-xs font-bold text-white">Instant Activation</h4>
              <p className="text-[11px] text-slate-400 leading-snug">Account turant verify ho kar live activate ho jata hai.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-black text-[#FFD447] uppercase">Kadam 3</span>
              <h4 className="text-xs font-bold text-white">AI Catalog & Payout</h4>
              <p className="text-[11px] text-slate-400 leading-snug">Gemini AI se product add karein aur direct bank payout paayein.</p>
            </div>
          </div>

          {onOpenRegistration && (
            <button
              onClick={onOpenRegistration}
              className="w-full py-3.5 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-2xl shadow-lg flex items-center justify-center gap-2 text-sm transition-transform active:scale-95 cursor-pointer"
            >
              <Store className="w-5 h-5" />
              <span>+ Nayi Dukan Kholein (Register New Store)</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Top Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-white">{currentSeller.storeName}</h1>
            <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> GSTIN Verified
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Merchant ID: {currentSeller.id} • Registered in {currentSeller.city}, {currentSeller.state} • Platform Commission: 12%
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Store Switcher */}
          {sellers.length > 0 && onSelectSeller && (
            <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300">
              <span className="text-[10px] text-slate-500 font-bold uppercase">Store:</span>
              <select
                value={currentSeller.id}
                onChange={(e) => onSelectSeller(e.target.value)}
                className="bg-transparent text-white font-bold focus:outline-none cursor-pointer"
              >
                {sellers.map((s) => (
                  <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                    {s.storeName} ({s.city})
                  </option>
                ))}
              </select>
            </div>
          )}

          {onOpenRegistration && (
            <button
              onClick={onOpenRegistration}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl border border-slate-700 flex items-center gap-1.5"
            >
              <Store className="w-3.5 h-3.5 text-[#FFD447]" /> + Nayi Dukan Kholein
            </button>
          )}

          {onDeleteSeller && (
            <button
              onClick={() => onDeleteSeller(currentSeller.id)}
              className="px-3 py-2 bg-red-950/70 hover:bg-red-900 text-red-300 text-xs font-bold rounded-xl border border-red-500/40 flex items-center gap-1.5 transition-colors"
              title="Remove this seller account"
            >
              <Trash2 className="w-3.5 h-3.5" /> Dukan Hatayein
            </button>
          )}

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow flex items-center gap-1.5 transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4" /> Add New Product
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-6 flex gap-6 text-xs font-bold text-slate-400 overflow-x-auto">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'dashboard' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Overview & Metrics
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'guide' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-[#FFD447]" />
          <span>Kaise Sell Karein? (Seller Guide)</span>
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'products' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          My Inventory ({sellerProducts.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'orders' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Orders & Dispatch ({sellerOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('settlements')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'settlements' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Earnings & Bank Settlements
        </button>
        <button
          onClick={() => setActiveTab('kyc')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'kyc' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Tax & KYC Details
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="p-6 space-y-6 flex-1">
        {/* TAB: HOW TO SELL GUIDE */}
        {activeTab === 'guide' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
            <div className="text-center space-y-2">
              <span className="text-xs bg-[#1746A2] text-white px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                PCMART Merchant Academy
              </span>
              <h2 className="text-2xl font-black text-white">
                PCMART Par Dukan Kaise Chalayein aur Product Kaise Bechein?
              </h2>
              <p className="text-xs text-slate-300 max-w-xl mx-auto">
                PCMART par selling ka complete process 4 simple steps me samjhein. Zero technical knowledge required!
              </p>
            </div>

            {/* 4 Steps Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Step 1 */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 relative overflow-hidden group hover:border-[#FFD447] transition-all">
                <div className="w-10 h-10 rounded-2xl bg-[#1746A2] text-[#FFD447] flex items-center justify-center font-black text-base shadow">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">Step 1: Dukan & Bank Account Set Karein</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Apni dukan ka naam, GSTIN number, aur bank account verify karein. PCMART 100% legal & GST compliant marketplace hai jahan aapka data secure rehta hai.
                  </p>
                </div>
                <div className="pt-2 text-[11px] text-emerald-400 font-semibold flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" /> Aapka Store: {currentSeller.storeName} ({currentSeller.status})
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 relative overflow-hidden group hover:border-[#FFD447] transition-all">
                <div className="w-10 h-10 rounded-2xl bg-[#FFD447] text-slate-950 flex items-center justify-center font-black text-base shadow">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">Step 2: Gemini AI se 1-Click Product List Karein</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Photo upload karein ya basic naam daalein — hamara **Gemini 3.8 Flash AI** aapke liye attractive title, 5 bullet points, market price analysis aur return warranty auto-generate kar deta hai.
                  </p>
                </div>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="mt-2 text-xs text-[#FFD447] hover:underline font-bold flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5" /> Add Product with AI Drafter →
                </button>
              </div>

              {/* Step 3 */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 relative overflow-hidden group hover:border-[#FFD447] transition-all">
                <div className="w-10 h-10 rounded-2xl bg-blue-900 text-blue-200 flex items-center justify-center font-black text-base shadow">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">Step 3: Order Aane Par Pack & Dispatch Karein</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Jab customer aapka item order karega, wo aapke **"Orders"** section me dikhega. 1-click me BlueDart / Delhivery AWB tracking label generate karein aur courier ko handover karein.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="mt-2 text-xs text-blue-300 hover:underline font-bold flex items-center gap-1"
                >
                  <Truck className="w-3.5 h-3.5" /> Check Pending Orders ({sellerOrders.length}) →
                </button>
              </div>

              {/* Step 4 */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 relative overflow-hidden group hover:border-[#FFD447] transition-all">
                <div className="w-10 h-10 rounded-2xl bg-emerald-950 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-black text-base shadow">
                  4
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">Step 4: Seedha Bank Me Paisa Transfer (Settlement)</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Customer ko delivery hone par PCMART ka **12% commission aur 2% PG fee** deduct hokar, baaki saara paisa automatic aapke bank account ({currentSeller.bankAccount.bankName}) me direct credit ho jata hai.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('settlements')}
                  className="mt-2 text-xs text-emerald-400 hover:underline font-bold flex items-center gap-1"
                >
                  <DollarSign className="w-3.5 h-3.5" /> View Bank Settlement Ledger →
                </button>
              </div>
            </div>

            {/* Seller Commission Transparency Card */}
            <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-3 text-xs">
              <h4 className="text-xs font-black text-white uppercase tracking-wider">
                Transparent Fee Calculation (Paisa Kaise Calculate Hota Hai)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-center">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Product Selling Price</span>
                  <span className="font-extrabold text-white text-sm">₹1,000</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">PCMART Fee (12%)</span>
                  <span className="font-extrabold text-red-400 text-sm">-₹120</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">PG & GST Fee</span>
                  <span className="font-extrabold text-red-400 text-sm">-₹45.20</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-emerald-500/40 bg-emerald-950/20">
                  <span className="text-emerald-400 block text-[10px] font-bold">Aapke Bank Me Credit</span>
                  <span className="font-black text-[#FFD447] text-sm">₹834.80 Net</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Total Gross Sales</span>
                <div className="text-2xl font-black text-white">₹{totalRevenue.toLocaleString()}</div>
                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> +18.4% from last month
                </span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Pending Dispatch</span>
                <div className="text-2xl font-black text-[#FFD447]">{pendingDispatches} Orders</div>
                <span className="text-[11px] text-amber-400">Requires packing within 24h</span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Settlement Balance</span>
                <div className="text-2xl font-black text-white">
                  ₹{currentSeller.balanceAvailable.toLocaleString()}
                </div>
                <span className="text-[11px] text-slate-400">Next payout scheduled on Friday</span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Seller Rating</span>
                <div className="text-2xl font-black text-emerald-400">★ {currentSeller.rating}</div>
                <span className="text-[11px] text-slate-400">Based on {currentSeller.totalOrders} fulfilled items</span>
              </div>
            </div>

            {/* Quick Actions & Low Stock Alerts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Recent Customer Orders
                  </h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-[#FFD447] hover:underline font-semibold"
                  >
                    View All
                  </button>
                </div>

                <div className="divide-y divide-slate-800">
                  {sellerOrders.slice(0, 4).map((ord) => (
                    <div key={ord.id} className="py-3 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white block">{ord.orderNumber}</span>
                        <span className="text-[11px] text-slate-400">
                          Customer: {ord.customerName} • {ord.shippingAddress.city}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-[#FFD447] block">₹{ord.totalAmount}</span>
                        <span className="text-[10px] text-slate-400">{ord.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Gemini AI Seller Assistant Banner */}
              <div className="bg-gradient-to-br from-[#1746A2]/40 to-slate-900 border border-blue-800/40 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#FFD447] text-slate-950 flex items-center justify-center font-bold">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">AI Catalogue Assist</h4>
                    <span className="text-[10px] text-blue-200">Gemini 3.8 Flash</span>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Draft engaging descriptions, SEO keywords, and optimal price recommendations directly from your product specs.
                </p>
                <button
                  onClick={() => {
                    setShowAddModal(true);
                    handleAiDraft();
                  }}
                  className="w-full py-2 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow"
                >
                  Try AI Product Drafter
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: INVENTORY */}
        {activeTab === 'products' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                My Listed Catalogue ({sellerProducts.length})
              </h3>
              <button
                onClick={() => setShowAddModal(true)}
                className="px-3 py-1.5 bg-[#FFD447] text-slate-950 font-bold text-xs rounded-xl"
              >
                + Add Product
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] font-bold">
                  <tr>
                    <th className="p-3">Product</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Selling Price</th>
                    <th className="p-3">MRP</th>
                    <th className="p-3">Stock Units</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Quick Stock Update</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {sellerProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3 flex items-center gap-2.5">
                        <img src={p.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                          <span className="font-bold text-white block">{p.title}</span>
                          <span className="text-[10px] text-slate-400">ID: {p.id}</span>
                        </div>
                      </td>
                      <td className="p-3">{p.category}</td>
                      <td className="p-3 font-bold text-[#FFD447]">₹{p.price}</td>
                      <td className="p-3 text-slate-400 line-through">₹{p.mrp}</td>
                      <td className="p-3">
                        <span
                          className={`font-bold ${
                            p.stock < 10 ? 'text-red-400' : 'text-emerald-400'
                          }`}
                        >
                          {p.stock} in stock
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded text-[10px] font-bold">
                          {p.approvalStatus}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => onUpdateStock(p.id, p.selectedVariantId, Math.max(0, p.stock - 5))}
                            className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-300"
                          >
                            -5
                          </button>
                          <button
                            onClick={() => onUpdateStock(p.id, p.selectedVariantId, p.stock + 10)}
                            className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-300"
                          >
                            +10
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: ORDERS & DISPATCH */}
        {activeTab === 'orders' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Seller Fulfillment & Dispatch
            </h3>

            <div className="divide-y divide-slate-800">
              {sellerOrders.map((ord) => (
                <div key={ord.id} className="py-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-white text-sm">{ord.orderNumber}</span>
                      <span className="text-[11px] text-slate-400 block">
                        Ordered on {new Date(ord.createdAt).toLocaleDateString()} • Customer: {ord.customerName} (
                        {ord.shippingAddress.city}, {ord.shippingAddress.pincode})
                      </span>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded text-xs font-bold ${
                        ord.status === 'DELIVERED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                          : ord.status === 'SHIPPED'
                          ? 'bg-blue-950 text-blue-400 border border-blue-500/40'
                          : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                      }`}
                    >
                      {ord.status}
                    </span>
                  </div>

                  {/* Order items matching this seller */}
                  <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                    {ord.items
                      .filter((it) => it.sellerId === currentSeller.id)
                      .map((it, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <img src={it.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                            <div>
                              <span className="font-bold text-white">{it.title}</span>
                              <span className="text-[10px] text-slate-400 block">
                                Qty: {it.quantity} • Unit: ₹{it.unitPrice}
                              </span>
                            </div>
                          </div>
                          <span className="font-extrabold text-[#FFD447]">₹{it.totalPrice}</span>
                        </div>
                      ))}
                  </div>

                  {/* Dispatch actions */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Payment Mode: <strong className="text-white">{ord.paymentMethod}</strong> (
                      {ord.paymentStatus})
                    </span>

                    {ord.status === 'CONFIRMED' && (
                      <button
                        onClick={() => {
                          const awb = prompt('Enter BlueDart/Delhivery AWB Tracking Number:', `BD-${Date.now().toString().slice(-8)}`);
                          if (awb) {
                            onShipOrderItem(ord.id, ord.items[0].productId, awb);
                          }
                        }}
                        className="px-4 py-1.5 bg-[#1746A2] hover:bg-blue-600 text-white font-bold rounded-xl shadow"
                      >
                        Generate Label & Dispatch
                      </button>
                    )}
                    {ord.status === 'SHIPPED' && (
                      <span className="text-emerald-400 font-semibold">
                        Shipped via {ord.carrier} (AWB: {ord.trackingNumber})
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: SETTLEMENTS */}
        {activeTab === 'settlements' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Marketplace Settlement Ledger
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Clear breakdown of marketplace fees (12%), payment gateway fees (2%), and GST (18% on fees).
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Available Balance</span>
                  <span className="text-xl font-black text-emerald-400">
                    ₹{currentSeller.balanceAvailable.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] font-bold">
                    <tr>
                      <th className="p-3">Settlement ID</th>
                      <th className="p-3">Order Ref</th>
                      <th className="p-3">Gross Sale</th>
                      <th className="p-3">PCMART Fee (12%)</th>
                      <th className="p-3">PG Fee (2%)</th>
                      <th className="p-3">GST (18% on fees)</th>
                      <th className="p-3">Net Payout</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">UTR Reference</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {settlements.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-800/40">
                        <td className="p-3 font-mono font-bold text-white">{s.id}</td>
                        <td className="p-3">{s.orderId}</td>
                        <td className="p-3 font-semibold text-white">₹{s.grossAmount}</td>
                        <td className="p-3 text-red-400">-₹{s.commissionDeduction}</td>
                        <td className="p-3 text-red-400">-₹{s.pgFeeDeduction}</td>
                        <td className="p-3 text-red-400">-₹{s.gstDeduction}</td>
                        <td className="p-3 font-black text-[#FFD447]">₹{s.netPayout}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              s.status === 'SETTLED'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                            }`}
                          >
                            {s.status}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">{s.utrNumber || 'Processing batch'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: KYC */}
        {activeTab === 'kyc' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 max-w-2xl">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Merchant Verification & Banking Setup
            </h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 block text-[10px]">Registered GSTIN</span>
                  <span className="font-mono font-bold text-white text-sm">{currentSeller.gstin}</span>
                </div>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> Verified on GST Portal
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 block text-[10px]">Permanent Account Number (PAN)</span>
                  <span className="font-mono font-bold text-white text-sm">{currentSeller.pan}</span>
                </div>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> Verified
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 block text-[10px]">Direct Deposit Bank Account</span>
                  <span className="font-bold text-white text-sm">{currentSeller.bankAccount.bankName}</span>
                  <span className="text-slate-400 font-mono block text-[11px]">
                    {currentSeller.bankAccount.accountNumberMasked} • IFSC: {currentSeller.bankAccount.ifsc}
                  </span>
                </div>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> Auto-Settlement Active
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ADD PRODUCT MODAL WITH GEMINI DRAFTER */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-[#FFD447]" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  List New Product on PCMART
                </h3>
              </div>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            {/* AI Assist Tool Button */}
            <div className="p-3 bg-gradient-to-r from-[#1746A2]/40 to-slate-950 border border-blue-900/60 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#FFD447]" /> Gemini AI Auto-Drafter
                </span>
                <p className="text-[10px] text-slate-300">
                  Automatically generates premium title, hook, bullet points, and pricing!
                </p>
              </div>
              <button
                type="button"
                onClick={handleAiDraft}
                disabled={isAiDrafting}
                className="px-3 py-1.5 bg-[#FFD447] text-slate-950 font-black text-xs rounded-xl shadow disabled:opacity-50"
              >
                {isAiDrafting ? 'Drafting...' : '✨ Generate Draft'}
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Product Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. PCMart SoundPulse Pro ANC Wireless Earbuds"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                  >
                    <option value="Audio">Audio</option>
                    <option value="Smart Watches">Smart Watches</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Home & Office">Home & Office</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Stock Quantity</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newStock}
                    onChange={(e) => setNewStock(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Selling Price (₹)</label>
                  <input
                    type="number"
                    min="10"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">MRP (₹)</label>
                  <input
                    type="number"
                    min="10"
                    required
                    value={newMrp}
                    onChange={(e) => setNewMrp(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Marketing Hook / 2-Line Overview</label>
                <input
                  type="text"
                  value={newHook}
                  onChange={(e) => setNewHook(e.target.value)}
                  placeholder="Crisp hook highlighting why it is the premium choice"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Detailed Features / Bullet Points</label>
                <textarea
                  rows={4}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Key features..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Product Photo Image URL</label>
                <input
                  type="url"
                  required
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#FFD447] text-slate-950 font-black rounded-xl shadow"
                >
                  Submit for Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
