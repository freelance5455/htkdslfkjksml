import React, { useState } from 'react';
import {
  Store,
  CheckCircle2,
  ShieldCheck,
  Building2,
  CreditCard,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  X,
  FileCheck,
} from 'lucide-react';
import { Seller } from '../../types';

interface SellerRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisterSeller: (newSeller: Seller) => void;
}

export const SellerRegistrationModal: React.FC<SellerRegistrationModalProps> = ({
  isOpen,
  onClose,
  onRegisterSeller,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [storeName, setStoreName] = useState<string>('');
  const [ownerName, setOwnerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [state, setState] = useState<string>('Maharashtra');
  const [category, setCategory] = useState<string>('Electronics & Audio');

  // Business / Tax
  const [gstin, setGstin] = useState<string>('');
  const [pan, setPan] = useState<string>('');

  // Bank Account
  const [bankName, setBankName] = useState<string>('HDFC Bank');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [ifsc, setIfsc] = useState<string>('');

  if (!isOpen) return null;

  // Auto-fill demo details for rapid testing
  const handleAutoFillDemo = () => {
    setStoreName('Bharat Smart Gadgets');
    setOwnerName('Suresh Kumar');
    setPhone('+91 98200 12345');
    setEmail('suresh@bharatsmart.in');
    setCity('Jaipur');
    setState('Rajasthan');
    setCategory('Electronics & Audio');
    setGstin('08AABCS9876K1Z9');
    setPan('AABCS9876K');
    setBankName('State Bank of India');
    setAccountNumber('554433221199');
    setIfsc('SBIN0001234');
  };

  const handleCompleteRegistration = () => {
    const newSellerId = `seller_${Date.now().toString().slice(-5)}`;
    const newSeller: Seller = {
      id: newSellerId,
      storeName: storeName || 'Bharat Smart Gadgets',
      ownerName: ownerName || 'Suresh Kumar',
      email: email || 'seller@pcmart.in',
      phone: phone || '+91 98200 12345',
      gstin: gstin || '08AABCS9876K1Z9',
      pan: pan || 'AABCS9876K',
      city: city || 'Jaipur',
      state: state || 'Rajasthan',
      rating: 5.0,
      totalOrders: 0,
      status: 'VERIFIED',
      commissionRate: 0.12, // 12% marketplace commission
      bankAccount: {
        accountNumberMasked: `•••• •••• ${(accountNumber || '1234').slice(-4)}`,
        ifsc: ifsc || 'SBIN0001234',
        bankName: bankName || 'State Bank of India',
      },
      balanceAvailable: 0,
      joinedDate: new Date().toISOString().split('T')[0],
    };

    onRegisterSeller(newSeller);
    setStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl relative text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#1746A2] flex items-center justify-center text-[#FFD447] font-bold">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Sell on PCMART • Dukan Registration
              </h3>
              <span className="text-[11px] text-[#FFD447] font-medium">
                Reach Millions of Verified Buyers Across India
              </span>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Multi-step progress bar */}
        {step < 4 && (
          <div className="flex items-center justify-between px-2 pt-1 text-xs">
            <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-[#FFD447] font-bold' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full border flex items-center justify-center text-[10px]">1</span>
              <span>Dukan Info</span>
            </div>
            <div className="w-8 h-0.5 bg-slate-800"></div>
            <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-[#FFD447] font-bold' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full border flex items-center justify-center text-[10px]">2</span>
              <span>GSTIN & Tax</span>
            </div>
            <div className="w-8 h-0.5 bg-slate-800"></div>
            <div className={`flex items-center gap-1.5 ${step >= 3 ? 'text-[#FFD447] font-bold' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full border flex items-center justify-center text-[10px]">3</span>
              <span>Bank Payout</span>
            </div>
          </div>
        )}

        {/* STEP 1: Dukan & Personal Details */}
        {step === 1 && (
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white block">Step 1: Store & Contact Details</span>
              <button
                type="button"
                onClick={handleAutoFillDemo}
                className="text-[11px] text-[#FFD447] hover:underline font-bold flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" /> Auto-fill Sample Data
              </button>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Store / Business Name (Dukan Ka Naam)*</label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                placeholder="e.g. Bharat Smart Gadgets, Rajasthan Handlooms"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Owner Full Name*</label>
                <input
                  type="text"
                  required
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Suresh Kumar"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Phone Number (+91)*</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="98200 12345"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">City*</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Jaipur, Pune, Delhi"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Primary Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
                >
                  <option value="Electronics & Audio">Electronics & Audio</option>
                  <option value="Smart Watches">Smart Watches</option>
                  <option value="Fashion & Apparel">Fashion & Apparel</option>
                  <option value="Home & Office">Home & Office</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (!storeName || !ownerName) {
                  handleAutoFillDemo();
                }
                setStep(2);
              }}
              className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow mt-2 flex items-center justify-center gap-1.5"
            >
              Continue to Tax & GSTIN <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 2: GSTIN & Tax Verification */}
        {step === 2 && (
          <div className="space-y-3 text-xs">
            <span className="font-bold text-white block">Step 2: Business Tax & KYC Verification</span>
            <p className="text-slate-400 text-[11px]">
              Government compliance mandates verified 15-digit GSTIN & PAN for Indian e-commerce seller settlements.
            </p>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">15-Digit GSTIN Number*</label>
              <input
                type="text"
                required
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="e.g. 08AABCS9876K1Z9"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-white uppercase focus:outline-none focus:border-[#FFD447]"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Permanent Account Number (PAN)*</label>
              <input
                type="text"
                required
                value={pan}
                onChange={(e) => setPan(e.target.value.toUpperCase())}
                placeholder="e.g. AABCS9876K"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-white uppercase focus:outline-none focus:border-[#FFD447]"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-emerald-400 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 shrink-0" />
              <span>Instant KYC Verification enabled on GST portal.</span>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-2.5 bg-slate-800 text-slate-300 font-bold rounded-xl"
              >
                Back
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!gstin) setGstin('08AABCS9876K1Z9');
                  if (!pan) setPan('AABCS9876K');
                  setStep(3);
                }}
                className="flex-1 py-2.5 bg-[#FFD447] text-slate-950 font-black rounded-xl shadow flex items-center justify-center gap-1"
              >
                Continue to Bank Payout <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Bank Account for Direct Payouts */}
        {step === 3 && (
          <div className="space-y-3 text-xs">
            <span className="font-bold text-white block">Step 3: Direct Settlement Bank Account</span>
            <p className="text-slate-400 text-[11px]">
              Customer orders delivered hone par aapka payment (12% commission katne ke baad) isi bank account me direct UTR ke saath transfer hoga.
            </p>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Bank Name*</label>
              <select
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#FFD447]"
              >
                <option value="State Bank of India">State Bank of India (SBI)</option>
                <option value="HDFC Bank">HDFC Bank Ltd</option>
                <option value="ICICI Bank">ICICI Bank</option>
                <option value="Axis Bank">Axis Bank</option>
                <option value="Punjab National Bank">Punjab National Bank (PNB)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Bank Account Number*</label>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="e.g. 554433221199"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-white focus:outline-none focus:border-[#FFD447]"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold">IFSC Code*</label>
              <input
                type="text"
                required
                value={ifsc}
                onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                placeholder="e.g. SBIN0001234"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-white uppercase focus:outline-none focus:border-[#FFD447]"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="flex-1 py-2.5 bg-slate-800 text-slate-300 font-bold rounded-xl"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleCompleteRegistration}
                className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl shadow flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" /> Launch My Dukan!
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Success Confirmation */}
        {step === 4 && (
          <div className="py-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
              <Store className="w-8 h-8 text-[#FFD447]" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Mubarak Ho! Aapki Dukan Live Hai</h3>
              <p className="text-xs text-slate-300 mt-1 font-bold">
                Store: <span className="text-[#FFD447]">{storeName || 'Bharat Smart Gadgets'}</span>
              </p>
              <span className="text-[11px] text-emerald-400 block mt-1 font-semibold">
                ✓ GSTIN Verified • 12% Marketplace Commission Active
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left text-xs space-y-1.5">
              <span className="font-bold text-white block">Aapka Selling Process:</span>
              <p className="text-slate-300">
                1. <strong>Product Add Karein:</strong> Gemini AI Drafter se 1-click me photo aur details daalkar products list karein.
              </p>
              <p className="text-slate-300">
                2. <strong>Order Receive & Dispatch:</strong> Jab customer order karega, BlueDart/Delhivery AWB label generate karke ship karein.
              </p>
              <p className="text-slate-300">
                3. <strong>Direct Bank Settlement:</strong> Commission kat ke aapka net paisa direct aapke verified bank account me credit ho jayega.
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow"
            >
              Open My Seller Portal Now
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
