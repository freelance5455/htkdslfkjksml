import React, { useState } from 'react';
import { 
  Bell, 
  Phone, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  X, 
  Send, 
  MessageSquare, 
  ShieldCheck,
  Calendar
} from 'lucide-react';
import { WeeklyQuiz, UserProfile } from '../types';

interface QuizReminderModalProps {
  quiz: WeeklyQuiz;
  language: string;
  userProfile?: UserProfile;
  onClose: () => void;
}

export default function QuizReminderModal({
  quiz,
  language,
  userProfile,
  onClose
}: QuizReminderModalProps) {
  const [phoneNumber, setPhoneNumber] = useState<string>(() => {
    return localStorage.getItem('edumind_user_phone') || '';
  });
  const [enableBrowserPush, setEnableBrowserPush] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const userId = userProfile?.name 
    ? `user-${userProfile.name.toLowerCase().replace(/\s+/g, '-')}`
    : 'user-guest';

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
    if (cleanPhone.length > 0 && cleanPhone.length < 10) {
      setErrorMessage(language === 'bn' ? 'সঠিক ১০ সংখ্যার মোবাইল নম্বর দিন' : 'Please provide a valid 10-digit phone number');
      return;
    }

    setIsSubmitting(true);
    try {
      if (cleanPhone) {
        localStorage.setItem('edumind_user_phone', cleanPhone);
      }

      // Request browser notification permission if checked
      if (enableBrowserPush && typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
          await Notification.requestPermission();
        }
      }

      const res = await fetch(`/api/weekly-quiz/${quiz.id}/subscribe-reminder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          userName: userProfile?.name || 'StudySkill Learner',
          phone: cleanPhone || undefined,
          browserPushEnabled: enableBrowserPush
        })
      });

      if (!res.ok) {
        throw new Error('Failed to register subscription');
      }

      setIsSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2500);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save reminder');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl overflow-hidden">
        
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/30">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {language === 'bn' ? '১০ মিনিট আগের রিমাইন্ডার সেট করুন' : '10-Minute Prior Quiz Reminder'}
              </h3>
              <p className="text-xs text-slate-400">
                {quiz.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!isSuccess ? (
          <form onSubmit={handleSubscribe} className="space-y-4">
            {/* Quiz Schedule Summary Box */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  {language === 'bn' ? 'কুইজ তারিখ:' : 'Quiz Date:'} {quiz.startDate}
                </span>
                <span className="flex items-center gap-1.5 text-amber-300">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  {language === 'bn' ? 'আরম্ভের সময়:' : 'Start Time:'} {quiz.startTime}
                </span>
              </div>
              <p className="text-xs text-indigo-300 font-medium">
                {language === 'bn' 
                  ? `⏰ কুইজ আরম্ভ হওয়ার ঠিক ১০ মিনিট আগে আপনার ফোনে মেসেজ ও ইন-অ্যাপ অ্যালার্ট পাঠানো হবে যাতে সময়মতো জয়েন করতে পারেন।` 
                  : `You will receive a notification 10 minutes prior to quiz commencement.`}
              </p>
            </div>

            {/* Mobile Number Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-indigo-400" />
                  {language === 'bn' ? 'মোবাইল নম্বর (SMS ও WhatsApp অ্যালার্টের জন্য):' : 'Mobile Number (for SMS & Push):'}
                </span>
                <span className="text-[10px] text-slate-500 font-normal">ঐচ্ছিক / Optional</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-slate-500 font-mono">+91</span>
                <input
                  type="tel"
                  maxLength={10}
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="9876543210"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Checkbox: Browser Push Notifications */}
            <label className="flex items-center gap-2.5 p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl cursor-pointer hover:bg-slate-950 transition-all">
              <input
                type="checkbox"
                checked={enableBrowserPush}
                onChange={(e) => setEnableBrowserPush(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer"
              />
              <div className="text-xs">
                <span className="font-bold text-slate-200 block">
                  {language === 'bn' ? 'ব্রাউজার ও স্ক্রিন নোটিফিকেশন অ্যালার্ট' : 'Enable Device Screen Notification'}
                </span>
                <span className="text-[11px] text-slate-400 block">
                  {language === 'bn' ? 'অ্যাপ ব্যাকগ্রাউন্ডে থাকলেও স্ক্রিনে লাইভ পপআপ ও সাউন্ড অ্যালার্ট বাজবে।' : 'Play audio chime and screen banner alert.'}
                </span>
              </div>
            </label>

            {errorMessage && (
              <p className="text-xs font-bold text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/50">
                {errorMessage}
              </p>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer transition-all"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-2/3 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>{language === 'bn' ? 'সেভ হচ্ছে...' : 'Saving...'}</span>
                ) : (
                  <>
                    <Bell className="w-4 h-4" />
                    <span>{language === 'bn' ? '১০ মিনিট আগের অ্যালার্ট সেট করুন' : 'Set 10-Min Alert'}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          /* Success Screen */
          <div className="py-8 flex flex-col items-center justify-center text-center space-y-3 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-base font-extrabold text-white">
              {language === 'bn' ? 'রিমাইন্ডার সফলভাবে অ্যাক্টিভ হয়েছে!' : 'Reminder Successfully Set!'}
            </h4>
            <p className="text-xs text-slate-300 max-w-xs mx-auto">
              {language === 'bn' 
                ? `"${quiz.title}" কুইজটি শুরু হতে ঠিক ১০ মিনিট আগে (${quiz.startTime}-এর ১০ মিনিট পূর্বে) আপনার মোবাইলে মেসেজ ও অ্যালার্ট পাঠানো হবে।` 
                : `You will get an alert exactly 10 minutes before the quiz starts.`}
            </p>
          </div>
        )}

      </div>
    </div>
  );
}
