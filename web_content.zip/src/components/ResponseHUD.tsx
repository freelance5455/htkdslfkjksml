/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, ExternalLink, Copy, Check, Volume2, VolumeX } from 'lucide-react';
import { ChatMessage } from '../types/assistant';

interface ResponseHUDProps {
  message: ChatMessage | null;
  isSpeaking: boolean;
  onDismiss: () => void;
  onStopSpeech: () => void;
  onReplaySpeech: (text: string) => void;
}

export const ResponseHUD: React.FC<ResponseHUDProps> = ({
  message,
  isSpeaking,
  onDismiss,
  onStopSpeech,
  onReplaySpeech,
}) => {
  const [copied, setCopied] = useState(false);

  if (!message) return null;

  const handleCopy = (text: string) => {
    if (!text) return;
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenUrl = (url?: string) => {
    if (!url) return;
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
        window.open(url, '_blank', 'noopener,noreferrer');
      }
    } catch {
      console.warn('Blocked invalid URL:', url);
    }
  };

  return (
    <div className="absolute top-[26%] left-1/2 -translate-x-1/2 w-[92%] max-w-lg z-30 animate-in fade-in zoom-in-95 duration-200">
      <div className="bg-slate-950/90 border border-cyan-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-md">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-cyan-500/20">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span className="text-[11px] font-orbitron font-semibold tracking-widest text-cyan-300 uppercase">
              {message.role === 'user' ? 'YOU' : 'ELYSIA INTELLIGENCE'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {message.role === 'assistant' && (
              isSpeaking ? (
                <button
                  onClick={onStopSpeech}
                  className="p-1 rounded-md text-cyan-400 hover:bg-cyan-950/60 transition-colors"
                  title="Stop speaking"
                  aria-label="Stop speaking"
                >
                  <VolumeX className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => onReplaySpeech(message.content)}
                  className="p-1 rounded-md text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/60 transition-colors"
                  title="Replay speech"
                  aria-label="Replay speech"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              )
            )}

            <button
              onClick={onDismiss}
              className="p-1 rounded-md text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              title="Dismiss response"
              aria-label="Dismiss response"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Response Body */}
        <div className="text-xs sm:text-sm text-slate-100 leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap font-sans pr-1">
          {message.content}
        </div>

        {/* Action Payload Buttons */}
        {message.action && (
          <div className="mt-3 pt-2.5 border-t border-slate-800 flex flex-wrap gap-2 items-center">
            {message.action.targetUrl && (
              <button
                onClick={() => handleOpenUrl(message.action?.targetUrl)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-rajdhani font-semibold tracking-wide border border-cyan-500/40 transition-colors active:scale-95"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                {message.action.type === 'navigation'
                  ? 'Open Destination'
                  : message.action.type === 'search'
                  ? 'View Search Results'
                  : 'Open in WhatsApp'}
              </button>
            )}

            {message.action.draftText && (
              <button
                onClick={() => handleCopy(message.action?.draftText || '')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-rajdhani font-semibold tracking-wide border border-slate-700 transition-colors active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied to Clipboard' : 'Copy Draft'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
