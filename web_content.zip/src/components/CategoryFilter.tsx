import React from 'react';
import { ProductCategory, AppLanguage } from '../types';
import { ShoppingBasket, Store, Sparkles, Leaf, BookOpen, Layers, Tag } from 'lucide-react';

export type CategoryFilterType = ProductCategory | 'all' | 'offers';

interface CategoryFilterProps {
  selectedCategory: CategoryFilterType;
  onSelectCategory: (category: CategoryFilterType) => void;
  language: AppLanguage;
  categoryCounts: Record<CategoryFilterType, number>;
}

interface CategoryItem {
  id: CategoryFilterType;
  nameUrdu: string;
  nameEn: string;
  icon: React.ReactNode;
  color: string;
  activeColor: string;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory,
  language,
  categoryCounts
}) => {
  const isUrdu = language === 'ur';

  const categories: CategoryItem[] = [
    {
      id: 'all',
      nameUrdu: 'سب سامان',
      nameEn: 'All Items',
      icon: <Layers className="w-4 h-4" />,
      color: 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-300',
      activeColor: 'bg-emerald-700 text-white border-emerald-800 shadow-emerald-200'
    },
    {
      id: 'grocery',
      nameUrdu: 'کریانہ و راشن',
      nameEn: 'Grocery & Ration',
      icon: <ShoppingBasket className="w-4 h-4" />,
      color: 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border-emerald-300',
      activeColor: 'bg-emerald-600 text-white border-emerald-700 shadow-emerald-300'
    },
    {
      id: 'general',
      nameUrdu: 'جنرل سٹور',
      nameEn: 'General Store',
      icon: <Store className="w-4 h-4" />,
      color: 'bg-blue-50 text-blue-800 hover:bg-blue-100 border-blue-300',
      activeColor: 'bg-blue-600 text-white border-blue-700 shadow-blue-300'
    },
    {
      id: 'cosmetics',
      nameUrdu: 'کاسمیٹکس',
      nameEn: 'Cosmetics & Beauty',
      icon: <Sparkles className="w-4 h-4" />,
      color: 'bg-pink-50 text-pink-800 hover:bg-pink-100 border-pink-300',
      activeColor: 'bg-pink-600 text-white border-pink-700 shadow-pink-300'
    },
    {
      id: 'pansar',
      nameUrdu: 'پنسار و جڑی بوٹیاں',
      nameEn: 'Pansar Store',
      icon: <Leaf className="w-4 h-4" />,
      color: 'bg-amber-50 text-amber-900 hover:bg-amber-100 border-amber-300',
      activeColor: 'bg-amber-600 text-white border-amber-700 shadow-amber-300'
    },
    {
      id: 'books',
      nameUrdu: 'بک ڈپو و اسٹیشنری',
      nameEn: 'Book Depot & Stationery',
      icon: <BookOpen className="w-4 h-4" />,
      color: 'bg-indigo-50 text-indigo-900 hover:bg-indigo-100 border-indigo-300',
      activeColor: 'bg-indigo-600 text-white border-indigo-700 shadow-indigo-300'
    },
    {
      id: 'offers',
      nameUrdu: 'خاص رعایت والے',
      nameEn: 'Special Offers',
      icon: <Tag className="w-4 h-4" />,
      color: 'bg-red-50 text-red-800 hover:bg-red-100 border-red-300',
      activeColor: 'bg-red-600 text-white border-red-700 shadow-red-300'
    }
  ];

  return (
    <div className="bg-white border-b border-slate-200 py-2.5 px-3 shadow-xs">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 pt-0.5">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            const count = categoryCounts[cat.id] || 0;

            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all border shrink-0 active:scale-95 shadow-xs ${
                  isSelected ? `${cat.activeColor} shadow-md` : cat.color
                }`}
              >
                <span>{cat.icon}</span>
                <span>{isUrdu ? cat.nameUrdu : cat.nameEn}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isSelected
                      ? 'bg-white/25 text-white'
                      : 'bg-slate-200/70 text-slate-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
