import { ChannelCard, ChannelCardSkeleton } from "@/components/channel-card";
import { Input } from "@/components/ui/input";
import { useSentinel } from "@/hooks/use-sentinel";
import { searchChannelsFn } from "@/lib/youtube/api";
import { useInfiniteQuery } from "@tanstack/react-query";
import { Loader2, Search, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

function useDebounced<T>(value: T, ms: number) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function SearchPanel({ autoFocus }: { autoFocus?: boolean }) {
  const [q, setQ] = useState("");
  const debounced = useDebounced(q.trim(), 280);
  const inputRef = useRef<HTMLInputElement>(null);
  const sentinel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoFocus) inputRef.current?.focus();
  }, [autoFocus]);

  const search = useInfiniteQuery({
    queryKey: ["channel-search", debounced],
    enabled: debounced.length > 0,
    initialPageParam: null as string | null,
    queryFn: async ({ pageParam }) =>
      searchChannelsFn({
        data: { query: debounced, continuation: pageParam },
      }),
    getNextPageParam: (last, pages) => {
      const token = last.continuation ?? undefined;
      if (!token) return undefined;
      if (pages.some((p, i) => i < pages.length - 1 && p.continuation === token)) {
        return undefined;
      }
      return token;
    },
    retry: 1,
  });

  const {
    data,
    isLoading,
    isError,
    hasNextPage,
    isFetchingNextPage,
    isFetching,
    fetchNextPage,
  } = search;

  const channels = useMemo(() => {
    const seen = new Set<string>();
    const list = [];
    for (const page of data?.pages ?? []) {
      if (page.resolved && !seen.has(page.resolved.id)) {
        seen.add(page.resolved.id);
        list.push(page.resolved);
      }
      for (const ch of page.channels) {
        if (seen.has(ch.id)) continue;
        seen.add(ch.id);
        list.push(ch);
      }
    }
    return list;
  }, [data]);

  const loadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage && !isFetching) {
      void fetchNextPage();
    }
  }, [fetchNextPage, hasNextPage, isFetching, isFetchingNextPage]);

  useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="relative px-4 pb-3 pt-1">
        <Search className="pointer-events-none absolute left-7 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          ref={inputRef}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search any channel, @handle, or ID"
          className="pl-10 pr-11 text-base"
          enterKeyHint="search"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
          aria-label="Search YouTube channels"
        />
        {q ? (
          <button
            type="button"
            className="absolute right-7 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            onClick={() => {
              setQ("");
              inputRef.current?.focus();
            }}
            aria-label="Clear search"
          >
            <X className="size-4" />
          </button>
        ) : null}
      </div>

      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-4 pb-28">
        {!debounced ? (
          <p className="px-1 py-8 text-sm text-muted-foreground">
            Find literally any channel — including ones with zero subscribers and channels that have
            never posted to Community.
          </p>
        ) : isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <ChannelCardSkeleton key={i} />
            ))}
          </div>
        ) : isError ? (
          <p className="px-1 py-8 text-sm text-muted-foreground">
            Couldn’t reach YouTube. Try another search.
          </p>
        ) : channels.length === 0 ? (
          <p className="px-1 py-8 text-sm text-muted-foreground">
            No channels matched “{debounced}”. Try an @handle or channel ID.
          </p>
        ) : (
          <div className="space-y-2">
            {channels.map((ch) => (
              <ChannelCard key={ch.id} channel={ch} />
            ))}
            <div ref={sentinel} className="h-8" />
            {isFetchingNextPage ? (
              <div className="flex justify-center py-4 text-muted-foreground">
                <Loader2 className="size-4 animate-spin" />
              </div>
            ) : null}
            {!hasNextPage ? (
              <p className="py-4 text-center text-xs text-muted-foreground">
                Showing every public match YouTube returned.
              </p>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}
