import React, { useState } from 'react';
import { MealItem, TierLevel, UserProfile } from '../types';
import { Camera, Mic, Sparkles, Droplets, Trash2, Flame, Lock } from 'lucide-react';

interface NutritionDashboardProps {
  user: UserProfile;
  meals: MealItem[];
  onDeleteMeal: (id: string) => void;
  onOpenScanModal: () => void;
  onOpenVoiceModal: () => void;
  currentTier: TierLevel;
  onOpenPaywall: (tier?: TierLevel) => void;
}

export const NutritionDashboard: React.FC<NutritionDashboardProps> = ({
  user,
  meals,
  onDeleteMeal,
  onOpenScanModal,
  onOpenVoiceModal,
  currentTier,
  onOpenPaywall,
}) => {
  const [waterGlasses, setWaterGlasses] = useState(5); // 5 * 250ml = 1250ml
  const [selectedMealForDetail, setSelectedMealForDetail] = useState<MealItem | null>(null);

  // Compute totals
  const totalCals = meals.reduce((acc, m) => acc + m.macros.calories, 0);
  const totalProtein = meals.reduce((acc, m) => acc + m.macros.protein, 0);
  const totalCarbs = meals.reduce((acc, m) => acc + m.macros.carbs, 0);
  const totalFat = meals.reduce((acc, m) => acc + m.macros.fat, 0);
  const totalFiber = meals.reduce((acc, m) => acc + m.macros.fiber, 0);
  const totalSugar = meals.reduce((acc, m) => acc + m.macros.sugar, 0);
  const totalSodium = meals.reduce((acc, m) => acc + m.macros.sodium, 0);

  const calPercentage = Math.min(Math.round((totalCals / user.dailyCalorieTarget) * 100), 100);
  const remainingCals = Math.max(user.dailyCalorieTarget - totalCals, 0);

  const averageHealthScore = meals.length > 0
    ? Math.round(meals.reduce((acc, m) => acc + m.healthScore, 0) / meals.length)
    : 0;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* AI Scanner Hero Card (Reinforcing NO MANUAL ADDING rule) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 p-6 sm:p-8">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-bold text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>تطبيق Cal AI الذكي — لا إدخال يدوي للوجبات</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
              التقط صورة لطبقك، ودع الذكاء الاصطناعي يحسب كل شيء فوراً
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              وفقاً لفلسفة التطبيق: <strong className="text-emerald-400">لا حاجة لإدخال المكونات يدوياً</strong>. كاميرا الرؤية الحاسوبية ومحرك الذكاء الاصطناعي يقومان بتقدير الوزن، السعرات، ونسب الماكروز والمغذيات الدقيقة في ثوانٍ معدودة.
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={onOpenScanModal}
                className="px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-sm flex items-center gap-2 transition-transform active:scale-95 shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                <Camera className="w-5 h-5" />
                <span>مسح طبق بالكاميرا</span>
              </button>

              <button
                onClick={onOpenVoiceModal}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-sm flex items-center gap-2 transition-colors cursor-pointer border border-slate-700"
              >
                <Mic className="w-4 h-4 text-indigo-400" />
                <span>وصف صوتي سريع</span>
              </button>
            </div>
          </div>

          {/* Quick Scanner Visual Card */}
          <div className="relative w-full lg:w-72 aspect-4/3 rounded-2xl overflow-hidden border border-slate-800 shadow-xl group">
            <img
              src="/src/assets/images/hero_food_scanner_1791967840424.jpg"
              alt="سكان الوجبة الذكي"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent flex flex-col justify-end p-4">
              <div className="flex items-center justify-between text-xs font-bold text-white mb-1">
                <span>نموذج تحليل Cal AI</span>
                <span className="text-emerald-400 tabular-nums">580 سعرة</span>
              </div>
              <div className="text-[11px] text-slate-300">
                بروتين 42غ · كارب 45غ · دهون صحية 22غ
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Daily Calorie Ring & Macro Bars */}
        <div className="lg:col-span-2 space-y-6">
          {/* Calorie & Macro Card */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white">هدف السعرات اليومي</h2>
                <p className="text-xs text-slate-400 mt-0.5">محسوب بناءً على نشاطك وأهدافك</p>
              </div>
              <div className="text-left">
                <span className="text-xs text-slate-400 block">المتبقي اليوم:</span>
                <span className="text-lg font-black text-emerald-400 tabular-nums">{remainingCals} سعرة</span>
              </div>
            </div>

            {/* Circular Progress & Numbers Row */}
            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-950/70 rounded-2xl border border-slate-800/80">
              {/* Circular Gauge */}
              <div className="relative w-32 h-32 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    stroke="#1e293b"
                    strokeWidth="10"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    stroke="#10b981"
                    strokeWidth="10"
                    strokeDasharray={251.2}
                    strokeDashoffset={251.2 - (251.2 * calPercentage) / 100}
                    strokeLinecap="round"
                    className="transition-all duration-700"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-xl font-black text-white tabular-nums">{totalCals}</span>
                  <span className="text-[10px] text-slate-400 font-medium">من {user.dailyCalorieTarget}</span>
                </div>
              </div>

              {/* Macro Bars */}
              <div className="flex-1 w-full space-y-3.5">
                {/* Protein */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-rose-400">البروتين</span>
                    <span className="text-slate-300 tabular-nums font-semibold">
                      {totalProtein}غ / {user.dailyProteinTarget}غ
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-rose-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((totalProtein / user.dailyProteinTarget) * 100, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Carbs */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-amber-400">الكربوهيدرات</span>
                    <span className="text-slate-300 tabular-nums font-semibold">
                      {totalCarbs}غ / {user.dailyCarbsTarget}غ
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((totalCarbs / user.dailyCarbsTarget) * 100, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Fat */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-sky-400">الدهون الصحية</span>
                    <span className="text-slate-300 tabular-nums font-semibold">
                      {totalFat}غ / {user.dailyFatTarget}غ
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-sky-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((totalFat / user.dailyFatTarget) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Today's Scanned Meals Feed */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white">وجبات اليوم الممسوحة بالذكاء الاصطناعي</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  تم تسجيلها آلياً عبر الكاميرا دون الحاجة لكتابة يدوية
                </p>
              </div>
              <button
                onClick={onOpenScanModal}
                className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>+ مسح وجبة جديدة</span>
              </button>
            </div>

            {meals.length === 0 ? (
              <div className="text-center py-10 space-y-3 bg-slate-950/50 rounded-2xl border border-dashed border-slate-800">
                <Camera className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-sm font-semibold text-slate-300">لم تقم بمسح أي وجبة اليوم بعد</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  وجه كاميرا هاتفك نحو طبقك أو ارفع صورة، وسيتولى Cal AI الباقي فوراً!
                </p>
                <button
                  onClick={onOpenScanModal}
                  className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs cursor-pointer inline-flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  <span>بدء أول مسح الآن</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {meals.map((meal) => (
                  <div
                    key={meal.id}
                    onClick={() => setSelectedMealForDetail(meal)}
                    className="p-3.5 bg-slate-950 hover:bg-slate-950/90 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-4 cursor-pointer transition-all hover:border-slate-700 group"
                  >
                    <div className="flex items-center gap-3.5 overflow-hidden">
                      <img
                        src={meal.imageUrl}
                        alt={meal.name}
                        className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-800 group-hover:scale-105 transition-transform"
                      />
                      <div className="truncate">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-white truncate">{meal.name}</h3>
                          <span className="text-[10px] text-slate-500 shrink-0">{meal.timestamp}</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 truncate">{meal.nameEn}</div>
                        <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-300 tabular-nums">
                          <span className="font-bold text-white">{meal.macros.calories} سعرة</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-rose-400">{meal.macros.protein}غ ب</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-amber-400">{meal.macros.carbs}غ ك</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-sky-400">{meal.macros.fat}غ د</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right hidden sm:block">
                        <span className="text-[10px] text-emerald-400 font-bold block">
                          جودة {meal.healthScore}/100
                        </span>
                        <span className="text-[10px] text-slate-500 tabular-nums">{meal.weightGrams}غ</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteMeal(meal.id);
                        }}
                        className="p-2 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-950/20 transition-colors"
                        title="حذف الوجبة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column (1 Col): Micronutrients, Water & Tier-Specific Modules */}
        <div className="space-y-6">
          {/* Level 2 Feature: Micronutrients Breakdown Card */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-base">🧬</span>
                <h3 className="text-sm font-bold text-white">المغذيات الدقيقة</h3>
              </div>
              {currentTier < 2 ? (
                <button
                  onClick={() => onOpenPaywall(2)}
                  className="text-[11px] text-amber-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  <Lock className="w-3 h-3" />
                  <span>فتح في المستوى 2</span>
                </button>
              ) : (
                <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10">
                  مستوى {currentTier} مفعل
                </span>
              )}
            </div>

            {currentTier < 2 ? (
              <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800/80 text-center space-y-2">
                <p className="text-xs text-slate-400 leading-relaxed">
                  احصل على تفصيل الألياف، السكر، والصوديوم بدعوة صديق واحد فقط!
                </p>
                <button
                  onClick={() => onOpenPaywall(2)}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold"
                >
                  دعوة صديق وفتح الميزة
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                  <div className="text-[11px] text-slate-400">الألياف اليومية</div>
                  <div className="text-base font-extrabold text-emerald-400 tabular-nums mt-0.5">{totalFiber}غ</div>
                  <div className="text-[10px] text-slate-500">الهدف: 30غ</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                  <div className="text-[11px] text-slate-400">السكريات</div>
                  <div className="text-base font-extrabold text-amber-400 tabular-nums mt-0.5">{totalSugar}غ</div>
                  <div className="text-[10px] text-slate-500">الحد الأقصى: 35غ</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                  <div className="text-[11px] text-slate-400">الصوديوم</div>
                  <div className="text-base font-extrabold text-sky-400 tabular-nums mt-0.5">{totalSodium}مغ</div>
                  <div className="text-[10px] text-slate-500">الموصى به: 2300مغ</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                  <div className="text-[11px] text-slate-400">معدل جودة الغذاء</div>
                  <div className="text-base font-extrabold text-purple-400 tabular-nums mt-0.5">{averageHealthScore}/100</div>
                  <div className="text-[10px] text-slate-500">ممتاز جداً</div>
                </div>
              </div>
            )}
          </div>

          {/* Water Intake Tracker */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-white">تتبع شرب الماء</h3>
              </div>
              <span className="text-xs text-sky-400 font-bold tabular-nums">
                {waterGlasses * 250} / 2500 مل
              </span>
            </div>

            <div className="flex items-center justify-between gap-1 p-2 bg-slate-950 rounded-xl border border-slate-800">
              {Array.from({ length: 8 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setWaterGlasses(i + 1)}
                  className={`w-7 h-9 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                    i < waterGlasses
                      ? 'bg-sky-500 text-slate-950 shadow-sm shadow-sky-500/20'
                      : 'bg-slate-900 text-slate-600 hover:bg-slate-800'
                  }`}
                  title={`كوب ${i + 1} (250 مل)`}
                >
                  <Droplets className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>انقر لتسجيل كوب ماء (250 مل)</span>
              <button
                onClick={() => setWaterGlasses(0)}
                className="text-slate-500 hover:text-slate-300"
              >
                إعادة ضبط
              </button>
            </div>
          </div>

          {/* Level 3 Mandatory Paywall Feature: AI Meal Swaps */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">اقتراحات البدائل الصحية (AI Swaps)</h3>
              </div>
              {currentTier < 3 && (
                <span className="text-[10px] text-amber-400 font-bold px-2 py-0.5 rounded bg-amber-500/10">
                  المستوى 3 (مدفوع)
                </span>
              )}
            </div>

            {currentTier < 3 ? (
              <div className="p-4 bg-slate-950/80 rounded-xl border border-amber-500/20 text-center space-y-2.5">
                <p className="text-xs text-slate-300 leading-relaxed">
                  يقوم الذكاء الاصطناعي باقتراح بدائل لتقليل السعرات دون المساس بالطعم، يتطلب <strong className="text-amber-400">المستوى 3</strong>.
                </p>
                <button
                  onClick={() => onOpenPaywall(3)}
                  className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  فتح المستوى 3 (اشترك أو ادعُ أصدقاء)
                </button>
              </div>
            ) : (
              <div className="space-y-2 text-xs">
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 text-slate-300">
                  💡 <span className="font-semibold text-white">اقتراح اليوم:</span> استبدال المايونيز بزبادي يوناني متبل يقلل 140 سعرة حرارية من وجبة الغداء.
                </div>
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 text-slate-300">
                  🥗 تناول طبق السلطة قبل الوجبة الرئيسية يقلل امتصاص السكريات بنسبة 28%.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Meal Detail Modal if selected */}
      {selectedMealForDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">{selectedMealForDetail.name}</h3>
              <button
                onClick={() => setSelectedMealForDetail(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <img
              src={selectedMealForDetail.imageUrl}
              alt={selectedMealForDetail.name}
              className="w-full aspect-16/9 rounded-xl object-cover border border-slate-800"
            />

            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 bg-slate-950 rounded-lg">
                <div className="font-bold text-white tabular-nums">{selectedMealForDetail.macros.calories}</div>
                <div className="text-[10px] text-slate-400">سعرة</div>
              </div>
              <div className="p-2 bg-slate-950 rounded-lg">
                <div className="font-bold text-rose-400 tabular-nums">{selectedMealForDetail.macros.protein}غ</div>
                <div className="text-[10px] text-slate-400">بروتين</div>
              </div>
              <div className="p-2 bg-slate-950 rounded-lg">
                <div className="font-bold text-amber-400 tabular-nums">{selectedMealForDetail.macros.carbs}غ</div>
                <div className="text-[10px] text-slate-400">كارب</div>
              </div>
              <div className="p-2 bg-slate-950 rounded-lg">
                <div className="font-bold text-sky-400 tabular-nums">{selectedMealForDetail.macros.fat}غ</div>
                <div className="text-[10px] text-slate-400">دهون</div>
              </div>
            </div>

            <div className="text-xs text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
              <div className="font-bold text-emerald-400">رأي الذكاء الاصطناعي:</div>
              <p>{selectedMealForDetail.aiInsight}</p>
            </div>

            <button
              onClick={() => setSelectedMealForDetail(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
