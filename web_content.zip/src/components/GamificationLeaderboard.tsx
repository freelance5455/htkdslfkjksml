import React from 'react';
import { 
  Trophy, 
  Award, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles, 
  Star, 
  TrendingUp, 
  Upload 
} from 'lucide-react';
import { User, Achievement, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface GamificationLeaderboardProps {
  users: User[];
  achievements: Achievement[];
  language: Language;
}

export const GamificationLeaderboard: React.FC<GamificationLeaderboardProps> = ({
  users,
  achievements,
  language
}) => {
  const t = TRANSLATIONS[language];

  // Sort users by points
  const sortedUsers = [...users].sort((a, b) => b.points - a.points);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <h1 className="text-xl font-extrabold text-white">{t.topContributors}</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Honoring Sri Lanka's top paper uploaders, educators, and community mentors helping students nationwide.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Leaderboard Table (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400 fill-current" />
              <span>National Gamification Rankings</span>
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Rank</th>
                  <th className="p-4">Contributor</th>
                  <th className="p-4">Role & School</th>
                  <th className="p-4 text-right">Points & Level</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {sortedUsers.map((u, index) => {
                  const rankIcon =
                    index === 0 ? '🥇' :
                    index === 1 ? '🥈' :
                    index === 2 ? '🥉' : `#${index + 1}`;

                  return (
                    <tr key={u.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="p-4 font-extrabold text-base text-amber-400">{rankIcon}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img src={u.avatar} alt={u.name} className="w-9 h-9 rounded-full object-cover ring-2 ring-amber-500/30" />
                          <div>
                            <p className="font-bold text-white flex items-center gap-1">
                              <span>{u.name}</span>
                              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                            </p>
                            <p className="text-[10px] text-slate-400">{u.badges[0] || 'Contributor'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <p className="font-semibold text-slate-200">{u.role}</p>
                        <p className="text-[10px] text-slate-400">{u.school} ({u.province})</p>
                      </td>
                      <td className="p-4 text-right">
                        <p className="font-black text-amber-400 text-sm">{u.points} Pts</p>
                        <p className="text-[10px] text-slate-400">Level {u.level}</p>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Achievements Column */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Platform Badges & Milestones</span>
            </h3>

            <div className="space-y-3">
              {achievements.map((ach) => (
                <div key={ach.id} className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
                        <Award className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">{ach.title}</p>
                        <p className="text-[10px] text-slate-400">{ach.description}</p>
                      </div>
                    </div>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full" style={{ width: `${ach.progress}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
