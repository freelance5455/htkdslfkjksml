import React from 'react';
import { X, FolderHeart, Trash2, Play, Calendar, ExternalLink, Sparkles, LogIn } from 'lucide-react';
import { UgcAdProject } from '../types';
import { auth, googleProvider, signInWithPopup } from '../firebase';
import { User } from 'firebase/auth';

interface SavedAdsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedAds: UgcAdProject[];
  user: User | null;
  onSelectAd: (ad: UgcAdProject) => void;
  onDeleteAd: (adId: string) => void;
}

export const SavedAdsDrawer: React.FC<SavedAdsDrawerProps> = ({
  isOpen,
  onClose,
  savedAds,
  user,
  onSelectAd,
  onDeleteAd,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer panel */}
      <div className="relative w-full max-w-md h-full bg-[#0b0e1b]/95 border-l border-white/10 p-5 sm:p-6 flex flex-col justify-between overflow-y-auto shadow-2xl z-10 backdrop-blur-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-pink-500/15 border border-pink-500/30 text-pink-400">
                <FolderHeart className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Saved UGC Ads</h3>
                <p className="text-xs text-slate-400">Firestore Cloud Sync</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* User state */}
          {!user ? (
            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 text-center space-y-3">
              <Sparkles className="w-8 h-8 text-cyan-400 mx-auto" />
              <h4 className="text-sm font-bold text-white">Sign in to Save Ads</h4>
              <p className="text-xs text-slate-400">
                Connect with Google to securely persist your 16s UGC scripts, voiceovers, and ads across sessions.
              </p>
              <button
                onClick={() => signInWithPopup(auth, googleProvider)}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign in with Google</span>
              </button>
            </div>
          ) : savedAds.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              <p className="font-semibold text-slate-400">No saved ads yet</p>
              <p className="mt-1">Generated ads will automatically save to your cloud account.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {savedAds.map((ad) => (
                <div
                  key={ad.id}
                  className="p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 transition-all group relative"
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={
                        ad.productImage ||
                        'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=150&q=80'
                      }
                      alt={ad.productName}
                      className="w-14 h-14 rounded-xl object-cover border border-white/10 shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-100 truncate">{ad.productName}</h4>
                      <p className="text-[11px] text-cyan-300 truncate mt-0.5 font-medium">
                        "{ad.script.hook.verbal.slice(0, 45)}..."
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400 font-mono">
                        <span className="px-1.5 py-0.2 rounded-full bg-white/5 text-slate-300">
                          {ad.voiceName} (TTS)
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(ad.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 mt-3 pt-2 border-t border-white/5">
                    <button
                      onClick={() => onDeleteAd(ad.id)}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 transition-colors"
                      title="Delete ad"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        onSelectAd(ad);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center gap-1 border border-cyan-500/30"
                    >
                      <Play className="w-3 h-3 fill-cyan-300" />
                      <span>Load in Studio</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 text-center">
          <p className="text-[11px] text-slate-500">
            Persistent storage powered by Firebase Firestore
          </p>
        </div>
      </div>
    </div>
  );
};
