import React, { useState } from 'react';
import { Radio, ShieldCheck, Sparkles, Clock, Users, Copy, Check, ExternalLink, RefreshCw, Zap, Lock, Volume2 } from 'lucide-react';
import type { ClientModuleData, RadioChannelItem } from '../types/dataconnect';
import { calcularDiasRestantesDemo } from '../services/clientModuleService';

interface ClientModuleCardProps {
  moduleData: ClientModuleData;
  activeFrequency: string;
  activeChannelName: string;
  onSelectChannel: (channel: RadioChannelItem) => void;
  onRegenerateDemo: () => void;
  onUpgradePremium: () => void;
}

export const ClientModuleCard: React.FC<ClientModuleCardProps> = ({
  moduleData,
  activeFrequency,
  activeChannelName,
  onSelectChannel,
  onRegenerateDemo,
  onUpgradePremium
}) => {
  const [copied, setCopied] = useState(false);
  const [showJson, setShowJson] = useState(false);
  const [tab, setTab] = useState<'publicos' | 'privados'>('privados');

  const diasRestantes = calcularDiasRestantesDemo(moduleData.vencimiento_demo);
  const isDemo = moduleData.tipo.includes('demo');

  const handleCopyId = () => {
    navigator.clipboard.writeText(moduleData.cliente_id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-[#0b0416]/95 border border-[#9D00FF]/40 rounded-2xl p-4 md:p-5 shadow-[0_0_30px_rgba(157,0,255,0.2)] text-white font-sans backdrop-blur-md">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#9D00FF] to-[#FF0044] flex items-center justify-center shadow-[0_0_15px_rgba(255,0,68,0.5)]">
            <Radio className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs md:text-sm font-black tracking-wider text-[#00ff88] uppercase flex items-center gap-1.5">
                <Check className="w-4 h-4 text-[#00ff88]" />
                TU RADIO EXCLUSIVO {isDemo ? '(VERSIÓN PRUEBA)' : 'OFICIAL'}
              </span>
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40 rounded-full">
                {moduleData.estado.toUpperCase()}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-400 font-mono">
              <span>ID: <strong className="text-white">{moduleData.cliente_id}</strong></span>
              <button 
                onClick={handleCopyId} 
                className="hover:text-[#00ff88] transition-colors p-1" 
                title="Copiar ID"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#00ff88]" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <span>• Freq Base: <strong className="text-[#9D00FF]">{moduleData.frecuencia_base || '433.500'} MHz</strong></span>
            </div>
          </div>
        </div>

        {/* Demo limit badges & CTA */}
        <div className="flex items-center gap-2">
          {isDemo && (
            <div className="flex items-center gap-2 bg-black/60 border border-yellow-500/40 px-3 py-1.5 rounded-xl text-[11px] font-mono">
              <div className="flex items-center gap-1 text-yellow-400">
                <Clock className="w-3.5 h-3.5" />
                <span>{diasRestantes > 0 ? `${diasRestantes} días de prueba` : 'Prueba finalizada'}</span>
              </div>
              <span className="text-gray-500">|</span>
              <div className="flex items-center gap-1 text-gray-300">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span>Hasta {moduleData.limite_usuarios || 5} ops</span>
              </div>
            </div>
          )}

          <button
            onClick={onUpgradePremium}
            className="px-3 py-1.5 bg-gradient-to-r from-[#FF0044] to-[#9D00FF] hover:from-[#ff1a5b] hover:to-[#b01aff] text-white text-xs font-bold rounded-xl shadow-[0_0_12px_rgba(255,0,68,0.4)] transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Pasar a Premium</span>
          </button>
        </div>
      </div>

      {/* Channel Switcher Tabs */}
      <div className="mt-4 flex items-center justify-between border-b border-gray-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTab('privados')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              tab === 'privados'
                ? 'bg-[#9D00FF] text-white shadow-[0_0_12px_rgba(157,0,255,0.4)]'
                : 'text-gray-400 hover:text-white bg-black/40'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Módulo Privado Exclusivo (Canales 4-10)</span>
            <span className="px-1.5 py-0.2 text-[9px] bg-black/40 rounded-full font-mono">7</span>
          </button>

          <button
            onClick={() => setTab('publicos')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              tab === 'publicos'
                ? 'bg-[#00ff88] text-black shadow-[0_0_12px_rgba(0,255,136,0.4)]'
                : 'text-gray-400 hover:text-white bg-black/40'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Canales Públicos Libres (1-3)</span>
            <span className="px-1.5 py-0.2 text-[9px] bg-black/40 rounded-full font-mono">3</span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setShowJson(!showJson)}
            className="text-gray-400 hover:text-gray-200 font-mono text-[11px] underline"
          >
            {showJson ? 'Ocultar JSON' : 'Ver JSON Base'}
          </button>
          <button
            onClick={onRegenerateDemo}
            className="text-gray-400 hover:text-[#00ff88] transition-colors p-1"
            title="Regenerar ID y frecuencias"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* JSON Viewer Modal or Dropdown */}
      {showJson && (
        <div className="mt-3 bg-black/90 border border-gray-800 rounded-xl p-3 font-mono text-[11px] text-green-400 overflow-x-auto max-h-48">
          <pre>{JSON.stringify(moduleData, null, 2)}</pre>
        </div>
      )}

      {/* Channel Grid */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {(tab === 'privados' ? moduleData.modulo_privado : moduleData.canales_publicos).map((canal) => {
          const isSelected = activeFrequency === canal.freq;
          return (
            <div
              key={canal.id}
              onClick={() => onSelectChannel(canal)}
              className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between group ${
                isSelected
                  ? 'bg-gradient-to-r from-[#9D00FF]/30 to-[#FF0044]/30 border-[#00ff88] shadow-[0_0_15px_rgba(0,255,136,0.3)]'
                  : 'bg-black/50 border-gray-800 hover:border-gray-600 hover:bg-black/70'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-black text-xs ${
                  isSelected ? 'bg-[#00ff88] text-black font-bold' : 'bg-gray-800 text-gray-300'
                }`}>
                  {canal.id < 10 ? `0${canal.id}` : canal.id}
                </div>
                <div>
                  <div className="text-xs font-bold text-white group-hover:text-[#00ff88] transition-colors flex items-center gap-1.5">
                    <span>{canal.nombre}</span>
                    {isSelected && <Volume2 className="w-3 h-3 text-[#00ff88] animate-bounce" />}
                  </div>
                  <div className="text-[10px] font-mono text-gray-400">
                    <span className="text-[#00ff88]">{canal.freq} MHz</span> • <span className="uppercase text-gray-500">{canal.acceso}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                  isSelected ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50' : 'bg-gray-900 text-gray-400'
                }`}>
                  {isSelected ? 'SINTONIZADO' : 'CONECTAR'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="mt-4 pt-3 border-t border-gray-800/80 flex flex-wrap items-center justify-between text-[11px] text-gray-400 font-mono gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#00ff88]" />
          <span>Frecuencias únicas sin interferencia • Red Sonovisión Latiz</span>
        </div>
        <div>
          <span>Canal Activo: <strong className="text-white">{activeChannelName}</strong> ({activeFrequency} MHz)</span>
        </div>
      </div>
    </div>
  );
};
