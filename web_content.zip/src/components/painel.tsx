import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { Clock, History, Radio, RefreshCw, Search, ShieldCheck, X } from "lucide-react";
import { obterEventos } from "@/lib/eventos";
import {
  FONTE_EVENTOS,
  estadoVisual,
  filtrarJogos,
  formatarDataHora,
  fundirHistorico,
  nomeLiga,
  numPt,
  processar,
  statsHistorico,
  type Desporto,
  type FiltroData,
  type HistItem,
  type JogoVista,
  type Modo,
  type Ordem,
  type Relatorio,
} from "@/lib/mercado";

const CACHE_EVENTOS = "vision-master-eventos-v2";
const CACHE_HIST = "vision-master-historico-v2";
const COOLDOWN_MS = 15000;
const MAX_CARTOES = 90;

const CAMPO =
  "h-11 w-full rounded-xl border border-line bg-surface-2 px-3 text-sm text-fg outline-none";

interface CacheEventos {
  guardadoEm: number | null;
  dados: unknown;
}

function lerCache(): CacheEventos | null {
  try {
    const t = localStorage.getItem(CACHE_EVENTOS);
    if (!t) return null;
    const o = JSON.parse(t) as CacheEventos;
    if (o && typeof o === "object" && "dados" in o) return o;
    return null;
  } catch {
    return null;
  }
}

function guardarCache(dados: unknown) {
  try {
    localStorage.setItem(CACHE_EVENTOS, JSON.stringify({ guardadoEm: Date.now(), dados }));
  } catch {
    /* quota */
  }
}

function lerHistorico(): HistItem[] {
  try {
    const raw = localStorage.getItem(CACHE_HIST);
    const arr: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? (arr as HistItem[]) : [];
  } catch {
    return [];
  }
}

function guardarHistorico(itens: HistItem[]) {
  try {
    localStorage.setItem(CACHE_HIST, JSON.stringify(itens));
  } catch {
    /* quota */
  }
}

function mensagemErro(erro: unknown) {
  if (erro instanceof Error && erro.message) return erro.message;
  return "sem resposta do servidor";
}

async function buscarEventos(): Promise<unknown> {
  try {
    return await obterEventos();
  } catch (erroServidor) {
    try {
      const resposta = await fetch(FONTE_EVENTOS, { cache: "no-store" });
      if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
      return await resposta.json();
    } catch (erroRede) {
      throw new Error(`${mensagemErro(erroServidor)} · ${mensagemErro(erroRede)}`);
    }
  }
}

function iniciais(nome: string) {
  const partes = nome.trim().split(/\s+/).filter(Boolean);
  if (partes.length > 1) {
    const a = partes[0]?.[0] ?? "";
    const b = partes[1]?.[0] ?? "";
    return (a + b).toUpperCase();
  }
  return (partes[0] || "?").slice(0, 2).toUpperCase();
}

function matiz(nome: string) {
  let h = 0;
  for (const c of nome) h = (h * 31 + (c.codePointAt(0) ?? 0)) % 360;
  return h;
}

export function Painel() {
  const [bruto, setBruto] = useState<unknown>(null);
  const [carregado, setCarregado] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [usandoCache, setUsandoCache] = useState(false);
  const [cacheEm, setCacheEm] = useState<number | null>(null);
  const [historico, setHistorico] = useState<HistItem[]>([]);
  const [modo, setModo] = useState<Modo>("blindado");
  const [termo, setTermo] = useState("");
  const [desporto, setDesporto] = useState<"" | Desporto>("");
  const [liga, setLiga] = useState("");
  const [data, setData] = useState<FiltroData>("");
  const [ordem, setOrdem] = useState<Ordem>("seguro");
  const [tick, setTick] = useState(0);
  const [aberto, setAberto] = useState(false);
  const [cooldownAte, setCooldownAte] = useState(0);
  const [relogio, setRelogio] = useState(0);

  const histRef = useRef<HistItem[]>([]);
  const temDados = useRef(false);
  const carregandoRef = useRef(false);
  const ultimoRef = useRef(0);

  const rel = useMemo(() => processar(bruto, Date.now()), [bruto, tick]);

  function aplicar(dados: unknown, cache: boolean, quando: number | null) {
    temDados.current = true;
    setBruto(dados);
    setUsandoCache(cache);
    setCacheEm(quando);
    setErro("");
    setCarregado(true);
    if (!cache) guardarCache(dados);
    const proximo = fundirHistorico(processar(dados, Date.now()), histRef.current);
    histRef.current = proximo;
    guardarHistorico(proximo);
    setHistorico(proximo);
  }

  async function carregar(manual = false) {
    if (carregandoRef.current) return;
    if (manual && Date.now() - ultimoRef.current < COOLDOWN_MS) return;
    carregandoRef.current = true;
    setCarregando(true);
    try {
      const dados = await buscarEventos();
      aplicar(dados, false, null);
      ultimoRef.current = Date.now();
      setCooldownAte(Date.now() + COOLDOWN_MS);
    } catch (falha) {
      if (!temDados.current) {
        const cache = lerCache();
        if (cache) aplicar(cache.dados, true, cache.guardadoEm);
        else setErro(mensagemErro(falha));
      } else {
        setErro(mensagemErro(falha));
      }
    } finally {
      carregandoRef.current = false;
      setCarregando(false);
    }
  }

  useEffect(() => {
    const inicial = lerHistorico();
    histRef.current = inicial;
    setHistorico(inicial);
    void carregar();
    const id = setInterval(() => void carregar(), 60000);
    const pulso = setInterval(() => setTick((n) => n + 1), 30000);
    return () => {
      clearInterval(id);
      clearInterval(pulso);
    };
    // montagem única
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (cooldownAte <= Date.now()) return;
    const id = setInterval(() => setRelogio((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, [cooldownAte]);

  useEffect(() => {
    if (!aberto) return;
    const anterior = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = anterior;
    };
  }, [aberto]);

  useEffect(() => {
    function noEscape(e: KeyboardEvent) {
      if (e.key === "Escape") setAberto(false);
    }
    document.addEventListener("keydown", noEscape);
    return () => document.removeEventListener("keydown", noEscape);
  }, []);

  const filtros = { modo, termo, desporto, liga, data, ordem };
  const base = useMemo(
    () => filtrarJogos(rel.jogos, { ...filtros, modo: "todos" }, Date.now()),
    // filtros de modo excluído de propósito; o resto entra por campos
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rel, termo, desporto, liga, data, ordem, tick],
  );
  const visiveis = useMemo(
    () => filtrarJogos(rel.jogos, filtros, Date.now()).slice(0, MAX_CARTOES),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rel, modo, termo, desporto, liga, data, ordem, tick],
  );

  const nBlind = base.filter((j) => j.sinal.nivel === "blindado").length;
  const nFirme = base.filter((j) => j.sinal.nivel !== "lista").length;
  const selosGlobais = rel.jogos.filter((j) => j.sinal.nivel === "blindado").length;
  const taxa = statsHistorico(historico, true);
  const ligas = [...new Set(rel.jogos.map((j) => j.liga))].sort((a, b) =>
    nomeLiga(a).localeCompare(nomeLiga(b), "pt"),
  );

  const restante = Math.max(0, cooldownAte - Date.now());
  void relogio;

  return (
    <div className="min-h-screen bg-canvas text-fg">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line-soft bg-elevated/95 px-4 backdrop-blur-md md:h-20 md:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-lg font-extrabold text-canvas">
            V
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-extrabold tracking-wide md:text-base">VISION MASTER</div>
            <div className="text-xs font-semibold tracking-widest text-muted">PAINEL DE PREVISÕES</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" aria-label="Histórico" className="inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-semibold text-fg" onClick={() => setAberto(true)}>
            <History className="size-4" aria-hidden />
            <span className="hidden sm:inline">Histórico</span>
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-primary bg-primary-deep px-3 text-sm font-semibold text-fg disabled:opacity-50"
            onClick={() => void carregar(true)}
            disabled={carregando || restante > 0}
          >
            <RefreshCw className={`size-4 ${carregando ? "animate-spin motion-reduce:animate-none" : ""}`} aria-hidden />
            {carregando ? "A atualizar" : restante > 0 ? `${Math.ceil(restante / 1000)}s` : "Atualizar"}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 pb-16 md:px-6 md:py-8">
        <div className="mb-5 max-w-2xl">
          <p className="mb-2 text-xs font-bold tracking-widest text-primary">MOTOR DE BLINDAGEM</p>
          <h1 className="text-3xl font-extrabold tracking-tight md:text-4xl">Jogos que não podem falhar</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Só aparecem eventos com odds completas. O selo Blindado fica para o favorito em que o mercado
            concorda de forma rara: probabilidade alta, folga larga sobre o 2.º resultado e margem da casa
            saudável. Sem odd, o jogo nem entra.
          </p>
        </div>

        <section className="mb-4 grid grid-cols-3 gap-2 md:gap-3">
          <Stat label="Com odds" valor={carregado ? String(rel.jogos.length) : "—"} />
          <Stat label="Blindados" valor={carregado ? String(selosGlobais) : "—"} tom="win" />
          <Stat
            label="Taxa do selo"
            valor={taxa.taxa == null ? "—" : `${taxa.taxa}%`}
            tom={taxa.taxa == null ? "neutro" : taxa.taxa >= 60 ? "win" : taxa.taxa >= 40 ? "warn" : "loss"}
            nota={taxa.resolvidos ? `${taxa.resolvidos} resolvidos` : "ainda sem fechos"}
          />
        </section>

        <details className="mb-4 rounded-2xl border border-line bg-surface-2 px-4 py-3">
          <summary className="text-sm font-semibold">Como o selo escolhe o que não falha</summary>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Nenhum palpite é garantia. O Blindado só passa quando as cinco fecham ao mesmo tempo. O índice
            ordena os que passam: quanto maior, mais o mercado trata o favorito como quase certo.
          </p>
          <ul className="mt-3 grid gap-2 text-sm text-fg md:grid-cols-2">
            <Regra texto="Probabilidade implícita de pelo menos 76%, já sem a margem da casa." />
            <Regra texto="Folga de pelo menos 52 pontos para o segundo resultado." />
            <Regra texto="Odd do favorito entre 1,12 e 1,38 — nem preço partido, nem odd longa." />
            <Regra texto="Margem da casa entre 2% e 14%. Fora disto, a odd é suspeita." />
            <Regra texto="No futebol, o empate não pode passar de 16%. Empate favorito nunca leva selo." />
            <Regra texto="Basquete e tênis entram na mesma régua, mas só se tiverem as duas odds." />
          </ul>
        </details>

        <div className="mb-3 grid grid-cols-3 gap-2" role="tablist" aria-label="Nível de confiança">
          <ModoBtn ativo={modo === "blindado"} onClick={() => setModo("blindado")} nome="Blindados" n={nBlind} />
          <ModoBtn ativo={modo === "firme"} onClick={() => setModo("firme")} nome="Alta confiança" n={nFirme} />
          <ModoBtn ativo={modo === "todos"} onClick={() => setModo("todos")} nome="Com odds" n={base.length} />
        </div>

        <div className="mb-3 grid gap-2 md:grid-cols-4">
          <label className="relative md:col-span-4">
            <span className="sr-only">Buscar equipa</span>
            <Search className="pointer-events-none absolute top-3.5 left-3 size-4 text-faint" aria-hidden />
            <input
              className={`${CAMPO} pl-10`}
              type="search"
              placeholder="Buscar equipa ou competição"
              value={termo}
              onChange={(e) => setTermo(e.target.value)}
              autoComplete="off"
            />
          </label>
          <select className={CAMPO} value={desporto} onChange={(e) => setDesporto(e.target.value as "" | Desporto)} aria-label="Desporto">
            <option value="">Todos os desportos</option>
            <option value="futebol">Futebol</option>
            <option value="basquete">Basquete</option>
            <option value="tenis">Tênis</option>
          </select>
          <select className={CAMPO} value={ligas.includes(liga) ? liga : ""} onChange={(e) => setLiga(e.target.value)} aria-label="Competição">
            <option value="">Todas as competições</option>
            {ligas.map((c) => (
              <option key={c} value={c}>
                {nomeLiga(c)}
              </option>
            ))}
          </select>
          <select className={CAMPO} value={data} onChange={(e) => setData(e.target.value as FiltroData)} aria-label="Data">
            <option value="">Todas as datas</option>
            <option value="hoje">Hoje</option>
            <option value="amanha">Amanhã</option>
            <option value="semana">Próximos 7 dias</option>
          </select>
          <select className={CAMPO} value={ordem} onChange={(e) => setOrdem(e.target.value as Ordem)} aria-label="Ordenação">
            <option value="seguro">Mais seguros</option>
            <option value="cedo">Mais cedo</option>
          </select>
        </div>

        <StatusBar
          rel={rel}
          mostrados={visiveis.length}
          totalFiltrado={filtrarJogos(rel.jogos, filtros, Date.now()).length}
          usandoCache={usandoCache}
          cacheEm={cacheEm}
          erro={erro && carregado ? erro : ""}
        />

        {!carregado && !erro ? (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-72 animate-pulse rounded-2xl border border-line bg-surface motion-reduce:animate-none" />
            ))}
            <p className="text-sm text-muted md:col-span-2 xl:col-span-3">A carregar só jogos que têm odds…</p>
          </div>
        ) : erro && !rel.jogos.length ? (
          <div className="rounded-2xl border border-dashed border-line px-6 py-12 text-center">
            <p className="text-sm font-semibold">Não foi possível carregar os jogos.</p>
            <p className="mt-2 text-sm text-muted">{erro}</p>
            <button type="button" className="mt-4 inline-flex h-11 items-center rounded-xl bg-primary-deep px-4 text-sm font-semibold" onClick={() => void carregar(true)}>
              Tentar outra vez
            </button>
          </div>
        ) : visiveis.length === 0 ? (
          <Vazio modo={modo} onFirme={() => setModo("firme")} onTodos={() => setModo("todos")} temFirme={nFirme > 0} temOdds={base.length > 0} />
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {visiveis.map((jogo, i) => (
              <Cartao key={jogo.id} jogo={jogo} i={i} />
            ))}
          </div>
        )}

        <p className="mt-8 text-center text-xs tracking-widest text-faint">
          VISION MASTER · SÓ ENTRA QUEM TEM ODD · SELO BLINDADO
        </p>
      </main>

      <Historico aberto={aberto} onFechar={() => setAberto(false)} historico={historico} estados={rel.estados} />
    </div>
  );
}

function Stat({
  label,
  valor,
  tom = "neutro",
  nota,
}: {
  label: string;
  valor: string;
  tom?: "neutro" | "win" | "warn" | "loss";
  nota?: string;
}) {
  const cor = tom === "win" ? "text-win" : tom === "warn" ? "text-warn" : tom === "loss" ? "text-loss" : "text-fg";
  return (
    <div className="rounded-2xl border border-line bg-surface px-3 py-3 md:px-4">
      <div className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</div>
      <div className={`mt-1 text-2xl font-extrabold tracking-tight ${cor}`}>{valor}</div>
      {nota ? <div className="mt-1 text-xs text-faint">{nota}</div> : null}
    </div>
  );
}

function Regra({ texto }: { texto: string }) {
  return (
    <li className="flex gap-2">
      <ShieldCheck className="mt-0.5 size-4 shrink-0 text-win" aria-hidden />
      <span>{texto}</span>
    </li>
  );
}

function ModoBtn({ ativo, onClick, nome, n }: { ativo: boolean; onClick: () => void; nome: string; n: number }) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={ativo}
      onClick={onClick}
      className={`flex min-h-16 flex-col items-center justify-center gap-1 rounded-xl border px-1 py-2 text-xs font-bold sm:text-sm ${
        ativo ? "border-primary bg-primary-deep text-fg" : "border-line bg-surface-2 text-muted"
      }`}
    >
      <span className="leading-none">{nome}</span>
      <span className={`text-xs font-semibold ${ativo ? "text-fg" : "text-faint"}`}>{n}</span>
    </button>
  );
}

function StatusBar({
  rel,
  mostrados,
  totalFiltrado,
  usandoCache,
  cacheEm,
  erro,
}: {
  rel: Relatorio;
  mostrados: number;
  totalFiltrado: number;
  usandoCache: boolean;
  cacheEm: number | null;
  erro: string;
}) {
  if (!rel.recebidos && !erro) return null;
  return (
    <div className="mb-4 flex flex-wrap gap-2 text-xs">
      <Pill>Proteção ativa</Pill>
      <Pill tom="ok">{rel.jogos.length} com odds à frente</Pill>
      {rel.semOdds > 0 ? <Pill tom="warn">{rel.semOdds} sem odds, ocultos</Pill> : null}
      {rel.margemInvalida > 0 ? <Pill tom="warn">{rel.margemInvalida} com margem suspeita</Pill> : null}
      {usandoCache ? (
        <Pill tom="warn">Cópia local{cacheEm ? ` de ${formatarDataHora(new Date(cacheEm))}` : ""}</Pill>
      ) : null}
      {erro ? <Pill tom="err">Última ligação falhou</Pill> : null}
      {mostrados < totalFiltrado ? <Pill>A mostrar {mostrados} de {totalFiltrado}</Pill> : null}
    </div>
  );
}

function Pill({ children, tom }: { children: ReactNode; tom?: "ok" | "warn" | "err" }) {
  const cls =
    tom === "ok"
      ? "border-win bg-win-dim text-win"
      : tom === "warn"
        ? "border-warn bg-warn-dim text-warn"
        : tom === "err"
          ? "border-loss bg-loss-dim text-loss"
          : "border-line bg-elevated text-muted";
  return <span className={`inline-flex items-center rounded-lg border px-2.5 py-1.5 ${cls}`}>{children}</span>;
}

function Vazio({
  modo,
  onFirme,
  onTodos,
  temFirme,
  temOdds,
}: {
  modo: Modo;
  onFirme: () => void;
  onTodos: () => void;
  temFirme: boolean;
  temOdds: boolean;
}) {
  return (
    <div className="rounded-2xl border border-dashed border-line px-6 py-12 text-center">
      <p className="text-sm font-semibold">
        {modo === "blindado"
          ? "Nenhum jogo passa o selo Blindado com estes filtros."
          : modo === "firme"
            ? "Nenhum favorito de alta confiança com estes filtros."
            : "Nenhum jogo com odds corresponde aos filtros."}
      </p>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted">
        {modo === "blindado"
          ? "O mercado não está a oferecer um favorito assim tão claro. Isso é o filtro a trabalhar, não um erro."
          : "Alarga a data, a competição ou a busca."}
      </p>
      <div className="mt-4 flex flex-wrap justify-center gap-2">
        {modo === "blindado" && temFirme ? (
          <button type="button" className="h-11 rounded-xl bg-primary-deep px-4 text-sm font-semibold" onClick={onFirme}>
            Ver alta confiança
          </button>
        ) : null}
        {modo !== "todos" && temOdds ? (
          <button type="button" className="h-11 rounded-xl border border-line px-4 text-sm font-semibold" onClick={onTodos}>
            Ver todos com odds
          </button>
        ) : null}
      </div>
    </div>
  );
}

function Cartao({ jogo, i }: { jogo: JogoVista; i: number }) {
  const s = jogo.sinal;
  const linha = s.nivel === "blindado" ? "via-win" : s.nivel === "firme" ? "via-primary" : "via-faint";
  const atraso = `${Math.min(i, 12) * 40}ms`;
  return (
    <article
      className="cartao-in relative overflow-hidden rounded-2xl border border-line bg-surface p-4"
      style={{ animationDelay: atraso }}
    >
      <div className={`pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent ${linha} to-transparent`} />
      <div className="mb-3 flex items-center justify-between gap-2">
        <span className="inline-flex items-center gap-1.5 text-xs text-muted">
          <Clock className="size-3.5 text-primary" aria-hidden />
          {formatarDataHora(new Date(jogo.inicioMs))}
        </span>
        <span className="rounded-md border border-primary bg-primary-dim px-2 py-1 text-xs font-bold tracking-wide text-primary">
          {jogo.desportoLabel}
        </span>
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-start gap-2">
        <Equipa nome={jogo.equipaCasa} />
        <div className="mt-3 grid size-7 place-items-center rounded-full border border-line text-xs font-bold text-faint">VS</div>
        <Equipa nome={jogo.equipaFora} />
      </div>
      <div className={`mt-3 grid gap-1.5 ${s.odds.empate == null ? "grid-cols-2" : "grid-cols-3"}`}>
        <Odd tag="1 · Casa" odd={s.odds.casa} fav={s.lado === "casa"} />
        {s.odds.empate != null ? <Odd tag="X · Empate" odd={s.odds.empate} fav={s.lado === "empate"} /> : null}
        <Odd tag="2 · Fora" odd={s.odds.fora} fav={s.lado === "fora"} />
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 border-t border-line-soft pt-3">
        <div className={`rounded-xl border px-3 py-2 ${s.nivel === "lista" ? "border-line bg-surface-2" : "border-win bg-win-dim"}`}>
          <div className="text-xs font-bold tracking-wide text-muted uppercase">
            {s.nivel === "blindado" ? "Blindado" : s.nivel === "firme" ? "Firme" : "Com odds"}
          </div>
          <div className="mt-1 text-sm font-extrabold text-win">{s.nome}</div>
          <div className="mt-1 text-xs text-muted">
            odd {numPt(s.odd)} · {s.prob}% · índice {s.score}
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line" aria-hidden>
            <div
              className={`h-full rounded-full ${s.nivel === "blindado" ? "bg-win" : s.nivel === "firme" ? "bg-primary" : "bg-muted"}`}
              style={{ width: `${Math.max(0, Math.min(100, s.prob))}%` }}
            />
          </div>
        </div>
        <div className="rounded-xl border border-line bg-surface-2 px-3 py-2">
          <div className="text-xs font-bold tracking-wide text-muted uppercase">Competição</div>
          <div className="mt-1 text-sm font-bold">{jogo.tipoJogo}</div>
          <div className="mt-2 text-xs text-muted">
            2.º {s.segundoNome} · {s.segundoProb}%
          </div>
          {jogo.categoria ? <div className="mt-1 text-xs text-faint">{jogo.categoria}</div> : null}
        </div>
      </div>
      {s.nivel === "lista" && s.falhas[0] ? (
        <p className="mt-3 text-xs text-warn">Fora do selo: {s.falhas[0]}</p>
      ) : (
        <ul className="mt-3 space-y-1.5">
          {s.motivos.map((m) => (
            <li key={m} className="flex gap-2 text-xs text-muted">
              <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-win" aria-hidden />
              <span>{m}</span>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

function Equipa({ nome }: { nome: string }) {
  return (
    <div className="flex min-w-0 flex-col items-center gap-2 text-center">
      <div
        className="avatar-equipa grid size-12 place-items-center rounded-xl text-sm font-extrabold"
        style={{ "--h": String(matiz(nome)) } as CSSProperties}
      >
        {iniciais(nome)}
      </div>
      <span className="text-xs font-bold break-words">{nome}</span>
    </div>
  );
}

function Odd({ tag, odd, fav }: { tag: string; odd: number; fav: boolean }) {
  return (
    <div className={`rounded-xl border px-1 py-2 text-center ${fav ? "border-win bg-win-dim" : "border-line bg-surface-2"}`}>
      <div className="text-xs font-bold tracking-wide text-faint">{tag}</div>
      <div className={`text-sm font-extrabold ${fav ? "text-win" : "text-fg"}`}>{numPt(odd)}</div>
      <div className="text-xs text-faint">{fav ? "favorito" : ""}</div>
    </div>
  );
}

function Historico({
  aberto,
  onFechar,
  historico,
  estados,
}: {
  aberto: boolean;
  onFechar: () => void;
  historico: HistItem[];
  estados: Relatorio["estados"];
}) {
  const sh = statsHistorico(historico);
  const itens = historico.map((h) => ({ h, v: estadoVisual(h, estados[h.id]) }));
  const ordenados = [...itens.filter((x) => x.v.tipo === "live"), ...itens.filter((x) => x.v.tipo !== "live")].slice(0, 60);

  return (
    <>
      <button
        type="button"
        aria-label="Fechar histórico"
        className={`fixed inset-0 z-40 bg-canvas/70 ${aberto ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onClick={onFechar}
      />
      <aside
        className={`fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-line-soft bg-elevated transition-transform duration-200 motion-reduce:transition-none ${
          aberto ? "translate-x-0" : "translate-x-full"
        }`}
        aria-hidden={!aberto}
      >
        <div className="flex items-center justify-between border-b border-line-soft px-4 py-4">
          <h2 className="text-base font-extrabold">Histórico do selo</h2>
          <button type="button" className="grid size-11 place-items-center rounded-xl border border-line" onClick={onFechar} aria-label="Fechar">
            <X className="size-4" />
          </button>
        </div>
        <div className="grid grid-cols-4 gap-2 border-b border-line-soft px-4 py-3">
          <Mini label="Total" valor={sh.total} />
          <Mini label="Ganhou" valor={sh.won} tom="win" />
          <Mini label="Perdeu" valor={sh.lost} tom="loss" />
          <Mini label="Pendente" valor={sh.pend} tom="warn" />
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {ordenados.length === 0 ? (
            <p className="px-2 py-10 text-center text-sm text-muted">
              Ainda sem selos registados. Quando um jogo passar a Blindado ou a alta confiança, fica aqui para ser avaliado no fim.
            </p>
          ) : (
            ordenados.map(({ h, v }) => (
              <div key={h.id} className={`mb-2 rounded-xl border px-3 py-3 ${v.tipo === "live" ? "border-loss bg-loss-dim" : "border-line bg-surface"}`}>
                <div className="text-sm font-extrabold">
                  {h.equipaCasa} vs {h.equipaFora}
                </div>
                <div className="mt-1 text-xs text-muted">
                  {h.tipoJogo} · {h.palpiteNome} · odd {numPt(h.oddUsada)} · {h.nivel === "blindado" ? "Blindado" : "Firme"}
                </div>
                <div className="mt-2 flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-fg">
                    {v.placar ? `${v.placar.casa}–${v.placar.fora} · ` : ""}
                    {h.prob}%
                  </span>
                  <Selo tipo={v.tipo} minuto={v.minuto} />
                </div>
              </div>
            ))
          )}
        </div>
      </aside>
    </>
  );
}

function Mini({ label, valor, tom }: { label: string; valor: number; tom?: "win" | "loss" | "warn" }) {
  const cor = tom === "win" ? "text-win" : tom === "loss" ? "text-loss" : tom === "warn" ? "text-warn" : "text-fg";
  return (
    <div className="rounded-xl border border-line bg-surface py-2 text-center">
      <div className={`text-base font-extrabold ${cor}`}>{valor}</div>
      <div className="text-xs font-bold tracking-wide text-faint uppercase">{label}</div>
    </div>
  );
}

function Selo({ tipo, minuto }: { tipo: "won" | "lost" | "live" | "pend" | "push"; minuto: string | null }) {
  if (tipo === "won") {
    return <span className="selo-ganho rounded-md border-2 border-fg bg-win px-2 py-1 text-xs font-extrabold tracking-widest text-win-ink">GANHOU</span>;
  }
  if (tipo === "lost") {
    return <span className="rounded-md border border-loss bg-loss-dim px-2 py-1 text-xs font-extrabold text-loss">PERDEU</span>;
  }
  if (tipo === "push") {
    return <span className="rounded-md border border-line px-2 py-1 text-xs font-extrabold text-muted">ANULADO</span>;
  }
  if (tipo === "live") {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-loss bg-loss-dim px-2 py-1 text-xs font-extrabold text-loss">
        <Radio className="ao-vivo-dot size-3" aria-hidden />
        Live{minuto ? ` · ${minuto}` : ""}
      </span>
    );
  }
  return <span className="rounded-md border border-warn bg-warn-dim px-2 py-1 text-xs font-extrabold text-warn">PENDENTE</span>;
}
