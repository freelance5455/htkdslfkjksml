import React, { useState, useMemo } from 'react';
import { Track } from '../types/audio';
import { Search, Play, Pause, Music, Folder, X } from 'lucide-react';

interface Props {
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
}

export const SearchView: React.FC<Props> = ({
  tracks,
  currentTrack,
  isPlaying,
  onPlayTrack,
}) => {
  const [query, setQuery] = useState('');
  const [formatFilter, setFormatFilter] = useState<string>('all');

  const filteredTracks = useMemo(() => {
    const q = query.toLowerCase().trim();
    return tracks.filter((t) => {
      const matchesFormat = formatFilter === 'all' || t.format === formatFilter;
      if (!matchesFormat) return false;
      if (!q) return true;

      return (
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.album.toLowerCase().includes(q) ||
        t.folderPath.toLowerCase().includes(q) ||
        t.format.toLowerCase().includes(q)
      );
    });
  }, [tracks, query, formatFilter]);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Search Input Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          autoFocus
          placeholder="Buscar por título, artista, álbum, carpeta o formato (MP3, OGG, WAV)..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-11 pr-10 py-3.5 text-sm bg-slate-900 border border-slate-800 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 shadow-inner"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Format Filter Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-500 mr-1">Formato:</span>
        {['all', 'mp3', 'ogg', 'wav', 'flac'].map((fmt) => (
          <button
            key={fmt}
            onClick={() => setFormatFilter(fmt)}
            className={`px-3 py-1 rounded-lg border uppercase tracking-wider text-[11px] font-mono transition ${
              formatFilter === fmt
                ? 'bg-indigo-600 border-indigo-500 text-white font-medium'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {fmt === 'all' ? 'Todos' : fmt}
          </button>
        ))}
        <span className="text-slate-500 ml-auto font-mono text-[11px]">
          {filteredTracks.length} resultados
        </span>
      </div>

      {/* Search Results List */}
      {filteredTracks.length === 0 ? (
        <div className="py-12 text-center bg-slate-900/30 rounded-2xl border border-dashed border-slate-800">
          <Music className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-xs text-slate-400 font-medium">No se encontraron canciones</p>
          <p className="text-[11px] text-slate-500 mt-1">
            Intenta con otro término o elimina los filtros de formato.
          </p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {filteredTracks.map((track) => {
            const isCurrent = currentTrack?.id === track.id;
            return (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition ${
                  isCurrent
                    ? 'bg-indigo-950/30 border-indigo-500/50'
                    : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-slate-800 border border-slate-700/50">
                    <img
                      src={track.coverUrl || '/icon.svg'}
                      alt={track.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      {isCurrent && isPlaying ? (
                        <Pause className="w-4 h-4 text-white" />
                      ) : (
                        <Play className="w-4 h-4 text-white ml-0.5" />
                      )}
                    </div>
                  </div>

                  <div className="min-w-0">
                    <p
                      className={`text-xs font-semibold truncate ${
                        isCurrent ? 'text-indigo-400' : 'text-slate-200'
                      }`}
                    >
                      {track.title}
                    </p>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 truncate mt-0.5">
                      <span className="truncate">{track.artist}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate text-slate-500">{track.album}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 ml-3">
                  <div className="hidden sm:flex items-center gap-1 text-[11px] text-slate-500">
                    <Folder className="w-3 h-3 text-slate-600" />
                    <span className="truncate max-w-[120px]">{track.folderPath}</span>
                  </div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 px-1.5 py-0.5 bg-slate-800 rounded">
                    {track.format}
                  </span>
                  <span className="text-xs font-mono tabular-nums text-slate-400">
                    {formatDuration(track.duration)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
