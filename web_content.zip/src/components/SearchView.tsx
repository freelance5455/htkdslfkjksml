import { useMemo, useState } from "react";
import { searchFormulas } from "../data";
import { searchSyllabus, STATUS_COLOR, STATUS_LABEL } from "../data/syllabus";
import type { ClassLevel, Subject } from "../data/types";
import { useAppState } from "../state/AppState";
import FormulaCard from "./FormulaCard";

const SUGGESTIONS = ["circle", "ohm", "velocity", "pythagoras", "mole", "quadratic", "trigonometry", "profit", "density", "probability"];
const CLASS_OPTIONS: (ClassLevel | "All")[] = ["All", 8, 9, 10];
const SUBJECT_OPTIONS: (Subject | "All")[] = ["All", "Mathematics", "Physics", "Chemistry"];

export default function SearchView() {
  const { board, navigate } = useAppState();
  const [query, setQuery] = useState("");
  const [classLevel, setClassLevel] = useState<ClassLevel | "All">("All");
  const [subject, setSubject] = useState<Subject | "All">("All");

  const formulaResults = useMemo(() => {
    const results = searchFormulas(query);
    return results.filter((f) => (classLevel === "All" || f.classLevel === classLevel) && (subject === "All" || f.subject === subject));
  }, [query, classLevel, subject]);

  const chapterResults = useMemo(() => {
    if (!query.trim()) return [];
    return searchSyllabus(query, board, classLevel === "All" ? undefined : classLevel, subject === "All" ? undefined : subject);
  }, [query, board, classLevel, subject]);

  const totalResults = formulaResults.length + chapterResults.length;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Search</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Search interactive formulas and {board} chapters by name, topic, symbol or keyword — e.g. "ohm", "circle", "velocity".
      </p>
      <div className="relative mt-5">
        <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2}>
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4.3-4.3" />
        </svg>
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type to search..."
          className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-12 pr-4 text-base shadow-sm outline-none ring-indigo-200 transition focus:ring-4 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:ring-indigo-500/20"
        />
      </div>

      <div className="mt-3 flex gap-2">
        <select
          value={classLevel}
          onChange={(e) => setClassLevel(e.target.value === "All" ? "All" : (Number(e.target.value) as ClassLevel))}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
        >
          {CLASS_OPTIONS.map((c) => (
            <option key={c} value={c}>
              {c === "All" ? "All Classes" : `Class ${c}`}
            </option>
          ))}
        </select>
        <select
          value={subject}
          onChange={(e) => setSubject(e.target.value as Subject | "All")}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
        >
          {SUBJECT_OPTIONS.map((s) => (
            <option key={s} value={s}>
              {s === "All" ? "All Subjects" : s}
            </option>
          ))}
        </select>
        <span className="flex items-center rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400">
          Board: {board}
        </span>
      </div>

      {!query && (
        <div className="mt-4 flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setQuery(s)}
              className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-500 transition hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {query && (
        <p className="mt-4 text-xs text-slate-400 dark:text-slate-500">
          {totalResults} result{totalResults === 1 ? "" : "s"} for "{query}"
        </p>
      )}

      {chapterResults.length > 0 && (
        <div className="mt-4">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">Chapters</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {chapterResults.map((c) => (
              <button
                key={`${c.board}-${c.classLevel}-${c.subject}-${c.chapter}`}
                onClick={() => navigate({ name: "class", classLevel: c.classLevel, subject: c.subject, chapter: c.chapter })}
                className="flex flex-col gap-1 rounded-xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
              >
                <span className="text-xs text-slate-400">
                  {c.board} · Class {c.classLevel} · {c.subject}
                </span>
                <span className="font-semibold text-slate-800 dark:text-slate-100">{c.chapter}</span>
                <span className={`inline-block w-fit rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${STATUS_COLOR[c.status]}`}>{STATUS_LABEL[c.status]}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {formulaResults.length > 0 && (
        <div className="mt-6">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">Interactive Formulas</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {formulaResults.map((f) => (
              <FormulaCard key={f.id} formula={f} />
            ))}
          </div>
        </div>
      )}

      {query && totalResults === 0 && (
        <div className="mt-10 text-center text-sm text-slate-400 dark:text-slate-500">No results found. Try a different keyword, or ask the AI Tutor.</div>
      )}
    </div>
  );
}
