import React, { useRef, useState } from 'react';
import { X, Download, Upload, FileSpreadsheet, ShieldCheck, Check, AlertCircle } from 'lucide-react';
import { createBackupData, exportToCSV, restoreBackupData } from '../utils/storage';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataRestored: () => void;
  totalCustomers: number;
}

export const BackupModal: React.FC<BackupModalProps> = ({
  isOpen,
  onClose,
  onDataRestored,
  totalCustomers,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const handleDownloadJSON = () => {
    const jsonStr = createBackupData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `gas-customers-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatusMessage({ text: 'बैकअप फ़ाइल (.json) सफलतापूर्वक डाउनलोड हो गई!' });
  };

  const handleDownloadCSV = () => {
    const csvStr = exportToCSV();
    const blob = new Blob([csvStr], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `gas-customers-list-${dateStr}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatusMessage({ text: 'Excel/CSV फ़ाइल सफलतापूर्वक डाउनलोड हो गई!' });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const result = restoreBackupData(content);
        if (result.success) {
          setStatusMessage({ text: result.message });
          onDataRestored();
        } else {
          setStatusMessage({ text: result.message, isError: true });
        }
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-orange-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-5 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-yellow-300" />
            <h2 className="text-base sm:text-lg font-bold">डेटा बैकअप व सुरक्षा</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-orange-100 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 text-slate-700">
          <div className="bg-orange-50 p-3 rounded-xl border border-orange-200 text-xs text-orange-950 font-medium">
            वर्तमान में <strong>{totalCustomers} ग्राहकों</strong> का डेटा आपके फोन के सुरक्षित लोकल स्टोरेज में सुरक्षित है। फोन बदलने या सुरक्षित रखने के लिए बैकअप डाउनलोड करें।
          </div>

          {statusMessage && (
            <div
              className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                statusMessage.isError
                  ? 'bg-rose-50 border border-rose-200 text-rose-700'
                  : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              }`}
            >
              {statusMessage.isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <Check className="w-4 h-4 shrink-0" />}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* Action 1: Export JSON */}
          <div className="border border-slate-200 rounded-xl p-3.5 hover:border-orange-300 transition">
            <h4 className="text-xs font-bold text-slate-900 mb-1 flex items-center gap-1.5">
              <Download className="w-4 h-4 text-orange-600" />
              <span>पूरा बैकअप डाउनलोड करें (JSON फ़ाइल)</span>
            </h4>
            <p className="text-[11px] text-slate-500 mb-2.5">
              सभी फोल्डर और ग्राहकों का संपूर्ण रिकॉर्ड एक फ़ाइल में सुरक्षित करें।
            </p>
            <button
              onClick={handleDownloadJSON}
              className="w-full py-2 px-3 rounded-lg bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>बैकअप फ़ाइल डाउनलोड करें</span>
            </button>
          </div>

          {/* Action 2: Export CSV for Excel */}
          <div className="border border-slate-200 rounded-xl p-3.5 hover:border-emerald-300 transition">
            <h4 className="text-xs font-bold text-slate-900 mb-1 flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Excel सूची डाउनलोड करें (CSV)</span>
            </h4>
            <p className="text-[11px] text-slate-500 mb-2.5">
              नाम, मोबाइल नंबर, डील तारीख और पते की टेबल Excel में देखने हेतु।
            </p>
            <button
              onClick={handleDownloadCSV}
              className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Excel/CSV डाउनलोड करें</span>
            </button>
          </div>

          {/* Action 3: Restore Backup */}
          <div className="border border-slate-200 rounded-xl p-3.5 hover:border-blue-300 transition">
            <h4 className="text-xs font-bold text-slate-900 mb-1 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>बैकअप फ़ाइल से रीस्टोर करें</span>
            </h4>
            <p className="text-[11px] text-slate-500 mb-2.5">
              पहले से डाउनलोड की गई .json बैकअप फ़ाइल चुनें।
            </p>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>बैकअप फ़ाइल चुनें (.json)</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition cursor-pointer"
          >
            बंद करें
          </button>
        </div>
      </div>
    </div>
  );
};
