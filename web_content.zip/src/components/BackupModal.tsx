import React, { useRef, useState } from 'react';
import {
  X,
  Database,
  Download,
  Upload,
  FileSpreadsheet,
  RotateCcw,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';
import {
  exportPaintingCsv,
  exportMaintenanceCsv,
  exportProceduresCsv,
  savePaintingReports,
  saveMaintenanceReports,
  saveProcedureReports
} from '../services/industryStorage';
import {
  INITIAL_PAINTING_REPORTS,
  INITIAL_MAINTENANCE_REPORTS,
  INITIAL_PROCEDURE_REPORTS
} from '../data/industryData';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  paintingReports: PaintingReport[];
  maintenanceReports: MaintenanceReport[];
  procedureReports: ProcedureReport[];
  onDataRestored: (
    paintings: PaintingReport[],
    maintenances: MaintenanceReport[],
    procedures: ProcedureReport[]
  ) => void;
}

export const BackupModal: React.FC<Props> = ({
  isOpen,
  onClose,
  paintingReports,
  maintenanceReports,
  procedureReports,
  onDataRestored
}) => {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isImporting, setIsImporting] = useState(false);

  const handleExportPaintingCsv = () => {
    exportPaintingCsv(paintingReports);
    setSuccessMsg('File CSV Painting Reports scaricato con successo.');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleExportMaintenanceCsv = () => {
    exportMaintenanceCsv(maintenanceReports);
    setSuccessMsg('File CSV Manutenzioni Impianti scaricato con successo.');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleExportProceduresCsv = () => {
    exportProceduresCsv(procedureReports);
    setSuccessMsg('File CSV Specifiche & Procedure scaricato con successo.');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleExportFullJson = () => {
    const payload = {
      version: '3.0',
      exportDate: new Date().toISOString(),
      company: 'Sfiller Sabbiatura e Verniciatura',
      paintingReports,
      maintenanceReports,
      procedureReports
    };
    const jsonStr = JSON.stringify(payload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_sfiller_sabbiatura_verniciatura_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setSuccessMsg('Archivio di backup completo JSON generato e scaricato.');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    setErrorMsg('');
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        const paints: PaintingReport[] = Array.isArray(parsed.paintingReports) ? parsed.paintingReports : [];
        const maints: MaintenanceReport[] = Array.isArray(parsed.maintenanceReports) ? parsed.maintenanceReports : [];
        const procs: ProcedureReport[] = Array.isArray(parsed.procedureReports) ? parsed.procedureReports : [];

        await savePaintingReports(paints);
        await saveMaintenanceReports(maints);
        await saveProcedureReports(procs);

        onDataRestored(paints, maints, procs);
        setSuccessMsg(`Backup ripristinato: ${paints.length} Painting Reports, ${maints.length} Manutenzioni, ${procs.length} Specifiche/Procedure.`);
        setTimeout(() => setSuccessMsg(''), 4000);
      } catch (err: any) {
        setErrorMsg('Errore nel formato del file di backup: ' + (err?.message || 'File non valido'));
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleResetDemo = async () => {
    if (window.confirm('Ripristinare i dati iniziali di prova (Painting Report, Manutenzioni e Specifiche dimostrative)?')) {
      await savePaintingReports(INITIAL_PAINTING_REPORTS);
      await saveMaintenanceReports(INITIAL_MAINTENANCE_REPORTS);
      await saveProcedureReports(INITIAL_PROCEDURE_REPORTS);
      onDataRestored(INITIAL_PAINTING_REPORTS, INITIAL_MAINTENANCE_REPORTS, INITIAL_PROCEDURE_REPORTS);
      setSuccessMsg('Database ripristinato ai dati operativi di fabbrica.');
      setTimeout(() => setSuccessMsg(''), 4000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-neutral-300 w-full max-w-lg overflow-hidden my-auto text-xs">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-neutral-800" />
            <div>
              <h2 className="text-base font-bold text-neutral-900">
                Esportazione Dati & Backup Aziendale
              </h2>
              <p className="text-[11px] text-neutral-500">
                Sfiller Sabbiatura & Verniciatura a Liquido
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-700 rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-md text-emerald-800 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-md text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Export CSVs */}
          <div className="space-y-2">
            <div className="p-3 border border-neutral-200 rounded-lg flex items-center justify-between bg-neutral-50/50">
              <div>
                <h4 className="font-bold text-neutral-900">Excel / CSV: Painting Reports</h4>
                <p className="text-[10px] text-neutral-500">Rapporti di verniciatura, commesse, specifiche e DFT</p>
              </div>
              <button
                onClick={handleExportPaintingCsv}
                className="px-3 py-1.5 bg-white border border-neutral-300 rounded font-semibold text-neutral-800 hover:bg-neutral-100"
              >
                Scarica CSV
              </button>
            </div>

            <div className="p-3 border border-neutral-200 rounded-lg flex items-center justify-between bg-neutral-50/50">
              <div>
                <h4 className="font-bold text-neutral-900">Excel / CSV: Manutenzioni Impianti</h4>
                <p className="text-[10px] text-neutral-500">Interventi, esiti, tempo impiegato e ricambi utilizzati</p>
              </div>
              <button
                onClick={handleExportMaintenanceCsv}
                className="px-3 py-1.5 bg-white border border-neutral-300 rounded font-semibold text-neutral-800 hover:bg-neutral-100"
              >
                Scarica CSV
              </button>
            </div>

            <div className="p-3 border border-neutral-200 rounded-lg flex items-center justify-between bg-neutral-50/50">
              <div>
                <h4 className="font-bold text-neutral-900">Excel / CSV: Specifiche & Procedure</h4>
                <p className="text-[10px] text-neutral-500">Istruzioni operative, layout Report & Run e fasi numerate</p>
              </div>
              <button
                onClick={handleExportProceduresCsv}
                className="px-3 py-1.5 bg-white border border-neutral-300 rounded font-semibold text-neutral-800 hover:bg-neutral-100"
              >
                Scarica CSV
              </button>
            </div>
          </div>

          {/* Backup Full JSON */}
          <div className="p-4 border border-neutral-300 rounded-lg flex items-center justify-between bg-neutral-100/60">
            <div className="flex items-center gap-2.5">
              <Download className="w-5 h-5 text-neutral-800" />
              <div>
                <h4 className="font-bold text-neutral-900">Salva Backup Completo (JSON)</h4>
                <p className="text-[10px] text-neutral-500">Archivio completo di dati e immagini in alta risoluzione</p>
              </div>
            </div>
            <button
              onClick={handleExportFullJson}
              className="px-3.5 py-1.5 bg-neutral-900 text-white rounded font-semibold hover:bg-neutral-800"
            >
              Crea Backup
            </button>
          </div>

          {/* Import JSON */}
          <div className="p-4 border border-neutral-300 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Upload className="w-5 h-5 text-neutral-800" />
              <div>
                <h4 className="font-bold text-neutral-900">Ripristina da Backup JSON</h4>
                <p className="text-[10px] text-neutral-500">Carica un archivio precedentemente salvato</p>
              </div>
            </div>
            <div>
              <input
                type="file"
                ref={fileInputRef}
                accept=".json,application/json"
                onChange={handleFileChange}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isImporting}
                className="px-3.5 py-1.5 bg-white border border-neutral-300 rounded font-semibold text-neutral-800 hover:bg-neutral-50"
              >
                {isImporting ? 'Ripristino...' : 'Carica File'}
              </button>
            </div>
          </div>

          {/* Reset Demo */}
          <div className="pt-2 border-t border-neutral-200 flex justify-between items-center text-[11px] text-neutral-500">
            <span>Dati dimostrativi Sfiller</span>
            <button
              onClick={handleResetDemo}
              className="text-neutral-500 hover:text-rose-600 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Ripristina dati iniziali</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
