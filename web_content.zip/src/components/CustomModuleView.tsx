import React, { useEffect, useMemo, useState } from 'react';
import { Archive, Edit2, Plus, Search, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney } from '../engine/calculations';
import type { CustomRecord } from '../types/app';
import { ConfirmDialog } from './ConfirmDialog';
import { DynamicFormRenderer } from './DynamicFormRenderer';
import { DynamicIcon } from './DynamicIcon';

export const CustomModuleView: React.FC<{ moduleId: string }> = ({ moduleId }) => {
  const {
    snapshot,
    saveCustomRecord,
    toggleArchiveCustomRecord,
    deleteCustomRecord,
    setActiveRoute,
    setSettingsSection,
    notify,
  } = useApp();

  const mod = snapshot.modules.find((m) => m.id === moduleId);
  const submodules = useMemo(
    () =>
      snapshot.submodules
        .filter((s) => s.moduleId === moduleId && s.visible && !s.archived && s.status === 'published')
        .sort((a, b) => a.position - b.position),
    [snapshot.submodules, moduleId]
  );

  const [selectedSubId, setSelectedSubId] = useState<string>('');
  const [showForm, setShowForm] = useState(false);
  const [editingRecord, setEditingRecord] = useState<CustomRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<CustomRecord | null>(null);

  useEffect(() => {
    if (submodules.length > 0 && !submodules.some((s) => s.id === selectedSubId)) {
      setSelectedSubId(submodules[0].id);
    }
  }, [submodules, selectedSubId]);

  const activeSub = submodules.find((s) => s.id === selectedSubId) || submodules[0];

  const subFields = useMemo(
    () =>
      snapshot.fields
        .filter((f) => f.submoduleId === activeSub?.id && f.visible && f.status === 'published')
        .sort((a, b) => a.position - b.position),
    [snapshot.fields, activeSub]
  );

  const records = useMemo(() => {
    if (!activeSub) return [];
    return snapshot.customRecords
      .filter((r) => r.submoduleId === activeSub.id && r.archived === showArchived)
      .filter((r) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return Object.values(r.values).some((v) => String(v ?? '').toLowerCase().includes(q));
      })
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [snapshot.customRecords, activeSub, showArchived, searchQuery]);

  if (!mod) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
        <p className="text-sm text-slate-600">Module not found.</p>
        <button
          type="button"
          onClick={() => setActiveRoute('dashboard')}
          className="mt-3 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-slate-900 cursor-pointer"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white shrink-0"
            style={{ backgroundColor: mod.color }}
          >
            <DynamicIcon name={mod.icon} className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900">{mod.name}</h2>
            <p className="text-xs text-slate-500">
              {mod.description || 'Custom dynamic database module'} · {submodules.length} submodule(s)
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('fields');
            }}
            className="px-3 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Configure Fields
          </button>
          {activeSub && (
            <button
              type="button"
              onClick={() => {
                setEditingRecord(null);
                setShowForm((prev) => !prev);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>{showForm ? 'Close Form' : 'Add Record'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Submodule Switcher */}
      {submodules.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center">
          <p className="text-sm text-slate-600">
            This module has no published submodules yet.
          </p>
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('submodules');
            }}
            className="mt-3 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            Add Submodule in Settings
          </button>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-2" role="tablist">
            {submodules.map((sub) => (
              <button
                key={sub.id}
                type="button"
                role="tab"
                aria-selected={activeSub?.id === sub.id}
                onClick={() => {
                  setSelectedSubId(sub.id);
                  setEditingRecord(null);
                }}
                className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  activeSub?.id === sub.id
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <DynamicIcon name={sub.icon} className="w-3.5 h-3.5" />
                <span>{sub.name}</span>
              </button>
            ))}
          </div>

          {/* Data Entry Form */}
          {showForm && activeSub && (
            <div className="rounded-xl border border-slate-200 bg-white p-6">
              <h3 className="font-display text-base font-bold text-slate-900 mb-4">
                {editingRecord ? `Edit ${activeSub.name} Record` : `New ${activeSub.name} Record`}
              </h3>
              <DynamicFormRenderer
                submoduleId={activeSub.id}
                fields={snapshot.fields.filter((f) => f.status === 'published')}
                formulas={snapshot.formulas.filter((f) => f.status === 'published')}
                mappings={snapshot.fieldMappings.filter((m) => m.status === 'published')}
                masterLists={snapshot.masterLists}
                allRecords={snapshot.customRecords}
                modules={snapshot.modules}
                submodules={snapshot.submodules}
                currency={snapshot.settings.currency}
                initialValues={editingRecord?.values}
                submitLabel={editingRecord ? 'Update Record' : 'Save Record'}
                onCancel={() => {
                  setShowForm(false);
                  setEditingRecord(null);
                }}
                onSubmit={async (values) => {
                  const res = await saveCustomRecord({
                    id: editingRecord?.id,
                    moduleId: mod.id,
                    submoduleId: activeSub.id,
                    values,
                  });
                  if (!res.ok) {
                    notify(res.error || 'Could not save record', 'error');
                    return;
                  }
                  notify(editingRecord ? 'Record updated' : 'Record saved');
                  setEditingRecord(null);
                  setShowForm(false);
                }}
              />
            </div>
          )}

          {/* Records Table */}
          {activeSub && (
            <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" aria-hidden="true" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={`Search ${activeSub.name}...`}
                    aria-label={`Search ${activeSub.name}`}
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300"
                  />
                </div>
                <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showArchived}
                    onChange={(e) => setShowArchived(e.target.checked)}
                  />
                  <span>Show Archived</span>
                </label>
              </div>

              {records.length === 0 ? (
                <div className="p-10 text-center text-sm text-slate-500">
                  No {showArchived ? 'archived ' : ''}records in {activeSub.name} yet.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                        {subFields.map((f) => (
                          <th key={f.id} className="py-3 px-4 whitespace-nowrap">
                            {f.label}
                          </th>
                        ))}
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {records.map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-50/70">
                          {subFields.map((f) => {
                            const val = rec.values[f.name];
                            let display = '';
                            if (Array.isArray(val)) display = val.join(', ');
                            else if (typeof val === 'boolean') display = val ? 'Yes' : 'No';
                            else if (f.type === 'currency' || (f.type === 'formula' && typeof val === 'number')) {
                              display =
                                f.type === 'currency'
                                  ? formatMoney(Number(val) || 0, snapshot.settings)
                                  : String(val ?? '0');
                            } else if (f.type === 'percentage') {
                              display = `${val ?? 0}%`;
                            } else {
                              display = String(val ?? '-');
                            }

                            return (
                              <td
                                key={f.id}
                                className={`py-3 px-4 ${
                                  f.type === 'number' || f.type === 'currency' || f.type === 'formula' || f.type === 'percentage'
                                    ? 'font-mono-num font-medium text-slate-900'
                                    : 'text-slate-700'
                                }`}
                              >
                                {display}
                              </td>
                            );
                          })}
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                aria-label={`Edit record ${rec.id}`}
                                onClick={() => {
                                  setEditingRecord(rec);
                                  setShowForm(true);
                                }}
                                className="p-1.5 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                aria-label={rec.archived ? `Unarchive record ${rec.id}` : `Archive record ${rec.id}`}
                                onClick={async () => {
                                  await toggleArchiveCustomRecord(rec.id, !rec.archived);
                                  notify(rec.archived ? 'Record restored from archive' : 'Record archived');
                                }}
                                className="p-1.5 rounded text-slate-500 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                              >
                                <Archive className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                aria-label={`Delete record ${rec.id}`}
                                onClick={() => setConfirmDelete(rec)}
                                className="p-1.5 rounded text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}

      <ConfirmDialog
        open={!!confirmDelete}
        title="Move Record to Recycle Bin?"
        message="This record will be moved to the Recycle Bin where it can be restored or permanently deleted."
        destructive
        confirmLabel="Delete"
        onConfirm={async () => {
          if (confirmDelete) {
            await deleteCustomRecord(confirmDelete.id);
            notify('Record moved to Recycle Bin');
          }
          setConfirmDelete(null);
        }}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
};
