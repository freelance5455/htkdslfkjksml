import React, { useEffect, useMemo, useState } from 'react';
import { Edit2, Plus, Search, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { evaluateFormula, formatNumber } from '../utils/calculations';
import { ConfirmModal } from './ConfirmModal';

interface CustomModuleViewProps {
  moduleId: string;
}

export const CustomModuleView: React.FC<CustomModuleViewProps> = ({ moduleId }) => {
  const {
    state,
    focusedRecordId,
    clearFocusedRecord,
    tr,
    themeTokens,
    notify,
    upsertCustomRecord,
    deleteCustomRecord,
  } = useApp();

  const mod = state.customModules.find((m) => m.id === moduleId);
  const [editId, setEditId] = useState<string | null>(null);
  const [selectedSubId, setSelectedSubId] = useState<string>('');
  const [values, setValues] = useState<Record<string, string | number | boolean | string[]>>({});
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [confirmDelId, setConfirmDelId] = useState<string | null>(null);

  const activeFields = useMemo(
    () =>
      (mod?.fields || [])
        .filter((f) => f.visible && !f.archived)
        .sort((a, b) => a.order - b.order),
    [mod]
  );

  const activeSubmodules = useMemo(
    () =>
      (mod?.submodules || [])
        .filter((s) => s.visible && !s.archived)
        .sort((a, b) => a.order - b.order),
    [mod]
  );

  const formFields = activeFields.filter((f) => f.showInForm);
  const tableFields = activeFields.filter((f) => f.showInTable);

  const initDefaults = () => {
    const next: Record<string, string | number | boolean | string[]> = {};
    for (const f of activeFields) {
      if (f.type === 'checkbox') next[f.key] = f.defaultValue === 'true';
      else if (f.type === 'multi_select') next[f.key] = [];
      else next[f.key] = f.defaultValue || '';
    }
    setValues(next);
    setEditId(null);
    setError('');
  };

  useEffect(() => {
    initDefaults();
    setSelectedSubId(activeSubmodules[0]?.id || '');
  }, [moduleId]);

  useEffect(() => {
    if (focusedRecordId) {
      const rec = state.customRecords.find((r) => r.id === focusedRecordId && r.moduleId === moduleId);
      if (rec) {
        setEditId(rec.id);
        setValues({ ...rec.values });
        setSelectedSubId(rec.submoduleId || '');
        clearFocusedRecord();
      }
    }
  }, [focusedRecordId, moduleId, state.customRecords, clearFocusedRecord]);

  // Compute live formula values
  const computedValues = useMemo(() => {
    const out = { ...values };
    for (const f of activeFields) {
      if (f.type === 'formula') {
        out[f.key] = evaluateFormula(f.formula, out);
      }
    }
    return out;
  }, [values, activeFields]);

  const records = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.customRecords
      .filter((r) => {
        if (r.moduleId !== moduleId) return false;
        if (activeSubmodules.length > 0 && selectedSubId && r.submoduleId !== selectedSubId) {
          return false;
        }
        if (q) {
          const hay = Object.values(r.values).join(' ').toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [state.customRecords, moduleId, activeSubmodules.length, selectedSubId, search]);

  if (!mod) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
        Custom module not found.
      </div>
    );
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const finalValues: Record<string, string | number | boolean | string[]> = { ...computedValues };

    for (const f of formFields) {
      if (f.type === 'formula') {
        finalValues[f.key] = evaluateFormula(f.formula, finalValues);
        continue;
      }
      const val = finalValues[f.key];
      if (f.required) {
        if (
          val === '' ||
          val === undefined ||
          val === null ||
          (Array.isArray(val) && val.length === 0)
        ) {
          setError(`"${f.label}" is required.`);
          return;
        }
      }
      if ((f.type === 'number' || f.type === 'decimal') && val !== '') {
        const num = Number(val);
        if (!Number.isFinite(num)) {
          setError(`"${f.label}" must be a valid number.`);
          return;
        }
        if (f.min !== undefined && num < f.min) {
          setError(`"${f.label}" must be at least ${f.min}.`);
          return;
        }
        if (f.max !== undefined && num > f.max) {
          setError(`"${f.label}" must be at most ${f.max}.`);
          return;
        }
        finalValues[f.key] = num;
      }
    }

    upsertCustomRecord(moduleId, finalValues, selectedSubId || undefined, editId || undefined);
    notify(editId ? 'Record updated.' : 'Record saved.');
    initDefaults();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">{mod.name}</h2>
          {mod.description && <p className="text-xs text-slate-500 mt-0.5">{mod.description}</p>}
        </div>
        {activeSubmodules.length > 0 && (
          <div className="inline-flex rounded-lg bg-slate-200/70 p-1">
            {activeSubmodules.map((sub) => (
              <button
                key={sub.id}
                type="button"
                onClick={() => setSelectedSubId(sub.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap ${
                  selectedSubId === sub.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {sub.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Dynamic Form */}
      {formFields.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-6 text-sm text-slate-500">
          This custom module has no fields yet. Open Dynamic Settings to add fields.
        </div>
      ) : (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              {editId ? `Edit ${mod.name} Record` : `Add ${mod.name} Record`}
            </h3>
            {editId && (
              <button type="button" onClick={initDefaults} className="text-xs text-slate-500">
                {tr('cancel')}
              </button>
            )}
          </div>

          {error && (
            <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {formFields.map((f) => {
              const val = computedValues[f.key];
              const fieldId = `cf_${f.id}`;
              return (
                <div key={f.id} className={f.type === 'long_text' ? 'sm:col-span-2 lg:col-span-3' : ''}>
                  <label htmlFor={fieldId} className="block text-xs font-medium text-slate-700 mb-1">
                    {f.label}
                    {f.unit ? ` (${f.unit})` : ''}
                    {f.required ? ' *' : ''}
                  </label>

                  {f.type === 'short_text' && (
                    <input
                      id={fieldId}
                      type="text"
                      value={String(val ?? '')}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      required={f.required}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  )}

                  {f.type === 'long_text' && (
                    <textarea
                      id={fieldId}
                      rows={2}
                      value={String(val ?? '')}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      required={f.required}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  )}

                  {(f.type === 'number' || f.type === 'decimal') && (
                    <input
                      id={fieldId}
                      type="number"
                      step={f.type === 'decimal' ? 'any' : '1'}
                      value={String(val ?? '')}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      required={f.required}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                    />
                  )}

                  {f.type === 'date' && (
                    <input
                      id={fieldId}
                      type="date"
                      value={String(val ?? '')}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                      required={f.required}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  )}

                  {f.type === 'dropdown' && (
                    <select
                      id={fieldId}
                      value={String(val ?? '')}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                      required={f.required}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      <option value="">Select...</option>
                      {f.options.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  )}

                  {f.type === 'multi_select' && (
                    <div className="flex flex-wrap gap-2 rounded-lg border border-slate-300 p-2">
                      {f.options.map((opt) => {
                        const arr = Array.isArray(val) ? val : [];
                        const checked = arr.includes(opt);
                        return (
                          <label key={opt} className="inline-flex items-center gap-1.5 text-xs text-slate-700">
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                const next = checked ? arr.filter((x) => x !== opt) : [...arr, opt];
                                setValues((v) => ({ ...v, [f.key]: next }));
                              }}
                            />
                            <span>{opt}</span>
                          </label>
                        );
                      })}
                    </div>
                  )}

                  {f.type === 'checkbox' && (
                    <label className="inline-flex items-center gap-2 py-2 text-sm text-slate-700">
                      <input
                        id={fieldId}
                        type="checkbox"
                        checked={Boolean(val)}
                        onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.checked }))}
                      />
                      <span>{f.placeholder || 'Yes'}</span>
                    </label>
                  )}

                  {f.type === 'formula' && (
                    <input
                      id={fieldId}
                      type="text"
                      readOnly
                      value={`${formatNumber(Number(val) || 0)}${f.unit ? ` ${f.unit}` : ''}`}
                      className="w-full rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-sm font-semibold tabular-nums text-emerald-900"
                    />
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
            >
              <Plus className="h-4 w-4" />
              <span>{editId ? tr('update') : tr('save')}</span>
            </button>
          </div>
        </form>
      )}

      {/* Records Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search ${mod.name}...`}
              aria-label={`Search ${mod.name}`}
              className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
            />
          </div>
          <span className="text-xs text-slate-500 tabular-nums">{records.length} records</span>
        </div>

        {records.length === 0 ? (
          <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <tr>
                  {tableFields.map((f) => (
                    <th key={f.id} className="px-4 py-3 text-start whitespace-nowrap">
                      {f.label}
                    </th>
                  ))}
                  <th className="px-4 py-3 text-end">{tr('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {records.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50">
                    {tableFields.map((f) => {
                      const raw =
                        f.type === 'formula'
                          ? evaluateFormula(f.formula, rec.values)
                          : rec.values[f.key];
                      const display = Array.isArray(raw)
                        ? raw.join(', ')
                        : typeof raw === 'boolean'
                          ? raw
                            ? 'Yes'
                            : 'No'
                          : f.type === 'formula' || f.type === 'number' || f.type === 'decimal'
                            ? formatNumber(Number(raw) || 0)
                            : String(raw ?? '—');
                      return (
                        <td key={f.id} className="px-4 py-3 tabular-nums">
                          {display}
                        </td>
                      );
                    })}
                    <td className="px-4 py-3 text-end whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => {
                          setEditId(rec.id);
                          setValues({ ...rec.values });
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        aria-label="Edit custom record"
                        className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (!state.settings.confirmBeforeDelete) {
                            deleteCustomRecord(rec.id);
                            notify('Moved to Recycle Bin.');
                          } else {
                            setConfirmDelId(rec.id);
                          }
                        }}
                        aria-label="Delete custom record"
                        className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmModal
        open={Boolean(confirmDelId)}
        title={tr('confirm_delete_title')}
        message={tr('confirm_delete_msg')}
        confirmLabel={tr('delete')}
        cancelLabel={tr('cancel')}
        onCancel={() => setConfirmDelId(null)}
        onConfirm={() => {
          if (confirmDelId) {
            deleteCustomRecord(confirmDelId);
            notify('Moved to Recycle Bin.');
          }
          setConfirmDelId(null);
        }}
      />
    </div>
  );
};
