import React, { useRef, useState, useEffect } from 'react';
import { Camera, X, Download, RefreshCw, SwitchCamera } from 'lucide-react';
import { deviceService } from '../services/deviceService';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPhotoCaptured?: (dataUrl: string) => void;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  onClose,
  onPhotoCaptured,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [streamActive, setStreamActive] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  useEffect(() => {
    if (isOpen) {
      setCapturedPhoto(null);
      setErrorMessage(null);
      initCamera(facingMode);
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const initCamera = async (facing: 'environment' | 'user') => {
    try {
      if (videoRef.current) {
        await deviceService.openCamera(videoRef.current, facing);
        setStreamActive(true);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Kameraga ulanishda xatolik yuz berdi, Sir.");
      setStreamActive(false);
    }
  };

  const stopCamera = () => {
    deviceService.closeCamera();
    setStreamActive(false);
  };

  const handleCapture = () => {
    if (videoRef.current) {
      try {
        const photoUrl = deviceService.capturePhoto(videoRef.current);
        setCapturedPhoto(photoUrl);
        if (onPhotoCaptured) {
          onPhotoCaptured(photoUrl);
        }
      } catch (err) {
        setErrorMessage("Suratga olishda xatolik yuz berdi, Sir.");
      }
    }
  };

  const handleSwitchCamera = async () => {
    if (videoRef.current) {
      try {
        const nextFacing = await deviceService.switchCamera(videoRef.current);
        setFacingMode(nextFacing);
      } catch (e: any) {
        setErrorMessage("Kamerani almashtirib bo'lmadi, Sir.");
      }
    }
  };

  const handleRetake = () => {
    setCapturedPhoto(null);
    initCamera(facingMode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-950 border border-cyan-500/40 rounded-xl overflow-hidden shadow-[0_0_35px_rgba(6,182,212,0.2)]">
        {/* Yuqori qism */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-cyan-500/20 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-cyan-400" />
            <span className="font-display text-sm tracking-wider text-cyan-300">
              JARVIS // OPTIK DATCHIK ({facingMode === 'environment' ? 'ORQA' : 'SELFI'})
            </span>
          </div>

          <div className="flex items-center gap-2">
            {!capturedPhoto && streamActive && (
              <button
                onClick={handleSwitchCamera}
                className="p-1.5 text-cyan-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="Kamerani almashtirish (Old / Orqa)"
              >
                <SwitchCamera className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video / Foto Oynasi */}
        <div className="relative aspect-video sm:aspect-4/3 bg-black flex items-center justify-center overflow-hidden">
          {errorMessage ? (
            <div className="p-6 text-center text-rose-400 text-sm">
              {errorMessage}
            </div>
          ) : capturedPhoto ? (
            <img
              src={capturedPhoto}
              alt="Olingan surat"
              className="w-full h-full object-contain"
            />
          ) : (
            <>
              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
              />
              {/* Futuristik nishon to'ri */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-44 h-44 border border-cyan-400/30 rounded-lg relative">
                  <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
                  <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2.5 h-2.5 bg-cyan-400/80 rounded-full animate-ping" />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Pastki boshqaruv */}
        <div className="p-4 border-t border-cyan-500/20 bg-slate-900/40 flex items-center justify-between gap-3">
          {capturedPhoto ? (
            <>
              <button
                onClick={handleRetake}
                className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-300 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                Qayta olish
              </button>
              <a
                href={capturedPhoto}
                download={`jarvis-photo-${Date.now()}.jpg`}
                className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-sm"
              >
                <Download className="w-4 h-4" />
                Saqlab olish
              </a>
            </>
          ) : (
            <>
              <button
                onClick={handleSwitchCamera}
                className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
              >
                <SwitchCamera className="w-4 h-4 text-cyan-400" />
                <span>{facingMode === 'environment' ? 'Selfi kameraga' : 'Orqa kameraga'}</span>
              </button>

              <button
                onClick={handleCapture}
                disabled={!streamActive}
                className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg transition-all shadow-[0_0_15px_rgba(6,182,212,0.4)]"
              >
                <Camera className="w-4 h-4" />
                Suratga olish
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
