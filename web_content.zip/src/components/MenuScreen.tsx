/**
 * SPR - Sahil Powerful Run
 * Master Home Screen UI
 * Rebuilt to closely match the SPR Home Screen reference image:
 * - Top Profile, Coin & Diamond Pills, Settings
 * - Left Actions: Daily Reward, Mission, Leaderboard
 * - Right Actions: Free Coins, Spin, Remove Ads
 * - Center SPR RUN 3D Logo with Crown & Ribbon Banner
 * - Lower Feature Cards: "Unlock All Players" & "Skateboard Collection"
 * - Bottom Action Row: Free Chest progress bar & Giant 3D "PLAY" Button
 * - Bottom Navigation Bar: Home, Players, Skateboard, Store, Settings
 */

import React from 'react';
import {
  Settings,
  Plus,
  Flame,
  Gift,
  Award,
  Trophy,
  Play,
  RotateCw,
  Ban,
  Home,
  User,
  ShoppingBag,
  Sliders,
  Sparkles,
  Smartphone,
  BarChart2,
  Mail,
} from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';
import { CHARACTERS } from '../game/constants';
import { SKATEBOARDS } from '../game/constants/skateboards';
import { useRewardCooldown } from '../hooks/useRewardCooldown';
import { useOrientation } from '../hooks/useOrientation';

interface Props {
  onPlay: () => void;
  onOpenShop: (tab?: 'characters' | 'skateboards') => void;
  onOpenDailyReward: () => void;
  onOpenLeaderboard: () => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  onOpenAbout: () => void;
  onOpenAndroidApp?: () => void;
  onOpenMissions: () => void;
  onOpenSpin: () => void;
  onOpenFreeCoins: () => void;
  onOpenRemoveAds: () => void;
  onOpenFreeChest: () => void;
  coins: number;
  diamonds: number;
  isPortrait?: boolean;
}

export const MenuScreen: React.FC<Props> = ({
  onPlay,
  onOpenShop,
  onOpenDailyReward,
  onOpenLeaderboard,
  onOpenSettings,
  onOpenHelp,
  onOpenAbout,
  onOpenAndroidApp,
  onOpenMissions,
  onOpenSpin,
  onOpenFreeCoins,
  onOpenRemoveAds,
  onOpenFreeChest,
  coins,
  diamonds,
  isPortrait: isPortraitProp,
}) => {
  const detectedPortrait = useOrientation();
  const isVertical = isPortraitProp !== undefined ? isPortraitProp : detectedPortrait;
  const selectedCharId = saveManager.getSelectedCharacterId();
  const currentChar = CHARACTERS.find((c) => c.id === selectedCharId) || CHARACTERS[0];

  const equippedBoardId = saveManager.getEquippedSkateboardId();
  const currentBoard = SKATEBOARDS.find((b) => b.id === equippedBoardId) || SKATEBOARDS[0];

  const dailyState = saveManager.getSaveData().dailyReward;
  const chestData = saveManager.getChestProgress();
  const playerLvl = saveManager.getPlayerLevel();

  // Offline 24-Hour Reward Cooldowns
  const dailyCd = useRewardCooldown('daily_reward');
  const spinCd = useRewardCooldown('spin');
  const freeCoinsCd = useRewardCooldown('free_coins');
  const missionsCd = useRewardCooldown('missions');
  const leaderboardCd = useRewardCooldown('leaderboard');

  const handleAction = (cb: () => void) => {
    soundManager.playButtonClick();
    cb();
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-between p-2.5 sm:p-4 md:p-6 select-none pointer-events-none overflow-hidden safe-insets">
      {/* ========================================================================= */}
      {/* 1. TOP BAR: Profile, Coin Pill, Diamond Pill, & Top Navigation Icons       */}
      {/* ========================================================================= */}
      <header className="w-full flex items-start sm:items-center justify-between gap-1.5 sm:gap-2 pointer-events-auto pt-[max(0.25rem,env(safe-area-inset-top))]">
        {/* Profile Card (Left) */}
        <div
          id="menu-profile-card"
          onClick={() => handleAction(() => onOpenShop('characters'))}
          className="flex items-center gap-2 sm:gap-2.5 px-2 sm:px-2.5 py-1 sm:py-1.5 bg-slate-900/85 hover:bg-slate-800/90 border-2 border-amber-400/80 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95 shrink-0"
          title="Profile & Runners"
        >
          {/* Avatar with Crown Badge */}
          <div className="relative w-8 h-8 sm:w-11 sm:h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-md shrink-0">
            <img
              src="/thumbnail.jpg"
              alt="Runner Avatar"
              className="w-full h-full rounded-full object-cover"
            />
            <div className="absolute -top-1.5 -left-1 text-xs sm:text-sm filter drop-shadow">
              👑
            </div>
          </div>

          {/* Profile Name & Level */}
          <div className="flex flex-col pr-1.5 sm:pr-2">
            <div className="flex items-center gap-1">
              <span className="text-[11px] sm:text-sm font-black text-white tracking-wide uppercase font-heading drop-shadow">
                {currentChar.name}
              </span>
              <span className="text-[9px] sm:text-xs font-extrabold text-amber-300 bg-amber-500/20 px-1 sm:px-1.5 py-0.2 rounded font-mono">
                Lv.{playerLvl.level}
              </span>
            </div>
            {/* XP Bar */}
            <div className="w-14 sm:w-20 h-1.5 bg-slate-700/80 rounded-full overflow-hidden mt-0.5 border border-slate-600/50">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full"
                style={{ width: `${(playerLvl.xp / playerLvl.maxExp) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Currency Pills & Top Action Buttons (Right) */}
        <div className="flex flex-col items-end gap-1 sm:gap-1.5 shrink-0">
          {/* Currency Row */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Coin Pill */}
            <div
              id="menu-coin-pill"
              onClick={() => handleAction(() => onOpenShop('characters'))}
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-0.5 sm:py-1 bg-slate-900/85 hover:bg-slate-800/90 border-2 border-amber-400/80 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Coins - Tap to Open Store"
            >
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow">
                <span className="text-black text-[10px] sm:text-xs font-black">🪙</span>
              </div>
              <span className="text-amber-300 font-black text-xs sm:text-base font-mono tracking-wide">
                {coins.toLocaleString()}
              </span>
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-md ml-0.5">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </div>

            {/* Diamond Pill */}
            <div
              id="menu-diamond-pill"
              onClick={() => handleAction(() => onOpenShop('skateboards'))}
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-0.5 sm:py-1 bg-slate-900/85 hover:bg-slate-800/90 border-2 border-cyan-400/80 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Diamonds - Tap to Open Store"
            >
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-tr from-cyan-600 to-sky-300 flex items-center justify-center shadow">
                <span className="text-[10px] sm:text-xs">💎</span>
              </div>
              <span className="text-cyan-300 font-black text-xs sm:text-base font-mono tracking-wide">
                {diamonds.toLocaleString()}
              </span>
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-md ml-0.5">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </div>
          </div>

          {/* Top Action Icons Row (Matching Reference Image) */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {/* Settings Button */}
            <button
              id="menu-btn-settings"
              onClick={() => handleAction(onOpenSettings)}
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/85 hover:bg-slate-800/90 border border-slate-600/80 text-slate-200 hover:text-white flex items-center justify-center shadow backdrop-blur-md cursor-pointer transition transform hover:rotate-90 hover:scale-105 active:scale-95"
              title="Game Settings"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Stats / Leaderboard Button */}
            <button
              id="menu-btn-leaderboard"
              onClick={() => handleAction(onOpenLeaderboard)}
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/85 hover:bg-slate-800/90 border border-yellow-400/70 text-yellow-300 flex items-center justify-center shadow backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="High Scores & Leaderboard"
            >
              <BarChart2 className="w-4 h-4" />
            </button>

            {/* Notification / Messages Button */}
            <button
              id="menu-btn-notifications"
              onClick={() => handleAction(onOpenDailyReward)}
              className="relative w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/85 hover:bg-slate-800/90 border border-red-400/70 text-red-300 flex items-center justify-center shadow backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Daily Rewards & Notifications"
            >
              <Mail className="w-4 h-4" />
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-red-500 border border-white text-white rounded-full text-[8px] font-black flex items-center justify-center">
                3
              </span>
            </button>

            {/* Runners / Character Button */}
            <button
              id="menu-btn-runners"
              onClick={() => handleAction(() => onOpenShop('characters'))}
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/85 hover:bg-slate-800/90 border border-amber-400/70 text-amber-300 flex items-center justify-center shadow backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Runners & Characters"
            >
              <User className="w-4 h-4" />
            </button>

            {/* Skateboards Button */}
            <button
              id="menu-btn-boards"
              onClick={() => handleAction(() => onOpenShop('skateboards'))}
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/85 hover:bg-slate-800/90 border border-cyan-400/70 text-cyan-300 flex items-center justify-center shadow backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Skateboards"
            >
              <span className="text-xs">🛹</span>
            </button>

            {/* About SPR Button */}
            <button
              id="menu-btn-about"
              onClick={() => handleAction(onOpenAbout)}
              className="flex items-center gap-1 px-2 py-1 bg-gradient-to-r from-amber-500/20 via-yellow-500/25 to-amber-500/20 hover:from-amber-500/35 hover:to-yellow-500/35 border border-amber-400/90 text-amber-300 hover:text-white rounded-full shadow backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="About SAHIL POWERFUL RUN"
            >
              <span className="text-xs">👑</span>
              <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-wider font-display drop-shadow">
                ABOUT
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. MIDDLE AREA: Left Column, Center SPR RUN Logo, Right Column */}
      {/* ========================================================================= */}
      <div className="relative flex-1 flex items-start justify-between w-full my-2">
        {/* --- LEFT ACTIONS COLUMN --- */}
        <div className="flex flex-col gap-3 pointer-events-auto z-30 pt-4">
          {/* DAILY REWARD */}
          <button
            id="menu-btn-daily-reward"
            onClick={() => handleAction(onOpenDailyReward)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="Claim Daily Reward"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-red-600 via-rose-700 to-red-900 border-2 border-amber-400 shadow-[0_4px_16px_rgba(239,68,68,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">🎁</span>
              {dailyCd.isAvailable ? (
                <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-white text-[10px] font-black animate-bounce shadow">
                  !
                </div>
              ) : (
                <div className="absolute -bottom-1.5 bg-slate-950/95 border border-amber-400/80 text-amber-300 font-mono text-[8px] sm:text-[9px] font-black px-1.5 py-0.2 rounded-full shadow flex items-center gap-0.5">
                  <span>🔒</span>
                  <span>{dailyCd.countdown}</span>
                </div>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              DAILY<br />REWARD
            </span>
          </button>

          {/* MISSION */}
          <button
            id="menu-btn-missions"
            onClick={() => handleAction(onOpenMissions)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="Daily Runner Missions"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-blue-600 via-indigo-700 to-blue-900 border-2 border-cyan-400 shadow-[0_4px_16px_rgba(59,130,246,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">📋</span>
              {!missionsCd.isAvailable ? (
                <div className="absolute -bottom-1.5 bg-slate-950/95 border border-cyan-400/80 text-cyan-300 font-mono text-[8px] sm:text-[9px] font-black px-1.5 py-0.2 rounded-full shadow flex items-center gap-0.5">
                  <span>🔒</span>
                  <span>{missionsCd.countdown}</span>
                </div>
              ) : (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-400 border border-white flex items-center justify-center text-slate-950 text-[9px] font-black shadow">
                  ★
                </div>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              MISSION
            </span>
          </button>

          {/* LEADERBOARD */}
          <button
            id="menu-btn-leaderboard"
            onClick={() => handleAction(onOpenLeaderboard)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="World High Scores & Leaderboard"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-amber-500 via-yellow-600 to-amber-800 border-2 border-yellow-300 shadow-[0_4px_16px_rgba(245,158,11,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">🏆</span>
              {!leaderboardCd.isAvailable ? (
                <div className="absolute -bottom-1.5 bg-slate-950/95 border border-amber-400/80 text-amber-300 font-mono text-[8px] sm:text-[9px] font-black px-1.5 py-0.2 rounded-full shadow flex items-center gap-0.5">
                  <span>🔒</span>
                  <span>{leaderboardCd.countdown}</span>
                </div>
              ) : (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 border border-white flex items-center justify-center text-slate-950 text-[9px] font-black shadow">
                  👑
                </div>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              LEADER<br />BOARD
            </span>
          </button>
        </div>

        {/* --- TOP-CENTER SPR RUN LOGO & BANNER --- */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-auto z-10">
          {/* Stylized 3D SPR RUN Brand */}
          <div className="relative flex items-center justify-center select-none">
            {/* Crown perched atop the S */}
            <div className="absolute -top-5 sm:-top-7 left-1 sm:left-3 text-2xl sm:text-4xl filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)] rotate-[-12deg] animate-pulse">
              👑
            </div>

            {/* SPR Text in 3D White & Cyan Glow */}
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-heading tracking-tight text-white drop-shadow-[0_6px_0_#1e3a8a] stroke-text">
              SPR
            </h1>

            {/* RUN Text in Fiery Orange/Yellow 3D */}
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-heading tracking-tight ml-2 sm:ml-3 text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 via-orange-400 to-red-600 drop-shadow-[0_6px_0_#7f1d1d]">
              RUN
            </h1>
          </div>

          {/* Yellow Ribbon Banner: RUN • COLLECT • UPGRADE */}
          <div className="mt-1 px-4 sm:px-6 py-0.5 sm:py-1 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border border-yellow-200 rounded-full shadow-[0_4px_12px_rgba(245,158,11,0.6)] transform -rotate-1">
            <span className="text-[10px] sm:text-xs font-black tracking-[0.2em] text-slate-950 uppercase font-display drop-shadow-sm">
              RUN • COLLECT • UPGRADE
            </span>
          </div>

          {/* Android App Button if available */}
          {onOpenAndroidApp && (
            <button
              onClick={() => handleAction(onOpenAndroidApp)}
              className="mt-2 flex items-center gap-1.5 px-3 py-1 bg-slate-900/80 hover:bg-slate-800 border border-amber-400/60 rounded-full text-amber-300 font-extrabold text-[11px] transition shadow cursor-pointer hover:scale-105 active:scale-95"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              <span>OFFLINE ANDROID APK</span>
            </button>
          )}
        </div>

        {/* --- RIGHT ACTIONS COLUMN --- */}
        <div className="flex flex-col gap-3 pointer-events-auto z-30 pt-4">
          {/* FREE COINS */}
          <button
            id="menu-btn-free-coins"
            onClick={() => handleAction(onOpenFreeCoins)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="Claim Free Bonus Coins"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-amber-500 via-yellow-600 to-amber-800 border-2 border-yellow-300 shadow-[0_4px_16px_rgba(245,158,11,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">🪙</span>
              {freeCoinsCd.isAvailable ? (
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-red-600 border border-white flex items-center justify-center text-white text-[9px] shadow animate-pulse">
                  ▶
                </div>
              ) : (
                <div className="absolute -bottom-1.5 bg-slate-950/95 border border-amber-400/80 text-amber-300 font-mono text-[8px] sm:text-[9px] font-black px-1.5 py-0.2 rounded-full shadow flex items-center gap-0.5">
                  <span>🔒</span>
                  <span>{freeCoinsCd.countdown}</span>
                </div>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              FREE<br />COINS
            </span>
          </button>

          {/* SPIN WHEEL */}
          <button
            id="menu-btn-spin"
            onClick={() => handleAction(onOpenSpin)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="Lucky Fortune Spin Wheel"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-purple-600 via-fuchsia-700 to-pink-800 border-2 border-pink-400 shadow-[0_4px_16px_rgba(168,85,247,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">🎡</span>
              {spinCd.isAvailable ? (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 border border-white flex items-center justify-center text-slate-950 text-[9px] font-black animate-spin shadow">
                  ★
                </div>
              ) : (
                <div className="absolute -bottom-1.5 bg-slate-950/95 border border-pink-400/80 text-pink-300 font-mono text-[8px] sm:text-[9px] font-black px-1.5 py-0.2 rounded-full shadow flex items-center gap-0.5">
                  <span>🔒</span>
                  <span>{spinCd.countdown}</span>
                </div>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              SPIN
            </span>
          </button>

          {/* REMOVE ADS */}
          <button
            id="menu-btn-remove-ads"
            onClick={() => handleAction(onOpenRemoveAds)}
            className="group flex flex-col items-center gap-1 transition transform hover:scale-110 active:scale-95 cursor-pointer focus:outline-none"
            title="VIP Ad-Free Pass"
          >
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-red-600 via-rose-700 to-red-900 border-2 border-red-400 shadow-[0_4px_16px_rgba(239,68,68,0.5)] flex items-center justify-center">
              <span className="text-2xl sm:text-3xl filter drop-shadow">🚫</span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] text-center leading-none">
              REMOVE<br />ADS
            </span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. LOWER SECTION: Feature Cards, Free Chest, Big 3D PLAY Button */}
      {/* ========================================================================= */}
      <div className="w-full flex flex-col gap-3 pointer-events-auto z-30 pb-16 sm:pb-20">
        {/* --- LOWER FEATURE CARDS ROW --- */}
        <div className="grid grid-cols-2 gap-2 sm:gap-4 max-w-2xl mx-auto w-full">
          {/* Card 1: UNLOCK ALL PLAYERS */}
          <div
            onClick={() => handleAction(() => onOpenShop('characters'))}
            className="flex items-center justify-between p-2 sm:p-2.5 bg-slate-900/90 hover:bg-slate-800/95 border-2 border-cyan-500/60 hover:border-cyan-400 rounded-2xl shadow-[0_6px_20px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-102 active:scale-98"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-400 flex items-center justify-center shadow shrink-0">
                <span className="text-lg">🏃</span>
              </div>
              <div className="truncate">
                <span className="text-[10px] sm:text-xs font-black text-white uppercase block leading-tight font-heading">
                  UNLOCK ALL
                </span>
                <span className="text-[11px] sm:text-sm font-black text-cyan-400 uppercase block leading-tight font-display">
                  PLAYERS
                </span>
              </div>
            </div>
            <button className="px-2.5 sm:px-4 py-1 sm:py-1.5 bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-black text-[10px] sm:text-xs uppercase rounded-xl shadow shrink-0">
              VIEW
            </button>
          </div>

          {/* Card 2: SKATEBOARD COLLECTION */}
          <div
            onClick={() => handleAction(() => onOpenShop('skateboards'))}
            className="flex items-center justify-between p-2 sm:p-2.5 bg-slate-900/90 hover:bg-slate-800/95 border-2 border-amber-500/60 hover:border-amber-400 rounded-2xl shadow-[0_6px_20px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-102 active:scale-98"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center shadow shrink-0">
                <span className="text-lg">🛹</span>
              </div>
              <div className="truncate">
                <span className="text-[10px] sm:text-xs font-black text-white uppercase block leading-tight font-heading">
                  SKATEBOARD
                </span>
                <span className="text-[11px] sm:text-sm font-black text-amber-400 uppercase block leading-tight font-display">
                  COLLECTION
                </span>
              </div>
            </div>
            <button className="px-2.5 sm:px-4 py-1 sm:py-1.5 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[10px] sm:text-xs uppercase rounded-xl shadow shrink-0">
              VIEW
            </button>
          </div>
        </div>

        {/* --- BOTTOM ACTION ROW: Free Chest & Giant 3D PLAY Button --- */}
        <div className="flex items-center justify-between gap-3 max-w-2xl mx-auto w-full">
          {/* Left: FREE CHEST BUTTON */}
          <div
            id="menu-btn-free-chest"
            onClick={() => handleAction(onOpenFreeChest)}
            className="flex items-center gap-2.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800/95 border-2 border-amber-400/80 rounded-2xl shadow-[0_6px_20px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition transform hover:scale-105 active:scale-95"
            title="Open Free Chest"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-md animate-pulse">
              <span className="text-2xl">🎁</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] sm:text-xs font-black text-white uppercase font-heading">
                  FREE CHEST
                </span>
                <span className="text-[10px] font-extrabold text-amber-300 font-mono">
                  {chestData.progress}/{chestData.max}
                </span>
              </div>
              {/* Progress Bar */}
              <div className="w-24 sm:w-28 h-2 bg-slate-700/80 rounded-full overflow-hidden mt-1 border border-slate-600/40">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full transition-all duration-300"
                  style={{ width: `${(chestData.progress / chestData.max) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Right: GIANT 3D COMIC PLAY BUTTON */}
          <button
            id="menu-btn-play"
            onClick={() => handleAction(onPlay)}
            className="relative group flex items-center justify-center px-8 sm:px-12 py-3.5 sm:py-4 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 border-4 border-yellow-200 rounded-3xl shadow-[0_8px_0_#b45309,0_15px_25px_rgba(245,158,11,0.7)] hover:shadow-[0_4px_0_#b45309,0_10px_20px_rgba(245,158,11,0.8)] hover:translate-y-1 active:translate-y-2 active:shadow-none transition-all transform cursor-pointer overflow-hidden animate-pulse"
          >
            {/* Glossy top highlight */}
            <div className="absolute top-0 inset-x-0 h-1/2 bg-white/30 rounded-t-2xl pointer-events-none" />

            {/* Inner Content with Comic Font */}
            <div className="relative flex items-center gap-2">
              <Play className="w-7 h-7 sm:w-9 sm:h-9 text-slate-950 fill-slate-950 filter drop-shadow" />
              <span className="text-3xl sm:text-4xl font-black italic tracking-wider text-slate-950 uppercase font-heading drop-shadow-[0_2px_0_rgba(255,255,255,0.6)]">
                PLAY
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. DOCKED BOTTOM NAVIGATION BAR */}
      {/* ========================================================================= */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-slate-950/95 border-t-2 border-amber-500/40 shadow-[0_-8px_25px_rgba(0,0,0,0.8)] backdrop-blur-lg px-2 pt-1.5 pb-[max(0.375rem,env(safe-area-inset-bottom))] pointer-events-auto">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {/* HOME (Active) */}
          <button
            id="nav-home"
            className="flex flex-col items-center gap-0.5 py-1 px-3 text-amber-400 transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center shadow-[0_0_10px_rgba(245,158,11,0.4)]">
              <Home className="w-5 h-5 text-amber-400 stroke-[2.5]" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-wider font-heading">
              HOME
            </span>
          </button>

          {/* PLAYERS */}
          <button
            id="nav-players"
            onClick={() => handleAction(() => onOpenShop('characters'))}
            className="flex flex-col items-center gap-0.5 py-1 px-3 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full hover:bg-slate-800/60 flex items-center justify-center">
              <User className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider">
              PLAYERS
            </span>
          </button>

          {/* SKATEBOARD */}
          <button
            id="nav-skateboard"
            onClick={() => handleAction(() => onOpenShop('skateboards'))}
            className="flex flex-col items-center gap-0.5 py-1 px-3 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full hover:bg-slate-800/60 flex items-center justify-center">
              <span className="text-lg">🛹</span>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider">
              SKATEBOARD
            </span>
          </button>

          {/* STORE */}
          <button
            id="nav-store"
            onClick={() => handleAction(() => onOpenShop('characters'))}
            className="flex flex-col items-center gap-0.5 py-1 px-3 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full hover:bg-slate-800/60 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider">
              STORE
            </span>
          </button>

          {/* SETTINGS */}
          <button
            id="nav-settings"
            onClick={() => handleAction(onOpenSettings)}
            className="flex flex-col items-center gap-0.5 py-1 px-3 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full hover:bg-slate-800/60 flex items-center justify-center">
              <Sliders className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider">
              SETTINGS
            </span>
          </button>
        </div>
      </nav>
    </div>
  );
};
