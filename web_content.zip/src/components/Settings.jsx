import { useState, useEffect } from 'react'
import {
  getSettings,
  setShopInfo,
  setAdminPin,
  clearAdminPin,
  hasAdminPin,
  backupData,
  restoreData,
} from '../db/database'

export default function Settings() {
  const [form, setForm] = useState({ shopName: '', shopPhone: '', shopAddress: '' })
  const [saved, setSaved] = useState(false)
  const [pinEnabled, setPinEnabled] = useState(false)
  const [pin, setPin] = useState('')
  const [pinMsg, setPinMsg] = useState('')
  const [restoreMsg, setRestoreMsg] = useState('')

  useEffect(() => {
    getSettings().then((s) =>
      setForm({
        shopName: s.shopName || '',
        shopPhone: s.shopPhone || '',
        shopAddress: s.shopAddress || '',
      }),
    )
    hasAdminPin().then(setPinEnabled)
  }, [])

  async function save() {
    await setShopInfo(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  async function savePin() {
    setPinMsg('')
    try {
      await setAdminPin(pin)
      setPin('')
      setPinEnabled(true)
      setPinMsg('PIN set ho gaya ✓')
    } catch (e) {
      setPinMsg(e.message)
    }
  }

  async function removePin() {
    if (!window.confirm('Admin PIN hata dein? Tab ADMIN bina PIN khulega.')) return
    await clearAdminPin()
    setPin('')
    setPinEnabled(false)
    setPinMsg('PIN hata diya ✓')
  }

  async function backup() {
    const json = await backupData()
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `kirana-backup-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  async function restore(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()

    let preview = null
    try {
      preview = JSON.parse(text)
    } catch {
      setRestoreMsg('Backup file galat hai — ye kirana-pos ka backup nahi lagta.')
      return
    }
    const counts = ['products', 'customers', 'bills', 'ledger'].map((k) => ({
      k,
      n: (preview[k] || []).length,
    }))
    const total = counts.reduce((s, c) => s + c.n, 0)
    if (
      !window.confirm(
        `Is backup me: ${counts.map((c) => `${c.n} ${c.k}`).join(', ')} (kul ${total}).\nPurana data delete hoke isse replace hoga. Continue?`,
      )
    )
      return

    try {
      await restoreData(text)
      window.alert('Data restore ho gaya. App reload karo.')
      window.location.reload()
    } catch (err) {
      setRestoreMsg(err.message || 'Restore nahi hua — file check karo.')
    }
  }

  return (
    <div>
      <h3>Shop Info</h3>
      {(['shopName', 'shopPhone', 'shopAddress']).map((key) => (
        <label className="field" key={key}>
          <span className="field-label">
            {key === 'shopName' ? 'Dukaan ka naam' : key === 'shopPhone' ? 'Phone' : 'Address'}
          </span>
          <input
            className="input"
            value={form[key]}
            onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          />
        </label>
      ))}
      <button className="btn btn-primary btn-big" onClick={save}>
        Save
      </button>
      {saved && <p className="green">Saved ✓</p>}

      <hr />
      <h3>Admin PIN {pinEnabled && <span className="green">(set hai)</span>}</h3>
      <p className="small muted">
        PIN lagao to ADMIN tab sirf PIN se khulega. 4-6 digit. Yaad rakhna — bhul gaye to
        khud ko bahar paoge (data safe hai).
      </p>
      <div className="row">
        <input
          className="input grow pin-input"
          type="password"
          inputMode="numeric"
          maxLength={6}
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
          placeholder="Naya PIN"
        />
        <button className="btn btn-primary" onClick={savePin}>
          {pinEnabled ? 'Badlo' : 'Set karo'}
        </button>
        {pinEnabled && (
          <button className="btn btn-ghost" onClick={removePin}>
            Hatado
          </button>
        )}
      </div>
      {pinMsg && <p className="small green">{pinMsg}</p>}

      <hr />
      <h3>Backup & Restore</h3>
      <button className="btn btn-primary btn-big" onClick={() => backup()}>
        ↓ Backup (JSON file download)
      </button>
      <label className="btn btn-ghost btn-big block">
        ↑ Restore from backup
        <input
          type="file"
          accept="application/json"
          style={{ display: 'none' }}
          onChange={restore}
        />
      </label>
      {restoreMsg && <p className="error">{restoreMsg}</p>}
    </div>
  )
}