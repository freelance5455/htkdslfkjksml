import { useState } from "react";
import {
  Bell,
  Eye,
  Layers,
  Power,
  Shield,
  Smartphone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ShieldMark } from "@/components/shield-mark";
import {
  PERMISSION_COPY,
  useShield,
  type PermissionId,
} from "@/lib/store";

const ICONS: Record<PermissionId, typeof Shield> = {
  vpn: Shield,
  notifications: Bell,
  background: Eye,
  boot: Power,
  apps: Smartphone,
  overlay: Layers,
};

const STEPS = ["intro", "permissions", "ready"] as const;

export function Onboarding() {
  const [step, setStep] = useState<(typeof STEPS)[number]>("intro");
  const grant = useShield((s) => s.grantPermission);
  const permissions = useShield((s) => s.permissions);
  const setOnboarded = useShield((s) => s.setOnboarded);
  const setProtection = useShield((s) => s.setProtection);

  async function ask(id: PermissionId) {
    if (id === "notifications" && "Notification" in window) {
      const res = await Notification.requestPermission();
      grant(id, res === "granted");
      return;
    }
    grant(id, true);
  }

  const requiredOk =
    permissions.vpn.granted &&
    permissions.notifications.asked &&
    permissions.background.granted;

  return (
    <main className="mx-auto flex min-h-dvh max-w-lg flex-col px-5 pb-10 pt-8">
      <div className="mb-8 flex items-center gap-2 text-muted">
        <ShieldMark className="size-6" />
        <span className="text-sm font-medium tracking-wide">Netzschild</span>
      </div>

      {step === "intro" ? (
        <section className="flex flex-1 flex-col">
          <ShieldMark pulse className="mb-8 size-20" />
          <h1 className="font-sans text-3xl font-medium leading-tight tracking-tight text-fg">
            Schutz, der nachfragt
          </h1>
          <p className="mt-4 max-w-prose text-base leading-relaxed text-muted">
            Netzschild läuft im Hintergrund, sieht den Netzwerkverkehr des
            Handys und hält an, bevor unsichere oder gefälschte Websites Daten
            empfangen. Der Inhalt verschlüsselter Seiten wird nicht gelesen —
            geprüft werden Domain, Ziel und Vertrauenssignale.
          </p>
          <ul className="mt-8 space-y-3 text-sm text-fg">
            {[
              "Jeder Domain-Aufruf wird lokal geprüft",
              "Bei Zweifel erscheint eine klare Nachfrage",
              "Sperren und Vertrauen legen Sie selbst fest",
            ].map((t) => (
              <li key={t} className="flex gap-3">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
                <span>{t}</span>
              </li>
            ))}
          </ul>
          <div className="mt-auto pt-10">
            <Button className="w-full" size="lg" onClick={() => setStep("permissions")}>
              Berechtigungen prüfen
            </Button>
          </div>
        </section>
      ) : null}

      {step === "permissions" ? (
        <section className="flex flex-1 flex-col">
          <h1 className="text-2xl font-medium tracking-tight">
            Nur was nötig ist
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Jede Berechtigung wird einzeln erklärt. Nichts wird still
            eingeschaltet. Pflichtrechte zuerst, optionale danach.
          </p>
          <ul className="mt-6 space-y-3">
            {(Object.keys(PERMISSION_COPY) as PermissionId[]).map((id) => {
              const copy = PERMISSION_COPY[id];
              const state = permissions[id];
              const Icon = ICONS[id];
              return (
                <li
                  key={id}
                  className="rounded-xl border border-border bg-surface p-4"
                >
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex size-9 items-center justify-center rounded-md bg-surface-2 text-primary">
                      <Icon className="size-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{copy.title}</p>
                        <span className="text-[11px] uppercase tracking-wider text-subtle">
                          {copy.required ? "Erforderlich" : "Optional"}
                        </span>
                      </div>
                      <p className="mt-1 text-sm leading-relaxed text-muted">
                        {copy.why}
                      </p>
                      <Button
                        size="sm"
                        variant={state.granted ? "secondary" : "default"}
                        className="mt-3"
                        onClick={() => ask(id)}
                      >
                        {state.granted
                          ? "Erteilt"
                          : state.asked
                            ? "Erneut fragen"
                            : "Erlauben"}
                      </Button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep("intro")}>
              Zurück
            </Button>
            <Button
              className="flex-1"
              disabled={!requiredOk}
              onClick={() => setStep("ready")}
            >
              Weiter
            </Button>
          </div>
        </section>
      ) : null}

      {step === "ready" ? (
        <section className="flex flex-1 flex-col">
          <ShieldMark pulse className="mb-8 size-20" />
          <h1 className="text-2xl font-medium tracking-tight">
            Bereit zum Schützen
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Nach dem Start erscheint ein dauerhafter Hinweis „Netzschild
            aktiv“. Neue oder zweifelhafte Ziele werden nicht still
            durchgelassen — Sie entscheiden.
          </p>
          <div className="mt-auto pt-10 space-y-3">
            <Button
              className="w-full"
              size="lg"
              onClick={() => {
                setProtection(true);
                setOnboarded(true);
              }}
            >
              Schutz jetzt starten
            </Button>
            <Button
              className="w-full"
              variant="ghost"
              onClick={() => {
                setProtection(false);
                setOnboarded(true);
              }}
            >
              Zuerst nur ansehen
            </Button>
          </div>
        </section>
      ) : null}
    </main>
  );
}
