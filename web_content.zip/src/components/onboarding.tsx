"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { AVATAR_CHOICES } from "@/lib/palette";
import { setToken } from "@/lib/client-session";

type Mode = "create" | "join" | "demo";

export function Onboarding() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("create");
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(AVATAR_CHOICES[0]);
  const [squadName, setSquadName] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(payloadMode: Mode) {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: payloadMode,
          name: name.trim() || (payloadMode === "demo" ? "Nuovo Eroe" : ""),
          avatar,
          squadName,
          code,
        }),
      });
      const data = (await response.json()) as { error?: string; token?: string };
      if (!response.ok) throw new Error(data.error ?? "Qualcosa è andato storto");
      // Salvo il token nel browser: la sessione funziona anche se i cookie
      // sono bloccati (es. anteprima dentro un iframe).
      setToken(data.token);
      router.push("/squad");
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Errore inatteso");
      setLoading(false);
    }
  }

  return (
    <div className="comic-panel relative overflow-hidden rounded-3xl p-5 sm:p-6">
      <div className="stripes absolute inset-x-0 top-0 h-1.5 opacity-80" />
      <div className="flex gap-1.5 rounded-xl border border-white/10 bg-black/40 p-1">
        {(
          [
            ["create", "Crea squadra"],
            ["join", "Ho un codice"],
            ["demo", "Prova demo"],
          ] as Array<[Mode, string]>
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => {
              setMode(key);
              setError(null);
            }}
            className={`flex-1 cursor-pointer rounded-lg px-2 py-2 text-[11px] font-black uppercase tracking-widest transition ${
              mode === key ? "bg-mv-red text-white" : "text-white/50 hover:text-white"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="mt-4 space-y-3">
        <div>
          <label htmlFor="name" className="text-[10px] font-bold uppercase tracking-widest text-white/45">
            Il tuo nome da eroe
          </label>
          <input
            id="name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={24}
            placeholder="Es. Tony"
            className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white placeholder:text-white/25 focus:border-mv-red/60 focus:outline-none"
          />
        </div>

        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/45">Scegli il tuo avatar</p>
          <div className="mt-1.5 grid grid-cols-8 gap-1.5">
            {AVATAR_CHOICES.map((choice) => (
              <button
                key={choice}
                type="button"
                onClick={() => setAvatar(choice)}
                className={`grid aspect-square cursor-pointer place-items-center rounded-lg border text-base transition ${
                  avatar === choice
                    ? "border-mv-red bg-mv-red/20 scale-105"
                    : "border-white/10 bg-white/[0.03] hover:border-white/30"
                }`}
              >
                {choice}
              </button>
            ))}
          </div>
        </div>

        {mode === "create" ? (
          <div>
            <label htmlFor="squad" className="text-[10px] font-bold uppercase tracking-widest text-white/45">
              Nome della squadra
            </label>
            <input
              id="squad"
              value={squadName}
              onChange={(event) => setSquadName(event.target.value)}
              maxLength={32}
              placeholder="Es. Vendicatori del Nord"
              className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white placeholder:text-white/25 focus:border-mv-red/60 focus:outline-none"
            />
            <p className="mt-1 text-[11px] text-white/35">
              Genereremo un codice per invitare i tuoi amici.
            </p>
          </div>
        ) : null}

        {mode === "join" ? (
          <div>
            <label htmlFor="code" className="text-[10px] font-bold uppercase tracking-widest text-white/45">
              Codice squadra
            </label>
            <input
              id="code"
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              maxLength={12}
              placeholder="ES. ASSEMBLE"
              className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 font-mono text-sm tracking-[0.2em] text-mv-gold placeholder:text-white/20 focus:border-mv-gold/60 focus:outline-none"
            />
          </div>
        ) : null}

        {mode === "demo" ? (
          <p className="rounded-xl border border-mv-gold/25 bg-mv-gold/5 p-3 text-[11px] leading-relaxed text-white/60">
            Entra nella <span className="font-bold text-mv-gold">Squadra Vendicatori</span> (codice{" "}
            <span className="font-mono text-mv-gold">ASSEMBLE</span>) con Giulia, Marco e Leo già dentro. Perfetto per
            vedere subito come funziona.
          </p>
        ) : null}

        {error ? (
          <p className="rounded-xl border border-mv-red/40 bg-mv-red/10 px-3 py-2 text-xs font-semibold text-mv-red">
            {error}
          </p>
        ) : null}

        <button
          type="button"
          disabled={loading || (mode !== "demo" && name.trim().length < 2)}
          onClick={() => submit(mode)}
          className="w-full cursor-pointer rounded-xl bg-mv-red px-4 py-3 text-sm font-black uppercase tracking-widest text-white shadow-[0_18px_35px_-18px_rgba(230,36,41,0.95)] transition hover:bg-mv-red-dark disabled:cursor-not-allowed disabled:opacity-40"
        >
          {loading ? "Un attimo..." : mode === "join" ? "Entra nella squadra" : mode === "demo" ? "Prova la demo" : "Crea la squadra"}
        </button>
      </div>
    </div>
  );
}
