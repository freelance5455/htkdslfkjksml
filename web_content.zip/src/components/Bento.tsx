import {
  Baby, Clapperboard, Cloud, Gamepad2, Globe2, LockKeyhole, MonitorSmartphone, Music2,
  Newspaper, ShoppingBag, Sparkles, Trophy,
} from "lucide-react";

const TILES = [
  { icon: Globe2, name: "World TV", desc: "Canales públicos y operadores verificados en Europa, América, Asia, África y Oceanía. EPG unificado, M3U / M3U8 / Xtream Codes.", tag: "600+ señales", tint: "from-sky-500/25 to-blue-700/10 text-sky-300", span: "lg:col-span-2" },
  { icon: Trophy, name: "Sports Center", desc: "LaLiga, Premier, Champions, NBA, NFL, F1, MotoGP, UFC… calendarios, tablas, fichajes y alertas. Datos ESPN en vivo.", tag: "26 deportes", tint: "from-amber-500/25 to-orange-800/10 text-amber-300", span: "lg:col-span-2" },
  { icon: Clapperboard, name: "Movies · Series", desc: "Estrenos, clásicos, anime y documentales. Fichas TMDB, subtítulos CC, 4K HDR y seguimiento por episodio.", tag: "35.000+ títulos", tint: "from-rose-500/25 to-red-800/10 text-rose-300", span: "" },
  { icon: Gamepad2, name: "Games Hub", desc: "Juegos Android optimizados: fichas, logros, guardado en la nube, mandos Bluetooth y multijugador.", tag: "2.400+ juegos", tint: "from-violet-500/25 to-purple-800/10 text-violet-300", span: "" },
  { icon: Music2, name: "Music · Radio", desc: "Álbumes, artistas, letras y ecualizador de 10 bandas. 30.000+ emisoras en vivo del directorio Radio Browser.", tag: "Stream en vivo", tint: "from-fuchsia-500/25 to-purple-800/10 text-fuchsia-300", span: "" },
  { icon: Newspaper, name: "News 24/7", desc: "Internacionales, deportivas, tecnología, cine, videojuegos y cultura. Fuentes originales con enlace a la noticia completa.", tag: "12 secciones", tint: "from-slate-400/20 to-slate-700/10 text-slate-300", span: "" },
  { icon: ShoppingBag, name: "TV LO3 Store", desc: "Tienda propia: apps, juegos, herramientas y apps Kids autorizadas. Descargas, actualizaciones, reseñas y panel de desarrolladores.", tag: "Solo apps legales", tint: "from-cyan-500/25 to-blue-800/10 text-cyan-300", span: "" },
  { icon: Sparkles, name: "TV LO3 AI", desc: "Búsqueda por voz, recomendaciones según tu historial, ayuda técnica y configuración inteligente del sistema.", tag: "Español natural", tint: "from-lilac/25 to-violetx/10 text-lilac", span: "" },
  { icon: Baby, name: "Kids con PIN", desc: "Catálogo infantil, juegos educativos, filtros por edad, PIN parental y horarios de uso. Tranquilidad para toda la casa.", tag: "Control parental", tint: "from-emerald-500/25 to-teal-800/10 text-emerald-300", span: "" },
  { icon: Cloud, name: "TV LO3 Cloud", desc: "Biblioteca, fotos, vídeos y documentos sincronizados. Copias cifradas y acceso remoto seguro a tu NAS y nube.", tag: "45 GB incluidos", tint: "from-sky-400/25 to-indigo-800/10 text-sky-300", span: "" },
  { icon: LockKeyhole, name: "Security", desc: "Cifrado E2E, 2FA, permisos granulares, protección anti-malware y gestión de sesiones en todos tus dispositivos.", tag: "Auditoría anual", tint: "from-lime-500/20 to-green-800/10 text-lime-300", span: "" },
  { icon: MonitorSmartphone, name: "Remote & Mandos", desc: "Control total con D-pad, teclado y mandos XInput. Gestión de dispositivos vinculados y reproducción en segundo plano.", tag: "Bluetooth 5.3", tint: "from-blue-500/25 to-violet-800/10 text-blue-300", span: "" },
];

export default function Bento() {
  return (
    <section id="funciones" className="relative scroll-mt-28 border-y border-white/5 bg-[#070c26]/60 py-16 sm:py-20">
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-0 h-72 w-[60rem] -translate-x-1/2 bg-[radial-gradient(ellipse_at_top,rgba(139,92,246,0.12),transparent_70%)]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="eyebrow">Un solo lugar</p>
            <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
              Toda tu vida digital<br />en <span className="grad-text">una sola app</span>.
            </h2>
          </div>
          <p className="max-w-sm text-sm text-slate-400">Dieciséis módulos integrados — desde World TV hasta Kids — orquestados con la misma capa de sistema: tu perfil, tu biblioteca, tu nube.</p>
        </div>

        <div className="mt-10 grid auto-rows-fr grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {TILES.map((t) => {
            const Icon = t.icon;
            return (
              <article key={t.name} className={`tile group flex flex-col rounded-2xl bg-gradient-to-br p-4 sm:p-5 ${t.tint} ${t.span}`}>
                <div className="flex items-center justify-between">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-black/35 backdrop-blur-sm sm:h-11 sm:w-11">
                    <Icon size={19} strokeWidth={2} className="text-white" />
                  </span>
                  <span className="rounded-full border border-white/12 bg-black/40 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-slate-200">{t.tag}</span>
                </div>
                <h3 className="mt-3 font-display text-base font-bold text-white sm:text-lg">{t.name}</h3>
                <p className="mt-1 flex-1 text-[11px] leading-snug text-slate-300 sm:text-xs">{t.desc}</p>
              </article>
            );
          })}
        </div>
        <p className="mt-4 text-center text-[11px] uppercase tracking-[0.2em] text-slate-600">Y además · Apps · Browser · Social y listas compartidas · My Library · Settings · Account · Remote</p>
      </div>
    </section>
  );
}
