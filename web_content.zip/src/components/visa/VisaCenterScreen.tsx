import { useState } from 'react';
import { ShieldCheck, FileCheck, Clock, Coins, Sparkles, CheckCircle2, ChevronRight, ChevronLeft, ArrowRight, ArrowLeft } from 'lucide-react';
import { VisaCountry, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';

interface VisaCenterScreenProps {
  countries: VisaCountry[];
  language: Language;
  currency: Currency;
  onRequestAssistance: (countryName: string) => void;
}

export function VisaCenterScreen({ countries, language, currency, onRequestAssistance }: VisaCenterScreenProps) {
  const [selectedCountry, setSelectedCountry] = useState<VisaCountry>(countries[0]);
  const [requestSent, setRequestSent] = useState(false);

  const t = translations[language];
  const isRTL = language === 'ar';

  const handleApplyAssistance = () => {
    onRequestAssistance(selectedCountry.countryName[language]);
    setRequestSent(true);
    setTimeout(() => {
      setRequestSent(false);
    }, 2500);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {t.visaCenterTitle}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {t.visaSubtitle}
        </p>
      </div>

      {/* Horizontal Country Selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {countries.map(country => (
          <button
            key={country.id}
            onClick={() => {
              setSelectedCountry(country);
              setRequestSent(false);
            }}
            className={`px-3.5 py-2 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all text-xs font-bold border ${
              selectedCountry.id === country.id
                ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <span className="text-base">{country.flagEmoji}</span>
            <span>{country.countryName[language]}</span>
          </button>
        ))}
      </div>

      {/* Selected Country Details Card */}
      <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/25 text-white space-y-5">
        {/* Country Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{selectedCountry.flagEmoji}</span>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">
                {language === 'ar' ? `تأشيرة ${selectedCountry.countryName.ar}` : `Visa for ${selectedCountry.countryName[language]}`}
              </h2>
              <p className="text-xs text-cyan-400 font-semibold mt-0.5">
                {selectedCountry.visaType}
              </p>
            </div>
          </div>

          <div className="text-left rtl:text-right">
            <span className="text-[10px] text-slate-400 block">{language === 'ar' ? 'نسبة القبول' : 'Success Rate'}</span>
            <span className="text-sm font-bold font-mono text-emerald-400">
              {selectedCountry.guaranteeRate}
            </span>
          </div>
        </div>

        {/* Processing & Fee KPI Strip */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{t.procTime}</span>
              <p className="font-bold text-white mt-0.5">{selectedCountry.processingTime}</p>
            </div>
          </div>

          <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{t.consularFees}</span>
              <p className="font-bold text-cyan-300 font-mono mt-0.5">
                {formatPrice(selectedCountry.feeDZD, currency, language)}
              </p>
            </div>
          </div>
        </div>

        {/* Required Documents */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <FileCheck className="w-4 h-4 text-cyan-400" />
            <span>{t.reqDocuments}</span>
          </h3>
          <div className="space-y-1.5 bg-[#060c20] p-4 rounded-2xl border border-slate-800/80">
            {selectedCountry.requirements.map((req, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                <span>{req}</span>
              </div>
            ))}
          </div>
        </div>

        {/* File Steps */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{language === 'ar' ? 'خطوات معالجة الملف في الوكالة' : 'Processing Workflow'}</span>
          </h3>
          <div className="grid grid-cols-1 gap-2">
            {selectedCountry.steps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300"
              >
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Button */}
        {requestSent ? (
          <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>{language === 'ar' ? 'تم استلام طلبك! سيتصل بك مستشار التأشيرات بالوكالة خلال ساعتين.' : 'Request Received! An agency advisor will contact you within 2 hours.'}</span>
          </div>
        ) : (
          <button
            onClick={handleApplyAssistance}
            className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <span>{t.applyVisaAssistance}</span>
            {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
}
