import React, { useState, useEffect } from 'react';
import { Smartphone, Maximize2, Check } from 'lucide-react';

interface LandscapeHelperProps {
  onDismiss: () => void;
}

export const LandscapeHelper: React.FC<LandscapeHelperProps> = ({ onDismiss }) => {
  const [isPortrait, setIsPortrait] = useState(false);
  const [hasDismissed, setHasDismissed] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      const portrait = window.innerHeight > window.innerWidth && window.innerWidth < 800;
      setIsPortrait(portrait);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  const handleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      }
      // Attempt screen lock if available on mobile
      const screenAny = window.screen as unknown as { orientation?: { lock?: (o: string) => Promise<void> } };
      if (screenAny?.orientation?.lock) {
        await screenAny.orientation.lock('landscape').catch(() => {});
      }
    } catch {
      // Ignore fullscreen restrictions in iframe
    }
    setHasDismissed(true);
    onDismiss();
  };

  if (!isPortrait || hasDismissed) return null;

  return (
    <div
      id="landscape-rotation-banner"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-zinc-950/95 backdrop-blur-md p-6 text-center text-zinc-100 select-none animate-in fade-in"
    >
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-2xl bg-red-600/20 border-2 border-red-500/40 flex items-center justify-center animate-pulse">
          <Smartphone className="w-10 h-10 text-red-400 rotate-90 transition-transform duration-700" />
        </div>
      </div>

      <h2 className="text-2xl font-display font-bold uppercase tracking-wider text-white mb-2">
        Gorizontal Ekran Rejimi
      </h2>
      <p className="text-sm text-zinc-400 max-w-xs mb-8">
        Qulay oʻynash, toʻliq boshqaruv paneli va grafika imkoniyatlari uchun telefoningizni
        yonbosh (gorizontal) qilib ushlang.
      </p>

      <div className="flex flex-col gap-3 w-full max-w-xs">
        <button
          id="fullscreen-landscape-btn"
          onClick={handleFullscreen}
          className="flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm uppercase tracking-wider shadow-lg shadow-red-950/60 transition active:scale-95"
        >
          <Maximize2 className="w-4 h-4" />
          Toʻliq Ekran & Boshlash
        </button>

        <button
          id="dismiss-landscape-btn"
          onClick={() => {
            setHasDismissed(true);
            onDismiss();
          }}
          className="py-2.5 px-6 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 font-semibold text-xs transition"
        >
          Shunday Davom Etish
        </button>
      </div>
    </div>
  );
};
