import React, { useEffect, useRef, useState } from 'react';
import { MessageSquare, Send, X } from 'lucide-react';
import type { GameTelemetry, PlayerProgress } from '../game/types';

interface GeminiGarageModalProps {
  open: boolean;
  telemetry: GameTelemetry;
  progress: PlayerProgress;
  onClose: () => void;
}

interface ChatTurn {
  role: 'user' | 'model';
  text: string;
}

const CHAT_MODELS = [
  { id: 'gemini-4-hydrogen', label: 'Mestre Tuning (Geral · Hydrogen)' },
  { id: 'gemini-3.1-flash-lite', label: 'Copiloto Rápido (Flash-Lite)' },
];

export const GeminiGarageModal: React.FC<GeminiGarageModalProps> = ({
  open,
  telemetry,
  progress,
  onClose,
}) => {
  const [chatModel, setChatModel] = useState<string>('gemini-4-hydrogen');
  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      role: 'model',
      text: 'Salve, piloto! Aqui é o Mestre Tuning da Garagem Moto Win. Pergunte como segurar o grau no ponto de equilíbrio, como lidar com a chuva nas vielas da favela ou qual peça equipar na sua 160!',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, chatLoading]);

  if (!open) return null;

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = chatInput.trim();
    if (!trimmed || chatLoading) return;

    const nextHistory: ChatTurn[] = [...messages, { role: 'user', text: trimmed }];
    setMessages(nextHistory);
    setChatInput('');
    setChatError(null);
    setChatLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: chatModel,
          messages: nextHistory,
          telemetry: {
            speedKmh: telemetry.speedKmh,
            zone: telemetry.zone,
            weather: telemetry.weather,
            timePhase: telemetry.timePhase,
            money: progress.money,
            xp: progress.xp,
            bikeColor: progress.customization.colorId,
            motorLevel: progress.customization.motorLevel,
          },
        }),
      });
      const data = (await res.json()) as { reply?: string; error?: string };
      if (!res.ok || !data.reply) {
        throw new Error(data.error ?? 'Falha ao responder.');
      }
      setMessages((prev) => [...prev, { role: 'model', text: data.reply! }]);
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Erro de conexão com o servidor.');
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3">
      <div className="w-full max-w-3xl h-[82vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <h2 className="font-display text-base font-bold text-white">
              Mestre Tuning · Assistente Moto Win
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            aria-label="Fechar Assistente"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-2.5 border-b border-white/10 bg-neutral-950/40">
          <span className="text-xs text-neutral-400">
            Zona: {telemetry.zone} · Clima: {telemetry.weather} · {Math.round(telemetry.speedKmh)} km/h
          </span>
          <select
            value={chatModel}
            onChange={(e) => setChatModel(e.target.value)}
            className="bg-neutral-800 border border-white/15 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            {CHAT_MODELS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-3">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[82%] rounded-xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-amber-500 text-neutral-950 font-medium'
                    : 'bg-neutral-800 text-neutral-100 border border-white/10'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          {chatLoading && (
            <div className="flex justify-start">
              <div className="rounded-xl px-4 py-2.5 text-xs bg-neutral-800 text-neutral-400 border border-white/10">
                Analisando telemetria da 160...
              </div>
            </div>
          )}
          {chatError && (
            <div className="rounded-xl px-4 py-2.5 text-xs bg-rose-950/70 border border-rose-500/40 text-rose-200">
              {chatError}
            </div>
          )}
        </div>

        <form onSubmit={sendMessage} className="p-3.5 border-t border-white/10 flex gap-2 bg-neutral-950/50">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Pergunte sobre grau, física na chuva, rotas ou upgrades da 160..."
            className="flex-1 bg-neutral-800 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            disabled={chatLoading || !chatInput.trim()}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-neutral-950 disabled:opacity-45 transition-colors cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            Enviar
          </button>
        </form>
      </div>
    </div>
  );
};
