// JUHNKRIX MUSIKA - App Update Notifier & Decentralized Auto-Version Engine
// Informs users directly of new version updates released by Prophet JUHNKRIX SYNVAGORD
// and enables direct in-app download and installation from JUHNKRIX MUSIKA DECENTRALIZED NETWORK.

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, Sparkles, X, RefreshCw, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { appReleaseService, AppReleaseItem } from '../lib/appReleaseService';
import { appDownloadEarningsEngine } from '../lib/appDownloadEarningsEngine';
import { appCompilerService } from '../lib/appCompiler';

interface AppUpdateNotifierProps {
  onOpenGetAppModal?: () => void;
}

export const AppUpdateNotifier: React.FC<AppUpdateNotifierProps> = ({ onOpenGetAppModal }) => {
  const [activeUpdate, setActiveUpdate] = useState<AppReleaseItem | null>(null);
  const [dismissed, setDismissed] = useState<boolean>(false);
  const [earningToast, setEarningToast] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    // Check local update status from decentralized engine
    const checkUpdates = () => {
      const check = appReleaseService.checkForUpdates();
      if (check.updateAvailable && check.latestRelease) {
        setActiveUpdate(check.latestRelease);
      }
    };

    checkUpdates();
    const interval = setInterval(checkUpdates, 15000); // Check every 15s

    // Listen for live broadcast updates pushed by Prophet JUHNKRIX
    const handlePushEvent = (e: any) => {
      if (e.detail?.release) {
        setActiveUpdate(e.detail.release);
        setDismissed(false);
      }
    };

    const handleUpdateEvent = (e: any) => {
      if (e.detail) {
        const releases = appReleaseService.getPublishedReleases();
        const plat = (e.detail.platform || 'android') as keyof typeof releases;
        setActiveUpdate(releases[plat] || releases.android);
        setDismissed(false);
      }
    };

    // Listen for download monetization events
    const handleEarningEvent = (e: any) => {
      const rec = e.detail;
      if (rec) {
        setEarningToast(`💰 Real Money Credited: +₦${rec.fiatAmountNgn.toLocaleString()} NGN (${rec.cryptoAmountJmc} JMC) to Owner JM-WALLET & OPay Account!`);
        setTimeout(() => setEarningToast(null), 5000);
      }
    };

    window.addEventListener('juhnkrix_auto_app_update_pushed', handlePushEvent);
    window.addEventListener('juhnkrix_app_update_available', handleUpdateEvent);
    window.addEventListener('juhnkrix_download_earning_credited', handleEarningEvent);

    return () => {
      clearInterval(interval);
      window.removeEventListener('juhnkrix_auto_app_update_pushed', handlePushEvent);
      window.removeEventListener('juhnkrix_app_update_available', handleUpdateEvent);
      window.removeEventListener('juhnkrix_download_earning_credited', handleEarningEvent);
    };
  }, []);

  const handleDownloadAndInstallUpdate = async () => {
    if (!activeUpdate) return;
    setIsDownloading(true);

    try {
      // Record download & monetization inside app
      appDownloadEarningsEngine.recordDownloadOrUpdate(activeUpdate.platform || 'android', 'UPDATE');

      // Compile/fetch package directly from built-in decentralized storage
      const result = await appCompilerService.compilePlatformPackage(activeUpdate.platform || 'android', () => {});

      // Trigger direct download without leaving the app
      const a = document.createElement('a');
      a.href = result.downloadUrl;
      a.download = activeUpdate.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      appReleaseService.setInstalledVersion(activeUpdate.version);

      setDownloadSuccessToast(`🎉 ${activeUpdate.fileName} successfully downloaded & updated from JUHNKRIX MUSIKA DECENTRALIZED NETWORK!`);
      setTimeout(() => setDownloadSuccessToast(null), 6000);
      setDismissed(true);
    } catch {
      // Direct user to built-in Get App page as fallback
      if (onOpenGetAppModal) {
        onOpenGetAppModal();
      }
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <>
      {/* Real-time Earnings Toast */}
      <AnimatePresence>
        {earningToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-16 right-4 z-[250] bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white font-extrabold px-5 py-3.5 rounded-2xl shadow-2xl border-2 border-emerald-300 text-xs sm:text-sm flex items-center space-x-2.5 max-w-md"
          >
            <Sparkles className="w-5 h-5 text-yellow-300 animate-spin-slow shrink-0" />
            <span>{earningToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Direct Download Success Toast */}
      <AnimatePresence>
        {downloadSuccessToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-[250] bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 text-emerald-200 font-bold px-6 py-4 rounded-2xl shadow-2xl border-2 border-emerald-400 text-xs sm:text-sm flex items-center space-x-3 max-w-lg"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{downloadSuccessToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sticky In-App Direct Update Banner */}
      <AnimatePresence>
        {activeUpdate && !dismissed && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            className="fixed bottom-24 left-4 right-4 sm:left-auto sm:right-6 sm:w-[420px] z-[200] bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/90 border-2 border-amber-400 rounded-3xl p-5 shadow-2xl shadow-amber-500/30 text-left space-y-3.5 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
                  <RefreshCw className="w-5 h-5 animate-spin-slow text-slate-950" />
                </div>
                <div>
                  <h4 className="text-xs font-black font-serif text-amber-200 tracking-wide uppercase">
                    PROPHET JUHNKRIX SYNVAGORD
                  </h4>
                  <span className="text-[10px] font-mono text-emerald-400 font-bold block">
                    JUHNKRIX MUSIKA v{activeUpdate.version} Available
                  </span>
                </div>
              </div>

              <button
                onClick={() => setDismissed(true)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Exact Prophet Message */}
            <p className="text-xs text-amber-100 font-medium leading-relaxed bg-amber-500/10 p-3 rounded-2xl border border-amber-500/20">
              &ldquo;PROPHET JUHNKRIX SYNVAGORD THE OWNER OF THE JUHNKRIX MUSIKA APP HAVE RELEASED A UPDATE OF NEW VERSION, PLEASE CLICK ON THE UPDATE BUTTON TO GET THE NEW VERSION DOWNLOADED AND INSTALL TO YOUR DEVICE.&rdquo;
            </p>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-1">
              <span>Package: <strong className="text-white">{activeUpdate.fileName}</strong></span>
              <span className="text-emerald-400 font-bold">{activeUpdate.fileSizeFormatted}</span>
            </div>

            <div className="text-[10px] font-mono text-cyan-300 flex items-center space-x-1.5 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Source: <strong>JUHNKRIX MUSIKA DECENTRALIZED NETWORK</strong></span>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <button
                onClick={handleDownloadAndInstallUpdate}
                disabled={isDownloading}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/30 transition-transform hover:scale-102 cursor-pointer disabled:opacity-50"
              >
                {isDownloading ? (
                  <>
                    <RefreshCw className="w-4 h-4 text-slate-950 animate-spin" />
                    <span>DOWNLOADING UPDATE...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 text-slate-950" />
                    <span>UPDATE NOW ({activeUpdate.fileSizeFormatted})</span>
                  </>
                )}
              </button>

              {onOpenGetAppModal && (
                <button
                  onClick={() => {
                    setDismissed(true);
                    onOpenGetAppModal();
                  }}
                  className="px-3.5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 text-xs font-bold"
                >
                  Get App Page
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
