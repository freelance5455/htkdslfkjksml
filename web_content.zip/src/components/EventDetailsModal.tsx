import React, { useState } from 'react';
import { EventItem } from '../types';
import { useApp } from '../context/AppContext';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  ShieldCheck,
  Users,
  Ticket,
  ExternalLink,
  Heart,
  Share2,
  Sparkles,
  Info,
  Car,
  Shirt,
  AlertCircle,
  RotateCcw,
  Mail,
} from 'lucide-react';

interface EventDetailsModalProps {
  event: EventItem | null;
  onClose: () => void;
  onBookNow: (event: EventItem) => void;
}

export const EventDetailsModal: React.FC<EventDetailsModalProps> = ({
  event,
  onClose,
  onBookNow,
}) => {
  const { isFavorite, toggleFavorite, formatKsh, showToast } = useApp();

  if (!event) return null;

  const isFav = isFavorite(event.id);
  const personalPrice = event.personalPrice || event.price;

  const handleShare = () => {
    const url = `${window.location.origin}${window.location.pathname}#event=${event.id}`;
    navigator.clipboard.writeText(url);
    showToast('Event link copied to clipboard!');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl my-auto bg-[#111317] rounded-[32px] shadow-2xl border border-[#1f2229] overflow-hidden text-[#f4f4f6]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Dismiss Button Bar */}
        <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
          <button
            onClick={() => toggleFavorite(event.id)}
            className={`w-9 h-9 rounded-full backdrop-blur-md flex items-center justify-center transition-all cursor-pointer ${
              isFav
                ? 'bg-red-500 text-white'
                : 'bg-black/60 text-white hover:bg-black/80 border border-white/10'
            }`}
            title="Save to favorites"
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={handleShare}
            className="w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md flex items-center justify-center transition-colors cursor-pointer border border-white/10"
            title="Share experience link"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md flex items-center justify-center transition-colors cursor-pointer border border-white/10"
            title="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Hero Cover Banner */}
        <div className="relative h-64 sm:h-72 w-full bg-[#090a0d] overflow-hidden">
          <img
            src={event.image}
            alt={event.title}
            className="w-full h-full object-cover opacity-85 transition-transform duration-700 hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111317] via-[#111317]/50 to-transparent" />

          {/* Category Pill */}
          <div className="absolute top-4 left-4 z-10 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#111317]/90 backdrop-blur-md text-[11px] font-bold uppercase tracking-wider text-emerald-400 border border-[#1f2229]">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>{event.categoryLabel || event.category}</span>
          </div>

          {/* Title & Organizer Overlay */}
          <div className="absolute bottom-4 left-6 right-6 text-white space-y-1">
            <h2 className="text-xl sm:text-2xl font-black tracking-tight leading-tight">
              {event.title}
            </h2>
            <p className="text-xs text-[#9496a1] font-medium flex items-center gap-2">
              <span>Presented by {event.organizer || event.hostName}</span>
              <span>·</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified Host
              </span>
            </p>
          </div>
        </div>

        {/* Event Body Content */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Key Logistics Matrix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-[#17191f] p-4 rounded-2xl border border-[#1f2229]">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/20">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-[#646875] block">
                  Date & Showtime
                </span>
                <span className="font-semibold text-[#f4f4f6]">
                  {event.date}
                </span>
                <span className="text-[11px] text-[#9496a1] block mt-0.5">
                  Doors: {event.doorTime} · Showtime: {event.time}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/20">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[10px] uppercase font-bold text-[#646875] block">
                  Venue Location
                </span>
                <span className="font-semibold text-[#f4f4f6] block truncate">
                  {event.venue}
                </span>
                <span className="text-[11px] text-[#9496a1] block truncate mt-0.5">
                  {event.address} · {event.city}, Kenya
                </span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6]">
              About This Experience
            </h3>
            <p className="text-xs sm:text-sm text-[#9496a1] leading-relaxed whitespace-pre-line font-normal">
              {event.description}
            </p>
          </div>

          {/* Additional Event Specifications & Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-xl bg-[#17191f] border border-[#1f2229] text-center">
              <span className="text-[10px] font-bold text-[#646875] uppercase block">Age Limit</span>
              <span className="text-xs font-bold text-[#f4f4f6] mt-0.5 block">
                {event.ageRestriction || 'All Ages'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#17191f] border border-[#1f2229] text-center">
              <span className="text-[10px] font-bold text-[#646875] uppercase block">Dress Code</span>
              <span className="text-xs font-bold text-[#f4f4f6] mt-0.5 block truncate">
                {event.dressCode || 'Smart Casual'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#17191f] border border-[#1f2229] text-center">
              <span className="text-[10px] font-bold text-[#646875] uppercase block">Refunds</span>
              <span className="text-xs font-bold text-emerald-400 mt-0.5 block">
                {event.refundPolicy || 'Automated'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#17191f] border border-[#1f2229] text-center">
              <span className="text-[10px] font-bold text-[#646875] uppercase block">Turnstiles</span>
              <span className="text-xs font-bold text-blue-400 mt-0.5 block">
                QR Verified
              </span>
            </div>
          </div>

          {/* Highlights & Perks */}
          {event.highlights && event.highlights.length > 0 && (
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Experience Highlights</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {event.highlights.map((h, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl bg-[#17191f] border border-[#1f2229] text-xs text-[#9496a1] flex items-center gap-2"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    <span className="font-medium text-[#f4f4f6]">{h}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Custom Ticket Tiers Overview */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6]">
                Available Ticket Packages (KES)
              </h3>
              <span className="text-[11px] text-[#646875]">Turnstile digital pass</span>
            </div>

            <div className="space-y-2">
              {/* Individual Pass */}
              <div className="p-3.5 rounded-2xl bg-[#17191f] border border-[#1f2229] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#111317] border border-[#1f2229] text-[#f4f4f6] flex items-center justify-center font-bold text-xs">
                    1x
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#f4f4f6]">
                      Individual Admission Pass
                    </h4>
                    <span className="text-[11px] text-[#9496a1]">
                      Standard admission for 1 guest
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-extrabold text-[#f4f4f6] block">
                    {formatKsh(personalPrice)}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-semibold">
                    Instant Pass
                  </span>
                </div>
              </div>

              {/* Custom Group Tiers */}
              {event.groupTiers &&
                event.groupTiers.map((tier) => (
                  <div
                    key={tier.id}
                    className="p-3.5 rounded-2xl bg-[#17191f] border border-[#1f2229] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-bold text-xs">
                        {tier.size}x
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-[#f4f4f6]">
                          {tier.name}
                        </h4>
                        <span className="text-[11px] text-[#9496a1] block">
                          {tier.perks || `Bundle package for ${tier.size} guests`}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-extrabold text-[#f4f4f6] block">
                        {formatKsh(tier.price)}
                      </span>
                      <span className="text-[10px] text-[#646875]">
                        Bundle for {tier.size}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Organizer & Official Social Channels */}
          <div className="space-y-3 pt-2 border-t border-[#1f2229]">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6]">
                Host Official Socials & Direct Contact
              </h3>
              <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified Channel
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Instagram */}
              {(() => {
                const instaHandle = event.instagram || `@${(event.organizer || event.hostName || 'eventra').toLowerCase().replace(/[^a-z0-9]/g, '')}.live`;
                const cleanInsta = instaHandle.replace(/^@/, '');
                return (
                  <a
                    href={`https://instagram.com/${cleanInsta}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-[#17191f] border border-[#232733] hover:border-pink-500/40 hover:bg-[#1c1f27] transition-all flex items-center gap-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center shrink-0 shadow-sm">
                      <svg className="w-5 h-5 text-white fill-current" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.13-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                      </svg>
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] uppercase font-bold text-[#646875] block">Instagram</span>
                      <span className="text-xs font-semibold text-white truncate block group-hover:text-pink-400 transition-colors">
                        @{cleanInsta}
                      </span>
                    </div>
                  </a>
                );
              })()}

              {/* TikTok */}
              {(() => {
                const tiktokHandle = event.tiktok || `@${(event.organizer || event.hostName || 'eventra').toLowerCase().replace(/[^a-z0-9]/g, '')}`;
                const cleanTiktok = tiktokHandle.replace(/^@/, '');
                return (
                  <a
                    href={`https://tiktok.com/@${cleanTiktok}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-[#17191f] border border-[#232733] hover:border-cyan-500/40 hover:bg-[#1c1f27] transition-all flex items-center gap-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-black border border-white/10 flex items-center justify-center shrink-0 shadow-sm relative overflow-hidden">
                      <svg className="w-5 h-5 text-white fill-current" viewBox="0 0 24 24">
                        <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                      </svg>
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] uppercase font-bold text-[#646875] block">TikTok</span>
                      <span className="text-xs font-semibold text-white truncate block group-hover:text-cyan-400 transition-colors">
                        @{cleanTiktok}
                      </span>
                    </div>
                  </a>
                );
              })()}

              {/* Gmail / Email */}
              {(() => {
                const targetEmail = event.gmail || event.hostEmail || `${(event.organizer || event.hostName || 'host').toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`;
                return (
                  <a
                    href={`mailto:${targetEmail}?subject=Inquiry regarding ${encodeURIComponent(event.title)}`}
                    className="p-3 rounded-2xl bg-[#17191f] border border-[#232733] hover:border-red-500/40 hover:bg-[#1c1f27] transition-all flex items-center gap-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#111317] border border-[#232733] flex items-center justify-center shrink-0 shadow-sm">
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="#EA4335" d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.272H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"/>
                      </svg>
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] uppercase font-bold text-[#646875] block">Gmail / Host</span>
                      <span className="text-xs font-semibold text-white truncate block group-hover:text-red-400 transition-colors">
                        {targetEmail}
                      </span>
                    </div>
                  </a>
                );
              })()}
            </div>
          </div>
        </div>

        {/* Sticky Bottom Actions Bar */}
        <div className="p-4 sm:p-6 bg-[#111317] border-t border-[#1f2229] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#646875] block">
              Admission Price
            </span>
            <span className="text-xl font-black text-[#f4f4f6]">
              {formatKsh(personalPrice)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#16181f] border border-[#232733] text-[11px] text-[#9496a1]">
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>Instant Email Pass Voucher Included</span>
            </div>

            <button
              onClick={() => {
                onClose();
                onBookNow(event);
              }}
              className="flex-1 sm:flex-none py-3 px-6 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs sm:text-sm font-bold active:scale-95 transition-all cursor-pointer shadow-md flex items-center justify-center gap-2"
            >
              <Ticket className="w-4 h-4" />
              <span>Book Pass</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
