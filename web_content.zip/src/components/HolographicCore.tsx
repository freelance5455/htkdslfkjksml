/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { VoiceModeState } from '../types/assistant';
import { voiceService } from '../services/voiceService';

interface HolographicCoreProps {
  voiceState: VoiceModeState;
  reducedMotion?: boolean;
}

// Module-level pre-allocated scratch objects to ensure zero GC in animation loop
const _vec3 = new THREE.Vector3();

export const HolographicCore: React.FC<HolographicCoreProps> = ({
  voiceState,
  reducedMotion = false,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const voiceStateRef = useRef(voiceState);
  const reducedMotionRef = useRef(reducedMotion);

  voiceStateRef.current = voiceState;
  reducedMotionRef.current = reducedMotion;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2('#02040a', 0.12);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0.15, 4.8);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    container.appendChild(renderer.domElement);

    // 2. Master Core Group with Parallax Support
    const masterGroup = new THREE.Group();
    masterGroup.position.set(0, 0.35, 0);
    scene.add(masterGroup);

    // Parallax tracking variables
    let pointerX = 0;
    let pointerY = 0;
    let targetTiltX = 0;
    let targetTiltY = 0;

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;
      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('clientX' in e) {
        clientX = (e as MouseEvent).clientX;
        clientY = (e as MouseEvent).clientY;
      }
      pointerX = (clientX / window.innerWidth) * 2 - 1;
      pointerY = -(clientY / window.innerHeight) * 2 + 1;
      targetTiltX = pointerY * 0.14;
      targetTiltY = pointerX * 0.18;
    };

    window.addEventListener('mousemove', onPointerMove, { passive: true });
    window.addEventListener('touchmove', onPointerMove, { passive: true });

    // 3. Central Luminous Star / Singularity Core
    const centerCoreGeo = new THREE.SphereGeometry(0.18, 32, 32);
    const centerCoreMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const centerCore = new THREE.Mesh(centerCoreGeo, centerCoreMat);
    masterGroup.add(centerCore);

    // Center Core Halo Bloom Mesh
    const haloGeo = new THREE.SphereGeometry(0.34, 24, 24);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.6,
      wireframe: false,
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    masterGroup.add(haloMesh);

    // Optical Star Flare Cross Lines (Horizontal & Vertical)
    const flareMat = new THREE.LineBasicMaterial({
      color: 0xe0f2fe,
      transparent: true,
      opacity: 0.85,
    });
    const hFlareGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-0.95, 0, 0),
      new THREE.Vector3(0.95, 0, 0),
    ]);
    const hFlare = new THREE.Line(hFlareGeo, flareMat);
    masterGroup.add(hFlare);

    const vFlareGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, -0.95, 0),
      new THREE.Vector3(0, 0.95, 0),
    ]);
    const vFlare = new THREE.Line(vFlareGeo, flareMat);
    masterGroup.add(vFlare);

    // 4. Concentric Cyan Radar / Holographic Rings
    const ringsGroup = new THREE.Group();
    masterGroup.add(ringsGroup);

    const createConcentricRing = (radius: number, dashed: boolean = false, opacity: number = 0.5) => {
      const segments = 128;
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * radius, Math.sin(theta) * radius, 0));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const mat = new THREE.LineBasicMaterial({
        color: 0x06b6d4,
        transparent: true,
        opacity,
      });
      return new THREE.Line(geo, mat);
    };

    const ringRadii = [0.45, 0.75, 1.05, 1.25, 1.5];
    const rings = ringRadii.map((r, i) => {
      const ring = createConcentricRing(r, i % 2 === 1, 0.35 + i * 0.1);
      ringsGroup.add(ring);
      return ring;
    });

    // Radial Tick Marks on Rings
    const ticksGroup = new THREE.Group();
    masterGroup.add(ticksGroup);
    const tickMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.65,
    });

    for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
      const innerR = 1.0;
      const outerR = angle % (Math.PI / 2) === 0 ? 1.32 : 1.14;
      const p1 = new THREE.Vector3(Math.cos(angle) * innerR, Math.sin(angle) * innerR, 0);
      const p2 = new THREE.Vector3(Math.cos(angle) * outerR, Math.sin(angle) * outerR, 0);
      const tickGeo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
      ticksGroup.add(new THREE.Line(tickGeo, tickMat));
    }

    // 5. Acoustic Shockwave Ripple Rings (emit radially when ELYSIA speaks)
    const shockwaveRingsCount = 3;
    const shockwaveGeos: THREE.BufferGeometry[] = [];
    const shockwaveMats: THREE.LineBasicMaterial[] = [];
    const shockwaveMeshes: THREE.Line[] = [];
    const shockwavePhases = [0.0, 0.33, 0.66];

    for (let s = 0; s < shockwaveRingsCount; s++) {
      const segments = 96;
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta), Math.sin(theta), 0));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const mat = new THREE.LineBasicMaterial({
        color: 0x67e8f9,
        transparent: true,
        opacity: 0.0,
      });
      const mesh = new THREE.Line(geo, mat);
      masterGroup.add(mesh);
      shockwaveGeos.push(geo);
      shockwaveMats.push(mat);
      shockwaveMeshes.push(mesh);
    }

    // 6. Enhanced Multi-Layered Fluid 3D Wave Ribbon System
    // Layer A: Hero Undulating Harmonic Wave Ribbon (Cyan & Violet Gradient)
    const wavePointCountA = 3200;
    const waveGeoA = new THREE.BufferGeometry();
    const positionsA = new Float32Array(wavePointCountA * 3);
    const colorsA = new Float32Array(wavePointCountA * 3);

    const cyanColor = new THREE.Color(0x06b6d4);
    const azureColor = new THREE.Color(0x38bdf8);
    const purpleColor = new THREE.Color(0xa855f7);
    const magentaColor = new THREE.Color(0xd946ef);

    for (let i = 0; i < wavePointCountA; i++) {
      const u = (i / wavePointCountA) * Math.PI * 2;
      const layer = Math.floor(i / 800);
      const baseR = 1.15 + layer * 0.09;

      positionsA[i * 3] = Math.cos(u) * baseR;
      positionsA[i * 3 + 1] = Math.sin(u) * baseR;
      positionsA[i * 3 + 2] = 0;

      const mixRatio = (Math.sin(u * 2) + 1) * 0.5;
      const ptColor = cyanColor.clone().lerp(purpleColor, mixRatio);
      colorsA[i * 3] = ptColor.r;
      colorsA[i * 3 + 1] = ptColor.g;
      colorsA[i * 3 + 2] = ptColor.b;
    }

    waveGeoA.setAttribute('position', new THREE.BufferAttribute(positionsA, 3));
    waveGeoA.setAttribute('color', new THREE.BufferAttribute(colorsA, 3));

    const waveMatA = new THREE.PointsMaterial({
      size: 0.026,
      vertexColors: true,
      transparent: true,
      opacity: 0.88,
    });
    const waveMeshA = new THREE.Points(waveGeoA, waveMatA);
    masterGroup.add(waveMeshA);

    // Layer B: Outer Expansive Acoustic Aura Wave (Violet-Magenta)
    const wavePointCountB = 1800;
    const waveGeoB = new THREE.BufferGeometry();
    const positionsB = new Float32Array(wavePointCountB * 3);
    const colorsB = new Float32Array(wavePointCountB * 3);

    for (let i = 0; i < wavePointCountB; i++) {
      const u = (i / wavePointCountB) * Math.PI * 2;
      const layer = Math.floor(i / 600);
      const baseR = 1.48 + layer * 0.08;

      positionsB[i * 3] = Math.cos(u) * baseR;
      positionsB[i * 3 + 1] = Math.sin(u) * baseR;
      positionsB[i * 3 + 2] = 0;

      const mix = (Math.cos(u * 3) + 1) * 0.5;
      const ptColor = purpleColor.clone().lerp(magentaColor, mix);
      colorsB[i * 3] = ptColor.r;
      colorsB[i * 3 + 1] = ptColor.g;
      colorsB[i * 3 + 2] = ptColor.b;
    }

    waveGeoB.setAttribute('position', new THREE.BufferAttribute(positionsB, 3));
    waveGeoB.setAttribute('color', new THREE.BufferAttribute(colorsB, 3));

    const waveMatB = new THREE.PointsMaterial({
      size: 0.022,
      vertexColors: true,
      transparent: true,
      opacity: 0.72,
    });
    const waveMeshB = new THREE.Points(waveGeoB, waveMatB);
    masterGroup.add(waveMeshB);

    // Layer C: Inner Resonator Wave (Near Singularity)
    const wavePointCountC = 1200;
    const waveGeoC = new THREE.BufferGeometry();
    const positionsC = new Float32Array(wavePointCountC * 3);
    const colorsC = new Float32Array(wavePointCountC * 3);

    for (let i = 0; i < wavePointCountC; i++) {
      const u = (i / wavePointCountC) * Math.PI * 2;
      const layer = Math.floor(i / 400);
      const baseR = 0.82 + layer * 0.06;

      positionsC[i * 3] = Math.cos(u) * baseR;
      positionsC[i * 3 + 1] = Math.sin(u) * baseR;
      positionsC[i * 3 + 2] = 0;

      const ptColor = azureColor.clone().lerp(cyanColor, Math.sin(u * 4) * 0.5 + 0.5);
      colorsC[i * 3] = ptColor.r;
      colorsC[i * 3 + 1] = ptColor.g;
      colorsC[i * 3 + 2] = ptColor.b;
    }

    waveGeoC.setAttribute('position', new THREE.BufferAttribute(positionsC, 3));
    waveGeoC.setAttribute('color', new THREE.BufferAttribute(colorsC, 3));

    const waveMatC = new THREE.PointsMaterial({
      size: 0.02,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
    });
    const waveMeshC = new THREE.Points(waveGeoC, waveMatC);
    masterGroup.add(waveMeshC);

    // 7. Ambient Cosmic Dust Particles
    const dustCount = 160;
    const dustGeo = new THREE.BufferGeometry();
    const dustPositions = new Float32Array(dustCount * 3);

    for (let i = 0; i < dustCount; i++) {
      const r = 0.5 + Math.random() * 2.3;
      const theta = Math.random() * Math.PI * 2;
      dustPositions[i * 3] = Math.cos(theta) * r;
      dustPositions[i * 3 + 1] = Math.sin(theta) * r;
      dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.9;
    }
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x7dd3fc,
      size: 0.02,
      transparent: true,
      opacity: 0.6,
    });
    const dustMesh = new THREE.Points(dustGeo, dustMat);
    masterGroup.add(dustMesh);

    // 8. Bottom Perspective 3D Cyan Grid Floor
    const floorGroup = new THREE.Group();
    floorGroup.position.set(0, -1.95, -0.5);
    floorGroup.rotation.x = -Math.PI / 2.3;
    scene.add(floorGroup);

    const gridHelper = new THREE.GridHelper(7, 24, 0x06b6d4, 0x0369a1);
    (gridHelper.material as THREE.Material).transparent = true;
    (gridHelper.material as THREE.Material).opacity = 0.28;
    floorGroup.add(gridHelper);

    const floorSpotGeo = new THREE.CircleGeometry(1.2, 32);
    const floorSpotMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.2,
      side: THREE.DoubleSide,
    });
    const floorSpot = new THREE.Mesh(floorSpotGeo, floorSpotMat);
    floorSpot.rotation.x = -Math.PI / 2;
    floorGroup.add(floorSpot);

    // 9. Animation Loop with Speech Modulation and Smooth Parallax
    let frameId = 0;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const syncStatus = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (syncStatus === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 60);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const animate = () => {
      const t = clock.getElapsedTime();
      const dt = clock.getDelta();
      const currentState = voiceStateRef.current;
      const motion = reducedMotionRef.current ? 0.25 : 1.0;
      const audioLevel = voiceService.getLiveAudioLevel();

      // Smooth Parallax Damping (Exponential)
      masterGroup.rotation.x += (targetTiltX - masterGroup.rotation.x) * 0.08 * motion;
      masterGroup.rotation.y += (targetTiltY - masterGroup.rotation.y) * 0.08 * motion;

      // Dynamic State Parameters
      let rotSpeed = 0.4;
      let waveSpeed = 2.4;
      let waveAmpA = 0.16;
      let waveAmpB = 0.14;
      let waveAmpC = 0.11;
      let speechExpansion = 1.0;

      if (currentState === 'SPEAKING') {
        // Voice is actively talking: dramatic, layered, cinematic acoustic ripple
        rotSpeed = 0.85;
        waveSpeed = 4.8;
        waveAmpA = 0.28 + audioLevel * 0.35;
        waveAmpB = 0.22 + audioLevel * 0.28;
        waveAmpC = 0.18 + audioLevel * 0.22;
        speechExpansion = 1.0 + audioLevel * 0.18;
      } else if (currentState === 'LISTENING') {
        rotSpeed = 0.95;
        waveSpeed = 4.0;
        waveAmpA = 0.22 + audioLevel * 0.22;
        waveAmpB = 0.18 + audioLevel * 0.15;
        waveAmpC = 0.14 + audioLevel * 0.12;
      } else if (currentState === 'PROCESSING') {
        rotSpeed = 2.4;
        waveSpeed = 7.5;
        waveAmpA = 0.26;
        waveAmpB = 0.22;
        waveAmpC = 0.16;
      } else if (currentState === 'ERROR') {
        rotSpeed = 0.2;
        waveSpeed = 1.2;
        waveAmpA = 0.1;
        waveAmpB = 0.08;
        waveAmpC = 0.06;
      }

      // Rotate radar rings and tick markers
      ringsGroup.rotation.z += 0.14 * rotSpeed * motion * dt;
      ticksGroup.rotation.z -= 0.09 * rotSpeed * motion * dt;
      dustMesh.rotation.z += 0.04 * motion * dt;

      // Singularity core breathing & voice pulsation
      const corePulse = 1.0 + (Math.sin(t * 3.2) * 0.05 + audioLevel * 0.28) * motion;
      centerCore.scale.set(corePulse, corePulse, corePulse);
      haloMesh.scale.set(corePulse * 1.08, corePulse * 1.08, corePulse * 1.08);

      // Star flare optical pulsation
      const flarePulse = 1.0 + (Math.sin(t * 4.8) * 0.12 + audioLevel * 0.45) * motion;
      hFlare.scale.set(flarePulse, flarePulse, 1);
      vFlare.scale.set(flarePulse, flarePulse, 1);

      // Acoustic Shockwave Rings (radiating outward during speech)
      for (let s = 0; s < shockwaveRingsCount; s++) {
        if (currentState === 'SPEAKING' || currentState === 'LISTENING') {
          shockwavePhases[s] = (shockwavePhases[s] + dt * (1.2 + audioLevel * 2.0)) % 1.0;
          const p = shockwavePhases[s];
          const ringScale = 0.4 + p * 1.5;
          const ringOpacity = Math.sin(p * Math.PI) * (0.6 + audioLevel * 0.4);
          shockwaveMeshes[s].scale.set(ringScale, ringScale, 1);
          shockwaveMats[s].opacity = ringOpacity;
        } else {
          shockwaveMats[s].opacity = 0.0;
        }
      }

      // 1. Animate Hero Wave Ribbon (Layer A) with multi-frequency sinusoidal harmonics
      const posAttrA = waveGeoA.attributes.position as THREE.BufferAttribute;
      const posA = posAttrA.array as Float32Array;
      for (let i = 0; i < wavePointCountA; i++) {
        const u = (i / wavePointCountA) * Math.PI * 2;
        const layer = Math.floor(i / 800);
        const baseR = (1.15 + layer * 0.09) * speechExpansion;

        // 6 main lobes + 3 secondary harmonic crests + 9 micro ripples
        const wave1 = Math.sin(u * 6 + t * waveSpeed * motion) * waveAmpA;
        const wave2 = Math.cos(u * 3 - t * (waveSpeed * 0.6) * motion) * (waveAmpA * 0.55);
        const wave3 = Math.sin(u * 9 + t * (waveSpeed * 1.3) * motion) * (waveAmpA * 0.28);

        const r = baseR + wave1 + wave2 + wave3;
        posA[i * 3] = Math.cos(u + t * 0.08 * motion) * r;
        posA[i * 3 + 1] = Math.sin(u + t * 0.08 * motion) * r;
        // 3D vertical depth displacement
        posA[i * 3 + 2] = Math.sin(u * 5 + t * 2.4 * motion) * (0.16 + audioLevel * 0.2) * motion;
      }
      posAttrA.needsUpdate = true;

      // 2. Animate Outer Wave Ribbon (Layer B) with fluid spatial billow
      const posAttrB = waveGeoB.attributes.position as THREE.BufferAttribute;
      const posB = posAttrB.array as Float32Array;
      for (let i = 0; i < wavePointCountB; i++) {
        const u = (i / wavePointCountB) * Math.PI * 2;
        const layer = Math.floor(i / 600);
        const baseR = (1.48 + layer * 0.08) * speechExpansion;

        const wave1 = Math.sin(u * 4 - t * (waveSpeed * 0.8) * motion) * waveAmpB;
        const wave2 = Math.cos(u * 8 + t * (waveSpeed * 1.1) * motion) * (waveAmpB * 0.4);

        const r = baseR + wave1 + wave2;
        posB[i * 3] = Math.cos(u - t * 0.06 * motion) * r;
        posB[i * 3 + 1] = Math.sin(u - t * 0.06 * motion) * r;
        posB[i * 3 + 2] = Math.cos(u * 4 + t * 1.8 * motion) * (0.2 + audioLevel * 0.25) * motion;
      }
      posAttrB.needsUpdate = true;

      // 3. Animate Inner Resonator Wave (Layer C) near singularity
      const posAttrC = waveGeoC.attributes.position as THREE.BufferAttribute;
      const posC = posAttrC.array as Float32Array;
      for (let i = 0; i < wavePointCountC; i++) {
        const u = (i / wavePointCountC) * Math.PI * 2;
        const layer = Math.floor(i / 400);
        const baseR = (0.82 + layer * 0.06) * speechExpansion;

        const wave1 = Math.sin(u * 8 + t * (waveSpeed * 1.2) * motion) * waveAmpC;
        const wave2 = Math.cos(u * 4 - t * waveSpeed * motion) * (waveAmpC * 0.5);

        const r = baseR + wave1 + wave2;
        posC[i * 3] = Math.cos(u + t * 0.12 * motion) * r;
        posC[i * 3 + 1] = Math.sin(u + t * 0.12 * motion) * r;
        posC[i * 3 + 2] = Math.sin(u * 6 + t * 3.0 * motion) * 0.1 * motion;
      }
      posAttrC.needsUpdate = true;

      // Render
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(animate);
      } else {
        frameId = requestAnimationFrame(animate);
      }
    };

    if (isSoftwareGl) {
      afterDraw(animate);
    } else {
      frameId = requestAnimationFrame(animate);
    }

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('touchmove', onPointerMove);

      if (typeof frameId === 'number') {
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
      }

      centerCoreGeo.dispose();
      centerCoreMat.dispose();
      haloGeo.dispose();
      haloMat.dispose();
      hFlareGeo.dispose();
      vFlareGeo.dispose();
      flareMat.dispose();

      rings.forEach((r) => {
        r.geometry.dispose();
        (r.material as THREE.Material).dispose();
      });

      shockwaveGeos.forEach((g) => g.dispose());
      shockwaveMats.forEach((m) => m.dispose());

      waveGeoA.dispose();
      waveMatA.dispose();
      waveGeoB.dispose();
      waveMatB.dispose();
      waveGeoC.dispose();
      waveMatC.dispose();

      dustGeo.dispose();
      dustMat.dispose();
      gridHelper.geometry.dispose();
      (gridHelper.material as THREE.Material).dispose();
      floorSpotGeo.dispose();
      floorSpotMat.dispose();

      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-hidden"
      aria-hidden="true"
    />
  );
};
