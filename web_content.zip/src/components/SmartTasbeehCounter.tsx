import React, { useState, useEffect, useRef } from 'react';
import { 
  RotateCcw, 
  Undo2, 
  Volume2, 
  VolumeX, 
  Vibrate, 
  Check, 
  Sparkles, 
  Target, 
  SlidersHorizontal, 
  X, 
  ChevronDown, 
  Heart,
  Save,
  Layers,
  Award,
  Zap,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { playTapSound, playMilestoneSound } from '../utils/audioFeedback';

export interface DhikrContextProp {
  id?: string;
  title: string;
  text?: string;
  target: number;
  currentCount: number;
  onUpdateCount?: (count: number) => void;
}

interface SmartTasbeehCounterProps {
  isOpen: boolean;
  onClose: () => void;
  dhikrContext?: DhikrContextProp | null;
}

const PRESET_PHRASES = [
  'سبحان الله',
  'الحمد لله',
  'لا إله إلا الله',
  'الله أكبر',
  'أستغفر الله العظيم وأتوب إليه',
  'لا حول ولا قوة إلا بالله العلي العظيم',
  'اللهم صلِّ وسلِّم على نبينا محمد',
  'سبحان الله وبحمده، سبحان الله العظيم',
  'حسبي الله ونعم الوكيل',
  'يا حي يا قيوم برحمتك أستغيث'
];

const PRESET_MILESTONES = [
  { label: 'كل ٣٣', value: 33 },
  { label: 'كل ١٠٠', value: 100 },
  { label: 'كل ١٠', value: 10 },
  { label: 'كل ٧', value: 7 },
  { label: 'الهدف المحدد', value: -1 }, // Follow target count
  { label: 'رقم مخصص...', value: 0 }
];

export const SmartTasbeehCounter: React.FC<SmartTasbeehCounterProps> = ({
  isOpen,
  onClose,
  dhikrContext
}) => {
  const { 
    settings, 
    updateSettings, 
    incrementTotalDhikrCount, 
    showToast 
  } = useApp();

  // Storage key for standalone mode persistence
  const STORAGE_KEY = 'hisn_standalone_tasbeeh_state';

  // State initialization with localStorage recovery (حفظ العدد الحالي في حالة الإغلاق)
  const [currentCount, setCurrentCount] = useState<number>(() => {
    if (dhikrContext) return dhikrContext.currentCount || 0;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.count === 'number' ? parsed.count : 0;
      }
    } catch {
      // ignore
    }
    return 0;
  });

  const [targetCount, setTargetCount] = useState<number>(() => {
    if (dhikrContext) return dhikrContext.target || 33;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.target === 'number' ? parsed.target : 33;
      }
    } catch {
      // ignore
    }
    return 33;
  });

  const [selectedPhrase, setSelectedPhrase] = useState<string>(() => {
    if (dhikrContext) return dhikrContext.title;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.phrase || PRESET_PHRASES[0];
      }
    } catch {
      // ignore
    }
    return PRESET_PHRASES[0];
  });

  // Milestone setting for vibration alert (اهتزاز عند الوصول لرقم معين)
  const [milestoneNumber, setMilestoneNumber] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.milestone === 'number' ? parsed.milestone : 33;
      }
    } catch {
      // ignore
    }
    return 33;
  });

  const [customMilestoneInput, setCustomMilestoneInput] = useState<string>('33');
  const [customTargetInput, setCustomTargetInput] = useState<string>('33');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(settings.sound ?? true);
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(settings.vibration ?? true);

  // UI modal panels & visual cues
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showPhrasesModal, setShowPhrasesModal] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [tapScale, setTapScale] = useState<boolean>(false);
  const [milestoneAlert, setMilestoneAlert] = useState<string | null>(null);

  // Synchronize when dhikrContext changes (e.g. opened inside Dhikr page)
  useEffect(() => {
    if (dhikrContext) {
      setCurrentCount(dhikrContext.currentCount || 0);
      setTargetCount(dhikrContext.target || 33);
      setSelectedPhrase(dhikrContext.title);
    }
  }, [dhikrContext]);

  // Persist current state in localStorage immediately on every update (حفظ العدد الحالي في حالة الإغلاق)
  useEffect(() => {
    if (!dhikrContext) {
      try {
        const stateToSave = {
          count: currentCount,
          target: targetCount,
          phrase: selectedPhrase,
          milestone: milestoneNumber,
          timestamp: Date.now()
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
      } catch {
        // ignore
      }
    }
  }, [currentCount, targetCount, selectedPhrase, milestoneNumber, dhikrContext]);

  // Handle vibration trigger on reaching milestones or targets
  const handleVibrationAlert = (type: 'tap' | 'milestone' | 'target') => {
    if (!vibrationEnabled) return;
    if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
      try {
        if (type === 'tap') {
          navigator.vibrate(25);
        } else if (type === 'milestone') {
          // Distinct dual-pulse pattern for reaching configured milestone number
          navigator.vibrate([45, 55, 45, 55, 90]);
        } else if (type === 'target') {
          // Rich celebratory triplet vibration
          navigator.vibrate([60, 70, 60, 70, 180]);
        }
      } catch {
        // ignore
      }
    }
  };

  // Tap handler (زيادة العداد)
  const handleTap = () => {
    setTapScale(true);
    setTimeout(() => setTapScale(false), 90);

    const nextCount = currentCount + 1;
    setCurrentCount(nextCount);
    incrementTotalDhikrCount(1);

    if (dhikrContext?.onUpdateCount) {
      dhikrContext.onUpdateCount(nextCount);
    }

    // Check if reached target count
    const reachedTarget = targetCount > 0 && nextCount === targetCount;

    // Check if reached configured milestone number (ميزة الاهتزاز عند الوصول لأرقام معينة)
    let reachedMilestone = false;
    const effectiveMilestone = milestoneNumber === -1 ? targetCount : milestoneNumber;
    
    if (effectiveMilestone > 0 && nextCount % effectiveMilestone === 0) {
      reachedMilestone = true;
    }

    if (reachedTarget) {
      handleVibrationAlert('target');
      playMilestoneSound(soundEnabled);
      setMilestoneAlert(`ما شاء الله! بلغت الهدف المحدد (${targetCount}) 🌟`);
      setTimeout(() => setMilestoneAlert(null), 3000);
    } else if (reachedMilestone) {
      handleVibrationAlert('milestone');
      playMilestoneSound(soundEnabled);
      setMilestoneAlert(`وصلت إلى الرقم (${nextCount}) 🌿`);
      setTimeout(() => setMilestoneAlert(null), 2500);
    } else {
      handleVibrationAlert('tap');
      playTapSound(soundEnabled);
    }
  };

  // Undo handler (تراجع -1)
  const handleUndo = () => {
    if (currentCount <= 0) return;
    const prevCount = currentCount - 1;
    setCurrentCount(prevCount);
    if (dhikrContext?.onUpdateCount) {
      dhikrContext.onUpdateCount(prevCount);
    }
    if (vibrationEnabled && 'navigator' in window && navigator.vibrate) {
      try {
        navigator.vibrate(15);
      } catch {
        // ignore
      }
    }
  };

  // Reset handler (تصفير العداد)
  const handleReset = () => {
    setCurrentCount(0);
    if (dhikrContext?.onUpdateCount) {
      dhikrContext.onUpdateCount(0);
    }
    setShowResetConfirm(false);
    showToast('تم تصفير العداد للبدء من جديد 🔄');
  };

  // Progress metrics
  const progressRatio = targetCount > 0 ? Math.min(1, currentCount / targetCount) : 0;
  const progressPercent = Math.round(progressRatio * 100);
  const remaining = Math.max(0, targetCount - currentCount);
  const completedCycles = targetCount > 0 ? Math.floor(currentCount / targetCount) : 0;

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 select-none text-right"
      role="dialog"
      aria-modal="true"
      aria-label="عداد التسبيح الرقمي"
    >
      <div className="w-full max-w-sm bg-gradient-to-b from-[#042017] via-[#021811] to-[#01100b] border border-emerald-500/30 rounded-3xl p-4 shadow-2xl flex flex-col space-y-3 relative overflow-hidden text-[#e4f2ea]">
        
        {/* Subtle decorative glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* 1. Top Header Bar */}
        <div className="flex items-center justify-between border-b border-emerald-800/60 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-800/50 border border-emerald-600/40 text-amber-300 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-[#e8f5ee] font-cairo flex items-center gap-1.5">
                <span>المسبحة الرقمية</span>
                {dhikrContext ? (
                  <span className="text-[10px] bg-amber-400/20 text-amber-300 px-1.5 py-0.2 rounded font-normal font-tajawal">
                    ذكر محدد
                  </span>
                ) : (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-normal font-tajawal">
                    تسبيح حر
                  </span>
                )}
              </h2>
              <p className="text-[10px] text-[#78a892] font-tajawal flex items-center gap-1">
                <Save className="w-2.5 h-2.5 text-emerald-400" />
                <span>العدد محفوظ تلقائياً</span>
              </p>
            </div>
          </div>

          {/* Quick Settings & Close */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSettingsModal(true)}
              className="p-1.5 rounded-xl bg-[#062c20] hover:bg-[#093a2b] border border-emerald-700/60 text-[#a0cfb8] hover:text-white transition-colors cursor-pointer"
              title="إعدادات الاهتزاز والهدف"
              aria-label="إعدادات العداد"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-[#062c20] hover:bg-red-950/60 hover:text-red-300 border border-emerald-700/60 text-[#a0cfb8] transition-colors cursor-pointer"
              title="إغلاق والعودة"
              aria-label="إغلاق المسبحة"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. Active Dhikr Phrase Card */}
        <div 
          onClick={() => !dhikrContext && setShowPhrasesModal(true)}
          className={`p-2.5 rounded-2xl border text-center transition-all ${
            !dhikrContext ? 'cursor-pointer hover:border-emerald-500/50 bg-[#032419]/90 border-emerald-700/50' : 'bg-[#032419]/60 border-emerald-800/40'
          }`}
          title={!dhikrContext ? 'اضغط لتغيير صيغة الذكر' : ''}
        >
          <div className="flex items-center justify-between text-[10px] text-[#70a48d] font-cairo mb-0.5 px-1">
            <span>الذكر الحالي:</span>
            {!dhikrContext && (
              <span className="text-amber-300 flex items-center gap-0.5">
                <span>تغيير</span>
                <ChevronDown className="w-3 h-3" />
              </span>
            )}
          </div>
          <p className="text-sm font-black text-amber-200 font-cairo line-clamp-2 px-1 leading-snug">
            {selectedPhrase}
          </p>
          {dhikrContext?.text && (
            <p className="text-[10px] text-[#90c0a9] font-amiri line-clamp-2 mt-1 px-1">
              {dhikrContext.text}
            </p>
          )}
        </div>

        {/* 3. Milestone Notification Alert Toast Banner */}
        {milestoneAlert && (
          <div className="bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-bold font-cairo py-1.5 px-3 rounded-xl text-center shadow-xs animate-bounce flex items-center justify-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>{milestoneAlert}</span>
          </div>
        )}

        {/* 4. Digital LED Display Pod */}
        <div className="bg-[#01140e] border border-emerald-600/40 rounded-2xl p-4 shadow-inner relative overflow-hidden flex flex-col items-center justify-center space-y-1">
          {/* Subtle Top Indicator Info */}
          <div className="w-full flex items-center justify-between text-[11px] text-[#5e917a] font-cairo">
            <span className="font-mono">
              الهدف: <span className="text-amber-300 font-bold">{targetCount > 0 ? targetCount : 'مفتوح'}</span>
            </span>
            <span className="flex items-center gap-1 font-mono">
              <span>اهتزاز عند: </span>
              <span className="text-emerald-300 font-bold">
                {milestoneNumber === -1 ? `الهدف (${targetCount})` : milestoneNumber}
              </span>
            </span>
          </div>

          {/* Large Digital LED Counter Digits */}
          <div className="py-2 flex items-baseline justify-center gap-1">
            <span className="text-5xl font-black font-mono tracking-tight text-white drop-shadow-[0_0_15px_rgba(52,211,153,0.35)]">
              {currentCount}
            </span>
            {targetCount > 0 && (
              <span className="text-lg font-mono text-[#4b7a66] font-bold">
                /{targetCount}
              </span>
            )}
          </div>

          {/* Visual Progress Bar to Target */}
          {targetCount > 0 && (
            <div className="w-full space-y-1">
              <div className="w-full h-2 rounded-full bg-[#032217] border border-emerald-900 overflow-hidden">
                <div 
                  className="h-full rounded-full bg-gradient-to-l from-amber-400 to-emerald-400 transition-all duration-300 ease-out"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#699c86] font-tajawal">
                <span>{progressPercent}% مكتمل</span>
                <span>بقي {remaining}</span>
              </div>
            </div>
          )}
        </div>

        {/* 5. Main Ergonomic Tap Zone (زر التسبيح الضخم) */}
        <div className="py-2 flex justify-center items-center">
          <button
            onClick={handleTap}
            className={`w-36 h-36 rounded-full bg-gradient-to-br from-emerald-600 via-emerald-700 to-[#043323] border-4 border-emerald-400/50 shadow-[0_0_25px_rgba(16,185,129,0.35)] active:shadow-inner flex flex-col items-center justify-center text-white transition-transform duration-75 cursor-pointer relative group ${
              tapScale ? 'scale-95 bg-emerald-500' : 'hover:scale-[1.02]'
            }`}
            aria-label="اضغط للتسبيح"
          >
            {/* Inner Ring Glow */}
            <div className="w-28 h-28 rounded-full border border-emerald-300/30 flex flex-col items-center justify-center bg-white/5 group-hover:bg-white/10 transition-colors">
              <span className="text-xl font-black font-cairo text-amber-200">
                سبّح
              </span>
              <span className="text-[10px] font-tajawal text-emerald-200 opacity-80 mt-0.5">
                انقر هنا
              </span>
            </div>
          </button>
        </div>

        {/* 6. Utility Action Bar: Undo, Sound, Vibration, Reset */}
        <div className="grid grid-cols-4 gap-2 pt-1 border-t border-emerald-800/40">
          {/* Undo Button */}
          <button
            onClick={handleUndo}
            disabled={currentCount <= 0}
            className="p-2 rounded-xl bg-[#032419] hover:bg-[#053525] disabled:opacity-40 border border-emerald-700/60 text-[#a0cfb8] hover:text-white flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
            title="تراجع عن آخر ضغطة (-1)"
          >
            <Undo2 className="w-4 h-4" />
            <span className="text-[9px] font-tajawal font-bold">تراجع</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-[#032419] border-emerald-600 text-amber-300'
                : 'bg-[#01140e] border-emerald-900/60 text-gray-500'
            }`}
            title={soundEnabled ? 'الصوت مفعّل' : 'الصوت معطّل'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="text-[9px] font-tajawal font-bold">{soundEnabled ? 'صوت' : 'صامت'}</span>
          </button>

          {/* Vibration Toggle */}
          <button
            onClick={() => setVibrationEnabled(!vibrationEnabled)}
            className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
              vibrationEnabled
                ? 'bg-[#032419] border-emerald-600 text-emerald-300'
                : 'bg-[#01140e] border-emerald-900/60 text-gray-500'
            }`}
            title={vibrationEnabled ? 'الاهتزاز مفعّل' : 'الاهتزاز معطّل'}
          >
            <Vibrate className="w-4 h-4" />
            <span className="text-[9px] font-tajawal font-bold">{vibrationEnabled ? 'اهتزاز' : 'بلا اهتزاز'}</span>
          </button>

          {/* Reset Button */}
          <button
            onClick={() => setShowResetConfirm(true)}
            className="p-2 rounded-xl bg-[#032419] hover:bg-red-950/50 border border-emerald-700/60 text-[#a0cfb8] hover:text-red-300 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
            title="تصفير العداد"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="text-[9px] font-tajawal font-bold">تصفير</span>
          </button>
        </div>

        {/* Reset Confirmation Overlay */}
        {showResetConfirm && (
          <div className="absolute inset-0 z-20 bg-black/90 p-4 flex flex-col items-center justify-center text-center space-y-3 animate-in fade-in">
            <RotateCcw className="w-8 h-8 text-amber-400" />
            <div>
              <p className="text-sm font-extrabold text-white font-cairo">
                هل تريد تصفير عداد التسبيح؟
              </p>
              <p className="text-[11px] text-gray-300 font-tajawal mt-1">
                العدد الحالي هو ({currentCount}). سيتم بدء جولة تسبيح جديدة من الصفر.
              </p>
            </div>
            <div className="flex items-center gap-2 w-full pt-1">
              <button
                onClick={handleReset}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold font-cairo text-xs cursor-pointer"
              >
                نعم، تصفير العداد
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-[#062c20] text-gray-300 font-bold font-cairo text-xs cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        )}

        {/* Phrases Selection Modal Overlay */}
        {showPhrasesModal && (
          <div className="absolute inset-0 z-20 bg-[#021811] p-4 flex flex-col space-y-3 animate-in fade-in overflow-hidden text-right">
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-2">
              <span className="text-sm font-extrabold text-white font-cairo">
                اختر صيغة التسبيح
              </span>
              <button
                onClick={() => setShowPhrasesModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 custom-scrollbar pl-1 pr-0.5">
              {PRESET_PHRASES.map((phrase, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedPhrase(phrase);
                    setShowPhrasesModal(false);
                  }}
                  className={`w-full p-2.5 rounded-xl border text-right font-cairo text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                    selectedPhrase === phrase
                      ? 'bg-emerald-800/60 border-amber-400/80 text-amber-200'
                      : 'bg-[#032419] border-emerald-800/40 text-[#c8e6d8] hover:border-emerald-600'
                  }`}
                >
                  <span>{phrase}</span>
                  {selectedPhrase === phrase && <Check className="w-3.5 h-3.5 text-amber-300" />}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Settings Modal (اهتزاز عند أرقام معينة والهدف) */}
        {showSettingsModal && (
          <div className="absolute inset-0 z-20 bg-[#021811] p-4 flex flex-col space-y-3 animate-in fade-in overflow-y-auto text-right">
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-2">
              <span className="text-sm font-extrabold text-white font-cairo flex items-center gap-1.5">
                <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                <span>إعدادات الاهتزاز والهدف</span>
              </span>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Vibration Milestone Configuration (ميزة الاهتزاز عند الوصول لأرقام معينة) */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-amber-300 font-cairo flex items-center gap-1">
                <Vibrate className="w-3.5 h-3.5 text-emerald-400" />
                <span>الاهتزاز عند الوصول لرقم معين:</span>
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {PRESET_MILESTONES.map((m) => (
                  <button
                    key={m.label}
                    onClick={() => {
                      if (m.value !== 0) {
                        setMilestoneNumber(m.value);
                      }
                    }}
                    className={`p-2 rounded-xl border text-center font-cairo text-xs font-bold transition-all cursor-pointer ${
                      milestoneNumber === m.value
                        ? 'bg-emerald-700 border-amber-400 text-amber-200 shadow-xs'
                        : 'bg-[#032419] border-emerald-800/60 text-[#a0cfb8] hover:border-emerald-600'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              {/* Custom Milestone Input */}
              <div className="pt-1 flex items-center gap-2">
                <span className="text-[11px] text-[#70a48d] font-tajawal">أو رقم مخصص:</span>
                <input
                  type="number"
                  min="1"
                  max="10000"
                  value={customMilestoneInput}
                  onChange={(e) => setCustomMilestoneInput(e.target.value)}
                  className="w-20 bg-[#01140e] border border-emerald-700/60 rounded-lg px-2 py-1 text-center text-xs font-mono font-bold text-white"
                />
                <button
                  onClick={() => {
                    const parsed = parseInt(customMilestoneInput, 10);
                    if (parsed > 0) {
                      setMilestoneNumber(parsed);
                      showToast(`تم تعيين الاهتزاز عند كل (${parsed}) تكرار 📳`);
                    }
                  }}
                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold font-cairo rounded-lg cursor-pointer"
                >
                  تعيين
                </button>
              </div>
            </div>

            {/* Target Count Configuration */}
            <div className="space-y-1.5 pt-2 border-t border-emerald-900/60">
              <label className="text-xs font-bold text-amber-300 font-cairo flex items-center gap-1">
                <Target className="w-3.5 h-3.5 text-emerald-400" />
                <span>العدد المستهدف (الجولة):</span>
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[33, 100, 500, 1000].map((num) => (
                  <button
                    key={num}
                    onClick={() => setTargetCount(num)}
                    className={`p-1.5 rounded-xl border text-center font-cairo text-xs font-bold transition-all cursor-pointer ${
                      targetCount === num
                        ? 'bg-emerald-700 border-amber-400 text-white'
                        : 'bg-[#032419] border-emerald-800/60 text-[#a0cfb8]'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>

              <div className="pt-1 flex items-center gap-2">
                <span className="text-[11px] text-[#70a48d] font-tajawal">هدف مخصص:</span>
                <input
                  type="number"
                  min="1"
                  max="100000"
                  value={customTargetInput}
                  onChange={(e) => setCustomTargetInput(e.target.value)}
                  className="w-20 bg-[#01140e] border border-emerald-700/60 rounded-lg px-2 py-1 text-center text-xs font-mono font-bold text-white"
                />
                <button
                  onClick={() => {
                    const parsed = parseInt(customTargetInput, 10);
                    if (parsed > 0) {
                      setTargetCount(parsed);
                      showToast(`تم تعيين الهدف إلى (${parsed})`);
                    }
                  }}
                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold font-cairo rounded-lg cursor-pointer"
                >
                  تعيين
                </button>
              </div>
            </div>

            {/* Persistence Notice */}
            <div className="pt-2 border-t border-emerald-900/60 bg-[#01140e] p-2.5 rounded-xl border border-emerald-900/40 text-[11px] text-[#78a892] font-tajawal flex items-center gap-2">
              <Save className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                يتم حفظ العدد والإعدادات تلقائياً في ذاكرة الجهاز ولن يُفقد عددك عند الإغلاق.
              </span>
            </div>

            <button
              onClick={() => setShowSettingsModal(false)}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold font-cairo text-xs rounded-xl cursor-pointer"
            >
              حفظ والإغلاق
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
