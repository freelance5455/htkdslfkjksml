import { useState } from "react";
import { copyText, shareLink } from "@/lib/utils";

export function PageIntro({
  kicker,
  title,
  lede,
}: {
  kicker: string;
  title: string;
  lede: string;
}) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto max-w-6xl px-4 py-10 md:py-14">
        <p className="text-sm font-medium text-olive">{kicker}</p>
        <h1 className="mt-2 font-display text-4xl leading-tight text-primary md:text-5xl">{title}</h1>
        <p className="mt-4 max-w-3xl text-lg leading-relaxed text-muted">{lede}</p>
      </div>
    </header>
  );
}

export function ReviewBanner({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded-card border border-line bg-soft px-4 py-3 text-sm leading-7 text-ink">{children}</p>
  );
}

export function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex rounded-full border border-line bg-surface px-3 py-1 text-xs text-olive">
      {children}
    </span>
  );
}

export function ActionBar({
  title,
  text,
  urlPath,
}: {
  title: string;
  text: string;
  urlPath: string;
}) {
  const [note, setNote] = useState("");

  async function onCopy() {
    await copyText(text);
    setNote("تم نسخ النص مع مصدره");
    window.setTimeout(() => setNote(""), 2000);
  }

  async function onShare() {
    const url = `${window.location.origin}${urlPath}`;
    const result = await shareLink({ title, text, url });
    setNote(result === "shared" ? "تمت المشاركة" : result === "copied" ? "نُسخ الرابط والنص" : "");
    window.setTimeout(() => setNote(""), 2000);
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button type="button" onClick={onCopy} className="rounded-full border border-line bg-surface px-4 py-2 text-sm">
        نسخ
      </button>
      <button type="button" onClick={onShare} className="rounded-full border border-line bg-surface px-4 py-2 text-sm">
        مشاركة
      </button>
      <button type="button" onClick={() => window.print()} className="rounded-full border border-line bg-surface px-4 py-2 text-sm">
        طباعة
      </button>
      {note ? (
        <span role="status" className="text-sm text-olive">
          {note}
        </span>
      ) : null}
    </div>
  );
}

export function Pager({ prev, next }: { prev?: React.ReactNode; next?: React.ReactNode }) {
  return (
    <nav className="mt-10 grid gap-3 border-t border-line pt-6 sm:grid-cols-2">
      <div>{prev}</div>
      <div>{next}</div>
    </nav>
  );
}
