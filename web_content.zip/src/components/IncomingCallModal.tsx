import React from 'react';
import { Phone, PhoneOff, Video, Volume2 } from 'lucide-react';
import { BlueTick } from './BlueTick.tsx';

interface IncomingCallModalProps {
  caller: {
    id: string;
    username: string;
    fullName: string;
    avatarUrl: string;
    verifiedBlueTick?: boolean;
  };
  isVideo: boolean;
  onAccept: () => void;
  onDecline: () => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  caller,
  isVideo,
  onAccept,
  onDecline,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-sm rounded-3xl bg-[#0a0f18] border border-cyan-500/50 p-6 shadow-[0_0_50px_rgba(0,210,255,0.3)] text-center text-slate-100 space-y-6">
        <div className="flex items-center justify-center gap-2 text-cyan-400 font-mono text-xs tracking-wider uppercase">
          <Volume2 size={16} className="animate-bounce" />
          <span>Incoming {isVideo ? 'Video' : 'Voice'} Call</span>
        </div>

        {/* Pulsing Avatar */}
        <div className="relative mx-auto w-28 h-28">
          <div className="absolute -inset-3 rounded-full bg-cyan-500/30 blur-md animate-ping" />
          <img
            src={caller.avatarUrl}
            alt={caller.fullName}
            className="relative w-28 h-28 rounded-3xl bg-slate-900 border-2 border-cyan-400 object-cover shadow-2xl"
          />
        </div>

        <div>
          <div className="flex items-center justify-center gap-1.5 font-black text-lg text-white font-display">
            <span>{caller.fullName}</span>
            {caller.verifiedBlueTick && <BlueTick size="sm" />}
          </div>
          <div className="text-xs text-cyan-400 font-mono mt-0.5">@{caller.username}</div>
          <div className="text-xs text-slate-400 mt-2">Connecting from Unknown Gamer Clan</div>
        </div>

        {/* Accept and Decline Buttons */}
        <div className="flex items-center justify-center gap-8 pt-4">
          {/* Decline Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={onDecline}
              className="w-16 h-16 rounded-3xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer"
              title="Decline Call"
            >
              <PhoneOff size={26} />
            </button>
            <span className="text-[11px] font-semibold text-slate-400">Decline</span>
          </div>

          {/* Accept Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={onAccept}
              className="w-16 h-16 rounded-3xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/40 active:scale-95 transition-all cursor-pointer animate-pulse"
              title="Accept Call"
            >
              {isVideo ? <Video size={28} /> : <Phone size={28} />}
            </button>
            <span className="text-[11px] font-semibold text-emerald-400">Answer</span>
          </div>
        </div>
      </div>
    </div>
  );
};
