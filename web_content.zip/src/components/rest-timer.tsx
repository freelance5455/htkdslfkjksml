import { useEffect, useRef } from "react";
import { Pause, Play, RotateCcw, SkipForward, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ProgressRing } from "@/components/progress-ring";
import { useAppStore } from "@/lib/store";
import { haptic, playRestChime } from "@/lib/sound";
import { formatMmSs } from "@/lib/utils";

export function RestTimer() {
  const rest = useAppStore((s) => s.restTimer);
  const tickRest = useAppStore((s) => s.tickRest);
  const pauseRest = useAppStore((s) => s.pauseRest);
  const resumeRest = useAppStore((s) => s.resumeRest);
  const skipRest = useAppStore((s) => s.skipRest);
  const restartRest = useAppStore((s) => s.restartRest);
  const closeRest = useAppStore((s) => s.closeRest);
  const soundEnabled = useAppStore((s) => s.settings.soundEnabled);
  const notificationsEnabled = useAppStore((s) => s.settings.notificationsEnabled);
  const last = useRef<number | null>(null);
  const finishedOnce = useRef(false);

  useEffect(() => {
    if (!rest.open || !rest.running) {
      last.current = null;
      return;
    }
    let raf = 0;
    const loop = (t: number) => {
      if (last.current == null) last.current = t;
      const dt = (t - last.current) / 1000;
      last.current = t;
      tickRest(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [rest.open, rest.running, tickRest]);

  useEffect(() => {
    if (rest.finished && rest.open && !finishedOnce.current) {
      finishedOnce.current = true;
      haptic(80);
      if (soundEnabled) void playRestChime();
      if (notificationsEnabled) {
        toast.success("Descanso concluído");
      }
    }
    if (!rest.open || !rest.finished) finishedOnce.current = false;
  }, [rest.finished, rest.open, soundEnabled, notificationsEnabled]);

  if (!rest.open) return null;

  const pct =
    rest.duration > 0
      ? ((rest.duration - rest.remaining) / rest.duration) * 100
      : 100;

  return (
    <div className="fixed inset-x-0 bottom-[4.75rem] z-40 px-3 md:bottom-6 md:left-64">
      <div
        className={`mx-auto max-w-lg rounded-2xl border border-primary/40 bg-popover/95 p-4 shadow-2xl backdrop-blur-md ${
          rest.finished ? "animate-ring-flash" : ""
        }`}
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-[11px] font-medium tracking-[0.2em] text-primary uppercase">
              Descanso
            </p>
            <p className="text-sm text-muted-foreground">{rest.exerciseName}</p>
          </div>
          <button
            type="button"
            onClick={closeRest}
            className="rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Fechar cronômetro"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="mt-3 flex items-center gap-4">
          <ProgressRing value={rest.finished ? 100 : pct} size={108} stroke={8}>
            <span className="font-mono text-xl font-semibold tabular-nums">
              {rest.finished ? "00:00" : formatMmSs(rest.remaining)}
            </span>
          </ProgressRing>
          <div className="min-w-0 flex-1 space-y-2">
            <p className="text-sm text-muted-foreground">
              {rest.finished
                ? "Hora de voltar. Próxima série."
                : `Meta ${formatMmSs(rest.duration)}`}
            </p>
            <div className="flex flex-wrap gap-2">
              {rest.finished ? (
                <Button size="sm" onClick={closeRest}>
                  Continuar
                </Button>
              ) : rest.running ? (
                <Button size="sm" variant="secondary" onClick={pauseRest}>
                  <Pause /> Pausar
                </Button>
              ) : (
                <Button size="sm" onClick={resumeRest}>
                  <Play /> Continuar
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={restartRest}>
                <RotateCcw /> Reiniciar
              </Button>
              <Button size="sm" variant="ghost" onClick={skipRest}>
                <SkipForward /> Pular
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
