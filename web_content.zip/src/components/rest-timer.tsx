import { useEffect } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGymStore } from "@/lib/store";
import { vibrate } from "@/lib/utils";

const R = 52;
const C = 2 * Math.PI * R;

export function RestTimer() {
  const timer = useGymStore((s) => s.restTimer);
  const tickTimer = useGymStore((s) => s.tickTimer);
  const skipTimer = useGymStore((s) => s.skipTimer);
  const addTimer = useGymStore((s) => s.addTimer);

  useEffect(() => {
    if (!timer) return;
    const id = window.setInterval(() => {
      const current = useGymStore.getState().restTimer;
      if (current && current.remaining <= 1) vibrate([70, 40, 70]);
      tickTimer();
    }, 1000);
    return () => window.clearInterval(id);
  }, [timer?.exerciseId, tickTimer]);

  if (!timer) return null;

  const progress = timer.remaining / timer.total;
  const m = Math.floor(timer.remaining / 60);
  const s = timer.remaining % 60;
  const clock = `${m}:${String(s).padStart(2, "0")}`;

  return (
    <div
      className="fixed inset-x-0 bottom-24 z-40 px-4"
      role="dialog"
      aria-label="Dinlenme süresi"
    >
      <div className="mx-auto flex max-w-md items-center gap-4 rounded-3xl bg-raised p-4 shadow-[var(--shadow-border)]">
        <div className="relative size-24 shrink-0">
          <svg viewBox="0 0 120 120" className="size-full -rotate-90" aria-hidden="true">
            <circle cx="60" cy="60" r={R} fill="none" stroke="currentColor" className="text-border" strokeWidth="6" />
            <circle
              cx="60"
              cy="60"
              r={R}
              fill="none"
              stroke="currentColor"
              className="text-primary"
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C * (1 - progress)}
              style={{ transition: "stroke-dashoffset 1s linear" }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center font-display text-xl tabular-nums leading-none text-fg">
            {clock}
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Dinlen</p>
          <p className="mt-1 truncate text-sm text-fg">{timer.label}</p>
          <div className="mt-3 flex gap-2">
            <Button type="button" variant="secondary" size="pill" onClick={() => addTimer(30)}>
              <Plus className="size-3.5" />
              30 sn
            </Button>
            <Button type="button" variant="ghost" size="pill" onClick={skipTimer}>
              <X className="size-3.5" />
              Atla
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
