import React, { useState } from 'react';
import { Check, X, ArrowLeftRight, FileCode } from 'lucide-react';

interface DiffViewerModalProps {
  isOpen: boolean;
  filename: string;
  originalCode: string;
  proposedCode: string;
  explanation?: string;
  onAccept: () => void;
  onReject: () => void;
  onClose: () => void;
}

export const DiffViewerModal: React.FC<DiffViewerModalProps> = ({
  isOpen,
  filename,
  originalCode,
  proposedCode,
  explanation,
  onAccept,
  onReject,
  onClose,
}) => {
  const [viewMode, setViewMode] = useState<'split' | 'unified'>('split');

  if (!isOpen) return null;

  const originalLines = originalCode.split('\n');
  const proposedLines = proposedCode.split('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-xs">
      <div className="bg-[#0b0f19] border border-cyan-500/40 rounded-xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-cyan-950/50 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#0f172a] border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Proposed Code Changes:</span>
                <span className="text-cyan-400 font-mono text-xs px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/50">
                  {filename}
                </span>
              </h3>
              <p className="text-xs text-slate-400">Review modifications before applying to file</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center bg-slate-900 border border-slate-700 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setViewMode('split')}
                className={`px-3 py-1 rounded-md font-medium transition-colors ${
                  viewMode === 'split' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'
                }`}
              >
                Side-by-Side
              </button>
              <button
                onClick={() => setViewMode('unified')}
                className={`px-3 py-1 rounded-md font-medium transition-colors ${
                  viewMode === 'unified' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'
                }`}
              >
                Unified
              </button>
            </div>

            <button
              onClick={onClose}
              aria-label="Close diff modal"
              className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* AI Explanation banner */}
        {explanation && (
          <div className="px-5 py-2.5 bg-cyan-950/30 border-b border-cyan-900/40 text-xs text-cyan-200 flex items-center gap-2">
            <span className="font-semibold text-cyan-400">Summary:</span>
            <span className="line-clamp-2">{explanation}</span>
          </div>
        )}

        {/* Diff Content View */}
        <div className="flex-1 overflow-auto p-4 font-mono text-xs bg-[#070a12]">
          {viewMode === 'split' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
              {/* Original */}
              <div className="flex flex-col border border-rose-900/40 rounded-lg overflow-hidden bg-rose-950/10">
                <div className="px-3 py-1.5 bg-rose-950/50 border-b border-rose-900/40 text-rose-300 font-semibold flex justify-between">
                  <span>Current Version</span>
                  <span>{originalLines.length} lines</span>
                </div>
                <div className="flex-1 overflow-auto p-3 space-y-0.5">
                  {originalLines.map((line, idx) => (
                    <div key={idx} className="flex gap-3 hover:bg-rose-500/10 px-1 rounded">
                      <span className="text-slate-600 select-none w-8 text-right shrink-0">{idx + 1}</span>
                      <pre className="text-slate-300 font-code whitespace-pre-wrap break-all">{line || ' '}</pre>
                    </div>
                  ))}
                </div>
              </div>

              {/* Proposed */}
              <div className="flex flex-col border border-emerald-900/40 rounded-lg overflow-hidden bg-emerald-950/10">
                <div className="px-3 py-1.5 bg-emerald-950/50 border-b border-emerald-900/40 text-emerald-300 font-semibold flex justify-between">
                  <span>Proposed Version</span>
                  <span>{proposedLines.length} lines</span>
                </div>
                <div className="flex-1 overflow-auto p-3 space-y-0.5">
                  {proposedLines.map((line, idx) => (
                    <div key={idx} className="flex gap-3 hover:bg-emerald-500/10 px-1 rounded">
                      <span className="text-slate-600 select-none w-8 text-right shrink-0">{idx + 1}</span>
                      <pre className="text-emerald-300 font-code whitespace-pre-wrap break-all">{line || ' '}</pre>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Unified view */
            <div className="border border-slate-800 rounded-lg overflow-hidden bg-[#0a0f1d] p-3 space-y-0.5">
              {proposedLines.map((line, idx) => {
                const isDifferent = originalLines[idx] !== line;
                return (
                  <div
                    key={idx}
                    className={`flex gap-3 px-2 py-0.5 rounded ${
                      isDifferent ? 'bg-emerald-500/15 text-emerald-200' : 'text-slate-300'
                    }`}
                  >
                    <span className="text-slate-600 select-none w-8 text-right shrink-0">{idx + 1}</span>
                    <span className="select-none font-bold text-slate-500 w-3">{isDifferent ? '+' : ' '}</span>
                    <pre className="font-code whitespace-pre-wrap break-all">{line || ' '}</pre>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-5 py-3 bg-[#0f172a] border-t border-slate-800">
          <button
            onClick={onReject}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-colors"
          >
            <X className="w-4 h-4" />
            <span>Reject Changes</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onAccept}
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition-all shadow-md shadow-emerald-500/20"
            >
              <Check className="w-4 h-4" />
              <span>Accept & Apply to Editor</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
