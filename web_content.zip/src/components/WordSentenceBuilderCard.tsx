import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Mic,
  PenLine,
  Play,
  RotateCcw,
  Send,
  Sparkles,
  Square,
  Volume2,
} from 'lucide-react';
import type { VocabEntry, WordSentenceCheckResult } from '../types';
import { blobToBase64, checkWordSentenceWithAi } from '../utils/aiApi';
import { buildDiffSegments, containsTargetWord } from '../utils/writingLogic';

interface WordSentenceBuilderCardProps {
  word: VocabEntry;
  onSpeak: (text: string) => void;
  onSentencePassed?: () => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}
interface SpeechRecognitionResultLike {
  0: SpeechRecognitionAlternativeLike;
}
interface SpeechRecognitionEventLike {
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRec(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export function WordSentenceBuilderCard({
  word,
  onSpeak,
  onSentencePassed,
}: WordSentenceBuilderCardProps) {
  const [sentence, setSentence] = useState('');
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<WordSentenceCheckResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const [isRecording, setIsRecording] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const audioUrlRef = useRef<string | null>(null);

  const cleanupRecording = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    mediaRecorderRef.current = null;
    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
  }, []);

  useEffect(() => {
    cleanupRecording();
    setSentence('');
    setChecking(false);
    setResult(null);
    setErrorMsg('');
    setIsRecording(false);
    setLiveTranscript('');
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    setAudioUrl(null);
  }, [word.id, word.en, cleanupRecording]);

  useEffect(() => {
    return () => {
      cleanupRecording();
      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
    };
  }, [cleanupRecording]);

  const handleEvaluate = useCallback(
    async (opts: { text?: string; audioBlob?: Blob; audioMimeType?: string }) => {
      const cleanText = (opts.text ?? sentence).trim();
      if (!cleanText && !opts.audioBlob) {
        setErrorMsg(`اكتب جملة بالإنجليزية تحتوي على كلمة «${word.en}» أو سجّلها بصوتك.`);
        return;
      }

      // Local strict check when typed text is provided without audio-only fallback
      if (cleanText && !opts.audioBlob && !containsTargetWord(cleanText, word.en)) {
        setResult(null);
        setErrorMsg(
          `يجب أن تحتوي جملتك حصراً على الكلمة المتعلمة «${word.en}» (أو أحد تصريفاتها الصحيحة). أعد صياغة الجملة بحيث تشمل الكلمة.`
        );
        return;
      }

      setChecking(true);
      setErrorMsg('');
      try {
        const audioBase64 =
          opts.audioBlob && opts.audioBlob.size > 0
            ? await blobToBase64(opts.audioBlob)
            : undefined;

        const res = await checkWordSentenceWithAi({
          targetWord: word.en,
          targetMeaningAr: word.ar,
          sentence: cleanText || undefined,
          audioBase64,
          audioMimeType: opts.audioMimeType || opts.audioBlob?.type || 'audio/webm',
        });

        const finalSentence = res.userSentence || cleanText;
        if (finalSentence && !cleanText) {
          setSentence(finalSentence);
        }

        // Double-check strict inclusion locally as well
        const usedWord =
          res.containsTargetWord || containsTargetWord(finalSentence, word.en);

        if (!usedWord) {
          setResult({
            ...res,
            userSentence: finalSentence,
            containsTargetWord: false,
            isCorrect: false,
          });
          setErrorMsg(
            `جملتك لم تتضمن الكلمة المطلوبة «${word.en}». حاول مرة أخرى باستخدامها داخل الجملة.`
          );
          return;
        }

        setResult({
          ...res,
          userSentence: finalSentence,
          containsTargetWord: true,
        });
        if (res.isCorrect || res.score >= 80) {
          onSentencePassed?.();
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'تعذر فحص الجملة حالياً. حاول مرة أخرى.');
      } finally {
        setChecking(false);
      }
    },
    [sentence, word.en, word.ar, onSentencePassed]
  );

  const stopRecording = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;

    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
      setIsRecording(false);
      const captured = transcriptRef.current.trim();
      if (captured) {
        setSentence(captured);
        void handleEvaluate({ text: captured });
      }
    }
  }, [handleEvaluate]);

  const startRecording = useCallback(async () => {
    if (isRecording) {
      stopRecording();
      return;
    }
    if (checking) return;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    transcriptRef.current = '';
    chunksRef.current = [];
    setLiveTranscript('');
    setErrorMsg('');
    setResult(null);
    setIsRecording(true);

    const SR = getSpeechRec();
    if (SR) {
      try {
        const rec = new SR();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (ev) => {
          let combined = '';
          for (let i = 0; i < ev.results.length; i++) {
            combined += ev.results[i][0].transcript + ' ';
          }
          const clean = combined.trim();
          transcriptRef.current = clean;
          setLiveTranscript(clean);
          setSentence(clean);
        };
        rec.onerror = () => {
          // Audio MediaRecorder handles fallback
        };
        rec.start();
        speechRecRef.current = rec;
      } catch {
        speechRecRef.current = null;
      }
    }

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm'
            : MediaRecorder.isTypeSupported('audio/mp4')
              ? 'audio/mp4'
              : '';

        const recorder = preferredMime
          ? new MediaRecorder(stream, { mimeType: preferredMime })
          : new MediaRecorder(stream);

        const actualMime = (recorder.mimeType || preferredMime || 'audio/webm').split(';')[0];

        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
        };

        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: actualMime });
          chunksRef.current = [];
          mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
          mediaStreamRef.current = null;
          mediaRecorderRef.current = null;
          setIsRecording(false);

          if (audioUrlRef.current) {
            URL.revokeObjectURL(audioUrlRef.current);
            audioUrlRef.current = null;
          }
          if (blob.size > 0) {
            const url = URL.createObjectURL(blob);
            audioUrlRef.current = url;
            setAudioUrl(url);
          }

          const spoken = transcriptRef.current.trim();
          if (spoken) {
            setSentence(spoken);
          }
          if (spoken || blob.size > 400) {
            void handleEvaluate({
              text: spoken || undefined,
              audioBlob: blob.size > 400 ? blob : undefined,
              audioMimeType: actualMime,
            });
          } else {
            setErrorMsg('لم يتم التقاط صوت واضح. اضغط على زر الميكروفون وقل جملتك بوضوح.');
          }
        };

        mediaRecorderRef.current = recorder;
        recorder.start();
      } catch {
        if (!speechRecRef.current) {
          setIsRecording(false);
          setErrorMsg('يرجى السماح بصلاحية الميكروفون أو كتابة الجملة مباشرة في الخانة أدناه.');
        }
      }
    } else if (!speechRecRef.current) {
      setIsRecording(false);
      setErrorMsg('التسجيل الصوتي غير مدعوم في هذا المتصفح، يمكنك كتابة الجملة مباشرة.');
    }
  }, [isRecording, checking, stopRecording, handleEvaluate]);

  const diffSegments =
    result && result.userSentence
      ? buildDiffSegments(result.userSentence, result.correctedEn, result.wrongParts)
      : [];

  const hasWordInDraft = sentence.trim().length > 0 && containsTargetWord(sentence, word.en);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-slate-100">
            <PenLine className="h-4 w-4 text-indigo-500" aria-hidden="true" />
            <span>بناء جملة باستخدام الكلمة (بالصوت أو بالكتابة)</span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            كوّن جملة إنجليزية من عندك يجب أن تحتوي حصراً على كلمة{' '}
            <span
              dir="ltr"
              className="inline-block rounded bg-indigo-50 px-1.5 py-0.5 font-en font-extrabold text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300"
            >
              {word.en}
            </span>{' '}
            وسيقوم الذكاء الاصطناعي بتصحيحها ووضع خط أحمر تحت أي خطأ.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {sentence.trim().length > 0 && (
            <span
              className={`rounded-lg px-2.5 py-1 text-[11px] font-bold ${
                hasWordInDraft
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                  : 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300'
              }`}
            >
              {hasWordInDraft ? `✓ تحتوي على «${word.en}»` : `أضف كلمة «${word.en}»`}
            </span>
          )}
        </div>
      </div>

      {/* Voice + Text Composer */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void handleEvaluate({ text: sentence });
        }}
        className="mt-4 space-y-3"
      >
        <div className="relative">
          <textarea
            dir="ltr"
            rows={2}
            value={sentence}
            disabled={checking}
            onChange={(e) => {
              setSentence(e.target.value);
              if (errorMsg) setErrorMsg('');
            }}
            aria-label={`اكتب جملة تحتوي على كلمة ${word.en}`}
            placeholder={`Write an English sentence using "${word.en}" or record with your voice...`}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-left font-en text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100 dark:focus:border-indigo-400 dark:focus:bg-slate-900"
          />
        </div>

        {isRecording && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 dark:border-rose-800/60 dark:bg-rose-950/30">
            <div className="flex items-center justify-between gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
              <span className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-600" />
                جاري الاستماع لجملتك... قل جملة تحتوي على «{word.en}» ثم اضغط إيقاف
              </span>
              <button
                type="button"
                onClick={stopRecording}
                className="inline-flex h-8 items-center gap-1 rounded-lg bg-rose-600 px-3 text-xs font-bold text-white hover:bg-rose-700"
              >
                <Square className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>إيقاف وتصحيح</span>
              </button>
            </div>
            {liveTranscript && (
              <p dir="ltr" className="mt-1.5 text-left font-en text-xs font-bold text-slate-700 dark:text-slate-200">
                {liveTranscript}
              </p>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={checking}
            onClick={() => void startRecording()}
            className={`inline-flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold text-white transition-colors disabled:opacity-50 ${
              isRecording
                ? 'bg-rose-600 hover:bg-rose-700'
                : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {isRecording ? (
              <>
                <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                <span>إيقاف التسجيل</span>
              </>
            ) : (
              <>
                <Mic className="h-4 w-4" aria-hidden="true" />
                <span>قل الجملة بصوتك</span>
              </>
            )}
          </button>

          <button
            type="submit"
            disabled={checking || isRecording || !sentence.trim()}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-xs font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-45"
          >
            <Send className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{checking ? 'جاري فحص الجملة...' : 'فحص وتصحيح الجملة'}</span>
          </button>

          {audioUrl && !isRecording && (
            <button
              type="button"
              onClick={() => {
                const a = new Audio(audioUrl);
                void a.play().catch(() => {});
              }}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>اسمع تسجيلك</span>
            </button>
          )}

          {(sentence || result || errorMsg) && !checking && !isRecording && (
            <button
              type="button"
              onClick={() => {
                setSentence('');
                setResult(null);
                setErrorMsg('');
              }}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>مسح</span>
            </button>
          )}
        </div>
      </form>

      {/* Strict Validation / Error Message */}
      {errorMsg && (
        <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-700 dark:border-rose-700/60 dark:bg-rose-950/35 dark:text-rose-300">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Result Card: Red Underlined Errors + Corrected Sentence Underneath */}
      {result && result.containsTargetWord && !checking && (
        <div
          className={`mt-4 space-y-3 rounded-xl border p-4 ${
            result.isCorrect
              ? 'border-emerald-300 bg-emerald-50/70 dark:border-emerald-700/60 dark:bg-emerald-950/25'
              : 'border-rose-300 bg-rose-50/50 dark:border-rose-700/60 dark:bg-rose-950/20'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-extrabold sm:text-sm">
              {result.isCorrect ? (
                <>
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  <span className="text-emerald-800 dark:text-emerald-300">
                    رائع! جملتك صحيحة تماماً واستخدمت «{word.en}» بإتقان
                  </span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-4 w-4 text-rose-600 dark:text-rose-400" aria-hidden="true" />
                  <span className="text-rose-800 dark:text-rose-300">
                    تم اكتشاف أخطاء في الجملة (موضّحة بالخط الأحمر)
                  </span>
                </>
              )}
            </div>
            <span
              className={`rounded-md px-2.5 py-0.5 font-code text-xs font-extrabold tabular-nums text-white ${
                result.score >= 85
                  ? 'bg-emerald-600'
                  : result.score >= 60
                    ? 'bg-amber-500'
                    : 'bg-rose-600'
              }`}
            >
              الدقة {result.score}%
            </span>
          </div>

          {/* Learner's Original Sentence with RED Underlines */}
          <div className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-700/80 dark:bg-slate-900/80">
            <div className="mb-1 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              جملتك:
            </div>
            <p
              dir="ltr"
              className="text-left font-en text-base leading-relaxed font-bold text-slate-900 dark:text-slate-100"
            >
              {diffSegments.map((seg, i) =>
                seg.isError && !result.isCorrect ? (
                  <span
                    key={i}
                    className="rounded bg-rose-500/15 px-1 text-rose-600 underline decoration-rose-500 decoration-wavy decoration-2 underline-offset-4 dark:text-rose-400 dark:decoration-rose-400"
                  >
                    {seg.text}
                  </span>
                ) : (
                  <span key={i}>{seg.text}</span>
                )
              )}
            </p>

            {/* Corrected Sentence Directly Underneath */}
            {!result.isCorrect && result.correctedEn && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 pt-3 dark:border-slate-700/80">
                <div>
                  <div className="text-[11px] font-extrabold text-emerald-700 dark:text-emerald-400">
                    الجملة بالطريقة الصحيحة:
                  </div>
                  <p
                    dir="ltr"
                    className="mt-0.5 text-left font-en text-base font-extrabold text-emerald-700 dark:text-emerald-300"
                  >
                    {result.correctedEn}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onSpeak(result.correctedEn)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-700/60 dark:bg-emerald-950/50 dark:text-emerald-300"
                >
                  <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>اسمع الصحيحة</span>
                </button>
              </div>
            )}
          </div>

          {result.explanationAr && (
            <p className="text-xs leading-relaxed font-semibold text-slate-700 dark:text-slate-200">
              <span className="font-extrabold">الشرح: </span>
              {result.explanationAr}
            </p>
          )}

          {result.betterExampleEn && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-indigo-200/70 bg-indigo-50/50 px-3 py-2 text-xs dark:border-indigo-800/50 dark:bg-indigo-950/30">
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 shrink-0 text-indigo-500" aria-hidden="true" />
                <span className="font-bold text-indigo-700 dark:text-indigo-300">مثال إضافي:</span>
                <span dir="ltr" className="font-en font-semibold text-slate-800 dark:text-slate-100">
                  {result.betterExampleEn}
                </span>
              </div>
              <button
                type="button"
                onClick={() => onSpeak(result.betterExampleEn)}
                className="inline-flex h-7 items-center gap-1 rounded-md bg-white px-2 text-[11px] font-bold text-indigo-700 hover:bg-indigo-50 dark:bg-slate-800 dark:text-indigo-300"
              >
                <Volume2 className="h-3 w-3" aria-hidden="true" />
                <span>نطق</span>
              </button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
