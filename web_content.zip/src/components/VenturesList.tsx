import { useGame } from '../context/GameContext';
import { VentureCard } from './VentureCard';
import { Users, Layers } from 'lucide-react';
import fantasyRealmKingdomImg from '../assets/images/fantasy_realm_kingdom_1791261375642.jpg';

export function VenturesList() {
  const { ventures, ventureStates } = useGame();

  const totalLevels = Object.values(ventureStates).reduce((sum, v) => sum + v.count, 0);
  const automatedCount = Object.values(ventureStates).filter((v) => v.managerHired).length;

  return (
    <div className="space-y-6">
      {/* Visual Kingdom Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-amber-900/40 shadow-xl bg-slate-900 max-h-48 md:max-h-56">
        <img
          src={fantasyRealmKingdomImg}
          alt="Fantasy Kingdom Realm"
          className="w-full h-48 md:h-56 object-cover object-center opacity-45 hover:opacity-55 transition-opacity"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-3">
          <div>
            <h2 className="font-cinzel text-xl sm:text-2xl md:text-3xl font-extrabold text-amber-200">
              Crown Estates & Guild Enterprises
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-0.5">
              Acquire workshops, hire Guildmasters for automated production, and unlock legendary speed multipliers!
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-300 shrink-0">
            <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/80 border border-slate-700/60 rounded-xl">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>{totalLevels} Total Levels</span>
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/80 border border-slate-700/60 rounded-xl">
              <Users className="w-3.5 h-3.5 text-emerald-400" />
              <span>{automatedCount} / {ventures.length} Automated</span>
            </span>
          </div>
        </div>
      </div>

      {/* Ventures Cards Grid */}
      <div className="grid grid-cols-1 gap-3.5">
        {ventures.map((venture) => (
          <VentureCard
            key={venture.id}
            venture={venture}
          />
        ))}
      </div>
    </div>
  );
}
