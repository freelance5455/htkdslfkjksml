import React, { useMemo, useState } from 'react';
import { Clock } from 'lucide-react';
import { ClanDashboardState } from '../shared/cocData';
import { computePlayerPeriodDeltas } from '../utils/clanAnalytics';
import { formatDateTimeRu } from '../utils/formatters';
import {
  SnapshotSeriesDef,
  SnapshotSeriesPoint,
  SnapshotTimeSeriesChart,
} from './ProgressCharts';

interface HistoryViewProps {
  state: ClanDashboardState;
  nowMs: number;
  onSelectPlayer: (tag: string) => void;
}

type HistoryRange = '24h' | '7d' | '30d' | '90d' | 'all';

const RANGE_OPTIONS: Array<{ id: HistoryRange; label: string; ms: number | null }> = [
  { id: '24h', label: '24 часа', ms: 24 * 60 * 60 * 1000 },
  { id: '7d', label: '7 дней', ms: 7 * 24 * 60 * 60 * 1000 },
  { id: '30d', label: '30 дней', ms: 30 * 24 * 60 * 60 * 1000 },
  { id: '90d', label: '90 дней', ms: 90 * 24 * 60 * 60 * 1000 },
  { id: 'all', label: 'Всё время', ms: null },
];

export const HistoryView: React.FC<HistoryViewProps> = ({
  state,
  nowMs,
  onSelectPlayer,
}) => {
  const [range, setRange] = useState<HistoryRange>('all');
  const [selectedPlayerTag, setSelectedPlayerTag] = useState<string>(
    () => state.players[0]?.tag ?? ''
  );

  const filteredSnapshots = useMemo(() => {
    const opt = RANGE_OPTIONS.find((r) => r.id === range);
    if (!opt || opt.ms === null) return state.snapshots;
    const cutoff = nowMs - opt.ms;
    return state.snapshots.filter((s) => new Date(s.timestamp).getTime() >= cutoff);
  }, [state.snapshots, range, nowMs]);

  const effectivePlayerTag = useMemo(() => {
    if (selectedPlayerTag && state.players.some((p) => p.tag === selectedPlayerTag)) {
      return selectedPlayerTag;
    }
    return state.players[0]?.tag ?? '';
  }, [selectedPlayerTag, state.players]);

  const clanPointsSeries: SnapshotSeriesDef[] = [
    { key: 'totalTrophies', label: 'Сумма трофеев участников', color: '#F59E0B' },
    { key: 'clanPoints', label: 'Очки клана', color: '#38BDF8' },
    { key: 'clanCapitalPoints', label: 'Очки столицы', color: '#10B981' },
  ];

  const donationsSeries: SnapshotSeriesDef[] = [
    { key: 'totalDonations', label: 'Отдано войск (сумма)', color: '#10B981' },
    { key: 'totalDonationsReceived', label: 'Получено войск (сумма)', color: '#A78BFA' },
  ];

  const membersWarSeries: SnapshotSeriesDef[] = [
    { key: 'memberCount', label: 'Участники', color: '#38BDF8' },
    { key: 'warWins', label: 'Победы в КВ', color: '#F59E0B' },
    { key: 'warLosses', label: 'Поражения в КВ', color: '#FB7185' },
  ];

  const clanSeriesPoints: SnapshotSeriesPoint[] = useMemo(() => {
    return filteredSnapshots.map((s) => ({
      id: s.id,
      timestamp: s.timestamp,
      values: {
        totalTrophies: s.totalTrophies,
        clanPoints: s.clanPoints,
        clanCapitalPoints: s.clanCapitalPoints,
        totalDonations: s.totalDonations,
        totalDonationsReceived: s.totalDonationsReceived,
        memberCount: s.memberCount,
        warWins: s.warWins,
        warLosses: s.warLosses,
      },
    }));
  }, [filteredSnapshots]);

  const playerPoints: SnapshotSeriesPoint[] = useMemo(() => {
    if (!effectivePlayerTag) return [];
    return filteredSnapshots
      .map((s) => {
        const entry = s.byPlayer[effectivePlayerTag];
        if (!entry) return null;
        return {
          id: `${s.id}-${effectivePlayerTag}`,
          timestamp: s.timestamp,
          values: {
            trophies: entry.trophies,
            donations: entry.donations,
            warStars: entry.warStars,
            heroesLevelSum: entry.heroesLevelSum ?? 0,
            troopsLevelSum: entry.troopsLevelSum ?? 0,
            compositeScore: entry.compositeScore ?? 0,
          },
        } as SnapshotSeriesPoint;
      })
      .filter((x): x is SnapshotSeriesPoint => x !== null);
  }, [filteredSnapshots, effectivePlayerTag]);

  const playerSeries: SnapshotSeriesDef[] = [
    { key: 'trophies', label: 'Трофеи', color: '#F59E0B' },
    { key: 'donations', label: 'Донаты', color: '#10B981' },
    { key: 'warStars', label: 'Звёзды КВ', color: '#38BDF8' },
    { key: 'compositeScore', label: 'Рейтинг (0–1000)', color: '#A78BFA' },
  ];

  // Activity table for all clan members in selected period
  const memberActivityRows = useMemo(() => {
    return state.players
      .map((p) => {
        const deltas = computePlayerPeriodDeltas(state.snapshots, p.tag, nowMs);
        const match = deltas.find((d) => d.periodId === range) ?? deltas[deltas.length - 1];
        return {
          player: p,
          period: match,
        };
      })
      .sort((a, b) => {
        const au = a.period?.available ? a.period.deltas.totalUpgradesCount : -1;
        const bu = b.period?.available ? b.period.deltas.totalUpgradesCount : -1;
        if (bu !== au) return bu - au;
        const ad = a.period?.available ? a.period.deltas.donations : 0;
        const bd = b.period?.available ? b.period.deltas.donations : 0;
        return bd - ad || b.player.trophies - a.player.trophies;
      });
  }, [state.players, state.snapshots, nowMs, range]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы начать накопление реальных исторических снимков и аналитику активности участников.
      </div>
    );
  }

  const firstSnapshotAt = state.snapshots[0]?.timestamp;

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Активность участников и снимки
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            {firstSnapshotAt
              ? `Сбор реальных снимков ведётся с ${formatDateTimeRu(firstSnapshotAt)} · Всего снимков: ${state.snapshots.length}`
              : 'История начинается с момента первого сохранения снимка клана'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start lg:self-auto">
          {RANGE_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setRange(opt.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                range === opt.id
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </section>

      <section className="flex items-start gap-3 rounded-lg border border-slate-800 bg-[#121824] px-4 py-3 text-xs text-slate-300">
        <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <span>
          Графики и приросты строятся строго по реально сохранённым снимкам из Supercell API (при подключении, ручном обновлении или автосинхронизации). Исторические данные до начала мониторинга отсутствуют в API и не достраиваются.
        </span>
      </section>

      {/* Member Activity & Development Comparison Table for Selected Range */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Активность и прирост участников ({RANGE_OPTIONS.find((r) => r.id === range)?.label})
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Сравнение первого и последнего снимка внутри выбранного окна времени
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                <th className="px-4 py-2.5">Игрок</th>
                <th className="px-3 py-2.5 text-right">TH</th>
                <th className="px-3 py-2.5 text-right">Улучшений</th>
                <th className="px-3 py-2.5 text-right">Герои (Δ ур.)</th>
                <th className="px-3 py-2.5 text-right">Войска (Δ ур.)</th>
                <th className="px-3 py-2.5 text-right">Трофеи</th>
                <th className="px-3 py-2.5 text-right">Донаты</th>
                <th className="px-3 py-2.5 text-right">Звёзды КВ</th>
                <th className="px-4 py-2.5 text-right">Опыт</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {memberActivityRows.map(({ player: p, period: pd }) => (
                <tr
                  key={p.tag}
                  onClick={() => onSelectPlayer(p.tag)}
                  className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                >
                  <td className="px-4 py-2.5 whitespace-nowrap">
                    <div className="font-medium text-slate-100">{p.name}</div>
                    <div className="font-mono text-[11px] text-slate-500">{p.tag}</div>
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                    {p.townHallLevel}
                    {pd?.available && pd.deltas.townHall > 0 && (
                      <span className="ml-1 text-emerald-400">(+{pd.deltas.townHall})</span>
                    )}
                  </td>
                  {!pd || !pd.available ? (
                    <td colSpan={7} className="px-3 py-2.5 text-right text-xs text-slate-500">
                      {pd?.reason ?? 'Недостаточно снимков'}
                    </td>
                  ) : (
                    <>
                      <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                        {pd.deltas.totalUpgradesCount > 0 ? `+${pd.deltas.totalUpgradesCount}` : '0'}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                        {pd.deltas.heroesLevels !== null
                          ? pd.deltas.heroesLevels > 0
                            ? `+${pd.deltas.heroesLevels}`
                            : pd.deltas.heroesLevels
                          : '—'}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                        {pd.deltas.troopsLevels !== null
                          ? pd.deltas.troopsLevels > 0
                            ? `+${pd.deltas.troopsLevels}`
                            : pd.deltas.troopsLevels
                          : '—'}
                      </td>
                      <td
                        className={`px-3 py-2.5 text-right font-mono tabular-nums ${
                          pd.deltas.trophies >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {pd.deltas.trophies > 0 ? `+${pd.deltas.trophies}` : pd.deltas.trophies}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                        +{pd.deltas.donations.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                        +{pd.deltas.warStars}★
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-300">
                        {pd.deltas.expLevel > 0 ? `+${pd.deltas.expLevel}` : '0'}
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Chart 1: Clan Trophies & Points */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Трофеи, очки клана и Столица
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Изменение ключевых рейтинговых показателей клана по снимкам ({filteredSnapshots.length})
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
            {clanPointsSeries.map((s) => (
              <span key={s.key} className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
                {s.label}
              </span>
            ))}
          </div>
        </div>
        <SnapshotTimeSeriesChart points={clanSeriesPoints} series={clanPointsSeries} height={260} />
      </section>

      {/* Charts 2 & 3 Split */}
      <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-100">
                Динамика донатов в клане
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                Суммарно отдано и получено войск участниками
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-300">
              {donationsSeries.map((s) => (
                <span key={s.key} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
                  {s.label}
                </span>
              ))}
            </div>
          </div>
          <SnapshotTimeSeriesChart points={clanSeriesPoints} series={donationsSeries} height={230} />
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-100">
                Численность и победы в войнах
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                Количество участников и счётчик побед/поражений в КВ
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
              {membersWarSeries.map((s) => (
                <span key={s.key} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
                  {s.label}
                </span>
              ))}
            </div>
          </div>
          <SnapshotTimeSeriesChart points={clanSeriesPoints} series={membersWarSeries} height={230} />
        </div>
      </section>

      {/* Chart 4: Individual Player Growth */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
        <div className="flex flex-col gap-3 border-b border-slate-800/80 pb-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Динамика отдельного игрока по снимкам
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Трофеи, донаты, звёзды КВ и общий рейтинг игрока
            </p>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={effectivePlayerTag}
              onChange={(e) => setSelectedPlayerTag(e.target.value)}
              className="rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              {state.players.map((p) => (
                <option key={p.tag} value={p.tag}>
                  {p.name} ({p.tag} · TH{p.townHallLevel})
                </option>
              ))}
            </select>
            {effectivePlayerTag && (
              <button
                type="button"
                onClick={() => onSelectPlayer(effectivePlayerTag)}
                className="rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs text-amber-400 hover:border-amber-500/60 whitespace-nowrap"
              >
                Профиль
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
          {playerSeries.map((s) => (
            <span key={s.key} className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
              {s.label}
            </span>
          ))}
        </div>

        <SnapshotTimeSeriesChart points={playerPoints} series={playerSeries} height={240} />
      </section>

      {/* Snapshot Ledger Table */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Журнал сохранённых снимков ({filteredSnapshots.length})
          </h2>
        </div>

        {filteredSnapshots.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            За выбранный период снимков не найдено. Нажмите «Обновить данные» в верхней панели или расширьте диапазон.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                  <th className="px-5 py-2.5">Дата и время</th>
                  <th className="px-3 py-2.5 text-right">Участники</th>
                  <th className="px-3 py-2.5 text-right">Очки клана</th>
                  <th className="px-3 py-2.5 text-right">Сумма трофеев</th>
                  <th className="px-3 py-2.5 text-right">Столица</th>
                  <th className="px-3 py-2.5 text-right">Донаты</th>
                  <th className="px-5 py-2.5 text-right">Победы КВ (серия)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {[...filteredSnapshots].reverse().map((snap) => (
                  <tr key={snap.id} className="hover:bg-slate-800/25 transition-colors">
                    <td className="px-5 py-2.5 font-mono text-xs text-slate-300 whitespace-nowrap">
                      {formatDateTimeRu(snap.timestamp)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {snap.memberCount}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                      {snap.clanPoints.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                      {snap.totalTrophies.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                      {snap.clanCapitalPoints.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {snap.totalDonations.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {snap.warWins} ({snap.warWinStreak})
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
