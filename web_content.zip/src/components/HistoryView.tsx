import React, { useMemo, useState } from 'react';
import {
  History,
  Search,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  PiggyBank,
  QrCode,
  Calendar,
  ExternalLink,
  Receipt,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { Transaction } from '../types';
import { formatRupiah } from '../utils/formatters';

interface HistoryViewProps {
  transactions: Transaction[];
  onSelectTransaction: (tx: Transaction) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  transactions,
  onSelectTransaction,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense' | 'savings'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Summary stats
  const stats = useMemo(() => {
    let totalIncome = 0;
    let totalExpense = 0;

    transactions.forEach((tx) => {
      if (tx.type === 'topup' || tx.type === 'qris_receive') {
        totalIncome += tx.amount;
      } else if (tx.type === 'qris_payment') {
        totalExpense += tx.amount;
      }
    });

    return { totalIncome, totalExpense, count: transactions.length };
  }, [transactions]);

  // Filtered transactions
  const filteredList = useMemo(() => {
    return transactions.filter((tx) => {
      // Type filter
      if (filterType === 'income' && !(tx.type === 'topup' || tx.type === 'qris_receive' || tx.type === 'to_wallet')) {
        return false;
      }
      if (filterType === 'expense' && tx.type !== 'qris_payment') {
        return false;
      }
      if (filterType === 'savings' && tx.type !== 'to_savings' && tx.type !== 'to_wallet') {
        return false;
      }

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          tx.title.toLowerCase().includes(q) ||
          tx.sourceAccount.toLowerCase().includes(q) ||
          tx.referenceCode.toLowerCase().includes(q) ||
          (tx.note && tx.note.toLowerCase().includes(q)) ||
          (tx.merchantName && tx.merchantName.toLowerCase().includes(q))
        );
      }

      return true;
    });
  }, [transactions, filterType, searchQuery]);

  const renderTxIcon = (tx: Transaction) => {
    switch (tx.type) {
      case 'topup':
      case 'qris_receive':
        return (
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <ArrowDownLeft className="w-5 h-5" />
          </div>
        );
      case 'qris_payment':
        return (
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
        );
      case 'to_savings':
        return (
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <PiggyBank className="w-5 h-5" />
          </div>
        );
      case 'to_wallet':
        return (
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <ArrowUpRight className="w-5 h-5" />
          </div>
        );
      default:
        return (
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">
              <History className="w-4 h-4 text-emerald-600" />
              <span>Buku Transaksi Digital</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              Riwayat Transaksi Siswa
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Catatan lengkap top up, pembayaran QRIS kantin, dan pergerakan tabungan.
            </p>
          </div>

          {/* Quick Stats Summary */}
          <div className="flex items-center gap-3">
            <div className="py-2.5 px-4 bg-emerald-50 border border-emerald-100 rounded-2xl">
              <span className="text-[10px] text-emerald-800 font-bold block flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-emerald-600" /> Total Masuk
              </span>
              <span className="text-xs sm:text-sm font-extrabold font-mono text-emerald-700">
                +{formatRupiah(stats.totalIncome)}
              </span>
            </div>

            <div className="py-2.5 px-4 bg-rose-50 border border-rose-100 rounded-2xl">
              <span className="text-[10px] text-rose-800 font-bold block flex items-center gap-1">
                <TrendingDown className="w-3 h-3 text-rose-600" /> Total Keluar
              </span>
              <span className="text-xs sm:text-sm font-extrabold font-mono text-rose-700">
                -{formatRupiah(stats.totalExpense)}
              </span>
            </div>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="mt-6 pt-5 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Segmented Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-2xl overflow-x-auto">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                filterType === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua ({transactions.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterType('income')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                filterType === 'income'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Top Up & Masuk
            </button>
            <button
              type="button"
              onClick={() => setFilterType('expense')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                filterType === 'expense'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              QRIS Belanja
            </button>
            <button
              type="button"
              onClick={() => setFilterType('savings')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                filterType === 'savings'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tabungan
            </button>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari transaksi / merchant..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Transaction List */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 shadow-xs">
        {filteredList.length === 0 ? (
          <div className="text-center py-12">
            <Receipt className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">Belum Ada Transaksi</p>
            <p className="text-xs text-slate-400 mt-1">
              Tidak ada catatan yang sesuai dengan filter atau pencarian saat ini.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredList.map((tx) => {
              const isIncome = tx.type === 'topup' || tx.type === 'qris_receive' || tx.type === 'to_wallet';

              return (
                <div
                  key={tx.id}
                  onClick={() => onSelectTransaction(tx)}
                  className="py-3.5 px-3 flex items-center justify-between gap-3 rounded-2xl hover:bg-slate-50 cursor-pointer transition-colors group"
                >
                  {/* Left: Icon & Title */}
                  <div className="flex items-center gap-3 min-w-0">
                    {renderTxIcon(tx)}

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate group-hover:text-emerald-700 transition-colors">
                          {tx.title}
                        </h4>
                        <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">
                          • {tx.referenceCode}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span>{tx.timestamp}</span>
                        <span>•</span>
                        <span className="truncate max-w-[150px] font-mono text-slate-600">
                          {tx.sourceAccount}
                        </span>
                      </div>

                      {tx.note && (
                        <p className="text-[11px] text-slate-400 italic truncate max-w-xs mt-0.5">
                          "{tx.note}"
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Nominal & Struk CTA */}
                  <div className="text-right shrink-0 flex items-center gap-3">
                    <div>
                      <span
                        className={`text-xs sm:text-sm font-bold font-mono block ${
                          isIncome ? 'text-emerald-600' : 'text-slate-900'
                        }`}
                      >
                        {isIncome ? '+' : '-'}{formatRupiah(tx.amount)}
                      </span>
                      <span className="text-[10px] text-emerald-600 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded">
                        Berhasil
                      </span>
                    </div>

                    <button
                      type="button"
                      className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors"
                      title="Lihat Struk Transaksi"
                    >
                      <Receipt className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
