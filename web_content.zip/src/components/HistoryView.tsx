import React, { useState } from "react";
import { Search, Trash2, Heart, Copy, Share2, Check, Clock, Filter, BookOpen } from "lucide-react";
import { GeneratedPoetry, AppSettings, GenerationMode } from "../types";
import { MODE_METADATA } from "../data/constants";

interface HistoryViewProps {
  history: GeneratedPoetry[];
  favorites: string[];
  settings: AppSettings;
  onToggleFavorite: (id: string) => void;
  onDeleteHistoryItem: (id: string) => void;
  onClearHistory: () => void;
  onSelectPoetry: (poetry: GeneratedPoetry) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  favorites,
  settings,
  onToggleFavorite,
  onDeleteHistoryItem,
  onClearHistory,
  onSelectPoetry
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState<string>("all");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Hassan's MisraSaaz AI",
          text: `${text}\n\n— Hassan's MisraSaaz AI (حسنؔ کا مصرع ساز)`
        });
      } catch {
        navigator.clipboard.writeText(text);
      }
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  const filteredHistory = history.filter((item) => {
    const matchesFilter = selectedFilter === "all" || item.mode === selectedFilter;
    const matchesSearch =
      searchQuery.trim() === "" ||
      item.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const fontClass = settings.selectedFont === "nastaliq" ? "font-urdu" : "font-urdu-sans";

  return (
    <div className="space-y-4 pb-20">
      {/* Top Controls Header */}
      <div className="bg-stone-900/90 rounded-2xl p-4 border border-emerald-900/40 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" />
            <h3 className="font-urdu-title text-xl text-amber-200 font-bold">
              تاریخچہ شاعری (Poetry History)
            </h3>
          </div>
          {history.length > 0 && (
            <button
              onClick={onClearHistory}
              id="clear-all-history-button"
              className="text-xs font-urdu-sans text-rose-400 hover:text-rose-300 px-2 py-1 rounded-lg hover:bg-rose-950/40 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>تمام صاف کریں</span>
            </button>
          )}
        </div>

        {/* Search Bar */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 text-stone-400 absolute right-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="موضوع یا شعر کے الفاظ تلاش کریں..."
            className="w-full pr-9 pl-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-200 text-sm font-urdu-sans focus:border-amber-400 focus:outline-none placeholder:text-stone-600"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-urdu-sans">
          <span className="text-stone-500 pl-1">
            <Filter className="w-3 h-3" />
          </span>
          {[
            { id: "all", label: "تمام (All)" },
            { id: "ghazal_shayari", label: "غزل و شاعری" },
            { id: "song_lyrics", label: "نغمہ نگاری" },
            { id: "bait_bazi", label: "بیت بازی" },
            { id: "rhyme_meter", label: "ردیف و قافیہ" }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id)}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
                selectedFilter === f.id
                  ? "bg-amber-500 text-stone-950 font-bold"
                  : "bg-stone-800 text-stone-400 hover:bg-stone-700"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* History Items List */}
      {filteredHistory.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-2xl bg-stone-900/40 border border-dashed border-stone-800">
          <BookOpen className="w-10 h-10 text-stone-600 mx-auto mb-2" />
          <p className="font-urdu-title text-lg text-stone-400">کوئی کلام محفوظ نہیں ہے</p>
          <p className="font-urdu-sans text-xs text-stone-500 mt-1">
            نئی غزل یا نغمہ تخلیق کریں، وہ خود بخود یہاں درج ہو جائے گی۔
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredHistory.map((item) => {
            const isFav = favorites.includes(item.id);
            const isCopied = copiedId === item.id;
            const meta = MODE_METADATA[item.mode];

            return (
              <div
                key={item.id}
                className="bg-stone-900/90 rounded-2xl p-4 border border-stone-800 hover:border-amber-500/40 transition-all shadow-md"
              >
                <div className="flex items-center justify-between border-b border-stone-800/80 pb-2 mb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-950/80 text-emerald-300 font-urdu-sans border border-emerald-800/50">
                      {meta?.badge || item.mode}
                    </span>
                    <span className="font-urdu-title font-bold text-amber-200">
                      {item.topic}
                    </span>
                  </div>
                  <span className="text-[10px] font-ui text-stone-500">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                </div>

                {/* Content */}
                <div
                  onClick={() => onSelectPoetry(item)}
                  className={`text-base md:text-lg text-amber-100/90 ${fontClass} whitespace-pre-line cursor-pointer hover:text-amber-200 transition-colors my-2 px-2`}
                >
                  {item.content.length > 280
                    ? item.content.slice(0, 280) + "..."
                    : item.content}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-800/60 mt-3">
                  <button
                    onClick={() => handleCopy(item.id, item.content)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-urdu-sans flex items-center gap-1"
                    title="کاپی کریں"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? "کاپی شد" : "کاپی"}</span>
                  </button>

                  <button
                    onClick={() => handleShare(item.content)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-urdu-sans flex items-center gap-1"
                    title="شیئر کریں"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>شیئر</span>
                  </button>

                  <button
                    onClick={() => onToggleFavorite(item.id)}
                    className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                      isFav
                        ? "bg-rose-950/60 border-rose-500/60 text-rose-300"
                        : "bg-stone-800 border-stone-700 text-stone-400 hover:text-rose-300"
                    }`}
                    title="پسندیدہ"
                  >
                    <Heart className={`w-3.5 h-3.5 ${isFav ? "fill-rose-500 text-rose-500" : ""}`} />
                  </button>

                  <button
                    onClick={() => onDeleteHistoryItem(item.id)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-rose-950/60 text-stone-400 hover:text-rose-400 transition-colors"
                    title="حذف کریں (Delete)"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
