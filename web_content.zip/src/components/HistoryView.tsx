import React, { useState } from 'react';
import { Trash2, ArrowRight, Play, Copy, Check, Calendar, Clock, Sparkles } from 'lucide-react';
import { ConversionRecord } from '../types';

interface HistoryViewProps {
  history: ConversionRecord[];
  onLoadRecord: (record: ConversionRecord) => void;
  onDeleteRecord: (id: string) => void;
  onClearHistory: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onLoadRecord,
  onDeleteRecord,
  onClearHistory,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState<string>('');

  const filteredHistory = history.filter((item) => {
    if (!searchFilter.trim()) return true;
    const term = searchFilter.toLowerCase();
    return (
      item.nyDateFormatted.toLowerCase().includes(term) ||
      item.nyTimeFormatted.toLowerCase().includes(term) ||
      item.nyTzAbbr.toLowerCase().includes(term) ||
      item.indiaTimeDisplay.toLowerCase().includes(term)
    );
  });

  const handleCopy = (item: ConversionRecord) => {
    const text = `Jaswanth Time Converter:\nNew York: ${item.nyFullDateDisplay} ${item.nyTimeDisplay} (${item.nyTzAbbr})\nIndia (IST): ${item.indiaFullDateDisplay} ${item.indiaTimeDisplay}\nOffset: IST is ${item.offsetDiffHours} ahead`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header card with summary */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Conversion History</h2>
            <p className="text-xs text-slate-500">
              {history.length === 0
                ? 'No conversions recorded yet'
                : `${history.length} saved conversion timestamps`}
            </p>
          </div>
          {history.length > 0 && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Delete all history items?')) {
                  onClearHistory();
                }
              }}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1"
            >
              <Trash2 size={13} />
              <span>Clear All</span>
            </button>
          )}
        </div>

        {/* Filter input */}
        {history.length > 3 && (
          <div className="mt-3">
            <input
              type="text"
              placeholder="Search history (e.g. 08:30, EDT)..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>
        )}
      </div>

      {/* Empty State */}
      {filteredHistory.length === 0 && (
        <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-slate-100">
          <div className="w-14 h-14 mx-auto rounded-full bg-blue-50 flex items-center justify-center text-blue-500 mb-3">
            <Clock className="w-7 h-7 stroke-[1.8]" />
          </div>
          <h3 className="font-bold text-slate-800 text-sm">No Recorded Conversions</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
            Whenever you press "Start from selected time" in the converter, the timestamp is automatically saved here for quick reference and session tracking.
          </p>
        </div>
      )}

      {/* History Items List */}
      <div className="space-y-3">
        {filteredHistory.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:border-blue-100 transition-all"
          >
            <div className="flex items-start justify-between gap-2 mb-2 pb-2 border-b border-slate-50">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Calendar size={13} />
                <span>Recorded {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="flex items-center gap-1">
                {/* Copy button */}
                <button
                  type="button"
                  onClick={() => handleCopy(item)}
                  className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                  title="Copy timing details"
                >
                  {copiedId === item.id ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                </button>
                {/* Delete button */}
                <button
                  type="button"
                  onClick={() => onDeleteRecord(item.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Delete record"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            {/* Time Comparison Row */}
            <div className="grid grid-cols-2 gap-3 mb-3">
              {/* NY Side */}
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100/80">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-semibold text-slate-600 flex items-center gap-1">
                    <span>🇺🇸</span> New York
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 bg-blue-100/80 text-blue-700 rounded">
                    {item.nyTzAbbr}
                  </span>
                </div>
                <div className="font-mono font-bold text-slate-900 text-sm">
                  {item.nyTimeDisplay}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {item.nyFullDateDisplay}
                </div>
              </div>

              {/* India Side */}
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100/80">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-semibold text-slate-600 flex items-center gap-1">
                    <span>🇮🇳</span> India
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 bg-amber-100/80 text-amber-700 rounded">
                    {item.indiaTzAbbr}
                  </span>
                </div>
                <div className="font-mono font-bold text-slate-900 text-sm">
                  {item.indiaTimeDisplay}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {item.indiaFullDateDisplay}
                </div>
              </div>
            </div>

            {/* Offset and Load CTA */}
            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-slate-500 text-[11px]">
                Offset: <strong className="text-slate-700 font-semibold">{item.offsetDiffHours}</strong> ahead in India
              </span>
              <button
                type="button"
                onClick={() => onLoadRecord(item)}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
              >
                <Play size={12} className="fill-blue-600" />
                <span>Load in Clocks</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
