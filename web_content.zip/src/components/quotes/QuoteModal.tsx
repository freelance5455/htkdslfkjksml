import React, { useState } from 'react';
import { BookQuote, Book, CustomSticker } from '../../types';
import { BOOK_REACTIONS, HIGHLIGHT_COLORS } from '../../constants/reactions';
import { X, Heart, Bookmark, Sparkles, Smile, Image as ImageIcon } from 'lucide-react';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveQuote: (quote: BookQuote) => void;
  books: Book[];
  initialQuote?: BookQuote | null;
  defaultBookId?: string;
  stickers?: CustomSticker[];
  onOpenStickerManager?: () => void;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  onSaveQuote,
  books,
  initialQuote,
  defaultBookId,
  stickers = [],
  onOpenStickerManager,
}) => {
  if (!isOpen) return null;

  const [bookId, setBookId] = useState(initialQuote?.bookId || defaultBookId || (books[0]?.id ?? ''));
  const [text, setText] = useState(initialQuote?.text || '');
  const [page, setPage] = useState<number | ''>(initialQuote?.page || '');
  const [location, setLocation] = useState(initialQuote?.location || '');
  const [color, setColor] = useState(initialQuote?.color || HIGHLIGHT_COLORS[0].hex);
  const [note, setNote] = useState(initialQuote?.note || '');
  const [reactionType, setReactionType] = useState<'emoji' | 'sticker'>(
    initialQuote?.customStickerUrl ? 'sticker' : 'emoji'
  );
  const [selectedEmoji, setSelectedEmoji] = useState(
    initialQuote?.reaction && !initialQuote?.customStickerUrl
      ? initialQuote.reaction
      : BOOK_REACTIONS[0].emoji + ' ' + BOOK_REACTIONS[0].label
  );
  const [selectedSticker, setSelectedSticker] = useState<CustomSticker | null>(() => {
    if (initialQuote?.customStickerId) {
      return stickers.find((s) => s.id === initialQuote.customStickerId) || null;
    }
    return stickers[0] || null;
  });
  const [favorite, setFavorite] = useState(initialQuote?.favorite || false);
  const [showAllReactions, setShowAllReactions] = useState(false);

  const selectedBook = books.find((b) => b.id === bookId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !bookId) return;

    let finalReaction = '';
    let finalStickerId: string | undefined = undefined;
    let finalStickerUrl: string | undefined = undefined;

    if (reactionType === 'sticker' && selectedSticker) {
      finalReaction = selectedSticker.name;
      finalStickerId = selectedSticker.id;
      finalStickerUrl = selectedSticker.dataUrl;
    } else {
      finalReaction = selectedEmoji;
    }

    const newQuote: BookQuote = {
      id: initialQuote?.id || 'quote-' + Date.now(),
      bookId,
      bookTitle: selectedBook?.title || 'Libro desconocido',
      author: selectedBook?.author || '',
      text: text.trim(),
      page: page === '' ? undefined : Number(page),
      location: location.trim() || undefined,
      color,
      note: note.trim() || undefined,
      reaction: finalReaction,
      customStickerId: finalStickerId,
      customStickerUrl: finalStickerUrl,
      favorite,
      createdAt: initialQuote?.createdAt || new Date().toISOString(),
    };

    onSaveQuote(newQuote);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl overflow-y-auto">
      <div className="w-full max-w-lg glass-panel rounded-3xl p-5 sm:p-6 border border-white/15 shadow-2xl my-auto animate-fadeIn max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-zinc-300" />
            <h3 className="text-base font-bold text-white tracking-tight font-['Syne']">
              {initialQuote ? 'Editar Frase' : 'Guardar Frase o Cita'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Book Selector */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Libro *</label>
            <select
              value={bookId}
              onChange={(e) => setBookId(e.target.value)}
              required
              className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 text-xs"
            >
              {books.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author}
                </option>
              ))}
            </select>
          </div>

          {/* Quote Text */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Texto de la frase *</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Escribe o pega aquí la cita que te inspiró..."
              required
              rows={3}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl p-3 text-white placeholder-zinc-500 focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 leading-relaxed font-serif text-sm"
            />
          </div>

          {/* Page & Location */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Página</label>
              <input
                type="number"
                value={page}
                onChange={(e) => setPage(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Ej. 142"
                min="1"
                className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Ubicación / Capítulo</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Ej. Cap. 4, Inicio"
                className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
          </div>

          {/* Color Subrayado */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1.5">Color del subrayado</label>
            <div className="flex items-center gap-2.5 flex-wrap">
              {HIGHLIGHT_COLORS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setColor(c.hex)}
                  title={c.label}
                  className={`w-7 h-7 rounded-full border transition-all ${
                    color === c.hex ? 'scale-125 border-white ring-2 ring-white/30' : 'border-transparent hover:scale-110'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          {/* Reacción: EMOJI o STICKER PERSONALIZADO (Section 41, 42, 43) */}
          <div className="space-y-2 pt-1 border-t border-white/10">
            <div className="flex items-center justify-between">
              <label className="text-zinc-300 font-semibold">Tipo de reacción</label>
              <div className="flex items-center gap-1 p-0.5 bg-white/[0.04] border border-white/10 rounded-lg">
                <button
                  type="button"
                  onClick={() => setReactionType('emoji')}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium transition-all flex items-center gap-1 ${
                    reactionType === 'emoji' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Smile className="w-3 h-3" />
                  <span>Emoji</span>
                </button>
                <button
                  type="button"
                  onClick={() => setReactionType('sticker')}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium transition-all flex items-center gap-1 ${
                    reactionType === 'sticker' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <ImageIcon className="w-3 h-3" />
                  <span>Sticker</span>
                </button>
              </div>
            </div>

            {reactionType === 'emoji' ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-zinc-400">Reacción activa: {selectedEmoji}</span>
                  <button
                    type="button"
                    onClick={() => setShowAllReactions(!showAllReactions)}
                    className="text-white hover:underline font-medium"
                  >
                    {showAllReactions ? 'Mostrar menos' : 'Ver todas (26)'}
                  </button>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap max-h-36 overflow-y-auto p-1.5 bg-white/[0.02] border border-white/10 rounded-xl">
                  {(showAllReactions ? BOOK_REACTIONS : BOOK_REACTIONS.slice(0, 8)).map((r) => {
                    const fullReaction = `${r.emoji} ${r.label}`;
                    const isSelected = selectedEmoji === fullReaction;
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setSelectedEmoji(fullReaction)}
                        className={`px-2.5 py-1 rounded-lg border text-[11px] flex items-center gap-1 transition-all ${
                          isSelected
                            ? 'bg-white/20 border-white/40 text-white font-semibold'
                            : 'bg-white/[0.03] border-white/10 text-zinc-300 hover:bg-white/[0.08]'
                        }`}
                      >
                        <span>{r.emoji}</span>
                        <span className="truncate max-w-[120px]">{r.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-zinc-400">
                    {selectedSticker ? `Sticker: ${selectedSticker.name}` : 'Selecciona un sticker'}
                  </span>
                  {onOpenStickerManager && (
                    <button
                      type="button"
                      onClick={onOpenStickerManager}
                      className="text-white hover:underline flex items-center gap-1 font-medium"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Gestionar stickers</span>
                    </button>
                  )}
                </div>

                {stickers.length === 0 ? (
                  <div className="p-4 rounded-xl border border-dashed border-white/15 text-center text-zinc-400">
                    <p className="mb-2">No tienes stickers importados aún.</p>
                    {onOpenStickerManager && (
                      <button
                        type="button"
                        onClick={onOpenStickerManager}
                        className="px-3 py-1 bg-white/10 hover:bg-white/15 text-white rounded-lg font-semibold"
                      >
                        Importar primer sticker
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-48 overflow-y-auto p-2 bg-white/[0.02] border border-white/10 rounded-2xl">
                    {stickers.map((stk) => {
                      const isSelected = selectedSticker?.id === stk.id;
                      return (
                        <button
                          key={stk.id}
                          type="button"
                          onClick={() => setSelectedSticker(stk)}
                          className={`aspect-square rounded-2xl p-2 border flex flex-col items-center justify-center transition-all ${
                            isSelected
                              ? 'bg-white/20 border-white shadow-md scale-105 ring-1 ring-white/30'
                              : 'bg-white/[0.04] border-white/10 hover:border-white/20'
                          }`}
                          title={stk.name}
                        >
                          <img
                            src={stk.dataUrl}
                            alt={stk.name}
                            className="w-12 h-12 object-contain"
                          />
                          <span className="text-[10px] text-zinc-400 truncate max-w-full mt-1">
                            {stk.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Note / Reflection */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Nota o reflexión personal</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="¿Por qué te marcó este pasaje? ¿Qué te hizo sentir o pensar?"
              rows={2}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl p-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
            />
          </div>

          {/* Favorite toggle */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-zinc-300 font-semibold">Marcar como favorita</span>
            <button
              type="button"
              onClick={() => setFavorite(!favorite)}
              className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs transition-all ${
                favorite
                  ? 'bg-white/20 border-white/40 text-white'
                  : 'bg-white/[0.04] border-white/10 text-zinc-400'
              }`}
            >
              <Heart className={`w-4 h-4 ${favorite ? 'fill-white text-white' : ''}`} />
              <span>{favorite ? 'Favorita' : 'Normal'}</span>
            </button>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-zinc-300 font-medium text-xs transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg active:scale-95 transition-all"
            >
              Guardar frase
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
