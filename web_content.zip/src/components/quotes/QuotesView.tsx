import React, { useState, useMemo } from 'react';
import { BookQuote, Book, CustomSticker } from '../../types';
import { EmptyState } from '../common/EmptyState';
import {
  Quote,
  Search,
  Heart,
  Plus,
  Trash2,
  Edit2,
  BookOpen,
  Filter,
  X,
} from 'lucide-react';

interface QuotesViewProps {
  quotes: BookQuote[];
  books: Book[];
  stickers?: CustomSticker[];
  onOpenAddQuote: () => void;
  onEditQuote: (quote: BookQuote) => void;
  onDeleteQuote: (quoteId: string) => void;
  onToggleFavoriteQuote: (quote: BookQuote) => void;
  onOpenBookDetail: (book: Book) => void;
}

export const QuotesView: React.FC<QuotesViewProps> = ({
  quotes,
  books,
  stickers = [],
  onOpenAddQuote,
  onEditQuote,
  onDeleteQuote,
  onToggleFavoriteQuote,
  onOpenBookDetail,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [bookFilter, setBookFilter] = useState<string>('ALL');
  const [favoriteOnly, setFavoriteOnly] = useState(false);
  const [colorFilter, setColorFilter] = useState<string>('ALL');
  const COLOR_FILTERS = [
    { id: 'blue', label: 'Azul', hex: '#3b82f6', aliases: ['#3b82f6', '#06b6d4', '#2563eb', '#00e5ff'] },
    { id: 'green', label: 'Verde', hex: '#22c55e', aliases: ['#22c55e', '#10b981', '#16a34a', '#4ade80'] },
    { id: 'purple', label: 'Morado', hex: '#a855f7', aliases: ['#a855f7', '#9333ea', '#c084fc'] },
    { id: 'yellow', label: 'Amarillo', hex: '#eab308', aliases: ['#eab308', '#facc15', '#f59e0b', '#fbbf24'] },
    { id: 'pink', label: 'Rosa', hex: '#ec4899', aliases: ['#ec4899', '#f472b6', '#f43f5e'] },
    { id: 'wine', label: 'Rojo vino', hex: '#881337', aliases: ['#881337', '#9f1239', '#7f1d1d', '#be123c'] },
  ];

  // Filtered quotes
  const filteredQuotes = useMemo(() => {
    return quotes.filter((q) => {
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchText = q.text.toLowerCase().includes(query);
        const matchNote = q.note?.toLowerCase().includes(query);
        const matchBook = q.bookTitle?.toLowerCase().includes(query);
        const matchAuthor = q.author?.toLowerCase().includes(query);
        if (!matchText && !matchNote && !matchBook && !matchAuthor) return false;
      }

      if (bookFilter !== 'ALL' && q.bookId !== bookFilter) return false;
      if (favoriteOnly && !q.favorite) return false;

      if (colorFilter !== 'ALL') {
        const activeColor = COLOR_FILTERS.find((cf) => cf.id === colorFilter);
        if (activeColor) {
          const qColor = (q.color || '').toLowerCase();
          const matches = qColor === activeColor.hex.toLowerCase() || activeColor.aliases.includes(qColor);
          if (!matches) return false;
        } else if (q.color !== colorFilter) {
          return false;
        }
      }

      return true;
    });
  }, [quotes, searchQuery, bookFilter, favoriteOnly, colorFilter]);

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
            Mis frases y subrayados
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            {quotes.length} {quotes.length === 1 ? 'pasaje guardado' : 'pasajes guardados'} de tus lecturas
          </p>
        </div>

        <button
          onClick={onOpenAddQuote}
          className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg active:scale-95 transition-all self-end sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nueva frase</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="glass-panel rounded-2xl p-4 border border-white/10 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -tranzinc-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por texto, notas o libro..."
            className="w-full bg-zinc-900 border border-white/15 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap text-xs">
          {/* Book Filter */}
          <select
            value={bookFilter}
            onChange={(e) => setBookFilter(e.target.value)}
            className="bg-zinc-900 border border-white/15 rounded-lg px-2.5 py-1.5 text-white focus:outline-none text-xs"
          >
            <option value="ALL">Todos los libros</option>
            {books.map((b) => (
              <option key={b.id} value={b.id}>
                {b.title}
              </option>
            ))}
          </select>

          {/* Favorite Toggle */}
          <button
            onClick={() => setFavoriteOnly(!favoriteOnly)}
            className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all ${
              favoriteOnly
                ? 'bg-white/20 border-white/40 text-white'
                : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${favoriteOnly ? 'fill-white text-white' : ''}`} />
            <span>Favoritas</span>
          </button>

          {/* Color Filter - Requirement 8: Azul, Verde, Morado, Amarillo, Rosa, Rojo vino */}
          <div className="flex items-center gap-1.5 ml-auto flex-wrap">
            <span className="text-zinc-400 text-[11px] font-medium mr-0.5">Color:</span>
            <button
              onClick={() => setColorFilter('ALL')}
              className={`px-2 py-0.5 rounded-full border text-[10px] font-medium transition-all ${
                colorFilter === 'ALL'
                  ? 'bg-white/20 border-white text-white shadow-sm'
                  : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
              }`}
              title="Todos los colores"
            >
              Todos
            </button>
            {COLOR_FILTERS.map((col) => {
              const isSelected = colorFilter === col.id;
              return (
                <button
                  key={col.id}
                  onClick={() => setColorFilter(isSelected ? 'ALL' : col.id)}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10.5px] transition-all ${
                    isSelected
                      ? 'bg-white/20 border-white text-white font-semibold ring-1 ring-white/40 shadow-sm'
                      : 'bg-white/[0.03] border-white/10 text-zinc-300 hover:text-white hover:bg-white/[0.08]'
                  }`}
                  title={`Filtrar por ${col.label}`}
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full border border-white/40 shadow-xs"
                    style={{ backgroundColor: col.hex }}
                  />
                  <span>{col.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* List of Quotes */}
      {filteredQuotes.length === 0 ? (
        <EmptyState
          icon={Quote}
          title={quotes.length === 0 ? 'Aún no tienes frases guardadas' : 'No hay frases que coincidan'}
          description={
            quotes.length === 0
              ? 'Guarda tus pasajes favoritos mientras lees para recordarlos siempre.'
              : 'Prueba cambiando o limpiando los filtros.'
          }
          actionLabel={quotes.length === 0 ? 'Crear primera frase' : undefined}
          onAction={quotes.length === 0 ? onOpenAddQuote : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredQuotes.map((q) => {
            const correspondingBook = books.find((b) => b.id === q.bookId);

            return (
              <div
                key={q.id}
                className="glass-panel-interactive rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between space-y-4 group relative overflow-hidden"
              >
                {/* Color highlight bar */}
                <div
                  className="absolute top-0 left-0 bottom-0 w-1.5"
                  style={{ backgroundColor: q.color || '#00e5ff' }}
                />

                <div className="space-y-3 pl-2">
                  {/* Book Reference & Location */}
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => correspondingBook && onOpenBookDetail(correspondingBook)}
                      className="text-left group/book flex items-center gap-1.5"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-zinc-300" />
                      <span className="text-xs font-semibold text-white/90 group-hover/book:text-white transition-colors truncate max-w-[200px]">
                        {q.bookTitle || correspondingBook?.title}
                      </span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      {q.page && (
                        <span className="text-[11px] font-mono text-zinc-400 bg-white/[0.04] px-2 py-0.5 rounded-md border border-white/[0.06]">
                          Pág. {q.page}
                        </span>
                      )}
                      <button
                        onClick={() => onToggleFavoriteQuote(q)}
                        className="p-1 text-zinc-400 hover:text-white transition-colors"
                        aria-label="Alternar favorita"
                      >
                        <Heart className={`w-4 h-4 ${q.favorite ? 'text-white fill-white' : ''}`} />
                      </button>
                    </div>
                  </div>

                  {/* Quote Body */}
                  <blockquote className="text-sm font-serif italic text-white/95 leading-relaxed pl-2 border-l-2 border-white/20 selectable-text">
                    "{q.text}"
                  </blockquote>

                  {/* Reaction / Sticker Tag (Requirement 4 & 9: Mayor tamaño visual conservando proporción y datos asociados) */}
                  {(() => {
                    const resolvedStickerUrl =
                      q.customStickerUrl || (q.customStickerId && stickers ? stickers.find((s) => s.id === q.customStickerId)?.dataUrl : undefined);

                    if (!q.reaction && !resolvedStickerUrl) return null;

                    return (
                      <div className="flex items-center gap-3 text-xs text-white font-medium bg-white/[0.06] border border-white/10 rounded-2xl p-2.5 w-fit shadow-md">
                        {resolvedStickerUrl ? (
                          <img
                            src={resolvedStickerUrl}
                            alt="Sticker"
                            className="w-14 h-14 rounded-xl object-contain drop-shadow"
                          />
                        ) : null}
                        <div className="flex flex-col">
                          {q.reaction && <span className="font-semibold text-white/95 text-xs">{q.reaction}</span>}
                          {(q.location || q.page) && (
                            <span className="text-[10.5px] text-zinc-400 font-mono">
                              {q.location || `Pág. ${q.page}`}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })()}

                  {/* Personal Note */}
                  {q.note && (
                    <div className="text-xs text-zinc-400 bg-white/[0.03] border border-white/[0.06] rounded-xl p-2.5 selectable-text">
                      <span className="font-semibold text-zinc-300 block mb-0.5">Nota:</span>
                      {q.note}
                    </div>
                  )}
                </div>

                {/* Footer Actions (Requirement 5: Botón Editar siempre visible y táctil) */}
                <div className="flex items-center justify-between pt-2 border-t border-white/[0.06] pl-2 text-[11px] text-zinc-500">
                  <span>
                    {new Date(q.createdAt).toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onEditQuote(q)}
                      className="px-2.5 py-1 rounded-lg bg-white/[0.06] hover:bg-white/15 text-zinc-200 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-medium"
                      title="Editar frase"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-zinc-300" />
                      <span>Editar</span>
                    </button>
                    <button
                      onClick={() => onDeleteQuote(q.id)}
                      className="p-1.5 rounded-lg bg-white/[0.04] hover:bg-white/15 text-zinc-400 hover:text-white transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
