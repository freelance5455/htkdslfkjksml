/**
 * GODEX v0.0.1 - AI Diff Viewer
 * Displays line-by-line additions and deletions with syntax highlights and metrics.
 */

import React, { useState } from 'react';
import { Sparkles, FileCode, Check, ArrowLeft, Plus, Minus } from 'lucide-react';
import { computeLineDiff } from '../services/diffEngine';

interface DiffViewerProps {
  originalFiles: Record<string, string>;
  currentFiles: Record<string, string>;
  activeFile: string;
  onClose: () => void;
}

export const DiffViewer: React.FC<DiffViewerProps> = ({
  originalFiles,
  currentFiles,
  activeFile,
  onClose
}) => {
  const [selectedFile, setSelectedFile] = useState(activeFile);

  const originalContent = originalFiles[selectedFile] || '';
  const currentContent = currentFiles[selectedFile] || '';

  const diff = computeLineDiff(originalContent, currentContent, selectedFile);
  const changedFiles = Object.keys(currentFiles).filter(
    path => (originalFiles[path] || '') !== currentFiles[path]
  );

  return (
    <div className="flex-1 h-full flex flex-col bg-[#090B10] border-r border-[#1C2230] overflow-hidden select-none font-mono">
      {/* Diff Header */}
      <div className="h-9 border-b border-[#1C2230] bg-[#0D1017] px-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex items-center gap-1 text-xs text-neutral-400 hover:text-cyan-300 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="text-[10px]">BACK_TO_EDITOR</span>
          </button>

          <div className="h-3 w-px bg-[#1C2230]" />

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="font-semibold text-neutral-200 text-xs">{selectedFile}</span>
            <span className="px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800 text-[9px] font-bold">
              +{diff.additions}
            </span>
            <span className="px-1.5 py-0.2 rounded bg-rose-950/80 text-rose-400 border border-rose-800 text-[9px] font-bold">
              -{diff.deletions}
            </span>
          </div>
        </div>

        {/* File Switcher */}
        {changedFiles.length > 1 && (
          <div className="flex items-center gap-1">
            {changedFiles.map(path => (
              <button
                key={path}
                onClick={() => setSelectedFile(path)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                  selectedFile === path
                    ? 'bg-[#151D2C] text-cyan-300 border border-[#232F46] font-semibold'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {path.split('/').pop()}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Diff Content Lines */}
      <div className="flex-1 overflow-y-auto font-mono text-xs leading-relaxed bg-[#08090D]">
        {diff.lines.map((line, idx) => {
          let bgClass = 'hover:bg-[#0D1119] text-neutral-300';
          let indicator = ' ';
          let markerColor = 'text-neutral-600';

          if (line.type === 'added') {
            bgClass = 'bg-emerald-950/40 text-emerald-200';
            indicator = '+';
            markerColor = 'text-emerald-400 font-bold';
          } else if (line.type === 'removed') {
            bgClass = 'bg-rose-950/40 text-rose-300 line-through opacity-80';
            indicator = '-';
            markerColor = 'text-rose-400 font-bold';
          }

          return (
            <div key={idx} className={`flex items-stretch border-b border-[#121620] ${bgClass}`}>
              {/* Line Numbers */}
              <div className="w-10 py-0.5 text-right pr-2 text-neutral-600 select-none text-[10px]">
                {line.oldLineNumber || ''}
              </div>
              <div className="w-10 py-0.5 text-right pr-2 text-neutral-600 select-none text-[10px] border-r border-[#19202E]">
                {line.newLineNumber || ''}
              </div>

              {/* Marker (+ / -) */}
              <div className={`w-6 py-0.5 text-center select-none ${markerColor}`}>
                {indicator}
              </div>

              {/* Code */}
              <div className="flex-1 py-0.5 px-2 whitespace-pre overflow-x-auto">
                {line.content || ' '}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
