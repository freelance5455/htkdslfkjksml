import type React from 'react';
import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, type HTMLMotionProps } from 'framer-motion';
import { Check } from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

interface RippleSpec {
  id: number;
  x: number;
  y: number;
  size: number;
}

export interface TactileButtonProps extends Omit<HTMLMotionProps<'button'>, 'children'> {
  children?: React.ReactNode;
  haptic?: boolean;
  flashSuccess?: boolean;
  successTrigger?: number | null;
}

export function TactileButton({
  className = '',
  children,
  haptic = true,
  flashSuccess = false,
  successTrigger = null,
  onPointerDown,
  onClick,
  ...props
}: TactileButtonProps) {
  const [ripples, setRipples] = useState<RippleSpec[]>([]);
  const [internalSuccess, setInternalSuccess] = useState(false);
  const [flyingCheckKey, setFlyingCheckKey] = useState<number | null>(null);
  const successTimerRef = useRef<number | null>(null);
  const checkTimerRef = useRef<number | null>(null);
  const prevTriggerRef = useRef<number | null>(successTrigger);

  const triggerSuccessVisual = () => {
    setInternalSuccess(true);
    setFlyingCheckKey(Date.now());
    if (successTimerRef.current !== null) window.clearTimeout(successTimerRef.current);
    if (checkTimerRef.current !== null) window.clearTimeout(checkTimerRef.current);
    successTimerRef.current = window.setTimeout(() => setInternalSuccess(false), 1000);
    checkTimerRef.current = window.setTimeout(() => setFlyingCheckKey(null), 650);
  };

  useEffect(() => {
    if (successTrigger !== null && successTrigger !== prevTriggerRef.current) {
      prevTriggerRef.current = successTrigger;
      triggerSuccessVisual();
    } else {
      prevTriggerRef.current = successTrigger;
    }
  }, [successTrigger]);

  useEffect(() => {
    return () => {
      if (successTimerRef.current !== null) window.clearTimeout(successTimerRef.current);
      if (checkTimerRef.current !== null) window.clearTimeout(checkTimerRef.current);
    };
  }, []);

  const handlePointerDown: React.PointerEventHandler<HTMLButtonElement> = (e) => {
    if (!props.disabled) {
      const rect = e.currentTarget.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 1.4;
      const x = e.clientX ? e.clientX - rect.left : rect.width / 2;
      const y = e.clientY ? e.clientY - rect.top : rect.height / 2;
      const id = Date.now() + Math.random();
      setRipples((prev) => [...prev.slice(-3), { id, x, y, size }]);
      window.setTimeout(() => {
        setRipples((prev) => prev.filter((r) => r.id !== id));
      }, 320);
    }
    onPointerDown?.(e);
  };

  const handleClick: React.MouseEventHandler<HTMLButtonElement> = (e) => {
    if (!props.disabled) {
      if (haptic) triggerHaptic(12);
      if (flashSuccess) triggerSuccessVisual();
    }
    onClick?.(e);
  };

  return (
    <motion.button
      whileHover={props.disabled ? undefined : { scale: 1.035 }}
      whileTap={props.disabled ? undefined : { scale: 0.93 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      onPointerDown={handlePointerDown}
      onClick={handleClick}
      className={`btn-shine relative shadow-[0_4px_12px_rgba(15,23,42,0.14)] dark:shadow-[0_4px_14px_rgba(0,0,0,0.45)] active:shadow-none cursor-pointer transition-colors duration-200 ${
        internalSuccess ? '!bg-emerald-500 !text-white !border-emerald-500' : ''
      } ${className}`}
      {...props}
    >
      {/* Circular touch ripple */}
      {ripples.map((r) => (
        <motion.span
          key={r.id}
          aria-hidden="true"
          initial={{ scale: 0, opacity: 0.45 }}
          animate={{ scale: 1.8, opacity: 0 }}
          transition={{ duration: 0.28, ease: 'easeOut' }}
          style={{
            left: r.x - r.size / 2,
            top: r.y - r.size / 2,
            width: r.size,
            height: r.size,
          }}
          className="pointer-events-none absolute rounded-full bg-white/45"
        />
      ))}

      {/* Flying mini checkmark on success */}
      <AnimatePresence>
        {flyingCheckKey !== null && (
          <motion.span
            key={flyingCheckKey}
            aria-hidden="true"
            initial={{ opacity: 1, y: 0, scale: 0.7 }}
            animate={{ opacity: 0, y: -26, scale: 1.25 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: 'easeOut' }}
            className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex items-center justify-center w-5 h-5 rounded-full bg-emerald-400 text-white shadow-sm"
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
          </motion.span>
        )}
      </AnimatePresence>

      {children}
    </motion.button>
  );
}

export function AdminButton({
  className = '',
  children,
  onClick,
  ...props
}: Omit<HTMLMotionProps<'button'>, 'children'> & { children?: React.ReactNode }) {
  const handleClick: React.MouseEventHandler<HTMLButtonElement> = (e) => {
    if (!props.disabled) triggerHaptic(10);
    onClick?.(e);
  };

  return (
    <motion.button
      whileHover={props.disabled ? undefined : { scale: 1.03 }}
      whileTap={props.disabled ? undefined : { scale: 0.95 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      onClick={handleClick}
      className={`btn-admin-shine shadow-sm active:shadow-none cursor-pointer ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}

export function InteractiveCard({
  className = '',
  children,
  ...props
}: Omit<HTMLMotionProps<'article'>, 'children'> & { children?: React.ReactNode }) {
  return (
    <motion.article
      whileHover={{ scale: 1.012, y: -2 }}
      whileTap={{ scale: 0.985, rotate: [0, -0.5, 0.5, 0] }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className={className}
      {...props}
    >
      {children}
    </motion.article>
  );
}
