import { Button } from "@/components/ui/button";
import { useSubscriptions } from "@/lib/subscriptions";
import type { ChannelSummary } from "@/lib/youtube/types";
import { Check } from "lucide-react";
import { useEffect, useState } from "react";

export function SubscribeButton({
  channel,
  size = "sm",
}: {
  channel: ChannelSummary;
  size?: "sm" | "default";
}) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const isSubscribed = useSubscriptions((s) => s.isSubscribed(channel.id));
  const toggle = useSubscriptions((s) => s.toggle);

  const subscribed = ready && isSubscribed;

  return (
    <Button
      type="button"
      size={size}
      variant={subscribed ? "subscribed" : "subscribe"}
      className="shrink-0"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle(channel);
      }}
      aria-pressed={subscribed}
      aria-label={subscribed ? "Unsubscribe" : "Subscribe"}
    >
      {subscribed ? (
        <>
          <Check />
          Subscribed
        </>
      ) : (
        "Subscribe"
      )}
    </Button>
  );
}
