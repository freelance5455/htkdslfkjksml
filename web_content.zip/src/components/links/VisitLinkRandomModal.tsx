import React, { useState, useEffect } from 'react';
import { 
  X, 
  ExternalLink, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Gift, 
  RefreshCw, 
  CheckCircle2, 
  ArrowRight,
  Globe,
  Coins
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { getRandomLink, rollRandomReward, RandomLinkItem } from '../../services/randomLinksLibrary';

interface VisitLinkRandomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVisited?: (coins: number) => void;
}

export const VisitLinkRandomModal: React.FC<VisitLinkRandomModalProps> = ({
  isOpen,
  onClose,
  onVisited,
}) => {
  const { currentUser, adjustUserCoins } = useApp();

  const [currentLink, setCurrentLink] = useState<RandomLinkItem>(getRandomLink());
  const [step, setStep] = useState<'browse' | 'rolling' | 'claimed'>('browse');
  const [visitedExternal, setVisitedExternal] = useState(false);
  const [timerLeft, setTimerLeft] = useState(10);
  const [rolledCoins, setRolledCoins] = useState(0);

  // Daily visit counter
  const [dailyVisitsCount, setDailyVisitsCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('taskearn_daily_link_visits_count');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    if (isOpen) {
      setCurrentLink(getRandomLink());
      setStep('browse');
      setVisitedExternal(false);
      setTimerLeft(10);
      setRolledCoins(0);
    }
  }, [isOpen]);

  // Countdown timer when external link is visited
  useEffect(() => {
    if (!isOpen || !visitedExternal || step !== 'browse') return;

    if (timerLeft <= 0) {
      setStep('rolling');
      revealRandomCoins();
      return;
    }

    const interval = setInterval(() => {
      setTimerLeft((prev) => {
        if (prev <= 1) {
          setStep('rolling');
          revealRandomCoins();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, visitedExternal, step, timerLeft]);

  const handleOpenLink = () => {
    setVisitedExternal(true);
    window.open(currentLink.url, '_blank', 'noopener,noreferrer');
  };

  const revealRandomCoins = () => {
    if (!currentUser) return;

    const awarded = rollRandomReward(currentLink.minCoins, currentLink.maxCoins);
    setRolledCoins(awarded);

    adjustUserCoins(
      currentUser.id,
      awarded,
      `Random Link Visit: ${currentLink.domain}`
    );

    const newCount = dailyVisitsCount + 1;
    setDailyVisitsCount(newCount);
    localStorage.setItem('taskearn_daily_link_visits_count', newCount.toString());

    confetti({
      particleCount: 90,
      spread: 70,
      origin: { y: 0.65 },
    });

    if (onVisited) {
      onVisited(awarded);
    }

    setTimeout(() => {
      setStep('claimed');
    }, 1000);
  };

  const handleNextRandomLink = () => {
    setCurrentLink(getRandomLink());
    setStep('browse');
    setVisitedExternal(false);
    setTimerLeft(10);
    setRolledCoins(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1 pr-6">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
              <Gift className="w-3 h-3" />
              <span>Random Earning Link</span>
            </span>
            <span className="text-xs font-black text-emerald-400">
              Win 20 – 100 Coins
            </span>
          </div>
          <h2 className="text-base font-black text-white">
            Visit Link & Earn Random Coins
          </h2>
          <p className="text-[11px] text-slate-400">
            Completed Today: <strong className="text-emerald-400">{dailyVisitsCount} visits</strong> • Unlimited Daily
          </p>
        </div>

        {/* Current Random Link Card */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-bold text-slate-400">
                {currentLink.category}
              </span>
              <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span className="truncate">{currentLink.title}</span>
              </h3>
              <p className="text-[11px] font-mono text-slate-400">
                {currentLink.domain}
              </p>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[10px] text-amber-400 block font-bold">Random Reward</span>
              <span className="text-xs font-black text-white">
                +{currentLink.minCoins} to +{currentLink.maxCoins}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {currentLink.description}
          </p>

          <div className="pt-1 flex items-center justify-between text-[10px] text-slate-500 border-t border-slate-850">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>Safe verified sponsor destination</span>
            </span>
            <span>Browse 10s</span>
          </div>
        </div>

        {/* Action States */}
        {step === 'browse' && (
          <div className="space-y-3">
            {visitedExternal ? (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-center">
                <div className="flex items-center justify-center gap-2 text-xs text-slate-300 font-semibold">
                  <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                  <span>Browsing & verifying visit... {timerLeft}s remaining</span>
                </div>

                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-400 rounded-full transition-all duration-300"
                    style={{ width: `${Math.round(((10 - timerLeft) / 10) * 100)}%` }}
                  />
                </div>
                <p className="text-[10px] text-slate-500">
                  Keep link open or return when timer hits 0 to roll random coins!
                </p>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleOpenLink}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:opacity-95 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Visit Link & Unlock Random Coins</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleNextRandomLink}
              disabled={visitedExternal}
              className="w-full py-2 rounded-xl text-slate-400 hover:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:opacity-40"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Shuffle Another Random Link</span>
            </button>
          </div>
        )}

        {step === 'rolling' && (
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-3 animate-in zoom-in-95 duration-200">
            <Gift className="w-10 h-10 text-amber-400 mx-auto animate-bounce" />
            <div className="space-y-1">
              <h3 className="text-base font-black text-white">
                Rolling Your Random Coins...
              </h3>
              <p className="text-xs text-amber-400 font-bold animate-pulse">
                Unlocking Lucky Bonus Box!
              </p>
            </div>
          </div>
        )}

        {step === 'claimed' && (
          <div className="text-center space-y-3 py-2 animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30">
              <Sparkles className="w-8 h-8 text-amber-400 animate-spin" />
            </div>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Lucky Random Reward
              </span>
              <h3 className="text-2xl font-black text-white pt-1">
                +{rolledCoins} Coins Won!
              </h3>
              <p className="text-xs text-emerald-400 font-bold">
                ≈ ₹{(rolledCoins / 100).toFixed(2)} INR Credited to Wallet
              </p>
              <p className="text-[11px] text-slate-400">
                You browsed <strong>{currentLink.domain}</strong> and verified your visit.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleNextRandomLink}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs hover:opacity-90 cursor-pointer shadow-md flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <span>Visit Another Link (+Coins)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-3 rounded-xl border border-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
