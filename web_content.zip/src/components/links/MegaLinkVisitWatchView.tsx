import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Clock, 
  ExternalLink, 
  Sparkles, 
  Coins, 
  CheckCircle2, 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  ShieldCheck, 
  Check, 
  Search,
  Filter,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  RANDOM_LINKS_CATALOG, 
  TOTAL_LINKS_CATALOG_COUNT, 
  WATCH_TIME_5_MINUTES_SECONDS,
  RandomLinkItem 
} from '../../services/randomLinksLibrary';

export const MegaLinkVisitWatchView: React.FC = () => {
  const { currentUser, adjustUserCoins, language } = useApp();
  const [selectedLink, setSelectedLink] = useState<RandomLinkItem>(RANDOM_LINKS_CATALOG[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // 5 Minutes Watch Timer state
  const [secondsRemaining, setSecondsRemaining] = useState<number>(WATCH_TIME_5_MINUTES_SECONDS);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [hasVisitedLink, setHasVisitedLink] = useState<boolean>(false);
  const [claimedSessionIds, setClaimedSessionIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_claimed_link_visits');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const totalRequiredSeconds = WATCH_TIME_5_MINUTES_SECONDS; // 300 seconds (5 minutes)

  // Countdown effect
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            setIsCompleted(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, secondsRemaining]);

  const handleStartWatch = () => {
    // Open link in new tab
    if (selectedLink.url) {
      window.open(selectedLink.url, '_blank', 'noopener,noreferrer');
    }
    setHasVisitedLink(true);
    setIsTimerRunning(true);
  };

  const handlePauseResume = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const handleFastTestWatch = () => {
    // Jump timer to completed for instant testing
    setSecondsRemaining(0);
    setIsTimerRunning(false);
    setIsCompleted(true);
    setHasVisitedLink(true);
  };

  const handleClaimReward = () => {
    if (!currentUser) return;
    const rewardCoins = 85; // guaranteed 5-minute watch reward
    adjustUserCoins(
      currentUser.id,
      rewardCoins, 
      `5-Min Link Watch Reward: ${selectedLink.title}`
    );
    const updated = [...claimedSessionIds, `${selectedLink.id}-${Date.now()}`];
    setClaimedSessionIds(updated);
    try {
      localStorage.setItem('taskearn_claimed_link_visits', JSON.stringify(updated));
    } catch {
      // ignore
    }
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });
    // Reset for next link
    setIsCompleted(false);
    setSecondsRemaining(WATCH_TIME_5_MINUTES_SECONDS);
    setHasVisitedLink(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.min(
    100, 
    Math.round(((totalRequiredSeconds - secondsRemaining) / totalRequiredSeconds) * 100)
  );

  const filteredLinks = RANDOM_LINKS_CATALOG.filter(link => 
    !searchQuery || 
    link.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    link.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    link.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-400" />
                100,000+ Verified Links
              </span>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-400" />
                5 Minutes Watch
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <span>{language === 'bn' ? '১০০,০০০+ লিংক ভিজিট ও ৫ মিনিট ওয়াচ' : '100,000+ Link Visit & 5-Min Watch Hub'}</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'bn'
                ? 'স্পনসরড লিংক ভিজিট করুন, ৫ মিনিট ব্রাউজ করুন এবং নিশ্চিত ৮৫ কয়েন ক্লেইম করুন।'
                : 'Visit sponsored web destinations, stay for 5 minutes, and collect +85 Coins automatically!'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2 rounded-xl border border-emerald-500/20 self-start sm:self-auto">
            <Coins className="w-4 h-4 text-amber-400" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-bold">Watch Reward</span>
              <span className="text-xs font-black text-amber-300">+85 Coins / 5 Mins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Watch Session Box */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-emerald-500/40 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20">
              Active Destination • {selectedLink.category}
            </span>
            <h3 className="text-base font-black text-white mt-1">
              {selectedLink.title}
            </h3>
            <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
              <span className="text-emerald-400 font-mono">{selectedLink.domain}</span>
              <span>•</span>
              <span className="truncate max-w-xs">{selectedLink.description}</span>
            </p>
          </div>

          <a
            href={selectedLink.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setHasVisitedLink(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto border border-slate-700 cursor-pointer"
          >
            <span>{language === 'bn' ? 'ওয়েবসাইটে যান' : 'Visit Website'}</span>
            <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
          </a>
        </div>

        {/* 5-Minute Timer Display HUD */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col items-center justify-center space-y-3 text-center">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-bold uppercase tracking-wider">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>{language === 'bn' ? '৫ মিনিট সময় কাউন্টডাউন' : '5 Minutes Watch Timer'}</span>
          </div>

          <div className="font-mono text-3xl sm:text-4xl font-black tracking-widest text-emerald-400 drop-shadow-[0_0_15px_rgba(16,185,129,0.3)]">
            {formatTime(secondsRemaining)}
          </div>

          {/* Progress Bar */}
          <div className="w-full max-w-md space-y-1">
            <div className="flex justify-between text-[11px] text-slate-400 font-bold">
              <span>{progressPercent}% {language === 'bn' ? 'সম্পন্ন' : 'Completed'}</span>
              <span>{Math.floor((totalRequiredSeconds - secondsRemaining) / 60)}m / 5m</span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap justify-center pt-2">
            {!isCompleted ? (
              <>
                {!isTimerRunning ? (
                  <button
                    onClick={handleStartWatch}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/30 active:scale-95 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{hasVisitedLink ? (language === 'bn' ? 'টাইমার পুনরায় চালু' : 'Resume 5-Min Timer') : (language === 'bn' ? 'ভিজিট ও ৫ মিনিট শুরু' : 'Visit & Start 5-Min Watch')}</span>
                  </button>
                ) : (
                  <button
                    onClick={handlePauseResume}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 cursor-pointer border border-slate-700"
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'পজ করুন' : 'Pause'}</span>
                  </button>
                )}

                {/* Instant preview test helper */}
                <button
                  type="button"
                  onClick={handleFastTestWatch}
                  className="px-3 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center gap-1 cursor-pointer"
                  title="Fast test to simulate 5-min completion"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'bn' ? 'ফাস্ট টেস্ট (Instant)' : 'Fast Test'}</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleClaimReward}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 font-black text-sm flex items-center gap-2 cursor-pointer shadow-xl shadow-amber-500/20 animate-pulse hover:scale-105 transition-all"
              >
                <Coins className="w-5 h-5 text-slate-950" />
                <span>{language === 'bn' ? '🎉 ৮৫ কয়েন ক্লেইম করুন (Claim +85)' : '🎉 Claim 85 Coins Reward'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 100,000+ Links Catalog Selector */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-black uppercase text-slate-300 tracking-wider">
            {language === 'bn' ? '১০০,০০০+ লিংক ক্যাটালগ থেকে পছন্দ করুন' : 'Choose from 100,000+ Link Library'}
          </h4>
          <span className="text-[11px] text-emerald-400 font-bold">
            {TOTAL_LINKS_CATALOG_COUNT.toLocaleString()}+ Links
          </span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'bn' ? 'লিংক বা বিষয় খুঁজুন...' : 'Search links catalog...'}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Links list */}
        <div className="space-y-2">
          {filteredLinks.map((link) => {
            const isCurrent = selectedLink.id === link.id;
            return (
              <div
                key={link.id}
                onClick={() => {
                  setSelectedLink(link);
                  setSecondsRemaining(WATCH_TIME_5_MINUTES_SECONDS);
                  setIsTimerRunning(false);
                  setIsCompleted(false);
                }}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 cursor-pointer ${
                  isCurrent
                    ? 'bg-emerald-950/40 border-emerald-500/60 shadow-md shadow-emerald-500/10'
                    : 'bg-slate-900/70 hover:bg-slate-850 border-slate-800'
                }`}
              >
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {link.category}
                    </span>
                    <span className="text-[11px] font-mono text-emerald-400 truncate">
                      {link.domain}
                    </span>
                  </div>
                  <h5 className="text-xs font-bold text-slate-100 truncate">
                    {link.title}
                  </h5>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-black text-amber-400">
                    +85 Coins
                  </span>
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isCurrent ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isCurrent ? <Check className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
