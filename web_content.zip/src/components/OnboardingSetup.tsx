import React from 'react';
import {
  Camera,
  CheckCircle2,
  Clipboard,
  Globe,
  Mic,
} from 'lucide-react';
import { NexcodeLogo } from './NexcodeLogo';
import type { PermissionStatusMap } from '../types';

const LANGUAGES = [
  'English',
  'Roman Urdu',
  'Urdu',
  'Hindi',
  'Arabic',
  'Spanish',
  'French',
  'German',
  'Japanese',
];

interface OnboardingSetupProps {
  language: string;
  onChangeLanguage: (lang: string) => void;
  permissions: PermissionStatusMap;
  onRequestMicrophone: () => void;
  onRequestClipboard: () => void;
  onRequestScreenOrCamera: () => void;
  onRequestAllAndContinue: () => void;
}

export const OnboardingSetup: React.FC<OnboardingSetupProps> = ({
  language,
  onChangeLanguage,
  permissions,
  onRequestMicrophone,
  onRequestClipboard,
  onRequestScreenOrCamera,
  onRequestAllAndContinue,
}) => {
  return (
    <div className="min-h-screen bg-black text-zinc-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-950 p-6 space-y-6">
        <div className="flex items-center gap-3.5">
          <NexcodeLogo size={42} />
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
              NEXCODE AI
            </h1>
            <p className="text-xs text-zinc-400">
              Allow permissions below to open Chat &amp; Voice Call.
            </p>
          </div>
        </div>

        {/* Permissions List */}
        <div className="space-y-2.5">
          <p className="text-xs font-medium text-zinc-300">Permissions</p>

          <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-zinc-800 bg-black">
            <div className="flex items-center gap-3">
              <Mic className="w-4 h-4 text-zinc-300 shrink-0" />
              <div>
                <p className="text-sm font-medium text-zinc-100">Microphone</p>
                <p className="text-[11px] text-zinc-500">For voice calls</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onRequestMicrophone}
              className="px-3 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-xs font-medium text-zinc-100 cursor-pointer shrink-0"
            >
              {permissions.microphone === 'granted' ? (
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Allowed
                </span>
              ) : (
                'Allow'
              )}
            </button>
          </div>

          <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-zinc-800 bg-black">
            <div className="flex items-center gap-3">
              <Camera className="w-4 h-4 text-zinc-300 shrink-0" />
              <div>
                <p className="text-sm font-medium text-zinc-100">Cam &amp; Screen Sharing</p>
                <p className="text-[11px] text-zinc-500">For live camera &amp; screen vision in calls</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onRequestScreenOrCamera}
              className="px-3 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-xs font-medium text-zinc-100 cursor-pointer shrink-0"
            >
              {permissions.screenShare === 'active' || permissions.screenShare === 'granted' ? (
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Allowed
                </span>
              ) : (
                'Allow'
              )}
            </button>
          </div>

          <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-zinc-800 bg-black">
            <div className="flex items-center gap-3">
              <Clipboard className="w-4 h-4 text-zinc-300 shrink-0" />
              <div>
                <p className="text-sm font-medium text-zinc-100">Clipboard</p>
                <p className="text-[11px] text-zinc-500">Copy generated code snippets</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onRequestClipboard}
              className="px-3 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-xs font-medium text-zinc-100 cursor-pointer shrink-0"
            >
              {permissions.clipboard === 'granted' ? (
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Allowed
                </span>
              ) : (
                'Allow'
              )}
            </button>
          </div>
        </div>

        {/* Language */}
        <div className="space-y-2">
          <label
            htmlFor="setup-language"
            className="flex items-center gap-2 text-xs font-medium text-zinc-300"
          >
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>Chat Language</span>
          </label>
          <select
            id="setup-language"
            value={language}
            onChange={(e) => onChangeLanguage(e.target.value)}
            className="w-full rounded-lg border border-zinc-800 bg-black px-3 py-2.5 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang} value={lang}>
                {lang}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={onRequestAllAndContinue}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-purple-600 hover:brightness-110 text-white text-sm font-medium transition-all cursor-pointer"
        >
          Continue to Chat
        </button>
      </div>
    </div>
  );
};
