import React, { useState, useEffect } from "react";
import {
  Wifi,
  WifiOff,
  Cloud,
  CloudOff,
  RefreshCw,
  CheckCircle2,
  Database,
  Cpu,
  Layers,
  Sparkles,
  Info
} from "lucide-react";
import { getOfflineQueue, clearOfflineQueue } from "../utils/offlineQueue";

interface OfflineSyncBadgeProps {
  onTriggerSync?: () => void;
  isSyncing?: boolean;
}

export const OfflineSyncBadge: React.FC<OfflineSyncBadgeProps> = ({
  onTriggerSync,
  isSyncing = false,
}) => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [queueCount, setQueueCount] = useState<number>(0);
  const [showDetails, setShowDetails] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    const checkQueue = () => {
      const queue = getOfflineQueue();
      setQueueCount(queue.length);
    };

    checkQueue();
    const interval = setInterval(checkQueue, 3000);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="relative inline-block">
      {/* Network & Local DB Status Pill Badge */}
      <button
        onClick={() => setShowDetails(!showDetails)}
        className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shadow-2xs ${
          isOnline
            ? "bg-teal-500/10 border-teal-500/30 text-teal-700 dark:text-teal-300 hover:bg-teal-500/20"
            : "bg-amber-500/15 border-amber-500/30 text-amber-800 dark:text-amber-300 hover:bg-amber-500/20"
        }`}
      >
        <div className="relative flex items-center justify-center">
          {isOnline ? (
            <Wifi className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
          ) : (
            <WifiOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          )}
          <span
            className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${
              isOnline ? "bg-teal-500 animate-pulse" : "bg-amber-500"
            }`}
          />
        </div>

        <span className="hidden sm:inline">
          {isOnline ? "Hibrit Senkronize" : "Çevrimdışı (Yerel DB)"}
        </span>

        {queueCount > 0 && (
          <span className="bg-amber-500 text-white font-mono text-[10px] px-1.5 py-0.2 rounded-full font-extrabold animate-bounce">
            {queueCount} Kuyruk
          </span>
        )}
      </button>

      {/* Popover Details Modal / Dropdown */}
      {showDetails && (
        <div className="absolute right-0 top-10 z-50 w-72 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-4 space-y-3 text-xs animate-in zoom-in-95">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Database className="w-4 h-4 text-teal-600" />
              <span>Veri & Senkronizasyon Durumu</span>
            </span>
            <button
              onClick={() => setShowDetails(false)}
              className="text-slate-400 hover:text-slate-600 text-xs font-bold"
            >
              ✕
            </button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
              <span className="text-slate-600 dark:text-slate-300 font-medium flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-blue-500" />
                Yerel Veritabanı:
              </span>
              <span className="font-bold text-teal-600 dark:text-teal-400">Aktif (IndexedDB)</span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
              <span className="text-slate-600 dark:text-slate-300 font-medium flex items-center gap-1.5">
                <Cloud className="w-3.5 h-3.5 text-purple-500" />
                Bulut AI Bağlantısı:
              </span>
              <span
                className={`font-bold ${
                  isOnline ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600"
                }`}
              >
                {isOnline ? "Erişilebilir" : "Çevrimdışı"}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
              <span className="text-slate-600 dark:text-slate-300 font-medium flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-500" />
                Bekleyen Kuyruk:
              </span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">
                {queueCount} İşlem
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
            Notlar önce cihazınızda yerel işlenir. Bağlantı kurulduğunda yapay zeka derisleştirmesi arka planda otomatik güncellenir.
          </p>

          <div className="flex gap-2 pt-1">
            {onTriggerSync && (
              <button
                onClick={() => {
                  onTriggerSync();
                  setShowDetails(false);
                }}
                disabled={isSyncing}
                className="flex-1 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-xs hover:opacity-90 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
                <span>Senkronize Et</span>
              </button>
            )}
            {queueCount > 0 && (
              <button
                onClick={() => {
                  clearOfflineQueue();
                  setQueueCount(0);
                }}
                className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 cursor-pointer"
              >
                Temizle
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
