import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Briefcase, 
  Award, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  Play, 
  FileText, 
  Globe, 
  Sparkles, 
  MessageSquare, 
  Zap, 
  HelpCircle, 
  RefreshCw,
  AlertCircle,
  ChevronRight,
  TrendingUp,
  Brain
} from 'lucide-react';
import { Language, ExamType } from '../types';
import { EXAM_PREPS } from '../presets';

interface GovtExamHubProps {
  language: Language;
  targetExam: string;
  setTargetExam: (exam: string) => void;
  onIncrementQuiz: (score: number) => void;
}

export default function GovtExamHub({ language, targetExam, setTargetExam, onIncrementQuiz }: GovtExamHubProps) {
  const [activeTab, setActiveTab] = useState<'syllabus' | 'pyq' | 'mock' | 'current_affairs' | 'interview'>('mock');

  // PYQ State
  const [pyqSubject, setPyqSubject] = useState<string>('Mathematics');
  const [pyqYear, setPyqYear] = useState<string>('2023');
  const [pyqList, setPyqList] = useState<any[]>([]);
  const [isLoadingPyq, setIsLoadingPyq] = useState<boolean>(false);
  const [selectedPyqAnswers, setSelectedPyqAnswers] = useState<Record<string, number>>({});

  // Current Affairs State
  const [caFeed, setCaFeed] = useState<any[]>([]);
  const [caQuiz, setCaQuiz] = useState<any[]>([]);
  const [isLoadingCa, setIsLoadingCa] = useState<boolean>(false);
  const [caUserAnswers, setCaUserAnswers] = useState<Record<number, number>>({});

  // Mock Test State
  const [mockSubject, setMockSubject] = useState<string>('Mathematics');
  const [mockDifficulty, setMockDifficulty] = useState<string>('Medium');
  const [mockQuestionCount, setMockQuestionCount] = useState<number>(5);
  const [mockTimeLimitMins, setMockTimeLimitMins] = useState<number>(10);
  const [isTestRunning, setIsTestRunning] = useState<boolean>(false);
  const [testMcqs, setTestMcqs] = useState<any[]>([]);
  const [currentMcqIdx, setCurrentMcqIdx] = useState<number>(0);
  const [userMcqAnswers, setUserMcqAnswers] = useState<Record<number, number>>({});
  const [markedForReview, setMarkedForReview] = useState<Record<number, boolean>>({});
  const [timeLeftSeconds, setTimeLeftSeconds] = useState<number>(600);
  const [testResult, setTestResult] = useState<any | null>(null);
  const [isLoadingMock, setIsLoadingMock] = useState<boolean>(false);

  // Interview Practice State
  const [jobRole, setJobRole] = useState<string>('Aptitude & Technical Specialist');
  const [interviewQuestion, setInterviewQuestion] = useState<string>('');
  const [interviewTip, setInterviewTip] = useState<string>('');
  const [userAnswer, setUserAnswer] = useState<string>('');
  const [interviewFeedback, setInterviewFeedback] = useState<any | null>(null);
  const [isLoadingInterview, setIsLoadingInterview] = useState<boolean>(false);

  // Load PYQs when tab or parameters change
  const fetchPyqs = async () => {
    setIsLoadingPyq(true);
    try {
      const response = await fetch('/api/gemini/pyqs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exam: targetExam,
          subject: pyqSubject,
          year: pyqYear,
          language
        })
      });
      if (response.ok) {
        const data = await response.json();
        setPyqList(data.questions || []);
      }
    } catch (err) {
      console.error('PYQ Fetch Error:', err);
    } finally {
      setIsLoadingPyq(false);
    }
  };

  // Load Current Affairs
  const fetchCurrentAffairs = async () => {
    setIsLoadingCa(true);
    try {
      const response = await fetch('/api/gemini/current-affairs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetExam,
          language
        })
      });
      if (response.ok) {
        const data = await response.json();
        setCaFeed(data.items || []);
        setCaQuiz(data.quiz || []);
      }
    } catch (err) {
      console.error('Current Affairs Error:', err);
    } finally {
      setIsLoadingCa(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'pyq' && pyqList.length === 0) {
      fetchPyqs();
    } else if (activeTab === 'current_affairs' && caFeed.length === 0) {
      fetchCurrentAffairs();
    }
  }, [activeTab]);

  // Mock Test Timer Effect
  useEffect(() => {
    let timer: any = null;
    if (isTestRunning && timeLeftSeconds > 0) {
      timer = setInterval(() => {
        setTimeLeftSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            handleSubmitMockTest();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isTestRunning, timeLeftSeconds]);

  // Start Mock Test
  const handleStartMockTest = async () => {
    setIsLoadingMock(true);
    setTestResult(null);
    setUserMcqAnswers({});
    setMarkedForReview({});
    setCurrentMcqIdx(0);

    try {
      const response = await fetch('/api/gemini/mcqs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: `${targetExam} ${mockSubject} Exam Prep`,
          subject: mockSubject,
          count: mockQuestionCount,
          language
        })
      });

      if (response.ok) {
        const data = await response.json();
        setTestMcqs(data.mcqs || []);
        setTimeLeftSeconds(mockTimeLimitMins * 60);
        setIsTestRunning(true);
      }
    } catch (err) {
      console.error('Start Mock Test Error:', err);
    } finally {
      setIsLoadingMock(false);
    }
  };

  // Submit Mock Test
  const handleSubmitMockTest = () => {
    setIsTestRunning(false);
    let correct = 0;
    let wrong = 0;
    let skipped = 0;

    testMcqs.forEach((mcq, idx) => {
      const ans = userMcqAnswers[idx];
      if (ans === undefined) {
        skipped++;
      } else if (ans === mcq.answerIndex) {
        correct++;
      } else {
        wrong++;
      }
    });

    const total = testMcqs.length;
    const scorePct = total > 0 ? Math.round((correct / total) * 100) : 0;
    const timeTakenSecs = (mockTimeLimitMins * 60) - timeLeftSeconds;
    const avgTimePerQ = total > 0 ? Math.round(timeTakenSecs / total) : 0;

    const result = {
      total,
      correct,
      wrong,
      skipped,
      scorePct,
      timeTakenSecs,
      avgTimePerQ
    };

    setTestResult(result);
    onIncrementQuiz(scorePct);
  };

  // AI Interview Practice
  const handleFetchInterviewQuestion = async () => {
    setIsLoadingInterview(true);
    setInterviewFeedback(null);
    setUserAnswer('');
    try {
      const response = await fetch('/api/gemini/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role: jobRole,
          language
        })
      });
      if (response.ok) {
        const data = await response.json();
        setInterviewQuestion(data.question || '');
        setInterviewTip(data.tips || '');
      }
    } catch (err) {
      console.error('Interview Q Error:', err);
    } finally {
      setIsLoadingInterview(false);
    }
  };

  const handleEvaluateInterviewAnswer = async () => {
    if (!userAnswer.trim()) return;
    setIsLoadingInterview(true);
    try {
      const response = await fetch('/api/gemini/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role: jobRole,
          question: interviewQuestion,
          answer: userAnswer,
          language
        })
      });
      if (response.ok) {
        const data = await response.json();
        setInterviewFeedback(data);
      }
    } catch (err) {
      console.error('Interview Eval Error:', err);
    } finally {
      setIsLoadingInterview(false);
    }
  };

  const selectedPrepInfo = EXAM_PREPS.find(p => p.exam.toLowerCase().includes(targetExam.toLowerCase())) || EXAM_PREPS[0];

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 max-w-6xl mx-auto w-full pb-24 md:pb-10">
      
      {/* Top Banner & Exam Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-slate-100 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full text-xs font-bold border border-indigo-500/30 mb-2">
            <Building2 className="w-3.5 h-3.5" />
            {language === 'bn' ? 'অল-ইন-ওয়ান পরীক্ষার সেন্টার' : 'All-in-One Exam Prep Hub'}
          </div>
          <h2 className="text-xl md:text-2xl font-black font-display text-white">
            {targetExam} {language === 'bn' ? 'প্রস্তুতি পোর্টাল' : 'Preparation Hub'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {selectedPrepInfo.description}
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 p-2 rounded-2xl w-full md:w-auto">
          <span className="text-xs font-bold text-slate-400 pl-2 shrink-0">
            {language === 'bn' ? 'পরীক্ষা বদলান:' : 'Change Exam:'}
          </span>
          <select
            value={targetExam}
            onChange={(e) => setTargetExam(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-indigo-300 font-extrabold text-xs rounded-xl px-3 py-1.5 focus:outline-none cursor-pointer w-full"
          >
            {EXAM_PREPS.map((p) => (
              <option key={p.exam} value={p.exam} className="bg-slate-900 text-white">
                {p.exam}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {[
          { id: 'mock', label: { en: 'Mock Test Engine', bn: 'মক টেস্ট ইঞ্জিন' }, icon: Play },
          { id: 'pyq', label: { en: 'PYQ (Previous Years)', bn: 'বিগত বছরের প্রশ্ন (PYQ)' }, icon: FileText },
          { id: 'current_affairs', label: { en: 'Current Affairs', bn: 'কারেন্ট অ্যাফেয়ার্স' }, icon: Globe },
          { id: 'interview', label: { en: 'Private Job & Interview', bn: 'ইন্টারভিউ ও জব স্পেশাল' }, icon: Briefcase },
          { id: 'syllabus', label: { en: 'Syllabus & Pattern', bn: 'সিলেবাস ও বিষয়' }, icon: BookOpen }
        ].map(tab => {
          const Icon = tab.icon;
          const isAct = activeTab === tab.id;
          const label = tab.label[language] || tab.label.en;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                isAct
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: MOCK TEST ENGINE */}
      {activeTab === 'mock' && (
        <div className="space-y-6">
          {!isTestRunning && !testResult && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-base font-black text-slate-900">
                  {language === 'bn' ? 'মক টেস্ট কনফিগারেশন' : 'Customize Your Mock Test'}
                </h3>
                <p className="text-xs text-slate-500">
                  {language === 'bn' ? 'আপনার প্রয়োজনীয় বিষয়, প্রশ্ন সংখ্যা ও সময় অনুযায়ী মক টেস্ট দিন' : 'Set question limits, timer, and topics for live exam practice'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'বিষয় (Subject)' : 'Subject'}
                  </label>
                  <select
                    value={mockSubject}
                    onChange={(e) => setMockSubject(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Mathematics">Mathematics / Quantitative Aptitude</option>
                    <option value="General Science">General Science</option>
                    <option value="Reasoning">General Intelligence & Reasoning</option>
                    <option value="General Knowledge">General Knowledge & History</option>
                    <option value="English">Verbal English Grammar</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'কঠিনতার মাত্রা' : 'Difficulty'}
                  </label>
                  <select
                    value={mockDifficulty}
                    onChange={(e) => setMockDifficulty(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard (Exam Standard)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'প্রশ্ন সংখ্যা' : 'No. of Questions'}
                  </label>
                  <select
                    value={mockQuestionCount}
                    onChange={(e) => setMockQuestionCount(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value={5}>5 Questions</option>
                    <option value={10}>10 Questions</option>
                    <option value={15}>15 Questions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'সময় সীমা (মিনিট)' : 'Time Limit (Mins)'}
                  </label>
                  <select
                    value={mockTimeLimitMins}
                    onChange={(e) => setMockTimeLimitMins(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value={5}>5 Mins</option>
                    <option value={10}>10 Mins</option>
                    <option value={15}>15 Mins</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleStartMockTest}
                disabled={isLoadingMock}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white font-black py-3.5 rounded-2xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
              >
                {isLoadingMock ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    {language === 'bn' ? 'এআই প্রশ্নপত্র তৈরি করছে...' : 'Generating Exam Paper...'}
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    {language === 'bn' ? 'লাইভ মক টেস্ট শুরু করুন' : 'Start Live Mock Test'}
                  </>
                )}
              </button>
            </div>
          )}

          {/* LIVE MOCK TEST SCREEN */}
          {isTestRunning && testMcqs.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-md space-y-6">
              {/* Test Header with Timer */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <span className="text-xs font-black text-indigo-600 uppercase tracking-wider">
                    {targetExam} — {mockSubject}
                  </span>
                  <div className="text-xs font-bold text-slate-500">
                    {language === 'bn' ? `প্রশ্ন ${currentMcqIdx + 1} / ${testMcqs.length}` : `Question ${currentMcqIdx + 1} of ${testMcqs.length}`}
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-rose-50 text-rose-700 px-4 py-2 rounded-2xl border border-rose-200 font-mono font-black text-sm animate-pulse">
                  <Clock className="w-4 h-4" />
                  {Math.floor(timeLeftSeconds / 60)}:{(timeLeftSeconds % 60).toString().padStart(2, '0')}
                </div>
              </div>

              {/* Current Question */}
              <div className="space-y-4">
                <h4 className="text-sm md:text-base font-extrabold text-slate-900 leading-relaxed">
                  {currentMcqIdx + 1}. {testMcqs[currentMcqIdx].question}
                </h4>

                <div className="space-y-2.5">
                  {testMcqs[currentMcqIdx].options.map((opt: string, optIdx: number) => {
                    const isSelected = userMcqAnswers[currentMcqIdx] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        onClick={() => setUserMcqAnswers(prev => ({ ...prev, [currentMcqIdx]: optIdx }))}
                        className={`w-full p-3.5 rounded-2xl border text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                            : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                        }`}
                      >
                        <span>{opt}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-white" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentMcqIdx(prev => Math.max(0, prev - 1))}
                  disabled={currentMcqIdx === 0}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200 cursor-pointer disabled:opacity-30"
                >
                  {language === 'bn' ? 'পূর্ববর্তী' : 'Previous'}
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={() => setMarkedForReview(prev => ({ ...prev, [currentMcqIdx]: !prev[currentMcqIdx] }))}
                    className={`px-3 py-2 text-xs font-bold rounded-xl border cursor-pointer ${
                      markedForReview[currentMcqIdx] 
                        ? 'bg-amber-100 text-amber-800 border-amber-300' 
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {markedForReview[currentMcqIdx] ? '★ Marked' : 'Mark for Review'}
                  </button>

                  {currentMcqIdx < testMcqs.length - 1 ? (
                    <button
                      onClick={() => setCurrentMcqIdx(prev => Math.min(testMcqs.length - 1, prev + 1))}
                      className="px-5 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700 cursor-pointer"
                    >
                      {language === 'bn' ? 'পরবর্তী' : 'Next'}
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmitMockTest}
                      className="px-6 py-2 bg-emerald-600 text-white font-extrabold text-xs rounded-xl hover:bg-emerald-700 cursor-pointer shadow-md shadow-emerald-600/20"
                    >
                      {language === 'bn' ? 'টেস্ট জমা দিন' : 'Submit Test'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* MOCK TEST SCORECARD & ANALYSIS */}
          {testResult && !isTestRunning && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-md space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    {language === 'bn' ? 'মক টেস্টের এআই পারফরম্যান্স রিপোর্ট' : 'AI Performance Scorecard'}
                  </h3>
                  <span className="text-xs text-slate-500">{targetExam} — {mockSubject}</span>
                </div>
                <div className="text-2xl font-black text-indigo-600 bg-indigo-50 px-4 py-1.5 rounded-2xl border border-indigo-100">
                  {testResult.scorePct}%
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-center">
                  <div className="text-xs font-bold text-slate-500">মোট প্রশ্ন</div>
                  <div className="text-lg font-black text-slate-800">{testResult.total}</div>
                </div>
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                  <div className="text-xs font-bold text-emerald-700">সঠিক উত্তর</div>
                  <div className="text-lg font-black text-emerald-800">{testResult.correct}</div>
                </div>
                <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-center">
                  <div className="text-xs font-bold text-rose-700">ভুল উত্তর</div>
                  <div className="text-lg font-black text-rose-800">{testResult.wrong}</div>
                </div>
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-center">
                  <div className="text-xs font-bold text-amber-700">ছেড়ে দেওয়া</div>
                  <div className="text-lg font-black text-amber-800">{testResult.skipped}</div>
                </div>
              </div>

              {/* Detailed Solutions Breakdown */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                  {language === 'bn' ? 'উত্তরপত্র ও সমাধান:' : 'Detailed Answers & Explanations:'}
                </h4>
                {testMcqs.map((mcq, idx) => {
                  const userAns = userMcqAnswers[idx];
                  const isCorrect = userAns === mcq.answerIndex;
                  return (
                    <div key={idx} className={`p-4 rounded-2xl border ${isCorrect ? 'bg-emerald-50/50 border-emerald-200' : 'bg-rose-50/50 border-rose-200'}`}>
                      <div className="text-xs font-bold text-slate-800 mb-1">
                        {idx + 1}. {mcq.question}
                      </div>
                      <div className="text-xs text-slate-600 space-y-0.5">
                        <div>
                          <strong>{language === 'bn' ? 'আপনার উত্তর:' : 'Your Answer:'}</strong>{' '}
                          {userAns !== undefined ? mcq.options[userAns] : '(Skipped)'}
                        </div>
                        <div>
                          <strong>{language === 'bn' ? 'সঠিক উত্তর:' : 'Correct Answer:'}</strong>{' '}
                          <span className="text-emerald-700 font-bold">{mcq.options[mcq.answerIndex]}</span>
                        </div>
                        <div className="pt-1 text-[11px] text-slate-500 font-medium italic">
                          💡 {mcq.explanation}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                onClick={() => setTestResult(null)}
                className="w-full bg-slate-900 text-white font-bold py-3 rounded-2xl text-xs cursor-pointer hover:bg-slate-800"
              >
                {language === 'bn' ? 'নতুন টেস্ট শুরু করুন' : 'Take Another Test'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PREVIOUS YEAR QUESTIONS (PYQ) */}
      {activeTab === 'pyq' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-base font-black text-slate-900">
                {language === 'bn' ? `${targetExam} বিগত বছরের প্রশ্নপত্র (PYQs)` : `${targetExam} Previous Year Questions`}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'bn' ? 'অফিসিয়াল বিগত বছরের প্রশ্ন ও এআই অনুশীলনী প্রশ্ন' : 'Official PYQs and AI pattern-matched practice questions'}
              </p>
            </div>

            <div className="flex gap-2">
              <select
                value={pyqSubject}
                onChange={(e) => setPyqSubject(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-xs font-bold rounded-xl px-3 py-1.5"
              >
                <option value="Mathematics">Mathematics</option>
                <option value="General Science">General Science</option>
                <option value="Reasoning">Reasoning</option>
                <option value="History">History & Polity</option>
              </select>

              <select
                value={pyqYear}
                onChange={(e) => setPyqYear(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-xs font-bold rounded-xl px-3 py-1.5"
              >
                <option value="2024">2024</option>
                <option value="2023">2023</option>
                <option value="2022">2022</option>
              </select>

              <button
                onClick={fetchPyqs}
                disabled={isLoadingPyq}
                className="bg-indigo-600 text-white text-xs font-bold px-4 py-1.5 rounded-xl cursor-pointer hover:bg-indigo-700"
              >
                {isLoadingPyq ? '...' : (language === 'bn' ? 'খুঁজুন' : 'Load')}
              </button>
            </div>
          </div>

          {isLoadingPyq ? (
            <div className="p-8 text-center text-xs font-bold text-slate-400 flex items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
              {language === 'bn' ? 'PYQ লোড হচ্ছে...' : 'Fetching PYQs...'}
            </div>
          ) : (
            <div className="space-y-4">
              {pyqList.map((pyq, idx) => {
                const selAns = selectedPyqAnswers[pyq.id];
                return (
                  <div key={pyq.id || idx} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-md ${
                        pyq.isOfficial ? 'bg-indigo-100 text-indigo-800' : 'bg-purple-100 text-purple-800'
                      }`}>
                        {pyq.label || (pyq.isOfficial ? 'Official PYQ' : 'AI Generated Practice Question')}
                      </span>
                      <span className="text-[11px] font-bold text-slate-400">{targetExam} {pyqYear}</span>
                    </div>

                    <p className="text-xs font-bold text-slate-800 leading-relaxed">
                      {idx + 1}. {pyq.question}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {pyq.options?.map((opt: string, oIdx: number) => {
                        const isSelected = selAns === oIdx;
                        const isCorrect = oIdx === pyq.correctIndex;
                        let btnStyle = 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100';
                        if (selAns !== undefined) {
                          if (isCorrect) btnStyle = 'bg-emerald-600 text-white border-emerald-600';
                          else if (isSelected) btnStyle = 'bg-rose-600 text-white border-rose-600';
                        }
                        return (
                          <button
                            key={oIdx}
                            onClick={() => setSelectedPyqAnswers(prev => ({ ...prev, [pyq.id]: oIdx }))}
                            className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer ${btnStyle}`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>

                    {selAns !== undefined && (
                      <div className="p-3 bg-white border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
                        <div className="font-bold text-indigo-700">💡 সমাধান / Explanation:</div>
                        <div>{pyq.explanation}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CURRENT AFFAIRS */}
      {activeTab === 'current_affairs' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-base font-black text-slate-900">
                {language === 'bn' ? 'দৈনিক ও সাপ্তাহিক কারেন্ট অ্যাফেয়ার্স' : 'Exam Special Current Affairs'}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'bn' ? 'চাকরির পরীক্ষার উপযোগী যাচাইকৃত তথ্য ও প্রশ্ন' : 'High-impact facts with exam relevance breakdowns'}
              </p>
            </div>
            <button
              onClick={fetchCurrentAffairs}
              disabled={isLoadingCa}
              className="px-3.5 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingCa ? 'animate-spin' : ''}`} />
              {language === 'bn' ? 'রিফ্রেশ' : 'Refresh'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {caFeed.map((item) => (
              <div key={item.id} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                    {item.category}
                  </span>
                  <span className="font-bold text-slate-400">{item.date}</span>
                </div>
                <h4 className="text-xs font-black text-slate-800">{item.title}</h4>
                <p className="text-xs font-medium text-slate-600 leading-relaxed">{item.summary}</p>
                <div className="pt-2 border-t border-slate-200/60 text-[11px] text-emerald-800 bg-emerald-50/50 p-2 rounded-xl">
                  <strong>🎯 পরীক্ষার গুরুত্ব:</strong> {item.examImportance}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PRIVATE JOB & INTERVIEW PREP */}
      {activeTab === 'interview' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-indigo-600" />
              {language === 'bn' ? 'এআই ড্রাইভেন ইন্টারভিউ মক অ্যান্ড অ্যানালিসিস' : 'AI Mock Interview & HR Practice'}
            </h3>
            <p className="text-xs text-slate-500">
              {language === 'bn' ? 'প্রাইভেট কোম্পানি ও সরকারি পদের জন্য লাইভ প্রশ্ন ও উত্তর স্পীকিং মূল্যায়ন' : 'Practice interview questions and get feedback on communication & clarity'}
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'জব পদ বা বিষয় নির্বাচন করুন:' : 'Target Role / Job Category:'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={jobRole}
                  onChange={(e) => setJobRole(e.target.value)}
                  placeholder="e.g. Software Engineer / Bank PO / WB Police SI"
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={handleFetchInterviewQuestion}
                  disabled={isLoadingInterview}
                  className="bg-indigo-600 text-white text-xs font-extrabold px-5 py-2 rounded-xl cursor-pointer hover:bg-indigo-700"
                >
                  {isLoadingInterview ? '...' : (language === 'bn' ? 'প্রশ্ন পান' : 'Get Question')}
                </button>
              </div>
            </div>

            {interviewQuestion && (
              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-2">
                <div className="text-xs font-bold text-indigo-400">
                  {language === 'bn' ? 'ইন্টারভিউয়ারের প্রশ্ন:' : 'Interviewer Question:'}
                </div>
                <p className="text-sm font-extrabold text-slate-100">{interviewQuestion}</p>
                {interviewTip && (
                  <div className="text-[11px] text-slate-400 italic">💡 Tip: {interviewTip}</div>
                )}
              </div>
            )}

            {interviewQuestion && (
              <div className="space-y-3">
                <textarea
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  rows={4}
                  placeholder={language === 'bn' ? 'আপনার উত্তর এখানে লিখুন...' : 'Type your interview response here...'}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3.5 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={handleEvaluateInterviewAnswer}
                  disabled={isLoadingInterview || !userAnswer.trim()}
                  className="w-full bg-indigo-600 text-white font-extrabold py-3 rounded-xl text-xs shadow-md cursor-pointer hover:bg-indigo-700 disabled:opacity-50"
                >
                  {isLoadingInterview ? 'মূল্যায়ন করা হচ্ছে...' : 'Evaluate Answer with AI'}
                </button>
              </div>
            )}

            {interviewFeedback && (
              <div className="p-5 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-4">
                <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                  <h4 className="text-sm font-black text-indigo-950">
                    {language === 'bn' ? 'ইন্টারভিউ স্কোরের ফিডব্যাক:' : 'AI Evaluation Scorecard'}
                  </h4>
                  <span className="text-lg font-black text-indigo-600 bg-white px-3 py-0.5 rounded-xl border border-indigo-200">
                    {interviewFeedback.overallScore} / 100
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-bold">
                  <div className="p-2 bg-white rounded-xl border border-indigo-100">Comms: {interviewFeedback.communication}%</div>
                  <div className="p-2 bg-white rounded-xl border border-indigo-100">Grammar: {interviewFeedback.grammar}%</div>
                  <div className="p-2 bg-white rounded-xl border border-indigo-100">Relevance: {interviewFeedback.relevance}%</div>
                </div>

                <div className="text-xs text-slate-700 space-y-1">
                  <div className="font-bold text-emerald-800">✓ ভালো দিক:</div>
                  <p>{interviewFeedback.strengths?.join(', ')}</p>
                  <div className="font-bold text-amber-800 pt-1">⚠️ উন্নতির উপায়:</div>
                  <p>{interviewFeedback.improvements?.join(', ')}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: SYLLABUS & PATTERN */}
      {activeTab === 'syllabus' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-base font-black text-slate-900">
            {targetExam} — {language === 'bn' ? 'অফিশিয়াল বিষয়ভিত্তিক সিলেবাস' : 'Official Exam Syllabus'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {selectedPrepInfo.syllabus.map((s, idx) => (
              <div key={idx} className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{s}</span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
