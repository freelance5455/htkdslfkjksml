function ring(cx: number, cy: number, radius: number, points: number, rotation: number) {
  const angle = (rotation * Math.PI) / 180;
  let path = "";
  for (let i = 0; i < points; i += 1) {
    const theta = angle + (i * 2 * Math.PI) / points;
    const x = cx + radius * Math.cos(theta);
    const y = cy + radius * Math.sin(theta);
    path += `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)} `;
  }
  return `${path}Z`;
}

export function NameMotif({
  seed,
  className = "",
  label,
}: {
  seed: number;
  className?: string;
  label?: string;
}) {
  const points = 6 + (seed % 7);
  const rotation = (seed * 23) % 360;
  const skip = 2 + (seed % 3);
  const rings = [78, 58, 38].slice(0, 2 + (seed % 2));
  const star = Array.from({ length: points }, (_, index) => {
    const theta = ((rotation + index * skip * (360 / points)) * Math.PI) / 180;
    const radius = index % 2 === 0 ? 46 : 22;
    const x = 100 + radius * Math.cos(theta);
    const y = 100 + radius * Math.sin(theta);
    return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(" ");

  return (
    <svg
      viewBox="0 0 200 200"
      className={className}
      role="img"
      aria-label={
        label
          ? `زخرفة هندسية بجانب اسم ${label}. ليست تمثيلًا لله تعالى.`
          : "زخرفة هندسية إسلامية. ليست تمثيلًا لله تعالى."
      }
    >
      <circle cx="100" cy="100" r="96" className="fill-soft" />
      <circle cx="100" cy="100" r="90" fill="none" className="stroke-gold" strokeWidth="0.6" />
      {rings.map((radius, index) => (
        <path
          key={radius}
          d={ring(100, 100, radius, points + (index % 2), rotation + index * 12)}
          fill="none"
          className={index === 0 ? "stroke-primary" : "stroke-olive"}
          strokeWidth={index === 0 ? 1.2 : 0.8}
        />
      ))}
      <path d={`${star} Z`} fill="none" className="stroke-gold" strokeWidth="1" />
      <circle cx="100" cy="100" r={4 + (seed % 5)} fill="none" className="stroke-primary" strokeWidth="1" />
    </svg>
  );
}

export function Crest({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <circle cx="32" cy="32" r="30" fill="none" className="stroke-gold" strokeWidth="1.2" />
      <path d={ring(32, 32, 18, 8, 22)} fill="none" className="stroke-primary" strokeWidth="1.4" />
      <circle cx="32" cy="32" r="3" className="fill-gold" />
    </svg>
  );
}
