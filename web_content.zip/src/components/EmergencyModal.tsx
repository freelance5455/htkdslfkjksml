/**
 * JARVIS Emergency Assistance Protocol (SOS)
 * Immediate high-priority beacon, GPS geolocation lock, emergency contact auto-dialer,
 * and encrypted distress dispatch via SMS/WhatsApp.
 */

import React, { useState, useEffect } from 'react';
import { AlertOctagon, PhoneCall, MapPin, Send, X, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { deviceService } from '../services/deviceService';
import { Contact } from '../types';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: Contact[];
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose, contacts }) => {
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [mapsLink, setMapsLink] = useState('');
  const [waLink, setWaLink] = useState('');
  const [telLink, setTelLink] = useState('');
  const [isLocating, setIsLocating] = useState(false);
  const [beaconActive, setBeaconActive] = useState(true);

  const primaryContact = contacts[0] || { name: 'Emergency Services', phone: '112' };

  useEffect(() => {
    if (!isOpen) return;

    // Trigger immediate SOS distress sequence
    setIsLocating(true);
    setBeaconActive(true);

    deviceService.triggerEmergencySOS(primaryContact.phone).then((res) => {
      if (res.lat && res.lon) {
        setCoords({ lat: res.lat, lon: res.lon });
      }
      setMapsLink(res.mapsUrl);
      setWaLink(res.waUrl);
      setTelLink(res.telUrl);
      setIsLocating(false);
    });

    return () => {
      setBeaconActive(false);
    };
  }, [isOpen, primaryContact]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-lg flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gray-950 border-2 border-red-500/80 rounded-2xl flex flex-col overflow-hidden shadow-[0_0_80px_rgba(239,68,68,0.4)]">
        {/* Top Alert Header */}
        <div className="bg-red-950/80 border-b border-red-500/40 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-red-400">
            <AlertOctagon className="w-6 h-6 animate-pulse" />
            <span className="font-mono font-bold tracking-widest text-sm uppercase text-red-200">
              Emergency Assistance // SOS Active
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded bg-red-900/40 text-red-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4">
          <div className="text-center space-y-1">
            <h3 className="text-lg font-bold text-red-100 uppercase tracking-wide">
              Distress Protocol Initiated
            </h3>
            <p className="text-xs text-red-300/80">
              JARVIS has locked GPS coordinates and prepared one-touch emergency dispatch to trusted contacts.
            </p>
          </div>

          {/* GPS Coordinates Box */}
          <div className="bg-gray-900/80 border border-red-500/30 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-gray-400 flex items-center space-x-1.5">
                <MapPin className="w-4 h-4 text-red-400" />
                <span>Live Satellite Fix</span>
              </span>
              {isLocating ? (
                <span className="text-amber-400 animate-pulse">Acquiring GPS...</span>
              ) : (
                <span className="text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Position Locked</span>
                </span>
              )}
            </div>

            {coords ? (
              <div className="text-xs font-mono text-cyan-300 bg-gray-950/70 p-2 rounded border border-gray-800 flex justify-between items-center">
                <span>Lat: {coords.lat.toFixed(5)}°, Lon: {coords.lon.toFixed(5)}°</span>
                <a
                  href={mapsLink}
                  target="_blank"
                  rel="noreferrer"
                  className="text-red-400 hover:underline text-[11px]"
                >
                  Open Map
                </a>
              </div>
            ) : null}
          </div>

          {/* Primary Action Buttons */}
          <div className="space-y-2.5 pt-2">
            {/* Quick Call */}
            <a
              href={telLink || `tel:${primaryContact.phone}`}
              className="w-full py-3.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold font-mono text-sm flex items-center justify-center space-x-2 transition-all shadow-[0_0_25px_rgba(239,68,68,0.5)]"
            >
              <PhoneCall className="w-5 h-5" />
              <span>Call Emergency Contact ({primaryContact.name})</span>
            </a>

            {/* WhatsApp Distress Message */}
            <a
              href={waLink}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold font-mono text-xs flex items-center justify-center space-x-2 transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
              <span>Send WhatsApp SOS + Live GPS Pin</span>
            </a>

            {/* National Emergency Hotline */}
            <a
              href="tel:112"
              className="w-full py-2.5 px-4 rounded-xl bg-gray-900 hover:bg-gray-800 text-red-400 border border-red-500/40 font-mono text-xs flex items-center justify-center space-x-2 transition-colors"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Dial National Emergency Dispatch (112)</span>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-900/60 px-4 py-2.5 border-t border-gray-800 text-[11px] text-gray-400 text-center font-mono">
          Safe Mode: Tap anywhere outside or click Close to cancel distress beacon.
        </div>
      </div>
    </div>
  );
};
