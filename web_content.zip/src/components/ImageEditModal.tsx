import React, { useState, useEffect, useRef } from "react";
import {
  Upload,
  Image as ImageIcon,
  Wand2,
  Sparkles,
  Loader2,
  AlertCircle,
  Download,
  Maximize2,
  RefreshCw,
  ArrowRight,
  Microscope,
  Dna,
  Atom,
  FlaskConical,
} from "lucide-react";
import { AspectRatio, GeneratedImage } from "../types";
import { SmartImage } from "./SmartImage";
import { generateLocalCanvasImage } from "../utils/localImageGenerator";
import { downloadImage } from "../utils/downloadImage";

interface ImageEditModalProps {
  baseImage: GeneratedImage | null;
  onEditSuccess: (image: GeneratedImage) => void;
  onOpenImageModal: (image: GeneratedImage) => void;
}

const SCIENTIFIC_EDIT_PRESETS = [
  {
    label: "Add Scientific Labels & Pointers",
    icon: <Microscope className="w-3.5 h-3.5 text-emerald-400" />,
    prompt: "Add clear scientific text labels with arrow pointers pointing to key biological structures and anatomical regions",
  },
  {
    label: "Biological Cross-Section Diagram",
    icon: <Dna className="w-3.5 h-3.5 text-cyan-400" />,
    prompt: "Convert into a detailed scientific biological cross-section diagram showing inner cell membranes and organelle structures",
  },
  {
    label: "Fluorescent Confocal Staining",
    icon: <FlaskConical className="w-3.5 h-3.5 text-pink-400" />,
    prompt: "Apply green fluorescent protein (GFP) and blue DAPI confocal microscope fluorescence staining to highlight nucleus and cell wall",
  },
  {
    label: "3D Bio-Molecular Render",
    icon: <Atom className="w-3.5 h-3.5 text-purple-400" />,
    prompt: "Transform into a 3D ray-traced molecular surface render with atomic depth and vivid scientific lighting",
  },
];

export const ImageEditModal: React.FC<ImageEditModalProps> = ({
  baseImage,
  onEditSuccess,
  onOpenImageModal,
}) => {
  const [currentBaseUrl, setCurrentBaseUrl] = useState<string | null>(baseImage ? baseImage.url : null);
  const [editPrompt, setEditPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(baseImage ? baseImage.aspectRatio : "1:1");
  const [isProcessing, setIsProcessing] = useState(false);
  const [editedResult, setEditedResult] = useState<GeneratedImage | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (baseImage) {
      setCurrentBaseUrl(baseImage.url);
      setEditedResult(null);
      setErrorMsg(null);
    }
  }, [baseImage]);

  // Handle local file upload (Drag & Drop or click)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorMsg("Please upload a valid image file (PNG, JPG, WebP).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCurrentBaseUrl(event.target.result as string);
        setEditedResult(null);
        setErrorMsg(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleEditSubmit = async () => {
    if (!currentBaseUrl || !editPrompt.trim() || isProcessing) return;

    setIsProcessing(true);
    setErrorMsg(null);

    const basePromptText = baseImage?.prompt || "";
    const combinedPrompt = basePromptText
      ? `${basePromptText}. Edit: ${editPrompt.trim()}`
      : editPrompt.trim();

    try {
      const activeKey = localStorage.getItem("custom_gemini_api_key") || "";
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (activeKey.trim()) headers["x-gemini-api-key"] = activeKey.trim();

      const response = await fetch("/api/edit-image", {
        method: "POST",
        headers,
        body: JSON.stringify({
          imageBase64: currentBaseUrl,
          basePrompt: basePromptText,
          prompt: editPrompt.trim(),
          aspectRatio,
        }),
      });

      const data = await response.json();
      if (!response.ok || data.useLocalFallback || !data.image?.url) {
        throw new Error("Use local canvas reference image transform");
      }

      if (data.image) {
        const newEditImage: GeneratedImage = {
          id: data.image.id,
          url: data.image.url,
          prompt: `${basePromptText ? basePromptText + " (Edited: " + editPrompt.trim() + ")" : editPrompt.trim()}`,
          aspectRatio,
          style: "AI Edited",
          timestamp: Date.now(),
        };
        setEditedResult(newEditImage);
        onEditSuccess(newEditImage);
      }
    } catch (err: any) {
      console.error("Image edit error:", err);
      // Fallback to local offline canvas img2img transform with combined context
      try {
        const url = await generateLocalCanvasImage({
          prompt: combinedPrompt,
          style: "AI Local Edit",
          aspectRatio,
          referenceImage: currentBaseUrl,
        });
        const fallbackEdited: GeneratedImage = {
          id: `img_edit_local_${Date.now()}`,
          url,
          prompt: combinedPrompt,
          aspectRatio,
          style: "Local AI Edit",
          timestamp: Date.now(),
        };
        setEditedResult(fallbackEdited);
        onEditSuccess(fallbackEdited);
      } catch (localErr) {
        setErrorMsg(err.message || "Failed to edit image.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Wand2 className="w-5 h-5 text-pink-400" />
              <span>AI Image-to-Image & Edit Studio</span>
            </h2>
            <p className="text-xs text-slate-400">
              Upload any image or use a generated creation, then describe changes to add, modify, or restyle elements.
            </p>
          </div>
          {currentBaseUrl && (
            <button
              onClick={() => {
                setCurrentBaseUrl(null);
                setEditedResult(null);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>New Base Image</span>
            </button>
          )}
        </div>

        {/* Upload Box or Base Image Preview Grid */}
        {!currentBaseUrl ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-700 hover:border-purple-500/80 rounded-2xl p-8 text-center cursor-pointer bg-slate-950/60 hover:bg-slate-950 transition group space-y-3"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />
            <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center group-hover:scale-110 transition duration-300">
              <Upload className="w-7 h-7 text-purple-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-slate-200">
                Click or Drag & Drop Image Here
              </h3>
              <p className="text-xs text-slate-400">
                Supports PNG, JPG, WebP up to 10MB
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            {/* Input Base Image */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Source Base Image</span>
                </span>
                <button
                  type="button"
                  onClick={() => currentBaseUrl && downloadImage(currentBaseUrl, "source_base_image.png")}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center gap-1 transition"
                  title="Save Base Image"
                >
                  <Download className="w-3 h-3 text-emerald-400" />
                  <span>Save Image</span>
                </button>
              </div>
              <div className="relative aspect-square max-h-[300px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                <SmartImage
                  src={currentBaseUrl}
                  alt="Source base"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
            </div>

            {/* Output Edited Result (if ready) or Placeholder */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                  <span>Edited Output Result</span>
                </span>
                {editedResult && (
                  <button
                    type="button"
                    onClick={() => downloadImage(editedResult.url, `edited_scientific_image_${editedResult.id}.png`)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold flex items-center gap-1 transition shadow-md"
                    title="Save Edited Image"
                  >
                    <Download className="w-3 h-3" />
                    <span>Save Image</span>
                  </button>
                )}
              </div>
              <div className="relative aspect-square max-h-[300px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                {isProcessing ? (
                  <div className="text-center p-6 space-y-3">
                    <Loader2 className="w-8 h-8 animate-spin text-pink-400 mx-auto" />
                    <p className="text-xs text-pink-300 font-mono animate-pulse">
                      AI is modifying your biological / scientific image...
                    </p>
                  </div>
                ) : editedResult ? (
                  <div className="relative w-full h-full group">
                    <SmartImage
                      src={editedResult.url}
                      alt={editedResult.prompt}
                      prompt={editedResult.prompt}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
                      <button
                        onClick={() => onOpenImageModal(editedResult)}
                        className="p-2.5 rounded-xl bg-purple-600 text-white hover:bg-purple-500 font-semibold text-xs flex items-center gap-1 shadow-lg"
                      >
                        <Maximize2 className="w-4 h-4" />
                        <span>View HD</span>
                      </button>
                      <button
                        onClick={() => downloadImage(editedResult.url, `scientific_edited_${editedResult.id}.png`)}
                        className="p-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 font-semibold text-xs flex items-center gap-1 shadow-lg"
                      >
                        <Download className="w-4 h-4" />
                        <span>Save Image</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-6 space-y-2 text-slate-500">
                    <ArrowRight className="w-8 h-8 mx-auto text-slate-600" />
                    <p className="text-xs">Describe your scientific edits below and click "Apply AI Image Edit"</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Edit Prompt Controls & Scientific Presets */}
        {currentBaseUrl && (
          <div className="space-y-4 border-t border-slate-800/80 pt-4">
            {/* Scientific Biological Presets Quick Select */}
            <div className="space-y-2">
              <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Microscope className="w-3.5 h-3.5" />
                <span>Scientific & Biological Edit Modifiers</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {SCIENTIFIC_EDIT_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setEditPrompt(preset.prompt)}
                    className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/40 text-left transition text-xs group flex items-start gap-2"
                  >
                    <div className="mt-0.5 shrink-0 p-1 rounded-lg bg-slate-900 border border-slate-800 group-hover:border-emerald-500/50">
                      {preset.icon}
                    </div>
                    <div className="space-y-0.5">
                      <div className="font-semibold text-slate-200 group-hover:text-emerald-300 transition">
                        {preset.label}
                      </div>
                      <div className="text-[10px] text-slate-400 line-clamp-1">
                        {preset.prompt}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Wand2 className="w-3.5 h-3.5 text-pink-400" />
                <span>Custom Edit Instructions / Modification Prompt</span>
              </label>
              <textarea
                value={editPrompt}
                onChange={(e) => setEditPrompt(e.target.value)}
                placeholder="e.g. Add red arrow labels pointing to the nucleus and mitochondria, or convert into a confocal fluorescence micrograph..."
                rows={3}
                className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-pink-500 transition resize-none"
              />
            </div>

            <button
              onClick={handleEditSubmit}
              disabled={isProcessing || !editPrompt.trim()}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:via-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-pink-600/20 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing AI Edit...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Apply AI Image Edit</span>
                </>
              )}
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="flex-1">{errorMsg}</span>
          </div>
        )}
      </div>
    </div>
  );
};
