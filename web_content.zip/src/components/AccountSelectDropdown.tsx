import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Account, AccountType } from '../types';
import {
  Banknote,
  Smartphone,
  CreditCard,
  Landmark,
  ArrowDownLeft,
  ArrowUpRight,
  Wallet,
  ChevronDown,
  Check,
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

export const getAccountTypeIcon = (type: AccountType): React.ComponentType<{ className?: string }> => {
  switch (type) {
    case 'cash':
      return Banknote;
    case 'mobile_banking':
      return Smartphone;
    case 'card':
      return CreditCard;
    case 'bank':
      return Landmark;
    case 'receivable':
      return ArrowDownLeft;
    case 'payable':
      return ArrowUpRight;
    default:
      return Wallet;
  }
};

export const getAccountTypeColorClass = (type: AccountType): string => {
  switch (type) {
    case 'cash':
      return 'text-emerald-500';
    case 'mobile_banking':
      return 'text-indigo-500';
    case 'card':
      return 'text-amber-500';
    case 'bank':
      return 'text-blue-500';
    case 'receivable':
      return 'text-cyan-500';
    case 'payable':
      return 'text-rose-500';
    default:
      return 'text-slate-500';
  }
};

export interface AccountSelectDropdownProps {
  id?: string;
  accounts: Account[];
  selectedAccountId: string;
  onSelectAccount: (accountId: string) => void;
  isLight?: boolean;
  isEn?: boolean;
  placeholder?: string;
  showBalances?: boolean;
  disabled?: boolean;
  className?: string;
}

export const AccountSelectDropdown: React.FC<AccountSelectDropdownProps> = ({
  id,
  accounts = [],
  selectedAccountId,
  onSelectAccount,
  isLight = true,
  isEn = false,
  placeholder,
  showBalances = true,
  disabled = false,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const selectedAccount = useMemo(() => {
    return accounts.find((acc) => acc.id === selectedAccountId);
  }, [accounts, selectedAccountId]);

  // Group accounts
  const groupedAccounts = useMemo(() => {
    const wallets = accounts.filter(
      (a) => a.type === 'cash' || a.type === 'mobile_banking' || a.type === 'bank' || a.type === 'card'
    );
    const receivables = accounts.filter((a) => a.type === 'receivable');
    const payables = accounts.filter((a) => a.type === 'payable');

    const groups: { title: string; items: Account[] }[] = [];
    if (wallets.length > 0) {
      groups.push({
        title: isEn ? '💼 Cash & Bank Wallets' : '💼 ক্যাশ ও ব্যাংক ওয়ালেট',
        items: wallets,
      });
    }
    if (receivables.length > 0) {
      groups.push({
        title: isEn ? '📥 Receivables (দেনাদার)' : '📥 দেনাদার হিসাব (Receivables)',
        items: receivables,
      });
    }
    if (payables.length > 0) {
      groups.push({
        title: isEn ? '📤 Payables (পাওনাদার)' : '📤 পাওনাদার হিসাব (Payables)',
        items: payables,
      });
    }

    return groups;
  }, [accounts, isEn]);

  const SelectedIcon = selectedAccount ? getAccountTypeIcon(selectedAccount.type) : Wallet;
  const selectedColorClass = selectedAccount
    ? getAccountTypeColorClass(selectedAccount.type)
    : 'text-slate-400';

  return (
    <div ref={containerRef} className="relative w-full">
      <button
        type="button"
        id={id}
        disabled={disabled}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-between transition cursor-pointer ${
          isLight
            ? 'bg-white border-slate-200 text-slate-900 hover:bg-slate-50 shadow-2xs'
            : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-750'
        } outline-hidden ${disabled ? 'opacity-60 cursor-not-allowed' : ''} ${className}`}
        style={
          isOpen
            ? {
                borderColor: 'var(--color-primary)',
                boxShadow: '0 0 0 3px var(--color-primary-20)',
              }
            : undefined
        }
      >
        <span className="flex items-center gap-2.5 truncate">
          <SelectedIcon className={`w-4 h-4 shrink-0 ${selectedColorClass}`} />
          {selectedAccount ? (
            <>
              <span className="font-bold text-xs sm:text-sm truncate">
                {isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla}
              </span>
              {showBalances && selectedAccount.currentBalance !== undefined && (
                <span className="text-[11px] text-slate-400 font-medium font-mono shrink-0">
                  ({formatCurrency(selectedAccount.currentBalance, !isEn)})
                </span>
              )}
            </>
          ) : (
            <span className="text-slate-400 font-medium">
              {placeholder || (isEn ? 'Select Account *' : 'অ্যাকাউন্ট নির্বাচন করুন *')}
            </span>
          )}
        </span>
        <ChevronDown
          className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ml-2 ${
            isOpen ? 'rotate-180' : ''
          }`}
          style={isOpen ? { color: 'var(--color-primary)' } : undefined}
        />
      </button>

      {isOpen && (
        <div
          className={`absolute z-50 top-full left-0 right-0 mt-1.5 rounded-2xl border shadow-xl overflow-hidden py-1 max-h-64 overflow-y-auto ${
            isLight
              ? 'bg-white border-slate-200 shadow-slate-900/10'
              : 'bg-slate-800 border-slate-700 shadow-black/50'
          }`}
          style={{
            borderColor: 'var(--color-primary-40)',
            boxShadow: '0 12px 30px -5px var(--color-primary-20), 0 0 0 1px var(--color-primary-30)',
          }}
        >
          {accounts.length === 0 ? (
            <div className="p-3 text-center text-xs text-slate-400">
              {isEn ? 'No accounts available' : 'কোনো অ্যাকাউন্ট পাওয়া যায়নি'}
            </div>
          ) : groupedAccounts.length > 1 ? (
            groupedAccounts.map((group) => (
              <div key={group.title} className="last:mb-0">
                <div
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider ${
                    isLight
                      ? 'bg-slate-50 text-slate-700 border-y border-slate-100'
                      : 'bg-slate-850 text-slate-400 border-y border-slate-700/60'
                  } first:border-t-0`}
                  style={{ color: 'var(--color-primary)' }}
                >
                  {group.title}
                </div>
                {group.items.map((acc) => {
                  const Icon = getAccountTypeIcon(acc.type);
                  const colorClass = getAccountTypeColorClass(acc.type);
                  const isSelected = acc.id === selectedAccountId;

                  return (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => {
                        onSelectAccount(acc.id);
                        setIsOpen(false);
                      }}
                      className={`w-full px-3.5 py-2.5 flex items-center justify-between text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                        isSelected
                          ? isLight
                            ? 'font-bold'
                            : 'bg-slate-700 text-white font-bold'
                          : isLight
                          ? 'text-slate-700 hover:bg-slate-50'
                          : 'text-slate-200 hover:bg-slate-700/60 hover:text-white'
                      }`}
                      style={
                        isSelected
                          ? {
                              backgroundColor: 'var(--color-primary-10)',
                              color: 'var(--color-primary)',
                            }
                          : undefined
                      }
                    >
                      <span className="flex items-center gap-2.5 truncate">
                        <Icon className={`w-4 h-4 shrink-0 ${colorClass}`} />
                        <span className="font-semibold truncate">
                          {isEn ? acc.nameEnglish : acc.nameBangla}
                        </span>
                        {showBalances && acc.currentBalance !== undefined && (
                          <span className="text-[11px] text-slate-400 font-mono shrink-0">
                            ({formatCurrency(acc.currentBalance, !isEn)})
                          </span>
                        )}
                      </span>
                      {isSelected && (
                        <Check className="w-4 h-4 shrink-0 ml-2" style={{ color: 'var(--color-primary)' }} />
                      )}
                    </button>
                  );
                })}
              </div>
            ))
          ) : (
            accounts.map((acc) => {
              const Icon = getAccountTypeIcon(acc.type);
              const colorClass = getAccountTypeColorClass(acc.type);
              const isSelected = acc.id === selectedAccountId;

              return (
                <button
                  key={acc.id}
                  type="button"
                  onClick={() => {
                    onSelectAccount(acc.id);
                    setIsOpen(false);
                  }}
                  className={`w-full px-3.5 py-2.5 flex items-center justify-between text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                    isSelected
                      ? isLight
                        ? 'font-bold'
                        : 'bg-slate-700 text-white font-bold'
                      : isLight
                      ? 'text-slate-700 hover:bg-slate-50'
                      : 'text-slate-200 hover:bg-slate-700/60 hover:text-white'
                  }`}
                  style={
                    isSelected
                      ? {
                          backgroundColor: 'var(--color-primary-10)',
                          color: 'var(--color-primary)',
                        }
                      : undefined
                  }
                >
                  <span className="flex items-center gap-2.5 truncate">
                    <Icon className={`w-4 h-4 shrink-0 ${colorClass}`} />
                    <span className="font-semibold truncate">
                      {isEn ? acc.nameEnglish : acc.nameBangla}
                    </span>
                    {showBalances && acc.currentBalance !== undefined && (
                      <span className="text-[11px] text-slate-400 font-mono shrink-0">
                        ({formatCurrency(acc.currentBalance, !isEn)})
                      </span>
                    )}
                  </span>
                  {isSelected && (
                    <Check className="w-4 h-4 shrink-0 ml-2" style={{ color: 'var(--color-primary)' }} />
                  )}
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
