import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Moon,
  Sun,
  HardDrive,
  Download,
  Trash2,
  LogOut,
  Sparkles,
  Info,
  Car,
} from 'lucide-react';
import {
  obtenerEstadisticas,
  formatearBytes,
  exportarTodasLasFotosZip,
  sembrarDatosDemo,
} from '../db/storage';
import { ConfirmarDialog } from './Dialogos';

interface AjustesViewProps {
  oscuro: boolean;
  onCambiarTema: (oscuro: boolean) => void;
  onVolver: () => void;
  onSalirApp: () => void;
}

export const AjustesView: React.FC<AjustesViewProps> = ({
  oscuro,
  onCambiarTema,
  onVolver,
  onSalirApp,
}) => {
  const [estadisticas, setEstadisticas] = useState({
    totalCarpetas: 0,
    totalFotos: 0,
    totalBytes: 0,
    espacioLibreTexto: 'Calculando…',
  });
  const [exportando, setExportando] = useState(false);
  const [mostrarConfirmarSalida, setMostrarConfirmarSalida] = useState(false);
  const [mostrarConfirmarLimpieza, setMostrarConfirmarLimpieza] = useState(false);

  const cargarEstadisticas = async () => {
    const stats = await obtenerEstadisticas();
    setEstadisticas(stats);
  };

  useEffect(() => {
    cargarEstadisticas();
  }, []);

  // Descargar ZIP completo de todas las carpetas
  const handleExportarZip = async () => {
    setExportando(true);
    try {
      const blob = await exportarTodasLasFotosZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `GaleriaTaller_Copia_${new Date().toISOString().slice(0, 10)}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error al exportar ZIP:', err);
    } finally {
      setExportando(false);
    }
  };

  const handleCargarDemo = async () => {
    await sembrarDatosDemo();
    await cargarEstadisticas();
  };

  const handleLimpiarTodo = async () => {
    indexedDB.deleteDatabase('galeria_taller_mecanico_db');
    setMostrarConfirmarLimpieza(false);
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors pb-12">
      {/* TopAppBar Requerimiento 31 */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="max-w-2xl mx-auto px-4 h-16 flex items-center gap-3">
          <button
            onClick={onVolver}
            aria-label="Atrás"
            className="p-2 -ml-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <ArrowLeft size={22} />
          </button>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">Ajustes</h1>
        </div>
      </header>

      {/* Contenido de Ajustes Requerimiento 32, 33, 35 */}
      <main className="max-w-2xl mx-auto w-full px-4 pt-6 space-y-6">
        {/* Sección Apariencia / Tema Requerimiento 32 */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Apariencia del Taller
          </h2>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500">
                {oscuro ? <Moon size={20} /> : <Sun size={20} />}
              </div>
              <div>
                <p className="font-bold text-sm text-slate-800 dark:text-slate-100">Tema oscuro</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Ideal para talleres mecánicos e iluminación tenue
                </p>
              </div>
            </div>

            {/* Switch estilo Material */}
            <button
              onClick={() => onCambiarTema(!oscuro)}
              className={`w-14 h-8 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                oscuro ? 'bg-amber-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${
                  oscuro ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </section>

        {/* Sección Almacenamiento Usado Requerimiento 33 */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400">
            <HardDrive size={16} />
            <span>Almacenamiento del Taller</span>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-500 dark:text-slate-400">Espacio Usado</span>
              <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-1">
                {formatearBytes(estadisticas.totalBytes)}
              </p>
              <span className="text-[11px] text-slate-400">
                {estadisticas.totalFotos} fotos en {estadisticas.totalCarpetas} carpetas
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-500 dark:text-slate-400">Espacio Libre</span>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-2 truncate">
                {estadisticas.espacioLibreTexto}
              </p>
              <span className="text-[11px] text-slate-400">En almacenamiento local</span>
            </div>
          </div>

          {/* Exportar Copia de Seguridad Completa */}
          <button
            onClick={handleExportarZip}
            disabled={exportando || estadisticas.totalFotos === 0}
            className="w-full py-3 px-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs text-slate-800 dark:text-slate-200 transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Download size={16} />
            <span>
              {exportando
                ? 'Comprimiendo fotos…'
                : 'Descargar copia de seguridad en ZIP'}
            </span>
          </button>
        </section>

        {/* Herramientas de Taller y Datos */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Gestión y Demostración
          </h2>

          <button
            onClick={handleCargarDemo}
            className="w-full py-3 px-4 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition flex items-center gap-2.5 text-left"
          >
            <Sparkles size={16} className="text-amber-500 shrink-0" />
            <span>Cargar carpetas de demostración (Vehículos de prueba)</span>
          </button>

          <button
            onClick={() => setMostrarConfirmarLimpieza(true)}
            className="w-full py-3 px-4 rounded-2xl border border-red-200 dark:border-red-900/40 hover:bg-red-50 dark:hover:bg-red-950/20 text-xs font-semibold text-red-600 dark:text-red-400 transition flex items-center gap-2.5 text-left"
          >
            <Trash2 size={16} className="shrink-0" />
            <span>Borrar todas las carpetas y fotos (Reiniciar app)</span>
          </button>
        </section>

        {/* Salir de la App Requerimiento 35 */}
        <section className="pt-2">
          <button
            onClick={() => setMostrarConfirmarSalida(true)}
            className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-600/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut size={18} />
            Salir de la app
          </button>
        </section>

        {/* Información del Sistema */}
        <div className="pt-4 text-center text-xs text-slate-400 space-y-1">
          <p className="font-semibold text-slate-500 dark:text-slate-400">
            Galería Taller Mecánico • Registro de Autos
          </p>
          <p>Almacenamiento privado seguro en dispositivo</p>
        </div>
      </main>

      {/* Diálogos */}
      {mostrarConfirmarSalida && (
        <ConfirmarDialog
          titulo="Salir"
          mensaje="¿Deseas cerrar la sesión y salir de la aplicación del taller?"
          textoOk="Salir"
          textoCancelar="Permanecer aquí"
          esPeligroso={false}
          onOk={onSalirApp}
          onCancelar={() => setMostrarConfirmarSalida(false)}
        />
      )}

      {mostrarConfirmarLimpieza && (
        <ConfirmarDialog
          titulo="¿Borrar todos los datos?"
          mensaje="Esta acción eliminará permanentemente todas las fotos y carpetas registradas. No se puede deshacer."
          textoOk="Sí, borrar todo"
          textoCancelar="Cancelar"
          esPeligroso={true}
          onOk={handleLimpiarTodo}
          onCancelar={() => setMostrarConfirmarLimpieza(false)}
        />
      )}
    </div>
  );
};
