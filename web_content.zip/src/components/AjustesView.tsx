import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Moon,
  Sun,
  HardDrive,
  Download,
  Trash2,
  LogOut,
  Sparkles,
  Info,
  Car,
  FileArchive,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';
import {
  obtenerEstadisticas,
  formatearBytes,
  exportarTodasLasFotosZip,
  sembrarDatosDemo,
  descomprimirEImportarZip,
} from '../db/storage';
import { ConfirmarDialog } from './Dialogos';

interface AjustesViewProps {
  oscuro: boolean;
  onCambiarTema: (oscuro: boolean) => void;
  onVolver: () => void;
  onSalirApp: () => void;
}

export const AjustesView: React.FC<AjustesViewProps> = ({
  oscuro,
  onCambiarTema,
  onVolver,
  onSalirApp,
}) => {
  const [estadisticas, setEstadisticas] = useState({
    totalCarpetas: 0,
    totalFotos: 0,
    totalBytes: 0,
    espacioLibreTexto: 'Calculando…',
  });
  const [exportando, setExportando] = useState(false);
  const [mostrarConfirmarSalida, setMostrarConfirmarSalida] = useState(false);
  const [mostrarConfirmarLimpieza, setMostrarConfirmarLimpieza] = useState(false);

  const cargarEstadisticas = async () => {
    const stats = await obtenerEstadisticas();
    setEstadisticas(stats);
  };

  useEffect(() => {
    cargarEstadisticas();
  }, []);

  const fileZipInputRef = React.useRef<HTMLInputElement>(null);
  const [descomprimiendo, setDescomprimiendo] = useState(false);
  const [mensajeImportacion, setMensajeImportacion] = useState<string | null>(null);

  const handleImportarZip = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    setDescomprimiendo(true);
    try {
      const res = await descomprimirEImportarZip(archivo);
      setMensajeImportacion(
        `¡Archivo ZIP descomprimido con éxito! Se importaron ${res.fotosImportadas} fotos en ${res.carpetasCreadas} carpetas.`
      );
      await cargarEstadisticas();
    } catch (err) {
      console.error('Error al descomprimir:', err);
      alert('No se pudo descomprimir el archivo. Asegúrate de que sea un archivo ZIP válido.');
    } finally {
      setDescomprimiendo(false);
      if (fileZipInputRef.current) fileZipInputRef.current.value = '';
    }
  };

  // Descargar ZIP completo de todas las carpetas
  const handleExportarZip = async () => {
    setExportando(true);
    try {
      const blob = await exportarTodasLasFotosZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `GaleriaTaller_Fotos_${new Date().toISOString().slice(0, 10)}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error al exportar ZIP:', err);
    } finally {
      setExportando(false);
    }
  };

  const handleCargarDemo = async () => {
    await sembrarDatosDemo();
    await cargarEstadisticas();
  };

  const handleLimpiarTodo = async () => {
    indexedDB.deleteDatabase('galeria_taller_mecanico_db');
    setMostrarConfirmarLimpieza(false);
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors pb-12">
      {/* TopAppBar Requerimiento 31 */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="max-w-2xl mx-auto px-4 h-16 flex items-center gap-3">
          <button
            onClick={onVolver}
            aria-label="Atrás"
            className="p-2 -ml-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <ArrowLeft size={22} />
          </button>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">Ajustes</h1>
        </div>
      </header>

      {/* Contenido de Ajustes Requerimiento 32, 33, 35 */}
      <main className="max-w-2xl mx-auto w-full px-4 pt-6 space-y-6">
        {/* Sección Apariencia / Tema Requerimiento 32 */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Apariencia del Taller
          </h2>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500">
                {oscuro ? <Moon size={20} /> : <Sun size={20} />}
              </div>
              <div>
                <p className="font-bold text-sm text-slate-800 dark:text-slate-100">Tema oscuro</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Ideal para talleres mecánicos e iluminación tenue
                </p>
              </div>
            </div>

            {/* Switch estilo Material */}
            <button
              onClick={() => onCambiarTema(!oscuro)}
              className={`w-14 h-8 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                oscuro ? 'bg-amber-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${
                  oscuro ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </section>

        {/* Sección Almacenamiento Usado Requerimiento 33 */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400">
            <HardDrive size={16} />
            <span>Almacenamiento del Taller</span>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-500 dark:text-slate-400">Espacio Usado</span>
              <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-1">
                {formatearBytes(estadisticas.totalBytes)}
              </p>
              <span className="text-[11px] text-slate-400">
                {estadisticas.totalFotos} fotos en {estadisticas.totalCarpetas} carpetas
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-500 dark:text-slate-400">Espacio Libre</span>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-2 truncate">
                {estadisticas.espacioLibreTexto}
              </p>
              <span className="text-[11px] text-slate-400">En almacenamiento local</span>
            </div>
          </div>

          {mensajeImportacion && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 size={16} className="shrink-0 text-emerald-500" />
              <span>{mensajeImportacion}</span>
            </div>
          )}

          {/* Acciones de Archivos ZIP */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            {/* Exportar Copia de Seguridad Completa */}
            <button
              onClick={handleExportarZip}
              disabled={exportando || estadisticas.totalFotos === 0}
              className="py-3 px-4 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md shadow-amber-600/20 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Download size={16} />
              <span>
                {exportando
                  ? 'Comprimiendo fotos…'
                  : 'Exportar todo en ZIP'}
              </span>
            </button>

            {/* Descomprimir e Importar ZIP */}
            <input
              type="file"
              ref={fileZipInputRef}
              accept=".zip,application/zip,application/x-zip-compressed"
              onChange={handleImportarZip}
              className="hidden"
            />
            <button
              onClick={() => fileZipInputRef.current?.click()}
              disabled={descomprimiendo}
              className="py-3 px-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition flex items-center justify-center gap-2"
            >
              <FileArchive size={16} className="text-amber-500" />
              <span>
                {descomprimiendo ? 'Descomprimiendo…' : 'Descomprimir e importar ZIP'}
              </span>
            </button>
          </div>

          {/* Información de Compatibilidad con Play Store */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 text-xs text-slate-500 dark:text-slate-400 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300">
              <Smartphone size={14} className="text-amber-500" />
              <span>Compatibilidad con apps de Play Store e Internet:</span>
            </div>
            <p className="leading-relaxed">
              Los archivos ZIP exportados utilizan compresión estándar <strong>DEFLATE</strong> y codificación de rutas universal. Puedes abrirlos y descomprimirlos directamente en tu teléfono con:
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {['ZArchiver', 'RAR de RARLAB', 'Files de Google', 'Samsung Mis Archivos', 'Xiaomi Administrador', 'WinRAR / 7-Zip'].map((app) => (
                <span key={app} className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 text-[11px] font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                  ✓ {app}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* Herramientas de Taller y Datos */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Gestión y Demostración
          </h2>

          <button
            onClick={handleCargarDemo}
            className="w-full py-3 px-4 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition flex items-center gap-2.5 text-left"
          >
            <Sparkles size={16} className="text-amber-500 shrink-0" />
            <span>Cargar carpetas de demostración (Vehículos de prueba)</span>
          </button>

          <button
            onClick={() => setMostrarConfirmarLimpieza(true)}
            className="w-full py-3 px-4 rounded-2xl border border-red-200 dark:border-red-900/40 hover:bg-red-50 dark:hover:bg-red-950/20 text-xs font-semibold text-red-600 dark:text-red-400 transition flex items-center gap-2.5 text-left"
          >
            <Trash2 size={16} className="shrink-0" />
            <span>Borrar todas las carpetas y fotos (Reiniciar app)</span>
          </button>
        </section>

        {/* Sección Formato HTML para Convertir a APK */}
        <section className="bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent dark:from-amber-500/15 dark:to-transparent rounded-3xl p-5 border border-amber-500/30 shadow-xs space-y-3.5">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
            <FileArchive size={16} />
            <span>Formato HTML (Listo para convertir a APK)</span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Hemos convertido y empaquetado toda la aplicación en un archivo <strong>HTML independiente (index.html)</strong> sin dependencias de Node.js ni servidores. Puedes descargarlo y convertirlo directamente a archivo <strong>.APK</strong> para instalar en cualquier teléfono Android.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <a
              href="/galeria_taller_apk.html"
              download="index.html"
              className="py-3 px-4 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md shadow-amber-600/25 transition flex items-center justify-center gap-2 cursor-pointer text-center"
            >
              <Download size={16} />
              <span>Descargar archivo index.html</span>
            </a>

            <a
              href="/galeria_taller_html_para_apk.zip"
              download="galeria_taller_html_para_apk.zip"
              className="py-3 px-4 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-center"
            >
              <FileArchive size={16} className="text-amber-400 dark:text-amber-600" />
              <span>Descargar Paquete ZIP para APK</span>
            </a>
          </div>

          <div className="p-3 rounded-xl bg-white/70 dark:bg-slate-900/70 border border-amber-500/20 text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              ¿Cómo convertir a APK en 1 minuto?
            </p>
            <p>
              1. Sube el <strong>index.html</strong> o el ZIP a herramientas como <em>AppsGeyser</em>, <em>Website 2 APK Builder</em> o <em>Web2Apk</em>.
            </p>
            <p>
              2. O envíatelo por WhatsApp/correo, ábrelo en Chrome en tu móvil y toca <strong>"Agregar a pantalla principal"</strong> para instalarlo directamente.
            </p>
          </div>
        </section>

        {/* Salir de la App Requerimiento 35 */}
        <section className="pt-2">
          <button
            onClick={() => setMostrarConfirmarSalida(true)}
            className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-600/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut size={18} />
            Salir de la app
          </button>
        </section>

        {/* Información del Sistema */}
        <div className="pt-4 text-center text-xs text-slate-400 space-y-1">
          <p className="font-semibold text-slate-500 dark:text-slate-400">
            Galería Taller Mecánico • Registro de Autos
          </p>
          <p>Almacenamiento privado seguro en dispositivo</p>
        </div>
      </main>

      {/* Diálogos */}
      {mostrarConfirmarSalida && (
        <ConfirmarDialog
          titulo="Salir"
          mensaje="¿Deseas cerrar la sesión y salir de la aplicación del taller?"
          textoOk="Salir"
          textoCancelar="Permanecer aquí"
          esPeligroso={false}
          onOk={onSalirApp}
          onCancelar={() => setMostrarConfirmarSalida(false)}
        />
      )}

      {mostrarConfirmarLimpieza && (
        <ConfirmarDialog
          titulo="¿Borrar todos los datos?"
          mensaje="Esta acción eliminará permanentemente todas las fotos y carpetas registradas. No se puede deshacer."
          textoOk="Sí, borrar todo"
          textoCancelar="Cancelar"
          esPeligroso={true}
          onOk={handleLimpiarTodo}
          onCancelar={() => setMostrarConfirmarLimpieza(false)}
        />
      )}
    </div>
  );
};
