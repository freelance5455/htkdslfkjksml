import React, { useState } from 'react';
import {
  Tv,
  Radio,
  DollarSign,
  Users,
  TrendingUp,
  Sparkles,
  Zap,
  CheckCircle2,
  Lock,
  ArrowRight,
  ShieldCheck,
  Flame,
  Award,
  Film,
  Building2,
  Globe,
} from 'lucide-react';
import { SubsidiaryChannel, TVProgram } from '../types/game';
import { soundFx } from '../utils/audio';

interface GroupChannelsHubProps {
  channels: SubsidiaryChannel[];
  cash: number;
  onUnlockChannel: (channelId: string) => void;
  onUpgradeChannel: (channelId: string) => void;
  onTriggerSimulcast?: () => void;
  onOpenSchedule: () => void;
}

export const GroupChannelsHub: React.FC<GroupChannelsHubProps> = ({
  channels,
  cash,
  onUnlockChannel,
  onUpgradeChannel,
  onTriggerSimulcast,
  onOpenSchedule,
}) => {
  const [selectedChannelId, setSelectedChannelId] = useState<string>(channels[0]?.id || 'chan-noticias');
  const [simulcastCooldown, setSimulcastCooldown] = useState(false);

  const activeChannels = channels.filter((c) => c.isUnlocked);
  const totalSubscribers = activeChannels.reduce((sum, c) => sum + c.subscribers, 0);
  const totalDailyRevenue = activeChannels.reduce(
    (sum, c) => sum + Math.round(c.subscribers * c.dailyRevenuePerSubscriber),
    0
  );

  const currentChannel = channels.find((c) => c.id === selectedChannelId) || channels[0];

  const handleSimulcast = () => {
    if (simulcastCooldown) return;
    soundFx.playPlantao();
    setSimulcastCooldown(true);
    if (onTriggerSimulcast) {
      onTriggerSimulcast();
    }
    setTimeout(() => setSimulcastCooldown(false), 20000);
  };

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 md:p-4 shadow-md flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-amber-400" />
            <span>Canais do Grupo & TV por Assinatura</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Crie canais pagos (como canal de notícias 24h ou esportes). Eles geram faturamento diário por assinante e fornecem atrações de graça para o Canal Mãe!
          </p>
        </div>

        {/* Financial Highlights */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-right">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">BASE DE ASSINANTES</span>
            <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1 justify-end">
              <Users className="w-3.5 h-3.5" />
              {totalSubscribers.toLocaleString('pt-BR')} assinantes
            </span>
          </div>

          <div className="bg-slate-950 border border-emerald-500/30 rounded-xl px-3 py-2 text-right">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">FATURAMENTO DIÁRIO</span>
            <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 justify-end">
              <DollarSign className="w-3.5 h-3.5" />
              + R$ {totalDailyRevenue.toLocaleString('pt-BR')} / dia
            </span>
          </div>
        </div>
      </div>

      {/* Channels Selector Pills */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {channels.map((chan) => {
          const isSelected = chan.id === selectedChannelId;
          return (
            <button
              key={chan.id}
              onClick={() => {
                soundFx.playClick();
                setSelectedChannelId(chan.id);
              }}
              className={`p-2.5 rounded-xl border flex items-center gap-2 transition-all cursor-pointer text-left active:scale-95 ${
                isSelected
                  ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-950/20'
                  : chan.isUnlocked
                  ? 'bg-slate-900 border-slate-700/80 hover:border-slate-600'
                  : 'bg-slate-950/60 border-slate-800 opacity-75'
              }`}
            >
              <span className="text-xl shrink-0">{chan.iconEmoji}</span>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-white truncate flex items-center gap-1">
                  <span>{chan.name}</span>
                </div>
                <div className="text-[10px] font-mono text-slate-400">
                  {chan.isUnlocked ? (
                    <span className="text-emerald-400 font-bold">● No Ar</span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" /> Bloqueado
                    </span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Channel Details Card */}
      {currentChannel && (
        <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col gap-4">
          {/* Channel Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center text-3xl shrink-0 shadow-inner"
                style={{ backgroundColor: `${currentChannel.color}25`, border: `1px solid ${currentChannel.color}60` }}
              >
                {currentChannel.iconEmoji}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-lg font-black text-white">{currentChannel.name}</h3>
                  <span
                    className="text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase"
                    style={{ backgroundColor: `${currentChannel.color}30`, color: currentChannel.color }}
                  >
                    {currentChannel.badge}
                  </span>
                  {currentChannel.isUnlocked && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500 text-emerald-400 font-bold">
                      NÍVEL {currentChannel.qualityLevel}
                    </span>
                  )}
                </div>
                <p className="text-xs text-amber-300 font-medium italic mt-0.5">{currentChannel.tagline}</p>
              </div>
            </div>

            {/* Status or Launch Action */}
            <div>
              {!currentChannel.isUnlocked ? (
                <button
                  onClick={() => {
                    if (cash >= currentChannel.unlockCost) {
                      soundFx.playVictory();
                      onUnlockChannel(currentChannel.id);
                    }
                  }}
                  disabled={cash < currentChannel.unlockCost}
                  className={`min-h-[44px] px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 cursor-pointer active:scale-95 transition-all shadow-md ${
                    cash >= currentChannel.unlockCost
                      ? 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 shadow-emerald-950/40'
                      : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Fundar Canal (R$ {currentChannel.unlockCost.toLocaleString('pt-BR')})</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 flex-wrap">
                  {currentChannel.type === 'noticias' && (
                    <button
                      onClick={handleSimulcast}
                      disabled={simulcastCooldown}
                      className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                        simulcastCooldown
                          ? 'bg-slate-800 text-slate-500'
                          : 'bg-red-600 hover:bg-red-500 text-white shadow-md shadow-red-950/40 animate-pulse'
                      }`}
                      title="Abrir transmissão conjunta com o canal de notícias no Canal Mãe (+5.0 IBOPE)"
                    >
                      <Zap className="w-4 h-4" />
                      <span>{simulcastCooldown ? 'Rede em Andamento...' : 'Simulcast Notícias (+5 IBOPE)'}</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      if (cash >= currentChannel.upgradeCost && currentChannel.qualityLevel < 5) {
                        soundFx.playCash();
                        onUpgradeChannel(currentChannel.id);
                      }
                    }}
                    disabled={cash < currentChannel.upgradeCost || currentChannel.qualityLevel >= 5}
                    className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                      currentChannel.qualityLevel >= 5
                        ? 'bg-slate-800 text-slate-500'
                        : cash >= currentChannel.upgradeCost
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-950/40'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>
                      {currentChannel.qualityLevel >= 5
                        ? 'Nível Máximo (5/5)'
                        : `Expandir Assinantes (R$ ${currentChannel.upgradeCost.toLocaleString('pt-BR')})`}
                    </span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Channel Description */}
          <p className="text-xs text-slate-300 leading-relaxed">{currentChannel.description}</p>

          {/* Channel Performance Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">ASSINANTES NA REDE</span>
              <span className="text-sm font-mono font-bold text-white mt-0.5 block">
                {currentChannel.isUnlocked
                  ? `${currentChannel.subscribers.toLocaleString('pt-BR')} lares`
                  : 'Aguardando Lançamento'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">FATURAMENTO DIÁRIO</span>
              <span className="text-sm font-mono font-bold text-emerald-400 mt-0.5 block">
                {currentChannel.isUnlocked
                  ? `+ R$ ${Math.round(currentChannel.subscribers * currentChannel.dailyRevenuePerSubscriber).toLocaleString('pt-BR')} / dia`
                  : 'R$ 0 / dia'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">REPASSE POR ASSINANTE</span>
              <span className="text-sm font-mono font-bold text-amber-400 mt-0.5 block">
                R$ {currentChannel.dailyRevenuePerSubscriber.toFixed(2)} / dia
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">STATUS DE SINAL</span>
              <span
                className={`text-sm font-mono font-bold mt-0.5 block ${
                  currentChannel.isUnlocked ? 'text-emerald-400' : 'text-slate-500'
                }`}
              >
                {currentChannel.isUnlocked ? 'Sinal 4K / Pay-TV Ativo' : 'Fora do Ar'}
              </span>
            </div>
          </div>

          {/* Synergy with Mother Channel (Canal Mãe) */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Sinergia & Vantagens para o Canal Mãe (TV Aberta)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-1">
              {currentChannel.synergyPerks.map((perk, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{perk}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Syndicated Productions for the Mother Channel */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-amber-400" />
                Atrações Geradas para Retransmissão no Canal Mãe (Custo R$ 0)
              </h4>
              <button
                onClick={() => {
                  soundFx.playClick();
                  onOpenSchedule();
                }}
                className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>Ver Grade Semanal</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {currentChannel.syndicatedShows.map((show) => (
                <div
                  key={show.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{show.title}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 uppercase">
                        {show.genre}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                      <span className="text-emerald-400 font-bold">Custo de Produção: GRÁTIS</span>
                      <span>·</span>
                      <span>Qualidade: {show.quality}%</span>
                      <span>·</span>
                      <span>Hype: {show.hype}%</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundFx.playClick();
                      onOpenSchedule();
                    }}
                    className="min-h-[38px] px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-300 text-xs font-bold cursor-pointer active:scale-95"
                  >
                    Escalar
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
