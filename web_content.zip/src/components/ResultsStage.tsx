import React, { useState } from 'react';
import {
  Coins,
  Gem,
  Sparkles,
  SlidersHorizontal,
  Wand2,
  FileCode,
  ChevronDown,
  ChevronUp,
  Search,
  CheckCircle,
  Copy,
  Check
} from 'lucide-react';
import { IdentifiedResource, ModificationMethod, CurrencyType } from '../types';

interface ResultsStageProps {
  resources: IdentifiedResource[];
  packageName: string;
  onSelectModificationMethod: (method: ModificationMethod) => void;
  onReset: () => void;
}

export const ResultsStage: React.FC<ResultsStageProps> = ({
  resources,
  packageName,
  onSelectModificationMethod,
  onReset
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedSnippets, setExpandedSnippets] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleSnippet = (id: string) => {
    setExpandedSnippets((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleCopyPath = (filePath: string, id: string) => {
    navigator.clipboard.writeText(filePath);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getCurrencyBadge = (type: CurrencyType) => {
    switch (type) {
      case 'coins':
        return {
          icon: <Coins className="w-4 h-4 text-amber-400" />,
          label: 'Coins',
          bgColor: 'bg-amber-500/10 border-amber-500/30 text-amber-300'
        };
      case 'gems':
        return {
          icon: <Gem className="w-4 h-4 text-emerald-400" />,
          label: 'Gems',
          bgColor: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
        };
      case 'diamonds':
        return {
          icon: <Sparkles className="w-4 h-4 text-cyan-400" />,
          label: 'Diamonds',
          bgColor: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
        };
      default:
        return {
          icon: <Coins className="w-4 h-4 text-purple-400" />,
          label: type.charAt(0).toUpperCase() + type.slice(1),
          bgColor: 'bg-purple-500/10 border-purple-500/30 text-purple-300'
        };
    }
  };

  const filteredResources = resources.filter((res) => {
    const matchesFilter = filterType === 'all' || res.currencyType === filterType;
    const matchesSearch =
      res.filePath.toLowerCase().includes(searchQuery.toLowerCase()) ||
      res.keyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(res.originalValue).includes(searchQuery);
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="flex flex-col w-full max-w-4xl mx-auto py-2">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider font-mono">
              Analysis Completed
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
            Identified Game Resources &amp; Values
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Package: <span className="text-slate-200 font-mono">{packageName}</span> • Found{' '}
            <span className="text-emerald-400 font-bold">{resources.length}</span> resource definitions
          </p>
        </div>

        <button
          onClick={onReset}
          className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition self-start sm:self-auto"
        >
          Analyze Another File
        </button>
      </div>

      {/* INFORM USER THAT VALUES CAN BE MODIFIED & CHOOSE MODIFICATION METHOD */}
      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-emerald-500/30 shadow-xl mb-6">
        <div className="flex items-start gap-3.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white">
              These game resource values can be modified.
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
              All locations defining game resource values—such as &quot;coins&quot;, &quot;gems&quot;, and &quot;diamonds&quot;—have been located. Please choose a modification method to proceed:
            </p>
          </div>
        </div>

        {/* 2 CLICKABLE SELECTION CARDS WITH EXACT LABELS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
          {/* OPTION 1: Manual Editing */}
          <button
            onClick={() => onSelectModificationMethod('manual')}
            className="p-5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border-2 border-slate-700 hover:border-emerald-400 text-left transition-all duration-200 group relative overflow-hidden shadow-lg hover:shadow-emerald-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                  <SlidersHorizontal className="w-5 h-5 text-amber-400" />
                </div>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-700">
                  Granular Control
                </span>
              </div>
              <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                Manual Editing of each identified file and value
              </h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Review each file independently, inspect code snippets, and manually customize individual values for coins, gems, and diamonds.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs font-semibold text-emerald-400">
              <span>Select Manual Editing</span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </div>
          </button>

          {/* OPTION 2: Automatic Editing */}
          <button
            onClick={() => onSelectModificationMethod('automatic')}
            className="p-5 rounded-xl bg-gradient-to-br from-emerald-950/40 via-slate-800/90 to-teal-950/30 hover:from-emerald-950/60 hover:to-teal-950/50 border-2 border-emerald-500/50 hover:border-emerald-400 text-left transition-all duration-200 group relative overflow-hidden shadow-lg shadow-emerald-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                  <Wand2 className="w-5 h-5 text-emerald-400" />
                </div>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Recommended • Instant
                </span>
              </div>
              <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                Automatic Editing of all identified files and values
              </h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Specify a target replacement value (e.g. 999,999) and let the app automatically patch all identified currencies across all package files at once.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-emerald-500/30 flex items-center justify-between text-xs font-semibold text-emerald-400">
              <span>Select Automatic Editing</span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </div>
          </button>
        </div>
      </div>

      {/* Resource Inspection & Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-semibold text-slate-400 mr-2">Filter by Currency:</span>
            {['all', 'coins', 'gems', 'diamonds', 'gold'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                  filterType === type
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search file or key..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 w-full sm:w-48"
            />
          </div>
        </div>

        {/* Identified Files and Locations List */}
        <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
          {filteredResources.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No matching resources found for query &quot;{searchQuery}&quot;.
            </div>
          ) : (
            filteredResources.map((res) => {
              const badge = getCurrencyBadge(res.currencyType);
              const isExpanded = !!expandedSnippets[res.id];

              return (
                <div
                  key={res.id}
                  className="rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition overflow-hidden"
                >
                  <div className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <FileCode className="w-4 h-4 text-slate-400" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-xs font-bold text-white truncate max-w-[280px] sm:max-w-md">
                            {res.filePath}
                          </span>
                          <button
                            onClick={() => handleCopyPath(res.filePath, res.id)}
                            className="text-slate-400 hover:text-slate-200 p-0.5 rounded"
                            title="Copy file path"
                          >
                            {copiedId === res.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/60">
                            Line {res.lineNumber}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          <span
                            className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full border ${badge.bgColor}`}
                          >
                            {badge.icon}
                            {badge.label}
                          </span>

                          <span className="text-xs font-mono text-slate-300">
                            Key:{' '}
                            <span className="text-emerald-400 font-semibold">{res.keyName}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 flex-shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                      <div className="text-right">
                        <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                          Current Value
                        </span>
                        <span className="text-sm font-bold text-amber-400 font-mono">
                          {res.currentValue.toLocaleString()}
                        </span>
                      </div>

                      <button
                        onClick={() => toggleSnippet(res.id)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 flex items-center gap-1 transition"
                      >
                        <span>{isExpanded ? 'Hide Code' : 'View Code'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Code Context */}
                  {isExpanded && (
                    <div className="px-3.5 pb-3.5 pt-1 border-t border-slate-800/80 bg-slate-900/60 font-mono text-xs text-slate-300">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                        <span>Location Context (Snippet):</span>
                        <span className="uppercase text-slate-400">{res.fileType}</span>
                      </div>
                      <pre className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/90 overflow-x-auto text-emerald-300 text-[11px] leading-relaxed">
                        {res.contextSnippet}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
