import React, { useState, useEffect } from "react";
import { Key, ExternalLink, Check, Copy, X, ShieldCheck, Sparkles, HelpCircle, RefreshCw } from "lucide-react";

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  hasServerKey: boolean | null;
  userApiKey: string;
  onSaveUserApiKey: (key: string) => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({
  isOpen,
  onClose,
  hasServerKey,
  userApiKey,
  onSaveUserApiKey,
}) => {
  if (!isOpen) return null;

  const [inputKey, setInputKey] = useState(userApiKey);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    setInputKey(userApiKey);
  }, [userApiKey]);

  const handleSave = () => {
    onSaveUserApiKey(inputKey.trim());
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleClear = () => {
    setInputKey("");
    onSaveUserApiKey("");
  };

  const activeKeyPresent = Boolean(inputKey.trim() || hasServerKey);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden p-6 sm:p-7 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>Free Gemini API Key Setup</span>
                {activeKeyPresent && (
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                    Active
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">Google AI Studio API Key Configuration</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Key Info Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-purple-950/40 to-slate-950 border border-purple-500/20 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
              <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
              <span>Get Your Free Gemini API Key</span>
            </div>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition shadow-md shadow-purple-600/20"
            >
              <span>Get Free Key</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Google AI Studio provides <strong>100% free Gemini API keys</strong> with generous rate limits. No credit card required.
          </p>
        </div>

        {/* Custom API Key Input */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Enter Your Gemini API Key</span>
            {userApiKey && (
              <button
                onClick={handleClear}
                className="text-[11px] text-rose-400 hover:underline"
              >
                Clear Saved Key
              </button>
            )}
          </label>
          <div className="relative">
            <input
              type="password"
              placeholder="AIzaSy..."
              value={inputKey}
              onChange={(e) => setInputKey(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-slate-100 placeholder-slate-600 text-xs font-mono focus:outline-none transition"
            />
          </div>
          <p className="text-[11px] text-slate-400">
            Keys are stored securely in your browser's local storage and used directly for image synthesis requests.
          </p>
        </div>

        {/* Status indicator */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center gap-3">
          <ShieldCheck className={`w-5 h-5 shrink-0 ${activeKeyPresent ? "text-emerald-400" : "text-amber-400"}`} />
          <div className="flex-1 text-[11px]">
            {activeKeyPresent ? (
              <span className="text-emerald-300 font-medium">
                Gemini AI Engine is ready for high-resolution image generation & prompt enhancement.
              </span>
            ) : (
              <span className="text-amber-300 font-medium">
                No key active yet. The studio will use high-resolution demo artwork generation until a key is added.
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/20 transition"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Saved!</span>
              </>
            ) : (
              <span>Save & Apply Key</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
