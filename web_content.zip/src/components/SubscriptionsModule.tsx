import React, { useState, useMemo } from 'react';
import {
  Plus,
  CheckCircle2,
  AlertCircle,
  CalendarClock,
  History,
  Edit3,
  Trash2,
  X,
} from 'lucide-react';
import {
  Account,
  BillingCycle,
  SubscriptionPaymentRecord,
  SubscriptionRecord,
} from '../types/finance';
import {
  formatBDT,
  formatDateBnEn,
  getCurrentYearMonth,
  getTodayISO,
  paisaToInputString,
  parseAmountToPaisa,
} from '../utils/money';

export function getThisMonthPayment(
  sub: SubscriptionRecord,
  currentYM: string
): SubscriptionPaymentRecord | undefined {
  return sub.paymentHistory.find(
    (p) =>
      p.paidDate.startsWith(currentYM) ||
      p.forPeriodDueDate.startsWith(currentYM)
  );
}

interface SubscriptionsModuleProps {
  subscriptions: SubscriptionRecord[];
  accounts: Account[];
  useBengaliDigits: boolean;
  onSaveSubscription: (
    subData: Omit<SubscriptionRecord, 'id' | 'createdAt' | 'paymentHistory'>,
    existingId?: string
  ) => void;
  onDeleteSubscription: (sub: SubscriptionRecord) => void;
  onRequestPaySubscription: (sub: SubscriptionRecord) => void;
}

export const SubscriptionsModule: React.FC<SubscriptionsModuleProps> = ({
  subscriptions,
  accounts,
  useBengaliDigits,
  onSaveSubscription,
  onDeleteSubscription,
  onRequestPaySubscription,
}) => {
  const todayISO = getTodayISO();
  const currentYM = getCurrentYearMonth();

  const [showSubModal, setShowSubModal] = useState(false);
  const [editingSub, setEditingSub] = useState<SubscriptionRecord | null>(null);
  const [nameBn, setNameBn] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [cycle, setCycle] = useState<BillingCycle>('MONTHLY');
  const [customDaysInput, setCustomDaysInput] = useState('30');
  const [nextDueDate, setNextDueDate] = useState(todayISO);
  const [category, setCategory] = useState('বিদ্যুৎ ও ইন্টারনেট বিল');
  const [defaultAccountId, setDefaultAccountId] = useState(
    accounts[0]?.id ?? ''
  );
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(
    null
  );

  const getAccountName = (accId?: string) => {
    if (!accId) return 'নগদ ক্যাশ';
    return accounts.find((a) => a.id === accId)?.nameBn ?? 'নগদ ক্যাশ';
  };

  const totals = useMemo(() => {
    let monthlyEquivalentPaisa = 0;
    let overdueCount = 0;

    for (const s of subscriptions) {
      if (!s.active) continue;
      if (s.cycle === 'MONTHLY') {
        monthlyEquivalentPaisa += s.amountPaisa;
      } else if (s.cycle === 'YEARLY') {
        monthlyEquivalentPaisa += Math.round(s.amountPaisa / 12);
      } else {
        const days = s.customDays && s.customDays > 0 ? s.customDays : 30;
        const perYear = Math.round((s.amountPaisa * 365) / days);
        monthlyEquivalentPaisa += Math.round(perYear / 12);
      }

      const paidThisMonth = getThisMonthPayment(s, currentYM);
      if (!paidThisMonth && s.nextDueDate < todayISO) {
        overdueCount += 1;
      }
    }

    return {
      monthlyEquivalentPaisa,
      overdueCount,
    };
  }, [subscriptions, todayISO, currentYM]);

  const openNewSubModal = () => {
    setEditingSub(null);
    setNameBn('');
    setAmountInput('');
    setCycle('MONTHLY');
    setCustomDaysInput('30');
    setNextDueDate(todayISO);
    setCategory('বিদ্যুৎ ও ইন্টারনেট বিল');
    setDefaultAccountId(accounts[0]?.id ?? '');
    setNotes('');
    setFormError(null);
    setShowSubModal(true);
  };

  const openEditSubModal = (sub: SubscriptionRecord) => {
    setEditingSub(sub);
    setNameBn(sub.nameBn);
    setAmountInput(paisaToInputString(sub.amountPaisa));
    setCycle(sub.cycle);
    setCustomDaysInput(String(sub.customDays ?? 30));
    setNextDueDate(sub.nextDueDate);
    setCategory(sub.category);
    setDefaultAccountId(sub.defaultAccountId ?? '');
    setNotes(sub.notes);
    setFormError(null);
    setShowSubModal(true);
  };

  const handleSaveSubSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!nameBn.trim()) {
      setFormError('অনুগ্রহ করে বিলের নাম লিখুন।');
      return;
    }

    const parsedAmount = parseAmountToPaisa(amountInput);
    if (parsedAmount === null || parsedAmount <= 0) {
      setFormError('অনুগ্রহ করে সঠিক বিলের পরিমাণ লিখুন।');
      return;
    }

    const parsedCustomDays = parseInt(customDaysInput, 10);
    if (
      cycle === 'CUSTOM_DAYS' &&
      (Number.isNaN(parsedCustomDays) || parsedCustomDays <= 0)
    ) {
      setFormError('নির্দিষ্ট দিনের সংখ্যা লিখুন (যেমন: ১৫ বা ৯০)।');
      return;
    }

    onSaveSubscription(
      {
        nameBn: nameBn.trim(),
        nameEn: nameBn.trim(),
        amountPaisa: parsedAmount,
        cycle,
        customDays: cycle === 'CUSTOM_DAYS' ? parsedCustomDays : undefined,
        nextDueDate,
        category,
        defaultAccountId: defaultAccountId || undefined,
        active: true,
        notes: notes.trim(),
      },
      editingSub?.id
    );
    setShowSubModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            নিয়মিত বিল ও সাবস্ক্রিপশন
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            ভাড়া, ইন্টারনেট, বিদ্যুৎ বিল এবং পরিশোধের মাধ্যম ও ইতিহাস
          </p>
        </div>

        <button
          type="button"
          onClick={openNewSubModal}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন বিল যোগ করুন</span>
        </button>
      </div>

      {/* Summary Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            মাসিক গড় বিল
          </p>
          <p className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatBDT(totals.monthlyEquivalentPaisa, { useBengaliDigits })}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            সকল সক্রিয় বিলের মাসিক হিসাব
          </p>
        </div>

        <div className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            মেয়াদোত্তীর্ণ বিল
          </p>
          <p
            className={`mt-1 text-2xl font-bold font-mono tabular-nums ${
              totals.overdueCount > 0
                ? 'text-red-600 dark:text-red-400'
                : 'text-emerald-700 dark:text-emerald-400'
            }`}
          >
            {totals.overdueCount}টি
          </p>
          <p className="mt-1 text-xs text-slate-500">
            মাসিক বিল একবার পরিশোধ করলে পরবর্তী মাস ছাড়া আবার পরিশোধ করা যাবেনা
          </p>
        </div>
      </section>

      {/* Subscriptions List */}
      <div className="space-y-4">
        {subscriptions.length === 0 ? (
          <div className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-12 text-center shadow-xs">
            <CalendarClock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
              কোনো নিয়মিত বিল যোগ করা হয়নি
            </p>
          </div>
        ) : (
          subscriptions.map((sub) => {
            const thisMonthPayment = getThisMonthPayment(sub, currentYM);
            const isLockedForThisMonth = Boolean(thisMonthPayment);
            const paidAccountName = thisMonthPayment
              ? getAccountName(thisMonthPayment.accountId ?? sub.defaultAccountId)
              : null;

            const isOverdue = !isLockedForThisMonth && sub.nextDueDate < todayISO;
            const cycleLabel =
              sub.cycle === 'MONTHLY'
                ? 'মাসিক'
                : sub.cycle === 'YEARLY'
                ? 'বাৎসরিক'
                : `প্রতি ${sub.customDays ?? 30} দিন পরপর`;

            const isHistoryOpen = expandedHistoryId === sub.id;

            return (
              <div
                key={sub.id}
                className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-5 sm:p-6 shadow-xs"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1 min-w-0">
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {sub.nameBn}
                    </h3>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span>চক্র: {cycleLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>খাত: {sub.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        পরবর্তী তারিখ:{' '}
                        <strong className="text-slate-800 dark:text-slate-200">
                          {formatDateBnEn(sub.nextDueDate, useBengaliDigits)}
                        </strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      {isLockedForThisMonth ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> এই মাসে পরিশোধিত (মাধ্যম: {paidAccountName})
                        </span>
                      ) : isOverdue ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-red-600 dark:text-red-400">
                          <AlertCircle className="w-3.5 h-3.5" /> মেয়াদোত্তীর্ণ
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-semibold text-amber-700 dark:text-amber-400">
                          <CalendarClock className="w-3.5 h-3.5" /> পরিশোধ বাকি
                        </span>
                      )}
                    </div>

                    {sub.notes && (
                      <p className="text-xs text-slate-500 pt-0.5">
                        বিবরণ: {sub.notes}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-4 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100 dark:border-slate-800 shrink-0">
                    <div className="sm:text-right">
                      <p className="text-xs text-slate-500">নির্ধারিত বিল:</p>
                      <p className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                        {formatBDT(sub.amountPaisa, { useBengaliDigits })}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {isLockedForThisMonth ? (
                        <button
                          type="button"
                          disabled
                          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5 cursor-not-allowed whitespace-nowrap shrink-0"
                          title="পরবর্তী মাস ছাড়া আবার পরিশোধ করা যাবেনা"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>এই মাসে পরিশোধিত ({paidAccountName})</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onRequestPaySubscription(sub)}
                          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>পরিশোধ করুন</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          setExpandedHistoryId(isHistoryOpen ? null : sub.id)
                        }
                        className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>ইতিহাস ({sub.paymentHistory.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => openEditSubModal(sub)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="সম্পাদনা"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteSubscription(sub)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {isHistoryOpen && (
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <h4 className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
                      পূর্বে পরিশোধিত বিলের তালিকা
                    </h4>
                    {sub.paymentHistory.length === 0 ? (
                      <p className="text-xs text-slate-500 py-2">
                        এখনো কোনো বিল পরিশোধ রেকর্ড নেই।
                      </p>
                    ) : (
                      <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
                        {sub.paymentHistory.map((p) => {
                          const mediumName = getAccountName(
                            p.accountId ?? sub.defaultAccountId
                          );
                          return (
                            <div
                              key={p.id}
                              className="py-2.5 flex items-center justify-between text-xs"
                            >
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="font-semibold text-slate-800 dark:text-slate-200">
                                  {p.note || 'বিল পরিশোধিত'}
                                </span>
                                <span aria-hidden="true" className="text-slate-400">
                                  ·
                                </span>
                                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                                  মাধ্যম: {mediumName}
                                </span>
                                <span aria-hidden="true" className="text-slate-400">
                                  ·
                                </span>
                                <span className="text-slate-500">
                                  তারিখ: {formatDateBnEn(p.paidDate, useBengaliDigits)}
                                </span>
                              </div>
                              <span className="font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                                {formatBDT(p.amountPaisa, { useBengaliDigits })}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Subscription Modal */}
      {showSubModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                {editingSub ? 'বিল সম্পাদনা করুন' : 'নতুন নিয়মিত বিল যোগ করুন'}
              </h2>
              <button
                type="button"
                onClick={() => setShowSubModal(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSubSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  বিলের নাম *
                </label>
                <input
                  type="text"
                  value={nameBn}
                  onChange={(e) => setNameBn(e.target.value)}
                  placeholder="যেমন: দোকান ভাড়া, ইন্টারনেট বিল..."
                  required
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    বিলের পরিমাণ (৳) *
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={amountInput}
                    onChange={(e) => setAmountInput(e.target.value)}
                    placeholder="১২০০"
                    required
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono tabular-nums text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    বিলিং চক্র *
                  </label>
                  <select
                    value={cycle}
                    onChange={(e) => setCycle(e.target.value as BillingCycle)}
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  >
                    <option value="MONTHLY">মাসিক</option>
                    <option value="YEARLY">বাৎসরিক</option>
                    <option value="CUSTOM_DAYS">নির্দিষ্ট দিন পরপর</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    পরবর্তী তারিখ *
                  </label>
                  <input
                    type="date"
                    value={nextDueDate}
                    onChange={(e) => setNextDueDate(e.target.value)}
                    required
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {cycle === 'CUSTOM_DAYS' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    কত দিন পরপর বিল আসবে? *
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={customDaysInput}
                    onChange={(e) => setCustomDaysInput(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    খাত
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    কোন হিসাব থেকে কাটা হবে
                  </label>
                  <select
                    value={defaultAccountId}
                    onChange={(e) => setDefaultAccountId(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.nameBn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  বিবরণ
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="মিটার নম্বর বা অতিরিক্ত তথ্য..."
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowSubModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
