import { Flame, Layers3, Sparkles } from "lucide-react";
import type { World } from "@/game/data";
import { getSkin } from "@/game/data";
import { cn } from "@/utils/cn";

function sectors(accent: string, accent2: string, dark: string, shift: number) {
  const angles = [34, 60, 30, 48, 26, 70, 42, 50];
  const colors = [accent, dark, accent2, accent, dark, accent, accent2, accent];
  let cursor = shift;
  const stops: string[] = [];
  angles.forEach((angle, i) => {
    const next = cursor + angle;
    stops.push(`${colors[i]} ${cursor}deg ${next}deg`);
    cursor = next;
  });
  stops.push(`${colors[0]} ${cursor}deg 360deg`);
  return `conic-gradient(from 0deg, ${stops.join(", ")})`;
}

export default function TowerPreview({
  world,
  level,
  skinId,
  className,
  compact = false,
}: {
  world: World;
  level: number;
  skinId: string;
  className?: string;
  compact?: boolean;
}) {
  const skin = getSkin(skinId);
  const layers = compact ? 6 : 9;
  const width = compact ? 210 : 292;

  return (
    <div className={cn("relative mx-auto aspect-[5/6] w-full max-w-[440px]", className)}>
      {/* atmosphere */}
      <div
        className="anim-glow absolute left-1/2 top-[38%] h-[72%] w-[96%] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[64px]"
        style={{ background: `radial-gradient(circle, ${world.glow}66, transparent 62%)` }}
      />
      <div className="absolute left-1/2 top-6 h-44 w-44 -translate-x-1/2 rounded-full border border-white/8" />
      <div
        className="anim-spin-slow absolute left-1/2 top-8 h-60 w-60 -translate-x-1/2 rounded-full border border-dashed border-white/12"
        style={{ borderColor: `${world.accent2}30` }}
      />
      <div className="absolute inset-x-8 bottom-10 h-24 rounded-[50%] bg-black/50 blur-2xl" />

      {/* tower */}
      <div className="absolute inset-x-0 bottom-[14%] top-[8%]">
        <div className="relative mx-auto h-full w-full">
          {Array.from({ length: layers }).map((_, index) => {
            const depth = layers - 1 - index;
            const w = width - depth * 7;
            const h = w * 0.31;
            const accent = index % 3 === 1 ? world.accent2 : world.accent;
            return (
              <div
                key={index}
                className="absolute left-1/2"
                style={{
                  width: w,
                  height: h,
                  bottom: `${6 + index * (compact ? 26 : 30)}px`,
                  transform: "translateX(-50%)",
                  zIndex: 30 - index,
                }}
              >
                <div
                  className="absolute inset-0 rounded-[50%]"
                  style={{
                    background: sectors(
                      accent,
                      world.accent2,
                      world.solid,
                      (index * 31 + level * 7) % 360,
                    ),
                    boxShadow: `0 ${Math.max(7, h * 0.14)}px 0 ${world.bg[0]}, 0 ${Math.max(9, h * 0.18)}px 22px rgba(0,0,0,.55), inset 0 1px 1px rgba(255,255,255,.28)`,
                    border: `1px solid ${accent}66`,
                    opacity: 1 - depth * 0.035,
                  }}
                >
                  <div
                    className="absolute inset-[18%] rounded-[50%] border border-white/12"
                    style={{ background: "radial-gradient(circle at 34% 22%, rgba(255,255,255,.18), transparent 62%)" }}
                  />
                </div>
                {/* front edge light */}
                <div
                  className="absolute inset-x-[16%] bottom-[7%] h-[2px] rounded-full opacity-60 blur-[1px]"
                  style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)` }}
                />
              </div>
            );
          })}

          {/* ball */}
          <div
            className="absolute left-1/2 z-40"
            style={{ bottom: `${12 + (layers - 1) * (compact ? 26 : 30) + width * 0.09}px` }}
          >
            <div className="relative -translate-x-1/2">
              <div
                className="anim-float relative rounded-full"
                style={{
                  width: compact ? 38 : 52,
                  height: compact ? 38 : 52,
                  background: `radial-gradient(circle at 32% 26%, ${skin.inner} 0%, ${skin.core} 38%, ${skin.outer} 100%)`,
                  boxShadow: `inset -5px -7px 14px rgba(0,0,0,.38), inset 4px 5px 12px rgba(255,255,255,.5), 0 12px 32px -4px ${skin.glow}dd, 0 0 46px -4px ${skin.glow}aa`,
                }}
              >
                <span className="absolute left-[22%] top-[15%] h-[22%] w-[30%] rounded-full bg-white/80 blur-[1.5px]" />
                <span className="absolute bottom-[18%] left-[18%] h-[10%] w-[18%] rounded-full bg-white/25 blur-[2px]" />
                <span
                  className="absolute -inset-2 -z-10 rounded-full opacity-60 blur-md"
                  style={{ background: skin.glow }}
                />
              </div>
              <span
                className="anim-glow absolute left-1/2 top-[20%] -z-10 h-10 w-10 -translate-x-1/2 rounded-full blur-xl"
                style={{ background: skin.glow }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* floating UI chips */}
      <div className="anim-float-slow absolute left-0 top-[13%] z-50 hidden sm:block">
        <div className="glass flex items-center gap-2 rounded-xl px-3 py-2 shadow-xl">
          <span
            className="flex h-7 w-7 items-center justify-center rounded-lg text-white"
            style={{ background: `linear-gradient(135deg, ${world.accent}, ${world.accent2})` }}
          >
            <Layers3 size={14} />
          </span>
          <div className="leading-none">
            <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/40">Depth</div>
            <div className="mt-1 font-display text-[12px] font-bold text-white">
              {84 + (level % 13)}%
            </div>
          </div>
        </div>
      </div>

      <div className="anim-float absolute right-0 top-[26%] z-50 hidden sm:block" style={{ animationDelay: "1.2s" }}>
        <div className="glass flex items-center gap-2 rounded-xl px-3 py-2 shadow-xl">
          <Flame size={16} className="text-orange-300" />
          <div className="leading-none">
            <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/40">Combo</div>
            <div className="mt-1 font-display text-[12px] font-bold text-orange-200">
              ×{7 + (level % 12)}
            </div>
          </div>
        </div>
      </div>

      <div
        className="anim-float-slow absolute bottom-[2%] left-1/2 z-50 w-[88%] -translate-x-1/2"
        style={{ animationDelay: "0.6s" }}
      >
        <div className="glass-strong flex items-center justify-between gap-3 rounded-2xl px-3.5 py-2.5 shadow-[0_20px_50px_-20px_rgba(0,0,0,.9)]">
          <div className="flex min-w-0 items-center gap-2.5">
            <span
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-white/15"
              style={{ background: `linear-gradient(135deg, ${world.accent}44, ${world.accent2}22)` }}
            >
              <Sparkles size={14} style={{ color: world.accent2 }} />
            </span>
            <div className="min-w-0 leading-tight">
              <div className="truncate text-[8px] font-bold uppercase tracking-[0.18em] text-white/40">
                World {String(world.id).padStart(2, "0")}
              </div>
              <div className="truncate font-display text-[12px] font-bold text-white">{world.name}</div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <span className="rounded-md bg-white/8 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-white/55">
              Level {level}
            </span>
            <span
              className="rounded-md px-2 py-1 text-[9px] font-extrabold uppercase tracking-wider text-black"
              style={{ background: world.accent2 }}
            >
              Live
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
