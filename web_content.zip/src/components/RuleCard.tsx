import React, { useState } from 'react';
import { GrammarRule } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useUserData } from '../context/UserDataContext';
import {
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  Clock,
  Circle,
  FileEdit,
  Lightbulb,
  Check,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface RuleCardProps {
  rule: GrammarRule;
}

export const RuleCard: React.FC<RuleCardProps> = ({ rule }) => {
  const { language, showAllLanguages, getText, isRtl } = useLanguage();
  const {
    isBookmarked,
    toggleBookmark,
    notes,
    saveNote,
    progressMap,
    updateProgress
  } = useUserData();

  const [expanded, setExpanded] = useState<boolean>(true);
  const [noteOpen, setNoteOpen] = useState<boolean>(false);
  const [noteText, setNoteText] = useState<string>(notes[rule.id]?.noteText || '');
  const [noteSavedFeedback, setNoteSavedFeedback] = useState<boolean>(false);

  const bookmarked = isBookmarked(rule.id);
  const currentProgress = progressMap[rule.id]?.status || 'not_started';

  const handleSaveNote = async () => {
    await saveNote(rule.id, rule.category, noteText);
    setNoteSavedFeedback(true);
    setTimeout(() => setNoteSavedFeedback(false), 2000);
  };

  const getStatusBadge = () => {
    switch (currentProgress) {
      case 'mastered':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            {language === 'pashto' ? 'زده شو' : language === 'urdu' ? 'یاد ہو گیا' : 'Mastered'}
          </span>
        );
      case 'studying':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            {language === 'pashto' ? 'تر لوست لاندې' : language === 'urdu' ? 'زیرِ مطالعہ' : 'Studying'}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-stone-100 text-stone-600 border border-stone-200">
            <Circle className="w-3.5 h-3.5 text-stone-400" />
            {language === 'pashto' ? 'پیل شوی نه دی' : language === 'urdu' ? 'شروع نہیں ہوا' : 'Not Started'}
          </span>
        );
    }
  };

  return (
    <article className="bg-white rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-md transition-shadow overflow-hidden mb-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-stone-900 via-emerald-950 to-stone-900 text-white p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex-1 min-w-[240px]">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2 py-0.5 rounded-md text-[11px] font-bold tracking-wider uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {rule.category === 'sarf' ? 'علم الصرف' : 'علم النحو'}
              </span>
              {getStatusBadge()}
            </div>

            {/* Vocalized Arabic Title */}
            <h3 className="font-arabic text-2xl sm:text-3xl font-bold text-amber-200 leading-snug tracking-wide mb-1">
              {rule.arabicTitle}
            </h3>

            {/* Localized Main Title */}
            <h4 className="text-base sm:text-lg font-semibold text-stone-200">
              {getText(rule.title)}
            </h4>
          </div>

          {/* Action Tools: Bookmark, Note, Expand */}
          <div className="flex items-center gap-2">
            {/* Bookmark button */}
            <button
              onClick={() => toggleBookmark(rule.id, rule.category, getText(rule.title))}
              title={bookmarked ? 'Remove Bookmark' : 'Add to Bookmarks'}
              className={`p-2 rounded-xl transition-all ${
                bookmarked
                  ? 'bg-amber-500 text-stone-950 shadow-sm'
                  : 'bg-stone-800 text-stone-300 hover:text-white hover:bg-stone-700'
              }`}
            >
              {bookmarked ? <BookmarkCheck className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
            </button>

            {/* Personal Note button */}
            <button
              onClick={() => setNoteOpen(!noteOpen)}
              title="Add personal study note"
              className={`p-2 rounded-xl transition-all ${
                notes[rule.id]?.noteText
                  ? 'bg-emerald-600 text-white'
                  : 'bg-stone-800 text-stone-300 hover:text-white hover:bg-stone-700'
              }`}
            >
              <FileEdit className="w-5 h-5" />
            </button>

            {/* Expand / Collapse */}
            <button
              onClick={() => setExpanded(!expanded)}
              className="p-2 rounded-xl bg-stone-800 text-stone-300 hover:text-white hover:bg-stone-700 transition-colors"
            >
              {expanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Status Selector Bar */}
        <div className="mt-4 pt-3 border-t border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-stone-400">
              {language === 'pashto' ? 'د مطالعې حالت:' : language === 'urdu' ? 'مطالعہ کی حالت:' : 'Learning Status:'}
            </span>
            <div className="flex items-center bg-stone-800 rounded-lg p-0.5 border border-stone-700">
              <button
                onClick={() => updateProgress(rule.id, 'not_started')}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  currentProgress === 'not_started' ? 'bg-stone-700 text-white' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                {language === 'pashto' ? 'نه دی شروع' : language === 'urdu' ? 'غیر شروع' : 'New'}
              </button>
              <button
                onClick={() => updateProgress(rule.id, 'studying')}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  currentProgress === 'studying' ? 'bg-amber-600 text-white font-semibold' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                {language === 'pashto' ? 'لوستل کېږي' : language === 'urdu' ? 'جاری' : 'Studying'}
              </button>
              <button
                onClick={() => updateProgress(rule.id, 'mastered')}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  currentProgress === 'mastered' ? 'bg-emerald-600 text-white font-semibold' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                {language === 'pashto' ? 'زده شو ✓' : language === 'urdu' ? 'مکمل ✓' : 'Mastered ✓'}
              </button>
            </div>
          </div>

          {/* Tags */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {rule.tags.map((tag) => (
              <span key={tag} className="px-2 py-0.5 rounded bg-stone-800 text-stone-300 text-[11px]">
                #{tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Expanded Content Body */}
      {expanded && (
        <div className="p-6 space-y-6">
          {/* Summary / Core Explanation */}
          <div className="bg-amber-50/60 border-l-4 rtl:border-l-0 rtl:border-r-4 border-amber-500 p-4 rounded-r-xl rtl:rounded-r-none rtl:rounded-l-xl">
            <h5 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-1">
              {language === 'pashto' ? 'خلاصه او موخه' : language === 'urdu' ? 'خلاصہ و حاصل کلام' : 'Overview & Summary'}
            </h5>
            <p className="text-stone-800 font-medium leading-relaxed">
              {getText(rule.summary)}
            </p>
          </div>

          {/* Definition Section */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-emerald-900 flex items-center gap-2 border-b border-emerald-100 pb-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
              <span>
                {language === 'pashto'
                  ? 'بشپړ تعریف او اصطلاحي بیان'
                  : language === 'urdu'
                  ? 'مکمل تعریف اور اصطلاحی وضاحت'
                  : 'Formal Definition & Linguistic Conception'}
              </span>
            </h4>

            {showAllLanguages ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                {/* Pashto Column */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-right dir-rtl">
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-800 mb-1.5">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-100">پښتو</span>
                  </div>
                  <p className="font-pashto text-sm leading-relaxed">{rule.definition.pashto}</p>
                </div>

                {/* Urdu Column */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-right dir-rtl">
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-800 mb-1.5">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-100">اردو</span>
                  </div>
                  <p className="font-urdu text-sm leading-relaxed">{rule.definition.urdu}</p>
                </div>

                {/* English Column */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-left dir-ltr">
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-800 mb-1.5">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-100">English</span>
                  </div>
                  <p className="text-sm leading-relaxed font-sans">{rule.definition.english}</p>
                </div>
              </div>
            ) : (
              <p className="text-stone-700 leading-relaxed text-sm sm:text-base bg-stone-50/70 p-4 rounded-xl border border-stone-100">
                {getText(rule.definition)}
              </p>
            )}
          </div>

          {/* Detailed Rules / Bullet Points */}
          {rule.detailedRules.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-900 flex items-center gap-2 border-b border-emerald-100 pb-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
                <span>
                  {language === 'pashto'
                    ? 'تفصیلي قواعد او فرعي احکام'
                    : language === 'urdu'
                    ? 'تفصیلی قواعد اور جزئیات'
                    : 'Detailed Sub-Rules & Guidelines'}
                </span>
              </h4>

              <div className="space-y-2.5">
                {rule.detailedRules.map((detail, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3 p-3 bg-white rounded-xl border border-stone-200/80 shadow-xs hover:border-emerald-200 transition-colors"
                  >
                    <span className="flex-shrink-0 w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center justify-center mt-0.5">
                      {idx + 1}
                    </span>
                    <div className="flex-1">
                      {showAllLanguages ? (
                        <div className="space-y-2 text-xs sm:text-sm">
                          <p className="font-pashto text-stone-800 dir-rtl"><strong className="text-emerald-800">پښتو:</strong> {detail.pashto}</p>
                          <p className="font-urdu text-stone-800 dir-rtl"><strong className="text-emerald-800">اردو:</strong> {detail.urdu}</p>
                          <p className="font-sans text-stone-700 dir-ltr"><strong className="text-emerald-800">English:</strong> {detail.english}</p>
                        </div>
                      ) : (
                        <p className="text-stone-800 text-sm sm:text-base leading-relaxed">
                          {getText(detail)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Examples Section */}
          {rule.examples.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-900 flex items-center gap-2 border-b border-emerald-100 pb-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-600" />
                <span>
                  {language === 'pashto'
                    ? 'مثالونه او عملي تطبیق'
                    : language === 'urdu'
                    ? 'امثلہ اور عملی تطبیق'
                    : 'Practical Examples & Demonstration'}
                </span>
              </h4>

              <div className="space-y-3">
                {rule.examples.map((eg, idx) => (
                  <div
                    key={idx}
                    className="bg-stone-50 rounded-xl p-4 border border-stone-200/90 relative overflow-hidden"
                  >
                    {/* Arabic Text Display */}
                    <div className="bg-white p-3.5 rounded-lg border border-stone-200 shadow-xs mb-3 text-center">
                      <p className="font-arabic text-xl sm:text-2xl text-stone-900 font-bold tracking-wide">
                        {eg.arabic}
                      </p>
                    </div>

                    {/* Translations */}
                    {showAllLanguages ? (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs sm:text-sm pt-1">
                        <div className="p-2.5 bg-white rounded-lg border border-stone-200 text-stone-800 dir-rtl">
                          <span className="text-[10px] font-bold text-amber-700 uppercase block mb-1">پښتو ژباړه</span>
                          <p className="font-pashto">{eg.pashtoTranslation}</p>
                        </div>
                        <div className="p-2.5 bg-white rounded-lg border border-stone-200 text-stone-800 dir-rtl">
                          <span className="text-[10px] font-bold text-amber-700 uppercase block mb-1">اردو ترجمہ</span>
                          <p className="font-urdu">{eg.urduTranslation}</p>
                        </div>
                        <div className="p-2.5 bg-white rounded-lg border border-stone-200 text-stone-800 dir-ltr">
                          <span className="text-[10px] font-bold text-amber-700 uppercase block mb-1">English Translation</span>
                          <p className="font-sans">{eg.englishTranslation}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="p-2.5 bg-white rounded-lg border border-stone-200 text-stone-800">
                        <span className="text-[10px] font-bold text-amber-700 uppercase block mb-1">
                          {language === 'pashto' ? 'ژباړه' : language === 'urdu' ? 'ترجمہ' : 'Translation'}
                        </span>
                        <p className="text-sm font-medium">
                          {language === 'pashto'
                            ? eg.pashtoTranslation
                            : language === 'urdu'
                            ? eg.urduTranslation
                            : eg.englishTranslation}
                        </p>
                      </div>
                    )}

                    {/* Analysis Breakdown */}
                    {eg.analysis && (
                      <div className="mt-2.5 text-xs text-stone-600 bg-amber-50/50 p-2.5 rounded-lg border border-amber-200/50">
                        <strong className="text-amber-900">
                          {language === 'pashto' ? 'اعرابي / صرفي تحلیل: ' : language === 'urdu' ? 'اعرابی و صرفی تجزیہ: ' : 'Grammatical Analysis: '}
                        </strong>
                        <span>{getText(eg.analysis)}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Classical Mnemonic Banner */}
          {rule.mnemonicOrNote && (
            <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-amber-50 border border-emerald-200 p-4 rounded-xl flex items-start gap-3">
              <Lightbulb className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-emerald-900 uppercase block mb-0.5">
                  {language === 'pashto' ? 'علمي نکته او منظوم یادښت' : language === 'urdu' ? 'علمی نکتہ اور منظوم قاعدہ' : 'Scholarly Mnemonic & Note'}
                </span>
                <p className="text-xs sm:text-sm text-stone-800 leading-relaxed font-medium">
                  {getText(rule.mnemonicOrNote)}
                </p>
              </div>
            </div>
          )}

          {/* Personal Study Note Box (Open / Closed) */}
          {noteOpen && (
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-300 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                  <FileEdit className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    {language === 'pashto'
                      ? 'د دې قاعدې په اړه ستاسو ځانګړی یادښت (په کلاوډ کې خوندي کېږي)'
                      : language === 'urdu'
                      ? 'اس قاعدے پر آپ کا ذاتی نوٹ (کلاؤڈ میں محفوظ ہوگا)'
                      : 'Your Personal Study Notes (Synced to Cloud)'}
                  </span>
                </span>
                {noteSavedFeedback && (
                  <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    {language === 'pashto' ? 'خوندي شو!' : language === 'urdu' ? 'محفوظ ہو گیا!' : 'Saved!'}
                  </span>
                )}
              </div>

              <textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder={
                  language === 'pashto'
                    ? 'دلته خپل یادښت، پوښتنې یا اضافي مثالونه ولیکئ...'
                    : language === 'urdu'
                    ? 'یہاں اپنے نوٹس، سوالات یا اضافی مثالیں لکھیں...'
                    : 'Write your insights, questions, or additional examples here...'
                }
                rows={3}
                className="w-full text-xs sm:text-sm p-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              />

              <div className="flex justify-end gap-2">
                <button
                  onClick={handleSaveNote}
                  className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors"
                >
                  {language === 'pashto' ? 'یادښت خوندي کړئ' : language === 'urdu' ? 'نوٹ محفوظ کریں' : 'Save Note'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </article>
  );
};
