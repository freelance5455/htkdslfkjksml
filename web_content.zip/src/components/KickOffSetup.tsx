import React, { useState } from 'react';
import { Play, ArrowLeftRight } from 'lucide-react';
import { STADIUMS } from '../data/clubs';
import { TRANSLATIONS } from '../i18n/translations';
import {
  Club,
  Difficulty,
  Formation,
  Language,
  MatchConfig,
  WeatherType,
} from '../types/game';
import { ClubCrest } from './ClubCrest';

interface KickOffSetupProps {
  clubs: Club[];
  initialConfig: MatchConfig;
  language: Language;
  onStartMatch: (config: MatchConfig) => void;
}

export const KickOffSetup: React.FC<KickOffSetupProps> = ({
  clubs,
  initialConfig,
  language,
  onStartMatch,
}) => {
  const t = TRANSLATIONS[language];
  const [config, setConfig] = useState<MatchConfig>(initialConfig);
  const [leagueFilter, setLeagueFilter] = useState<'all' | 'brasileirao' | 'europe' | 'custom'>('all');
  const [pickingSide, setPickingSide] = useState<'home' | 'away'>('home');

  const homeClub = clubs.find((c) => c.id === config.homeClubId) || clubs[0];
  const awayClub = clubs.find((c) => c.id === config.awayClubId) || clubs[1];

  const filteredClubs = clubs.filter((c) => leagueFilter === 'all' || c.league === leagueFilter);

  const swapTeams = () => {
    setConfig((prev) => ({
      ...prev,
      homeClubId: prev.awayClubId,
      awayClubId: prev.homeClubId,
    }));
  };

  const homeKitVariant = config.homeKitVariant ?? 'home';
  const awayKitVariant = config.awayKitVariant ?? 'away';

  return (
    <div className="relative z-10 h-full overflow-y-auto px-4 sm:px-8 py-5 max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Matchup Cards + Club Picker */}
        <div className="lg:col-span-7 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl">
          {/* Selected Matchup */}
          <div className="grid grid-cols-11 items-center gap-2 bg-slate-100 dark:bg-[#111A2E] border border-slate-200 dark:border-slate-700/70 rounded-xl p-4">
            <button
              onClick={() => setPickingSide('home')}
              className={`col-span-5 flex items-center gap-3 p-2.5 rounded-lg border text-left transition-colors ${
                pickingSide === 'home'
                  ? 'border-amber-400 bg-amber-400/10'
                  : 'border-transparent hover:bg-white/60 dark:hover:bg-slate-800/70'
              }`}
            >
              <ClubCrest club={homeClub} size={46} />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase text-amber-600 dark:text-amber-400">
                  {t.selectHome}
                </div>
                <div className="font-display font-bold text-xl text-slate-900 dark:text-white truncate">
                  {homeClub.name}
                </div>
                <div className="font-mono-num text-xs text-slate-600 dark:text-slate-300">
                  OVR {homeClub.ovr}
                </div>
              </div>
            </button>

            <div className="col-span-1 flex flex-col items-center justify-center">
              <button
                onClick={swapTeams}
                title="Swap"
                className="p-2 rounded-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:border-amber-400 transition-colors"
              >
                <ArrowLeftRight className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => setPickingSide('away')}
              className={`col-span-5 flex items-center justify-end gap-3 p-2.5 rounded-lg border text-right transition-colors ${
                pickingSide === 'away'
                  ? 'border-amber-400 bg-amber-400/10'
                  : 'border-transparent hover:bg-white/60 dark:hover:bg-slate-800/70'
              }`}
            >
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase text-sky-600 dark:text-sky-400">
                  {t.selectAway}
                </div>
                <div className="font-display font-bold text-xl text-slate-900 dark:text-white truncate">
                  {awayClub.name}
                </div>
                <div className="font-mono-num text-xs text-slate-600 dark:text-slate-300">
                  OVR {awayClub.ovr}
                </div>
              </div>
              <ClubCrest club={awayClub} size={46} />
            </button>
          </div>

          {/* Kit Variant Selection */}
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                {homeClub.abbr} {t.kitSelection}
              </span>
              <div className="flex gap-1">
                {(['home', 'away'] as const).map((kv) => (
                  <button
                    key={kv}
                    onClick={() => setConfig((prev) => ({ ...prev, homeKitVariant: kv }))}
                    className={`px-2 py-1 rounded text-[11px] font-bold uppercase ${
                      homeKitVariant === kv
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {kv === 'home' ? '1' : '2'}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                {awayClub.abbr} {t.kitSelection}
              </span>
              <div className="flex gap-1">
                {(['home', 'away'] as const).map((kv) => (
                  <button
                    key={kv}
                    onClick={() => setConfig((prev) => ({ ...prev, awayKitVariant: kv }))}
                    className={`px-2 py-1 rounded text-[11px] font-bold uppercase ${
                      awayKitVariant === kv
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {kv === 'home' ? '1' : '2'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* League Filter Tabs */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
              {(
                [
                  ['all', t.allLeagues],
                  ['brasileirao', t.brasileirao],
                  ['europe', t.europe],
                  ['custom', t.custom],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setLeagueFilter(key)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    leagueFilter === key
                      ? 'bg-amber-400 text-slate-950'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {pickingSide === 'home' ? t.selectHome : t.selectAway}
            </span>
          </div>

          {/* Clubs Grid */}
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[340px] overflow-y-auto pr-1">
            {filteredClubs.map((club) => {
              const isHome = club.id === config.homeClubId;
              const isAway = club.id === config.awayClubId;
              return (
                <button
                  key={club.id}
                  onClick={() =>
                    setConfig((prev) => ({
                      ...prev,
                      [pickingSide === 'home' ? 'homeClubId' : 'awayClubId']: club.id,
                    }))
                  }
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-colors ${
                    isHome || isAway
                      ? 'border-amber-400 bg-amber-400/10'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70 hover:border-slate-400 dark:hover:border-slate-600'
                  }`}
                >
                  <ClubCrest club={club} size={34} />
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                      {club.name}
                    </div>
                    <div className="font-mono-num text-[11px] text-slate-500 dark:text-slate-400">
                      {club.abbr} · {club.ovr}
                      {isHome ? ' · H' : isAway ? ' · A' : ''}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Stadium, Weather, Tactics, Duration & Kick-Off */}
        <div className="lg:col-span-5 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
          <div className="space-y-4">
            {/* Stadium */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                {t.stadium}
              </label>
              <select
                value={config.stadiumId}
                onChange={(e) => setConfig((prev) => ({ ...prev, stadiumId: e.target.value }))}
                className="w-full px-3 py-2.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white"
              >
                {STADIUMS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.city} · {s.capacity})
                  </option>
                ))}
              </select>
            </div>

            {/* Weather */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                {t.weather}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    ['day', t.weatherDay],
                    ['night', t.weatherNight],
                    ['rain', t.weatherRain],
                  ] as Array<[WeatherType, string]>
                ).map(([w, label]) => (
                  <button
                    key={w}
                    onClick={() => setConfig((prev) => ({ ...prev, weather: w }))}
                    className={`py-2 rounded-lg text-xs font-semibold border transition-colors ${
                      config.weather === w
                        ? 'bg-amber-400 border-amber-400 text-slate-950'
                        : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration & Formation */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                  {t.duration}
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[2, 3, 5].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setConfig((prev) => ({ ...prev, durationMinutes: mins }))}
                      className={`py-2 rounded-lg font-mono-num text-xs font-bold border ${
                        config.durationMinutes === mins
                          ? 'bg-amber-400 border-amber-400 text-slate-950'
                          : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {mins}m
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                  {t.formation}
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['4-3-3', '4-4-2', '3-5-2'] as Formation[]).map((form) => (
                    <button
                      key={form}
                      onClick={() => setConfig((prev) => ({ ...prev, formation: form }))}
                      className={`py-2 rounded-lg font-mono-num text-xs font-bold border ${
                        config.formation === form
                          ? 'bg-amber-400 border-amber-400 text-slate-950'
                          : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {form}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Difficulty */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                {t.difficulty}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    ['amateur', t.diffAmateur],
                    ['professional', t.diffPro],
                    ['legendary', t.diffLegend],
                  ] as Array<[Difficulty, string]>
                ).map(([d, label]) => (
                  <button
                    key={d}
                    onClick={() => setConfig((prev) => ({ ...prev, difficulty: d }))}
                    className={`py-2 rounded-lg text-xs font-semibold border ${
                      config.difficulty === d
                        ? 'bg-amber-400 border-amber-400 text-slate-950'
                        : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => onStartMatch({ ...config, careerMatchId: undefined })}
            className="w-full py-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-2xl tracking-wide uppercase flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.98]"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>{t.startMatch}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
