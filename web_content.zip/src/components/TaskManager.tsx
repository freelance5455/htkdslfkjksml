import React, { useState, useEffect } from 'react';
import { TaskItem } from '../types';
import { Plus, Check, Trash2, Sparkles, Clock, AlertCircle, ChevronDown, ChevronUp, CheckCircle2, ShieldAlert, Timer, Bell, BellRing, Play } from 'lucide-react';
import { triggerConfetti } from '../utils/confetti';
import { playTaskCompleteSound, playCoinSound, playErrorSound } from '../utils/soundEffects';

interface TaskManagerProps {
  tasks: TaskItem[];
  onAddTask: (task: Omit<TaskItem, 'id' | 'createdAt' | 'completedPomodoros' | 'isCompleted'>) => void;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onAIAnalyzeTask: (taskTitle: string) => void;
  onAddSubtask: (taskId: string, subtaskTitle: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onStartPomodoroForTask: (taskId: string) => void;
  soundEnabled: boolean;
}

export const TaskManager: React.FC<TaskManagerProps> = ({
  tasks,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onAIAnalyzeTask,
  onAddSubtask,
  onToggleSubtask,
  onStartPomodoroForTask,
  soundEnabled,
}) => {
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('active');
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('عمل');
  const [newPriority, setNewPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [newPomodoros, setNewPomodoros] = useState(2);
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [subtaskInput, setSubtaskInput] = useState('');

  // Strict Rule Modal State
  const [strictModalTask, setStrictModalTask] = useState<TaskItem | null>(null);

  // Notification State
  const [notificationPermission, setNotificationPermission] = useState<string>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const requestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      if (permission === 'granted') {
        new Notification('🔔 وقتي - رفيق الإنتاجية', {
          body: 'تم تفعيل التذكيرات بنجاح! سنذكرك دائماً بإنجاز مهامك وفتح تايمر الـ 25 دقيقة 🚀',
          icon: '/favicon.ico',
        });
      }
    }
  };

  // Periodic In-App & Browser Reminder for active tasks
  useEffect(() => {
    const uncompletedCount = tasks.filter((t) => !t.isCompleted).length;
    if (uncompletedCount === 0) return;

    const interval = setInterval(() => {
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('⏳ تذكير إنجاز المهام - وقتي', {
          body: `لديك ${uncompletedCount} مهام معلقة تنتظرك! افتح تايمر الـ 25 دقيقة وابدأ في إنجاز أول مهمة الآن 🔥`,
          icon: '/favicon.ico',
        });
      }
    }, 180000); // Remind every 3 minutes if active

    return () => clearInterval(interval);
  }, [tasks]);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddTask({
      title: newTitle.trim(),
      category: newCategory,
      priority: newPriority,
      estimatedPomodoros: Math.max(1, newPomodoros),
    });

    setNewTitle('');
    setIsAdding(false);
  };

  // STRICT RULE CHECK: Must complete at least one 25-min Pomodoro session to mark task as done!
  const handleTaskCheck = (task: TaskItem) => {
    if (task.isCompleted) {
      // Unchecking is allowed
      onToggleTask(task.id);
      return;
    }

    if (task.completedPomodoros < 1) {
      // BLOCK PREMATURE COMPLETION!
      if (soundEnabled) playErrorSound();
      setStrictModalTask(task);
      return;
    }

    // Task has at least 1 Pomodoro completed, allowed!
    if (soundEnabled) {
      playTaskCompleteSound();
      setTimeout(playCoinSound, 300);
    }
    triggerConfetti();
    onToggleTask(task.id);
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'active') return !t.isCompleted;
    if (filter === 'completed') return t.isCompleted;
    return true;
  });

  const priorityColors = {
    high: 'text-red-400 bg-red-950/40 border-red-500/30',
    medium: 'text-amber-400 bg-amber-950/40 border-amber-500/30',
    low: 'text-emerald-400 bg-emerald-950/40 border-emerald-500/30',
  };

  const priorityLabels = {
    high: 'عاجل ومهم 🔥',
    medium: 'متوسط الأهمية ⚡',
    low: 'عادي / مرن 🌿',
  };

  const uncompletedTasksCount = tasks.filter((t) => !t.isCompleted).length;

  return (
    <div className="py-3 px-2 max-w-xl mx-auto">
      
      {/* Task Reminder Banner */}
      {uncompletedTasksCount > 0 && (
        <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-900 border border-indigo-500/30 flex items-center justify-between gap-3 text-right shadow-lg">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-400 shrink-0">
              <BellRing className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <p className="text-xs font-black text-white">
                تذكير نشط: لديك {uncompletedTasksCount} مهام معلقة!
              </p>
              <p className="text-[11px] text-slate-300 mt-0.5">
                قانون وقتي: يجب فتح تايمر 25 دقيقة لإنجاز واحتساب أي مهمة ⏱️
              </p>
            </div>
          </div>

          {notificationPermission !== 'granted' && (
            <button
              onClick={requestNotificationPermission}
              className="py-1.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-md shrink-0 cursor-pointer transition-colors"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>تفعيل الإشعارات</span>
            </button>
          )}
        </div>
      )}

      {/* Header and Add Button */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center gap-2">
            <span>قائمة المهام اليومية</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
              {uncompletedTasksCount} متبقية
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            كل مهمة تنجزها تمنحك +20 نقطة و +35 خبرة XP
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>مهمة جديدة</span>
        </button>
      </div>

      {/* Add Task Form Drawer */}
      {isAdding && (
        <form
          onSubmit={handleCreateTask}
          className="mb-5 p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/40 shadow-xl space-y-3 animate-in fade-in slide-in-from-top-2 duration-200"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>إضافة مهمة جديدة</span>
            </h3>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="text-slate-500 hover:text-slate-300 text-xs"
            >
              إلغاء
            </button>
          </div>

          <input
            type="text"
            required
            autoFocus
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="ما الذي تريد إنجازه بتركيز؟"
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-right"
          />

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1 text-right">التصنيف:</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 text-right"
              >
                <option value="عمل">💼 عمل</option>
                <option value="دراسة">📚 دراسة</option>
                <option value="برمجة">💻 برمجة</option>
                <option value="شخصي">🌱 شخصي</option>
                <option value="صحة">🏃‍♂️ صحة</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 mb-1 text-right">الأولوية:</label>
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 text-right"
              >
                <option value="high">🔥 عاجل</option>
                <option value="medium">⚡ متوسط</option>
                <option value="low">🌿 عادي</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 mb-1 text-right">جلسات البومودورو:</label>
              <input
                type="number"
                min="1"
                max="20"
                value={newPomodoros}
                onChange={(e) => setNewPomodoros(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 text-center font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl font-bold text-xs bg-indigo-600 hover:bg-indigo-500 text-white shadow-md transition-colors cursor-pointer"
          >
            تثبيت المهمة والبدء
          </button>
        </form>
      )}

      {/* Filter Tabs */}
      <div className="flex bg-slate-900/60 p-1 rounded-xl border border-slate-800 mb-4">
        <button
          onClick={() => setFilter('active')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
            filter === 'active'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          النشطة ({uncompletedTasksCount})
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
            filter === 'completed'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          المكتملة ({tasks.filter((t) => t.isCompleted).length})
        </button>
        <button
          onClick={() => setFilter('all')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
            filter === 'all'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          الكل ({tasks.length})
        </button>
      </div>

      {/* Tasks List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-3xl bg-slate-900/30 border border-dashed border-slate-800">
            <CheckCircle2 className="w-12 h-12 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-300">
              {filter === 'completed' ? 'لم تكمل أي مهمة بعد، ابدأ الآن!' : 'رائع! لا توجد مهام معلقة في هذه القائمة'}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              أضف مهمتك الأولى وافتح تايمر الـ 25 دقيقة لإنجازها ⏱️
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isExpanded = expandedTaskId === task.id;
            const completedSubtasks = (task.subtasks || []).filter((s) => s.completed).length;
            const totalSubtasks = (task.subtasks || []).length;
            const hasCompletedPomodoro = task.completedPomodoros >= 1;

            return (
              <div
                key={task.id}
                className={`p-3.5 rounded-2xl border transition-all duration-200 ${
                  task.isCompleted
                    ? 'bg-slate-950/60 border-slate-800/60 opacity-60'
                    : 'bg-slate-900/80 hover:bg-slate-900 border-slate-800 hover:border-slate-700 shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  
                  {/* Checkbox button */}
                  <button
                    onClick={() => handleTaskCheck(task)}
                    className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 transition-all cursor-pointer ${
                      task.isCompleted
                        ? 'bg-emerald-500 border-emerald-400 text-white shadow-sm shadow-emerald-500/30'
                        : hasCompletedPomodoro
                        ? 'border-indigo-400 hover:border-emerald-400 bg-slate-950 text-transparent'
                        : 'border-slate-700 hover:border-amber-400 bg-slate-950 text-transparent'
                    }`}
                    title={
                      task.isCompleted
                        ? 'مكتملة'
                        : hasCompletedPomodoro
                        ? 'انقر لوسمها كمكتملة بعد إنجاز جلسة التركيز ✓'
                        : 'يتطلب فتح تايمر 25 دقيقة أولاً لإتمامها'
                    }
                  >
                    <Check className="w-4 h-4 stroke-[3]" />
                  </button>

                  {/* Task Content */}
                  <div className="flex-1 min-w-0 text-right">
                    <p
                      className={`text-sm font-bold leading-snug break-words ${
                        task.isCompleted
                          ? 'line-through text-slate-400'
                          : 'text-slate-100'
                      }`}
                    >
                      {task.title}
                    </p>

                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      {/* Priority */}
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${priorityColors[task.priority]}`}>
                        {priorityLabels[task.priority]}
                      </span>

                      {/* Category */}
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">
                        {task.category}
                      </span>

                      {/* Pomodoros counter */}
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full border font-mono font-bold flex items-center gap-1 ${
                          hasCompletedPomodoro
                            ? 'bg-emerald-950/50 text-emerald-300 border-emerald-800/40'
                            : 'bg-amber-950/50 text-amber-300 border-amber-800/40'
                        }`}
                      >
                        <Clock className="w-2.5 h-2.5" />
                        <span>{task.completedPomodoros}/{task.estimatedPomodoros} بومودورو</span>
                      </span>

                      {/* Subtasks Count */}
                      {totalSubtasks > 0 && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950/50 text-purple-300 border border-purple-800/40 font-mono font-bold">
                          {completedSubtasks}/{totalSubtasks} خطوة
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1">
                    
                    {/* Launch 25-min Pomodoro for this task button */}
                    {!task.isCompleted && (
                      <button
                        onClick={() => onStartPomodoroForTask(task.id)}
                        className="py-1 px-2.5 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white text-[11px] font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                        title="فتح وتشغيل تايمر 25 دقيقة لهذه المهمة"
                      >
                        <Timer className="w-3.5 h-3.5 text-amber-300" />
                        <span className="hidden sm:inline">تايمر 25د</span>
                      </button>
                    )}

                    {/* AI Breakdown button */}
                    {!task.isCompleted && (
                      <button
                        onClick={() => onAIAnalyzeTask(task.title)}
                        className="p-1.5 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 hover:text-indigo-200 border border-indigo-500/20 transition-colors cursor-pointer"
                        title="تفكيك ذكي عبر الذكاء الاصطناعي 🪄"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {/* Toggle Subtasks drawer */}
                    <button
                      onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                      className="p-1.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                      title="الخطوات الفرعية"
                    >
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => onDeleteTask(task.id)}
                      className="p-1.5 rounded-xl bg-slate-800/60 hover:bg-red-950/60 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                      title="حذف المهمة"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>

                {/* Subtasks section */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2 animate-in fade-in duration-150">
                    <div className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                      <span>الخطوات التنفيذية الذرية:</span>
                      <button
                        onClick={() => onAIAnalyzeTask(task.title)}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-bold"
                      >
                        <Sparkles className="w-3 h-3" />
                        توليد بالذكاء الاصطناعي
                      </button>
                    </div>

                    {(task.subtasks || []).map((sub) => (
                      <div
                        key={sub.id}
                        onClick={() => onToggleSubtask(task.id, sub.id)}
                        className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800/60 text-xs cursor-pointer transition-colors"
                      >
                        <div
                          className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                            sub.completed ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-slate-700 bg-slate-900'
                          }`}
                        >
                          {sub.completed && <Check className="w-3 h-3" />}
                        </div>
                        <span className={`text-right flex-1 ${sub.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                          {sub.title}
                        </span>
                      </div>
                    ))}

                    <div className="flex gap-1.5 mt-2">
                      <input
                        type="text"
                        value={subtaskInput}
                        onChange={(e) => setSubtaskInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && subtaskInput.trim()) {
                            onAddSubtask(task.id, subtaskInput.trim());
                            setSubtaskInput('');
                          }
                        }}
                        placeholder="أضف خطوة فرعية..."
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 text-right"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (subtaskInput.trim()) {
                            onAddSubtask(task.id, subtaskInput.trim());
                            setSubtaskInput('');
                          }
                        }}
                        className="px-3 py-1 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-bold cursor-pointer"
                      >
                        إضافة
                      </button>
                    </div>
                  </div>
                )}

              </div>
            );
          })
        )}
      </div>

      {/* ===================== STRICT 25-MIN POMODORO REQUIREMENT MODAL ===================== */}
      {strictModalTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 to-amber-950/40 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl text-right">
            
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 mb-3 shadow-md">
              <ShieldAlert className="w-8 h-8" />
            </div>

            <h3 className="text-lg font-black text-amber-300 text-center">
              قانون وقتي الصارم للإنتاجية ⏱️
            </h3>

            <p className="text-xs text-slate-200 mt-2 leading-relaxed text-center">
              لا يمكن وسم المهمة <strong className="text-white">«{strictModalTask.title}»</strong> كمكتملة حتى تفتح تايمر التركيز (25 دقيقة) وتكمل جلسة بومودورو واحدة على الأقل لإنجازها الحقيقي!
            </p>

            <div className="mt-5 space-y-2">
              <button
                onClick={() => {
                  const id = strictModalTask.id;
                  setStrictModalTask(null);
                  onStartPomodoroForTask(id);
                }}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/30 cursor-pointer transition-all"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>افتح تايمر الـ 25 دقيقة الآن 🚀</span>
              </button>

              <button
                onClick={() => setStrictModalTask(null)}
                className="w-full py-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
              >
                إلغاء والعودة
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
