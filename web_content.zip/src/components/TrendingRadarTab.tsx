import React, { useState, useEffect } from 'react';
import { TrendingVideo, ViralAudio, LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { Flame, Music2, Sparkles, Compass, Eye, TrendingUp, Play, Pause, Copy, Check, MessageSquareCode, ArrowUpRight, Radio, Volume2 } from 'lucide-react';

interface TrendingRadarTabProps {
  language: LanguageCode;
  onAskAboutTrend: (trendTopic: string) => void;
}

export const TrendingRadarTab: React.FC<TrendingRadarTabProps> = ({ language, onAskAboutTrend }) => {
  const [videos, setVideos] = useState<TrendingVideo[]>([]);
  const [audios, setAudios] = useState<ViralAudio[]>([]);
  const [loading, setLoading] = useState(true);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  useEffect(() => {
    fetch('/api/trends/live')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setVideos(data.videos || []);
          setAudios(data.audios || []);
        }
      })
      .catch(err => console.error('Failed to load trends:', err))
      .finally(() => setLoading(false));
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Audio synthesizer tone preview
  const toggleAudioPlay = (audio: ViralAudio) => {
    if (playingAudioId === audio.id) {
      setPlayingAudioId(null);
      return;
    }

    setPlayingAudioId(audio.id);
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const baseFreq = audio.bpm > 120 ? 440 : 220;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);
      // Rhythmic pulses mimicking bpm
      const intervalSec = 60 / audio.bpm;
      for (let i = 0; i < 8; i++) {
        osc.frequency.setValueAtTime(baseFreq * (i % 2 === 0 ? 1 : 1.25), ctx.currentTime + i * intervalSec);
      }

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 3.5);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 3.5);

      setTimeout(() => {
        setPlayingAudioId(null);
      }, 3500);
    } catch {
      setPlayingAudioId(null);
    }
  };

  const categories = ['All', 'Technology', 'Food & Travel', 'Gaming & Setup', 'Music & Audio', 'Education'];

  const filteredVideos = selectedCategory === 'All' 
    ? videos 
    : videos.filter(v => v.category.toLowerCase().includes(selectedCategory.toLowerCase()));

  return (
    <div className="space-y-6">
      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/20'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Section 1: Trending Videos Radar */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
              <Flame className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white tracking-wide">
              {t.trendingVideos}
            </h3>
          </div>
          <span className="text-[11px] font-mono text-zinc-400">
            Realtime Velocity Index
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredVideos.map(video => (
            <div
              key={video.id}
              className="smooth-card p-4 rounded-2xl bg-zinc-900/70 border border-white/10 hover:border-cyan-500/40 flex flex-col justify-between group shadow-sm relative overflow-hidden"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-[10px] font-semibold text-zinc-300">
                    {video.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-800/40">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{video.growthRate}</span>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 mb-1.5">
                  {video.title}
                </h4>

                <div className="flex items-center gap-3 text-xs text-zinc-400 mb-2">
                  <span>Channel: <strong className="text-zinc-300">{video.channel}</strong></span>
                  <span>•</span>
                  <span>Views: <strong className="text-zinc-300">{video.views}</strong></span>
                </div>

                {/* 3-Second Viral Hook Breakdown */}
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 mb-3">
                  <div className="text-[11px] font-semibold text-amber-300 flex items-center gap-1 mb-0.5">
                    <Sparkles className="w-3 h-3" />
                    <span>3-Sec Viral Hook Secret:</span>
                  </div>
                  <p className="text-xs text-zinc-300 leading-snug">
                    {video.hook}
                  </p>
                </div>

                {/* Future Prediction Wave */}
                <div className="text-[11px] text-cyan-400/90 bg-cyan-950/20 border border-cyan-800/30 rounded-lg px-2.5 py-1.5 mb-3">
                  <strong>🔮 Bhavishya Forecast:</strong> {video.futurePrediction}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {video.tags.map(tag => (
                    <span key={tag} className="text-[10px] text-zinc-400 bg-white/5 px-2 py-0.5 rounded-md">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-zinc-400 font-mono">Virality Score:</span>
                  <span className="text-xs font-black text-cyan-300 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-700/50">
                    {video.viralityScore}%
                  </span>
                </div>

                <button
                  onClick={() => onAskAboutTrend(`Analyze this viral trend and give me 3 video script hooks for my channel: "${video.title}" (Category: ${video.category})`)}
                  className="px-2.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-xs font-semibold flex items-center gap-1 border border-cyan-500/30 active:scale-95 transition-all"
                >
                  <MessageSquareCode className="w-3.5 h-3.5" />
                  <span>{t.askAgentAboutTrend}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: Viral Audio Radar */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-pink-500/20 text-pink-400">
              <Music2 className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white tracking-wide">
              {t.trendingAudios}
            </h3>
          </div>
          <span className="text-[11px] font-mono text-pink-400">
            Shorts Background Music Sync
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {audios.map(audio => (
            <div
              key={audio.id}
              className="smooth-card p-3.5 rounded-2xl bg-zinc-900/60 border border-white/10 hover:border-pink-500/40 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-pink-950/50 text-pink-300 border border-pink-700/40">
                    {audio.viralityStatus}
                  </span>
                  <span className="text-[10px] text-zinc-400 font-mono">
                    {audio.bpm} BPM
                  </span>
                </div>

                <h5 className="text-sm font-bold text-white mb-0.5 line-clamp-1">
                  {audio.name}
                </h5>
                <p className="text-xs text-zinc-400 mb-2">
                  By {audio.artist} • <span className="text-zinc-300 font-medium">{audio.usedInShorts}</span>
                </p>

                <div className="text-[11px] text-zinc-400 bg-black/40 rounded-lg p-2 mb-3">
                  <span className="text-zinc-500">Vibe:</span> <strong className="text-zinc-300">{audio.mood}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                <button
                  onClick={() => toggleAudioPlay(audio)}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                    playingAudioId === audio.id
                      ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-lg shadow-pink-600/30 font-bold'
                      : 'bg-white/5 hover:bg-white/10 text-zinc-300'
                  }`}
                >
                  {playingAudioId === audio.id ? (
                    <>
                      <Pause className="w-3.5 h-3.5 fill-white" />
                      <span>Playing</span>
                      <span className="flex items-center gap-0.5 ml-1">
                        <span className="w-1 bg-white rounded-full eq-bar-1" />
                        <span className="w-1 bg-white rounded-full eq-bar-2" />
                        <span className="w-1 bg-white rounded-full eq-bar-3" />
                      </span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Preview Tone</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => handleCopy(audio.name, audio.id)}
                  title="Copy Audio Name"
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
                >
                  {copiedId === audio.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
