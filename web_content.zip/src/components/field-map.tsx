import { useEffect, useRef, useState } from "react";
import type { LayerGroup, Map as LeafletMap, TileLayer } from "leaflet";
import { resolveStop, type Find, type Tour } from "@/lib/field";
import { PLACES, placeStopId } from "@/lib/field";

export type BasemapId = "topo" | "karte" | "satellit";

export type MapFocus = { lat: number; lng: number; zoom: number; token: number };

type Props = {
  basemap: BasemapId;
  finds: Find[];
  tours: Tour[];
  showPlaces: boolean;
  selectedKey: string | null;
  activeTourId: string | null;
  draftPin: { lat: number; lng: number } | null;
  userLoc: { lat: number; lng: number } | null;
  focus: MapFocus | null;
  placing: boolean;
  onMapClick: (lat: number, lng: number) => void;
  onSelect: (key: string) => void;
};

const TILES: Record<
  BasemapId,
  { url: string; attribution: string; maxZoom: number; subdomains?: string }
> = {
  topo: {
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attribution: "Kartendaten © OpenStreetMap, SRTM · Darstellung © OpenTopoMap (CC-BY-SA)",
    maxZoom: 17,
    subdomains: "abc",
  },
  karte: {
    url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
    attribution: "© OpenStreetMap © CARTO",
    maxZoom: 19,
    subdomains: "abcd",
  },
  satellit: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Bilder © Esri, Maxar, Earthstar Geographics",
    maxZoom: 18,
  },
};

function crystal(kind: "find" | "place" | "draft", selected: boolean, number?: number) {
  const badge = number ? `<span class="pin-n">${number}</span>` : "";
  const fill = kind === "place" ? "none" : "currentColor";
  const stroke = kind === "place" ? "currentColor" : "var(--color-primary-fg)";
  const width = kind === "place" ? "1.8" : "1.2";
  return `<div class="pin pin-${kind}${selected ? " is-on" : ""}">${badge}<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 2.2 27.2 13.2 16 30 4.8 13.2Z" fill="${fill}" stroke="${stroke}" stroke-width="${width}" stroke-linejoin="round"/></svg></div>`;
}

export function FieldMap({
  basemap,
  finds,
  tours,
  showPlaces,
  selectedKey,
  activeTourId,
  draftPin,
  userLoc,
  focus,
  placing,
  onMapClick,
  onSelect,
}: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const tileRef = useRef<TileLayer | null>(null);
  const groupRef = useRef<LayerGroup | null>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const clickRef = useRef(onMapClick);
  const selectRef = useRef(onSelect);
  const draftRef = useRef(draftPin);
  const [mapReady, setMapReady] = useState(false);
  clickRef.current = onMapClick;
  selectRef.current = onSelect;
  draftRef.current = draftPin;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let alive = true;
    let map: LeafletMap | null = null;

    void (async () => {
      const L = await import("leaflet");
      await import("leaflet/dist/leaflet.css");
      if (!alive || !hostRef.current) return;
      leafletRef.current = L;
      map = L.map(hostRef.current, {
        zoomControl: false,
        minZoom: 6,
        maxZoom: 18,
        maxBounds: L.latLngBounds([45.7, 8.3], [49.7, 18.1]),
        maxBoundsViscosity: 0.7,
      }).setView([47.45, 13.35], 7);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      groupRef.current = L.layerGroup().addTo(map);
      map.on("click", (event) => {
        clickRef.current(event.latlng.lat, event.latlng.lng);
      });
      mapRef.current = map;
      map.invalidateSize();
      setMapReady(true);
    })();

    const observer = new ResizeObserver(() => {
      const current = mapRef.current;
      current?.invalidateSize();
      const pin = draftRef.current;
      if (pin && current && !current.getBounds().contains([pin.lat, pin.lng])) {
        current.panTo([pin.lat, pin.lng]);
      }
    });
    observer.observe(host);

    return () => {
      alive = false;
      observer.disconnect();
      map?.remove();
      mapRef.current = null;
      tileRef.current = null;
      groupRef.current = null;
      setMapReady(false);
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !mapReady) return;
    tileRef.current?.remove();
    const spec = TILES[basemap];
    const layer = L.tileLayer(spec.url, {
      attribution: spec.attribution,
      maxZoom: spec.maxZoom,
      ...(spec.subdomains ? { subdomains: spec.subdomains } : {}),
    });
    layer.addTo(map);
    layer.bringToBack();
    tileRef.current = layer;
  }, [basemap, mapReady]);

  useEffect(() => {
    const map = mapRef.current;
    const group = groupRef.current;
    const L = leafletRef.current;
    if (!map || !group || !L || !mapReady) return;
    group.clearLayers();
    const copper =
      getComputedStyle(document.documentElement).getPropertyValue("--color-primary").trim() ||
      "rgb(208, 137, 58)";

    const active = tours.find((tour) => tour.id === activeTourId);
    const numbers = new Map<string, number>();
    if (active?.visible) {
      active.stopIds.forEach((id, index) => {
        if (!numbers.has(id)) numbers.set(id, index + 1);
      });
    }

    for (const tour of tours) {
      if (!tour.visible) continue;
      const points = tour.stopIds
        .map((id) => resolveStop(id, finds))
        .filter((point) => point !== null);
      if (points.length < 2) continue;
      const line = L.polyline(
        points.map((point) => [point.lat, point.lng] as [number, number]),
        {
          color: copper,
          weight: tour.fixed ? 4 : 3,
          opacity: tour.id === activeTourId ? 0.95 : 0.42,
          dashArray: tour.fixed ? undefined : "8 8",
          interactive: false,
        },
      );
      group.addLayer(line);
    }

    if (showPlaces) {
      for (const place of PLACES) {
        const key = placeStopId(place.id);
        const marker = L.marker([place.lat, place.lng], {
          icon: L.divIcon({
            className: "ader-pin",
            html: crystal("place", selectedKey === key, numbers.get(key)),
            iconSize: [28, 28],
            iconAnchor: [14, 28],
          }),
          keyboard: false,
          zIndexOffset: selectedKey === key ? 800 : 100,
          title: place.name,
        });
        marker.on("click", () => {
          selectRef.current(key);
        });
        group.addLayer(marker);
      }
    }

    for (const find of finds) {
      const key = find.id;
      const marker = L.marker([find.lat, find.lng], {
        icon: L.divIcon({
          className: "ader-pin",
          html: crystal("find", selectedKey === key, numbers.get(key)),
          iconSize: [28, 28],
          iconAnchor: [14, 28],
        }),
        keyboard: false,
        zIndexOffset: selectedKey === key ? 900 : 400,
        title: find.name,
      });
      marker.on("click", (event) => {
        const original = (event as { originalEvent?: Event }).originalEvent;
        original?.stopPropagation();
        selectRef.current(key);
      });
      group.addLayer(marker);
    }

    if (draftPin) {
      const marker = L.marker([draftPin.lat, draftPin.lng], {
        icon: L.divIcon({
          className: "ader-pin",
          html: crystal("draft", true),
          iconSize: [28, 28],
          iconAnchor: [14, 28],
        }),
        keyboard: false,
        zIndexOffset: 1000,
        interactive: false,
      });
      group.addLayer(marker);
      if (!map.getBounds().pad(-0.2).contains([draftPin.lat, draftPin.lng])) {
        map.panTo([draftPin.lat, draftPin.lng]);
      }
    }

    if (userLoc) {
      const marker = L.marker([userLoc.lat, userLoc.lng], {
        icon: L.divIcon({
          className: "ader-pin",
          html: `<div class="me-dot"></div>`,
          iconSize: [14, 14],
          iconAnchor: [7, 7],
        }),
        keyboard: false,
        zIndexOffset: 1100,
        interactive: false,
        title: "Dein Standort",
      });
      group.addLayer(marker);
    }
  }, [finds, tours, showPlaces, selectedKey, activeTourId, draftPin, userLoc, mapReady]);

  useEffect(() => {
    if (!focus || !mapRef.current || !mapReady) return;
    mapRef.current.flyTo([focus.lat, focus.lng], focus.zoom, { duration: 0.65 });
  }, [focus, mapReady]);

  return (
    <div className={placing ? "ader-map placing absolute inset-0 z-0" : "ader-map absolute inset-0 z-0"}>
      <div ref={hostRef} className="h-full w-full" role="application" aria-label="Karte von Österreich" />
    </div>
  );
}
