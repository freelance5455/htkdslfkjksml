import { useState, useEffect } from 'react';
import { Compass, Navigation, ArrowUp, ShieldAlert, Luggage, Coffee, CheckSquare, Eye, Camera, RefreshCw } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface AirportARScreenProps {
  language: Language;
}

export function AirportARScreen({ language }: AirportARScreenProps) {
  const [activePoi, setActivePoi] = useState<'gate' | 'security' | 'passport' | 'baggage' | 'lounge' | 'checkin'>('gate');
  const [distance, setDistance] = useState(120);
  const [compassHeading, setCompassHeading] = useState(42);

  const t = translations[language];

  useEffect(() => {
    const interval = setInterval(() => {
      setCompassHeading(prev => (prev + 1) % 360);
    }, 200);
    return () => clearInterval(interval);
  }, []);

  const pois = [
    { id: 'gate', name: t.arPois.gate, dist: 120, target: 'Gate 16', icon: <Navigation className="w-4 h-4 text-cyan-400" /> },
    { id: 'security', name: t.arPois.security, dist: 45, target: 'Checkpoint B', icon: <ShieldAlert className="w-4 h-4 text-amber-400" /> },
    { id: 'passport', name: t.arPois.passport, dist: 80, target: 'Police Aux Frontières', icon: <CheckSquare className="w-4 h-4 text-blue-400" /> },
    { id: 'lounge', name: t.arPois.lounge, dist: 150, target: 'VIP Salon Taki', icon: <Coffee className="w-4 h-4 text-purple-400" /> },
    { id: 'baggage', name: t.arPois.baggage, dist: 310, target: 'Carrousel 03', icon: <Luggage className="w-4 h-4 text-emerald-400" /> },
  ];

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {t.arAssistantTitle}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {t.arNotice}
        </p>
      </div>

      {/* AR HUD Viewport Simulation */}
      <div className="relative w-full h-[380px] md:h-[440px] rounded-3xl overflow-hidden border border-cyan-400/50 bg-[#030611] shadow-[0_0_50px_rgba(0,240,255,0.25)] flex flex-col justify-between p-4">
        {/* Simulated Camera Background: Terminal Corridor Grid with Perspective Lines */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#060c22] via-[#091538] to-[#040816] opacity-90 pointer-events-none" />
        
        {/* Terminal Perspective Grid Overlay */}
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 50% 40%, rgba(0, 240, 255, 0.4) 1px, transparent 1px)`,
            backgroundSize: '24px 24px',
          }}
        />

        {/* Top HUD: Compass & Sensor Telemetry */}
        <div className="relative z-10 flex items-center justify-between text-xs font-mono text-cyan-400 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-cyan-500/30">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>AR ENGINE ACTIVE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5" />
            <span>HDG {compassHeading}° NNE</span>
          </div>
        </div>

        {/* Center 3D Spatial Navigation Arrow & Floating Hologram */}
        <div className="relative z-10 my-auto flex flex-col items-center justify-center">
          {/* Spatial Floating Marker */}
          <div className="animate-bounce [animation-duration:2s] flex flex-col items-center">
            {/* Hologram Pin */}
            <div className="px-4 py-2 rounded-2xl bg-cyan-950/80 backdrop-blur-md border border-cyan-400 text-cyan-300 text-xs font-bold shadow-[0_0_25px_rgba(0,240,255,0.4)] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>{activePoi === 'gate' ? 'Gate 16 · بوابة المغادرة' : activePoi.toUpperCase()}</span>
            </div>

            {/* Glowing 3D AR Waypoint Arrow */}
            <div className="w-16 h-16 my-3 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 p-1 flex items-center justify-center shadow-[0_0_35px_rgba(0,102,255,0.6)] animate-pulse">
              <div className="w-full h-full rounded-full bg-[#070b1e] flex items-center justify-center">
                <ArrowUp className="w-8 h-8 text-cyan-400" />
              </div>
            </div>

            {/* Distance HUD */}
            <div className="text-center">
              <p className="text-2xl font-black text-white font-mono tracking-tight">
                {distance} <span className="text-xs text-cyan-400">متر (m)</span>
              </p>
              <p className="text-[10px] text-slate-400 font-mono">
                مطار هواري بومدين · صالة الرحلات الدولية
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Horizon line */}
        <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-400 bg-black/60 backdrop-blur-md p-2.5 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2">
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span>Camera Vision Ready</span>
          </div>
          <button
            onClick={() => setDistance(prev => Math.max(10, prev - 15))}
            className="text-[10px] text-cyan-400 font-bold hover:underline"
          >
            {language === 'ar' ? 'محاكاة الاقتراب من البوابة' : 'Simulate Walking'}
          </button>
        </div>
      </div>

      {/* POI Selector Chips */}
      <div className="space-y-2">
        <p className="text-xs font-bold text-slate-300">
          {language === 'ar' ? 'اختر نقطة الوصول داخل المطار (Waypoints):' : 'Select Airport Destination:'}
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {pois.map(poi => (
            <button
              key={poi.id}
              onClick={() => {
                setActivePoi(poi.id as any);
                setDistance(poi.dist);
              }}
              className={`p-3 rounded-2xl border text-right rtl:text-right ltr:text-left transition-all ${
                activePoi === poi.id
                  ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                {poi.icon}
                <span className="text-[10px] font-mono text-cyan-400">{poi.dist}m</span>
              </div>
              <p className="text-xs font-bold text-white truncate">{poi.name}</p>
              <p className="text-[10px] text-slate-400">{poi.target}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
