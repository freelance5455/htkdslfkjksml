import React, { useMemo, useState } from 'react';
import { Castle } from 'lucide-react';
import { ClanDashboardState } from '../shared/cocData';
import { formatDateTimeRu } from '../utils/formatters';

interface CapitalViewProps {
  state: ClanDashboardState;
  onSelectPlayer: (tag: string) => void;
}

export const CapitalView: React.FC<CapitalViewProps> = ({
  state,
  onSelectPlayer,
}) => {
  const [seasonIdx, setSeasonIdx] = useState(0);

  const seasons = state.capitalRaids;
  const activeSeason = seasons[seasonIdx] ?? seasons[0] ?? null;

  const overallParticipants = useMemo(() => {
    const map = new Map<
      string,
      {
        tag: string;
        name: string;
        weekends: number;
        attacks: number;
        limit: number;
        totalLoot: number;
      }
    >();
    for (const s of seasons) {
      for (const m of s.members) {
        const cur = map.get(m.tag) ?? {
          tag: m.tag,
          name: m.name,
          weekends: 0,
          attacks: 0,
          limit: 0,
          totalLoot: 0,
        };
        cur.weekends += 1;
        cur.attacks += m.attacks;
        cur.limit += m.attackLimit + m.bonusAttackLimit;
        cur.totalLoot += m.capitalResourcesLooted;
        map.set(m.tag, cur);
      }
    }
    const contribByTag = new Map(state.players.map((p) => [p.tag, p.clanCapitalContributions]));
    return Array.from(map.values())
      .map((item) => ({
        ...item,
        avgPerAttack: item.attacks > 0 ? Math.round(item.totalLoot / item.attacks) : 0,
        allTimeContrib: contribByTag.get(item.tag) ?? 0,
      }))
      .sort((a, b) => b.totalLoot - a.totalLoot || b.attacks - a.attacks);
  }, [seasons, state.players]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы загрузить статистику Столицы клана и рейдовых выходных.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Столица клана и рейды
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Данные из <span className="font-mono text-slate-300">GET /clans/{state.clan.tag}/capitalraidseasons</span>
          </p>
        </div>

        {seasons.length > 0 && (
          <select
            value={seasonIdx}
            onChange={(e) => setSeasonIdx(Number(e.target.value))}
            className="rounded-md border border-slate-800 bg-[#121824] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none self-start sm:self-auto"
          >
            {seasons.map((s, idx) => (
              <option key={`${s.startTime}-${idx}`} value={idx}>
                Рейд: {formatDateTimeRu(s.startTime)} — {s.state === 'ongoing' ? 'Идёт сейчас' : 'Завершён'}
              </option>
            ))}
          </select>
        )}
      </section>

      {/* Clan Capital Hall & Districts */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Castle className="h-4 w-4 text-amber-400" />
            <h2 className="font-display text-base font-semibold text-slate-100">
              Инфраструктура Столицы клана
            </h2>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-300 font-mono tabular-nums">
            <span>Очки: <strong className="text-amber-400">{state.clan.clanCapitalPoints.toLocaleString('ru-RU')}</strong></span>
            <span>Лига: <strong>{state.clan.capitalLeague ?? 'Без лиги'}</strong></span>
            {state.clan.capitalHallLevel && (
              <span>Ратуша столицы: <strong className="text-emerald-400">Ур. {state.clan.capitalHallLevel}</strong></span>
            )}
          </div>
        </div>

        {state.clan.capitalDistricts && state.clan.capitalDistricts.length > 0 ? (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {state.clan.capitalDistricts.map((d) => (
              <div
                key={d.id}
                className="rounded-md border border-slate-800 bg-[#0B0F17] px-3.5 py-2.5 flex items-center justify-between gap-2 text-xs"
              >
                <span className="text-slate-200 truncate">{d.name}</span>
                <span className="font-mono font-semibold tabular-nums text-amber-400 shrink-0">
                  Ур. {d.districtHallLevel}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-slate-500">
            Данные о районах столицы не получены из API.
          </div>
        )}
      </section>

      {!activeSeason ? (
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-xs text-slate-400">
          Сезоны рейдов Столицы клана не найдены в Supercell API.
        </section>
      ) : (
        <>
          {/* Season KPIs */}
          <section className="grid grid-cols-2 gap-4 lg:grid-cols-5">
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Добыто золота столицы</div>
              <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-amber-400">
                {activeSeason.capitalTotalLoot.toLocaleString('ru-RU')}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Использовано атак</div>
              <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-slate-100">
                {activeSeason.totalAttacks}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Разрушено районов</div>
              <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-emerald-400">
                {activeSeason.enemyDistrictsDestroyed}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500 font-mono tabular-nums">
                Рейдов завершено: {activeSeason.raidsCompleted}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Медали за атаку</div>
              <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-sky-400">
                {activeSeason.offensiveReward}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500">за 6 атак макс.</div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Медали за оборону</div>
              <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-slate-100">
                {activeSeason.defensiveReward}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500 font-mono tabular-nums">
                Оборонительных логов: {activeSeason.defenseLogCount}
              </div>
            </div>
          </section>

          {/* Participant Activity Table */}
          <section className="rounded-lg border border-slate-800 bg-[#121824]">
            <div className="border-b border-slate-800 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Активность участников в рейде ({activeSeason.members.length})
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                Использованные атаки (включая бонусную атаку) и добытое золото столицы
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                    <th className="px-4 py-2.5">#</th>
                    <th className="px-4 py-2.5">Участник</th>
                    <th className="px-3 py-2.5 text-right">Атаки</th>
                    <th className="px-3 py-2.5 text-right">Лимит (+бонус)</th>
                    <th className="px-4 py-2.5 text-right">Добыто золота</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {activeSeason.members.map((m, idx) => {
                    const maxAtks = m.attackLimit + m.bonusAttackLimit;
                    return (
                      <tr
                        key={m.tag}
                        onClick={() => onSelectPlayer(m.tag)}
                        className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                      >
                        <td className="px-4 py-2.5 font-mono tabular-nums text-slate-500">{idx + 1}</td>
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <div className="font-medium text-slate-100">{m.name}</div>
                          <div className="font-mono text-[11px] text-slate-500">{m.tag}</div>
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-emerald-400">
                          {m.attacks}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                          {m.attackLimit} (+{m.bonusAttackLimit}) = {maxAtks}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                          {m.capitalResourcesLooted.toLocaleString('ru-RU')}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          {/* Attacked Clans & Districts */}
          <section className="rounded-lg border border-slate-800 bg-[#121824]">
            <div className="border-b border-slate-800 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Атакованные кланы и районы ({activeSeason.attackLog.length})
              </h2>
            </div>
            <div className="divide-y divide-slate-800/70">
              {activeSeason.attackLog.map((raid, idx) => (
                <div key={`${raid.defenderTag}-${idx}`} className="p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm font-semibold text-slate-100">
                      {raid.defenderName}{' '}
                      <span className="font-mono text-xs font-normal text-slate-400">
                        {raid.defenderTag} · Ур. {raid.defenderLevel}
                      </span>
                    </div>
                    <div className="font-mono text-xs tabular-nums text-slate-300">
                      Районов: <strong className="text-emerald-400">{raid.districtsDestroyed}/{raid.districtCount}</strong> · Атак: {raid.attackCount}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
                    {raid.districts.map((d, dIdx) => (
                      <div
                        key={`${d.id}-${dIdx}`}
                        className="rounded border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium text-slate-200 truncate">
                            {d.name} (Ур.{d.districtHallLevel})
                          </span>
                          <span className="font-mono font-semibold text-amber-400 shrink-0">
                            {d.destructionPercent}%
                          </span>
                        </div>
                        <div className="mt-1 flex items-center justify-between font-mono text-[11px] text-slate-400 tabular-nums">
                          <span>Атак: {d.attackCount}</span>
                          <span>{d.totalLooted.toLocaleString('ru-RU')} зол.</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              {activeSeason.attackLog.length === 0 && (
                <div className="p-6 text-center text-xs text-slate-500">
                  Лог атак по районам пуст.
                </div>
              )}
            </div>
          </section>
        </>
      )}

      {/* Overall Capital Participant Rating Across Captured Weekends */}
      {overallParticipants.length > 0 && (
        <section className="rounded-lg border border-slate-800 bg-[#121824]">
          <div className="border-b border-slate-800 px-5 py-4">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Сводный рейтинг участников Столицы ({seasons.length} рейд. выходных)
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Суммарное участие, атаки, добыча золота столицы и общий вклад участников
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                  <th className="px-4 py-2.5">#</th>
                  <th className="px-4 py-2.5">Участник</th>
                  <th className="px-3 py-2.5 text-right">Уик-эндов</th>
                  <th className="px-3 py-2.5 text-right">Атаки</th>
                  <th className="px-3 py-2.5 text-right">Всего добыто</th>
                  <th className="px-3 py-2.5 text-right">Ср. за атаку</th>
                  <th className="px-4 py-2.5 text-right">Общий вклад</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {overallParticipants.map((op, idx) => (
                  <tr
                    key={op.tag}
                    onClick={() => onSelectPlayer(op.tag)}
                    className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                  >
                    <td className="px-4 py-2.5 font-mono tabular-nums text-amber-400">#{idx + 1}</td>
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      <div className="font-medium text-slate-100">{op.name}</div>
                      <div className="font-mono text-[11px] text-slate-500">{op.tag}</div>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {op.weekends}/{seasons.length}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                      {op.attacks}/{op.limit}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                      {op.totalLoot.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                      {op.avgPerAttack.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {op.allTimeContrib > 0 ? op.allTimeContrib.toLocaleString('ru-RU') : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
