import { useCallback, useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import {
  Activity,
  DollarSign,
  ExternalLink,
  ImagePlus,
  Plus,
  Receipt,
  RotateCcw,
  ShieldAlert,
  Trash2,
  TrendingUp,
  Users,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { apiRequest } from '../api.ts';
import type {
  AdminOverviewData,
  AuditLogRecord,
  OrderItem,
  PaymentRecord,
  RefundRecord,
  ServiceItem,
  SupportTicket,
  UserProfile,
} from '../types.ts';
import { formatDateTime, formatInrExact, formatNumber, formatPaymentMethodLabel } from '../utils/format.ts';
import { ReceiptModal } from './ReceiptModal.tsx';
import { StatusLabel } from './StatusLabel.tsx';

export type AdminTab = 'overview' | 'orders' | 'services' | 'customers' | 'payments' | 'support' | 'audit';

interface AdminCustomerRow {
  id: number;
  name: string;
  email: string;
  phone: string;
  wallet_balance_paise: number;
  status: 'active' | 'suspended';
  created_at: string;
  order_count: number;
  total_spent_paise: number;
}

interface AdminWorkspaceProps {
  user: UserProfile;
  activeTab: AdminTab;
  onChangeTab: (tab: AdminTab) => void;
  onServicesChanged: () => void;
}

export function AdminWorkspace({ user, activeTab, onChangeTab, onServicesChanged }: AdminWorkspaceProps) {
  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [customers, setCustomers] = useState<AdminCustomerRow[]>([]);
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [refunds, setRefunds] = useState<RefundRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [bannerError, setBannerError] = useState('');

  // Service creation state
  const [showAddService, setShowAddService] = useState(false);
  const [newSvcName, setNewSvcName] = useState('');
  const [newSvcCategory, setNewSvcCategory] = useState('Creator Promotion');
  const [newSvcDesc, setNewSvcDesc] = useState('');
  const [newSvcRefQty, setNewSvcRefQty] = useState('1000');
  const [newSvcRefPrice, setNewSvcRefPrice] = useState('50');

  // Service inline editing state
  const [editingSvcId, setEditingSvcId] = useState<number | null>(null);
  const [editRefQty, setEditRefQty] = useState('');
  const [editRefPriceInr, setEditRefPriceInr] = useState('');

  // Refund modal state
  const [refundTarget, setRefundTarget] = useState<PaymentRecord | null>(null);
  const [refundReason, setRefundReason] = useState('');
  const [refundDest, setRefundDest] = useState<'wallet' | 'original_source'>('wallet');
  const [refundLoading, setRefundLoading] = useState(false);

  // Support reply state
  const [replyTicketId, setReplyTicketId] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');
  const [replyStatus, setReplyStatus] = useState<'in_review' | 'resolved'>('resolved');

  // Receipt viewer
  const [receiptCode, setReceiptCode] = useState<string | null>(null);

  // Merchant UPI receiving settings
  const [merchantUpiId, setMerchantUpiId] = useState('');
  const [merchantName, setMerchantName] = useState('SOCIAL BOOST');
  const [upiDirectEnabled, setUpiDirectEnabled] = useState(true);
  const [upiQrImageData, setUpiQrImageData] = useState('');
  const [upiSaveMsg, setUpiSaveMsg] = useState('');
  const [upiSaving, setUpiSaving] = useState(false);

  const loadAdminData = useCallback(async () => {
    setBannerError('');
    try {
      const [ov, cust, ord, svc, pay, sup, aud] = await Promise.all([
        apiRequest<AdminOverviewData>('/api/admin/overview'),
        apiRequest<{ customers: AdminCustomerRow[] }>('/api/admin/customers'),
        apiRequest<{ orders: OrderItem[] }>('/api/admin/orders'),
        apiRequest<{ services: ServiceItem[] }>('/api/admin/services'),
        apiRequest<{
          payments: PaymentRecord[];
          refunds: RefundRecord[];
          upiSettings?: {
            merchant_upi_id: string;
            merchant_name: string;
            upi_direct_enabled: number;
            upi_qr_image_data?: string;
          };
        }>('/api/admin/payments'),
        apiRequest<{ tickets: SupportTicket[] }>('/api/admin/support'),
        apiRequest<{ logs: AuditLogRecord[] }>('/api/admin/audit-logs'),
      ]);
      setOverview(ov);
      setCustomers(cust.customers);
      setOrders(ord.orders);
      setServices(svc.services);
      setPayments(pay.payments);
      setRefunds(pay.refunds);
      if (pay.upiSettings) {
        setMerchantUpiId(pay.upiSettings.merchant_upi_id || '');
        setMerchantName(pay.upiSettings.merchant_name || 'SOCIAL BOOST');
        setUpiDirectEnabled(pay.upiSettings.upi_direct_enabled === 1);
        setUpiQrImageData(pay.upiSettings.upi_qr_image_data || '');
      }
      setTickets(sup.tickets);
      setAuditLogs(aud.logs);
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to load admin console data.');
    }
  }, []);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData]);

  const handleToggleCustomerStatus = async (cust: AdminCustomerRow) => {
    const nextStatus = cust.status === 'active' ? 'suspended' : 'active';
    try {
      await apiRequest(`/api/admin/customers/${cust.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: nextStatus }),
      });
      await loadAdminData();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Unable to update customer.');
    }
  };

  const handleUpdateOrderStatus = async (orderId: number, status: string, progressPercent: number) => {
    setBannerError('');
    try {
      await apiRequest(`/api/admin/orders/${orderId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, progressPercent }),
      });
      await loadAdminData();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Unable to update order.');
    }
  };

  const handleCreateService = async (e: FormEvent) => {
    e.preventDefault();
    setBannerError('');
    try {
      await apiRequest('/api/admin/services', {
        method: 'POST',
        body: JSON.stringify({
          name: newSvcName,
          category: newSvcCategory,
          description: newSvcDesc,
          referenceQuantity: Number(newSvcRefQty),
          referencePriceInr: Number(newSvcRefPrice),
          policyApproved: true,
        }),
      });
      setShowAddService(false);
      setNewSvcName('');
      setNewSvcDesc('');
      await loadAdminData();
      onServicesChanged();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to create service.');
    }
  };

  const handleToggleServiceActive = async (svc: ServiceItem) => {
    try {
      await apiRequest(`/api/admin/services/${svc.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive: svc.is_active !== 1 }),
      });
      await loadAdminData();
      onServicesChanged();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to update service.');
    }
  };

  const handleSaveServicePrice = async (svcId: number) => {
    try {
      await apiRequest(`/api/admin/services/${svcId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          referenceQuantity: Number(editRefQty),
          referencePriceInr: Number(editRefPriceInr),
        }),
      });
      setEditingSvcId(null);
      await loadAdminData();
      onServicesChanged();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to update pricing.');
    }
  };

  const handleProcessRefund = async (e: FormEvent) => {
    e.preventDefault();
    if (!refundTarget) return;
    setRefundLoading(true);
    setBannerError('');
    try {
      await apiRequest('/api/admin/refunds', {
        method: 'POST',
        body: JSON.stringify({
          paymentId: refundTarget.id,
          reason: refundReason,
          destination: refundDest,
        }),
      });
      setRefundTarget(null);
      setRefundReason('');
      await loadAdminData();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Refund failed.');
    } finally {
      setRefundLoading(false);
    }
  };

  const handleReplyTicket = async (e: FormEvent) => {
    e.preventDefault();
    if (!replyTicketId) return;
    try {
      await apiRequest(`/api/admin/support/${replyTicketId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          adminReply: replyText,
          status: replyStatus,
        }),
      });
      setReplyTicketId(null);
      setReplyText('');
      await loadAdminData();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to update support ticket.');
    }
  };

  const handleQrFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type)) {
      setBannerError('Please select a PNG, JPG, or WebP QR code image.');
      return;
    }
    if (file.size > 1_500_000) {
      setBannerError('UPI QR code image must be under 1.5 MB.');
      return;
    }
    setBannerError('');
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setUpiQrImageData(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveUpiSettings = async (e: FormEvent) => {
    e.preventDefault();
    setUpiSaving(true);
    setUpiSaveMsg('');
    setBannerError('');
    try {
      await apiRequest('/api/admin/upi-settings', {
        method: 'PATCH',
        body: JSON.stringify({ merchantUpiId, merchantName, upiDirectEnabled, upiQrImageData }),
      });
      setUpiSaveMsg('Merchant UPI ID and QR code settings saved.');
      await loadAdminData();
      onServicesChanged();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to save UPI settings.');
    } finally {
      setUpiSaving(false);
    }
  };

  const handleVerifyUpiPayment = async (paymentId: number, decision: 'approve' | 'reject') => {
    setBannerError('');
    try {
      await apiRequest(`/api/admin/payments/${paymentId}/verify-upi`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      await loadAdminData();
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Failed to update UPI payment status.');
    }
  };

  const maxSeriesRevenue = Math.max(
    100,
    ...(overview?.revenueSeries?.map((d) => d.revenue_paise) || [100]),
  );

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Sub-navigation bar for quick tab access on all viewports */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-medium text-cyan-300">
            Role: {user.role.replace('_', ' ')} · {user.email}
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gradient-aurora mt-0.5">
            Administrator Operations Panel
          </h1>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl sb-surface overflow-x-auto">
          {(
            [
              { id: 'overview', label: 'Revenue' },
              { id: 'orders', label: 'Orders' },
              { id: 'services', label: 'Services' },
              { id: 'customers', label: 'Customers' },
              { id: 'payments', label: 'Payments & Refunds' },
              { id: 'support', label: 'Support' },
              { id: 'audit', label: 'Audit Logs' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onChangeTab(t.id)}
              className={`min-h-[38px] px-3 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                activeTab === t.id
                  ? 'btn-gradient-primary text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {bannerError && (
        <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-4 py-3 text-xs text-rose-300 flex items-center justify-between">
          <span>{bannerError}</span>
          <button type="button" onClick={() => setBannerError('')} className="text-rose-200 cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {/* ADMIN OVERVIEW & REVENUE */}
      {activeTab === 'overview' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-2xl sb-surface p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Daily Revenue</span>
                <DollarSign className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-gradient-ocean mt-2">
                {formatInrExact(overview?.dailyRevenuePaise ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">Captured today</div>
            </div>

            <div className="rounded-2xl sb-surface p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Monthly Revenue</span>
                <TrendingUp className="h-4 w-4 text-fuchsia-400" />
              </div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-gradient-sunset mt-2">
                {formatInrExact(overview?.monthlyRevenuePaise ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">Current billing month</div>
            </div>

            <div className="rounded-2xl sb-surface p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Customers &amp; Orders</span>
                <Users className="h-4 w-4 text-cyan-400" />
              </div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-cyan-300 mt-2">
                {formatNumber(overview?.totalCustomers ?? 0)} / {formatNumber(overview?.totalOrders ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {formatNumber(overview?.activeOrders ?? 0)} active orders
              </div>
            </div>

            <div className="rounded-2xl sb-surface p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Refunds &amp; Tickets</span>
                <RotateCcw className="h-4 w-4 text-amber-400" />
              </div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-amber-300 mt-2">
                {formatInrExact(overview?.totalRefundedPaise ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {formatNumber(overview?.openTickets ?? 0)} open support tickets
              </div>
            </div>
          </div>

          {/* 7-day Revenue Chart */}
          <div className="rounded-2xl sb-surface p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-gradient-aurora">7-Day Verified Revenue Breakdown</h2>
                <p className="text-xs text-slate-300">Only verified payments count toward revenue.</p>
              </div>
              <Activity className="h-4 w-4 text-cyan-400" />
            </div>

            {overview?.revenueSeries?.length ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3 items-end pt-4">
                {overview.revenueSeries.map((day) => {
                  const pct = Math.max(12, Math.round((day.revenue_paise / maxSeriesRevenue) * 100));
                  return (
                    <div key={day.day} className="rounded-xl sb-surface-inner p-3 space-y-2">
                      <div className="h-24 flex items-end">
                        <div
                          className="w-full rounded-lg bg-gradient-to-t from-fuchsia-600 via-violet-500 to-cyan-400"
                          style={{ height: `${pct}%` }}
                        />
                      </div>
                      <div className="text-xs font-mono font-bold text-cyan-200">
                        {formatInrExact(day.revenue_paise)}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        {day.day} · {day.tx_count} tx
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">No captured payments in the last 7 days.</div>
            )}
          </div>
        </motion.div>
      )}

      {/* ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <section className="rounded-2xl sb-surface overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-sm font-semibold text-white">All Customer Orders, Links & Payments ({orders.length})</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/[0.06] text-slate-400">
                  <th className="px-5 py-3 font-medium">Order</th>
                  <th className="px-5 py-3 font-medium">Customer</th>
                  <th className="px-5 py-3 font-medium">Service & Campaign Link</th>
                  <th className="px-5 py-3 font-medium">Payment & UTR</th>
                  <th className="px-5 py-3 font-medium text-right">Amount</th>
                  <th className="px-5 py-3 font-medium">Order Status</th>
                  <th className="px-5 py-3 font-medium text-right">Update Fulfillment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5 whitespace-nowrap">
                      <div className="font-mono font-semibold text-white">{ord.order_code}</div>
                      <div className="text-[11px] font-mono text-slate-400">{formatDateTime(ord.created_at)}</div>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="text-white font-medium">{ord.customer_name}</div>
                      <div className="text-[11px] text-slate-400">{ord.customer_email}</div>
                    </td>
                    <td className="px-5 py-3.5 max-w-[280px]">
                      <div className="text-violet-300 font-medium">
                        {ord.service_name_snapshot} · {formatNumber(ord.quantity)}
                      </div>
                      <a
                        href={ord.target_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-blue-300 hover:text-blue-200 underline underline-offset-2 mt-0.5 max-w-full"
                      >
                        <span className="truncate">{ord.target_url}</span>
                        <ExternalLink className="h-3 w-3 shrink-0" />
                      </a>
                    </td>
                    <td className="px-5 py-3.5 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-200 font-medium">
                          {ord.payment_method ? formatPaymentMethodLabel(ord.payment_method) : 'Not initiated'}
                        </span>
                        {ord.latest_payment_code && (
                          <button
                            type="button"
                            onClick={() => setReceiptCode(ord.latest_payment_code!)}
                            className="text-blue-400 hover:text-blue-300 text-[11px] underline cursor-pointer"
                          >
                            Receipt
                          </button>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                        {ord.utr_number ? `UTR: ${ord.utr_number}` : ord.payment_gateway_status || ord.payment_status}
                      </div>
                      {ord.latest_payment_id &&
                        (ord.payment_gateway_status === 'pending' || ord.payment_gateway_status === 'created') && (
                          <div className="flex items-center gap-2.5 mt-1">
                            <button
                              type="button"
                              onClick={() => handleVerifyUpiPayment(ord.latest_payment_id!, 'approve')}
                              className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                            >
                              Verify UPI
                            </button>
                            <button
                              type="button"
                              onClick={() => handleVerifyUpiPayment(ord.latest_payment_id!, 'reject')}
                              className="text-[11px] font-medium text-rose-400 hover:text-rose-300 cursor-pointer"
                            >
                              Reject
                            </button>
                          </div>
                        )}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono font-semibold text-white whitespace-nowrap">
                      {formatInrExact(ord.total_amount_paise)}
                    </td>
                    <td className="px-5 py-3.5 whitespace-nowrap">
                      <StatusLabel status={ord.status} compact />
                    </td>
                    <td className="px-5 py-3.5 text-right whitespace-nowrap">
                      {ord.payment_status === 'paid' ? (
                        <select
                          aria-label={`Update status for ${ord.order_code}`}
                          value={ord.status}
                          onChange={(e) => {
                            const s = e.target.value;
                            const pct = s === 'completed' ? 100 : s === 'in_progress' ? 60 : s === 'queued' ? 15 : 0;
                            handleUpdateOrderStatus(ord.id, s, pct);
                          }}
                          className="min-h-[36px] rounded-lg sb-surface-inner px-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                        >
                          <option value="queued">Verified & Queued</option>
                          <option value="in_progress">In Progress</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      ) : (
                        <span className="text-[11px] text-slate-500">Awaiting payment</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* SERVICES & PRICING MANAGEMENT */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Service Catalogue & Reference Pricing</h2>
            <button
              type="button"
              onClick={() => setShowAddService((v) => !v)}
              className="min-h-[42px] px-4 rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Add Service</span>
            </button>
          </div>

          {showAddService && (
            <form
              onSubmit={handleCreateService}
              className="rounded-2xl sb-surface border-fuchsia-400/35 p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              <div>
                <label className="block text-xs text-slate-300 mb-1">Service Name</label>
                <input
                  type="text"
                  required
                  value={newSvcName}
                  onChange={(e) => setNewSvcName(e.target.value)}
                  placeholder="e.g. Story Impressions"
                  className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1">Category</label>
                <input
                  type="text"
                  required
                  value={newSvcCategory}
                  onChange={(e) => setNewSvcCategory(e.target.value)}
                  className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3 text-xs text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs text-slate-300 mb-1">Ref Quantity</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newSvcRefQty}
                    onChange={(e) => setNewSvcRefQty(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3 text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">Ref Price (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    step="0.01"
                    value={newSvcRefPrice}
                    onChange={(e) => setNewSvcRefPrice(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3 text-xs font-mono text-white"
                  />
                </div>
              </div>
              <div className="sm:col-span-2 lg:col-span-2">
                <label className="block text-xs text-slate-300 mb-1">Compliant Description</label>
                <input
                  type="text"
                  required
                  value={newSvcDesc}
                  onChange={(e) => setNewSvcDesc(e.target.value)}
                  placeholder="Policy-compliant creator reach description..."
                  className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3 text-xs text-white"
                />
              </div>
              <div className="flex items-end gap-2">
                <button
                  type="submit"
                  className="flex-1 min-h-[42px] rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
                >
                  Save Service
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddService(false)}
                  className="min-h-[42px] px-4 rounded-xl border border-white/10 text-xs text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="rounded-2xl sb-surface overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/[0.06] text-slate-400">
                    <th className="px-5 py-3 font-medium">Service</th>
                    <th className="px-5 py-3 font-medium text-right">Reference Qty</th>
                    <th className="px-5 py-3 font-medium text-right">Reference Price</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {services.map((svc) => {
                    const isEditing = editingSvcId === svc.id;
                    return (
                      <tr key={svc.id} className="hover:bg-white/[0.02]">
                        <td className="px-5 py-3.5">
                          <div className="font-semibold text-white">{svc.name}</div>
                          <div className="text-[11px] text-slate-400">{svc.category}</div>
                        </td>
                        <td className="px-5 py-3.5 text-right font-mono text-slate-200">
                          {isEditing ? (
                            <input
                              type="number"
                              value={editRefQty}
                              onChange={(e) => setEditRefQty(e.target.value)}
                              className="w-24 min-h-[34px] rounded-lg bg-[#08071a] border border-white/15 px-2 text-right font-mono text-white"
                            />
                          ) : (
                            formatNumber(svc.reference_quantity)
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-right font-mono font-semibold text-blue-300">
                          {isEditing ? (
                            <input
                              type="number"
                              step="0.01"
                              value={editRefPriceInr}
                              onChange={(e) => setEditRefPriceInr(e.target.value)}
                              className="w-24 min-h-[34px] rounded-lg bg-[#08071a] border border-white/15 px-2 text-right font-mono text-white"
                            />
                          ) : (
                            formatInrExact(svc.reference_price_paise)
                          )}
                        </td>
                        <td className="px-5 py-3.5">
                          <StatusLabel status={svc.is_active === 1 ? 'active' : 'suspended'} compact />
                        </td>
                        <td className="px-5 py-3.5 text-right whitespace-nowrap space-x-3">
                          {isEditing ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleSaveServicePrice(svc.id)}
                                className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                              >
                                Save
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingSvcId(null)}
                                className="text-slate-400 hover:text-white cursor-pointer"
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingSvcId(svc.id);
                                  setEditRefQty(String(svc.reference_quantity));
                                  setEditRefPriceInr(String(svc.reference_price_paise / 100));
                                }}
                                className="text-blue-400 hover:text-blue-300 font-medium cursor-pointer"
                              >
                                Edit Price
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleServiceActive(svc)}
                                className="text-violet-400 hover:text-violet-300 font-medium cursor-pointer"
                              >
                                {svc.is_active === 1 ? 'Disable' : 'Enable'}
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOMERS MANAGEMENT */}
      {activeTab === 'customers' && (
        <section className="rounded-2xl sb-surface overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-sm font-semibold text-white">Registered Customers ({customers.length})</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/[0.06] text-slate-400">
                  <th className="px-5 py-3 font-medium">Customer</th>
                  <th className="px-5 py-3 font-medium text-right">Orders</th>
                  <th className="px-5 py-3 font-medium text-right">Total Spent</th>
                  <th className="px-5 py-3 font-medium text-right">Wallet Balance</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {customers.map((c) => (
                  <tr key={c.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5">
                      <div className="font-semibold text-white">{c.name}</div>
                      <div className="text-[11px] text-slate-400">{c.email}</div>
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono text-slate-200">{formatNumber(c.order_count)}</td>
                    <td className="px-5 py-3.5 text-right font-mono text-white">
                      {formatInrExact(c.total_spent_paise)}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono text-blue-300">
                      {formatInrExact(c.wallet_balance_paise)}
                    </td>
                    <td className="px-5 py-3.5">
                      <StatusLabel status={c.status} compact />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => handleToggleCustomerStatus(c)}
                        className="text-xs font-medium text-violet-400 hover:text-violet-300 cursor-pointer"
                      >
                        {c.status === 'active' ? 'Suspend' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* PAYMENTS & REFUNDS */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          {/* Merchant UPI Receiving Configuration */}
          <section className="rounded-2xl sb-surface border-cyan-400/35 p-5 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-semibold text-white">Receive Payments via UPI (QR Code Image & UPI ID)</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Upload your own UPI QR code image and/or enter your UPI ID. Customers see it during UPI, GPay, PhonePe, and Paytm checkout.
                </p>
              </div>
              <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={upiDirectEnabled}
                  onChange={(e) => setUpiDirectEnabled(e.target.checked)}
                  className="h-4 w-4 accent-violet-500"
                />
                <span>Enable Direct UPI QR</span>
              </label>
            </div>

            <form onSubmit={handleSaveUpiSettings} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                <div className="sm:col-span-5">
                  <label className="block text-xs text-slate-300 mb-1">Your Merchant UPI ID (VPA)</label>
                  <input
                    type="text"
                    value={merchantUpiId}
                    onChange={(e) => setMerchantUpiId(e.target.value)}
                    placeholder="e.g. yourname@okicici or business@ybl"
                    className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3.5 text-xs font-mono text-white"
                  />
                </div>
                <div className="sm:col-span-4">
                  <label className="block text-xs text-slate-300 mb-1">Payee Display Name</label>
                  <input
                    type="text"
                    required
                    value={merchantName}
                    onChange={(e) => setMerchantName(e.target.value)}
                    placeholder="SOCIAL BOOST"
                    className="w-full min-h-[42px] rounded-xl sb-surface-inner px-3.5 text-xs text-white"
                  />
                </div>
                <div className="sm:col-span-3">
                  <button
                    type="submit"
                    disabled={upiSaving}
                    className="w-full min-h-[42px] rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
                  >
                    {upiSaving ? 'Saving...' : 'Save UPI Settings'}
                  </button>
                </div>
              </div>

              {/* Upload Custom UPI QR Image */}
              <div className="rounded-xl sb-surface-inner p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  {upiQrImageData ? (
                    <div className="p-1.5 bg-white rounded-lg shrink-0">
                      <img
                        src={upiQrImageData}
                        alt="Uploaded Merchant UPI QR"
                        referrerPolicy="no-referrer"
                        className="w-20 h-20 object-contain block"
                      />
                    </div>
                  ) : (
                    <div className="w-20 h-20 rounded-lg border border-dashed border-white/15 flex items-center justify-center text-slate-500 shrink-0">
                      <ImagePlus className="h-6 w-6" />
                    </div>
                  )}

                  <div className="space-y-1">
                    <div className="text-xs font-semibold text-white">
                      {upiQrImageData ? 'Custom UPI QR Code Image Active' : 'Add UPI QR Code Image (Optional)'}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Upload a PNG, JPG, or WebP screenshot/export of your GPay, PhonePe, Paytm, or Bank UPI QR code (max 1.5 MB).
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <label className="min-h-[40px] px-3.5 rounded-xl border border-white/10 bg-white/[0.05] hover:bg-white/[0.1] text-xs font-medium text-white inline-flex items-center gap-1.5 cursor-pointer">
                    <ImagePlus className="h-3.5 w-3.5 text-blue-400" />
                    <span>{upiQrImageData ? 'Replace QR' : 'Upload QR Image'}</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleQrFileChange}
                      className="sr-only"
                    />
                  </label>
                  {upiQrImageData && (
                    <button
                      type="button"
                      onClick={() => setUpiQrImageData('')}
                      className="min-h-[40px] px-3 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-xs font-medium text-rose-300 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>Remove</span>
                    </button>
                  )}
                </div>
              </div>
            </form>

            {upiSaveMsg && <div className="text-xs text-emerald-400">{upiSaveMsg}</div>}
          </section>

          <section className="rounded-2xl sb-surface overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.08]">
              <h2 className="text-sm font-semibold text-white">Gateway & UPI Payment Records ({payments.length})</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/[0.06] text-slate-400">
                    <th className="px-5 py-3 font-medium">Payment</th>
                    <th className="px-5 py-3 font-medium">Order & Campaign Link</th>
                    <th className="px-5 py-3 font-medium">Customer</th>
                    <th className="px-5 py-3 font-medium">Method & UTR</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium text-right">Amount</th>
                    <th className="px-5 py-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {payments.map((p) => (
                    <tr key={p.id} className="hover:bg-white/[0.02]">
                      <td className="px-5 py-3.5">
                        <div className="font-mono text-white">{p.payment_code}</div>
                        <div className="text-[11px] font-mono text-slate-400">
                          {p.webhook_verified ? 'Verified' : 'Unverified'} · {formatDateTime(p.created_at)}
                        </div>
                      </td>
                      <td className="px-5 py-3.5 max-w-[240px]">
                        <div className="font-mono text-violet-300">
                          {p.order_code ? `${p.order_code} · ${p.service_name_snapshot || ''}` : 'Wallet Top-up'}
                        </div>
                        {p.target_url && (
                          <a
                            href={p.target_url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-blue-300 hover:text-blue-200 underline underline-offset-2 mt-0.5 max-w-full"
                          >
                            <span className="truncate">{p.target_url}</span>
                            <ExternalLink className="h-3 w-3 shrink-0" />
                          </a>
                        )}
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="text-white">{p.customer_name}</div>
                        <div className="text-[11px] text-slate-400">{p.customer_email}</div>
                      </td>
                      <td className="px-5 py-3.5 text-slate-300">
                        <div>{formatPaymentMethodLabel(p.method)}</div>
                        {p.utr_number && (
                          <div className="text-[11px] font-mono text-blue-300">UTR: {p.utr_number}</div>
                        )}
                      </td>
                      <td className="px-5 py-3.5">
                        <StatusLabel status={p.status} compact />
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono font-semibold text-white">
                        {formatInrExact(p.amount_paise)}
                      </td>
                      <td className="px-5 py-3.5 text-right whitespace-nowrap space-x-3">
                        <button
                          type="button"
                          onClick={() => setReceiptCode(p.payment_code)}
                          className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 cursor-pointer"
                        >
                          <Receipt className="h-3.5 w-3.5" />
                          <span>Receipt</span>
                        </button>
                        {(p.status === 'pending' || p.status === 'created') && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleVerifyUpiPayment(p.id, 'approve')}
                              className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                            >
                              Verify UPI
                            </button>
                            <button
                              type="button"
                              onClick={() => handleVerifyUpiPayment(p.id, 'reject')}
                              className="text-rose-400 hover:text-rose-300 font-medium cursor-pointer"
                            >
                              Reject
                            </button>
                          </>
                        )}
                        {p.status === 'captured' && (
                          <button
                            type="button"
                            onClick={() => {
                              setRefundTarget(p);
                              setRefundReason('');
                              setRefundDest('wallet');
                            }}
                            className="text-amber-400 hover:text-amber-300 font-medium cursor-pointer"
                          >
                            Refund
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-2xl sb-surface overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.08]">
              <h2 className="text-sm font-semibold text-white">Processed Refunds ({refunds.length})</h2>
            </div>
            {refunds.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">No refunds issued yet.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-white/[0.06] text-slate-400">
                      <th className="px-5 py-3 font-medium">Refund Code</th>
                      <th className="px-5 py-3 font-medium">Customer</th>
                      <th className="px-5 py-3 font-medium">Reason</th>
                      <th className="px-5 py-3 font-medium">Destination</th>
                      <th className="px-5 py-3 font-medium text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {refunds.map((r) => (
                      <tr key={r.id}>
                        <td className="px-5 py-3 font-mono text-white">{r.refund_code}</td>
                        <td className="px-5 py-3 text-slate-300">{r.customer_name}</td>
                        <td className="px-5 py-3 text-slate-300">{r.reason}</td>
                        <td className="px-5 py-3 text-slate-300 capitalize">{r.destination.replace('_', ' ')}</td>
                        <td className="px-5 py-3 text-right font-mono font-semibold text-white">
                          {formatInrExact(r.amount_paise)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}

      {/* SUPPORT DESK */}
      {activeTab === 'support' && (
        <div className="rounded-2xl sb-surface overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-sm font-semibold text-white">Customer Support Queue ({tickets.length})</h2>
          </div>
          {tickets.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">No support tickets found.</div>
          ) : (
            <div className="divide-y divide-white/[0.06]">
              {tickets.map((t) => (
                <div key={t.id} className="p-5 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="text-sm font-semibold text-white">{t.subject}</div>
                      <div className="text-[11px] font-mono text-slate-400">
                        {t.ticket_code} · {t.customer_name} ({t.customer_email}) · {formatDateTime(t.created_at)}
                      </div>
                    </div>
                    <StatusLabel status={t.status} compact />
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{t.message}</p>

                  {replyTicketId === t.id ? (
                    <form onSubmit={handleReplyTicket} className="space-y-3 pt-2">
                      <textarea
                        rows={3}
                        required
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Write response to customer..."
                        className="w-full rounded-xl sb-surface-inner p-3 text-xs text-white"
                      />
                      <div className="flex flex-wrap items-center gap-3">
                        <select
                          value={replyStatus}
                          onChange={(e) => setReplyStatus(e.target.value as 'in_review' | 'resolved')}
                          className="min-h-[38px] rounded-lg sb-surface-inner px-3 text-xs text-white"
                        >
                          <option value="in_review">In Review</option>
                          <option value="resolved">Mark Resolved</option>
                        </select>
                        <button
                          type="submit"
                          className="min-h-[38px] px-4 rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
                        >
                          Send Reply
                        </button>
                        <button
                          type="button"
                          onClick={() => setReplyTicketId(null)}
                          className="min-h-[38px] px-3 text-xs text-slate-400 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="flex items-center justify-between gap-4 pt-1">
                      <div className="text-xs text-blue-300">
                        {t.admin_reply ? `Reply: ${t.admin_reply}` : 'Awaiting admin response'}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setReplyTicketId(t.id);
                          setReplyText(t.admin_reply || '');
                          setReplyStatus('resolved');
                        }}
                        className="min-h-[36px] px-3.5 rounded-lg border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-xs font-medium text-white cursor-pointer shrink-0"
                      >
                        Reply
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* AUDIT LOGS */}
      {activeTab === 'audit' && (
        <section className="rounded-2xl sb-surface overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Security & Administrative Audit Logs</h2>
            <ShieldAlert className="h-4 w-4 text-violet-400" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/[0.06] text-slate-400">
                  <th className="px-5 py-3 font-medium">Timestamp</th>
                  <th className="px-5 py-3 font-medium">Actor</th>
                  <th className="px-5 py-3 font-medium">Action</th>
                  <th className="px-5 py-3 font-medium">Entity</th>
                  <th className="px-5 py-3 font-medium">Metadata</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3 font-mono text-slate-400 whitespace-nowrap">
                      {formatDateTime(log.created_at)}
                    </td>
                    <td className="px-5 py-3 whitespace-nowrap">
                      <span className="text-white font-medium">{log.actor_type}</span>
                      <span className="text-slate-400"> · {log.actor_email || 'system'}</span>
                    </td>
                    <td className="px-5 py-3 font-mono text-violet-300 whitespace-nowrap">{log.action}</td>
                    <td className="px-5 py-3 font-mono text-slate-200 whitespace-nowrap">
                      {log.entity_type}:{log.entity_id}
                    </td>
                    <td className="px-5 py-3 font-mono text-[11px] text-slate-400 max-w-[320px] truncate">
                      {log.metadata_json}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Refund Modal */}
      {refundTarget && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
          <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl sb-surface p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Process Refund</h3>
              <button
                type="button"
                onClick={() => setRefundTarget(null)}
                className="min-h-[36px] min-w-[36px] rounded-lg bg-white/[0.05] flex items-center justify-center text-slate-300 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="rounded-xl sb-surface-inner p-4 text-xs space-y-1">
              <div className="text-slate-400">Payment: {refundTarget.payment_code}</div>
              <div className="text-lg font-bold font-mono text-white">
                {formatInrExact(refundTarget.amount_paise)}
              </div>
              <div className="text-slate-400">Customer: {refundTarget.customer_name}</div>
            </div>

            <form onSubmit={handleProcessRefund} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">Refund Destination</label>
                <select
                  value={refundDest}
                  onChange={(e) => setRefundDest(e.target.value as 'wallet' | 'original_source')}
                  className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3 text-xs text-white"
                >
                  <option value="wallet">Credit Customer Account Wallet (Instant)</option>
                  <option value="original_source">Original UPI / Bank Source (Gateway)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">Refund Reason (Recorded in Audit Log)</label>
                <input
                  type="text"
                  required
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  placeholder="e.g. Campaign URL unavailable or customer request"
                  className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                disabled={refundLoading}
                className="w-full min-h-[44px] rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
              >
                {refundLoading ? 'Processing Refund...' : 'Confirm & Issue Refund'}
              </button>
            </form>
          </div>
        </div>
      )}

      <ReceiptModal paymentCode={receiptCode} onClose={() => setReceiptCode(null)} />
    </div>
  );
}
