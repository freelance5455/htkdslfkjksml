import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { Image, Video, Hash, MapPin, Send, X, RefreshCw } from 'lucide-react';

interface CreatePostCardProps {
  onPostCreated: () => void;
}

export const CreatePostCard: React.FC<CreatePostCardProps> = ({ onPostCreated }) => {
  const { currentUser, setAuthModalOpen } = useAuth();
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [province, setProvince] = useState(currentUser?.province || 'Luanda');
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!currentUser) {
    return (
      <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-5 mb-5 flex items-center justify-between text-slate-300">
        <div>
          <h4 className="font-bold text-white text-sm">Junte-se à conversa no Angola Connect</h4>
          <p className="text-xs text-slate-400 mt-0.5">Faça login para publicar, comentar e reagir.</p>
        </div>
        <button
          onClick={() => setAuthModalOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all"
        >
          Entrar / Registar
        </button>
      </div>
    );
  }

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    setMediaType(isVideo ? 'video' : 'image');

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        setIsUploading(true);
        const base64 = reader.result as string;
        const res = await api.uploadFile(base64, file.name);
        setMediaUrl(res.url);
      } catch (err: any) {
        setErrorMsg('Erro no envio do ficheiro: ' + err.message);
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAddHashtag = (tag: string) => {
    setContent(prev => (prev ? `${prev} #${tag}` : `#${tag}`));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !mediaUrl) return;

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      await api.createPost({
        authorId: currentUser.id,
        content: content.trim(),
        mediaUrl: mediaUrl || undefined,
        mediaType: mediaUrl ? mediaType : 'none',
        province
      });

      setContent('');
      setMediaUrl(null);
      onPostCreated();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 mb-5 shadow-sm">
      <form onSubmit={handleSubmit} className="space-y-3.5">
        <div className="flex gap-3">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-10 h-10 rounded-full object-cover shrink-0 ring-2 ring-slate-800"
          />
          <div className="flex-1">
            <textarea
              rows={3}
              placeholder={`No que está a pensar, ${currentUser.name.split(' ')[0]}? Partilhe com Angola...`}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 resize-none transition-colors"
            />
          </div>
        </div>

        {/* Media Preview if attached */}
        {mediaUrl && (
          <div className="relative rounded-xl overflow-hidden border border-slate-800 max-h-80 bg-slate-950">
            {mediaType === 'image' ? (
              <img src={mediaUrl} alt="Preview" className="w-full h-full max-h-80 object-cover" />
            ) : (
              <video src={mediaUrl} controls className="w-full h-full max-h-80 object-cover" />
            )}
            <button
              type="button"
              onClick={() => setMediaUrl(null)}
              className="absolute top-2 right-2 p-1.5 bg-black/70 hover:bg-black text-white rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {errorMsg && (
          <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/60">{errorMsg}</p>
        )}

        {/* Hashtags shortcut */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs text-slate-400 scrollbar-none">
          <span className="text-[11px] text-slate-500 font-medium shrink-0 flex items-center gap-1">
            <Hash className="w-3 h-3 text-amber-500" />
            Adicionar:
          </span>
          {['AngolaConnect', 'Luanda', 'Kizomba', 'ModaAngolana', 'StartupsAngola', 'PalancasNegras'].map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => handleAddHashtag(tag)}
              className="px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 hover:border-amber-500/50 hover:text-amber-400 transition-colors shrink-0 text-[11px]"
            >
              #{tag}
            </button>
          ))}
        </div>

        {/* Action Controls & Location */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800/80 text-slate-300 hover:text-white cursor-pointer text-xs transition-colors">
              <Image className="w-4 h-4 text-emerald-400" />
              <span>Foto</span>
              <input type="file" accept="image/*" onChange={handleMediaUpload} className="hidden" />
            </label>

            <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800/80 text-slate-300 hover:text-white cursor-pointer text-xs transition-colors">
              <Video className="w-4 h-4 text-red-400" />
              <span>Vídeo</span>
              <input type="file" accept="video/*" onChange={handleMediaUpload} className="hidden" />
            </label>

            {/* Province tag */}
            <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="bg-transparent text-xs text-slate-200 focus:outline-none"
              >
                {ANGOLA_PROVINCES.filter(p => p !== 'Todas').map((p) => (
                  <option key={p} value={p} className="bg-slate-900 text-white">
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting || isUploading || (!content.trim() && !mediaUrl)}
            className="px-5 py-2 bg-gradient-to-r from-red-600 via-amber-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/10 transition-all active:scale-[0.98] disabled:opacity-40"
          >
            {isSubmitting || isUploading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-950" />
            ) : (
              <>
                <span>Publicar</span>
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
