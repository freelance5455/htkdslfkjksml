import React, { useState, useEffect } from 'react';
import { Post, StoriesGroup, User, TrendingHashtag } from '../../types';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { StoriesBar } from '../stories/StoriesBar';
import { CreatePostCard } from './CreatePostCard';
import { PostCard } from './PostCard';
import { MapPin, Hash, X, Flame, Sparkles, RefreshCw, ShoppingBag, ArrowRight } from 'lucide-react';

interface FeedViewProps {
  onOpenStory: (group: StoriesGroup) => void;
  onOpenCreateStory: () => void;
  onNavigateTab: (tab: string) => void;
  onAuthorClick: (userId: string) => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onOpenStory,
  onOpenCreateStory,
  onNavigateTab,
  onAuthorClick
}) => {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [storiesGrouped, setStoriesGrouped] = useState<StoriesGroup[]>([]);
  const [authorsMap, setAuthorsMap] = useState<Map<string, User>>(new Map());
  const [selectedProvince, setSelectedProvince] = useState<string>('Todas');
  const [activeHashtag, setActiveHashtag] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [trendingTags, setTrendingTags] = useState<TrendingHashtag[]>([]);
  const [recommendedUsers, setRecommendedUsers] = useState<User[]>([]);

  const loadFeedData = async () => {
    try {
      setIsLoading(true);

      // Load stories
      const storiesRes = await api.getStories(currentUser?.id);
      setStoriesGrouped(storiesRes.storiesGrouped || []);

      // Load users map for authors
      const usersRes = await api.searchUsers();
      const map = new Map<string, User>();
      for (const u of usersRes.users || []) {
        map.set(u.id, u);
      }
      setAuthorsMap(map);

      // Recommended users (not me, not already friends)
      if (currentUser) {
        const notFriends = (usersRes.users || []).filter(
          u => u.id !== currentUser.id && !currentUser.friends.includes(u.id)
        );
        setRecommendedUsers(notFriends.slice(0, 3));
      }

      // Load posts with filters
      const postsRes = await api.getPosts({
        province: selectedProvince !== 'Todas' ? selectedProvince : undefined,
        hashtag: activeHashtag || undefined
      });
      setPosts(postsRes.posts || []);

      // Load trends for side rail
      const trendsRes = await api.getTrends();
      setTrendingTags(trendsRes.trendingHashtags.slice(0, 5));
    } catch (err) {
      console.error('Erro ao carregar feed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadFeedData();
  }, [selectedProvince, activeHashtag, currentUser?.id]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        {/* Main Feed Column (8 cols on lg) */}
        <main className="lg:col-span-8">

          {/* Stories Horizontal Bar */}
          <StoriesBar
            storiesGrouped={storiesGrouped}
            onOpenStory={onOpenStory}
            onOpenCreateStory={onOpenCreateStory}
          />

          {/* Province Filter Pill Bar */}
          <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-semibold text-slate-400 shrink-0 flex items-center gap-1 pl-1">
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              Filtrar por Província:
            </span>
            {ANGOLA_PROVINCES.map((prov) => (
              <button
                key={prov}
                onClick={() => setSelectedProvince(prov)}
                className={`px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap shrink-0 transition-colors ${
                  selectedProvince === prov
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                }`}
              >
                {prov === 'Todas' ? '🇦🇴 Todas as Províncias' : prov}
              </button>
            ))}
          </div>

          {/* Active Hashtag Filter indicator if selected */}
          {activeHashtag && (
            <div className="flex items-center justify-between p-3 mb-4 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Hash className="w-4 h-4 text-amber-400" />
                A ver publicações com a hashtag: <strong className="font-bold">#{activeHashtag}</strong>
              </span>
              <button
                onClick={() => setActiveHashtag(null)}
                className="flex items-center gap-1 p-1 hover:bg-amber-500/20 rounded-md transition-colors"
                title="Limpar filtro"
              >
                <span>Limpar</span>
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Create Post */}
          <CreatePostCard onPostCreated={loadFeedData} />

          {/* Posts Feed */}
          {isLoading ? (
            <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
              <RefreshCw className="w-6 h-6 animate-spin text-amber-400 mx-auto mb-2" />
              <p className="text-xs">A carregar publicações de Angola...</p>
            </div>
          ) : posts.length === 0 ? (
            <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-10 text-center text-slate-400">
              <Sparkles className="w-8 h-8 text-amber-400/80 mx-auto mb-2" />
              <h4 className="font-bold text-white text-sm">Nenhuma publicação encontrada</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                {selectedProvince !== 'Todas'
                  ? `Ainda não existem publicações na província de ${selectedProvince}. Seja o primeiro a publicar!`
                  : 'Comece a partilhar com a comunidade angolana agora mesmo.'}
              </p>
            </div>
          ) : (
            posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                authorsMap={authorsMap}
                onPostUpdated={loadFeedData}
                onHashtagClick={(tag) => setActiveHashtag(tag)}
                onAuthorClick={onAuthorClick}
              />
            ))
          )}

        </main>

        {/* Right Rail (4 cols on lg: Trending, Recommendations, Marketplace teaser) */}
        <aside className="hidden lg:block lg:col-span-4 space-y-5">

          {/* Angola Agora Trending Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-500" />
                <h3 className="font-bold text-sm text-white font-display">Angola Agora 🇦🇴</h3>
              </div>
              <button
                onClick={() => onNavigateTab('trends')}
                className="text-xs text-amber-400 hover:underline font-medium"
              >
                Ver tudo
              </button>
            </div>

            <div className="mt-3 space-y-2.5">
              {trendingTags.map((t) => (
                <button
                  key={t.tag}
                  onClick={() => setActiveHashtag(t.tag)}
                  className="w-full flex items-center justify-between text-left p-2 rounded-xl hover:bg-slate-950 transition-colors group"
                >
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">
                      {t.category}
                    </span>
                    <p className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors">
                      #{t.tag}
                    </p>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {t.count.toLocaleString()} posts
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* People Recommendations */}
          {recommendedUsers.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="font-bold text-sm text-white font-display">Conectar com Pessoas</h3>
                <button
                  onClick={() => onNavigateTab('friends')}
                  className="text-xs text-amber-400 hover:underline font-medium"
                >
                  Explorar
                </button>
              </div>

              <div className="mt-3 space-y-3">
                {recommendedUsers.map((u) => (
                  <div key={u.id} className="flex items-center justify-between gap-2.5">
                    <button
                      onClick={() => onAuthorClick(u.id)}
                      className="flex items-center gap-2.5 text-left flex-1 min-w-0"
                    >
                      <img
                        src={u.avatar}
                        alt={u.name}
                        className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-slate-700"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-white truncate hover:text-amber-400">{u.name}</p>
                        <p className="text-[10px] text-slate-400 truncate">🇦🇴 {u.province}</p>
                      </div>
                    </button>

                    <button
                      onClick={async () => {
                        if (!currentUser) return;
                        await api.sendFriendRequest(currentUser.id, u.id);
                        alert(`Pedido de amizade enviado a ${u.name}!`);
                        loadFeedData();
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-white rounded-lg text-xs font-medium transition-colors shrink-0"
                    >
                      Adicionar
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Marketplace Spotlight Card */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 text-emerald-400 mb-2">
              <ShoppingBag className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Mercado Angola</span>
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Compre e venda em Kwanzas (AOA)</h4>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Descubra moda artesanal Samakaka, tecnologia, veículos e imóveis em todas as províncias.
            </p>
            <button
              onClick={() => onNavigateTab('marketplace')}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
            >
              <span>Ver Anúncios</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </aside>

      </div>
    </div>
  );
};
