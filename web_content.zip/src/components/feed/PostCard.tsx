import React, { useState } from 'react';
import { Post, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import {
  Heart, MessageCircle, Share2, Bookmark,
  MoreHorizontal, Flag, Trash2, Edit2, Check,
  Send, CornerDownRight, ShieldCheck, Flame
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  authorsMap: Map<string, User>;
  onPostUpdated: () => void;
  onHashtagClick?: (tag: string) => void;
  onAuthorClick?: (userId: string) => void;
}

const REACTIONS = [
  { key: 'like', label: 'Gosto', emoji: '👍', color: 'text-blue-400' },
  { key: 'love', label: 'Amor', emoji: '❤️', color: 'text-red-400' },
  { key: 'angola', label: 'Força Angola', emoji: '🇦🇴', color: 'text-amber-400' },
  { key: 'laugh', label: 'Riso', emoji: '😂', color: 'text-yellow-400' },
  { key: 'fire', label: 'Fogo', emoji: '🔥', color: 'text-orange-400' }
];

export const PostCard: React.FC<PostCardProps> = ({
  post,
  authorsMap,
  onPostUpdated,
  onHashtagClick,
  onAuthorClick
}) => {
  const { currentUser, setAuthModalOpen } = useAuth();
  const author = authorsMap.get(post.authorId);

  const [showReactionsPicker, setShowReactionsPicker] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const isAuthor = currentUser?.id === post.authorId;
  const isSaved = currentUser ? post.savedBy.includes(currentUser.id) : false;
  const userReaction = currentUser ? post.likes.find(l => l.userId === currentUser.id)?.reaction : null;

  // React
  const handleReact = async (reactionKey: any = 'like') => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    setShowReactionsPicker(false);
    try {
      await api.reactPost(post.id, currentUser.id, reactionKey);
      onPostUpdated();
    } catch (err: any) {
      console.error(err);
    }
  };

  // Comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (!commentText.trim()) return;

    try {
      await api.commentPost(post.id, {
        authorId: currentUser.id,
        text: commentText.trim()
      });
      setCommentText('');
      onPostUpdated();
    } catch (err: any) {
      console.error(err);
    }
  };

  // Reply to Comment
  const handleAddReply = async (commentId: string) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (!replyText.trim()) return;

    try {
      await api.commentPost(post.id, {
        authorId: currentUser.id,
        text: replyText.trim(),
        parentCommentId: commentId
      });
      setReplyText('');
      setReplyToId(null);
      onPostUpdated();
    } catch (err: any) {
      console.error(err);
    }
  };

  // Share
  const handleShare = async () => {
    try {
      await api.sharePost(post.id, currentUser?.id);
      navigator.clipboard?.writeText?.(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
      onPostUpdated();
    } catch (err) {
      console.error(err);
    }
  };

  // Save / Bookmark
  const handleToggleSave = async () => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      await api.savePost(post.id, currentUser.id);
      onPostUpdated();
    } catch (err) {
      console.error(err);
    }
  };

  // Delete
  const handleDelete = async () => {
    if (!currentUser) return;
    if (!window.confirm('Tem a certeza que deseja eliminar esta publicação?')) return;
    try {
      await api.deletePost(post.id, currentUser.id, currentUser.isAdmin);
      onPostUpdated();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Save edit
  const handleSaveEdit = async () => {
    if (!currentUser) return;
    try {
      await api.updateProfile(post.id, { bio: editContent }); // or endpoint
      const res = await fetch(`/api/posts/${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, content: editContent })
      });
      if (res.ok) {
        setIsEditing(false);
        onPostUpdated();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Report
  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !reportReason.trim()) return;

    try {
      await api.reportPost(post.id, currentUser.id, reportReason.trim());
      setShowReportModal(false);
      setReportReason('');
      alert('Denúncia enviada com sucesso à moderação do Angola Connect.');
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Render text with clickable hashtags
  const renderFormattedText = (text: string) => {
    const parts = text.split(/(#[\w\u00C0-\u017F]+)/g);
    return parts.map((part, i) => {
      if (part.startsWith('#')) {
        return (
          <button
            key={i}
            onClick={() => onHashtagClick?.(part.slice(1))}
            className="text-amber-400 hover:underline font-medium inline-block mr-0.5"
          >
            {part}
          </button>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  const activeReactionObj = REACTIONS.find(r => r.key === userReaction);

  return (
    <article className="w-full bg-slate-900 border border-slate-800 rounded-2xl mb-5 shadow-sm overflow-hidden text-slate-100">

      {/* Header */}
      <div className="p-4 sm:p-5 pb-3 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onAuthorClick?.(post.authorId)}
            className="focus:outline-none"
          >
            <img
              src={author?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
              alt={author?.name || 'Autor'}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-800 hover:ring-amber-500/50 transition-all"
            />
          </button>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => onAuthorClick?.(post.authorId)}
                className="font-bold text-sm text-white hover:text-amber-400 transition-colors text-left"
              >
                {author?.name || 'Utilizador Angola Connect'}
              </button>
              {author?.verified && (
                <span title="Verificado 🇦🇴">
                  <ShieldCheck className="w-4 h-4 text-amber-400 fill-amber-400/20 shrink-0" />
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>@{author?.username || 'utilizador'}</span>
              <span>·</span>
              <span className="text-amber-400/90 font-medium">🇦🇴 {post.province}</span>
              <span>·</span>
              <span className="text-slate-500">
                {new Date(post.createdAt).toLocaleDateString('pt-AO', { day: '2-digit', month: 'short' })}
              </span>
            </div>
          </div>
        </div>

        {/* Options Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(prev => !prev)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {showMenu && (
            <div
              className="absolute right-0 mt-1 w-44 bg-slate-950 border border-slate-800 rounded-xl shadow-xl py-1 text-xs text-slate-200 z-30 animate-in fade-in zoom-in-95"
              onClick={() => setShowMenu(false)}
            >
              {isAuthor && (
                <>
                  <button
                    onClick={() => { setIsEditing(true); setEditContent(post.content); }}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 text-slate-300"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Editar Publicação</span>
                  </button>
                  <button
                    onClick={handleDelete}
                    className="w-full text-left px-3 py-2 hover:bg-red-950/40 text-red-400 flex items-center gap-2"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar</span>
                  </button>
                </>
              )}
              {!isAuthor && (
                <button
                  onClick={() => setShowReportModal(true)}
                  className="w-full text-left px-3 py-2 hover:bg-red-950/40 text-red-400 flex items-center gap-2"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Denunciar Conteúdo</span>
                </button>
              )}
              <button
                onClick={handleToggleSave}
                className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 text-slate-300"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{isSaved ? 'Remover dos Salvos' : 'Guardar Publicação'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Text Content */}
      <div className="px-4 sm:px-5 py-2">
        {isEditing ? (
          <div className="space-y-2">
            <textarea
              rows={3}
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setIsEditing(false)}
                className="px-3 py-1 text-xs text-slate-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-3 py-1 bg-amber-500 text-slate-950 font-bold rounded-lg text-xs"
              >
                Guardar
              </button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-line">
            {renderFormattedText(post.content)}
          </p>
        )}
      </div>

      {/* Media Gallery */}
      {post.mediaUrl && (
        <div className="mt-2.5 max-h-[500px] overflow-hidden bg-slate-950 border-y border-slate-800/80">
          {post.mediaType === 'video' ? (
            <video src={post.mediaUrl} controls className="w-full max-h-[500px] object-contain" />
          ) : (
            <img
              src={post.mediaUrl}
              alt="Mídia da publicação"
              className="w-full max-h-[500px] object-cover"
            />
          )}
        </div>
      )}

      {/* Stats Bar */}
      <div className="px-4 sm:px-5 py-2.5 flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/80">
        <div className="flex items-center gap-1.5">
          {post.likes.length > 0 && (
            <span className="flex items-center -space-x-1">
              <span className="w-5 h-5 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center text-[10px]">❤️</span>
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px]">🇦🇴</span>
            </span>
          )}
          <span>{post.likes.length} reações</span>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={() => setShowComments(prev => !prev)} className="hover:text-slate-200">
            {post.comments.length} comentários
          </button>
          <span>·</span>
          <span>{post.sharesCount} partilhas</span>
        </div>
      </div>

      {/* Action Buttons & Reactions Popover */}
      <div className="relative px-2 sm:px-4 py-1.5 flex items-center justify-between text-xs font-semibold text-slate-400">

        {/* Reaction trigger */}
        <div
          className="relative flex-1"
          onMouseEnter={() => setShowReactionsPicker(true)}
          onMouseLeave={() => setShowReactionsPicker(false)}
        >
          <button
            onClick={() => handleReact(userReaction ? userReaction : 'like')}
            className={`w-full py-2 rounded-xl flex items-center justify-center gap-1.5 hover:bg-slate-800/60 transition-colors ${activeReactionObj ? activeReactionObj.color : 'hover:text-white'}`}
          >
            {activeReactionObj ? (
              <>
                <span className="text-base">{activeReactionObj.emoji}</span>
                <span>{activeReactionObj.label}</span>
              </>
            ) : (
              <>
                <Heart className="w-4 h-4" />
                <span>Gosto</span>
              </>
            )}
          </button>

          {/* Reactions Floating Palette */}
          {showReactionsPicker && (
            <div className="absolute bottom-full left-0 mb-1 flex items-center gap-1.5 p-1.5 bg-slate-950 border border-slate-800 rounded-full shadow-2xl z-40 animate-in zoom-in-75 duration-150">
              {REACTIONS.map((r) => (
                <button
                  key={r.key}
                  onClick={() => handleReact(r.key)}
                  className="w-8 h-8 flex items-center justify-center text-lg hover:scale-135 active:scale-95 transition-transform"
                  title={r.label}
                >
                  {r.emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Comment trigger */}
        <button
          onClick={() => setShowComments(prev => !prev)}
          className="flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 hover:bg-slate-800/60 hover:text-white transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Comentar</span>
        </button>

        {/* Share trigger */}
        <button
          onClick={handleShare}
          className="flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 hover:bg-slate-800/60 hover:text-white transition-colors"
        >
          <Share2 className="w-4 h-4" />
          <span>{copiedLink ? 'Link Copiado!' : 'Partilhar'}</span>
        </button>

        {/* Save trigger */}
        <button
          onClick={handleToggleSave}
          className={`px-3 py-2 rounded-xl flex items-center justify-center hover:bg-slate-800/60 transition-colors ${isSaved ? 'text-amber-400' : 'hover:text-white'}`}
          title="Guardar"
        >
          <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-amber-400' : ''}`} />
        </button>
      </div>

      {/* Expandable Comments Section */}
      {showComments && (
        <div className="p-4 sm:p-5 pt-3 bg-slate-950/60 border-t border-slate-800/80 space-y-3">

          {/* New Comment Input */}
          {currentUser && (
            <form onSubmit={handleAddComment} className="flex gap-2">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full object-cover shrink-0"
              />
              <div className="flex-1 flex gap-2">
                <input
                  type="text"
                  placeholder="Escreva um comentário simpático..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs hover:bg-amber-400 disabled:opacity-40 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          )}

          {/* Comments List */}
          <div className="space-y-3 pt-2">
            {post.comments.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-2">Seja o primeiro a comentar!</p>
            ) : (
              post.comments.map((comm) => {
                const commAuthor = authorsMap.get(comm.authorId);
                return (
                  <div key={comm.id} className="space-y-2 text-xs">
                    <div className="flex items-start gap-2.5">
                      <img
                        src={commAuthor?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
                        alt={commAuthor?.name || 'Autor'}
                        className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                      />
                      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-white">{commAuthor?.name || 'Utilizador'}</span>
                          <span className="text-[10px] text-slate-500">
                            {new Date(comm.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-300 mt-1 leading-relaxed">{comm.text}</p>

                        <button
                          onClick={() => setReplyToId(replyToId === comm.id ? null : comm.id)}
                          className="text-[10px] text-amber-400 font-semibold mt-1.5 hover:underline"
                        >
                          Responder
                        </button>
                      </div>
                    </div>

                    {/* Replies */}
                    {comm.replies && comm.replies.length > 0 && (
                      <div className="pl-9 space-y-2">
                        {comm.replies.map((rep) => {
                          const repAuthor = authorsMap.get(rep.authorId);
                          return (
                            <div key={rep.id} className="flex items-start gap-2 bg-slate-900/60 border border-slate-800/60 rounded-xl p-2">
                              <CornerDownRight className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-1" />
                              <img
                                src={repAuthor?.avatar || '/src/assets/images/angola_user_manuel_1793388060300.jpg'}
                                className="w-5 h-5 rounded-full object-cover shrink-0"
                              />
                              <div className="flex-1">
                                <span className="font-semibold text-white text-[11px]">{repAuthor?.name}</span>
                                <p className="text-slate-300 text-xs mt-0.5">{rep.text}</p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Inline reply box */}
                    {replyToId === comm.id && (
                      <div className="pl-9 flex gap-2">
                        <input
                          type="text"
                          placeholder="Responder a este comentário..."
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                        <button
                          onClick={() => handleAddReply(comm.id)}
                          className="px-3 py-1 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs"
                        >
                          Enviar
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl">
            <h4 className="font-bold text-sm text-white mb-2 font-display">Denunciar Conteúdo</h4>
            <p className="text-xs text-slate-400 mb-3">
              Por que motivo deseja denunciar esta publicação à moderação?
            </p>
            <form onSubmit={handleReportSubmit} className="space-y-3">
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                required
              >
                <option value="">Selecione um motivo...</option>
                <option value="spam">Spam ou fraude comercial</option>
                <option value="hate">Discurso de ódio ou ofensa</option>
                <option value="misinfo">Desinformação</option>
                <option value="inappropriate">Conteúdo impróprio ou nudez</option>
                <option value="other">Outro motivo</option>
              </select>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs"
                >
                  Confirmar Denúncia
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </article>
  );
};
