import type { HudState, Mode } from "@/game/engine";
import type { Word } from "@/game/words";

interface TopBarProps {
  hud: HudState;
  onPause: () => void;
}

export function TopBar({ hud, onPause }: TopBarProps) {
  return (
    <div className="flex w-full items-center justify-between gap-2 px-3 pt-3 sm:px-5">
      <div className="flex items-center gap-2">
        <div className="glass flex items-center gap-2 rounded-xl px-3 py-1.5">
          <span className="text-xs text-slate-300">امتیاز</span>
          <span
            key={hud.score}
            className="animate-pop-in font-display text-xl font-black tabular-nums text-cyan-300 sm:text-2xl"
          >
            {hud.score}
          </span>
        </div>
        <div className="glass hidden items-center gap-1.5 rounded-xl px-3 py-1.5 sm:flex">
          <span className="text-xs text-slate-300">مرحله</span>
          <span className="font-display text-sm font-black text-violet-200">{hud.level}</span>
        </div>
        {hud.combo >= 2 && (
          <div
            key={`combo-${hud.combo}`}
            className="animate-pop-in flex items-center gap-1 rounded-xl bg-gradient-to-l from-amber-500/30 to-orange-500/20 px-2.5 py-1.5 ring-1 ring-amber-300/40"
          >
            <span className="text-sm">🔥</span>
            <span className="font-display text-sm font-black tabular-nums text-amber-200">
              {hud.combo}
            </span>
            {hud.multiplier > 1 && (
              <span className="rounded-md bg-amber-300/25 px-1 font-display text-[11px] font-black text-amber-100">
                ×{hud.multiplier}
              </span>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-2">
        <div className="glass flex items-center gap-1 rounded-xl px-2.5 py-1.5">
          {Array.from({ length: hud.maxHearts }).map((_, i) => (
            <span
              key={i}
              className={`text-base transition-all ${
                i < hud.hearts ? "" : "opacity-25 grayscale"
              }`}
              style={{ filter: i < hud.hearts ? "drop-shadow(0 0 6px #fb7185aa)" : undefined }}
            >
              ❤️
            </span>
          ))}
        </div>
        <button
          onClick={onPause}
          aria-label="توقف بازی"
          className="glass grid h-9 w-9 place-items-center rounded-xl text-base transition active:scale-90 active:bg-white/20"
        >
          ⏸
        </button>
      </div>
    </div>
  );
}

interface PromptCardProps {
  hud: HudState;
  mode: Mode;
  timer: { remaining: number; max: number };
  onSpeak: () => void;
}

export function PromptCard({ hud, mode, timer, onSpeak }: PromptCardProps) {
  const pct = timer.max > 0 ? Math.max(0, (timer.remaining / timer.max) * 100) : 0;
  const urgent = timer.remaining <= 3.2;
  return (
    <div className="mt-2 w-full px-3 sm:px-5">
      <div className="glass relative mx-auto w-full max-w-2xl overflow-hidden rounded-2xl px-4 py-2.5">
        <div className="text-[11px] font-medium text-slate-400">
          {mode === "meaning"
            ? "معنی فارسیِ این کلمه چیست؟"
            : mode === "type"
              ? "کلمهٔ انگلیسیِ این واژه را تایپ کن"
              : "این کلمه به انگلیسی یعنی چه؟"}
        </div>
        <div className="flex items-center justify-center gap-2">
          <span
            key={hud.prompt}
            className="animate-pop-in font-display text-2xl font-black tracking-tight text-white drop-shadow-[0_2px_10px_rgba(34,211,238,0.5)] sm:text-3xl"
            style={{ direction: hud.promptIsEnglish ? "ltr" : "rtl" }}
          >
            {hud.prompt}
          </span>
          <button
            onClick={onSpeak}
            aria-label="شنیدن تلفظ"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/10 text-sm transition active:scale-90 active:bg-cyan-400/40"
          >
            🔊
          </button>
        </div>

        {mode === "type" && hud.hintPattern && (
          <div className="mt-1 text-center font-display text-sm tracking-[0.3em] text-cyan-200/80">
            {hud.hintPattern}
          </div>
        )}

        <div className="mt-2 flex items-center gap-2">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full transition-[width] duration-100 ${
                urgent
                  ? "bg-gradient-to-l from-rose-500 to-rose-400"
                  : "bg-gradient-to-l from-emerald-400 to-cyan-300"
              }`}
              style={{ width: `${pct}%` }}
            />
          </div>
          <span className="shrink-0 font-display text-[10px] font-bold text-slate-400">
            {hud.mastered}/{hud.total} کلمه
          </span>
        </div>
      </div>
    </div>
  );
}

interface AnswerBarProps {
  hud: HudState;
  mode: Mode;
  onHint: () => void;
}

export function AnswerBar({ hud, mode, onHint }: AnswerBarProps) {
  if (mode !== "type") {
    return (
      <div className="flex w-full items-center justify-center gap-2 px-3 pb-2 sm:px-5">
        <button
          onClick={onHint}
          className="rounded-xl border border-amber-300/40 bg-amber-300/10 px-4 py-2 text-xs font-bold text-amber-200 transition active:scale-95 active:bg-amber-300/25"
        >
          💡 راهنما (−۲۰)
        </button>
      </div>
    );
  }
  return (
    <div className="w-full px-3 pb-1 sm:px-5">
      <div className="mx-auto flex w-full max-w-2xl items-center gap-2">
        <div className="flex h-11 flex-1 items-center gap-1 rounded-xl border border-white/10 bg-slate-900/70 px-3 font-display text-lg font-black tracking-[0.25em]">
          {hud.buffer.length === 0 ? (
            <span className="tracking-normal text-xs font-medium text-slate-500">
              کلمه را تایپ کن…
            </span>
          ) : (
            hud.buffer.split("").map((c, i) => (
              <span
                key={i}
                className="animate-pop-in text-cyan-200"
              >
                {c}
              </span>
            ))
          )}
        </div>
        <button
          onClick={onHint}
          className="h-11 shrink-0 rounded-xl border border-amber-300/40 bg-amber-300/10 px-3 text-xs font-bold text-amber-200 transition active:scale-95 active:bg-amber-300/25"
        >
          💡 −۲۰
        </button>
      </div>
    </div>
  );
}

interface FlashToastProps {
  flash: { word: Word; ok: boolean } | null;
}

export function FlashToast({ flash }: FlashToastProps) {
  if (!flash) return null;
  return (
    <div
      key={flash.word.id + String(flash.ok)}
      className="animate-float-up pointer-events-none absolute inset-x-2 bottom-2 z-20 mx-auto max-w-xl rounded-2xl border border-white/15 bg-slate-950/85 px-4 py-2.5 text-center shadow-2xl backdrop-blur-md"
      style={{ borderColor: flash.ok ? "rgba(163,230,53,0.45)" : "rgba(248,113,113,0.45)" }}
    >
      <div className="flex items-center justify-center gap-2">
        <span className="text-base">{flash.ok ? "✅" : "❌"}</span>
        <span className="font-display text-base font-black text-white" style={{ direction: "ltr" }}>
          {flash.word.en}
        </span>
        <span className="text-sm text-slate-300">{flash.word.fa}</span>
      </div>
      <div className="mt-0.5 text-[12px] text-slate-400" style={{ direction: "ltr" }}>
        {flash.word.sentence}
      </div>
      <div className="text-[12px] text-slate-500">{flash.word.sentenceFa}</div>
    </div>
  );
}
