import type { FighterHud, HudState } from "../game/types";
import { Joystick } from "./Joystick";
import { ActionButton } from "./ActionButton";
import {
  DodgeIcon,
  FlameIcon,
  HammerIcon,
  PauseIcon,
  ShieldIcon,
  SoundOffIcon,
  SoundOnIcon,
  SwordIcon,
} from "./icons";

const P1_COLOR = "#54e2ff";
const P2_COLOR = "#ff6a2a";

interface HudProps {
  hud: HudState;
  muted: boolean;
  controlsEnabled: boolean;
  onPause: () => void;
  onToggleMute: () => void;
  onMove: (player: 0 | 1, x: number, y: number) => void;
  onPress: (player: 0 | 1, action: "light" | "heavy" | "dodge" | "special") => void;
  onBlock: (player: 0 | 1, held: boolean) => void;
}

function RoundPips({ won, color, reverse }: { won: number; color: string; reverse?: boolean }) {
  return (
    <div className={`flex items-center gap-1 ${reverse ? "flex-row-reverse" : ""}`}>
      {[0, 1].map((i) => (
        <span
          key={i}
          className="block h-2 w-2 rotate-45 border"
          style={{
            borderColor: i < won ? color : "rgba(255,255,255,0.22)",
            background: i < won ? color : "transparent",
            boxShadow: i < won ? `0 0 8px ${color}` : "none",
          }}
        />
      ))}
    </div>
  );
}

function FighterPanel({ f, color, reverse }: { f: FighterHud; color: string; reverse?: boolean }) {
  const hp = Math.max(0, Math.min(100, (f.health / f.maxHealth) * 100));
  const en = Math.max(0, Math.min(100, f.energy));
  return (
    <div className={`min-w-0 flex-1 ${reverse ? "text-right" : "text-left"}`}>
      <div className={`flex items-center gap-2 ${reverse ? "flex-row-reverse" : ""}`}>
        <div className="min-w-0">
          <div className="flex items-baseline gap-1.5" style={{ flexDirection: reverse ? "row-reverse" : "row" }}>
            <span
              className="font-display truncate text-[13px] font-bold leading-none tracking-[0.14em] sm:text-base"
              style={{ color, textShadow: `0 0 14px ${color}66` }}
            >
              {f.name}
            </span>
            <span className="hidden truncate text-[8px] uppercase tracking-[0.18em] text-white/40 sm:inline">
              {f.epithet}
            </span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1.5" style={{ marginLeft: reverse ? 0 : "auto", marginRight: reverse ? "auto" : 0 }}>
          <RoundPips won={f.rounds} color={color} reverse={reverse} />
        </div>
      </div>

      <div className="relative mt-1 h-[9px] overflow-hidden border border-white/15 bg-black/70 sm:h-[11px]">
        <div
          className="absolute inset-y-0 bg-white/35"
          style={{
            width: `${hp}%`,
            [reverse ? "right" : "left"]: 0,
            transition: "width 0.65s ease 0.12s",
          }}
        />
        <div
          className="absolute inset-y-0"
          style={{
            width: `${hp}%`,
            [reverse ? "right" : "left"]: 0,
            background: `linear-gradient(180deg, ${color}, ${color}88 55%, ${color}55)`,
            boxShadow: `0 0 12px ${color}88`,
            transition: "width 0.12s linear",
          }}
        />
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              "repeating-linear-gradient(90deg, rgba(0,0,0,0.55) 0 1px, transparent 1px 12px)",
          }}
        />
      </div>

      <div className="mt-1 flex items-center gap-1.5" style={{ flexDirection: reverse ? "row-reverse" : "row" }}>
        <div className="relative h-[4px] flex-1 overflow-hidden bg-white/10">
          <div
            className="absolute inset-y-0"
            style={{
              width: `${en}%`,
              [reverse ? "right" : "left"]: 0,
              background: en >= 100 ? "#ffe6a8" : `${color}cc`,
              boxShadow: en >= 100 ? "0 0 10px #ffe6a8" : "none",
              transition: "width 0.18s linear",
            }}
          />
        </div>
        <span
          className="text-[7px] font-bold tracking-[0.16em]"
          style={{ color: en >= 100 ? "#ffe6a8" : "rgba(255,255,255,0.4)" }}
        >
          {en >= 100 ? "SPECIAL READY" : "ENERGY"}
        </span>
      </div>
    </div>
  );
}

export function Hud({
  hud,
  muted,
  controlsEnabled,
  onPause,
  onToggleMute,
  onMove,
  onPress,
  onBlock,
}: HudProps) {
  const [p1, p2] = hud.fighters;
  const timerColor = hud.timer <= 10 ? "#ff6a4a" : "#f5e6c4";
  const showMessage = !!hud.message;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between">
      {/* top gradient scrim */}
      <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/80 via-black/35 to-transparent" />

      {/* ── top HUD ─────────────────────────────────────────── */}
      <div className="relative z-10 px-2 pt-[max(6px,env(safe-area-inset-top))] pl-[max(8px,env(safe-area-inset-left))] pr-[max(8px,env(safe-area-inset-right))] sm:px-4">
        <div className="mx-auto flex max-w-5xl items-start gap-2 sm:gap-4">
          <FighterPanel f={p1} color={P1_COLOR} />
          <div className="flex w-[74px] shrink-0 flex-col items-center sm:w-[104px]">
            <div className="font-display text-[9px] font-bold tracking-[0.3em] text-gold/80">ROUND {hud.round}</div>
            <div
              className="font-display text-[26px] font-black leading-none tabular-nums sm:text-[34px]"
              style={{ color: timerColor, textShadow: "0 2px 18px rgba(0,0,0,0.9)" }}
            >
              {String(hud.timer).padStart(2, "0")}
            </div>
            <div className="mt-1 flex items-center gap-1">
              <button
                type="button"
                aria-label={muted ? "Unmute" : "Mute"}
                onClick={onToggleMute}
                className="pointer-events-auto grid h-6 w-6 place-items-center rounded border border-white/15 bg-black/50 text-white/70 active:scale-95"
              >
                {muted ? <SoundOffIcon className="h-3 w-3" /> : <SoundOnIcon className="h-3 w-3" />}
              </button>
              <button
                type="button"
                aria-label="Pause"
                onClick={onPause}
                className="pointer-events-auto grid h-6 w-6 place-items-center rounded border border-gold/30 bg-black/50 text-gold active:scale-95"
              >
                <PauseIcon className="h-3 w-3" />
              </button>
            </div>
          </div>
          <FighterPanel f={p2} color={P2_COLOR} reverse />
        </div>
      </div>

      {/* portrait hint */}
      <div className="portrait-hint pointer-events-none absolute inset-x-0 top-[68px] z-10 justify-center">
        <div className="mx-auto flex w-fit items-center gap-1.5 rounded-full border border-gold/25 bg-black/60 px-3 py-1 text-[8px] font-semibold uppercase tracking-[0.14em] text-gold/80 backdrop-blur-sm">
          <span className="text-[10px]">⟳</span> Rotate to landscape for a larger arena
        </div>
      </div>

      {/* ── center announcement ─────────────────────────────── */}
      <div className="pointer-events-none absolute inset-x-0 top-[24%] z-10 flex flex-col items-center px-4 text-center">
        {showMessage && (
          <div key={hud.messageKey} className="anim-slam">
            <div
              className="font-display text-[clamp(30px,8vw,64px)] font-black leading-none tracking-[0.08em]"
              style={{
                background: "linear-gradient(180deg,#fff8e2,#f0d79b 45%,#b8893c)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
                filter: "drop-shadow(0 4px 24px rgba(0,0,0,0.9)) drop-shadow(0 0 26px rgba(217,179,106,0.35))",
              }}
            >
              {hud.message}
            </div>
            {hud.sub && (
              <div className="mt-1 text-[9px] font-semibold uppercase tracking-[0.32em] text-white/60 sm:text-[11px]">
                {hud.sub}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── bottom controls ─────────────────────────────────── */}
      <div className="relative z-10 px-2 pb-[max(8px,env(safe-area-inset-bottom))] pl-[max(8px,env(safe-area-inset-left))] pr-[max(8px,env(safe-area-inset-right))] sm:px-5">
        <div className="mx-auto flex max-w-5xl items-end justify-between gap-2">
          {/* player 1 — always left */}
          <div className="flex items-end gap-1.5 sm:gap-2.5">
            <Joystick
              side="left"
              color={P1_COLOR}
              label="P1 · AETHER"
              disabled={!controlsEnabled}
              onChange={(x, y) => onMove(0, x, y)}
            />
            <div className="flex flex-col items-center gap-1">
              <button
                type="button"
                className="no-touch pointer-events-auto flex items-center gap-1 rounded-full border border-white/20 bg-black/55 px-2 py-[3px] text-[7px] font-bold tracking-[0.14em] text-white/70 active:scale-95"
                style={{ touchAction: "none", opacity: controlsEnabled ? 1 : 0.4 }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  if (!controlsEnabled) return;
                  e.currentTarget.setPointerCapture(e.pointerId);
                  onBlock(0, true);
                }}
                onPointerUp={() => onBlock(0, false)}
                onPointerCancel={() => onBlock(0, false)}
                onLostPointerCapture={() => onBlock(0, false)}
                onContextMenu={(e) => e.preventDefault()}
              >
                <ShieldIcon className="h-2.5 w-2.5" /> BLOCK
              </button>
              <div className="grid grid-cols-2 gap-1 sm:gap-1.5">
                <ActionButton
                  label="LIGHT"
                  icon={<SwordIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P1_COLOR}
                  cooldown={p1.cooldowns.light}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(0, "light")}
                />
                <ActionButton
                  label="HEAVY"
                  icon={<HammerIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P1_COLOR}
                  cooldown={p1.cooldowns.heavy}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(0, "heavy")}
                />
                <ActionButton
                  label="DODGE"
                  icon={<DodgeIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P1_COLOR}
                  cooldown={p1.cooldowns.dodge}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(0, "dodge")}
                />
                <ActionButton
                  label="SPECIAL"
                  icon={<FlameIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={p1.energy >= 100 ? "#ffe6a8" : P1_COLOR}
                  cooldown={p1.cooldowns.special}
                  ready={p1.energy >= 100}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(0, "special")}
                />
              </div>
            </div>
          </div>

          {/* player 2 — always right */}
          <div className="flex items-end gap-1.5 sm:gap-2.5">
            <div className="flex flex-col items-center gap-1">
              <button
                type="button"
                className="no-touch pointer-events-auto flex items-center gap-1 rounded-full border border-white/20 bg-black/55 px-2 py-[3px] text-[7px] font-bold tracking-[0.14em] text-white/70 active:scale-95"
                style={{ touchAction: "none", opacity: controlsEnabled ? 1 : 0.4 }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  if (!controlsEnabled) return;
                  e.currentTarget.setPointerCapture(e.pointerId);
                  onBlock(1, true);
                }}
                onPointerUp={() => onBlock(1, false)}
                onPointerCancel={() => onBlock(1, false)}
                onLostPointerCapture={() => onBlock(1, false)}
                onContextMenu={(e) => e.preventDefault()}
              >
                <ShieldIcon className="h-2.5 w-2.5" /> BLOCK
              </button>
              <div className="grid grid-cols-2 gap-1 sm:gap-1.5">
                <ActionButton
                  label="LIGHT"
                  icon={<SwordIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P2_COLOR}
                  cooldown={p2.cooldowns.light}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(1, "light")}
                />
                <ActionButton
                  label="HEAVY"
                  icon={<HammerIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P2_COLOR}
                  cooldown={p2.cooldowns.heavy}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(1, "heavy")}
                />
                <ActionButton
                  label="DODGE"
                  icon={<DodgeIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={P2_COLOR}
                  cooldown={p2.cooldowns.dodge}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(1, "dodge")}
                />
                <ActionButton
                  label="SPECIAL"
                  icon={<FlameIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
                  color={p2.energy >= 100 ? "#ffe6a8" : P2_COLOR}
                  cooldown={p2.cooldowns.special}
                  ready={p2.energy >= 100}
                  disabled={!controlsEnabled}
                  onPress={() => onPress(1, "special")}
                />
              </div>
            </div>
            <Joystick
              side="right"
              color={P2_COLOR}
              label="P2 · INFERNO"
              disabled={!controlsEnabled}
              onChange={(x, y) => onMove(1, x, y)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
