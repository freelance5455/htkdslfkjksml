import { useEffect, useState } from "react";
import { useGame } from "../game/store";
import { faNumber, toFa } from "../utils/fa";

const RADIUS = 52;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
const MAX_KMH = 300;

export default function Hud() {
  const g = useGame();
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!g.toast) return;
    setToast(g.toast.text);
    const timer = window.setTimeout(() => setToast(null), 1500);
    return () => window.clearTimeout(timer);
  }, [g.toast]);

  const visible =
    g.phase === "playing" || g.phase === "countdown" || g.phase === "crashed";
  if (!visible) return null;

  const ratio = Math.min(1, g.speed / MAX_KMH);
  const offset = CIRCUMFERENCE * (1 - ratio);

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      {/* speed / boost vignette */}
      <div
        className="absolute inset-0 transition-opacity duration-200"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 38%, rgba(126,34,206,0.6) 100%)",
          opacity: g.boosting
            ? 0.85
            : Math.min(0.7, Math.max(0, (g.speed - 110) / 240)),
        }}
      />

      {/* score panel */}
      <div className="absolute top-4 right-4 rounded-2xl border border-white/10 bg-slate-900/50 px-5 py-3 backdrop-blur-md">
        <div className="text-[11px] tracking-widest text-cyan-300/70">امتیاز</div>
        <div className="font-mono text-3xl font-bold text-white tabular-nums drop-shadow-[0_0_14px_rgba(79,227,255,0.75)]">
          {faNumber(g.score)}
        </div>
        <div className="mt-1 text-[11px] text-white/55">
          بهترین: <span className="text-amber-300">{faNumber(g.best)}</span>
        </div>
      </div>

      {/* speed panel */}
      <div className="absolute top-4 left-4 flex flex-col items-center gap-2 rounded-2xl border border-white/10 bg-slate-900/50 px-4 py-3 backdrop-blur-md">
        <div className="relative h-28 w-28">
          <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
            <defs>
              <linearGradient id="speedGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#4fe3ff" />
                <stop offset="60%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#ff4d6d" />
              </linearGradient>
            </defs>
            <circle
              cx="60"
              cy="60"
              r={RADIUS}
              fill="none"
              stroke="rgba(255,255,255,0.1)"
              strokeWidth="9"
            />
            <circle
              cx="60"
              cy="60"
              r={RADIUS}
              fill="none"
              stroke="url(#speedGrad)"
              strokeWidth="9"
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 120ms linear" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-mono text-3xl font-bold tabular-nums text-white">
              {faNumber(g.speed)}
            </span>
            <span className="text-[10px] tracking-widest text-white/50">
              کیلومتر/ساعت
            </span>
          </div>
        </div>

        {/* nitro */}
        <div className="w-full">
          <div className="mb-1 flex items-center justify-between text-[10px] text-white/55">
            <span>نیترو</span>
            <span className={g.boosting ? "text-cyan-300" : "text-white/55"}>
              {toFa(g.nitro)}٪
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full transition-[width] duration-100 ${
                g.boosting
                  ? "bg-gradient-to-l from-cyan-300 to-fuchsia-400 shadow-[0_0_12px_rgba(79,227,255,0.9)]"
                  : "bg-gradient-to-l from-cyan-400/80 to-blue-500/80"
              }`}
              style={{ width: `${g.nitro}%` }}
            />
          </div>
        </div>
      </div>

      {/* bottom stats */}
      <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-3">
        <div className="rounded-xl border border-white/10 bg-slate-900/50 px-4 py-2 text-center backdrop-blur-md">
          <div className="text-[10px] tracking-widest text-white/45">مسافت</div>
          <div className="font-mono text-lg font-bold text-white tabular-nums">
            {faNumber(g.distance)}
            <span className="mr-1 text-[10px] font-normal text-white/50">متر</span>
          </div>
        </div>
        <div className="rounded-xl border border-white/10 bg-slate-900/50 px-4 py-2 text-center backdrop-blur-md">
          <div className="text-[10px] tracking-widest text-white/45">سلول انرژی</div>
          <div className="font-mono text-lg font-bold text-cyan-300 tabular-nums">
            {faNumber(g.pickups)}
          </div>
        </div>
        <div className="rounded-xl border border-white/10 bg-slate-900/50 px-4 py-2 text-center backdrop-blur-md">
          <div className="text-[10px] tracking-widest text-white/45">
            {g.boosting ? "نیترو فعال" : "شتاب"}
          </div>
          <div
            className={`font-mono text-lg font-bold tabular-nums ${
              g.boosting ? "text-fuchsia-300" : "text-white"
            }`}
          >
            {g.boosting ? "BOOST" : "—"}
          </div>
        </div>
      </div>

      {/* toast */}
      {toast && (
        <div className="animate-pop absolute top-28 left-1/2 -translate-x-1/2 rounded-full border border-cyan-300/40 bg-slate-950/70 px-5 py-2 text-sm font-medium text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.35)] backdrop-blur-md">
          {toast}
        </div>
      )}

      {/* countdown */}
      {g.phase === "countdown" && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            key={g.countdown}
            className="animate-pop text-[120px] font-black leading-none text-white drop-shadow-[0_0_40px_rgba(79,227,255,0.9)]"
          >
            {toFa(g.countdown)}
          </div>
        </div>
      )}
    </div>
  );
}
