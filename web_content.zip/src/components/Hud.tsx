import { STAT_ICONS, STAT_LABELS, type GameState, type StatKey } from "../game/types";
import { AREA_NAME } from "../game/engine";
import { missionById } from "../game/data/missions";
import { Portrait } from "./Portrait";

const STAT_COLOR: Record<StatKey, string> = {
  influence: "#c79ae8",
  reputation: "#e8c06a",
  intelligence: "#7fc4e8",
  wealth: "#7fd0a0",
  power: "#e07a6a",
};

const ORDER: StatKey[] = ["influence", "reputation", "intelligence", "wealth", "power"];

export function Hud({
  state,
  objective,
  onOpen,
  onInteract,
  nearNpc,
  muted,
  onToggleMute,
}: {
  state: GameState;
  objective: string;
  onOpen: (p: "inventory" | "relations" | "journal" | "map") => void;
  onInteract: () => void;
  nearNpc: string | null;
  muted: boolean;
  onToggleMute: () => void;
}) {
  const mission = state.currentMission !== null ? missionById(state.currentMission) : null;
  const progress = state.completedMissions.length;

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      {/* top left: character */}
      <div className="absolute left-2 top-2 flex gap-2 sm:left-3 sm:top-3" style={{ paddingTop: "env(safe-area-inset-top)" }}>
        <div className="panel pointer-events-auto flex items-stretch gap-2 px-2 py-1.5">
          <Portrait palette={{ skin: "#e0ac79", hair: "#3b2a1a", cloth: "#2f3b58", accent: "#c9a45a" }} size={48} />
          <div className="flex min-w-[118px] flex-col justify-center gap-0.5 sm:min-w-[150px]">
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate text-[13px] font-semibold tracking-wide text-[#f7e3a8]">
                {state.playerName || "Sem Nome"}
              </span>
              <span className="mono text-[11px] text-[#e8c06a]">{state.score} pts</span>
            </div>
            <div className="grid grid-cols-5 gap-1">
              {ORDER.map((k) => (
                <div key={k} className="flex flex-col items-center gap-0.5" title={STAT_LABELS[k]}>
                  <span className="text-[10px] leading-none" style={{ color: STAT_COLOR[k] }}>
                    {STAT_ICONS[k]}
                  </span>
                  <div className="stat-bar w-full">
                    <div
                      className="stat-fill"
                      style={{
                        width: `${Math.min(100, (state.stats[k] / 100) * 100)}%`,
                        background: STAT_COLOR[k],
                      }}
                    />
                  </div>
                  <span className="mono text-[9px] leading-none text-[#9d8fb0]">{state.stats[k]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* top right: area + progress */}
      <div className="absolute right-2 top-2 flex flex-col items-end gap-1.5 sm:right-3 sm:top-3">
        <div className="panel pointer-events-auto px-3 py-1.5 text-right">
          <div className="panel-title">{AREA_NAME[state.player.areaId] ?? state.player.areaId}</div>
          <div className="mono hidden text-[10px] text-[#9d8fb0] sm:block">
            Leis dominadas {progress}/48 · <span className="text-[#e8c06a]">{state.knownLaws.length}</span> sabedorias
          </div>
        </div>
        <div className="flex gap-1">
          {(
            [
              ["inventory", "I", "Inventário"],
              ["relations", "R", "Relações"],
              ["journal", "J", "Diário das Leis"],
              ["map", "M", "Mapa do Reino"],
            ] as const
          ).map(([id, key, label]) => (
            <button
              key={id}
              className="btn pointer-events-auto px-1.5 py-1 text-[10px] sm:px-2 sm:text-[11px]"
              title={`${label} (${key})`}
              onClick={() => onOpen(id)}
            >
              {key}
            </button>
          ))}
          <button
            className="btn pointer-events-auto px-1.5 py-1 text-[10px] sm:px-2 sm:text-[11px]"
            onClick={onToggleMute}
            title={muted ? "Som desligado" : "Som ligado"}
          >
            {muted ? "MUD" : "SOM"}
          </button>
        </div>
      </div>

      {/* objective */}
      <div className="absolute left-1/2 top-[92px] w-[min(94vw,460px)] -translate-x-1/2 sm:top-3">
        <div className="panel pointer-events-auto sweep relative overflow-hidden px-3 py-1.5 text-center">
          <div className="panel-title">
            {mission ? `Lei ${mission.id} / 48 — ${mission.lawTitle}` : "Todas as 48 leis dominadas"}
          </div>
          <div className="truncate text-[12px] text-[#ecdcb8]">
            {mission ? (
              <>
                <span className="gold font-semibold">{mission.title}:</span> {objective}
              </>
            ) : (
              "O reino espera o seu próximo movimento."
            )}
          </div>
        </div>
      </div>

      {/* interact prompt */}
      {nearNpc && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 sm:bottom-6">
          <button
            className="btn btn-primary pointer-events-auto animate-pulse px-4 py-2 text-[13px]"
            onClick={onInteract}
          >
            [E] Conversar com {nearNpc}
          </button>
        </div>
      )}
    </div>
  );
}
