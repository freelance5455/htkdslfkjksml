import { useMemo } from "react";
import { formatTime, mapById, MISSION, SPECIES, WAVES, type Loadout, type MapId, type SpeciesKey, type TouchLayout } from "@/data";
import type { TargetInfo } from "@/game/world";
import TouchControls from "@/components/TouchControls";
import {
  AnimalMark,
  ClockIcon,
  CrosshairIcon,
  MutedIcon,
  PauseIcon,
  ReloadIcon,
  RifleIcon,
  ScopeIcon,
  SoundIcon,
  TargetIcon,
  WindIcon,
} from "@/components/Icons";

export interface HudToast {
  id: number;
  title: string;
  subtitle: string;
  tone: "success" | "info" | "empty";
}

export interface WaveNotice {
  id: number;
  title: string;
  subtitle: string;
  tone: "wave" | "cleared" | "final";
}

interface Props {
  loadout: Loadout;
  timeLeft: number;
  ammo: number;
  reserve: number;
  reloading: boolean;
  aiming: boolean;
  target: TargetInfo | null;
  heading: number;
  spotted: SpeciesKey[];
  bag: Partial<Record<SpeciesKey, number>>;
  harvested: number;
  score: number;
  shots: number;
  hits: number;
  toast: HudToast | null;
  hitMarker: number;
  muted: boolean;
  infiniteAmmo: boolean;
  waveIndex: number;
  waveTimeLeft: number;
  waveHarvested: number;
  wavesCleared: number;
  waveNotice: WaveNotice | null;
  controlsLayout: TouchLayout;
  mapId: MapId;
  onPause: () => void;
  onFire: () => void;
  onReload: () => void;
  onToggleAim: () => void;
  onToggleMute: () => void;
  onOpenGuide: () => void;
  onMoveAxes: (x: number, y: number) => void;
}

const CARDINALS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];

function Compass({ heading }: { heading: number }) {
  const deg = ((heading % 360) + 360) % 360;
  const rounded = Math.round(deg);
  const cardinal = CARDINALS[Math.round(deg / 45) % 8];
  const ticks = useMemo(() => {
    const base = Math.round(deg / 5) * 5;
    return Array.from({ length: 25 }, (_, index) => {
      const value = base + (index - 12) * 5;
      const normalized = ((value % 360) + 360) % 360;
      const offset = value - deg;
      return { value, normalized, offset };
    });
  }, [deg]);

  return (
    <div className="flex w-[276px] flex-col items-center">
      <div className="relative h-11 w-full overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-bark-950/50 to-transparent" />
        {ticks.map((tick) => {
          const major = tick.normalized % 45 === 0;
          const label = CARDINALS[Math.round(tick.normalized / 45) % 8];
          const left = 50 + (tick.offset / 120) * 100;
          if (left < 0 || left > 100) return null;
          return (
            <div key={`${tick.value}`} className="absolute top-0 -translate-x-1/2" style={{ left: `${left}%` }}>
              <span className={`mx-auto block w-px ${major ? "h-2.5 bg-sand-200" : "h-1.5 bg-sand-300/40"}`} />
              {major && (
                <span className={`mt-1 block font-condensed text-[0.55rem] uppercase tracking-[0.14em] ${label === "N" ? "text-brass-300" : "text-sand-300/75"}`}>
                  {label}
                </span>
              )}
            </div>
          );
        })}
        <span className="absolute left-1/2 top-0 h-3 w-px -translate-x-1/2 bg-brass-300" />
        <span className="absolute left-1/2 top-3 h-1.5 w-1.5 -translate-x-1/2 rotate-45 border-b border-r border-brass-300" />
      </div>
      <div className="mt-0.5 flex items-baseline gap-2">
        <span className="font-condensed text-xl leading-none tracking-[0.14em] text-sand-100">{cardinal}</span>
        <span className="num text-[0.68rem] tracking-[0.12em] text-brass-300">{String(rounded).padStart(3, "0")}°</span>
      </div>
      <span className="eyebrow mt-1 text-[0.44rem] text-sand-400">Heading · true north</span>
    </div>
  );
}

function ScopeOverlay({ target, wind }: { target: TargetInfo | null; wind: string }) {
  const lens = "min(62vw, 74vh)";
  return (
    <div className="pointer-events-none absolute inset-0 z-10 animate-scope">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(5,9,6,0) 0%, rgba(5,9,6,0) calc(min(31vw, 37vh) - 2px), rgba(4,8,5,0.58) calc(min(31vw, 37vh)), rgba(3,6,4,0.97) calc(min(31vw, 37vh) + 1px))",
        }}
      />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ width: lens, height: lens }}>
        <div className="absolute inset-0 rounded-full border border-black/80 shadow-[inset_0_0_40px_rgba(0,0,0,0.55)]" />
        <div className="absolute inset-[3px] rounded-full border border-sand-200/20" />
        <div className="absolute inset-0 rounded-full border border-brass-300/10" />
        <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-sand-200/25" />
        <span className="absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-sand-200/25" />
        <span className="absolute left-1/2 top-1/2 h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass-300" />
        {[-120, -80, -40, 40, 80, 120].map((offset) => (
          <span
            key={`v${offset}`}
            className="absolute left-1/2 h-[5px] w-px -translate-x-1/2 bg-sand-200/45"
            style={{ top: `calc(50% + ${offset}px)` }}
          />
        ))}
        {[-120, -80, -40, 40, 80, 120].map((offset) => (
          <span
            key={`h${offset}`}
            className="absolute top-1/2 h-px w-[5px] -translate-y-1/2 bg-sand-200/45"
            style={{ left: `calc(50% + ${offset}px)` }}
          />
        ))}
        <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 text-center">
          <p className="num text-[0.6rem] tracking-[0.22em] text-brass-300/90">
            {target ? `${target.distance} M · ${target.name.toUpperCase()}` : `STANDBY · WIND ${wind.toUpperCase()}`}
          </p>
        </div>
        <span className="absolute left-1/2 top-[calc(50%+150px)] -translate-x-1/2 font-condensed text-[0.5rem] uppercase tracking-[0.28em] text-sand-300/40">
          Ridgeline optics · 4×
        </span>
      </div>
    </div>
  );
}

export default function Hud({
  loadout,
  timeLeft,
  ammo,
  reserve,
  reloading,
  aiming,
  target,
  heading,
  spotted,
  bag,
  harvested,
  score,
  shots,
  hits,
  toast,
  hitMarker,
  muted,
  infiniteAmmo,
  onPause,
  onFire,
  onReload,
  onToggleAim,
  onToggleMute,
  onOpenGuide,
  waveIndex,
  waveTimeLeft,
  waveHarvested,
  wavesCleared,
  waveNotice,
  controlsLayout,
  mapId,
  onMoveAxes,
}: Props) {
  const ground = mapById(mapId);
  const accuracy = shots > 0 ? Math.round((hits / shots) * 100) : 0;
  const urgent = timeLeft <= 45;
  const wave = WAVES[Math.min(waveIndex, WAVES.length - 1)];
  const progress = wave.quota > 0 ? Math.min(1, waveHarvested / wave.quota) : 0;
  const pips = Array.from({ length: loadout.magazine });
  const ringLength = 2 * Math.PI * 17;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none font-sans">
      {aiming && <ScopeOverlay target={target} wind={ground.wind} />}

      <div className="absolute inset-x-0 top-0 h-36 bg-gradient-to-b from-bark-950/80 via-bark-950/35 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-bark-950/85 via-bark-950/35 to-transparent" />

      {/* top left */}
      <div className="pt-safe absolute left-0 top-0 flex items-start gap-3 px-4 pb-4 md:px-5 md:pb-5">
        <button
          onClick={onPause}
          aria-label="Pause hunt"
          className="pointer-events-auto flex h-10 w-10 shrink-0 items-center justify-center rounded-sm border border-sand-100/20 bg-bark-950/55 text-sand-200 backdrop-blur-md transition hover:border-brass-300/50 hover:text-brass-300"
        >
          <PauseIcon size={16} />
        </button>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="eyebrow text-[0.5rem] text-brass-300">Drive {waveIndex + 1} / {WAVES.length}</span>
            <span className="hidden h-px w-6 bg-brass-300/40 sm:block" />
            <span className="eyebrow hidden text-[0.48rem] text-sand-400 sm:block">{wave.name}</span>
          </div>
          <h1 className="mt-1 font-serif text-[1.4rem] leading-none text-sand-100 sm:text-[1.7rem]">{MISSION.name}</h1>
          <div className="mt-2.5 flex items-center gap-2.5">
            <div className="h-[3px] w-24 overflow-hidden rounded-full bg-sand-100/15 sm:w-32">
              <div className="h-full rounded-full bg-brass-300 transition-all duration-500" style={{ width: `${progress * 100}%` }} />
            </div>
            <span className="num text-[0.7rem] tracking-[0.1em] text-sand-200">
              {Math.min(waveHarvested, wave.quota)}<span className="text-sand-400">/{wave.quota}</span>
            </span>
            <span className="eyebrow hidden text-[0.44rem] text-sand-400 md:block">Drive quota</span>
            <span className="h-2.5 w-px bg-sand-100/20" />
            <span className="num text-[0.64rem] text-sand-300">{harvested}<span className="text-sand-400/70"> total</span></span>
          </div>
          <div className="mt-2 flex items-center gap-1">
            {WAVES.map((item, index) => (
              <span
                key={item.id}
                title={item.name}
                className={`h-1 w-5 rounded-full transition-colors ${
                  index < waveIndex ? "bg-brass-300/80" : index === waveIndex ? "bg-brass-300" : "bg-sand-100/18"
                } ${index === waveIndex && waveHarvested >= wave.quota ? "animate-pulse-soft" : ""}`}
              />
            ))}
            <span className="ml-1 eyebrow hidden text-[0.4rem] text-sand-400/80 lg:block">{wavesCleared} cleared</span>
          </div>
        </div>
      </div>

      {/* compass */}
      <div className="absolute left-1/2 top-4 hidden -translate-x-1/2 lg:block">
        <Compass heading={heading} />
        <div className="mt-1 flex items-center justify-center gap-3">
          <span className="flex items-center gap-1.5">
            <WindIcon size={11} className="text-brass-300/80" />
            <span className="eyebrow text-[0.44rem] text-sand-300/70">{ground.wind}</span>
          </span>
          <span className="h-2 w-px bg-sand-100/20" />
          <span className="flex items-center gap-1.5">
            <span className={`h-1 w-1 rounded-full ${spotted.length > 0 ? "bg-brass-300" : "bg-sand-400/60"}`} />
            <span className="eyebrow text-[0.44rem] text-sand-300/70">{spotted.length > 0 ? `${spotted.length} species in sight` : "Scanning"}</span>
          </span>
        </div>
      </div>

      {/* top right */}
      <div className="pt-safe absolute right-0 top-0 hidden flex-col items-end gap-2 px-4 pb-4 sm:flex md:px-5 md:pb-5">
        <div className="hud-panel flex items-center gap-3 rounded-sm py-2 pl-3 pr-3.5">
          <div className="relative flex h-10 w-10 items-center justify-center">
            <svg viewBox="0 0 40 40" className="-rotate-90">
              <circle cx="20" cy="20" r="17" fill="none" stroke="rgba(244,238,226,0.14)" strokeWidth="2" />
              <circle
                cx="20"
                cy="20"
                r="17"
                fill="none"
                stroke={urgent ? "#d28b62" : "#e9c88e"}
                strokeWidth="2"
                strokeLinecap="round"
                strokeDasharray={ringLength}
                strokeDashoffset={ringLength * (1 - Math.max(0, timeLeft) / MISSION.time)}
                className="transition-all duration-1000"
              />
            </svg>
            <ClockIcon size={13} className={`absolute ${urgent ? "text-clay-500" : "text-sand-300"}`} />
          </div>
          <div>
            <p className={`num text-xl leading-none tracking-[0.06em] ${urgent ? "text-clay-500" : "text-sand-100"}`}>{formatTime(timeLeft)}</p>
            <p className="eyebrow mt-1 text-[0.44rem] text-sand-400">Until last light</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5 rounded-sm border border-sand-100/12 bg-bark-950/45 px-3 py-1.5 backdrop-blur-md">
          <span className="num text-sm text-brass-300">{score.toLocaleString()}</span>
          <span className="eyebrow text-[0.44rem] text-sand-400">pts</span>
          <span className="h-2.5 w-px bg-sand-100/20" />
          <span className="num text-[0.68rem] text-sand-300">{accuracy}% acc</span>
          <span className="h-2.5 w-px bg-sand-100/20" />
          <span className="num text-[0.68rem] text-sand-300">{harvested} taken</span>
        </div>
        <div className={`flex items-center gap-2 rounded-sm border px-3 py-1.5 backdrop-blur-md ${waveTimeLeft <= 10 ? "border-clay-500/40 bg-bark-950/60" : "border-brass-300/22 bg-bark-950/45"}`}>
          <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-brass-300" />
          <span className="eyebrow text-[0.42rem] text-sand-300/80">Drive ends</span>
              <span className={`num text-[0.72rem] ${waveTimeLeft <= 10 ? "text-clay-500" : "text-sand-100"}`}>{formatTime(waveTimeLeft)}</span>
              {infiniteAmmo && <span className="eyebrow text-[0.4rem] text-brass-300">· ∞ ammo</span>}
          {waveHarvested >= wave.quota && <span className="eyebrow text-[0.4rem] text-brass-300">· quota met</span>}
        </div>
      </div>

      {/* drive announcement */}
      {waveNotice && (
        <div key={waveNotice.id} className="absolute left-1/2 top-[124px] z-30 w-[min(88vw,380px)] -translate-x-1/2 animate-enter md:top-[130px]">
          <div className="overflow-hidden rounded-sm border border-brass-300/30 bg-bark-900/90 shadow-[0_18px_60px_-16px_rgba(0,0,0,0.85)] backdrop-blur-xl">
            <div className="flex items-center justify-between gap-2 border-b border-sand-100/10 px-3.5 py-1.5">
              <span className="flex items-center gap-1.5">
                <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />
                <span className="eyebrow text-[0.44rem] text-brass-300">
                  {waveNotice.tone === "cleared" ? "Drive cleared" : waveNotice.tone === "final" ? "Drives complete" : "The herd moves"}
                </span>
              </span>
              <span className="num text-[0.55rem] text-sand-300/80">Drive {Math.min(waveIndex + 1, WAVES.length)} / {WAVES.length}</span>
            </div>
            <div className="px-3.5 py-2.5">
              <p className="font-serif text-[1.3rem] leading-none text-sand-100">{waveNotice.title}</p>
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <p className="text-[0.64rem] leading-snug text-sand-300/80">{waveNotice.subtitle}</p>
                {waveNotice.tone === "wave" && (
                  <span className="shrink-0 rounded-sm border border-brass-300/25 bg-brass-300/8 px-2 py-1">
                    <span className="eyebrow text-[0.4rem] text-brass-300">Quota {wave.quota}</span>
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div key={toast.id} className="absolute left-1/2 top-[132px] z-30 -translate-x-1/2 animate-toast md:top-[116px]">
          <div
            className={`flex items-center gap-3 rounded-sm border px-4 py-2.5 backdrop-blur-xl ${
              toast.tone === "success"
                ? "border-brass-300/40 bg-bark-900/88 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.8)]"
                : toast.tone === "empty"
                  ? "border-clay-500/40 bg-bark-900/88"
                  : "border-sand-100/20 bg-bark-900/85"
            }`}
          >
            <span className={`flex h-7 w-7 items-center justify-center rounded-full ${toast.tone === "success" ? "bg-brass-300/15 text-brass-300" : "bg-clay-500/15 text-clay-500"}`}>
              {toast.tone === "success" ? <TargetIcon size={14} /> : <ReloadIcon size={14} />}
            </span>
            <div>
              <p className="font-condensed text-[0.82rem] uppercase tracking-[0.14em] text-sand-100">{toast.title}</p>
              <p className="eyebrow mt-0.5 text-[0.46rem] text-sand-400">{toast.subtitle}</p>
            </div>
          </div>
        </div>
      )}

      {/* species tracker */}
      <aside className="absolute right-4 top-[196px] hidden w-[204px] xl:block">
        <div className="hud-panel rounded-sm p-3">
          <div className="flex items-center justify-between">
            <span className="eyebrow text-[0.48rem] text-brass-300">{ground.name}</span>
            <span className="flex items-center gap-1">
              <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />
              <span className="eyebrow text-[0.4rem] text-sand-400">Live</span>
            </span>
          </div>
          <div className="mt-2 space-y-px">
            {SPECIES.map((species) => {
              const count = bag[species.key] ?? 0;
              const seen = spotted.includes(species.key);
              return (
                <div key={species.key} className="flex items-center gap-2 rounded-sm px-1 py-1.5 transition hover:bg-sand-100/5">
                  <span className={`shrink-0 ${seen ? "text-brass-300" : "text-sand-300/55"}`}>
                    <AnimalMark species={species.key} size={22} />
                  </span>
                  <span className={`flex-1 truncate font-condensed text-[0.66rem] uppercase tracking-[0.06em] ${seen ? "text-sand-100" : "text-sand-300/65"}`}>
                    {species.name}
                  </span>
                  {seen && <span className="h-1 w-1 shrink-0 rounded-full bg-brass-300" />}
                  <span className={`num w-5 text-right text-[0.68rem] ${count > 0 ? "text-brass-300" : "text-sand-400/50"}`}>{count > 0 ? count : "—"}</span>
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-sand-100/10 pt-2">
            <span className="eyebrow text-[0.42rem] text-sand-400">Range</span>
            <span className="num text-[0.62rem] text-sand-200">{target ? `${target.distance} m` : "—"}</span>
          </div>
        </div>
      </aside>

      {/* target reticle */}
        <div className="absolute left-1/2 top-[calc(50%-14px)] z-30 -translate-x-1/2 -translate-y-1/2 md:top-1/2">
        {!aiming && (
          <div className={`relative transition-all duration-200 ${target ? "scale-110" : "scale-100"}`}>
            <span className="absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-sand-100 shadow-[0_0_4px_rgba(0,0,0,0.8)]" />
            {[
              "left-1/2 top-0 -translate-x-1/2 h-2 w-px",
              "left-1/2 bottom-0 -translate-x-1/2 h-2 w-px",
              "top-1/2 left-0 -translate-y-1/2 w-2 h-px",
              "top-1/2 right-0 -translate-y-1/2 w-2 h-px",
            ].map((position) => (
              <span
                key={position}
                className={`absolute ${position} ${target ? "bg-brass-300" : "bg-sand-100/80"}`}
                style={{ margin: 0 }}
              />
            ))}
            {target && (
              <>
                <span className="absolute -left-6 -top-6 h-4 w-4 border-l border-t border-brass-300/80" />
                <span className="absolute -right-6 -top-6 h-4 w-4 border-r border-t border-brass-300/80" />
                <span className="absolute -bottom-6 -left-6 h-4 w-4 border-b border-l border-brass-300/80" />
                <span className="absolute -bottom-6 -right-6 h-4 w-4 border-b border-r border-brass-300/80" />
                <div className="absolute left-1/2 top-7 w-48 -translate-x-1/2 text-center">
                  <p className="font-condensed text-[0.66rem] uppercase tracking-[0.18em] text-brass-300">{target.name}</p>
                  <p className="num mt-0.5 text-[0.6rem] tracking-[0.12em] text-sand-100/90">
                    {target.distance} M {target.headshot && <span className="text-brass-300">· VITAL</span>}
                  </p>
                </div>
              </>
            )}
          </div>
        )}
        {hitMarker > 0 && (
          <div key={hitMarker} className="absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2 animate-hit">
            <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 rotate-45 bg-brass-300" />
            <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 -rotate-45 bg-brass-300" />
          </div>
        )}
      </div>

      {/* status prompt */}
      <div className="absolute bottom-[104px] left-1/2 z-20 hidden -translate-x-1/2 lg:block">
        <div className={`flex items-center gap-2 rounded-full border px-3.5 py-1.5 backdrop-blur-md ${reloading ? "border-brass-300/35 bg-bark-950/70" : "border-sand-100/12 bg-bark-950/45"}`}>
          {reloading ? (
            <>
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brass-300" />
              <span className="eyebrow text-[0.48rem] text-brass-300">Reloading · hold steady</span>
            </>
          ) : ammo === 0 && !infiniteAmmo ? (
            <>
              <span className="h-1.5 w-1.5 rounded-full bg-clay-500" />
              <span className="eyebrow text-[0.48rem] text-clay-500">Magazine empty · press R to reload</span>
            </>
          ) : (
            <>
              <CrosshairIcon size={12} className="text-brass-300/80" />
              <span className="eyebrow text-[0.46rem] text-sand-300/70">
                Drag to track · {aiming ? "scope steady" : "shift or right-click to steady"}
              </span>
            </>
          )}
        </div>
      </div>

      {/* bottom left controls */}
      <div className="absolute bottom-5 left-4 z-20 hidden md:block">
        <div className="flex items-end gap-3">
          <div className="hud-panel rounded-sm px-3 py-2.5">
            <div className="flex items-center gap-2">
              <WindIcon size={13} className="text-brass-300/80" />
              <span className="eyebrow text-[0.44rem] text-sand-300/70">Wind {ground.wind}</span>
            </div>
            <div className="mt-2 flex items-center gap-1.5">
              {["W", "A", "S", "D"].map((key) => (
                <kbd key={key} className="flex h-5 min-w-5 items-center justify-center rounded-[2px] border border-sand-100/20 bg-bark-950/50 px-1 font-condensed text-[0.55rem] uppercase text-sand-200">
                  {key}
                </kbd>
              ))}
              <span className="ml-1 eyebrow text-[0.4rem] text-sand-400">Move</span>
            </div>
          </div>
          <div className="pointer-events-auto flex flex-col gap-1.5">
            <button
              onClick={onOpenGuide}
              className="flex h-8 w-8 items-center justify-center rounded-sm border border-sand-100/14 bg-bark-950/50 text-sand-300 backdrop-blur-md transition hover:border-brass-300/40 hover:text-brass-300"
              aria-label="Open field guide"
            >
              <AnimalMark species="deer" size={19} />
            </button>
            <button
              onClick={onToggleMute}
              aria-label={muted ? "Unmute sound" : "Mute sound"}
              className="flex h-8 w-8 items-center justify-center rounded-sm border border-sand-100/14 bg-bark-950/50 text-sand-300 backdrop-blur-md transition hover:border-brass-300/40 hover:text-brass-300"
            >
              {muted ? <MutedIcon size={14} /> : <SoundIcon size={14} />}
            </button>
          </div>
        </div>
      </div>

      {/* weapon panel desktop */}
      <div className="pointer-events-auto absolute bottom-5 right-4 z-20 hidden w-[282px] md:block">
        <div className="hud-panel overflow-hidden rounded-sm">
          <div className="flex items-center justify-between gap-2 border-b border-sand-100/10 px-3.5 py-2.5">
            <div className="flex min-w-0 items-center gap-2">
              <RifleIcon size={17} className="shrink-0 text-brass-300" />
              <span className="truncate font-condensed text-[0.76rem] uppercase tracking-[0.1em] text-sand-100">{loadout.name}</span>
            </div>
            <span className="num shrink-0 text-[0.58rem] tracking-[0.1em] text-sand-400">{loadout.calibre}</span>
          </div>
          <div className="flex items-stretch">
            <div className="flex flex-1 items-center gap-3 px-3.5 py-3">
              <div>
                <p className={`num text-[2.1rem] leading-none ${infiniteAmmo ? "text-brass-300" : ammo === 0 ? "text-clay-500" : "text-sand-100"}`}>
                  {infiniteAmmo ? "∞" : String(ammo).padStart(2, "0")}
                </p>
                <p className="eyebrow mt-1 text-[0.42rem] text-sand-400">{infiniteAmmo ? "Unlimited" : "In magazine"}</p>
              </div>
              <div className="flex-1">
                <div className="flex gap-[3px]">
                  {pips.map((_, index) => (
                    <span
                      key={index}
                      className={`h-4 flex-1 rounded-[1px] border ${
                        infiniteAmmo || index < ammo ? "border-brass-400/70 bg-brass-400/85" : "border-sand-100/15 bg-sand-100/5"
                      } ${reloading && index < ammo ? "animate-pulse" : ""}`}
                    />
                  ))}
                </div>
                <p className="num mt-1.5 text-[0.58rem] tracking-[0.1em] text-sand-400">
                  Reserve <span className="text-sand-200">{infiniteAmmo ? "∞" : String(reserve).padStart(2, "0")}</span>
                  {infiniteAmmo && <span className="ml-1 text-brass-300/80">· auto</span>}
                </p>
              </div>
            </div>
            <div className="flex w-[74px] flex-col gap-1.5 border-l border-sand-100/10 p-2">
              <button
                onClick={onToggleAim}
                className={`flex flex-1 flex-col items-center justify-center gap-0.5 rounded-sm border transition ${
                  aiming ? "border-brass-300/60 bg-brass-300/12 text-brass-300" : "border-sand-100/15 text-sand-300 hover:border-brass-300/40 hover:text-brass-300"
                }`}
              >
                <ScopeIcon size={14} />
                <span className="font-condensed text-[0.48rem] uppercase tracking-[0.12em]">{aiming ? "Steady" : "Steady"}</span>
              </button>
              <button
                onClick={onReload}
                className={`flex flex-1 flex-col items-center justify-center gap-0.5 rounded-sm border transition ${
                  reloading ? "border-brass-300/60 bg-brass-300/12 text-brass-300" : "border-sand-100/15 text-sand-300 hover:border-brass-300/40 hover:text-brass-300"
                }`}
              >
                <ReloadIcon size={13} className={reloading ? "animate-spin" : ""} />
                <span className="font-condensed text-[0.48rem] uppercase tracking-[0.12em]">{reloading ? "…" : "Reload"}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <TouchControls
        layout={controlsLayout}
        ammo={ammo}
        reserve={reserve}
        reloading={reloading}
        aiming={aiming}
        infiniteAmmo={infiniteAmmo}
        waveIndex={waveIndex}
        waveTotal={WAVES.length}
        waveQuota={wave.quota}
        waveHarvested={waveHarvested}
        waveTime={formatTime(waveTimeLeft)}
        onMove={onMoveAxes}
        onFire={onFire}
        onReload={onReload}
        onToggleAim={onToggleAim}
      />
    </div>
  );
}
