import { useEffect, useRef } from "react";
import type { HudState, Team } from "@/game/types";
import { cn } from "@/utils/cn";
import { FoxMark, Icon, IconButton, KeyCap, Panel, TeamBadge } from "./ui";

export interface HudProps {
  hud: HudState;
  nickname: string;
  serverName?: string | null;
  soundOn: boolean;
  touch: boolean;
  hitKey: number;
  damageKey: number;
  toast: { id: number; text: string; tone?: "good" | "bad" | "info" } | null;
  streak: { id: number; text: string } | null;
  killBanner: { id: number; text: string } | null;
  showScoreboard: boolean;
  onPause: () => void;
  onToggleSound: () => void;
  onToggleScoreboard: () => void;
  onSelectWeapon: (index: number) => void;
  onOpenWeapons: () => void;
}

const WEAPON_ICONS = ["crosshair", "bolt", "target", "grenade", "ammo", "star"] as const;

function formatTime(seconds: number) {
  const s = Math.max(0, Math.ceil(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function teamColor(team: Team | "none") {
  return team === "sun" ? "text-sun" : team === "tide" ? "text-teal" : "text-grape";
}

function teamBg(team: Team | "none") {
  return team === "sun" ? "bg-sun" : team === "tide" ? "bg-teal" : "bg-grape";
}

export function Hud({
  hud,
  nickname,
  serverName,
  soundOn,
  touch,
  hitKey,
  damageKey,
  toast,
  streak,
  killBanner,
  showScoreboard,
  onPause,
  onToggleSound,
  onToggleScoreboard,
  onSelectWeapon,
  onOpenWeapons,
}: HudProps) {
  const healthPct = (hud.health / hud.maxHealth) * 100;
  const armorPct = (hud.armor / hud.maxArmor) * 100;
  const healthColor = healthPct > 55 ? "bg-lime" : healthPct > 25 ? "bg-sun" : "bg-coral";
  const activeWeapon = hud.weapons[hud.weaponIndex];
  const gap = 5 + hud.spread * 13;

  return (
    <div className="pointer-events-none fixed inset-0 z-30 select-none overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_52%,rgba(23,17,38,0.5))]" />

      {damageKey > 0 && (
        <div
          key={`dmg-${damageKey}`}
          className="animate-damage absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(255,60,60,0.55)_100%)]"
        />
      )}
      {hud.health <= 30 && hud.player.alive && (
        <div className="animate-low-health absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(255,40,40,0.5)_100%)]" />
      )}

      {/* top bar */}
      <div className="safe-top absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-2 sm:p-3">
        <Panel className="flex w-[154px] items-center gap-2 p-1.5 pr-2 sm:w-[224px] sm:p-2">
          <div className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl border-[3px] border-ink bg-sun shadow-[0_2px_0_0_#241a35] sm:h-12 sm:w-12">
            <FoxMark className="h-8 w-8 sm:h-9 sm:w-9" />
            <span className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-ink bg-teal" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1">
              <span className="truncate font-display text-[10px] font-extrabold uppercase tracking-wide text-cream sm:text-xs">{nickname}</span>
              <TeamBadge team="sun" className="hidden sm:inline-flex" />
            </div>
            <div className="mt-1 space-y-1">
              <div className="flex items-center gap-1">
                <Icon name="heart" className="h-2.5 w-2.5 shrink-0 text-coral" />
                <div className="h-2 flex-1 overflow-hidden rounded-full border-2 border-ink bg-ink/70 sm:h-2.5">
                  <div className={cn("h-full rounded-full transition-[width] duration-150", healthColor)} style={{ width: `${healthPct}%` }} />
                </div>
                <span className="w-5 text-right font-mono text-[9px] font-black text-cream sm:text-[10px]">{hud.health}</span>
              </div>
              <div className="flex items-center gap-1">
                <Icon name="shield" className="h-2.5 w-2.5 shrink-0 text-teal" />
                <div className="h-1.5 flex-1 overflow-hidden rounded-full border-2 border-ink bg-ink/70 sm:h-2">
                  <div className="h-full rounded-full bg-teal transition-[width] duration-150" style={{ width: `${armorPct}%` }} />
                </div>
                <span className="w-5 text-right font-mono text-[9px] font-black text-cream/70 sm:text-[10px]">{hud.armor}</span>
              </div>
            </div>
          </div>
        </Panel>

        <Panel className="w-[136px] p-1.5 text-center sm:w-[204px] sm:p-2">
          <div className="flex items-center justify-center gap-1.5">
            <Icon name="clock" className="h-3.5 w-3.5 text-sun sm:h-4 sm:w-4" />
            <span className="font-display text-lg font-black tabular-nums leading-none text-cream sm:text-2xl">{formatTime(hud.timeLeft)}</span>
          </div>
          {hud.mode === "dm" ? (
            <>
              <div className="mt-1 flex items-stretch justify-center gap-2">
                <div className="flex-1">
                  <p className="text-[7px] font-black uppercase tracking-wider text-cream/35">Счёт</p>
                  <p className="font-display text-xs font-black leading-tight text-sun sm:text-sm">{hud.score.toLocaleString("ru-RU")}</p>
                </div>
                <div className="w-px bg-cream/10" />
                <div className="flex-1">
                  <p className="text-[7px] font-black uppercase tracking-wider text-cream/35">Убийства</p>
                  <p className="font-display text-xs font-black leading-tight text-cream sm:text-sm">
                    {hud.kills}
                    <span className="text-cream/35">/{hud.scoreLimit}</span>
                  </p>
                </div>
              </div>
              <div className="mt-1 h-1 overflow-hidden rounded-full border border-ink bg-ink/70">
                <div className="h-full bg-sun" style={{ width: `${Math.min(100, (hud.kills / hud.scoreLimit) * 100)}%` }} />
              </div>
              {serverName && (
                <div className="mt-1 hidden items-center justify-center gap-1 sm:flex">
                  <span className="h-1.5 w-1.5 rounded-full bg-lime" />
                  <span className="max-w-[150px] truncate text-[7px] font-black uppercase tracking-wider text-lime/80">Online · {serverName}</span>
                </div>
              )}
            </>
          ) : (
            <>
              <div className="mt-1 flex items-center justify-between gap-1">
                <div className="flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full border border-ink bg-sun" />
                  <span className="font-display text-sm font-black text-sun sm:text-base">{hud.teamScores.sun}</span>
                </div>
                <span className="text-[8px] font-black text-cream/25">VS</span>
                <div className="flex items-center gap-1">
                  <span className="font-display text-sm font-black text-teal sm:text-base">{hud.teamScores.tide}</span>
                  <span className="h-2 w-2 rounded-full border border-ink bg-teal" />
                </div>
              </div>
              <div className="mt-1 flex h-1.5 overflow-hidden rounded-full border border-ink bg-ink/70">
                <div className="bg-sun" style={{ width: `${(hud.teamScores.sun / Math.max(1, hud.teamScores.sun + hud.teamScores.tide)) * 100}%` }} />
                <div className="flex-1 bg-teal" />
              </div>
            </>
          )}
        </Panel>

        <div className="flex w-[112px] flex-col items-end gap-1.5 sm:w-[236px]">
          <div className="pointer-events-auto flex gap-1.5">
            <IconButton icon={soundOn ? "sound" : "mute"} label="Звук" onClick={onToggleSound} active={soundOn} className="h-8 w-8 sm:h-9 sm:w-9" />
            <IconButton icon="users" label="Таблица счёта" onClick={onToggleScoreboard} className="h-8 w-8 sm:h-9 sm:w-9" />
            <IconButton icon="pause" label="Пауза" onClick={onPause} className="h-8 w-8 bg-coral text-white sm:h-9 sm:w-9" />
          </div>
          <Panel className="hidden w-full p-1.5 min-[430px]:block">
            <div className="mb-1 flex items-center justify-between px-0.5">
              <span className="text-[8px] font-black uppercase tracking-[0.18em] text-cream/40">Миникарта</span>
              <span className="flex items-center gap-1 text-[8px] font-bold text-cream/30">
                <span className="h-1.5 w-1.5 rounded-full bg-sun" /> ВЫ
              </span>
            </div>
            <Minimap hud={hud} />
          </Panel>
          <div className="w-full space-y-1">
            {hud.killFeed.slice(0, 4).map((item) => (
              <div
                key={item.id}
                className={cn(
                  "animate-slide-in flex items-center gap-1 rounded-lg border-2 px-1.5 py-1 text-[9px] font-bold backdrop-blur-sm",
                  item.isPlayer ? "border-sun/60 bg-sun/15" : "border-cream/10 bg-ink/65"
                )}
              >
                <span className={cn("max-w-[54px] truncate sm:max-w-[76px]", teamColor(item.killerTeam))}>{item.killer}</span>
                <Icon name="crosshair" className="h-3 w-3 shrink-0 text-cream/35" />
                <span className={cn("max-w-[54px] truncate sm:max-w-[76px]", teamColor(item.victimTeam))}>{item.victim}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* crosshair */}
      {hud.player.alive && !hud.vehicle && (
        <div className="absolute left-1/2 top-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2">
          <span className={cn("absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-ink", hud.aiming ? "bg-teal" : "bg-cream")} />
          {[0, 90, 180, 270].map((deg) => (
            <span
              key={deg}
              className={cn("absolute left-1/2 top-1/2 h-2.5 w-[2px] rounded-full", hud.aiming ? "bg-teal" : "bg-cream/90")}
              style={{ transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-${gap}px)` }}
            />
          ))}
          {hitKey > 0 && (
            <div key={`hit-${hitKey}`} className="animate-hitmarker absolute inset-0">
              {[45, 135, 225, 315].map((deg) => (
                <span
                  key={deg}
                  className="absolute left-1/2 top-1/2 h-3 w-[2.5px] rounded-full bg-white shadow-[0_0_4px_rgba(255,255,255,0.8)]"
                  style={{ transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-13px)` }}
                />
              ))}
            </div>
          )}
          {hud.reloading && (
            <svg viewBox="0 0 80 80" className="absolute inset-0 h-full w-full -rotate-90">
              <circle cx="40" cy="40" r="30" fill="none" stroke="rgba(36,26,53,0.6)" strokeWidth="4" />
              <circle
                cx="40"
                cy="40"
                r="30"
                fill="none"
                stroke="#ffb43c"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 30}
                strokeDashoffset={2 * Math.PI * 30 * (1 - hud.reloadProgress)}
              />
            </svg>
          )}
          {hud.reloading && (
            <div className="absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded-md border-2 border-ink bg-sun px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wider text-ink">
              Перезарядка
            </div>
          )}
        </div>
      )}

      {/* streak + kill banner */}
      {streak && (
        <div key={`streak-${streak.id}`} className="animate-streak absolute left-1/2 top-[19%] -translate-x-1/2 text-center">
          <div className="flex items-center justify-center gap-2 text-sun">
            <Icon name="star" className="h-5 w-5 sm:h-7 sm:w-7" />
            <span className="font-display text-2xl font-black uppercase tracking-tight text-outline sm:text-4xl">{streak.text}</span>
            <Icon name="star" className="h-5 w-5 sm:h-7 sm:w-7" />
          </div>
        </div>
      )}
      {killBanner && (
        <div key={`kill-${killBanner.id}`} className="animate-streak absolute left-1/2 top-[29%] -translate-x-1/2 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border-[3px] border-ink bg-coral px-3 py-1 shadow-[0_3px_0_0_#241a35]">
            <Icon name="skull" className="h-4 w-4 text-white" />
            <span className="font-display text-[10px] font-black uppercase tracking-wider text-white sm:text-xs">{killBanner.text}</span>
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div key={`toast-${toast.id}`} className="animate-toast absolute left-1/2 top-[62%] -translate-x-1/2">
          <div
            className={cn(
              "flex items-center gap-2 rounded-full border-[3px] border-ink px-3 py-1.5 shadow-[0_3px_0_0_#241a35]",
              toast.tone === "bad" ? "bg-coral text-white" : toast.tone === "info" ? "bg-grape text-ink" : "bg-teal text-ink"
            )}
          >
            <Icon name={toast.tone === "bad" ? "skull" : "bolt"} className="h-4 w-4" />
            <span className="whitespace-nowrap font-display text-[10px] font-extrabold uppercase tracking-wide sm:text-xs">{toast.text}</span>
          </div>
        </div>
      )}

      {/* vehicle / pickup prompt */}
      {hud.vehicle && (
        <div className="absolute bottom-[92px] left-1/2 -translate-x-1/2 sm:bottom-[104px]">
          <Panel className="flex items-center gap-2 px-2.5 py-1.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg border-2 border-ink bg-teal text-ink">
              <Icon name="car" className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <p className="text-[7px] font-black uppercase tracking-wider text-cream/40">Техника</p>
              <p className="font-display text-[10px] font-extrabold text-cream">{hud.vehicle.name}</p>
            </div>
            <div className="w-20 sm:w-28">
              <div className="h-2 overflow-hidden rounded-full border-2 border-ink bg-ink/70">
                <div className="h-full bg-lime" style={{ width: `${(hud.vehicle.health / hud.vehicle.maxHealth) * 100}%` }} />
              </div>
              <p className="mt-0.5 text-right font-mono text-[8px] font-bold text-cream/40">
                {hud.vehicle.health}/{hud.vehicle.maxHealth}
              </p>
            </div>
            <div className="text-right">
              <p className="font-display text-base font-black leading-none text-sun">{hud.vehicle.speed}</p>
              <p className="text-[7px] font-bold uppercase text-cream/35">км/ч</p>
            </div>
            <span className="hidden items-center gap-1 sm:flex">
              <KeyCap>E</KeyCap>
              <span className="text-[8px] font-bold uppercase text-cream/50">Выйти</span>
            </span>
          </Panel>
        </div>
      )}
      {!hud.vehicle && hud.nearVehicle && hud.player.alive && (
        <div className="animate-bob absolute bottom-[92px] left-1/2 -translate-x-1/2 sm:bottom-[104px]">
          <div className="flex items-center gap-2 rounded-full border-[3px] border-ink bg-cream px-3 py-1.5 text-ink shadow-[0_3px_0_0_#241a35]">
            <Icon name="car" className="h-4 w-4" />
            <span className="whitespace-nowrap font-display text-[9px] font-extrabold uppercase tracking-wide sm:text-[10px]">
              {touch ? "Нажми «Машина»" : "E — сесть в"} {hud.nearVehicle}
            </span>
          </div>
        </div>
      )}

      {/* weapon slots */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 sm:bottom-3">
        <div className="mb-1 flex items-center justify-center gap-1.5">
          <span className="rounded-md border-2 border-ink bg-ink/70 px-2 py-0.5 font-display text-[9px] font-extrabold uppercase tracking-wider text-cream/80 backdrop-blur-sm">
            {activeWeapon.name} <span className="text-sun">{activeWeapon.ammo}</span>
            <span className="text-cream/35">/{activeWeapon.reserve}</span>
          </span>
          <button
            type="button"
            onClick={onOpenWeapons}
            className="pointer-events-auto flex items-center gap-1 rounded-md border-2 border-ink bg-grape px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wider text-ink shadow-[0_2px_0_0_#241a35] transition-transform active:translate-y-[1px]"
          >
            <Icon name="swap" className="h-3 w-3" />
            <span className="hidden sm:inline">Выбор</span><span className="hidden rounded bg-ink/20 px-1 font-mono text-[7px] sm:inline">X</span>
          </button>
        </div>
        <div className="pointer-events-auto flex items-end gap-1 sm:gap-1.5">
          {hud.weapons.map((weapon, i) => {
            const active = i === hud.weaponIndex;
            return (
              <button
                key={weapon.id}
                type="button"
                onClick={() => onSelectWeapon(i)}
                className={cn(
                  "relative flex h-10 w-10 flex-col items-center justify-center overflow-hidden rounded-xl border-[3px] transition-all sm:h-14 sm:w-14",
                  active ? "border-ink text-ink shadow-[0_3px_0_0_#241a35]" : "border-cream/15 bg-ink/70 text-cream/60 hover:bg-ink/90"
                )}
                style={active ? { backgroundColor: weapon.color } : undefined}
                aria-label={weapon.name}
              >
                <span className="absolute left-1 top-0.5 font-mono text-[7px] font-black opacity-50">{i + 1}</span>
                <Icon name={WEAPON_ICONS[i]} className="h-4 w-4 sm:h-5 sm:w-5" />
                <span className="mt-0.5 font-display text-[8px] font-black leading-none sm:text-[9px]">{weapon.short}</span>
                <span className={cn("font-mono text-[8px] font-bold leading-none", active ? "text-ink/70" : "text-cream/40")}>{weapon.ammo}</span>
                {weapon.reloading && (
                  <span className="absolute inset-x-0 bottom-0 h-1 bg-ink/30">
                    <span className="block h-full bg-sun" style={{ width: `${weapon.reloadProgress * 100}%` }} />
                  </span>
                )}
              </button>
            );
          })}
          <div className="ml-0.5 flex h-10 w-8 flex-col items-center justify-center rounded-xl border-[3px] border-cream/15 bg-ink/70 text-cream/70 sm:h-14 sm:w-11">
            <Icon name="grenade" className="h-4 w-4 text-lime" />
            <span className="font-display text-[10px] font-black leading-none">{hud.grenades}</span>
            <span className="text-[6px] font-bold uppercase text-cream/35">Гранаты</span>
          </div>
        </div>
      </div>

      {/* respawn */}
      {!hud.player.alive && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-ink/65 backdrop-blur-[3px]">
          <div className="animate-pop-in flex flex-col items-center px-6 text-center">
            <div className="relative mb-3 grid h-20 w-20 place-items-center rounded-3xl border-[3px] border-ink bg-coral text-white shadow-[0_6px_0_0_#241a35]">
              <Icon name="skull" className="h-10 w-10" />
              <span className="absolute inset-0 rounded-3xl border-[3px] border-coral/50 animate-pulse-ring" />
            </div>
            <p className="font-display text-2xl font-black uppercase tracking-tight text-cream text-outline sm:text-4xl">Вы выбиты</p>
            <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.2em] text-cream/50">Возрождение через</p>
            <div className="mt-2 font-display text-5xl font-black text-sun text-outline">{Math.ceil(hud.player.respawnIn)}</div>
            <div className="mt-3 h-2 w-48 overflow-hidden rounded-full border-2 border-ink bg-ink/70">
              <div className="h-full bg-sun transition-[width] duration-100" style={{ width: `${Math.max(0, 100 - (hud.player.respawnIn / 3) * 100)}%` }} />
            </div>
            <p className="mt-3 max-w-xs text-[11px] font-medium leading-snug text-cream/50">
              Совет: держись за укрытиями и меняй позицию. Здоровье восстанавливается через 6 секунд без урона.
            </p>
          </div>
        </div>
      )}

      {/* scoreboard */}
      {showScoreboard && (
        <div className="pointer-events-auto absolute inset-0 z-50 grid place-items-center bg-ink/75 p-3 backdrop-blur-sm">
          <Panel className="animate-pop-in w-full max-w-2xl p-3 sm:p-4">
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-xl border-[3px] border-ink bg-sun text-ink">
                  <Icon name="users" className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-display text-sm font-black uppercase tracking-wide text-cream">Таблица боя</p>
                  <p className="text-[9px] font-bold uppercase tracking-wider text-cream/40">
                    {hud.mode === "dm" ? "Deathmatch · каждый сам за себя" : "Team Deathmatch · 4 на 4"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {hud.mode === "tdm" && (
                  <div className="flex items-center gap-1 rounded-lg border-2 border-ink bg-ink/60 px-2 py-1">
                    <span className="h-2 w-2 rounded-full bg-sun" />
                    <span className="font-display text-xs font-black text-sun">{hud.teamScores.sun}</span>
                    <span className="text-[8px] text-cream/30">:</span>
                    <span className="font-display text-xs font-black text-teal">{hud.teamScores.tide}</span>
                    <span className="h-2 w-2 rounded-full bg-teal" />
                  </div>
                )}
                <span className="hidden items-center gap-1 text-[9px] font-bold uppercase text-cream/40 sm:flex">
                  <KeyCap>TAB</KeyCap> закрыть
                </span>
              </div>
            </div>
            <div className="overflow-hidden rounded-xl border-2 border-cream/10">
              <div className="grid grid-cols-[28px_1fr_54px_44px_44px] gap-1 bg-ink/60 px-2 py-1.5 text-[8px] font-black uppercase tracking-wider text-cream/35 sm:grid-cols-[32px_1fr_70px_54px_54px]">
                <span>#</span>
                <span>Боец</span>
                <span className="text-center">Команда</span>
                <span className="text-center">Убийства</span>
                <span className="text-center">Смерти</span>
              </div>
              <div className="max-h-[46vh] overflow-y-auto">
                {hud.scoreboard.map((entry, i) => (
                  <div
                    key={`${entry.name}-${i}`}
                    className={cn(
                      "grid grid-cols-[28px_1fr_54px_44px_44px] items-center gap-1 border-t border-cream/5 px-2 py-1.5 text-[10px] sm:grid-cols-[32px_1fr_70px_54px_54px]",
                      entry.isPlayer ? "bg-sun/15" : i % 2 === 0 ? "bg-white/[0.03]" : ""
                    )}
                  >
                    <span className={cn("font-display text-[10px] font-black", i === 0 ? "text-sun" : "text-cream/40")}>{i + 1}</span>
                    <span className="flex min-w-0 items-center gap-1.5">
                      <span className={cn("h-2 w-2 shrink-0 rounded-full border border-ink", teamBg(entry.team))} />
                      <span className={cn("truncate font-display text-[10px] font-extrabold", entry.isPlayer ? "text-sun" : "text-cream")}>{entry.name}</span>
                      {entry.isPlayer && <span className="rounded bg-sun px-1 text-[7px] font-black text-ink">ВЫ</span>}
                    </span>
                    <span className="flex justify-center">
                      <TeamBadge team={entry.team} />
                    </span>
                    <span className="text-center font-mono text-[11px] font-black text-cream">{entry.kills}</span>
                    <span className="text-center font-mono text-[11px] font-bold text-cream/40">{entry.deaths}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-2 flex items-center justify-between text-[9px] font-bold uppercase tracking-wider text-cream/35">
              <span>Лимит: {hud.scoreLimit} {hud.mode === "dm" ? "убийств" : "очков"}</span>
              <span className="flex items-center gap-1">
                <Icon name="clock" className="h-3 w-3" /> {formatTime(hud.timeLeft)}
              </span>
            </div>
          </Panel>
        </div>
      )}
    </div>
  );
}

function Minimap({ hud }: { hud: HudState }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const size = canvas.width;
    const pad = 10;
    const inner = size - pad * 2;
    const world = 176;
    const toX = (x: number) => pad + ((x + world / 2) / world) * inner;
    const toY = (z: number) => pad + ((z + world / 2) / world) * inner;

    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "#1b3434";
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = "rgba(255,246,230,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const p = pad + (inner / 4) * i;
      ctx.beginPath();
      ctx.moveTo(p, pad);
      ctx.lineTo(p, pad + inner);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(pad, p);
      ctx.lineTo(pad + inner, p);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(255,246,230,0.10)";
    ctx.strokeStyle = "rgba(255,246,230,0.12)";
    for (const o of hud.obstacles) {
      const w = (o.w / world) * inner;
      const d = (o.d / world) * inner;
      ctx.fillRect(toX(o.x) - w / 2, toY(o.z) - d / 2, w, d);
      ctx.strokeRect(toX(o.x) - w / 2, toY(o.z) - d / 2, w, d);
    }
    for (const b of hud.blips) {
      if (b.kind === "pickup") {
        ctx.fillStyle = "#9fe870";
        ctx.fillRect(toX(b.x) - 2, toY(b.z) - 2, 4, 4);
      }
    }
    for (const b of hud.blips) {
      if (b.kind !== "vehicle") continue;
      ctx.fillStyle = b.team === "tide" ? "#39d6c8" : "#ffb43c";
      ctx.strokeStyle = "#241a35";
      ctx.lineWidth = 2;
      ctx.fillRect(toX(b.x) - 4, toY(b.z) - 4, 8, 8);
      ctx.strokeRect(toX(b.x) - 4, toY(b.z) - 4, 8, 8);
    }
    for (const b of hud.blips) {
      if (b.kind !== "bot") continue;
      ctx.beginPath();
      ctx.fillStyle = b.team === "tide" ? "#39d6c8" : b.team === "sun" ? "#ffb43c" : "#a08cff";
      ctx.strokeStyle = "#241a35";
      ctx.lineWidth = 2;
      ctx.arc(toX(b.x), toY(b.z), 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    const p = hud.player;
    if (p.alive) {
      const px = toX(p.x);
      const py = toY(p.z);
      const angle = Math.atan2(-Math.cos(p.yaw), -Math.sin(p.yaw));
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.arc(px, py, 30, angle - 0.5, angle + 0.5);
      ctx.closePath();
      ctx.fillStyle = "rgba(255,180,60,0.20)";
      ctx.fill();
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(-p.yaw);
      ctx.beginPath();
      ctx.moveTo(0, -8);
      ctx.lineTo(6, 6);
      ctx.lineTo(0, 3);
      ctx.lineTo(-6, 6);
      ctx.closePath();
      ctx.fillStyle = "#ffb43c";
      ctx.strokeStyle = "#241a35";
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    ctx.strokeStyle = "rgba(255,246,230,0.15)";
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, size - 2, size - 2);
  }, [hud]);

  return <canvas ref={ref} width={320} height={320} className="aspect-square w-full rounded-lg border-2 border-ink bg-[#1b3434]" />;
}
