import { useEffect, useState, type ReactNode } from "react";
import {
  store,
  useStore,
  marsBusy,
  clickReward,
  CLICKS_PER_SET,
  TAPS_PER_BREAK,
  DRINK_COST,
  rankOf,
  restMs,
  stamina,
} from "../lib/store";
import { FOODS } from "../lib/world";
import { toFa } from "../lib/fa";
import { boop, fanfare } from "../lib/sound";
import { BagIcon, CoinIcon, JeekoMark, SoundOffIcon, SoundOnIcon } from "./icons";
import { ALL_ITEMS, SLOT_LABEL } from "../lib/catalog";
import { ItemIcon } from "./ItemIcon";
import { MarsDock } from "./MarsHud";
import { WheelDock } from "./WheelHud";
import { isShort, isTiny, useLayout, useMeasure, useViewportWatcher } from "../lib/layout";

/* ================================================================== */
/*  helpers                                                            */
/* ================================================================== */
export function fmt(ms: number) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${toFa(Math.floor(s / 60), 2)}:${toFa(s % 60, 2)}`;
}

function useNow(active: boolean, ms = 500) {
  const [, setN] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setN((v) => v + 1), ms);
    return () => window.clearInterval(id);
  }, [active, ms]);
  return Date.now();
}

export function Btn({
  children,
  onClick,
  tone = "primary",
  disabled,
  full,
  size = "md",
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "primary" | "dark" | "ghost" | "danger" | "cool";
  disabled?: boolean;
  full?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const tones = {
    primary: "bg-gradient-to-b from-amber-400 to-amber-500 text-amber-950 shadow-[0_8px_18px_-10px_rgba(180,83,9,0.95)]",
    dark: "bg-amber-950/90 text-amber-50",
    ghost: "bg-white/12 text-violet-50 ring-1 ring-white/15",
    danger: "bg-gradient-to-b from-rose-500 to-rose-600 text-white",
    cool: "bg-gradient-to-b from-sky-400 to-sky-600 text-white",
  };
  const sizes = {
    sm: "px-2.5 py-1.5 text-[11px] gap-1",
    md: "px-3.5 py-2 text-[12.5px] gap-1.5",
    lg: "px-5 py-3 text-[14px] gap-2",
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        boop();
        onClick();
      }}
      className={`pointer-events-auto inline-flex items-center justify-center rounded-2xl font-extrabold transition duration-200 ${
        sizes[size]
      } ${full ? "w-full" : ""} ${
        disabled
          ? "cursor-not-allowed bg-amber-900/15 text-amber-900/35"
          : `${tones[tone]} hover:-translate-y-0.5 active:translate-y-0`
      }`}
    >
      {children}
    </button>
  );
}

/** Bottom dock — the single place every in-map control lives. */
function Dock({ children }: { children: ReactNode }) {
  const { h } = useLayout();
  const tight = isShort(h);
  const tiny = isTiny(h);
  return (
    <div className="pointer-events-none flex justify-center px-2 pb-2 sm:px-3 sm:pb-3">
      <div
        className={`card no-scrollbar pointer-events-auto flex w-full max-w-md flex-col overflow-y-auto rounded-3xl ${
          tight ? "gap-1.5 p-2" : "gap-2 p-2.5"
        }`}
        style={{ maxHeight: tiny ? "min(58dvh, 260px)" : "min(46dvh, 340px)" }}
      >
        {children}
      </div>
    </div>
  );
}

function Chip({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="tile-soft rounded-xl py-1 text-center">
      <div className="text-[13px] font-black tabular-nums" style={{ color: tone ?? "#451a03" }}>
        {value}
      </div>
      <div className="text-[9.5px] font-bold text-amber-900/50">{label}</div>
    </div>
  );
}

/* ================================================================== */
/*  TOP BAR — always visible, single row                               */
/* ================================================================== */
export function TopBar() {
  const points = useStore((s) => s.points);
  const sound = useStore((s) => s.sound);
  const owner = useStore((s) => s.owner);
  const earned = useStore((s) => s.earned);
  const map = useStore((s) => s.map);
  const jailed = useStore((s) => s.jailUntil > Date.now());
  const onMars = useStore((s) => !!s.mars);
  const marsLocked = useStore(marsBusy);
  const rank = rankOf(earned);

  return (
    <div className="pointer-events-none flex items-center gap-1.5 px-2 py-2 sm:px-3 sm:py-3">
      {map !== "home" && !jailed && !onMars && !marsLocked ? (
        <button
          type="button"
          onClick={() => {
            store.home();
            boop();
          }}
          className="card pointer-events-auto flex shrink-0 items-center gap-1 rounded-xl py-1.5 pr-2 pl-2.5 text-[12px] font-black text-amber-950 transition hover:-translate-y-0.5"
        >
          <span className="text-sm">🏠</span>
          خونه
        </button>
      ) : (
        <div className="card flex shrink-0 items-center gap-1.5 rounded-xl py-1.5 pr-1.5 pl-2">
          <JeekoMark className="size-5 shrink-0" />
          <span
            className="hidden text-[13px] font-black text-amber-950 min-[360px]:inline"
            style={{ fontFamily: "ui-sans-serif, system-ui, sans-serif" }}
          >
            Jeeko
          </span>
        </div>
      )}

      <div className="card flex min-w-0 flex-1 items-center gap-1.5 rounded-xl px-2 py-1.5">
        <span className="shrink-0 text-[10px] font-black text-amber-900/60">
          سطح {toFa(rank.level)}
        </span>
        <div className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-amber-900/12">
          <div
            className="h-full rounded-full bg-gradient-to-l from-amber-400 to-amber-500"
            style={{
              width: `${Math.min(100, ((earned - rank.from) / Math.max(1, rank.next - rank.from)) * 100)}%`,
            }}
          />
        </div>
      </div>

      <button
        type="button"
        disabled={marsLocked}
        onClick={() => {
          store.setShop(true);
          boop();
        }}
        className={`pointer-events-auto inline-flex shrink-0 items-center gap-1 rounded-xl bg-amber-950/90 py-1.5 pr-1.5 pl-2 text-amber-50 backdrop-blur transition ${
          marsLocked ? "opacity-45" : "hover:-translate-y-0.5"
        }`}
      >
        <CoinIcon className="size-4 text-amber-300" />
        <span className="text-[12.5px] font-black tabular-nums">{toFa(points)}</span>
        <span className="grid size-5 place-items-center rounded-lg bg-white/15">
          <BagIcon className="size-3" />
        </span>
      </button>

      <button
        type="button"
        aria-label="صدا"
        onClick={() => {
          store.toggleSound();
          boop();
        }}
        className="card pointer-events-auto grid size-9 shrink-0 place-items-center rounded-xl text-amber-900/75 transition hover:-translate-y-0.5"
      >
        {sound ? <SoundOnIcon className="size-[17px]" /> : <SoundOffIcon className="size-[17px]" />}
      </button>

      <button
        type="button"
        aria-label="مالک"
        onClick={() => {
          store.setOwnerOpen(true);
          boop();
        }}
        className={`card pointer-events-auto grid size-9 shrink-0 place-items-center rounded-xl text-sm transition hover:-translate-y-0.5 ${
          owner ? "ring-2 ring-amber-500" : ""
        }`}
      >
        {owner ? "👑" : "🔐"}
      </button>
    </div>
  );
}

/* ================================================================== */
/*  HOME DOCK — click meter + rest state                               */
/* ================================================================== */
export function HomeDock() {
  const clicks = useStore((s) => s.clicks);
  const taps = useStore((s) => s.tapsSinceBreak);
  const lock = useStore((s) => s.clickLockUntil);
  const sleep = useStore((s) => s.sleepUntil);
  const points = useStore((s) => s.points);
  const reward = useStore(clickReward);
  const now = useNow(lock > Date.now() || sleep > Date.now());

  if (sleep > now) {
    return (
      <Dock>
        <div className="flex items-center gap-2.5">
          <span className="flex items-end gap-0.5 text-sky-600">
            <span className="zzz text-[11px] font-black">z</span>
            <span className="zzz text-sm font-black" style={{ animationDelay: "0.3s" }}>
              Z
            </span>
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-black text-amber-950">جیکو بعد از کار خوابیده</div>
            <div className="text-[10.5px] font-bold text-amber-900/55">
              بیدار شدن تا {fmt(sleep - now)}
            </div>
          </div>
          <Btn tone="cool" size="sm" disabled={points < DRINK_COST} onClick={() => store.drinkEnergy()}>
            🥤 انرژی‌زا {toFa(DRINK_COST)}
          </Btn>
        </div>
      </Dock>
    );
  }

  const locked = lock > now;

  return (
    <Dock>
      <div className="flex items-center gap-2">
        <div className="flex shrink-0 gap-1">
          {Array.from({ length: CLICKS_PER_SET }).map((_, i) => (
            <span
              key={i}
              className={`size-2.5 rounded-full transition ${
                i < clicks ? "bg-amber-500" : "bg-amber-900/15"
              }`}
            />
          ))}
        </div>
        <div className="min-w-0 flex-1 text-center">
          {locked ? (
            <>
              <div className="text-[11.5px] font-black text-rose-600">
                جیکو خسته‌ست — {fmt(lock - now)}
              </div>
              <div className="hidden text-[10px] font-bold text-amber-900/50 min-[380px]:block">
                تا اون موقع می‌تونی کار کنی یا بازی
              </div>
            </>
          ) : (
            <>
              <div className="text-[11.5px] font-black text-amber-950">
                👆 {toFa(CLICKS_PER_SET - clicks)} کلیک تا {toFa(reward)} پوینت
              </div>
              <div className="hidden text-[10px] font-bold text-amber-900/50 min-[380px]:block">
                {toFa(taps)}/{toFa(TAPS_PER_BREAK)} ضربه تا استراحت
              </div>
            </>
          )}
        </div>
      </div>

      <div className="flex gap-1.5">
        <Btn full size="lg" onClick={() => store.openPanel("hub")}>
          🎮 منوی بازی
        </Btn>
        <button
          type="button"
          aria-label="گوشی جیکو"
          onClick={() => {
            store.openPhone();
            boop();
          }}
          className="pointer-events-auto grid aspect-square shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-slate-700 to-slate-900 px-4 text-xl text-white shadow-[0_8px_18px_-10px_rgba(15,23,42,0.9)] transition hover:-translate-y-0.5 active:translate-y-0"
        >
          📱
        </button>
      </div>
    </Dock>
  );
}

/* ================================================================== */
/*  GYM DOCK                                                           */
/* ================================================================== */
export function GymDock() {
  const pet = useStore((s) => s.pet);
  const since = useStore((s) => s.repsSinceFood);
  const eating = useStore((s) => !!s.eating);
  const hungry = since >= 3;

  return (
    <Dock>
      <div className="grid grid-cols-3 gap-1.5">
        <Chip label="حرکت" value={`${toFa(pet.reps)}/${toFa(12)}`} />
        <Chip label="سن" value={`${toFa(pet.age)} سال`} />
        <Chip
          label="تا گرسنگی"
          value={toFa(Math.max(0, 3 - since))}
          tone={hungry ? "#e11d48" : undefined}
        />
      </div>

      <div className="h-1.5 overflow-hidden rounded-full bg-amber-900/12">
        <div
          className="h-full rounded-full bg-gradient-to-l from-violet-400 to-violet-600 transition-[width] duration-300"
          style={{ width: `${(pet.reps / 12) * 100}%` }}
        />
      </div>

      {hungry ? (
        <div className="grid grid-cols-2 gap-1.5">
          <Btn full tone="cool" onClick={() => store.setFridge(true)}>
            🧊 یخچال
          </Btn>
          <Btn full onClick={() => store.openPanel("market")}>
            🛒 فروشگاه
          </Btn>
        </div>
      ) : (
        <Btn full size="lg" disabled={eating} onClick={() => store.doRep()}>
          🏋️ دمبل بزن
        </Btn>
      )}
    </Dock>
  );
}

/* ================================================================== */
/*  JOB DOCKS                                                          */
/* ================================================================== */
export function SweepDock() {
  const play = useStore((s) => s.play);
  const [left, setLeft] = useState(45);

  useEffect(() => {
    if (!play || play.over) return;
    setLeft(45);
    const id = window.setInterval(() => {
      setLeft((v) => {
        if (v <= 1) {
          store.endPlay(true);
          fanfare();
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [play?.over]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!play || play.kind !== "sweep") return null;

  if (play.over) {
    return (
      <Dock>
        <div className="flex flex-col items-center gap-1.5 py-1 text-center">
          <span className="text-3xl">🧹</span>
          <div className="text-[13px] font-black text-amber-950">
            {toFa(play.score)} زباله جمع کردی
          </div>
          <div className="text-xl font-black text-emerald-600">+{toFa(play.loot)}</div>
          <Btn full onClick={() => store.closePlay()}>
            برگشت به خونه
          </Btn>
        </div>
      </Dock>
    );
  }

  return (
    <Dock>
      <div className="grid grid-cols-3 gap-1.5">
        <Chip label="جمع‌شده" value={toFa(play.score)} />
        <Chip label="درآمد" value={toFa(play.loot)} tone="#15803d" />
        <Chip label="ثانیه" value={toFa(left)} tone={left < 10 ? "#e11d48" : undefined} />
      </div>
      <Btn
        full
        tone="dark"
        onClick={() => {
          store.endPlay(true);
          fanfare();
        }}
      >
        پایان شیفت و دریافت پول
      </Btn>
    </Dock>
  );
}

export function HeistDock() {
  const play = useStore((s) => s.play);
  if (!play || play.kind !== "heist") return null;
  const risk = Math.min(72, 5 + play.score * 6);

  if (play.over) {
    return (
      <Dock>
        <div className="flex flex-col items-center gap-1.5 py-1 text-center">
          <span className="text-3xl">{play.loot > 0 ? "💰" : "🚔"}</span>
          <div className="text-[13px] font-black text-amber-950">
            {play.loot > 0 ? "در رفتی!" : "چیزی گیرت نیومد"}
          </div>
          {play.loot > 0 && (
            <div className="text-xl font-black text-emerald-600">+{toFa(play.loot)}</div>
          )}
          <Btn full onClick={() => store.closePlay()}>
            برگشت به خونه
          </Btn>
        </div>
      </Dock>
    );
  }

  return (
    <Dock>
      <div className="grid grid-cols-3 gap-1.5">
        <Chip label="جیب‌بری" value={toFa(play.score)} />
        <Chip label="غنیمت" value={toFa(play.loot)} tone="#15803d" />
        <Chip label="ریسک" value={`${toFa(Math.round(risk))}٪`} tone="#e11d48" />
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-amber-900/12">
        <div
          className="h-full rounded-full bg-gradient-to-l from-rose-400 to-rose-600 transition-[width] duration-300"
          style={{ width: `${risk}%` }}
        />
      </div>
      <Btn
        full
        tone="dark"
        onClick={() => {
          store.endPlay(true);
          if (play.loot > 0) fanfare();
        }}
      >
        فرار با غنیمت
      </Btn>
    </Dock>
  );
}

/* ================================================================== */
/*  JAIL                                                               */
/* ================================================================== */
export function JailDock() {
  const until = useStore((s) => s.jailUntil);
  const points = useStore((s) => s.points);
  const now = useNow(until > Date.now());
  if (until <= now) return null;

  return (
    <Dock>
      <div className="flex items-center gap-2.5 rounded-2xl bg-rose-600/92 px-3 py-2 text-white">
        <span className="text-xl">⛓️</span>
        <span className="flex-1 text-[12px] font-black">جیکو بازداشته</span>
        <span className="text-xl font-black tabular-nums">{fmt(until - now)}</span>
      </div>
      <Btn full tone="danger" disabled={points < 150} onClick={() => store.bail()}>
        پرداخت وثیقه — {toFa(150)} پوینت
      </Btn>
    </Dock>
  );
}

/* ================================================================== */
/*  FRIDGE SHEET — buy + feed in one graphical strip                   */
/* ================================================================== */
export function FridgeSheet() {
  const open = useStore((s) => s.fridgeOpen);
  const fridge = useStore((s) => s.fridge);
  const points = useStore((s) => s.points);
  const age = useStore((s) => s.pet.age);
  if (!open) return null;

  return (
    <div className="pointer-events-auto fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <div
        className="fade-in absolute inset-0 bg-amber-950/70"
        onClick={() => store.setFridge(false)}
      />
      <div className="sheet panel relative flex max-h-[88dvh] w-full flex-col rounded-t-3xl sm:m-4 sm:max-w-md sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-amber-900/12 bg-[#fff6e4] px-4 py-3">
          <h2 className="text-[14.5px] font-black text-amber-950">🧊 یخچال جیکو</h2>
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-950/90 px-2.5 py-1 text-[11.5px] font-black tabular-nums text-amber-100">
            <CoinIcon className="size-3.5 text-amber-300" />
            {toFa(points)}
          </span>
        </div>

        <div className="no-scrollbar grid min-h-0 flex-1 grid-cols-3 gap-2 overflow-y-auto p-3 sm:grid-cols-4">
          {FOODS.map((f) => {
            const have = fridge[f.id] ?? 0;
            const locked = !!f.adult && age < 18;
            return (
              <div
                key={f.id}
                className={`flex flex-col items-center gap-1 rounded-2xl tile p-2 ${
                  locked ? "opacity-45" : ""
                }`}
              >
                <span className="relative text-2xl">
                  {f.emoji}
                  {have > 0 && (
                    <span className="absolute -top-1 -right-2 grid size-4 place-items-center rounded-full bg-amber-950/90 text-[9px] font-black text-amber-50">
                      {toFa(have)}
                    </span>
                  )}
                </span>
                <span className="text-[10px] font-black text-amber-950">{f.name}</span>
                {locked ? (
                  <span className="text-[9px] font-black text-rose-600">۱۸+</span>
                ) : have > 0 ? (
                  <button
                    type="button"
                    onClick={() => {
                      store.eat(f.id, f.emoji);
                      boop();
                    }}
                    className="w-full rounded-lg bg-gradient-to-b from-emerald-400 to-emerald-500 py-1 text-[10px] font-black text-white"
                  >
                    بده بخوره
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      store.buyFood(f.id, f.price);
                      boop();
                    }}
                    className="inline-flex w-full items-center justify-center gap-0.5 rounded-lg bg-white/80 py-1 text-[10px] font-black text-amber-900"
                  >
                    <CoinIcon className="size-2.5" />
                    {toFa(f.price)}
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="border-t border-amber-900/12 p-3">
          <Btn full tone="ghost" onClick={() => store.setFridge(false)}>
            بستن
          </Btn>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  TOAST                                                              */
/* ================================================================== */
export function Toast() {
  const toast = useStore((s) => s.toast);
  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => store.clearToast(), 1800);
    return () => window.clearTimeout(t);
  }, [toast]);
  if (!toast) return null;
  return (
    <div
      className="pointer-events-none fixed inset-x-0 z-50 flex justify-center px-4"
      style={{ top: "calc(env(safe-area-inset-top, 0px) + 3.4rem)" }}
    >
      <div
        key={toast.id}
        className={`pop rounded-full px-4 py-2 text-[12px] font-black shadow-lg backdrop-blur ${
          toast.kind === "good" ? "bg-amber-950/90 text-amber-50" : "bg-rose-600/92 text-white"
        }`}
      >
        {toast.text}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  OWNER PANEL                                                        */
/* ================================================================== */
export function OwnerPanel() {
  const open = useStore((s) => s.ownerOpen);
  const owner = useStore((s) => s.owner);
  const points = useStore((s) => s.points);
  const st = useStore(stamina);
  const rest = useStore(restMs);
  const [pass, setPass] = useState("");
  const [amount, setAmount] = useState("1000");
  const [slot, setSlot] = useState<keyof typeof SLOT_LABEL>("suit");
  const ownedCount = useStore((s) => s.owned.length);
  const equippedNow = useStore((s) => s.equipped);

  useEffect(() => {
    if (!open) setPass("");
  }, [open]);
  if (!open) return null;

  return (
    <div className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center px-4">
      <div
        className="fade-in absolute inset-0 bg-amber-950/75"
        onClick={() => store.setOwnerOpen(false)}
      />
      <div className="sheet panel relative w-full max-w-sm rounded-3xl p-4">
        {!owner ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (store.login(pass)) fanfare();
            }}
            className="flex flex-col gap-3"
          >
            <div className="text-center">
              <div className="text-3xl">🔐</div>
              <h3 className="mt-1 text-[15px] font-black text-amber-950">ورود مالک</h3>
            </div>
            <input
              type="password"
              autoFocus
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              placeholder="رمز عبور"
              autoComplete="off"
              className="rounded-xl bg-white/75 px-3 py-2.5 text-center text-[13px] font-bold tracking-widest text-amber-950 outline-none placeholder:tracking-normal placeholder:text-amber-900/30"
            />
            <div className="grid grid-cols-2 gap-2">
              <Btn full onClick={() => store.login(pass) && fanfare()}>
                ورود
              </Btn>
              <Btn full tone="ghost" onClick={() => store.setOwnerOpen(false)}>
                انصراف
              </Btn>
            </div>
          </form>
        ) : (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-[15px] font-black text-amber-950">👑 پنل مالک</h3>
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-950/90 px-2.5 py-1 text-[11.5px] font-black tabular-nums text-amber-100">
                <CoinIcon className="size-3.5 text-amber-300" />
                {toFa(points)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <Chip label="کار تا خستگی" value={toFa(st)} />
              <Chip label="مدت خواب" value={fmt(rest)} />
            </div>

            <div className="rounded-2xl tile p-3">
              <div className="mb-2 text-[12px] font-black text-amber-950">افزایش پوینت</div>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-xl bg-white/75 px-3 py-2 text-[13px] font-black text-amber-950 outline-none"
              />
              <div className="mt-2 grid grid-cols-4 gap-1.5">
                {[1000, 10000, 100000, 1000000].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => {
                      setAmount(String(v));
                      boop();
                    }}
                    className="rounded-lg bg-white/70 py-1.5 text-[10.5px] font-black text-amber-900 transition hover:bg-white"
                  >
                    {v >= 1000000 ? "۱M" : `${toFa(v / 1000)}K`}
                  </button>
                ))}
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <Btn
                  full
                  onClick={() => {
                    store.grant(Math.abs(Number(amount) || 0));
                    fanfare();
                  }}
                >
                  + افزودن
                </Btn>
                <Btn full tone="danger" onClick={() => store.grant(-Math.abs(Number(amount) || 0))}>
                  − کسر
                </Btn>
              </div>
            </div>

            {/* ---- wardrobe: unlock any cosmetic, wheel-exclusives included ---- */}
            <div className="tile rounded-2xl p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[12px] font-black text-amber-950">کمد آیتم‌ها</span>
                <span className="text-[10px] font-bold text-amber-900/50">
                  {toFa(ownedCount)}/{toFa(ALL_ITEMS.length)}
                </span>
              </div>

              <div className="no-scrollbar mb-2 flex gap-1 overflow-x-auto">
                {(Object.keys(SLOT_LABEL) as (keyof typeof SLOT_LABEL)[]).map((sl) => (
                  <button
                    key={sl}
                    type="button"
                    onClick={() => {
                      setSlot(sl);
                      boop();
                    }}
                    className={`shrink-0 rounded-full px-2.5 py-1 text-[10.5px] font-bold transition ${
                      slot === sl
                        ? "bg-amber-950/90 text-amber-50"
                        : "bg-white/70 text-amber-900 ring-1 ring-amber-900/10"
                    }`}
                  >
                    {SLOT_LABEL[sl]}
                  </button>
                ))}
              </div>

              <div className="no-scrollbar grid max-h-36 grid-cols-4 gap-1.5 overflow-y-auto">
                {ALL_ITEMS.filter((i) => i.slot === slot).map((i) => {
                  const on = equippedNow[i.slot] === i.id;
                  return (
                    <button
                      key={i.id}
                      type="button"
                      title={i.name}
                      onClick={() => {
                        store.grantItem(i.id);
                        boop();
                      }}
                      className={`relative grid aspect-square place-items-center rounded-xl bg-white/70 p-1 ring-2 transition hover:-translate-y-0.5 ${
                        on ? "ring-amber-500" : "ring-transparent"
                      }`}
                    >
                      <ItemIcon id={i.id} className="size-full" />
                      {i.wheel && (
                        <span className="absolute -top-1 -right-1 text-[9px]">✦</span>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="mt-2 grid grid-cols-2 gap-2">
                <Btn full size="sm" onClick={() => store.grantAll()}>
                  باز کردن همه
                </Btn>
                <Btn full size="sm" tone="ghost" onClick={() => store.grantSpins(5)}>
                  +۵ چرخش
                </Btn>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Btn full tone="ghost" onClick={() => store.wake()}>
                بیدار / آزاد کردن
              </Btn>
              <Btn full tone="ghost" onClick={() => store.resetAll()}>
                ریست کامل
              </Btn>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Btn full tone="dark" onClick={() => store.setOwnerOpen(false)}>
                بستن
              </Btn>
              <Btn full tone="danger" onClick={() => store.logout()}>
                خروج از پنل
              </Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  ROOT                                                               */
/* ================================================================== */
/* ================================================================== */
/*  WATERMARK — tiny Jeeko brand mark, bottom-right                    */
/* ================================================================== */
function Watermark() {
  const map = useStore((s) => s.map);
  const dark = map === "night" || map === "jail";

  return (
    <div
      aria-hidden
      dir="ltr"
      className="pointer-events-none fixed right-2.5 bottom-2 z-20 hidden items-center gap-1 opacity-35 mix-blend-luminosity select-none min-[900px]:flex"
    >
      <JeekoMark className="size-3.5 shrink-0" />
      <span
        className={`text-[10px] leading-none font-black tracking-[0.14em] ${
          dark ? "text-white/80" : "text-amber-950/80"
        }`}
        style={{ fontFamily: "ui-sans-serif, system-ui, sans-serif" }}
      >
        JEEKO
      </span>
    </div>
  );
}

export function Hud() {
  const map = useStore((s) => s.map);
  const jailed = useStore((s) => s.jailUntil > Date.now());
  const shopOpen = useStore((s) => s.shopOpen);
  const fridgeOpen = useStore((s) => s.fridgeOpen);
  const panel = useStore((s) => s.panel);
  const phone = useStore((s) => s.phone);
  const onMars = useStore((s) => !!s.mars);
  const busySheet = shopOpen || fridgeOpen || !!panel || phone === "open";

  useViewportWatcher();
  const topRef = useMeasure("top");
  const bottomRef = useMeasure("bottom");

  return (
    <>
      {/* full-screen overlay column: header pinned top, dock pinned bottom,
          the 3D scene breathes in the flexible gap between them */}
      <div
        className="pointer-events-none fixed inset-0 z-30 flex flex-col"
        style={{
          paddingTop: "env(safe-area-inset-top, 0px)",
          paddingBottom: "env(safe-area-inset-bottom, 0px)",
        }}
      >
        <div ref={topRef} className="shrink-0">
          <TopBar />
        </div>

        <div className="min-h-0 flex-1" />

        <div ref={bottomRef} className="shrink-0">
          {!busySheet &&
            (onMars ? (
              <MarsDock />
            ) : map === "wheel" ? (
              <WheelDock />
            ) : jailed ? (
              <JailDock />
            ) : map === "home" ? (
              <HomeDock />
            ) : map === "gym" ? (
              <GymDock />
            ) : map === "street" ? (
              <SweepDock />
            ) : (
              <HeistDock />
            ))}
        </div>
      </div>

      <Toast />
      <FridgeSheet />
      <OwnerPanel />
      <Watermark />
    </>
  );
}
