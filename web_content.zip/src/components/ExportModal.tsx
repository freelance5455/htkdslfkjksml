import React, { useMemo, useState } from 'react';
import { Check, Copy, Download, X } from 'lucide-react';
import { AvatarConfig, WorldId } from '../types/game';
import { getWorldById } from '../engine/worlds';
import { buildStandaloneHtml } from '../engine/exportHtml';

interface ExportModalProps {
  open: boolean;
  worldId: WorldId;
  avatarConfig: AvatarConfig;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  open,
  worldId,
  avatarConfig,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const world = getWorldById(worldId, []);

  const htmlCode = useMemo(() => {
    if (!open) return '';
    return buildStandaloneHtml(world, avatarConfig);
  }, [open, world, avatarConfig]);

  if (!open) return null;

  const handleDownload = () => {
    const blob = new Blob([htmlCode], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `slapbox-${world.id}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(htmlCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored if blocked
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/80 p-4"
    >
      <div className="w-[min(760px,96vw)] max-h-[86vh] flex flex-col rounded-2xl bg-slate-900 border border-white/15 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <h2 id="export-title" className="font-display text-lg font-bold text-white">
              Ekspor Game HTML Mandiri
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Dunia: {world.name} · Satu file .html siap dibuka langsung di browser mana saja
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup modal ekspor"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-auto flex-1 bg-slate-950">
          <pre className="text-xs font-mono text-slate-300 leading-relaxed whitespace-pre-wrap break-all">
            {htmlCode}
          </pre>
        </div>

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-white/10 bg-slate-900">
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Kode Tersalin' : 'Salin Kode HTML'}
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Unduh slapbox-{world.id}.html
          </button>
        </div>
      </div>
    </div>
  );
};
