/**
 * GODEX v0.0.1 - Project Build & ZIP Export Modal
 */

import React, { useState } from 'react';
import { Download, FileArchive, Check, Copy, Terminal, X, Sparkles } from 'lucide-react';
import JSZip from 'jszip';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: Record<string, string>;
  projectTitle: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  files,
  projectTitle
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      setIsExporting(true);
      const zip = new JSZip();

      // Add all project files into the zip archive
      Object.keys(files).forEach(path => {
        zip.file(path, files[path]);
      });

      // Ensure package.json and README.md exist in archive
      if (!files['package.json']) {
        zip.file('package.json', JSON.stringify({
          name: projectTitle.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          version: '1.0.0',
          private: true,
          type: 'module',
          scripts: {
            dev: 'vite',
            build: 'vite build'
          },
          dependencies: {
            react: '^19.0.0',
            'react-dom': '^19.0.0',
            'lucide-react': '^0.546.0'
          }
        }, null, 2));
      }

      if (!files['README.md']) {
        zip.file('README.md', `# ${projectTitle}\n\nBuilt with GODEX.\n\n## Quick Start\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\`\n`);
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${projectTitle.toLowerCase().replace(/[^a-z0-9]/g, '-')}-source.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 2500);
    } catch (err) {
      console.error('ZIP generation error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const cliCommands = `# Unpack and run locally\nunzip ${projectTitle.toLowerCase().replace(/[^a-z0-9]/g, '-')}-source.zip\ncd ${projectTitle.toLowerCase().replace(/[^a-z0-9]/g, '-')}\nnpm install\nnpm run dev`;

  const handleCopyCli = () => {
    navigator.clipboard.writeText(cliCommands);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-xl bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <FileArchive className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                PROJECT_EXPORT.ARCHIVE
              </h2>
              <p className="text-[10px] text-neutral-400 font-sans">Full source bundle generation with local execution manifest</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#07080D]">
          {/* Download Action Card */}
          <div className="p-3.5 rounded bg-[#0D1018] border border-[#1C2334] flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-bold text-white text-xs">Standard Project ZIP Package</div>
              <p className="text-neutral-400 text-[11px] font-sans">
                Includes {Object.keys(files).length} files, tsconfig, package.json, and React components.
              </p>
            </div>

            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#0E2A38] hover:bg-[#133A4E] border border-cyan-500/60 text-xs font-bold text-cyan-300 shadow transition-all active:scale-95 disabled:opacity-50"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>DOWNLOADED</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>{isExporting ? 'GENERATING...' : 'DOWNLOAD_ZIP'}</span>
                </>
              )}
            </button>
          </div>

          {/* Local CLI Instructions */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-bold text-neutral-400 uppercase tracking-wider px-1">
              <span>Local Execution CLI</span>
              <button
                onClick={handleCopyCli}
                className="flex items-center gap-1 text-[10px] text-cyan-400 hover:underline"
              >
                {copiedCli ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCli ? 'COPIED' : 'COPY_COMMANDS'}</span>
              </button>
            </div>

            <div className="p-3 rounded bg-[#06070A] border border-[#1B2232] font-mono text-[11px] text-neutral-300 whitespace-pre overflow-x-auto leading-relaxed">
              {cliCommands}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="h-11 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
