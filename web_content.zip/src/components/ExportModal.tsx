import React, { useState } from 'react';
import {
  Download,
  X,
  CheckCircle2,
  Music,
  Play,
  Pause,
  Clock,
  HardDrive
} from 'lucide-react';
import { Project } from '../types/daw';
import { engine } from '../audio/engine';

interface ExportModalProps {
  project: Project;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  project,
  isOpen,
  onClose,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [renderedBlob, setRenderedBlob] = useState<Blob | null>(null);
  const [renderedUrl, setRenderedUrl] = useState<string | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const audioPreviewRef = React.useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const secondsPerBeat = 60 / project.bpm;
  const songLengthBeats = project.loopEnd || 16;
  const songDurationSec = Math.round(songLengthBeats * secondsPerBeat + 1.5);
  const estimatedSizeMb = ((44100 * 2 * 2 * songDurationSec) / (1024 * 1024)).toFixed(2);

  const handleStartExport = async () => {
    setIsExporting(true);
    setProgress(10);
    setRenderedBlob(null);
    setRenderedUrl(null);

    try {
      const blob = await engine.exportProjectWav(project, (pct) => {
        setProgress(pct);
      });

      const url = URL.createObjectURL(blob);
      setRenderedBlob(blob);
      setRenderedUrl(url);
      setProgress(100);
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = () => {
    if (!renderedUrl || !renderedBlob) return;
    const a = document.createElement('a');
    a.href = renderedUrl;
    const sanitizedName = project.name.replace(/[^a-z0-9_-]/gi, '_');
    a.download = `${sanitizedName}_FLMobile.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const togglePreview = () => {
    if (!audioPreviewRef.current || !renderedUrl) return;
    if (isPlayingPreview) {
      audioPreviewRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      audioPreviewRef.current.play();
      setIsPlayingPreview(true);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#181c25] border border-[#2f3747] rounded-3xl max-w-md w-full p-6 shadow-2xl relative flex flex-col gap-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-[#252b38] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#00e676]/20 border border-[#00e676]/40 flex items-center justify-center text-[#00e676]">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              Export Song to WAV
            </h3>
            <p className="text-xs text-slate-400">
              Master render: 44.1kHz · 16-Bit Stereo PCM
            </p>
          </div>
        </div>

        {/* Track Details Card */}
        <div className="bg-[#11141b] border border-[#232835] rounded-2xl p-4 flex flex-col gap-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Song Title:</span>
            <span className="font-semibold text-slate-100">{project.name}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Tempo:</span>
            <span className="font-mono text-slate-200">{project.bpm} BPM</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Duration:</span>
            <span className="font-mono text-[#00e5ff] font-bold">
              {songDurationSec} seconds ({songLengthBeats} beats)
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Estimated Size:</span>
            <span className="font-mono text-slate-300">~{estimatedSizeMb} MB</span>
          </div>
        </div>

        {/* Progress or Render Status */}
        {isExporting ? (
          <div className="flex flex-col gap-2 py-2">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-medium animate-pulse">Rendering DSP Audio Engine...</span>
              <span className="font-mono text-[#00e676] font-bold">{progress}%</span>
            </div>
            <div className="w-full h-2 bg-[#12141a] rounded-full overflow-hidden border border-[#262c38]">
              <div
                className="h-full bg-gradient-to-r from-[#ff7700] via-[#ffca28] to-[#00e676] transition-all duration-300 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : renderedBlob ? (
          <div className="flex flex-col gap-3 py-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#00e676] bg-[#00e676]/10 border border-[#00e676]/20 px-3 py-2 rounded-xl">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Audio successfully rendered! Ready to download.</span>
            </div>

            {/* Hidden Audio Element for Preview */}
            <audio
              ref={audioPreviewRef}
              src={renderedUrl || undefined}
              onEnded={() => setIsPlayingPreview(false)}
            />

            {/* Preview Play Button */}
            <button
              onClick={togglePreview}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#232936] hover:bg-[#2e3646] text-white text-xs font-semibold transition-colors border border-[#31394c]"
            >
              {isPlayingPreview ? (
                <>
                  <Pause className="w-4 h-4 fill-current text-[#00e676]" />
                  <span>Pause Preview</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current text-[#00e676]" />
                  <span>Play Rendered Audio Preview</span>
                </>
              )}
            </button>
          </div>
        ) : null}

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 mt-1">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            Cancel
          </button>

          {!renderedBlob ? (
            <button
              onClick={handleStartExport}
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#00e676] hover:bg-[#00c853] text-black font-bold text-xs shadow-lg shadow-[#00e676]/20 disabled:opacity-50 transition-all active:scale-95"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>{isExporting ? 'Rendering...' : 'Render WAV'}</span>
            </button>
          ) : (
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#ff7700] hover:bg-[#ff8800] text-black font-bold text-xs shadow-lg shadow-[#ff7700]/25 transition-all active:scale-95"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>Download .WAV File</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
