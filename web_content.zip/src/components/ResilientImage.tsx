import React, { useState } from 'react';
import { Gamepad2 } from 'lucide-react';

interface ResilientImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle,
}) => {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-950 text-[#39E52D] border border-neutral-800 ${className}`}
      >
        <Gamepad2 className="w-6 h-6 opacity-80" />
        {fallbackTitle && (
          <span className="mt-1 px-2 text-[10px] font-medium text-neutral-300 truncate max-w-full">
            {fallbackTitle}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
