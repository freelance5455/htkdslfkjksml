import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck,
  Lock,
  HardDrive,
  Cpu,
  CheckCircle2,
  RefreshCw,
  FileCode,
  Key,
  Wallet,
  Coins,
  MessageCircle,
  BookOpen,
  Sparkles,
  Zap,
  Check
} from 'lucide-react';
import { StorageTargetMedia } from '../lib/selfCustodialBackupEngine';

export interface LosslessEncryptionVisualizerProps {
  isActive: boolean;
  targetMedia: StorageTargetMedia;
  onComplete?: () => void;
  mode?: 'MANUAL' | 'AUTO';
}

interface EncryptingFileItem {
  id: string;
  fileName: string;
  category: string;
  sizeKb: number;
  cipher: string;
  icon: React.FC<{ className?: string }>;
  status: 'QUEUED' | 'ENCRYPTING' | 'ENCRYPTED_AND_WRITTEN';
  progress: number;
}

export const LosslessEncryptionVisualizer: React.FC<LosslessEncryptionVisualizerProps> = ({
  isActive,
  targetMedia,
  onComplete,
  mode = 'MANUAL'
}) => {
  const [overallProgress, setOverallProgress] = useState<number>(0);
  const [currentFileIndex, setCurrentFileIndex] = useState<number>(0);
  const [cipherHexStream, setCipherHexStream] = useState<string>('0x777A98F1B02C4E8A...INITIALIZING_CIPHER_GCM');
  const [throughputMbps, setThroughputMbps] = useState<number>(18.4);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const initialFiles: EncryptingFileItem[] = [
    {
      id: 'wallet',
      fileName: 'wallet_vault.dat.enc',
      category: 'Wallet Data (BTC Altar & JMC Private Keys, 12-Word Mnemonics)',
      sizeKb: 64.2,
      cipher: 'AES-256-GCM / Poly1305',
      icon: Wallet,
      status: 'QUEUED',
      progress: 0
    },
    {
      id: 'mining',
      fileName: 'jm_crypto_mining.ledger.enc',
      category: 'Mined JMC Tokens, Mining Nonces & Block Proofs',
      sizeKb: 48.8,
      cipher: 'Lossless SHA-256 Stream',
      icon: Coins,
      status: 'QUEUED',
      progress: 0
    },
    {
      id: 'chat',
      fileName: 'jm_chat_e2ee.history.enc',
      category: 'JM Chat E2EE Transcripts & Believer Contact Manifest',
      sizeKb: 72.5,
      cipher: 'ChaCha20-Poly1305 AEAD',
      icon: MessageCircle,
      status: 'QUEUED',
      progress: 0
    },
    {
      id: 'prayer',
      fileName: 'prophetic_prayer_journal.vault.enc',
      category: 'Prayer Journal, Petitions, Liturgies & Soaking Audio Cache',
      sizeKb: 38.1,
      cipher: 'Lossless AES-GCM (528Hz)',
      icon: BookOpen,
      status: 'QUEUED',
      progress: 0
    },
    {
      id: 'keys',
      fileName: 'device_identity_credentials.sig.enc',
      category: 'Hardware Identity (IMEI, Serial, ED25519 Passkeys & Passwords)',
      sizeKb: 16.4,
      cipher: 'ED25519 Sovereign Signature',
      icon: Key,
      status: 'QUEUED',
      progress: 0
    },
    {
      id: 'manifest',
      fileName: 'decentralized_storage_manifest.jmbk',
      category: 'Full Sealed Backup Bundle & 50M Peer Merkle Root',
      sizeKb: 240.0,
      cipher: 'Lossless .jmbk Encrypted Container',
      icon: HardDrive,
      status: 'QUEUED',
      progress: 0
    }
  ];

  const [files, setFiles] = useState<EncryptingFileItem[]>(initialFiles);

  useEffect(() => {
    if (!isActive) {
      setOverallProgress(0);
      setCurrentFileIndex(0);
      setIsFinished(false);
      setFiles(initialFiles.map(f => ({ ...f, status: 'QUEUED', progress: 0 })));
      return;
    }

    let isMounted = true;
    setIsFinished(false);
    setOverallProgress(5);

    const runSimulation = async () => {
      const stepDuration = mode === 'AUTO' ? 140 : 380;

      for (let i = 0; i < initialFiles.length; i++) {
        if (!isMounted) return;
        setCurrentFileIndex(i);

        // Mark current file as ENCRYPTING
        setFiles(prev =>
          prev.map((f, idx) =>
            idx === i
              ? { ...f, status: 'ENCRYPTING', progress: 45 }
              : idx < i
              ? { ...f, status: 'ENCRYPTED_AND_WRITTEN', progress: 100 }
              : { ...f, status: 'QUEUED', progress: 0 }
          )
        );

        setCipherHexStream(
          `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}...CIPHER_STREAM_BLOCK_${i + 1}`
        );
        setThroughputMbps(parseFloat((16 + Math.random() * 8).toFixed(1)));
        setOverallProgress(Math.round(((i + 0.5) / initialFiles.length) * 100));

        await new Promise(r => setTimeout(r, stepDuration));

        if (!isMounted) return;

        // Mark current file as ENCRYPTED_AND_WRITTEN
        setFiles(prev =>
          prev.map((f, idx) =>
            idx <= i
              ? { ...f, status: 'ENCRYPTED_AND_WRITTEN', progress: 100 }
              : { ...f, status: 'QUEUED', progress: 0 }
          )
        );

        setOverallProgress(Math.round(((i + 1) / initialFiles.length) * 100));
        await new Promise(r => setTimeout(r, 60));
      }

      if (isMounted) {
        setOverallProgress(100);
        setIsFinished(true);
        if (onComplete) onComplete();
      }
    };

    runSimulation();

    return () => {
      isMounted = false;
    };
  }, [isActive, mode]);

  if (!isActive && !isFinished) {
    return null;
  }

  const mediaLabel = targetMedia.replace(/_/g, ' ');

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="w-full bg-slate-950/95 border-2 border-cyan-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl backdrop-blur-xl space-y-4 font-mono text-xs text-slate-200"
    >
      {/* Header telemetry */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            <Lock className={`w-5 h-5 ${!isFinished ? 'animate-pulse' : ''}`} />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <h3 className="font-bold text-white text-sm sm:text-base font-serif">
                LOSSLESS ENCRYPTION ENGINE • REAL-TIME BACKUP STREAM
              </h3>
            </div>
            <p className="text-[11px] text-slate-400">
              Encrypting & streaming files losslessly to connected <strong className="text-amber-300">{mediaLabel}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 self-end sm:self-auto text-[11px]">
          <div className="px-3 py-1 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 flex items-center space-x-1.5 font-bold">
            {!isFinished ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>{isFinished ? 'ENCRYPTION COMPLETE' : `ENCRYPTING ${overallProgress}%`}</span>
          </div>
          <div className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-[10px]">
            {throughputMbps} MB/s
          </div>
        </div>
      </div>

      {/* Real-time Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-400">
            {!isFinished
              ? `Currently Encrypting: ${files[currentFileIndex]?.fileName || 'Compiling vault...'}`
              : `✓ All 6 Data Partitions Losslessly Encrypted & Written to ${mediaLabel}`}
          </span>
          <span className="text-cyan-400 font-bold">{overallProgress}%</span>
        </div>

        <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 shadow-[0_0_15px_rgba(6,182,212,0.8)]"
            initial={{ width: '0%' }}
            animate={{ width: `${overallProgress}%` }}
            transition={{ ease: 'easeOut', duration: 0.2 }}
          />
        </div>
      </div>

      {/* Live File Encryption Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
        {files.map((file, idx) => {
          const Icon = file.icon;
          const isCurrent = !isFinished && currentFileIndex === idx;
          const isDone = file.status === 'ENCRYPTED_AND_WRITTEN';

          return (
            <div
              key={file.id}
              className={`p-3 rounded-2xl border transition-all duration-200 flex items-start space-x-3 ${
                isCurrent
                  ? 'bg-slate-900/90 border-cyan-400 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-400/40'
                  : isDone
                  ? 'bg-slate-900/60 border-emerald-500/30'
                  : 'bg-slate-900/30 border-slate-800/80 opacity-50'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                  isDone
                    ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-400'
                    : isCurrent
                    ? 'bg-cyan-500/20 border-cyan-400/60 text-cyan-300 animate-pulse'
                    : 'bg-slate-800 border-slate-700 text-slate-500'
                }`}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : isCurrent ? (
                  <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                ) : (
                  <Icon className="w-4 h-4 text-slate-400" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white truncate font-mono">
                    {file.fileName}
                  </span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-black uppercase ${
                      isDone
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                        : isCurrent
                        ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-400 animate-pulse'
                        : 'bg-slate-900 text-slate-500 border border-slate-800'
                    }`}
                  >
                    {isDone ? 'WRITTEN' : isCurrent ? 'ENCRYPTING' : 'QUEUED'}
                  </span>
                </div>

                <div className="text-[10px] text-slate-400 truncate mt-0.5">
                  {file.category}
                </div>

                <div className="flex items-center justify-between text-[9px] text-slate-500 mt-1 pt-1 border-t border-slate-850">
                  <span className="text-cyan-300/80 font-mono">{file.cipher}</span>
                  <span>{file.sizeKb} KB</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Hex Stream & Target Path Footer */}
      <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[10px] text-slate-400 font-mono">
        <div className="flex items-center space-x-2 truncate">
          <span className="text-cyan-400 font-bold">CIPHER STREAM:</span>
          <span className="text-slate-300 truncate">{cipherHexStream}</span>
        </div>
        <div className="shrink-0 text-emerald-400 font-bold">
          {isFinished ? `✓ Written to ${mediaLabel}` : 'Lossless AES-256 Pipeline'}
        </div>
      </div>
    </motion.div>
  );
};
