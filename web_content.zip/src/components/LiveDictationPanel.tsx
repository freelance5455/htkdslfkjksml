import { useEffect, useRef } from 'react';
import { ArrowDown, Loader2, Mic, Square } from 'lucide-react';
import {
  findLanguageByCode,
  resolveEffectiveOutputLanguage,
  SAME_AS_SPEAKING_CODE,
} from '../constants/languages';
import { LiveDictationState } from '../types/recorder';
import { getTextDirection, getTranscriptFontClass } from '../utils/formatting';

interface LiveDictationPanelProps {
  liveState: LiveDictationState;
  speakingCode: string;
  outputCode: string;
  isCommittingNext: boolean;
  onToggleListening: () => void;
  onNext: () => void;
}

/**
 * Keeps the newest spoken words visible inside a single-line horizontal strip
 * by sliding older text smoothly to the side without ever scrolling the page vertically.
 */
function scrollHorizontalToLatest(el: HTMLElement | null, dir: 'rtl' | 'ltr') {
  if (!el) return;
  const maxScroll = Math.max(0, el.scrollWidth - el.clientWidth);
  if (maxScroll === 0) return;

  if (dir === 'ltr') {
    el.scrollLeft = maxScroll;
  } else {
    // Modern Chromium/WebKit/Gecko use negative scrollLeft from 0 (right edge) to -maxScroll (left/latest edge)
    el.scrollLeft = -maxScroll;
  }
}

export function LiveDictationPanel({
  liveState,
  speakingCode,
  outputCode,
  isCommittingNext,
  onToggleListening,
  onNext,
}: LiveDictationPanelProps) {
  const rawTickerRef = useRef<HTMLDivElement | null>(null);
  const translatedTickerRef = useRef<HTMLDivElement | null>(null);

  const speakingLang = findLanguageByCode(speakingCode);
  const effectiveOutputLang = resolveEffectiveOutputLanguage(speakingCode, outputCode);
  const isTranslatingMode =
    outputCode !== SAME_AS_SPEAKING_CODE && effectiveOutputLang.code !== speakingCode;

  const combinedRaw = [liveState.liveRawText, liveState.interimRawText]
    .filter(Boolean)
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();

  const cleanedTranslated = liveState.liveTranslatedText
    .replace(/\s+/g, ' ')
    .trim();

  const hasDraft = combinedRaw.length > 0;

  const rawDir = getTextDirection(speakingCode, combinedRaw);
  const rawFont = getTranscriptFontClass(speakingCode, combinedRaw);

  const translatedDir = getTextDirection(
    effectiveOutputLang.code,
    cleanedTranslated
  );
  const translatedFont = getTranscriptFontClass(
    effectiveOutputLang.code,
    cleanedTranslated
  );

  // Slide single-line spoken strip horizontally to keep latest words in view
  useEffect(() => {
    scrollHorizontalToLatest(rawTickerRef.current, rawDir);
  }, [combinedRaw, rawDir]);

  // Slide single-line live translation strip horizontally as well
  useEffect(() => {
    if (isTranslatingMode) {
      scrollHorizontalToLatest(translatedTickerRef.current, translatedDir);
    }
  }, [cleanedTranslated, isTranslatingMode, translatedDir]);

  return (
    <section
      aria-label="Live Voice Input"
      className="flex flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] sm:p-5"
    >
      {/* Top Status & Live Audio Bars */}
      <div>
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            {liveState.isListening && (
              <span
                aria-hidden="true"
                className="h-2 w-2 shrink-0 rounded-full bg-rose-600 animate-pulse"
              />
            )}
            <span className="truncate text-sm font-semibold text-slate-900">
              {liveState.isListening ? 'Listening...' : 'Live Voice'}
            </span>
          </div>

          {liveState.isListening ? (
            <div
              className="flex h-5 items-center gap-[3px]"
              aria-label="Microphone activity"
            >
              {liveState.waveformBars.slice(-14).map((bar, idx) => (
                <span
                  key={idx}
                  className="w-[2.5px] rounded-full bg-blue-600 transition-all duration-75"
                  style={{ height: `${Math.max(4, Math.round(bar * 20))}px` }}
                />
              ))}
            </div>
          ) : (
            <span className="text-xs text-slate-400">
              {isTranslatingMode
                ? `${speakingLang.englishName} → ${effectiveOutputLang.englishName}`
                : speakingLang.englishName}
            </span>
          )}
        </div>

        {/* Single-Line Horizontal Live Voice Strip (slides older words to the side, never grows tall) */}
        <div className="rounded-xl border border-slate-100 bg-slate-50/80 px-3.5 py-2.5">
          {hasDraft ? (
            <div className="space-y-2">
              <div className="relative">
                {/* Soft edge fade on the trailing side where older spoken words glide away */}
                <div
                  aria-hidden="true"
                  className={`pointer-events-none absolute inset-y-0 z-10 w-7 ${
                    rawDir === 'rtl'
                      ? 'right-0 bg-gradient-to-l from-slate-50/95 to-transparent'
                      : 'left-0 bg-gradient-to-r from-slate-50/95 to-transparent'
                  }`}
                />
                <div
                  ref={rawTickerRef}
                  dir={rawDir}
                  data-testid="live-voice-ticker"
                  className={`no-scrollbar flex h-11 items-center overflow-x-auto whitespace-nowrap touch-pan-x text-base text-slate-900 ${rawFont}`}
                >
                  <span className="inline-block px-1">
                    {liveState.liveRawText.replace(/\s+/g, ' ').trim()}
                    {liveState.interimRawText ? (
                      <span className="text-slate-400">
                        {liveState.liveRawText ? ' ' : ''}
                        {liveState.interimRawText.replace(/\s+/g, ' ').trim()}
                      </span>
                    ) : null}
                  </span>
                </div>
              </div>

              {isTranslatingMode && (
                <div className="border-t border-slate-200/80 pt-2">
                  <div className="relative">
                    <div
                      aria-hidden="true"
                      className={`pointer-events-none absolute inset-y-0 z-10 w-7 ${
                        translatedDir === 'rtl'
                          ? 'right-0 bg-gradient-to-l from-slate-50/95 to-transparent'
                          : 'left-0 bg-gradient-to-r from-slate-50/95 to-transparent'
                      }`}
                    />
                    <div
                      ref={translatedTickerRef}
                      dir={translatedDir}
                      className={`no-scrollbar flex h-10 items-center overflow-x-auto whitespace-nowrap touch-pan-x text-sm text-blue-700 ${translatedFont}`}
                    >
                      {cleanedTranslated ? (
                        <span className="inline-block px-1">{cleanedTranslated}</span>
                      ) : (
                        <span dir="ltr" className="font-sans text-xs text-slate-400">
                          Translating live to {effectiveOutputLang.englishName}...
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex h-11 items-center justify-center overflow-hidden text-center">
              <p className="truncate text-sm text-slate-400">
                {liveState.isListening
                  ? `Speak now in ${speakingLang.englishName}...`
                  : 'Tap Start Speaking to begin'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Primary Action Controls: Start/Stop + Next */}
      <div className="mt-3.5 flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleListening}
          className={`flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold whitespace-nowrap transition-all active:scale-[0.98] ${
            liveState.isListening
              ? 'bg-rose-600 text-white shadow-sm shadow-rose-600/20 hover:bg-rose-700'
              : 'bg-blue-600 text-white shadow-sm shadow-blue-600/20 hover:bg-blue-700'
          }`}
        >
          {liveState.isListening ? (
            <>
              <Square className="h-4 w-4 fill-current shrink-0" aria-hidden="true" />
              <span>Stop</span>
            </>
          ) : (
            <>
              <Mic className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Start Speaking</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onNext}
          disabled={!hasDraft || isCommittingNext}
          className={`flex min-h-[48px] min-w-[116px] items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-semibold whitespace-nowrap transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45 ${
            hasDraft
              ? 'border-slate-900 bg-slate-900 text-white hover:bg-slate-800'
              : 'border-slate-200 bg-white text-slate-500'
          }`}
        >
          {isCommittingNext ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin shrink-0" aria-hidden="true" />
              <span>Placing...</span>
            </>
          ) : (
            <>
              <span>Next</span>
              <ArrowDown className="h-4 w-4 shrink-0" aria-hidden="true" />
            </>
          )}
        </button>
      </div>
    </section>
  );
}
