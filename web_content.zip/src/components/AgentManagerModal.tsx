import React, { useState } from 'react';
import { Agent, LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { Bot, Plus, Trash2, Check, X, Sparkles, UserCheck, Flame, ShieldAlert } from 'lucide-react';

interface AgentManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  agents: Agent[];
  activeAgentId: string;
  onSelectAgent: (agentId: string) => void;
  onCreateAgent: (agent: Omit<Agent, 'id' | 'createdAt'>) => void;
  onDeleteAgent: (agentId: string) => void;
  language: LanguageCode;
}

export const AgentManagerModal: React.FC<AgentManagerModalProps> = ({
  isOpen,
  onClose,
  agents,
  activeAgentId,
  onSelectAgent,
  onCreateAgent,
  onDeleteAgent,
  language,
}) => {
  const [tab, setTab] = useState<'list' | 'create'>('list');
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [customInstructions, setCustomInstructions] = useState('');
  const [selectedColor, setSelectedColor] = useState('cyan');
  const [agentToDelete, setAgentToDelete] = useState<Agent | null>(null);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  if (!isOpen) return null;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onCreateAgent({
      name: name.trim(),
      role: role.trim() || 'YouTube Trend & Viral Growth Agent',
      customInstructions: customInstructions.trim(),
      avatar: '🤖',
      color: selectedColor,
      isDefault: false,
      isCustom: true,
    });

    setName('');
    setRole('');
    setCustomInstructions('');
    setTab('list');
  };

  const confirmDeleteAction = () => {
    if (agentToDelete) {
      onDeleteAgent(agentToDelete.id);
      setAgentToDelete(null);
    }
  };

  const COLOR_OPTIONS = [
    { id: 'cyan', class: 'bg-cyan-500 ring-cyan-400' },
    { id: 'pink', class: 'bg-pink-500 ring-pink-400' },
    { id: 'amber', class: 'bg-amber-500 ring-amber-400' },
    { id: 'emerald', class: 'bg-emerald-500 ring-emerald-400' },
    { id: 'violet', class: 'bg-violet-500 ring-violet-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-zinc-950 shadow-2xl p-6 relative overflow-hidden flex flex-col max-h-[85vh]">
        {/* Top RGB bar */}
        <div className="absolute top-0 left-0 right-0 h-1 rgb-gradient-border" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {t.switchAgent}
              </h3>
              <p className="text-xs text-zinc-400">
                Create, switch, or delete custom YouTube Viral Agents
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 p-1 bg-zinc-900 rounded-xl mb-4 border border-white/5">
          <button
            onClick={() => setTab('list')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              tab === 'list'
                ? 'bg-zinc-800 text-white shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Active Agents ({agents.length})
          </button>
          <button
            onClick={() => setTab('create')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
              tab === 'create'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            {t.createNewAgent}
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto pr-1">
          {tab === 'list' ? (
            <div className="space-y-2.5">
              {agents.map(ag => {
                const isActive = ag.id === activeAgentId;
                return (
                  <div
                    key={ag.id}
                    className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                      isActive
                        ? 'border-cyan-500/50 bg-cyan-950/20 shadow-[0_0_15px_rgba(0,255,255,0.15)]'
                        : 'border-white/5 bg-zinc-900/60 hover:bg-zinc-900'
                    }`}
                  >
                    <div
                      className="flex items-center gap-3 cursor-pointer flex-1"
                      onClick={() => {
                        onSelectAgent(ag.id);
                        onClose();
                      }}
                    >
                      <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-xl shrink-0">
                        {ag.avatar}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">
                            {ag.name}
                          </span>
                          {ag.isDefault && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-zinc-400 font-mono">
                              Default
                            </span>
                          )}
                          {ag.isCustom && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                              Custom
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-zinc-400 mt-0.5 line-clamp-1">
                          {ag.role}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {isActive ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-cyan-400 bg-cyan-950/60 px-2.5 py-1 rounded-lg border border-cyan-800/40">
                          <Check className="w-3.5 h-3.5" /> Selected
                        </span>
                      ) : (
                        <button
                          onClick={() => {
                            onSelectAgent(ag.id);
                            onClose();
                          }}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-300 font-medium"
                        >
                          Select
                        </button>
                      )}

                      {/* Delete Agent Button (Available for custom agents, or allow deleting any non-primary agent) */}
                      {agents.length > 1 && (
                        <button
                          title={t.deleteAgent}
                          onClick={() => setAgentToDelete(ag)}
                          className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <form onSubmit={handleCreateSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  {t.agentName} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Viral Shorts 3-Sec Hook Hacker"
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  {t.agentRole}
                </label>
                <input
                  type="text"
                  value={role}
                  onChange={e => setRole(e.target.value)}
                  placeholder="e.g. Specializes in finding trending Bollywood phonk songs & CTR titles"
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  {t.agentInstructions}
                </label>
                <textarea
                  rows={3}
                  value={customInstructions}
                  onChange={e => setCustomInstructions(e.target.value)}
                  placeholder="Provide any custom personality, channel niche, or specific rules for this viral growth agent..."
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Agent Accent Color
                </label>
                <div className="flex items-center gap-2">
                  {COLOR_OPTIONS.map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedColor(c.id)}
                      className={`w-7 h-7 rounded-full ${c.class} transition-all ${
                        selectedColor === c.id ? 'ring-2 ring-offset-2 ring-offset-black scale-110' : 'opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs tracking-wider uppercase transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  {t.createBtn}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Delete Confirmation Alert Modal */}
        {agentToDelete && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-2xl border border-rose-500/40 bg-zinc-950 p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-3 border border-rose-500/30">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>
              <h4 className="text-base font-bold text-white mb-1">
                {t.deleteAgent}: "{agentToDelete.name}"?
              </h4>
              <p className="text-xs text-zinc-400 mb-4">
                {t.deleteAgentConfirm}
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAgentToDelete(null)}
                  className="flex-1 py-2 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold hover:bg-zinc-700"
                >
                  {t.cancel}
                </button>
                <button
                  onClick={confirmDeleteAction}
                  className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30"
                >
                  {t.confirmDelete}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
