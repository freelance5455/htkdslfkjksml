import { useEffect, useRef, useState } from "react";
import { ArrowLeft, MessagesSquare, Search, Send } from "lucide-react";
import { toast } from "sonner";
import {
  listMessages,
  listThreads,
  searchReaders,
  sendMessage,
  type ChatLine,
  type ReaderCard,
  type ThreadPreview,
} from "@/lib/library-api";
import { errorText, formatWhen, initials } from "@/components/bits";

export function ChatPanel({ myPublicId }: { myPublicId: string }) {
  const [query, setQuery] = useState("");
  const [people, setPeople] = useState<ReaderCard[]>([]);
  const [threads, setThreads] = useState<ThreadPreview[]>([]);
  const [active, setActive] = useState<ReaderCard | null>(null);
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      searchReaders({ data: query })
        .then((rows) => {
          if (!cancelled) setPeople(rows);
        })
        .catch((err: unknown) => {
          if (!cancelled) toast.error(errorText(err));
        });
    }, 200);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [query]);

  useEffect(() => {
    let cancelled = false;
    listThreads()
      .then((rows) => {
        if (!cancelled) setThreads(rows);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    const pull = () => {
      listMessages({ data: active.publicId })
        .then((rows) => {
          if (!cancelled) setLines(rows);
        })
        .catch(() => undefined);
    };
    pull();
    const timer = window.setInterval(pull, 4000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [active]);

  useEffect(() => {
    const node = scroller.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [lines, active]);

  async function submit() {
    if (!active || sending) return;
    const body = draft.trim();
    if (!body) return;
    setSending(true);
    try {
      const line = await sendMessage({ data: { publicId: active.publicId, body } });
      setLines((current) => [...current, line]);
      setDraft("");
      const threadsNext = await listThreads();
      setThreads(threadsNext);
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setSending(false);
    }
  }

  return (
    <section className="space-y-4">
      <div>
        <p className="text-xs font-semibold tracking-widest text-accent uppercase">Between readers</p>
        <h2 className="mt-1 font-display text-3xl">Chat</h2>
        <p className="mt-1 text-sm text-muted">
          Your ID is <span className="font-semibold text-ink">{myPublicId}</span>. Search another reader by name or ID.
        </p>
      </div>
      <div className="chat-shell">
        <div className={`lift flex min-h-80 flex-col p-4 ${active ? "hidden md:flex" : "flex"}`}>
          <label className="mb-3 flex h-11 items-center gap-2 rounded-xl border border-line bg-paper px-3">
            <Search className="size-4 text-muted" />
            <input
              id="reader-search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Name or reader ID"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted"
            />
          </label>
          <div className="min-h-0 flex-1 space-y-1 overflow-auto">
            {threads.length > 0 && !query.trim() && (
              <p className="px-2 pb-1 text-xs font-semibold tracking-wide text-muted uppercase">Recent</p>
            )}
            {!query.trim() &&
              threads.map((thread) => (
                <ReaderRow
                  key={thread.publicId}
                  person={thread}
                  detail={thread.lastBody}
                  active={active?.publicId === thread.publicId}
                  onPick={() => {
                    setActive(thread);
                    setLines([]);
                  }}
                />
              ))}
            <p className="px-2 pt-3 pb-1 text-xs font-semibold tracking-wide text-muted uppercase">Readers</p>
            {people.length === 0 ? (
              <p className="px-2 py-6 text-sm text-muted">
                No other readers yet. When someone else creates an account, they will show up here.
              </p>
            ) : (
              people.map((person) => (
                <ReaderRow
                  key={person.publicId}
                  person={person}
                  detail={person.publicId}
                  active={active?.publicId === person.publicId}
                  onPick={() => {
                    setActive(person);
                    setLines([]);
                  }}
                />
              ))
            )}
          </div>
        </div>

        <div className={`lift min-h-80 flex-col overflow-hidden ${active ? "flex" : "hidden md:flex"}`}>
          {active ? (
            <>
              <div className="flex items-center gap-3 border-b border-line px-4 py-3">
                <button type="button" className="btn btn-ghost size-11 px-0 md:hidden" aria-label="Back to readers" onClick={() => setActive(null)}>
                  <ArrowLeft className="size-4" />
                </button>
                <Avatar name={active.name} />
                <div className="min-w-0">
                  <h3 className="truncate font-display text-xl">{active.name}</h3>
                  <p className="truncate text-xs text-muted">{active.publicId}</p>
                </div>
              </div>
              <div ref={scroller} className="chat-log flex-1 space-y-3 overflow-auto px-4 py-4">
                {lines.length === 0 ? (
                  <p className="pt-10 text-center text-sm text-muted">Start the conversation.</p>
                ) : (
                  lines.map((line) => (
                    <div key={line.id} className={`flex ${line.fromMe ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs rounded-2xl px-3 py-2 text-sm ${
                          line.fromMe ? "bg-primary text-primary-fg" : "border border-line bg-surface text-ink"
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{line.body}</p>
                        <p className={`mt-1 text-right text-xs ${line.fromMe ? "bubble-time" : "text-muted"}`}>
                          {formatWhen(line.createdAt)}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <form
                className="flex gap-2 border-t border-line p-3"
                onSubmit={(event) => {
                  event.preventDefault();
                  void submit();
                }}
              >
                <textarea
                  id="chat-draft"
                  value={draft}
                  rows={1}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      void submit();
                    }
                  }}
                  placeholder="Write a message"
                  className="field-input h-11 py-2"
                />
                <button type="submit" className="btn btn-primary size-11 px-0" disabled={sending} aria-label="Send message">
                  <Send className="size-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="grid flex-1 place-items-center px-6 text-center">
              <div>
                <MessagesSquare className="mx-auto size-8 text-primary" />
                <p className="mt-3 font-display text-2xl">Choose a reader</p>
                <p className="mt-1 text-sm text-muted">Messages stay between the two of you.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Avatar({ name }: { name: string }) {
  return (
    <span className="grid size-11 shrink-0 place-items-center rounded-full bg-primary-soft font-semibold text-primary">
      {initials(name)}
    </span>
  );
}

function ReaderRow({
  person,
  detail,
  active,
  onPick,
}: {
  person: ReaderCard;
  detail: string;
  active: boolean;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onPick}
      className={`flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left ${active ? "bg-primary-soft" : "hover:bg-paper"}`}
    >
      <Avatar name={person.name} />
      <span className="min-w-0">
        <span className="block truncate text-sm font-semibold">{person.name}</span>
        <span className="block truncate text-xs text-muted">{detail}</span>
      </span>
    </button>
  );
}
