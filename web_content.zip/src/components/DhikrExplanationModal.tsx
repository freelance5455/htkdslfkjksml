import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  BookOpen, 
  HeartHandshake, 
  Share2, 
  Copy, 
  Check, 
  ScrollText, 
  ZoomIn, 
  ZoomOut,
  Info
} from 'lucide-react';
import { DhikrItem } from '../types';
import { getDhikrExplanation, DhikrExplanationData } from '../data/dhikrExplanations';
import { IslamicArchBorder } from './IslamicPattern';
import { DEDICATION_TEXT } from '../data/adhkarData';

interface DhikrExplanationModalProps {
  dhikr: DhikrItem;
  isOpen: boolean;
  onClose: () => void;
  showToast: (message: string) => void;
}

export const DhikrExplanationModal: React.FC<DhikrExplanationModalProps> = ({
  dhikr,
  isOpen,
  onClose,
  showToast,
}) => {
  const [copied, setCopied] = useState(false);
  const [modalTextSize, setModalTextSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [activeTab, setActiveTab] = useState<'all' | 'virtue' | 'meaning' | 'tadabbur'>('all');

  if (!isOpen) return null;

  const data: DhikrExplanationData | null = getDhikrExplanation(dhikr.id, dhikr.title);

  const getTextSizeClass = () => {
    switch (modalTextSize) {
      case 'large':
        return 'text-base md:text-lg leading-relaxed';
      case 'xlarge':
        return 'text-lg md:text-xl leading-loose';
      case 'normal':
      default:
        return 'text-sm md:text-base leading-relaxed';
    }
  };

  const handleCopy = async () => {
    if (!data) return;
    const textToCopy = `✨ فضل وتفسير: ${dhikr.title} ✨\n\n` +
      `📜 نص الذكر:\n${dhikr.text}\n\n` +
      `🌟 فضل الذكر:\n${data.virtue}\n\n` +
      `📖 معاني الكلمات والتفسير:\n${data.meaning}\n\n` +
      `💭 وقفة تدبرية:\n${data.tadabbur}\n\n` +
      `📌 المصدر: ${data.source}\n\n` +
      `${DEDICATION_TEXT.appName} - ${DEDICATION_TEXT.subTitle}`;

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        showToast('تم نسخ فضل وتفسير الذكر بنجاح ✨');
        setTimeout(() => setCopied(false), 2000);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = textToCopy;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopied(true);
        showToast('تم نسخ فضل وتفسير الذكر بنجاح ✨');
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      showToast('تعذر النسخ');
    }
  };

  const handleShare = async () => {
    if (!data) return;
    const shareText = `✨ فضل وتفسير: ${dhikr.title} ✨\n\n` +
      `${dhikr.text}\n\n` +
      `🌟 الفضل: ${data.virtue}\n\n` +
      `📖 التفسير: ${data.meaning}\n\n` +
      `📌 المصدر: ${data.source}\n\n` +
      `${DEDICATION_TEXT.appName}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `فضل وتفسير ${dhikr.title}`,
          text: shareText,
        });
      } catch {
        // Cancelled or unsupported
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="explanation-modal-title"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl max-h-[92vh] sm:max-h-[88vh] bg-[#ffffff] dark:bg-[#031d15] border-t sm:border border-emerald-600/30 dark:border-emerald-700/60 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden text-right"
        onClick={(e) => e.stopPropagation()}
        dir="rtl"
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-10 bg-[#f7faf8]/95 dark:bg-[#04241a]/95 backdrop-blur-md px-5 py-3.5 border-b border-emerald-600/15 dark:border-emerald-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/15 dark:bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-600 dark:text-amber-400 shadow-2xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="explanation-modal-title" className="text-base sm:text-lg font-black text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                  فضل وتفسير الذكر
                </h3>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-700/15 text-emerald-800 dark:text-emerald-300 border border-emerald-600/30 font-tajawal">
                  {dhikr.categoryArabic}
                </span>
              </div>
              <p className="text-xs text-[#3a6752] dark:text-[#8fc4ab] font-tajawal font-bold mt-0.5">
                {dhikr.title}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Text Zoom Controls */}
            <div className="hidden xs:flex items-center bg-emerald-900/10 dark:bg-emerald-950/60 p-0.5 rounded-xl border border-emerald-600/20">
              <button
                onClick={() => setModalTextSize('normal')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                  modalTextSize === 'normal' 
                    ? 'bg-emerald-700 text-white shadow-2xs' 
                    : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                }`}
                title="حجم خط عادي"
                aria-label="حجم خط عادي"
              >
                A
              </button>
              <button
                onClick={() => setModalTextSize('large')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                  modalTextSize === 'large' 
                    ? 'bg-emerald-700 text-white shadow-2xs' 
                    : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                }`}
                title="حجم خط متوسط"
                aria-label="حجم خط متوسط"
              >
                A+
              </button>
              <button
                onClick={() => setModalTextSize('xlarge')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                  modalTextSize === 'xlarge' 
                    ? 'bg-emerald-700 text-white shadow-2xs' 
                    : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                }`}
                title="حجم خط كبير"
                aria-label="حجم خط كبير"
              >
                A++
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/15 dark:hover:bg-emerald-900/40 transition-colors cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Filter */}
        <div className="px-5 pt-3 pb-2 bg-[#fbfdfc] dark:bg-[#031d15] border-b border-emerald-600/10 dark:border-emerald-800/40 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'all'
                ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-900/5 dark:bg-emerald-950/40 text-[#2b5945] dark:text-[#a5d8c1] hover:bg-emerald-500/15'
            }`}
          >
            عرض شامل
          </button>
          <button
            onClick={() => setActiveTab('virtue')}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
              activeTab === 'virtue'
                ? 'bg-amber-600 dark:bg-amber-500 text-white shadow-xs'
                : 'bg-amber-500/10 text-amber-800 dark:text-amber-300 hover:bg-amber-500/20'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>فضل الذكر</span>
          </button>
          <button
            onClick={() => setActiveTab('meaning')}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
              activeTab === 'meaning'
                ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-900/5 dark:bg-emerald-950/40 text-[#2b5945] dark:text-[#a5d8c1] hover:bg-emerald-500/15'
            }`}
          >
            <BookOpen className="w-3 h-3" />
            <span>التفسير والمعاني</span>
          </button>
          <button
            onClick={() => setActiveTab('tadabbur')}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
              activeTab === 'tadabbur'
                ? 'bg-teal-700 dark:bg-teal-600 text-white shadow-xs'
                : 'bg-teal-500/10 text-teal-800 dark:text-teal-300 hover:bg-teal-500/20'
            }`}
          >
            <HeartHandshake className="w-3 h-3" />
            <span>وقفة تدبرية</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 font-tajawal">
          {/* Quick Dhikr Preview Card */}
          <div className="bg-[#f0f7f3] dark:bg-[#05261b] border border-emerald-600/25 dark:border-emerald-700/50 rounded-2xl p-4 text-center relative overflow-hidden shadow-xs">
            <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 font-cairo block mb-1">
              نص الذكر الشريف:
            </span>
            <p className="font-quran text-base sm:text-lg text-[#0c2e20] dark:text-[#e4f2ea] leading-loose selection:bg-amber-200">
              {dhikr.text}
            </p>
          </div>

          <IslamicArchBorder className="text-emerald-600/30 my-1" />

          {data ? (
            <>
              {/* SECTION 1: فضل الذكر وثوابه (Virtue & Merit) */}
              {(activeTab === 'all' || activeTab === 'virtue') && (
                <div className="bg-gradient-to-br from-amber-500/10 via-amber-400/5 to-transparent dark:from-amber-950/40 dark:via-emerald-950/20 dark:to-transparent border border-amber-500/30 dark:border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-xs transition-all">
                  <div className="flex items-center gap-2 mb-2.5">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm sm:text-base font-extrabold text-amber-900 dark:text-amber-300 font-cairo">
                      فضل الذكر وثوابه في السنة النبوية
                    </h4>
                  </div>
                  <div className={`text-[#143d2b] dark:text-[#e1efe8] font-medium ${getTextSizeClass()}`}>
                    <p className="whitespace-pre-line leading-relaxed">
                      {data.virtue}
                    </p>
                  </div>
                </div>
              )}

              {/* SECTION 2: التفسير ومعاني الكلمات (Explanation & Meaning) */}
              {(activeTab === 'all' || activeTab === 'meaning') && (
                <div className="bg-[#f6fbf8] dark:bg-[#04271c] border border-emerald-600/20 dark:border-emerald-800/60 rounded-2xl p-4 sm:p-5 shadow-xs transition-all">
                  <div className="flex items-center gap-2 mb-2.5">
                    <div className="w-7 h-7 rounded-lg bg-emerald-600/15 text-emerald-700 dark:text-emerald-400 flex items-center justify-center">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm sm:text-base font-extrabold text-emerald-900 dark:text-emerald-200 font-cairo">
                      معاني الكلمات والتفسير المبسط
                    </h4>
                  </div>
                  <div className={`text-[#143d2b] dark:text-[#e1efe8] font-medium space-y-2 ${getTextSizeClass()}`}>
                    {data.meaning.split('\n').map((line, idx) => (
                      <p key={idx} className="leading-relaxed">
                        {line}
                      </p>
                    ))}
                  </div>
                </div>
              )}

              {/* SECTION 3: وقفة تدبرية (Contemplation & Heart Reflection) */}
              {(activeTab === 'all' || activeTab === 'tadabbur') && (
                <div className="bg-[#eef8f3] dark:bg-[#052b1e] border border-teal-600/25 dark:border-teal-700/50 rounded-2xl p-4 sm:p-5 shadow-xs transition-all">
                  <div className="flex items-center gap-2 mb-2.5">
                    <div className="w-7 h-7 rounded-lg bg-teal-500/20 text-teal-700 dark:text-teal-300 flex items-center justify-center">
                      <HeartHandshake className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm sm:text-base font-extrabold text-teal-900 dark:text-teal-200 font-cairo">
                      وقفة تدبرية وأثر الذكر في القلب واليوم
                    </h4>
                  </div>
                  <div className={`text-[#143d2b] dark:text-[#e1efe8] font-medium ${getTextSizeClass()}`}>
                    <p className="leading-relaxed">
                      {data.tadabbur}
                    </p>
                  </div>
                </div>
              )}

              {/* SECTION 4: المصدر وتخريج الحديث (Source Reference) */}
              <div className="bg-emerald-900/5 dark:bg-emerald-950/50 border border-emerald-600/15 dark:border-emerald-800/40 rounded-xl p-3 flex items-start gap-2 text-xs text-[#2b5945] dark:text-[#97cbaf]">
                <ScrollText className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold font-cairo block text-emerald-900 dark:text-emerald-200">
                    تخريج الحديث والمصدر المعتمد:
                  </span>
                  <span className="font-tajawal mt-0.5 block">
                    {data.source}
                  </span>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-8 space-y-2">
              <Info className="w-8 h-8 text-emerald-600 mx-auto" />
              <p className="text-sm text-emerald-900 dark:text-emerald-200 font-bold">
                جاري تحديث بيانات التفسير لهذا الذكر المبارك
              </p>
              <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0]">
                جميع الأذكار مأخوذة من هدي النبي ﷺ وأصحابه الكرام.
              </p>
            </div>
          )}
        </div>

        {/* Modal Bottom Actions Bar */}
        <div className="sticky bottom-0 bg-[#f7faf8]/95 dark:bg-[#04241a]/95 backdrop-blur-md px-4 py-3 border-t border-emerald-600/15 dark:border-emerald-800/60 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 rounded-xl bg-emerald-700/15 hover:bg-emerald-700/25 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/40 border border-emerald-600/30 text-emerald-900 dark:text-emerald-200 text-xs font-bold font-cairo flex items-center gap-1.5 transition-colors cursor-pointer"
              title="نسخ الفضل والتفسير"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ' : 'نسخ الفائدة'}</span>
            </button>

            <button
              onClick={handleShare}
              className="px-3.5 py-2 rounded-xl bg-emerald-700/15 hover:bg-emerald-700/25 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/40 border border-emerald-600/30 text-emerald-900 dark:text-emerald-200 text-xs font-bold font-cairo flex items-center gap-1.5 transition-colors cursor-pointer"
              title="مشاركة الفائدة"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-600 hover:to-emerald-700 text-white text-xs font-bold font-cairo transition-all cursor-pointer shadow-xs"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
