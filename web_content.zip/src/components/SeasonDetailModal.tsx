import React, { useState } from 'react';
import { Calendar, Trophy, X, Medal, Layers } from 'lucide-react';
import type { Season, Player, Category } from '../types/index.ts';

interface SeasonDetailModalProps {
  season: Season | null;
  onClose: () => void;
  players: Player[];
  categories: Category[];
}

export const SeasonDetailModal: React.FC<SeasonDetailModalProps> = ({
  season,
  onClose,
  players,
  categories,
}) => {
  if (!season) return null;

  const [selectedCatId, setSelectedCatId] = useState<string>(
    categories.find((c) => c.status === 'active')?.id || 'cat-200g'
  );

  const getPlayer = (id: string) => players.find((p) => p.id === id);

  const snapshots = season.snapshots || {};
  const currentCatResults = snapshots[selectedCatId] || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          aria-label="Fechar detalhes da temporada"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="mb-5">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Snapshot Oficial Imutável</span>
          </div>
          <h2 className="text-xl font-black text-white">{season.name}</h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Período oficial: {season.startDate} a {season.endDate} · Fechada em {season.closedAt ? season.closedAt.slice(0, 10) : 'Data indisponível'}
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-xl mb-4 overflow-x-auto">
          {categories.filter((c) => c.status === 'active').map((cat) => {
            const isSelected = cat.id === selectedCatId;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCatId(cat.id)}
                className={`flex-1 min-w-[120px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-neutral-800 text-white border border-neutral-700'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat.name.split(' ')[0]} {cat.name.split(' ')[1]}
              </button>
            );
          })}
        </div>

        {/* Results Table */}
        <div className="space-y-2.5">
          {currentCatResults.length === 0 ? (
            <p className="text-xs text-neutral-500 py-6 text-center">
              Nenhum participante registrado nesta categoria durante esta semana.
            </p>
          ) : (
            currentCatResults.map((item) => {
              const player = getPlayer(item.playerId);
              if (!player) return null;

              return (
                <div
                  key={item.playerId}
                  className={`flex items-center justify-between p-3.5 rounded-xl border ${
                    item.isChampion
                      ? 'bg-amber-950/30 border-amber-500/40'
                      : 'bg-neutral-950/80 border-neutral-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center text-xs font-black text-neutral-400">
                      {item.rank}º
                    </span>
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white"
                      style={{ backgroundColor: player.color || '#10b981' }}
                    >
                      {player.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{player.name}</span>
                        {item.isChampion && (
                          <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
                            Campeão Oficial
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-neutral-500">
                        {item.daysTrained} dias · Maior sequência: {item.maxStreak}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-neutral-500 block uppercase">Média Final</span>
                    <span className="text-lg font-black text-white font-mono-numbers">
                      {item.formattedAverage}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
