import React from 'react';
import { Music } from 'lucide-react';

interface ArtworkImageProps {
  artworkUrl?: string;
  alt?: string;
  className?: string;
  iconSize?: number;
}

export const ArtworkImage: React.FC<ArtworkImageProps> = ({
  artworkUrl,
  alt = 'Artwork',
  className = 'w-12 h-12 rounded-lg',
  iconSize = 20,
}) => {
  const [error, setError] = React.useState(false);

  if (artworkUrl && !error) {
    return (
      <img
        src={artworkUrl}
        alt={alt}
        className={`${className} object-cover flex-shrink-0 shadow-md`}
        onError={() => setError(true)}
      />
    );
  }

  return (
    <div
      className={`${className} flex-shrink-0 flex items-center justify-center bg-gradient-to-br from-emerald-900 to-slate-900 border border-emerald-500/20 shadow-md`}
    >
      <Music size={iconSize} className="text-emerald-400" />
    </div>
  );
};
