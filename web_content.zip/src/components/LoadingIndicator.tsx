import React from "react";
import { motion } from "motion/react";
import { Feather, Sparkles } from "lucide-react";

export const LoadingIndicator: React.FC = () => {
  return (
    <div className="w-full my-6 p-6 rounded-2xl bg-gradient-to-b from-stone-900 via-emerald-950/40 to-stone-900 border border-amber-500/30 shadow-2xl text-center relative overflow-hidden">
      {/* Decorative ambient background glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(16,185,129,0.12),transparent_70%)] pointer-events-none" />

      {/* Floating Feather / Ink Pen Icon */}
      <div className="relative flex justify-center mb-3">
        <motion.div
          animate={{
            y: [-3, 4, -3],
            rotate: [-15, -5, -15],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-12 h-12 rounded-full bg-emerald-900/60 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-lg"
        >
          <Feather className="w-6 h-6" />
        </motion.div>
        
        <motion.div
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [0.8, 1.2, 0.8]
          }}
          transition={{
            duration: 1.6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-0 right-1/2 translate-x-6 text-amber-400"
        >
          <Sparkles className="w-4 h-4" />
        </motion.div>
      </div>

      {/* Required Urdu Loading Text */}
      <motion.h3
        animate={{ opacity: [0.75, 1, 0.75] }}
        transition={{ duration: 1.5, repeat: Infinity }}
        className="text-xl md:text-2xl font-bold font-urdu-title text-amber-300 mb-2 tracking-wide"
      >
        شاعر ذہن لڑا رہا ہے...
      </motion.h3>

      <p className="text-xs font-urdu-sans text-emerald-200/80 mb-5">
        بحر، قافیہ اور ردیف کا نازک امتزاج سجایا جا رہا ہے...
      </p>

      {/* Animated Loading Bar */}
      <div className="w-full max-w-sm mx-auto h-2 bg-stone-800 rounded-full overflow-hidden border border-emerald-800/50 p-0.5 relative">
        <motion.div
          className="h-full bg-gradient-to-r from-amber-500 via-emerald-400 to-amber-400 rounded-full"
          initial={{ x: "-100%" }}
          animate={{ x: "100%" }}
          transition={{
            duration: 1.8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Poetic meter pulses */}
      <div className="flex justify-center items-center gap-1.5 mt-4 text-[11px] text-stone-400 font-urdu-sans">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
        <span>فَعُولُنْ مَفَاعِيلُنْ فَعُولُنْ مَفَاعِيلُ</span>
      </div>
    </div>
  );
};
