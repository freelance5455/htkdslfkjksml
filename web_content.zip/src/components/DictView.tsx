import { useMemo, useState } from 'react';
import { Gamepad2, Search, Sparkles, Trash2 } from 'lucide-react';
import { BANDS } from '../data/constants';
import type { CefrBand, SavedWordNote, SourceType, VocabStore } from '../types';
import { searchVocab } from '../utils/vocabLogic';
import { NotebookPanel } from './NotebookModal';
import { WordRow } from './WordRow';

interface DictViewProps {
  store: VocabStore;
  favorites: number[];
  mistakes: number[];
  savedWordNotes: SavedWordNote[];
  favoriteSentences: number[];
  favoritesSet: Set<number>;
  mistakesSet: Set<number>;
  masteredSet: Set<number>;
  onOpenWordDetail: (id: number) => void;
  onSpeak: (text: string) => void;
  onToggleFavorite: (id: number) => void;
  onPlayCollection: (source: Extract<SourceType, 'mistakes' | 'favorites'>) => void;
  onClearCollection: (source: Extract<SourceType, 'mistakes' | 'favorites'>) => void;
  onOpenMistakeFixer: () => void;
  onAddWordNote: (note: SavedWordNote) => void;
  onDeleteWordNote: (noteId: string) => void;
  onToast: (msg: string) => void;
}

export function DictView({
  store,
  favorites,
  mistakes,
  savedWordNotes,
  favoriteSentences,
  favoritesSet,
  mistakesSet,
  masteredSet,
  onOpenWordDetail,
  onSpeak,
  onToggleFavorite,
  onPlayCollection,
  onClearCollection,
  onOpenMistakeFixer,
  onAddWordNote,
  onDeleteWordNote,
  onToast,
}: DictViewProps) {
  const [tab, setTab] = useState<'search' | 'mistakes' | 'favorites' | 'notebook'>('search');
  const [query, setQuery] = useState('');
  const [bandFilter, setBandFilter] = useState<CefrBand | 'ALL'>('ALL');
  const [limit, setLimit] = useState(50);

  const searchMatches = useMemo(() => {
    return searchVocab(store, query, bandFilter);
  }, [store, query, bandFilter]);

  const activeCollection = tab === 'mistakes' ? mistakes : favorites;
  const validCollection = useMemo(
    () => activeCollection.filter((id) => id >= 0 && id < store.words.length),
    [activeCollection, store.words.length]
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
          القاموس والمراجعة
        </h1>

        <div
          role="tablist"
          aria-label="أقسام القاموس"
          className="grid grid-cols-4 gap-1 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80 sm:w-[460px]"
        >
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'search'}
            onClick={() => setTab('search')}
            className={`min-h-[40px] whitespace-nowrap rounded-lg px-2 text-xs font-bold transition-colors ${
              tab === 'search' ? 'bg-indigo-600 text-white' : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            بحث
          </button>
          <button
            type="button"
            role="tab"
            data-testid="dict-tab-mistakes"
            aria-selected={tab === 'mistakes'}
            onClick={() => setTab('mistakes')}
            className={`min-h-[40px] whitespace-nowrap rounded-lg px-2 text-xs font-bold transition-colors ${
              tab === 'mistakes' ? 'bg-indigo-600 text-white' : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            الأخطاء ({mistakes.length})
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'favorites'}
            onClick={() => setTab('favorites')}
            className={`min-h-[40px] whitespace-nowrap rounded-lg px-2 text-xs font-bold transition-colors ${
              tab === 'favorites'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            المفضلة ({favorites.length})
          </button>
          <button
            type="button"
            role="tab"
            data-testid="dict-tab-notebook"
            aria-selected={tab === 'notebook'}
            onClick={() => setTab('notebook')}
            className={`min-h-[40px] whitespace-nowrap rounded-lg px-2 text-xs font-bold transition-colors ${
              tab === 'notebook'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            دفتري الشخصي
          </button>
        </div>
      </div>

      {tab === 'notebook' ? (
        <NotebookPanel
          store={store}
          favoriteWordIds={favorites}
          savedWordNotes={savedWordNotes}
          favoriteSentenceNums={favoriteSentences}
          onSpeak={onSpeak}
          onOpenWordDetail={onOpenWordDetail}
          onAddNote={onAddWordNote}
          onDeleteNote={onDeleteWordNote}
          onToast={onToast}
        />
      ) : tab === 'search' ? (
        <div className="space-y-4">
          <div className="flex flex-col gap-2.5 sm:flex-row">
            <div className="relative flex-1">
              <Search
                className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setLimit(50);
                }}
                aria-label="ابحث بكلمة إنجليزية أو عربية"
                placeholder="ابحث بأي كلمة إنجليزية أو عربية..."
                className="h-11 w-full rounded-xl border border-slate-200 bg-white pr-10 pl-4 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-100"
              />
            </div>

            <select
              aria-label="تصفية حسب مستوى CEFR"
              value={bandFilter}
              onChange={(e) => {
                setBandFilter(e.target.value as CefrBand | 'ALL');
                setLimit(50);
              }}
              className="h-11 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-100 sm:w-36"
            >
              <option value="ALL">كل المستويات</option>
              {BANDS.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            {query.trim() ? (
              <>
                النتائج المطابقة:{' '}
                <span className="font-code tabular-nums">
                  {searchMatches.length.toLocaleString('en-US')}
                </span>
              </>
            ) : (
              <>
                ابحث فورياً في{' '}
                <span className="font-code tabular-nums">
                  {store.words.length.toLocaleString('en-US')}
                </span>{' '}
                كلمة أو تصفّح أحدث الكلمات بالأسفل.
              </>
            )}
          </p>

          {query.trim() ? (
            searchMatches.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500 dark:border-slate-800 dark:bg-[#131c2e] dark:text-slate-400">
                لا توجد نتائج مطابقة لـ «{query}».
              </div>
            ) : (
              <div className="space-y-2">
                {searchMatches.slice(0, limit).map((id) => {
                  const w = store.words[id];
                  if (!w) return null;
                  return (
                    <WordRow
                      key={id}
                      word={w}
                      isFavorite={favoritesSet.has(id)}
                      isMistake={mistakesSet.has(id)}
                      isMastered={masteredSet.has(id)}
                      onOpenDetail={onOpenWordDetail}
                      onSpeak={onSpeak}
                      onToggleFavorite={onToggleFavorite}
                    />
                  );
                })}
                {searchMatches.length > limit && (
                  <button
                    type="button"
                    onClick={() => setLimit((l) => l + 50)}
                    className="h-11 w-full rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    عرض المزيد ({searchMatches.length - limit})
                  </button>
                )}
              </div>
            )
          ) : (
            <div className="space-y-2">
              {(bandFilter === 'ALL'
                ? store.words.slice(0, 20).map((w) => w.id)
                : store.byBand[bandFilter].slice(0, 20)
              ).map((id) => {
                const w = store.words[id];
                if (!w) return null;
                return (
                  <WordRow
                    key={id}
                    word={w}
                    isFavorite={favoritesSet.has(id)}
                    isMistake={mistakesSet.has(id)}
                    isMastered={masteredSet.has(id)}
                    onOpenDetail={onOpenWordDetail}
                    onSpeak={onSpeak}
                    onToggleFavorite={onToggleFavorite}
                  />
                );
              })}
            </div>
          )}
        </div>
      ) : validCollection.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {tab === 'mistakes' ? 'لا توجد أخطاء مسجلة حالياً' : 'قائمة المفضلة فارغة'}
          </h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {tab === 'mistakes'
              ? 'الكلمات التي تخطئ بها أثناء اللعب ستظهر هنا تلقائياً لمراجعتها.'
              : 'اضغط على أيقونة النجمة بجانب أي كلمة لإضافتها إلى المفضلة.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#131c2e]">
            <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {tab === 'mistakes' ? 'بنك الأخطاء' : 'الكلمات المفضلة'} ·{' '}
              <span className="font-code tabular-nums">{validCollection.length}</span> كلمة
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {tab === 'mistakes' && (
                <button
                  type="button"
                  data-testid="dict-mistake-fixer-btn"
                  onClick={onOpenMistakeFixer}
                  className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white hover:bg-emerald-700"
                >
                  <Sparkles className="h-4 w-4" aria-hidden="true" />
                  <span>جلسة إصلاح سريعة (دقيقتان)</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => onPlayCollection(tab)}
                className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white hover:bg-indigo-700"
              >
                <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                <span>العب بها</span>
              </button>
              <button
                type="button"
                onClick={() => onClearCollection(tab)}
                className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>مسح القائمة</span>
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {validCollection.slice(0, 80).map((id) => {
              const w = store.words[id];
              if (!w) return null;
              return (
                <WordRow
                  key={id}
                  word={w}
                  isFavorite={favoritesSet.has(id)}
                  isMistake={mistakesSet.has(id)}
                  isMastered={masteredSet.has(id)}
                  onOpenDetail={onOpenWordDetail}
                  onSpeak={onSpeak}
                  onToggleFavorite={onToggleFavorite}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
