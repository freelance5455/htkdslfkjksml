import React, { useState } from 'react';
import { X, Phone, Globe, Shield, Coins, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { AVAILABLE_PHONE_CATALOG } from '../services/store.ts';

interface RentNumberModalProps {
  userCredits: number;
  onClose: () => void;
  onRent: (
    item: typeof AVAILABLE_PHONE_CATALOG[0],
    duration: '20m' | '24h' | '7d' | '30d'
  ) => void;
  onOpenCreditsModal: () => void;
}

export const RentNumberModal: React.FC<RentNumberModalProps> = ({
  userCredits,
  onClose,
  onRent,
  onOpenCreditsModal,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<string>('US');
  const [selectedDuration, setSelectedDuration] = useState<'20m' | '24h' | '7d' | '30d'>('20m');
  const [selectedNumber, setSelectedNumber] = useState(AVAILABLE_PHONE_CATALOG[0]);

  const filteredNumbers = AVAILABLE_PHONE_CATALOG.filter((item) => item.countryCode === selectedCountry);

  const getDurationCost = () => {
    switch (selectedDuration) {
      case '20m':
        return 10;
      case '24h':
        return 25;
      case '7d':
        return 70;
      case '30d':
        return 180;
    }
  };

  const cost = getDurationCost();
  const hasEnoughCredits = userCredits >= cost;

  const handleConfirm = () => {
    if (!hasEnoughCredits) {
      onOpenCreditsModal();
      return;
    }
    onRent(selectedNumber, selectedDuration);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mb-4">
          <Phone className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 mb-1">Rent Temporary Phone Number</h3>
        <p className="text-xs text-slate-500 mb-5">
          Receive one-time SMS verification passcodes securely. Rented numbers only receive SMS (no outbound calls or SMS).
        </p>

        {/* STEP 1: COUNTRY SELECTION */}
        <div className="mb-5">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>1. Choose Country</span>
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
            {[
              { code: 'US', flag: '🇺🇸', name: 'US' },
              { code: 'GB', flag: '🇬🇧', name: 'UK' },
              { code: 'DE', flag: '🇩🇪', name: 'DE' },
              { code: 'CA', flag: '🇨🇦', name: 'CA' },
              { code: 'FR', flag: '🇫🇷', name: 'FR' },
            ].map((country) => (
              <button
                type="button"
                key={country.code}
                onClick={() => {
                  setSelectedCountry(country.code);
                  const first = AVAILABLE_PHONE_CATALOG.find((n) => n.countryCode === country.code);
                  if (first) setSelectedNumber(first);
                }}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedCountry === country.code
                    ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                }`}
              >
                <div className="text-xl mb-0.5">{country.flag}</div>
                <div className="text-xs font-semibold">{country.name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* STEP 2: AVAILABLE NUMBERS */}
        <div className="mb-5">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            2. Available Lines ({filteredNumbers.length})
          </label>
          <div className="space-y-2">
            {filteredNumbers.map((item) => (
              <button
                type="button"
                key={item.number}
                onClick={() => setSelectedNumber(item)}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  selectedNumber.number === item.number
                    ? 'bg-blue-50/80 border-blue-500 text-slate-900 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-blue-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{item.flag}</span>
                  <div>
                    <div className="font-mono text-sm font-bold text-blue-700">{item.number}</div>
                    <div className="text-[11px] text-slate-500">{item.friendlyLocation}</div>
                  </div>
                </div>
                {selectedNumber.number === item.number && (
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* STEP 3: RENTAL DURATION */}
        <div className="mb-5">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            3. Rental Window
          </label>
          <div className="grid grid-cols-4 gap-2">
            {[
              { id: '20m', label: '20 Min', cost: 10, note: 'Quick OTP' },
              { id: '24h', label: '24 Hours', cost: 25, note: 'Standard' },
              { id: '7d', label: '7 Days', cost: 70, note: 'Extended' },
              { id: '30d', label: '30 Days', cost: 180, note: 'VIP' },
            ].map((tier) => (
              <button
                type="button"
                key={tier.id}
                onClick={() => setSelectedDuration(tier.id as any)}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedDuration === tier.id
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                }`}
              >
                <div className="text-xs font-bold">{tier.label}</div>
                <div className={`text-[11px] font-mono font-semibold mt-0.5 ${
                  selectedDuration === tier.id ? 'text-blue-100' : 'text-blue-600'
                }`}>
                  {tier.cost} pts
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* PRICING & CONFIRMATION BOX */}
        <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5 mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-500" />
            <div>
              <div className="text-xs font-bold text-slate-900">Total Rental Cost</div>
              <div className="text-[11px] text-slate-500">Your balance: {userCredits} credits</div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-lg font-mono font-bold text-blue-700">{cost} Credits</span>
          </div>
        </div>

        {!hasEnoughCredits && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4 flex items-center gap-2 text-xs text-amber-800">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>You need {cost - userCredits} more credits to rent this line.</span>
          </div>
        )}

        <div className="flex items-center gap-2">
          {hasEnoughCredits ? (
            <button
              onClick={handleConfirm}
              className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-sm shadow-blue-600/20 active:scale-98 cursor-pointer"
            >
              <span>Confirm &amp; Rent Line</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onOpenCreditsModal}
              className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-sm cursor-pointer"
            >
              <Coins className="w-4 h-4" />
              <span>Get Credits to Rent</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
