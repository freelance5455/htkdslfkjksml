import React, { useState } from 'react';
import { ClockSettings, ClockTheme } from '../types/clock';
import { soundService } from '../services/soundService';
import { X, Moon, Sun, Bell, Volume2, Globe, Sparkles } from 'lucide-react';

interface ClockSettingsModalProps {
  settings: ClockSettings;
  theme: ClockTheme;
  onUpdateSettings: (newSettings: Partial<ClockSettings>) => void;
  onClose: () => void;
}

const COMMON_TIMEZONES = [
  { label: 'Auto (Local Device)', value: 'local' },
  { label: 'UTC (Coordinated Universal Time)', value: 'UTC' },
  { label: 'New York (EDT/EST)', value: 'America/New_York' },
  { label: 'Los Angeles (PDT/PST)', value: 'America/Los_Angeles' },
  { label: 'Chicago (CDT/CST)', value: 'America/Chicago' },
  { label: 'London (BST/GMT)', value: 'Europe/London' },
  { label: 'Paris / Berlin (CEST/CET)', value: 'Europe/Paris' },
  { label: 'Tokyo (JST)', value: 'Asia/Tokyo' },
  { label: 'Singapore (SGT)', value: 'Asia/Singapore' },
  { label: 'Dubai (GST)', value: 'Asia/Dubai' },
  { label: 'Sydney (AEST/AEDT)', value: 'Australia/Sydney' },
];

export const ClockSettingsModal: React.FC<ClockSettingsModalProps> = ({
  settings,
  theme,
  onUpdateSettings,
  onClose,
}) => {
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationStatus(permission);
    }
  };

  const handleTestHourlyChime = () => {
    soundService.playHourlyChime(0.6);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div
        className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl border p-6 sm:p-8 space-y-6 shadow-2xl"
        style={{
          backgroundColor: theme.surfaceBg,
          borderColor: theme.border,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b pb-4" style={{ borderColor: theme.border }}>
          <div>
            <h3 className="text-lg font-bold tracking-tight" style={{ color: theme.textPrimary }}>
              Display & Clock Settings
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Customize time format, precision, hourly alerts, and brightness.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Display Dimmer / Brightness Slider */}
        <div className="p-4 rounded-2xl border space-y-3" style={{ borderColor: theme.border, backgroundColor: theme.background }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Moon className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Display Brightness (Night Dimmer)
              </span>
            </div>
            <span className="text-xs font-mono font-bold" style={{ color: theme.textAccent }}>
              {settings.brightness}%
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Moon className="w-3.5 h-3.5 text-slate-500" />
            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={settings.brightness}
              onChange={(e) => onUpdateSettings({ brightness: parseInt(e.target.value) })}
              className="w-full accent-amber-500"
            />
            <Sun className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-[11px] text-slate-400">
            Dim the display down to 10% for dark rooms and bedside nightstand mode.
          </p>
        </div>

        {/* Time Format Toggles */}
        <div className="space-y-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Time & Digits Format
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 12h / 24h */}
            <div
              className="flex items-center justify-between p-3.5 rounded-xl border cursor-pointer hover:bg-white/5 transition-colors"
              style={{ borderColor: theme.border, backgroundColor: theme.background }}
              onClick={() => onUpdateSettings({ hour12: !settings.hour12 })}
            >
              <div>
                <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                  12-Hour Format
                </div>
                <div className="text-[11px] text-slate-400">Show AM/PM indicators</div>
              </div>
              <input
                type="checkbox"
                checked={settings.hour12}
                onChange={() => {}}
                className="w-4 h-4 rounded accent-amber-500 pointer-events-none"
              />
            </div>

            {/* Show Seconds */}
            <div
              className="flex items-center justify-between p-3.5 rounded-xl border cursor-pointer hover:bg-white/5 transition-colors"
              style={{ borderColor: theme.border, backgroundColor: theme.background }}
              onClick={() => onUpdateSettings({ showSeconds: !settings.showSeconds })}
            >
              <div>
                <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                  Show Seconds
                </div>
                <div className="text-[11px] text-slate-400">Seconds & progress bar</div>
              </div>
              <input
                type="checkbox"
                checked={settings.showSeconds}
                onChange={() => {}}
                className="w-4 h-4 rounded accent-amber-500 pointer-events-none"
              />
            </div>

            {/* Blinking Colons */}
            <div
              className="flex items-center justify-between p-3.5 rounded-xl border cursor-pointer hover:bg-white/5 transition-colors"
              style={{ borderColor: theme.border, backgroundColor: theme.background }}
              onClick={() => onUpdateSettings({ blinkColons: !settings.blinkColons })}
            >
              <div>
                <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                  Blinking Colons
                </div>
                <div className="text-[11px] text-slate-400">Flash separators every second</div>
              </div>
              <input
                type="checkbox"
                checked={settings.blinkColons}
                onChange={() => {}}
                className="w-4 h-4 rounded accent-amber-500 pointer-events-none"
              />
            </div>

            {/* High Precision Milliseconds */}
            <div
              className="flex items-center justify-between p-3.5 rounded-xl border cursor-pointer hover:bg-white/5 transition-colors"
              style={{ borderColor: theme.border, backgroundColor: theme.background }}
              onClick={() => onUpdateSettings({ showMilliseconds: !settings.showMilliseconds })}
            >
              <div>
                <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                  Milliseconds (00-99)
                </div>
                <div className="text-[11px] text-slate-400">High-precision counter</div>
              </div>
              <input
                type="checkbox"
                checked={settings.showMilliseconds}
                onChange={() => {}}
                className="w-4 h-4 rounded accent-amber-500 pointer-events-none"
              />
            </div>
          </div>
        </div>

        {/* Timezone Selector */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Timezone & World Synchronization
          </label>
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={settings.timezone}
              onChange={(e) => onUpdateSettings({ timezone: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2"
              style={{
                backgroundColor: theme.background,
                borderColor: theme.border,
                color: theme.textPrimary,
              }}
            >
              {COMMON_TIMEZONES.map((tz) => (
                <option key={tz.value} value={tz.value} className="bg-neutral-900 text-white">
                  {tz.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Hourly Chime & Alerts */}
        <div className="p-4 rounded-2xl border space-y-3" style={{ borderColor: theme.border, backgroundColor: theme.background }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                  Hourly Chime
                </div>
                <div className="text-[11px] text-slate-400">Gentle acoustic chime at the top of every hour</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTestHourlyChime}
                title="Preview chime"
                className="p-1.5 rounded-lg border hover:bg-white/10 text-xs flex items-center gap-1 text-slate-300"
                style={{ borderColor: theme.border }}
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Test</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ hourlyChime: !settings.hourlyChime })}
                className="w-11 h-6 rounded-full relative transition-colors"
                style={{
                  backgroundColor: settings.hourlyChime ? theme.textAccent : 'rgba(255,255,255,0.15)',
                }}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                    settings.hourlyChime ? 'translate-x-5' : 'translate-x-0.5'
                  } mt-0.5`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Browser Notification Permission Status */}
        <div className="flex items-center justify-between pt-2 border-t text-xs text-slate-400" style={{ borderColor: theme.border }}>
          <span>Browser Notifications: <strong className="capitalize text-slate-200">{notificationStatus}</strong></span>
          {notificationStatus !== 'granted' && (
            <button
              onClick={requestNotificationPermission}
              className="px-3 py-1 text-xs rounded-lg border hover:bg-white/5 text-slate-200 transition-colors"
              style={{ borderColor: theme.border }}
            >
              Enable Notifications
            </button>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold rounded-xl shadow-sm transition-all"
            style={{
              backgroundColor: theme.textAccent,
              color: '#fff',
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
