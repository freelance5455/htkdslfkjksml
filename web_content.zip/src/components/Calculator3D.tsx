"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Float, OrbitControls } from "@react-three/drei";
import CalculatorModel from "./CalculatorModel";
import { CalcLights, Sway } from "./CalcScene";
import type { ScreenData } from "@/lib/calculator";

export type Calculator3DProps = {
  screen: ScreenData;
  bodyColor?: string;
  accent?: string;
  onKey?: (id: string) => void;
  pressedId?: string | null;
  sway?: number;
  intro?: boolean;
  cameraZ?: number;
  className?: string;
};

/** Interactive floating scientific calculator — tap the 3D keys. */
export default function Calculator3D({
  screen,
  bodyColor = "#1c1d22",
  accent = "#8b5cf6",
  onKey,
  pressedId = null,
  sway = 0.35,
  intro = false,
  cameraZ = 15,
  className = "h-full w-full",
}: Calculator3DProps) {
  return (
    <div className={className}>
      <Canvas
        dpr={[1, 1.75]}
        camera={{ position: [0, 0, cameraZ], fov: 36 }}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        style={{ background: "transparent", touchAction: "pan-y" }}
      >
        <Suspense fallback={null}>
          <CalcLights accent={accent} />
          <Float speed={1.5} rotationIntensity={0.12} floatIntensity={0.8} floatingRange={[-0.12, 0.16]}>
            <Sway amount={sway} intro={intro}>
              <CalculatorModel
                screen={screen}
                bodyColor={bodyColor}
                accent={accent}
                onKey={onKey}
                pressedId={pressedId}
              />
            </Sway>
          </Float>
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            rotateSpeed={0.6}
            minAzimuthAngle={-0.9}
            maxAzimuthAngle={0.9}
            minPolarAngle={Math.PI / 2 - 0.5}
            maxPolarAngle={Math.PI / 2 + 0.4}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}
