import React, { useMemo, useState } from 'react';
import { RotateCcw, Search, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatDateTime } from '../utils/calculations';
import { ConfirmModal } from './ConfirmModal';

export const RecycleBinModule: React.FC = () => {
  const {
    state,
    tr,
    notify,
    restoreRecycleItem,
    permanentDeleteRecycleItem,
    emptyRecycleBin,
  } = useApp();

  const [search, setSearch] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [confirmTarget, setConfirmTarget] = useState<{
    open: boolean;
    mode: 'single' | 'all';
    id?: string;
    label?: string;
  }>({ open: false, mode: 'single' });

  const dateFmt = state.settings.dateFormat;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.recycleBin.filter((item) => {
      const d = item.deletedAt.slice(0, 10);
      if (fromDate && d < fromDate) return false;
      if (toDate && d > toDate) return false;
      if (q) {
        const hay = `${item.moduleLabel} ${item.summary} ${item.recordId}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [state.recycleBin, search, fromDate, toDate]);

  return (
    <div className="space-y-5">
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">{tr('nav_recycle_bin')}</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Deleted records are stored here safely. Restore any record back to its original module or delete it permanently.
          </p>
        </div>
        {state.recycleBin.length > 0 && (
          <button
            type="button"
            onClick={() => setConfirmTarget({ open: true, mode: 'all' })}
            className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 whitespace-nowrap"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Empty Recycle Bin ({state.recycleBin.length})</span>
          </button>
        )}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-2.5">
          <div className="relative sm:col-span-2">
            <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search deleted items..."
              aria-label="Search recycle bin"
              className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
            />
          </div>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            aria-label="Filter deleted items from date"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
          />
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            aria-label="Filter deleted items to date"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
          />
        </div>

        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center text-sm text-slate-500">
            Recycle Bin is empty.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="px-4 sm:px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 hover:bg-slate-50"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-900">{item.summary}</div>
                  <div className="text-xs text-slate-500 mt-0.5 tabular-nums">
                    {item.moduleLabel} · Deleted {formatDateTime(item.deletedAt, dateFmt)}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      restoreRecycleItem(item.id);
                      notify('Record restored to its original module.');
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 whitespace-nowrap"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>{tr('restore')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setConfirmTarget({
                        open: true,
                        mode: 'single',
                        id: item.id,
                        label: item.summary,
                      })
                    }
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 whitespace-nowrap"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>{tr('permanent_delete')}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmModal
        open={confirmTarget.open}
        title="Permanent Deletion"
        message={
          confirmTarget.mode === 'all'
            ? 'Permanently delete all items in the Recycle Bin? This action cannot be undone.'
            : `Permanently delete "${confirmTarget.label}"? This action cannot be undone.`
        }
        confirmLabel={tr('permanent_delete')}
        cancelLabel={tr('cancel')}
        onCancel={() => setConfirmTarget({ open: false, mode: 'single' })}
        onConfirm={() => {
          if (confirmTarget.mode === 'all') {
            emptyRecycleBin();
            notify('Recycle Bin emptied.');
          } else if (confirmTarget.id) {
            permanentDeleteRecycleItem(confirmTarget.id);
            notify('Record permanently deleted.');
          }
          setConfirmTarget({ open: false, mode: 'single' });
        }}
      />
    </div>
  );
};
