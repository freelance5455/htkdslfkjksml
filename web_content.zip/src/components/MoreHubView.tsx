import React, { useState } from 'react';
import {
  BarChart3,
  Building2,
  ChevronRight,
  FileText,
  KeyRound,
  Lock,
  Receipt,
  Trash2,
  User,
} from 'lucide-react';
import { AppTab, StudioSettings } from '../types';
import { formatINR } from '../utils/formatters';

interface MoreHubViewProps {
  settings: StudioSettings;
  invoiceCount: number;
  totalExpenses: number;
  netProfit: number;
  onNavigate: (tab: AppTab) => void;
  onUpdateSettings: (next: Partial<StudioSettings>) => void;
  onLockApp: () => void;
  onClearAllData: () => void;
  onToast: (msg: string) => void;
}

export const MoreHubView: React.FC<MoreHubViewProps> = ({
  settings,
  invoiceCount,
  totalExpenses,
  netProfit,
  onNavigate,
  onUpdateSettings,
  onLockApp,
  onClearAllData,
  onToast,
}) => {
  const [confirmClear, setConfirmClear] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');

  const handlePinUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{4}$/.test(newPin)) {
      setPinError('PIN must be exactly 4 digits.');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError('PIN entries do not match.');
      return;
    }
    onUpdateSettings({ pinCode: newPin });
    setNewPin('');
    setConfirmPin('');
    setPinError('');
    onToast('Admin PIN updated successfully');
  };

  return (
    <div className="space-y-6">
      <div className="space-y-0.5">
        <h1 className="font-display text-2xl font-bold text-[#0F172A]">
          Studio Hub &amp; Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          {settings.companyName} · Managed by {settings.adminName} ({settings.adminTitle})
        </p>
      </div>

      {/* Section 1: Workspace Tools Navigation (Single surface, 1px dividers) */}
      <section className="surface-card overflow-hidden divide-y divide-slate-200">
        <button
          type="button"
          onClick={() => onNavigate('invoices')}
          className="w-full px-5 py-4 text-left hover:bg-slate-50 transition-colors duration-150 flex items-center justify-between gap-4 cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5 text-[#0F172A]" strokeWidth={1.75} />
            </div>
            <div className="space-y-0.5">
              <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A]">
                Invoices
              </h2>
              <p className="text-xs text-slate-500">{invoiceCount} invoices generated</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" strokeWidth={1.75} />
        </button>

        <button
          type="button"
          onClick={() => onNavigate('expenses')}
          className="w-full px-5 py-4 text-left hover:bg-slate-50 transition-colors duration-150 flex items-center justify-between gap-4 cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5 text-[#0F172A]" strokeWidth={1.75} />
            </div>
            <div className="space-y-0.5">
              <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A]">
                Expense Manager
              </h2>
              <p className="text-xs text-slate-500 tabular-nums">
                {formatINR(totalExpenses)} logged
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" strokeWidth={1.75} />
        </button>

        <button
          type="button"
          onClick={() => onNavigate('reports')}
          className="w-full px-5 py-4 text-left hover:bg-slate-50 transition-colors duration-150 flex items-center justify-between gap-4 cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
              <BarChart3 className="w-5 h-5 text-[#0F172A]" strokeWidth={1.75} />
            </div>
            <div className="space-y-0.5">
              <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A]">
                Financial Reports
              </h2>
              <p className="text-xs text-slate-500 tabular-nums">
                Net Profit {formatINR(netProfit)}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" strokeWidth={1.75} />
        </button>
      </section>

      {/* Section 2: Admin Profile & Company Information (Unified surface, 1px dividers) */}
      <section className="surface-card overflow-hidden divide-y divide-slate-200">
        {/* Live Profile Summary Header */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50/40">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#0F172A]">
              <User className="w-4 h-4" strokeWidth={1.75} />
              <span>Admin Profile</span>
            </div>
            <p className="font-display text-base font-bold text-[#0F172A]">
              {settings.adminName} · <span className="font-normal text-slate-600">{settings.adminTitle}</span>
            </p>
            <p className="text-xs text-slate-500 leading-relaxed">{settings.adminBio}</p>
            <p className="text-xs font-mono text-slate-600">{settings.adminEmail}</p>
          </div>

          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#0F172A]">
              <Building2 className="w-4 h-4" strokeWidth={1.75} />
              <span>Company Profile</span>
            </div>
            <p className="font-display text-base font-bold text-[#0F172A]">
              {settings.companyName}
            </p>
            <p className="text-xs text-slate-500 leading-relaxed">{settings.companyAbout}</p>
            <p className="text-xs text-slate-600">{settings.companyAddress}</p>
          </div>
        </div>

        {/* Editable Admin Fields */}
        <div className="p-6 space-y-4">
          <h2 className="font-display text-base font-bold text-[#0F172A]">
            Admin Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Admin Name</label>
              <input
                type="text"
                value={settings.adminName}
                onChange={(e) => onUpdateSettings({ adminName: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Role / Title</label>
              <input
                type="text"
                value={settings.adminTitle}
                onChange={(e) => onUpdateSettings({ adminTitle: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Admin Email</label>
              <input
                type="email"
                value={settings.adminEmail}
                onChange={(e) => onUpdateSettings({ adminEmail: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-medium text-slate-600">About Admin</label>
            <textarea
              rows={2}
              value={settings.adminBio}
              onChange={(e) => onUpdateSettings({ adminBio: e.target.value })}
              className="w-full px-3 py-2 text-sm field-input resize-none"
            />
          </div>
        </div>

        {/* Editable Company & Billing Fields */}
        <div className="p-6 space-y-4">
          <h2 className="font-display text-base font-bold text-[#0F172A]">
            Company &amp; Billing Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Company Name</label>
              <input
                type="text"
                value={settings.companyName}
                onChange={(e) => onUpdateSettings({ companyName: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">
                UPI ID (Reminders &amp; Invoices)
              </label>
              <input
                type="text"
                value={settings.upiId}
                onChange={(e) => onUpdateSettings({ upiId: e.target.value })}
                className="w-full h-10 px-3 text-sm font-mono field-input"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Company Address</label>
              <input
                type="text"
                value={settings.companyAddress}
                onChange={(e) => onUpdateSettings({ companyAddress: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Invoice Payment Note</label>
              <input
                type="text"
                value={settings.invoiceNote}
                onChange={(e) => onUpdateSettings({ invoiceNote: e.target.value })}
                className="w-full h-10 px-3 text-sm field-input"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-medium text-slate-600">About Company</label>
            <textarea
              rows={2}
              value={settings.companyAbout}
              onChange={(e) => onUpdateSettings({ companyAbout: e.target.value })}
              className="w-full px-3 py-2 text-sm field-input resize-none"
            />
          </div>
        </div>

        {/* Security & Change PIN Section */}
        <form onSubmit={handlePinUpdate} className="p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="space-y-0.5">
              <h2 className="font-display text-base font-bold text-[#0F172A] inline-flex items-center gap-2">
                <KeyRound className="w-4 h-4" strokeWidth={1.75} />
                <span>Admin Security PIN</span>
              </h2>
              <p className="text-xs text-slate-500">
                4-digit admin PIN protection is active. Update your PIN anytime below.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">New 4-Digit PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={newPin}
                onChange={(e) => {
                  setPinError('');
                  setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4));
                }}
                placeholder="••••"
                className="w-full h-10 px-3 text-sm font-mono tracking-widest field-input"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Confirm PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={confirmPin}
                onChange={(e) => {
                  setPinError('');
                  setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4));
                }}
                placeholder="••••"
                className="w-full h-10 px-3 text-sm font-mono tracking-widest field-input"
              />
            </div>

            <button
              type="submit"
              className="btn-primary h-11 px-4 text-sm font-semibold cursor-pointer"
            >
              Update Admin PIN
            </button>
          </div>

          {pinError && <p className="text-xs font-medium text-red-600">{pinError}</p>}
        </form>

        {/* Workspace Actions Footer */}
        <div className="p-5 sm:p-6 flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 bg-slate-50/40">
          <button
            type="button"
            onClick={onLockApp}
            className="btn-secondary w-full sm:w-auto h-11 px-4 text-sm sm:text-xs font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <Lock className="w-4 h-4" strokeWidth={1.75} />
            <span>Lock Workspace</span>
          </button>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="btn-secondary w-full sm:w-auto h-11 px-4 text-sm sm:text-xs font-semibold text-red-600 hover:bg-red-50 hover:border-red-200 inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" strokeWidth={1.75} />
              <span>Clear All Data</span>
            </button>
          ) : (
            <div className="flex flex-col sm:inline-flex sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  onClearAllData();
                  setConfirmClear(false);
                }}
                className="h-11 px-4 rounded-[8px] bg-red-600 hover:bg-red-700 text-sm sm:text-xs font-semibold text-white cursor-pointer transition-colors duration-150"
              >
                Confirm Clear Everything
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="btn-secondary h-11 px-4 text-sm sm:text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
