import React, { useState, useEffect, useRef } from 'react';
import { X, Edit2 } from 'lucide-react';
import { feedback } from '../utils/haptics';

interface PromptModalProps {
  isOpen: boolean;
  title: string;
  label?: string;
  initialValue: string;
  placeholder?: string;
  confirmLabel?: string;
  onConfirm: (val: string) => void;
  onClose: () => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const PromptModal: React.FC<PromptModalProps> = ({
  isOpen,
  title,
  label,
  initialValue,
  placeholder,
  confirmLabel = 'Save',
  onConfirm,
  onClose,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [val, setVal] = useState(initialValue);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setVal(initialValue);
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    }
  }, [isOpen, initialValue]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!val.trim()) return;
    feedback.vibrateSoft(hapticsEnabled);
    feedback.playTap(soundEnabled);
    onConfirm(val.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl p-5 border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Edit2 className="w-4 h-4 text-red-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {label && (
            <label className="block font-semibold text-slate-700 dark:text-slate-300">
              {label}
            </label>
          )}

          <input
            ref={inputRef}
            type="text"
            required
            value={val}
            onChange={(e) => setVal(e.target.value)}
            placeholder={placeholder}
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          />

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl bg-[#d9262c] hover:bg-red-700 text-white font-semibold shadow-sm transition active:scale-95"
            >
              {confirmLabel}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
