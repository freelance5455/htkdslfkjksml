import React, { useState } from 'react';
import { StudyModule } from '../types/index.ts';
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  BookOpen,
  Award,
  Globe,
  Share2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSuccessChime, playTapChime } from '../utils/audio.ts';

interface QuizRunnerProps {
  module: StudyModule;
  language: 'om' | 'en';
  onBack: () => void;
  onReadNotes: (module: StudyModule) => void;
  onQuizCompleted?: (moduleId: string, score: number, total: number) => void;
}

export const QuizRunner: React.FC<QuizRunnerProps> = ({
  module,
  language: appLanguage,
  onBack,
  onReadNotes,
  onQuizCompleted,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [qId: number]: number }>({});
  const [submittedQuestions, setSubmittedQuestions] = useState<{ [qId: number]: boolean }>({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [showEnQuestion, setShowEnQuestion] = useState(false);

  const questions = module.questions;
  const currentQuestion = questions[currentIndex];
  const total = questions.length;

  const currentSelected = selectedAnswers[currentQuestion.id];
  const isCurrentSubmitted = submittedQuestions[currentQuestion.id];

  const handleSelectOption = (optionIndex: number) => {
    if (isCurrentSubmitted) return; // already answered
    playTapChime();
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optionIndex,
    }));
  };

  const handleSubmitAnswer = () => {
    if (currentSelected === undefined) return;

    setSubmittedQuestions((prev) => ({
      ...prev,
      [currentQuestion.id]: true,
    }));

    if (currentSelected === currentQuestion.correctIndex) {
      playSuccessChime();
    }
  };

  const handleNext = () => {
    if (currentIndex < total - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Completed!
      setIsCompleted(true);

      // Calculate score
      let score = 0;
      questions.forEach((q) => {
        if (selectedAnswers[q.id] === q.correctIndex) {
          score += 1;
        }
      });

      if (score >= 3) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch (e) {
          // ignore
        }
      }

      onQuizCompleted?.(module.id, score, total);
    }
  };

  const handleRestart = () => {
    setSelectedAnswers({});
    setSubmittedQuestions({});
    setCurrentIndex(0);
    setIsCompleted(false);
  };

  // Calculate current score
  let correctCount = 0;
  questions.forEach((q) => {
    if (selectedAnswers[q.id] === q.correctIndex) {
      correctCount += 1;
    }
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <button
          onClick={onBack}
          className="min-h-[44px] inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-slate-950 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{appLanguage === 'om' ? 'Qabxiitti Deebi\'i' : 'Back'}</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowEnQuestion((prev) => !prev)}
            className="min-h-[38px] px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-600" />
            <span>{showEnQuestion ? 'Afaan Oromoo' : 'English View'}</span>
          </button>

          <span className="text-xs font-bold text-slate-600 tabular-nums bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            {currentIndex + 1} / {total}
          </span>
        </div>
      </div>

      {!isCompleted ? (
        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-500 font-medium">
              <span>
                {appLanguage === 'om'
                  ? `Gaaffii ${currentIndex + 1}ffaa ${total} keessaa`
                  : `Question ${currentIndex + 1} of ${total}`}
              </span>
              <span>{Math.round(((currentIndex + 1) / total) * 100)}%</span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-300 rounded-full"
                style={{ width: `${((currentIndex + 1) / total) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Card */}
          <div className="bg-white p-5 sm:p-7 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
                <HelpCircle className="w-4 h-4" />
                <span>
                  {appLanguage === 'om'
                    ? `${module.subject} · Kutaa 9`
                    : `${module.subjectEn || module.subject} · Grade 9 Review`}
                </span>
              </div>

              <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                {showEnQuestion && currentQuestion.questionTranslation
                  ? currentQuestion.questionTranslation
                  : currentQuestion.question}
              </h2>

              {!showEnQuestion && currentQuestion.questionTranslation && (
                <p className="text-xs text-slate-500 italic">
                  {currentQuestion.questionTranslation}
                </p>
              )}
            </div>

            {/* Options List */}
            <div className="space-y-3">
              {currentQuestion.options.map((option, optIdx) => {
                const isSelected = currentSelected === optIdx;
                const isCorrect = optIdx === currentQuestion.correctIndex;

                let optionStyle =
                  'border-slate-200 bg-white hover:bg-slate-50 hover:border-slate-300 text-slate-800';

                if (isCurrentSubmitted) {
                  if (isCorrect) {
                    optionStyle = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                  } else if (isSelected && !isCorrect) {
                    optionStyle = 'border-rose-400 bg-rose-50 text-rose-950';
                  } else {
                    optionStyle = 'border-slate-200 bg-slate-50/50 text-slate-400 opacity-70';
                  }
                } else if (isSelected) {
                  optionStyle = 'border-amber-500 bg-amber-50/70 text-slate-950 font-semibold ring-1 ring-amber-500';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    disabled={isCurrentSubmitted}
                    className={`w-full min-h-[52px] p-4 text-left rounded-xl border text-sm transition-all flex items-center justify-between gap-3 cursor-pointer ${optionStyle}`}
                  >
                    <span className="leading-relaxed">{option}</span>

                    {isCurrentSubmitted && (
                      <span className="shrink-0">
                        {isCorrect ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        ) : isSelected ? (
                          <XCircle className="w-5 h-5 text-rose-500" />
                        ) : null}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation & Answer Key Box upon submission */}
            {isCurrentSubmitted && (
              <div
                className={`p-4 rounded-xl border space-y-2 text-xs sm:text-sm animate-fade-in ${
                  currentSelected === currentQuestion.correctIndex
                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                    : 'bg-amber-50/80 border-amber-200 text-amber-950'
                }`}
              >
                <div className="flex items-center gap-2 font-bold">
                  <span>
                    {appLanguage === 'om' ? 'Deebii Sirrii (Answer Key):' : 'Correct Answer Key:'}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-white border border-current font-extrabold text-xs">
                    {currentQuestion.answerKey}
                  </span>
                </div>

                <p className="leading-relaxed font-normal">
                  <span className="font-semibold">
                    {appLanguage === 'om' ? 'Ibsa (Explanation): ' : 'Pedagogical Explanation: '}
                  </span>
                  {showEnQuestion && currentQuestion.explanationEn
                    ? currentQuestion.explanationEn
                    : currentQuestion.explanation}
                </p>
              </div>
            )}

            {/* Action Bar */}
            <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
              {!isCurrentSubmitted ? (
                <button
                  onClick={handleSubmitAnswer}
                  disabled={currentSelected === undefined}
                  className="min-h-[44px] px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-all cursor-pointer shadow-sm active:scale-[0.98]"
                >
                  {appLanguage === 'om' ? 'Deebii Mirkaneessi' : 'Submit Answer'}
                </button>
              ) : (
                <button
                  onClick={handleNext}
                  className="min-h-[44px] px-6 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-all cursor-pointer shadow-sm active:scale-[0.98]"
                >
                  {currentIndex < total - 1
                    ? appLanguage === 'om'
                      ? 'Gaaffii Itti Aanu'
                      : 'Next Question'
                    : appLanguage === 'om'
                    ? 'Bu\'aa Ilaali'
                    : 'See Results'}
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Results View */
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6 text-center">
          <div className="inline-flex p-4 rounded-full bg-amber-100 text-amber-700 mx-auto">
            <Award className="w-10 h-10" />
          </div>

          <div className="space-y-1">
            <h2 className="text-2xl font-extrabold text-slate-900">
              {correctCount === 5
                ? appLanguage === 'om'
                  ? 'Baga Gammadde! 100% Qabatte!'
                  : 'Perfect Score! 5 out of 5!'
                : correctCount >= 3
                ? appLanguage === 'om'
                  ? 'Baay\'ee Gaarii! Qabxii Gaarii Qabatte!'
                  : 'Well Done! Great Understanding!'
                : appLanguage === 'om'
                ? 'Gaarii Yaaltee Jirta! Qabxiilee Irra Deebi\'ii Dubbisi.'
                : 'Good Effort! Keep Practicing!'}
            </h2>
            <p className="text-sm text-slate-600">
              {module.title} · {module.grade}
            </p>
          </div>

          {/* Scoreboard */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 max-w-sm mx-auto">
            <p className="text-xs text-slate-500 font-medium">
              {appLanguage === 'om' ? 'Qabxii Argatte' : 'Your Review Score'}
            </p>
            <p className="text-4xl font-extrabold text-slate-900 my-1 tabular-nums">
              {correctCount} <span className="text-lg text-slate-400">/ {total}</span>
            </p>
            <p className="text-xs font-semibold text-amber-700">
              {Math.round((correctCount / total) * 100)}% {appLanguage === 'om' ? 'Sirrii' : 'Accuracy'}
            </p>
          </div>

          {/* All Questions Answer Review Accordion */}
          <div className="text-left space-y-3 pt-4 border-t border-slate-100">
            <h3 className="font-bold text-sm text-slate-900">
              {appLanguage === 'om' ? 'Ibsa Gaaffilee 5n Hunda (Answer Keys & Review):' : 'All 5 Questions & Explanations Review:'}
            </h3>

            <div className="space-y-3">
              {questions.map((q, qIdx) => {
                const userAns = selectedAnswers[q.id];
                const isUserCorrect = userAns === q.correctIndex;

                return (
                  <div
                    key={q.id}
                    className={`p-4 rounded-xl border text-xs space-y-1.5 ${
                      isUserCorrect
                        ? 'bg-emerald-50/50 border-emerald-200'
                        : 'bg-rose-50/50 border-rose-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-bold text-slate-900">
                        {qIdx + 1}. {q.question}
                      </span>
                      <span className="shrink-0 font-extrabold text-xs">
                        {isUserCorrect ? (
                          <span className="text-emerald-700 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Sirrii
                          </span>
                        ) : (
                          <span className="text-rose-600 flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> Dogoggora
                          </span>
                        )}
                      </span>
                    </div>

                    <div className="text-slate-600 flex items-center gap-2">
                      <span>Deebii Keetii: {userAns !== undefined ? q.options[userAns] : 'Hin deebifamne'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-bold text-emerald-800">
                        Deebii Sirrii: {q.answerKey} ({q.options[q.correctIndex]})
                      </span>
                    </div>

                    <p className="text-slate-600 pt-1 leading-relaxed border-t border-slate-200/50">
                      <span className="font-medium text-slate-700">Ibsa: </span>
                      {q.explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleRestart}
              className="min-h-[44px] px-5 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{appLanguage === 'om' ? 'Irra Deebi\'ii Yaali' : 'Retake Quiz'}</span>
            </button>

            <button
              onClick={() => onReadNotes(module)}
              className="min-h-[44px] px-5 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>{appLanguage === 'om' ? 'Qabxii Dubbisi' : 'Read Notes'}</span>
            </button>

            <button
              onClick={onBack}
              className="min-h-[44px] px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm cursor-pointer"
            >
              <span>{appLanguage === 'om' ? 'Boqonnaa Kan Biraa' : 'Next Topic'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
