/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Book,
  ReaderSettings,
  ReadingSession,
  BookChapter,
  BookBookmark,
  BookHighlight,
  BookAnnotation,
  CustomSticker,
  BookQuote,
  RoomSharedItem,
} from '../../types';
import { communityService } from '../../services/communityService';
import { BOOK_REACTIONS, HIGHLIGHT_COLORS } from '../../constants/reactions';
import { paginateContent } from '../../services/bookFileProcessor';
import {
  X,
  Play,
  Pause,
  Settings2,
  Bookmark,
  Clock,
  List,
  ChevronRight,
  ChevronLeft,
  FileText,
  Highlighter,
  Smile,
  Image as ImageIcon,
  Edit3,
  Trash2,
  Sun,
  Moon,
  Type,
  AlignLeft,
  Quote,
  Copy,
  Check,
  MessageSquare,
} from 'lucide-react';

interface ReaderModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (settings: ReaderSettings) => void;
  onSaveReadingSession: (session: ReadingSession, newPagesRead: number) => void;
  onOpenAddQuoteWithText?: (text: string, page?: number) => void;
  onSaveQuoteDirectly?: (quote: BookQuote) => void;
  onDeleteQuote?: (quoteId: string) => void;
  onUpdateBook?: (book: Book) => void;
  stickers?: CustomSticker[];
  quotes?: BookQuote[];
}

const DEFAULT_STICKERS = [
  { id: 'stk-cat', name: 'Gato lector', emoji: '🐱', symbol: '🐈' },
  { id: 'stk-books', name: 'Torre de libros', emoji: '📚', symbol: '📖' },
  { id: 'stk-moon', name: 'Luna mágica', emoji: '🌙', symbol: '✨' },
  { id: 'stk-coffee', name: 'Café de lectura', emoji: '☕', symbol: '☕' },
  { id: 'stk-heart', name: 'Corazón ardiente', emoji: '💖', symbol: '❤️' },
  { id: 'stk-dragon', name: 'Dragón de fantasía', emoji: '🐉', symbol: '🐲' },
  { id: 'stk-sword', name: 'Espada legendaria', emoji: '⚔️', symbol: '🗡️' },
  { id: 'stk-sparkle', name: 'Destello', emoji: '✨', symbol: '💫' },
];

export const ReaderModal: React.FC<ReaderModalProps> = ({
  book,
  isOpen,
  onClose,
  readerSettings,
  onUpdateReaderSettings,
  onSaveReadingSession,
  onOpenAddQuoteWithText,
  onSaveQuoteDirectly,
  onDeleteQuote,
  onUpdateBook,
  stickers = [],
  quotes = [],
}) => {
  if (!isOpen || !book) return null;

  // Controls Visibility (Hidden by default, toggled on center tap)
  const [controlsVisible, setControlsVisible] = useState(false);

  // Drawers
  const [showSettingsDrawer, setShowSettingsDrawer] = useState(false);
  const [showChaptersDrawer, setShowChaptersDrawer] = useState(false);
  const [showAnnotationsDrawer, setShowAnnotationsDrawer] = useState(false);
  const [annotationsActiveTab, setAnnotationsActiveTab] = useState<
    'all' | 'bookmarks' | 'notes' | 'stickers' | 'highlights' | 'quotes'
  >('all');

  // Floating selection tools (Requirement 3: Subrayar, Nota, Frase, Reacción, Sticker, Copiar)
  const [selectedText, setSelectedText] = useState('');
  const [selectedHighlightId, setSelectedHighlightId] = useState<string | null>(null);
  const [showHighlightColorPicker, setShowHighlightColorPicker] = useState(false);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [tempNoteText, setTempNoteText] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);

  // Timer State (Requirement 1: Visible pause/resume button, auto-start, pause stops timer without ending session)
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  // Requirement 9: Contenido compartido vs privado (por defecto privado)
  const [shareWithRoom, setShareWithRoom] = useState(false);
  const [showRoomCommentInput, setShowRoomCommentInput] = useState(false);
  const [roomCommentText, setRoomCommentText] = useState('');
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Requirement 10: Comentarios dentro del lector
  const [activeContextSharedItems, setActiveContextSharedItems] = useState<RoomSharedItem[] | null>(null);
  const [contextItemIndex, setContextItemIndex] = useState(0);

  // Room lookup for this book & active reading members
  const roomForBook = useMemo(() => {
    return communityService.getRoomForBook(book.id);
  }, [book.id]);

  const readingRoomMembers = useMemo(() => {
    return roomForBook?.participants.filter((p: any) => p.isReadingNow && p.userId !== 'me') || [];
  }, [roomForBook]);

  // Requirement 9: Helper to push shared items to the reading room
  const handleShareItemWithRoom = (item: {
    type: 'highlight' | 'note' | 'quote' | 'reaction' | 'sticker';
    text: string;
    color?: string;
    note?: string;
    reaction?: string;
    customStickerId?: string;
    customStickerUrl?: string;
  }) => {
    if (!shareWithRoom) return;
    let targetRoom = roomForBook;
    if (!targetRoom) {
      targetRoom = communityService.createRoom(
        book,
        ['friend-ana', 'friend-luis'],
        computedProgress,
        currentPageNumber
      );
    }
    if (targetRoom) {
      communityService.addSharedItem(targetRoom.id, {
        bookId: book.id,
        userId: 'me',
        userName: 'Tú (Yo)',
        userAvatar: '',
        page: currentPageNumber,
        ...item,
      });
      setShareFeedback('¡Compartido con la sala!');
      setTimeout(() => setShareFeedback(null), 2500);
    }
  };

  // Requirement 11: Comentar frase específica directamente desde el lector hacia la sala
  const handleSendRoomCommentForPhrase = () => {
    if (!roomCommentText.trim() || !selectedText) return;
    let targetRoom = roomForBook;
    if (!targetRoom) {
      targetRoom = communityService.createRoom(
        book,
        ['friend-ana', 'friend-luis'],
        computedProgress,
        currentPageNumber
      );
    }
    if (targetRoom) {
      // 1. Mensaje en el chat de la sala citando la frase
      communityService.addMessage(
        targetRoom.id,
        `"${selectedText}": ${roomCommentText.trim()}`
      );
      // 2. Anotación asociada a la ubicación exacta del texto
      communityService.addSharedItem(targetRoom.id, {
        bookId: book.id,
        userId: 'me',
        userName: 'Tú (Yo)',
        userAvatar: '',
        type: 'note',
        page: currentPageNumber,
        text: selectedText,
        note: roomCommentText.trim(),
        color: '#06b6d4',
      });
      setShareFeedback('¡Comentario enviado a la sala!');
      setTimeout(() => setShareFeedback(null), 2500);
    }
    setRoomCommentText('');
    setShowRoomCommentInput(false);
    setSelectedText('');
  };

  // Local mutable book annotations state for immediate UI feedback
  const [localBookmarks, setLocalBookmarks] = useState<BookBookmark[]>(book.bookmarks || []);
  const [localHighlights, setLocalHighlights] = useState<BookHighlight[]>(book.highlights || []);
  const [localAnnotations, setLocalAnnotations] = useState<BookAnnotation[]>(book.annotations || []);

  // Split content into clean pages (Requirement 4: imported books pagination & real pages)
  const rawPages = (book.sampleContent || '')
    .split(/\n\s*---PAGE---\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);

  let initialPages = rawPages.length > 0 ? rawPages : paginateContent(book.sampleContent || '');

  if (initialPages.length === 0) {
    initialPages = [
      `Feyre apretó los dientes, intentando no mostrar el miedo que sentía. El palacio era más grande de lo que había imaginado, y cada rincón parecía susurrar secretos que ella no estaba destinada a conocer.\n\n—No estás a salvo aquí —dijo una voz cercana, suave pero firme.\n\nFeyre giró la cabeza, encontrándose con la mirada de Rhysand. Sus ojos eran de un azul tan profundo que parecían absorber la luz, y por un momento, todo a su alrededor desapareció.\n\nEl viento soplaba entre las columnas de mármol negro, trayendo consigo el aroma a jazmín y noche estrellada. No había retorno. Las decisiones tomadas en el bosque bajo la nieve la habían conducido a esta corte de sombras y sueños.`,
      `La biblioteca de la corte era un santuario de silencio y polvo estelar. Estantes infinitos de obsidiana se elevaban hacia un techo que reflejaba constelaciones vivas.\n\nFeyre acarició el lomo de un tomo encuadernado en terciopelo medianoche. Cada libro guardaba no solo palabras, sino memorias talladas por siglos de historia.\n\n—Si buscas respuestas —escuchó a sus espaldas—, las hallarás entre las páginas que nadie se atreve a abrir.\n\nElla sonrió apenas, sabiendo que el verdadero viaje acababa de comenzar.`,
      `Las campanas de la ciudad tañían a lo lejos cuando el sol descendió tras las montañas escarpadas.\n\nLa lectura continúa en este lector digital adaptado. Puedes seleccionar cualquier fragmento de texto para:\n• Subrayar con tu color preferido.\n• Añadir notas y reflexiones.\n• Pegar stickers ilustrados.\n• Asignar reacciones emocionales.\n\nCada anotación se guarda en "Mis anotaciones" para que puedas volver en cualquier instante a la página exacta.`,
    ];
  }

  // Ensure total reader pages matches book.totalPages if specified, so user can navigate all pages
  const totalReaderPages = Math.max(book.totalPages || 1, initialPages.length);

  // Generate complete displayPages array
  const displayPages = Array.from({ length: totalReaderPages }, (_, idx) => {
    if (idx < initialPages.length) return initialPages[idx];
    return `Página ${idx + 1}\n\nLectura en curso: "${book.title}"\nAutor: ${book.author}\n\nPuedes navegar tocando el lateral derecho para avanzar, o el izquierdo para retroceder. Mantén presionado cualquier texto para subrayar, añadir notas o stickers.`;
  });

  // Remember last real position of book (Requirement 4: NO 100% by default, remember last read page)
  const [pageIndex, setPageIndex] = useState<number>(() => {
    if (book.pagesRead && book.pagesRead > 0) {
      return Math.min(totalReaderPages - 1, Math.max(0, book.pagesRead - 1));
    }
    return 0; // Page 1 by default
  });

  const sessionStartPage = useRef(pageIndex + 1);
  const mainCanvasRef = useRef<HTMLDivElement>(null);

  // Real Current Page & Real Progress Calculation
  const currentPageNumber = pageIndex + 1;
  const computedProgress = Math.min(
    100,
    Math.round((currentPageNumber / totalReaderPages) * 100)
  );

  // Real Current Chapter (Requirement 4: capítulo actual)
  const currentChapter = book.chapters && book.chapters.length > 0
    ? [...book.chapters].reverse().find((c) => (c.pageStart || c.page || 1) <= currentPageNumber) || book.chapters[0]
    : null;

  // Timer interval (stops when paused, resumes on same session)
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => setTimerSeconds((prev) => prev + 1), 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  // Finish session & persist reading progress
  const handleFinishSession = () => {
    setIsTimerRunning(false);
    const durationMinutes = Math.max(1, Math.round(timerSeconds / 60));
    const pagesReadInSession = Math.max(0, currentPageNumber - sessionStartPage.current);

    const newSession: ReadingSession = {
      id: 'ses-' + Date.now(),
      bookId: book.id,
      date: new Date().toISOString().slice(0, 10),
      startTime: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      durationMinutes,
      startPage: sessionStartPage.current,
      endPage: currentPageNumber,
      pagesRead: pagesReadInSession,
    };

    // Save session
    onSaveReadingSession(newSession, currentPageNumber);

    // Update book position and progress in storage (Requirement 7: conservar todo al salir con X)
    if (onUpdateBook) {
      onUpdateBook({
        ...book,
        bookmarks: localBookmarks,
        highlights: localHighlights,
        annotations: localAnnotations,
        pagesRead: currentPageNumber,
        progress: computedProgress,
        status: currentPageNumber >= totalReaderPages ? 'TERMINADO' : 'LEYENDO',
        dateStarted: book.dateStarted || new Date().toISOString(),
        dateFinished:
          currentPageNumber >= totalReaderPages ? new Date().toISOString() : book.dateFinished,
      });
    }

    onClose();
  };

  // Helper to persist updated book annotations to storage
  const syncBookChanges = (
    updatedBookmarks: BookBookmark[],
    updatedHighlights: BookHighlight[],
    updatedAnnotations: BookAnnotation[]
  ) => {
    setLocalBookmarks(updatedBookmarks);
    setLocalHighlights(updatedHighlights);
    setLocalAnnotations(updatedAnnotations);

    if (onUpdateBook) {
      onUpdateBook({
        ...book,
        bookmarks: updatedBookmarks,
        highlights: updatedHighlights,
        annotations: updatedAnnotations,
        pagesRead: currentPageNumber,
        progress: computedProgress,
      });
    }
  };

  // Requirement 2: Screen Touch Tap Navigation
  // tocar mitad derecha -> siguiente
  // tocar mitad izquierda -> anterior
  // tocar centro -> mostrar/ocultar controles
  // No swipe
  const handleReadingCanvasClick = (e: React.MouseEvent) => {
    // If user has an active text selection, do not change page
    const sel = window.getSelection();
    if (sel && sel.toString().trim().length > 0) return;

    if (!mainCanvasRef.current) return;
    const rect = mainCanvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;

    // Center 30% band (35% to 65%) -> Toggle Controls
    if (clickX >= width * 0.35 && clickX <= width * 0.65) {
      setControlsVisible((v) => !v);
      return;
    }

    // Left 35% -> Previous Page
    if (clickX < width * 0.35) {
      if (pageIndex > 0) {
        setPageIndex((p) => p - 1);
        mainCanvasRef.current?.scrollTo({ top: 0 });
        setSelectedText('');
        setSelectedHighlightId(null);
        setShowHighlightColorPicker(false);
      }
      return;
    }

    // Right 35% -> Next Page
    if (clickX > width * 0.65) {
      if (pageIndex < totalReaderPages - 1) {
        setPageIndex((p) => p + 1);
        mainCanvasRef.current?.scrollTo({ top: 0 });
        setSelectedText('');
        setSelectedHighlightId(null);
        setShowHighlightColorPicker(false);
      }
      return;
    }
  };

  // Requirement 3: Text selection listener directly on book text
  const handleSelectionChange = () => {
    const sel = window.getSelection();
    if (sel && sel.toString().trim().length > 0) {
      setSelectedText(sel.toString().trim());
      setSelectedHighlightId(null);
      setShowHighlightColorPicker(false);
      setShowStickerPicker(false);
      setShowReactionPicker(false);
      setShowNoteInput(false);
    }
  };

  // Matching elements for selectedText (Requirement 6)
  const matchingHighlight = React.useMemo(() => {
    if (!selectedText) return null;
    return localHighlights.find(
      (h) => (selectedHighlightId ? h.id === selectedHighlightId : (h.page === currentPageNumber && h.text === selectedText))
    ) || null;
  }, [selectedText, selectedHighlightId, localHighlights, currentPageNumber]);

  const hasHighlightColor = Boolean(matchingHighlight && matchingHighlight.color && matchingHighlight.color !== '#ffffff');

  const matchingNoteAnn = React.useMemo(() => {
    if (!selectedText) return null;
    return localAnnotations.find(
      (a) => a.page === currentPageNumber && a.text === selectedText && a.type === 'note' && a.title
    ) || null;
  }, [selectedText, localAnnotations, currentPageNumber]);

  const matchingQuote = React.useMemo(() => {
    if (!selectedText || !quotes) return null;
    return quotes.find(
      (q) => q.bookId === book.id && (q.page === currentPageNumber || !q.page) && (q.text === selectedText || q.text.trim() === selectedText.trim())
    ) || null;
  }, [selectedText, quotes, book.id, currentPageNumber]);

  const matchingReaction = React.useMemo(() => {
    if (!selectedText) return null;
    const ann = localAnnotations.find(
      (a) => a.page === currentPageNumber && a.text === selectedText && a.reaction && a.type !== 'sticker'
    );
    if (ann?.reaction) return ann.reaction;
    const hl = localHighlights.find(
      (h) => h.page === currentPageNumber && h.text === selectedText && h.reaction && !h.customStickerId
    );
    return hl?.reaction || null;
  }, [selectedText, localAnnotations, localHighlights, currentPageNumber]);

  const matchingSticker = React.useMemo(() => {
    if (!selectedText) return null;
    const ann = localAnnotations.find(
      (a) => a.page === currentPageNumber && a.text === selectedText && a.type === 'sticker'
    );
    if (ann) return ann;
    const hl = localHighlights.find(
      (h) => h.page === currentPageNumber && h.text === selectedText && (h.customStickerId || h.customStickerUrl)
    );
    return hl || null;
  }, [selectedText, localAnnotations, localHighlights, currentPageNumber]);

  // Add / Toggle Bookmark
  const isCurrentPageBookmarked = localBookmarks.some(
    (b) => b.page === currentPageNumber || b.chapterTitle === `Página ${currentPageNumber}`
  );

  const handleToggleBookmark = () => {
    let nextBms: BookBookmark[];
    if (isCurrentPageBookmarked) {
      nextBms = localBookmarks.filter(
        (b) => b.page !== currentPageNumber && b.chapterTitle !== `Página ${currentPageNumber}`
      );
      const nextAnns = localAnnotations.filter(
        (a) => !(a.type === 'bookmark' && a.page === currentPageNumber)
      );
      syncBookChanges(nextBms, localHighlights, nextAnns);
    } else {
      const newBm: BookBookmark = {
        id: 'bm-' + Date.now(),
        page: currentPageNumber,
        chapterTitle: currentChapter ? currentChapter.title : `Página ${currentPageNumber}`,
        createdAt: new Date().toISOString(),
      };
      nextBms = [...localBookmarks, newBm];

      const newAnn: BookAnnotation = {
        id: 'ann-' + Date.now(),
        bookId: book.id,
        type: 'bookmark',
        page: currentPageNumber,
        title: currentChapter ? `Marcador: ${currentChapter.title}` : `Marcador en Página ${currentPageNumber}`,
        createdAt: new Date().toISOString(),
      };
      syncBookChanges(nextBms, localHighlights, [...localAnnotations, newAnn]);
    }
  };

  // 1. SUBRAYAR (Requirement 4: directo e independiente, Requirement 5: cambiar color sin duplicar ni borrar texto)
  const handleSaveHighlight = (colorHex: string) => {
    if (!selectedText) return;

    if (shareWithRoom) {
      handleShareItemWithRoom({
        type: 'highlight',
        text: selectedText,
        color: colorHex,
      });
    }

    if (matchingHighlight) {
      // Requirement 5: Cambiar directamente el color sin duplicar ni borrar texto
      const updatedHighlights = localHighlights.map((h) => {
        if (h.id === matchingHighlight.id || (h.page === currentPageNumber && h.text === selectedText)) {
          return { ...h, color: colorHex };
        }
        return h;
      });

      const updatedAnnotations = localAnnotations.map((a) => {
        if (a.page === currentPageNumber && a.text === selectedText && a.type === 'highlight') {
          return { ...a, color: colorHex };
        }
        return a;
      });

      syncBookChanges(localBookmarks, updatedHighlights, updatedAnnotations);
    } else {
      // Requirement 4: Guardar subrayado directamente e independiente
      const newHl: BookHighlight = {
        id: 'hl-' + Date.now(),
        bookId: book.id,
        page: currentPageNumber,
        text: selectedText,
        color: colorHex,
        createdAt: new Date().toISOString(),
      };

      const newAnn: BookAnnotation = {
        id: 'ann-' + Date.now(),
        bookId: book.id,
        type: 'highlight',
        page: currentPageNumber,
        text: selectedText,
        color: colorHex,
        createdAt: new Date().toISOString(),
      };

      syncBookChanges(
        localBookmarks,
        [...localHighlights, newHl],
        [...localAnnotations, newAnn]
      );
    }

    setShowHighlightColorPicker(false);
  };

  // Requirement 6: Borrar elementos desde el propio lector (individual e independiente)
  // - Eliminar subrayado -> quitar únicamente el subrayado
  const handleDeleteHighlight = () => {
    if (!selectedText) return;

    const nextHighlights = localHighlights
      .map((h) => {
        if (h.id === matchingHighlight?.id || (h.page === currentPageNumber && h.text === selectedText)) {
          if (h.reaction || h.customStickerId || h.note) {
            return { ...h, color: '#ffffff' };
          }
          return null;
        }
        return h;
      })
      .filter(Boolean) as BookHighlight[];

    const nextAnnotations = localAnnotations.filter(
      (a) => !(a.page === currentPageNumber && a.text === selectedText && a.type === 'highlight')
    );

    syncBookChanges(localBookmarks, nextHighlights, nextAnnotations);
    setShowHighlightColorPicker(false);
  };

  // - Eliminar anotación/nota -> quitar únicamente la nota
  const handleDeleteNote = () => {
    if (!selectedText) return;

    const nextAnnotations = localAnnotations.filter(
      (a) => !(a.page === currentPageNumber && a.text === selectedText && a.type === 'note')
    );

    const nextHighlights = localHighlights.map((h) => {
      if (h.page === currentPageNumber && h.text === selectedText && h.note) {
        const { note, ...rest } = h;
        return rest as BookHighlight;
      }
      return h;
    });

    syncBookChanges(localBookmarks, nextHighlights, nextAnnotations);
    setShowNoteInput(false);
  };

  // - Eliminar frase/quote -> quitar únicamente la frase guardada
  const handleDeleteQuote = () => {
    if (!matchingQuote) return;
    if (onDeleteQuote) {
      onDeleteQuote(matchingQuote.id);
    }
  };

  // - Eliminar reacción -> quitar únicamente la reacción
  const handleDeleteReaction = () => {
    if (!selectedText) return;

    const nextHighlights = localHighlights
      .map((h) => {
        if (h.page === currentPageNumber && h.text === selectedText && h.reaction) {
          if ((!h.color || h.color === '#ffffff') && !h.customStickerId && !h.note) {
            return null;
          }
          const { reaction, ...rest } = h;
          return rest as BookHighlight;
        }
        return h;
      })
      .filter(Boolean) as BookHighlight[];

    const nextAnnotations = localAnnotations.filter(
      (a) => !(a.page === currentPageNumber && a.text === selectedText && a.reaction && a.type !== 'sticker')
    );

    syncBookChanges(localBookmarks, nextHighlights, nextAnnotations);
    setShowReactionPicker(false);
  };

  // - Eliminar sticker -> quitar únicamente el sticker
  const handleDeleteSticker = () => {
    if (!selectedText) return;

    const nextHighlights = localHighlights
      .map((h) => {
        if (h.page === currentPageNumber && h.text === selectedText && (h.customStickerId || h.customStickerUrl)) {
          if ((!h.color || h.color === '#ffffff') && !h.reaction && !h.note) {
            return null;
          }
          const { customStickerId, customStickerUrl, ...rest } = h;
          return rest as BookHighlight;
        }
        return h;
      })
      .filter(Boolean) as BookHighlight[];

    const nextAnnotations = localAnnotations.filter(
      (a) => !(a.page === currentPageNumber && a.text === selectedText && a.type === 'sticker')
    );

    syncBookChanges(localBookmarks, nextHighlights, nextAnnotations);
    setShowStickerPicker(false);
  };

  // 2. NOTA
  const handleSaveNote = () => {
    if (!tempNoteText.trim()) return;

    const fragment = selectedText || `Nota en pág. ${currentPageNumber}`;

    if (shareWithRoom) {
      handleShareItemWithRoom({
        type: 'note',
        text: fragment,
        note: tempNoteText.trim(),
        color: '#ffffff',
      });
    }

    const newAnn: BookAnnotation = {
      id: 'ann-' + Date.now(),
      bookId: book.id,
      type: 'note',
      page: currentPageNumber,
      text: fragment,
      title: tempNoteText.trim(),
      color: '#ffffff',
      createdAt: new Date().toISOString(),
    };

    syncBookChanges(localBookmarks, localHighlights, [...localAnnotations, newAnn]);

    setTempNoteText('');
    setSelectedText('');
    setShowNoteInput(false);
  };

  // 3. FRASE
  const handleSaveQuote = () => {
    if (!selectedText) return;

    if (shareWithRoom) {
      handleShareItemWithRoom({
        type: 'quote',
        text: selectedText,
        color: '#ffffff',
      });
    }

    if (onOpenAddQuoteWithText) {
      onOpenAddQuoteWithText(selectedText, currentPageNumber);
    }
    setSelectedText('');
  };

  // 4. REACCIÓN (Requirement 8: Sin nombre personalizado, solo emoji/sticker)
  const handleAttachReaction = (reaction: { emoji: string; label: string }) => {
    const fragment = selectedText || `Fragmento de pág. ${currentPageNumber}`;

    if (shareWithRoom) {
      handleShareItemWithRoom({
        type: 'reaction',
        text: fragment,
        reaction: reaction.emoji,
      });
    }

    const newAnn: BookAnnotation = {
      id: 'ann-' + Date.now(),
      bookId: book.id,
      type: 'note',
      page: currentPageNumber,
      text: fragment,
      reaction: reaction.emoji,
      color: '#ffffff',
      createdAt: new Date().toISOString(),
    };

    const newHl: BookHighlight = {
      id: 'hl-' + Date.now(),
      bookId: book.id,
      page: currentPageNumber,
      text: fragment,
      color: '#ffffff',
      reaction: reaction.emoji,
      createdAt: new Date().toISOString(),
    };

    syncBookChanges(
      localBookmarks,
      [...localHighlights, newHl],
      [...localAnnotations, newAnn]
    );

    setSelectedText('');
    setShowReactionPicker(false);
  };

  // 5. STICKER (Requirement 9: Mayor tamaño visual, conservando proporción)
  const handleAttachSticker = (stickerItem: { id: string; name: string; emoji?: string; dataUrl?: string }) => {
    const fragment = selectedText || `Fragmento de pág. ${currentPageNumber}`;

    if (shareWithRoom) {
      handleShareItemWithRoom({
        type: 'sticker',
        text: fragment,
        reaction: stickerItem.emoji || stickerItem.name,
        customStickerId: stickerItem.id,
        customStickerUrl: stickerItem.dataUrl || undefined,
      });
    }

    const newAnn: BookAnnotation = {
      id: 'ann-' + Date.now(),
      bookId: book.id,
      type: 'sticker',
      page: currentPageNumber,
      text: fragment,
      reaction: stickerItem.emoji || stickerItem.name,
      customStickerId: stickerItem.id,
      customStickerUrl: stickerItem.dataUrl || undefined,
      color: '#ffffff',
      createdAt: new Date().toISOString(),
    };

    const newHl: BookHighlight = {
      id: 'hl-' + Date.now(),
      bookId: book.id,
      page: currentPageNumber,
      text: fragment,
      color: '#ffffff',
      reaction: stickerItem.emoji || stickerItem.name,
      customStickerId: stickerItem.id,
      customStickerUrl: stickerItem.dataUrl || undefined,
      createdAt: new Date().toISOString(),
    };

    // Requirement 4: Guardar stickers personalizados junto con la frase correspondiente en Mis frases
    const newQuote: BookQuote = {
      id: 'quote-' + Date.now(),
      bookId: book.id,
      bookTitle: book.title,
      author: book.author,
      text: fragment,
      page: currentPageNumber,
      location: currentChapter ? currentChapter.title : `Página ${currentPageNumber}`,
      reaction: stickerItem.emoji || stickerItem.name,
      customStickerId: stickerItem.id,
      customStickerUrl: stickerItem.dataUrl || undefined,
      color: '#ffffff',
      favorite: false,
      createdAt: new Date().toISOString(),
    };

    if (onSaveQuoteDirectly) {
      onSaveQuoteDirectly(newQuote);
    }

    syncBookChanges(
      localBookmarks,
      [...localHighlights, newHl],
      [...localAnnotations, newAnn]
    );

    setSelectedText('');
    setShowStickerPicker(false);
  };

  // 6. COPIAR
  const handleCopyText = async () => {
    if (!selectedText) return;
    try {
      await navigator.clipboard.writeText(selectedText);
      setCopyFeedback(true);
      setTimeout(() => {
        setCopyFeedback(false);
        setSelectedText('');
      }, 1200);
    } catch {
      // Fallback
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 1200);
    }
  };

  // Delete individual annotation from drawer
  const handleDeleteAnnotationById = (annId: string, type: string, page: number, text?: string) => {
    const nextAnns = localAnnotations.filter((a) => a.id !== annId);
    let nextBms = localBookmarks;
    let nextHls = localHighlights;

    if (type === 'bookmark') {
      nextBms = localBookmarks.filter((b) => b.page !== page);
    } else if (type === 'highlight' && text) {
      nextHls = localHighlights.filter((h) => !(h.page === page && h.text === text));
    } else if (type === 'note' && text) {
      nextHls = localHighlights.map((h) => (h.page === page && h.text === text ? { ...h, note: undefined } : h));
    } else if (type === 'sticker' && text) {
      nextHls = localHighlights.map((h) => (h.page === page && h.text === text ? { ...h, customStickerId: undefined, customStickerUrl: undefined } : h));
    }

    syncBookChanges(nextBms, nextHls, nextAnns);
  };

  // Jump to specific page
  const handleJumpToPage = (targetPage: number) => {
    const zeroBased = Math.max(0, Math.min(totalReaderPages - 1, targetPage - 1));
    setPageIndex(zeroBased);
    setShowAnnotationsDrawer(false);
    setShowChaptersDrawer(false);
    setShowSettingsDrawer(false);
    setControlsVisible(false);
  };

  // Typography & Layout styles
  const getFontFamilyClass = () => {
    switch (readerSettings.fontFamily) {
      case 'serif':
        return 'font-serif';
      case 'mono':
        return 'font-mono';
      default:
        return 'font-sans';
    }
  };

  const getMarginClass = () => {
    switch (readerSettings.margins) {
      case 'narrow':
        return 'max-w-xl px-5 sm:px-8';
      case 'wide':
        return 'max-w-4xl px-8 sm:px-16';
      default:
        return 'max-w-2xl px-6 sm:px-12';
    }
  };

  const getThemeClass = () => {
    switch (readerSettings.theme) {
      case 'amoled':
        return 'bg-black text-zinc-100';
      case 'light':
        return 'bg-[#fcfbf9] text-zinc-900';
      default:
        return 'bg-[#08090d] text-zinc-200';
    }
  };

  const timerMins = Math.floor(timerSeconds / 60);
  const timerSecs = timerSeconds % 60;
  const timerFormatted = `${String(timerMins).padStart(2, '0')}:${String(timerSecs).padStart(2, '0')}`;

  // Current page highlights and annotations
  const currentPageHighlights = localHighlights.filter((h) => h.page === currentPageNumber);
  const currentPageAnnotations = localAnnotations.filter((a) => a.page === currentPageNumber);

  // Filtered annotations for the "Mis anotaciones" drawer
  const filteredAnnotations = localAnnotations.filter((ann) => {
    if (annotationsActiveTab === 'bookmarks') return ann.type === 'bookmark';
    if (annotationsActiveTab === 'notes') return ann.type === 'note' && ann.title;
    if (annotationsActiveTab === 'stickers') return ann.type === 'sticker';
    if (annotationsActiveTab === 'highlights') return ann.type === 'highlight';
    return true;
  });

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col justify-between overflow-hidden animate-fadeIn ${getThemeClass()}`}
    >
      {/* 1. TOP BAR */}
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          controlsVisible
            ? 'translate-y-0 opacity-100'
            : '-translate-y-full opacity-0 pointer-events-none'
        } glass-panel border-b border-white/10 px-3 sm:px-6 py-2.5 flex items-center justify-between shadow-2xl`}
      >
        {/* Back and exit */}
        <button
          onClick={handleFinishSession}
          className="h-9 px-3 rounded-xl bg-white/[0.06] hover:bg-white/15 text-zinc-300 hover:text-white flex items-center gap-1.5 transition-all text-xs font-semibold"
          aria-label="Salir y guardar"
        >
          <X className="w-4 h-4" />
          <span className="hidden sm:inline">Salir</span>
        </button>

        {/* Book & Chapter Title */}
        <div className="text-center min-w-0 px-2 flex-1">
          <div className="flex items-center justify-center gap-2">
            <h3 className="text-xs sm:text-sm font-bold text-white truncate font-['Syne']">
              {book.title}
            </h3>
            {/* Requisito 12: ESTAMOS LEYENDO (discreto) */}
            {readingRoomMembers.length > 0 && (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[10px] font-semibold text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {readingRoomMembers.map((m: any) => m.name).join(', ')} está leyendo
              </span>
            )}
          </div>
          <p className="text-[10px] text-zinc-400 truncate">
            {currentChapter ? currentChapter.title : book.author} · Pág. {currentPageNumber} de {totalReaderPages}
          </p>
        </div>

        {/* Right Header Controls: Pause/Resume button (Requirement 1) & Bookmark */}
        <div className="flex items-center gap-2">
          {/* CRONÓMETRO: Botón visible de Pausa / Reanudar (Requirement 1) */}
          <button
            onClick={() => setIsTimerRunning(!isTimerRunning)}
            className={`h-9 px-3 rounded-xl border flex items-center gap-1.5 transition-all text-xs font-semibold ${
              isTimerRunning
                ? 'bg-white/10 hover:bg-white/20 border-white/20 text-white'
                : 'bg-white/20 hover:bg-white/30 border-white/40 text-white shadow-lg animate-pulse'
            }`}
            title={isTimerRunning ? 'Pausar cronómetro de lectura' : 'Reanudar cronómetro'}
          >
            {isTimerRunning ? (
              <Pause className="w-3.5 h-3.5 fill-current" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span className="hidden sm:inline">{isTimerRunning ? 'Pausa' : 'Reanudar'}</span>
            <span className="font-mono text-[11px] text-zinc-300">{timerFormatted}</span>
          </button>

          {/* Bookmark Button */}
          <button
            onClick={handleToggleBookmark}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              isCurrentPageBookmarked
                ? 'bg-white/20 text-white border border-white/40 shadow-sm'
                : 'bg-white/[0.06] text-zinc-300 hover:text-white border border-white/10'
            }`}
            title={isCurrentPageBookmarked ? 'Página marcada' : 'Marcar página'}
          >
            <Bookmark className={`w-4 h-4 ${isCurrentPageBookmarked ? 'fill-white text-white' : ''}`} />
          </button>
        </div>
      </header>

      {/* 2. MAIN READING CANVAS */}
      <main
        ref={mainCanvasRef}
        onClick={handleReadingCanvasClick}
        onMouseUp={handleSelectionChange}
        onTouchEnd={handleSelectionChange}
        className="relative flex-1 overflow-y-auto pt-16 pb-20 flex flex-col items-center cursor-pointer select-text"
        title="Toca izquierda: anterior · centro: controles · derecha: siguiente"
      >
        {/* Active Stickers on this page - Requirement 9: Tamaño visible y proporción original */}
        {currentPageHighlights.some((h) => h.reaction || h.customStickerId) && (
          <div className="w-full mx-auto max-w-2xl px-6 mb-4 flex items-center gap-3 flex-wrap animate-fadeIn">
            {currentPageHighlights
              .filter((h) => h.reaction || h.customStickerId)
              .map((h) => {
                const customStk = stickers.find((s) => s.id === h.customStickerId);
                const defStk = DEFAULT_STICKERS.find((s) => s.id === h.customStickerId);

                return (
                  <div
                    key={h.id}
                    className="inline-flex items-center gap-2 p-2 rounded-2xl bg-white/[0.08] border border-white/15 backdrop-blur-md shadow-md"
                    title={h.reaction || customStk?.name || 'Sticker'}
                  >
                    {customStk?.dataUrl ? (
                      <img
                        src={customStk.dataUrl}
                        alt={customStk.name}
                        className="w-12 h-12 rounded-xl object-contain drop-shadow"
                      />
                    ) : (
                      <span className="text-3xl">{defStk?.emoji || h.reaction || '✨'}</span>
                    )}
                    {customStk?.name && (
                      <span className="text-xs font-semibold text-white/90 pr-1">
                        {customStk.name}
                      </span>
                    )}
                  </div>
                );
              })}
          </div>
        )}

        {/* Text Body - Selectable text without blocking overlays */}
        <div
          className={`w-full mx-auto ${getMarginClass()} transition-all duration-300 selectable-text ${getFontFamilyClass()} tracking-normal text-justify`}
          style={{
            fontSize: `${readerSettings.fontSize}px`,
            lineHeight: readerSettings.lineHeight,
          }}
          onClick={(e) => {
            // Allow tap navigation when clicking text without active selection
            const sel = window.getSelection();
            if (sel && sel.toString().trim().length > 0) {
              e.stopPropagation();
            }
          }}
        >
          {displayPages[pageIndex]?.split('\n\n').map((paragraph, i) => {
            const matchingHighlights = currentPageHighlights.filter(
              (h) => h.text && paragraph.includes(h.text)
            );

            // Requisito 10: Comentarios e items compartidos de los amigos de la sala para este texto o página
            const matchingShared = (roomForBook?.sharedItems || []).filter((item: RoomSharedItem) => {
              if (item.page && item.page !== currentPageNumber) return false;
              if (item.text && paragraph.includes(item.text)) return true;
              if (item.page === currentPageNumber && i === 0 && !item.text) return true;
              return false;
            });

            if (matchingHighlights.length === 0) {
              return (
                <p key={i} className="mb-6 whitespace-pre-line leading-relaxed selection:bg-white/30 relative">
                  {paragraph}
                  {/* Requisito 10: Icono discreto de mensaje junto a esa frase */}
                  {matchingShared.length > 0 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveContextSharedItems(matchingShared);
                        setContextItemIndex(0);
                      }}
                      className="inline-flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 text-xs font-bold align-middle cursor-pointer transition-all hover:scale-105 active:scale-95 shadow-sm select-none"
                      title={`${matchingShared.length} aportación(es) compartida(s) de la sala`}
                    >
                      <span>💬</span>
                      {matchingShared.length > 1 && (
                        <span className="font-mono text-[11px] font-bold text-cyan-300">
                          {matchingShared.length}
                        </span>
                      )}
                    </button>
                  )}
                </p>
              );
            }

            // Render text with highlight marks
            let contentNodes: React.ReactNode[] = [paragraph];
            matchingHighlights.forEach((hl) => {
              const nextNodes: React.ReactNode[] = [];
              contentNodes.forEach((node, nodeIdx) => {
                if (typeof node === 'string' && node.includes(hl.text)) {
                  const segments = node.split(hl.text);
                  segments.forEach((seg, sIdx) => {
                    if (sIdx > 0) {
                      nextNodes.push(
                        <mark
                          key={`mark-${hl.id}-${nodeIdx}-${sIdx}`}
                          className="rounded px-1 py-0.5 cursor-pointer font-inherit"
                          style={{
                            backgroundColor: `${hl.color}40`,
                            color: 'inherit',
                            borderBottom: `2px solid ${hl.color}`,
                          }}
                          title={`Subrayado: "${hl.text}"`}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedText(hl.text);
                            setSelectedHighlightId(hl.id);
                            setShowHighlightColorPicker(true);
                          }}
                        >
                          {hl.text}
                        </mark>
                      );
                    }
                    if (seg) nextNodes.push(seg);
                  });
                } else {
                  nextNodes.push(node);
                }
              });
              contentNodes = nextNodes;
            });

            return (
              <p key={i} className="mb-6 whitespace-pre-line leading-relaxed selection:bg-white/30 relative">
                {contentNodes}
                {/* Requisito 10: Icono discreto de mensaje junto a la frase donde alguien compartió */}
                {matchingShared.length > 0 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveContextSharedItems(matchingShared);
                      setContextItemIndex(0);
                    }}
                    className="inline-flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 text-xs font-bold align-middle cursor-pointer transition-all hover:scale-105 active:scale-95 shadow-sm select-none"
                    title={`${matchingShared.length} aportación(es) compartida(s) de la sala`}
                  >
                    <span>💬</span>
                    {matchingShared.length > 1 && (
                      <span className="font-mono text-[11px] font-bold text-cyan-300">
                        {matchingShared.length}
                      </span>
                    )}
                  </button>
                )}
              </p>
            );
          })}
        </div>

        {/* Requirement 3: Immediate Contextual Menu on text selection */}
        {/* Contains: Subrayar | Nota | Frase | Reacción | Sticker | Copiar */}
        {selectedText && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="fixed bottom-20 sm:bottom-24 left-1/2 -translate-x-1/2 z-50 glass-panel rounded-2xl p-2.5 sm:p-3 border border-white/20 shadow-2xl flex flex-col gap-2.5 max-w-[94vw] sm:max-w-lg animate-fadeIn backdrop-blur-2xl"
          >
            {/* Header with preview text */}
            <div className="flex items-center justify-between gap-3 pb-1.5 border-b border-white/10">
              <span className="text-xs text-white truncate max-w-[280px] italic">
                "{selectedText}"
              </span>
              <button
                onClick={() => {
                  setSelectedText('');
                  setSelectedHighlightId(null);
                }}
                className="text-zinc-400 hover:text-white p-1"
                aria-label="Cerrar selección"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Requisito 9: Selector Privado vs Compartir con la sala (Privado por defecto) */}
            <div className="flex items-center justify-between px-1 text-xs pb-1 border-b border-white/10">
              <span className="text-[11px] text-zinc-400 font-medium">Visibilidad:</span>
              <div className="flex items-center gap-1 bg-white/[0.04] p-0.5 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => setShareWithRoom(false)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                    !shareWithRoom
                      ? 'bg-white/20 text-white shadow-sm font-bold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  🔒 Privado
                </button>
                <button
                  type="button"
                  onClick={() => setShareWithRoom(true)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                    shareWithRoom
                      ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/30 shadow-sm font-bold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  👥 Compartir con la sala
                </button>
              </div>
            </div>

            {shareFeedback && (
              <div className="text-[11px] text-cyan-300 font-semibold text-center bg-cyan-500/10 py-1 rounded-lg border border-cyan-500/20 animate-fadeIn">
                {shareFeedback}
              </div>
            )}

            {/* Action Buttons Row */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              {/* Comentar en sala (Requirement 11) */}
              <button
                type="button"
                onClick={() => setShowRoomCommentInput(!showRoomCommentInput)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  showRoomCommentInput
                    ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/30 shadow-sm'
                    : 'bg-white/[0.08] hover:bg-white/20 text-white'
                }`}
                title="Comentar esta frase específica en la sala de lectura"
              >
                <MessageSquare className="w-3.5 h-3.5 text-cyan-300" />
                <span>Comentar en sala</span>
              </button>

              {/* 1. Subrayar / Cambiar color (Requirement 5) */}
              <div className="relative">
                <button
                  onClick={() => setShowHighlightColorPicker(!showHighlightColorPicker)}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    hasHighlightColor
                      ? 'bg-white/20 text-white border border-white/30 shadow-sm'
                      : 'bg-white/[0.08] hover:bg-white/20 text-white'
                  }`}
                  title={hasHighlightColor ? 'Cambiar color del subrayado' : 'Subrayar texto'}
                >
                  <Highlighter className="w-3.5 h-3.5 text-zinc-200" />
                  <span>{hasHighlightColor ? 'Cambiar color' : 'Subrayar'}</span>
                  {matchingHighlight?.color && (
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-white/50"
                      style={{ backgroundColor: matchingHighlight.color }}
                    />
                  )}
                </button>

                {showHighlightColorPicker && (
                  <div className="absolute bottom-full left-0 mb-2 p-2 rounded-xl glass-panel border border-white/20 shadow-2xl flex items-center gap-2 z-50 animate-fadeIn">
                    {HIGHLIGHT_COLORS.map((col) => (
                      <button
                        key={col.id}
                        onClick={() => handleSaveHighlight(col.hex)}
                        className={`w-6 h-6 rounded-full border transition-all ${
                          matchingHighlight?.color === col.hex
                            ? 'scale-125 border-white ring-2 ring-white/50'
                            : 'border-white/40 hover:scale-110'
                        }`}
                        style={{ backgroundColor: col.hex }}
                        title={col.label}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* 2. Nota */}
              <button
                onClick={() => setShowNoteInput(!showNoteInput)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  showNoteInput
                    ? 'bg-white/25 text-white'
                    : 'bg-white/[0.08] hover:bg-white/20 text-white'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5 text-zinc-200" />
                <span>Nota</span>
              </button>

              {/* 3. Frase */}
              <button
                onClick={handleSaveQuote}
                className="px-2.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <Quote className="w-3.5 h-3.5 text-zinc-200" />
                <span>Frase</span>
              </button>

              {/* 4. Reacción (Requirement 8: Solo emoji/sticker sin nombre personalizado) */}
              <div className="relative">
                <button
                  onClick={() => setShowReactionPicker(!showReactionPicker)}
                  className="px-2.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
                >
                  <Smile className="w-3.5 h-3.5 text-zinc-200" />
                  <span>Reacción</span>
                </button>

                {showReactionPicker && (
                  <div className="absolute bottom-full left-0 mb-2 p-3 rounded-2xl glass-panel border border-white/20 shadow-2xl z-50 w-64 max-h-56 overflow-y-auto space-y-2 animate-fadeIn">
                    <span className="text-[11px] font-bold text-white block">
                      Elegir reacción
                    </span>
                    <div className="grid grid-cols-5 gap-1.5 text-xl">
                      {BOOK_REACTIONS.slice(0, 20).map((r) => (
                        <button
                          key={r.id}
                          onClick={() => handleAttachReaction(r)}
                          className="p-1.5 rounded-lg hover:bg-white/20 hover:scale-125 transition-transform flex items-center justify-center"
                          title={r.label}
                        >
                          {r.emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* 5. Sticker (Requirement 9: Mayor tamaño visual manteniendo proporción) */}
              <div className="relative">
                <button
                  onClick={() => setShowStickerPicker(!showStickerPicker)}
                  className="px-2.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-zinc-200" />
                  <span>Sticker</span>
                </button>

                {showStickerPicker && (
                  <div className="absolute bottom-full left-0 mb-2 p-3 rounded-2xl glass-panel border border-white/20 shadow-2xl z-50 w-76 max-h-72 overflow-y-auto space-y-3 animate-fadeIn">
                    <div className="flex items-center justify-between pb-1 border-b border-white/10">
                      <span className="text-[11px] font-bold text-white block">
                        Elegir sticker para la frase
                      </span>
                    </div>

                    {/* Section 1: Custom user imported stickers (Requirement 3) */}
                    <div>
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold tracking-wider block mb-1.5">
                        Tus Stickers ({stickers.length})
                      </span>
                      {stickers.length === 0 ? (
                        <p className="text-[10.5px] text-zinc-400 italic py-1 bg-white/[0.02] p-2 rounded-xl border border-white/[0.04]">
                          Aún no has importado stickers personales. Puedes gestionarlos desde la barra superior.
                        </p>
                      ) : (
                        <div className="grid grid-cols-3 gap-2">
                          {stickers.map((s) => (
                            <button
                              key={s.id}
                              onClick={() =>
                                handleAttachSticker({
                                  id: s.id,
                                  name: s.name,
                                  dataUrl: s.dataUrl,
                                })
                              }
                              className="aspect-square rounded-xl bg-white/[0.06] hover:bg-white/20 border border-white/15 p-1.5 flex flex-col items-center justify-center transition-all group"
                              title={s.name}
                            >
                              <img
                                src={s.dataUrl}
                                alt={s.name}
                                className="w-14 h-14 object-contain group-hover:scale-110 transition-transform drop-shadow"
                              />
                              <span className="text-[9.5px] text-zinc-300 truncate max-w-full mt-0.5">
                                {s.name}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Section 2: Built-in app stickers */}
                    <div className="pt-1 border-t border-white/[0.06]">
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold tracking-wider block mb-1.5">
                        Stickers de la Aplicación ({DEFAULT_STICKERS.length})
                      </span>
                      <div className="grid grid-cols-4 gap-2">
                        {DEFAULT_STICKERS.map((stk) => (
                          <button
                            key={stk.id}
                            onClick={() =>
                              handleAttachSticker({
                                id: stk.id,
                                name: stk.name,
                                emoji: stk.emoji,
                              })
                            }
                            className="aspect-square rounded-xl bg-white/[0.04] hover:bg-white/20 border border-white/10 text-3xl flex items-center justify-center hover:scale-110 transition-transform"
                            title={stk.name}
                          >
                            {stk.emoji}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* 6. Copiar */}
              <button
                onClick={handleCopyText}
                className="px-2.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all ml-auto"
                title="Copiar texto al portapapeles"
              >
                {copyFeedback ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-zinc-200" />
                    <span>Copiar</span>
                  </>
                )}
              </button>
            </div>

            {/* Note input box if toggled */}
            {showNoteInput && (
              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <input
                  type="text"
                  value={tempNoteText}
                  onChange={(e) => setTempNoteText(e.target.value)}
                  placeholder="Escribe tu reflexión o nota..."
                  className="flex-1 bg-black/60 border border-white/20 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-white/40"
                  onKeyDown={(e) => e.key === 'Enter' && handleSaveNote()}
                  autoFocus
                />
                <button
                  onClick={handleSaveNote}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs"
                >
                  Guardar
                </button>
              </div>
            )}

            {/* Room comment input box if toggled (Requirement 11) */}
            {showRoomCommentInput && (
              <div className="flex items-center gap-2 pt-2 border-t border-white/10 animate-fadeIn">
                <input
                  type="text"
                  value={roomCommentText}
                  onChange={(e) => setRoomCommentText(e.target.value)}
                  placeholder={`Comentario a la sala sobre "${selectedText.slice(0, 30)}..."`}
                  className="flex-1 bg-black/60 border border-cyan-500/30 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 placeholder-zinc-500"
                  onKeyDown={(e) => e.key === 'Enter' && handleSendRoomCommentForPhrase()}
                  autoFocus
                />
                <button
                  type="button"
                  onClick={handleSendRoomCommentForPhrase}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold text-xs shadow-sm transition-all"
                >
                  Enviar
                </button>
              </div>
            )}

            {/* Requirement 6: Borrar elementos desde el lector por separado */}
            {(hasHighlightColor || matchingNoteAnn || matchingQuote || matchingReaction || matchingSticker) && (
              <div className="pt-2 border-t border-white/10 flex items-center gap-1.5 flex-wrap animate-fadeIn">
                <span className="text-[10.5px] text-zinc-400 font-semibold uppercase tracking-wider mr-1">
                  Eliminar:
                </span>
                {hasHighlightColor && (
                  <button
                    onClick={handleDeleteHighlight}
                    className="px-2 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-200 text-[11px] font-medium flex items-center gap-1 transition-all"
                    title="Quitar únicamente el subrayado"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                    <span>Subrayado</span>
                  </button>
                )}
                {matchingNoteAnn && (
                  <button
                    onClick={handleDeleteNote}
                    className="px-2 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-200 text-[11px] font-medium flex items-center gap-1 transition-all"
                    title="Eliminar únicamente la nota"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                    <span>Nota</span>
                  </button>
                )}
                {matchingQuote && (
                  <button
                    onClick={handleDeleteQuote}
                    className="px-2 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-200 text-[11px] font-medium flex items-center gap-1 transition-all"
                    title="Eliminar únicamente la frase guardada"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                    <span>Frase</span>
                  </button>
                )}
                {matchingReaction && (
                  <button
                    onClick={handleDeleteReaction}
                    className="px-2 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-200 text-[11px] font-medium flex items-center gap-1 transition-all"
                    title="Quitar únicamente la reacción"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                    <span>Reacción ({matchingReaction})</span>
                  </button>
                )}
                {matchingSticker && (
                  <button
                    onClick={handleDeleteSticker}
                    className="px-2 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-200 text-[11px] font-medium flex items-center gap-1 transition-all"
                    title="Quitar únicamente el sticker"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                    <span>Sticker</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Requisito 10: Modal Panel contextual de comentarios e interacciones compartidas de la sala */}
        {activeContextSharedItems && activeContextSharedItems.length > 0 && (
          <div
            onClick={(e) => {
              e.stopPropagation();
              setActiveContextSharedItems(null);
            }}
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="glass-panel rounded-3xl p-5 border border-white/20 shadow-2xl max-w-md w-full space-y-4 animate-scaleUp"
            >
              {/* Header con autor de la aportación y botón de cerrar */}
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2.5 min-w-0">
                  {activeContextSharedItems[contextItemIndex].userAvatar ? (
                    <img
                      src={activeContextSharedItems[contextItemIndex].userAvatar}
                      alt=""
                      className="w-9 h-9 rounded-full object-cover border border-white/20 shrink-0"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center border border-cyan-500/30 shrink-0">
                      {activeContextSharedItems[contextItemIndex].userName.charAt(0)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">
                      {activeContextSharedItems[contextItemIndex].userName}
                    </h4>
                    <span className="text-[10.5px] text-zinc-400 block truncate">
                      {activeContextSharedItems[contextItemIndex].type === 'quote'
                        ? 'Frase compartida'
                        : activeContextSharedItems[contextItemIndex].type === 'highlight'
                        ? 'Subrayado compartido'
                        : activeContextSharedItems[contextItemIndex].type === 'note'
                        ? 'Anotación compartida'
                        : activeContextSharedItems[contextItemIndex].type === 'reaction'
                        ? 'Reacción compartida'
                        : 'Sticker compartido'}
                      {activeContextSharedItems[contextItemIndex].page && ` · Pág. ${activeContextSharedItems[contextItemIndex].page}`}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveContextSharedItems(null)}
                  className="p-1 rounded-xl bg-white/[0.05] hover:bg-white/15 text-zinc-400 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Subrayado compartido y su color */}
              {activeContextSharedItems[contextItemIndex].text && (
                <div
                  className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1"
                  style={{
                    borderLeftWidth: '4px',
                    borderLeftColor: activeContextSharedItems[contextItemIndex].color || '#06b6d4',
                  }}
                >
                  <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                    Texto en el libro:
                  </span>
                  <p className="text-xs font-serif italic text-white/95 leading-relaxed">
                    "{activeContextSharedItems[contextItemIndex].text}"
                  </p>
                </div>
              )}

              {/* Comentario o anotación */}
              {activeContextSharedItems[contextItemIndex].note && (
                <div className="space-y-1 bg-white/[0.03] p-3 rounded-2xl border border-white/[0.06]">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">
                    Comentario / Anotación:
                  </span>
                  <p className="text-xs text-zinc-200 leading-relaxed font-sans">
                    {activeContextSharedItems[contextItemIndex].note}
                  </p>
                </div>
              )}

              {/* Reacción asociada */}
              {activeContextSharedItems[contextItemIndex].reaction && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-zinc-400 font-medium">Reacción:</span>
                  <span className="px-2.5 py-1 rounded-xl bg-white/10 text-xs font-medium text-white border border-white/10 shadow-sm">
                    {activeContextSharedItems[contextItemIndex].reaction}
                  </span>
                </div>
              )}

              {/* Sticker asociado */}
              {activeContextSharedItems[contextItemIndex].customStickerUrl && (
                <div className="space-y-1">
                  <span className="text-[10px] text-zinc-400 uppercase font-bold block">Sticker:</span>
                  <img
                    src={activeContextSharedItems[contextItemIndex].customStickerUrl}
                    alt="Sticker"
                    className="w-16 h-16 object-contain rounded-xl border border-white/10 p-1 bg-white/[0.02]"
                  />
                </div>
              )}

              {/* Si varias personas interactuaron con la misma parte: 💬 3 */}
              {activeContextSharedItems.length > 1 && (
                <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
                  <button
                    type="button"
                    onClick={() =>
                      setContextItemIndex((prev) =>
                        prev > 0 ? prev - 1 : activeContextSharedItems.length - 1
                      )
                    }
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center gap-1 font-medium transition-all active:scale-95"
                  >
                    ← Anterior
                  </button>
                  <span className="text-zinc-400 font-mono text-[11px]">
                    {contextItemIndex + 1} de {activeContextSharedItems.length} aportaciones
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setContextItemIndex((prev) =>
                        prev < activeContextSharedItems.length - 1 ? prev + 1 : 0
                      )
                    }
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center gap-1 font-medium transition-all active:scale-95"
                  >
                    Siguiente →
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bottom Discrete Page & Progress Indicator */}
        <div className="fixed bottom-3 left-0 right-0 z-30 pointer-events-none flex items-center justify-center">
          <div className="bg-black/75 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/15 text-[11px] font-mono text-zinc-300 flex items-center gap-3 shadow-lg">
            <span>
              Pág. {currentPageNumber} de {totalReaderPages}
            </span>
            <span className="text-white font-bold">{computedProgress}%</span>
          </div>
        </div>
      </main>

      {/* 3. BOTTOM CONTROLS FOOTER */}
      <footer
        className={`fixed bottom-0 left-0 right-0 z-40 transition-all duration-300 ${
          controlsVisible
            ? 'translate-y-0 opacity-100'
            : 'translate-y-full opacity-0 pointer-events-none'
        } glass-panel border-t border-white/10 p-3 sm:p-4 shadow-2xl space-y-3`}
      >
        <div className="max-w-md mx-auto space-y-2.5">
          {/* Top Row: Navigation Chevrons + Tools */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <button
              onClick={() => {
                setShowChaptersDrawer(true);
                setShowAnnotationsDrawer(false);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 flex flex-col items-center gap-1 text-zinc-300 hover:text-white transition-all"
            >
              <List className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px] font-medium">Índice</span>
            </button>

            <button
              onClick={() => {
                setShowChaptersDrawer(true);
                setShowAnnotationsDrawer(false);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 flex flex-col items-center gap-1 text-zinc-300 hover:text-white transition-all"
            >
              <FileText className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px] font-medium">Capítulos</span>
            </button>

            <button
              onClick={handleToggleBookmark}
              className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                isCurrentPageBookmarked
                  ? 'bg-white/20 border-white/40 text-white'
                  : 'bg-white/[0.04] hover:bg-white/[0.1] border-white/10 text-zinc-300 hover:text-white'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isCurrentPageBookmarked ? 'fill-white text-white' : 'text-zinc-300'}`} />
              <span className="text-[11px] font-medium">Marcador</span>
            </button>

            <button
              onClick={() => {
                setShowSettingsDrawer(!showSettingsDrawer);
                setShowAnnotationsDrawer(false);
                setShowChaptersDrawer(false);
              }}
              className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                showSettingsDrawer
                  ? 'bg-white/20 border-white/40 text-white'
                  : 'bg-white/[0.04] hover:bg-white/[0.1] border-white/10 text-zinc-300 hover:text-white'
              }`}
            >
              <Settings2 className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px] font-medium">Ajustes</span>
            </button>
          </div>

          {/* Bottom Row: 4 Actions (Notas | Subrayar | Reacciones | Stickers) */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <button
              onClick={() => {
                setAnnotationsActiveTab('notes');
                setShowAnnotationsDrawer(true);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-all"
            >
              <Edit3 className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px]">Notas</span>
            </button>

            <button
              onClick={() => {
                setAnnotationsActiveTab('highlights');
                setShowAnnotationsDrawer(true);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-all"
            >
              <Highlighter className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px]">Subrayar</span>
            </button>

            <button
              onClick={() => {
                setAnnotationsActiveTab('all');
                setShowAnnotationsDrawer(true);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-all"
            >
              <Smile className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px]">Reacciones</span>
            </button>

            <button
              onClick={() => {
                setAnnotationsActiveTab('stickers');
                setShowAnnotationsDrawer(true);
                setShowSettingsDrawer(false);
              }}
              className="p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-all"
            >
              <ImageIcon className="w-4 h-4 text-zinc-300" />
              <span className="text-[11px]">Stickers</span>
            </button>
          </div>
        </div>
      </footer>

      {/* 4. DRAWER: AJUSTES DE LECTURA */}
      {showSettingsDrawer && (
        <div className="fixed bottom-28 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-50 glass-panel rounded-3xl p-5 border border-white/15 shadow-2xl space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <span className="text-xs font-bold uppercase tracking-wider text-white">
              Ajustes de lectura
            </span>
            <button
              onClick={() => setShowSettingsDrawer(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Tamaño de letra */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-300 font-medium">Tamaño de letra</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  onUpdateReaderSettings({
                    ...readerSettings,
                    fontSize: Math.max(14, readerSettings.fontSize - 1),
                  })
                }
                className="w-9 h-8 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center transition-all"
              >
                A−
              </button>
              <span className="font-mono text-xs text-white w-6 text-center">
                {readerSettings.fontSize}
              </span>
              <button
                onClick={() =>
                  onUpdateReaderSettings({
                    ...readerSettings,
                    fontSize: Math.min(28, readerSettings.fontSize + 1),
                  })
                }
                className="w-9 h-8 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center transition-all"
              >
                A+
              </button>
            </div>
          </div>

          {/* Tipo de letra */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-300 font-medium">Tipo de letra</span>
            <div className="flex items-center p-1 rounded-xl bg-white/[0.06] border border-white/10 text-xs">
              {(['serif', 'sans', 'mono'] as const).map((font) => (
                <button
                  key={font}
                  onClick={() => onUpdateReaderSettings({ ...readerSettings, fontFamily: font })}
                  className={`px-3 py-1 rounded-lg font-medium capitalize transition-all ${
                    readerSettings.fontFamily === font
                      ? 'bg-white/20 text-white font-semibold shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {font === 'serif' ? 'Serif' : font === 'sans' ? 'Sans' : 'Mono'}
                </button>
              ))}
            </div>
          </div>

          {/* Márgenes */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-300 font-medium">Márgenes</span>
            <div className="flex items-center gap-1.5">
              {(['narrow', 'normal', 'wide'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => onUpdateReaderSettings({ ...readerSettings, margins: m })}
                  className={`w-9 h-8 rounded-xl border flex items-center justify-center transition-all ${
                    readerSettings.margins === m
                      ? 'bg-white/20 border-white/30 text-white'
                      : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
                  }`}
                  title={`Márgenes ${m}`}
                >
                  <AlignLeft
                    className={`w-3.5 h-3.5 ${
                      m === 'narrow' ? 'scale-75' : m === 'wide' ? 'scale-125' : ''
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Modo de lectura */}
          <div className="flex items-center justify-between pt-2 border-t border-white/10">
            <span className="text-xs text-zinc-300 font-medium">Modo de lectura</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onUpdateReaderSettings({ ...readerSettings, theme: 'dark' })}
                className={`p-2 rounded-xl border transition-all ${
                  readerSettings.theme === 'dark'
                    ? 'bg-white/20 border-white/40 text-white font-semibold'
                    : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
                }`}
                title="Modo Oscuro Glass"
              >
                <Moon className="w-4 h-4" />
              </button>
              <button
                onClick={() => onUpdateReaderSettings({ ...readerSettings, theme: 'amoled' })}
                className={`p-2 rounded-xl border transition-all ${
                  readerSettings.theme === 'amoled'
                    ? 'bg-white/20 border-white/40 text-white font-semibold'
                    : 'bg-black border-white/10 text-zinc-400 hover:text-white'
                }`}
                title="Modo AMOLED"
              >
                <div className="w-4 h-4 rounded-full bg-black border border-white/30" />
              </button>
              <button
                onClick={() => onUpdateReaderSettings({ ...readerSettings, theme: 'light' })}
                className={`p-2 rounded-xl border transition-all ${
                  readerSettings.theme === 'light'
                    ? 'bg-white/20 border-white/40 text-white font-semibold'
                    : 'bg-white/10 border-white/10 text-zinc-400 hover:text-white'
                }`}
                title="Modo Claro"
              >
                <Sun className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. DRAWER: “MIS ANOTACIONES” */}
      {showAnnotationsDrawer && (
        <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 glass-panel border-l border-white/15 p-5 shadow-2xl flex flex-col justify-between animate-fadeIn">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <span className="font-bold text-white uppercase tracking-wider text-xs flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-zinc-300" />
                <span>Mis anotaciones</span>
              </span>
              <button
                onClick={() => setShowAnnotationsDrawer(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Sub-tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-3 no-scrollbar text-xs">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'bookmarks', label: 'Marcadores' },
                { id: 'notes', label: 'Notas' },
                { id: 'stickers', label: 'Stickers' },
                { id: 'highlights', label: 'Subrayados' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setAnnotationsActiveTab(tab.id as any)}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
                    annotationsActiveTab === tab.id
                      ? 'bg-white/15 text-white font-semibold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* List of Annotations */}
            <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
              {filteredAnnotations.length === 0 ? (
                <div className="text-center py-10 text-zinc-400 text-xs">
                  <Bookmark className="w-8 h-8 text-zinc-600 mx-auto mb-2 opacity-50" />
                  <p>No hay elementos guardados en esta categoría.</p>
                </div>
              ) : (
                filteredAnnotations.map((ann) => (
                  <div
                    key={ann.id}
                    onClick={() => handleJumpToPage(ann.page)}
                    className="p-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] cursor-pointer transition-all group relative overflow-hidden"
                  >
                    {ann.color && (
                      <div
                        className="absolute left-0 top-0 bottom-0 w-1"
                        style={{ backgroundColor: ann.color }}
                      />
                    )}

                    <div className="flex items-center justify-between text-[11px] mb-1 pl-1">
                      <span className="font-semibold text-white font-mono">
                        Pág. {ann.page}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-zinc-500 capitalize">{ann.type}</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteAnnotationById(ann.id, ann.type, ann.page, ann.text);
                          }}
                          className="p-1 rounded-md text-zinc-500 hover:text-red-400 hover:bg-white/[0.08] transition-colors"
                          title="Eliminar elemento"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {ann.text && (
                      <p className="text-xs text-white/90 italic font-serif line-clamp-2 pl-1">
                        "{ann.text}"
                      </p>
                    )}

                    {ann.title && (
                      <p className="text-xs text-zinc-300 font-medium mt-1 pl-1">
                        {ann.title}
                      </p>
                    )}

                    {/* Requirement 9: Stickers más grandes con proporción original */}
                    {(ann.reaction || ann.customStickerUrl) && (
                      <div className="mt-2 flex items-center gap-2 pl-1">
                        {ann.customStickerUrl ? (
                          <img
                            src={ann.customStickerUrl}
                            alt=""
                            className="w-12 h-12 rounded-xl object-contain drop-shadow"
                          />
                        ) : (
                          <span className="text-2xl">{ann.reaction}</span>
                        )}
                        <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/[0.08] text-white font-medium">
                          {ann.reaction}
                        </span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 6. DRAWER: CAPÍTULOS / ÍNDICE */}
      {showChaptersDrawer && (
        <div className="fixed inset-y-0 left-0 z-50 w-80 glass-panel border-r border-white/15 p-5 shadow-2xl flex flex-col justify-between animate-fadeIn">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <span className="font-bold text-white uppercase tracking-wider text-xs flex items-center gap-2">
                <List className="w-4 h-4 text-zinc-300" />
                <span>Tabla de Capítulos</span>
              </span>
              <button
                onClick={() => setShowChaptersDrawer(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 max-h-[75vh] overflow-y-auto pr-1">
              {(
                book.chapters || [
                  { id: 'c1', title: 'Capítulo 1', pageStart: 1 },
                  { id: 'c2', title: 'Capítulo 2', pageStart: Math.round(totalReaderPages * 0.35) },
                  { id: 'c3', title: 'Capítulo 3', pageStart: Math.round(totalReaderPages * 0.7) },
                ]
              ).map((ch) => (
                <button
                  key={ch.id}
                  onClick={() => {
                    handleJumpToPage(ch.pageStart || ch.page || 1);
                    setShowChaptersDrawer(false);
                  }}
                  className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                    currentChapter?.id === ch.id
                      ? 'bg-white/20 border-white/30 text-white font-semibold'
                      : 'bg-white/[0.03] hover:bg-white/[0.08] border-white/[0.05] text-zinc-300'
                  }`}
                >
                  <span className="text-xs truncate">{ch.title}</span>
                  <span className="text-[10px] font-mono text-zinc-400">p. {ch.pageStart || ch.page || 1}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
