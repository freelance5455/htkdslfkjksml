import React, { useState, useEffect } from 'react';
import { X, Plus, Edit3, Trash2, Check, Settings2 } from 'lucide-react';
import {
  Account,
  CustomCategory,
  TransactionRecord,
  TransactionType,
} from '../types/finance';
import {
  getTodayISO,
  paisaToInputString,
  parseAmountToPaisa,
} from '../utils/money';

interface TransactionModalProps {
  open: boolean;
  initialType?: TransactionType;
  editingTransaction?: TransactionRecord | null;
  accounts: Account[];
  categories: CustomCategory[];
  onClose: () => void;
  onSave: (txData: Omit<TransactionRecord, 'id' | 'createdAt'>, existingId?: string) => void;
  onAddCategory: (cat: CustomCategory) => void;
  onUpdateCategory: (catId: string, newNameBn: string) => void;
  onDeleteCategory: (catId: string) => void;
}

const TX_TYPE_OPTIONS: {
  type: 'INCOME' | 'EXPENSE';
  labelBn: string;
}[] = [
  { type: 'INCOME', labelBn: 'আয়' },
  { type: 'EXPENSE', labelBn: 'ব্যয়' },
];

export const TransactionModal: React.FC<TransactionModalProps> = ({
  open,
  initialType = 'EXPENSE',
  editingTransaction,
  accounts,
  categories,
  onClose,
  onSave,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
}) => {
  const normalizedInitialType: 'INCOME' | 'EXPENSE' =
    initialType === 'INCOME' || initialType === 'SALE' ? 'INCOME' : 'EXPENSE';

  const [type, setType] = useState<'INCOME' | 'EXPENSE'>(normalizedInitialType);
  const [amountInput, setAmountInput] = useState('');
  const [date, setDate] = useState(getTodayISO());
  const [category, setCategory] = useState('');
  const [accountId, setAccountId] = useState(accounts[0]?.id ?? '');
  const [note, setNote] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Category Management State (Add / Edit / Delete)
  const [showManageCategories, setShowManageCategories] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  const availableCategories = categories.filter((c) =>
    c.applicableTo.includes(type)
  );

  useEffect(() => {
    if (!open) return;
    setErrorMsg(null);
    setShowManageCategories(false);
    setNewCategoryInput('');
    setEditingCatId(null);

    if (editingTransaction) {
      const editType: 'INCOME' | 'EXPENSE' =
        editingTransaction.type === 'INCOME' || editingTransaction.type === 'SALE'
          ? 'INCOME'
          : 'EXPENSE';
      setType(editType);
      setAmountInput(paisaToInputString(editingTransaction.amountPaisa));
      setDate(editingTransaction.date);
      setCategory(editingTransaction.category);
      setAccountId(editingTransaction.accountId);
      setNote(editingTransaction.note);
    } else {
      setType(normalizedInitialType);
      setAmountInput('');
      setDate(getTodayISO());
      const matchingCats = categories.filter((c) =>
        c.applicableTo.includes(normalizedInitialType)
      );
      setCategory(matchingCats[0]?.nameBn ?? 'সাধারণ');
      setAccountId(accounts[0]?.id ?? '');
      setNote('');
    }
  }, [open, editingTransaction, normalizedInitialType, accounts]);

  const handleTypeSwitch = (nextType: 'INCOME' | 'EXPENSE') => {
    setType(nextType);
    setErrorMsg(null);
    setEditingCatId(null);
    const matching = categories.filter((c) => c.applicableTo.includes(nextType));
    setCategory(matching[0]?.nameBn ?? 'সাধারণ');
  };

  const handleCreateCustomCategory = () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    const newCat: CustomCategory = {
      id: `cat-custom-${Date.now()}`,
      nameBn: trimmed,
      nameEn: trimmed,
      applicableTo: [type],
    };
    onAddCategory(newCat);
    setCategory(newCat.nameBn);
    setNewCategoryInput('');
  };

  const handleSaveEditedCategory = (catId: string, oldName: string) => {
    const trimmed = editingCatName.trim();
    if (!trimmed) return;
    onUpdateCategory(catId, trimmed);
    if (category === oldName) {
      setCategory(trimmed);
    }
    setEditingCatId(null);
    setEditingCatName('');
  };

  const handleRemoveCategory = (cat: CustomCategory) => {
    onDeleteCategory(cat.id);
    if (category === cat.nameBn) {
      const remaining = availableCategories.filter((c) => c.id !== cat.id);
      setCategory(remaining[0]?.nameBn ?? 'সাধারণ');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const parsedPaisa = parseAmountToPaisa(amountInput);
    if (parsedPaisa === null || parsedPaisa <= 0) {
      setErrorMsg('অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন (যেমন: ৫০০ বা ১২৫০)।');
      return;
    }

    if (!date) {
      setErrorMsg('অনুগ্রহ করে লেনদেনের তারিখ নির্বাচন করুন।');
      return;
    }

    if (!accountId) {
      setErrorMsg('অনুগ্রহ করে কোন হিসাবে যাবে তা নির্বাচন করুন।');
      return;
    }

    onSave(
      {
        type,
        amountPaisa: parsedPaisa,
        date,
        category: category || 'সাধারণ',
        accountId,
        note: note.trim() || category,
      },
      editingTransaction?.id
    );
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div
        role="dialog"
        aria-modal="true"
        className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto shadow-2xl"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3 sm:hidden" />

        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
              {editingTransaction ? 'হিসাব সম্পাদনা করুন' : 'নতুন হিসাব যোগ করুন'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Segmented Transaction Type Control: Only আয় and ব্যয় */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              হিসাবের ধরন
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {TX_TYPE_OPTIONS.map((opt) => {
                const active = type === opt.type;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => handleTypeSwitch(opt.type)}
                    className={`min-h-[44px] px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center ${
                      active
                        ? opt.type === 'INCOME'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-red-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <span>{opt.labelBn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
              {errorMsg}
            </div>
          )}

          {/* Amount & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                টাকার পরিমাণ *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-base font-semibold text-slate-500">
                  ৳
                </span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={amountInput}
                  onChange={(e) => setAmountInput(e.target.value)}
                  placeholder="১২৫০"
                  required
                  className="w-full min-h-[44px] pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-base font-mono tabular-nums text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                তারিখ *
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
          </div>

          {/* Account & Category Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                কোন হিসাবে যাবে *
              </label>
              <select
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.nameBn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  খাত *
                </label>
                <button
                  type="button"
                  onClick={() => setShowManageCategories((prev) => !prev)}
                  className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
                >
                  <Settings2 className="w-3.5 h-3.5" />
                  <span>খাত পরিচালনা</span>
                </button>
              </div>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {availableCategories.map((c) => (
                  <option key={c.id} value={c.nameBn}>
                    {c.nameBn}
                  </option>
                ))}
                {category &&
                  !availableCategories.some((c) => c.nameBn === category) && (
                    <option value={category}>{category}</option>
                  )}
              </select>
            </div>
          </div>

          {/* Category Add / Edit / Delete Panel */}
          {showManageCategories && (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {type === 'INCOME' ? 'আয়ের খাতসমূহ' : 'ব্যয়ের খাতসমূহ'} (যোগ, সম্পাদনা ও মুছে ফেলুন)
                </p>
              </div>

              {/* Add new category */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newCategoryInput}
                  onChange={(e) => setNewCategoryInput(e.target.value)}
                  placeholder="নতুন খাতের নাম লিখুন..."
                  className="flex-1 min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100"
                />
                <button
                  type="button"
                  onClick={handleCreateCustomCategory}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-1 whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>যোগ করুন</span>
                </button>
              </div>

              {/* Existing categories list with Edit & Delete */}
              <div className="max-h-40 overflow-y-auto divide-y divide-slate-200/70 dark:divide-slate-700/70">
                {availableCategories.map((c) => {
                  const isEditingThis = editingCatId === c.id;
                  return (
                    <div
                      key={c.id}
                      className="py-2 flex items-center justify-between gap-2 text-xs"
                    >
                      {isEditingThis ? (
                        <div className="flex-1 flex items-center gap-1.5">
                          <input
                            type="text"
                            value={editingCatName}
                            onChange={(e) => setEditingCatName(e.target.value)}
                            className="flex-1 min-h-[32px] px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditedCategory(c.id, c.nameBn)}
                            className="p-1.5 rounded-md bg-emerald-600 text-white hover:bg-emerald-700"
                            title="সংরক্ষণ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingCatId(null)}
                            className="p-1.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
                            title="বাতিল"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="text-slate-800 dark:text-slate-200 font-medium truncate">
                            {c.nameBn}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingCatId(c.id);
                                setEditingCatName(c.nameBn);
                              }}
                              className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-700"
                              title="খাত সম্পাদনা"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveCategory(c)}
                              className="p-1.5 rounded-md text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40"
                              title="খাত মুছে ফেলুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Note */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              বিবরণ
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="যেমন: খুচরা বিক্রয়, দোকান ভাড়া, বাজার খরচ..."
              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors whitespace-nowrap shrink-0"
            >
              {editingTransaction ? 'আপডেট সংরক্ষণ করুন' : 'সংরক্ষণ করুন'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
