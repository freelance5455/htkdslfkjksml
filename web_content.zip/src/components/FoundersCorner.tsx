import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, MarketItem, Coupon, ItemCategory, CustomFrameConfig, CustomThemePalette } from '../types';
import { Crown, PlusCircle, Tag, Ticket, Sparkles, Check, DollarSign, Megaphone, Zap, Paintbrush, Palette, Eye, RotateCcw, Sliders, Eraser } from 'lucide-react';
import { playLevelUpSound, playErrorSound, playCoinSound } from '../utils/soundEffects';
import { triggerConfetti } from '../utils/confetti';

interface FoundersCornerProps {
  user: UserProfile;
  marketItems: MarketItem[];
  onRefreshMarket: () => void;
  onAddCoins: (amount: number) => void;
  soundEnabled: boolean;
}

export const FoundersCorner: React.FC<FoundersCornerProps> = ({
  user,
  marketItems,
  onRefreshMarket,
  onAddCoins,
  soundEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<'add_product' | 'edit_prices' | 'coupons' | 'broadcast'>('add_product');

  // Add Product State
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<ItemCategory>('avatar');
  const [newProdPrice, setNewProdPrice] = useState(300);
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdIcon, setNewProdIcon] = useState('👑');
  const [newProdRarity, setNewProdRarity] = useState<'common' | 'rare' | 'epic' | 'legendary'>('legendary');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // ===================== AVATAR DRAWING PAD STATE =====================
  const [avatarCreationMode, setAvatarCreationMode] = useState<'draw' | 'icon'>('draw');
  const [brushColor, setBrushColor] = useState('#facc15');
  const [brushSize, setBrushSize] = useState(5);
  const [drawnAvatarData, setDrawnAvatarData] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawingRef = useRef(false);

  // ===================== CUSTOM FRAME DESIGNER STATE =====================
  const [frameConfig, setFrameConfig] = useState<CustomFrameConfig>({
    borderColor1: '#06b6d4',
    borderColor2: '#ec4899',
    glowColor: '#38bdf8',
    animation: 'pulse',
    borderWidth: 3,
  });

  // ===================== CUSTOM THEME PALETTE DESIGNER STATE =====================
  const [themePalette, setThemePalette] = useState<CustomThemePalette>({
    bg: '#050814',
    card: '#0c1329',
    border: '#1e293b',
    accent: 'bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500',
    textAccent: 'text-cyan-400',
    gradient: 'from-slate-950 via-cyan-950/40 to-slate-950',
  });

  // Edit Prices State
  const [selectedItemId, setSelectedItemId] = useState(marketItems[0]?.id || '');
  const [editPriceValue, setEditPriceValue] = useState(250);

  // Coupons State
  const [couponCode, setCouponCode] = useState('');
  const [couponCoins, setCouponCoins] = useState(500);
  const [couponMaxUses, setCouponMaxUses] = useState(100);
  const [couponsList, setCouponsList] = useState<Coupon[]>([]);

  // Announcement State
  const [announcementText, setAnnouncementText] = useState('');

  // Fetch Coupons on mount
  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    try {
      const res = await fetch('/api/coupons', {
        headers: {
          'x-user-role': user.role,
          'x-user-email': user.email,
        },
      });
      if (res.ok) {
        const data = await res.json();
        setCouponsList(data.coupons || []);
      }
    } catch {
      //
    }
  };

  // Canvas Drawing Logic
  useEffect(() => {
    if (newProdCategory === 'avatar' && avatarCreationMode === 'draw') {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Dark background for drawing
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
  }, [newProdCategory, avatarCreationMode]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawingRef.current = true;
    draw(e);
  };

  const stopDrawing = () => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;
    const canvas = canvasRef.current;
    if (canvas) {
      setDrawnAvatarData(canvas.toDataURL('image/png'));
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushSize;
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    setDrawnAvatarData(null);
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    setIsSubmitting(true);
    setStatusMsg(null);

    let drawingData = undefined;
    if (newProdCategory === 'avatar' && avatarCreationMode === 'draw') {
      const canvas = canvasRef.current;
      drawingData = canvas ? canvas.toDataURL('image/png') : (drawnAvatarData || undefined);
    }

    try {
      const res = await fetch('/api/market/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': user.role,
          'x-user-email': user.email,
        },
        body: JSON.stringify({
          name: newProdName.trim(),
          category: newProdCategory,
          price: newProdPrice,
          description: newProdDesc.trim() || `عنصر ${newProdCategory} مبتكر من تصميم المؤسس`,
          icon: newProdCategory === 'avatar' && avatarCreationMode === 'draw' ? '🎨' : newProdIcon,
          rarity: newProdRarity,
          customDrawing: drawingData,
          customFrameConfig: newProdCategory === 'frame' ? frameConfig : undefined,
          customThemePalette: newProdCategory === 'theme' ? themePalette : undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشلت إضافة المنتج');

      if (soundEnabled) playLevelUpSound();
      triggerConfetti();
      setStatusMsg({ text: `تم نشر «${newProdName}» بنجاح في الماركت لجميع المستخدمين! 🎉`, type: 'success' });
      setNewProdName('');
      setNewProdDesc('');
      clearCanvas();
      onRefreshMarket();
    } catch (err: any) {
      if (soundEnabled) playErrorSound();
      setStatusMsg({ text: err.message || 'حدث خطأ أثناء إضافة المنتج', type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdatePrice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItemId) return;

    setIsSubmitting(true);
    setStatusMsg(null);

    try {
      const res = await fetch('/api/market/update-price', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': user.role,
          'x-user-email': user.email,
        },
        body: JSON.stringify({
          itemId: selectedItemId,
          newPrice: editPriceValue,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل تحديث السعر');

      if (soundEnabled) playCoinSound();
      setStatusMsg({ text: `تم تحديث سعر المنتج بنجاح إلى ${editPriceValue} نقطة! 🪙`, type: 'success' });
      onRefreshMarket();
    } catch (err: any) {
      if (soundEnabled) playErrorSound();
      setStatusMsg({ text: err.message || 'حدث خطأ أثناء التحديث', type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    setIsSubmitting(true);
    setStatusMsg(null);

    try {
      const res = await fetch('/api/coupons/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': user.role,
          'x-user-email': user.email,
        },
        body: JSON.stringify({
          code: couponCode.trim().toUpperCase(),
          coinsReward: couponCoins,
          maxUses: couponMaxUses,
          description: `كوبون هدية خاص من المؤسس`,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل إنشاء الكوبون');

      if (soundEnabled) playLevelUpSound();
      triggerConfetti();
      setStatusMsg({ text: `تم إنشاء كود الكوبون [${couponCode.toUpperCase()}] بقيمة ${couponCoins} نقطة! 🎟️`, type: 'success' });
      setCouponCode('');
      fetchCoupons();
    } catch (err: any) {
      if (soundEnabled) playErrorSound();
      setStatusMsg({ text: err.message || 'حدث خطأ في إنشاء الكوبون', type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBroadcastAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementText.trim()) return;

    try {
      const res = await fetch('/api/announcement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': user.role,
          'x-user-email': user.email,
        },
        body: JSON.stringify({ message: announcementText.trim() }),
      });
      if (res.ok) {
        if (soundEnabled) playCoinSound();
        setStatusMsg({ text: 'تم بث الإعلان الإداري للجميع بنجاح! 📢', type: 'success' });
        setAnnouncementText('');
      }
    } catch {
      //
    }
  };

  const palettePresets = [
    { name: 'فضاء كوني 🌌', bg: '#030712', card: '#0f172a', border: '#a855f7', accent: 'bg-gradient-to-r from-purple-600 to-indigo-600', textAccent: 'text-purple-400' },
    { name: 'سايبر نيون 🌆', bg: '#08080c', card: '#12111a', border: '#06b6d4', accent: 'bg-gradient-to-r from-cyan-500 to-pink-500', textAccent: 'text-cyan-400' },
    { name: 'زمردي ملكي 🌲', bg: '#02120b', card: '#062416', border: '#10b981', accent: 'bg-gradient-to-r from-emerald-600 to-teal-600', textAccent: 'text-emerald-400' },
    { name: 'ذهب إمبراطوري 👑', bg: '#120f06', card: '#241d08', border: '#facc15', accent: 'bg-gradient-to-r from-amber-500 to-yellow-500', textAccent: 'text-amber-400' },
    { name: 'ياقوت دموي 🩸', bg: '#140507', card: '#290b0e', border: '#ef4444', accent: 'bg-gradient-to-r from-red-600 to-rose-600', textAccent: 'text-red-400' },
  ];

  return (
    <div className="py-3 px-2 max-w-2xl mx-auto">
      
      {/* Founder Secret Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-950 via-slate-900 to-yellow-950/80 border-2 border-amber-500/50 mb-5 shadow-2xl relative overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-3xl shadow-lg">
            👑
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-amber-300">
                استوديو المؤسس وكورنر الإدارة
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black">
                VIP حصري
              </span>
            </div>
            <p className="text-xs text-amber-200/80 mt-1">
              أهلاً بك يا مؤسس! يمكنك رسم الأفاتار، تصميم الإطارات المتوهجة، وهندسة ألوان الثيمات بحرية تامة 🎨
            </p>
          </div>
        </div>

        {/* Quick Testing Coins Booster */}
        <div className="mt-4 pt-3 border-t border-amber-500/30 flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-400" />
            شحن رصيد تجريبي فوري للمؤسس:
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onAddCoins(1000);
                if (soundEnabled) playCoinSound();
                triggerConfetti();
              }}
              className="py-1 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all cursor-pointer"
            >
              +1,000 نقطة 🪙
            </button>
            <button
              onClick={() => {
                onAddCoins(5000);
                if (soundEnabled) playLevelUpSound();
                triggerConfetti();
              }}
              className="py-1 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-all cursor-pointer shadow-md"
            >
              +5,000 نقطة 👑
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-5">
        <button
          onClick={() => { setActiveTab('add_product'); setStatusMsg(null); }}
          className={`py-2 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'add_product'
              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <Paintbrush className="w-4 h-4" />
          <span>رسم وتصميم عنصر</span>
        </button>

        <button
          onClick={() => { setActiveTab('edit_prices'); setStatusMsg(null); }}
          className={`py-2 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'edit_prices'
              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>تعديل الأسعار</span>
        </button>

        <button
          onClick={() => { setActiveTab('coupons'); setStatusMsg(null); }}
          className={`py-2 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'coupons'
              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <Ticket className="w-4 h-4" />
          <span>توليد الكوبونات</span>
        </button>

        <button
          onClick={() => { setActiveTab('broadcast'); setStatusMsg(null); }}
          className={`py-2 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'broadcast'
              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>بث إعلان</span>
        </button>
      </div>

      {statusMsg && (
        <div
          className={`mb-4 p-3 rounded-2xl text-xs font-bold text-center border ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
              : 'bg-red-950/60 border-red-500/40 text-red-300'
          }`}
        >
          {statusMsg.text}
        </div>
      )}

      {/* 1. Add / Design Product Form */}
      {activeTab === 'add_product' && (
        <form
          onSubmit={handleAddProduct}
          className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/30 space-y-5 shadow-xl text-right"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-400">استوديو الإبداع والتصميم المباشر</span>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>إنشاء ونشر عنصر تفاعلي جديد</span>
            </h3>
          </div>

          {/* Basic Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسم العنصر:</label>
              <input
                type="text"
                required
                value={newProdName}
                onChange={(e) => setNewProdName(e.target.value)}
                placeholder="مثال: أفاتار الصقر الذهبي / إطار اللهب النيون"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">القسم / التصنيف:</label>
              <select
                value={newProdCategory}
                onChange={(e) => setNewProdCategory(e.target.value as ItemCategory)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right"
              >
                <option value="avatar">🎭 أفاتار (رسم حر أو شكل وألوان)</option>
                <option value="frame">🖼️ إطار بصري متوهج (تصميم حواف وتوهج)</option>
                <option value="theme">🎨 ثيم كامل (هندسة ألوان وخلفيات)</option>
                <option value="title">📜 لقب نصي (Title)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">السعر بالنقاط:</label>
              <input
                type="number"
                min="0"
                required
                value={newProdPrice}
                onChange={(e) => setNewProdPrice(parseInt(e.target.value, 10) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-center font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الندرة (Rarity):</label>
              <select
                value={newProdRarity}
                onChange={(e) => setNewProdRarity(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right"
              >
                <option value="common">عادي (Common)</option>
                <option value="rare">نادر (Rare) 💎</option>
                <option value="epic">ملحمي (Epic) 🔮</option>
                <option value="legendary">أسطوري (Legendary) 👑</option>
              </select>
            </div>
          </div>

          {/* ==================== A. AVATAR DRAWING & DESIGN STUDIO ==================== */}
          {newProdCategory === 'avatar' && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-indigo-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setAvatarCreationMode('draw')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      avatarCreationMode === 'draw' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    🖌️ لوحة الرسم بالفرشاة
                  </button>
                  <button
                    type="button"
                    onClick={() => setAvatarCreationMode('icon')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      avatarCreationMode === 'icon' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    ⭐ أيقونة ورمز جاهز
                  </button>
                </div>
                <span className="text-xs font-black text-indigo-400">تصميم ورسم الأفاتار:</span>
              </div>

              {avatarCreationMode === 'draw' ? (
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
                  {/* Drawing Canvas */}
                  <div className="relative">
                    <canvas
                      ref={canvasRef}
                      width={180}
                      height={180}
                      onMouseDown={startDrawing}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      onMouseMove={draw}
                      onTouchStart={startDrawing}
                      onTouchEnd={stopDrawing}
                      onTouchMove={draw}
                      className="border-2 border-indigo-500/50 rounded-2xl bg-slate-950 shadow-inner cursor-crosshair touch-none"
                    />
                    <div className="absolute top-1.5 left-1.5 flex gap-1">
                      <button
                        type="button"
                        onClick={clearCanvas}
                        className="p-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 cursor-pointer"
                        title="مسح الرسم"
                      >
                        <Eraser className="w-3 h-3 text-red-400" />
                        <span>مسح</span>
                      </button>
                    </div>
                  </div>

                  {/* Colors & Brush Size Controls */}
                  <div className="space-y-3 text-right">
                    <div>
                      <span className="block text-[11px] text-slate-400 mb-1.5">اختر لون الفرشاة:</span>
                      <div className="flex flex-wrap gap-1.5 max-w-[180px]">
                        {['#facc15', '#06b6d4', '#ec4899', '#f97316', '#10b981', '#a855f7', '#ffffff', '#ef4444', '#3b82f6'].map((color) => (
                          <button
                            key={color}
                            type="button"
                            onClick={() => setBrushColor(color)}
                            style={{ backgroundColor: color }}
                            className={`w-6 h-6 rounded-full border-2 transition-transform cursor-pointer ${
                              brushColor === color ? 'border-white scale-125 shadow-md' : 'border-transparent'
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="block text-[11px] text-slate-400 mb-1">سُمك الفرشاة: {brushSize}px</span>
                      <input
                        type="range"
                        min="2"
                        max="14"
                        value={brushSize}
                        onChange={(e) => setBrushSize(parseInt(e.target.value, 10))}
                        className="w-32 accent-indigo-500"
                      />
                    </div>

                    <div className="text-[11px] text-emerald-400 font-bold">
                      ✓ ارسم مباشرة بإصبعك أو الماوس
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-300">اختر الرمز أو الإيموجي:</label>
                  <input
                    type="text"
                    value={newProdIcon}
                    onChange={(e) => setNewProdIcon(e.target.value)}
                    placeholder="🦅, 🐉, 👑, 🚀, 💎"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xl text-center"
                  />
                </div>
              )}
            </div>
          )}

          {/* ==================== B. FRAME VISUAL DESIGNER ==================== */}
          {newProdCategory === 'frame' && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-4 text-right">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-bold">تحكم في التوهج والحدود والحركة</span>
                <h4 className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>مصمم الإطارات المتوهجة المخصصة:</span>
                </h4>
              </div>

              {/* Color Pickers */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">اللون الأساسي للإطار:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={frameConfig.borderColor1}
                      onChange={(e) => setFrameConfig({ ...frameConfig, borderColor1: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{frameConfig.borderColor1}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">لون التدرج الثانوي:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={frameConfig.borderColor2}
                      onChange={(e) => setFrameConfig({ ...frameConfig, borderColor2: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{frameConfig.borderColor2}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">لون التوهج (Glow):</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={frameConfig.glowColor}
                      onChange={(e) => setFrameConfig({ ...frameConfig, glowColor: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{frameConfig.glowColor}</span>
                  </div>
                </div>
              </div>

              {/* Animation Mode */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">نمط الحركة والتوهج:</label>
                  <select
                    value={frameConfig.animation}
                    onChange={(e) => setFrameConfig({ ...frameConfig, animation: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 text-right"
                  >
                    <option value="pulse">نبض نيون متوهج (Pulse)</option>
                    <option value="flame">لهب ناري متقد (Flame)</option>
                    <option value="electric">وميض كهربائي خاطف (Electric)</option>
                    <option value="spin">دوران مجرة حلزوني (Spin)</option>
                    <option value="portal">بوابة أبعاد كونية (Portal)</option>
                  </select>
                </div>

                {/* Live Frame Preview */}
                <div className="flex items-center justify-center p-2 rounded-2xl bg-slate-900/60 border border-slate-800">
                  <div
                    style={{
                      borderWidth: `${frameConfig.borderWidth || 3}px`,
                      borderStyle: 'solid',
                      borderColor: frameConfig.borderColor1,
                      boxShadow: `0 0 25px ${frameConfig.glowColor}`,
                    }}
                    className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl bg-slate-950 transition-all ${
                      frameConfig.animation === 'spin' ? 'animate-spin' : 'animate-pulse'
                    }`}
                  >
                    {user.avatar || '👑'}
                  </div>
                  <span className="text-xs font-bold text-amber-300 mr-3">معاينة الإطار الحية 👁️</span>
                </div>
              </div>
            </div>
          )}

          {/* ==================== C. THEME PALETTE DESIGNER ==================== */}
          {newProdCategory === 'theme' && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-4 text-right">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-bold">اختر من النماذج أو خصص كل لون</span>
                <h4 className="text-xs font-black text-cyan-300 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-cyan-400" />
                  <span>مصمم ألوان وشكل الثيم:</span>
                </h4>
              </div>

              {/* Quick Presets */}
              <div>
                <span className="block text-[11px] text-slate-400 mb-1.5">نماذج ألوان سريعة جاهزة:</span>
                <div className="flex flex-wrap gap-2">
                  {palettePresets.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() =>
                        setThemePalette({
                          bg: preset.bg,
                          card: preset.card,
                          border: preset.border,
                          accent: preset.accent,
                          textAccent: preset.textAccent,
                          gradient: `from-slate-950 via-[${preset.card}] to-slate-950`,
                        })
                      }
                      className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-200 cursor-pointer"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Color Pickers */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">لون الخلفية الرئيسية (Bg):</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themePalette.bg}
                      onChange={(e) => setThemePalette({ ...themePalette, bg: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{themePalette.bg}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">لون البطاقات (Card):</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themePalette.card}
                      onChange={(e) => setThemePalette({ ...themePalette, card: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{themePalette.card}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">لون الحواف والتوهج:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themePalette.border}
                      onChange={(e) => setThemePalette({ ...themePalette, border: e.target.value })}
                      className="w-9 h-9 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">{themePalette.border}</span>
                  </div>
                </div>
              </div>

              {/* Theme Live Preview */}
              <div
                style={{ backgroundColor: themePalette.bg }}
                className="p-3.5 rounded-2xl border transition-all"
              >
                <div
                  style={{ backgroundColor: themePalette.card, borderColor: themePalette.border }}
                  className="p-3 rounded-xl border shadow-lg flex items-center justify-between"
                >
                  <span className="text-xs font-black text-white">معاينة بطاقة الثيم المصمم 🎨</span>
                  <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 text-white font-bold text-xs shadow-md">
                    زر الواجهة
                  </div>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">الوصف الحماسي للعنصر:</label>
            <input
              type="text"
              value={newProdDesc}
              onChange={(e) => setNewProdDesc(e.target.value)}
              placeholder="وصف مشوق يوضح مميزات وقوة هذا المقتنى الجديد..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-2xl font-black text-xs sm:text-sm bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? 'جاري النشر في الماركت...' : '🚀 نشر العنصر المصمم فوراً في الماركت أونلاين'}
          </button>
        </form>
      )}

      {/* 2. Edit Prices Form */}
      {activeTab === 'edit_prices' && (
        <form
          onSubmit={handleUpdatePrice}
          className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/30 space-y-4 shadow-xl text-right"
        >
          <h3 className="text-sm font-black text-amber-300 flex items-center gap-2">
            <Tag className="w-4 h-4 text-amber-400" />
            <span>تعديل أسعار عناصر المتاجر الحالية</span>
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">اختر العنصر لتعديل سعره:</label>
            <select
              value={selectedItemId}
              onChange={(e) => {
                setSelectedItemId(e.target.value);
                const item = marketItems.find((i) => i.id === e.target.value);
                if (item) setEditPriceValue(item.price);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right"
            >
              {marketItems.map((item) => (
                <option key={item.id} value={item.id}>
                  [{item.category}] {item.name} - السعر الحالي: {item.price} نقطة
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">السعر الجديد (بالنقاط):</label>
            <input
              type="number"
              min="0"
              required
              value={editPriceValue}
              onChange={(e) => setEditPriceValue(parseInt(e.target.value, 10) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-amber-500 text-center font-mono font-bold"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-2xl font-black text-xs sm:text-sm bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? 'جاري حفظ السعر...' : '💾 اعتماد وتطبيق السعر الجديد أونلاين'}
          </button>
        </form>
      )}

      {/* 3. Coupons Generator */}
      {activeTab === 'coupons' && (
        <div className="space-y-4 text-right">
          <form
            onSubmit={handleCreateCoupon}
            className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/30 space-y-4 shadow-xl"
          >
            <h3 className="text-sm font-black text-amber-300 flex items-center gap-2">
              <Ticket className="w-4 h-4 text-amber-400" />
              <span>توليد كود كوبون هدية جديد</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">رمز الكوبون (Code):</label>
                <input
                  type="text"
                  required
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="مثال: RAMADAN2026"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-center font-mono uppercase font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">النقاط الممنوحة:</label>
                <input
                  type="number"
                  min="50"
                  required
                  value={couponCoins}
                  onChange={(e) => setCouponCoins(parseInt(e.target.value, 10) || 50)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-center font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">الحد الأقصى للاستخدام:</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={couponMaxUses}
                  onChange={(e) => setCouponMaxUses(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-center font-mono font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 rounded-2xl font-black text-xs sm:text-sm bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              توليد الكود ونشره أونلاين 🎟️
            </button>
          </form>

          {/* Active Coupons List */}
          <div className="p-4 rounded-3xl bg-slate-900/60 border border-slate-800">
            <h4 className="text-xs font-black text-slate-300 mb-3">الكوبونات النشطة في السحابة:</h4>
            <div className="space-y-2">
              {couponsList.map((cp) => (
                <div
                  key={cp.code}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-amber-300 text-xs px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
                      {cp.code}
                    </span>
                    <span className="text-[11px] text-slate-400">{cp.description || 'كوبون هدية'}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 flex items-center gap-2">
                    <span className="text-amber-400 font-bold">+{cp.coinsReward} نقطة</span>
                    <span className="text-slate-500">
                      ({cp.usedCount}/{cp.maxUses} استخدام)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. Broadcast Form */}
      {activeTab === 'broadcast' && (
        <form
          onSubmit={handleBroadcastAnnouncement}
          className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/30 space-y-4 shadow-xl text-right"
        >
          <h3 className="text-sm font-black text-amber-300 flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-amber-400" />
            <span>بث إعلان إداري عام لجميع المستخدمين</span>
          </h3>

          <textarea
            rows={3}
            required
            value={announcementText}
            onChange={(e) => setAnnouncementText(e.target.value)}
            placeholder="اكتب رسالة الإعلان أو تحديث المسابقة التي ستظهر أعلى واجهة التطبيق..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500 text-right leading-relaxed"
          />

          <button
            type="submit"
            className="w-full py-3 rounded-2xl font-black text-xs sm:text-sm bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/20 transition-all cursor-pointer"
          >
            بث الإعلان الآن 📢
          </button>
        </form>
      )}

    </div>
  );
};
