import React from 'react';
import { X, Flame, Shield, Check, ExternalLink, Smartphone, Zap } from 'lucide-react';
import { soundFX } from '../utils/audio';

interface FreeFireTipsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'ur';
}

export const FreeFireTipsModal: React.FC<FreeFireTipsModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;

  const handleLaunchGame = () => {
    soundFX.playBoost();
    // Try launching Free Fire intent or fallback to Google Play Store
    const isAndroid = /Android/i.test(navigator.userAgent);
    if (isAndroid) {
      window.location.href = 'freefire://';
      setTimeout(() => {
        window.location.href = 'https://play.google.com/store/apps/details?id=com.dts.freefireth';
      }, 1500);
    } else {
      window.open('https://play.google.com/store/apps/details?id=com.dts.freefireth', '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700/80 p-6 shadow-2xl text-slate-100 overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500"></div>

        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Flame className="w-6 h-6 text-orange-500 fill-current" />
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Free Fire Pakistan Low Ping Guide 🇵🇰
              </h2>
              <p className="text-xs text-slate-400">Garena Free Fire PK Server Optimization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs">
          {/* Quick Launch CTA */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-orange-950/40 to-slate-900 border border-amber-500/30 flex items-center justify-between">
            <div>
              <div className="font-bold text-sm text-amber-300">Boost Applied Successfully!</div>
              <p className="text-slate-300 mt-0.5">WiFi reset completed & low-ping routing active.</p>
            </div>
            <button
              onClick={handleLaunchGame}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <Flame className="w-4 h-4 fill-current" />
              <span>Launch Free Fire</span>
            </button>
          </div>

          {/* Pakistan Free Fire Optimization Tips */}
          <div className="space-y-2">
            <h4 className="font-semibold text-slate-200 text-sm flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Pakistan 4G / Wi-Fi Ping Stabilization Settings</span>
            </h4>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="font-semibold text-amber-400">1. Android Private DNS Setup (Zero Jitter)</div>
              <p className="text-slate-400">
                Go to Android <strong>Settings → Connections / Network → More Connection Settings → Private DNS</strong>.
              </p>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 font-mono text-emerald-400 select-all">
                one.one.one.one
              </div>
              <p className="text-[11px] text-slate-500">This routes Free Fire packets directly to Cloudflare PKIX in Karachi/Islamabad.</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="font-semibold text-amber-400">2. Jazz & Zong 4G APN Gaming Config</div>
              <p className="text-slate-400">
                Set APN Protocol to <strong>IPv4/IPv6</strong> and Bearer to <strong>LTE</strong> to stop mid-game 999+ ping spikes.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="font-semibold text-amber-400">3. In-Game Free Fire Settings</div>
              <p className="text-slate-400">
                Set Graphics to <strong>Smooth</strong> and FPS to <strong>High</strong>. Turn OFF "Auto Download Resources" in Free Fire to prevent background network usage during matches.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
