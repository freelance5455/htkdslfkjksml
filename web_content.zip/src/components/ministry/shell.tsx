import { Link, useRouterState } from "@tanstack/react-router";
import {
  Award,
  BarChart3,
  BookOpen,
  CalendarCheck,
  History,
  LayoutDashboard,
  LifeBuoy,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Settings,
  Sparkles,
  Sun,
  Users,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Toaster } from "sonner";
import { formatTime } from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, mobile: "Dashboard" },
  { to: "/planner", label: "AI Meeting Planner", icon: Sparkles, mobile: "Planner" },
  { to: "/workbook", label: "JW Workbook", icon: BookOpen, mobile: "Workbook" },
  { to: "/members", label: "Members", icon: Users, mobile: "Members" },
  { to: "/skills", label: "Abilities & Skills", icon: Award, mobile: null },
  { to: "/history", label: "Assignment History", icon: History, mobile: null },
  { to: "/availability", label: "Availability", icon: CalendarCheck, mobile: null },
  { to: "/reports", label: "Reports", icon: BarChart3, mobile: null },
  { to: "/help", label: "Help Centre", icon: LifeBuoy, mobile: null },
  { to: "/settings", label: "Settings", icon: Settings, mobile: null },
] as const;

function isActive(pathname: string, to: string) {
  if (to === "/") return pathname === "/";
  return pathname === to || pathname.startsWith(`${to}/`);
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const collapsed = useMinistry((state) => state.collapsed);
  const toggleCollapsed = useMinistry((state) => state.toggleCollapsed);
  const congregation = useMinistry((state) => state.congregation);
  const meetingTime = useMinistry((state) => state.meetingTime);
  const meetingWeekday = useMinistry((state) => state.meetingWeekday);
  const theme = useMinistry((state) => state.theme);
  const setTheme = useMinistry((state) => state.setTheme);
  const [more, setMore] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const pending = useMinistry.persist.rehydrate();
    void Promise.resolve(pending).finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!ready) return;
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [ready, theme]);

  useEffect(() => {
    setMore(false);
  }, [pathname]);

  const page = NAV.find((item) => isActive(pathname, item.to));

  return (
    <div className="min-h-dvh bg-canvas text-ink">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-30 hidden flex-col bg-sidebar text-on-navy transition-[width] duration-200 ease-out lg:flex",
          collapsed ? "w-[92px]" : "w-[272px]",
        )}
      >
        <div className={cn("flex items-center gap-3 px-4 pt-6", collapsed && "justify-center px-3")}>
          <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-cyan font-display text-xl text-sidebar">
            M
          </span>
          {collapsed ? null : (
            <span className="min-w-0">
              <span className="block font-display text-xl leading-none">MinistryFlow</span>
              <span className="mt-1 inline-flex rounded-full bg-cyan/15 px-2 py-0.5 text-[10px] font-semibold tracking-[0.14em] text-cyan uppercase">
                AI
              </span>
            </span>
          )}
        </div>
        <nav className="mt-8 flex-1 space-y-1 overflow-y-auto px-3" aria-label="Primary">
          {NAV.map((item) => {
            const active = isActive(pathname, item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                title={item.label}
                className={cn(
                  "tap flex h-11 items-center gap-3 rounded-2xl px-3 text-sm font-medium text-on-navy/75 transition-colors hover:bg-on-navy/8 hover:text-on-navy",
                  active && "bg-on-navy/12 text-on-navy shadow-[inset_3px_0_0_0_var(--color-cyan)]",
                  collapsed && "justify-center px-0",
                )}
              >
                <Icon className={cn("size-5 shrink-0", active && "text-cyan")} strokeWidth={1.75} />
                {collapsed ? null : <span className="truncate">{item.label}</span>}
              </Link>
            );
          })}
        </nav>
        <button
          type="button"
          onClick={toggleCollapsed}
          className="tap m-3 flex h-11 items-center justify-center gap-2 rounded-2xl text-sm text-on-navy/70 hover:bg-on-navy/8 hover:text-on-navy"
        >
          {collapsed ? <PanelLeftOpen className="size-5" /> : <PanelLeftClose className="size-5" />}
          {collapsed ? null : <span>Collapse</span>}
        </button>
      </aside>

      <div className={cn("transition-[padding] duration-200 ease-out", collapsed ? "lg:pl-[92px]" : "lg:pl-[272px]")}>
        <header className="sticky top-0 z-20 border-b border-line/80 bg-canvas/80 backdrop-blur-xl">
          <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-ink">{page?.label ?? "MinistryFlow"}</p>
              <p className="truncate text-xs text-muted">
                {congregation} · {meetingWeekday} {formatTime(meetingTime)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="tap grid size-11 place-items-center rounded-full border border-line bg-card text-ink shadow-card"
              aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            >
              {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
          </div>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 pt-6 pb-28 sm:px-6 lg:pb-12">
          <div key={pathname} className="rise-in min-w-0">
            {children}
          </div>
        </main>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/90 px-1 pt-1 backdrop-blur-xl lg:hidden"
        style={{ paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" }}
        aria-label="Mobile"
      >
        <ul className="grid grid-cols-5">
          {NAV.filter((item) => item.mobile).map((item) => {
            const active = isActive(pathname, item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-medium",
                    active ? "text-royal" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={1.75} />
                  {item.mobile}
                </Link>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMore(true)}
              className="flex min-h-14 w-full flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-medium text-muted"
            >
              <Settings className="size-5" strokeWidth={1.75} />
              More
            </button>
          </li>
        </ul>
      </nav>

      {more ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button type="button" className="absolute inset-0 bg-sidebar/55" aria-label="Close menu" onClick={() => setMore(false)} />
          <div className="absolute inset-x-0 bottom-0 rounded-t-3xl border border-line bg-card p-4 shadow-lift" style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}>
            <div className="mb-3 flex items-center justify-between">
              <p className="font-display text-2xl">More</p>
              <button type="button" className="grid size-10 place-items-center rounded-full hover:bg-soft" onClick={() => setMore(false)} aria-label="Close">
                <X className="size-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {NAV.filter((item) => !item.mobile).map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className="flex h-14 items-center gap-3 rounded-2xl bg-soft px-3 text-sm font-medium"
                  >
                    <Icon className="size-4 text-royal" />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      ) : null}
      <Toaster theme={theme} position="top-center" />
    </div>
  );
}
