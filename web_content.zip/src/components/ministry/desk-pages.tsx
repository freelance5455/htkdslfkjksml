import * as Accordion from "@radix-ui/react-accordion";
import * as Switch from "@radix-ui/react-switch";
import { ChevronDown } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button, Card, Field, PageIntro, StatusPill, fieldClass } from "@/components/ministry/ui";
import {
  formatLong,
  formatShort,
  fullName,
  partStatus,
  privilegeLabel,
  SKILL_META,
  utcTodayIso,
} from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";
import { SKILL_IDS, type Section } from "@/lib/ministry/types";
import { cn } from "@/lib/utils";

export function HistoryPage() {
  const members = useMinistry((state) => state.members);
  const meetings = useMinistry((state) => state.meetings);
  const assignments = useMinistry((state) => state.assignments);
  const [memberId, setMemberId] = useState("all");
  const [section, setSection] = useState<"all" | Section>("all");
  const today = utcTodayIso();
  const byId = new Map(members.map((member) => [member.id, member]));
  const rows = meetings
    .slice()
    .reverse()
    .map((meeting) => ({
      meeting,
      parts: assignments
        .filter((assignment) => assignment.meetingId === meeting.id)
        .filter((assignment) => (section === "all" ? true : assignment.section === section))
        .filter((assignment) =>
          memberId === "all"
            ? true
            : assignment.assigneeId === memberId || assignment.assistantId === memberId,
        )
        .sort((a, b) => a.order - b.order),
    }))
    .filter((group) => group.parts.length);

  return (
    <div>
      <PageIntro
        eyebrow="Record"
        title="Assignment history"
        lede="Every part already given, and the ones still waiting for the meeting."
      />
      <div className="mb-5 grid gap-3 sm:grid-cols-2">
        <Field label="Publisher">
          <select className={fieldClass} value={memberId} onChange={(event) => setMemberId(event.target.value)}>
            <option value="all">Everyone</option>
            {members
              .slice()
              .sort((a, b) => a.lastName.localeCompare(b.lastName))
              .map((member) => (
                <option key={member.id} value={member.id}>
                  {fullName(member)}
                </option>
              ))}
          </select>
        </Field>
        <Field label="Section">
          <select
            className={fieldClass}
            value={section}
            onChange={(event) => setSection(event.target.value as "all" | Section)}
          >
            <option value="all">All sections</option>
            <option value="opening">Opening</option>
            <option value="treasures">Treasures</option>
            <option value="ministry">Ministry</option>
            <option value="living">Living as Christians</option>
            <option value="closing">Closing</option>
          </select>
        </Field>
      </div>
      <div className="space-y-5">
        {rows.length === 0 ? <Card className="p-8 text-sm text-muted">Nothing in the record matches those filters.</Card> : null}
        {rows.map(({ meeting, parts }) => (
          <section key={meeting.id}>
            <h2 className="text-2xl">{meeting.theme}</h2>
            <p className="mb-3 text-sm text-muted">{formatLong(meeting.date)}</p>
            <div className="space-y-2">
              {parts.map((part) => {
                const assignee = part.assigneeId ? byId.get(part.assigneeId) : undefined;
                const assistant = part.assistantId ? byId.get(part.assistantId) : undefined;
                return (
                  <Card key={part.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="font-semibold">{part.title}</p>
                      <p className="truncate text-sm text-muted">
                        {assignee ? fullName(assignee) : "Unassigned"}
                        {part.needsAssistant ? ` · Assistant ${assistant ? fullName(assistant) : "open"}` : ""}
                        {` · ${part.durationMin} min`}
                      </p>
                    </div>
                    <StatusPill status={partStatus(meeting.date, part.assigneeId, today)} />
                  </Card>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

export function AvailabilityPage() {
  const members = useMinistry((state) => state.members);
  const meetings = useMinistry((state) => state.meetings);
  const toggleAway = useMinistry((state) => state.toggleAway);
  const today = utcTodayIso();
  const future = meetings.filter((meeting) => meeting.date >= today);
  const [date, setDate] = useState(future[0]?.date ?? "");
  const meeting = future.find((item) => item.date === date) ?? future[0];
  const sorted = [...members].sort((a, b) => a.lastName.localeCompare(b.lastName));

  return (
    <div>
      <PageIntro
        eyebrow="Schedule"
        title="Availability"
        lede="Mark who cannot accept a part on a given week. Away publishers are skipped by the arranger."
      />
      <div className="mb-4 flex flex-wrap gap-2">
        {future.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setDate(item.date)}
            className={cn(
              "tap h-11 rounded-full px-4 text-sm font-semibold",
              meeting?.date === item.date ? "bg-sidebar text-on-navy" : "bg-card text-ink",
            )}
          >
            {formatShort(item.date)}
          </button>
        ))}
      </div>
      {meeting ? (
        <Card className="divide-y divide-line">
          {sorted.map((member) => {
            const traveling = member.availability === "away";
            const away = traveling || member.awayDates.includes(meeting.date);
            return (
              <div key={member.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{fullName(member)}</p>
                  <p className="truncate text-xs text-muted">
                    {privilegeLabel(member.privilege)}
                    {traveling ? " · Away for now" : member.availability === "limited" ? " · Limited" : ""}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={traveling}
                  onClick={() => {
                    toggleAway(member.id, meeting.date);
                    toast.success(away ? "Marked available" : "Marked away", { description: fullName(member) });
                  }}
                  className={cn(
                    "tap h-11 shrink-0 rounded-full px-4 text-sm font-semibold",
                    away ? "bg-warn-soft text-warn" : "bg-good-soft text-good",
                    traveling && "opacity-70",
                  )}
                >
                  {away ? "Away" : "Available"}
                </button>
              </div>
            );
          })}
        </Card>
      ) : (
        <Card className="p-8 text-sm text-muted">No upcoming meetings.</Card>
      )}
    </div>
  );
}

export function ReportsPage() {
  const members = useMinistry((state) => state.members);
  const assignments = useMinistry((state) => state.assignments);
  const data = useMemo(
    () =>
      members
        .map((member) => ({
          name: member.firstName,
          parts: assignments.filter(
            (assignment) => assignment.assigneeId === member.id || assignment.assistantId === member.id,
          ).length,
        }))
        .filter((row) => row.parts > 0)
        .sort((a, b) => b.parts - a.parts)
        .slice(0, 8),
    [members, assignments],
  );
  const busiest = data[0];
  const quiet = [...members].sort((a, b) => {
    const load = (id: string) =>
      assignments.filter((assignment) => assignment.assigneeId === id || assignment.assistantId === id).length;
    return load(a.id) - load(b.id);
  })[0];
  const coverage = SKILL_IDS.map((skill) => {
    const qualified = members.filter((member) => (member.skills[skill] ?? 0) >= 70).length;
    return { skill, label: SKILL_META[skill].label, qualified };
  });

  return (
    <div>
      <PageIntro
        eyebrow="Balance"
        title="Reports"
        lede="A calm look at who has been used, and where the congregation is thin."
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="p-4">
          <p className="text-sm text-muted">Busiest on record</p>
          <p className="mt-2 font-display text-3xl">{busiest?.name ?? "—"}</p>
          <p className="text-sm text-muted tabular-nums">{busiest ? `${busiest.parts} parts` : "No parts yet"}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted">Lightest load</p>
          <p className="mt-2 font-display text-3xl">{quiet ? quiet.firstName : "—"}</p>
          <p className="text-sm text-muted">A good person to consider next.</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted">Parts on record</p>
          <p className="mt-2 font-display text-3xl tabular-nums">
            {assignments.filter((assignment) => assignment.assigneeId).length}
          </p>
          <p className="text-sm text-muted">Primary assignments with a name.</p>
        </Card>
      </div>
      <Card className="mt-4 p-4 sm:p-5">
        <h2 className="text-2xl">Parts per publisher</h2>
        <p className="mb-4 text-sm text-muted">Primary parts and assists, top of the roster.</p>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
              <XAxis type="number" allowDecimals={false} hide />
              <YAxis
                type="category"
                dataKey="name"
                width={72}
                axisLine={false}
                tickLine={false}
                tick={{ fill: "var(--color-muted)", fontSize: 12 }}
              />
              <Tooltip
                cursor={{ fill: "var(--color-soft)" }}
                contentStyle={{
                  background: "var(--color-card)",
                  border: "1px solid var(--color-line)",
                  borderRadius: 16,
                  color: "var(--color-ink)",
                }}
              />
              <Bar dataKey="parts" fill="var(--color-royal)" radius={[0, 8, 8, 0]} barSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {coverage.map((item) => (
          <Card key={item.skill} className="p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-semibold">{item.label}</p>
              <p className="text-sm text-muted tabular-nums">{item.qualified} ready</p>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-soft">
              <div
                className="h-full rounded-full bg-cyan"
                style={{ width: `${Math.min(100, item.qualified * 18)}%` }}
              />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

const HELP = [
  {
    q: "What does Arrange with AI actually do?",
    a: "It reads who is free, which parts they can handle, and how often they have already been used. You get a full programme you can edit. Nothing is announced until you are satisfied.",
  },
  {
    q: "Who can receive which part?",
    a: "Chairman, prayer, treasures talks, spiritual gems, Living as Christians talks, and the Congregation Bible study are offered to brothers. Elders are preferred for chairman, gems, and the Bible study. Student parts and householder roles can be brothers or sisters. Unbaptized publishers are kept to the Bible reading and student parts.",
  },
  {
    q: "Why was someone left unassigned?",
    a: "They may be marked away, already used in the same meeting, or rated below 45 for that part. Use Replace or Edit to choose someone else, or raise the skill if it is out of date.",
  },
  {
    q: "Can I undo an arrangement?",
    a: "Yes. The confirmation that appears after arranging has Undo, and it restores the programme from just before that run.",
  },
  {
    q: "Where is this data kept?",
    a: "In this browser only. It is a working sample for Northside Congregation. Reset it any time from Settings. There is no shared congregation account in this version.",
  },
  {
    q: "Does the assistant replace the overseer?",
    a: "No. MinistryFlow prepares a balanced suggestion. The brother arranging the meeting still makes the final decision.",
  },
];

export function HelpPage() {
  return (
    <div>
      <PageIntro
        eyebrow="Help Centre"
        title="How the desk works"
        lede="A short guide for the brother or sister who prepares the midweek meeting."
      />
      <Accordion.Root type="single" collapsible className="space-y-2">
        {HELP.map((item) => (
          <Accordion.Item key={item.q} value={item.q} className="overflow-hidden rounded-3xl border border-line bg-card shadow-card">
            <Accordion.Header>
              <Accordion.Trigger className="group tap flex w-full items-center justify-between gap-3 px-4 py-4 text-left text-sm font-semibold">
                {item.q}
                <ChevronDown className="size-4 shrink-0 text-muted transition-transform group-data-[state=open]:rotate-180" />
              </Accordion.Trigger>
            </Accordion.Header>
            <Accordion.Content className="px-4 pb-4 text-sm text-muted">{item.a}</Accordion.Content>
          </Accordion.Item>
        ))}
      </Accordion.Root>
    </div>
  );
}

export function SettingsPage() {
  const congregation = useMinistry((state) => state.congregation);
  const meetingTime = useMinistry((state) => state.meetingTime);
  const meetingWeekday = useMinistry((state) => state.meetingWeekday);
  const theme = useMinistry((state) => state.theme);
  const setTheme = useMinistry((state) => state.setTheme);
  const updateSettings = useMinistry((state) => state.updateSettings);
  const resetDemo = useMinistry((state) => state.resetDemo);
  const [name, setName] = useState(congregation);
  const [time, setTime] = useState(meetingTime);

  useEffect(() => {
    setName(congregation);
    setTime(meetingTime);
  }, [congregation, meetingTime]);

  return (
    <div>
      <PageIntro
        eyebrow="Settings"
        title="Congregation"
        lede="The name on the desk, when you meet, and how the interface looks."
      />
      <Card className="space-y-5 p-5">
        <Field label="Congregation name">
          <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
        </Field>
        <Field label="Meeting time">
          <input className={fieldClass} type="time" value={time} onChange={(event) => setTime(event.target.value)} />
        </Field>
        <p className="text-sm text-muted">
          Sample weeks are prepared for {meetingWeekday}. Changing the time updates the clock on the planner.
        </p>
        <Button
          onClick={() => {
            updateSettings({ congregation: name, meetingTime: time });
            toast.success("Settings saved");
          }}
        >
          Save details
        </Button>
      </Card>

      <Card className="mt-4 flex items-center justify-between gap-4 p-5">
        <div>
          <h2 className="font-sans text-lg font-semibold tracking-normal">Dark mode</h2>
          <p className="text-sm text-muted">A navy desk for evening preparation. The choice stays in this browser.</p>
        </div>
        <Switch.Root
          checked={theme === "dark"}
          onCheckedChange={(checked) => {
            setTheme(checked ? "dark" : "light");
            toast.success(checked ? "Dark mode on" : "Light mode on");
          }}
          className="relative h-8 w-14 shrink-0 rounded-full bg-line transition-colors data-[state=checked]:bg-royal"
          aria-label="Dark mode"
        >
          <Switch.Thumb className="block size-6 translate-x-1 rounded-full bg-card shadow transition-transform data-[state=checked]:translate-x-7" />
        </Switch.Root>
      </Card>

      <Card className="mt-4 p-5">
        <h2 className="font-sans text-lg font-semibold tracking-normal">Sample congregation</h2>
        <p className="mt-1 text-sm text-muted">
          Restore the original Northside roster, meetings, and assignment history. Your dark mode choice is kept.
        </p>
        <Button
          variant="danger"
          className="mt-4"
          onClick={() => {
            resetDemo();
            setName("Northside Congregation");
            setTime("19:00");
            toast.success("Sample data restored");
          }}
        >
          Reset sample data
        </Button>
      </Card>
    </div>
  );
}
