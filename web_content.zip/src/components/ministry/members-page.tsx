import { Plus, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Avatar, Button, Card, Field, Modal, PageIntro, fieldClass } from "@/components/ministry/ui";
import { fullName, privilegeLabel, SKILL_META, utcTodayIso } from "@/lib/ministry/format";
import { blankMember, useMinistry } from "@/lib/ministry/store";
import { SKILL_IDS, type Availability, type Gender, type Member, type Privilege, type SkillId } from "@/lib/ministry/types";
import { cn } from "@/lib/utils";

const FILTERS = ["All", "Elders", "Servants", "Publishers", "Brothers", "Sisters", "Away"] as const;

export function MembersPage() {
  const members = useMinistry((state) => state.members);
  const assignments = useMinistry((state) => state.assignments);
  const meetings = useMinistry((state) => state.meetings);
  const saveMember = useMinistry((state) => state.saveMember);
  const removeMember = useMinistry((state) => state.removeMember);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const [draft, setDraft] = useState<Member | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const today = utcTodayIso();

  const visible = useMemo(() => {
    return members
      .filter((member) => {
        const hay = `${member.firstName} ${member.lastName} ${member.note}`.toLowerCase();
        if (query && !hay.includes(query.toLowerCase())) return false;
        if (filter === "Elders") return member.privilege === "elder";
        if (filter === "Servants") return member.privilege === "servant";
        if (filter === "Publishers") return member.privilege === "publisher" || member.privilege === "unbaptized";
        if (filter === "Brothers") return member.gender === "brother";
        if (filter === "Sisters") return member.gender === "sister";
        if (filter === "Away") return member.availability === "away" || member.awayDates.some((date) => date >= today);
        return true;
      })
      .sort((a, b) => a.lastName.localeCompare(b.lastName) || a.firstName.localeCompare(b.firstName));
  }, [members, query, filter, today]);

  return (
    <div>
      <PageIntro
        eyebrow="Congregation"
        title="Members"
        lede="Profiles, abilities, and who can be approached for the next meeting."
        actions={
          <Button
            onClick={() => {
              setDraft(blankMember());
            }}
          >
            <Plus className="size-4" />
            Add member
          </Button>
        }
      />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative min-w-0 flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search by name"
            className={cn(fieldClass, "pl-10")}
            aria-label="Search members"
          />
        </div>
      </div>
      <div className="mb-5 flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setFilter(item)}
            className={cn(
              "tap h-10 rounded-full px-3 text-sm font-semibold",
              filter === item ? "bg-sidebar text-on-navy" : "bg-card text-muted",
            )}
          >
            {item}
          </button>
        ))}
      </div>
      {visible.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted">No one matches that search.</Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((member) => {
            const history = assignments.filter(
              (assignment) => assignment.assigneeId === member.id || assignment.assistantId === member.id,
            ).length;
            const topSkills = SKILL_IDS.filter((skill) => (member.skills[skill] ?? 0) >= 70)
              .slice(0, 3)
              .map((skill) => SKILL_META[skill].label);
            const away = member.availability === "away" || member.awayDates.some((date) => date >= today);
            return (
              <button
                key={member.id}
                type="button"
                onClick={() => setDraft(member)}
                className="tap rounded-3xl border border-line bg-card p-4 text-left shadow-card hover:border-royal/30"
              >
                <div className="flex items-start gap-3">
                  <Avatar member={member} />
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{fullName(member)}</p>
                    <p className="truncate text-sm text-muted">
                      {privilegeLabel(member.privilege)} · {member.gender === "brother" ? "Brother" : "Sister"}
                    </p>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {(topSkills.length ? topSkills : ["Developing"]).map((skill) => (
                    <span key={skill} className="rounded-full bg-soft px-2.5 py-1 text-xs font-medium text-ink">
                      {skill}
                    </span>
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-between text-xs text-muted">
                  <span className={cn("font-semibold", away ? "text-warn" : "text-good")}>
                    {away ? "Away or limited dates" : member.availability === "limited" ? "Limited" : "Available"}
                  </span>
                  <span className="tabular-nums">{history} parts on record</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      <MemberDialog
        member={draft}
        meetings={meetings.map((meeting) => meeting.date)}
        onOpenChange={(open) => {
          if (!open) setDraft(null);
        }}
        onSave={(member) => {
          if (!member.firstName.trim() || !member.lastName.trim()) {
            toast("Add a first and last name.");
            return;
          }
          saveMember({ ...member, firstName: member.firstName.trim(), lastName: member.lastName.trim() });
          setDraft(null);
          toast.success("Member saved");
        }}
        onRemove={(id) => setConfirmId(id)}
      />

      <Modal
        open={Boolean(confirmId)}
        onOpenChange={(open) => {
          if (!open) setConfirmId(null);
        }}
        title="Remove this publisher?"
        description="Their name will come off future parts. Past meetings stay in the record without that assignment."
      >
        <div className="flex justify-end gap-2">
          <Button variant="soft" onClick={() => setConfirmId(null)}>
            Keep
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              if (confirmId) removeMember(confirmId);
              setConfirmId(null);
              setDraft(null);
              toast.success("Member removed");
            }}
          >
            Remove
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function MemberDialog({
  member,
  meetings,
  onOpenChange,
  onSave,
  onRemove,
}: {
  member: Member | null;
  meetings: string[];
  onOpenChange: (open: boolean) => void;
  onSave: (member: Member) => void;
  onRemove: (id: string) => void;
}) {
  const [draft, setDraft] = useState<Member | null>(member);
  const isNew = member ? !useMinistry.getState().members.some((item) => item.id === member.id) : false;

  useEffect(() => {
    setDraft(member);
  }, [member]);

  if (!draft) return null;

  const patch = (partial: Partial<Member>) => setDraft({ ...draft, ...partial });

  return (
    <Modal
      open
      onOpenChange={onOpenChange}
      title={isNew ? "Add a member" : fullName(draft)}
      description="Skills from 0 to 100. The arranger only uses a part when the rating is at least 45."
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          onSave(draft);
        }}
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="First name">
            <input className={fieldClass} value={draft.firstName} onChange={(event) => patch({ firstName: event.target.value })} />
          </Field>
          <Field label="Last name">
            <input className={fieldClass} value={draft.lastName} onChange={(event) => patch({ lastName: event.target.value })} />
          </Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Brother or sister">
            <select
              className={fieldClass}
              value={draft.gender}
              onChange={(event) => patch({ gender: event.target.value as Gender })}
            >
              <option value="brother">Brother</option>
              <option value="sister">Sister</option>
            </select>
          </Field>
          <Field label="Privilege">
            <select
              className={fieldClass}
              value={draft.privilege}
              onChange={(event) => patch({ privilege: event.target.value as Privilege })}
            >
              <option value="elder">Elder</option>
              <option value="servant">Ministerial servant</option>
              <option value="publisher">Publisher</option>
              <option value="unbaptized">Unbaptized publisher</option>
            </select>
          </Field>
        </div>
        <Field label="Availability">
          <select
            className={fieldClass}
            value={draft.availability}
            onChange={(event) => patch({ availability: event.target.value as Availability })}
          >
            <option value="available">Available</option>
            <option value="limited">Limited</option>
            <option value="away">Away for now</option>
          </select>
        </Field>
        <Field label="Phone">
          <input className={fieldClass} value={draft.phone} onChange={(event) => patch({ phone: event.target.value })} />
        </Field>
        <Field label="Note">
          <textarea
            className={cn(fieldClass, "h-20 py-2")}
            value={draft.note}
            onChange={(event) => patch({ note: event.target.value })}
          />
        </Field>
        <div className="space-y-3">
          {SKILL_IDS.map((skill) => (
            <SkillSlider
              key={skill}
              skill={skill}
              value={draft.skills[skill] ?? 0}
              onChange={(value) => patch({ skills: { ...draft.skills, [skill]: value } })}
            />
          ))}
        </div>
        {meetings.length ? (
          <p className="text-xs text-muted">Per-week away dates are set on the Availability page.</p>
        ) : null}
        <div className="flex flex-wrap justify-between gap-2 pt-2">
          {isNew ? <span /> : (
            <Button variant="danger" onClick={() => onRemove(draft.id)}>
              Remove
            </Button>
          )}
          <div className="flex gap-2">
            <Button variant="soft" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>
    </Modal>
  );
}

function SkillSlider({
  skill,
  value,
  onChange,
}: {
  skill: SkillId;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="flex items-center justify-between text-xs font-medium text-muted">
        <span>{SKILL_META[skill].label}</span>
        <span className="tabular-nums text-ink">{value}</span>
      </span>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-1 w-full accent-royal"
      />
    </label>
  );
}
