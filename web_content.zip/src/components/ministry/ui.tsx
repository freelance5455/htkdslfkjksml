import * as Dialog from "@radix-ui/react-dialog";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { avatarTone, initials, statusLabel } from "@/lib/ministry/format";
import type { Member, PartStatus } from "@/lib/ministry/types";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "navy" | "ghost" | "soft" | "danger";
  static?: boolean;
};

const buttonVariants: Record<NonNullable<ButtonProps["variant"]>, string> = {
  primary: "bg-royal text-on-royal shadow-card hover:brightness-110",
  navy: "bg-sidebar text-on-navy hover:bg-sidebar-2",
  ghost: "bg-transparent text-ink hover:bg-soft",
  soft: "bg-soft text-ink hover:bg-line",
  danger: "bg-danger/10 text-danger hover:bg-danger/15",
};

export function Button({
  variant = "primary",
  static: isStatic,
  className,
  type = "button",
  ...props
}: ButtonProps) {
  return (
    <button
      type={type}
      className={cn(
        "tap inline-flex h-11 items-center justify-center gap-2 rounded-full px-4 text-sm font-semibold",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan focus-visible:ring-offset-2 focus-visible:ring-offset-canvas",
        "disabled:opacity-50",
        !isStatic && "active:scale-[0.96]",
        buttonVariants[variant],
        className,
      )}
      {...props}
    />
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section className={cn("min-w-0 max-w-full rounded-3xl border border-line bg-card shadow-card", className)}>
      {children}
    </section>
  );
}

export function Avatar({
  member,
  size = "md",
}: {
  member: Pick<Member, "id" | "firstName" | "lastName">;
  size?: "sm" | "md" | "lg";
}) {
  const box = size === "lg" ? "size-14 text-lg" : size === "sm" ? "size-8 text-xs" : "size-10 text-sm";
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center rounded-2xl font-semibold",
        box,
        avatarTone(member.id),
      )}
      aria-hidden
    >
      {initials(member)}
    </span>
  );
}

export function StatusPill({ status }: { status: PartStatus }) {
  const styles: Record<PartStatus, string> = {
    completed: "bg-good-soft text-good",
    pending: "bg-royal/10 text-royal",
    unassigned: "bg-warn-soft text-warn",
  };
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold", styles[status])}>
      <span
        className={cn(
          "size-1.5 rounded-full",
          status === "completed" && "bg-good",
          status === "pending" && "bg-royal",
          status === "unassigned" && "bg-warn",
        )}
        aria-hidden
      />
      {statusLabel(status)}
    </span>
  );
}

export function PageIntro({
  eyebrow,
  title,
  lede,
  actions,
}: {
  eyebrow?: string;
  title: string;
  lede?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        {eyebrow ? (
          <p className="mb-2 text-xs font-semibold tracking-[0.16em] text-royal uppercase">{eyebrow}</p>
        ) : null}
        <h1 className="text-3xl text-ink sm:text-4xl">{title}</h1>
        {lede ? <p className="mt-2 text-sm text-muted sm:text-base">{lede}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block text-sm font-medium text-ink">
      <span className="mb-1.5 block">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "h-11 w-full rounded-2xl border border-line bg-canvas px-3 text-sm text-ink outline-none transition focus:border-royal focus:ring-4 focus:ring-royal/15";

export function Modal({
  open,
  onOpenChange,
  title,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-sidebar/55 backdrop-blur-sm" />
        <Dialog.Content className="fixed top-1/2 left-1/2 z-50 max-h-[min(88dvh,820px)] w-[min(100%-1.5rem,36rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-3xl border border-line bg-card p-5 shadow-lift sm:p-6">
          <div className="mb-4 flex items-start justify-between gap-4">
            <div>
              <Dialog.Title className="font-display text-2xl text-ink">{title}</Dialog.Title>
              {description ? (
                <Dialog.Description className="mt-1 text-sm text-muted">{description}</Dialog.Description>
              ) : null}
            </div>
            <Dialog.Close className="tap grid size-10 place-items-center rounded-full text-muted hover:bg-soft hover:text-ink" aria-label="Close">
              <X className="size-4" />
            </Dialog.Close>
          </div>
          {children}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
