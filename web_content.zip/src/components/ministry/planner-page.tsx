import { useServerFn } from "@tanstack/react-start";
import { ArrowLeftRight, Music, Pencil, Sparkles } from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button, Card, Field, Modal, StatusPill, fieldClass } from "@/components/ministry/ui";
import { arrangeWithGrok } from "@/lib/ministry/ai.functions";
import { arrangeParts, isEligible, nextReplacement, toDraft } from "@/lib/ministry/arrange";
import { arrangementBrief } from "@/lib/ministry/brief";
import {
  addMinutes,
  formatLong,
  formatShort,
  formatTime,
  fullName,
  partStatus,
  utcTodayIso,
} from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";
import type { AiPick, Assignment, Section } from "@/lib/ministry/types";
import { cn } from "@/lib/utils";

const STEPS = [
  "Reading availability",
  "Matching abilities",
  "Balancing the schedule",
  "Writing recommendations",
];

const SECTION_LABEL: Record<Section, string> = {
  opening: "Opening",
  treasures: "Treasures from God’s Word",
  ministry: "Apply Yourself to the Field Ministry",
  living: "Living as Christians",
  closing: "Closing",
};

export function PlannerPage() {
  const arrange = useServerFn(arrangeWithGrok);
  const congregation = useMinistry((state) => state.congregation);
  const meetingTime = useMinistry((state) => state.meetingTime);
  const members = useMinistry((state) => state.members);
  const meetings = useMinistry((state) => state.meetings);
  const assignments = useMinistry((state) => state.assignments);
  const lastArrangement = useMinistry((state) => state.lastArrangement);
  const arrangeRequested = useMinistry((state) => state.arrangeRequested);
  const focusMeetingId = useMinistry((state) => state.focusMeetingId);
  const applyMeeting = useMinistry((state) => state.applyMeeting);
  const patchAssignment = useMinistry((state) => state.patchAssignment);
  const today = utcTodayIso();
  const upcoming = meetings.find((meeting) => meeting.date >= today) ?? meetings[0];
  const [meetingId, setMeetingId] = useState(upcoming?.id ?? "");
  const [step, setStep] = useState(-1);
  const [running, setRunning] = useState(false);
  const [editing, setEditing] = useState<Assignment | null>(null);

  const meeting = meetings.find((item) => item.id === meetingId) ?? upcoming;
  const parts = useMemo(
    () =>
      assignments
        .filter((assignment) => assignment.meetingId === meeting?.id)
        .sort((a, b) => a.order - b.order),
    [assignments, meeting?.id],
  );

  async function runArrange(targetId = meeting?.id) {
    const current = meetings.find((item) => item.id === targetId);
    if (!current || running) return;
    const snapshot = assignments
      .filter((assignment) => assignment.meetingId === current.id)
      .map((assignment) => ({ ...assignment }));
    setRunning(true);
    setStep(0);
    const timers = STEPS.map((_, index) => window.setTimeout(() => setStep(index), index * 420));
    try {
      const history = assignments.filter((assignment) => assignment.meetingId !== current.id);
      const brief = arrangementBrief(congregation, current, snapshot, members, history);
      let picks: AiPick[] = [];
      let summary = "Arranged from skills, availability, and recent load.";
      let source: "grok" | "local" = "local";
      try {
        const result = await arrange({ data: { brief } });
        if (result.ok) {
          picks = result.picks;
          summary = result.summary;
          source = "grok";
        }
      } catch {
        source = "local";
      }
      const next = arrangeParts(
        current.id,
        current.date,
        snapshot.map(toDraft),
        members,
        history,
        picks,
      );
      applyMeeting(current.id, next, { meetingId: current.id, summary, source });
      toast.success(source === "grok" ? "AI arrangement ready" : "Arrangement ready", {
        description: summary,
        action: {
          label: "Undo",
          onClick: () => applyMeeting(current.id, snapshot, null),
        },
      });
    } finally {
      timers.forEach((timer) => window.clearTimeout(timer));
      setStep(4);
      setRunning(false);
    }
  }

  useEffect(() => {
    if (!focusMeetingId) return;
    setMeetingId(focusMeetingId);
    useMinistry.setState({ focusMeetingId: null });
  }, [focusMeetingId]);

  useEffect(() => {
    setStep(-1);
  }, [meetingId]);

  useEffect(() => {
    if (!arrangeRequested || !meeting) return;
    useMinistry.setState({ arrangeRequested: false });
    void runArrange(meeting.id);
    // Consumed once when the dashboard sends the user here.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arrangeRequested, meeting?.id]);

  if (!meeting) {
    return <p className="text-muted">No meetings are on the schedule.</p>;
  }

  const note = lastArrangement?.meetingId === meeting.id ? lastArrangement : null;

  return (
    <div>
      <header className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-2xl">
          <p className="mb-2 text-xs font-semibold tracking-[0.16em] text-royal uppercase">AI Meeting Planner</p>
          <h1 className="text-3xl text-ink sm:text-4xl">{meeting.theme}</h1>
          <p className="mt-2 text-sm text-muted sm:text-base">
            {formatLong(meeting.date)} · {meeting.reading}. Review every name before it is announced.
          </p>
        </div>
        <button
          type="button"
          disabled={running}
          onClick={() => void runArrange(meeting.id)}
          className="tap inline-flex h-14 items-center gap-3 self-start rounded-full bg-royal pr-5 pl-2 text-sm font-semibold text-on-royal disabled:opacity-60"
        >
          <span className="ai-orb grid size-10 place-items-center rounded-full bg-cyan text-sidebar">
            <Sparkles className="size-5" />
          </span>
          {running ? "Arranging…" : "Arrange with AI"}
        </button>
      </header>

      <div className="mb-5 flex flex-wrap gap-2">
        {meetings.map((item) => {
          const active = item.id === meeting.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setMeetingId(item.id)}
              className={cn(
                "tap h-11 shrink-0 rounded-full border px-4 text-sm font-semibold",
                active ? "border-transparent bg-sidebar text-on-navy" : "border-line bg-card text-ink",
              )}
            >
              {item.date < today ? "Past · " : ""}
              {formatShort(item.date)}
            </button>
          );
        })}
      </div>

      {running || step === 4 ? (
        <Card className="mb-5 p-5">
          <div className="flex items-center gap-3">
            <span className={cn("grid size-11 place-items-center rounded-2xl bg-cyan text-sidebar", running && "ai-orb")}>
              <Sparkles className="size-5" />
            </span>
            <div>
              <p className="font-semibold">{running ? "MinistryFlow is arranging this week" : "Recommendations ready"}</p>
              <p className="text-sm text-muted">
                {note?.source === "grok"
                  ? "Grok prepared this suggestion."
                  : step === 4
                    ? "Balanced on this device from skills and availability."
                    : "Checking who is qualified and free."}
              </p>
            </div>
          </div>
          <ol className="mt-4 grid gap-2 sm:grid-cols-4">
            {STEPS.map((label, index) => {
              const done = step > index;
              const current = step === index && running;
              return (
                <li
                  key={label}
                  className={cn(
                    "rounded-2xl border px-3 py-3 text-sm",
                    done ? "border-royal/20 bg-royal/8 text-ink" : "border-line text-muted",
                    current && "border-cyan bg-cyan/10 text-ink",
                  )}
                >
                  <span className="mr-2 font-semibold tabular-nums">{done ? "✓" : index + 1}</span>
                  {label}
                </li>
              );
            })}
          </ol>
          {note && step === 4 ? <p className="mt-4 text-sm text-ink">{note.summary}</p> : null}
        </Card>
      ) : null}

      <Programme
        meetingDate={meeting.date}
        meetingTime={meetingTime}
        songs={meeting.songs}
        parts={parts}
        members={members}
        today={today}
        onEdit={setEditing}
        onReplace={(assignment, slot) => {
          const history = assignments.filter((item) => item.meetingId !== meeting.id);
          const replacement = nextReplacement(assignment, meeting.date, members, parts, history, slot);
          if (!replacement) {
            toast("No other qualified publisher is free for this part.");
            return;
          }
          const person = members.find((member) => member.id === replacement.id);
          patchAssignment(
            assignment.id,
            slot === "assignee"
              ? { assigneeId: replacement.id, reason: replacement.reason }
              : { assistantId: replacement.id, reason: replacement.reason },
            {
              title: "Publisher replaced",
              detail: `${assignment.title} · ${person ? fullName(person) : "Updated"}`,
              tone: "edit",
            },
          );
          toast.success("Replacement ready", { description: replacement.reason });
        }}
      />

      <EditDialog
        assignment={editing}
        meetingDate={meeting.date}
        members={members}
        parts={parts}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
        onSave={(next) => {
          patchAssignment(next.id, next, {
            title: "Assignment edited",
            detail: next.title,
            tone: "edit",
          });
          setEditing(null);
          toast.success("Assignment saved");
        }}
      />
    </div>
  );
}

function Programme({
  meetingDate,
  meetingTime,
  songs,
  parts,
  members,
  today,
  onEdit,
  onReplace,
}: {
  meetingDate: string;
  meetingTime: string;
  songs: [number, number, number];
  parts: Assignment[];
  members: { id: string; firstName: string; lastName: string }[];
  today: string;
  onEdit: (assignment: Assignment) => void;
  onReplace: (assignment: Assignment, slot: "assignee" | "assistant") => void;
}) {
  const byId = new Map(members.map((member) => [member.id, member]));
  let cursor = 0;
  let sangMid = false;
  const rows: { key: string; node: ReactNode }[] = [];
  const pushSong = (number: number) => {
    const when = formatTime(addMinutes(meetingTime, cursor));
    rows.push({
      key: `song-${number}-${cursor}`,
      node: (
        <div className="flex items-center gap-3 py-2 text-sm text-muted">
          <span className="grid size-8 place-items-center rounded-full bg-soft text-royal">
            <Music className="size-3.5" />
          </span>
          <span className="tabular-nums">{when}</span>
          <span>Song {number}</span>
        </div>
      ),
    });
    cursor += 4;
  };
  pushSong(songs[0]);
  let lastSection: Section | null = null;
  for (const part of parts) {
    if (part.section === "living" && !sangMid) {
      pushSong(songs[1]);
      sangMid = true;
    }
    if (part.section === "closing") pushSong(songs[2]);
    const when = formatTime(addMinutes(meetingTime, cursor));
    const status = partStatus(meetingDate, part.assigneeId, today);
    const assignee = part.assigneeId ? byId.get(part.assigneeId) : undefined;
    const assistant = part.assistantId ? byId.get(part.assistantId) : undefined;
    const showSection = part.section !== lastSection;
    lastSection = part.section;
    rows.push({
      key: part.id,
      node: (
        <div>
          {showSection ? (
            <p className="mt-4 mb-2 text-xs font-semibold tracking-[0.14em] text-royal uppercase">
              {SECTION_LABEL[part.section]}
            </p>
          ) : null}
          <article
            className={cn(
              "rounded-3xl border bg-card p-4 shadow-card sm:p-5",
              status === "unassigned" ? "border-dashed border-warn/60" : "border-line",
            )}
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-muted tabular-nums">
                  {when} · {part.durationMin} min
                </p>
                <h2 className="mt-1 font-sans text-lg font-semibold tracking-normal text-ink">{part.title}</h2>
                <p className="mt-1 text-sm text-muted">{part.detail}</p>
              </div>
              <StatusPill status={status} />
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              <PersonLine label="Assigned member" name={assignee ? fullName(assignee) : "Unassigned"} />
              <PersonLine
                label="Assistant"
                name={
                  part.needsAssistant ? (assistant ? fullName(assistant) : "Unassigned") : "Not required"
                }
              />
            </div>
            {part.reason ? <p className="mt-3 text-sm text-muted">{part.reason}</p> : null}
            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="soft" className="h-10" onClick={() => onEdit(part)}>
                <Pencil className="size-4" />
                Edit
              </Button>
              <Button variant="soft" className="h-10" onClick={() => onReplace(part, "assignee")}>
                <ArrowLeftRight className="size-4" />
                Replace
              </Button>
              {part.needsAssistant ? (
                <Button variant="ghost" className="h-10" onClick={() => onReplace(part, "assistant")}>
                  Replace assistant
                </Button>
              ) : null}
            </div>
          </article>
        </div>
      ),
    });
    cursor += part.durationMin;
  }

  return (
    <div className="relative space-y-1 border-l border-line pl-4 sm:pl-6">
      {rows.map((row) => (
        <div key={row.key}>{row.node}</div>
      ))}
    </div>
  );
}

function PersonLine({ label, name }: { label: string; name: string }) {
  return (
    <div className="rounded-2xl bg-soft px-3 py-2">
      <p className="text-[11px] font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="truncate text-sm font-semibold">{name}</p>
    </div>
  );
}

function EditDialog({
  assignment,
  meetingDate,
  members,
  parts,
  onOpenChange,
  onSave,
}: {
  assignment: Assignment | null;
  meetingDate: string;
  members: ReturnType<typeof useMinistry.getState>["members"];
  parts: Assignment[];
  onOpenChange: (open: boolean) => void;
  onSave: (assignment: Assignment) => void;
}) {
  const [assigneeId, setAssigneeId] = useState<string>("");
  const [assistantId, setAssistantId] = useState<string>("");

  useEffect(() => {
    setAssigneeId(assignment?.assigneeId ?? "");
    setAssistantId(assignment?.assistantId ?? "");
  }, [assignment]);

  const used = new Set<string>();
  for (const part of parts) {
    if (!assignment || part.id === assignment.id) continue;
    if (part.assigneeId) used.add(part.assigneeId);
    if (part.assistantId) used.add(part.assistantId);
  }

  const assigneeOptions = assignment
    ? members.filter(
        (member) =>
          member.id === assigneeId ||
          isEligible(member, {
            date: meetingDate,
            skill: assignment.skill,
            who: assignment.who,
            allowUnbaptized: assignment.allowUnbaptized,
            used,
          }),
      )
    : [];
  const assistantUsed = new Set(used);
  if (assigneeId) assistantUsed.add(assigneeId);
  const assistantOptions =
    assignment?.assistantSkill
      ? members.filter(
          (member) =>
            member.id === assistantId ||
            isEligible(member, {
              date: meetingDate,
              skill: assignment.assistantSkill as NonNullable<Assignment["assistantSkill"]>,
              who: assignment.assistantWho,
              allowUnbaptized: assignment.assistantAllowUnbaptized,
              used: assistantUsed,
            }),
        )
      : [];

  return (
    <Modal
      open={Boolean(assignment)}
      onOpenChange={onOpenChange}
      title={assignment?.title ?? "Edit assignment"}
      description="Choose a qualified publisher. People already used in this meeting are hidden."
    >
      {assignment ? (
        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            onSave({
              ...assignment,
              assigneeId: assigneeId || null,
              assistantId: assignment.needsAssistant ? assistantId || null : null,
              reason: assigneeId ? "Adjusted manually by the overseer." : "Cleared. This part is open again.",
            });
          }}
        >
          <Field label="Assigned member">
            <select className={fieldClass} value={assigneeId} onChange={(event) => setAssigneeId(event.target.value)}>
              <option value="">Unassigned</option>
              {assigneeOptions.map((member) => (
                <option key={member.id} value={member.id}>
                  {fullName(member)}
                </option>
              ))}
            </select>
          </Field>
          {assignment.needsAssistant ? (
            <Field label="Assistant">
              <select className={fieldClass} value={assistantId} onChange={(event) => setAssistantId(event.target.value)}>
                <option value="">Unassigned</option>
                {assistantOptions.map((member) => (
                  <option key={member.id} value={member.id}>
                    {fullName(member)}
                  </option>
                ))}
              </select>
            </Field>
          ) : null}
          <div className="flex flex-wrap justify-end gap-2 pt-2">
            <Button variant="soft" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Save assignment</Button>
          </div>
        </form>
      ) : null}
    </Modal>
  );
}
