import { useNavigate } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { Button, Card, PageIntro } from "@/components/ministry/ui";
import { formatLong, partStatus, utcTodayIso } from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";
import type { Section } from "@/lib/ministry/types";

const SECTION: Record<Section, string> = {
  opening: "Opening",
  treasures: "Treasures from God’s Word",
  ministry: "Apply Yourself to the Field Ministry",
  living: "Living as Christians",
  closing: "Closing",
};

export function WorkbookPage() {
  const navigate = useNavigate();
  const focusMeeting = useMinistry((state) => state.focusMeeting);
  const meetings = useMinistry((state) => state.meetings);
  const assignments = useMinistry((state) => state.assignments);
  const today = utcTodayIso();

  return (
    <div>
      <PageIntro
        eyebrow="Workbook"
        title="JW Workbook"
        lede="Original midweek outlines for this congregation. Open a week in the planner when you are ready to assign it."
      />
      <div className="space-y-4">
        {meetings.map((meeting) => {
          const parts = assignments
            .filter((assignment) => assignment.meetingId === meeting.id)
            .sort((a, b) => a.order - b.order);
          const open = parts.filter((part) => partStatus(meeting.date, part.assigneeId, today) === "unassigned").length;
          let section: Section | null = null;
          return (
            <Card key={meeting.id} className="p-5 sm:p-6">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex gap-3">
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-sidebar text-cyan">
                    <BookOpen className="size-5" />
                  </span>
                  <div>
                    <p className="text-xs font-semibold tracking-[0.14em] text-royal uppercase">
                      Week of {meeting.weekLabel}
                    </p>
                    <h2 className="mt-1 text-3xl">{meeting.theme}</h2>
                    <p className="mt-1 text-sm text-muted">
                      {formatLong(meeting.date)} · Bible reading {meeting.reading}
                    </p>
                    <p className="mt-2 max-w-xl text-sm text-muted">{meeting.summary}</p>
                  </div>
                </div>
                <Button
                  variant="soft"
                  onClick={() => {
                    focusMeeting(meeting.id);
                    void navigate({ to: "/planner" });
                  }}
                >
                  Open in planner
                </Button>
              </div>
              <p className="mt-4 text-xs font-medium text-muted">
                Songs {meeting.songs.join(" · ")}
                {meeting.date < today ? " · Completed week" : open ? ` · ${open} open parts` : " · Parts assigned"}
              </p>
              <ol className="mt-4 space-y-2">
                {parts.map((part) => {
                  const show = part.section !== section;
                  section = part.section;
                  return (
                    <li key={part.id}>
                      {show ? (
                        <p className="mt-3 mb-1 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">
                          {SECTION[part.section]}
                        </p>
                      ) : null}
                      <div className="flex items-baseline justify-between gap-3 rounded-2xl bg-soft px-3 py-2">
                        <span className="min-w-0">
                          <span className="block text-sm font-semibold">{part.title}</span>
                          <span className="block text-xs text-muted">{part.detail}</span>
                        </span>
                        <span className="shrink-0 text-xs font-semibold text-muted tabular-nums">{part.durationMin} min</span>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
