import { useNavigate } from "@tanstack/react-router";
import {
  ArrowUpRight,
  BookOpen,
  CalendarCheck,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Hourglass,
  Info,
  Sparkles,
  Users,
} from "lucide-react";
import { Button, Card, StatusPill } from "@/components/ministry/ui";
import {
  formatLong,
  formatShort,
  fullName,
  partStatus,
  utcTodayIso,
} from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";

const QUICK = [
  { to: "/planner", label: "AI Meeting Planner", detail: "Arrange or adjust the week", icon: Sparkles },
  { to: "/workbook", label: "JW Workbook", detail: "Themes, readings, and parts", icon: BookOpen },
  { to: "/members", label: "Members", detail: "Profiles, skills, and notes", icon: Users },
  { to: "/availability", label: "Availability", detail: "Who can take a part", icon: CalendarCheck },
] as const;

export function DashboardPage() {
  const navigate = useNavigate();
  const congregation = useMinistry((state) => state.congregation);
  const members = useMinistry((state) => state.members);
  const meetings = useMinistry((state) => state.meetings);
  const assignments = useMinistry((state) => state.assignments);
  const activities = useMinistry((state) => state.activities);
  const requestArrange = useMinistry((state) => state.requestArrange);
  const today = utcTodayIso();
  const byId = new Map(members.map((member) => [member.id, member]));
  const upcomingMeetings = meetings.filter((meeting) => meeting.date >= today);
  const next = upcomingMeetings[0];
  const nextParts = next
    ? assignments.filter((assignment) => assignment.meetingId === next.id).sort((a, b) => a.order - b.order)
    : [];
  const completed = assignments.filter((assignment) => {
    const meeting = meetings.find((item) => item.id === assignment.meetingId);
    return meeting ? partStatus(meeting.date, assignment.assigneeId, today) === "completed" : false;
  }).length;
  const pending = assignments.filter((assignment) => {
    const meeting = meetings.find((item) => item.id === assignment.meetingId);
    return meeting ? partStatus(meeting.date, assignment.assigneeId, today) === "pending" : false;
  }).length;
  const openCount = nextParts.filter((part) => !part.assigneeId).length;

  const stats = [
    { label: "Registered Members", value: members.length, icon: Users, note: congregation },
    { label: "Upcoming Meetings", value: upcomingMeetings.length, icon: CalendarDays, note: "On the schedule" },
    { label: "Completed Assignments", value: completed, icon: CheckCircle2, note: "Already given" },
    { label: "Pending Assignments", value: pending, icon: Hourglass, note: "Still ahead" },
  ];

  return (
    <div>
      <section className="relative min-w-0 overflow-hidden rounded-[1.75rem] bg-sidebar px-5 py-6 text-on-navy shadow-lift sm:px-8 sm:py-8">
        <div
          className="pointer-events-none absolute inset-0"
          aria-hidden
          style={{
            backgroundImage:
              "radial-gradient(520px 180px at 100% 0%, rgb(53 106 230 / 0.45), transparent 60%), linear-gradient(180deg, rgb(54 197 232 / 0.12), transparent 32%)",
          }}
        />
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-xl">
            <p className="text-xs font-semibold tracking-[0.18em] text-cyan uppercase">Midweek meeting desk</p>
            <h1 className="mt-3 text-4xl text-on-navy sm:text-5xl">Welcome to MinistryFlow AI</h1>
            <p className="mt-3 max-w-md text-base text-on-navy/75">Your intelligent meeting assignment assistant.</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={() => {
                requestArrange();
                void navigate({ to: "/planner" });
              }}
              className="tap inline-flex h-14 items-center gap-3 rounded-full bg-royal pr-5 pl-2 text-sm font-semibold text-on-royal shadow-[0_14px_30px_-16px_rgb(53,106,230,0.95)]"
            >
              <span className="ai-orb grid size-10 place-items-center rounded-full bg-cyan text-sidebar">
                <Sparkles className="size-5" />
              </span>
              Arrange with AI
            </button>
            <Button variant="ghost" className="h-14 text-on-navy hover:bg-on-navy/10" onClick={() => void navigate({ to: "/planner" })}>
              Open planner
            </Button>
          </div>
        </div>
      </section>

      <div className="stagger mt-5 grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <p className="text-sm text-muted">{stat.label}</p>
                <span className="grid size-10 place-items-center rounded-2xl bg-soft text-royal">
                  <Icon className="size-4" />
                </span>
              </div>
              <p className="mt-4 font-display text-4xl tabular-nums text-ink">{stat.value}</p>
              <p className="mt-1 truncate text-xs text-muted">{stat.note}</p>
            </Card>
          );
        })}
      </div>

      <div className="mt-5 grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,0.9fr)]">
        <Card className="p-5 sm:p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold tracking-[0.16em] text-royal uppercase">Upcoming meeting</p>
              <h2 className="mt-2 text-3xl text-ink">{next ? next.theme : "No meeting scheduled"}</h2>
              {next ? (
                <p className="mt-1 text-sm text-muted">
                  {formatLong(next.date)} · {next.reading}
                </p>
              ) : null}
            </div>
            {next ? (
              <button
                type="button"
                onClick={() => void navigate({ to: "/planner" })}
                className="tap grid size-11 shrink-0 place-items-center rounded-full bg-soft text-ink"
                aria-label="Open this meeting"
              >
                <ArrowUpRight className="size-4" />
              </button>
            ) : null}
          </div>
          {next ? (
            <>
              <div className="mt-4 flex flex-wrap gap-2 text-xs font-medium text-muted">
                <span className="rounded-full bg-soft px-3 py-1">Week of {next.weekLabel}</span>
                <span className="rounded-full bg-soft px-3 py-1">Songs {next.songs.join(" · ")}</span>
                <span className="rounded-full bg-soft px-3 py-1">
                  {openCount === 0 ? "Programme filled" : `${openCount} parts still open`}
                </span>
              </div>
              <ol className="mt-5 space-y-2">
                {nextParts.slice(0, 5).map((part) => {
                  const person = part.assigneeId ? byId.get(part.assigneeId) : undefined;
                  const status = partStatus(next.date, part.assigneeId, today);
                  return (
                    <li key={part.id} className="flex min-w-0 items-center gap-3 rounded-2xl bg-soft/70 px-3 py-2.5">
                      <span className="w-12 shrink-0 text-xs font-semibold text-muted tabular-nums">{part.durationMin}m</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{part.title}</p>
                        <p className="truncate text-xs text-muted">{person ? fullName(person) : "Needs a publisher"}</p>
                      </div>
                      <StatusPill status={status} />
                    </li>
                  );
                })}
              </ol>
            </>
          ) : (
            <p className="mt-4 text-sm text-muted">Add a meeting week from the workbook when you are ready.</p>
          )}
        </Card>

        <Card className="p-5 sm:p-6">
          <p className="text-xs font-semibold tracking-[0.16em] text-royal uppercase">Recent activity</p>
          <h2 className="mt-2 text-3xl">What changed</h2>
          <ul className="mt-5 space-y-4">
            {activities.slice(0, 5).map((item) => (
              <li key={item.id} className="flex gap-3">
                <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-2xl bg-soft text-royal">
                  <Clock3 className="size-4" />
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{item.title}</p>
                  <p className="text-sm text-muted">{item.detail}</p>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-5">
        <h2 className="text-2xl">Quick access</h2>
        <div className="mt-3 grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {QUICK.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.to}
                type="button"
                onClick={() => void navigate({ to: item.to })}
                className="tap flex min-w-0 items-center gap-3 rounded-3xl border border-line bg-card p-4 text-left shadow-card hover:border-royal/30"
              >
                <span className="grid size-11 place-items-center rounded-2xl bg-sidebar text-cyan">
                  <Icon className="size-5" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold">{item.label}</span>
                  <span className="block truncate text-xs text-muted">{item.detail}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {next ? (
        <Card className="mt-5 flex items-center gap-3 p-4">
          <span className="grid size-10 shrink-0 place-items-center rounded-2xl bg-soft text-royal">
            <Info className="size-4" />
          </span>
          <p className="min-w-0 flex-1 text-sm text-muted">
            <span className="font-semibold text-ink">{formatShort(next.date)}</span> is the next meeting. Suggestions stay editable — the overseer confirms the final programme.
          </p>
        </Card>
      ) : null}
    </div>
  );
}
