import { useState } from "react";
import { Card, PageIntro } from "@/components/ministry/ui";
import { fullName, privilegeLabel, SKILL_META } from "@/lib/ministry/format";
import { useMinistry } from "@/lib/ministry/store";
import { SKILL_IDS, type SkillId } from "@/lib/ministry/types";
import { cn } from "@/lib/utils";

export function SkillsPage() {
  const members = useMinistry((state) => state.members);
  const setSkill = useMinistry((state) => state.setSkill);
  const [active, setActive] = useState<SkillId>("treasures");
  const meta = SKILL_META[active];
  const ranked = [...members]
    .map((member) => ({ member, value: member.skills[active] ?? 0 }))
    .sort((a, b) => b.value - a.value || a.member.lastName.localeCompare(b.member.lastName));

  return (
    <div>
      <PageIntro
        eyebrow="Abilities"
        title="Abilities & skills"
        lede="See who can carry each part, and adjust a rating when someone has grown."
      />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {SKILL_IDS.map((skill) => {
          const qualified = members.filter((member) => (member.skills[skill] ?? 0) >= 70).length;
          const average = Math.round(
            members.reduce((sum, member) => sum + (member.skills[skill] ?? 0), 0) / Math.max(members.length, 1),
          );
          return (
            <button
              key={skill}
              type="button"
              onClick={() => setActive(skill)}
              className={cn(
                "tap rounded-3xl border bg-card p-4 text-left shadow-card",
                active === skill ? "border-royal" : "border-line",
              )}
            >
              <p className="text-xs font-semibold tracking-wide text-royal uppercase">{SKILL_META[skill].group}</p>
              <h2 className="mt-1 font-sans text-lg font-semibold tracking-normal">{SKILL_META[skill].label}</h2>
              <p className="mt-1 text-sm text-muted">{SKILL_META[skill].blurb}</p>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-soft">
                <div className="h-full rounded-full bg-royal" style={{ width: `${average}%` }} />
              </div>
              <p className="mt-2 text-xs text-muted tabular-nums">
                {qualified} qualified · average {average}
              </p>
            </button>
          );
        })}
      </div>

      <Card className="mt-5 p-5">
        <h2 className="text-3xl">{meta.label}</h2>
        <p className="mt-1 text-sm text-muted">{meta.blurb}</p>
        <ul className="mt-5 space-y-4">
          {ranked.map(({ member, value }) => (
            <li key={member.id}>
              <div className="mb-1 flex items-center justify-between gap-3 text-sm">
                <span className="min-w-0 truncate font-semibold">
                  {fullName(member)}
                  <span className="ml-2 font-normal text-muted">{privilegeLabel(member.privilege)}</span>
                </span>
                <span className="tabular-nums text-muted">{value}</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={value}
                aria-label={`${meta.label} for ${fullName(member)}`}
                onChange={(event) => setSkill(member.id, active, Number(event.target.value))}
                className="w-full accent-royal"
              />
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
