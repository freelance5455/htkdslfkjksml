import React, { useState } from 'react';
import {
  TrendingUp,
  DollarSign,
  Clock,
  Layers,
  Sparkles,
  ArrowRight,
  Bookmark,
  Check,
  FileText,
  Users,
  Target,
  Award,
  ExternalLink,
  X,
  Copy,
} from 'lucide-react';
import { BusinessBlueprint, Language } from '../types';
import { SAMPLE_BLUEPRINTS } from '../data/mockData';
import { translations } from '../translations/translations';
import { synthesizeBusinessPlan } from '../services/aiFallbackService';

interface Props {
  language: Language;
  savedBlueprintIds: string[];
  onToggleSaveBlueprint: (id: string) => void;
}

export const BusinessOpportunities: React.FC<Props> = ({
  language,
  savedBlueprintIds,
  onToggleSaveBlueprint,
}) => {
  const [blueprints] = useState<BusinessBlueprint[]>(SAMPLE_BLUEPRINTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [capitalFilter, setCapitalFilter] = useState<'all' | 'micro' | 'low' | 'medium'>('all');

  // Business plan generator modal state
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [planLoading, setPlanLoading] = useState(false);
  const [activePlanTitle, setActivePlanTitle] = useState('');
  const [businessPlanData, setBusinessPlanData] = useState<any>(null);
  const [planCopied, setPlanCopied] = useState(false);

  const t = translations[language].business;

  const filteredBlueprints = blueprints.filter((b) => {
    const matchesCategory =
      selectedCategory === 'all' || b.category === selectedCategory;
    const matchesCapital =
      capitalFilter === 'all' || b.capitalRequired === capitalFilter;
    return matchesCategory && matchesCapital;
  });

  const handleGeneratePlan = async (blueprint: BusinessBlueprint) => {
    const title = language === 'am' ? blueprint.titleAm : blueprint.title;
    const description = language === 'am' ? blueprint.summaryAm : blueprint.summary;

    setActivePlanTitle(title);
    setIsPlanModalOpen(true);
    setPlanLoading(true);
    setBusinessPlanData(null);

    let plan: any = null;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const response = await fetch('/api/gemini/generate-business-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        signal: controller.signal,
        body: JSON.stringify({
          title,
          description,
          category: blueprint.category,
          language,
        }),
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const data = await response.json().catch(() => null);
        if (data?.data?.executiveSummary) {
          plan = data.data;
        }
      }
    } catch (err: any) {
      console.warn('Network issue in business plan call, using engine:', err?.message);
    }

    if (!plan || !plan.executiveSummary) {
      plan = synthesizeBusinessPlan(title, description, language);
    }

    setBusinessPlanData(plan);
    setPlanLoading(false);
  };

  const copyBusinessPlan = () => {
    if (!businessPlanData) return;
    const text = `PROJECT ZERO - 1-PAGE LEAN BUSINESS CANVAS
Venture: ${activePlanTitle}

Executive Summary:
${businessPlanData.executiveSummary}

Value Proposition:
${businessPlanData.uniqueValueProposition}

Target Customers:
${businessPlanData.targetCustomerSegments?.map((s: string) => `• ${s}`).join('\n')}

Revenue Streams:
${businessPlanData.revenueStreams?.map((r: string) => `• ${r}`).join('\n')}

Cost Structure:
${businessPlanData.costStructure?.map((c: string) => `• ${c}`).join('\n')}

First Month Milestones:
${businessPlanData.firstMonthMilestones?.map((m: string) => `• ${m}`).join('\n')}`;

    navigator.clipboard.writeText(text);
    setPlanCopied(true);
    setTimeout(() => setPlanCopied(false), 2000);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-emerald-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="flex items-center space-x-2 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-2">
          <TrendingUp className="w-4 h-4" />
          <span>PROJECT ZERO • VENTURE BLUEPRINTS</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
          {t.title}
        </h2>
        <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
          {t.subtitle}
        </p>
      </div>

      {/* Filter Chips */}
      <div className="space-y-3">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
          {[
            { id: 'all', label: t.allSectors },
            { id: 'agriculture', label: language === 'am' ? 'ግብርና' : 'Agri-Business' },
            { id: 'green', label: language === 'am' ? 'መልሶ ጥቅም' : 'Eco & Recycling' },
            { id: 'services', label: language === 'am' ? 'አገልግሎት' : 'Local Services' },
            { id: 'tech', label: language === 'am' ? 'ዲጂታል' : 'Digital / Fintech' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Capital Level Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="font-bold text-slate-500 text-[11px] whitespace-nowrap">
            {t.capitalFilter}:
          </span>
          {[
            { id: 'all', label: t.capitalAll },
            { id: 'micro', label: t.capitalMicro },
            { id: 'low', label: t.capitalLow },
            { id: 'medium', label: t.capitalMedium },
          ].map((cap) => (
            <button
              key={cap.id}
              onClick={() => setCapitalFilter(cap.id as any)}
              className={`px-3 py-1 rounded-xl whitespace-nowrap text-[11px] font-semibold transition-all ${
                capitalFilter === cap.id
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cap.label}
            </button>
          ))}
        </div>
      </div>

      {/* Blueprints Grid */}
      <div className="space-y-4">
        {filteredBlueprints.map((blueprint) => {
          const isSaved = savedBlueprintIds.includes(blueprint.id);
          const title = language === 'am' ? blueprint.titleAm : blueprint.title;
          const summary = language === 'am' ? blueprint.summaryAm : blueprint.summary;
          const steps = language === 'am' ? blueprint.keyStepsAm : blueprint.keySteps;
          const audience = language === 'am' ? blueprint.targetAudienceAm : blueprint.targetAudience;

          return (
            <div
              key={blueprint.id}
              className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm hover:border-emerald-300 transition-all space-y-4 group"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">
                      {blueprint.category}
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium">
                      ROI: {blueprint.roiTimeline}
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-emerald-900 transition-colors">
                    {title}
                  </h3>
                </div>

                <button
                  onClick={() => onToggleSaveBlueprint(blueprint.id)}
                  className={`p-2 rounded-xl transition-all cursor-pointer ${
                    isSaved
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                  title="Bookmark opportunity"
                >
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>

              {/* Demand Score & Capital Matrix */}
              <div className="grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
                    <span>{t.demandScore}</span>
                    <span className="font-extrabold text-emerald-700">{blueprint.demandScore}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${blueprint.demandScore}%` }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                    {t.capitalFilter}
                  </div>
                  <div className="font-extrabold text-slate-800 text-[11px] sm:text-xs line-clamp-1">
                    {blueprint.capitalAmount}
                  </div>
                </div>
              </div>

              {/* Summary */}
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                {summary}
              </p>

              {/* Target Customers */}
              <div className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-100 text-xs flex items-start space-x-2">
                <Users className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-emerald-950 mr-1">{t.targetCustomers}:</span>
                  <span className="text-emerald-900">{audience}</span>
                </div>
              </div>

              {/* Initial Action Steps */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  {t.starterSteps}
                </div>
                <div className="space-y-1">
                  {steps.map((step, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-xs text-slate-700">
                      <span className="w-4 h-4 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action: Generate AI Business Plan */}
              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  onClick={() => handleGeneratePlan(blueprint)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs flex items-center space-x-1.5 shadow-sm transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t.generatePlan}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Incubation & Grants Alert Card */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 rounded-3xl p-5 sm:p-6 text-white space-y-3">
        <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
          <Award className="w-4 h-4" />
          <span>{t.exploreTenders}</span>
        </div>
        <h3 className="font-extrabold text-base">
          {language === 'am' ? 'የወጣቶች ስራ ፈጠራ ድጋፎች እና ኢንኩቤተሮች' : 'Youth Innovation Grants & Incubation Calls'}
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          {language === 'am'
            ? 'አካባቢያዊ ችግሮችን ወደ ንግድ የሚቀይሩ ወጣቶች ከመንግስት እና ከአለም አቀፍ ድርጅቶች መነሻ ካፒታል እና ስልጠና ማግኘት ይችላሉ።'
            : 'Access seed capital, zero-collateral micro-grants, and mentoring for problem-solving startups in emerging markets.'}
        </p>
        <div className="flex flex-wrap gap-2 pt-1 font-medium text-xs">
          <span className="px-3 py-1 rounded-full bg-white/10 text-emerald-300">
            • UNDP Youth Connekt Africa
          </span>
          <span className="px-3 py-1 rounded-full bg-white/10 text-emerald-300">
            • Tony Elumelu TEF Foundation
          </span>
          <span className="px-3 py-1 rounded-full bg-white/10 text-emerald-300">
            • Ethiopia Innovation & Technology (MInT)
          </span>
        </div>
      </div>

      {/* AI Business Plan Modal */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-xl border border-slate-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-5 text-white flex items-center justify-between shrink-0">
              <div className="pr-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                  PROJECT ZERO • LEAN CANVAS
                </span>
                <h3 className="font-extrabold text-base sm:text-lg line-clamp-1">{activePlanTitle}</h3>
              </div>
              <button
                onClick={() => setIsPlanModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700">
              {planLoading ? (
                <div className="py-16 text-center space-y-3">
                  <div className="w-8 h-8 border-3 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin mx-auto"></div>
                  <p className="text-slate-600 font-semibold text-xs">
                    {language === 'am' ? 'ባለ 1-ገጽ የቢዝነስ እቅድ በGemini እየተዘጋጀ ነው...' : 'Drafting 1-Page Lean Canvas with Gemini AI...'}
                  </p>
                </div>
              ) : businessPlanData ? (
                <div className="space-y-4">
                  {/* Executive Summary */}
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                    <div className="font-bold text-emerald-950 mb-1 text-xs uppercase tracking-wider">
                      Executive Summary
                    </div>
                    <p className="leading-relaxed text-emerald-900 text-xs sm:text-sm">
                      {businessPlanData.executiveSummary}
                    </p>
                  </div>

                  {/* Value Proposition */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="font-bold text-slate-900 mb-1 text-xs uppercase tracking-wider">
                      Unique Value Proposition
                    </div>
                    <p className="leading-relaxed text-slate-700 text-xs sm:text-sm">
                      {businessPlanData.uniqueValueProposition}
                    </p>
                  </div>

                  {/* Customer Segments & Channels */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900 mb-1.5">Target Customers</div>
                      <ul className="space-y-1 list-disc list-inside text-slate-600">
                        {businessPlanData.targetCustomerSegments?.map((s: string, i: number) => (
                          <li key={i}>{s}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900 mb-1.5">Marketing & Channels</div>
                      <ul className="space-y-1 list-disc list-inside text-slate-600">
                        {businessPlanData.channels?.map((c: string, i: number) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Revenue & Costs */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-emerald-50/40 border border-emerald-100 text-xs">
                      <div className="font-bold text-emerald-950 mb-1.5">Revenue Streams</div>
                      <ul className="space-y-1 list-disc list-inside text-emerald-900">
                        {businessPlanData.revenueStreams?.map((r: string, i: number) => (
                          <li key={i}>{r}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-rose-50/40 border border-rose-100 text-xs">
                      <div className="font-bold text-rose-950 mb-1.5">Cost Structure</div>
                      <ul className="space-y-1 list-disc list-inside text-rose-900">
                        {businessPlanData.costStructure?.map((c: string, i: number) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* First Month Milestones */}
                  <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 text-xs">
                    <div className="font-bold text-teal-950 mb-2">First Month Launch Milestones</div>
                    <div className="space-y-1.5">
                      {businessPlanData.firstMonthMilestones?.map((m: string, i: number) => (
                        <div key={i} className="flex items-start space-x-2 text-teal-900">
                          <Check className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                          <span>{m}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500 text-xs">
                  Could not load business plan.
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
              <button
                onClick={copyBusinessPlan}
                disabled={!businessPlanData}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-1.5"
              >
                {planCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{planCopied ? 'Copied' : 'Copy Plan'}</span>
              </button>

              <button
                onClick={() => setIsPlanModalOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
