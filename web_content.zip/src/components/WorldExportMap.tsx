import { useState } from 'react';
import {
  Globe2,
  Ship,
  Compass,
  ArrowUpRight,
  TrendingUp,
  Clock,
  Scale,
  Sparkles,
  Info,
} from 'lucide-react';
import { Language } from '../types';
import { playKeyTap } from '../utils/audio';

export type SupportedCountryFilter = 'all' | 'china' | 'eu' | 'us' | 'india' | 'uae';

interface WorldExportMapProps {
  language: Language;
  selectedCountry: SupportedCountryFilter;
  onSelectCountry: (country: SupportedCountryFilter) => void;
  onOpenProfitAdvisor?: () => void;
}

interface DestinationHub {
  id: SupportedCountryFilter;
  nameSw: string;
  nameEn: string;
  flag: string;
  ports: string;
  transitDays: number;
  topCropsSw: string;
  topCropsEn: string;
  tariffBadgeSw: string;
  tariffBadgeEn: string;
  priceIndex: number;
  indexDelta: string;
  freightCostUsd: number; // estimated 40ft container freight from Dar
  cx: number;
  cy: number;
}

const DESTINATION_HUBS: DestinationHub[] = [
  {
    id: 'china',
    nameSw: 'China',
    nameEn: 'China',
    flag: '🇨🇳',
    ports: 'Qingdao, Tianjin, Shanghai, Guangzhou',
    transitDays: 22,
    topCropsSw: 'Ufuta (99%), Soya, Mihogo, Parachichi, Korosho, Pilipili',
    topCropsEn: 'Sesame (99%), Soybeans, Cassava, Avocados, Cashews, Chili',
    tariffBadgeSw: 'Ushuru Sifuri 0% (Zero-Tariff 98%)',
    tariffBadgeEn: 'Zero-Tariff 98% Bilateral Protocol',
    priceIndex: 142.6,
    indexDelta: '+8.4%',
    freightCostUsd: 1850,
    cx: 730,
    cy: 215,
  },
  {
    id: 'eu',
    nameSw: 'Umoja wa Ulaya (EU)',
    nameEn: 'European Union (EU)',
    flag: '🇪🇺',
    ports: 'Rotterdam, Hamburg, Amsterdam, Marseille',
    transitDays: 26,
    topCropsSw: 'Parachichi ya Kikaboni, Kahawa (EUDR), Kakao, Korosho W240',
    topCropsEn: 'Organic Avocados, Specialty Coffee (EUDR), Fine Cocoa, Cashew W240',
    tariffBadgeSw: 'Ushuru Sifuri 0% (EU EBA Scheme)',
    tariffBadgeEn: 'EU EBA 0% Duty Free Quota',
    priceIndex: 158.2,
    indexDelta: '+14.6%',
    freightCostUsd: 2650,
    cx: 470,
    cy: 165,
  },
  {
    id: 'us',
    nameSw: 'Marekani (USA)',
    nameEn: 'United States (USA)',
    flag: '🇺🇸',
    ports: 'New York/Newark, Long Beach, Savannah, Miami',
    transitDays: 31,
    topCropsSw: 'Kahawa Peaberry (SCA 86+), Korosho W320, Matunda Yaliyokaushwa',
    topCropsEn: 'Specialty Coffee (SCA 86+), Cashews W320, Organic Dried Fruits',
    tariffBadgeSw: 'Ushuru Sifuri 0% (Mpango wa AGOA)',
    tariffBadgeEn: 'AGOA Duty-Free 0% Preference',
    priceIndex: 164.8,
    indexDelta: '+15.2%',
    freightCostUsd: 3400,
    cx: 210,
    cy: 195,
  },
  {
    id: 'india',
    nameSw: 'India',
    nameEn: 'India',
    flag: '🇮🇳',
    ports: 'JNPT Port Mumbai, Chennai',
    transitDays: 12,
    topCropsSw: 'Mbaazi (Toor Dal), Choroko, Kunde',
    topCropsEn: 'Pigeon Peas (Toor Dal), Mung Beans, Pulses',
    tariffBadgeSw: 'Makubaliano ya G2G (0% Ushuru)',
    tariffBadgeEn: 'Bilateral G2G MoU (0% Duty)',
    priceIndex: 124.5,
    indexDelta: '+4.2%',
    freightCostUsd: 1100,
    cx: 645,
    cy: 245,
  },
  {
    id: 'uae',
    nameSw: 'Falme za Kiarabu (UAE)',
    nameEn: 'United Arab Emirates (UAE)',
    flag: '🇦🇪',
    ports: 'Jebel Ali / Dubai Port, Abu Dhabi',
    transitDays: 14,
    topCropsSw: 'Karafuu ya Zanzibar, Tangawizi, Embe',
    topCropsEn: 'Zanzibar Cloves, Fresh Ginger, Mangoes',
    tariffBadgeSw: 'Mkataba wa Biashara Tanzania-GCC',
    tariffBadgeEn: 'Tanzania-GCC Economic Partnership',
    priceIndex: 139.8,
    indexDelta: '+6.8%',
    freightCostUsd: 1350,
    cx: 580,
    cy: 228,
  },
];

export default function WorldExportMap({
  language,
  selectedCountry,
  onSelectCountry,
  onOpenProfitAdvisor,
}: WorldExportMapProps) {
  const isSw = language === 'sw';
  const [hoveredHub, setHoveredHub] = useState<DestinationHub | null>(null);

  // Origin Coordinates (Tanzania Coast / Dar es Salaam Port)
  const tzOrigin = { cx: 535, cy: 315 };

  const activeHub =
    selectedCountry !== 'all'
      ? DESTINATION_HUBS.find((h) => h.id === selectedCountry) || null
      : hoveredHub;

  return (
    <div
      id="world-export-map-container"
      className="p-4 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-emerald-950 text-[#F7F4E9] border border-emerald-500/30 shadow-xl relative overflow-hidden"
    >
      {/* Decorative ambient radial glows */}
      <div className="absolute -top-16 -left-16 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -right-16 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
              <Compass className="w-3 h-3" />
              <span>{isSw ? 'Global Export Insights' : 'Global Export Insights'}</span>
            </span>
            <span className="text-[10px] text-slate-300 flex items-center gap-1 font-medium">
              <Ship className="w-3 h-3 text-amber-400" />
              <span>{isSw ? 'Njia Kuu za Bahari (Corridors)' : 'Direct Maritime Corridors'}</span>
            </span>
          </div>
          <h3 className="font-display text-base sm:text-lg font-bold text-white mt-1">
            {isSw
              ? 'Ramani ya Njia za Masoko ya Kimataifa & Viashiria vya Bei'
              : 'Global Export Market Corridors & Price Indices'}
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            {isSw
              ? 'Tazama mahitaji maalum ya mazao nchini China, Ulaya (EU), Marekani (US), na Ghuba. Chagua taifa kuona viashiria vya bei za usafirishaji na vigezo vya tani.'
              : 'Interactive export corridor tracking from Dar es Salaam & Mtwara ports to China, EU, US, and GCC markets with real-time price indices and FCL quantity rules.'}
          </p>
        </div>

        {/* Action Button: AI Profit Advisor Command */}
        {onOpenProfitAdvisor && (
          <button
            id="open-profit-advisor-btn"
            onClick={() => {
              playKeyTap();
              onOpenProfitAdvisor();
            }}
            className="flex-shrink-0 py-2 px-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all cursor-pointer hover:scale-[1.02] active:scale-95 self-start sm:self-center"
          >
            <Sparkles className="w-4 h-4 fill-current" />
            <span>{isSw ? 'Ushauri wa Faida Kubwa' : 'Best Profit Advisor'}</span>
          </button>
        )}
      </div>

      {/* Country Filter Bar */}
      <div className="relative z-10 flex items-center gap-1.5 overflow-x-auto py-2.5 no-scrollbar">
        <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1 mr-1 flex-shrink-0">
          <Globe2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isSw ? 'Chagua Taifa:' : 'Select Market:'}</span>
        </span>

        <button
          id="map-filter-all"
          onClick={() => {
            playKeyTap();
            onSelectCountry('all');
          }}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex-shrink-0 flex items-center gap-1 ${
            selectedCountry === 'all'
              ? 'bg-white text-slate-950 shadow-md font-extrabold'
              : 'bg-white/10 text-slate-200 hover:bg-white/15'
          }`}
        >
          <span>🌍</span>
          <span>{isSw ? 'Masoko Yote (All)' : 'All Corridors'}</span>
        </button>

        {DESTINATION_HUBS.map((hub) => {
          const isSelected = selectedCountry === hub.id;
          return (
            <button
              key={hub.id}
              id={`map-filter-${hub.id}`}
              onClick={() => {
                playKeyTap();
                onSelectCountry(hub.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex-shrink-0 flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/30 ring-2 ring-amber-300'
                  : 'bg-white/10 text-slate-200 hover:bg-white/15'
              }`}
            >
              <span className="text-sm">{hub.flag}</span>
              <span>{isSw ? hub.nameSw : hub.nameEn}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-md font-mono ${
                  isSelected ? 'bg-black/20 text-slate-900 font-bold' : 'bg-white/10 text-amber-300'
                }`}
              >
                EPI {hub.priceIndex}
              </span>
            </button>
          );
        })}
      </div>

      {/* SVG WORLD MAP VISUALIZATION */}
      <div className="relative z-10 my-2 rounded-2xl bg-slate-950/80 border border-white/10 overflow-hidden shadow-inner">
        <svg
          viewBox="0 0 920 440"
          className="w-full h-auto max-h-[380px] select-none block"
          style={{ minHeight: '230px' }}
        >
          <defs>
            {/* Background Gradients */}
            <linearGradient id="oceanGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0B132B" />
              <stop offset="100%" stopColor="#081C1B" />
            </linearGradient>

            {/* Shipping Route Gradients */}
            <linearGradient id="chinaRouteGrad" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#EF4444" />
            </linearGradient>

            <linearGradient id="euRouteGrad" x1="1" y1="1" x2="0" y2="0">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>

            <linearGradient id="usRouteGrad" x1="1" y1="1" x2="0" y2="0">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>

            {/* Radar Pulse Animation */}
            <radialGradient id="tanzaniaPulse" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.8" />
              <stop offset="70%" stopColor="#10B981" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Ocean Background */}
          <rect width="920" height="440" fill="url(#oceanGrad)" />

          {/* Subtle Grid Lines (Latitude/Longitude Aesthetic) */}
          <g stroke="rgba(255,255,255,0.05)" strokeWidth="0.8" strokeDasharray="3 4">
            <line x1="0" y1="110" x2="920" y2="110" />
            <line x1="0" y1="220" x2="920" y2="220" /> {/* Equator */}
            <line x1="0" y1="330" x2="920" y2="330" />
            <line x1="230" y1="0" x2="230" y2="440" />
            <line x1="460" y1="0" x2="460" y2="440" />
            <line x1="690" y1="0" x2="690" y2="440" />
          </g>

          {/* Simplified Stylized Continents Outlines */}
          <g fill="#1E293B" fillOpacity="0.75" stroke="#334155" strokeWidth="1" strokeLinejoin="round">
            {/* North America */}
            <path d="M 80 80 Q 140 60 210 75 Q 260 90 270 140 Q 250 180 200 200 Q 160 230 180 250 Q 150 240 130 200 Q 90 180 70 130 Z" />
            {/* South America */}
            <path d="M 220 260 Q 270 270 290 310 Q 270 370 240 400 Q 220 370 210 320 Z" />
            {/* Europe */}
            <path d="M 430 110 Q 480 90 520 110 Q 510 160 470 170 Q 430 160 420 130 Z" />
            {/* Africa */}
            <path d="M 430 180 Q 490 170 540 200 Q 560 260 550 330 Q 520 390 480 400 Q 440 360 420 280 Q 410 230 430 180 Z" />
            {/* Madagascar */}
            <ellipse cx="580" cy="350" rx="10" ry="24" transform="rotate(20 580 350)" />
            {/* Asia */}
            <path d="M 530 100 Q 640 70 780 100 Q 840 140 820 220 Q 750 250 710 260 Q 660 280 630 250 Q 600 200 540 180 Z" />
            {/* Australia */}
            <path d="M 760 310 Q 820 300 840 340 Q 810 380 760 370 Q 740 340 760 310 Z" />
          </g>

          {/* SHIPPING LANES / CORRIDOR ARCS from Tanzania to Destinations */}
          <g>
            {/* Route 1: Tanzania -> China (Indian Ocean -> Malacca -> South China Sea) */}
            <path
              d="M 535 315 Q 630 320 680 280 T 730 215"
              fill="none"
              stroke={selectedCountry === 'china' ? '#EF4444' : 'url(#chinaRouteGrad)'}
              strokeWidth={selectedCountry === 'china' ? '3.5' : '2'}
              strokeDasharray={selectedCountry === 'china' ? 'none' : '4 3'}
              opacity={selectedCountry === 'all' || selectedCountry === 'china' ? 0.9 : 0.25}
              className="transition-all duration-300"
            />

            {/* Route 2: Tanzania -> European Union (Suez Canal / Mediterranean / Gibraltar -> Rotterdam) */}
            <path
              d="M 535 315 Q 520 230 495 190 T 470 165"
              fill="none"
              stroke={selectedCountry === 'eu' ? '#38BDF8' : 'url(#euRouteGrad)'}
              strokeWidth={selectedCountry === 'eu' ? '3.5' : '2'}
              strokeDasharray={selectedCountry === 'eu' ? 'none' : '4 3'}
              opacity={selectedCountry === 'all' || selectedCountry === 'eu' ? 0.9 : 0.25}
              className="transition-all duration-300"
            />

            {/* Route 3: Tanzania -> United States (Cape of Good Hope / Atlantic -> New York) */}
            <path
              d="M 535 315 Q 460 410 340 340 T 210 195"
              fill="none"
              stroke={selectedCountry === 'us' ? '#F59E0B' : 'url(#usRouteGrad)'}
              strokeWidth={selectedCountry === 'us' ? '3.5' : '2'}
              strokeDasharray={selectedCountry === 'us' ? 'none' : '4 3'}
              opacity={selectedCountry === 'all' || selectedCountry === 'us' ? 0.9 : 0.25}
              className="transition-all duration-300"
            />

            {/* Route 4: Tanzania -> India (Direct Indian Ocean corridor) */}
            <path
              d="M 535 315 Q 590 280 645 245"
              fill="none"
              stroke="#A855F7"
              strokeWidth={selectedCountry === 'india' ? '3.5' : '1.8'}
              strokeDasharray={selectedCountry === 'india' ? 'none' : '3 3'}
              opacity={selectedCountry === 'all' || selectedCountry === 'india' ? 0.9 : 0.25}
              className="transition-all duration-300"
            />

            {/* Route 5: Tanzania -> UAE (Arabian Sea -> Strait of Hormuz) */}
            <path
              d="M 535 315 Q 560 270 580 228"
              fill="none"
              stroke="#34D399"
              strokeWidth={selectedCountry === 'uae' ? '3.5' : '1.8'}
              strokeDasharray={selectedCountry === 'uae' ? 'none' : '3 3'}
              opacity={selectedCountry === 'all' || selectedCountry === 'uae' ? 0.9 : 0.25}
              className="transition-all duration-300"
            />
          </g>

          {/* ORIGIN HUB: TANZANIA (Dar es Salaam / Mtwara Ports) */}
          <g>
            <circle cx={tzOrigin.cx} cy={tzOrigin.cy} r="22" fill="url(#tanzaniaPulse)" className="animate-ping" style={{ transformOrigin: `${tzOrigin.cx}px ${tzOrigin.cy}px` }} />
            <circle cx={tzOrigin.cx} cy={tzOrigin.cy} r="8" fill="#10B981" stroke="#FFFFFF" strokeWidth="2.5" />
            <circle cx={tzOrigin.cx} cy={tzOrigin.cy} r="3" fill="#FFFFFF" />

            {/* Label for Tanzania */}
            <rect
              x={tzOrigin.cx - 52}
              y={tzOrigin.cy + 14}
              width="104"
              height="20"
              rx="6"
              fill="#064E3B"
              stroke="#34D399"
              strokeWidth="1"
            />
            <text
              x={tzOrigin.cx}
              y={tzOrigin.cy + 28}
              textAnchor="middle"
              fill="#ECFDF5"
              fontSize="10"
              fontWeight="bold"
            >
              🇹🇿 TANZANIA (Origin)
            </text>
          </g>

          {/* DESTINATION PINS & INTERACTIVE NODES */}
          {DESTINATION_HUBS.map((hub) => {
            const isSelected = selectedCountry === hub.id;
            const isHovered = hoveredHub?.id === hub.id;
            const isFaded = selectedCountry !== 'all' && !isSelected;

            return (
              <g
                key={hub.id}
                id={`map-node-${hub.id}`}
                className="cursor-pointer transition-all duration-200"
                opacity={isFaded ? 0.35 : 1}
                onClick={() => {
                  playKeyTap();
                  onSelectCountry(hub.id);
                }}
                onMouseEnter={() => setHoveredHub(hub)}
                onMouseLeave={() => setHoveredHub(null)}
              >
                {/* Outer Glow on hover or selection */}
                {(isSelected || isHovered) && (
                  <circle
                    cx={hub.cx}
                    cy={hub.cy}
                    r="20"
                    fill={hub.id === 'china' ? '#EF4444' : hub.id === 'eu' ? '#38BDF8' : '#F59E0B'}
                    fillOpacity="0.3"
                  />
                )}

                {/* Node circle */}
                <circle
                  cx={hub.cx}
                  cy={hub.cy}
                  r={isSelected ? '9' : '7'}
                  fill={
                    hub.id === 'china'
                      ? '#DC2626'
                      : hub.id === 'eu'
                      ? '#2563EB'
                      : hub.id === 'us'
                      ? '#D97706'
                      : hub.id === 'india'
                      ? '#9333EA'
                      : '#059669'
                  }
                  stroke="#FFFFFF"
                  strokeWidth={isSelected ? '2.5' : '1.5'}
                />

                {/* Destination Label Pill */}
                <g transform={`translate(${hub.cx - 45}, ${hub.cy - 30})`}>
                  <rect
                    width="90"
                    height="22"
                    rx="6"
                    fill={isSelected ? '#FBBF24' : '#0F172A'}
                    stroke={isSelected ? '#F59E0B' : 'rgba(255,255,255,0.3)'}
                    strokeWidth={isSelected ? '1.5' : '0.8'}
                  />
                  <text
                    x="45"
                    y="15"
                    textAnchor="middle"
                    fill={isSelected ? '#0F172A' : '#F8FAFC'}
                    fontSize="10"
                    fontWeight="bold"
                  >
                    {hub.flag} {hub.nameSw.split(' ')[0]}
                  </text>
                </g>
              </g>
            );
          })}
        </svg>

        {/* Floating Interactive Route Summary Badge (Inside the map canvas) */}
        {activeHub && (
          <div className="absolute bottom-2 left-2 right-2 sm:left-4 sm:right-auto sm:max-w-md p-3 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-white/20 shadow-2xl text-xs space-y-1.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 font-bold text-white text-sm">
                <span className="text-base">{activeHub.flag}</span>
                <span>{isSw ? activeHub.nameSw : activeHub.nameEn}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-normal">
                  {isSw ? activeHub.tariffBadgeSw : activeHub.tariffBadgeEn}
                </span>
              </div>
              <span className="text-amber-400 font-mono font-bold text-[11px] flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>EPI {activeHub.priceIndex}</span>
                <span className="text-emerald-400">({activeHub.indexDelta})</span>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 pt-1 border-t border-white/10">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                <span>
                  {isSw ? 'Muda wa Usafiri:' : 'Sea Transit:'}{' '}
                  <strong className="text-white">{activeHub.transitDays} {isSw ? 'Siku' : 'Days'}</strong>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                <span>
                  {isSw ? 'Bandari Kuu:' : 'Key Ports:'}{' '}
                  <span className="text-white truncate">{activeHub.ports.split(',')[0]}</span>
                </span>
              </div>
            </div>

            <div className="text-[11px] text-slate-300 leading-tight">
              <span className="text-slate-400">{isSw ? 'Mazao Yenye Mahitaji:' : 'In-Demand Crops:'} </span>
              <span className="text-emerald-200 font-medium">
                {isSw ? activeHub.topCropsSw : activeHub.topCropsEn}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* QUICK STATS CARDS: EXPORT PRICE INDICES FOR CHINA, EU & US */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-1">
        {/* China Demand Card */}
        <div
          onClick={() => {
            playKeyTap();
            onSelectCountry('china');
          }}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            selectedCountry === 'china'
              ? 'bg-red-950/70 border-red-500 shadow-md ring-1 ring-red-400'
              : 'bg-white/5 border-white/10 hover:bg-white/10'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-xs flex items-center gap-1.5">
              <span className="text-base">🇨🇳</span>
              <span>China (Qingdao / Tianjin)</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/30">
              Zero-Tariff 98%
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Kielezo cha Bei (EPI)' : 'Price Index (EPI)'}</span>
              <span className="font-display text-lg font-extrabold text-white">142.6</span>
              <span className="text-xs text-emerald-400 font-semibold ml-1.5">+8.4%</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Ujazo wa Chini' : 'Standard FCL'}</span>
              <span className="text-xs font-semibold text-amber-300">25 MT (Kontena 1)</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-300 mt-1.5 line-clamp-1">
            🌱 {isSw ? 'Ufuta 99%, Soya, Mihogo mkaushwa, Parachichi' : 'Sesame 99%, Soybeans, Cassava chips'}
          </p>
        </div>

        {/* European Union Demand Card */}
        <div
          onClick={() => {
            playKeyTap();
            onSelectCountry('eu');
          }}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            selectedCountry === 'eu'
              ? 'bg-sky-950/70 border-sky-500 shadow-md ring-1 ring-sky-400'
              : 'bg-white/5 border-white/10 hover:bg-white/10'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-xs flex items-center gap-1.5">
              <span className="text-base">🇪🇺</span>
              <span>European Union (Rotterdam)</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30">
              EU EBA 0% Duty
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Kielezo cha Bei (EPI)' : 'Price Index (EPI)'}</span>
              <span className="font-display text-lg font-extrabold text-white">158.2</span>
              <span className="text-xs text-emerald-400 font-semibold ml-1.5">+14.6%</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Ujazo wa Chini' : 'Standard FCL'}</span>
              <span className="text-xs font-semibold text-amber-300">21.6 MT (Reefer)</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-300 mt-1.5 line-clamp-1">
            🥑 {isSw ? 'Parachichi Kikaboni, Kahawa ya EUDR, Kakao' : 'Organic Avocados, EUDR Coffee, Cocoa'}
          </p>
        </div>

        {/* United States Demand Card */}
        <div
          onClick={() => {
            playKeyTap();
            onSelectCountry('us');
          }}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            selectedCountry === 'us'
              ? 'bg-amber-950/70 border-amber-500 shadow-md ring-1 ring-amber-400'
              : 'bg-white/5 border-white/10 hover:bg-white/10'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-xs flex items-center gap-1.5">
              <span className="text-base">🇺🇸</span>
              <span>United States (New York / LA)</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              AGOA Duty-Free
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Kielezo cha Bei (EPI)' : 'Price Index (EPI)'}</span>
              <span className="font-display text-lg font-extrabold text-white">164.8</span>
              <span className="text-xs text-emerald-400 font-semibold ml-1.5">+15.2%</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">{isSw ? 'Ujazo wa Chini' : 'Standard FCL'}</span>
              <span className="text-xs font-semibold text-amber-300">18 - 25 MT (FCL)</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-300 mt-1.5 line-clamp-1">
            ☕ {isSw ? 'Kahawa Peaberry SCA 86+, Korosho W320' : 'Specialty Coffee SCA 86+, Cashews W320'}
          </p>
        </div>
      </div>
    </div>
  );
}
