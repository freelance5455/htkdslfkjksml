import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  AccessoryId,
  DisciplineId,
  FloatingPopup,
  GameMode,
  LiveTelemetry,
} from '../types/game';
import { createKotostModel, KotostRig } from '../three/createKotostModel';
import {
  createStackItemMesh,
  createStageEnvironment,
} from '../three/createStageEnvironment';
import { STACK_ITEMS_CATALOG } from '../data/disciplines';
import { soundEngine } from '../utils/soundEngine';

interface KotostArena3DProps {
  mode: GameMode;
  discipline: DisciplineId;
  accessory: AccessoryId;
  unlockedRecords: Record<DisciplineId, boolean>;
  onTelemetryUpdate: (telemetry: LiveTelemetry) => void;
  onSpawnPopup: (popup: Omit<FloatingPopup, 'id'>) => void;
  onFinishDiscipline: (finalScore: number) => void;
  externalTriggerRef: React.MutableRefObject<{
    triggerPrimaryAction: () => void;
    setHoldState: (holding: boolean) => void;
    steerHorizontal: (dir: number) => void;
    petKotost: () => void;
  } | null>;
}

interface FlyingTreat {
  mesh: THREE.Mesh;
  startPos: THREE.Vector3;
  progress: number;
  speed: number;
}

interface BurstParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
}

interface StackedObject {
  mesh: THREE.Group;
  height: number;
  radius: number;
  offsetX: number;
  yOffsetOnHead: number;
}

export const KotostArena3D: React.FC<KotostArena3DProps> = ({
  mode,
  discipline,
  accessory,
  unlockedRecords,
  onTelemetryUpdate,
  onSpawnPopup,
  onFinishDiscipline,
  externalTriggerRef,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // Keep latest props accessible inside requestAnimationFrame without recreating scene
  const stateRef = useRef({
    mode,
    discipline,
    accessory,
    unlockedRecords,
    onTelemetryUpdate,
    onSpawnPopup,
    onFinishDiscipline,
  });

  useEffect(() => {
    stateRef.current = {
      mode,
      discipline,
      accessory,
      unlockedRecords,
      onTelemetryUpdate,
      onSpawnPopup,
      onFinishDiscipline,
    };
  }, [
    mode,
    discipline,
    accessory,
    unlockedRecords,
    onTelemetryUpdate,
    onSpawnPopup,
    onFinishDiscipline,
  ]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Setup Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#131C2E');
    scene.fog = new THREE.FogExp2('#131C2E', 0.018);

    const camera = new THREE.PerspectiveCamera(
      44,
      container.clientWidth / container.clientHeight,
      0.1,
      200
    );
    camera.position.set(0, 2.3, 5.4);
    camera.lookAt(0, 1.25, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Warm Sunlit Living Room & Studio Broadcast Lighting
    const ambientLight = new THREE.AmbientLight('#FFF7ED', 1.25);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight('#E0F2FE', '#C88D54', 0.85);
    scene.add(hemiLight);

    // Main sunlit window directional light from upper right (matching the reference photo!)
    const dirLight = new THREE.DirectionalLight('#FFFBEB', 2.2);
    dirLight.position.set(5.5, 8.5, 6.0);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 28;
    const d = 5.5;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // Warm rim light from left to highlight the calico fur contour
    const rimLight = new THREE.PointLight('#F59E0B', 2.4, 14);
    rimLight.position.set(-4.0, 3.5, 2.0);
    scene.add(rimLight);

    // 3. Create Stage & Kotost 3D Model
    const stage = createStageEnvironment();
    scene.add(stage.sceneGroup);

    const kotost: KotostRig = createKotostModel();
    scene.add(kotost.root);
    kotost.setAccessory(stateRef.current.accessory);

    // 4. Dynamic Gameplay Objects & Pools
    const dynamicGroup = new THREE.Group();
    scene.add(dynamicGroup);

    // Golden Tsar-Fish for Chonk Discipline
    const goldenFishGroup = new THREE.Group();
    const fishGoldMat = new THREE.MeshStandardMaterial({
      color: '#FDE047',
      emissive: '#F59E0B',
      emissiveIntensity: 0.65,
      metalness: 0.85,
      roughness: 0.15,
    });
    const fishBody = new THREE.Mesh(new THREE.SphereGeometry(0.28, 20, 16), fishGoldMat);
    fishBody.scale.set(1.6, 0.85, 0.55);
    goldenFishGroup.add(fishBody);
    const fishTail = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.32, 12), fishGoldMat);
    fishTail.rotation.z = Math.PI / 2;
    fishTail.position.x = -0.45;
    goldenFishGroup.add(fishTail);
    goldenFishGroup.visible = false;
    dynamicGroup.add(goldenFishGroup);

    // Stack Tower Group attached to Kotost's flat head!
    const stackTowerGroup = new THREE.Group();
    kotost.headTopAnchor.add(stackTowerGroup);

    // Swinging Active Item Group for Stack Discipline
    const swingingHookGroup = new THREE.Group();
    dynamicGroup.add(swingingHookGroup);

    const flyingTreats: FlyingTreat[] = [];
    const particles: BurstParticle[] = [];

    const spawnParticles = (origin: THREE.Vector3, colorHex: string, count = 14) => {
      const geo = new THREE.OctahedronGeometry(0.08, 0);
      const mat = new THREE.MeshBasicMaterial({ color: colorHex });
      for (let i = 0; i < count; i++) {
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.copy(origin);
        const angle = Math.random() * Math.PI * 2;
        const speed = 1.5 + Math.random() * 3.5;
        const vel = new THREE.Vector3(
          Math.cos(angle) * speed,
          1.8 + Math.random() * 3.2,
          Math.sin(angle) * speed
        );
        dynamicGroup.add(mesh);
        particles.push({ mesh, vel, life: 0, maxLife: 0.45 + Math.random() * 0.25 });
      }
    };

    const spawnTreatToMouth = (isGolden = false) => {
      const colors = ['#FB7185', '#FBBF24', '#FFFBF5', '#F97316'];
      const color = isGolden ? '#FDE047' : colors[Math.floor(Math.random() * colors.length)];
      const geo = new THREE.SphereGeometry(isGolden ? 0.22 : 0.14, 14, 14);
      const mat = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.25,
        roughness: 0.3,
      });
      const mesh = new THREE.Mesh(geo, mat);
      const side = (Math.random() - 0.5) * 3.8;
      const startPos = new THREE.Vector3(side, 0.8 + Math.random() * 2.2, 3.4);
      mesh.position.copy(startPos);
      dynamicGroup.add(mesh);
      flyingTreats.push({ mesh, startPos, progress: 0, speed: 4.8 });
    };

    // ==========================================
    // GAME SIMULATION STATE
    // ==========================================
    let sim = {
      prevMode: '' as string,
      prevDiscipline: '' as string,
      // Orbit & pointer state
      pointerNDC: new THREE.Vector2(0, 0),
      orbitYaw: 0,
      isDraggingOrbit: false,
      dragStartX: 0,
      // Spring squash & stretch for Kotost
      squashY: 1.0,
      squashVel: 0,
      chonkScale: 1.0,
      mouthOpenTimer: 0,
      blinkTimer: 2.2,
      isBlinking: false,
      cameraShake: 0,
      finishedSent: false,

      // 1. CHONK SPRINT STATE
      chonkScore: 18.0, // Starts at 18 КГ-Шар, target 150 КГ-Шар
      chonkTimeLeft: 15.0,
      chonkCombo: 0,
      chonkLastClickTime: 0,
      fishActive: false,
      fishTimer: 1.8,
      fishAngle: 0,

      // 2. MEGA-JUMP STATE
      jumpPhase: 'charge' as 'charge' | 'flight' | 'landed',
      jumpGauge: 0,
      jumpGaugeDir: 1,
      jumpIsHolding: false,
      jumpAutoReleaseTimer: 9.0,
      catY: 0,
      catX: 0,
      catVY: 0,
      catVX: 0,
      maxHeightMeters: 0,
      steerInput: 0, // -1..1

      // 3. ZEN HEAD-STACK STATE
      stackedItems: [] as StackedObject[],
      currentStackHeightY: 0,
      swingItemObj: null as ReturnType<typeof createStackItemMesh> | null,
      swingDropInProgress: false,
      swingX: 0,
      swingY: 1.4,
      swingPhase: 0,
      towerTiltAngle: 0,
      towerTiltVel: 0,
      stackLives: 3,
      stackScore: 0,
    };

    const setupNextSwingItem = (index: number) => {
      // Clear previous hook children
      while (swingingHookGroup.children.length > 0) {
        swingingHookGroup.remove(swingingHookGroup.children[0]);
      }
      const itemObj = createStackItemMesh(index);
      swingingHookGroup.add(itemObj.mesh);
      sim.swingItemObj = itemObj;
      sim.swingDropInProgress = false;
      sim.swingY = 2.65 + sim.currentStackHeightY + 1.15;
    };

    const resetDisciplineSimulation = (disc: DisciplineId) => {
      sim.finishedSent = false;
      sim.squashY = 1.0;
      sim.squashVel = 0;
      sim.chonkScale = 1.0;
      sim.catX = 0;
      sim.catY = 0;
      sim.catVX = 0;
      sim.catVY = 0;
      kotost.root.position.set(0, 0, 0);
      kotost.root.rotation.set(0, 0, 0);
      goldenFishGroup.visible = false;
      swingingHookGroup.visible = false;

      // Clear stacked items
      while (stackTowerGroup.children.length > 0) {
        stackTowerGroup.remove(stackTowerGroup.children[0]);
      }
      sim.stackedItems = [];
      sim.currentStackHeightY = 0;
      sim.towerTiltAngle = 0;
      sim.towerTiltVel = 0;

      if (disc === 'chonk') {
        sim.chonkScore = 18.0;
        sim.chonkTimeLeft = 15.0;
        sim.chonkCombo = 0;
        sim.fishActive = false;
        sim.fishTimer = 2.0;
      } else if (disc === 'jump') {
        sim.jumpPhase = 'charge';
        sim.jumpGauge = 0.15;
        sim.jumpGaugeDir = 1;
        sim.jumpIsHolding = false;
        sim.jumpAutoReleaseTimer = 10.0;
        sim.maxHeightMeters = 0;
        // Reset clouds visibility
        stage.jumpClouds.forEach((c) => {
          c.visible = true;
          c.scale.setScalar(1);
          if (!c.userData.isGoldenBooster) c.scale.set(1.45, 0.55, 1.1);
        });
      } else if (disc === 'stack') {
        sim.stackLives = 3;
        sim.stackScore = 0;
        sim.swingPhase = 0;
        swingingHookGroup.visible = true;
        setupNextSwingItem(0);
      }
    };

    // ==========================================
    // PLAYER ACTIONS (Shared by Mouse, Keyboard, and UI Buttons)
    // ==========================================
    const handleChonkFeed = (isGoldenFishBonus = false) => {
      if (stateRef.current.mode !== 'playing' || stateRef.current.discipline !== 'chonk') return;
      if (sim.finishedSent) return;

      const now = performance.now();
      if (now - sim.chonkLastClickTime < 550) {
        sim.chonkCombo = Math.min(sim.chonkCombo + 1, 25);
      } else {
        sim.chonkCombo = 1;
      }
      sim.chonkLastClickTime = now;

      const gain = isGoldenFishBonus
        ? 22.5
        : Number((4.4 + Math.min(sim.chonkCombo * 0.32, 4.2)).toFixed(1));
      sim.chonkScore = Number((sim.chonkScore + gain).toFixed(1));

      // Elastic squash & mouth open
      sim.squashVel += isGoldenFishBonus ? -5.5 : -2.6;
      sim.mouthOpenTimer = 0.16;
      sim.cameraShake = isGoldenFishBonus ? 0.18 : 0.045;

      spawnTreatToMouth(isGoldenFishBonus);
      spawnParticles(
        new THREE.Vector3(0, 1.6, 1.3),
        isGoldenFishBonus ? '#FDE047' : '#F59E0B',
        isGoldenFishBonus ? 24 : 8
      );

      if (isGoldenFishBonus) {
        soundEngine.playGoldenBonus();
        stateRef.current.onSpawnPopup({
          text: `+${gain} КГ-ШАР!`,
          subtext: '🐟 ЗОЛОТАЯ ЦАРЬ-РЫБА СЪЕДЕНА!',
          x: 50,
          y: 34,
          color: 'gold',
        });
      } else {
        soundEngine.playChomp(sim.chonkCombo);
        if (sim.chonkCombo % 3 === 0 || gain > 6) {
          const phrases = ['ХРУМ-КУСЬ!', 'ПУХЛОСТЬ РАСТЁТ!', 'МЕГА-ЩЁЧКИ!', 'ИДЕАЛЬНЫЙ ШАР!'];
          stateRef.current.onSpawnPopup({
            text: `+${gain} КГ-Шар`,
            subtext: phrases[sim.chonkCombo % phrases.length],
            x: 34 + Math.random() * 32,
            y: 36 + Math.random() * 20,
            color: sim.chonkScore >= 150 ? 'emerald' : 'gold',
          });
        }
      }
    };

    const launchJump = () => {
      if (
        stateRef.current.mode !== 'playing' ||
        stateRef.current.discipline !== 'jump' ||
        sim.jumpPhase !== 'charge'
      )
        return;

      sim.jumpPhase = 'flight';
      sim.jumpIsHolding = false;

      // Calculate launch power from sweet spot (ideal is 0.78..1.0)
      const g = sim.jumpGauge;
      const isSweetSpot = g >= 0.78;
      const powerFactor = isSweetSpot ? 1.18 + (g - 0.78) * 0.9 : 0.65 + g * 0.55;

      sim.catVY = 19.5 * powerFactor;
      sim.squashY = 1.48;
      sim.squashVel = 4.2;
      sim.cameraShake = 0.22;

      soundEngine.playBoing(powerFactor);
      spawnParticles(new THREE.Vector3(0, 0.5, 0), isSweetSpot ? '#10B981' : '#F59E0B', 26);

      stateRef.current.onSpawnPopup({
        text: isSweetSpot ? 'ИДЕАЛЬНЫЙ ТЫГЫДЫК-СТАРТ!' : 'СТАРТ В НЕБО!',
        subtext: 'Рулите влево/вправо (A/D или курсор) по облакам!',
        x: 50,
        y: 42,
        color: isSweetSpot ? 'emerald' : 'gold',
      });
    };

    const dropStackItem = () => {
      if (
        stateRef.current.mode !== 'playing' ||
        stateRef.current.discipline !== 'stack' ||
        sim.swingDropInProgress ||
        !sim.swingItemObj ||
        sim.finishedSent
      )
        return;

      sim.swingDropInProgress = true;
    };

    const petKotostInHub = () => {
      sim.squashVel = -3.6;
      sim.mouthOpenTimer = 0.25;
      soundEngine.playMeow(0.92 + Math.random() * 0.22);
      spawnParticles(new THREE.Vector3(0, 1.9, 1.1), '#FDE047', 16);

      const hubPhrases = [
        { t: 'МЯУ-СФЕРИЧНОСТЬ 100%!', s: 'Индекс круглости в норме' },
        { t: 'ПОГЛАЖЕНО ОФИЦИАЛЬНО!', s: 'Пушистость подтверждена комиссией' },
        { t: 'ГДЕ МОЙ ПАШТЕТ?', s: 'Готов к мировому рекорду!' },
        { t: 'ШОКИРОВАННЫЙ ВЗГЛЯД 👀', s: 'Зрачки расширены на максимум' },
      ];
      const pick = hubPhrases[Math.floor(Math.random() * hubPhrases.length)];
      stateRef.current.onSpawnPopup({
        text: pick.t,
        subtext: pick.s,
        x: 42 + Math.random() * 16,
        y: 32 + Math.random() * 12,
        color: 'gold',
      });
    };

    const triggerPrimaryAction = () => {
      const { mode: curMode, discipline: curDisc } = stateRef.current;
      if (curMode === 'hub') {
        petKotostInHub();
        return;
      }
      if (curMode !== 'playing') return;

      if (curDisc === 'chonk') {
        handleChonkFeed(false);
      } else if (curDisc === 'jump') {
        if (sim.jumpPhase === 'charge') {
          if (!sim.jumpIsHolding) {
            sim.jumpIsHolding = true;
          } else {
            launchJump();
          }
        }
      } else if (curDisc === 'stack') {
        dropStackItem();
      }
    };

    const setHoldState = (holding: boolean) => {
      const { mode: curMode, discipline: curDisc } = stateRef.current;
      if (curMode !== 'playing') return;
      if (curDisc === 'jump' && sim.jumpPhase === 'charge') {
        if (holding) {
          sim.jumpIsHolding = true;
        } else if (sim.jumpIsHolding) {
          launchJump();
        }
      }
    };

    const steerHorizontal = (dir: number) => {
      sim.steerInput = dir;
      if (
        stateRef.current.mode === 'playing' &&
        stateRef.current.discipline === 'stack' &&
        dir !== 0
      ) {
        // Nudge tower balance toward center!
        sim.towerTiltVel -= dir * 0.42;
      }
    };

    externalTriggerRef.current = {
      triggerPrimaryAction,
      setHoldState,
      steerHorizontal,
      petKotost: petKotostInHub,
    };

    // ==========================================
    // POINTER & KEYBOARD LISTENERS
    // ==========================================
    const raycaster = new THREE.Raycaster();

    const onPointerDown = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      sim.pointerNDC.set(nx, ny);

      const { mode: curMode, discipline: curDisc } = stateRef.current;

      if (curMode === 'hub') {
        sim.isDraggingOrbit = true;
        sim.dragStartX = e.clientX;
        raycaster.setFromCamera(sim.pointerNDC, camera);
        const hits = raycaster.intersectObject(kotost.bodyMesh, true);
        if (hits.length > 0) {
          petKotostInHub();
        }
        return;
      }

      if (curMode === 'playing') {
        if (curDisc === 'chonk') {
          // Check if player clicked on the flying Golden Tsar-Fish!
          if (sim.fishActive && goldenFishGroup.visible) {
            raycaster.setFromCamera(sim.pointerNDC, camera);
            const fishHits = raycaster.intersectObjects(goldenFishGroup.children, true);
            if (fishHits.length > 0 || goldenFishGroup.position.distanceTo(new THREE.Vector3(nx * 2.2, 1.8, 1.5)) < 1.35) {
              sim.fishActive = false;
              goldenFishGroup.visible = false;
              sim.fishTimer = 2.4;
              handleChonkFeed(true);
              return;
            }
          }
          handleChonkFeed(false);
        } else if (curDisc === 'jump') {
          if (sim.jumpPhase === 'charge') {
            sim.jumpIsHolding = true;
          }
        } else if (curDisc === 'stack') {
          dropStackItem();
        }
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      sim.pointerNDC.set(nx, ny);

      if (stateRef.current.mode === 'hub' && sim.isDraggingOrbit) {
        const dx = e.clientX - sim.dragStartX;
        sim.dragStartX = e.clientX;
        sim.orbitYaw += dx * 0.008;
      }
    };

    const onPointerUp = () => {
      sim.isDraggingOrbit = false;
      if (
        stateRef.current.mode === 'playing' &&
        stateRef.current.discipline === 'jump' &&
        sim.jumpPhase === 'charge' &&
        sim.jumpIsHolding
      ) {
        launchJump();
      }
    };

    const keysDown = new Set<string>();
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        const { mode: curMode, discipline: curDisc } = stateRef.current;
        if (curMode === 'playing') {
          if (curDisc === 'chonk' && !e.repeat) {
            // If golden fish is right near center, spacebar also catches it!
            if (sim.fishActive && Math.abs(goldenFishGroup.position.x) < 1.1) {
              sim.fishActive = false;
              goldenFishGroup.visible = false;
              sim.fishTimer = 2.5;
              handleChonkFeed(true);
            } else {
              handleChonkFeed(false);
            }
          } else if (curDisc === 'jump' && sim.jumpPhase === 'charge') {
            sim.jumpIsHolding = true;
          } else if (curDisc === 'stack' && !e.repeat) {
            dropStackItem();
          }
        } else if (curMode === 'hub' && !e.repeat) {
          petKotostInHub();
        }
      }
      keysDown.add(e.code);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysDown.delete(e.code);
      if (e.code === 'Space') {
        if (
          stateRef.current.mode === 'playing' &&
          stateRef.current.discipline === 'jump' &&
          sim.jumpPhase === 'charge' &&
          sim.jumpIsHolding
        ) {
          launchJump();
        }
      }
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    // ==========================================
    // MAIN 60FPS ANIMATION & PHYSICS LOOP
    // ==========================================
    let animId = 0;
    let lastTime = performance.now();
    let telemetryTimer = 0;

    const animate = (now: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;
      const elapsed = now * 0.001;

      const { mode: curMode, discipline: curDisc, accessory: curAcc, unlockedRecords: curUnlocked } =
        stateRef.current;

      // Sync accessory & trophies
      kotost.setAccessory(curAcc);
      stage.updateTrophies(curUnlocked, elapsed);
      stage.skyTowerGroup.visible = curDisc === 'jump' && (curMode === 'playing' || curMode === 'countdown');

      // Detect mode or discipline change
      if (sim.prevMode !== curMode || sim.prevDiscipline !== curDisc) {
        if (curMode === 'countdown' || (curMode === 'playing' && sim.prevMode !== 'countdown')) {
          resetDisciplineSimulation(curDisc);
        } else if (curMode === 'hub') {
          resetDisciplineSimulation(curDisc);
        }
        sim.prevMode = curMode;
        sim.prevDiscipline = curDisc;
      }

      // Keyboard horizontal steering check
      let kbSteer = 0;
      if (keysDown.has('KeyA') || keysDown.has('ArrowLeft')) kbSteer -= 1;
      if (keysDown.has('KeyD') || keysDown.has('ArrowRight')) kbSteer += 1;
      const activeSteer = kbSteer !== 0 ? kbSteer : sim.steerInput;

      // ==========================================
      // KOTOST IDLE BREATHING, BLINKING & EYE TRACKING
      // ==========================================
      sim.blinkTimer -= dt;
      if (sim.blinkTimer <= 0) {
        if (!sim.isBlinking) {
          sim.isBlinking = true;
          sim.blinkTimer = 0.11;
        } else {
          sim.isBlinking = false;
          sim.blinkTimer = 2.4 + Math.random() * 2.5;
        }
      }
      const lidScaleY = sim.isBlinking ? 1.0 : 0.001;
      kotost.leftEyelid.scale.y = THREE.MathUtils.lerp(kotost.leftEyelid.scale.y, lidScaleY, 0.45);
      kotost.rightEyelid.scale.y = THREE.MathUtils.lerp(kotost.rightEyelid.scale.y, lidScaleY, 0.45);

      // Eye pupil tracking: look up at stacked items in 'stack', or track cursor in 'hub'/'chonk'
      let targetEyeX = sim.pointerNDC.x * 0.042;
      let targetEyeY = sim.pointerNDC.y * 0.038 + 0.015;
      if (curMode === 'playing' && curDisc === 'stack') {
        targetEyeX = sim.swingX * 0.03;
        targetEyeY = 0.055; // Stare intently upward at the swinging item!
      } else if (curMode === 'playing' && curDisc === 'chonk' && sim.fishActive) {
        targetEyeX = goldenFishGroup.position.x * 0.028;
        targetEyeY = 0.035;
      }
      kotost.leftPupil.position.x = THREE.MathUtils.lerp(kotost.leftPupil.position.x, targetEyeX, 0.2);
      kotost.leftPupil.position.y = THREE.MathUtils.lerp(kotost.leftPupil.position.y, targetEyeY, 0.2);
      kotost.rightPupil.position.x = THREE.MathUtils.lerp(kotost.rightPupil.position.x, targetEyeX, 0.2);
      kotost.rightPupil.position.y = THREE.MathUtils.lerp(kotost.rightPupil.position.y, targetEyeY, 0.2);

      // Mouth open animation
      if (sim.mouthOpenTimer > 0) {
        sim.mouthOpenTimer -= dt;
        kotost.mouthMesh.scale.set(1.45, 1.35, 0.8);
      } else {
        kotost.mouthMesh.scale.lerp(new THREE.Vector3(1.2, 0.22, 0.4), 0.25);
      }

      // Tail gentle wag
      kotost.tailGroup.rotation.z = Math.sin(elapsed * 4.2) * 0.18;

      // Spring Squash-and-Stretch Physics
      const springK = 140;
      const damping = 11;
      const springForce = (1.0 - sim.squashY) * springK;
      sim.squashVel += springForce * dt;
      sim.squashVel *= Math.exp(-damping * dt);
      sim.squashY += sim.squashVel * dt;
      sim.squashY = THREE.MathUtils.clamp(sim.squashY, 0.44, 1.55);

      const breathe = 1.0 + Math.sin(elapsed * 3.2) * 0.016;
      const sy = sim.squashY * breathe;
      const sxz = (1.0 / Math.sqrt(sy)) * sim.chonkScale;

      kotost.bodyGroup.scale.set(sxz, sy * (1.0 + (sim.chonkScale - 1.0) * 0.65), sxz);
      kotost.leftPaw.position.x = -0.48 * sxz;
      kotost.rightPaw.position.x = 0.48 * sxz;
      kotost.leftPaw.position.z = 1.05 * sxz;
      kotost.rightPaw.position.z = 1.05 * sxz;

      // ==========================================
      // DISCIPLINE-SPECIFIC GAMEPLAY LOGIC
      // ==========================================
      let camTargetPos = new THREE.Vector3(0, 2.2, 5.2);
      let camLookTarget = new THREE.Vector3(0, 1.25, 0);

      if (curMode === 'hub' || curMode === 'result') {
        const yaw = sim.orbitYaw + Math.sin(elapsed * 0.45) * 0.12;
        camTargetPos.set(Math.sin(yaw) * 5.2, 2.15, Math.cos(yaw) * 5.2);
        camLookTarget.set(0, 1.25, 0);
        kotost.root.rotation.y = THREE.MathUtils.lerp(kotost.root.rotation.y, 0, 0.1);
      } else if (curDisc === 'chonk') {
        // DISCIPLINE 1: CHONK SPRINT
        const targetScale = 1.0 + Math.max(0, (sim.chonkScore - 18) / 145) * 0.85;
        sim.chonkScale = THREE.MathUtils.lerp(sim.chonkScale, targetScale, 0.12);

        const zoomOut = (sim.chonkScale - 1.0) * 2.1;
        camTargetPos.set(0, 2.25 + zoomOut * 0.35, 5.0 + zoomOut);
        camLookTarget.set(0, 1.3 + zoomOut * 0.25, 0);

        if (curMode === 'playing' && !sim.finishedSent) {
          sim.chonkTimeLeft = Math.max(0, sim.chonkTimeLeft - dt);

          // Golden Tsar-Fish Spawner
          if (!sim.fishActive) {
            sim.fishTimer -= dt;
            if (sim.fishTimer <= 0 && sim.chonkTimeLeft > 1.2) {
              sim.fishActive = true;
              sim.fishAngle = -1.6;
              goldenFishGroup.visible = true;
            }
          } else {
            sim.fishAngle += dt * 1.45;
            goldenFishGroup.position.set(
              Math.sin(sim.fishAngle) * 2.4,
              1.95 + Math.cos(sim.fishAngle * 2.2) * 0.45,
              1.65
            );
            goldenFishGroup.rotation.z = Math.cos(sim.fishAngle * 2.2) * 0.25;
            if (sim.fishAngle > 1.6) {
              sim.fishActive = false;
              goldenFishGroup.visible = false;
              sim.fishTimer = 1.8;
            }
          }

          if (sim.chonkTimeLeft <= 0) {
            sim.finishedSent = true;
            goldenFishGroup.visible = false;
            stateRef.current.onFinishDiscipline(Number(sim.chonkScore.toFixed(1)));
          }
        }
      } else if (curDisc === 'jump') {
        // DISCIPLINE 2: MEGA-JUMP TYGYDYK
        if (curMode === 'playing' && !sim.finishedSent) {
          if (sim.jumpPhase === 'charge') {
            // Oscillate power gauge rapidly when holding, or at medium speed so button-tappers can also time it!
            const oscSpeed = sim.jumpIsHolding ? 1.85 : 1.15;
            sim.jumpGauge += sim.jumpGaugeDir * dt * oscSpeed;
            if (sim.jumpGauge >= 1.0) {
              sim.jumpGauge = 1.0;
              sim.jumpGaugeDir = -1;
            } else if (sim.jumpGauge <= 0.08) {
              sim.jumpGauge = 0.08;
              sim.jumpGaugeDir = 1;
            }

            // Compress Kotost like a hydraulic spring according to gauge
            const compress = sim.jumpIsHolding ? 0.48 : 0.85 - sim.jumpGauge * 0.22;
            sim.squashY = THREE.MathUtils.lerp(sim.squashY, compress, 0.25);

            sim.jumpAutoReleaseTimer -= dt;
            if (sim.jumpAutoReleaseTimer <= 0) {
              launchJump();
            }

            camTargetPos.set(0, 1.9, 4.7);
            camLookTarget.set(0, 1.1, 0);
          } else if (sim.jumpPhase === 'flight') {
            // Horizontal steering via keyboard, on-screen buttons, or cursor X
            const pointerSteer = Math.abs(sim.pointerNDC.x) > 0.08 ? sim.pointerNDC.x * 1.25 : 0;
            const desiredX =
              activeSteer !== 0
                ? sim.catX + activeSteer * 7.5 * dt
                : THREE.MathUtils.lerp(sim.catX, pointerSteer * 2.4, 0.08);

            sim.catX = THREE.MathUtils.clamp(desiredX, -2.6, 2.6);
            kotost.root.rotation.z = (sim.catX - desiredX) * 2.5;

            // Vertical physics
            const gravity = 14.8;
            sim.catVY -= gravity * dt;
            sim.catY += sim.catVY * dt;

            // Convert 3D Y to Guinness Meters (1m = 0.55 units)
            const currentMeters = Math.max(0, sim.catY / 0.55);
            if (currentMeters > sim.maxHeightMeters) {
              sim.maxHeightMeters = currentMeters;
            }

            // Check collisions with Bouncy Clouds & Golden Yarn Boosters when moving downward or near cloud
            stage.jumpClouds.forEach((cloud) => {
              if (!cloud.visible) return;
              // Gentle cloud motion
              cloud.position.x =
                cloud.userData.baseX + Math.sin(elapsed * 1.4 + cloud.userData.phase) * 0.55;

              const dy = Math.abs(sim.catY + 0.5 - cloud.position.y);
              const dx = Math.abs(sim.catX - cloud.position.x);
              const isGold = cloud.userData.isGoldenBooster;

              if (dy < 0.72 && dx < 1.12 && (sim.catVY < 8.5 || isGold)) {
                cloud.visible = false;
                const boostVel = isGold ? 21.5 : 15.8;
                sim.catVY = Math.max(sim.catVY + 6.5, boostVel);
                sim.squashY = 0.58;
                sim.squashVel = 5.0;
                sim.cameraShake = isGold ? 0.2 : 0.1;

                soundEngine.playBoing(isGold ? 1.5 : 1.0);
                spawnParticles(
                  new THREE.Vector3(sim.catX, sim.catY + 0.5, 0),
                  isGold ? '#FDE047' : '#38BDF8',
                  18
                );

                stateRef.current.onSpawnPopup({
                  text: isGold ? '🌟 ЗОЛОТОЙ ТУРБО-КЛУБОК!' : '☁️ ОТСКОК ОТ ОБЛАКА!',
                  subtext: `Высота: ${Math.round(sim.maxHeightMeters)} Метров`,
                  x: 50,
                  y: 45,
                  color: isGold ? 'gold' : 'emerald',
                });
              }
            });

            kotost.root.position.set(sim.catX, Math.max(0, sim.catY), 0);

            // Dynamic sky color transition as altitude rises into stratosphere!
            const skyFactor = THREE.MathUtils.clamp(currentMeters / 55, 0, 1);
            const lowColor = new THREE.Color('#131C2E');
            const highColor = new THREE.Color('#060B19');
            scene.background = lowColor.lerp(highColor, skyFactor);

            camTargetPos.set(sim.catX * 0.35, Math.max(2.2, sim.catY + 2.0), 6.2);
            camLookTarget.set(sim.catX * 0.5, Math.max(1.25, sim.catY + 1.1), 0);

            // End flight once falling significantly below peak or hitting ground
            if (
              (sim.catVY < -13.5 && sim.maxHeightMeters > 8) ||
              (sim.catY <= 0 && sim.catVY < 0)
            ) {
              sim.jumpPhase = 'landed';
              sim.catY = 0;
              kotost.root.position.set(0, 0, 0);
              kotost.root.rotation.set(0, 0, 0);
              sim.finishedSent = true;
              stateRef.current.onFinishDiscipline(Number(sim.maxHeightMeters.toFixed(1)));
            }
          }
        } else {
          camTargetPos.set(0, 1.9, 4.8);
          camLookTarget.set(0, 1.15, 0);
        }
      } else if (curDisc === 'stack') {
        // DISCIPLINE 3: ZEN HEAD-STACKING
        const viewHeight = Math.min(sim.currentStackHeightY * 0.85, 5.5);
        camTargetPos.set(0, 2.35 + viewHeight, 4.4 + viewHeight * 0.45);
        camLookTarget.set(0, 1.95 + viewHeight * 0.88, 0);

        if (curMode === 'playing' && !sim.finishedSent) {
          // Swing active item horizontally above tower
          if (!sim.swingDropInProgress) {
            const speed = 1.95 + Math.min(sim.stackScore * 0.14, 1.8);
            sim.swingPhase += dt * speed;
            sim.swingX = Math.sin(sim.swingPhase) * 1.18;
            const targetTopY = 2.34 + sim.currentStackHeightY + 0.95;
            sim.swingY = THREE.MathUtils.lerp(sim.swingY, targetTopY, 0.2);
            swingingHookGroup.position.set(sim.swingX, sim.swingY, 0.22);
          } else if (sim.swingItemObj) {
            // Item is dropping down toward the top of the stack!
            sim.swingY -= 11.5 * dt;
            swingingHookGroup.position.set(sim.swingX, sim.swingY, 0.22);

            const landY = 2.34 + sim.currentStackHeightY + sim.swingItemObj.height * 0.5;
            if (sim.swingY <= landY) {
              // Check landing alignment relative to previous item (or head center)
              const prevOffset =
                sim.stackedItems.length > 0
                  ? sim.stackedItems[sim.stackedItems.length - 1].offsetX
                  : 0;
              const deltaX = sim.swingX - prevOffset - Math.sin(sim.towerTiltAngle) * 0.35;
              const absDelta = Math.abs(deltaX);

              if (absDelta < 0.54) {
                // SUCCESSFUL LANDING!
                const isPerfect = absDelta < 0.13;
                const finalOffsetX = isPerfect ? prevOffset : prevOffset + deltaX * 0.68;

                // Detach mesh from hook and attach to Kotost's head stack!
                const landedMesh = sim.swingItemObj.mesh;
                swingingHookGroup.remove(landedMesh);
                landedMesh.position.set(
                  finalOffsetX,
                  sim.currentStackHeightY + sim.swingItemObj.height * 0.5,
                  0
                );
                stackTowerGroup.add(landedMesh);

                sim.stackedItems.push({
                  mesh: landedMesh,
                  height: sim.swingItemObj.height,
                  radius: sim.swingItemObj.radius,
                  offsetX: finalOffsetX,
                  yOffsetOnHead: sim.currentStackHeightY,
                });

                sim.currentStackHeightY += sim.swingItemObj.height;
                sim.stackScore += 1;

                // Squish Kotost's head slightly under the added weight!
                sim.squashVel -= 2.4;
                sim.cameraShake = isPerfect ? 0.08 : 0.04;

                // Apply slight tilt impulse if off-center, or stabilize if perfect!
                if (isPerfect) {
                  sim.towerTiltVel *= 0.4;
                  sim.towerTiltAngle *= 0.65;
                } else {
                  sim.towerTiltVel += deltaX * 0.55;
                }

                soundEngine.playStackLand(sim.stackScore, isPerfect);
                spawnParticles(
                  new THREE.Vector3(finalOffsetX, 2.34 + sim.currentStackHeightY, 0.3),
                  isPerfect ? '#10B981' : '#FDE047',
                  isPerfect ? 20 : 10
                );

                stateRef.current.onSpawnPopup({
                  text: isPerfect
                    ? `✨ ИДЕАЛЬНЫЙ ЦЕНТР! (${sim.stackScore})`
                    : `БАЛАНС УДЕРЖАН! (${sim.stackScore})`,
                  subtext: sim.swingItemObj.name,
                  x: 50,
                  y: 35,
                  color: isPerfect ? 'emerald' : 'gold',
                });

                // Prepare next item
                setupNextSwingItem(sim.stackScore);
              } else {
                // MISSED THE TOWER!
                sim.stackLives -= 1;
                sim.cameraShake = 0.22;
                soundEngine.playMeow(0.75);
                spawnParticles(new THREE.Vector3(sim.swingX, landY, 0.3), '#E11D48', 16);

                stateRef.current.onSpawnPopup({
                  text: 'МИМО МАКУШКИ!',
                  subtext:
                    sim.stackLives > 0
                      ? `Осталось попыток сброса: ${sim.stackLives}`
                      : 'Башня зафиксирована судьями!',
                  x: 50,
                  y: 42,
                  color: 'crimson',
                });

                if (sim.stackLives <= 0) {
                  sim.finishedSent = true;
                  swingingHookGroup.visible = false;
                  stateRef.current.onFinishDiscipline(sim.stackScore);
                } else {
                  setupNextSwingItem(sim.stackScore);
                }
              }
            }
          }

          // Tower tilt physics & player counter-balancing
          if (sim.stackedItems.length > 0) {
            const avgOffset =
              sim.stackedItems.reduce((acc, it) => acc + it.offsetX, 0) /
              sim.stackedItems.length;
            // Gravity torque from off-center mass + gentle restorative spring from Kotost's neckless stability!
            sim.towerTiltVel += avgOffset * 0.45 * dt - sim.towerTiltAngle * 1.8 * dt;
            // Player active balance via A/D or Arrow keys
            if (activeSteer !== 0) {
              sim.towerTiltVel -= activeSteer * 2.2 * dt;
            }
            sim.towerTiltVel *= 0.94;
            sim.towerTiltAngle += sim.towerTiltVel * dt;
            sim.towerTiltAngle = THREE.MathUtils.clamp(sim.towerTiltAngle, -0.48, 0.48);

            stackTowerGroup.rotation.z = -sim.towerTiltAngle;
            kotost.bodyGroup.rotation.z = -sim.towerTiltAngle * 0.25;
          }
        }
      }

      // ==========================================
      // UPDATE FLYING TREATS & PARTICLES
      // ==========================================
      for (let i = flyingTreats.length - 1; i >= 0; i--) {
        const ft = flyingTreats[i];
        ft.progress += dt * ft.speed;
        const mouthTarget = new THREE.Vector3(0, 1.55 * sim.chonkScale, 1.15 * sim.chonkScale);
        ft.mesh.position.lerpVectors(ft.startPos, mouthTarget, Math.min(1, ft.progress));
        ft.mesh.position.y += Math.sin(ft.progress * Math.PI) * 0.65;
        if (ft.progress >= 1) {
          dynamicGroup.remove(ft.mesh);
          flyingTreats.splice(i, 1);
        }
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life += dt;
        p.vel.y -= 7.5 * dt;
        p.mesh.position.addScaledVector(p.vel, dt);
        p.mesh.rotation.x += 6 * dt;
        p.mesh.rotation.y += 6 * dt;
        const s = Math.max(0.001, 1.0 - p.life / p.maxLife);
        p.mesh.scale.setScalar(s);
        if (p.life >= p.maxLife) {
          dynamicGroup.remove(p.mesh);
          particles.splice(i, 1);
        }
      }

      // Smooth Camera Tracking + Shake
      camera.position.lerp(camTargetPos, 0.14);
      if (sim.cameraShake > 0.002) {
        camera.position.x += (Math.random() - 0.5) * sim.cameraShake;
        camera.position.y += (Math.random() - 0.5) * sim.cameraShake;
        sim.cameraShake *= 0.85;
      }
      camera.lookAt(camLookTarget);

      renderer.render(scene, camera);

      // ==========================================
      // EMIT LIVE TELEMETRY TO REACT HUD (~20Hz)
      // ==========================================
      telemetryTimer += dt;
      if (telemetryTimer >= 0.05) {
        telemetryTimer = 0;
        if (curDisc === 'chonk') {
          stateRef.current.onTelemetryUpdate({
            currentScore: Number(sim.chonkScore.toFixed(1)),
            targetScore: 150,
            timeLeft: Number(sim.chonkTimeLeft.toFixed(1)),
            combo: sim.chonkCombo,
            phaseText:
              sim.chonkScore >= 150
                ? '🏆 МИРОВОЙ РЕКОРД ПОБИТ! ПРОДОЛЖАЙТЕ КОРМИТЬ!'
                : 'КОРМИТЕ КОТОСТЬ НА СКОРОСТЬ!',
            subStatusText: sim.fishActive
              ? '🐟 ЗОЛОТАЯ ЦАРЬ-РЫБА НА ЭКРАНЕ! КЛИКНИТЕ ПО НЕЙ (+22.5 КГ)!'
              : 'Кликайте по Котости или жмите ПРОБЕЛ!',
          });
        } else if (curDisc === 'jump') {
          stateRef.current.onTelemetryUpdate({
            currentScore: Number(sim.maxHeightMeters.toFixed(1)),
            targetScore: 45,
            timeLeft: -1,
            combo: 0,
            powerGauge: sim.jumpGauge,
            jumpPhase: sim.jumpPhase,
            phaseText:
              sim.jumpPhase === 'charge'
                ? 'ЗАРЯДИТЕ ПРУЖИНУ И ОТПУСТИТЕ В ЗЕЛЁНОЙ ЗОНЕ!'
                : 'В ПОЛЁТЕ! ЛОВИТЕ ОБЛАКА И ЗОЛОТЫЕ КЛУБКИ!',
            subStatusText:
              sim.jumpPhase === 'charge'
                ? 'Зажмите и отпустите ПРОБЕЛ / Кнопку на пике шкалы!'
                : 'Подруливайте влево/вправо (A/D, Стрелки или Курсор)',
          });
        } else if (curDisc === 'stack') {
          const nextSpec =
            STACK_ITEMS_CATALOG[sim.stackScore % STACK_ITEMS_CATALOG.length];
          stateRef.current.onTelemetryUpdate({
            currentScore: sim.stackScore,
            targetScore: 12,
            timeLeft: -1,
            combo: sim.stackScore,
            towerTilt: sim.towerTiltAngle / 0.48,
            nextItemName: nextSpec.name,
            livesLeft: sim.stackLives,
            phaseText:
              sim.stackScore >= 12
                ? '🏆 РЕКОРД ГИННЕССА ПОБИТ! СТРОЙТЕ ЕЩЁ ВЫШЕ!'
                : 'СБРАСЫВАЙТЕ ПРЕДМЕТЫ ТОЧНО НА МАКУШКУ!',
            subStatusText: `Следующий предмет: ${nextSpec.name}`,
          });
        }
      }
    };

    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      domElem.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, [externalTriggerRef]);

  return (
    <div
      ref={mountRef}
      className="fixed inset-0 w-screen h-screen z-0 cursor-pointer touch-none"
      title="Интерактивная 3D сцена Котости"
    />
  );
};
