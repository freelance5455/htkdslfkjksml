import React, { useState } from 'react';
import {
  ArrowRight,
  Barcode,
  Package,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Calendar,
  Layers,
  ShoppingBag,
  ShoppingCart,
  Edit3,
  Check,
  X,
  Plus,
  Clock,
  Sparkles,
} from 'lucide-react';
import type { MedicineStock, PurchaseItem, SaleItem, MedicineItem } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic } from '../utils/calculations.ts';

interface MedicineDetailsScreenProps {
  stock: MedicineStock;
  medicineItem?: MedicineItem;
  purchases: PurchaseItem[];
  sales: SaleItem[];
  onBack: () => void;
  onUpdateMedicine: (updated: {
    barcode: string;
    name: string;
    scientificName?: string;
    unit: string;
    minStockAlert: number;
  }) => void;
  onQuickPurchase: (barcode: string) => void;
  onQuickSale: (barcode: string) => void;
}

export const MedicineDetailsScreen: React.FC<MedicineDetailsScreenProps> = ({
  stock,
  medicineItem,
  purchases,
  sales,
  onBack,
  onUpdateMedicine,
  onQuickPurchase,
  onQuickSale,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'batches' | 'purchases' | 'sales'>('batches');

  // Edit form state
  const [editName, setEditName] = useState(medicineItem?.name || stock.name);
  const [editScientific, setEditScientific] = useState(medicineItem?.scientificName || '');
  const [editUnit, setEditUnit] = useState(medicineItem?.unit || 'باكيت');
  const [editMinStock, setEditMinStock] = useState(stock.minStockAlert.toString());

  // Filter purchases & sales for this specific medicine
  const medicinePurchases = purchases
    .filter((p) => p.barcode.trim() === stock.barcode.trim())
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt);

  const medicineSales = sales
    .filter((s) => s.barcode.trim() === stock.barcode.trim())
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt);

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;

    onUpdateMedicine({
      barcode: stock.barcode,
      name: editName.trim(),
      scientificName: editScientific.trim() || undefined,
      unit: editUnit.trim() || 'باكيت',
      minStockAlert: Math.max(0, parseInt(editMinStock, 10) || 5),
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Top Header with Back button and Edit toggle */}
      <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition active:scale-95"
            aria-label="الرجوع إلى الجرد"
            title="الرجوع إلى الجرد"
          >
            <ArrowRight className="h-5 w-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-md border border-teal-200">
                تفاصيل المادة الدوائية
              </span>
              <span className="text-xs font-mono text-slate-500 flex items-center gap-1">
                <Barcode className="h-3.5 w-3.5 text-slate-400" />
                {stock.barcode}
              </span>
            </div>
            <h1 className="text-xl font-black text-slate-900 mt-1">{stock.name}</h1>
            {medicineItem?.scientificName && (
              <p className="text-xs text-slate-500 italic mt-0.5">{medicineItem.scientificName}</p>
            )}
          </div>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 active:scale-95 transition shadow-2xs"
        >
          <Edit3 className="h-4 w-4 text-teal-600" />
          {isEditing ? 'إلغاء التعديل' : 'تعديل البيانات'}
        </button>
      </div>

      {/* Edit Form Modal/Drawer if active */}
      {isEditing && (
        <form
          onSubmit={handleSaveEdit}
          className="rounded-2xl border-2 border-teal-500 bg-teal-50/40 p-4 space-y-4 shadow-sm"
        >
          <div className="flex items-center justify-between border-b border-teal-200/60 pb-2">
            <h3 className="text-sm font-bold text-teal-900 flex items-center gap-1.5">
              <Edit3 className="h-4 w-4 text-teal-700" />
              تعديل بيانات المادة الدوائية
            </h3>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">اسم الدواء التجاري</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                required
                className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm focus:border-teal-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الاسم العلمي / المنشأ</label>
              <input
                type="text"
                value={editScientific}
                onChange={(e) => setEditScientific(e.target.value)}
                placeholder="مثال: Paracetamol (GSK)"
                className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm focus:border-teal-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">وحدة القياس</label>
              <select
                value={editUnit}
                onChange={(e) => setEditUnit(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm focus:border-teal-500 focus:outline-hidden"
              >
                <option value="باكيت">باكيت</option>
                <option value="علبة">علبة</option>
                <option value="شريط">شريط</option>
                <option value="قارورة">قارورة / شراب</option>
                <option value="كرتونة">كرتونة</option>
                <option value="أمبولة">أمبولة</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">حد تنبيه المخزون المنخفض</label>
              <input
                type="number"
                min="0"
                value={editMinStock}
                onChange={(e) => setEditMinStock(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm focus:border-teal-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-teal-800"
            >
              <Check className="h-4 w-4" />
              حفظ التعديلات
            </button>
          </div>
        </form>
      )}

      {/* Main KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Remaining Stock */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">الرصيد المتوفر</span>
            <div
              className={`rounded-full p-2 ${
                stock.remaining === 0
                  ? 'bg-rose-100 text-rose-600'
                  : stock.isLowStock
                  ? 'bg-amber-100 text-amber-600'
                  : 'bg-emerald-100 text-emerald-600'
              }`}
            >
              <Package className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-slate-900">{stock.remaining}</span>
            <span className="text-xs text-slate-500">{medicineItem?.unit || 'باكيت'}</span>
          </div>
          <div className="mt-2">
            {stock.remaining === 0 ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                نفذ المخزون
              </span>
            ) : stock.isLowStock ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                أوشك على النفاد (الحد {stock.minStockAlert})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                متوفر بكثرة
              </span>
            )}
          </div>
        </div>

        {/* Average Cost */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">متوسط كلفة الشراء</span>
            <div className="rounded-full bg-blue-100 text-blue-600 p-2">
              <DollarSign className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-slate-900">
            {formatIQD(stock.averageCost)}
          </div>
          <p className="mt-2 text-[11px] text-slate-400">محسوب بالمتوسط المرجح لكل الشراء</p>
        </div>

        {/* Total Stock Value */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">القيمة الإجمالية للمخزون</span>
            <div className="rounded-full bg-indigo-100 text-indigo-600 p-2">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-indigo-900">
            {formatIQD(stock.stockValue)}
          </div>
          <p className="mt-2 text-[11px] text-slate-400">الرصيد × متوسط التكلفة</p>
        </div>

        {/* Nearest Expiry */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">أقرب وجبة انتهاء</span>
            <div
              className={`rounded-full p-2 ${
                stock.isExpired
                  ? 'bg-rose-100 text-rose-600'
                  : stock.isNearExpiry
                  ? 'bg-amber-100 text-amber-600'
                  : 'bg-teal-100 text-teal-600'
              }`}
            >
              <Calendar className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-base font-black text-slate-900">
            {stock.nearestExpiry ? formatDateArabic(stock.nearestExpiry) : 'لا توجد وجبات'}
          </div>
          <div className="mt-2">
            {stock.daysToExpiry !== null ? (
              stock.daysToExpiry <= 0 ? (
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                  منتهي الصلاحية!
                </span>
              ) : stock.daysToExpiry <= 90 ? (
                <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                  ينتهي خلال {stock.daysToExpiry} يوم
                </span>
              ) : (
                <span className="text-[11px] text-slate-500">
                  متبقي {stock.daysToExpiry} يوم
                </span>
              )
            ) : (
              <span className="text-[11px] text-slate-400">-</span>
            )}
          </div>
        </div>
      </div>

      {/* Quick Action Shortcuts */}
      <div className="flex gap-2">
        <button
          onClick={() => onQuickPurchase(stock.barcode)}
          className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-teal-700 py-2.5 px-4 text-xs font-bold text-white shadow-xs hover:bg-teal-800 active:scale-98 transition"
        >
          <ShoppingCart className="h-4 w-4" />
          شراء وجبة جديدة من هذا الدواء
        </button>
        <button
          onClick={() => onQuickSale(stock.barcode)}
          disabled={stock.remaining <= 0}
          className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-indigo-700 py-2.5 px-4 text-xs font-bold text-white shadow-xs hover:bg-indigo-800 disabled:opacity-40 disabled:pointer-events-none active:scale-98 transition"
        >
          <ShoppingBag className="h-4 w-4" />
          تسجيل بيع من هذا الدواء
        </button>
      </div>

      {/* Tabs for Batches, Purchases, and Sales */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Tab Headers */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 p-1 gap-1">
          <button
            onClick={() => setActiveTab('batches')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition ${
              activeTab === 'batches'
                ? 'bg-white text-teal-800 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="h-4 w-4" />
            الوجبات الحالية بالمخزن ({stock.batches.length})
          </button>
          <button
            onClick={() => setActiveTab('purchases')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition ${
              activeTab === 'purchases'
                ? 'bg-white text-teal-800 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShoppingCart className="h-4 w-4" />
            سجل المشتريات ({medicinePurchases.length})
          </button>
          <button
            onClick={() => setActiveTab('sales')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition ${
              activeTab === 'sales'
                ? 'bg-white text-teal-800 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShoppingBag className="h-4 w-4" />
            سجل المبيعات ({medicineSales.length})
          </button>
        </div>

        {/* Tab 1: Current Batches (FEFO allocation) */}
        {activeTab === 'batches' && (
          <div className="p-4 space-y-3">
            <div className="text-xs text-slate-500 flex items-center justify-between">
              <span>الوجبات المتوفرة حالياً مرتبة حسب الأقرب انتهاءً (FEFO):</span>
              <span className="font-bold text-slate-700">المجموع: {stock.remaining} {medicineItem?.unit || 'باكيت'}</span>
            </div>

            {stock.batches.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                لا توجد وجبات نشطة في المخزن حالياً.
              </div>
            ) : (
              <div className="space-y-2">
                {stock.batches.map((batch, index) => {
                  const [year, month, day] = batch.expiryDate.split('-');
                  const expDate = new Date(batch.expiryDate);
                  const today = new Date();
                  const diffDays = Math.ceil((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                  const isExp = diffDays <= 0;
                  const isNear = diffDays > 0 && diffDays <= 90;

                  return (
                    <div
                      key={batch.purchaseId + index}
                      className={`flex items-center justify-between p-3 rounded-xl border ${
                        isExp
                          ? 'border-rose-200 bg-rose-50/50'
                          : isNear
                          ? 'border-amber-200 bg-amber-50/50'
                          : 'border-slate-200 bg-slate-50/50'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">
                            صلاحية: {day}/{month}/{year}
                          </span>
                          {index === 0 && (
                            <span className="text-[10px] font-bold text-teal-800 bg-teal-100 px-2 py-0.5 rounded-full">
                              يُصرف أولاً (FEFO)
                            </span>
                          )}
                          {isExp && (
                            <span className="text-[10px] font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded-full">
                              منتهي
                            </span>
                          )}
                          {isNear && (
                            <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                              ينتهي خلال {diffDays} يوم
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-500">
                          المورد: {batch.supplier || 'مورد عام'} | سعر الشراء: {formatIQD(batch.unitPrice)}
                        </div>
                      </div>

                      <div className="text-left">
                        <div className="text-base font-black text-teal-800">
                          {batch.remainingQty}{' '}
                          <span className="text-xs font-normal text-slate-500">
                            / {batch.originalQty}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400">الكمية المتبقية</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Recent Purchases */}
        {activeTab === 'purchases' && (
          <div className="p-4 space-y-3">
            {medicinePurchases.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                لا توجد عمليات شراء مسجلة لهذا الدواء.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {medicinePurchases.map((purchase) => (
                  <div key={purchase.id} className="py-3 flex items-center justify-between first:pt-0 last:pb-0">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">{purchase.supplier}</span>
                        <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          {formatDateArabic(purchase.date)}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500">
                        الكمية: <strong className="text-slate-800">{purchase.qty}</strong> بسعر{' '}
                        {formatIQD(purchase.unitPrice)} | إكسباير: {formatDateArabic(purchase.expiryDate)}
                      </div>
                    </div>

                    <div className="text-left space-y-0.5">
                      <div className="text-sm font-black text-slate-900">
                        {formatIQD(purchase.totalAmount)}
                      </div>
                      {purchase.remainingUnpaid > 0 ? (
                        <div className="text-[11px] font-bold text-amber-600">
                          دين: {formatIQD(purchase.remainingUnpaid)}
                        </div>
                      ) : (
                        <div className="text-[11px] font-bold text-emerald-600">واصل كاش</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Recent Sales */}
        {activeTab === 'sales' && (
          <div className="p-4 space-y-3">
            {medicineSales.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                لا توجد عمليات بيع مسجلة لهذا الدواء بعد.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {medicineSales.map((sale) => {
                  const unitCost = sale.avgCostAtSale || stock.averageCost;
                  const profitPerUnit = sale.unitPrice - unitCost;
                  const totalProfit = profitPerUnit * sale.qty;

                  return (
                    <div key={sale.id} className="py-3 flex items-center justify-between first:pt-0 last:pb-0">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-900">{sale.buyer}</span>
                          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                            {formatDateArabic(sale.date)}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500">
                          الكمية: <strong className="text-slate-800">{sale.qty}</strong> بسعر بيع{' '}
                          {formatIQD(sale.unitPrice)}
                        </div>
                      </div>

                      <div className="text-left space-y-0.5">
                        <div className="text-sm font-black text-indigo-900">
                          {formatIQD(sale.totalAmount)}
                        </div>
                        <div className="text-[11px] font-bold text-emerald-600 flex items-center gap-1 justify-end">
                          <span>ربح:</span>
                          <span>{formatIQD(totalProfit)}</span>
                        </div>
                        {sale.remainingUnpaid > 0 && (
                          <div className="text-[10px] text-amber-600">
                            متبقي دين: {formatIQD(sale.remainingUnpaid)}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
