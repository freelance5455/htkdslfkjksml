import { useMemo, useState } from 'react';
import type { Department, ShiftType } from '../types/attendance';
import { computeMonthlyTrend, formatShiftLabel, getMonthlyCycleRange } from '../utils/attendanceLogic';

interface MonthlyOverviewCardProps {
  departments: Department[];
  todayDate: string;
  selectedShift: ShiftType;
}

export function MonthlyOverviewCard({
  departments,
  todayDate,
  selectedShift,
}: MonthlyOverviewCardProps) {
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string>('all');
  const [hoveredDate, setHoveredDate] = useState<string | null>(null);

  const cycle = useMemo(() => getMonthlyCycleRange(todayDate), [todayDate]);

  // Reset filter if selected department was deleted/missing
  const effectiveDepartmentId =
    selectedDepartmentId === 'all' || departments.some((d) => d.id === selectedDepartmentId)
      ? selectedDepartmentId
      : 'all';

  const trend = useMemo(
    () => computeMonthlyTrend(departments, cycle.dates, effectiveDepartmentId, selectedShift),
    [departments, cycle.dates, effectiveDepartmentId, selectedShift],
  );

  const activeDay = useMemo(() => {
    if (hoveredDate) {
      return trend.days.find((d) => d.date === hoveredDate) ?? null;
    }
    return trend.days.find((d) => d.date === todayDate) ?? null;
  }, [hoveredDate, trend.days, todayDate]);

  const yTicks = useMemo(() => {
    const max = trend.maxDailyCount;
    const mid = Math.ceil(max / 2);
    return [max, mid, 0];
  }, [trend.maxDailyCount]);

  return (
    <section
      aria-labelledby="monthly-overview-heading"
      className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-5 sm:p-6 space-y-5"
    >
      {/* Header & Department Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 id="monthly-overview-heading" className="text-lg font-semibold text-slate-900">
            Monthly Attendance Overview
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            {cycle.label} · {cycle.dates.length} days · {formatShiftLabel(selectedShift)}
          </p>
        </div>

        {departments.length > 1 && (
          <div
            role="tablist"
            aria-label="Filter monthly chart by department"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-xl self-start sm:self-auto"
          >
            <button
              type="button"
              role="tab"
              aria-selected={effectiveDepartmentId === 'all'}
              onClick={() => setSelectedDepartmentId('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                effectiveDepartmentId === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Departments
            </button>
            {departments.map((dept) => (
              <button
                key={dept.id}
                type="button"
                role="tab"
                aria-selected={effectiveDepartmentId === dept.id}
                onClick={() => setSelectedDepartmentId(dept.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  effectiveDepartmentId === dept.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {dept.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Cycle Totals & Active Day Readout */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 text-sm">
        <div className="flex flex-wrap items-center gap-5">
          <div className="inline-flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500 shrink-0" aria-hidden="true" />
            <span className="text-slate-600">Present:</span>
            <span data-testid="monthly-total-present" className="font-bold text-emerald-700 tabular-nums">
              {trend.totalPresent}
            </span>
          </div>
          <div className="inline-flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-xs bg-rose-500 shrink-0" aria-hidden="true" />
            <span className="text-slate-600">Absent:</span>
            <span data-testid="monthly-total-absent" className="font-bold text-rose-600 tabular-nums">
              {trend.totalAbsent}
            </span>
          </div>
        </div>

        <div className="text-xs sm:text-sm text-slate-600 tabular-nums">
          {activeDay ? (
            <span>
              <strong className="text-slate-900">{activeDay.shortLabel}</strong>
              {activeDay.date === todayDate ? ' (Today)' : ''}:{' '}
              <span className="text-emerald-700 font-semibold">{activeDay.present} Present</span>
              {' · '}
              <span className="text-rose-600 font-semibold">{activeDay.absent} Absent</span>
            </span>
          ) : (
            <span>Hover or tap any day bar for counts</span>
          )}
        </div>
      </div>

      {/* Bar Chart */}
      <div className="overflow-x-auto pb-1">
        <div className="min-w-[620px]">
          <div className="flex gap-3">
            {/* Y-Axis Scale */}
            <div
              aria-hidden="true"
              className="flex flex-col justify-between h-44 pb-6 text-[11px] font-mono text-slate-400 tabular-nums select-none w-6 text-right shrink-0"
            >
              {yTicks.map((tick, idx) => (
                <span key={`${tick}-${idx}`}>{tick}</span>
              ))}
            </div>

            {/* Bars Plot Area */}
            <div className="flex-1 relative pr-1">
              {/* Horizontal Gridlines */}
              <div
                aria-hidden="true"
                className="absolute inset-x-0 top-0 bottom-6 flex flex-col justify-between pointer-events-none"
              >
                <div className="border-t border-dashed border-slate-100" />
                <div className="border-t border-dashed border-slate-100" />
                <div className="border-t border-slate-200" />
              </div>

              {/* 31-day Grouped Bar Columns */}
              <div
                role="img"
                aria-label={`Daily attendance bar chart from ${cycle.label}`}
                className="relative z-10 grid h-44 pb-6 items-end gap-1"
                style={{ gridTemplateColumns: `repeat(${trend.days.length}, minmax(0, 1fr))` }}
              >
                {trend.days.map((day, idx) => {
                  const presentHeightPct =
                    day.present > 0 ? Math.max(6, Math.round((day.present / trend.maxDailyCount) * 100)) : 0;
                  const absentHeightPct =
                    day.absent > 0 ? Math.max(6, Math.round((day.absent / trend.maxDailyCount) * 100)) : 0;

                  const isToday = day.date === todayDate;
                  const isSelected = hoveredDate === day.date || (!hoveredDate && isToday);
                  const isFirst = idx === 0;
                  const isLast = idx === trend.days.length - 1;
                  const showLabel =
                    isFirst ||
                    isLast ||
                    day.dayNumber === '1' ||
                    day.dayNumber === '5' ||
                    day.dayNumber === '10' ||
                    day.dayNumber === '15' ||
                    day.dayNumber === '20';

                  const labelAlignClass = isFirst
                    ? 'left-0'
                    : isLast
                      ? 'right-0'
                      : 'left-1/2 -translate-x-1/2';

                  return (
                    <button
                      key={day.date}
                      type="button"
                      onMouseEnter={() => setHoveredDate(day.date)}
                      onFocus={() => setHoveredDate(day.date)}
                      onClick={() => setHoveredDate(day.date)}
                      aria-label={`${day.shortLabel}: ${day.present} Present, ${day.absent} Absent`}
                      className={`group relative h-full flex flex-col justify-end items-center rounded-md transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${
                        isSelected ? 'bg-slate-100/80' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="w-full h-full flex items-end justify-center gap-[2px] px-[2px]">
                        <span
                          className="w-1/2 max-w-[9px] rounded-t-xs bg-emerald-500 group-hover:bg-emerald-600 transition-all duration-150"
                          style={{ height: `${presentHeightPct}%` }}
                        />
                        <span
                          className="w-1/2 max-w-[9px] rounded-t-xs bg-rose-500 group-hover:bg-rose-600 transition-all duration-150"
                          style={{ height: `${absentHeightPct}%` }}
                        />
                      </div>

                      {showLabel && (
                        <span
                          className={`absolute -bottom-5 ${labelAlignClass} text-[10px] font-mono tabular-nums whitespace-nowrap ${
                            isToday ? 'font-bold text-blue-600' : 'text-slate-400'
                          }`}
                        >
                          {isFirst || day.dayNumber === '1' || isLast
                            ? day.shortLabel
                            : day.dayNumber}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Per-Department Monthly Totals */}
      <div className="pt-4 border-t border-slate-100 space-y-2.5">
        <p className="text-xs font-semibold text-slate-500">Department Breakdown ({cycle.label})</p>
        <div className="space-y-2.5">
          {trend.byDepartment.map((item) => {
            const sum = item.present + item.absent;
            const presentPct = sum > 0 ? Math.round((item.present / sum) * 100) : 0;
            const absentPct = sum > 0 ? 100 - presentPct : 0;

            return (
              <div key={item.departmentId} className="space-y-1">
                <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-semibold text-slate-900 truncate">{item.departmentName}</span>
                    <span className="text-xs text-slate-500 truncate">· {item.supervisor}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm tabular-nums shrink-0">
                    <span className="font-semibold text-emerald-700">{item.present} Present</span>
                    <span className="font-semibold text-rose-600">{item.absent} Absent</span>
                  </div>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden flex">
                  {sum > 0 && (
                    <>
                      <div
                        className="h-full bg-emerald-500 transition-all duration-200"
                        style={{ width: `${presentPct}%` }}
                      />
                      <div
                        className="h-full bg-rose-500 transition-all duration-200"
                        style={{ width: `${absentPct}%` }}
                      />
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
