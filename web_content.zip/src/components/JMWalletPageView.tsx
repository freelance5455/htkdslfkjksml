import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  PlusCircle, 
  RefreshCw, 
  CheckCircle2, 
  Trash2, 
  Zap, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Key, 
  ShieldCheck, 
  Copy, 
  Check, 
  QrCode, 
  Coins, 
  AlertTriangle, 
  Sparkles, 
  ExternalLink, 
  Lock, 
  Unlock, 
  Cpu, 
  HardDrive, 
  Activity, 
  Smartphone, 
  Eye, 
  EyeOff,
  Share2,
  DollarSign,
  Info,
  Layers,
  X,
  Fingerprint,
  History,
  TrendingUp,
  Download,
  Upload
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { membersRegistryService } from '../lib/membersRegistryService';
import { JMEarningsDashboard } from './JMEarningsDashboard';
import { tradeHistoryTracker, TradeHistoryRecord } from '../lib/tradeHistory';
import { walletWebSocketSync, WalletWsEvent } from '../lib/walletWebSocketSync';
import { stakingEngine, StakePosition } from '../lib/stakingEngine';
import { CommunityPrayerWall } from './CommunityPrayerWall';

export interface DerivedWalletAddress {
  address: string;
  label: string;
  createdAt: string;
  usageCount: number;
  note?: string;
}

export interface UserWalletState {
  isCreated: boolean;
  isActive: boolean;
  masterAddress: string;
  derivedAddresses: DerivedWalletAddress[];
  seedPhrase: string[];
  privateKey: string;
  createdAt: string;
  activatedAt?: string;
  linkedMiningApp: boolean;
  linkedExternalWallets: boolean;
  linkedMobileBanking: boolean;
}

const WALLET_STORAGE_KEY = 'jm_user_sovereign_wallet_v1';

const MNEMONIC_POOL = [
  'prophetic', 'altar', 'glory', 'sovereign', 'covenant', 'anointed', 
  'sanctuary', 'praise', 'heavens', 'worship', 'harvest', 'grace', 
  'dominion', 'victory', 'shalom', 'divine', 'wisdom', 'righteousness'
];

interface JMWalletPageViewProps {
  onNavigateToMining?: () => void;
  onOpenSignup?: () => void;
}

export const JMWalletPageView: React.FC<JMWalletPageViewProps> = ({
  onNavigateToMining,
  onOpenSignup
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showSeedModal, setShowSeedModal] = useState<boolean>(false);
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [showSendModal, setShowSendModal] = useState<boolean>(false);
  const [showReceiveModal, setShowReceiveModal] = useState<boolean>(false);
  const [selectedAddressForQr, setSelectedAddressForQr] = useState<string>('');

  // Security PIN Protection States
  const [showPinModal, setShowPinModal] = useState<boolean>(false);
  const [pinActionType, setPinActionType] = useState<'activate' | 'delete' | null>(null);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  const handleInitiateActivate = () => {
    setPinActionType('activate');
    setEnteredPin('');
    setPinError(null);
    setShowPinModal(true);
  };

  const handleInitiateDelete = () => {
    setPinActionType('delete');
    setEnteredPin('');
    setPinError(null);
    setShowPinModal(true);
  };

  const handleVerifyPinAndExecute = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredPin === '7777' || enteredPin.toLowerCase() === 'juhnkrix') {
      setShowPinModal(false);
      if (pinActionType === 'activate') {
        handleActivateWallet();
      } else if (pinActionType === 'delete') {
        setShowDeleteModal(true);
      }
    } else {
      setPinError('❌ Invalid Security PIN. Default PIN is 7777.');
    }
  };

  // Biometric Security States
  const [biometricEnabled, setBiometricEnabled] = useState<boolean>(() => {
    return localStorage.getItem('jm_biometric_security_enabled') === 'true';
  });
  const [showBiometricModal, setShowBiometricModal] = useState<boolean>(false);
  const [biometricActionType, setBiometricActionType] = useState<'send' | 'delete' | null>(null);
  const [isScanningBiometric, setIsScanningBiometric] = useState<boolean>(false);

  // Transaction History State
  const [transactions, setTransactions] = useState<any[]>(() => {
    try {
      const stored = localStorage.getItem('jm_jmc_transaction_history_v1');
      if (stored) return JSON.parse(stored);
    } catch {}
    return [
      {
        id: 'tx-001',
        type: 'RECEIVE',
        amount: 1.5000,
        address: '0x84fA1239857d4B7192aF094589d71A4909cF128C',
        timestamp: '2026-10-28 14:22:00',
        status: 'CONFIRMED'
      },
      {
        id: 'tx-002',
        type: 'SEND',
        amount: 0.2500,
        address: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5',
        timestamp: '2026-10-29 09:15:00',
        status: 'CONFIRMED'
      }
    ];
  });

  const handleToggleBiometric = () => {
    const next = !biometricEnabled;
    setBiometricEnabled(next);
    localStorage.setItem('jm_biometric_security_enabled', next ? 'true' : 'false');
    showToast(next ? '🔒 Biometric Fingerprint Passkey Enabled!' : '🔓 Biometric Security Disabled.');
  };

  const handleTriggerBiometricCheck = (actionType: 'send' | 'delete') => {
    if (!biometricEnabled) {
      if (actionType === 'send') setShowSendModal(true);
      if (actionType === 'delete') handleInitiateDelete();
      return;
    }
    setBiometricActionType(actionType);
    setIsScanningBiometric(false);
    setShowBiometricModal(true);
  };

  const handleSimulateBiometricScan = async () => {
    setIsScanningBiometric(true);
    try {
      if (typeof window !== 'undefined' && window.PublicKeyCredential && navigator.credentials) {
        try {
          const publicKey = {
            challenge: new Uint8Array([21, 31, 105, 78, 18, 45, 99, 102]),
            timeout: 60000,
            userVerification: 'preferred' as const
          };
          await navigator.credentials.get({ publicKey }).catch(() => {});
        } catch {
          // Fallback simulation
        }
      }
    } catch {
      // ignore
    }

    setTimeout(() => {
      setIsScanningBiometric(false);
      setShowBiometricModal(false);
      showToast('✓ Biometric Passkey / Fingerprint Verified via Credential Management API!');
      if (biometricActionType === 'send') {
        setShowSendModal(true);
      } else if (biometricActionType === 'delete') {
        handleInitiateDelete();
      }
    }, 1500);
  };

  // Staking States & Handlers (Using stakingEngine for Prophetic Rewards Multipliers)
  const [stakeInputAmount, setStakeInputAmount] = useState<string>('0.5000');
  const [stakeHorizonDays, setStakeHorizonDays] = useState<number>(90);
  const [stakePositions, setStakePositions] = useState<StakePosition[]>(() => stakingEngine.getStakedPositions());

  const stakedBalance = useMemo(() => {
    return stakePositions.reduce((acc, p) => p.status === 'ACTIVE' ? acc + p.amount : acc, 0);
  }, [stakePositions]);

  const handleStakeJmc = () => {
    const amt = parseFloat(stakeInputAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('❌ Please enter a valid JMC amount to stake.');
      return;
    }
    if (amt > jmcBalance) {
      showToast('❌ Insufficient JMC balance to stake.');
      return;
    }
    const newBal = +(jmcBalance - amt).toFixed(4);
    setJmcBalance(newBal);
    try {
      localStorage.setItem('jm_crypto_balance_v2', newBal.toFixed(4));
    } catch {}

    const newPos = stakingEngine.createStake(amt, stakeHorizonDays);
    setStakePositions(stakingEngine.getStakedPositions());
    showToast(`✨ Successfully locked ${amt} JMC for ${stakeHorizonDays} days! Prophetic Rewards APY & Multiplier Active.`);
  };

  const handleClaimStakeRewards = (positionId: string) => {
    const result = stakingEngine.claimRewards(positionId);
    setStakePositions(result.positions);
    if (result.claimedAmount > 0) {
      const newBal = +(jmcBalance + result.claimedAmount).toFixed(4);
      setJmcBalance(newBal);
      try {
        localStorage.setItem('jm_crypto_balance_v2', newBal.toFixed(4));
      } catch {}
      showToast(`🎉 Successfully claimed +${result.claimedAmount} JMC Prophetic Rewards! Credited to wallet balance.`);
    } else {
      showToast('ℹ️ No unclaimed rewards available for this position.');
    }
  };

  const handleJoinPrayerReward = () => {
    const bonus = 0.0050;
    const newBal = +(jmcBalance + bonus).toFixed(4);
    setJmcBalance(newBal);
    try {
      localStorage.setItem('jm_crypto_balance_v2', newBal.toFixed(4));
    } catch {}
    setTransactions(prev => [
      {
        id: `prayer-reward-${Date.now()}`,
        type: 'RECEIVE (PRAYER REWARD)',
        amount: bonus,
        address: 'Community Sanctuary Prayer Wall',
        timestamp: new Date().toLocaleTimeString(),
        status: 'CONFIRMED'
      },
      ...prev
    ]);
  };

  const handleDownloadTransactionPdfTxt = () => {
    try {
      let content = `======================================================\n`;
      content += `JUHNKRIX MUSIKA - OFFICIAL JMC TRANSACTION LEDGER\n`;
      content += `Generated At: ${new Date().toLocaleString()}\n`;
      content += `Domain: juhnkrixmusika.pages.dev\n`;
      content += `======================================================\n\n`;
      transactions.forEach((tx, idx) => {
        content += `[${idx + 1}] ID: ${tx.id}\n`;
        content += `Type: ${tx.type}\n`;
        content += `Amount: ${tx.amount} JMC\n`;
        content += `Address/Recipient: ${tx.address}\n`;
        content += `Timestamp: ${tx.timestamp}\n`;
        content += `Status: ${tx.status}\n`;
        content += `------------------------------------------------------\n`;
      });
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JUHNKRIX_JMC_TRANSACTION_LEDGER_${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('✓ Transaction ledger formatted & downloaded as clean printable document!');
    } catch (e: any) {
      showToast(`❌ Error downloading ledger: ${e.message}`);
    }
  };

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsedData = JSON.parse(content);
        if (!Array.isArray(parsedData)) {
          throw new Error('Invalid JSON format: Expected an array of transactions.');
        }
        setTransactions(prev => {
          const existingIds = new Set(prev.map(t => t.id));
          const newItems = parsedData.filter(t => t && t.id && !existingIds.has(t.id));
          const merged = [...newItems, ...prev];
          try {
            localStorage.setItem('jm_jmc_transaction_history_v1', JSON.stringify(merged));
          } catch {}
          return merged;
        });
        showToast(`✓ Successfully imported ${parsedData.length} JMC transactions and merged into local storage ledger!`);
      } catch (err: any) {
        showToast(`❌ Error parsing JSON backup: ${err.message}`);
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleExportJson = () => {
    try {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(transactions, null, 2));
      const a = document.createElement('a');
      a.href = dataStr;
      a.download = `juhnkrix_jmc_transactions_backup_${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast('✓ Successfully exported JMC transaction history as JSON file backup.');
    } catch (e: any) {
      showToast(`❌ Error exporting JSON: ${e.message}`);
    }
  };

  const handleExportCsv = () => {
    try {
      let csv = 'Transaction ID,Type,Amount (JMC),Address/Source,Timestamp,Status\n';
      transactions.forEach(tx => {
        csv += `"${tx.id}","${tx.type}","${tx.amount}","${tx.address || ''}","${tx.timestamp}","${tx.status || 'CONFIRMED'}"\n`;
      });
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `juhnkrix_jmc_transaction_report_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('✓ Successfully exported JMC transaction history as CSV tax report.');
    } catch (e: any) {
      showToast(`❌ Error exporting CSV: ${e.message}`);
    }
  };

  // New address generation inputs
  const [newAddressLabel, setNewAddressLabel] = useState<string>('Sacred Praise Offering');
  const [newAddressNote, setNewAddressNote] = useState<string>('Receiving JMC Transaction');

  // Send transaction inputs
  const [recipientAddress, setRecipientAddress] = useState<string>('');
  const [sendAmountJmc, setSendAmountJmc] = useState<string>('0.0100');
  const [isSending, setIsSending] = useState<boolean>(false);

  // Financial values: 1 JMC = $35,000 USD (₦52,500,000 NGN)
  const JMC_USD_PRICE = 35000;
  const USD_TO_NGN_RATE = 1500;
  const JMC_NGN_PRICE = JMC_USD_PRICE * USD_TO_NGN_RATE;

  // Registered member check
  const [isRegistered, setIsRegistered] = useState<boolean>(() => {
    return membersRegistryService.isCurrentUserRegistered();
  });

  // Current balance states (Synced with mining ledger)
  const [jmcBalance, setJmcBalance] = useState<number>(() => {
    try {
      const ledger = localStorage.getItem('jmc_balance_ledger');
      if (ledger) {
        const parsed = JSON.parse(ledger);
        if (typeof parsed.jmcBalance === 'number') return parsed.jmcBalance;
      }
      const saved = localStorage.getItem('jm_crypto_balance_v2');
      return saved ? parseFloat(saved) : 2.4500;
    } catch {
      return 2.4500;
    }
  });

  const [unclaimedMined, setUnclaimedMined] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('jm_crypto_mined_unclaimed_v2');
      return saved ? parseFloat(saved) : 0.0450;
    } catch {
      return 0.0450;
    }
  });

  const [isRefreshingBalance, setIsRefreshingBalance] = useState<boolean>(false);

  // Real-Time WebSocket Listener for Linked External Wallet Trades & Transfers
  useEffect(() => {
    const handleWsEvent = (evt: WalletWsEvent) => {
      setJmcBalance(prev => {
        const next = +(prev + evt.amount).toFixed(4);
        try {
          localStorage.setItem('jm_crypto_balance_v2', next.toFixed(4));
        } catch {}
        return next;
      });

      setTransactions(prev => [
        {
          id: evt.id,
          type: evt.type === 'EXTERNAL_TRADE' ? 'RECEIVE (TRADE)' : 'RECEIVE (TRANSFER)',
          amount: evt.amount,
          address: evt.sourceOrDestination,
          timestamp: evt.timestamp,
          status: 'CONFIRMED'
        },
        ...prev
      ]);

      setToastMessage(`🟢 Live WS Sync: Detected ${evt.type === 'EXTERNAL_TRADE' ? 'External Exchange Trade' : 'Wallet Transfer'} (+${evt.amount} JMC). Balance updated!`);
      setTimeout(() => setToastMessage(null), 5000);
    };

    walletWebSocketSync.connect(handleWsEvent);
    return () => {
      walletWebSocketSync.disconnect(handleWsEvent);
    };
  }, []);

  // Load sovereign user wallet state
  const [tradeHistory] = useState<TradeHistoryRecord[]>(() => tradeHistoryTracker.getTradeHistory());

  const [wallet, setWallet] = useState<UserWalletState>(() => {
    try {
      const stored = localStorage.getItem(WALLET_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error(e);
    }
    // Default active demo wallet
    return {
      isCreated: true,
      isActive: true,
      masterAddress: '0xJUHNKRIX77789a8f4a1239857d4B7192aF094589',
      derivedAddresses: [
        {
          address: '0xJUHNKRIX77789a8f4a1239857d4B7192aF094589',
          label: 'Master Sovereign Wallet',
          createdAt: '2026-06-01',
          usageCount: 14,
          note: 'Primary JMC Storing & Global Trade'
        },
        {
          address: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5',
          label: 'Mining Rewards Payout Receiver',
          createdAt: '2026-08-15',
          usageCount: 28,
          note: 'Direct 50% device miner share receiver'
        }
      ],
      seedPhrase: [
        'divine', 'altar', 'praise', 'glory', 'sovereign', 'prophet', 
        'covenant', 'grace', 'holy', 'oil', 'fire', 'victory'
      ],
      privateKey: '0x8f7a93c4e2b109786543d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1',
      createdAt: '2026-06-01',
      activatedAt: '2026-06-01',
      linkedMiningApp: true,
      linkedExternalWallets: true,
      linkedMobileBanking: true
    };
  });

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  }, []);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    showToast(`✓ Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedKey(null), 3000);
  };

  const persistWallet = (updated: UserWalletState) => {
    setWallet(updated);
    try {
      localStorage.setItem(WALLET_STORAGE_KEY, JSON.stringify(updated));
      localStorage.setItem('juhnkrix_user_jmc_address', updated.masterAddress);
      membersRegistryService.updateCurrentMemberWallet(updated.masterAddress);
    } catch (e) {
      console.error(e);
    }
  };

  // 1. CREATE A USER WALLET
  const handleCreateUserWallet = () => {
    // Generate 12-word seed mnemonic
    const shuffled = [...MNEMONIC_POOL].sort(() => 0.5 - Math.random());
    const newSeed = shuffled.slice(0, 12);

    // Generate random 40-char hex address with 0xJUHNKRIX prefix
    const randomHex = Array.from({ length: 30 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const newMasterAddress = `0xJUHNKRIX${randomHex.substring(0, 30)}`;
    const newPrivKey = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    const newWallet: UserWalletState = {
      isCreated: true,
      isActive: true,
      masterAddress: newMasterAddress,
      derivedAddresses: [
        {
          address: newMasterAddress,
          label: 'Master Sovereign Wallet',
          createdAt: new Date().toLocaleDateString(),
          usageCount: 0,
          note: 'Primary Self-Custodial Root'
        }
      ],
      seedPhrase: newSeed,
      privateKey: newPrivKey,
      createdAt: new Date().toLocaleString(),
      activatedAt: new Date().toLocaleString(),
      linkedMiningApp: true,
      linkedExternalWallets: true,
      linkedMobileBanking: true
    };

    persistWallet(newWallet);
    showToast('🎉 Personal JM-CRYPTO Wallet successfully created and backed by self-custodial on-device keys!');
    setShowSeedModal(true);
  };

  // 2. GENERATE NEW WALLET ADDRESS
  const handleGenerateNewAddress = () => {
    if (!wallet.isCreated) {
      showToast('❌ Please create your JM-CRYPTO wallet first.');
      return;
    }

    const randomHex = Array.from({ length: 30 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const derivedAddress = `0x${randomHex.substring(0, 40)}`;
    const newEntry: DerivedWalletAddress = {
      address: derivedAddress,
      label: newAddressLabel.trim() || `Transaction Address #${wallet.derivedAddresses.length + 1}`,
      createdAt: new Date().toLocaleString(),
      usageCount: 0,
      note: newAddressNote.trim() || 'One-Time Transaction Receiver'
    };

    const updated: UserWalletState = {
      ...wallet,
      derivedAddresses: [newEntry, ...wallet.derivedAddresses]
    };

    persistWallet(updated);
    showToast(`✓ New JMC wallet address generated for: "${newEntry.label}"!`);
  };

  // 3. CHECK YOUR JM-CRYPTO WALLET ACCOUNT BALANCE
  const handleCheckBalance = () => {
    setIsRefreshingBalance(true);
    showToast('🔄 Verifying on-device cryptographic ledger & IndexedDB block hashes...');

    setTimeout(() => {
      try {
        const rawLedger = localStorage.getItem('jmc_balance_ledger');
        if (rawLedger) {
          const parsed = JSON.parse(rawLedger);
          if (typeof parsed.jmcBalance === 'number') setJmcBalance(parsed.jmcBalance);
          if (typeof parsed.unclaimedMiningReward === 'number') setUnclaimedMined(parsed.unclaimedMiningReward);
        } else {
          const rawMined = localStorage.getItem('jm_crypto_mined_unclaimed_v2');
          if (rawMined) setUnclaimedMined(parseFloat(rawMined));
        }
      } catch {
        // ignore
      }
      setIsRefreshingBalance(false);
      showToast('✓ Account Balance Verified: 100% synchronized with JMC decentralized ledger!');
    }, 1000);
  };

  // 4. DELETE WALLET
  const handleDeleteWallet = () => {
    try {
      localStorage.removeItem(WALLET_STORAGE_KEY);
      localStorage.removeItem('juhnkrix_user_jmc_address');
    } catch {
      // ignore
    }

    setWallet({
      isCreated: false,
      isActive: false,
      masterAddress: '',
      derivedAddresses: [],
      seedPhrase: [],
      privateKey: '',
      createdAt: '',
      linkedMiningApp: false,
      linkedExternalWallets: false,
      linkedMobileBanking: false
    });

    setShowDeleteModal(false);
    showToast('✓ Wallet permanently deleted from device storage.');
  };

  // 5. ACTIVATE WALLET
  const handleActivateWallet = () => {
    if (!wallet.isCreated) {
      showToast('❌ Please create your wallet first before activating.');
      return;
    }

    const updated: UserWalletState = {
      ...wallet,
      isActive: true,
      activatedAt: new Date().toLocaleString(),
      linkedMiningApp: true,
      linkedExternalWallets: true,
      linkedMobileBanking: true
    };

    persistWallet(updated);
    showToast('⚡ WALLET ACTIVATED! Integrated with JM-Crypto Mining App, Web3 Wallets & Mobile Banking accounts.');
  };

  // SEND JMC TRANSACTION
  const handleSendJmc = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(sendAmountJmc);
    if (isNaN(amount) || amount <= 0) {
      showToast('❌ Invalid send amount.');
      return;
    }
    if (amount > jmcBalance) {
      showToast('❌ Insufficient JMC balance.');
      return;
    }
    if (!recipientAddress.trim() || !recipientAddress.startsWith('0x')) {
      showToast('❌ Invalid recipient address. Must start with 0x.');
      return;
    }

    setIsSending(true);
    setTimeout(() => {
      const newBal = +(jmcBalance - amount).toFixed(4);
      setJmcBalance(newBal);
      const newTx = {
        id: `tx-${Date.now()}`,
        type: 'SEND',
        amount,
        address: recipientAddress,
        timestamp: new Date().toLocaleString(),
        status: 'CONFIRMED'
      };
      const updatedTxs = [newTx, ...transactions];
      setTransactions(updatedTxs);
      try {
        localStorage.setItem('jm_jmc_transaction_history_v1', JSON.stringify(updatedTxs));
        localStorage.setItem('jm_crypto_balance_v2', newBal.toFixed(4));
        const rawLedger = localStorage.getItem('jmc_balance_ledger');
        if (rawLedger) {
          const parsed = JSON.parse(rawLedger);
          parsed.jmcBalance = newBal;
          parsed.updatedAt = new Date().toISOString();
          localStorage.setItem('jmc_balance_ledger', JSON.stringify(parsed));
        }
      } catch {
        // ignore
      }

      setIsSending(false);
      setShowSendModal(false);
      showToast(`✓ Successfully sent ${amount} JMC ($${(amount * JMC_USD_PRICE).toLocaleString()} USD) to ${recipientAddress.substring(0, 12)}...!`);
    }, 1500);
  };

  // Gated Registration Shield
  if (!isRegistered) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-6 relative overflow-hidden">
          <div className="w-20 h-20 rounded-3xl bg-amber-500/20 border-2 border-amber-400/50 text-amber-400 flex items-center justify-center mx-auto shadow-xl shadow-amber-500/20">
            <Lock className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
              MEMBERS-ONLY SANCTUARY PORTAL
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
              JM-WALLET ACCESS RESTRICTED
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
              Only registered members of the JUHNKRIX MUSIKA Sanctuary are authorized to access the 
              <strong> JM-WALLET APP PAGE</strong> and <strong>JM-CRYPTO APP PAGE</strong>.
              Registration is completely free and activates your on-device cryptographic vault.
            </p>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                if (onOpenSignup) {
                  onOpenSignup();
                } else {
                  // Fallback direct registration
                  membersRegistryService.registerNewMember({
                    fullName: 'Anointed Believer',
                    email: 'believer@juhnkrixmusika.com',
                    phoneNumber: '+2347071918280',
                    membershipTier: 'Anointed Member'
                  });
                  setIsRegistered(true);
                  showToast('✓ Registered member verified! Unlocking JM-WALLET...');
                }
              }}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-105"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>REGISTER AS A MEMBER NOW</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 text-slate-100 font-sans">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 right-4 z-50 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-extrabold px-5 py-3 rounded-2xl shadow-2xl border-2 border-amber-300 flex items-center space-x-2.5 text-xs sm:text-sm max-w-md"
          >
            <Sparkles className="w-4 h-4 text-slate-950 shrink-0 animate-spin-slow" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Banner: Decentralized Native App Architecture Callout */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-700 flex items-center justify-center text-slate-950 border-2 border-amber-200 shadow-xl shadow-amber-500/30 shrink-0">
              <Wallet className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black font-serif tracking-tight bg-gradient-to-r from-amber-200 via-yellow-200 to-amber-400 bg-clip-text text-transparent">
                  JM-WALLET APP
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Self-Custodial & Decentralized
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  End-to-End Native Device
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
                The JUHNKRIX MUSIKA JM-WALLET is completely a self-custodial decentralized native app that does not rely on any web domain registrar or hosting company. 
                All cryptographic keys, addresses, and balances are secured right on your device hardware across our 50,000,000 global community of believers.
              </p>
            </div>
          </div>

          {/* Quick Active Status Badge & Live WS Sync Badge */}
          <div className="flex flex-col sm:flex-row items-end gap-3 shrink-0">
            <div className="px-4 py-2 rounded-2xl bg-slate-950 border border-emerald-500/30 text-right font-mono">
              <span className="text-[10px] text-emerald-400 block font-bold flex items-center justify-end space-x-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>LIVE WS SYNC</span>
              </span>
              <span className="text-xs text-slate-300 font-bold">External Trades Connected</span>
            </div>
            <div className="px-4 py-2 rounded-2xl bg-slate-950 border border-amber-500/30 text-right font-mono">
              <span className="text-[10px] text-slate-400 block">WALLET STATUS</span>
              <span className={`text-sm font-bold flex items-center space-x-1.5 ${wallet.isActive ? 'text-emerald-400' : 'text-amber-400'}`}>
                <span className={`w-2 h-2 rounded-full ${wallet.isActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                <span>{wallet.isActive ? 'ACTIVE & CONNECTED' : 'UNACTIVATED'}</span>
              </span>
            </div>
          </div>
        </div>

        {/* 5 Core Action Toolbar Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-4 border-t border-amber-500/20 relative z-10">
          {/* Action 1: Create Wallet */}
          <button
            onClick={handleCreateUserWallet}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-500/20 via-yellow-500/20 to-slate-900 border border-amber-400/50 hover:border-amber-300 text-left transition-all hover:scale-102 cursor-pointer shadow-md group"
          >
            <div className="flex items-center justify-between mb-2">
              <PlusCircle className="w-5 h-5 text-amber-400 group-hover:rotate-90 transition-transform" />
              <span className="text-[9px] font-mono text-amber-300 font-bold bg-amber-500/20 px-1.5 py-0.5 rounded">NEW</span>
            </div>
            <div className="text-xs font-black text-amber-100 font-serif">CREATE WALLET</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Generate personal JMC wallet keys</div>
          </button>

          {/* Action 2: Generate New Address */}
          <button
            onClick={handleGenerateNewAddress}
            className="p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 hover:border-amber-400 text-left transition-all hover:scale-102 cursor-pointer shadow-md group"
          >
            <div className="flex items-center justify-between mb-2">
              <QrCode className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span className="text-[9px] font-mono text-indigo-300 font-bold bg-indigo-500/20 px-1.5 py-0.5 rounded">HD DERIVE</span>
            </div>
            <div className="text-xs font-black text-indigo-100 font-serif">GENERATE ADDRESS</div>
            <div className="text-[10px] text-slate-400 mt-0.5">New address per transaction</div>
          </button>

          {/* Action 3: Check Balance */}
          <button
            onClick={handleCheckBalance}
            disabled={isRefreshingBalance}
            className="p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-emerald-500/30 hover:border-emerald-400 text-left transition-all hover:scale-102 cursor-pointer shadow-md group"
          >
            <div className="flex items-center justify-between mb-2">
              <RefreshCw className={`w-5 h-5 text-emerald-400 ${isRefreshingBalance ? 'animate-spin' : 'group-hover:rotate-180 transition-transform'}`} />
              <span className="text-[9px] font-mono text-emerald-300 font-bold bg-emerald-500/20 px-1.5 py-0.5 rounded">VERIFY</span>
            </div>
            <div className="text-xs font-black text-emerald-100 font-serif">CHECK BALANCE</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Cryptographic ledger refresh</div>
          </button>

          {/* Action 4: Activate Wallet */}
          <button
            onClick={handleInitiateActivate}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-500/20 via-teal-500/20 to-slate-900 border border-emerald-400/50 hover:border-emerald-300 text-left transition-all hover:scale-102 cursor-pointer shadow-md group"
          >
            <div className="flex items-center justify-between mb-2">
              <Zap className="w-5 h-5 text-emerald-400 animate-pulse" />
              <span className="text-[9px] font-mono text-emerald-300 font-bold bg-emerald-500/20 px-1.5 py-0.5 rounded">PIN PROTECTED</span>
            </div>
            <div className="text-xs font-black text-emerald-100 font-serif">ACTIVATE WALLET</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Link Mining & Bank accounts</div>
          </button>

          {/* Action 5: Delete Wallet */}
          <button
            onClick={handleInitiateDelete}
            className="p-3.5 rounded-2xl bg-rose-950/30 hover:bg-rose-950/50 border border-rose-500/40 hover:border-rose-400 text-left transition-all hover:scale-102 cursor-pointer shadow-md group"
          >
            <div className="flex items-center justify-between mb-2">
              <Trash2 className="w-5 h-5 text-rose-400 group-hover:scale-110 transition-transform" />
              <span className="text-[9px] font-mono text-rose-300 font-bold bg-rose-500/20 px-1.5 py-0.5 rounded">PIN PROTECTED</span>
            </div>
            <div className="text-xs font-black text-rose-100 font-serif">DELETE WALLET</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Permanently wipe local keys</div>
          </button>
        </div>
      </div>

      {/* SECTION: JMEARNINGS DASHBOARD */}
      <JMEarningsDashboard />

      {/* SECTION: STAKE JMC & PROPHETIC REWARDS */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-mono font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>JM-WALLET STAKING ENGINE & PROPHETIC REWARDS</span>
            </div>
            <h2 className="text-2xl font-bold font-serif text-amber-100">Lock JMC to Earn Prophetic Rewards Multiplier</h2>
            <p className="text-xs text-slate-300">
              Lock your JMC in sovereign device storage for a fixed horizon to earn high APY yields and passive prophetic multipliers.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-amber-500/30 font-mono text-xs text-right space-y-1 shrink-0">
            <div className="text-amber-300 font-bold">Total Staked: <strong className="text-white">{stakedBalance.toFixed(4)} JMC</strong></div>
            <div className="text-emerald-400">Active Positions: <strong className="text-white">{stakePositions.filter(p => p.status === 'ACTIVE').length}</strong></div>
          </div>
        </div>

        {/* Staking Form */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 bg-slate-950/80 p-5 rounded-2xl border border-amber-500/30 space-y-4 font-mono">
            <div className="space-y-1.5">
              <label className="text-xs text-amber-300 font-bold block">Amount to Stake (JMC)</label>
              <input
                type="number"
                step="0.0001"
                min="0.0001"
                value={stakeInputAmount}
                onChange={e => setStakeInputAmount(e.target.value)}
                className="w-full bg-slate-900 border border-amber-500/40 rounded-xl px-4 py-3 text-sm text-amber-100 font-bold focus:outline-none focus:border-amber-400"
              />
              <span className="text-[10px] text-slate-400">Available Balance: <strong className="text-white">{jmcBalance.toFixed(4)} JMC</strong></span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-amber-300 font-bold block">Lock Horizon</label>
              <div className="grid grid-cols-2 gap-2">
                {[30, 90, 180, 365].map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setStakeHorizonDays(days)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all ${
                      stakeHorizonDays === days
                        ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                        : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-amber-500/40'
                    }`}
                  >
                    {days} Days ({days === 365 ? '250% APY' : days === 180 ? '120% APY' : days === 90 ? '77.7% APY' : '35% APY'})
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleStakeJmc}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase shadow-lg shadow-amber-500/30 cursor-pointer transition-transform hover:scale-102"
            >
              Lock & Stake JMC Now
            </button>
          </div>

          {/* Active Staked Positions List */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider">Your Active Staking Vault Positions</h3>
            {stakePositions.length === 0 ? (
              <div className="text-center py-12 bg-slate-950/60 rounded-2xl border border-slate-800 text-slate-400 text-xs font-mono">
                No active staking positions found. Lock JMC above to start earning Prophetic Rewards.
              </div>
            ) : (
              <div className="space-y-3">
                {stakePositions.map((pos) => (
                  <div key={pos.id} className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-amber-100 font-bold font-serif text-sm">{pos.amount} JMC Locked</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/30">
                          {pos.horizonDays} Days ({pos.apyPercent}% APY)
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Unlock Date: <strong className="text-slate-200">{pos.unlockDate}</strong> • Prophetic Multiplier: <strong className="text-emerald-400">{pos.propheticMultiplier}x</strong>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-end">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block">Claimable Rewards</span>
                        <strong className="text-emerald-400 font-bold">{pos.earnedRewards.toFixed(4)} JMC</strong>
                      </div>
                      <button
                        onClick={() => handleClaimStakeRewards(pos.id)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md cursor-pointer transition-transform hover:scale-102"
                      >
                        Claim Rewards
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SECTION: JM EARNINGS DASHBOARD */}
      <JMEarningsDashboard />

      {/* SECTION: COMMUNITY PRAYER WALL */}
      <CommunityPrayerWall onJoinPrayerReward={handleJoinPrayerReward} />

      {/* SECTION: CHECK YOUR JM-CRYPTO WALLET ACCOUNT BALANCE */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/40">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-amber-100 font-serif">
                CHECK YOUR JM-CRYPTO WALLET ACCOUNT BALANCE
              </h2>
              <p className="text-xs text-slate-400">
                100% decentralized ledger stored on-device with official 1 JMC = $35,000 USD / ₦52,500,000 NGN valuation.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleCheckBalance}
              disabled={isRefreshingBalance}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isRefreshingBalance ? 'animate-spin' : ''}`} />
              <span>{isRefreshingBalance ? 'Verifying...' : 'Refresh Balance'}</span>
            </button>
            <button
              onClick={() => handleTriggerBiometricCheck('send')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-xs font-extrabold flex items-center space-x-1.5 transition-all hover:scale-105 cursor-pointer shadow-md"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-950" />
              <span>Send JMC</span>
            </button>
            <button
              onClick={() => {
                setSelectedAddressForQr(wallet.masterAddress);
                setShowReceiveModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 text-xs font-extrabold flex items-center space-x-1.5 transition-all hover:scale-105 cursor-pointer shadow-md"
            >
              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400" />
              <span>Receive JMC</span>
            </button>
            <button
              onClick={() => {
                setSelectedAddressForQr(wallet.masterAddress);
                setShowReceiveModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold flex items-center space-x-1.5 transition-all hover:scale-105 cursor-pointer shadow-md"
            >
              <QrCode className="w-3.5 h-3.5 text-white" />
              <span>Show QR Address</span>
            </button>
          </div>
        </div>

        {/* Balance Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Primary Available Balance */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-amber-500/30 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Primary Wallet Balance</span>
              <Coins className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-3xl font-black font-mono text-amber-300">
              {jmcBalance.toFixed(4)} <span className="text-sm font-bold text-amber-400">JMC</span>
            </div>
            <div className="text-xs font-bold text-emerald-400">
              ≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString()} USD
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              ₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()} NGN
            </div>
          </div>

          {/* Unclaimed Mining Reward (50% Device Share) */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-yellow-500/30 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Mining App Device Share (50%)</span>
              <Cpu className="w-4 h-4 text-yellow-400 animate-spin-slow" />
            </div>
            <div className="text-3xl font-black font-mono text-yellow-300">
              +{unclaimedMined.toFixed(4)} <span className="text-sm font-bold text-yellow-400">JMC</span>
            </div>
            <div className="text-xs font-bold text-yellow-400/90">
              ≈ ${(unclaimedMined * JMC_USD_PRICE).toLocaleString()} USD
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              Auto-syncs from JM-Mining Rig
            </div>
          </div>

          {/* Total Portfolio Valuation */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-emerald-500/30 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Total Portfolio Valuation</span>
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black font-mono text-emerald-300">
              ${((jmcBalance + unclaimedMined) * JMC_USD_PRICE).toLocaleString()}
            </div>
            <div className="text-xs font-bold text-amber-300">
              ₦{((jmcBalance + unclaimedMined) * JMC_NGN_PRICE).toLocaleString()} NGN
            </div>
            <div className="text-[10px] text-emerald-400 font-mono">
              100% Certified 1:1 Treasury Peg
            </div>
          </div>

          {/* Master Public Address Preview */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Master Address</span>
                <Key className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="font-mono text-xs text-indigo-200 mt-2 break-all bg-slate-900 p-2 rounded-xl border border-slate-800">
                {wallet.masterAddress || 'Wallet not created'}
              </div>
            </div>
            <div className="flex items-center space-x-2 pt-1">
              <button
                onClick={() => copyToClipboard(wallet.masterAddress, 'Master Address')}
                className="flex-1 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-[10px] font-bold flex items-center justify-center space-x-1"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedKey === 'Master Address' ? 'Copied' : 'Copy Address'}</span>
              </button>
              <button
                onClick={() => setShowSeedModal(true)}
                className="py-1.5 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 text-[10px] font-bold border border-amber-500/30"
              >
                Seed Backup
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION: GENERATE NEW WALLET ADDRESS (FOR SENDING & RECEIVING) */}
      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-400/40">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-indigo-100 font-serif">
                GENERATE NEW WALLET ADDRESS
              </h2>
              <p className="text-xs text-slate-400">
                Generate fresh, disposable or labeled JMC addresses for every new send/receive transaction to enhance privacy.
              </p>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
            {wallet.derivedAddresses.length} Addresses Derived
          </span>
        </div>

        {/* Generate New Address Creator Form */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-indigo-500/30 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-indigo-300 font-bold block mb-1">
                Transaction Address Label:
              </label>
              <input
                type="text"
                value={newAddressLabel}
                onChange={(e) => setNewAddressLabel(e.target.value)}
                placeholder="e.g. Offering Seed, Mining Payout, Partner Exchange..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-400 font-medium"
              />
            </div>
            <div>
              <label className="text-xs text-indigo-300 font-bold block mb-1">
                Transaction Purpose / Note:
              </label>
              <input
                type="text"
                value={newAddressNote}
                onChange={(e) => setNewAddressNote(e.target.value)}
                placeholder="e.g. Receiving JMC from Brother Emmanuel..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-400 font-medium"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              onClick={handleGenerateNewAddress}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-xs flex items-center space-x-2 shadow-lg shadow-indigo-500/30 transition-all hover:scale-102 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>GENERATE NEW ADDRESS NOW</span>
            </button>
          </div>
        </div>

        {/* Generated Addresses Table */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Your Active Generated JMC Addresses ({wallet.derivedAddresses.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                  <th className="py-2.5 px-3">Address Label & Purpose</th>
                  <th className="py-2.5 px-3">Public Address</th>
                  <th className="py-2.5 px-3">Created</th>
                  <th className="py-2.5 px-3">Usage</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {wallet.derivedAddresses.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-950/60 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-bold text-amber-200 font-sans">{item.label}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{item.note}</div>
                    </td>
                    <td className="py-3 px-3">
                      <code className="text-indigo-300 font-mono text-[11px] select-all">
                        {item.address}
                      </code>
                    </td>
                    <td className="py-3 px-3 text-[10px] text-slate-400">
                      {item.createdAt}
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-emerald-400 font-bold">
                        {item.usageCount} txs
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        <button
                          onClick={() => copyToClipboard(item.address, item.label)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/20 text-[10px] flex items-center space-x-1"
                          title="Copy Address"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedAddressForQr(item.address);
                            setShowReceiveModal(true);
                          }}
                          className="p-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-400/30 text-[10px] flex items-center space-x-1"
                          title="View QR Code"
                        >
                          <QrCode className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* SECTION: STAKE JMC CARD */}
      <div className="bg-slate-900/90 border border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-purple-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-400/40">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-purple-100 font-serif">
                STAKE JMC (77.7% APY SPIRITUAL GROWTH REWARDS)
              </h2>
              <p className="text-xs text-slate-400">
                Lock your JMC in the covenant staking vault to earn passive prophetic harvest rewards.
              </p>
            </div>
          </div>

          <div className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-400/30">
            Staked: {stakedBalance.toFixed(4)} JMC
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1 text-xs">
                <span className="text-slate-300 font-bold">Amount to Stake (JMC):</span>
                <span className="text-amber-300 font-mono">Available: {jmcBalance.toFixed(4)} JMC</span>
              </div>
              <div className="flex space-x-2">
                <input
                  type="number"
                  step="0.0001"
                  min="0.0001"
                  max={jmcBalance}
                  value={stakeInputAmount}
                  onChange={(e) => setStakeInputAmount(e.target.value)}
                  className="flex-1 bg-slate-950 border border-purple-500/40 rounded-xl px-4 py-2.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-purple-400"
                />
                <button
                  onClick={handleStakeJmc}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs uppercase shadow-lg shadow-purple-500/30 cursor-pointer"
                >
                  Stake JMC
                </button>
              </div>
            </div>

            {/* Interactive Horizon Slider */}
            <div className="space-y-2 bg-slate-950 p-4 rounded-2xl border border-purple-500/20">
              <div className="flex justify-between items-center text-xs">
                <span className="text-purple-300 font-bold">Staking Horizon:</span>
                <span className="text-amber-300 font-mono font-bold">{stakeHorizonDays} Days</span>
              </div>
              <input
                type="range"
                min="30"
                max="365"
                step="30"
                value={stakeHorizonDays}
                onChange={(e) => setStakeHorizonDays(parseInt(e.target.value, 10))}
                className="w-full accent-purple-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <button onClick={() => setStakeHorizonDays(30)} className="hover:text-purple-300">30 Days</button>
                <button onClick={() => setStakeHorizonDays(90)} className="hover:text-purple-300">90 Days</button>
                <button onClick={() => setStakeHorizonDays(180)} className="hover:text-purple-300">180 Days</button>
                <button onClick={() => setStakeHorizonDays(365)} className="hover:text-purple-300">365 Days</button>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-300">
                <span>Staking Horizon Progress ({stakeHorizonDays} Days):</span>
                <span className="text-emerald-400">77.7% APY Yield</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div className="bg-gradient-to-r from-purple-500 to-emerald-400 h-full rounded-full transition-all" style={{ width: `${Math.min(100, (stakeHorizonDays / 365) * 100)}%` }} />
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-5 rounded-2xl border border-purple-500/20 space-y-3">
            <div className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center justify-between">
              <span>Reward Projection</span>
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px]">77.7% APY</span>
            </div>
            <div className="text-2xl font-black font-mono text-emerald-300">
              +{((parseFloat(stakeInputAmount) || 0) * 0.777 * (stakeHorizonDays / 365)).toFixed(4)} <span className="text-xs text-amber-300 font-bold">JMC</span>
            </div>
            <div className="text-xs text-slate-300 font-mono">
              Total Return at End of {stakeHorizonDays} Days: <strong className="text-white">{( (parseFloat(stakeInputAmount) || 0) + ((parseFloat(stakeInputAmount) || 0) * 0.777 * (stakeHorizonDays / 365)) ).toFixed(4)} JMC</strong>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed pt-1 border-t border-slate-800">
              Calculated using compound prophetic harvest rewards over {stakeHorizonDays} days at certified 77.7% APY rate.
            </p>
          </div>
        </div>
      </div>

      {/* SECTION: MINI D3.JS / SVG 7-DAY JMC PRICE CHART */}
      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-400/40">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-indigo-100 font-serif">
                JMC 7-DAY HISTORICAL PRICE MOVEMENT (D3 ANALYTICS)
              </h2>
              <p className="text-xs text-slate-400">
                Visualizing JMC treasury token valuation trend from $32,000 to $35,000 USD over the last 7 days.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
            +9.37% (7D Trend)
          </span>
        </div>

        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
          <div className="h-44 w-full flex items-end justify-between px-2 pt-6 pb-2 relative">
            <svg className="absolute inset-0 w-full h-full p-4 overflow-visible" viewBox="0 0 700 140" preserveAspectRatio="none">
              <defs>
                <linearGradient id="jmcGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path
                d="M 0 110 Q 116 90 233 70 Q 350 80 466 40 Q 583 25 700 10 L 700 140 L 0 140 Z"
                fill="url(#jmcGrad)"
              />
              <path
                d="M 0 110 Q 116 90 233 70 Q 350 80 466 40 Q 583 25 700 10"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="3"
              />
            </svg>

            {[
              { day: 'Mon', price: '$32,000' },
              { day: 'Tue', price: '$32,800' },
              { day: 'Wed', price: '$33,200' },
              { day: 'Thu', price: '$34,100' },
              { day: 'Fri', price: '$33,900' },
              { day: 'Sat', price: '$34,600' },
              { day: 'Sun', price: '$35,000' }
            ].map((pt, idx) => (
              <div key={idx} className="z-10 flex flex-col items-center group relative">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400 border-2 border-slate-950 shadow-lg group-hover:scale-150 transition-transform" />
                <span className="text-[10px] text-slate-400 font-mono mt-2">{pt.day}</span>
                <div className="absolute -top-8 bg-slate-900 border border-amber-500/40 text-amber-200 text-[10px] font-mono px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl">
                  {pt.price}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SECTION: JMC TRANSACTION HISTORY CARD */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/40">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-amber-100 font-serif">
                JMC TRANSACTION HISTORY (LOCAL STORAGE)
              </h2>
              <p className="text-xs text-slate-400">
                Scrollable ledger of sent and received JMC cryptocurrency transfers stored securely on-device.
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 flex-wrap gap-2">
            <button
              onClick={handleExportJson}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Export Transaction History as JSON File Backup"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export JSON Backup</span>
            </button>
            <button
              onClick={handleExportCsv}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Export Transaction History as CSV Report for Tax Preparation"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Export CSV Tax Report</span>
            </button>
            <input
              type="file"
              accept=".json"
              ref={fileInputRef}
              onChange={handleImportJson}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Import JMC Transaction History JSON Backup"
            >
              <Upload className="w-3.5 h-3.5 text-indigo-400" />
              <span>Import JSON Backup</span>
            </button>
            <button
              onClick={handleDownloadTransactionPdfTxt}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Download Printable Text Document / Ledger"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Download Transaction PDF</span>
            </button>
            <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
              {transactions.length} Total
            </span>
          </div>
        </div>

        <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
          {transactions.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500 font-mono">
              No recent transactions recorded. Send or receive JMC to populate history.
            </div>
          ) : (
            transactions.map((tx) => (
              <div key={tx.id} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between gap-3 hover:border-amber-500/40 transition-all">
                <div className="flex items-center space-x-3.5">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    tx.type === 'SEND' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  }`}>
                    {tx.type === 'SEND' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center space-x-2">
                      <span>{tx.type === 'SEND' ? 'Sent JMC' : 'Received JMC'}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-900 text-[9px] font-mono text-amber-300 border border-slate-800">
                        {tx.status}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-indigo-300 truncate max-w-xs sm:max-w-md mt-0.5">
                      {tx.address}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className={`text-sm font-black font-mono ${tx.type === 'SEND' ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {tx.type === 'SEND' ? '-' : '+'}{tx.amount.toFixed(4)} JMC
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {tx.timestamp}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* SECTION: JM-GLOBAL-TRADE EXCHANGE HISTORY */}
      <div className="bg-slate-900/90 border border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-purple-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-400/40">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-purple-100 font-serif">
                JM-GLOBAL-TRADE EXCHANGE HISTORY (THIRD-PARTY)
              </h2>
              <p className="text-xs text-slate-400">
                Logged records of successful interactions and secure navigation to verified external crypto exchanges.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-400/30">
            {tradeHistory.length} Interactions
          </span>
        </div>

        <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
          {tradeHistory.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500 font-mono">
              No exchange trade records yet. Explore JM-GLOBAL-TRADE to connect with verified platforms.
            </div>
          ) : (
            tradeHistory.map((th) => (
              <div key={th.id} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between gap-3 hover:border-purple-500/40 transition-all">
                <div className="flex items-center space-x-3.5">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center">
                    🌐
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center space-x-2">
                      <span>{th.exchangeName}</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-[9px] font-mono text-emerald-300 border border-emerald-400/30">
                        {th.safetyScore}% Safety
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-indigo-300 truncate max-w-xs sm:max-w-md mt-0.5">
                      {th.exchangeUrl}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-mono text-emerald-400 font-bold">
                    {th.status}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {th.timestamp}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* SECTION: BIOMETRIC SECURITY SETTINGS */}
      <div className="bg-slate-900/90 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/40">
              <Fingerprint className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-emerald-100 font-serif">
                BIOMETRIC SECURITY (FINGERPRINT / PASSKEY)
              </h2>
              <p className="text-xs text-slate-400">
                Gate access to &apos;Send JMC&apos; and &apos;Delete Wallet&apos; actions using browser Credential Management API & simulated fingerprint scanner.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-xs font-bold text-slate-300">
              {biometricEnabled ? 'ENABLED' : 'DISABLED'}
            </span>
            <button
              onClick={handleToggleBiometric}
              className={`w-14 h-8 rounded-full p-1 transition-colors relative cursor-pointer ${biometricEnabled ? 'bg-emerald-500' : 'bg-slate-800'}`}
            >
              <div className={`w-6 h-6 rounded-full bg-white shadow-md transition-transform ${biometricEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: ACTIVATE WALLET & SEAMLESS MULTI-APP INTEGRATION */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-950 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/40">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-emerald-100 font-serif">
                ACTIVATE WALLET (AUTOMATIC CROSS-ENGINE INTEGRATION)
              </h2>
              <p className="text-xs text-slate-300">
                Activates and links your JMC Wallet directly with the JM-CRYPTO MINING APP, Web3 external wallets, and mobile bank settlement accounts.
              </p>
            </div>
          </div>

          <button
            onClick={handleActivateWallet}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase flex items-center space-x-2 shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4 text-slate-950" />
            <span>ACTIVATE ALL INTEGRATIONS</span>
          </button>
        </div>

        {/* 3 Active Integration Panels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Integration 1: Mining App */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <Cpu className="w-4 h-4" />
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400">
                CONNECTED
              </span>
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-100 font-serif">JM-Crypto Mining Rig</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Your 50% device miner rewards are automatically deposited into your JMC Wallet address.
              </p>
            </div>
            <button
              onClick={onNavigateToMining}
              className="text-[11px] text-amber-400 font-bold hover:underline flex items-center space-x-1"
            >
              <span>Open Mining App</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          {/* Integration 2: External Crypto Wallets */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-indigo-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                <Layers className="w-4 h-4" />
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400">
                LINKED (500+)
              </span>
            </div>
            <div>
              <h4 className="text-sm font-bold text-indigo-100 font-serif">Web3 Wallets Bridge</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Linked with MetaMask, Trust Wallet, Coinbase, MiniPay, and Phantom for global swapping.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              EVM • Base • BNB • Solana Bridge
            </div>
          </div>

          {/* Integration 3: Mobile Banking Settlement */}
          <div className="bg-slate-950 p-5 rounded-2xl border border-teal-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                <Smartphone className="w-4 h-4" />
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400">
                ACTIVE
              </span>
            </div>
            <div>
              <h4 className="text-sm font-bold text-teal-100 font-serif">Mobile Banking Clearing</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Connected with OPay, Fidelity Bank, and Moniepoint for zero-gas Nigerian Naira fiat settlement.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              NIBSS Direct Clearing Network
            </div>
          </div>
        </div>
      </div>

      {/* SEED PHRASE BACKUP MODAL */}
      <AnimatePresence>
        {showSeedModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6"
            >
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/40">
                    <Key className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-amber-100 font-serif">
                      12-WORD SOVEREIGN SEED PHRASE
                    </h3>
                    <p className="text-xs text-slate-400">Write these 12 sacred words down safely offline.</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSeedModal(false)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                {wallet.seedPhrase.map((word, i) => (
                  <div key={i} className="bg-slate-900 p-2 rounded-xl text-center border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 font-mono block">{i + 1}</span>
                    <span className="text-xs font-bold text-amber-200 font-mono">{word}</span>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-amber-950/30 border border-amber-500/20 rounded-xl text-[11px] text-amber-200 leading-relaxed">
                <strong>Self-Custodial Guarantee:</strong> These 12 words grant full sovereign control of your JMC assets. Never share them with anyone.
              </div>

              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={() => copyToClipboard(wallet.seedPhrase.join(' '), '12-Word Seed Phrase')}
                  className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase flex items-center justify-center space-x-2"
                >
                  <Copy className="w-4 h-4 text-slate-950" />
                  <span>Copy Seed Phrase</span>
                </button>
                <button
                  onClick={() => setShowSeedModal(false)}
                  className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DELETE WALLET CONFIRMATION MODAL */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-rose-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5 text-center"
            >
              <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border-2 border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto shadow-xl">
                <Trash2 className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-black text-rose-100 font-serif">
                  PERMANENTLY DELETE WALLET?
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  This action will completely wipe your local private keys, seed phrase, and derived addresses from this device. 
                  Ensure you have backed up your 12-word seed phrase before proceeding!
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleDeleteWallet}
                  className="py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase shadow-lg shadow-rose-600/30"
                >
                  Confirm Delete
                </button>
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* RECEIVE JMC QR MODAL */}
      <AnimatePresence>
        {showReceiveModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-4 text-center"
            >
              <div className="flex justify-between items-center border-b border-amber-500/20 pb-3">
                <h3 className="text-sm font-bold font-serif text-amber-100">
                  RECEIVE JM-CRYPTO
                </h3>
                <button onClick={() => setShowReceiveModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-white p-4 rounded-2xl mx-auto w-52 h-52 flex items-center justify-center shadow-inner">
                <QRCodeSVG
                  value={selectedAddressForQr || wallet.masterAddress}
                  size={180}
                  level="H"
                  includeMargin={true}
                />
              </div>

              <div className="text-[11px] font-mono text-amber-300 break-all p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                {selectedAddressForQr || wallet.masterAddress}
              </div>

              <button
                onClick={() => {
                  copyToClipboard(selectedAddressForQr || wallet.masterAddress, 'Receive Address');
                  setShowReceiveModal(false);
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase"
              >
                Copy Address & Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SEND JMC MODAL */}
      <AnimatePresence>
        {showSendModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-amber-500/20 pb-3">
                <div className="flex items-center space-x-2 text-amber-200">
                  <ArrowUpRight className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-bold font-serif">SEND JM-CRYPTO</h3>
                </div>
                <button onClick={() => setShowSendModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSendJmc} className="space-y-4">
                <div>
                  <label className="text-xs text-slate-300 font-bold block mb-1">
                    Recipient JMC Wallet Address:
                  </label>
                  <input
                    type="text"
                    required
                    value={recipientAddress}
                    onChange={(e) => setRecipientAddress(e.target.value)}
                    placeholder="0x..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="text-slate-300 font-bold">Amount (JMC):</span>
                    <span className="text-amber-400 font-mono">Available: {jmcBalance.toFixed(4)} JMC</span>
                  </div>
                  <input
                    type="number"
                    step="0.0001"
                    min="0.0001"
                    max={jmcBalance}
                    required
                    value={sendAmountJmc}
                    onChange={(e) => setSendAmountJmc(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white font-mono font-bold focus:border-amber-400 focus:outline-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>≈ ${(parseFloat(sendAmountJmc || '0') * JMC_USD_PRICE).toLocaleString()} USD</span>
                    <span>₦{(parseFloat(sendAmountJmc || '0') * JMC_NGN_PRICE).toLocaleString()} NGN</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSending}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/30 disabled:opacity-50"
                  >
                    <ArrowUpRight className="w-4 h-4 text-slate-950" />
                    <span>{isSending ? 'Sending JMC...' : 'CONFIRM & SEND JMC'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SECURITY PIN PROMPT MODAL FOR ACTIVATE / DELETE */}
      <AnimatePresence>
        {showPinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl space-y-5 text-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border-2 border-amber-400/40 text-amber-400 flex items-center justify-center mx-auto shadow-lg">
                <Lock className="w-7 h-7" />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-black text-amber-100 font-serif">
                  SECURITY PIN REQUIRED
                </h3>
                <p className="text-xs text-slate-300">
                  Enter your sovereign 4-digit security PIN (Default: <code className="text-amber-300 font-mono font-bold">7777</code>) to authorize {pinActionType === 'delete' ? 'Wallet Deletion' : 'Wallet Activation'}.
                </p>
              </div>

              <form onSubmit={handleVerifyPinAndExecute} className="space-y-4">
                <div>
                  <input
                    type="password"
                    maxLength={6}
                    autoFocus
                    required
                    value={enteredPin}
                    onChange={(e) => setEnteredPin(e.target.value)}
                    placeholder="Enter PIN (7777)"
                    className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-3 text-center text-lg text-amber-200 font-mono font-bold tracking-widest focus:outline-none focus:border-amber-400"
                  />
                  {pinError && (
                    <div className="text-[11px] text-rose-400 font-bold mt-1.5">{pinError}</div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    type="submit"
                    className="py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase shadow-lg shadow-amber-500/20 cursor-pointer"
                  >
                    Confirm PIN
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPinModal(false)}
                    className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* SIMULATED BIOMETRIC FINGERPRINT SCANNER MODAL */}
      <AnimatePresence>
        {showBiometricModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-emerald-500/50 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl space-y-6 text-center"
            >
              <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400/50 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/20 relative cursor-pointer"
                onClick={handleSimulateBiometricScan}
              >
                <Fingerprint className={`w-10 h-10 ${isScanningBiometric ? 'animate-pulse text-emerald-300' : 'text-emerald-400'}`} />
                {isScanningBiometric && (
                  <div className="absolute inset-0 border-2 border-emerald-400 rounded-full animate-ping pointer-events-none" />
                )}
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-black text-emerald-100 font-serif">
                  TOUCH SENSOR OR SCAN FINGERPRINT
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isScanningBiometric 
                    ? 'Verifying biometric passkey with hardware secure enclave...' 
                    : 'Tap the fingerprint icon above or use your device passkey to authorize this secure transaction.'}
                </p>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <button
                  disabled={isScanningBiometric}
                  onClick={handleSimulateBiometricScan}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs uppercase shadow-lg shadow-emerald-500/30 cursor-pointer disabled:opacity-50"
                >
                  {isScanningBiometric ? 'Scanning Biometric...' : 'Simulate Successful Scan'}
                </button>
                <button
                  disabled={isScanningBiometric}
                  onClick={() => setShowBiometricModal(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
