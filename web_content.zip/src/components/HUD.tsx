import React, { useState } from 'react';
import { Mission, Language, CharacterId } from '../types/game';

interface HUDProps {
  currentMission: Mission;
  collectedMissionItemsCount: number;
  totalMissionItemsCount: number;
  coins: number;
  stars: number;
  language: Language;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleLanguage: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onOpenPause: () => void;
  nearTarget: { id: string; name: string; type: 'character' | 'item'; characterId?: CharacterId } | null;
  onInteract: () => void;
  onResetPosition: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  currentMission,
  collectedMissionItemsCount,
  totalMissionItemsCount,
  coins,
  stars,
  language,
  soundEnabled,
  musicEnabled,
  onToggleLanguage,
  onToggleSound,
  onToggleMusic,
  onOpenPause,
  nearTarget,
  onInteract,
  onResetPosition,
}) => {
  const [dockCollapsed, setDockCollapsed] = useState(false);

  const missionTitle = currentMission.title[language];
  const missionDesc = currentMission.description[language];
  const progressPercent = Math.min(
    100,
    Math.round((collectedMissionItemsCount / Math.max(1, totalMissionItemsCount)) * 100)
  );

  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-4 md:p-6 select-none">
      {/* =========================================
          TOP PERIMETER BAR
      ========================================= */}
      <div className="flex items-start justify-between w-full">
        {/* Top-Left: Player Badge & Stats Cluster */}
        <div className="pointer-events-auto flex items-center gap-3 bg-slate-950/80 border border-amber-500/30 rounded-2xl p-2.5 shadow-lg">
          {/* Ayush Avatar */}
          <div className="w-11 h-11 rounded-xl bg-sky-600 border border-sky-300 flex items-center justify-center text-xl shadow-inner font-bold text-white">
            🧢
          </div>

          <div className="flex flex-col">
            <div className="text-xs font-bold text-sky-300 tracking-wide">AYUSH (HERO)</div>
            <div className="flex items-center gap-3 text-xs font-semibold tabular-nums">
              <span className="flex items-center gap-1 text-amber-300">
                <span>🪙</span> {coins}
              </span>
              <span className="flex items-center gap-1 text-amber-400">
                <span>⭐</span> {stars}
              </span>
            </div>
          </div>
        </div>

        {/* Top-Center: Current Mission Objective Pill */}
        <div className="pointer-events-auto hidden md:flex flex-col items-center max-w-md bg-slate-950/85 border border-amber-500/40 rounded-2xl px-5 py-2.5 shadow-xl text-center">
          <div className="text-xs font-extrabold text-amber-400 uppercase tracking-wider">
            {missionTitle}
          </div>
          <div className="text-xs text-slate-300 truncate max-w-xs">{missionDesc}</div>
          {/* Progress bar */}
          <div className="w-full bg-slate-800 rounded-full h-2 mt-1.5 overflow-hidden border border-slate-700">
            <div
              className="bg-amber-400 h-full transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="text-[10px] text-amber-200 mt-1 font-semibold tabular-nums">
            {collectedMissionItemsCount} / {totalMissionItemsCount} Objectives
          </div>
        </div>

        {/* Top-Right: Controls Cluster (Lang, Audio, Pause) */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Language Switcher */}
          <button
            onClick={onToggleLanguage}
            className="px-3 py-1.5 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-amber-400/40 text-xs font-extrabold text-amber-300 active:scale-95 shadow transition-all"
            title="Switch Language (Hinglish / English)"
          >
            {language === 'hinglish' ? '🇮🇳 Hinglish' : '🇬🇧 English'}
          </button>

          {/* Music Toggle */}
          <button
            onClick={onToggleMusic}
            className={`w-9 h-9 rounded-xl border flex items-center justify-center text-sm shadow transition-all active:scale-95 ${
              musicEnabled
                ? 'bg-slate-900/85 border-amber-400/40 text-amber-300'
                : 'bg-red-950/80 border-red-500/40 text-red-300'
            }`}
            title="Toggle Music"
          >
            {musicEnabled ? '🎵' : '🔇'}
          </button>

          {/* SFX Toggle */}
          <button
            onClick={onToggleSound}
            className={`w-9 h-9 rounded-xl border flex items-center justify-center text-sm shadow transition-all active:scale-95 ${
              soundEnabled
                ? 'bg-slate-900/85 border-amber-400/40 text-amber-300'
                : 'bg-red-950/80 border-red-500/40 text-red-300'
            }`}
            title="Toggle Sound Effects"
          >
            {soundEnabled ? '🔊' : '🔈'}
          </button>

          {/* Pause Button */}
          <button
            onClick={onOpenPause}
            className="w-9 h-9 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 border border-amber-300 font-extrabold flex items-center justify-center text-sm shadow transition-all active:scale-95"
            title="Pause Game"
          >
            ⏸
          </button>
        </div>
      </div>

      {/* =========================================
          INTERACTION PROMPT (When near NPC / Item)
      ========================================= */}
      {nearTarget && (
        <div className="pointer-events-auto self-center mb-6 animate-bounce">
          <button
            onClick={onInteract}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black shadow-2xl border-2 border-white flex items-center gap-3 transition-transform active:scale-95 text-sm md:text-base"
          >
            <span className="text-xl">✨</span>
            <span>
              {nearTarget.type === 'character' ? (language === 'hinglish' ? `Baat karo [E]: ${nearTarget.name}` : `Talk [E]: ${nearTarget.name}`) : (language === 'hinglish' ? `Uthao [E]: ${nearTarget.name}` : `Collect [E]: ${nearTarget.name}`)}
            </span>
          </button>
        </div>
      )}

      {/* =========================================
          COLLAPSIBLE BOTTOM DOCK (Three.js Skill Mandate)
          Consolidated, zero side occlusion, collapsible Zen mode
      ========================================= */}
      <div className="pointer-events-auto self-center flex flex-col items-center">
        {/* Toggle Collapse Button */}
        <button
          onClick={() => setDockCollapsed(!dockCollapsed)}
          className="mb-1 text-[11px] font-bold px-3 py-1 rounded-t-xl bg-slate-950/90 text-amber-300 border-t border-x border-amber-500/30 hover:bg-slate-900 transition-colors"
        >
          {dockCollapsed ? '▴ Show Mission Dock' : '▾ Hide Controls / Zen Mode'}
        </button>

        {!dockCollapsed && (
          <div className="w-full max-w-xl bg-slate-950/90 border border-amber-500/40 rounded-2xl px-5 py-3 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-3 text-slate-200">
            {/* Mission Clue / Details */}
            <div className="flex-1 text-center md:text-left">
              <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wide">
                Active Objective:
              </div>
              <div className="text-xs font-medium text-slate-300">
                {currentMission.subtitle[language]}
              </div>
            </div>

            {/* Quick Helper Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={onResetPosition}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold border border-slate-600 text-amber-200 active:scale-95 transition-all"
                title="Return Ayush to Living Room Center"
              >
                🏠 Living Room
              </button>
              <div className="hidden sm:block text-[10px] text-slate-400 px-2 py-1 bg-slate-900 rounded-lg border border-slate-800 font-mono">
                WASD / Arrows · Space Jump · E Act
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
