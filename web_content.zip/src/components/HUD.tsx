import React from "react";
import { Player, WeatherType, SeasonType, UiCustomizationSettings } from "../types";
import { SEASONS_DATA } from "../game/constants";
import {
  Hammer,
  Store,
  Coins,
  Sun,
  Moon,
  CloudRain,
  CloudFog,
  Award,
  Zap,
  Settings,
  Package,
} from "lucide-react";

interface HUDProps {
  player: Player;
  gameDay: number;
  dayTime: number;
  weather: WeatherType;
  season: SeasonType;
  settings: UiCustomizationSettings;
  isLandscape?: boolean;
  isHoldingHand?: boolean;
  inDeepKochubon?: boolean;
  inCampfireZone?: boolean;
  fps?: number;
  onOpenBackpack: () => void;
  onOpenCrafting: () => void;
  onOpenShop: () => void;
  onOpenAwards: () => void;
  onOpenSettings: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  player,
  gameDay,
  dayTime,
  weather,
  season,
  settings,
  isLandscape = false,
  isHoldingHand = false,
  inDeepKochubon = false,
  inCampfireZone = true,
  fps = 60,
  onOpenBackpack,
  onOpenCrafting,
  onOpenShop,
  onOpenAwards,
  onOpenSettings,
}) => {
  const isNight = dayTime > 0.65 && dayTime < 0.95;
  const currentSeason = SEASONS_DATA[season];

  // 1. MINIMAL UI MODE
  if (settings.isMinimalMode) {
    return (
      <div className="absolute top-1.5 left-2 right-2 pointer-events-none flex items-center justify-between z-20 select-none">
        {/* Minimal Left Pill */}
        <div className="flex items-center gap-2 bg-stone-950/85 backdrop-blur-md px-3 py-1 rounded-full border border-stone-800 shadow-xl pointer-events-auto">
          <span className="text-emerald-400 font-bold text-xs font-['Hind_Siliguri']">
            কচুবন Remaster
          </span>
          <span className="text-stone-500 text-[10px]">•</span>
          <span className="text-stone-300 text-[10px]">
            {season === "spring"
              ? "🌸"
              : season === "summer"
              ? "☀️"
              : season === "monsoon"
              ? "🌧️"
              : "❄️"}{" "}
            দিন {gameDay}
          </span>
          <span className="text-stone-500 text-[10px]">•</span>
          <span className="flex items-center gap-1 text-yellow-400 font-bold font-mono text-[11px]">
            <Coins className="w-3 h-3" /> {player.coins} Tk
          </span>
          {isHoldingHand && (
            <span className="text-[9px] bg-yellow-500/20 text-yellow-300 px-1 rounded font-bold">
              ✋ শান্ত হাত
            </span>
          )}
          {player.isSprinting && (
            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 rounded font-bold animate-pulse">
              ⚡ দৌড়
            </span>
          )}
          <span className="text-emerald-400 font-mono font-bold text-[10px] bg-emerald-950/90 px-1.5 py-0.2 rounded border border-emerald-700/60">
            🟢 {fps} FPS
          </span>
        </div>

        {/* Minimal Right Quick Controls */}
        <div className="flex items-center gap-1 pointer-events-auto">
          <button
            onClick={onOpenBackpack}
            className="p-1.5 bg-amber-700/90 hover:bg-amber-600 text-white rounded-full border border-amber-500 shadow cursor-pointer transition transform active:scale-95"
            title="ব্যাকপ্যাক [B]"
          >
            <Package className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onOpenSettings}
            className="p-1.5 bg-stone-900/90 hover:bg-stone-800 text-stone-200 rounded-full border border-stone-700 cursor-pointer shadow transition"
            title="সেটিংস [Esc]"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  // 2. STANDARD / LANDSCAPE COMPACT HUD (Clean, Minimal, Modern)
  const isCompact =
    (settings.autoLandscapeSmall && isLandscape) ||
    settings.hudScale === "compact" ||
    settings.hudScale === "ultra_compact";

  return (
    <div
      className={`absolute top-0 left-0 right-0 pointer-events-none flex flex-col gap-1 z-20 select-none transition-all duration-200 ${
        isCompact ? "p-1 scale-95 origin-top" : "p-1.5"
      }`}
    >
      <div className="flex items-center justify-between gap-1 flex-wrap">
        {/* Left: App Title, Player Status & Coins */}
        <div className="flex items-center gap-1.5 bg-stone-900/95 backdrop-blur-md px-2.5 py-1 rounded-xl border border-stone-700/80 pointer-events-auto shadow-md">
          <div className="flex items-center gap-1">
            <span className="text-emerald-400 font-bold text-xs sm:text-sm font-['Hind_Siliguri']">
              কচুবন Remaster
            </span>
            {isLandscape && (
              <span className="text-[8px] bg-emerald-950 text-emerald-300 px-1 py-0.2 rounded border border-emerald-700/50 font-mono">
                Landscape
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] text-stone-300 border-l border-stone-700 pl-2">
            <span className="font-semibold text-amber-300">তোজো</span>
            <span className="flex items-center gap-0.5 text-yellow-400 font-bold font-mono">
              <Coins className="w-3 h-3 text-yellow-400" /> {player.coins} Tk
            </span>

            {/* Hand Peace Indicator */}
            {isHoldingHand && (
              <span className="text-[9px] bg-amber-500/20 text-yellow-300 px-1 rounded flex items-center gap-0.5 font-bold border border-yellow-500/30">
                <span>✋</span>
                <span className="hidden sm:inline">খালি হাত</span>
              </span>
            )}

            {/* Sprint Indicator */}
            {player.isSprinting && (
              <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 rounded flex items-center gap-0.5 font-bold animate-pulse border border-amber-500/40">
                <Zap className="w-2.5 h-2.5" /> দৌড়
              </span>
            )}

            {/* LIVE STAMINA BAR (Depletes on sprint, auto-recharges) */}
            <div
              className="flex items-center gap-1 bg-stone-950/70 px-1.5 py-0.5 rounded-lg border border-stone-800"
              title="স্ট্যামিনা (দৌড়ালে দ্রুত খরচ হয় এবং দাঁড়িয়ে বা হাঁটলে নিজে রিচার্জ হয়)"
            >
              <Zap
                className={`w-3 h-3 ${
                  player.stamina < 20
                    ? "text-rose-500 animate-bounce"
                    : "text-amber-400"
                }`}
              />
              <div className="w-10 sm:w-14 h-1.5 bg-stone-800 rounded-full overflow-hidden border border-stone-700/50">
                <div
                  className={`h-full transition-all duration-75 ${
                    player.stamina < 25
                      ? "bg-rose-500"
                      : player.stamina < 60
                      ? "bg-amber-400"
                      : "bg-emerald-400"
                  }`}
                  style={{
                    width: `${Math.max(
                      0,
                      Math.min(
                        100,
                        (player.stamina / (player.maxStamina || 100)) * 100
                      )
                    )}%`,
                  }}
                />
              </div>
              <span className="font-mono text-[8px] sm:text-[9px] text-stone-300 min-w-[18px] text-right">
                {Math.round(player.stamina)}%
              </span>
            </div>
          </div>
        </div>

        {/* Center: Season, Weather, Day Counter, Zone Badge & 60 FPS */}
        <div className="flex items-center gap-1.5 bg-stone-900/95 backdrop-blur-md px-2.5 py-1 rounded-xl border border-stone-700/80 pointer-events-auto shadow-md text-xs">
          {/* Zone Badge (Roblox 99 Nights Campfire vs Deep Kochubon) */}
          <div className="flex items-center gap-1 border-r border-stone-700 pr-1.5">
            {inDeepKochubon ? (
              <span className="text-[10px] font-bold text-emerald-300 bg-emerald-950/90 border border-emerald-600/70 px-1.5 py-0.5 rounded flex items-center gap-0.5 animate-pulse">
                <span>🌲</span>
                <span className="font-['Hind_Siliguri']">গভীর কচুবন</span>
              </span>
            ) : inCampfireZone ? (
              <span className="text-[10px] font-bold text-amber-300 bg-amber-950/90 border border-amber-600/70 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                <span>🔥</span>
                <span className="font-['Hind_Siliguri']">ক্যাম্পফায়ার</span>
              </span>
            ) : (
              <span className="text-[10px] font-bold text-stone-300 px-1 py-0.5 rounded flex items-center gap-0.5 font-['Hind_Siliguri']">
                <span>🏡</span>
                <span>গ্রাম</span>
              </span>
            )}
          </div>

          {/* Season badge */}
          <div className="flex items-center gap-1 border-r border-stone-700 pr-1.5">
            <span className="text-[10px] sm:text-[11px]">
              {season === "spring"
                ? "🌸"
                : season === "summer"
                ? "☀️"
                : season === "monsoon"
                ? "🌧️"
                : "❄️"}
            </span>
            <span className="text-stone-300 font-bold font-['Hind_Siliguri'] text-[10px] sm:text-[11px]">
              {currentSeason.bengaliName.split(" ")[0]}
            </span>
          </div>

          {/* Weather badge */}
          <div className="flex items-center gap-1 border-r border-stone-700 pr-1.5">
            {weather === "rain" ? (
              <CloudRain className="w-3 h-3 text-sky-400 animate-bounce" />
            ) : weather === "fog" ? (
              <CloudFog className="w-3 h-3 text-slate-300 animate-pulse" />
            ) : (
              <Sun className="w-3 h-3 text-amber-400 animate-spin-slow" />
            )}
            <span className="text-stone-200 font-bold font-['Hind_Siliguri'] text-[10px] sm:text-[11px]">
              {weather === "rain" ? "বৃষ্টি" : weather === "fog" ? "কুয়াশা" : "রোদ"}
            </span>
          </div>

          {/* Day Counter */}
          <div className="flex items-center gap-1 pl-0.5 text-[10px] sm:text-[11px] border-r border-stone-700 pr-1.5">
            {isNight ? (
              <Moon className="w-3 h-3 text-indigo-400" />
            ) : (
              <Sun className="w-3 h-3 text-amber-400" />
            )}
            <span className="font-mono text-stone-300">
              দিন <strong className="text-amber-400">{gameDay}</strong>
            </span>
          </div>

          {/* Rock-solid 60 FPS Badge */}
          <div
            className="flex items-center gap-1 text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-600/50"
            title="Lag-free 60 FPS smooth rendering engine"
          >
            <span>🟢</span>
            <span>{fps} FPS</span>
          </div>
        </div>

        {/* Right: Core Action Buttons (Backpack, Permanent Mustakim Store, Crafting, Roadmap/Awards, Settings) */}
        <div className="flex items-center gap-1 sm:gap-1.5 pointer-events-auto">
          {/* BACKPACK BUTTON */}
          <button
            onClick={onOpenBackpack}
            className="flex items-center gap-1 px-2 py-1 bg-amber-700 hover:bg-amber-600 text-amber-100 rounded-xl border border-amber-500/60 shadow cursor-pointer transition transform active:scale-95 text-[10px] sm:text-xs font-bold"
            title="ব্যাকপ্যাক ইনভেন্টরি [B]"
          >
            <Package className="w-3.5 h-3.5 text-amber-300" />
            <span>ব্যাগ [B]</span>
          </button>

          {/* PERMANENT MUSTAKIM DEVELOPER STORE BUTTON */}
          <button
            onClick={onOpenShop}
            className="flex items-center gap-1 px-2 py-1 bg-teal-700 hover:bg-teal-600 text-teal-100 rounded-xl border border-teal-400/60 shadow cursor-pointer transition transform active:scale-95 text-[10px] sm:text-xs font-bold"
            title="দেপলোপার মুস্তাকিমের দোকান (স্থায়ী)"
          >
            <Store className="w-3.5 h-3.5 text-teal-200" />
            <span>মুস্তাকিম দোকান</span>
          </button>

          {/* CRAFTING BUTTON */}
          <button
            onClick={onOpenCrafting}
            className="flex items-center gap-1 px-2 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-[10px] sm:text-xs font-bold shadow border border-amber-400/60 cursor-pointer transition transform active:scale-95"
            title="ক্রাফটিং মেনু [C]"
          >
            <Hammer className="w-3.5 h-3.5 text-amber-200" />
            <span className="hidden sm:inline">ক্রাফটিং [C]</span>
          </button>

          {/* ROADMAP & AWARDS BUTTON */}
          <button
            onClick={onOpenAwards}
            className="flex items-center gap-1 px-2 py-1 bg-yellow-600/90 hover:bg-yellow-500 text-white rounded-xl text-[10px] sm:text-xs font-bold shadow border border-yellow-400/60 cursor-pointer transition transform active:scale-95"
            title="রোডম্যাপ ও মাইলফলক (Awards & Roadmap)"
          >
            <Award className="w-3.5 h-3.5 text-yellow-200" />
            <span className="hidden sm:inline">রোডম্যাপ</span>
          </button>

          {/* SETTINGS BUTTON (ALL EXTRA UI CONSOLIDATED HERE) */}
          <button
            onClick={onOpenSettings}
            className="p-1 sm:p-1.5 bg-stone-800 hover:bg-stone-700 text-amber-300 hover:text-white rounded-xl border border-stone-600 shadow cursor-pointer transition transform active:scale-95"
            title="গেম সেটিংস ও UI কাস্টমাইজ [Esc / O]"
          >
            <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
