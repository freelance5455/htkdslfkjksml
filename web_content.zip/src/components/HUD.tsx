import { useEffect, useRef, type CSSProperties, type ReactNode } from 'react';
import type { FeedItem, HudState } from '../game/types';

interface HUDProps {
  hud: HudState;
  muted: boolean;
  touch: boolean;
  onPause: () => void;
  onToggleMute: () => void;
}

const fmt = (s: number) => {
  if (!isFinite(s)) return '--:--';
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
};

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="pointer-events-auto grid h-10 w-10 place-items-center rounded-lg bg-black/55 text-white/90 ring-1 ring-white/15 transition active:scale-90 hover:bg-white/15"
    >
      {children}
    </button>
  );
}

function Bar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  return (
    <div className="mb-1.5">
      <div className="mb-0.5 flex justify-between font-display text-[11px] tracking-[0.2em] text-white/75">
        <span>{label}</span>
        <span className="tabular-nums">{value}</span>
      </div>
      <div className="h-2.5 overflow-hidden rounded-full bg-black/60 ring-1 ring-white/10">
        <div
          className="h-full rounded-full transition-[width] duration-150"
          style={{ width: `${Math.max(0, Math.min(100, (value / max) * 100))}%`, background: color, boxShadow: `0 0 10px ${color}` }}
        />
      </div>
    </div>
  );
}

function Crosshair({ ads, hitTick, hitHead }: { ads: boolean; hitTick: number; hitHead: boolean }) {
  const g = ads ? 3 : 8;
  const bar: CSSProperties = { position: 'absolute', background: 'rgba(255,255,255,0.92)', boxShadow: '0 0 3px rgba(0,0,0,0.8)' };
  return (
    <div className="pointer-events-none absolute left-1/2 top-1/2">
      <div style={{ ...bar, left: -g - 10, top: -1, width: 8, height: 2 }} />
      <div style={{ ...bar, left: g + 2, top: -1, width: 8, height: 2 }} />
      <div style={{ ...bar, left: -1, top: -g - 10, width: 2, height: 8 }} />
      <div style={{ ...bar, left: -1, top: g + 2, width: 2, height: 8 }} />
      {hitTick > 0 && (
        <svg key={hitTick} className="anim-hit absolute" style={{ left: -14, top: -14 }} width="28" height="28" viewBox="0 0 28 28">
          <g stroke={hitHead ? '#fde047' : '#ffffff'} strokeWidth="2.5" strokeLinecap="round">
            <line x1="7" y1="7" x2="11" y2="11" />
            <line x1="21" y1="7" x2="17" y2="11" />
            <line x1="7" y1="21" x2="11" y2="17" />
            <line x1="21" y1="21" x2="17" y2="17" />
          </g>
        </svg>
      )}
    </div>
  );
}

function Minimap({ data, size }: { data: HudState['minimap']; size: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    const s = size;
    const k = (s / 2 - 6) / data.mapR;
    const cx = s / 2;
    g.clearRect(0, 0, s, s);
    g.save();
    g.beginPath();
    g.arc(cx, cx, s / 2 - 1, 0, Math.PI * 2);
    g.clip();
    g.fillStyle = 'rgba(12,22,18,0.92)';
    g.fillRect(0, 0, s, s);
    g.fillStyle = 'rgba(70,110,60,0.55)';
    g.beginPath();
    g.arc(cx, cx, data.mapR * k, 0, Math.PI * 2);
    g.fill();
    // Zone
    g.fillStyle = 'rgba(56,189,248,0.16)';
    g.strokeStyle = 'rgba(186,230,253,0.95)';
    g.lineWidth = 1.5;
    g.beginPath();
    g.arc(cx + data.zx * k, cx + data.zz * k, data.zr * k, 0, Math.PI * 2);
    g.fill();
    g.stroke();
    g.restore();

    // Player arrow
    const px = cx + data.px * k;
    const py = cx + data.pz * k;
    g.save();
    g.translate(px, py);
    g.rotate(-data.yaw);
    g.fillStyle = '#fbbf24';
    g.strokeStyle = '#0b0f14';
    g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(0, -8);
    g.lineTo(5.5, 6);
    g.lineTo(0, 3);
    g.lineTo(-5.5, 6);
    g.closePath();
    g.fill();
    g.stroke();
    g.restore();

    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = 2;
    g.beginPath();
    g.arc(cx, cx, s / 2 - 1, 0, Math.PI * 2);
    g.stroke();
  }, [data, size]);
  return <canvas ref={ref} width={size} height={size} style={{ width: size, height: size }} className="rounded-full shadow-lg shadow-black/60" />;
}

function Feed({ items }: { items: FeedItem[] }) {
  const tone: Record<FeedItem['tone'], string> = {
    kill: 'text-amber-300',
    death: 'text-rose-400',
    zone: 'text-sky-300',
    neutral: 'text-white/85',
  };
  return (
    <div className="flex flex-col items-end gap-1">
      {items.map((it) => (
        <div key={it.id} className="anim-feed rounded bg-black/55 px-2 py-0.5 text-[12px] font-semibold">
          <span className={tone[it.tone]}>{it.text}</span>
          {it.head && <span className="ml-1 text-yellow-300">HEADSHOT</span>}
          {it.weapon && <span className="ml-1.5 text-white/45">{it.weapon}</span>}
        </div>
      ))}
    </div>
  );
}

export function HUD({ hud, muted, touch, onPause, onToggleMute }: HUDProps) {
  const playing = hud.phase === 'playing' || hud.phase === 'drop';
  const outside = !hud.zone.inside && hud.phase === 'playing';
  const zoneText = !isFinite(hud.zone.timeLeft)
    ? 'FINAL ZONE'
    : hud.zone.shrinking
      ? `ZONE SHRINKING ${fmt(hud.zone.timeLeft)}`
      : `ZONE CLOSES IN ${fmt(hud.zone.timeLeft)}`;
  const w = hud.weapon;
  const mm = touch ? 118 : 150;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 select-none font-body text-white">
      {hud.dmgTick > 0 && <div key={hud.dmgTick} className="anim-dmg absolute inset-0" />}
      {outside && <div className="anim-zone absolute inset-0" />}

      {/* Top-left: alive / kills / system buttons */}
      <div className="absolute left-3 top-3 flex flex-col gap-2 sm:left-5 sm:top-5">
        <div className="flex items-center gap-2 rounded-lg bg-black/55 px-3 py-1 ring-1 ring-white/10">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-orange-400" fill="currentColor" aria-hidden>
            <circle cx="12" cy="7" r="3.5" />
            <path d="M5 21c0-4 3-6.5 7-6.5s7 2.5 7 6.5z" />
          </svg>
          <span className="font-display text-2xl font-bold leading-none tabular-nums">{hud.alive}</span>
          <span className="font-display text-[10px] tracking-[0.25em] text-white/55">ALIVE</span>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-black/55 px-3 py-1 ring-1 ring-white/10">
          <span className="font-display text-[10px] tracking-[0.25em] text-white/55">KILLS</span>
          <span className="font-display text-xl font-bold leading-none text-orange-300 tabular-nums">{hud.kills}</span>
        </div>
        {playing && (
          <div className="flex gap-2">
            <IconButton label="Pause" onClick={onPause}>
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                <rect x="6" y="5" width="4" height="14" rx="1" />
                <rect x="14" y="5" width="4" height="14" rx="1" />
              </svg>
            </IconButton>
            <IconButton label={muted ? 'Unmute' : 'Mute'} onClick={onToggleMute}>
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 5L6 9H2v6h4l5 4V5z" />
                {muted ? <path d="M22 9l-6 6M16 9l6 6" /> : <path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14" />}
              </svg>
            </IconButton>
          </div>
        )}
      </div>

      {/* Top-right: minimap + kill feed */}
      <div className="absolute right-3 top-3 flex flex-col items-end gap-2 sm:right-5 sm:top-5">
        <Minimap data={hud.minimap} size={mm} />
        <Feed items={hud.feed} />
      </div>

      {/* Top-centre: zone status */}
      <div className="absolute left-1/2 top-3 -translate-x-1/2 text-center sm:top-5">
        <div
          className={`whitespace-nowrap rounded-md px-4 py-1 font-display text-[13px] font-bold tracking-[0.18em] ring-1 ${
            outside ? 'anim-warn bg-rose-600/85 ring-rose-300/60' : 'bg-black/55 ring-white/10'
          }`}
        >
          {outside ? 'OUTSIDE ZONE · TAKING DAMAGE' : zoneText}
        </div>
      </div>

      {playing && hud.phase === 'playing' && <Crosshair ads={hud.ads} hitTick={hud.hitTick} hitHead={hud.hitHead} />}

      {hud.phase === 'drop' && (
        <div className="absolute inset-x-0 top-[22%] text-center">
          <div className="font-display text-3xl font-bold tracking-[0.35em] text-amber-300 [text-shadow:0_0_18px_rgba(251,146,60,0.7)]">
            DROPPING
          </div>
          <div className="mt-1 font-display text-xs tracking-[0.3em] text-white/60">
            LANDING IN {Math.max(0, Math.ceil(hud.dropTotal - hud.dropT))}s
          </div>
        </div>
      )}

      {hud.phase === 'dying' && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className={`anim-drop font-display text-6xl font-black tracking-wider ${hud.win ? 'title-gold' : 'text-rose-400 [text-shadow:0_0_24px_rgba(251,113,133,0.7)]'}`}
          >
            {hud.win ? 'BOOYAH!' : 'ELIMINATED'}
          </div>
        </div>
      )}

      {/* Bottom-left: health / armor / meds */}
      <div className="absolute bottom-3 left-3 w-[190px] sm:bottom-5 sm:left-5">
        <Bar label="HEALTH" value={hud.hp} max={100} color="#22c55e" />
        {hud.armor > 0 && <Bar label="ARMOR" value={hud.armor} max={100} color="#38bdf8" />}
        <div className="mt-2 flex items-center gap-2 font-display text-sm tracking-wider text-white/80">
          <span className="grid h-6 w-6 place-items-center rounded bg-emerald-500/25 text-emerald-300">+</span>
          <span className="tabular-nums">{hud.meds}</span>
          <span className="text-[10px] text-white/45">MEDKIT · F</span>
        </div>
      </div>

      {/* Bottom-right: weapon card */}
      {w && playing && (
        <div className="absolute bottom-3 right-3 w-[200px] rounded-xl bg-black/60 p-3 ring-1 ring-white/10 sm:bottom-5 sm:right-5 sm:w-[220px]">
          <div className="flex items-baseline justify-between">
            <span className="font-display text-base font-bold tracking-wider text-amber-300">{w.name}</span>
            <span className="font-display text-[10px] tracking-widest text-white/50">{w.auto ? 'AUTO' : 'SEMI'}</span>
          </div>
          <div className="mt-0.5 flex items-end gap-2">
            <span className="font-display text-5xl font-bold leading-none tabular-nums">{w.mag}</span>
            <span className="pb-1 font-display text-xl text-white/45 tabular-nums">/ {w.reserve}</span>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-amber-400 transition-[width] duration-100" style={{ width: w.reloading ? `${w.reloadFrac * 100}%` : '0%' }} />
          </div>
          <div className="mt-2 flex gap-1.5">
            {w.slots.map((s, i) => (
              <div
                key={i}
                className={`flex-1 truncate rounded px-2 py-1 text-center font-display text-[10px] tracking-wider ${
                  i === w.active ? 'bg-amber-400 font-bold text-black' : 'bg-white/10 text-white/55'
                }`}
              >
                {i + 1} · {s ? s.name : 'EMPTY'}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pickup prompt */}
      {hud.prompt && hud.phase === 'playing' && (
        <div className="absolute bottom-[30%] left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-black/70 px-4 py-1.5 font-display text-sm tracking-wider ring-1 ring-amber-300/40">
          <span className="mr-2 rounded bg-amber-400 px-1.5 text-black">{touch ? 'PICK' : 'E'}</span>
          {hud.prompt}
        </div>
      )}
    </div>
  );
}
