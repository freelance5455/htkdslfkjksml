import React from 'react';
import {
  ColorId,
  GameMode,
  LevelConfig,
  SaveData,
  ThemeConfig
} from '../types/game';
import {
  Pause,
  Volume2,
  VolumeX,
  Lightbulb,
  PlusCircle,
  Zap,
  RotateCcw,
  Sparkles,
  Trophy,
  Flame,
  Clock
} from 'lucide-react';

interface HUDProps {
  level: LevelConfig;
  mode: GameMode;
  movesRemaining: number;
  score: number;
  multiplier: number;
  comboCount: number;
  timeLeft?: number;
  connectedColors: ColorId[];
  theme: ThemeConfig;
  saveData: SaveData;
  onPause: () => void;
  onToggleSound: () => void;
  onUseBooster: (type: 'hint' | 'extraMoves' | 'colorClear' | 'undo' | 'reset') => void;
  canUndo: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  level,
  mode,
  movesRemaining,
  score,
  multiplier,
  comboCount,
  timeLeft,
  connectedColors,
  theme,
  saveData,
  onPause,
  onToggleSound,
  onUseBooster,
  canUndo
}) => {
  const isSoundOn = saveData.settings.sound;
  const isMovesLow = mode === 'classic' && movesRemaining <= 3;
  const isTimeLow = mode === 'time_challenge' && (timeLeft ?? 10) <= 5;

  const totalPairs = level.pairs.length;
  const connectedCount = connectedColors.length;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-5 select-none z-10">
      {/* Top Header Perimeter Cluster */}
      <div className="w-full flex items-center justify-between gap-3">
        {/* Left: Level / Mode title & objectives */}
        <div className="pointer-events-auto flex items-center gap-2 sm:gap-3 bg-slate-900/80 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800 shadow-lg">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              {mode === 'classic' ? `World ${level.worldIndex}` : mode.replace('_', ' ')}
            </div>
            <div className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5 truncate max-w-[150px] sm:max-w-[220px]">
              {level.name}
            </div>
          </div>

          <div className="h-6 w-px bg-slate-700/60 mx-1 hidden sm:block" />

          {/* Color Progress Pips */}
          <div className="hidden sm:flex items-center gap-1.5 pl-1">
            {level.pairs.map((p, idx) => {
              const isDone = connectedColors.includes(p.color);
              const colorDef = theme.colors[p.color];
              return (
                <div
                  key={idx}
                  title={`${colorDef?.label}: ${isDone ? 'Connected' : 'Pending'}`}
                  className="w-3.5 h-3.5 rounded-full transition-all duration-300 flex items-center justify-center text-[8px] font-bold"
                  style={{
                    backgroundColor: isDone ? colorDef?.hex : 'rgba(30, 41, 59, 0.8)',
                    boxShadow: isDone ? `0 0 8px ${colorDef?.hex}` : 'none',
                    border: `1.5px solid ${isDone ? '#ffffff' : colorDef?.hex || '#64748b'}`
                  }}
                >
                  {isDone && '✓'}
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: Score & Combo Multiplier */}
        <div className="pointer-events-auto flex flex-col items-center">
          <div className="flex items-center gap-1.5 bg-slate-900/80 backdrop-blur-md px-4 py-1.5 rounded-xl border border-slate-800 shadow-lg">
            <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-mono tabular-nums text-base sm:text-lg font-extrabold text-white">
              {score.toLocaleString()}
            </span>

            {multiplier > 1 && (
              <span className="ml-1 px-1.5 py-0.5 rounded text-[11px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-0.5 animate-pulse">
                <Flame className="w-3 h-3 text-orange-400" />
                {multiplier}x
              </span>
            )}
          </div>

          {comboCount >= 2 && (
            <div className="text-[10px] font-bold text-amber-400 tracking-wider uppercase mt-1 animate-bounce">
              {comboCount}x Flow Combo!
            </div>
          )}
        </div>

        {/* Right: Moves / Timer & Quick Utility buttons */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Moves or Timer Readout */}
          {mode === 'time_challenge' ? (
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono tabular-nums font-black text-sm sm:text-base border transition-all ${
                isTimeLow
                  ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                  : 'bg-slate-900/80 border-slate-800 text-cyan-300'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>{timeLeft}s</span>
            </div>
          ) : (
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono tabular-nums font-bold text-xs sm:text-sm border transition-all ${
                isMovesLow
                  ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                  : 'bg-slate-900/80 border-slate-800 text-slate-200'
              }`}
            >
              <span className="text-slate-400 text-[11px]">MOVES:</span>
              <span className="font-black text-sm sm:text-base">{movesRemaining}</span>
            </div>
          )}

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            aria-label="Toggle sound"
            className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors shadow-lg"
          >
            {isSoundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Pause Button */}
          <button
            onClick={onPause}
            aria-label="Pause game"
            className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors shadow-lg"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Bottom Perimeter: Objective Progress & Boosters Toolbar */}
      <div className="w-full flex flex-col items-center gap-2.5">
        {/* Mobile Mini Progress Indicator */}
        <div className="sm:hidden pointer-events-auto flex items-center gap-2 bg-slate-900/70 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-800">
          <span className="text-xs text-slate-400">
            {connectedCount} of {totalPairs} Connected
          </span>
        </div>

        {/* Booster Controls Bar */}
        <div className="pointer-events-auto flex items-center justify-center gap-1.5 sm:gap-2.5 bg-slate-950/85 backdrop-blur-md px-3 sm:px-4 py-2 rounded-2xl border border-slate-800/80 shadow-2xl">
          {/* Hint */}
          <button
            onClick={() => onUseBooster('hint')}
            title="Hint: Show shortest remaining connection path"
            className="group relative flex flex-col items-center gap-0.5 px-2.5 sm:px-3 py-1.5 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-slate-300 hover:text-amber-300"
          >
            <Lightbulb className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-semibold text-slate-400 group-hover:text-slate-200">Hint</span>
            <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 bg-amber-500 text-slate-950 text-[10px] font-extrabold rounded-full">
              {saveData.boosters.hint}
            </span>
          </button>

          {/* Extra Moves */}
          {mode !== 'time_challenge' && (
            <button
              onClick={() => onUseBooster('extraMoves')}
              title="+5 Extra Moves"
              className="group relative flex flex-col items-center gap-0.5 px-2.5 sm:px-3 py-1.5 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-slate-300 hover:text-emerald-300"
            >
              <PlusCircle className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-semibold text-slate-400 group-hover:text-slate-200">+5 Moves</span>
              <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 bg-emerald-500 text-slate-950 text-[10px] font-extrabold rounded-full">
                {saveData.boosters.extraMoves}
              </span>
            </button>
          )}

          {/* Color Clear */}
          <button
            onClick={() => onUseBooster('colorClear')}
            title="Color Clear: Automatically connects 1 unsolved color"
            className="group relative flex flex-col items-center gap-0.5 px-2.5 sm:px-3 py-1.5 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-slate-300 hover:text-cyan-300"
          >
            <Zap className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-semibold text-slate-400 group-hover:text-slate-200">Solve 1</span>
            <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 bg-cyan-500 text-slate-950 text-[10px] font-extrabold rounded-full">
              {saveData.boosters.colorClear}
            </span>
          </button>

          {/* Undo */}
          <button
            onClick={() => onUseBooster('undo')}
            disabled={!canUndo}
            title="Undo last path connection"
            className={`group relative flex flex-col items-center gap-0.5 px-2.5 sm:px-3 py-1.5 rounded-xl transition-all ${
              canUndo
                ? 'hover:bg-slate-800/80 active:scale-95 text-slate-300 hover:text-purple-300'
                : 'opacity-40 cursor-not-allowed text-slate-500'
            }`}
          >
            <RotateCcw className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-semibold text-slate-400">Undo</span>
            <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 bg-purple-500 text-slate-950 text-[10px] font-extrabold rounded-full">
              {saveData.boosters.undo}
            </span>
          </button>

          {/* Clear / Reset All Paths */}
          <button
            onClick={() => onUseBooster('reset')}
            title="Reset active board paths"
            className="group flex flex-col items-center gap-0.5 px-2.5 sm:px-3 py-1.5 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-slate-400 hover:text-rose-400"
          >
            <Sparkles className="w-5 h-5 text-slate-400 group-hover:text-rose-400 transition-colors" />
            <span className="text-[10px] font-semibold">Reset</span>
          </button>
        </div>
      </div>
    </div>
  );
};
