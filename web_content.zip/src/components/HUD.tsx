import React from 'react';
import { GameEngine } from '../game/engine';
import { ITEMS } from '../game/items';
import { sprites } from '../game/sprites';
import { Volume2, VolumeX, Save, ShieldCheck, Backpack, Hammer, Tent, Sparkles, Heart, Zap, Flame, CloudRain, Cloud, Sun, Moon, Wind } from 'lucide-react';

interface HUDProps {
  engine: GameEngine;
  onOpenInventory: () => void;
  onOpenCrafting: () => void;
  onOpenBuilding: () => void;
  onOpenSkillTree: () => void;
  onOpenAssetAudit: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onManualSave: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  engine,
  onOpenInventory,
  onOpenCrafting,
  onOpenBuilding,
  onOpenSkillTree,
  onOpenAssetAudit,
  isMuted,
  onToggleMute,
  onManualSave,
}) => {
  const p = engine.player;

  // Format in-game clock (00:00 to 23:59)
  const hours = Math.floor(engine.timeOfDay / 60);
  const minutes = Math.floor(engine.timeOfDay % 60);
  const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

  const isNight = engine.timeOfDay < 300 || engine.timeOfDay > 1200;

  // XP progression calculation
  const xpNeeded = Math.floor(75 * Math.pow(1.3, p.level - 1));
  const xpPercent = Math.min(100, Math.round((p.xp / xpNeeded) * 100));

  // Current weather name in Arabic
  const weatherType = engine.weather.current;
  const weatherNames: Record<string, { name: string; icon: React.ReactNode }> = {
    clear: { name: 'صافٍ', icon: <Sun className="w-3.5 h-3.5 text-amber-400" /> },
    cloudy: { name: 'غائم', icon: <Cloud className="w-3.5 h-3.5 text-slate-300" /> },
    rain: { name: 'ماطر', icon: <CloudRain className="w-3.5 h-3.5 text-blue-400" /> },
    storm: { name: 'عاصف', icon: <Wind className="w-3.5 h-3.5 text-cyan-300" /> },
    fog: { name: 'ضبابي', icon: <Wind className="w-3.5 h-3.5 text-slate-300" /> },
  };
  const currentWeatherInfo = weatherNames[weatherType] || weatherNames.clear;

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-2 sm:p-4 font-['Tajawal',sans-serif]">
      {/* Top Bar: Survival Meters, Weather/Clock, & Controls */}
      <div className="flex flex-wrap items-start justify-between gap-2 w-full">
        {/* Survival Status Bars & Level/XP */}
        <div className="flex flex-col gap-1.5 bg-neutral-950/85 backdrop-blur-xs border-2 border-neutral-700/80 p-2 sm:p-2.5 rounded-lg text-white shadow-xl pointer-events-auto">
          {/* Health Bar */}
          <div className="flex items-center gap-2 text-xs">
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
            <div className="w-24 sm:w-36 h-2.5 sm:h-3 bg-neutral-800 rounded overflow-hidden border border-neutral-700">
              <div
                className="h-full bg-red-600 transition-all duration-200"
                style={{ width: `${Math.max(0, Math.min(100, (p.health / p.maxHealth) * 100))}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-300 w-12 text-right">
              {Math.round(p.health)}/{p.maxHealth}
            </span>
          </div>

          {/* Hunger Bar */}
          <div className="flex items-center gap-2 text-xs">
            <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <div className="w-24 sm:w-36 h-2.5 sm:h-3 bg-neutral-800 rounded overflow-hidden border border-neutral-700">
              <div
                className="h-full bg-amber-500 transition-all duration-200"
                style={{ width: `${Math.max(0, Math.min(100, (p.hunger / p.maxHunger) * 100))}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-300 w-12 text-right">
              {Math.round(p.hunger)}/{p.maxHunger}
            </span>
          </div>

          {/* Energy Bar */}
          <div className="flex items-center gap-2 text-xs">
            <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
            <div className="w-24 sm:w-36 h-2.5 sm:h-3 bg-neutral-800 rounded overflow-hidden border border-neutral-700">
              <div
                className="h-full bg-cyan-400 transition-all duration-200"
                style={{ width: `${Math.max(0, Math.min(100, (p.energy / p.maxEnergy) * 100))}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-300 w-12 text-right">
              {Math.round(p.energy)}/{p.maxEnergy}
            </span>
          </div>

          {/* XP Bar */}
          <div className="flex items-center gap-2 text-xs pt-0.5 border-t border-neutral-800/80">
            <span className="text-[10px] font-black text-purple-400 w-3.5 text-center">XP</span>
            <div className="w-24 sm:w-36 h-2 bg-neutral-800 rounded overflow-hidden border border-neutral-700">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-amber-400 transition-all duration-200"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
            <span className="text-[9px] font-mono text-purple-300 w-12 text-right">
              م{p.level} ({xpPercent}%)
            </span>
          </div>
        </div>

        {/* Center Clock, Day, & Weather Badge */}
        <div className="flex items-center gap-2 bg-neutral-950/85 border-2 border-neutral-700/80 px-3 py-1.5 rounded-lg text-white shadow-xl pointer-events-auto">
          {isNight ? <Moon className="w-4 h-4 text-blue-300" /> : <Sun className="w-4 h-4 text-amber-400" />}
          <div className="flex flex-col text-center">
            <div className="flex items-center gap-1.5 justify-center">
              <span className="text-[11px] font-bold text-amber-400">اليوم {engine.dayCount}</span>
              <span className="text-[10px] text-neutral-400">•</span>
              <span className="text-xs font-mono tracking-wider">{timeStr}</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-neutral-300 justify-center">
              {currentWeatherInfo.icon}
              <span>{currentWeatherInfo.name}</span>
            </div>
          </div>
        </div>

        {/* Top Right Quick Actions & Skill Tree */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Skill Tree Button */}
          <button
            id="btn-open-skilltree"
            onClick={onOpenSkillTree}
            title="شجرة المهارات (K)"
            className={`relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-bold transition cursor-pointer border shadow ${
              p.skillPoints > 0
                ? 'bg-amber-500/20 border-amber-400 text-amber-300 animate-pulse ring-2 ring-amber-400/40'
                : 'bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border-neutral-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">المهارات</span>
            {p.skillPoints > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-black">
                {p.skillPoints}
              </span>
            )}
          </button>

          <button
            id="btn-save-game"
            onClick={onManualSave}
            title="حفظ اللعبة"
            className="flex items-center gap-1 bg-neutral-900/90 hover:bg-neutral-800 active:scale-95 text-neutral-200 border border-neutral-700 px-2.5 py-1.5 rounded-md text-xs transition cursor-pointer shadow"
          >
            <Save className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">حفظ</span>
          </button>

          <button
            id="btn-toggle-sound"
            onClick={onToggleMute}
            title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
            className="p-1.5 bg-neutral-900/90 hover:bg-neutral-800 active:scale-95 text-neutral-200 border border-neutral-700 rounded-md transition cursor-pointer shadow"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          <button
            id="btn-asset-audit"
            onClick={onOpenAssetAudit}
            title="فحص الأصول ومعاينة الرسوم"
            className="flex items-center gap-1 bg-neutral-900/90 hover:bg-neutral-800 active:scale-95 text-neutral-200 border border-neutral-700 px-2.5 py-1.5 rounded-md text-xs transition cursor-pointer shadow"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">الأصول</span>
          </button>
        </div>
      </div>

      {/* Notification Toast (Center-Top) */}
      {engine.activeNotification && (
        <div className="self-center mt-2 bg-neutral-900/95 border-2 border-amber-500/90 text-amber-200 px-4 py-2 rounded-lg shadow-2xl flex items-center gap-3 animate-bounce">
          <span className="text-2xl">{engine.activeNotification.icon}</span>
          <div className="flex flex-col text-right">
            <span className="text-xs font-black text-amber-300">إنجاز جديد: {engine.activeNotification.title}</span>
            <span className="text-[11px] text-neutral-300">{engine.activeNotification.desc}</span>
          </div>
        </div>
      )}

      {/* Bottom Area: Hotbar & Desktop Action Buttons */}
      <div className="flex flex-col items-center gap-2 mb-1 sm:mb-2">
        {/* Hotbar (5 Quick Slots) */}
        <div className="flex items-center gap-1.5 bg-neutral-950/90 border-2 border-neutral-700/90 p-1.5 rounded-xl shadow-2xl pointer-events-auto">
          {engine.inventory.slice(0, 5).map((slot, idx) => {
            const isSelected = engine.player.selectedHotbarIndex === idx;
            const itemDef = slot && slot.item ? ITEMS[slot.item] : null;

            return (
              <button
                key={idx}
                id={`hotbar-slot-${idx}`}
                onClick={() => engine.selectHotbarSlot(idx)}
                className={`relative w-11 h-11 sm:w-13 sm:h-13 rounded-lg border-2 flex items-center justify-center transition cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-950/40 shadow-md shadow-amber-500/20'
                    : 'border-neutral-700 bg-neutral-900/80 hover:border-neutral-500'
                }`}
              >
                <span className="absolute top-0.5 left-1 text-[9px] font-mono text-neutral-400">
                  {idx + 1}
                </span>

                {slot && slot.item && (
                  <>
                    <HotbarItemIcon itemId={slot.item} />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0.5 right-1 text-[10px] font-mono font-bold text-white bg-black/70 px-1 rounded">
                        {slot.count}
                      </span>
                    )}
                    {slot.durability !== undefined && itemDef?.maxDurability && (
                      <div className="absolute bottom-0.5 left-1 right-1 h-1 bg-neutral-800 rounded-xs overflow-hidden">
                        <div
                          className="h-full bg-cyan-400"
                          style={{ width: `${(slot.durability / itemDef.maxDurability) * 100}%` }}
                        />
                      </div>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>

        {/* Quick Menu Tabs (Desktop & Tablet) */}
        <div className="hidden sm:flex items-center gap-2 pointer-events-auto">
          <button
            id="btn-open-inventory"
            onClick={onOpenInventory}
            className="flex items-center gap-1.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer shadow"
          >
            <Backpack className="w-3.5 h-3.5 text-amber-400" />
            <span>الحقيبة (I)</span>
          </button>

          <button
            id="btn-open-crafting"
            onClick={onOpenCrafting}
            className="flex items-center gap-1.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer shadow"
          >
            <Hammer className="w-3.5 h-3.5 text-cyan-400" />
            <span>الصناعة (C)</span>
          </button>

          <button
            id="btn-open-building"
            onClick={onOpenBuilding}
            className="flex items-center gap-1.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer shadow"
          >
            <Tent className="w-3.5 h-3.5 text-emerald-400" />
            <span>البناء (B)</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// Item Icon Canvas Subcomponent
export const HotbarItemIcon: React.FC<{ itemId: string }> = ({ itemId }) => {
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);

  React.useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, 24, 24);

    const sprite = sprites.get(`item_${itemId}`);
    if (sprite) {
      ctx.drawImage(sprite, 0, 0, 24, 24);
    }
  }, [itemId]);

  return <canvas ref={canvasRef} width={24} height={24} className="w-6 h-6 sm:w-7 sm:h-7 pointer-events-none" style={{ imageRendering: 'pixelated' }} />;
};
