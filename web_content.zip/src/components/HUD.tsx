import React, { useEffect, useRef } from 'react';
import {
  Shield,
  Heart,
  Zap,
  Crosshair,
  Package,
  Layers,
  Skull,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { WeaponType, KillFeedEntry } from '../game/types';
import { WEAPON_REGISTRY } from '../game/weapons';
import { sounds } from '../game/audio';

interface HUDProps {
  hp: number;
  maxHp: number;
  ep: number;
  maxEp: number;
  vest: number;
  aliveCount: number;
  kills: number;
  activeWeapon: WeaponType;
  currentAmmo: number;
  reserveAmmo: number;
  glooWalls: number;
  medkits: number;
  isOutsideZone: boolean;
  zoneCountdown: number;
  zonePhase: number;
  isHealing: boolean;
  killFeed: KillFeedEntry[];
  hitMarker: boolean;
  isHeadshotHit: boolean;
  damageNumbers: { id: number; dmg: number; isHeadshot: boolean; x: number; y: number }[];
  radarData: {
    playerX: number;
    playerZ: number;
    playerRot: number;
    zoneX: number;
    zoneZ: number;
    zoneRadius: number;
    targetZoneX: number;
    targetZoneZ: number;
    targetZoneRadius: number;
    gunshots: { x: number; z: number; time: number }[];
  } | null;
  onDeployGlooWall: () => void;
  onUseMedkit: () => void;
  onSwitchWeapon: (slot: 0 | 1 | 2) => void;
  onReload: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  hp,
  maxHp,
  ep,
  maxEp,
  vest,
  aliveCount,
  kills,
  activeWeapon,
  currentAmmo,
  reserveAmmo,
  glooWalls,
  medkits,
  isOutsideZone,
  zoneCountdown,
  zonePhase,
  isHealing,
  killFeed,
  hitMarker,
  isHeadshotHit,
  damageNumbers,
  radarData,
  onDeployGlooWall,
  onUseMedkit,
  onSwitchWeapon,
  onReload,
  isMuted,
  onToggleMute,
}) => {
  const radarCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const activeDef = WEAPON_REGISTRY[activeWeapon];

  // Draw circular radar mini-map
  useEffect(() => {
    if (!radarCanvasRef.current || !radarData) return;
    const canvas = radarCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const center = size / 2;
    const radarScale = 0.55; // 1 meter = 0.55 pixels on radar

    ctx.clearRect(0, 0, size, size);

    // Save for clipping
    ctx.save();
    ctx.beginPath();
    ctx.arc(center, center, center - 2, 0, Math.PI * 2);
    ctx.clip();

    // Background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(0, 0, size, size);

    // Grid rings
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    [25, 50, 75].forEach((r) => {
      ctx.beginPath();
      ctx.arc(center, center, r, 0, Math.PI * 2);
      ctx.stroke();
    });

    // Translate relative to player
    const relZoneX = (radarData.zoneX - radarData.playerX) * radarScale;
    const relZoneZ = (radarData.zoneZ - radarData.playerZ) * radarScale;
    const zoneRad = radarData.zoneRadius * radarScale;

    // Draw Current Safe Zone Circle
    ctx.strokeStyle = '#00d2ff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(center + relZoneX, center + relZoneZ, zoneRad, 0, Math.PI * 2);
    ctx.stroke();

    // Draw Next Zone Circle (white dashed)
    const relNextX = (radarData.targetZoneX - radarData.playerX) * radarScale;
    const relNextZ = (radarData.targetZoneZ - radarData.playerZ) * radarScale;
    const nextRad = radarData.targetZoneRadius * radarScale;

    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.beginPath();
    ctx.arc(center + relNextX, center + relNextZ, nextRad, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw Gunshot Pings (Red blips)
    radarData.gunshots.forEach((g) => {
      const gx = center + (g.x - radarData.playerX) * radarScale;
      const gz = center + (g.z - radarData.playerZ) * radarScale;
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(gx, gz, 4, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Center Player Arrow
    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(radarData.playerRot);

    // Heading cone
    ctx.fillStyle = 'rgba(245, 158, 11, 0.25)';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 30, -Math.PI * 0.75, -Math.PI * 0.25);
    ctx.closePath();
    ctx.fill();

    // Player arrow
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(5, 5);
    ctx.lineTo(0, 2);
    ctx.lineTo(-5, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    ctx.restore();

    // Outer border
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(center, center, center - 2, 0, Math.PI * 2);
    ctx.stroke();
  }, [radarData]);

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden font-sans">
      {/* 1. Outside Zone Warning Flash */}
      {isOutsideZone && (
        <div className="absolute inset-0 bg-blue-500/20 border-8 border-cyan-400 pointer-events-none flex items-center justify-center">
          <div className="bg-red-600/90 text-white font-black text-xl px-6 py-2 rounded-lg tracking-widest uppercase shadow-2xl animate-bounce">
            ⚠️ OUTSIDE SAFE ZONE - TAKE COVER!
          </div>
        </div>
      )}

      {/* 2. Low Health Red Vignette */}
      {hp < 60 && (
        <div className="absolute inset-0 bg-red-600/15 pointer-events-none" />
      )}

      {/* 3. TOP BAR: Alive, Kills, Zone Timer */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-3">
        {/* Alive Count */}
        <div className="bg-slate-900/90 text-white border border-amber-500/50 px-4 py-1.5 rounded-full flex items-center gap-2 shadow-lg">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span className="text-xs uppercase font-bold text-slate-400">Alive</span>
          <span className="text-lg font-black text-amber-400 tabular-nums">{aliveCount}</span>
        </div>

        {/* Safe Zone Timer Pill */}
        <div className="bg-slate-900/90 text-white border border-cyan-500/60 px-5 py-1.5 rounded-full flex items-center gap-2 shadow-lg">
          <span className="text-xs font-bold text-cyan-300 uppercase">
            {zoneCountdown > 0 ? `Zone shrinks in` : 'Zone Shrinking!'}
          </span>
          <span className="text-lg font-black text-white tabular-nums">
            {zoneCountdown > 0 ? `${zoneCountdown}s` : '⚡'}
          </span>
          <span className="text-[10px] bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded font-mono">
            P{zonePhase}
          </span>
        </div>

        {/* Kills Count */}
        <div className="bg-slate-900/90 text-white border border-red-500/50 px-4 py-1.5 rounded-full flex items-center gap-2 shadow-lg">
          <Skull className="w-4 h-4 text-red-500" />
          <span className="text-xs uppercase font-bold text-slate-400">Kills</span>
          <span className="text-lg font-black text-red-400 tabular-nums">{kills}</span>
        </div>
      </div>

      {/* 4. TOP-LEFT: Radar Mini-Map */}
      <div className="absolute top-4 left-4 flex flex-col items-start gap-1">
        <div className="relative w-32 h-32 rounded-full overflow-hidden shadow-2xl border-2 border-slate-700 bg-slate-950/80">
          <canvas ref={radarCanvasRef} width={128} height={128} className="w-full h-full" />
          <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-black text-amber-400">
            N
          </div>
        </div>
        <div className="text-[10px] text-slate-300 font-mono bg-slate-950/70 px-2 py-0.5 rounded">
          BERMUDA ISLAND
        </div>
      </div>

      {/* 5. TOP-RIGHT: Sound Toggle & Kill Feed */}
      <div className="absolute top-4 right-4 flex flex-col items-end gap-2 max-w-xs">
        <button
          onClick={onToggleMute}
          className="pointer-events-auto p-2 bg-slate-900/80 hover:bg-slate-800 text-amber-400 rounded-lg border border-amber-500/40 shadow-lg cursor-pointer transition-colors"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Kill Feed Items */}
        <div className="flex flex-col gap-1 w-64">
          {killFeed.slice(-4).map((feed) => (
            <div
              key={feed.id}
              className={`text-xs px-2.5 py-1 rounded backdrop-blur-none flex items-center justify-between border shadow-md transition-all ${
                feed.isPlayerKiller
                  ? 'bg-amber-950/90 border-amber-500 text-amber-200'
                  : 'bg-slate-950/80 border-slate-700 text-slate-300'
              }`}
            >
              <span className="font-bold truncate max-w-[80px]">{feed.killer}</span>
              <span className="text-[10px] text-red-400 font-mono px-1">
                {feed.isHeadshot ? '💥 🎯' : '💥'}
              </span>
              <span className="truncate max-w-[80px] opacity-75">{feed.victim}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 6. CENTER: Reticle Crosshair & Hit Markers */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-8 h-8 flex items-center justify-center">
          {/* Center Dot */}
          <div className="w-1.5 h-1.5 bg-amber-400 rounded-full shadow-[0_0_8px_rgba(245,158,11,1)]" />

          {/* Crosshair Ticks */}
          <div className="absolute -top-3 w-0.5 h-2 bg-white/80" />
          <div className="absolute -bottom-3 w-0.5 h-2 bg-white/80" />
          <div className="absolute -left-3 h-0.5 w-2 bg-white/80" />
          <div className="absolute -right-3 h-0.5 w-2 bg-white/80" />

          {/* Hit Marker X */}
          {hitMarker && (
            <div
              className={`absolute inset-0 flex items-center justify-center text-xl font-black ${
                isHeadshotHit ? 'text-red-500 scale-125' : 'text-amber-400 scale-100'
              }`}
            >
              ✕
            </div>
          )}
        </div>
      </div>

      {/* 7. Floating Damage Numbers */}
      {damageNumbers.map((d) => (
        <div
          key={d.id}
          style={{ left: `${d.x}px`, top: `${d.y}px` }}
          className={`absolute pointer-events-none font-black text-xl select-none -translate-x-1/2 -translate-y-1/2 transition-all ${
            d.isHeadshot ? 'text-red-500 text-2xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]' : 'text-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]'
          }`}
        >
          {d.dmg}
        </div>
      ))}

      {/* 8. BOTTOM-LEFT: HP, EP, Vest, Medkit */}
      <div className="absolute bottom-6 left-6 flex flex-col gap-2 max-w-sm">
        {/* EP Bar (Energy Points - Free Fire Mushroom EP) */}
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
          <div className="flex-1 bg-slate-950/80 rounded-full h-2.5 overflow-hidden border border-amber-500/40">
            <div
              className="bg-amber-400 h-full transition-all duration-150"
              style={{ width: `${(ep / maxEp) * 100}%` }}
            />
          </div>
          <span className="text-xs font-mono font-bold text-amber-400 w-12 text-right">
            {ep}/{maxEp}
          </span>
        </div>

        {/* HP Bar */}
        <div className="flex items-center gap-2">
          <Heart className="w-4 h-4 text-red-500 fill-red-500" />
          <div className="flex-1 bg-slate-950/80 rounded-full h-4 overflow-hidden border border-red-500/40">
            <div
              className={`h-full transition-all duration-150 ${
                hp < 50 ? 'bg-red-600' : 'bg-emerald-500'
              }`}
              style={{ width: `${(hp / maxHp) * 100}%` }}
            />
          </div>
          <span className="text-sm font-mono font-black text-white w-14 text-right">
            {hp}/{maxHp}
          </span>
        </div>

        {/* Armor Vest & Medkit Quick Buttons */}
        <div className="flex items-center gap-3 mt-1">
          {/* Vest Level */}
          <div className="bg-slate-900/90 text-white px-3 py-1 rounded-lg border border-slate-700 flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-slate-300">Vest:</span>
            <span className="text-xs font-mono font-bold text-blue-400">{vest}%</span>
          </div>

          {/* Medkit Button */}
          <button
            onClick={onUseMedkit}
            className={`pointer-events-auto px-3 py-1.5 rounded-lg border flex items-center gap-2 text-xs font-bold shadow-lg transition-all cursor-pointer ${
              isHealing
                ? 'bg-emerald-600 border-emerald-400 text-white'
                : medkits > 0
                ? 'bg-slate-900/90 hover:bg-emerald-950/80 border-emerald-500 text-emerald-400'
                : 'bg-slate-950/60 border-slate-800 text-slate-500 opacity-60'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>{isHealing ? 'HEALING...' : `Medkit [H] x${medkits}`}</span>
          </button>
        </div>
      </div>

      {/* 9. BOTTOM-RIGHT: Weapons, Ammo, Gloo Wall Button */}
      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3 max-w-sm">
        {/* Gloo Wall Instant Button */}
        <button
          onClick={onDeployGlooWall}
          className={`pointer-events-auto px-4 py-2 rounded-xl border flex items-center gap-2 text-sm font-black tracking-wide shadow-2xl transition-all cursor-pointer ${
            glooWalls > 0
              ? 'bg-cyan-950/90 hover:bg-cyan-900 border-cyan-400 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95'
              : 'bg-slate-900/70 border-slate-800 text-slate-500 opacity-50'
          }`}
        >
          <Layers className="w-5 h-5 text-cyan-400" />
          <span>GLOO WALL [G]</span>
          <span className="bg-cyan-500 text-slate-950 px-2 py-0.5 rounded-full text-xs font-mono font-black">
            {glooWalls}
          </span>
        </button>

        {/* Current Weapon & Ammo Card */}
        <div className="bg-slate-950/90 border-2 border-amber-500/70 rounded-2xl p-4 flex items-center gap-5 shadow-2xl">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">
              {activeDef.category}
            </span>
            <span className="text-xl font-black text-white">{activeDef.name}</span>
          </div>

          {/* Ammo Readout */}
          <div className="flex items-baseline gap-1 border-l border-slate-700 pl-4">
            <span className="text-3xl font-black text-amber-400 tabular-nums">
              {currentAmmo}
            </span>
            <span className="text-sm font-mono text-slate-400 font-bold">
              / {reserveAmmo}
            </span>
          </div>

          {/* Reload Button */}
          <button
            onClick={onReload}
            className="pointer-events-auto p-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white rounded-lg cursor-pointer transition-colors"
            title="Reload [R]"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Weapon Slots Selector */}
        <div className="flex items-center gap-2">
          {(['ar', 'shotgun', 'sniper'] as WeaponType[]).map((wId, idx) => {
            const def = WEAPON_REGISTRY[wId];
            const isActive = activeWeapon === wId;
            return (
              <button
                key={wId}
                onClick={() => onSwitchWeapon(idx as 0 | 1 | 2)}
                className={`pointer-events-auto px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md scale-105'
                    : 'bg-slate-900/80 text-slate-400 hover:text-white border-slate-700'
                }`}
              >
                [{idx + 1}] {def.name.split(' ')[0]}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
