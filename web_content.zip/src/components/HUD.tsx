import React from 'react';
import { Pause, Zap, Magnet, Rocket, Footprints, Shield, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';
import { ActivePowerups } from '../types/game';

interface HUDProps {
  score: number;
  coins: number;
  distance: number;
  momDistanceRatio: number; // 0 (caught) to 1 (safe distance)
  activePowerups: ActivePowerups;
  onPause: () => void;
  onJump: () => void;
  onSlide: () => void;
  onLeft: () => void;
  onRight: () => void;
  onToggleBoard: () => void;
  showOnScreenButtons: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  coins,
  distance,
  momDistanceRatio,
  activePowerups,
  onPause,
  onJump,
  onSlide,
  onLeft,
  onRight,
  onToggleBoard,
  showOnScreenButtons
}) => {
  // Danger status based on Mom proximity
  const isMomVeryClose = momDistanceRatio < 0.35;
  const isMomModerate = momDistanceRatio < 0.65;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 md:p-5 z-20">
      {/* Top Bar: Low-Occlusion Perimeter Status */}
      <div className="flex items-start justify-between gap-3 w-full">
        {/* Left cluster: Coins & Pause button */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={onPause}
            className="w-10 h-10 rounded-xl bg-slate-900/80 border border-slate-700/80 hover:bg-slate-800 text-white flex items-center justify-center active:scale-90 transition-all shadow-lg"
            title="إيقاف مؤقت"
          >
            <Pause className="w-5 h-5 fill-white" />
          </button>

          <div className="flex items-center gap-1.5 bg-slate-900/80 border border-amber-500/40 rounded-xl px-3 py-1.5 shadow-md">
            <span className="text-amber-400 text-base">🪙</span>
            <span className="text-amber-300 font-extrabold tabular-nums text-base">
              {coins.toLocaleString('ar-EG')}
            </span>
          </div>
        </div>

        {/* Center: Mom Danger Bar (مؤشر خطر ماما) */}
        <div className="flex flex-col items-center bg-slate-900/85 border border-slate-700/70 rounded-2xl px-3.5 py-1.5 shadow-lg max-w-[200px] w-full">
          <div className="flex items-center justify-between w-full text-[11px] font-bold mb-1">
            <span className={isMomVeryClose ? 'text-red-400 font-black animate-pulse' : 'text-slate-300'}>
              {isMomVeryClose ? '⚠️ ماما خلفك تماماً!' : 'مسافة الأمان من ماما'}
            </span>
            <span className="text-sm">🩴</span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-700">
            <div
              className={`h-full rounded-full transition-all duration-200 ${
                isMomVeryClose
                  ? 'bg-red-500 animate-pulse'
                  : isMomModerate
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.max(8, momDistanceRatio * 100)}%` }}
            />
          </div>
        </div>

        {/* Right cluster: Score & Distance */}
        <div className="flex flex-col items-end gap-1">
          <div className="bg-slate-900/85 border border-cyan-500/30 rounded-xl px-3 py-1 text-left min-w-[90px] shadow-md">
            <div className="text-[10px] text-cyan-400 font-bold">النقاط</div>
            <div className="text-base md:text-lg font-black text-white tabular-nums">
              {score.toLocaleString('ar-EG')}
            </div>
          </div>

          <div className="bg-slate-900/75 border border-slate-700 rounded-lg px-2 py-0.5 text-left text-xs font-bold text-slate-300 tabular-nums">
            {distance} م
          </div>
        </div>
      </div>

      {/* Middle Flank: Active Powerup Timers (compact pills) */}
      <div className="flex flex-col gap-1.5 max-w-[120px] pointer-events-none mt-2">
        {activePowerups.magnet > 0 && (
          <div className="flex items-center gap-1.5 bg-red-950/85 border border-red-500/60 rounded-xl px-2 py-1 text-red-200 text-xs font-bold shadow-md">
            <Magnet className="w-3.5 h-3.5 text-red-400" />
            <span className="tabular-nums">{Math.ceil(activePowerups.magnet)} ث</span>
          </div>
        )}

        {activePowerups.multiplier > 0 && (
          <div className="flex items-center gap-1.5 bg-blue-950/85 border border-blue-500/60 rounded-xl px-2 py-1 text-blue-200 text-xs font-bold shadow-md">
            <Zap className="w-3.5 h-3.5 text-blue-400" />
            <span className="tabular-nums">2X ({Math.ceil(activePowerups.multiplier)} ث)</span>
          </div>
        )}

        {activePowerups.jetpack > 0 && (
          <div className="flex items-center gap-1.5 bg-amber-950/85 border border-amber-500/60 rounded-xl px-2 py-1 text-amber-200 text-xs font-bold shadow-md">
            <Rocket className="w-3.5 h-3.5 text-amber-400" />
            <span className="tabular-nums">طيران ({Math.ceil(activePowerups.jetpack)} ث)</span>
          </div>
        )}

        {activePowerups.sneakers > 0 && (
          <div className="flex items-center gap-1.5 bg-emerald-950/85 border border-emerald-500/60 rounded-xl px-2 py-1 text-emerald-200 text-xs font-bold shadow-md">
            <Footprints className="w-3.5 h-3.5 text-emerald-400" />
            <span className="tabular-nums">{Math.ceil(activePowerups.sneakers)} ث</span>
          </div>
        )}

        {activePowerups.hoverboard && (
          <div className="flex items-center gap-1.5 bg-purple-950/85 border border-purple-500/60 rounded-xl px-2 py-1 text-purple-200 text-xs font-bold shadow-md">
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span>درع الزلاجة 🛡️</span>
          </div>
        )}
      </div>

      {/* Bottom Controls Area */}
      <div className="flex items-end justify-between w-full pointer-events-none mt-auto">
        {/* Optional Virtual Touch D-Pad */}
        {showOnScreenButtons ? (
          <div className="pointer-events-auto grid grid-cols-3 gap-1.5 p-2 bg-slate-900/60 rounded-2xl border border-slate-800">
            <div />
            <button
              onClick={onJump}
              className="w-12 h-12 rounded-xl bg-slate-800/80 active:bg-amber-600 flex items-center justify-center text-white border border-slate-700 active:scale-95 transition-all"
            >
              <ArrowUp className="w-6 h-6" />
            </button>
            <div />
            <button
              onClick={onLeft}
              className="w-12 h-12 rounded-xl bg-slate-800/80 active:bg-amber-600 flex items-center justify-center text-white border border-slate-700 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <button
              onClick={onSlide}
              className="w-12 h-12 rounded-xl bg-slate-800/80 active:bg-amber-600 flex items-center justify-center text-white border border-slate-700 active:scale-95 transition-all"
            >
              <ArrowDown className="w-6 h-6" />
            </button>
            <button
              onClick={onRight}
              className="w-12 h-12 rounded-xl bg-slate-800/80 active:bg-amber-600 flex items-center justify-center text-white border border-slate-700 active:scale-95 transition-all"
            >
              <ArrowRight className="w-6 h-6" />
            </button>
          </div>
        ) : (
          <div />
        )}

        {/* Hoverboard Action Trigger Button */}
        <div className="pointer-events-auto">
          <button
            onClick={onToggleBoard}
            className={`flex flex-col items-center justify-center w-16 h-16 rounded-2xl border-2 active:scale-90 transition-all shadow-xl ${
              activePowerups.hoverboard
                ? 'bg-purple-600 border-purple-300 text-white shadow-purple-500/50'
                : 'bg-slate-900/85 hover:bg-slate-800 border-amber-500/60 text-amber-300'
            }`}
            title="تشغيل الزلاجة (نقر مزدوج أو مفتاح E)"
          >
            <span className="text-2xl">⚡</span>
            <span className="text-[10px] font-black">{activePowerups.hoverboard ? 'نشطة' : 'المركبة'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
