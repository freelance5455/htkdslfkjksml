import { useEffect, useRef } from "react";
import type { Game, UIState } from "../game/Game";
import { LOCATIONS, CAVES, WORLD_HALF, VIEWPOINTS } from "../game/worldData";

function fmtHour(h: number) {
  const hh = Math.floor(h);
  const mm = Math.floor((h - hh) * 60);
  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}

function drawArrow(ctx: CanvasRenderingContext2D, x: number, y: number, f: number, s: number) {
  const dx = Math.sin(f), dy = Math.cos(f);
  ctx.save();
  ctx.fillStyle = "#ff4fd8";
  ctx.strokeStyle = "#1a0620";
  ctx.lineWidth = Math.max(1, s * 0.3);
  ctx.beginPath();
  ctx.moveTo(x + dx * s * 1.4, y + dy * s * 1.4);
  ctx.lineTo(x - dy * s * 0.8 - dx * s * 0.7, y + dx * s * 0.8 - dy * s * 0.7);
  ctx.lineTo(x + dy * s * 0.8 - dx * s * 0.7, y - dx * s * 0.8 - dy * s * 0.7);
  ctx.closePath();
  ctx.stroke();
  ctx.fill();
  ctx.restore();
}

export function HUD({ ui, game, onOpenMap, onOpenSettings, showFps }: { ui: UIState | null; game: Game | null; onOpenMap: () => void; onOpenSettings: () => void; showFps: boolean }) {
  const mini = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = mini.current;
    if (!c || !game || !ui) return;
    const ctx = c.getContext("2d")!;
    ctx.imageSmoothingEnabled = false;
    const S = c.width;
    if (ui.inCave) {
      ctx.fillStyle = "#0b0710";
      ctx.fillRect(0, 0, S, S);
      ctx.fillStyle = "#b070ff";
      ctx.font = "10px monospace";
      ctx.textAlign = "center";
      ctx.fillText("CAVERNA", S / 2, S / 2);
      return;
    }
    // zoomed local view: 160 world units around player
    const src = game.minimap;
    const world = WORLD_HALF * 2;
    const span = 200;
    const cxw = Math.max(-WORLD_HALF + span / 2, Math.min(WORLD_HALF - span / 2, ui.px));
    const czw = Math.max(-WORLD_HALF + span / 2, Math.min(WORLD_HALF - span / 2, ui.pz));
    const px = ((cxw + WORLD_HALF) / world) * src.width;
    const pz = ((czw + WORLD_HALF) / world) * src.height;
    const sw = (span / world) * src.width;
    ctx.fillStyle = "#1a2a1a";
    ctx.fillRect(0, 0, S, S);
    ctx.drawImage(src, px - sw / 2, pz - sw / 2, sw, sw, 0, 0, S, S);
    // points of interest
    const toMini = (x: number, z: number) => [((x - cxw) / span + 0.5) * S, ((z - czw) / span + 0.5) * S];
    ctx.fillStyle = "#c070ff";
    for (const cv of CAVES) {
      const [x, y] = toMini(cv.x, cv.z);
      if (x > 0 && y > 0 && x < S && y < S) ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    ctx.fillStyle = "#ffd24a";
    for (const v of VIEWPOINTS) {
      const [x, y] = toMini(v.x, v.z);
      if (x > 0 && y > 0 && x < S && y < S) ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    const [ax, ay] = toMini(ui.px, ui.pz);
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(ax - Math.sin(ui.yaw) * 16, ay - Math.cos(ui.yaw) * 16);
    ctx.stroke();
    drawArrow(ctx, ax, ay, ui.facing, 5);
  }, [ui, game]);

  if (!ui) return null;
  const night = ui.hour >= 19.5 || ui.hour < 5.5;
  return (
    <>
      <div className="pointer-events-none absolute left-3 top-3 z-30 flex flex-col gap-2 sm:left-5 sm:top-5">
        <div className="pixel-panel px-3 py-2 text-white">
          <div className="text-[11px] uppercase tracking-widest text-fuchsia-300">{ui.inCave ? "Caverna" : "Região"}</div>
          <div className="text-sm sm:text-base">{ui.region}</div>
        </div>
        <div className="flex gap-2">
          <div className="pixel-panel px-2 py-1 text-xs text-white">{night ? "🌙" : "☀️"} {fmtHour(ui.hour)}</div>
          <div className="pixel-panel px-2 py-1 text-xs text-fuchsia-200">💎 {ui.crystals}</div>
          <div className="pixel-panel px-2 py-1 text-xs text-amber-200">🧭 {ui.discovered}/{ui.totalLoc}</div>
        </div>
        <div className="pixel-panel flex w-44 items-center gap-1.5 px-1.5 py-1">
          <span className={`text-sm leading-none ${ui.hp < ui.maxHp * 0.3 ? "animate-pulse" : ""}`}>❤️</span>
          <div className="relative h-3 flex-1 bg-black/60">
            <div
              className="h-3 transition-all duration-200"
              style={{
                width: `${Math.max(0, (ui.hp / ui.maxHp) * 100)}%`,
                background: "linear-gradient(to bottom, #ff6b7a 0%, #d8354a 45%, #9a1a2e 100%)",
              }}
            />
            <div className="pointer-events-none absolute inset-0 flex">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="h-full flex-1 border-r border-black/40" />
              ))}
            </div>
          </div>
          <span className="w-7 text-right text-[10px] text-rose-100">{Math.ceil(ui.hp)}</span>
        </div>
        {ui.stamina < 99 && (
          <div className="pixel-panel w-40 p-1">
            <div className="h-2 bg-black/50">
              <div className="h-2 bg-gradient-to-r from-lime-400 to-emerald-500 transition-all" style={{ width: `${ui.stamina}%` }} />
            </div>
          </div>
        )}
        {ui.swimming && <div className="pixel-panel px-2 py-1 text-xs text-sky-200">🌊 Nadando</div>}
        {showFps && <div className="pixel-panel px-2 py-1 text-xs text-lime-300">{ui.fps} FPS</div>}
      </div>

      <div className="absolute right-3 top-3 z-30 flex items-start gap-2 sm:right-5 sm:top-5">
        <button onClick={onOpenSettings} className="pixel-btn h-10 w-10 bg-black/50 text-lg text-white" aria-label="Configurações">⚙️</button>
        <button onClick={onOpenMap} className="pixel-panel block p-1" aria-label="Mapa">
          <canvas ref={mini} width={112} height={112} className="block h-24 w-24 sm:h-28 sm:w-28" style={{ imageRendering: "pixelated" }} />
          <div className="mt-0.5 text-center text-[10px] text-white/70">MAPA (M)</div>
        </button>
      </div>

      {ui.panorama && (
        <div className="pointer-events-none absolute inset-x-0 top-20 z-20 flex justify-center">
          <div className="pixel-panel px-5 py-3 text-center text-white">
            <div className="text-[11px] uppercase tracking-widest text-amber-300">Mirante</div>
            <div className="text-lg">{ui.panorama}</div>
            <div className="text-[11px] text-white/60">mova-se ou toque em Voltar para sair</div>
          </div>
        </div>
      )}
    </>
  );
}

export function MapOverlay({ game, ui, onClose }: { game: Game; ui: UIState | null; onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    ctx.imageSmoothingEnabled = false;
    const S = c.width;
    ctx.drawImage(game.minimap, 0, 0, S, S);
    const disc = game.discoveredSet;
    const toMap = (x: number, z: number) => [((x + WORLD_HALF) / (WORLD_HALF * 2)) * S, ((z + WORLD_HALF) / (WORLD_HALF * 2)) * S];
    ctx.font = "bold 11px monospace";
    ctx.textAlign = "center";
    const seen = new Set<string>();
    for (const l of LOCATIONS) {
      if (seen.has(l.name)) continue;
      seen.add(l.name);
      const [x, y] = toMap(l.x, l.z);
      const known = disc.has(l.name);
      const isCave = CAVES.some((c) => c.name === l.name);
      ctx.fillStyle = known ? (isCave ? "#c070ff" : "#ffe08a") : "rgba(255,255,255,0.35)";
      ctx.fillRect(x - 3, y - 3, 6, 6);
      if (known) {
        ctx.fillStyle = "rgba(0,0,0,0.75)";
        ctx.fillText(l.name, x + 1, y - 6);
        ctx.fillStyle = "#fff";
        ctx.fillText(l.name, x, y - 7);
      } else {
        ctx.fillStyle = "rgba(255,255,255,0.6)";
        ctx.fillText("?", x, y - 6);
      }
    }
    if (ui && !ui.inCave) {
      const [x, y] = toMap(ui.px, ui.pz);
      drawArrow(ctx, x, y, ui.facing, 7);
    }
  }, [game, ui]);
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-3" onClick={onClose}>
      <div className="pixel-panel max-h-full p-3" onClick={(e) => e.stopPropagation()}>
        <div className="mb-2 flex items-center justify-between gap-4 text-white">
          <span className="text-sm uppercase tracking-widest text-fuchsia-300">Mapa das Terras de Ametista</span>
          <button onClick={onClose} className="pixel-btn bg-rose-600 px-3 py-1 text-sm">✕</button>
        </div>
        <canvas ref={ref} width={640} height={640} className="block aspect-square max-h-[75vh] w-[min(80vw,75vh)]" style={{ imageRendering: "pixelated" }} />
        <div className="mt-2 flex flex-wrap gap-3 text-[11px] text-white/80">
          <span><span className="inline-block h-2 w-2 bg-[#ffe08a]" /> Locais</span>
          <span><span className="inline-block h-2 w-2 bg-[#c070ff]" /> Cavernas</span>
          <span><span className="inline-block h-2 w-2 bg-[#ff4fd8]" /> Você</span>
          <span>? Não descoberto</span>
        </div>
      </div>
    </div>
  );
}
