/**
 * SPR - Sahil Powerful Run
 * In-Game Heads-Up Display (HUD) & Touch Overlay
 * Includes 3D Skateboard deployment button and active timer indicator
 */

import React from 'react';
import {
  Pause,
  Shield,
  Zap,
  Rocket,
  Magnet,
  Sparkles,
  ArrowLeft,
  ArrowRight,
  ArrowDown,
  AlertTriangle,
  Disc,
} from 'lucide-react';
import { PowerUpType } from '../game/constants';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  score: number;
  distance: number;
  coins: number;
  diamonds?: number;
  highScore: number;
  speed: number;
  activePowerUps: Record<PowerUpType, number>;
  dangerWarningActive: boolean;
  isSkating: boolean;
  skateboardTimer: number;
  newHighScoreNotice?: number | null;
  showControlButtons?: boolean;
  isPortrait?: boolean;
  onHome?: () => void;
  onPause: () => void;
  onSettings?: () => void;
  onLeaderboard?: () => void;
  onRunners?: () => void;
  onBoards?: () => void;
  onNotifications?: () => void;
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  onSwipeUp: () => void;
  onSwipeDown: () => void;
  onToggleSkateboard: () => void;
}

export const HUD: React.FC<Props> = ({
  score,
  distance,
  coins,
  diamonds = 0,
  highScore,
  speed,
  activePowerUps,
  dangerWarningActive,
  isSkating,
  skateboardTimer,
  newHighScoreNotice,
  showControlButtons = false,
  onPause,
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  onToggleSkateboard,
}) => {

  return (
    <div className="absolute inset-0 z-10 pointer-events-none select-none flex flex-col justify-between p-2.5 sm:p-4 safe-insets">
      {/* Real-Time Surpassed High Score Notification Banner */}
      {newHighScoreNotice !== null && newHighScoreNotice !== undefined && (
        <div className="absolute top-16 sm:top-20 left-1/2 -translate-x-1/2 z-30 pointer-events-none animate-bounce">
          <div className="flex flex-col items-center px-6 py-2 sm:px-8 sm:py-3 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-100 rounded-2xl shadow-[0_0_35px_rgba(234,179,8,0.9)] backdrop-blur text-center ring-4 ring-yellow-400/50">
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl">🏆</span>
              <span className="text-xs sm:text-base font-black tracking-widest text-slate-950 uppercase font-display">
                NEW HIGH SCORE!
              </span>
              <span className="text-xl sm:text-2xl">🏆</span>
            </div>
            <div className="text-2xl sm:text-4xl font-black text-slate-950 font-display tracking-wider drop-shadow-sm -mt-0.5">
              {newHighScoreNotice.toLocaleString()}
            </div>
          </div>
        </div>
      )}

      {/* Top Header: Clean Immersive In-Game HUD (No Menu Buttons During Active Run) */}
      <div className="w-full flex items-center justify-between gap-2 pointer-events-auto">
        {/* Top-Left: Pause Button + Multiplier Badge */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            id="hud-btn-pause"
            onClick={() => {
              soundManager.playButtonClick();
              onPause();
            }}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-sky-900/90 hover:bg-sky-800 active:bg-sky-700 border-2 border-sky-400/80 text-white flex items-center justify-center shadow-lg cursor-pointer active:scale-95 shrink-0 transition"
            title="Pause Game"
            aria-label="Pause"
          >
            <Pause className="w-5 h-5 fill-current" />
          </button>

          <div className="px-2.5 sm:px-3 py-1 bg-sky-950/90 border-2 border-yellow-400/80 rounded-2xl shadow backdrop-blur">
            <span className="text-sm sm:text-base font-black text-yellow-400 font-display tracking-wider">
              {activePowerUps.doubleCoins > 0 ? 'x4' : 'x2'}
            </span>
          </div>
        </div>

        {/* Center: Danger Zone Warning Banner (Only when active) */}
        {dangerWarningActive && (
          <div className="animate-bounce flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1 sm:py-1.5 bg-red-600/95 border-2 border-yellow-400 rounded-full shadow-[0_0_25px_rgba(220,38,38,0.9)] backdrop-blur pointer-events-none">
            <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-300 animate-pulse shrink-0" />
            <span className="text-[11px] sm:text-xs font-black tracking-widest text-white uppercase font-display whitespace-nowrap">
              ⚠️ DANGER ZONE!
            </span>
          </div>
        )}

        {/* Top-Right: Coins, Diamonds, and 6-Digit Score */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Coins */}
          <div
            id="hud-coin-balance"
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1 bg-sky-950/90 border-2 border-amber-400/80 rounded-2xl shadow backdrop-blur"
            title="Coins Collected"
          >
            <span className="text-xs sm:text-sm">🪙</span>
            <span className="text-amber-300 font-black text-xs sm:text-sm font-mono">
              {coins.toLocaleString()}
            </span>
          </div>

          {/* Diamonds */}
          <div
            id="hud-diamond-balance"
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1 bg-sky-950/90 border-2 border-cyan-400/80 rounded-2xl shadow backdrop-blur"
            title="Diamonds"
          >
            <span className="text-xs sm:text-sm">💎</span>
            <span className="text-cyan-300 font-black text-xs sm:text-sm font-mono">
              {diamonds.toLocaleString()}
            </span>
          </div>

          {/* 6-Digit Score */}
          <div className="px-2.5 sm:px-3.5 py-1 bg-sky-950/90 border-2 border-sky-500/70 rounded-2xl shadow-lg backdrop-blur">
            <span className="text-lg sm:text-2xl font-black font-display tracking-widest text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
              {score.toString().padStart(6, '0')}
            </span>
          </div>
        </div>
      </div>

      {/* Middle Side: Active Power-up Badges & Skateboard Indicator */}
      <div className="flex flex-col gap-2 my-auto self-start pointer-events-none">
        {/* Active Skateboard Badge */}
        {isSkating && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-cyan-950/90 border-2 border-cyan-400 rounded-full shadow-[0_0_16px_rgba(6,182,212,0.6)] backdrop-blur animate-pulse">
            <Disc className="w-4 h-4 text-cyan-300 animate-spin" />
            <span className="text-xs font-black text-cyan-200 uppercase tracking-wider font-display">
              SKATEBOARD RIDE
            </span>
            <span className="text-xs font-black text-white font-mono bg-cyan-900/80 px-1.5 py-0.5 rounded">
              {skateboardTimer}s
            </span>
          </div>
        )}

        {activePowerUps.shield > 0 && (
          <div className="flex items-center gap-2.5 px-4 py-2 bg-sky-950/90 border-2 border-cyan-400 rounded-2xl shadow-[0_0_16px_rgba(6,182,212,0.6)] backdrop-blur animate-pulse">
            <div className="w-7 h-7 rounded-xl bg-cyan-500/30 border border-cyan-300 flex items-center justify-center">
              <Shield className="w-4 h-4 text-cyan-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-black text-white uppercase tracking-wider font-display">SHIELD</span>
              <span className="text-xs font-black text-cyan-300 font-mono">{activePowerUps.shield.toFixed(0)}s</span>
            </div>
          </div>
        )}
        {activePowerUps.magnet > 0 && (
          <div className="flex items-center gap-2.5 px-4 py-2 bg-sky-950/90 border-2 border-red-400 rounded-2xl shadow-[0_0_16px_rgba(239,68,68,0.6)] backdrop-blur animate-pulse">
            <div className="w-7 h-7 rounded-xl bg-red-500/30 border border-red-300 flex items-center justify-center">
              <Magnet className="w-4 h-4 text-red-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-black text-white uppercase tracking-wider font-display">MAGNET</span>
              <span className="text-xs font-black text-red-300 font-mono">{activePowerUps.magnet.toFixed(0)}s</span>
            </div>
          </div>
        )}
        {activePowerUps.rocket > 0 && (
          <div className="flex items-center gap-2.5 px-4 py-2 bg-gradient-to-r from-orange-950/90 via-sky-950/90 to-amber-950/90 border-2 border-orange-400 rounded-2xl shadow-[0_0_20px_rgba(249,115,22,0.7)] backdrop-blur animate-pulse">
            <div className="w-7 h-7 rounded-xl bg-orange-500/30 border border-orange-300 flex items-center justify-center">
              <Rocket className="w-4 h-4 text-orange-400 animate-bounce" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-black text-white uppercase tracking-wider font-display flex items-center gap-1">
                ROCKET FLIGHT 🔥
              </span>
              <span className="text-xs font-black text-orange-300 font-mono">{activePowerUps.rocket.toFixed(0)}s</span>
            </div>
          </div>
        )}
        {activePowerUps.doubleCoins > 0 && (
          <div className="flex items-center gap-2.5 px-4 py-2 bg-sky-950/90 border-2 border-purple-400 rounded-2xl shadow-[0_0_16px_rgba(168,85,247,0.6)] backdrop-blur animate-pulse">
            <div className="w-7 h-7 rounded-xl bg-purple-500/30 border border-purple-300 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-purple-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-black text-white uppercase tracking-wider font-display">2X COINS</span>
              <span className="text-xs font-black text-purple-300 font-mono">{activePowerUps.doubleCoins.toFixed(0)}s</span>
            </div>
          </div>
        )}
        {activePowerUps.speedBoost > 0 && (
          <div className="flex items-center gap-2.5 px-4 py-2 bg-sky-950/90 border-2 border-amber-400 rounded-2xl shadow-[0_0_16px_rgba(245,158,11,0.6)] backdrop-blur animate-pulse">
            <div className="w-7 h-7 rounded-xl bg-amber-500/30 border border-amber-300 flex items-center justify-center">
              <Zap className="w-4 h-4 text-amber-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-black text-white uppercase tracking-wider font-display">BOOST</span>
              <span className="text-xs font-black text-amber-300 font-mono">{activePowerUps.speedBoost.toFixed(0)}s</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Controls: Optional on-screen gameplay icon buttons (Default: OFF) */}
      {showControlButtons && (
        <div className="flex items-end justify-between w-full pointer-events-auto mt-auto pb-1 animate-fade-in">
          {/* Left Side: Steering Controls (Left & Right) */}
          <div className="flex items-center gap-2.5">
            <button
              id="hud-btn-left"
              onClick={onSwipeLeft}
              onPointerDown={(e) => {
                e.preventDefault();
                onSwipeLeft();
              }}
              className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-sky-950/80 active:bg-sky-600 border-2 border-sky-500/70 active:border-cyan-300 flex items-center justify-center text-white backdrop-blur shadow-xl transition transform active:scale-95 cursor-pointer"
              aria-label="Move Left"
            >
              <ArrowLeft className="w-7 h-7 sm:w-8 sm:h-8" />
            </button>
            <button
              id="hud-btn-right"
              onClick={onSwipeRight}
              onPointerDown={(e) => {
                e.preventDefault();
                onSwipeRight();
              }}
              className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-sky-950/80 active:bg-sky-600 border-2 border-sky-500/70 active:border-cyan-300 flex items-center justify-center text-white backdrop-blur shadow-xl transition transform active:scale-95 cursor-pointer"
              aria-label="Move Right"
            >
              <ArrowRight className="w-7 h-7 sm:w-8 sm:h-8" />
            </button>
          </div>

          {/* Center: Interactive Skateboard Button (Clean Circular Button) & Slide */}
          <div className="flex flex-col items-center gap-2">
            <button
              id="hud-btn-skateboard"
              onClick={onToggleSkateboard}
              onPointerDown={(e) => {
                e.preventDefault();
                onToggleSkateboard();
              }}
              className={`relative w-13 h-13 sm:w-16 sm:h-16 rounded-full border-2 transition shadow-2xl flex flex-col items-center justify-center cursor-pointer transform active:scale-95 ${
                isSkating
                  ? 'bg-gradient-to-tr from-cyan-500 via-sky-400 to-blue-600 border-white text-slate-950 shadow-[0_0_25px_rgba(6,182,212,0.9)] animate-pulse'
                  : 'bg-gradient-to-b from-sky-900/90 to-slate-950/90 hover:from-sky-800 hover:to-slate-900 border-cyan-400/80 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
              }`}
              title="Ride 3D Skateboard (Double Tap / B)"
              aria-label="Toggle Skateboard"
            >
              <span className="text-xl sm:text-2xl leading-none select-none">🛹</span>
              {isSkating ? (
                <span className="absolute -bottom-1 px-1.5 py-0.2 bg-slate-950 text-cyan-300 border border-cyan-400 text-[9px] font-black rounded-full font-mono shadow">
                  {skateboardTimer}s
                </span>
              ) : null}
            </button>

            <button
              id="hud-btn-slide"
              onClick={onSwipeDown}
              onPointerDown={(e) => {
                e.preventDefault();
                onSwipeDown();
              }}
              className="px-5 py-1.5 rounded-xl bg-sky-950/80 active:bg-cyan-600 border border-sky-500/60 flex items-center gap-1.5 text-white backdrop-blur shadow-lg transition transform active:scale-95 cursor-pointer"
              aria-label="Slide"
            >
              <ArrowDown className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-wider font-display">SLIDE</span>
            </button>
          </div>

          {/* Right Side: Circular Glowing JUMP Button (Matching Reference Image) */}
          <div className="flex items-center">
            <button
              id="hud-btn-jump"
              onClick={onSwipeUp}
              onPointerDown={(e) => {
                e.preventDefault();
                onSwipeUp();
              }}
              className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-cyan-600 via-sky-500 to-cyan-400 active:from-cyan-400 active:to-cyan-200 border-3 border-cyan-200 flex flex-col items-center justify-center text-white font-black backdrop-blur shadow-[0_0_25px_rgba(6,182,212,0.8)] transition transform active:scale-95 cursor-pointer ring-4 ring-cyan-500/40"
              aria-label="Jump"
            >
              <div className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center text-2xl drop-shadow">
                🏃
              </div>
              <span className="text-[10px] sm:text-xs font-black uppercase tracking-widest font-display text-white drop-shadow -mt-0.5">
                JUMP
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
