import React from 'react';
import { Volume2, VolumeX, Pause, BookOpen, RotateCcw, Shirt, Coins, Smartphone } from 'lucide-react';
import { CharacterGender, SkinId } from '../types';

interface HUDProps {
  score: number;
  answeredCount: number;
  totalQuestions: number;
  collectedCapsules: number;
  gender: CharacterGender;
  equippedSkin: SkinId;
  walletPoints: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onOpenStudyGuide: () => void;
  onOpenSkinStore: () => void;
  onOpenAndroidAPK: () => void;
  onRestart: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  answeredCount,
  totalQuestions,
  collectedCapsules,
  gender,
  walletPoints,
  isMuted,
  onToggleMute,
  onPause,
  onOpenStudyGuide,
  onOpenSkinStore,
  onOpenAndroidAPK,
  onRestart,
}) => {
  const progressPercent = (answeredCount / totalQuestions) * 100;

  return (
    <>
      {/* Top HUD Bar */}
      <div className="fixed top-2.5 left-2.5 right-2.5 z-30 flex items-center justify-between gap-2 pointer-events-none">
        {/* Left cluster: Game Title & stats */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Character avatar badge button that can also open wardrobe */}
          <button
            onClick={onOpenSkinStore}
            title="تغيير الشخصية والزي"
            aria-label="خزانة الملابس"
            className="bg-[#08102ce6] border border-[#4cf5ff60] shadow-[0_0_16px_rgba(76,245,255,0.15)] rounded-xl px-2.5 py-1.5 text-xs font-bold flex items-center gap-1.5 backdrop-blur-md cursor-pointer hover:border-[#4cf5ff] transition-colors"
          >
            <span className="text-base">{gender === 'boy' ? '🧑‍🔬' : '👩‍🔬'}</span>
            <span className="text-[#4cf5ff] hidden sm:inline">
              {gender === 'boy' ? 'دكتور' : 'دكتورة'}
            </span>
          </button>

          <div className="bg-[#08102ce6] border border-[#4cf5ff60] shadow-[0_0_16px_rgba(76,245,255,0.15)] rounded-xl px-3 py-2 text-xs md:text-sm font-bold flex items-center gap-1.5 backdrop-blur-md">
            <span className="text-slate-400">المحطة:</span>
            <strong className="text-[#ffe18a] font-mono-num">
              {answeredCount} / {totalQuestions}
            </strong>
          </div>

          <div className="bg-[#08102ce6] border border-[#4cf5ff60] shadow-[0_0_16px_rgba(76,245,255,0.15)] rounded-xl px-3 py-2 text-xs md:text-sm font-bold flex items-center gap-1.5 backdrop-blur-md">
            <span className="text-slate-400">النقاط:</span>
            <strong className="text-[#ffe18a] font-mono-num">{score}</strong>
          </div>

          <div className="hidden lg:flex bg-[#08102ce6] border border-[#4cf5ff60] rounded-xl px-3 py-2 text-xs md:text-sm font-bold items-center gap-1.5 backdrop-blur-md">
            <span className="text-slate-400">كبسولات:</span>
            <strong className="text-[#4cf5ff] font-mono-num">{collectedCapsules}</strong>
          </div>

          <div className="hidden xl:flex bg-[#08102ce6] border border-[#ffe18a4d] rounded-xl px-3 py-2 text-xs font-bold items-center gap-1.5 backdrop-blur-md text-[#ffe18a]">
            <Coins className="w-3.5 h-3.5" />
            <span className="font-mono-num">{walletPoints}</span>
          </div>
        </div>

        {/* Right cluster: Functional buttons */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Android APK Button */}
          <button
            onClick={onOpenAndroidAPK}
            title="تثبيت التطبيق للأندرويد بصيغة APK"
            aria-label="تثبيت APK"
            className="h-10 px-2.5 sm:px-3 bg-[#083e29e6] hover:bg-[#0c593ce6] border border-[#38ef7d99] rounded-xl text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            <Smartphone className="w-4 h-4 text-[#38ef7d]" />
            <span className="hidden sm:inline">APK</span>
          </button>

          {/* Wardrobe & Skins Store */}
          <button
            onClick={onOpenSkinStore}
            title="خزانة الأزياء واسكنات الدكتور"
            aria-label="خزانة الأزياء"
            className="h-10 px-3 bg-[#0f1d46e6] hover:bg-[#1a2f6de6] border border-[#7a94ffe6] rounded-xl text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            <Shirt className="w-4 h-4 text-[#4cf5ff]" />
            <span className="hidden md:inline">الاسكنات</span>
          </button>

          {/* Study Guide button */}
          <button
            onClick={onOpenStudyGuide}
            title="دليل مراجعة الكيمياء التحليلية"
            aria-label="دليل المراجعة"
            className="h-10 px-3 bg-[#0f1d46e6] hover:bg-[#1a2f6de6] border border-[#7a94ffe6] rounded-xl text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            <BookOpen className="w-4 h-4 text-[#ffe18a]" />
            <span className="hidden md:inline">مراجعة المفاهيم</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
            aria-label={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
            className="w-10 h-10 bg-[#0f1d46e6] hover:bg-[#1a2f6de6] border border-[#7a94ffe6] rounded-xl text-white flex items-center justify-center transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#4cf5ff]" />
            )}
          </button>

          {/* Pause Button */}
          <button
            onClick={onPause}
            title="إيقاف مؤقت"
            aria-label="إيقاف مؤقت"
            className="w-10 h-10 bg-[#0f1d46e6] hover:bg-[#1a2f6de6] border border-[#7a94ffe6] rounded-xl text-white flex items-center justify-center transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            <Pause className="w-4 h-4 text-amber-300" />
          </button>

          {/* Quick Restart */}
          <button
            onClick={onRestart}
            title="إعادة البدء"
            aria-label="إعادة البدء"
            className="w-10 h-10 bg-[#0f1d46e6] hover:bg-[#1a2f6de6] border border-[#7a94ffe6] rounded-xl text-white flex items-center justify-center transition-colors shadow-sm active:scale-95 cursor-pointer backdrop-blur-md hidden sm:flex"
          >
            <RotateCcw className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </div>

      {/* Progress Track */}
      <div className="fixed top-14 left-2.5 right-2.5 z-30 h-1.5 rounded-full bg-[#0a122e] overflow-hidden border border-[#2b3e7560] pointer-events-none">
        <div
          className="h-full bg-gradient-to-r from-[#4cf5ff] via-[#9b6bff] to-[#ffe18a] transition-all duration-300 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Desktop Hint */}
      <div className="fixed top-18 left-1/2 -translate-x-1/2 z-20 hidden md:block text-center bg-[#071333e6] border border-[#8d9cff4d] px-3.5 py-1.5 rounded-full text-xs text-slate-300 pointer-events-none backdrop-blur-md shadow-lg">
        تحرك بـ <kbd className="text-[#ffe18a] font-mono px-1">← →</kbd> أو{' '}
        <kbd className="text-[#ffe18a] font-mono px-1">A / D</kbd> • اقفز بـ{' '}
        <kbd className="text-[#ffe18a] font-mono px-1">Space</kbd> • أوقف بـ{' '}
        <kbd className="text-[#ffe18a] font-mono px-1">Esc</kbd>
      </div>
    </>
  );
};
