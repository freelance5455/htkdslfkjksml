import React from 'react';
import {
  Volume2,
  VolumeX,
  Pause,
  Plane as PlaneIcon,
  Globe2,
  Zap,
  TrendingUp,
  Building2,
  Sparkles,
  BarChart3,
  User
} from 'lucide-react';
import { sound } from '../game/sound';

interface HUDProps {
  airlineName: string;
  cash: number;
  incomePerSec: number;
  fleetCount: number;
  unlockedCitiesCount: number;
  totalCitiesCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onPause: () => void;
  activeTab: 'fleet' | 'liveries' | 'upgrades' | 'airports' | 'analytics' | null;
  onSelectTab: (tab: 'fleet' | 'liveries' | 'upgrades' | 'airports' | 'analytics' | null) => void;
  hasRedeemedChristmas?: boolean;
  userAvatar?: string | null;
  userEmail?: string | null;
  onOpenAnalytics?: () => void;
}

export const HUD: React.FC<HUDProps> = React.memo(({
  airlineName,
  cash,
  incomePerSec,
  fleetCount,
  unlockedCitiesCount,
  totalCitiesCount,
  soundEnabled,
  onToggleSound,
  onPause,
  activeTab,
  onSelectTab,
  hasRedeemedChristmas,
  userAvatar,
  userEmail,
  onOpenAnalytics
}) => {
  const [zuluTime, setZuluTime] = React.useState('');

  React.useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setZuluTime(now.toUTCString().slice(17, 25) + ' Z');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Top Header Navigation Strip */}
      <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between px-4 sm:px-6 py-2.5 bg-[#090a0f]/95 border-b border-[#27272a] text-white">
        {/* Left: Custom Player Airline Name & Real-Time Zulu Clock */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-white text-black flex items-center justify-center font-black tracking-tighter text-sm font-mono shadow-sm">
            ✈
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold tracking-wider text-sm sm:text-base text-white truncate max-w-[180px] sm:max-w-none">
                {airlineName || 'GLOBAL AIRWAYS'}
              </span>
              <span className="hidden sm:inline-block px-1.5 py-0.5 rounded bg-[#18181b] border border-[#27272a] text-[10px] font-mono text-[#a1a1aa] tabular-nums">
                {zuluTime}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#71717a] font-mono">
              <span>WORLD FLIGHT NETWORK</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#a1a1aa]">{unlockedCitiesCount}/{totalCitiesCount} HUBS</span>
            </div>
          </div>
        </div>

        {/* Center: Live Financial Counter */}
        <div className="flex items-center gap-4 sm:gap-8">
          <div className="flex flex-col items-center sm:items-end">
            <div className="flex items-baseline gap-1.5 font-mono">
              <span className="text-xs text-[#a1a1aa]">$</span>
              <span className="text-xl sm:text-2xl font-bold tracking-tight text-white tabular-nums">
                {cash.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-mono text-[#a1a1aa]">
              <TrendingUp size={12} className="text-white" />
              <span className="tabular-nums">+${incomePerSec.toFixed(1)}/s</span>
            </div>
          </div>
        </div>

        {/* Right: Sound, Pilot Profile & Pause Controls */}
        <div className="flex items-center gap-2">
          {userEmail && (
            <button
              onClick={() => {
                if (onOpenAnalytics) onOpenAnalytics();
                else onSelectTab(activeTab === 'analytics' ? null : 'analytics');
              }}
              title={`Logged in as ${userEmail}. Click to view Analytics.`}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] text-xs font-mono text-white transition-colors cursor-pointer"
            >
              {userAvatar ? (
                <img src={userAvatar} alt="Pilot" className="w-4 h-4 rounded-full" />
              ) : (
                <User size={13} className="text-emerald-400" />
              )}
              <span className="truncate max-w-[100px]">{userEmail.split('@')[0]}</span>
            </button>
          )}

          <button
            onClick={() => {
              onToggleSound();
              sound.playClick();
            }}
            aria-label={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
            title={soundEnabled ? 'Mute Audio [M]' : 'Unmute Audio [M]'}
            className="p-2 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] border border-[#27272a] rounded-lg transition-colors cursor-pointer"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          <button
            onClick={() => {
              onPause();
              sound.playClick();
            }}
            aria-label="Pause Game"
            title="Pause [P / Esc]"
            className="p-2 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] border border-[#27272a] rounded-lg transition-colors cursor-pointer"
          >
            <Pause size={16} />
          </button>
        </div>
      </header>

      {/* Bottom Main Drawer Switcher Bar */}
      <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center p-1.5 bg-[#0e0f14]/95 border border-[#27272a] rounded-xl shadow-2xl gap-1 text-xs font-medium text-white max-w-[96vw] overflow-x-auto scrollbar-none">
        <button
          onClick={() => {
            onSelectTab(activeTab === 'fleet' ? null : 'fleet');
            sound.playClick();
          }}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'fleet'
              ? 'bg-white text-black font-semibold shadow-sm'
              : 'text-[#a1a1aa] hover:text-white hover:bg-[#18181b]'
          }`}
        >
          <PlaneIcon size={14} />
          <span>Fleet ({fleetCount})</span>
        </button>

        <button
          onClick={() => {
            onSelectTab(activeTab === 'liveries' ? null : 'liveries');
            sound.playClick();
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer relative ${
            activeTab === 'liveries'
              ? 'bg-red-600 text-white font-semibold shadow-sm'
              : 'text-[#a1a1aa] hover:text-white hover:bg-[#18181b]'
          }`}
        >
          <Sparkles size={14} className={activeTab === 'liveries' ? 'text-white' : 'text-red-400'} />
          <span>Skins & Codes</span>
          {!hasRedeemedChristmas && (
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" title="Special livery available" />
          )}
        </button>

        <button
          onClick={() => {
            onSelectTab(activeTab === 'upgrades' ? null : 'upgrades');
            sound.playClick();
          }}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'upgrades'
              ? 'bg-white text-black font-semibold shadow-sm'
              : 'text-[#a1a1aa] hover:text-white hover:bg-[#18181b]'
          }`}
        >
          <Zap size={14} />
          <span>Upgrades</span>
        </button>

        <button
          onClick={() => {
            onSelectTab(activeTab === 'airports' ? null : 'airports');
            sound.playClick();
          }}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'airports'
              ? 'bg-white text-black font-semibold shadow-sm'
              : 'text-[#a1a1aa] hover:text-white hover:bg-[#18181b]'
          }`}
        >
          <Building2 size={14} />
          <span>Airports ({unlockedCitiesCount})</span>
        </button>

        <button
          onClick={() => {
            onSelectTab(activeTab === 'analytics' ? null : 'analytics');
            sound.playClick();
          }}
          data-testid="analytics-tab-btn"
          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'analytics'
              ? 'bg-emerald-600 text-white font-semibold shadow-sm'
              : 'text-[#a1a1aa] hover:text-white hover:bg-[#18181b]'
          }`}
        >
          <BarChart3 size={14} />
          <span>Analytics</span>
        </button>
      </nav>
    </>
  );
});
