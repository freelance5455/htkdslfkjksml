import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameEngine, KillFeedItem } from '../game/core/GameEngine';
import { PlayerStats } from '../game/player/PlayerController';
import { HUDLayoutConfig, HUDManager } from '../game/hud/HUDConfig';
import { PerformanceMetrics } from '../game/core/PerformanceMonitor';
import { CrosshairView } from './CrosshairView';
import {
  RotateCcw,
  Shield,
  Heart,
  Settings,
  Flashlight,
  DollarSign,
  Skull,
  Compass,
  Crosshair,
  Flame,
  Zap,
  Activity,
  Award,
  Sparkles,
  Target,
  ChevronsUp,
  ChevronDown,
  FastForward,
  Sword,
  Eye,
} from 'lucide-react';
import { sound } from '../audio/SoundEngine';

interface HUDProps {
  engine: GameEngine;
  onOpenSettings: () => void;
  onOpenPause: () => void;
}

export const HUD: React.FC<HUDProps> = ({ engine, onOpenPause }) => {
  // Player Stats
  const [stats, setStats] = useState<PlayerStats>(engine.player.stats);
  const [currentAmmo, setCurrentAmmo] = useState(engine.weapons.activeWeapon.currentAmmo);
  const [reserveAmmo, setReserveAmmo] = useState(engine.weapons.activeWeapon.reserveAmmo);
  const [weaponName, setWeaponName] = useState(engine.weapons.activeWeapon.def.name);
  const [isAiming, setIsAiming] = useState(false);
  const [isReloading, setIsReloading] = useState(false);
  const [isMoving, setIsMoving] = useState(false);
  const [isFiring, setIsFiring] = useState(false);

  // Economy, XP & Kill Feed
  const [xp, setXp] = useState<number>(engine.xp);
  const [killFeed, setKillFeed] = useState<KillFeedItem[]>([]);

  // Performance telemetry metrics
  const [perf, setPerf] = useState<PerformanceMetrics>(engine.perfMonitor.metrics);
  const [showPerf, setShowPerf] = useState(true);

  // Wave info
  const [wave, setWave] = useState(engine.zombies.currentWave);
  const [isIntermission, setIsIntermission] = useState(engine.zombies.isWaveIntermission);
  const [zombiesRemaining, setZombiesRemaining] = useState(engine.zombies.totalWaveZombies);

  // Hitmarker & Damage & Prompts
  const [hitmarker, setHitmarker] = useState<{ active: boolean; isHeadshot: boolean }>({
    active: false,
    isHeadshot: false,
  });
  const [damageFlash, setDamageFlash] = useState(false);
  const [interactPrompt, setInteractPrompt] = useState<string | null>(null);

  // HUD Layout configuration
  const [hudConfig, setHudConfig] = useState<HUDLayoutConfig>(() => HUDManager.load());

  // --- MULTI-TOUCH ENGINE STATE ---
  const [joystickActive, setJoystickActive] = useState(false);
  const [joystickBasePos, setJoystickBasePos] = useState({ x: 120, y: 380 });
  const [stickOffset, setStickOffset] = useState({ x: 0, y: 0 });
  const moveTouchIdRef = useRef<number | null>(null);
  const moveOriginRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const lookTouchIdRef = useRef<number | null>(null);
  const lastLookPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const fireIntervalRef = useRef<number | null>(null);

  // Sync HUD config updates
  useEffect(() => {
    const handleStorage = () => {
      setHudConfig(HUDManager.load());
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Subscribe to engine callbacks
  useEffect(() => {
    engine.player.onStatsChange = (newStats) => {
      setStats(newStats);
    };

    engine.player.onDamageTaken = () => {
      setDamageFlash(true);
      setTimeout(() => setDamageFlash(false), 240);
    };

    engine.weapons.onAmmoChange = (curr, res) => {
      setCurrentAmmo(curr);
      setReserveAmmo(res);
      setWeaponName(engine.weapons.activeWeapon.def.name);
      setIsReloading(engine.weapons.activeWeapon.isReloading);
    };

    engine.weapons.onHit = (isHeadshot) => {
      setHitmarker({ active: true, isHeadshot });
      setTimeout(() => {
        setHitmarker(prev => ({ ...prev, active: false }));
      }, 120);
    };

    engine.zombies.onWaveChange = (w, intermission) => {
      setWave(w);
      setIsIntermission(intermission);
    };

    engine.zombies.onZombieCountChange = (remaining) => {
      setZombiesRemaining(remaining);
    };

    engine.player.onInteractPrompt = (prompt) => {
      setInteractPrompt(prompt);
    };

    engine.onMetricsUpdate = (m) => {
      setPerf(m);
    };

    engine.onKillFeedUpdate = (items) => {
      setKillFeed(items);
    };

    engine.onXPUpdate = (val) => {
      setXp(val);
    };

    return () => {
      engine.player.onStatsChange = undefined;
      engine.player.onDamageTaken = undefined;
      engine.weapons.onAmmoChange = undefined;
      engine.weapons.onHit = undefined;
      engine.zombies.onWaveChange = undefined;
      engine.zombies.onZombieCountChange = undefined;
      engine.player.onInteractPrompt = undefined;
      engine.onMetricsUpdate = undefined;
      engine.onKillFeedUpdate = undefined;
      engine.onXPUpdate = undefined;
    };
  }, [engine]);

  // Desktop Pointer Lock and Keyboard Listeners
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === engine.renderer.domElement) {
        engine.player.addLookDelta(e.movementX, e.movementY);
        engine.weapons.addSway(e.movementX, e.movementY);
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      // Fix critical fire bug: If clicking on ANY button or UI element, DO NOT FIRE!
      const target = e.target as HTMLElement;
      if (target && (target.closest('button') || target.closest('[role="button"]') || target.closest('input') || target.closest('.pointer-events-auto'))) {
        return;
      }

      if (document.pointerLockElement !== engine.renderer.domElement) {
        engine.renderer.domElement.requestPointerLock?.();
      } else {
        if (e.button === 0) {
          handleShoot();
        } else if (e.button === 2) {
          handleToggleAim();
        }
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyR') {
        engine.weapons.reload();
      } else if (e.code === 'KeyQ' || e.code === 'Digit1' || e.code === 'Digit2') {
        engine.weapons.switchWeapon();
        sound.playUIClick();
      } else if (e.code === 'KeyE') {
        engine.interactWithNearest();
      } else if (e.code === 'KeyP') {
        setShowPerf(prev => !prev);
      } else if (e.code === 'KeyC') {
        if (engine.player.isSprinting) {
          engine.player.triggerSlide();
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', stopContinuousFire);
    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', stopContinuousFire);
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [engine]);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsMoving(engine.player.isPlayerMoving());
    }, 100);
    return () => clearInterval(interval);
  }, [engine]);

  const handleShoot = useCallback(() => {
    const targets = engine.zombies.getRaycastTargets();
    const shot = engine.weapons.shoot(targets);
    if (shot) {
      setIsFiring(true);
      setTimeout(() => setIsFiring(false), 75);
    }
  }, [engine]);

  const startContinuousFire = () => {
    handleShoot();
    if (fireIntervalRef.current) clearInterval(fireIntervalRef.current);
    fireIntervalRef.current = window.setInterval(() => {
      handleShoot();
    }, 55);
  };

  const stopContinuousFire = () => {
    if (fireIntervalRef.current) {
      clearInterval(fireIntervalRef.current);
      fireIntervalRef.current = null;
    }
  };

  const handleToggleAim = () => {
    const nextAim = !engine.weapons.activeWeapon.isAiming;
    engine.weapons.setAim(nextAim);
    engine.player.isAiming = nextAim;
    setIsAiming(nextAim);
    sound.playUIClick();
  };

  const handleButtonTap = (action: () => void) => (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
    if ('changedTouches' in e) {
      e.preventDefault();
    }
    action();
  };

  // ADS Touch / Pointer handlers supporting Tap, Hold, and Hybrid (Requirement 10)
  const adsTouchStartRef = useRef(0);
  const handleAdsPointerDown = (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
    adsTouchStartRef.current = performance.now();
    const mode = engine.player.adsBehavior;

    if (mode === 'hold' || mode === 'hybrid') {
      engine.weapons.setAim(true);
      engine.player.isAiming = true;
      setIsAiming(true);
      if (engine.weapons.activeWeapon.def.type === 'sniper') sound.playScopeZoomSound();
      else sound.playAdsSound();
    } else if (mode === 'tap') {
      handleToggleAim();
    }
  };

  const handleAdsPointerUp = (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
    const mode = engine.player.adsBehavior;
    const holdDuration = performance.now() - adsTouchStartRef.current;

    if (mode === 'hold') {
      engine.weapons.setAim(false);
      engine.player.isAiming = false;
      setIsAiming(false);
    } else if (mode === 'hybrid') {
      // Quick tap (< 240ms) toggles on/off. Long hold (> 240ms) releases ADS on finger up.
      if (holdDuration > 240) {
        engine.weapons.setAim(false);
        engine.player.isAiming = false;
        setIsAiming(false);
      }
    }
  };

  // --- 1. LEFT ZONE: DYNAMIC / FLOATING TOUCH JOYSTICK ---
  const handleLeftTouchStart = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.clientX < window.innerWidth * 0.5) {
        moveTouchIdRef.current = touch.identifier;

        if (hudConfig.joystickMode === 'dynamic') {
          setJoystickBasePos({ x: touch.clientX, y: touch.clientY });
          moveOriginRef.current = { x: touch.clientX, y: touch.clientY };
        } else {
          const fixedX = (hudConfig.elements.joystick.x / 100) * window.innerWidth;
          const fixedY = (hudConfig.elements.joystick.y / 100) * window.innerHeight;
          setJoystickBasePos({ x: fixedX, y: fixedY });
          moveOriginRef.current = { x: fixedX, y: fixedY };
        }

        setJoystickActive(true);
        updateMovement(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleLeftTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === moveTouchIdRef.current) {
        updateMovement(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleLeftTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === moveTouchIdRef.current) {
        resetMoveTouch();
        break;
      }
    }
    let found = false;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === moveTouchIdRef.current) {
        found = true;
        break;
      }
    }
    if (!found) resetMoveTouch();
  };

  const resetMoveTouch = () => {
    moveTouchIdRef.current = null;
    setJoystickActive(false);
    setStickOffset({ x: 0, y: 0 });
    engine.player.virtualMoveX = 0;
    engine.player.virtualMoveY = 0;
    engine.player.virtualSprint = false;
  };

  const updateMovement = (clientX: number, clientY: number) => {
    const origin = moveOriginRef.current;
    let dx = clientX - origin.x;
    let dy = clientY - origin.y;
    const maxRadius = 60 * hudConfig.elements.joystick.scale;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setStickOffset({ x: dx, y: dy });

    const normX = dx / maxRadius;
    const normY = dy / maxRadius;

    engine.player.virtualMoveX = normX;
    engine.player.virtualMoveY = normY;
    engine.player.virtualSprint = normY < -0.65;
  };

  // --- 2. RIGHT ZONE: CAMERA TOUCH LOOK DRAG ---
  const handleRightTouchStart = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.clientX >= window.innerWidth * 0.5 && lookTouchIdRef.current === null) {
        lookTouchIdRef.current = touch.identifier;
        lastLookPosRef.current = { x: touch.clientX, y: touch.clientY };
        break;
      }
    }
  };

  const handleRightTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current) {
        const dx = touch.clientX - lastLookPosRef.current.x;
        const dy = touch.clientY - lastLookPosRef.current.y;
        lastLookPosRef.current = { x: touch.clientX, y: touch.clientY };

        engine.player.addLookDelta(dx, dy);
        engine.weapons.addSway(dx, dy);
        break;
      }
    }
  };

  const handleRightTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchIdRef.current) {
        lookTouchIdRef.current = null;
        break;
      }
    }
    let found = false;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === lookTouchIdRef.current) {
        found = true;
        break;
      }
    }
    if (!found) lookTouchIdRef.current = null;
  };

  const getStyle = (elemId: string): React.CSSProperties => {
    const elem = hudConfig.elements[elemId];
    if (!elem) return { display: 'none' };
    return {
      left: `${elem.x}%`,
      top: `${elem.y}%`,
      transform: `translate(-50%, -50%) scale(${elem.scale})`,
      opacity: elem.opacity,
      display: elem.visible ? 'flex' : 'none',
      position: 'absolute',
    };
  };

  const currentLevel = Math.floor(xp / 500) + 1;
  const currentLevelXP = xp % 500;

  return (
    <div className="absolute inset-0 z-30 select-none overflow-hidden touch-none pointer-events-none">
      {/* Damage Screen Vignette */}
      {damageFlash && (
        <div className="absolute inset-0 bg-red-600/30 transition-opacity duration-150 pointer-events-none vignette-damage" />
      )}
      {stats.health <= 70 && !stats.isDead && (
        <div className="absolute inset-0 vignette-critical pointer-events-none" />
      )}

      {/* --- SEPARATE TOUCH SENSOR LAYERS --- */}
      {/* 1. Left Movement Touch Area */}
      <div
        onTouchStart={handleLeftTouchStart}
        onTouchMove={handleLeftTouchMove}
        onTouchEnd={handleLeftTouchEnd}
        onTouchCancel={handleLeftTouchEnd}
        className="absolute left-0 top-0 w-1/2 h-full z-10 pointer-events-auto touch-none"
      />

      {/* 2. Right Camera Look Touch Area */}
      <div
        onTouchStart={handleRightTouchStart}
        onTouchMove={handleRightTouchMove}
        onTouchEnd={handleRightTouchEnd}
        onTouchCancel={handleRightTouchEnd}
        className="absolute right-0 top-0 w-1/2 h-full z-10 pointer-events-auto touch-none"
      />

      {/* --- DYNAMIC / FLOATING ANALOG JOYSTICK VISUAL --- */}
      {(joystickActive || hudConfig.joystickMode === 'fixed') && hudConfig.elements.joystick.visible && (
        <div
          className="pointer-events-none z-25 absolute -translate-x-1/2 -translate-y-1/2 transition-opacity"
          style={{
            left: hudConfig.joystickMode === 'dynamic' ? `${joystickBasePos.x}px` : `${hudConfig.elements.joystick.x}%`,
            top: hudConfig.joystickMode === 'dynamic' ? `${joystickBasePos.y}px` : `${hudConfig.elements.joystick.y}%`,
            opacity: joystickActive ? hudConfig.elements.joystick.opacity : hudConfig.elements.joystick.opacity * 0.5,
          }}
        >
          <div
            className="rounded-full bg-zinc-950/50 border-2 border-zinc-500/70 backdrop-blur-sm flex items-center justify-center shadow-2xl"
            style={{
              width: `${120 * hudConfig.elements.joystick.scale}px`,
              height: `${120 * hudConfig.elements.joystick.scale}px`,
            }}
          >
            <div
              className={`rounded-full bg-gradient-to-br from-zinc-500 to-zinc-700 border-2 border-zinc-300 shadow-xl flex items-center justify-center ${
                joystickActive ? 'border-red-400 scale-105' : ''
              }`}
              style={{
                width: `${52 * hudConfig.elements.joystick.scale}px`,
                height: `${52 * hudConfig.elements.joystick.scale}px`,
                transform: `translate(${stickOffset.x}px, ${stickOffset.y}px)`,
              }}
            >
              <Compass className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      )}

      {/* --- CENTER FIXED CROSSHAIR & HITMARKER --- */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none flex items-center justify-center">
        <CrosshairView
          config={hudConfig.crosshair}
          isAiming={isAiming}
          isMoving={isMoving}
          isFiring={isFiring}
        />

        {hitmarker.active && (
          <div className="absolute w-8 h-8 pointer-events-none animate-ping duration-75">
            <svg viewBox="0 0 32 32" className="w-full h-full">
              <line x1="6" y1="6" x2="12" y2="12" stroke={hitmarker.isHeadshot ? '#fbbf24' : '#ef4444'} strokeWidth="2.8" />
              <line x1="26" y1="6" x2="20" y2="12" stroke={hitmarker.isHeadshot ? '#fbbf24' : '#ef4444'} strokeWidth="2.8" />
              <line x1="6" y1="26" x2="12" y2="20" stroke={hitmarker.isHeadshot ? '#fbbf24' : '#ef4444'} strokeWidth="2.8" />
              <line x1="26" y1="26" x2="20" y2="20" stroke={hitmarker.isHeadshot ? '#fbbf24' : '#ef4444'} strokeWidth="2.8" />
            </svg>
          </div>
        )}
      </div>

      {/* --- TELEMETRY & STATUS OVERLAY (TOP CENTER) --- */}
      {showPerf && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center gap-2 px-3 py-0.5 rounded-full bg-black/65 border border-zinc-800 text-[10px] font-mono-tech text-zinc-400 backdrop-blur-xs">
          <Activity className="w-3 h-3 text-emerald-400" />
          <span className={perf.fps < 45 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
            {perf.fps} FPS
          </span>
          <span>•</span>
          <span>{perf.frameTime}ms</span>
          <span>•</span>
          <span>{perf.activeZombies} AI</span>
        </div>
      )}

      {/* --- KILL FEED POPUPS (TOP-LEFT / CENTER) --- */}
      <div className="absolute top-20 left-6 z-25 pointer-events-none flex flex-col gap-1.5 max-w-xs">
        {killFeed.map(item => (
          <div
            key={item.id}
            className="flex items-center gap-2 px-3 py-1 rounded-lg bg-black/75 border border-red-800/80 text-white font-mono-tech text-xs shadow-lg animate-fade-in"
          >
            <Skull className="w-3.5 h-3.5 text-red-500" />
            <span className="font-bold text-red-400">+{item.points}</span>
            <span className="text-zinc-200 uppercase">{item.text}</span>
            <span className="text-amber-400 font-bold text-[10px]">+{item.xp} XP</span>
          </div>
        ))}
      </div>

      {/* --- SNIPER SCOPE FULLSCREEN OVERLAY (Requirement 8) --- */}
      {isAiming && engine.weapons.activeWeapon.def.type === 'sniper' && (
        <div className="absolute inset-0 z-20 pointer-events-none flex items-center justify-center bg-black/40">
          {/* Black outer scope housing with vignette */}
          <div className="relative w-[85vmin] h-[85vmin] rounded-full border-[10vmin] border-black/95 shadow-[0_0_120px_40px_rgba(0,0,0,0.95)] overflow-hidden flex items-center justify-center">
            {/* Fine Mils-Dot Reticle */}
            <svg viewBox="0 0 400 400" className="w-full h-full">
              {/* Scope outer ring */}
              <circle cx="200" cy="200" r="185" stroke="#10b981" strokeWidth="1" strokeOpacity="0.4" fill="none" />
              {/* Horizontal Crosshair */}
              <line x1="20" y1="200" x2="380" y2="200" stroke="#0f172a" strokeWidth="2" />
              <line x1="20" y1="200" x2="380" y2="200" stroke="#10b981" strokeWidth="1" strokeOpacity="0.8" />
              {/* Vertical Crosshair */}
              <line x1="200" y1="20" x2="200" y2="380" stroke="#0f172a" strokeWidth="2" />
              <line x1="200" y1="20" x2="200" y2="380" stroke="#10b981" strokeWidth="1" strokeOpacity="0.8" />
              {/* Elevation Range Hash Marks */}
              {[-120, -90, -60, -30, 30, 60, 90, 120].map((offset, i) => (
                <line key={`h_${i}`} x1={200 + offset} y1="195" x2={200 + offset} y2="205" stroke="#10b981" strokeWidth="1" />
              ))}
              {[-120, -90, -60, -30, 30, 60, 90, 120].map((offset, i) => (
                <line key={`v_${i}`} x1="195" y1={200 + offset} x2="205" y2={200 + offset} stroke="#10b981" strokeWidth="1" />
              ))}
              {/* Illuminated Center Dot */}
              <circle cx="200" cy="200" r="2.5" fill="#ef4444" />
            </svg>
          </div>
        </div>
      )}

      {/* --- CUSTOMIZABLE ACTION BUTTONS & HUD MODULES (Clean Modern CoD Icons - Requirement 12) --- */}

      {/* 1. Primary Fire Button (Target / Muzzle Blast Icon) */}
      <div style={getStyle('fire')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={(e) => { e.stopPropagation(); startContinuousFire(); }}
          onTouchEnd={(e) => { e.stopPropagation(); stopContinuousFire(); }}
          onMouseDown={(e) => { e.stopPropagation(); startContinuousFire(); }}
          onMouseUp={(e) => { e.stopPropagation(); stopContinuousFire(); }}
          className="w-20 h-20 rounded-full bg-gradient-to-br from-red-600 via-red-700 to-red-800 active:from-red-500 active:to-red-600 border-3 border-red-400 shadow-2xl shadow-red-600/60 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
          title="Fire"
        >
          <Target className="w-10 h-10 drop-shadow-md" />
        </button>
      </div>

      {/* 2. ADS Button (Reticle / Sight Icon + Tap/Hold/Hybrid handling) */}
      <div style={getStyle('ads')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleAdsPointerDown}
          onTouchEnd={handleAdsPointerUp}
          onMouseDown={handleAdsPointerDown}
          onMouseUp={handleAdsPointerUp}
          className={`w-14 h-14 rounded-full border-2 flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
            isAiming
              ? 'bg-red-600/50 border-red-400 text-white shadow-red-600/40 scale-105'
              : 'bg-zinc-900/90 border-zinc-600 text-zinc-200'
          }`}
          title="Aim Down Sights (ADS)"
        >
          {engine.weapons.activeWeapon.def.type === 'sniper' ? (
            <Eye className="w-7 h-7" />
          ) : (
            <Crosshair className="w-7 h-7" />
          )}
        </button>
      </div>

      {/* 3. Reload Button (Circular Arrow Icon) */}
      <div style={getStyle('reload')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.weapons.reload())}
          onClick={handleButtonTap(() => engine.weapons.reload())}
          className="w-14 h-14 rounded-full bg-zinc-900/90 active:bg-zinc-800 text-amber-400 border-2 border-amber-500/60 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer"
          title="Reload"
        >
          <RotateCcw className="w-7 h-7" />
        </button>
      </div>

      {/* 4. Jump Button (Leaping Chevron Icon) */}
      <div style={getStyle('jump')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.player.jump())}
          onClick={handleButtonTap(() => engine.player.jump())}
          className="w-14 h-14 rounded-full bg-zinc-900/90 active:bg-zinc-800 text-zinc-200 border-2 border-zinc-600 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer"
          title="Jump"
        >
          <ChevronsUp className="w-8 h-8" />
        </button>
      </div>

      {/* 5. Crouch Button (Crouching Downward Chevron Icon) */}
      <div style={getStyle('crouch')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => {
            engine.player.isCrouching = !engine.player.isCrouching;
            sound.playUIClick();
          })}
          onClick={handleButtonTap(() => {
            engine.player.isCrouching = !engine.player.isCrouching;
            sound.playUIClick();
          })}
          className={`w-13 h-13 rounded-full border-2 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer ${
            engine.player.isCrouching ? 'bg-amber-600/40 border-amber-400 text-white' : 'bg-zinc-900/90 border-zinc-600 text-zinc-200'
          }`}
          title="Crouch"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </div>

      {/* 6. Tactical Slide Button (Sliding Arrow Icon) */}
      <div style={getStyle('slide')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.player.triggerSlide())}
          onClick={handleButtonTap(() => engine.player.triggerSlide())}
          className={`w-13 h-13 rounded-full border-2 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer ${
            engine.player.isSliding ? 'bg-cyan-600/60 border-cyan-300 text-white scale-105' : 'bg-zinc-900/90 border-cyan-500/60 text-cyan-300'
          }`}
          title="Slide"
        >
          <FastForward className="w-6 h-6" />
        </button>
      </div>

      {/* 7. Sprint Button (Sprint Bolt Icon) */}
      <div style={getStyle('sprint')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => {
            engine.player.virtualSprint = !engine.player.virtualSprint;
            sound.playUIClick();
          })}
          onClick={handleButtonTap(() => {
            engine.player.virtualSprint = !engine.player.virtualSprint;
            sound.playUIClick();
          })}
          className={`w-12 h-12 rounded-full border-2 flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer ${
            engine.player.isSprinting ? 'bg-red-600/50 border-red-400 text-white' : 'bg-zinc-900/90 border-zinc-600 text-zinc-300'
          }`}
          title="Sprint"
        >
          <Zap className="w-6 h-6" />
        </button>
      </div>

      {/* 8. Quick Knife Melee Button (Combat Knife Icon) */}
      <div style={getStyle('melee')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.player.melee())}
          onClick={handleButtonTap(() => engine.player.melee())}
          className="w-13 h-13 rounded-full bg-zinc-900/90 active:bg-zinc-800 text-red-400 border-2 border-red-500/70 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer"
          title="Knife Melee"
        >
          <Sword className="w-6 h-6" />
        </button>
      </div>

      {/* 9. Tactical Frag Grenade Button (Frag Pin Icon) */}
      <div style={getStyle('grenade')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.player.throwGrenade(engine.scene))}
          onClick={handleButtonTap(() => engine.player.throwGrenade(engine.scene))}
          className="relative w-13 h-13 rounded-full bg-zinc-900/90 active:bg-zinc-800 text-emerald-400 border-2 border-emerald-500/70 flex items-center justify-center shadow-xl active:scale-90 transition-transform cursor-pointer"
          title="Frag Grenade"
        >
          <Flame className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-600 text-white font-mono-tech text-[10px] flex items-center justify-center font-bold">
            {stats.grenades}
          </span>
        </button>
      </div>

      {/* 10. Tactical Flashlight Button (Clean Tap Toggle) */}
      <div style={getStyle('flashlight')} className="z-30 pointer-events-auto">
        <button
          onTouchStart={handleButtonTap(() => engine.player.toggleFlashlight())}
          onClick={handleButtonTap(() => engine.player.toggleFlashlight())}
          className={`w-12 h-12 rounded-full border-2 flex items-center justify-center shadow-lg active:scale-90 transition-colors cursor-pointer ${
            stats.flashlightOn
              ? 'bg-amber-500/40 border-amber-400 text-amber-300 shadow-amber-500/40'
              : 'bg-zinc-900/90 border-zinc-700 text-zinc-400'
          }`}
        >
          <Flashlight className="w-5 h-5" />
        </button>
      </div>

      {/* 11. Weapon Switch / Ammo Status */}
      <div style={getStyle('switch_weapon')} className="z-30 pointer-events-auto">
        <div
          onTouchStart={handleButtonTap(() => {
            engine.weapons.switchWeapon();
            sound.playUIClick();
          })}
          onClick={handleButtonTap(() => {
            engine.weapons.switchWeapon();
            sound.playUIClick();
          })}
          className="flex items-center gap-3 bg-zinc-950/85 backdrop-blur-md p-2.5 rounded-2xl border border-zinc-800 shadow-2xl cursor-pointer hover:border-zinc-600 transition-colors"
        >
          <div className="flex flex-col items-end">
            <span className="font-teko text-2xl text-white font-bold tracking-wider leading-none">
              {weaponName}
            </span>
            <span className="font-mono-tech text-[9px] text-zinc-400 uppercase">
              TAP TO SWITCH
            </span>
          </div>

          <div className="h-7 w-[1px] bg-zinc-800" />

          <div className="flex items-baseline gap-1">
            <span
              className={`font-teko text-3xl font-bold leading-none ${
                currentAmmo <= 5 ? 'text-red-500 animate-pulse' : 'text-amber-400'
              }`}
            >
              {isReloading ? '...' : currentAmmo}
            </span>
            <span className="font-mono-tech text-xs text-zinc-500 font-semibold">/ {reserveAmmo}</span>
          </div>
        </div>
      </div>

      {/* 12. Health & Armor Bar */}
      <div style={getStyle('health_bar')} className="z-30 pointer-events-auto">
        <div className="flex flex-col gap-1.5 bg-zinc-950/85 backdrop-blur-md p-2 rounded-xl border border-zinc-800/80 shadow-xl w-48 sm:w-56">
          <div className="flex items-center gap-2">
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 shrink-0" />
            <div className="flex-1 h-2.5 bg-zinc-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-red-500 rounded-full transition-all duration-150"
                style={{ width: `${(stats.health / stats.maxHealth) * 100}%` }}
              />
            </div>
            <span className="font-mono-tech text-[10px] text-red-400 font-bold min-w-[45px] text-right">
              {Math.round(stats.health)}/{stats.maxHealth}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400 shrink-0" />
            <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-cyan-400 rounded-full transition-all duration-150"
                style={{ width: `${(stats.armor / stats.maxArmor) * 100}%` }}
              />
            </div>
            <span className="font-mono-tech text-[10px] text-cyan-300 font-bold min-w-[45px] text-right">
              {stats.armor}
            </span>
          </div>
        </div>
      </div>

      {/* 13. Wave Banner, Kill Counter & XP Banner */}
      <div style={getStyle('wave_counter')} className="z-30 pointer-events-auto flex flex-col gap-1">
        <div className="flex items-center gap-3 bg-zinc-950/85 backdrop-blur-md border border-zinc-800/80 px-3.5 py-1.5 rounded-xl shadow-xl">
          <div className="flex flex-col">
            <span className="text-zinc-400 font-mono-tech text-[9px] tracking-widest uppercase">
              {isIntermission ? 'INTERMISSION' : 'ROUND'}
            </span>
            <span className="text-2xl font-teko leading-none text-red-500 font-bold tracking-wider">
              {isIntermission ? 'NEXT WAVE...' : `WAVE ${wave}`}
            </span>
          </div>

          <div className="h-6 w-[1px] bg-zinc-800" />

          <div className="flex items-center gap-1.5">
            <Skull className="w-3.5 h-3.5 text-red-400" />
            <div className="flex flex-col">
              <span className="text-zinc-400 font-mono-tech text-[9px] uppercase">ZOMBIES</span>
              <span className="text-lg font-teko leading-none text-white font-semibold">
                {zombiesRemaining}
              </span>
            </div>
          </div>

          <div className="h-6 w-[1px] bg-zinc-800" />

          {/* Kill Counter */}
          <div className="flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <div className="flex flex-col">
              <span className="text-zinc-400 font-mono-tech text-[9px] uppercase">KILLS</span>
              <span className="text-lg font-teko leading-none text-amber-400 font-bold">
                {stats.kills}
              </span>
            </div>
          </div>
        </div>

        {/* Level & XP Bar */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-black/75 border border-zinc-800 text-[10px] font-mono-tech text-zinc-400">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span className="text-white font-bold">LVL {currentLevel}</span>
          <div className="flex-1 h-1 bg-zinc-800 rounded-full overflow-hidden">
            <div className="h-full bg-amber-400" style={{ width: `${(currentLevelXP / 500) * 100}%` }} />
          </div>
          <span className="text-zinc-400">{currentLevelXP}/500 XP</span>
          <span className="text-emerald-400 font-bold">${stats.points}</span>
        </div>
      </div>

      {/* 14. Radar Minimap & Pause Button */}
      <div style={getStyle('radar')} className="z-30 pointer-events-auto flex items-center gap-2">
        <div className="relative w-15 h-15 rounded-full bg-zinc-950/90 backdrop-blur-md border-2 border-emerald-500/50 shadow-xl overflow-hidden flex items-center justify-center">
          <div className="absolute inset-0 border border-emerald-500/20 rounded-full scale-50" />
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-emerald-500/10 to-transparent rounded-full animate-spin [animation-duration:3s]" />
          <div className="w-2 h-2 bg-emerald-400 rounded-full shadow-[0_0_6px_#34d399] z-10" />

          {engine.zombies.zombies.filter(z => !z.isDead).map((zb, idx) => {
            const dx = zb.rig.root.position.x - engine.player.position.x;
            const dz = zb.rig.root.position.z - engine.player.position.z;
            const cos = Math.cos(engine.player.yaw);
            const sin = Math.sin(engine.player.yaw);
            const rx = dx * cos - dz * sin;
            const rz = dx * sin + dz * cos;
            const px = Math.max(-24, Math.min(24, rx * 1.2));
            const pz = Math.max(-24, Math.min(24, rz * 1.2));
            return (
              <div
                key={idx}
                className="absolute w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_4px_#ef4444]"
                style={{ transform: `translate(${px}px, ${pz}px)` }}
              />
            );
          })}
        </div>

        <button
          onTouchStart={handleButtonTap(() => {
            sound.playUIClick();
            onOpenPause();
          })}
          onClick={handleButtonTap(() => {
            sound.playUIClick();
            onOpenPause();
          })}
          className="w-9 h-9 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 flex items-center justify-center border border-zinc-700/80 shadow-lg cursor-pointer active:scale-90 transition-transform"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {/* Top Center: Wall-Buy / Barricade / Door Prompt */}
      {interactPrompt && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 pointer-events-auto">
          <button
            onTouchStart={handleButtonTap(() => engine.interactWithNearest())}
            onClick={handleButtonTap(() => engine.interactWithNearest())}
            className="animate-bounce px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-zinc-950 font-teko text-xl tracking-wider uppercase font-bold rounded-xl shadow-2xl border border-amber-300 flex items-center gap-2 cursor-pointer"
          >
            <DollarSign className="w-5 h-5 fill-zinc-950" />
            <span>{interactPrompt}</span>
          </button>
        </div>
      )}
    </div>
  );
};
