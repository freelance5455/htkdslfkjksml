import React from 'react';
import { Volume2, VolumeX, Pause, Play, Tv, Flame, Shield, Award, Music, Smartphone } from 'lucide-react';
import { TrackConfig } from '../types.ts';

interface HUDProps {
  score: number;
  highScore: number;
  speed: number;
  maxSpeed: number;
  health: number;
  nitro: number;
  isNitroActive: boolean;
  track: TrackConfig;
  isPaused: boolean;
  isMuted: boolean;
  isMusicMuted: boolean;
  isCrtEnabled: boolean;
  isTiltEnabled: boolean;
  tiltAngle: number;
  onTogglePause: () => void;
  onToggleMute: () => void;
  onToggleMusic: () => void;
  onToggleTilt: () => void;
  onToggleCrt: () => void;
  onShowLeaderboard: () => void;
  onHorn: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  highScore,
  speed,
  maxSpeed,
  health,
  nitro,
  isNitroActive,
  track,
  isPaused,
  isMuted,
  isMusicMuted,
  isCrtEnabled,
  isTiltEnabled,
  tiltAngle,
  onTogglePause,
  onToggleMute,
  onToggleMusic,
  onToggleTilt,
  onToggleCrt,
  onShowLeaderboard,
  onHorn
}) => {
  const speedKmh = Math.floor(speed * 18);
  const maxKmh = Math.floor(maxSpeed * 22);
  const speedRatio = Math.min(1, speedKmh / maxKmh);

  return (
    <div 
      dir="ltr"
      className="absolute top-0 inset-x-0 p-2 md:p-4 pointer-events-none z-20 flex flex-col gap-2 font-mono"
    >
      {/* Top Bar Status */}
      <div className="flex items-center justify-between gap-2 bg-black/80 backdrop-blur-md border-2 border-amber-500/80 rounded-xl px-2.5 sm:px-3 py-2 text-white shadow-xl pointer-events-auto">
        {/* Score & High Score */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex flex-col">
            <span className="text-[9px] sm:text-[10px] text-amber-400 font-bold uppercase tracking-wider font-cairo">النقاط / SCORE</span>
            <span className="text-lg sm:text-2xl font-black text-amber-300 font-press-start tracking-tight">
              {score.toString().padStart(5, '0')}
            </span>
          </div>
          <div className="hidden sm:flex flex-col border-l border-white/20 pl-3">
            <span className="text-[10px] text-gray-400 font-bold font-cairo">أعلى سكور / BEST</span>
            <span className="text-sm font-bold text-gray-300 font-press-start">
              {highScore.toString().padStart(5, '0')}
            </span>
          </div>
        </div>

        {/* Speedometer & Nitro */}
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center">
            <div className="flex items-baseline gap-1">
              <span className={`text-xl sm:text-3xl font-black font-press-start ${
                isNitroActive ? 'text-cyan-400 animate-pulse' : speedRatio > 0.8 ? 'text-rose-400' : 'text-emerald-400'
              }`}>
                {speedKmh}
              </span>
              <span className="text-[9px] sm:text-[10px] text-gray-300 font-bold">KM/H</span>
            </div>
            {/* Speed bar */}
            <div className="w-20 sm:w-32 h-2 bg-gray-800 rounded-full overflow-hidden border border-gray-600">
              <div 
                className={`h-full transition-all duration-75 ${
                  isNitroActive ? 'bg-gradient-to-r from-cyan-400 to-blue-500' : 'bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500'
                }`}
                style={{ width: `${speedRatio * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {/* Light Music toggle 🎵 */}
          <button
            onClick={onToggleMusic}
            title={isMusicMuted ? "تشغيل الموسيقى الخفيفة" : "كتم الموسيقى الخفيفة"}
            className={`p-1.5 sm:p-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
              !isMusicMuted ? 'bg-amber-500 text-black font-bold' : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            <Music className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="text-[9px] font-cairo hidden md:inline">موسيقى</span>
          </button>

          {/* Tilt phone steering toggle 📱 */}
          <button
            onClick={onToggleTilt}
            title="تبديل التحكم بإمالة الهاتف / Phone Tilt Steering"
            className={`p-1.5 sm:p-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
              isTiltEnabled ? 'bg-cyan-500 text-black font-bold' : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="text-[9px] font-cairo hidden md:inline">إمالة</span>
          </button>

          {/* Quick Horn button */}
          <button
            onClick={onHorn}
            title="كلاكسون / Horn (H)"
            className="p-1.5 sm:p-2 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white rounded-lg transition-transform text-xs font-bold font-cairo flex items-center gap-1 cursor-pointer"
          >
            <span>📢</span>
            <span className="hidden lg:inline">BIP!</span>
          </button>

          {/* CRT toggle */}
          <button
            onClick={onToggleCrt}
            title="تبديل شاشة قديمة / Toggle CRT Scanlines"
            className={`p-1.5 sm:p-2 rounded-lg transition-colors cursor-pointer ${
              isCrtEnabled ? 'bg-amber-500 text-black font-bold' : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            <Tv className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Master Sound FX Mute button */}
          <button
            onClick={onToggleMute}
            title="مؤثرات الصوت / Sound FX (M)"
            className="p-1.5 sm:p-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />}
          </button>

          {/* Pause button */}
          <button
            onClick={onTogglePause}
            title="إيقاف مؤقت / Pause (P)"
            className="p-1.5 sm:p-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            {isPaused ? <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" /> : <Pause className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />}
          </button>

          {/* High Scores button */}
          <button
            onClick={onShowLeaderboard}
            title="قائمة الشرف / Leaderboard"
            className="p-1.5 sm:p-2 bg-gray-800 hover:bg-gray-700 text-amber-400 rounded-lg transition-colors cursor-pointer"
          >
            <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>

      {/* Secondary Meters: Health & Nitro */}
      <div className="flex items-center justify-between px-2 text-xs">
        {/* Health */}
        <div className="flex items-center gap-1.5 sm:gap-2 bg-black/70 backdrop-blur-sm px-2.5 sm:px-3 py-1 rounded-lg border border-white/10">
          <Shield className="w-3.5 h-3.5 text-rose-400" />
          <span className="text-[9px] sm:text-[10px] text-gray-300 font-bold font-cairo">متانة / HP:</span>
          <div className="w-16 sm:w-28 h-2 bg-gray-800 rounded-full overflow-hidden border border-gray-700">
            <div 
              className={`h-full transition-all duration-200 ${
                health > 50 ? 'bg-emerald-500' : health > 25 ? 'bg-amber-500' : 'bg-rose-500 animate-pulse'
              }`}
              style={{ width: `${Math.max(0, health)}%` }}
            />
          </div>
          <span className="text-[9px] sm:text-[10px] font-bold">{Math.max(0, Math.round(health))}%</span>
        </div>

        {/* Nitro Meter */}
        <div className="flex items-center gap-1.5 sm:gap-2 bg-black/70 backdrop-blur-sm px-2.5 sm:px-3 py-1 rounded-lg border border-white/10">
          <Flame className={`w-3.5 h-3.5 ${nitro >= 100 ? 'text-cyan-400 animate-bounce' : 'text-gray-400'}`} />
          <span className="text-[9px] sm:text-[10px] text-gray-300 font-bold font-cairo">نيترو / NITRO:</span>
          <div className="w-16 sm:w-28 h-2 bg-gray-800 rounded-full overflow-hidden border border-gray-700">
            <div 
              className={`h-full transition-all duration-100 ${
                isNitroActive ? 'bg-cyan-300 animate-pulse' : nitro >= 100 ? 'bg-gradient-to-r from-blue-500 to-cyan-400' : 'bg-cyan-600'
              }`}
              style={{ width: `${Math.min(100, Math.max(0, nitro))}%` }}
            />
          </div>
          <span className="text-[9px] sm:text-[10px] font-bold text-cyan-300">{Math.round(nitro)}%</span>
        </div>
      </div>
    </div>
  );
};
