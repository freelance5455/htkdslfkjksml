import React, { useState } from 'react';
import { Compass, MapPin, Navigation, ExternalLink, Search, RefreshCw, X, ShieldAlert, Car, Wrench, Fuel, ShoppingBag, Stethoscope } from 'lucide-react';
import { NearbyPlace } from '../types';

interface NearbyPlacesModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoords?: { lat: number; lon: number };
}

export const NearbyPlacesModal: React.FC<NearbyPlacesModalProps> = ({ isOpen, onClose, userCoords }) => {
  const [searchQuery, setSearchQuery] = useState('mechanic');
  const [places, setPlaces] = useState<NearbyPlace[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSearch = async (term: string) => {
    setIsLoading(true);
    setErrorMsg(null);
    setSearchQuery(term);

    try {
      const lat = userCoords?.lat || 28.6139;
      const lon = userCoords?.lon || 77.2090;
      const res = await fetch(`/api/places/nearby?lat=${lat}&lon=${lon}&query=${encodeURIComponent(term)}`);
      if (!res.ok) throw new Error('Location service error');
      const data = await res.json();
      setPlaces(data.places || []);
    } catch (e: any) {
      setErrorMsg(e.message || 'Unable to retrieve nearby locations.');
    } finally {
      setIsLoading(false);
    }
  };

  const quickCategories = [
    { label: 'Mechanic / Garage', query: 'mechanic', icon: Wrench },
    { label: 'Petrol Pump', query: 'fuel', icon: Fuel },
    { label: 'Hospital / Clinic', query: 'hospital', icon: Stethoscope },
    { label: 'Grocery / Store', query: 'grocery', icon: ShoppingBag },
    { label: 'Car Repair', query: 'car repair', icon: Car },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              NEARBY SERVICES & ROUTE DIRECTIONS (PART 9)
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Truthful Traffic Notice */}
          <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-start gap-2.5 text-xs text-cyan-200">
            <ShieldAlert className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-bold uppercase tracking-wider block text-cyan-300">
                GPS Verified Distances & Live Traffic Standard
              </span>
              Distances are calculated from your verified GPS coordinates. Live real-time road traffic, lane congestion, and turn-by-turn routing are launched directly via official Google Maps Navigation.
            </div>
          </div>

          {/* Search Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (searchQuery.trim()) handleSearch(searchQuery.trim());
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search shops, mechanics, clinics, stores..."
              className="flex-1 px-4 py-2 bg-gray-950 border border-cyan-500/40 rounded-xl text-cyan-100 text-xs focus:outline-none focus:border-cyan-400"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-bold text-xs uppercase rounded-xl transition-all flex items-center gap-1 cursor-pointer glow-cyan-sm"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Search
            </button>
          </form>

          {/* Quick Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar">
            {quickCategories.map((cat) => (
              <button
                key={cat.query}
                onClick={() => handleSearch(cat.query)}
                className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-gray-950 border border-cyan-500/25 hover:border-cyan-400 text-cyan-200 text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <cat.icon className="w-3.5 h-3.5 text-cyan-400" />
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {errorMsg}
            </div>
          )}

          {/* Results List */}
          <div className="space-y-2.5">
            {places.map((place) => (
              <div
                key={place.id}
                className="p-3.5 rounded-xl bg-gray-950/70 border border-cyan-500/25 hover:border-cyan-400/50 transition-all flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="p-2.5 rounded-xl bg-cyan-950 border border-cyan-500/30 text-cyan-300 flex-shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-cyan-100 truncate">
                      {place.name}
                    </div>
                    <div className="text-xs text-cyan-400/70 truncate mt-0.5">
                      {place.address}
                    </div>
                    <div className="flex items-center gap-2 mt-1.5 text-[11px] font-mono-tech text-cyan-300">
                      <span className="px-1.5 py-0.5 rounded bg-cyan-900/60 border border-cyan-500/30 text-emerald-300">
                        {place.distanceMeters > 0 
                          ? `${(place.distanceMeters / 1000).toFixed(2)} km away` 
                          : 'Location Search'}
                      </span>
                      <span className="text-cyan-400/60 uppercase">{place.category}</span>
                    </div>
                  </div>
                </div>

                <a
                  href={place.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400 text-emerald-200 text-xs font-tech uppercase flex items-center gap-1.5 flex-shrink-0 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  Route
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-400/70 flex items-center justify-between">
          <span>Harman Sir, location searches query official spatial registries.</span>
          <span className="font-mono-tech text-cyan-300">GPS ACTIVE</span>
        </div>
      </div>
    </div>
  );
};
