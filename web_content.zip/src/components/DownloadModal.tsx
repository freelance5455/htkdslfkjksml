import React, { useState } from 'react';
import { Quiz } from '../types';
import {
  downloadQuizAsPrintableHtml,
  downloadQuizAsText,
  downloadQuizAsJson,
  downloadAllQuizzesAsJson,
  downloadOfflineAppHtml,
} from '../utils/fileExporter';
import {
  X,
  Download,
  Printer,
  FileText,
  FileCode,
  HardDriveDownload,
  Smartphone,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  BookOpen
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  quiz?: Quiz | null;
  allQuizzes: Quiz[];
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  quiz,
  allQuizzes,
}) => {
  const [includeAnswers, setIncludeAnswers] = useState(true);
  const [includeExplanations, setIncludeExplanations] = useState(true);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const targetQuiz = quiz || allQuizzes[0];

  const handleDownloadAction = (action: () => void, label: string) => {
    action();
    setDownloadSuccess(label);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-100 flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 p-5 text-white flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Download className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg leading-tight">फाइल फॉर्मेट में डाउनलोड करें</h3>
              <p className="text-xs text-blue-100">
                {targetQuiz ? targetQuiz.title : 'क्विज़ डेटा एवं टेस्ट पेपर्स'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {downloadSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{downloadSuccess} फाइल डाउनलोड हो गई है!</span>
            </div>
          )}

          {targetQuiz && (
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">चयनित टेस्ट (Selected Test)</span>
                <h4 className="font-bold text-slate-800 text-sm truncate max-w-xs sm:max-w-md">{targetQuiz.title}</h4>
                <span className="text-xs text-slate-400">{targetQuiz.questions.length} प्रश्न उपलब्ध</span>
              </div>
            </div>
          )}

          {/* Options for Printable / PDF */}
          <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-2xl space-y-2">
            <span className="text-xs font-bold text-blue-900 block">प्रिंट / PDF सेटिंग्स:</span>
            <div className="flex flex-wrap gap-4 text-xs font-medium text-slate-700">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeAnswers}
                  onChange={(e) => setIncludeAnswers(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>उत्तर कुंजी (Answer Key) शामिल करें</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeExplanations}
                  onChange={(e) => setIncludeExplanations(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>विस्तृत व्याख्या (Explanation) जोड़ें</span>
              </label>
            </div>
          </div>

          {/* Download Options Grid */}
          <div className="space-y-2.5">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
              उपलब्ध फाइल फॉर्मेट (Available Formats)
            </span>

            {/* 1. Printable Question Paper / PDF HTML */}
            {targetQuiz && (
              <button
                onClick={() =>
                  handleDownloadAction(
                    () =>
                      downloadQuizAsPrintableHtml(targetQuiz, {
                        includeAnswers,
                        includeExplanations,
                        autoPrint: true,
                      }),
                    'PDF / प्रिंट प्रश्न-पत्र'
                  )
                }
                className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition flex items-center justify-between text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-800 text-sm group-hover:text-blue-700">
                      📄 प्रिंट / PDF प्रश्न-पत्र (.html / Print to PDF)
                    </h5>
                    <p className="text-xs text-slate-500">
                      A4 साइज परीक्षा फॉर्मेट, ओएमआर और उत्तर कुंजी सहित
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                  डाउनलोड
                </span>
              </button>
            )}

            {/* 2. Text File (.txt) */}
            {targetQuiz && (
              <button
                onClick={() =>
                  handleDownloadAction(
                    () => downloadQuizAsText(targetQuiz, includeAnswers),
                    'टेक्स्ट प्रश्न-पत्र (.txt)'
                  )
                }
                className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-amber-500 hover:bg-amber-50/50 transition flex items-center justify-between text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-800 text-sm group-hover:text-amber-800">
                      📝 प्लेन टेक्स्ट फाइल (.txt)
                    </h5>
                    <p className="text-xs text-slate-500">
                      WhatsApp, Telegram या Word में कॉपी-पेस्ट करने हेतु
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg">
                  डाउनलोड
                </span>
              </button>
            )}

            {/* 3. JSON Data File (.json) */}
            {targetQuiz && (
              <button
                onClick={() =>
                  handleDownloadAction(
                    () => downloadQuizAsJson(targetQuiz),
                    'क्विज़ डेटा (.json)'
                  )
                }
                className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition flex items-center justify-between text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                    <FileCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-800 text-sm group-hover:text-emerald-800">
                      📊 क्विज़ JSON डेटा फाइल (.json)
                    </h5>
                    <p className="text-xs text-slate-500">
                      डेटा बैकअप, सॉफ्टवेयर इंटिग्रेशन और कोडिंग उपयोग के लिए
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
                  डाउनलोड
                </span>
              </button>
            )}

            {/* 4. Complete Backup of All Quizzes (.json) */}
            <button
              onClick={() =>
                handleDownloadAction(
                  () => downloadAllQuizzesAsJson(allQuizzes),
                  'सभी टेस्ट का फुल बैकअप (.json)'
                )
              }
              className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-purple-500 hover:bg-purple-50/50 transition flex items-center justify-between text-left group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                  <HardDriveDownload className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800 text-sm group-hover:text-purple-800">
                    💾 सभी टेस्ट पेपर्स का फुल बैकअप (.json)
                  </h5>
                  <p className="text-xs text-slate-500">
                    कुल {allQuizzes.length} टेस्ट पेपर्स का पूरा डेटा एक फाइल में सुरक्षित करें
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-lg">
                बैकअप
              </span>
            </button>

            {/* 5. Standalone Offline App (.html) */}
            <button
              onClick={() =>
                handleDownloadAction(
                  () => downloadOfflineAppHtml(allQuizzes),
                  'स्टैंडअलोन ऑफलाइन ऐप (.html)'
                )
              }
              className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50/50 transition flex items-center justify-between text-left group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800 text-sm group-hover:text-indigo-800">
                    📱 ऑफलाइन वेब ऐप फाइल (.html)
                  </h5>
                  <p className="text-xs text-slate-500">
                    बिना इंटरनेट किसी भी मोबाइल या कंप्यूटर ब्राउज़र में सीधे चलाएं
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg">
                ऐप फाइल
              </span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs sm:text-sm font-semibold rounded-xl transition"
          >
            बंद करें (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
