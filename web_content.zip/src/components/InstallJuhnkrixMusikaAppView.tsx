import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Download, 
  Smartphone, 
  Apple, 
  Monitor, 
  Laptop, 
  Terminal, 
  Coffee, 
  Layers, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ShieldCheck, 
  FolderDown, 
  HardDrive, 
  Cpu, 
  Sparkles, 
  ArrowRight, 
  Check, 
  Copy, 
  FileCode, 
  Package, 
  Radio, 
  Zap, 
  Lock, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { 
  AppPlatformId, 
  PLATFORM_CONFIGS, 
  PlatformConfig, 
  PackageBuildResult, 
  buildSingleFilePackage, 
  installDirectlyToDevice, 
  saveAppPackageToStorage 
} from '../lib/multiPlatformAppPackager';

interface InstallJuhnkrixMusikaAppViewProps {
  onBackToDashboard?: () => void;
}

export const InstallJuhnkrixMusikaAppView: React.FC<InstallJuhnkrixMusikaAppViewProps> = ({
  onBackToDashboard
}) => {
  const [selectedPlatform, setSelectedPlatform] = useState<AppPlatformId>('android');
  
  // Direct Install States
  const [isInstallingDirectly, setIsInstallingDirectly] = useState<boolean>(false);
  const [directInstallStatus, setDirectInstallStatus] = useState<string | null>(null);
  const [directInstallPercent, setDirectInstallPercent] = useState<number>(0);
  const [directInstallResult, setDirectInstallResult] = useState<{ success: boolean; message: string; method: string } | null>(null);

  // Download Package States
  const [isBuildingPackage, setIsBuildingPackage] = useState<boolean>(false);
  const [packageBuildStatus, setPackageBuildStatus] = useState<string | null>(null);
  const [packageBuildPercent, setPackageBuildPercent] = useState<number>(0);
  const [builtPackage, setBuiltPackage] = useState<PackageBuildResult | null>(null);
  
  // Storage Destination Modal/Selection State
  const [showStorageDestinationModal, setShowStorageDestinationModal] = useState<boolean>(false);
  const [savingToStorage, setSavingToStorage] = useState<boolean>(false);
  const [storageSaveSuccess, setStorageSaveSuccess] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedHash, setCopiedHash] = useState<boolean>(false);

  const currentPlatformConfig = PLATFORM_CONFIGS[selectedPlatform];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Trigger Direct Device Installation (Pattern 1)
  const handleDirectDeviceInstallation = async () => {
    setIsInstallingDirectly(true);
    setDirectInstallStatus(`Initializing packaging engine for ${currentPlatformConfig.name}...`);
    setDirectInstallPercent(10);
    setDirectInstallResult(null);

    try {
      const res = await installDirectlyToDevice(selectedPlatform, (status, percent) => {
        setDirectInstallStatus(status);
        setDirectInstallPercent(percent);
      });
      setDirectInstallResult(res);
      showToast(`✓ App installation granted! Added ${currentPlatformConfig.name} to device app menu.`);
    } catch (err: any) {
      setDirectInstallResult({
        success: false,
        message: err.message || 'Direct installation failed.',
        method: 'ERROR'
      });
      showToast(`❌ Installation error: ${err.message}`);
    } finally {
      setIsInstallingDirectly(false);
    }
  };

  // Trigger Single-File Package Build (Pattern 2 - Step 1)
  const handleStartPackageBuild = async () => {
    setIsBuildingPackage(true);
    setPackageBuildStatus(`Packaging entire JUHNKRIX MUSIKA APP into single-file ${currentPlatformConfig.extension.toUpperCase()} setup...`);
    setPackageBuildPercent(15);
    setBuiltPackage(null);
    setStorageSaveSuccess(null);

    try {
      const result = await buildSingleFilePackage(selectedPlatform, (status, percent) => {
        setPackageBuildStatus(status);
        setPackageBuildPercent(percent);
      });
      setBuiltPackage(result);
      setShowStorageDestinationModal(true);
      showToast(`✓ Package generated: ${result.fileName} (${result.fileSizeFormatted})`);
    } catch (err: any) {
      showToast(`❌ Build error: ${err.message}`);
    } finally {
      setIsBuildingPackage(false);
    }
  };

  // Save to SD Card or Device Storage (Pattern 2 - Step 2)
  const handleSaveToTargetStorage = async (target: 'SD_CARD' | 'DEVICE_STORAGE') => {
    if (!builtPackage) return;
    setSavingToStorage(true);
    const targetLabel = target === 'SD_CARD' ? 'SD CARD STORAGE' : 'DEVICE STORAGE';

    try {
      const res = await saveAppPackageToStorage(
        builtPackage.blob,
        builtPackage.fileName,
        target
      );
      setStorageSaveSuccess(`✓ Successfully saved ${builtPackage.fileName} into ${res.pathText}!`);
      showToast(`✓ Saved to ${targetLabel}!`);
    } catch (err: any) {
      showToast(`⚠️ ${err.message || 'Storage permission denied.'}`);
    } finally {
      setSavingToStorage(false);
    }
  };

  const handleCopySha256 = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    showToast('✓ Copied SHA-256 checksum to clipboard!');
    setTimeout(() => setCopiedHash(false), 2500);
  };

  const getPlatformIcon = (iconName: string) => {
    switch (iconName) {
      case 'Smartphone': return <Smartphone className="w-5 h-5" />;
      case 'Apple': return <Apple className="w-5 h-5" />;
      case 'Layers': return <Layers className="w-5 h-5" />;
      case 'Monitor': return <Monitor className="w-5 h-5" />;
      case 'Laptop': return <Laptop className="w-5 h-5" />;
      case 'Terminal': return <Terminal className="w-5 h-5" />;
      case 'Coffee': return <Coffee className="w-5 h-5" />;
      default: return <Package className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-8 text-slate-100 max-w-7xl mx-auto animate-fadeIn pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border-2 border-amber-400 text-amber-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
              <Package className="w-4 h-4 text-amber-400" />
              <span>INSTALL & PACKAGING ENGINE • JUHNKRIX MUSIKA SOVEREIGN SUITE</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black font-serif text-amber-100 tracking-tight">
              INSTALL JUHNKRIX MUSIKA APP
            </h1>
            
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              Wrap and package the entire JUHNKRIX MUSIKA APP into a single installable native application for your device. Select your operating system below to install directly into your device app menu or download a standalone setup file to your SD Card or Device Storage.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-amber-500/30 text-[11px] font-mono text-amber-300 flex items-center space-x-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>Magic IP: 142.250.190.46</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-amber-500/30 text-[11px] font-mono text-slate-300 flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Source: JUHNKRIX MUSIKA DECENTRALIZED NETWORK</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-[11px] font-bold text-emerald-300 flex items-center space-x-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span>₦5 IMSI Carrier Billing Active</span>
              </div>
            </div>
          </div>

          {onBackToDashboard && (
            <button
              onClick={onBackToDashboard}
              className="px-5 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center space-x-2 transition-all shrink-0 hover:scale-105"
            >
              <span>← Back to Dashboard</span>
            </button>
          )}
        </div>
      </div>

      {/* STEP 1: SELECT APP VERSION PROMPT */}
      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center shadow-lg shadow-amber-500/30">
            1
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-extrabold text-amber-200">
              SELECT YOUR PREFERRED JUHNKRIX MUSIKA APP VERSION
            </h2>
            <p className="text-xs text-slate-400">
              Choose the exact platform version you want to install or download onto your device.
            </p>
          </div>
        </div>

        {/* 7 Platforms Selector Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
          {(Object.keys(PLATFORM_CONFIGS) as AppPlatformId[]).map((pid) => {
            const config = PLATFORM_CONFIGS[pid];
            const isSelected = selectedPlatform === pid;

            return (
              <motion.button
                key={pid}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  setSelectedPlatform(pid);
                  setBuiltPackage(null);
                  setDirectInstallResult(null);
                  setStorageSaveSuccess(null);
                }}
                className={`p-4 rounded-2xl border-2 text-left flex flex-col justify-between transition-all relative overflow-hidden ${
                  isSelected
                    ? 'bg-gradient-to-br from-amber-500/20 via-slate-900 to-amber-950/40 border-amber-400 shadow-xl shadow-amber-500/20'
                    : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 hover:border-amber-500/40'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-400 shadow-lg shadow-amber-400 animate-ping" />
                )}

                <div className="space-y-2">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-amber-400'
                  }`}>
                    {getPlatformIcon(config.iconName)}
                  </div>
                  
                  <div>
                    <div className="text-xs font-black text-slate-100 leading-tight">
                      {config.name}
                    </div>
                    <div className="text-[10px] font-mono text-amber-400 uppercase tracking-wide mt-0.5">
                      .{config.extension}
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 line-clamp-1">
                  {config.badge}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* STEP 2: SELECTED VERSION SPECIFICATION & ENGINE CONTROLS */}
      <div className="bg-slate-950 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-8">
        {/* Platform Overview Banner */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-950 flex items-center justify-center shadow-xl shadow-amber-500/30 shrink-0">
              {getPlatformIcon(currentPlatformConfig.iconName)}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-xl sm:text-2xl font-black text-amber-100">
                  {currentPlatformConfig.name}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-mono font-bold">
                  {currentPlatformConfig.badge}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                {currentPlatformConfig.description}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono shrink-0 w-full lg:w-auto">
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Target OS:</span>
              <span className="text-amber-300 font-bold">{currentPlatformConfig.targetOs}</span>
            </div>
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Output Binary:</span>
              <span className="text-emerald-400 font-bold">{currentPlatformConfig.outputFileName}</span>
            </div>
          </div>
        </div>

        {/* The Two Packaging & Installation Patterns */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center shadow-lg shadow-amber-500/30">
              2
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-amber-200">
                CHOOSE YOUR INSTALLATION & PACKAGING PATTERN
              </h2>
              <p className="text-xs text-slate-400">
                Select between direct automated system installation or downloading a single-file setup package to your SD card/device storage.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
            
            {/* PATTERN 1: INSTALL DIRECTLY INTO YOUR DEVICE */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="space-y-4 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-400 flex items-center justify-center">
                    <Zap className="w-5 h-5" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-black uppercase tracking-wider">
                    Pattern 1 • Zero-Download Direct OS Install
                  </span>
                </div>

                <div>
                  <h4 className="text-lg sm:text-xl font-black text-emerald-100">
                    INSTALL THE JUHNKRIX MUSIKA APP DIRECTLY INTO YOUR DEVICE
                  </h4>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    Automatically packages the entire JUHNKRIX MUSIKA APP into the {currentPlatformConfig.name} and goes straight into your device. It opens your device app installation system engines & machines to gain appropriate approval permission, automatically installs the app version directly into your device, and makes it appear on your device apps menu as a normal non-webbase native app.
                  </p>
                </div>

                <div className="space-y-2 pt-2 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Adds JUHNKRIX MUSIKA directly to your installed apps system</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Appears on your device apps menu for instant launcher click</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Runs as a native non-webbase offline application</span>
                  </div>
                </div>

                {/* Direct Install Status & Progress */}
                {isInstallingDirectly && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/40 space-y-3">
                    <div className="flex justify-between text-xs font-mono text-emerald-300">
                      <span className="flex items-center space-x-2">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>{directInstallStatus}</span>
                      </span>
                      <span className="font-bold">{directInstallPercent}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
                        initial={{ width: '0%' }}
                        animate={{ width: `${directInstallPercent}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>
                )}

                {directInstallResult && (
                  <div className={`p-4 rounded-2xl border text-xs font-bold flex items-start space-x-3 ${
                    directInstallResult.success
                      ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200'
                      : 'bg-rose-500/20 border-rose-400/40 text-rose-200'
                  }`}>
                    {directInstallResult.success ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-extrabold">{directInstallResult.message}</div>
                      <div className="text-[10px] font-mono text-slate-400 mt-1">Method: {directInstallResult.method}</div>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-4 relative z-10">
                <button
                  disabled={isInstallingDirectly}
                  onClick={handleDirectDeviceInstallation}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-102 disabled:opacity-50"
                >
                  {isInstallingDirectly ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      <span>PACKAGING & GAINING DEVICE OS APPROVAL...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 text-slate-950" />
                      <span>INSTALL THE JUHNKRIX MUSIKA APP DIRECTLY INTO YOUR DEVICE</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* PATTERN 2: DOWNLOAD SINGLE FILE PACKAGE SETUP */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="space-y-4 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-400 flex items-center justify-center">
                    <Download className="w-5 h-5" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider">
                    Pattern 2 • Single-File Setup Package
                  </span>
                </div>

                <div>
                  <h4 className="text-lg sm:text-xl font-black text-amber-100">
                    DOWNLOAD THE JUHNKRIX MUSIKA APP SINGLE FILE PACKAGE SETUP
                  </h4>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    Automatically wraps and packages the entire JUHNKRIX MUSIKA APP into a single setup installable app for {currentPlatformConfig.name} ({currentPlatformConfig.outputFileName}). Prompts you to select whether you want to save or download into your SD CARD STORAGE or DEVICE STORAGE with full permission.
                  </p>
                </div>

                <div className="space-y-2 pt-2 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Single-file standalone setup executable ({currentPlatformConfig.outputFileName})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Custom destination: SD CARD STORAGE or DEVICE INBUILT STORAGE</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Cryptographically verified with SHA-256 signature seal</span>
                  </div>
                </div>

                {/* Build Status & Progress */}
                {isBuildingPackage && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/40 space-y-3">
                    <div className="flex justify-between text-xs font-mono text-amber-300">
                      <span className="flex items-center space-x-2">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>{packageBuildStatus}</span>
                      </span>
                      <span className="font-bold">{packageBuildPercent}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-amber-500 to-yellow-400"
                        initial={{ width: '0%' }}
                        animate={{ width: `${packageBuildPercent}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>
                )}

                {/* Built Package Details */}
                {builtPackage && (
                  <div className="bg-slate-950/90 p-4 rounded-2xl border border-amber-500/40 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-black text-amber-200">{builtPackage.fileName}</span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono text-[10px]">
                        {builtPackage.fileSizeFormatted}
                      </span>
                    </div>

                    <div className="flex items-center justify-between bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300">
                      <span className="truncate max-w-[200px] sm:max-w-xs">
                        SHA-256: {builtPackage.sha256Hash}
                      </span>
                      <button
                        onClick={() => handleCopySha256(builtPackage.sha256Hash)}
                        className="text-amber-400 hover:text-amber-300 ml-2 shrink-0 flex items-center space-x-1"
                      >
                        {copiedHash ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span className="text-[10px]">{copiedHash ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>

                    {storageSaveSuccess && (
                      <div className="text-xs font-bold text-emerald-300 flex items-center space-x-1.5 pt-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{storageSaveSuccess}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="pt-4 relative z-10">
                <button
                  disabled={isBuildingPackage}
                  onClick={handleStartPackageBuild}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-102 disabled:opacity-50"
                >
                  {isBuildingPackage ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      <span>COMPILING {currentPlatformConfig.extension.toUpperCase()} PACKAGE...</span>
                    </>
                  ) : (
                    <>
                      <Package className="w-4 h-4 text-slate-950" />
                      <span>DOWNLOAD THE JUHNKRIX MUSIKA APP SINGLE FILE PACKAGE SETUP</span>
                    </>
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* STORAGE SELECTION PROMPT MODAL (Pattern 2 Storage Selection) */}
      <AnimatePresence>
        {showStorageDestinationModal && builtPackage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="space-y-3 text-center sm:text-left">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black">
                  <FolderDown className="w-4 h-4 text-amber-400" />
                  <span>STORAGE LOCATION SELECTION</span>
                </div>
                
                <h3 className="text-xl sm:text-2xl font-black text-amber-100">
                  Where do you want me to save or download the app to?
                </h3>
                
                <p className="text-xs text-slate-300 leading-relaxed">
                  Select your desired storage destination below to grant permission and automatically save <span className="font-mono text-amber-300 font-bold">{builtPackage.fileName}</span> with the name <span className="font-bold text-amber-300">JUHNKRIX-MUSIKA</span>.
                </p>
              </div>

              {/* Destination Options */}
              <div className="space-y-4 pt-2">
                
                {/* SD CARD STORAGE OPTION */}
                <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-5 space-y-3 hover:border-amber-400 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                        <HardDrive className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-black text-sm text-slate-100">SD CARD STORAGE</div>
                        <div className="text-[11px] text-slate-400">External MicroSD / Removable Storage</div>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900 p-3 rounded-xl border border-slate-800">
                    Please click on the <strong>'SD CARD STORAGE'</strong> button to grant me permission to open your SD CARD STORAGE for me to save or download the apps version into it and I will save or download the app version into your SD CARD STORAGE with a name <strong>JUHNKRIX-MUSIKA</strong>.
                  </p>

                  <button
                    disabled={savingToStorage}
                    onClick={() => handleSaveToTargetStorage('SD_CARD')}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 transition-all"
                  >
                    {savingToStorage ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <HardDrive className="w-4 h-4 text-slate-950" />
                    )}
                    <span>SD CARD STORAGE (GRANT PERMISSION & SAVE)</span>
                  </button>
                </div>

                {/* DEVICE INBUILT STORAGE OPTION */}
                <div className="bg-slate-950 border border-cyan-500/30 rounded-2xl p-5 space-y-3 hover:border-cyan-400 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-black text-sm text-slate-100">DEVICE INBUILT STORAGE</div>
                        <div className="text-[11px] text-slate-400">Internal Storage / Primary Downloads</div>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900 p-3 rounded-xl border border-slate-800">
                    Please click on the <strong>'DEVICE STORAGE'</strong> button to grant me permission to open your DEVICE STORAGE for me to save or download the apps version into it and I will save or download the app version into your DEVICE STORAGE with a name <strong>JUHNKRIX-MUSIKA</strong>.
                  </p>

                  <button
                    disabled={savingToStorage}
                    onClick={() => handleSaveToTargetStorage('DEVICE_STORAGE')}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-cyan-500/20 transition-all"
                  >
                    {savingToStorage ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <Smartphone className="w-4 h-4 text-slate-950" />
                    )}
                    <span>DEVICE STORAGE (GRANT PERMISSION & SAVE)</span>
                  </button>
                </div>

              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setShowStorageDestinationModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
                >
                  Done / Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
