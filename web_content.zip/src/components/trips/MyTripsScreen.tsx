import { useState } from 'react';
import { Calendar, Plane, Building2, Shield, Car, Compass, Clock, MapPin, ChevronDown, ChevronUp, Sparkles, ExternalLink, Luggage } from 'lucide-react';
import { TravelTrip, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { TripGuardianModal } from '../guardian/TripGuardianModal';

interface MyTripsScreenProps {
  trip: TravelTrip;
  language: Language;
  currency: Currency;
  onOpenWallet: () => void;
  onOpenPacking?: () => void;
}

export function MyTripsScreen({ trip, language, currency, onOpenWallet, onOpenPacking }: MyTripsScreenProps) {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [showGuardian, setShowGuardian] = useState(false);
  const [expandedDay, setExpandedDay] = useState<number | null>(1);

  const t = translations[language];

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white">
            {t.navTrips}
          </h1>
          <p className="text-xs text-cyan-400 font-mono mt-0.5">
            TAKI-GO Unified Travel Dossier
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'upcoming' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'ar' ? 'الرحلات القادمة (1)' : 'Upcoming (1)'}
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'past' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'ar' ? 'السابقة' : 'Past'}
          </button>
        </div>
      </div>

      {activeTab === 'upcoming' ? (
        <div className="space-y-5">
          {/* Main Trip Card */}
          <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 text-white space-y-4">
            {/* Top row */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider block mb-1">
                  {trip.destinationCountry}
                </span>
                <h2 className="text-lg md:text-xl font-black text-white">
                  {trip.destinationCity}
                </h2>
                <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{trip.startDate} — {trip.endDate}</span>
                </p>
              </div>

              {/* Guardian Launcher Pill */}
              <button
                onClick={() => setShowGuardian(true)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold hover:bg-emerald-500/30 transition-colors shadow-[0_0_15px_rgba(16,185,129,0.2)]"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>{t.smartGuardianBadge}</span>
              </button>
            </div>

            {/* Quick Service Badges Strip */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                  <Plane className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{t.flight}</span>
                </div>
                <p className="font-bold text-white truncate">{trip.flightInfo.flightNumber}</p>
                <p className="text-[10px] text-emerald-400 font-semibold">{t.onTime}</p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                  <Building2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>{t.hotel}</span>
                </div>
                <p className="font-bold text-white truncate">{trip.hotelInfo.name}</p>
                <p className="text-[10px] text-slate-400">7 ليالٍ مؤكدة</p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                  <Car className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'ar' ? 'التنقلات' : 'Transfer'}</span>
                </div>
                <p className="font-bold text-white truncate">Mercedes Vito VIP</p>
                <p className="text-[10px] text-slate-400">سائق خاص</p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{language === 'ar' ? 'التأمين' : 'Insurance'}</span>
                </div>
                <p className="font-bold text-emerald-400 truncate">سارٍ ومؤكد</p>
                <p className="text-[10px] text-slate-400">Allianz International</p>
              </div>
            </div>

            {/* Travel Program Timeline */}
            <div className="pt-3 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-cyan-400" />
                  <span>{language === 'ar' ? 'الجدول الزمني للرحلة (Itinerary):' : 'Day-by-Day Itinerary:'}</span>
                </h3>
                <div className="flex items-center gap-3">
                  {onOpenPacking && (
                    <button
                      onClick={onOpenPacking}
                      className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                    >
                      <Luggage className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'حزم أمتعة الرحلة' : 'Packing List'}</span>
                    </button>
                  )}
                  <button
                    onClick={onOpenWallet}
                    className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-semibold"
                  >
                    <span>{language === 'ar' ? 'المحفظة' : 'Wallet'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                {trip.timeline.map(item => (
                  <div
                    key={item.day}
                    onClick={() => setExpandedDay(expandedDay === item.day ? null : item.day)}
                    className="p-3.5 rounded-2xl bg-[#060c20] border border-slate-800/80 hover:border-slate-700 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                          D{item.day}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-white">{item.title}</p>
                          <p className="text-[10px] text-slate-400">{item.time}</p>
                        </div>
                      </div>
                      {expandedDay === item.day ? (
                        <ChevronUp className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>

                    {expandedDay === item.day && (
                      <p className="mt-2.5 pt-2.5 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
                        {item.description}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center glass-panel rounded-3xl text-slate-400 text-xs">
          {language === 'ar' ? 'لا توجد رحلات سابقة منتهية بعد.' : 'No completed past trips yet.'}
        </div>
      )}

      {/* Smart Trip Guardian Modal Component */}
      <TripGuardianModal
        isOpen={showGuardian}
        onClose={() => setShowGuardian(false)}
        trip={trip}
        language={language}
      />
    </div>
  );
}
