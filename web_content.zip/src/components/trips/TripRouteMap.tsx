import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Polyline,
  useMap,
} from 'react-leaflet';
import L from 'leaflet';
import {
  Plane,
  MapPin,
  Building2,
  Play,
  Pause,
  RotateCcw,
  Compass,
  Layers,
  Wifi,
  WifiOff,
  HardDriveDownload,
  RefreshCw,
  Navigation,
  Clock,
  Gauge,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import { Language, TravelTrip } from '../../types';
import {
  CachedTripMapData,
  MapCoordinate,
  loadTripMapCache,
  saveTripMapCache,
  clearTripMapCache,
  generateFlightArc,
  calculateDistanceKm,
} from '../../utils/mapCache';

interface TripRouteMapProps {
  trip: TravelTrip;
  language: Language;
}

// Calculate compass bearing between two coordinates for airplane heading rotation
function calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const lat1Rad = (lat1 * Math.PI) / 180;
  const lat2Rad = (lat2 * Math.PI) / 180;
  const y = Math.sin(dLon) * Math.cos(lat2Rad);
  const x =
    Math.cos(lat1Rad) * Math.sin(lat2Rad) -
    Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLon);
  const brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
}

// Custom Leaflet Icons using glowing cyberpunk styling
function createDepartureIcon(code: string, city: string) {
  return L.divIcon({
    className: 'leaflet-custom-marker',
    html: `
      <div class="relative flex flex-col items-center group -translate-x-1/2 -translate-y-1/2" style="width: 80px;">
        <div class="relative w-10 h-10 rounded-full bg-[#050b1e] border-2 border-[#00f0ff] shadow-[0_0_18px_#00f0ff] flex items-center justify-center text-[#00f0ff]">
          <svg class="w-5 h-5 -rotate-45" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
          </svg>
          <span class="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#00f0ff] animate-ping opacity-75"></span>
        </div>
        <div class="mt-1 bg-[#091129]/95 border border-[#00f0ff]/50 px-2 py-0.5 rounded-md shadow-lg text-center">
          <span class="text-[10px] font-mono font-black text-[#00f0ff] tracking-wider block">${code}</span>
          <span class="text-[9px] text-slate-300 block leading-tight truncate max-w-[70px]">${city}</span>
        </div>
      </div>
    `,
    iconSize: [80, 60],
    iconAnchor: [40, 20],
    popupAnchor: [0, -25],
  });
}

function createArrivalIcon(code: string, city: string) {
  return L.divIcon({
    className: 'leaflet-custom-marker',
    html: `
      <div class="relative flex flex-col items-center group -translate-x-1/2 -translate-y-1/2" style="width: 80px;">
        <div class="relative w-10 h-10 rounded-full bg-[#050b1e] border-2 border-[#10b981] shadow-[0_0_18px_#10b981] flex items-center justify-center text-[#10b981]">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <span class="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#10b981] animate-ping opacity-75"></span>
        </div>
        <div class="mt-1 bg-[#091129]/95 border border-[#10b981]/50 px-2 py-0.5 rounded-md shadow-lg text-center">
          <span class="text-[10px] font-mono font-black text-[#10b981] tracking-wider block">${code}</span>
          <span class="text-[9px] text-slate-300 block leading-tight truncate max-w-[70px]">${city}</span>
        </div>
      </div>
    `,
    iconSize: [80, 60],
    iconAnchor: [40, 20],
    popupAnchor: [0, -25],
  });
}

function createAnimatedPlaneIcon(headingDeg: number, flightNumber: string) {
  return L.divIcon({
    className: 'leaflet-animated-plane-marker',
    html: `
      <div class="relative flex flex-col items-center -translate-x-1/2 -translate-y-1/2" style="width: 70px;">
        <div class="relative w-11 h-11 rounded-full bg-[#07122b] border-2 border-[#00f0ff] shadow-[0_0_20px_#00f0ff] flex items-center justify-center">
          <div style="transform: rotate(${headingDeg}deg); transition: transform 0.2s ease-out;">
            <svg class="w-6 h-6 text-[#00f0ff]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
            </svg>
          </div>
          <span class="absolute inset-0 rounded-full border border-[#00f0ff] animate-ping opacity-60"></span>
        </div>
        <span class="mt-1 text-[9px] font-mono font-black text-white bg-[#030712]/90 border border-[#00f0ff]/60 px-1.5 py-0.2 rounded shadow">
          ${flightNumber}
        </span>
      </div>
    `,
    iconSize: [70, 60],
    iconAnchor: [35, 20],
    popupAnchor: [0, -25],
  });
}

function createHotelIcon(hotelName: string) {
  return L.divIcon({
    className: 'leaflet-hotel-marker',
    html: `
      <div class="relative flex flex-col items-center -translate-x-1/2 -translate-y-1/2" style="width: 80px;">
        <div class="w-9 h-9 rounded-full bg-[#070e24] border-2 border-[#38bdf8] shadow-[0_0_15px_#38bdf8] flex items-center justify-center text-[#38bdf8]">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
        </div>
        <div class="mt-1 bg-[#091129]/95 border border-[#38bdf8]/40 px-1.5 py-0.5 rounded text-center">
          <span class="text-[9px] text-[#38bdf8] font-bold block truncate max-w-[70px]">Swissôtel</span>
          <span class="text-[8px] text-amber-400 block">★★★★★</span>
        </div>
      </div>
    `,
    iconSize: [80, 55],
    iconAnchor: [40, 18],
    popupAnchor: [0, -22],
  });
}

// Controller component inside MapContainer to fly/pan to specific bounds
function MapViewController({
  center,
  zoom,
  bounds,
}: {
  center?: [number, number];
  zoom?: number;
  bounds?: L.LatLngBoundsExpression;
}) {
  const map = useMap();

  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14, animate: true });
    } else if (center && zoom) {
      map.setView(center, zoom, { animate: true });
    }
  }, [map, bounds, center, zoom]);

  return null;
}

export function TripRouteMap({ trip, language }: TripRouteMapProps) {
  const isRTL = language === 'ar';
  const [mapData, setMapData] = useState<CachedTripMapData>(() => loadTripMapCache(trip.id));
  const [activeView, setActiveView] = useState<'flight' | 'city'>('flight');
  const [mapStyle, setMapStyle] = useState<'dark' | 'standard'>('dark');
  const [isSimulatingOffline, setIsSimulatingOffline] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // Animation controls for flight journey path
  const [isPlaying, setIsPlaying] = useState(true);
  const [animationSpeed, setAnimationSpeed] = useState<number>(1); // 1x, 2x, 4x
  const [progressPercent, setProgressPercent] = useState<number>(45); // Current flight progress 0-100%

  // Departure & Arrival Coordinates
  const departureCoord: [number, number] = useMemo(
    () => [mapData.flightRoute.origin.lat, mapData.flightRoute.origin.lng],
    [mapData]
  );
  const arrivalCoord: [number, number] = useMemo(
    () => [mapData.flightRoute.destination.lat, mapData.flightRoute.destination.lng],
    [mapData]
  );
  const hotelCoord: [number, number] = useMemo(
    () => [mapData.cityMap.hotel.lat, mapData.cityMap.hotel.lng],
    [mapData]
  );

  // High-resolution flight waypoints (great circle arc)
  const journeyArcPoints = useMemo(() => {
    const raw = generateFlightArc(
      { lat: departureCoord[0], lng: departureCoord[1] },
      { lat: arrivalCoord[0], lng: arrivalCoord[1] },
      60
    );
    return raw.map(p => [p.lat, p.lng] as [number, number]);
  }, [departureCoord, arrivalCoord]);

  // Transfer route coordinates (Airport -> Hotel)
  const transferRoutePoints: [number, number][] = useMemo(() => {
    return [
      arrivalCoord,
      [41.18, 28.85],
      [41.12, 28.92],
      [41.08, 28.98],
      hotelCoord,
    ];
  }, [arrivalCoord, hotelCoord]);

  // Calculate current animated plane position and bearing
  const { currentPlanePos, currentHeading } = useMemo(() => {
    if (!journeyArcPoints.length) {
      return { currentPlanePos: departureCoord, currentHeading: 75 };
    }
    const totalPoints = journeyArcPoints.length;
    const exactIndex = ((progressPercent / 100) * (totalPoints - 1));
    const lowerIndex = Math.floor(exactIndex);
    const upperIndex = Math.min(totalPoints - 1, lowerIndex + 1);
    const fraction = exactIndex - lowerIndex;

    const p1 = journeyArcPoints[lowerIndex];
    const p2 = journeyArcPoints[upperIndex];

    const lat = p1[0] + (p2[0] - p1[0]) * fraction;
    const lng = p1[1] + (p2[1] - p1[1]) * fraction;

    const heading = calculateBearing(p1[0], p1[1], p2[0], p2[1]);
    return { currentPlanePos: [lat, lng] as [number, number], currentHeading: heading };
  }, [journeyArcPoints, progressPercent, departureCoord]);

  // Animation Loop Effect
  useEffect(() => {
    if (!isPlaying) return;

    const intervalTime = 80;
    const step = 0.4 * animationSpeed;

    const interval = setInterval(() => {
      setProgressPercent(prev => {
        if (prev >= 100) {
          return 0; // Loop flight journey
        }
        return Math.min(100, Number((prev + step).toFixed(2)));
      });
    }, intervalTime);

    return () => clearInterval(interval);
  }, [isPlaying, animationSpeed]);

  // View bounds
  const flightBounds: L.LatLngBoundsExpression = useMemo(() => {
    return L.latLngBounds([departureCoord, arrivalCoord]).pad(0.25);
  }, [departureCoord, arrivalCoord]);

  const cityBounds: L.LatLngBoundsExpression = useMemo(() => {
    return L.latLngBounds([arrivalCoord, hotelCoord]).pad(0.35);
  }, [arrivalCoord, hotelCoord]);

  // Sync cache handler
  const handleManualSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      const refreshed = loadTripMapCache(trip.id);
      saveTripMapCache(trip.id, refreshed);
      setMapData(refreshed);
      setIsSyncing(false);
      setSyncFeedback(
        isRTL
          ? 'تم تحديث وحفظ مسار الرحلة محلياً في الكاش'
          : 'Trip journey route cached successfully for offline access'
      );
      setTimeout(() => setSyncFeedback(null), 3000);
    }, 700);
  };

  // Telemetry statistics
  const totalDistanceKm = mapData.flightRoute.distanceKm;
  const currentDistanceKm = Math.round((progressPercent / 100) * totalDistanceKm);
  const remainingDistanceKm = Math.max(0, totalDistanceKm - currentDistanceKm);
  const remainingHours = ((1 - progressPercent / 100) * mapData.flightRoute.estimatedFlightHours).toFixed(1);

  return (
    <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-500/30 text-white space-y-4 shadow-[0_4px_35px_rgba(0,102,255,0.2)]">
      {/* Header bar with Offline Status & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm md:text-base font-black text-white">
              {isRTL
                ? 'خريطة مسار الرحلة الجوي (React-Leaflet)'
                : 'Journey Route Visualizer (React-Leaflet)'}
            </h3>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {isRTL
              ? `مسار الرحلة الجوي بين مطار الجزائر (ALG) ومطار إسطنبول (IST) مع تعقب الحركة الحية`
              : `Flight route corridor between Algiers (ALG) and Istanbul (IST) with animated flight tracking`}
          </p>
        </div>

        {/* Offline Cache Status Badge */}
        <div className="flex items-center gap-2">
          <div
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold border transition-all ${
              isSimulatingOffline
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
            }`}
          >
            {isSimulatingOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>{isRTL ? 'محاكاة بدون إنترنت (كاش)' : 'Simulated Offline (Cached)'}</span>
              </>
            ) : (
              <>
                <HardDriveDownload className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isRTL ? 'محفوظ محلياً للعمل بدون إنترنت' : 'Cached Offline (14.8 KB)'}</span>
              </>
            )}
          </div>

          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-300 hover:text-white transition-all active:scale-95 disabled:opacity-50"
            title={isRTL ? 'تحديث الكاش المحلي' : 'Refresh local cache'}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-cyan-400' : ''}`} />
          </button>
        </div>
      </div>

      {syncFeedback && (
        <div className="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{syncFeedback}</span>
        </div>
      )}

      {/* Map Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        {/* View Switcher: Journey Route vs City & Hotel */}
        <div className="flex items-center gap-1 p-1 bg-slate-900/90 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveView('flight')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeView === 'flight'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plane className="w-3.5 h-3.5" />
            <span>{isRTL ? 'مسار الرحلة الجوي (ALG ✈️ IST)' : 'Flight Journey Route'}</span>
          </button>
          <button
            onClick={() => setActiveView('city')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeView === 'city'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{isRTL ? 'الفندق والتنقلات (إسطنبول)' : 'Arrival & Hotel Transfer'}</span>
          </button>
        </div>

        {/* Right side controls: Map theme and Offline Simulation */}
        <div className="flex items-center gap-2">
          {/* Tile Layer Theme Toggle */}
          <button
            onClick={() => setMapStyle(mapStyle === 'dark' ? 'standard' : 'dark')}
            className="text-[11px] px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-300 flex items-center gap-1.5 transition-colors"
            title="Toggle Map Style"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>{mapStyle === 'dark' ? (isRTL ? 'الوضع التكتيكي الداكن' : 'Dark Tactical') : (isRTL ? 'الخريطة القياسية' : 'Standard')}</span>
          </button>

          {/* Toggle Offline Simulation */}
          <button
            onClick={() => setIsSimulatingOffline(!isSimulatingOffline)}
            className={`text-[11px] px-2.5 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 ${
              isSimulatingOffline
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            {isSimulatingOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            <span>{isSimulatingOffline ? (isRTL ? 'إنهاء الأوفلاين' : 'End Offline') : (isRTL ? 'محاكاة بدون إنترنت' : 'Test Offline')}</span>
          </button>
        </div>
      </div>

      {/* Main Map Container using React-Leaflet */}
      <div className="relative w-full h-80 md:h-96 rounded-2xl bg-[#030712] border border-cyan-500/30 overflow-hidden shadow-2xl">
        <MapContainer
          center={activeView === 'flight' ? [39.0, 16.0] : arrivalCoord}
          zoom={activeView === 'flight' ? 5 : 10}
          scrollWheelZoom={false}
          className="w-full h-full"
        >
          {/* Map View Controller for auto bounds fitting */}
          <MapViewController bounds={activeView === 'flight' ? flightBounds : cityBounds} />

          {/* TileLayer: CartoDB Dark Matter for cyberpunk dark aesthetic, or OpenStreetMap fallback */}
          <TileLayer
            attribution='&copy; <a href="https://carto.com/">CARTO</a>'
            url={
              mapStyle === 'dark'
                ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
                : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
            }
          />

          {/* Departure Airport Marker (ALG) */}
          <Marker
            position={departureCoord}
            icon={createDepartureIcon('ALG', isRTL ? 'الجزائر' : 'Algiers')}
          >
            <Popup>
              <div className="p-2 space-y-1.5 text-xs text-white min-w-[200px]">
                <div className="flex items-center gap-2 pb-1 border-b border-cyan-500/30 text-cyan-400 font-bold">
                  <Plane className="w-4 h-4 -rotate-45" />
                  <span>{isRTL ? 'مطار المغادرة: الجزائر العاصمة' : 'Departure: Algiers (ALG)'}</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {mapData.flightRoute.origin.title}
                </p>
                <div className="pt-1 text-[10px] space-y-0.5 text-slate-400 font-mono">
                  <p>TERMINAL: T4 • GATE: 16</p>
                  <p>FLIGHT: {trip.flightInfo.airline} {trip.flightInfo.flightNumber}</p>
                  <p className="text-emerald-400 font-bold">STATUS: {isRTL ? 'في الموعد المحدد' : 'ON TIME (08:20 AM)'}</p>
                </div>
              </div>
            </Popup>
          </Marker>

          {/* Arrival Airport Marker (IST) */}
          <Marker
            position={arrivalCoord}
            icon={createArrivalIcon('IST', isRTL ? 'إسطنبول' : 'Istanbul')}
          >
            <Popup>
              <div className="p-2 space-y-1.5 text-xs text-white min-w-[200px]">
                <div className="flex items-center gap-2 pb-1 border-b border-emerald-500/30 text-emerald-400 font-bold">
                  <MapPin className="w-4 h-4" />
                  <span>{isRTL ? 'مطار الوصول: إسطنبول الدولي' : 'Arrival: Istanbul (IST)'}</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {mapData.flightRoute.destination.title}
                </p>
                <div className="pt-1 text-[10px] space-y-0.5 text-slate-400 font-mono">
                  <p>TERMINAL: INTL ARRIVALS • BELT: 4</p>
                  <p>ETA: 13:45 PM • BAGGAGE: 30 KG</p>
                  <p className="text-cyan-400 font-bold">{isRTL ? 'استقبال VIP مخصص مشمول' : 'VIP Transfer Concierge Included'}</p>
                </div>
              </div>
            </Popup>
          </Marker>

          {/* Hotel Location Marker (Swissôtel) */}
          <Marker
            position={hotelCoord}
            icon={createHotelIcon(mapData.cityMap.hotel.title)}
          >
            <Popup>
              <div className="p-2 space-y-1.5 text-xs text-white min-w-[210px]">
                <div className="flex items-center gap-2 pb-1 border-b border-sky-500/30 text-sky-400 font-bold">
                  <Building2 className="w-4 h-4" />
                  <span>{trip.hotelInfo.name}</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {trip.hotelInfo.address}
                </p>
                <div className="pt-1 text-[10px] space-y-0.5 text-slate-400 font-mono">
                  <p>ROOM: {trip.hotelInfo.roomType}</p>
                  <p>CHECK-IN: {trip.hotelInfo.checkIn}</p>
                  <p className="text-amber-400 font-bold">RATING: 5-STAR LUXURY BOSPHORUS</p>
                </div>
              </div>
            </Popup>
          </Marker>

          {/* Animated In-Flight Marker along the Journey Route */}
          <Marker
            position={currentPlanePos}
            icon={createAnimatedPlaneIcon(currentHeading, trip.flightInfo.flightNumber)}
          >
            <Popup>
              <div className="p-2 space-y-1.5 text-xs text-white min-w-[190px]">
                <div className="flex items-center gap-2 pb-1 border-b border-cyan-500/30 text-cyan-400 font-bold">
                  <Navigation className="w-4 h-4" />
                  <span>{isRTL ? 'الرحلة أثناء الطيران' : 'Flight In Progress'}</span>
                </div>
                <div className="text-[11px] space-y-0.5 font-mono text-slate-300">
                  <p>PROGRESS: {Math.round(progressPercent)}%</p>
                  <p>ALTITUDE: 33,000 FT (10,050 M)</p>
                  <p>SPEED: 840 KM/H</p>
                  <p className="text-cyan-300">DIST REMAINING: {remainingDistanceKm.toLocaleString()} KM</p>
                </div>
              </div>
            </Popup>
          </Marker>

          {/* Journey Flight Route Polyline (Curved Geodesic Arc with animated dash flow) */}
          <Polyline
            positions={journeyArcPoints}
            pathOptions={{
              color: '#00f0ff',
              weight: 4,
              opacity: 0.9,
              dashArray: '10, 10',
              className: 'animated-flight-path',
            }}
          />

          {/* Secondary Transfer Polyline from Arrival Airport to Hotel */}
          <Polyline
            positions={transferRoutePoints}
            pathOptions={{
              color: '#f59e0b',
              weight: 3,
              opacity: 0.85,
              dashArray: '6, 6',
            }}
          />
        </MapContainer>

        {/* Tactical HUD Overlay Badge */}
        <div className="absolute top-3 left-3 z-[400] pointer-events-none">
          <div className="bg-[#030712]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-cyan-500/40 shadow-lg text-xs space-y-0.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-mono font-bold text-[10px]">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>LIVE JOURNEY RADAR • TK652</span>
            </div>
            <p className="text-[10px] text-slate-300 font-mono">
              ALG ✈️ IST • {totalDistanceKm.toLocaleString()} KM
            </p>
          </div>
        </div>

        {/* Offline Vector Simulation Fallback Overlay */}
        {isSimulatingOffline && (
          <div className="absolute bottom-3 right-3 z-[400] pointer-events-none bg-amber-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-amber-500/50 text-[10px] text-amber-300 font-mono flex items-center gap-1.5">
            <WifiOff className="w-3.5 h-3.5" />
            <span>OFFLINE LOCAL VECTOR CACHE ACTIVE</span>
          </div>
        )}
      </div>

      {/* Flight Animation Playback & Route Telemetry Panel */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#060c20] via-[#091438] to-[#060c20] border border-cyan-500/30 space-y-3">
        {/* Playback Controls and Telemetry Row */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {/* Play/Pause Button */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-9 h-9 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white flex items-center justify-center hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(0,240,255,0.4)]"
              title={isPlaying ? 'Pause Journey Animation' : 'Play Journey Animation'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            </button>

            {/* Restart Button */}
            <button
              onClick={() => setProgressPercent(0)}
              className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition-all"
              title="Restart Journey Animation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Speed Multiplier Button */}
            <button
              onClick={() => {
                const next = animationSpeed === 1 ? 2 : animationSpeed === 2 ? 4 : 1;
                setAnimationSpeed(next);
              }}
              className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-cyan-300 text-xs font-mono font-bold transition-all"
              title="Animation Speed"
            >
              {animationSpeed}x
            </button>
          </div>

          {/* Telemetry Stats: Traveled / Total / Remaining */}
          <div className="flex items-center gap-4 text-xs font-mono">
            <div>
              <span className="text-[10px] text-slate-400 block">{isRTL ? 'المسافة المقطوعة' : 'Traveled'}</span>
              <span className="font-bold text-cyan-300">{currentDistanceKm.toLocaleString()} KM</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{isRTL ? 'المتبقي للوصول' : 'Remaining'}</span>
              <span className="font-bold text-emerald-300">{remainingDistanceKm.toLocaleString()} KM ({remainingHours}h)</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{isRTL ? 'التقدم' : 'Progress'}</span>
              <span className="font-bold text-white">{Math.round(progressPercent)}%</span>
            </div>
          </div>
        </div>

        {/* Interactive Flight Scrubber / Progress Bar */}
        <div className="space-y-1">
          <input
            type="range"
            min="0"
            max="100"
            step="0.5"
            value={progressPercent}
            onChange={e => setProgressPercent(parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-400">
            <span>ALG (08:20 ص)</span>
            <span className="text-cyan-400 font-bold">{isRTL ? 'مسار الطيران المباشر' : 'Direct Geodesic Corridor'}</span>
            <span>IST (13:45 م)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
