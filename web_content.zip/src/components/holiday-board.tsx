import { useMemo, useState } from "react";
import { holidaysForYear, type HolidayKind } from "@/lib/holidays";
import { diffDays, formatLongDate, sentenceCase } from "@/lib/time";

type Filter = "todos" | HolidayKind;

type Props = {
  todayIso: string | null;
};

function whenLabel(days: number): string {
  if (days === 0) return "Hoje";
  if (days === 1) return "Amanhã";
  if (days > 1) return `Em ${days} dias`;
  if (days === -1) return "Ontem";
  return `Há ${Math.abs(days)} dias`;
}

const FILTERS: { id: Filter; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "oficial", label: "Oficiais" },
  { id: "festivo", label: "Festivos" },
];

export function HolidayBoard({ todayIso }: Props) {
  const [filter, setFilter] = useState<Filter>("todos");
  const year = todayIso ? Number(todayIso.slice(0, 4)) : null;

  const { list, next } = useMemo(() => {
    if (!todayIso || year === null) return { list: [], next: null };
    const yearList = holidaysForYear(year).map((holiday) => ({
      holiday,
      days: diffDays(todayIso, holiday.date),
    }));
    const visible = yearList.filter((item) => filter === "todos" || item.holiday.kind === filter);
    let upcoming = visible.find((item) => item.days >= 0) ?? null;
    if (!upcoming) {
      const first = holidaysForYear(year + 1).find(
        (holiday) => filter === "todos" || holiday.kind === filter,
      );
      if (first) upcoming = { holiday: first, days: diffDays(todayIso, first.date) };
    }
    return { list: visible, next: upcoming };
  }, [filter, todayIso, year]);

  return (
    <section className="rounded-card border border-line bg-card p-5 shadow-card sm:p-7">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">Brasil{year ? ` · ${year}` : ""}</p>
          <h2 className="mt-1 text-3xl leading-none text-ink">Feriados e datas festivas</h2>
        </div>
        <div className="flex gap-1 rounded-full bg-paper p-1" role="tablist" aria-label="Filtrar datas">
          {FILTERS.map((item) => {
            const selected = filter === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={selected}
                className={
                  "min-h-11 rounded-full px-4 text-sm font-medium transition-colors " +
                  (selected ? "bg-ink text-paper" : "text-ink hover:bg-card")
                }
                onClick={() => setFilter(item.id)}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {next ? (
        <article className="mt-5 rounded-2xl bg-forest px-5 py-4 text-paper">
          <p className="text-sm font-medium text-paper/80">{whenLabel(next.days)}</p>
          <h3 className="mt-1 text-3xl leading-none">{next.holiday.name}</h3>
          <p className="mt-2">{sentenceCase(formatLongDate(next.holiday.date))}</p>
          <p className="mt-1 text-sm text-paper/80">{next.holiday.note}</p>
        </article>
      ) : null}

      <ul className="mt-4 divide-y divide-line">
        {list.map((item) => {
          const past = item.days < 0;
          const today = item.days === 0;
          return (
            <li
              key={`${item.holiday.date}-${item.holiday.name}`}
              className={"flex items-start justify-between gap-3 py-3 " + (past ? "opacity-55" : "")}
            >
              <div>
                <p className="font-medium text-ink">
                  {item.holiday.name}
                  {today ? <span className="ml-2 text-sm font-medium text-clay">hoje</span> : null}
                </p>
                <p className="text-sm text-muted">{sentenceCase(formatLongDate(item.holiday.date))}</p>
              </div>
              <div className="text-right">
                <span
                  className={
                    "inline-flex rounded-full px-2 py-1 text-xs font-medium " +
                    (item.holiday.kind === "oficial" ? "bg-paper text-forest" : "bg-paper text-clay")
                  }
                >
                  {item.holiday.kind === "oficial" ? "Oficial" : "Festivo"}
                </span>
                <p className="mt-1 text-xs text-muted">{todayIso ? whenLabel(item.days) : ""}</p>
              </div>
            </li>
          );
        })}
      </ul>
      <p className="mt-2 text-sm text-muted">
        Oficiais são feriados nacionais. Festivos incluem carnaval, festas juninas e datas de calendário que o país comemora mesmo sem feriado em todo lugar.
      </p>
    </section>
  );
}
