import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { WordData } from '../types';
import { sound } from '../services/sound';

interface VocabArena3DProps {
  words: WordData[];
  onExit: () => void;
  onAddMistake: (word: string, wrongAns: string, correctAns: string, question: string) => void;
  onAddXp: (amount: number) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
}

type GameState = 'title' | 'playing' | 'paused' | 'gameover' | 'victory';

interface ActiveGate {
  group: THREE.Group;
  z: number;
  lane: number; // -1: Left, 0: Center, 1: Right
  word: string;
  isCorrect: boolean;
  mesh: THREE.Mesh;
  halo: THREE.Mesh;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
}

export const VocabArena3D: React.FC<VocabArena3DProps> = ({
  words,
  onExit,
  onAddMistake,
  onAddXp,
  onSetStatus,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // React state only for high-level shell
  const [gameState, setGameState] = useState<GameState>('title');
  const [hudScore, setHudScore] = useState(0);
  const [hudMultiplier, setHudMultiplier] = useState(1);
  const [hudHp, setHudHp] = useState(3);
  const [currentPrompt, setCurrentPrompt] = useState<{ word: string; meaning: string }>({
    word: 'Callous',
    meaning: 'অনুভূতিহীন, নির্দয় / Insensitive to suffering'
  });

  // Game state refs (isolated from React re-renders for true 60fps loop)
  const gameRef = useRef({
    state: 'title' as GameState,
    score: 0,
    multiplier: 1,
    streak: 0,
    hp: 3,
    lane: 0, // -1, 0, 1
    targetX: 0,
    playerX: 0,
    playerY: 0,
    isJumping: false,
    jumpVelocity: 0,
    speed: 18,
    distance: 0,
    cameraShake: 0,
    hitstop: 0,
    targetWord: null as WordData | null,
    targetChoices: [] as { word: string; isCorrect: boolean }[],
    gateSpawnZ: -60,
    activeGates: [] as ActiveGate[],
    particles: [] as Particle[],
    roadSegments: [] as THREE.Group[],
  });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b14);
    scene.fog = new THREE.FogExp2(0x070b14, 0.016);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      200
    );
    camera.position.set(0, 4.2, 7.5);
    camera.lookAt(0, 1.8, -10);

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Environment Lighting (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Key Light
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 2.2);
    keyLight.position.set(8, 16, 10);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 40;
      keyLight.shadow.camera.left = -12;
      keyLight.shadow.camera.right = 12;
      keyLight.shadow.camera.top = 12;
      keyLight.shadow.camera.bottom = -12;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    // Hemisphere Light Fill
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 1.0);
    scene.add(hemiLight);

    // ----------------------------------------------------
    // 1. Procedural 5-Part Hero Character (THREE.Group)
    // ----------------------------------------------------
    const playerGroup = new THREE.Group();

    // Torso / Jet Core
    const torsoGeo = new THREE.BoxGeometry(0.8, 1.1, 0.6);
    const torsoMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.85,
      roughness: 0.2,
    });
    const torso = new THREE.Mesh(torsoGeo, torsoMat);
    torso.position.y = 1.1;
    torso.castShadow = !isSoftwareGl;
    playerGroup.add(torso);

    // Glowing Cyber Visor
    const visorGeo = new THREE.BoxGeometry(0.65, 0.22, 0.3);
    const visorMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 2.0,
      roughness: 0.1,
    });
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 1.35, 0.22);
    playerGroup.add(visor);

    // Kinetic Shoulder Thruster Wings (Left & Right)
    const wingGeo = new THREE.BoxGeometry(0.2, 0.5, 0.4);
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x0369a1,
      metalness: 0.9,
      roughness: 0.15,
    });
    const leftWing = new THREE.Mesh(wingGeo, wingMat);
    leftWing.position.set(-0.55, 1.15, -0.05);
    const rightWing = new THREE.Mesh(wingGeo, wingMat);
    rightWing.position.set(0.55, 1.15, -0.05);
    playerGroup.add(leftWing);
    playerGroup.add(rightWing);

    // Kinetic Hover Boots
    const bootGeo = new THREE.BoxGeometry(0.26, 0.35, 0.4);
    const bootMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.7,
      roughness: 0.3,
    });
    const leftBoot = new THREE.Mesh(bootGeo, bootMat);
    leftBoot.position.set(-0.25, 0.25, 0);
    const rightBoot = new THREE.Mesh(bootGeo, bootMat);
    rightBoot.position.set(0.25, 0.25, 0);
    playerGroup.add(leftBoot);
    playerGroup.add(rightBoot);

    // Floating Energy Halo / Ring
    const haloGeo = new THREE.TorusGeometry(0.5, 0.04, 8, 24);
    const haloMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
    const halo = new THREE.Mesh(haloGeo, haloMat);
    halo.rotation.x = Math.PI / 2;
    halo.position.set(0, 1.8, 0);
    playerGroup.add(halo);

    // Soft Contact Shadow Plane underneath
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 64;
    shadowCanvas.height = 64;
    const sCtx = shadowCanvas.getContext('2d')!;
    const grad = sCtx.createRadialGradient(32, 32, 4, 32, 32, 30);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.6)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 64, 64);
    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 1.6),
      new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.02;
    playerGroup.add(shadowPlane);

    scene.add(playerGroup);

    // ----------------------------------------------------
    // 2. Procedural Endless Road / Track System
    // ----------------------------------------------------
    const roadSegments: THREE.Group[] = [];
    const laneWidth = 3.6;
    const totalRoadWidth = laneWidth * 3 + 2.0;
    const segmentLength = 40;

    for (let i = 0; i < 5; i++) {
      const seg = new THREE.Group();
      seg.position.z = -i * segmentLength;

      // Road Surface
      const roadGeo = new THREE.PlaneGeometry(totalRoadWidth, segmentLength, 1, 1);
      const roadMat = new THREE.MeshStandardMaterial({
        color: 0x0b1324,
        roughness: 0.6,
        metalness: 0.2,
      });
      const roadMesh = new THREE.Mesh(roadGeo, roadMat);
      roadMesh.rotation.x = -Math.PI / 2;
      roadMesh.receiveShadow = !isSoftwareGl;
      seg.add(roadMesh);

      // Neon Lane Divider Lines
      [-laneWidth / 2, laneWidth / 2].forEach((xPos) => {
        const lineGeo = new THREE.PlaneGeometry(0.12, segmentLength);
        const lineMat = new THREE.MeshBasicMaterial({ color: 0x1e293b });
        const line = new THREE.Mesh(lineGeo, lineMat);
        line.rotation.x = -Math.PI / 2;
        line.position.set(xPos, 0.01, 0);
        seg.add(line);
      });

      // Outer Glowing Edge Curb Pillars
      [-totalRoadWidth / 2, totalRoadWidth / 2].forEach((xPos) => {
        const curbGeo = new THREE.BoxGeometry(0.3, 0.4, segmentLength);
        const curbMat = new THREE.MeshStandardMaterial({
          color: 0x10b981,
          emissive: 0x059669,
          emissiveIntensity: 0.4,
          roughness: 0.3,
        });
        const curb = new THREE.Mesh(curbGeo, curbMat);
        curb.position.set(xPos, 0.2, 0);
        seg.add(curb);
      });

      scene.add(seg);
      roadSegments.push(seg);
    }
    gameRef.current.roadSegments = roadSegments;

    // Helper: Dynamic Gate Text Texture Generator
    const createGateTexture = (text: string, isHot: boolean) => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 256;
      const ctx = canvas.getContext('2d')!;

      // Background
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 512, 256);

      // Frame Border
      ctx.lineWidth = 12;
      ctx.strokeStyle = isHot ? '#f59e0b' : '#38bdf8';
      ctx.strokeRect(10, 10, 492, 236);

      // Text
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 54px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, 256, 128);

      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
      return tex;
    };

    // Helper: Spawn Next Set of 3 Choice Gates
    const spawnGateSet = (targetZ: number) => {
      const allWords = words.length > 0 ? words : [{ word: 'Callous', simpleDef: 'Insensitive to pain', bengali: 'অনুভূতিহীন' } as WordData];
      const correctWord = allWords[Math.floor(Math.random() * allWords.length)];
      const distractors = allWords.filter(w => w.word !== correctWord.word).sort(() => 0.5 - Math.random()).slice(0, 2);

      const choices = [
        { word: correctWord.word, isCorrect: true },
        { word: distractors[0]?.word || 'Abase', isCorrect: false },
        { word: distractors[1]?.word || 'Abash', isCorrect: false },
      ].sort(() => 0.5 - Math.random());

      gameRef.current.targetWord = correctWord;
      setCurrentPrompt({
        word: correctWord.word,
        meaning: correctWord.bengali ? `${correctWord.bengali.split('(')[0]} / ${correctWord.simpleDef}` : correctWord.simpleDef
      });

      const lanes = [-1, 0, 1]; // Left (-3.6), Center (0), Right (3.6)
      lanes.forEach((laneIdx, i) => {
        const choice = choices[i];
        const gateGroup = new THREE.Group();
        const posX = laneIdx * laneWidth;
        gateGroup.position.set(posX, 0, targetZ);

        // Gate Portal Arch (Procedural 3 parts)
        const archGeo = new THREE.BoxGeometry(3.0, 3.4, 0.3);
        const archMat = new THREE.MeshStandardMaterial({
          color: 0x1e293b,
          metalness: 0.7,
          roughness: 0.3,
        });
        const arch = new THREE.Mesh(archGeo, archMat);
        arch.position.y = 1.7;
        gateGroup.add(arch);

        // Word Banner Texture
        const bannerGeo = new THREE.PlaneGeometry(2.6, 1.3);
        const bannerTex = createGateTexture(choice.word, choice.isCorrect);
        const bannerMat = new THREE.MeshBasicMaterial({ map: bannerTex });
        const banner = new THREE.Mesh(bannerGeo, bannerMat);
        banner.position.set(0, 1.9, 0.17);
        gateGroup.add(banner);

        // Glowing bottom threshold
        const threshGeo = new THREE.BoxGeometry(2.8, 0.1, 0.6);
        const threshMat = new THREE.MeshStandardMaterial({
          color: 0x06b6d4,
          emissive: 0x0891b2,
          emissiveIntensity: 0.8,
        });
        const thresh = new THREE.Mesh(threshGeo, threshMat);
        thresh.position.set(0, 0.05, 0);
        gateGroup.add(thresh);

        scene.add(gateGroup);

        gameRef.current.activeGates.push({
          group: gateGroup,
          z: targetZ,
          lane: laneIdx,
          word: choice.word,
          isCorrect: choice.isCorrect,
          mesh: arch,
          halo: thresh,
        });
      });
    };

    // Helper: Trigger Particle Explosion
    const triggerGateParticles = (x: number, y: number, z: number, isSuccess: boolean) => {
      const pColor = isSuccess ? 0x34d399 : 0xf43f5e;
      const count = isSoftwareGl ? 8 : 20;

      for (let i = 0; i < count; i++) {
        const pGeo = new THREE.BoxGeometry(0.15, 0.15, 0.15);
        const pMat = new THREE.MeshBasicMaterial({ color: pColor });
        const pMesh = new THREE.Mesh(pGeo, pMat);
        pMesh.position.set(x, y + 1.2, z);

        const vel = new THREE.Vector3(
          (Math.random() - 0.5) * 8,
          Math.random() * 6 + 2,
          (Math.random() - 0.5) * 6
        );

        scene.add(pMesh);
        gameRef.current.particles.push({
          mesh: pMesh,
          vel,
          life: 0,
          maxLife: 0.6,
        });
      }
    };

    // Initial Gate set
    spawnGateSet(-50);

    // ----------------------------------------------------
    // 3. Input Handling (Edge-Triggered & Continuous)
    // ----------------------------------------------------
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        if (gameRef.current.state === 'playing') {
          gameRef.current.state = 'paused';
          setGameState('paused');
        } else if (gameRef.current.state === 'paused') {
          gameRef.current.state = 'playing';
          setGameState('playing');
        }
        return;
      }

      if (gameRef.current.state === 'title') {
        if (e.code === 'Enter' || e.code === 'Space') {
          gameRef.current.state = 'playing';
          setGameState('playing');
          sound.correct();
        }
        return;
      }

      if (gameRef.current.state !== 'playing') return;

      // Move Lane Left
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') {
        if (gameRef.current.lane > -1) {
          gameRef.current.lane -= 1;
          sound.flip();
        }
      }

      // Move Lane Right
      if (e.code === 'KeyD' || e.code === 'ArrowRight') {
        if (gameRef.current.lane < 1) {
          gameRef.current.lane += 1;
          sound.flip();
        }
      }

      // Jump
      if ((e.code === 'Space' || e.code === 'ArrowUp') && !gameRef.current.isJumping) {
        gameRef.current.isJumping = true;
        gameRef.current.jumpVelocity = 8.5;
        sound.playTone(380, 'sine', 0.12);
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    // ----------------------------------------------------
    // 4. 60fps Clamped Physics & Render Loop
    // ----------------------------------------------------
    let lastTime = performance.now();
    let frameId = 0;

    const clock = new THREE.Clock();

    const tick = () => {
      frameId = requestAnimationFrame(tick);

      const rawDt = clock.getDelta();
      const dt = Math.min(rawDt, 0.05); // clamp delta time

      const g = gameRef.current;

      // Hitstop logic
      if (g.hitstop > 0) {
        g.hitstop -= dt;
        renderer.render(scene, camera);
        return;
      }

      if (g.state === 'playing') {
        // Lateral lane interpolation (smooth exponential damping)
        const targetX = g.lane * laneWidth;
        g.playerX += (targetX - g.playerX) * (1 - Math.exp(-14 * dt));

        // Jump physics
        if (g.isJumping) {
          g.playerY += g.jumpVelocity * dt;
          g.jumpVelocity -= 22 * dt; // gravity
          if (g.playerY <= 0) {
            g.playerY = 0;
            g.isJumping = false;
            g.jumpVelocity = 0;
          }
        }

        playerGroup.position.set(g.playerX, g.playerY, 0);

        // Running animation tilt & bob
        const runBob = Math.sin(clock.getElapsedTime() * 12) * 0.08;
        torso.position.y = 1.1 + runBob;
        leftBoot.position.y = 0.25 + (g.isJumping ? 0.3 : Math.sin(clock.getElapsedTime() * 14) * 0.15);
        rightBoot.position.y = 0.25 + (g.isJumping ? 0.3 : -Math.sin(clock.getElapsedTime() * 14) * 0.15);
        halo.rotation.z += dt * 3;

        // Infinite road scrolling
        g.roadSegments.forEach((seg) => {
          seg.position.z += g.speed * dt;
          if (seg.position.z > 20) {
            seg.position.z -= 5 * segmentLength;
          }
        });

        // Gate collision & advancement
        for (let i = g.activeGates.length - 1; i >= 0; i--) {
          const gate = g.activeGates[i];
          gate.group.position.z += g.speed * dt;

          // Check pass-through threshold (around z = 0)
          if (gate.group.position.z > -1.2 && gate.group.position.z < 1.6) {
            // Is player in this gate's lane?
            if (g.lane === gate.lane) {
              const success = gate.isCorrect;
              triggerGateParticles(gate.group.position.x, 0, gate.group.position.z, success);

              if (success) {
                // Correct word gate breach
                g.streak += 1;
                g.multiplier = Math.min(4, 1 + Math.floor(g.streak / 3));
                const addedScore = 100 * g.multiplier;
                g.score += addedScore;
                g.speed = Math.min(28, g.speed + 0.6); // speed ramp

                sound.correct();
                onAddXp(20);
                if (g.targetWord) {
                  onSetStatus(g.targetWord.word, 'mastered');
                }

                setHudScore(g.score);
                setHudMultiplier(g.multiplier);
              } else {
                // Wrong gate hit
                g.streak = 0;
                g.multiplier = 1;
                g.hp -= 1;
                g.cameraShake = 0.5;
                g.hitstop = 0.08; // 80ms hitstop

                sound.wrong();
                if (g.targetWord) {
                  onAddMistake(
                    g.targetWord.word,
                    gate.word,
                    g.targetWord.word,
                    'Vocab Arena 3D Gate Breach'
                  );
                }

                setHudHp(g.hp);
                setHudMultiplier(1);

                if (g.hp <= 0) {
                  g.state = 'gameover';
                  setGameState('gameover');
                }
              }

              // Remove all gates from this set
              g.activeGates.forEach((gt) => scene.remove(gt.group));
              g.activeGates = [];

              // Spawn next gate set further ahead
              spawnGateSet(-55);
              break;
            }
          }

          // Clean up gates that passed behind camera
          if (gate.group.position.z > 10) {
            scene.remove(gate.group);
            g.activeGates.splice(i, 1);
          }
        }

        // Particle updates
        for (let pIdx = g.particles.length - 1; pIdx >= 0; pIdx--) {
          const p = g.particles[pIdx];
          p.life += dt;
          p.mesh.position.addScaledVector(p.vel, dt);
          p.vel.y -= 12 * dt; // gravity
          const scale = Math.max(0.01, 1 - p.life / p.maxLife);
          p.mesh.scale.set(scale, scale, scale);

          if (p.life >= p.maxLife) {
            scene.remove(p.mesh);
            g.particles.splice(pIdx, 1);
          }
        }

        // Camera Shake decay
        if (g.cameraShake > 0) {
          camera.position.x = (Math.random() - 0.5) * g.cameraShake;
          camera.position.y = 4.2 + (Math.random() - 0.5) * g.cameraShake;
          g.cameraShake *= 0.88;
        } else {
          camera.position.x = 0;
          camera.position.y = 4.2;
        }
      } else if (g.state === 'title') {
        // Slow cinematic orbit on Title Screen
        const t = clock.getElapsedTime() * 0.5;
        camera.position.x = Math.sin(t) * 4;
        camera.position.z = 7.5 + Math.cos(t) * 1.5;
        camera.lookAt(0, 1.4, -4);
        halo.rotation.z += dt * 1.5;
      }

      renderer.render(scene, camera);
    };

    frameId = requestAnimationFrame(tick);

    // Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [words]);

  const handleStartGame = () => {
    gameRef.current.state = 'playing';
    gameRef.current.score = 0;
    gameRef.current.hp = 3;
    gameRef.current.multiplier = 1;
    gameRef.current.streak = 0;
    setHudScore(0);
    setHudHp(3);
    setHudMultiplier(1);
    setGameState('playing');
    sound.correct();
  };

  const handleResume = () => {
    gameRef.current.state = 'playing';
    setGameState('playing');
  };

  const handleRestart = () => {
    handleStartGame();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#070b14] overflow-hidden select-none font-sans">
      
      {/* Isolated Three.js Canvas Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full" />

      {/* ---------------------------------------------------- */}
      {/* 1. Playing HUD Overlay (<15% viewport occlusion)     */}
      {/* ---------------------------------------------------- */}
      {gameState === 'playing' && (
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 safe-top safe-bottom">
          
          {/* Top Status Cluster */}
          <div className="w-full flex items-start justify-between">
            {/* Health Hearts */}
            <div className="flex items-center gap-1.5 bg-black/60 border border-slate-700/60 px-3 py-1.5 rounded-2xl pointer-events-auto">
              {[1, 2, 3].map((heart) => (
                <span
                  key={heart}
                  className={`text-lg transition-transform ${
                    heart <= hudHp ? 'scale-100 opacity-100' : 'scale-75 opacity-25 grayscale'
                  }`}
                >
                  ❤️
                </span>
              ))}
            </div>

            {/* Target Word Clue Banner */}
            <div className="bg-black/75 border-2 border-emerald-500/60 text-white px-4 py-2 rounded-2xl shadow-xl max-w-sm text-center pointer-events-auto">
              <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                Target Meaning / বাংলা অর্থ:
              </div>
              <div className="text-xs sm:text-sm font-black font-bengali text-amber-300 mt-0.5 leading-snug">
                {currentPrompt.meaning}
              </div>
              <div className="text-[9px] text-slate-400 mt-0.5">
                Hit the gate with the matching English word!
              </div>
            </div>

            {/* Score & Multiplier */}
            <div className="flex items-center gap-2 bg-black/60 border border-slate-700/60 px-3.5 py-1.5 rounded-2xl pointer-events-auto text-right">
              <div>
                <div className="text-[10px] text-slate-400 font-bold uppercase">Score</div>
                <div className="text-sm font-black text-amber-400 font-mono tabular-nums">
                  {hudScore}
                </div>
              </div>
              {hudMultiplier > 1 && (
                <div className="text-xs font-black px-1.5 py-0.5 bg-emerald-500 text-slate-950 rounded-lg">
                  {hudMultiplier}x
                </div>
              )}
            </div>
          </div>

          {/* Bottom Controls / Lane Touch Indicators for Mobile */}
          <div className="w-full flex items-center justify-between text-slate-400 text-xs pointer-events-auto">
            <button
              onClick={() => {
                if (gameRef.current.lane > -1) {
                  gameRef.current.lane -= 1;
                  sound.flip();
                }
              }}
              className="p-4 rounded-2xl bg-black/50 border border-slate-700 active:scale-95 text-white font-bold text-sm sm:hidden"
            >
              ◀ Left
            </button>

            <div className="hidden sm:block text-[11px] text-slate-400 font-mono bg-black/40 px-3 py-1 rounded-xl">
              A / D or ← / → Move Lane &bull; Space Jump &bull; Esc Pause
            </div>

            <button
              onClick={() => {
                if ((window as any) && !gameRef.current.isJumping) {
                  gameRef.current.isJumping = true;
                  gameRef.current.jumpVelocity = 8.5;
                }
              }}
              className="p-4 rounded-2xl bg-emerald-600/60 border border-emerald-500 active:scale-95 text-white font-bold text-sm sm:hidden"
            >
              ▲ Jump
            </button>

            <button
              onClick={() => {
                if (gameRef.current.lane < 1) {
                  gameRef.current.lane += 1;
                  sound.flip();
                }
              }}
              className="p-4 rounded-2xl bg-black/50 border border-slate-700 active:scale-95 text-white font-bold text-sm sm:hidden"
            >
              Right ▶
            </button>
          </div>

        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 2. Full-Viewport Title Screen                         */}
      {/* ---------------------------------------------------- */}
      {gameState === 'title' && (
        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-between p-8 safe-top safe-bottom text-white animate-in fade-in">
          
          {/* Top Brand Tag */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase tracking-widest">
              VocabMuse Interactive 3D Lab
            </span>
          </div>

          {/* Hero Bespoke Title SVG Lockup */}
          <div className="text-center space-y-4 max-w-md">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 to-cyan-400 flex items-center justify-center text-slate-950 font-black text-3xl shadow-[0_0_30px_rgba(16,185,129,0.5)]">
              ⚡
            </div>

            <div>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white uppercase drop-shadow-md">
                Cadre <span className="text-emerald-400">Runner</span> 3D
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-2 leading-relaxed">
                গতিশীল ৩ডি ট্র্যাকে দৌড়ান, সঠিক শব্দের গেট ভেদ করুন এবং বিসিএস ও প্রতিযোগিতামূলক পরীক্ষার শব্দভাণ্ডারে অপরাজেয় দখল গড়ে তুলুন!
              </p>
            </div>

            <div className="pt-4 flex flex-col items-center gap-3">
              <button
                onClick={handleStartGame}
                className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-base rounded-2xl shadow-[0_0_25px_rgba(16,185,129,0.4)] active:scale-95 transition-all uppercase tracking-wider"
              >
                Press Space or Click to Launch
              </button>

              <button
                onClick={onExit}
                className="text-xs text-slate-400 hover:text-white font-bold transition-colors"
              >
                Return to Wordbook
              </button>
            </div>
          </div>

          {/* Flat Control Hints */}
          <div className="text-center text-[11px] text-slate-400 font-mono">
            A/D or ←/→ Move Lanes &bull; Space Jump &bull; Esc Pause
          </div>

        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 3. Pause Screen Modal                                */}
      {/* ---------------------------------------------------- */}
      {gameState === 'paused' && (
        <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 text-white animate-in fade-in">
          <div className="bg-[#111827] border-2 border-slate-700 max-w-xs w-full rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <h3 className="text-xl font-black">Game Paused</h3>
            <p className="text-xs text-slate-400">Current Score: {hudScore}</p>

            <div className="space-y-2">
              <button
                onClick={handleResume}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md"
              >
                Resume Run
              </button>
              <button
                onClick={handleRestart}
                className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-extrabold text-xs rounded-xl"
              >
                Restart
              </button>
              <button
                onClick={onExit}
                className="w-full py-3 border border-slate-700 text-slate-400 hover:text-white font-bold text-xs rounded-xl"
              >
                Exit to App
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 4. Game Over Modal                                   */}
      {/* ---------------------------------------------------- */}
      {gameState === 'gameover' && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 text-white animate-in zoom-in-95">
          <div className="bg-[#111827] border-2 border-rose-900/60 max-w-sm w-full rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-900/40 text-rose-500 border border-rose-700 flex items-center justify-center font-black text-3xl">
              💥
            </div>

            <div>
              <h3 className="text-2xl font-black text-white">Shields Depleted</h3>
              <p className="text-xs text-slate-400 font-bengali mt-1">
                ভুল গেটগুলোতে আঘাত হেনেছেন। ভুল শব্দগুলো স্বয়ংক্রিয়ভাবে মিস্টেক্স ব্যাংকে যুক্ত হয়েছে।
              </p>
            </div>

            <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Final Score</div>
              <div className="text-3xl font-black text-amber-400 font-mono">{hudScore}</div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={handleRestart}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-[0_3px_0_0_#059669] active:scale-95 transition-all"
              >
                Try Again
              </button>
              <button
                onClick={onExit}
                className="w-full py-2.5 border border-slate-700 text-slate-300 font-bold text-xs rounded-xl hover:bg-slate-800"
              >
                Review Mistakes in App
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
