import React, { useState, useEffect } from "react";
import {
  EMOTIONS,
  EmotionKey,
  MemoryItem,
  ChatMessage,
  SuggestedSong,
  MoodTrendPoint,
  USER_MOODS,
  UserMoodOption,
  MoodQuote,
  MOOD_QUOTES,
  getQuotesForEmotion,
} from "../types";
import {
  BookHeart,
  Sparkles,
  Plus,
  Trash2,
  Volume2,
  Music,
  ExternalLink,
  TrendingUp,
  Quote,
  RotateCcw,
  Copy,
  Check,
  Download,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

interface EmotionMirrorPanelProps {
  currentEmotion: EmotionKey;
  emotionIntensity: number;
  emotionHistoryCounts: Record<EmotionKey, number>;
  memories: MemoryItem[];
  suggestedSongs: SuggestedSong[];
  moodTrend: MoodTrendPoint[];
  onLogMood: (moodOption: UserMoodOption) => void;
  onAddMemory: (text: string, category: string) => void;
  onRemoveMemory: (id: string) => void;
  onTestEmotion: (emotion: EmotionKey) => void;
  personaName: string;
  userName: string;
  userMood: string;
  messages: ChatMessage[];
  onSpeakText: (text: string, emotion: EmotionKey) => void;
  onOpenJournalModal?: (moodOption?: UserMoodOption) => void;
}

const CustomMoodTooltip = ({ active, payload }: any) => {
  if (!active || !payload || !payload.length) return null;
  const point: MoodTrendPoint = payload[0].payload;

  return (
    <div className="rounded-xl border border-slate-700 bg-[#0B0F17]/95 p-3 shadow-xl">
      <div className="flex items-center justify-between gap-4 text-xs text-slate-400">
        <span className="font-semibold text-slate-200">{point.dayLabelBn}</span>
        <span>·</span>
        <span>{point.dateLabelBn}</span>
      </div>
      <div className="mt-1.5 flex items-baseline justify-between gap-3">
        <span className="text-xs font-medium text-amber-300">
          {point.moodLabelBn}
        </span>
        <span className="font-mono text-xs font-semibold tabular-nums text-sky-300">
          {point.score}/100
        </span>
      </div>
      {point.noteBn && (
        <p className="mt-1 text-[11px] text-slate-400 max-w-[200px]">
          {point.noteBn}
        </p>
      )}
    </div>
  );
};

export const EmotionMirrorPanel: React.FC<EmotionMirrorPanelProps> = ({
  currentEmotion,
  emotionIntensity,
  emotionHistoryCounts,
  memories,
  suggestedSongs,
  moodTrend,
  onLogMood,
  onAddMemory,
  onRemoveMemory,
  onTestEmotion,
  personaName,
  userName,
  userMood,
  messages,
  onSpeakText,
  onOpenJournalModal,
}) => {
  const [newMemoryText, setNewMemoryText] = useState("");
  const [newMemoryCat, setNewMemoryCat] = useState("অনুভূতি");
  const [friendNote, setFriendNote] = useState<string>("");
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);

  // Daily Mood Quote State matching current emotion/mood
  const [currentQuote, setCurrentQuote] = useState<MoodQuote>(() => {
    const list = getQuotesForEmotion(currentEmotion, userMood);
    return list[Math.floor(Math.random() * list.length)] || MOOD_QUOTES[0];
  });
  const [isCopied, setIsCopied] = useState(false);
  const [isGeneratingAiQuote, setIsGeneratingAiQuote] = useState(false);

  // Automatically update quote when emotion or mood changes
  useEffect(() => {
    const list = getQuotesForEmotion(currentEmotion, userMood);
    const randomPick =
      list[Math.floor(Math.random() * list.length)] || MOOD_QUOTES[0];
    setCurrentQuote(randomPick);
  }, [currentEmotion, userMood]);

  const handleNextQuote = () => {
    const list = getQuotesForEmotion(currentEmotion, userMood);
    const others = list.filter((q) => q.id !== currentQuote.id);
    const pool = others.length > 0 ? others : list;
    const nextPick = pool[Math.floor(Math.random() * pool.length)];
    setCurrentQuote(nextPick);
  };

  const handleCopyQuote = () => {
    if (!currentQuote) return;
    navigator.clipboard.writeText(
      `“${currentQuote.quoteBn}” — ${currentQuote.authorBn}`
    );
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleGenerateAiQuote = async () => {
    setIsGeneratingAiQuote(true);
    try {
      const res = await fetch("/api/mood-quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName,
          userMood,
          emotionKey: currentEmotion,
        }),
      });
      const data = await res.json();
      if (data && data.quote) {
        setCurrentQuote({
          id: `ai-${Date.now()}`,
          quoteBn: data.quote,
          authorBn: data.author || "Thunder ভাই",
          contextBn: data.context || `তোর ${userMood} মেজাজে Thunder-এর প্রেরণা`,
          matchedMoods: [currentEmotion],
        });
      }
    } catch {
      handleNextQuote();
    } finally {
      setIsGeneratingAiQuote(false);
    }
  };

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    onAddMemory(newMemoryText.trim(), newMemoryCat);
    setNewMemoryText("");
  };

  // Download all saved diary entries / memories as plain text (.txt) file
  const handleDownloadDiary = () => {
    if (memories.length === 0) return;

    const dateStr = new Date().toLocaleDateString("bn-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    let content = `======================================================\n`;
    content += `   Thunder ও ${userName}-এর স্মৃতির ডায়েরি (Mood & Memories)\n`;
    content += `======================================================\n`;
    content += `ডাউনলোডের তারিখ : ${dateStr}\n`;
    content += `মোট সংরক্ষিত স্মৃতি : ${memories.length}টি\n`;
    content += `বর্তমান মেজাজ    : ${userMood}\n`;
    content += `সহানুভূতিশীল ভাই : Thunder\n`;
    content += `======================================================\n\n`;

    memories.forEach((mem, idx) => {
      const emo = EMOTIONS[mem.emotionKey]?.labelBn || "সহানুভূতিশীল";
      content += `[স্মৃতি #${idx + 1}]\n`;
      content += `তারিখ ও সময় : ${mem.timestamp}\n`;
      content += `ধরন         : ${mem.category}\n`;
      content += `অনুভূতি       : ${emo}\n`;
      content += `বিবরণ       :\n${mem.text}\n`;
      content += `------------------------------------------------------\n\n`;
    });

    content += `======================================================\n`;
    content += `Thunder ভাইয়ের আন্তরিক বার্তা:\n`;
    content += `"ভাই ${userName}, জীবনের যে পরিস্থিতিতেই থাকিস না কেন, তোর এই Thunder ভাই সবসময় তোর পাশে ছায়ার মতো থাকবে। তোর মনের প্রতিটি কথা আমার স্মৃতির ডায়েরিতে অমলিন।"\n`;
    content += `======================================================\n`;

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Thunder_Diary_${userName}_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleGenerateFriendNote = async () => {
    setIsGeneratingNote(true);
    try {
      const res = await fetch("/api/friend-note", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          personaName,
          userName,
          userMood,
          recentMessages: messages.slice(-6),
          memories,
        }),
      });
      const data = await res.json();
      if (data.note) {
        setFriendNote(data.note);
      }
    } catch {
      setFriendNote(
        "শোন ভাই, জীবনের পথে কখনো মন খারাপ হলে নিজেকে একা ভাববি না। তোর এই Thunder ভাই সবসময় তোর পাশে আছে। মন হালকা করতে অর্ণবের 'হোক কলরব' বা শিরোনামহীনের 'হাসিমুখ' গানটা শুনতে পারিস!"
      );
    } finally {
      setIsGeneratingNote(false);
    }
  };

  // Compute 7-day average & trend delta
  const avgScore =
    moodTrend.length > 0
      ? Math.round(
          moodTrend.reduce((acc, item) => acc + item.score, 0) /
            moodTrend.length
        )
      : 70;

  const firstScore = moodTrend[0]?.score ?? 50;
  const latestScore = moodTrend[moodTrend.length - 1]?.score ?? 70;
  const scoreDelta = latestScore - firstScore;

  const allEmotions = Object.values(EMOTIONS);

  return (
    <div className="flex flex-col gap-6">
      {/* Section 1: 7-Day Mood Trend Chart (Recharts) */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#111726] p-5">
        <div className="flex items-start justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-amber-400 shrink-0" />
            <div>
              <h3 className="text-base font-semibold text-slate-100">
                Mood Trend · গত ৭ দিনের মনের গ্রাফ
              </h3>
              <p className="text-xs text-slate-400">
                গত ৭ দিনে তোর মনের অবস্থা ও মানসিক প্রশান্তির ওঠানামা
              </p>
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="font-mono text-xs font-semibold tabular-nums text-amber-300">
              গড় {avgScore}/100
            </div>
            <div
              className={`font-mono text-[11px] tabular-nums ${
                scoreDelta >= 0 ? "text-emerald-400" : "text-rose-400"
              }`}
            >
              {scoreDelta >= 0 ? `+${scoreDelta}` : scoreDelta} পয়েন্ট (৭ দিনে)
            </div>
          </div>
        </div>

        {/* Recharts 7-Day AreaChart */}
        <div className="mt-4 h-52 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={moodTrend}
              margin={{ top: 10, right: 10, left: -24, bottom: 0 }}
            >
              <defs>
                <linearGradient id="moodScoreFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.42} />
                  <stop offset="60%" stopColor="#38BDF8" stopOpacity={0.14} />
                  <stop offset="95%" stopColor="#38BDF8" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#1E293B"
                vertical={false}
              />
              <XAxis
                dataKey="dayLabelBn"
                stroke="#64748B"
                fontSize={11}
                tickLine={false}
                axisLine={{ stroke: "#1E293B" }}
              />
              <YAxis
                domain={[0, 100]}
                ticks={[25, 50, 75, 100]}
                stroke="#64748B"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomMoodTooltip />} />
              <ReferenceLine
                y={avgScore}
                stroke="#38BDF8"
                strokeDasharray="4 4"
                strokeOpacity={0.5}
              />
              <Area
                type="monotone"
                dataKey="score"
                stroke="#F59E0B"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#moodScoreFill)"
                activeDot={{
                  r: 5,
                  fill: "#F59E0B",
                  stroke: "#0B0F17",
                  strokeWidth: 2,
                }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Emotional Well-being Insight + Quick Log */}
        <div className="mt-3 border-t border-slate-800/80 pt-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>আজকের মেজাজ: {userMood}</span>
            <span className="font-mono tabular-nums text-slate-300">
              বর্তমান স্কোর: {latestScore}/100
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            {latestScore >= 70
              ? "Thunder-এর পর্যবেক্ষণ: ভাই, গত কয়েক দিনের তুলনায় আজ তোর মন বেশ প্রফুল্ল ও স্থির আছে!"
              : latestScore >= 45
              ? "Thunder-এর পর্যবেক্ষণ: ভাই, হালকা ক্লান্তি বা চাপ থাকলেও তুই ধীরে ধীরে সামলে নিচ্ছিস।"
              : "Thunder-এর পর্যবেক্ষণ: ভাই, আজ তোর মনটা বেশ ভারী। চিন্তা করিস না, আমি আর আমার গান তোর পাশেই আছি।"}
          </p>

          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {USER_MOODS.map((m) => {
              const isCurrent = userMood === m.labelBn;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onLogMood(m)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-colors whitespace-nowrap ${
                    isCurrent
                      ? "border-amber-500/50 bg-amber-500/15 text-amber-200"
                      : "border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                  }`}
                >
                  {m.labelBn} ({m.score})
                </button>
              );
            })}
          </div>

          {/* Daily Mood Journal Modal Trigger */}
          <div className="mt-3.5 flex items-center justify-between gap-2 border-t border-slate-800/80 pt-3">
            <span className="text-xs text-slate-400">
              মেজাজের বিস্তারিত অনুভূতির ডায়েরি:
            </span>
            <button
              type="button"
              onClick={() => {
                const currentOpt =
                  USER_MOODS.find((m) => m.labelBn === userMood) || USER_MOODS[4];
                onOpenJournalModal?.(currentOpt);
              }}
              className="flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/15 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/25 transition-colors shadow-sm shrink-0"
            >
              <BookHeart className="h-3.5 w-3.5 text-amber-400" />
              <span>দৈনিক ডায়েরি লেখো (Mood Journal)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Section 2: Daily 'Mood Quote' (আজকের মেজাজের অনুপ্রেরণাদায়ক উক্তি) */}
      <div className="relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-[#151D30] via-[#111726] to-[#0D1424] p-5 shadow-lg">
        {/* Subtle decorative quote background */}
        <Quote className="pointer-events-none absolute -bottom-6 -right-4 h-32 w-32 text-amber-500/5 rotate-12" />

        {/* Section Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/15 text-amber-300 border border-amber-500/30">
              <Quote className="h-3.5 w-3.5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                <span>Mood Quote · আজকের উক্তি</span>
              </h3>
              <p className="text-xs text-slate-400">
                তোর মেজাজ (<span className="text-amber-300 font-medium">{userMood}</span>) অনুযায়ী অনুপ্রেরণামূলক বাণী
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span
              className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-medium border"
              style={{
                borderColor: `${EMOTIONS[currentEmotion]?.accentHex || "#F59E0B"}40`,
                backgroundColor: `${EMOTIONS[currentEmotion]?.accentHex || "#F59E0B"}15`,
                color: EMOTIONS[currentEmotion]?.accentHex || "#F59E0B",
              }}
            >
              <span>{EMOTIONS[currentEmotion]?.labelBn || "সহানুভূতি"}</span>
            </span>
          </div>
        </div>

        {/* Quote Card */}
        <div className="mt-4 rounded-xl border border-slate-800/80 bg-slate-900/60 p-4 relative z-10 backdrop-blur-sm">
          <div className="flex items-start gap-3">
            <Quote className="h-5 w-5 text-amber-400 shrink-0 mt-0.5 opacity-80" />
            <div className="flex-1">
              <p className="font-display text-sm sm:text-base leading-relaxed text-amber-100/95 font-medium italic">
                “{currentQuote.quoteBn}”
              </p>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-amber-300">
                    — {currentQuote.authorBn}
                  </span>
                  <span className="text-slate-600">·</span>
                  <span className="text-[11px] text-slate-400">
                    {currentQuote.contextBn}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleCopyQuote}
                    title="উক্তিটি কপি করো"
                    className="flex items-center gap-1 rounded-lg border border-slate-700/80 bg-slate-800/80 px-2.5 py-1 text-xs text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                  >
                    {isCopied ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        <span className="text-emerald-300">কপি হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>কপি</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      onSpeakText(
                        `ভাই, তোর জন্য আজকের অনুপ্রেরণামূলক উক্তি: ${currentQuote.quoteBn} — ${currentQuote.authorBn}`,
                        currentEmotion
                      )
                    }
                    title="Thunder-এর কণ্ঠে উক্তিটি শোনো"
                    className="flex items-center gap-1 rounded-lg border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-200 hover:bg-amber-500/20 transition-colors"
                  >
                    <Volume2 className="h-3 w-3 text-amber-400" />
                    <span>কণ্ঠে শোনো</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls for More Quotes */}
        <div className="mt-3 flex items-center justify-between gap-2 text-xs">
          <button
            type="button"
            onClick={handleNextQuote}
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/70 px-3 py-1.5 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5 text-amber-400" />
            <span>অন্য উক্তি দেখাও</span>
          </button>

          <button
            type="button"
            onClick={handleGenerateAiQuote}
            disabled={isGeneratingAiQuote}
            className="flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/15 px-3 py-1.5 font-medium text-amber-200 hover:bg-amber-500/25 transition-colors disabled:opacity-50"
          >
            <Sparkles
              className={`h-3.5 w-3.5 text-amber-300 ${
                isGeneratingAiQuote ? "animate-spin" : ""
              }`}
            />
            <span>
              {isGeneratingAiQuote
                ? "বাণী ভাবছি..."
                : "Thunder-এর বিশেষ বাণী"}
            </span>
          </button>
        </div>
      </div>

      {/* Section 3: Thunder's Suggested Songs for Bhai */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#111726] p-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Music className="h-4 w-4 text-amber-400" />
            <div>
              <h3 className="text-base font-semibold text-slate-100">
                ভাইয়ের মন ভালো করার গান
              </h3>
              <p className="text-xs text-slate-400">
                তোর মনের কষ্ট ও মেজাজ বুঝে Thunder-এর গান সাজেশন
              </p>
            </div>
          </div>
          <span className="font-mono text-xs tabular-nums text-amber-300">
            {suggestedSongs.length}টি গান
          </span>
        </div>

        <div className="mt-3.5 space-y-3 max-h-64 overflow-y-auto pr-1">
          {suggestedSongs.map((song, idx) => {
            const ytQuery = encodeURIComponent(`${song.title} ${song.artist}`);
            return (
              <div
                key={`${song.title}-${idx}`}
                className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-3.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-semibold text-amber-300">
                      {song.title}
                    </h4>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-400">
                      <span>শিল্পী: {song.artist}</span>
                    </div>
                  </div>
                  <a
                    href={`https://www.youtube.com/results?search_query=${ytQuery}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-200 hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>শুনুন</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>

                {song.lyricSnippet && (
                  <p className="mt-2 border-l-2 border-amber-500/40 pl-2.5 text-xs italic text-slate-300">
                    “{song.lyricSnippet}”
                  </p>
                )}

                <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-slate-400">
                  <span>{song.reasonBn}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onSpeakText(
                        `ভাই, তোর মন ভালো করার জন্য আমি ${song.artist}-এর ${song.title} গানটা সাজেস্ট করছি। ${song.reasonBn}`,
                        "empathetic"
                      )
                    }
                    className="flex items-center gap-1 text-sky-300 hover:text-sky-200 whitespace-nowrap shrink-0"
                  >
                    <Volume2 className="h-3 w-3" />
                    <span>Thunder-এর মুখে শোনো</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 3: Live Emotion Spectrum */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#111726] p-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div>
            <h3 className="text-base font-semibold text-slate-100">
              Thunder-এর অনুভূতির দর্পণ
            </h3>
            <p className="text-xs text-slate-400">
              ভাইয়ের কথার সাথে Thunder-এর মনের অনুভূতির পরিবর্তন
            </p>
          </div>
          <span className="font-mono text-xs tabular-nums text-amber-300">
            {EMOTIONS[currentEmotion].labelBn} · {emotionIntensity}%
          </span>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-2.5">
          {allEmotions.map((emo) => {
            const isActive = emo.key === currentEmotion;
            const count = emotionHistoryCounts[emo.key] || 0;
            const barWidth = isActive
              ? emotionIntensity
              : Math.min(85, 18 + count * 16);

            return (
              <button
                key={emo.key}
                type="button"
                onClick={() => onTestEmotion(emo.key)}
                className={`group flex flex-col gap-1.5 rounded-xl border p-3 text-left transition-colors ${
                  isActive
                    ? "border-slate-700 bg-slate-800/75"
                    : "border-slate-800/60 bg-slate-900/40 hover:border-slate-700/80"
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ backgroundColor: emo.accentHex }}
                    />
                    <span className="font-medium text-slate-200">
                      {emo.labelBn}
                    </span>
                    <span className="text-slate-500" aria-hidden="true">
                      ·
                    </span>
                    <span className="text-slate-400">{emo.labelEn}</span>
                  </div>
                  <span className="font-mono tabular-nums text-slate-400">
                    {count} বার প্রকাশ
                  </span>
                </div>

                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${barWidth}%`,
                      backgroundColor: emo.accentHex,
                    }}
                  />
                </div>

                <p className="text-xs text-slate-400">{emo.descriptionBn}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Section 4: Heartfelt Brother's Letter */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#111726] p-5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-slate-100">
              ভাইয়ের প্রতি Thunder-এর চিঠি
            </h3>
            <p className="text-xs text-slate-400">
              সান্ত্বনা ও সাহস জোগাতে তোর ভাইয়ের ব্যক্তিগত বার্তা
            </p>
          </div>
          <button
            type="button"
            onClick={handleGenerateFriendNote}
            disabled={isGeneratingNote}
            className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>{isGeneratingNote ? "লেখা হচ্ছে..." : "চিঠি লেখো"}</span>
          </button>
        </div>

        {friendNote ? (
          <div className="mt-4 border-t border-slate-800/80 pt-3">
            <p className="text-sm leading-relaxed text-slate-200 whitespace-pre-line">
              {friendNote}
            </p>
            <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
              <span>ইতি, তোর ভাই Thunder</span>
              <button
                type="button"
                onClick={() => onSpeakText(friendNote, "touched")}
                className="flex items-center gap-1.5 text-amber-300 hover:text-amber-200 transition-colors"
              >
                <Volume2 className="h-3.5 w-3.5" />
                <span>কণ্ঠে শোনো</span>
              </button>
            </div>
          </div>
        ) : (
          <p className="mt-3 text-xs text-slate-400">
            “চিঠি লেখো” বোতামে চাপ দিলে Thunder তোর জন্য সান্ত্বনা ও গানের সাজেশনসহ মনের কথা লিখবে।
          </p>
        )}
      </div>

      {/* Section 5: Shared Brotherhood Diary / Memories */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#111726] p-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <BookHeart className="h-4 w-4 text-amber-400" />
            <h3 className="text-base font-semibold text-slate-100">
              দুই ভাইয়ের স্মৃতির ডায়েরি
            </h3>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadDiary}
              disabled={memories.length === 0}
              title="সংরক্ষিত সব স্মৃতির ডায়েরি টেক্সট ফাইল (.txt) আকারে ডাউনলোড করো"
              className="flex items-center gap-1 rounded-lg border border-sky-500/40 bg-sky-500/10 px-2.5 py-1 text-xs font-medium text-sky-300 hover:bg-sky-500/20 transition-colors disabled:opacity-40"
            >
              <Download className="h-3 w-3" />
              <span>ডায়েরি ডাউনলোড (.txt)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                const currentOpt =
                  USER_MOODS.find((m) => m.labelBn === userMood) || USER_MOODS[4];
                onOpenJournalModal?.(currentOpt);
              }}
              className="flex items-center gap-1 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-300 hover:bg-amber-500/20 transition-colors"
            >
              <BookHeart className="h-3 w-3" />
              <span>নতুন ডায়েরি লেখো</span>
            </button>
            <span className="font-mono text-xs tabular-nums text-slate-400">
              মোট {memories.length}টি স্মৃতি
            </span>
          </div>
        </div>

        <p className="mt-2 text-xs text-slate-400">
          তোর বলা সুখ-দুঃখের কথা ও পছন্দের গানের কথা Thunder এখানে যত্ন করে মনে রাখে।
        </p>

        {/* Manual Memory Input */}
        <form onSubmit={handleCreateMemory} className="mt-3 flex gap-2">
          <select
            value={newMemoryCat}
            onChange={(e) => setNewMemoryCat(e.target.value)}
            aria-label="স্মৃতির ধরন"
            className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-2 text-xs text-slate-200 focus:border-amber-400 focus:outline-none"
          >
            <option value="অনুভূতি">অনুভূতি</option>
            <option value="পছন্দ">পছন্দ</option>
            <option value="স্বপ্ন">স্বপ্ন</option>
            <option value="গল্প">গল্প</option>
          </select>
          <input
            type="text"
            value={newMemoryText}
            onChange={(e) => setNewMemoryText(e.target.value)}
            placeholder="Thunder ভাইকে মনে রাখার মতো কিছু লেখো..."
            className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none"
          />
          <button
            type="submit"
            className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>যোগ করো</span>
          </button>
        </form>

        {/* Memories List */}
        <div className="mt-4 space-y-2.5 max-h-60 overflow-y-auto pr-1">
          {memories.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-500">
              এখনো কোনো স্মৃতি জমা হয়নি। Thunder ভাইয়ের সাথে নিজের মনের কথা শেয়ার করলে এখানে জমা হবে।
            </div>
          ) : (
            memories.map((mem) => (
              <div
                key={mem.id}
                className="flex items-start justify-between gap-3 border-b border-slate-800/60 pb-2.5 last:border-none"
              >
                <div>
                  <p className="text-xs font-medium text-slate-200">
                    {mem.text}
                  </p>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
                    <span className="text-amber-300/90">{mem.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {mem.timestamp}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onRemoveMemory(mem.id)}
                  aria-label="স্মৃতি মুছে ফেলো"
                  className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
