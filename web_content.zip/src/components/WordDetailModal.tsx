import React, { useState } from 'react';
import {
  ChevronLeft,
  Volume2,
  Bookmark,
  Sparkles,
  Table,
  GitCompare,
  Layers,
  AlertTriangle,
  FileText,
  CheckSquare,
  PenTool,
  Check,
  Brain,
  Clock
} from 'lucide-react';
import { WordData, CognitiveStatus, SrsItem, SrsRating } from '../types';
import { speakWord, sound } from '../services/sound';
import { SrsEngine, EBBINGHAUS_STAGES } from '../services/srs';

interface WordDetailModalProps {
  word: WordData;
  isSaved: boolean;
  status: CognitiveStatus;
  fluency?: number;
  srsItem?: SrsItem;
  onClose: () => void;
  onToggleSave: (word: string) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
  onAnswerExamBattery: (word: string, isCorrect: boolean) => void;
  onOpenChatWithWord?: (word: string) => void;
  onUpdateFluency?: (word: string, score: number) => void;
  onSaveEnrichedDossier?: (dossier: WordData) => void;
  onRateSrsWord?: (word: string, rating: SrsRating) => void;
  targetExam?: string;
}

export const WordDetailModal: React.FC<WordDetailModalProps> = ({
  word,
  isSaved,
  status,
  fluency = 50,
  srsItem,
  onClose,
  onToggleSave,
  onSetStatus,
  onAnswerExamBattery,
  onOpenChatWithWord,
  onUpdateFluency,
  onSaveEnrichedDossier,
  onRateSrsWord,
  targetExam = 'Bangladesh Civil Service (BCS)',
}) => {
  const [activeWord, setActiveWord] = useState<WordData>(word);
  const [currentFluency, setCurrentFluency] = useState(fluency);
  const [isEnriching, setIsEnriching] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [revealedExplanations, setRevealedExplanations] = useState<Record<number, boolean>>({});

  const handleEnrichWithAI = async () => {
    setIsEnriching(true);
    try {
      const response = await fetch('/api/generate-word-dossier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word: activeWord.word, targetExam }),
      });
      if (!response.ok) throw new Error('Enrichment failed');
      const enriched: WordData = await response.json();
      if (enriched && enriched.word) {
        setActiveWord(enriched);
        if (onSaveEnrichedDossier) {
          onSaveEnrichedDossier(enriched);
        }
        sound.triggerCelebration();
        sound.triggerFloatingXp(25);
      }
    } catch (e) {
      console.error('Enrichment error:', e);
      alert('Could not connect to online AI enrichment. Please try again or open directly in Gemini / ChatGPT below.');
    } finally {
      setIsEnriching(false);
    }
  };

  const handleOpenInPersonalAI = (platform: 'gemini' | 'chatgpt') => {
    const prompt = `Act as an expert English lexicographer and senior ${targetExam} vocabulary instructor.
Provide an authentic, highly detailed Master Dossier for the word: "${activeWord.word}".
Include:
1. True morphological forms (noun, verb, adjective, adverb) with realistic sentences.
2. 5 high-yield collocations.
3. 5 real-world sentences from contemporary literature or news editorials (with Bengali translations).
4. Subtle nuance distinctions from confusing lookalikes.
5. Bengali mnemonic hook (মনে রাখার কৌশল).
6. 3 Exam-pattern MCQs.`;

    navigator.clipboard.writeText(prompt);
    sound.triggerFloatingXp(10);
    const url = platform === 'gemini' ? 'https://gemini.google.com/app' : 'https://chatgpt.com';
    window.open(url, '_blank');
  };

  const handleSelectAnswer = (qIdx: number, chosenIdx: number, correctIdx: number) => {
    if (selectedAnswers[qIdx] !== undefined) return; // already answered
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: chosenIdx }));
    setRevealedExplanations(prev => ({ ...prev, [qIdx]: true }));

    const isCorrect = chosenIdx === correctIdx;
    if (isCorrect) {
      sound.triggerFloatingXp(15);
      handleSetFluencyScore(Math.min(100, currentFluency + 15));
    } else {
      sound.wrong();
    }
    onAnswerExamBattery(activeWord.word, isCorrect);
  };

  const handleSetFluencyScore = (score: number) => {
    setCurrentFluency(score);
    if (onUpdateFluency) {
      onUpdateFluency(activeWord.word, score);
    }
    if (score >= 80) {
      onSetStatus(activeWord.word, 'mastered');
    } else if (score >= 40) {
      onSetStatus(activeWord.word, 'revise');
    } else {
      onSetStatus(activeWord.word, 'learn');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#f8faf7] dark:bg-[#090d16] flex flex-col overflow-hidden animate-in fade-in duration-200">
      
      {/* Top Header Bar */}
      <div className="bg-white/95 dark:bg-[#111827]/95 backdrop-blur-md border-b-2 border-slate-200 dark:border-slate-800 p-3 safe-top shrink-0 flex items-center justify-between">
        <button
          onClick={onClose}
          className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-extrabold text-xs flex items-center gap-1 shadow-sm active:scale-95 transition-all"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Wordbook</span>
        </button>

        {/* Cognitive Status Selector & Bookmark */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onToggleSave(word.word)}
            className={`p-2 rounded-xl transition-all ${
              isSaved
                ? 'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600'
            }`}
            title={isSaved ? 'Saved in Bookmarks' : 'Save to Bookmarks'}
          >
            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={() => onSetStatus(word.word, 'learn')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all ${
              status === 'learn'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            Learn
          </button>

          <button
            onClick={() => onSetStatus(word.word, 'revise')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all ${
              status === 'revise'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            Revise
          </button>

          <button
            onClick={() => onSetStatus(word.word, 'mastered')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all ${
              status === 'mastered'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            Known
          </button>
        </div>
      </div>

      {/* Scrollable 17-Section Dossier Body */}
      <div className="flex-1 smooth-scroll p-4 space-y-4 pb-28 max-w-2xl mx-auto w-full">
        
        {/* Headword Showcase */}
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
                  {word.word}
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  🔥 Exam Focus
                </span>
              </div>
              
              <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs">
                <span className="font-bold text-emerald-600 dark:text-emerald-400 capitalize">
                  {word.posFull || word.pos}
                </span>
                <span className="text-slate-400 font-mono">{word.ipa}</span>
                <span className="font-bengali font-bold text-slate-500">{word.bengaliPron}</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300">
                  {word.cefr}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => speakWord(word.word, 'en-US')}
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:text-emerald-500 font-bold text-xs flex items-center gap-1 active:scale-95 transition-all"
                title="US Pronunciation"
              >
                <Volume2 className="w-3.5 h-3.5" /> US
              </button>
              <button
                onClick={() => speakWord(word.word, 'en-GB')}
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:text-emerald-500 font-bold text-xs flex items-center gap-1 active:scale-95 transition-all"
                title="UK Pronunciation"
              >
                <Volume2 className="w-3.5 h-3.5" /> UK
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/80 font-bengali space-y-1">
            <div className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wide">
              বাংলা অর্থ ও সারমর্ম:
            </div>
            <div className="text-base font-bold text-emerald-950 dark:text-emerald-100">
              {activeWord.bengali}
            </div>
            {activeWord.bengaliExp && (
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pt-1">
                {activeWord.bengaliExp}
              </p>
            )}
          </div>

          {/* WordUp-Style Fluency Meter */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span>WordUp Fluency Mastery:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-mono text-sm">{currentFluency}%</span>
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                {currentFluency >= 80 ? 'Mastered 🌟' : currentFluency >= 50 ? 'Retained ⚡' : currentFluency >= 25 ? 'Learning 🎯' : 'Encountered'}
              </span>
            </div>

            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-400 via-teal-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${currentFluency}%` }}
              />
            </div>

            {/* Quick 1-Tap Fluency Selector */}
            <div className="grid grid-cols-4 gap-1.5 pt-1 text-[10px] font-bold">
              {[
                { label: 'Unseen (0%)', val: 0 },
                { label: 'Encountered (35%)', val: 35 },
                { label: 'Revise (65%)', val: 65 },
                { label: 'Mastered (100%)', val: 100 },
              ].map((lvl) => (
                <button
                  key={lvl.val}
                  onClick={() => handleSetFluencyScore(lvl.val)}
                  className={`py-1.5 rounded-xl border text-center transition-all ${
                    currentFluency === lvl.val
                      ? 'bg-emerald-600 text-white border-emerald-600 font-black shadow-sm'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-emerald-400'
                  }`}
                >
                  {lvl.label}
                </button>
              ))}
            </div>
          </div>

          {/* Ebbinghaus Memory Curve & Retention Status */}
          {srsItem && (
            <div className="p-3 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Ebbinghaus Memory Retention:</span>
                  <span className={`font-mono text-sm ${
                    srsItem.retentionScore >= 80
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : srsItem.retentionScore >= 50
                      ? 'text-amber-600 dark:text-amber-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}>
                    {srsItem.retentionScore}%
                  </span>
                </span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300">
                  {EBBINGHAUS_STAGES[srsItem.stage]?.label || 'Stage 0'}
                </span>
              </div>

              <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    srsItem.retentionScore >= 80 ? 'bg-emerald-500' : srsItem.retentionScore >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${srsItem.retentionScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 pt-0.5">
                <span>Stability: {srsItem.stability} Days</span>
                <span>Reviewed: {srsItem.reviewsCount} time{srsItem.reviewsCount !== 1 ? 's' : ''} ({srsItem.lapses} lapse)</span>
              </div>

              {onRateSrsWord && (
                <div className="flex items-center justify-between pt-1 border-t border-indigo-200/60 dark:border-indigo-900/60">
                  <span className="text-[9px] font-bold text-slate-400 font-bengali">
                    স্পেসড রিপিটেশন রেটিং দিন:
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        onRateSrsWord(activeWord.word, 'again');
                        sound.wrong();
                      }}
                      className="px-2 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-[9px] font-extrabold hover:bg-rose-200 active:scale-95 transition-all"
                    >
                      Again (&lt;1d)
                    </button>
                    <button
                      onClick={() => {
                        onRateSrsWord(activeWord.word, 'good');
                        sound.correct();
                      }}
                      className="px-2 py-0.5 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[9px] font-extrabold hover:bg-blue-200 active:scale-95 transition-all"
                    >
                      Good
                    </button>
                    <button
                      onClick={() => {
                        onRateSrsWord(activeWord.word, 'easy');
                        sound.triggerFloatingXp(20);
                      }}
                      className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[9px] font-extrabold hover:bg-emerald-200 active:scale-95 transition-all"
                    >
                      Easy
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Online AI Integration Bar (Non-Generic Gemini Enrichment & Personal AI Accounts) */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 text-white border border-indigo-700/50 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-black text-amber-300">
                <Sparkles className="w-4 h-4 fill-current" />
                <span>Deep Online AI Lexicographer</span>
              </div>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Bespoke Content
              </span>
            </div>

            <p className="text-[11px] text-slate-300 font-bengali leading-relaxed">
              স্বয়ংক্রিয় AI ইন্টিগ্রেশনের মাধ্যমে শব্দটির জন্য খাঁটি ব্যাকরণিক রূপান্তর (Real Word Forms), প্রাকৃতিক কলকেশন ও পরীক্ষার প্রশ্নমালা তৈরি করুন।
            </p>

            <button
              onClick={handleEnrichWithAI}
              disabled={isEnriching}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              {isEnriching ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Generating Bespoke 17-Section Dossier...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Enrich with Gemini AI (Bespoke Forms & Sentences)</span>
                </>
              )}
            </button>

            {/* Launch into personal Gemini or ChatGPT accounts */}
            <div className="pt-1 flex items-center gap-2">
              <button
                onClick={() => handleOpenInPersonalAI('gemini')}
                className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] rounded-lg shadow-sm flex items-center justify-center gap-1 active:scale-95 transition-all"
                title="Send master prompt to your personal Google Gemini account"
              >
                <span>Launch in Gemini</span>
              </button>

              <button
                onClick={() => handleOpenInPersonalAI('chatgpt')}
                className="flex-1 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-[10px] rounded-lg shadow-sm flex items-center justify-center gap-1 active:scale-95 transition-all"
                title="Send master prompt to your personal OpenAI ChatGPT account"
              >
                <span>Launch in ChatGPT</span>
              </button>
            </div>
          </div>
        </div>

        {/* Section 1 & 2: Definitions & Connotations */}
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3 text-xs">
          <h3 className="font-extrabold uppercase tracking-wider text-slate-400">
            1 & 2. Definitions & Connotations
          </h3>
          <div className="space-y-2">
            <div>
              <strong className="text-slate-900 dark:text-white block font-bold">Simplest English Definition:</strong>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">{activeWord.simpleDef}</p>
            </div>
            <div>
              <strong className="text-slate-900 dark:text-white block font-bold">Advanced Lexicographical Definition:</strong>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">{activeWord.advDef}</p>
            </div>
            <div>
              <strong className="text-slate-900 dark:text-white block font-bold">Register & Emotional Tone:</strong>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">{activeWord.register} &bull; {activeWord.connotations}</p>
            </div>
          </div>
        </div>

        {/* Section 3: Word Family & Parts of Speech Matrix */}
        {activeWord.formsTable && activeWord.formsTable.length > 0 && (
          <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-600 flex items-center gap-1.5">
                <Table className="w-4 h-4" /> 3. Word Family & Parts of Speech Matrix
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">Genuine Forms</span>
            </div>
            <p className="text-xs text-slate-500 font-bengali">
              শব্দটির মূল রূপ, এর রূপান্তরিত পদ (Derivatives) এবং পরীক্ষায় বিভ্রান্তি এড়াতে ব্যবহার নির্দেশিকা:
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-100 dark:border-slate-800 rounded-xl overflow-hidden">
                <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-600 dark:text-slate-300">
                  <tr>
                    <th className="p-2.5">Form</th>
                    <th className="p-2.5">Part of Speech</th>
                    <th className="p-2.5 font-bengali">বাংলা অর্থ</th>
                    <th className="p-2.5">Contextual Example</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {activeWord.formsTable.map((f, i) => (
                    <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold text-emerald-600 dark:text-emerald-400">{f.form}</td>
                      <td className="p-2.5 text-slate-400 font-mono text-[11px]">{f.pos}</td>
                      <td className="p-2.5 font-bengali font-semibold">{f.bng}</td>
                      <td className="p-2.5 italic text-slate-600 dark:text-slate-300">{f.ex}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {activeWord.formsUsageNote && (
              <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-xs font-bengali text-amber-900 dark:text-amber-200">
                {activeWord.formsUsageNote}
              </div>
            )}
          </div>
        )}

        {/* Section 7: Nuance Differences & Confusing Words */}
        {activeWord.confusions && activeWord.confusions.length > 0 && (
          <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
                <GitCompare className="w-4 h-4" /> 7. Nuance Differences & Confusing Words
              </h3>
              <span className="text-[10px] text-amber-600 font-bold bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded">
                High Exam Yield
              </span>
            </div>
            <p className="text-xs text-slate-500 font-bengali">
              কাছাকাছি অর্থের শব্দগুলোর সূক্ষ্ম পার্থক্য (Nuances) বুঝে নিন, যাতে MCQ পরীক্ষায় বিভ্রান্তি না ঘটে:
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-amber-100 dark:border-amber-950 rounded-xl overflow-hidden">
                <thead className="bg-amber-50 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 font-bold">
                  <tr>
                    <th className="p-2.5">Word</th>
                    <th className="p-2.5">Core Meaning</th>
                    <th className="p-2.5">Example in Context</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {activeWord.confusions.map((c, i) => (
                    <tr key={i} className="hover:bg-amber-50/20 dark:hover:bg-amber-950/20">
                      <td className="p-2.5 font-bold text-amber-900 dark:text-amber-300">{c.word}</td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-200">{c.diff}</td>
                      <td className="p-2.5 italic text-slate-500 dark:text-slate-400">{c.ex}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Section 9 & 10: Collocations & Grammar */}
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-600 mb-2 flex items-center gap-1.5">
              <Layers className="w-4 h-4" /> 9. Common Collocations & Natural Expressions
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {(activeWord.collocations || []).map((cl, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-[9px] uppercase font-bold text-slate-400 font-mono">{cl.type}</div>
                  <div className="font-mono text-emerald-700 dark:text-emerald-400 font-black text-xs mt-0.5">{cl.expr}</div>
                  <div className="font-bengali text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">{cl.bn}</div>
                </div>
              ))}
            </div>
          </div>

          {activeWord.keyExpression && (
            <div className="p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
                Particularly Useful Institutional Expression:
              </span>
              <div className="text-xs sm:text-sm font-black font-mono text-slate-900 dark:text-white">
                {activeWord.keyExpression}
              </div>
              <p className="text-xs font-bengali text-slate-600 dark:text-slate-300 leading-relaxed">
                {activeWord.keyExpressionBn}
              </p>
            </div>
          )}

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
            <h4 className="font-extrabold uppercase tracking-wider text-slate-400 mb-1">
              10. Grammar Patterns & Prepositions
            </h4>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed font-mono">
              {activeWord.grammar}
            </p>
          </div>

          {activeWord.errors && activeWord.errors.length > 0 && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <h4 className="font-extrabold uppercase tracking-wider text-rose-600 mb-2 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4" /> 12. Common Errors to Avoid
              </h4>
              <div className="space-y-2">
                {activeWord.errors.map((err, i) => (
                  <div key={i} className="p-2.5 rounded-xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900">
                    <div className="text-rose-600 font-bold">&times; {err.mistake}</div>
                    <div className="text-emerald-700 dark:text-emerald-400 font-medium mt-0.5 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> {err.fix}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Section 5: Examination Example Sentences */}
        {activeWord.sentences && activeWord.sentences.length > 0 && (
          <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-600 flex items-center gap-1.5">
                <FileText className="w-4 h-4" /> 5. Examination Example Sentences
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">BCS / Essay Caliber</span>
            </div>
            <p className="text-xs text-slate-500 font-bengali">
              বিভিন্ন বাস্তবিক ও প্রাতিষ্ঠানিক ক্ষেত্রে শব্দটির বহুমুখী প্রয়োগ:
            </p>
            <div className="space-y-2.5">
              {activeWord.sentences.map((s, idx) => (
                <div key={idx} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400">
                    <span>Example Sentence {idx + 1}</span>
                    <span className="font-mono text-[9px] text-emerald-500">Verified</span>
                  </div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-white leading-relaxed">
                    {s.en}
                  </div>
                  <div className="text-xs font-bengali text-emerald-900 dark:text-emerald-300 bg-emerald-50/60 dark:bg-emerald-950/40 p-1.5 rounded-lg leading-relaxed">
                    {s.bn}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section 6: Synonyms & Antonyms */}
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3 text-xs">
          <h3 className="font-extrabold uppercase tracking-wider text-slate-400">
            6. Synonyms & Antonyms
          </h3>
          <div className="space-y-2">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
              <strong className="text-slate-900 dark:text-white block font-bold">Synonyms by Nuance:</strong>
              {activeWord.synonyms.map((sg, i) => (
                <div key={i} className="text-[11px]">
                  <span className="font-semibold text-emerald-700 dark:text-emerald-400">{sg.nuance}: </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{sg.words.join(', ')}</span>
                  {sg.note && <span className="text-slate-400 text-[10px] block font-normal">{sg.note}</span>}
                </div>
              ))}
            </div>

            <div className="p-3 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900 space-y-1.5">
              <strong className="text-rose-800 dark:text-rose-300 block font-bold">Antonyms:</strong>
              {activeWord.antonyms.map((ag, i) => (
                <div key={i} className="text-[11px]">
                  <span className="font-semibold text-rose-700 dark:text-rose-400">{ag.nuance}: </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{ag.words.join(', ')}</span>
                  {ag.note && <span className="text-slate-400 text-[10px] block font-normal">{ag.note}</span>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Section 8 & 13: Etymology & Mnemonic */}
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-[#111827] dark:to-slate-900 border-2 border-amber-200 dark:border-amber-900/60 rounded-3xl p-4 shadow-sm space-y-3">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-400 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 fill-current" /> 8 & 13. Etymology & Memory Hook
          </h3>
          <div className="text-xs">
            <strong className="text-slate-800 dark:text-slate-200 block mb-0.5">8. Etymology & Roots:</strong>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{activeWord.etymology}</p>
          </div>
          <div className="p-3 bg-white/90 dark:bg-slate-900/90 rounded-2xl font-bengali space-y-1 border border-amber-200/50 dark:border-amber-800/40">
            <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase">
              13. মনে রাখার টেকনিক (Mnemonic):
            </span>
            <p className="text-xs font-semibold text-slate-900 dark:text-white leading-relaxed">
              {activeWord.mnemonicBengali}
            </p>
          </div>
        </div>

        {/* Section 15: Competitive Examination MCQs Battery */}
        {activeWord.examBattery && activeWord.examBattery.length > 0 && (
          <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-purple-600 flex items-center gap-1.5">
                <CheckSquare className="w-4 h-4" /> 15. Competitive Examination MCQs Battery
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                {activeWord.examBattery.length} Exam-Pattern MCQs
              </span>
            </div>
            <p className="text-xs text-slate-500 font-bengali">
              বিসিএস প্রিলিমিনারি, ব্যাংক নিয়োগ ও বিশ্ববিদ্যালয় ভর্তি পরীক্ষার আদলে তৈরি ৫টি ভিন্ন ক্যাটাগরির বহুনির্বাচনী প্রশ্নমালা:
            </p>
            
            <div className="space-y-3">
              {activeWord.examBattery.map((q, qIndex) => {
                const answered = selectedAnswers[qIndex] !== undefined;
                const chosen = selectedAnswers[qIndex];

                return (
                  <div key={qIndex} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
                      <span>MCQ {qIndex + 1} of {activeWord.examBattery.length}</span>
                      <span className="text-purple-500 font-mono text-[10px]">Exam Standard</span>
                    </div>
                    
                    <div className="font-black text-xs sm:text-sm text-slate-900 dark:text-white leading-snug">
                      {q.q}
                    </div>

                    <div className="space-y-1.5">
                      {q.opts.map((opt, oIdx) => {
                        let btnStyle = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-500";
                        if (answered) {
                          if (oIdx === q.ans) {
                            btnStyle = "bg-emerald-600 text-white font-bold border-emerald-600";
                          } else if (oIdx === chosen) {
                            btnStyle = "bg-rose-600 text-white font-bold border-rose-600";
                          } else {
                            btnStyle = "opacity-50 bg-slate-100 dark:bg-slate-800 border-transparent text-slate-400";
                          }
                        }

                        return (
                          <button
                            key={oIdx}
                            disabled={answered}
                            onClick={() => handleSelectAnswer(qIndex, oIdx, q.ans)}
                            className={`w-full text-left p-2.5 rounded-xl border text-xs font-semibold active:scale-[0.99] transition-all flex items-center ${btnStyle}`}
                          >
                            <span className="font-mono font-bold mr-2 opacity-70">
                              {String.fromCharCode(65 + oIdx)})
                            </span>
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    {revealedExplanations[qIndex] && (
                      <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 font-bengali text-emerald-900 dark:text-emerald-200 text-xs leading-relaxed animate-in fade-in">
                        <strong>ব্যাখ্যা:</strong> {q.exp}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Section 11 & Essay Writing Anchor */}
        {activeWord.essayQuote && (
          <div className="bg-gradient-to-br from-indigo-900 to-purple-950 text-white rounded-3xl p-5 shadow-xl space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                <PenTool className="w-4 h-4" /> Final Anchor for Advanced Writing & Essays
              </h3>
              <span className="text-[9px] bg-white/20 px-2 py-0.5 rounded-full font-mono">BCS Written</span>
            </div>
            <blockquote className="text-xs sm:text-sm font-semibold italic text-slate-100 leading-relaxed border-l-2 border-amber-400 pl-3">
              "{activeWord.essayQuote}"
            </blockquote>
            {activeWord.essayQuoteBn && (
              <p className="text-xs font-bengali text-indigo-200 pt-1 leading-relaxed">
                {activeWord.essayQuoteBn}
              </p>
            )}
          </div>
        )}

        {/* Section 16 & 17: Summary & Quick Revision */}
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3 text-xs">
          <h3 className="font-extrabold uppercase tracking-wider text-slate-400">
            16 & 17. Quick Revision & Top Takeaways
          </h3>
          {activeWord.quickRevision && (
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl space-y-1">
              <div><strong>Model Sentence:</strong> <em>"{activeWord.quickRevision.sentence}"</em></div>
              <div><strong>Top Collocation:</strong> <code className="text-emerald-600 dark:text-emerald-400">{activeWord.quickRevision.collocation}</code></div>
            </div>
          )}
          <div className="space-y-1.5 font-medium text-slate-700 dark:text-slate-200">
            {activeWord.finalSummary.map((pt, i) => (
              <div key={i} className="flex items-start gap-1.5">
                <span className="text-emerald-500 font-bold">&bull;</span>
                <span>{pt}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
