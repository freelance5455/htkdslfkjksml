import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  CloudRain,
  Delete,
  Flame,
  Grid3X3,
  Heart,
  Layers,
  Lightbulb,
  Pause,
  Play,
  Rocket,
  RotateCcw,
  Sparkles,
  Timer,
  Trophy,
  Volume2,
  XCircle,
  Zap,
} from 'lucide-react';
import { BANDS } from '../data/constants';
import type {
  ArcadeGameModeId,
  CefrBand,
  PersistedSettings,
  VocabEntry,
  VocabStore,
} from '../types';
import {
  buildBlitzQuestion,
  buildMemoryDeck,
  computeWordRainSpeed,
  evaluateRocketState,
  evaluateWordleGuess,
  getBlitzMultiplier,
  getFilteredBandWords,
  mergeWordleKeyStates,
  pickDailyWordleWord,
  pickRandomWordleWord,
  pickRocketHintLetter,
  pickRocketWord,
  type MemoryCardItem,
  type WordleTileState,
} from '../utils/arcadeGamesLogic';
import { todayStr } from '../utils/storage';

interface ArcadeGamesArenaProps {
  mode: ArcadeGameModeId;
  store: VocabStore;
  settings: PersistedSettings;
  onSpeak: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xpDelta: number) => void;
  onMarkMistake: (wordId: number) => void;
  onMarkMastered: (wordId: number) => void;
  onUpdateSettings: (patch: Partial<PersistedSettings>) => void;
  onOpenWordDetail: (wordId: number) => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onExit: () => void;
}

const QWERTY_ROWS = [
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
  ['enter', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'back'],
];

const ALPHABET = 'abcdefghijklmnopqrstuvwxyz'.split('');

const BAND_FILTER_OPTIONS: Array<{ id: CefrBand | 'ALL'; label: string }> = [
  { id: 'ALL', label: 'الكل' },
  ...BANDS.map((b) => ({ id: b, label: b })),
];

function BandSelectorBar({
  band,
  onChange,
}: {
  band: CefrBand | 'ALL';
  onChange: (b: CefrBand | 'ALL') => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="اختيار المستوى">
      {BAND_FILTER_OPTIONS.map((opt) => (
        <button
          key={opt.id}
          type="button"
          onClick={() => onChange(opt.id)}
          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition-colors ${
            band === opt.id
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

/* ============================================================================
 * 1) TMN WORDLE ("تحدي الكلمة — Wordle")
 * ============================================================================ */
function WordleGame({
  store,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkMastered,
  onUpdateSettings,
  onOpenWordDetail,
  onHudChange,
  onExit,
}: Omit<ArcadeGamesArenaProps, 'mode' | 'onMarkMistake'>) {
  const today = todayStr();
  const [subMode, setSubMode] = useState<'daily' | 'endless'>('daily');
  const [band, setBand] = useState<CefrBand | 'ALL'>('ALL');
  const [seed, setSeed] = useState(() => Date.now());
  const [target, setTarget] = useState<VocabEntry>(() => pickDailyWordleWord(store, today));
  const [guesses, setGuesses] = useState<Array<{ word: string; states: WordleTileState[] }>>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [keyStates, setKeyStates] = useState<Record<string, WordleTileState>>({});
  const [showHint, setShowHint] = useState(false);
  const [shakeRow, setShakeRow] = useState(false);
  const [status, setStatus] = useState<'playing' | 'won' | 'lost'>('playing');

  const startRound = useCallback(
    (nextSubMode: 'daily' | 'endless', nextBand: CefrBand | 'ALL', nextSeed: number) => {
      const nextTarget =
        nextSubMode === 'daily'
          ? pickDailyWordleWord(store, today)
          : pickRandomWordleWord(store, nextBand, nextSeed, target.id);
      setTarget(nextTarget);
      setGuesses([]);
      setCurrentInput('');
      setKeyStates({});
      setShowHint(false);
      setStatus('playing');
    },
    [store, today, target.id]
  );

  useEffect(() => {
    onHudChange({
      current: Math.min(6, guesses.length + (status === 'playing' ? 1 : 0)),
      total: 6,
      correct: status === 'won' ? 1 : 0,
      wrong: status === 'lost' ? 1 : 0,
    });
  }, [guesses.length, status, onHudChange]);

  const handleSubmitGuess = useCallback(() => {
    if (status !== 'playing') return;
    if (currentInput.length !== 5) {
      onSfx('err');
      setShakeRow(true);
      window.setTimeout(() => setShakeRow(false), 320);
      return;
    }

    const states = evaluateWordleGuess(currentInput, target.en);
    const nextGuesses = [...guesses, { word: currentInput, states }];
    const nextKeys = mergeWordleKeyStates(keyStates, currentInput, states);
    setGuesses(nextGuesses);
    setKeyStates(nextKeys);
    setCurrentInput('');

    const won = states.every((s) => s === 'correct');
    if (won) {
      setStatus('won');
      onSfx('win');
      const bonusXp = Math.max(20, 65 - nextGuesses.length * 7);
      onEarnXp(bonusXp);
      if (target.id >= 0) onMarkMastered(target.id);
      onSpeak(target.en);
      if (subMode === 'daily') {
        onUpdateSettings({
          wordleDailyDate: today,
          wordleDailyStatus: 'won',
          wordleDailyGuesses: nextGuesses.length,
        });
      }
    } else if (nextGuesses.length >= 6) {
      setStatus('lost');
      onSfx('err');
      onSpeak(target.en);
      if (subMode === 'daily') {
        onUpdateSettings({
          wordleDailyDate: today,
          wordleDailyStatus: 'lost',
          wordleDailyGuesses: 6,
        });
      }
    } else {
      onSfx('tap');
    }
  }, [
    status,
    currentInput,
    target,
    guesses,
    keyStates,
    subMode,
    today,
    onSfx,
    onEarnXp,
    onMarkMastered,
    onSpeak,
    onUpdateSettings,
  ]);

  const handleKeyPress = useCallback(
    (key: string) => {
      if (status !== 'playing') return;
      if (key === 'enter') {
        handleSubmitGuess();
      } else if (key === 'back') {
        setCurrentInput((prev) => prev.slice(0, -1));
      } else if (/^[a-z]$/.test(key)) {
        setCurrentInput((prev) => (prev.length < 5 ? prev + key : prev));
      }
    },
    [status, handleSubmitGuess]
  );

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        handleKeyPress('enter');
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleKeyPress('back');
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        handleKeyPress(e.key.toLowerCase());
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleKeyPress]);

  const tileColorClass = (state: WordleTileState, hasChar: boolean) => {
    if (state === 'correct') return 'border-emerald-500 bg-emerald-600 text-white';
    if (state === 'present') return 'border-amber-500 bg-amber-500 text-slate-950';
    if (state === 'absent')
      return 'border-slate-400 bg-slate-500 text-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300';
    return hasChar
      ? 'border-indigo-400 bg-white text-slate-900 dark:border-indigo-400/70 dark:bg-[#151f35] dark:text-white animate-tile-pop'
      : 'border-slate-200 bg-slate-50/70 text-slate-900 dark:border-slate-700/70 dark:bg-[#0d1424] dark:text-white';
  };

  const keyColorClass = (state?: WordleTileState) => {
    if (state === 'correct') return 'bg-emerald-600 text-white border-emerald-500';
    if (state === 'present') return 'bg-amber-500 text-slate-950 border-amber-400';
    if (state === 'absent')
      return 'bg-slate-300/80 text-slate-600 border-slate-300 dark:bg-slate-800/70 dark:text-slate-500 dark:border-slate-800';
    return 'bg-white text-slate-800 border-slate-200 hover:bg-slate-100 dark:bg-[#162036] dark:text-slate-100 dark:border-slate-700/80 dark:hover:bg-slate-700';
  };

  return (
    <div data-testid="arcade-wordle" className="mx-auto max-w-2xl space-y-5">
      {/* Mode Switch & Controls */}
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-1.5 rounded-xl bg-slate-100 p-1 dark:bg-slate-900/70">
          <button
            type="button"
            data-testid="wordle-mode-daily"
            onClick={() => {
              setSubMode('daily');
              startRound('daily', band, Date.now());
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors ${
              subMode === 'daily'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
            }`}
          >
            كلمة اليوم
          </button>
          <button
            type="button"
            data-testid="wordle-mode-endless"
            onClick={() => {
              setSubMode('endless');
              const s = Date.now();
              setSeed(s);
              startRound('endless', band, s);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors ${
              subMode === 'endless'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
            }`}
          >
            لعب مفتوح
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            data-testid="wordle-hint-btn"
            onClick={() => {
              setShowHint(true);
              onSfx('tap');
            }}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/10 px-3 text-xs font-bold text-amber-700 hover:bg-amber-500/20 dark:text-amber-300"
          >
            <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" />
            <span>تلميح المعنى العربي</span>
          </button>
          <button
            type="button"
            onClick={() => onSpeak(target.en)}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <Volume2 className="h-3.5 w-3.5 text-indigo-500" aria-hidden="true" />
            <span>استمع للنطق</span>
          </button>
        </div>
      </div>

      {subMode === 'endless' && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-1">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
            مستوى الكلمات:
          </span>
          <BandSelectorBar
            band={band}
            onChange={(b) => {
              setBand(b);
              const s = Date.now();
              setSeed(s);
              startRound('endless', b, s);
            }}
          />
        </div>
      )}

      {showHint && (
        <div
          data-testid="wordle-hint-box"
          className="tmn-card flex items-center justify-between gap-3 rounded-2xl px-4 py-3 text-sm"
        >
          <div>
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
              المعنى العربي ({target.band}):{' '}
            </span>
            <span className="font-extrabold text-slate-900 dark:text-white">{target.ar}</span>
          </div>
          <span className="font-code text-xs text-slate-400">5 أحرف</span>
        </div>
      )}

      {/* 6 x 5 Wordle Tile Grid */}
      <div className="tmn-card rounded-3xl p-3.5 sm:p-4">
        <div
          dir="ltr"
          data-testid="wordle-grid"
          className="mx-auto grid max-w-[268px] grid-rows-6 gap-1.5"
        >
          {Array.from({ length: 6 }).map((_, rowIdx) => {
            const submitted = guesses[rowIdx];
            const isCurrent = rowIdx === guesses.length && status === 'playing';
            return (
              <div
                key={rowIdx}
                className={`grid grid-cols-5 gap-1.5 ${
                  isCurrent && shakeRow ? 'animate-match-shake' : ''
                }`}
              >
                {Array.from({ length: 5 }).map((__, colIdx) => {
                  const ch = submitted
                    ? submitted.word[colIdx] || ''
                    : isCurrent
                      ? currentInput[colIdx] || ''
                      : '';
                  const state: WordleTileState = submitted ? submitted.states[colIdx] : 'empty';
                  return (
                    <div
                      key={colIdx}
                      className={`flex aspect-square items-center justify-center rounded-xl border-2 font-en text-xl font-extrabold uppercase transition-colors ${tileColorClass(
                        state,
                        Boolean(ch)
                      )}`}
                    >
                      {ch}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>

        {/* End of Round Summary Card */}
        {status !== 'playing' && (
          <div
            data-testid="wordle-result-card"
            className="mt-5 rounded-2xl border border-slate-200 bg-slate-50/90 p-4 text-center dark:border-slate-700/80 dark:bg-slate-900/70"
          >
            <div className="flex items-center justify-center gap-2 text-base font-extrabold">
              {status === 'won' ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                  <Trophy className="h-5 w-5" aria-hidden="true" />
                  أحسنت! اكتشفت الكلمة في {guesses.length} محاولات
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-rose-600 dark:text-rose-400">
                  <XCircle className="h-5 w-5" aria-hidden="true" />
                  انتهت المحاولات — الكلمة كانت:
                </span>
              )}
            </div>
            <div className="mt-2 font-en text-2xl font-extrabold tracking-wide text-slate-900 dark:text-white" dir="ltr">
              {target.en}
            </div>
            <div className="mt-1 text-sm font-bold text-indigo-600 dark:text-indigo-300">
              {target.ar} · {target.band}
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => onSpeak(target.en)}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              >
                <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                <span>استمع للنطق</span>
              </button>
              {target.id >= 0 && (
                <button
                  type="button"
                  onClick={() => onOpenWordDetail(target.id)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-indigo-400/40 bg-indigo-500/10 px-3.5 text-xs font-bold text-indigo-700 hover:bg-indigo-500/20 dark:text-indigo-300"
                >
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span>فتح صفحة الكلمة</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setSubMode('endless');
                  const s = seed + 1;
                  setSeed(s);
                  startRound('endless', band, s);
                }}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-4 text-xs font-extrabold text-white hover:bg-indigo-700"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>كلمة جديدة</span>
              </button>
              <button
                type="button"
                onClick={onExit}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Interactive QWERTY Keyboard */}
      <div dir="ltr" className="tmn-card space-y-1.5 rounded-2xl p-2.5 sm:p-3.5">
        {QWERTY_ROWS.map((row, rIdx) => (
          <div key={rIdx} className="flex justify-center gap-1 sm:gap-1.5">
            {row.map((k) => {
              const isAction = k === 'enter' || k === 'back';
              return (
                <button
                  key={k}
                  type="button"
                  data-testid={`wordle-key-${k}`}
                  onClick={() => handleKeyPress(k)}
                  disabled={status !== 'playing'}
                  aria-label={k === 'enter' ? 'إرسال' : k === 'back' ? 'حذف' : k.toUpperCase()}
                  className={`flex h-11 items-center justify-center rounded-lg border font-en text-xs font-extrabold uppercase transition-colors disabled:opacity-50 sm:h-12 sm:text-sm ${
                    isAction ? 'px-2.5 sm:px-3.5' : 'min-w-[28px] flex-1 max-w-[44px]'
                  } ${keyColorClass(keyStates[k])}`}
                >
                  {k === 'back' ? (
                    <Delete className="h-4 w-4" aria-hidden="true" />
                  ) : k === 'enter' ? (
                    '↵'
                  ) : (
                    k
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {settings.wordleDailyDate === today && subMode === 'daily' && status === 'playing' && (
        <p className="text-center text-xs text-slate-500 dark:text-slate-400">
          لقد أكملت كلمة اليوم مسبقاً ({settings.wordleDailyStatus === 'won' ? 'فوز' : 'انتهت المحاولات'}) — يمكنك اللعب مجدداً أو التبديل إلى «لعب مفتوح».
        </p>
      )}
    </div>
  );
}

/* ============================================================================
 * 2) 60-SECOND SPEED BLITZ ("سباق 60 ثانية")
 * ============================================================================ */
function SpeedBlitzGame({
  store,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkMistake,
  onUpdateSettings,
  onHudChange,
  onExit,
}: Omit<ArcadeGamesArenaProps, 'mode' | 'onMarkMastered' | 'onOpenWordDetail'>) {
  const [band, setBand] = useState<CefrBand | 'ALL'>('ALL');
  const [phase, setPhase] = useState<'playing' | 'over'>('playing');
  const [timeLeft, setTimeLeft] = useState(60);
  const [hearts, setHearts] = useState(3);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [qNum, setQNum] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [missedWords, setMissedWords] = useState<VocabEntry[]>([]);
  const [addedMistakeIds, setAddedMistakeIds] = useState<number[]>([]);
  const [flashState, setFlashState] = useState<'none' | 'ok' | 'err' | 'bonus'>('none');
  const recentIdsRef = useRef<Set<number>>(new Set());
  const [question, setQuestion] = useState(() =>
    buildBlitzQuestion(store, 'ALL', Date.now(), new Set(), 0)
  );

  const bestScore = Math.max(settings.bestBlitzScore || 0, score);
  const multiplier = getBlitzMultiplier(streak);

  const loadNextQuestion = useCallback(
    (nextNum: number, activeBand: CefrBand | 'ALL') => {
      const q = buildBlitzQuestion(
        store,
        activeBand,
        Date.now() + nextNum * 131,
        recentIdsRef.current,
        nextNum
      );
      recentIdsRef.current.add(q.target.id);
      if (recentIdsRef.current.size > 40) recentIdsRef.current.clear();
      setQuestion(q);
    },
    [store]
  );

  const finishGame = useCallback(
    (finalScore: number) => {
      setPhase('over');
      onSfx('win');
      const earnedXp = Math.max(10, Math.min(80, Math.round(finalScore / 15)));
      onEarnXp(earnedXp);
      if (finalScore > (settings.bestBlitzScore || 0)) {
        onUpdateSettings({ bestBlitzScore: finalScore });
      }
    },
    [onSfx, onEarnXp, settings.bestBlitzScore, onUpdateSettings]
  );

  const resetGame = useCallback(
    (activeBand: CefrBand | 'ALL' = band) => {
      recentIdsRef.current.clear();
      setPhase('playing');
      setTimeLeft(60);
      setHearts(3);
      setScore(0);
      setStreak(0);
      setQNum(0);
      setCorrectCount(0);
      setWrongCount(0);
      setMissedWords([]);
      setAddedMistakeIds([]);
      setFlashState('none');
      loadNextQuestion(0, activeBand);
    },
    [band, loadNextQuestion]
  );

  useEffect(() => {
    onHudChange({
      current: qNum + 1,
      total: Math.max(qNum + 1, 20),
      correct: correctCount,
      wrong: wrongCount,
    });
  }, [qNum, correctCount, wrongCount, onHudChange]);

  // Countdown tick
  useEffect(() => {
    if (phase !== 'playing') return;
    const id = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(id);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'playing' && timeLeft === 0) {
      finishGame(score);
    }
  }, [phase, timeLeft, score, finishGame]);

  const handleOptionPick = (isCorrect: boolean) => {
    if (phase !== 'playing') return;
    if (isCorrect) {
      const nextStreak = streak + 1;
      const mult = getBlitzMultiplier(nextStreak);
      const nextScore = score + 10 * mult;
      setStreak(nextStreak);
      setScore(nextScore);
      setCorrectCount((c) => c + 1);
      if (nextStreak % 5 === 0) {
        setTimeLeft((t) => Math.min(60, t + 1));
        setFlashState('bonus');
        onSfx('win');
      } else {
        setFlashState('ok');
        onSfx('ok');
      }
      window.setTimeout(() => setFlashState('none'), 220);
      const nextNum = qNum + 1;
      setQNum(nextNum);
      loadNextQuestion(nextNum, band);
    } else {
      const nextHearts = hearts - 1;
      setHearts(nextHearts);
      setStreak(0);
      setWrongCount((w) => w + 1);
      setMissedWords((prev) =>
        prev.some((w) => w.id === question.target.id) ? prev : [...prev, question.target]
      );
      setFlashState('err');
      onSfx('err');
      window.setTimeout(() => setFlashState('none'), 260);
      if (nextHearts <= 0) {
        finishGame(score);
      } else {
        const nextNum = qNum + 1;
        setQNum(nextNum);
        loadNextQuestion(nextNum, band);
      }
    }
  };

  return (
    <div data-testid="arcade-speed-blitz" className="mx-auto max-w-2xl space-y-5">
      {/* Live Arcade Telemetry Strip */}
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 font-code text-lg font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
            <Timer className="h-5 w-5" aria-hidden="true" />
            <span>{timeLeft}s</span>
          </div>
          <div className="flex items-center gap-1" aria-label={`الأرواح المتبقية ${hearts}`}>
            {[0, 1, 2].map((i) => (
              <Heart
                key={i}
                className={`h-5 w-5 transition-transform ${
                  i < hearts
                    ? 'fill-rose-500 text-rose-500'
                    : 'text-slate-300 dark:text-slate-700'
                }`}
                aria-hidden="true"
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-extrabold tabular-nums">
          <span
            className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 font-code ${
              multiplier > 1
                ? 'bg-amber-500/15 text-amber-600 dark:text-amber-300'
                : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
            }`}
          >
            <Flame className="h-3.5 w-3.5" aria-hidden="true" />
            x{multiplier}
          </span>
          <span className="font-code text-base text-slate-900 dark:text-white">{score}</span>
          <span className="text-slate-400">
            الأعلى: <span className="font-code text-emerald-500">{bestScore}</span>
          </span>
        </div>
      </div>

      {phase === 'playing' ? (
        <>
          <div className="flex flex-wrap items-center justify-between gap-2 px-1">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              {flashState === 'bonus'
                ? '+1 ثانية مكافأة سلسلة 5 إجابات!'
                : 'كل 5 إجابات متتالية تمنحك +1 ثانية إضافية'}
            </span>
            <BandSelectorBar
              band={band}
              onChange={(b) => {
                setBand(b);
                resetGame(b);
              }}
            />
          </div>

          <div
            className={`tmn-card rounded-3xl p-6 text-center transition-colors sm:p-8 ${
              flashState === 'err'
                ? 'border-rose-500/60'
                : flashState === 'ok' || flashState === 'bonus'
                  ? 'border-emerald-500/60'
                  : ''
            }`}
          >
            <div className="text-xs font-bold text-slate-400">
              {question.direction === 'en2ar' ? 'اختر المعنى العربي الصحيح' : 'اختر الكلمة الإنجليزية الصحيحة'}{' '}
              · {question.target.band}
            </div>
            <div
              dir={question.direction === 'en2ar' ? 'ltr' : 'rtl'}
              className={`mt-3 text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl ${
                question.direction === 'en2ar' ? 'font-en' : ''
              }`}
            >
              {question.prompt}
            </div>
            <button
              type="button"
              onClick={() => onSpeak(question.target.en)}
              aria-label="استمع للنطق"
              className="mt-3 inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-700 dark:text-slate-300"
            >
              <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>نطق</span>
            </button>

            <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {question.options.map((opt, idx) => (
                <button
                  key={`${question.target.id}-${opt.id}-${idx}`}
                  type="button"
                  data-testid={`blitz-opt-${opt.isCorrect ? 'correct' : idx}`}
                  dir={question.direction === 'ar2en' ? 'ltr' : 'rtl'}
                  onClick={() => handleOptionPick(opt.isCorrect)}
                  className={`min-h-[56px] rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3 text-base font-bold text-slate-900 transition-colors hover:border-indigo-500 hover:bg-indigo-50 dark:border-slate-700/80 dark:bg-[#0d1424] dark:text-slate-100 dark:hover:border-indigo-400 dark:hover:bg-indigo-500/15 ${
                    question.direction === 'ar2en' ? 'font-en' : ''
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div data-testid="blitz-summary" className="tmn-card rounded-3xl p-6 text-center sm:p-8">
          <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
          <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
            انتهى سباق 60 ثانية!
          </h2>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
              <div className="text-xs font-bold text-slate-400">النتيجة</div>
              <div className="mt-1 font-code text-2xl font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
                {score}
              </div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
              <div className="text-xs font-bold text-slate-400">أعلى رقم</div>
              <div className="mt-1 font-code text-2xl font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                {bestScore}
              </div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
              <div className="text-xs font-bold text-slate-400">الدقة</div>
              <div className="mt-1 font-code text-2xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                {Math.round((correctCount / Math.max(1, correctCount + wrongCount)) * 100)}%
              </div>
            </div>
          </div>

          {missedWords.length > 0 && (
            <div className="mt-6 text-start">
              <h3 className="mb-2 text-xs font-extrabold text-slate-500 dark:text-slate-400">
                الكلمات التي أخطأت فيها ({missedWords.length}):
              </h3>
              <div className="space-y-2">
                {missedWords.map((w) => {
                  const saved = addedMistakeIds.includes(w.id);
                  return (
                    <div
                      key={w.id}
                      className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm dark:border-slate-800"
                    >
                      <div>
                        <span className="font-en font-bold text-slate-900 dark:text-white" dir="ltr">
                          {w.en}
                        </span>
                        <span className="mx-2 text-slate-400">—</span>
                        <span className="text-slate-600 dark:text-slate-300">{w.ar}</span>
                      </div>
                      <button
                        type="button"
                        disabled={saved}
                        onClick={() => {
                          onMarkMistake(w.id);
                          setAddedMistakeIds((prev) => [...prev, w.id]);
                          onSfx('tap');
                        }}
                        className="shrink-0 rounded-lg border border-rose-400/40 bg-rose-500/10 px-2.5 py-1 text-xs font-bold text-rose-600 hover:bg-rose-500/20 disabled:opacity-50 dark:text-rose-300"
                      >
                        {saved ? 'تمت الإضافة ✓' : 'أضف لبنك الأخطاء'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => resetGame()}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>العب مجدداً</span>
            </button>
            <button
              type="button"
              onClick={onExit}
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>العودة للألعاب</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================================================================
 * 3) MEMORY FLIP CARDS ("بطاقات الذاكرة")
 * ============================================================================ */
function MemoryFlipGame({
  store,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkMastered,
  onUpdateSettings,
  onHudChange,
  onExit,
}: Omit<ArcadeGamesArenaProps, 'mode' | 'onMarkMistake' | 'onOpenWordDetail'>) {
  const [band, setBand] = useState<CefrBand | 'ALL'>('ALL');
  const [pairCount, setPairCount] = useState<6 | 8>(6);
  const [seed, setSeed] = useState(() => Date.now());
  const [cards, setCards] = useState<MemoryCardItem[]>(() =>
    buildMemoryDeck(store, 'ALL', 6, Date.now())
  );
  const [flippedUids, setFlippedUids] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [locked, setLocked] = useState(false);

  const matchedPairs = useMemo(() => cards.filter((c) => c.matched).length / 2, [cards]);
  const isComplete = cards.length > 0 && matchedPairs === pairCount;

  const startNewDeck = useCallback(
    (nextBand: CefrBand | 'ALL', nextPairs: 6 | 8, nextSeed: number) => {
      setCards(buildMemoryDeck(store, nextBand, nextPairs, nextSeed));
      setFlippedUids([]);
      setMoves(0);
      setElapsedSec(0);
      setLocked(false);
    },
    [store]
  );

  useEffect(() => {
    onHudChange({
      current: matchedPairs,
      total: pairCount,
      correct: matchedPairs,
      wrong: Math.max(0, moves - matchedPairs),
    });
  }, [matchedPairs, pairCount, moves, onHudChange]);

  useEffect(() => {
    if (isComplete) return;
    const id = window.setInterval(() => setElapsedSec((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [isComplete, seed]);

  const handleFlip = (card: MemoryCardItem) => {
    if (locked || card.matched || flippedUids.includes(card.uid)) return;
    if (card.side === 'en') onSpeak(card.text);
    onSfx('tap');

    const nextFlipped = [...flippedUids, card.uid];
    setFlippedUids(nextFlipped);

    if (nextFlipped.length === 2) {
      setLocked(true);
      const nextMoves = moves + 1;
      setMoves(nextMoves);
      const first = cards.find((c) => c.uid === nextFlipped[0]);
      const second = card;

      if (first && first.pairId === second.pairId && first.side !== second.side) {
        onSfx('ok');
        const updated = cards.map((c) =>
          c.pairId === first.pairId ? { ...c, matched: true } : c
        );
        setCards(updated);
        setFlippedUids([]);
        setLocked(false);
        if (first.wordId >= 0) onMarkMastered(first.wordId);

        if (updated.every((c) => c.matched)) {
          onSfx('win');
          onEarnXp(pairCount === 8 ? 45 : 30);
          if (!settings.bestMemoryMoves || nextMoves < settings.bestMemoryMoves) {
            onUpdateSettings({ bestMemoryMoves: nextMoves });
          }
        }
      } else {
        window.setTimeout(() => {
          setFlippedUids([]);
          setLocked(false);
        }, 720);
      }
    }
  };

  return (
    <div data-testid="arcade-memory-flip" className="mx-auto max-w-3xl space-y-5">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-1.5 rounded-xl bg-slate-100 p-1 dark:bg-slate-900/70">
          <button
            type="button"
            onClick={() => {
              setPairCount(6);
              const s = Date.now();
              setSeed(s);
              startNewDeck(band, 6, s);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors ${
              pairCount === 6
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            12 بطاقة (6 أزواج)
          </button>
          <button
            type="button"
            onClick={() => {
              setPairCount(8);
              const s = Date.now();
              setSeed(s);
              startNewDeck(band, 8, s);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors ${
              pairCount === 8
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            16 بطاقة (8 أزواج)
          </button>
        </div>

        <div className="flex items-center gap-4 text-xs font-bold tabular-nums text-slate-600 dark:text-slate-300">
          <span>
            الحركات: <strong className="font-code text-slate-900 dark:text-white">{moves}</strong>
          </span>
          <span>
            الوقت: <strong className="font-code text-indigo-500">{elapsedSec}s</strong>
          </span>
          {settings.bestMemoryMoves ? (
            <span>
              الأفضل: <strong className="font-code text-emerald-500">{settings.bestMemoryMoves}</strong>
            </span>
          ) : null}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 px-1">
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
          اقلب البطاقات لمطابقة كل كلمة إنجليزية مع معناها العربي
        </span>
        <BandSelectorBar
          band={band}
          onChange={(b) => {
            setBand(b);
            const s = Date.now();
            setSeed(s);
            startNewDeck(b, pairCount, s);
          }}
        />
      </div>

      <div
        className={`grid gap-2.5 sm:gap-3 ${
          pairCount === 8 ? 'grid-cols-4' : 'grid-cols-3 sm:grid-cols-4'
        }`}
      >
        {cards.map((card, idx) => {
          const isOpen = card.matched || flippedUids.includes(card.uid);
          return (
            <button
              key={card.uid}
              type="button"
              data-testid={`memory-card-${idx}`}
              onClick={() => handleFlip(card)}
              disabled={card.matched}
              className="tmn-perspective h-24 w-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 sm:h-28"
            >
              <div className={`tmn-flip-inner ${isOpen ? 'is-flipped' : ''}`}>
                {/* Card Front (Face-down) */}
                <div className="tmn-flip-face flex items-center justify-center rounded-2xl border border-slate-200 bg-white shadow-xs hover:border-indigo-400 dark:border-slate-700/80 dark:bg-[#11192b]">
                  <Layers className="h-6 w-6 text-indigo-500/70" aria-hidden="true" />
                </div>

                {/* Card Back (Revealed) */}
                <div
                  className={`tmn-flip-face tmn-flip-back flex flex-col items-center justify-center rounded-2xl border px-2 text-center ${
                    card.matched
                      ? 'border-emerald-500/60 bg-emerald-500/12 text-emerald-700 dark:text-emerald-300'
                      : card.side === 'en'
                        ? 'border-indigo-500/60 bg-indigo-500/12 text-indigo-700 dark:text-indigo-200'
                        : 'border-amber-500/60 bg-amber-500/12 text-amber-800 dark:text-amber-200'
                  }`}
                >
                  <span className="text-[10px] font-bold opacity-70">
                    {card.side === 'en' ? 'EN' : 'AR'}
                  </span>
                  <span
                    dir={card.side === 'en' ? 'ltr' : 'rtl'}
                    className={`mt-1 line-clamp-2 text-sm font-extrabold sm:text-base ${
                      card.side === 'en' ? 'font-en' : ''
                    }`}
                  >
                    {card.text}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {isComplete && (
        <div
          data-testid="memory-complete-card"
          className="tmn-card rounded-3xl p-6 text-center"
        >
          <Trophy className="mx-auto h-9 w-9 text-amber-500" aria-hidden="true" />
          <h3 className="mt-2 text-xl font-extrabold text-slate-900 dark:text-white">
            أحسنت! طابقت جميع البطاقات بنجاح
          </h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            أنهيت الجولة في {moves} حركة خلال {elapsedSec} ثانية (+{pairCount === 8 ? 45 : 30} XP)
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                const s = Date.now();
                setSeed(s);
                startNewDeck(band, pairCount, s);
              }}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>المجموعة التالية</span>
            </button>
            <button
              type="button"
              onClick={onExit}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-4 text-xs font-bold text-slate-600 dark:border-slate-700 dark:text-slate-300"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>خروج</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================================================================
 * 4) WORD RAIN ARCADE ("مطر الكلمات")
 * ============================================================================ */
interface RainDrop {
  uid: number;
  word: VocabEntry;
  xPct: number;
  yPct: number;
}

function WordRainGame({
  store,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onUpdateSettings,
  onHudChange,
  onExit,
}: Omit<ArcadeGamesArenaProps, 'mode' | 'onMarkMistake' | 'onMarkMastered' | 'onOpenWordDetail'>) {
  const [band, setBand] = useState<CefrBand | 'ALL'>('ALL');
  const [phase, setPhase] = useState<'playing' | 'paused' | 'over'>('playing');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [hearts, setHearts] = useState(3);
  const [drops, setDrops] = useState<RainDrop[]>([]);
  const [burstText, setBurstText] = useState<string | null>(null);

  const pool = useMemo(() => getFilteredBandWords(store, band), [store, band]);
  const dropsRef = useRef<RainDrop[]>([]);
  const scoreRef = useRef(0);
  const heartsRef = useRef(3);
  const nextUidRef = useRef(1);
  const lastSpawnRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef<number>(0);

  const spawnDrop = useCallback(() => {
    if (pool.length === 0) return;
    const activeIds = new Set(dropsRef.current.map((d) => d.word.id));
    let pick = pool[Math.floor(Math.random() * pool.length)];
    for (let i = 0; i < 15; i++) {
      if (!activeIds.has(pick.id)) break;
      pick = pool[Math.floor(Math.random() * pool.length)];
    }
    const lanes = [14, 38, 62, 82];
    const xPct = lanes[nextUidRef.current % lanes.length] + (Math.random() * 6 - 3);
    const drop: RainDrop = {
      uid: nextUidRef.current++,
      word: pick,
      xPct: Math.max(10, Math.min(86, xPct)),
      yPct: 4,
    };
    dropsRef.current = [...dropsRef.current, drop];
    setDrops(dropsRef.current);
  }, [pool]);

  const resetGame = useCallback(() => {
    dropsRef.current = [];
    scoreRef.current = 0;
    heartsRef.current = 3;
    lastSpawnRef.current = 0;
    lastTsRef.current = 0;
    setDrops([]);
    setScore(0);
    setCombo(0);
    setHearts(3);
    setPhase('playing');
    spawnDrop();
  }, [spawnDrop]);

  useEffect(() => {
    if (dropsRef.current.length === 0 && phase === 'playing') {
      spawnDrop();
    }
  }, [spawnDrop, phase]);

  useEffect(() => {
    onHudChange({
      current: score,
      total: Math.max(100, settings.bestWordRainScore || 100),
      correct: Math.floor(score / 10),
      wrong: 3 - hearts,
    });
  }, [score, hearts, settings.bestWordRainScore, onHudChange]);

  // Smooth clamped requestAnimationFrame loop (zero React 60Hz jitter via ~25fps throttled commit)
  useEffect(() => {
    if (phase !== 'playing') return;
    let accumCommit = 0;

    const tick = (ts: number) => {
      if (!lastTsRef.current) lastTsRef.current = ts;
      const dt = Math.min(0.05, Math.max(0.001, (ts - lastTsRef.current) / 1000));
      lastTsRef.current = ts;
      accumCommit += dt;

      const speed = computeWordRainSpeed(scoreRef.current);
      let missedAny = false;
      const surviving: RainDrop[] = [];
      for (const d of dropsRef.current) {
        const nextY = d.yPct + speed * dt;
        if (nextY >= 90) {
          missedAny = true;
        } else {
          surviving.push({ ...d, yPct: nextY });
        }
      }
      dropsRef.current = surviving;

      if (missedAny) {
        heartsRef.current = Math.max(0, heartsRef.current - 1);
        setHearts(heartsRef.current);
        setCombo(0);
        onSfx('err');
        if (heartsRef.current <= 0) {
          setPhase('over');
          setDrops([]);
          const finalScore = scoreRef.current;
          onEarnXp(Math.max(10, Math.min(70, Math.round(finalScore / 12))));
          if (finalScore > (settings.bestWordRainScore || 0)) {
            onUpdateSettings({ bestWordRainScore: finalScore });
          }
          return;
        }
      }

      const spawnIntervalMs = Math.max(1650, 3200 - Math.floor(scoreRef.current / 30) * 180);
      if (
        dropsRef.current.length === 0 ||
        (dropsRef.current.length < 3 && ts - lastSpawnRef.current >= spawnIntervalMs)
      ) {
        lastSpawnRef.current = ts;
        spawnDrop();
      }

      if (accumCommit >= 0.04 || missedAny) {
        accumCommit = 0;
        setDrops(dropsRef.current.slice());
      }

      rafRef.current = window.requestAnimationFrame(tick);
    };

    rafRef.current = window.requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) window.cancelAnimationFrame(rafRef.current);
      lastTsRef.current = 0;
    };
  }, [phase, spawnDrop, onSfx, onEarnXp, settings.bestWordRainScore, onUpdateSettings]);

  // Lowest falling word determines the active target among the 4 Arabic buttons
  const lowestDrop = useMemo(() => {
    if (drops.length === 0) return null;
    return drops.reduce((best, d) => (d.yPct > best.yPct ? d : best), drops[0]);
  }, [drops]);

  const answerButtons = useMemo(() => {
    if (!lowestDrop) return [];
    const correctWord = lowestDrop.word;
    const opts: Array<{ wordId: number; ar: string; isCorrect: boolean }> = [
      { wordId: correctWord.id, ar: correctWord.ar, isCorrect: true },
    ];
    const usedAr = new Set([correctWord.ar.trim().toLowerCase()]);
    // Prefer other active drops first for natural arcade tension, then pool distractors
    for (const d of drops) {
      if (opts.length >= 4) break;
      const key = d.word.ar.trim().toLowerCase();
      if (d.word.id !== correctWord.id && !usedAr.has(key)) {
        usedAr.add(key);
        opts.push({ wordId: d.word.id, ar: d.word.ar, isCorrect: false });
      }
    }
    let guard = 0;
    while (opts.length < 4 && guard < 80 && pool.length > 0) {
      guard++;
      const cand = pool[(correctWord.id * 19 + guard * 37) % pool.length];
      const key = cand.ar.trim().toLowerCase();
      if (!usedAr.has(key)) {
        usedAr.add(key);
        opts.push({ wordId: cand.id, ar: cand.ar, isCorrect: false });
      }
    }
    // Stable deterministic order per lowest drop so buttons don't jitter every frame
    return opts.sort(
      (a, b) =>
        ((a.wordId * 17 + lowestDrop.uid * 7) % 31) -
        ((b.wordId * 17 + lowestDrop.uid * 7) % 31)
    );
  }, [lowestDrop?.uid, pool]);

  const handleAnswer = useCallback(
    (wordId: number) => {
      if (phase !== 'playing') return;
      // Destroy lowest matching drop
      const matching = dropsRef.current
        .filter((d) => d.word.id === wordId)
        .sort((a, b) => b.yPct - a.yPct);
      if (matching.length > 0) {
        const hit = matching[0];
        dropsRef.current = dropsRef.current.filter((d) => d.uid !== hit.uid);
        const nextCombo = combo + 1;
        const pts = 10 + Math.min(20, nextCombo * 2);
        scoreRef.current += pts;
        setScore(scoreRef.current);
        setCombo(nextCombo);
        setBurstText(`${hit.word.en} +${pts}`);
        onSpeak(hit.word.en);
        onSfx('ok');
        window.setTimeout(() => setBurstText(null), 420);
        if (dropsRef.current.length === 0) spawnDrop();
        else setDrops(dropsRef.current.slice());
      } else {
        setCombo(0);
        onSfx('err');
      }
    },
    [phase, combo, onSpeak, onSfx, spawnDrop]
  );

  // Keys 1-4 support
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (phase === 'over') return;
      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        setPhase((p) => (p === 'playing' ? 'paused' : 'playing'));
        return;
      }
      const idx = Number(e.key) - 1;
      if (idx >= 0 && idx < answerButtons.length) {
        handleAnswer(answerButtons[idx].wordId);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [phase, answerButtons, handleAnswer]);

  return (
    <div data-testid="arcade-word-rain" className="mx-auto max-w-2xl space-y-4">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1" aria-label={`الأرواح ${hearts}`}>
            {[0, 1, 2].map((i) => (
              <Heart
                key={i}
                className={`h-5 w-5 ${
                  i < hearts ? 'fill-rose-500 text-rose-500' : 'text-slate-300 dark:text-slate-700'
                }`}
                aria-hidden="true"
              />
            ))}
          </div>
          <span className="font-code text-base font-extrabold tabular-nums text-slate-900 dark:text-white">
            {score} نقطة
          </span>
          {combo >= 2 && (
            <span className="font-code text-xs font-extrabold text-amber-500">
              سلسلة x{combo}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            data-testid="word-rain-pause-btn"
            disabled={phase === 'over'}
            onClick={() => setPhase((p) => (p === 'playing' ? 'paused' : 'playing'))}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:border-indigo-400 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          >
            {phase === 'paused' ? (
              <>
                <Play className="h-3.5 w-3.5" aria-hidden="true" />
                <span>استئناف</span>
              </>
            ) : (
              <>
                <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                <span>إيقاف مؤقت</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 px-1">
        <span className="text-xs text-slate-500 dark:text-slate-400">
          اضغط الترجمة الصحيحة (أو أزرار 1–4) قبل وصول الكلمة للأسفل
        </span>
        <BandSelectorBar
          band={band}
          onChange={(b) => {
            setBand(b);
            resetGame();
          }}
        />
      </div>

      {/* Falling Arena */}
      <div
        data-testid="word-rain-arena"
        className="tmn-card relative h-[340px] w-full overflow-hidden rounded-3xl bg-slate-950/95 sm:h-[380px]"
      >
        {/* Subtle bottom danger threshold line */}
        <div className="pointer-events-none absolute inset-x-0 bottom-7 border-t border-dashed border-rose-500/40" />

        {burstText && (
          <div className="pointer-events-none absolute top-4 left-1/2 z-20 -translate-x-1/2 rounded-xl bg-emerald-500/20 px-3 py-1 font-en text-sm font-extrabold text-emerald-300">
            {burstText}
          </div>
        )}

        {drops.map((d) => {
          const isLowest = lowestDrop?.uid === d.uid;
          return (
            <div
              key={d.uid}
              dir="ltr"
              style={{
                left: `${d.xPct}%`,
                top: 0,
                transform: `translate(-50%, ${d.yPct * 3.2}px)`,
              }}
              className={`pointer-events-none absolute rounded-xl border px-3.5 py-2 font-en text-base font-extrabold shadow-sm will-change-transform ${
                isLowest
                  ? 'border-indigo-400 bg-indigo-600 text-white'
                  : 'border-slate-700 bg-[#152038] text-slate-200'
              }`}
            >
              {d.word.en}
            </div>
          );
        })}

        {phase === 'paused' && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/80 text-white">
            <Pause className="h-8 w-8 text-indigo-400" aria-hidden="true" />
            <div className="mt-2 text-lg font-extrabold">اللعبة متوقفة مؤقتاً</div>
            <button
              type="button"
              onClick={() => setPhase('playing')}
              className="mt-4 inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              <span>متابعة اللعب</span>
            </button>
          </div>
        )}

        {phase === 'over' && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/90 p-5 text-center text-white">
            <Trophy className="h-10 w-10 text-amber-400" aria-hidden="true" />
            <div className="mt-2 text-xl font-extrabold">انتهت الجولة!</div>
            <div className="mt-1 font-code text-sm text-slate-300">
              نتيجتك: {score} · أعلى نتيجة: {Math.max(score, settings.bestWordRainScore || 0)}
            </div>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={resetGame}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>العب مجدداً</span>
              </button>
              <button
                type="button"
                onClick={onExit}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-700 px-4 text-xs font-bold text-slate-200 hover:bg-slate-800"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 4 Bottom Arabic Answer Buttons */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
        {answerButtons.map((opt, idx) => (
          <button
            key={`${lowestDrop?.uid || 0}-${opt.wordId}-${idx}`}
            type="button"
            disabled={phase !== 'playing'}
            onClick={() => handleAnswer(opt.wordId)}
            className="tmn-card flex min-h-[56px] items-center justify-between gap-2 rounded-2xl px-4 py-3 text-start text-sm font-extrabold text-slate-900 transition-colors hover:border-indigo-500 hover:bg-indigo-50 disabled:opacity-50 dark:text-white dark:hover:border-indigo-400 dark:hover:bg-indigo-500/15"
          >
            <span className="line-clamp-2">{opt.ar}</span>
            <span className="shrink-0 font-code text-xs text-slate-400">{idx + 1}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
 * 5) SAVE THE ROCKET ("أنقذ الصاروخ — تخمين الحروف")
 * ============================================================================ */
function SaveRocketGame({
  store,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkMastered,
  onMarkMistake,
  onUpdateSettings,
  onOpenWordDetail,
  onHudChange,
  onExit,
}: Omit<ArcadeGamesArenaProps, 'mode'>) {
  const [band, setBand] = useState<CefrBand | 'ALL'>('ALL');
  const [target, setTarget] = useState<VocabEntry>(() => pickRocketWord(store, 'ALL', Date.now()));
  const [guessed, setGuessed] = useState<string[]>([]);
  const [hintUsed, setHintUsed] = useState(false);
  const [streak, setStreak] = useState(0);
  const [solvedCount, setSolvedCount] = useState(0);
  const [failedCount, setFailedCount] = useState(0);
  const seenIdsRef = useRef<Set<number>>(new Set());

  const rocketState = useMemo(() => evaluateRocketState(target.en, guessed, 6), [target.en, guessed]);

  const loadNextWord = useCallback(
    (activeBand: CefrBand | 'ALL') => {
      const next = pickRocketWord(store, activeBand, Date.now(), seenIdsRef.current);
      seenIdsRef.current.add(next.id);
      if (seenIdsRef.current.size > 50) seenIdsRef.current.clear();
      setTarget(next);
      setGuessed([]);
      setHintUsed(false);
    },
    [store]
  );

  useEffect(() => {
    onHudChange({
      current: solvedCount + failedCount + 1,
      total: Math.max(10, solvedCount + failedCount + 1),
      correct: solvedCount,
      wrong: failedCount,
    });
  }, [solvedCount, failedCount, onHudChange]);

  const handleGuessLetter = useCallback(
    (ch: string) => {
      if (rocketState.status !== 'playing') return;
      const lower = ch.toLowerCase();
      if (guessed.includes(lower)) return;
      const nextGuessed = [...guessed, lower];
      setGuessed(nextGuessed);

      const nextState = evaluateRocketState(target.en, nextGuessed, 6);
      const isHit = target.en.toLowerCase().includes(lower);
      if (nextState.status === 'won') {
        const nextStreak = streak + 1;
        setStreak(nextStreak);
        setSolvedCount((c) => c + 1);
        onSfx('win');
        onSpeak(target.en);
        onEarnXp(25);
        if (target.id >= 0) onMarkMastered(target.id);
        if (nextStreak > (settings.bestRocketStreak || 0)) {
          onUpdateSettings({ bestRocketStreak: nextStreak });
        }
      } else if (nextState.status === 'lost') {
        setStreak(0);
        setFailedCount((c) => c + 1);
        onSfx('err');
        onSpeak(target.en);
        if (target.id >= 0) onMarkMistake(target.id);
      } else {
        onSfx(isHit ? 'ok' : 'err');
      }
    },
    [
      rocketState.status,
      guessed,
      target,
      streak,
      settings.bestRocketStreak,
      onSfx,
      onSpeak,
      onEarnXp,
      onMarkMastered,
      onMarkMistake,
      onUpdateSettings,
    ]
  );

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (/^[a-zA-Z]$/.test(e.key)) {
        handleGuessLetter(e.key.toLowerCase());
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleGuessLetter]);

  const shieldPct = Math.round((rocketState.remainingAttempts / rocketState.maxWrong) * 100);

  return (
    <div data-testid="arcade-save-rocket" className="mx-auto max-w-2xl space-y-5">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-4 text-xs font-extrabold tabular-nums">
          <span className="inline-flex items-center gap-1.5 text-sky-600 dark:text-sky-400">
            <Rocket className="h-4 w-4" aria-hidden="true" />
            الدرع: {rocketState.remainingAttempts}/{rocketState.maxWrong}
          </span>
          <span className="text-amber-600 dark:text-amber-400">سلسلة: {streak}</span>
          <span className="text-slate-400">
            الأعلى: <strong className="font-code text-emerald-500">{settings.bestRocketStreak || 0}</strong>
          </span>
        </div>

        <button
          type="button"
          data-testid="rocket-hint-btn"
          disabled={hintUsed || rocketState.status !== 'playing'}
          onClick={() => {
            const letter = pickRocketHintLetter(target.en, guessed);
            if (letter) {
              setHintUsed(true);
              handleGuessLetter(letter);
            }
          }}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/10 px-3 text-xs font-bold text-amber-700 hover:bg-amber-500/20 disabled:opacity-45 dark:text-amber-300"
        >
          <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{hintUsed ? 'تم استخدام التلميح' : 'كشف حرف مجاني'}</span>
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 px-1">
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400">مستوى الكلمات:</span>
        <BandSelectorBar
          band={band}
          onChange={(b) => {
            setBand(b);
            loadNextWord(b);
          }}
        />
      </div>

      {/* Main Rocket Stage */}
      <div className="tmn-card rounded-3xl p-6 text-center">
        {/* Custom SVG Rocket Shield Gauge */}
        <div className="mx-auto flex max-w-xs flex-col items-center">
          <svg
            viewBox="0 0 180 110"
            className="h-28 w-44"
            role="img"
            aria-label={`طاقة درع الصاروخ ${shieldPct}%`}
          >
            {/* Outer Shield Ring */}
            <circle
              cx="90"
              cy="54"
              r="44"
              fill="none"
              stroke="rgba(148,163,184,0.22)"
              strokeWidth="6"
            />
            <circle
              cx="90"
              cy="54"
              r="44"
              fill="none"
              stroke={
                rocketState.remainingAttempts > 3
                  ? '#10b981'
                  : rocketState.remainingAttempts > 1
                    ? '#f59e0b'
                    : '#f43f5e'
              }
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={`${Math.round((shieldPct / 100) * 276)} 276`}
              transform="rotate(-90 90 54)"
            />
            {/* Rocket Hull */}
            <path
              d="M90 22 C102 36 104 54 102 70 L78 70 C76 54 78 36 90 22 Z"
              fill="#6366f1"
              stroke="#e2e8f0"
              strokeWidth="2"
            />
            <circle cx="90" cy="48" r="7" fill="#38bdf8" stroke="#ffffff" strokeWidth="2" />
            <path d="M78 58 L66 72 L78 70 Z" fill="#4f46e5" />
            <path d="M102 58 L114 72 L102 70 Z" fill="#4f46e5" />
            {/* Flame only while fuel remains */}
            {rocketState.remainingAttempts > 0 && (
              <path
                d="M84 72 L90 92 L96 72 Z"
                fill={rocketState.status === 'won' ? '#10b981' : '#f59e0b'}
              />
            )}
          </svg>
          <div className="mt-1 flex gap-1.5" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <span
                key={i}
                className={`h-2 w-6 rounded-full transition-colors ${
                  i < rocketState.remainingAttempts
                    ? 'bg-emerald-500'
                    : 'bg-slate-200 dark:bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="mt-4 text-xs font-bold text-indigo-600 dark:text-indigo-400">
          مستوى {target.band} · {target.en.length} أحرف
        </div>
        <div className="mt-1 text-2xl font-extrabold text-slate-900 dark:text-white">
          {target.ar}
        </div>

        {/* Letter Slots */}
        <div dir="ltr" className="mt-5 flex flex-wrap items-center justify-center gap-2">
          {rocketState.maskedChars.map((slot, idx) => (
            <div
              key={idx}
              className={`flex h-12 w-10 items-center justify-center rounded-xl border-2 font-en text-2xl font-extrabold uppercase sm:h-14 sm:w-12 ${
                slot.revealed
                  ? 'border-indigo-500 bg-indigo-500/12 text-slate-900 dark:text-white'
                  : rocketState.status === 'lost'
                    ? 'border-rose-400/60 bg-rose-500/10 text-rose-500'
                    : 'border-slate-300 bg-slate-50 text-transparent dark:border-slate-700 dark:bg-[#0d1424]'
              }`}
            >
              {slot.revealed || rocketState.status === 'lost' ? slot.ch : '_'}
            </div>
          ))}
        </div>

        {rocketState.status !== 'playing' && (
          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/90 p-4 dark:border-slate-800 dark:bg-slate-900/70">
            <div
              className={`text-base font-extrabold ${
                rocketState.status === 'won'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {rocketState.status === 'won'
                ? 'تم إنقاذ الصاروخ بنجاح! (+25 XP)'
                : `نفد الوقود — الكلمة كانت: ${target.en}`}
            </div>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <button
                type="button"
                onClick={() => onSpeak(target.en)}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              >
                <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                <span>استمع للنطق</span>
              </button>
              {target.id >= 0 && (
                <button
                  type="button"
                  onClick={() => onOpenWordDetail(target.id)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-indigo-400/40 bg-indigo-500/10 px-3.5 text-xs font-bold text-indigo-700 dark:text-indigo-300"
                >
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span>صفحة الكلمة</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => loadNextWord(band)}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>الكلمة التالية</span>
              </button>
              <button
                type="button"
                onClick={onExit}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-xs font-bold text-slate-600 dark:border-slate-700 dark:text-slate-300"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Interactive A-Z Keyboard */}
      <div dir="ltr" className="tmn-card flex flex-wrap justify-center gap-1.5 rounded-2xl p-3">
        {ALPHABET.map((ch) => {
          const used = guessed.includes(ch);
          const isHit = used && target.en.toLowerCase().includes(ch);
          const isMiss = used && !isHit;
          return (
            <button
              key={ch}
              type="button"
              data-testid={`rocket-key-${ch}`}
              disabled={used || rocketState.status !== 'playing'}
              onClick={() => handleGuessLetter(ch)}
              className={`flex h-11 w-10 items-center justify-center rounded-xl border font-en text-sm font-extrabold uppercase transition-colors sm:w-11 ${
                isHit
                  ? 'border-emerald-500 bg-emerald-600 text-white'
                  : isMiss
                    ? 'border-rose-400/40 bg-rose-500/15 text-rose-400 opacity-50'
                    : 'border-slate-200 bg-white text-slate-800 hover:border-indigo-400 hover:bg-indigo-50 dark:border-slate-700 dark:bg-[#162036] dark:text-slate-100 dark:hover:border-indigo-400'
              }`}
            >
              {ch}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================================
 * MAIN EXPORTED ARENA ROUTER
 * ============================================================================ */
export function ArcadeGamesArena(props: ArcadeGamesArenaProps) {
  const { mode, onExit } = props;

  const meta: Record<ArcadeGameModeId, { title: string; subtitle: string; icon: React.ReactNode }> =
    {
      wordle: {
        title: 'تحدي الكلمة — Wordle',
        subtitle: 'خمّن الكلمة الإنجليزية من 5 أحرف خلال 6 محاولات',
        icon: <Grid3X3 className="h-5 w-5" aria-hidden="true" />,
      },
      speed_blitz: {
        title: 'سباق 60 ثانية',
        subtitle: 'أجب بأسرع وقت واضرب نقاطك بمضاعف السلسلة حتى x5',
        icon: <Zap className="h-5 w-5" aria-hidden="true" />,
      },
      memory_flip: {
        title: 'بطاقات الذاكرة',
        subtitle: 'طابق كل كلمة إنجليزية مع معناها العربي بأقل عدد من الحركات',
        icon: <Sparkles className="h-5 w-5" aria-hidden="true" />,
      },
      word_rain: {
        title: 'مطر الكلمات',
        subtitle: 'التقط ترجمة الكلمات المتساقطة قبل أن تصل إلى الأسفل',
        icon: <CloudRain className="h-5 w-5" aria-hidden="true" />,
      },
      save_rocket: {
        title: 'أنقذ الصاروخ — تخمين الحروف',
        subtitle: 'خمّن حروف الكلمة الإنجليزية قبل نفاد طاقة الدرع',
        icon: <Rocket className="h-5 w-5" aria-hidden="true" />,
      },
    };

  const info = meta[mode];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xs">
            {info.icon}
          </div>
          <div>
            <h1 className="text-lg font-extrabold text-slate-900 dark:text-white sm:text-xl">
              {info.title}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">{info.subtitle}</p>
          </div>
        </div>

        <button
          type="button"
          data-testid="arcade-exit-btn"
          onClick={onExit}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-[#11192b] dark:text-slate-200"
        >
          <CheckCircle2 className="hidden" aria-hidden="true" />
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>العودة للألعاب</span>
        </button>
      </div>

      {mode === 'wordle' && <WordleGame {...props} />}
      {mode === 'speed_blitz' && <SpeedBlitzGame {...props} />}
      {mode === 'memory_flip' && <MemoryFlipGame {...props} />}
      {mode === 'word_rain' && <WordRainGame {...props} />}
      {mode === 'save_rocket' && <SaveRocketGame {...props} />}
    </div>
  );
}
