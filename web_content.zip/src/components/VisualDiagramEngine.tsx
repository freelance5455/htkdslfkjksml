import React, { useState } from 'react';
import {
  GitBranch,
  Layers,
  Volume2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import type { KanjiItem } from '../types';
import { HIRAGANA_DATA, KANJI_DATA, KATAKANA_DATA } from '../utils/japaneseData';
import { KanjiVisualArtwork } from './KanjiVisualArtwork';

interface VisualDiagramEngineProps {
  onEarnXp: (amount: number) => void;
}

type DiagramCategory =
  | 'kanji_breakdown'
  | 'radicals'
  | 'onyomi_kunyomi'
  | 'vocab_map'
  | 'grammar_flow'
  | 'sentence_structure'
  | 'verb_conjugation'
  | 'kana_compare'
  | 'memory_map'
  | 'diagram_quiz';

const VERB_CONJUGATIONS = [
  {
    group: 'Ichidan (-ru Verb)',
    base: '食べる (たべる / Taberu — To eat)',
    masu: '食べます (たべます)',
    masen: '食べません (たべません)',
    mashita: '食べました (たべました)',
    teForm: '食べて (たべて)',
    hindi: 'खाना (विनम्र रूप)',
  },
  {
    group: 'Godan (-u Verb)',
    base: '飲む (のむ / Nomu — To drink)',
    masu: '飲みます (のみます)',
    masen: '飲みません (のみません)',
    mashita: '飲みました (のみました)',
    teForm: '飲んで (のんで)',
    hindi: 'पीना (विनम्र रूप)',
  },
  {
    group: 'Godan (-ku Verb)',
    base: '書く (かく / Kaku — To write)',
    masu: '書きます (かきます)',
    masen: '書きません (かきません)',
    mashita: '書きました (かきました)',
    teForm: '書いて (かいて)',
    hindi: 'लिखना (विनम्र रूप)',
  },
  {
    group: 'Irregular Verb',
    base: 'する (Suru — To do)',
    masu: 'します (Shimasu)',
    masen: 'しません (Shimasen)',
    mashita: 'しました (Shimashita)',
    teForm: 'して (Shite)',
    hindi: 'करना (अनियमित क्रिया)',
  },
];

const DIAGRAM_QUIZ = [
  {
    prompt: 'Look at the Radical Composition: 木 (Tree) + 木 (Tree) + 木 (Tree) = ?',
    options: ['森 (Mori — Forest)', '本 (Hon — Book)', '火 (Hi — Fire)', '山 (Yama — Mountain)'],
    correct: 0,
    explanation: 'Three Trees (木) combined together create 森 (Mori — Deep Forest).',
  },
  {
    prompt: 'In the Japanese SOV Sentence Flow Diagram, where does the Verb ALWAYS appear?',
    options: ['At the very end of the sentence', 'Right after the Topic (は)', 'Before the Subject', 'Before the Object'],
    correct: 0,
    explanation: 'Just like Hindi (मैं सेब खाता हूँ), Japanese uses Subject-Object-Verb (SOV): 私は りんごを 食べます.',
  },
  {
    prompt: 'For Kanji 山 (Mountain), which compound word uses its Onyomi reading サン (san)?',
    options: ['富士山 (ふじさん — Mt. Fuji)', '山道 (やまみち — Mountain road)', '山 (やま — Single mountain)', 'やまのぼり (Mountain climbing)'],
    correct: 0,
    explanation: '富士山 uses Onyomi サン (san), whereas 山道 uses Kunyomi やま (yama).',
  },
];

export const VisualDiagramEngineModule: React.FC<VisualDiagramEngineProps> = ({ onEarnXp }) => {
  const [activeCategory, setActiveCategory] = useState<DiagramCategory>('kanji_breakdown');
  const [selectedKanji, setSelectedKanji] = useState<KanjiItem>(KANJI_DATA[0]); // Defaults to 山 Mountain
  const [selectedParticle, setSelectedParticle] = useState<'は' | 'が' | 'を' | 'に' | 'で'>('で');
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);

  const speakJapanese = (text: string) => {
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'ja-JP';
        u.rate = 0.88;
        window.speechSynthesis.speak(u);
      }
    } catch {
      // ignore if speech synthesis is blocked
    }
  };

  const categories: Array<{ id: DiagramCategory; label: string }> = [
    { id: 'kanji_breakdown', label: '1. Kanji Breakdown' },
    { id: 'radicals', label: '2. Radical Explorer' },
    { id: 'onyomi_kunyomi', label: '3. Onyomi vs Kunyomi' },
    { id: 'vocab_map', label: '4. Vocab Mind-Map' },
    { id: 'grammar_flow', label: '5. Grammar Flowchart' },
    { id: 'sentence_structure', label: '6. SOV Sentence Diagram' },
    { id: 'verb_conjugation', label: '7. Verb Chart' },
    { id: 'kana_compare', label: '8. Hiragana vs Katakana' },
    { id: 'memory_map', label: '9. Visual Memory Maps' },
    { id: 'diagram_quiz', label: '10. Interactive Diagram Quiz' },
  ];

  const particleMap: Record<'は' | 'が' | 'を' | 'に' | 'で', { role: string; hindi: string; jp: string; en: string }> = {
    'は': {
      role: 'Topic Marker (Pronounced "wa")',
      hindi: 'विषय सूचक (जिसके बारे में बात हो रही है)',
      jp: '私は 学生 です。',
      en: 'As for me, I am a student.',
    },
    'が': {
      role: 'Grammatical Subject / Identifier',
      hindi: 'कर्ता / पहचान सूचक',
      jp: '富士山が 高い です。',
      en: 'Mount Fuji is tall.',
    },
    'を': {
      role: 'Direct Object Marker (Pronounced "o")',
      hindi: 'कर्म सूचक ("को")',
      jp: '日本の 本を 読みます。',
      en: 'I read a Japanese book.',
    },
    'に': {
      role: 'Destination / Specific Time',
      hindi: 'गंतव्य / निश्चित समय ("पर / को")',
      jp: '山に 登ります。',
      en: 'I climb toward the mountain.',
    },
    'で': {
      role: 'Location of Action / Means',
      hindi: 'कार्य का स्थान या साधन ("में / से")',
      jp: '図書館で 勉強します。',
      en: 'I study at the library.',
    },
  };

  const currentQuiz = DIAGRAM_QUIZ[quizIndex % DIAGRAM_QUIZ.length];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Visual Diagram Learning Engine (図解学習)
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Learn Japanese visually with Kanji pictographs, radical decompositions, reading trees, grammar flowcharts, and SOV diagrams.
          </p>
        </div>
      </div>

      {/* Category Switcher */}
      <div className="flex flex-wrap gap-1.5 p-2 rounded-2xl bg-[#0B102B] border border-slate-800">
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white bg-[#060919]/60'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Kanji Selector Pill Strip for Kanji-centric Diagrams */}
      {(['kanji_breakdown', 'radicals', 'onyomi_kunyomi', 'vocab_map', 'memory_map'] as DiagramCategory[]).includes(
        activeCategory
      ) && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 shrink-0">Select Kanji Diagram:</span>
          {KANJI_DATA.map((k) => (
            <button
              key={k.kanji}
              type="button"
              onClick={() => {
                setSelectedKanji(k);
                speakJapanese(k.kanji);
              }}
              className={`px-3 py-1.5 rounded-xl border text-sm font-bold transition shrink-0 ${
                selectedKanji.kanji === k.kanji
                  ? 'bg-indigo-950/90 border-cyan-400 text-cyan-200'
                  : 'bg-[#0B102B] border-slate-800 text-slate-300 hover:border-slate-600'
              }`}
            >
              {k.kanji} <span className="text-[11px] font-normal text-slate-400">{k.meaningEn.split(',')[0]}</span>
            </button>
          ))}
        </div>
      )}

      {/* 1. Kanji Breakdown Diagram (Includes Mountain Illustration + Readings + Vocab) */}
      {activeCategory === 'kanji_breakdown' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-300">
                JLPT {selectedKanji.jlpt} · {selectedKanji.strokesCount} Strokes
              </span>
              <button
                type="button"
                onClick={() => speakJapanese(selectedKanji.kanji)}
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1"
              >
                <Volume2 className="w-3.5 h-3.5" />
                Speak
              </button>
            </div>

            <KanjiVisualArtwork type={selectedKanji.visualIllustration} kanji={selectedKanji.kanji} />

            <div className="text-center space-y-1">
              <div className="text-5xl font-extrabold text-white">{selectedKanji.kanji}</div>
              <p className="text-lg font-bold text-cyan-300">{selectedKanji.meaningEn}</p>
              <p className="text-sm font-semibold text-amber-300">हिंदी अर्थ: {selectedKanji.meaningHi}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#060919] border border-purple-500/30 text-xs text-slate-200">
              <p className="font-semibold text-purple-300 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Visual Memory Trick
              </p>
              <p>{selectedKanji.memoryTrick}</p>
            </div>
          </div>

          <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-cyan-400" />
              Visual Structure & Reading Tree
            </h3>

            {/* Readings Branch Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#060919] border border-cyan-500/40 space-y-1">
                <span className="text-[11px] font-mono uppercase text-cyan-300">
                  Onyomi (音読み — Compound Reading)
                </span>
                <p className="text-base font-bold text-white">{selectedKanji.onyomi}</p>
                <p className="text-xs text-slate-400">Used when combined with other Kanji</p>
              </div>
              <div className="p-4 rounded-xl bg-[#060919] border border-purple-500/40 space-y-1">
                <span className="text-[11px] font-mono uppercase text-purple-300">
                  Kunyomi (訓読み — Native Reading)
                </span>
                <p className="text-base font-bold text-white">{selectedKanji.kunyomi}</p>
                <p className="text-xs text-slate-400">Used alone or with Hiragana okurigana</p>
              </div>
            </div>

            {/* Compound Vocabulary Diagram Nodes */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Vocabulary Connections ({selectedKanji.vocabulary.length} Examples)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {selectedKanji.vocabulary.map((v, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      speakJapanese(v.word);
                      onEarnXp(3);
                    }}
                    className="p-3.5 rounded-xl bg-[#060919] border border-slate-800 hover:border-cyan-400 text-left space-y-1 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-white">{v.word}</span>
                      <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                    <p className="text-xs text-cyan-300 font-mono">{v.reading}</p>
                    <p className="text-xs text-slate-300">{v.meaningEn}</p>
                    <p className="text-[11px] text-amber-300">{v.meaningHi}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Sentence Strip */}
            <div className="p-4 rounded-xl bg-[#060919] border border-slate-800 space-y-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-cyan-300">Example Usage Sentence</span>
                <button
                  type="button"
                  onClick={() => speakJapanese(selectedKanji.exampleSentence.jp)}
                  className="text-cyan-300 hover:underline flex items-center gap-1"
                >
                  <Volume2 className="w-3.5 h-3.5" /> Play
                </button>
              </div>
              <p className="text-sm font-bold text-white">{selectedKanji.exampleSentence.jp}</p>
              <p className="text-slate-400 font-mono">{selectedKanji.exampleSentence.romaji}</p>
              <p className="text-slate-200">{selectedKanji.exampleSentence.en}</p>
              <p className="text-amber-300">{selectedKanji.exampleSentence.hi}</p>
            </div>
          </div>
        </div>
      )}

      {/* 2. Radical / Component Explorer */}
      {activeCategory === 'radicals' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            Radical & Component Equation for 「{selectedKanji.kanji}」 ({selectedKanji.meaningEn})
          </h3>

          <div className="flex flex-wrap items-center justify-center gap-4 p-6 rounded-2xl bg-[#060919] border border-slate-800">
            {selectedKanji.radicals.map((rad, idx) => (
              <React.Fragment key={idx}>
                {idx > 0 && <span className="text-2xl font-bold text-purple-400">+</span>}
                <div className="p-4 rounded-2xl bg-[#0D1438] border border-cyan-500/40 text-center min-w-[140px]">
                  <div className="text-4xl font-bold text-cyan-300">{rad.part}</div>
                  <p className="text-xs font-bold text-white mt-2">{rad.name}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{rad.meaning}</p>
                </div>
              </React.Fragment>
            ))}
            <span className="text-2xl font-bold text-emerald-400">=</span>
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950 to-purple-950 border-2 border-cyan-400 text-center min-w-[150px]">
              <div className="text-5xl font-extrabold text-white">{selectedKanji.kanji}</div>
              <p className="text-xs font-bold text-cyan-200 mt-2">{selectedKanji.meaningEn}</p>
              <p className="text-xs text-amber-300">{selectedKanji.meaningHi}</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 bg-[#060919] p-4 rounded-xl border border-slate-800">
            <strong>Visual Story:</strong> {selectedKanji.memoryTrick}
          </p>
        </div>
      )}

      {/* 3. Onyomi vs Kunyomi Comparison Tree */}
      {activeCategory === 'onyomi_kunyomi' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-indigo-950 border-2 border-cyan-400 text-5xl font-bold text-white">
              {selectedKanji.kanji}
            </div>
            <p className="text-sm font-bold text-slate-200">
              {selectedKanji.meaningEn} · <span className="text-amber-300">{selectedKanji.meaningHi}</span>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-[#060919] border border-cyan-500/40 space-y-3">
              <h4 className="text-sm font-bold text-cyan-300">
                Branch A: ONYOMI (音読み — Sound Reading)
              </h4>
              <p className="text-xl font-bold text-white">{selectedKanji.onyomi}</p>
              <p className="text-xs text-slate-400">
                Originates from classical Chinese pronunciation. Almost always written in Katakana in dictionaries and used when 2+ Kanji join together.
              </p>
              <div className="p-3 rounded-xl bg-[#0B102B] border border-slate-800 text-xs">
                <p className="text-slate-400">Compound Rule Example:</p>
                <p className="text-sm font-bold text-cyan-200 mt-1">
                  {selectedKanji.vocabulary[0]?.word} ({selectedKanji.vocabulary[0]?.reading})
                </p>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#060919] border border-purple-500/40 space-y-3">
              <h4 className="text-sm font-bold text-purple-300">
                Branch B: KUNYOMI (訓読み — Meaning Reading)
              </h4>
              <p className="text-xl font-bold text-white">{selectedKanji.kunyomi}</p>
              <p className="text-xs text-slate-400">
                Native Japanese spoken word assigned to the Kanji meaning. Typically appears when the Kanji stands alone or takes Hiragana endings.
              </p>
              <div className="p-3 rounded-xl bg-[#0B102B] border border-slate-800 text-xs">
                <p className="text-slate-400">Standalone / Sentence Example:</p>
                <p className="text-sm font-bold text-purple-200 mt-1">
                  {selectedKanji.exampleSentence.jp}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Vocabulary Association Mind-Map */}
      {activeCategory === 'vocab_map' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-6">
          <h3 className="text-base font-bold text-white text-center">
            Vocabulary Association Map around 「{selectedKanji.kanji}」 ({selectedKanji.meaningEn})
          </h3>
          <div className="flex flex-col items-center space-y-6">
            <div className="px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-600/30 to-purple-600/30 border-2 border-cyan-400 text-center">
              <span className="text-4xl font-extrabold text-white">{selectedKanji.kanji}</span>
              <p className="text-xs text-cyan-200 mt-1">{selectedKanji.meaningEn} / {selectedKanji.meaningHi}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full">
              {selectedKanji.vocabulary.map((v, i) => (
                <div
                  key={i}
                  className="p-4 rounded-2xl bg-[#060919] border border-slate-800 hover:border-cyan-400 transition space-y-2 text-center"
                >
                  <div className="text-2xl font-bold text-white">{v.word}</div>
                  <div className="text-xs font-mono text-cyan-300">{v.reading}</div>
                  <div className="text-xs text-slate-200">{v.meaningEn}</div>
                  <div className="text-xs text-amber-300">{v.meaningHi}</div>
                  <button
                    type="button"
                    onClick={() => speakJapanese(v.word)}
                    className="mt-1 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 inline-flex items-center gap-1"
                  >
                    <Volume2 className="w-3 h-3" /> Hear Word
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. Grammar Flowchart */}
      {activeCategory === 'grammar_flow' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
          <h3 className="text-base font-bold text-white">
            Interactive Particle Decision Flowchart (助詞フローチャート)
          </h3>
          <div className="flex flex-wrap gap-2">
            {(['は', 'が', 'を', 'に', 'で'] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => {
                  setSelectedParticle(p);
                  speakJapanese(particleMap[p].jp);
                }}
                className={`px-4 py-2 rounded-xl font-bold text-sm border transition ${
                  selectedParticle === p
                    ? 'bg-cyan-600 border-cyan-300 text-white'
                    : 'bg-[#060919] border-slate-800 text-slate-300'
                }`}
              >
                Particle 「{p}」
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center p-5 rounded-2xl bg-[#060919] border border-slate-800">
            <div className="p-4 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-center">
              <p className="text-xs text-slate-400">Step 1: Noun Role</p>
              <p className="text-sm font-bold text-white mt-1">{particleMap[selectedParticle].role}</p>
              <p className="text-xs text-amber-300 mt-1">{particleMap[selectedParticle].hindi}</p>
            </div>
            <div className="flex flex-col items-center justify-center gap-2">
              <ArrowRight className="w-6 h-6 text-cyan-400 hidden md:block" />
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-3xl font-extrabold text-white shadow-lg">
                {selectedParticle}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 space-y-1">
              <p className="text-xs text-emerald-300 font-semibold">Step 3: Live Example Sentence</p>
              <p className="text-base font-bold text-white">{particleMap[selectedParticle].jp}</p>
              <p className="text-xs text-slate-300">{particleMap[selectedParticle].en}</p>
            </div>
          </div>
        </div>
      )}

      {/* 6. Sentence Structure Diagram (SOV Japanese vs SVO English vs SOV Hindi) */}
      {activeCategory === 'sentence_structure' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
          <h3 className="text-base font-bold text-white">
            Sentence Structure Blueprint: Why Hindi Speakers Master Japanese Fast!
          </h3>
          <div className="space-y-4">
            {[
              {
                lang: 'Japanese (S-O-V)',
                blocks: [
                  { label: 'Subject', text: '私は (Watashi wa)', color: 'border-cyan-400 bg-cyan-950/40' },
                  { label: 'Object', text: '日本語を (Nihongo o)', color: 'border-amber-400 bg-amber-950/40' },
                  { label: 'Verb (End)', text: '勉強します (Benkyou shimasu)', color: 'border-purple-400 bg-purple-950/40' },
                ],
              },
              {
                lang: 'Hindi (S-O-V — Same Order!)',
                blocks: [
                  { label: 'कर्ता (Subject)', text: 'मैं', color: 'border-cyan-400 bg-cyan-950/40' },
                  { label: 'कर्म (Object)', text: 'जापानी भाषा', color: 'border-amber-400 bg-amber-950/40' },
                  { label: 'क्रिया (Verb - End)', text: 'पढ़ता हूँ।', color: 'border-purple-400 bg-purple-950/40' },
                ],
              },
              {
                lang: 'English (S-V-O)',
                blocks: [
                  { label: 'Subject', text: 'I', color: 'border-cyan-400 bg-cyan-950/40' },
                  { label: 'Verb (Middle)', text: 'study', color: 'border-purple-400 bg-purple-950/40' },
                  { label: 'Object (End)', text: 'Japanese.', color: 'border-amber-400 bg-amber-950/40' },
                ],
              },
            ].map((row) => (
              <div key={row.lang} className="p-4 rounded-xl bg-[#060919] border border-slate-800 space-y-2">
                <p className="text-xs font-bold text-cyan-300">{row.lang}</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {row.blocks.map((b, i) => (
                    <div key={i} className={`p-3 rounded-xl border ${b.color}`}>
                      <span className="text-[10px] uppercase tracking-wider text-slate-300">{b.label}</span>
                      <p className="text-sm font-bold text-white mt-0.5">{b.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. Verb Conjugation Chart */}
      {activeCategory === 'verb_conjugation' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4 overflow-x-auto">
          <h3 className="text-base font-bold text-white">
            Visual Verb Conjugation Matrix (動詞の活用表)
          </h3>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-cyan-300">
                <th className="py-2.5 pr-3">Group</th>
                <th className="py-2.5 pr-3">Dictionary (Plain)</th>
                <th className="py-2.5 pr-3">Polite (〜ます)</th>
                <th className="py-2.5 pr-3">Negative (〜ません)</th>
                <th className="py-2.5 pr-3">Past (〜ました)</th>
                <th className="py-2.5 pr-3">Te-Form (〜て)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {VERB_CONJUGATIONS.map((row) => (
                <tr key={row.base} className="hover:bg-[#060919]/60">
                  <td className="py-3 pr-3 font-semibold text-purple-300">{row.group}</td>
                  <td className="py-3 pr-3 text-white font-semibold">
                    {row.base}
                    <div className="text-[11px] text-amber-300">{row.hindi}</div>
                  </td>
                  <td className="py-3 pr-3 text-emerald-300 font-medium">{row.masu}</td>
                  <td className="py-3 pr-3 text-rose-300 font-medium">{row.masen}</td>
                  <td className="py-3 pr-3 text-cyan-200 font-medium">{row.mashita}</td>
                  <td className="py-3 pr-3 text-amber-200 font-medium">{row.teForm}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 8. Hiragana vs Katakana Side-by-Side Comparison */}
      {activeCategory === 'kana_compare' && (
        <div className="p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <h3 className="text-base font-bold text-white">
            Hiragana (Curved Native Words) vs Katakana (Angular Loanwords) — All 46 Pairs
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-5 gap-2.5">
            {HIRAGANA_DATA.map((h, i) => {
              const k = KATAKANA_DATA[i];
              return (
                <button
                  key={h.char}
                  type="button"
                  onClick={() => speakJapanese(h.char)}
                  className="p-2.5 rounded-xl bg-[#060919] border border-slate-800 hover:border-cyan-400 flex items-center justify-between text-xs transition"
                >
                  <span className="text-lg font-bold text-cyan-300">{h.char}</span>
                  <span className="font-mono text-slate-400">{h.romaji}</span>
                  <span className="text-lg font-bold text-purple-300">{k?.char}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 9. Visual Memory Maps */}
      {activeCategory === 'memory_map' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {KANJI_DATA.slice(0, 6).map((k) => (
            <div key={k.kanji} className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-extrabold text-white">{k.kanji}</span>
                  <div>
                    <p className="text-sm font-bold text-cyan-300">{k.meaningEn}</p>
                    <p className="text-xs text-amber-300">{k.meaningHi}</p>
                  </div>
                </div>
                <span className="text-xs font-mono text-slate-400">JLPT {k.jlpt}</span>
              </div>
              <KanjiVisualArtwork type={k.visualIllustration} kanji={k.kanji} />
              <p className="text-xs text-slate-200 leading-relaxed flex items-start gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
                {k.memoryTrick}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* 10. Interactive Diagram Quiz */}
      {activeCategory === 'diagram_quiz' && (
        <div className="max-w-2xl mx-auto p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono text-cyan-300">
              Visual Diagram Challenge {(quizIndex % DIAGRAM_QUIZ.length) + 1} / {DIAGRAM_QUIZ.length}
            </span>
          </div>
          <h3 className="text-lg font-bold text-white">{currentQuiz.prompt}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQuiz.options.map((opt, idx) => {
              const isPicked = quizAnswer === idx;
              const isRight = currentQuiz.correct === idx;
              let cls = 'bg-[#060919] border-slate-800 text-white hover:border-cyan-400';
              if (quizAnswer !== null) {
                if (isRight) cls = 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-semibold';
                else if (isPicked) cls = 'bg-rose-950/70 border-rose-500 text-rose-200';
              }
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setQuizAnswer(idx);
                    if (idx === currentQuiz.correct) onEarnXp(15);
                  }}
                  className={`p-3.5 rounded-xl border text-left text-sm transition ${cls}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          {quizAnswer !== null && (
            <div className="p-4 rounded-xl bg-indigo-950/50 border border-indigo-500/40 text-xs text-slate-200 space-y-2">
              <p className="flex items-center gap-1.5 font-semibold text-cyan-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                {currentQuiz.explanation}
              </p>
              <button
                type="button"
                onClick={() => {
                  setQuizAnswer(null);
                  setQuizIndex((i) => i + 1);
                }}
                className="px-4 py-2 rounded-lg bg-cyan-600 text-white font-semibold"
              >
                Next Visual Question →
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
