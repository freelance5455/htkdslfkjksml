/**
 * GODEX v0.0.1 - Starter Projects & Templates Switcher Modal
 */

import React from 'react';
import { Layers, Film, Cpu, Server, FileCode, Check, X, Sparkles } from 'lucide-react';
import { STARTER_PROJECTS } from '../templates/starterProjects';
import { ProjectTemplate } from '../types';

interface StarterProjectsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTemplateId: string;
  onSelectTemplate: (template: ProjectTemplate) => void;
}

export const StarterProjectsModal: React.FC<StarterProjectsModalProps> = ({
  isOpen,
  onClose,
  activeTemplateId,
  onSelectTemplate
}) => {
  if (!isOpen) return null;

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Video': return <Film className="w-5 h-5 text-cyan-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-indigo-400" />;
      case 'Server': return <Server className="w-5 h-5 text-emerald-400" />;
      default: return <FileCode className="w-5 h-5 text-neutral-400" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-2xl bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <Layers className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                PROJECT_TEMPLATES.STARTER_CATALOG
              </h2>
              <p className="text-[10px] text-neutral-400 font-sans">Pre-configured real-world full-stack architectures</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-[#07080D]">
          {STARTER_PROJECTS.map(template => {
            const isSelected = activeTemplateId === template.id;

            return (
              <div
                key={template.id}
                onClick={() => {
                  if (isSelected) {
                    onClose();
                    return;
                  }
                  if (confirm(`Switch project to "${template.title}"? Current workspace files will be replaced with this template.`)) {
                    onSelectTemplate(template);
                    onClose();
                  }
                }}
                className={`p-3.5 rounded border cursor-pointer transition-all flex items-start justify-between gap-4 ${
                  isSelected
                    ? 'border-cyan-500/80 bg-[#101B2A] shadow-md shadow-cyan-950/40'
                    : 'border-[#1B2232] bg-[#0D1018] hover:border-[#28354E] hover:bg-[#111622]'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded bg-[#090B10] border border-[#1E2738] shrink-0 mt-0.5">
                    {getIcon(template.iconName)}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{template.title}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#161E2E] text-cyan-300 border border-[#232F46] font-semibold">
                        {template.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed max-w-lg font-sans">
                      {template.description}
                    </p>
                    <div className="text-[9px] font-mono text-neutral-500 pt-0.5">
                      {Object.keys(template.files).length} files included • React 19 • Tailwind CSS
                    </div>
                  </div>
                </div>

                <div className="shrink-0 pt-1">
                  {isSelected ? (
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#0E2A38] text-cyan-300 border border-cyan-500/60 text-[10px] font-bold">
                      <Check className="w-3 h-3" />
                      <span>ACTIVE</span>
                    </div>
                  ) : (
                    <button className="px-2.5 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-300">
                      OPEN
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="h-11 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
