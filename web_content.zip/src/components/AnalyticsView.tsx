import React from 'react';
import { TierLevel, UserProfile } from '../types';
import { Lock, Activity } from 'lucide-react';

interface AnalyticsViewProps {
  user: UserProfile;
  currentTier: TierLevel;
  onOpenPaywall: (tier?: TierLevel) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  currentTier,
  onOpenPaywall,
}) => {
  const isLevel5Unlocked = currentTier >= 5;

  // 7-day mock trend data
  const days = [
    { day: 'السبت', cals: 2150 },
    { day: 'الأحد', cals: 2080 },
    { day: 'الإثنين', cals: 1980 },
    { day: 'الثلاثاء', cals: 2250 },
    { day: 'الأربعاء', cals: 2110 },
    { day: 'الخميس', cals: 2040 },
    { day: 'اليوم', cals: 1890 },
  ];

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      <div>
        <h1 className="text-2xl font-black text-white">التحليلات والتنبؤ الذكي</h1>
        <p className="text-sm text-slate-400 mt-1">
          تتبع مسار التغذية اليومية وتوقعات الذكاء الاصطناعي لكتلة جسمك
        </p>
      </div>

      {/* 7-day bar chart */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">متوسط استهلاك السعرات (الأيام الـ 7 الماضية)</h2>
          </div>
          <span className="text-xs text-emerald-400 font-semibold">معدل الالتزام: 94%</span>
        </div>

        <div className="pt-6 pb-2 grid grid-cols-7 gap-2 sm:gap-4 items-end h-48 border-b border-slate-800">
          {days.map((item, idx) => {
            const heightPct = Math.round((item.cals / 2600) * 100);
            return (
              <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity tabular-nums">
                  {item.cals}
                </span>
                <div
                  className="w-full max-w-[40px] bg-emerald-500/80 hover:bg-emerald-400 rounded-t-lg transition-all"
                  style={{ height: `${heightPct}%` }}
                />
                <span className="text-[11px] text-slate-400 font-medium">{item.day}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Level 5 Feature: AI Body Composition & Weight Predictor */}
      <div className={`p-6 rounded-2xl border transition-all ${
        isLevel5Unlocked
          ? 'bg-gradient-to-br from-amber-950/20 via-slate-900 to-slate-900 border-amber-500/40 shadow-xl'
          : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-lg">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">المتنبئ الذكي لتطور الوزن والدهون (90 يوماً)</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 font-bold border border-amber-500/20">
                  المستوى 5 VIP
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                نمذجة خوارزمية ذكية تتوقع مسار انخفاض وزنك ونسبة الدهون بناءً على وجباتك الممسوحة
              </p>
            </div>
          </div>

          {!isLevel5Unlocked && (
            <button
              onClick={() => onOpenPaywall(5)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>فتح ميزة المستوى 5</span>
            </button>
          )}
        </div>

        {!isLevel5Unlocked ? (
          <div className="py-10 text-center space-y-3">
            <Lock className="w-10 h-10 text-amber-500/40 mx-auto" />
            <p className="text-sm font-bold text-white">هذه الميزة محجوزة لأعضاء المستوى 5 (VIP Legend)</p>
            <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
              وفقاً للنظام، يتطلب المستوى 5: <strong className="text-amber-400">20 دعوة واشتراكاً نشطاً</strong> (منك أو من 6 أصدقاء مدعوين).
            </p>
            <button
              onClick={() => onOpenPaywall(5)}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs"
            >
              عرض متطلبات فتح المستوى 5
            </button>
          </div>
        ) : (
          <div className="pt-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block mb-1">الوزن المتوقع بعد 30 يوماً</span>
                <span className="text-2xl font-black text-emerald-400 tabular-nums">76.4 كغ</span>
                <span className="text-[11px] text-slate-500 block mt-1">انخفاض -2.1 كغ</span>
              </div>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block mb-1">الوزن المتوقع بعد 60 يوماً</span>
                <span className="text-2xl font-black text-emerald-400 tabular-nums">74.2 كغ</span>
                <span className="text-[11px] text-slate-500 block mt-1">انخفاض -4.3 كغ</span>
              </div>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 block mb-1">الوزن المتوقع بعد 90 يوماً</span>
                <span className="text-2xl font-black text-amber-400 tabular-nums">71.8 كغ</span>
                <span className="text-[11px] text-emerald-400 block mt-1">الوصول لنسبة دهون 14%</span>
              </div>
            </div>

            <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <span className="font-bold text-amber-400 block mb-1">تحليل محرك التنبؤ العصبي:</span>
              بناءً على استمرارك في تسجيل معدل عجز سعرات 350 سعرة يومياً ونسبة بروتين تتجاوز 1.6غ لكل كيلوغرام من وزن الجسم، يتوقع نظام Cal AI ثبات الكتلة العضلية وانخفاض دهون البطن بنسبة 22% بحلول نهاية الشهر الثاني.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
