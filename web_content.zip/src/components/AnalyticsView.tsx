import React, { useMemo, useState } from 'react';
import type { Sale, StoreData } from '../types';
import { fmtDateLabel, fmtDuration, fmtHoursMinutes, fmtInt, fmtMoney, fmtTimeOnly, toDateKey, useNowMs } from '../utils';
import { CustomDatePicker, StatCard } from './SharedUI';

interface AnalyticsViewProps {
  data: StoreData;
  t: Record<string, string>;
  initialTab?: 'sales' | 'time';
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ data, t, initialTab = 'sales' }) => {
  const [sectionTab, setSectionTab] = useState<'sales' | 'time'>(initialTab);
  const nowMs = useNowMs(sectionTab === 'time' && !!data.activeSession, 1000);
  const [preset, setPreset] = useState('last30Days');
  const [customStart, setCustomStart] = useState(toDateKey(new Date(Date.now() - 29 * 86400000)));
  const [customEnd, setCustomEnd] = useState(toDateKey(new Date()));
  const [granularity, setGranularity] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');

  const dateBounds = useMemo(() => {
    const now = new Date();
    const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
    const endOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
    let s: Date;
    let e: Date;
    if (preset === 'today') {
      s = startOfDay(now);
      e = endOfDay(now);
    } else if (preset === 'yesterday') {
      const y = new Date(now.getTime() - 86400000);
      s = startOfDay(y);
      e = endOfDay(y);
    } else if (preset === 'last7Days') {
      s = startOfDay(new Date(now.getTime() - 6 * 86400000));
      e = endOfDay(now);
    } else if (preset === 'last30Days') {
      s = startOfDay(new Date(now.getTime() - 29 * 86400000));
      e = endOfDay(now);
    } else if (preset === 'thisMonth') {
      s = new Date(now.getFullYear(), now.getMonth(), 1);
      e = endOfDay(now);
    } else if (preset === 'prevMonth') {
      s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      e = endOfDay(new Date(now.getFullYear(), now.getMonth(), 0));
    } else if (preset === 'thisYear') {
      s = new Date(now.getFullYear(), 0, 1);
      e = endOfDay(now);
    } else {
      s = startOfDay(new Date(customStart));
      e = endOfDay(new Date(customEnd));
    }

    const span = Math.max(86400000, e.getTime() - s.getTime() + 1);
    const prevE = new Date(s.getTime() - 1);
    const prevS = new Date(prevE.getTime() - span + 1);
    return { s, e, prevS, prevE };
  }, [preset, customStart, customEnd]);

  const currentSales = useMemo(
    () =>
      data.sales.filter((s) => {
        const dt = new Date(s.date).getTime();
        return dt >= dateBounds.s.getTime() && dt <= dateBounds.e.getTime();
      }),
    [data.sales, dateBounds]
  );

  const currentExpenses = useMemo(
    () =>
      (data.expenses || []).filter((ex) => {
        const dt = new Date(ex.date).getTime();
        return dt >= dateBounds.s.getTime() && dt <= dateBounds.e.getTime();
      }),
    [data.expenses, dateBounds]
  );

  const prevSales = useMemo(
    () =>
      data.sales.filter((s) => {
        const dt = new Date(s.date).getTime();
        return dt >= dateBounds.prevS.getTime() && dt <= dateBounds.prevE.getTime();
      }),
    [data.sales, dateBounds]
  );

  const stats = useMemo(() => {
    const summarize = (list: Sale[]) => {
      const rev = list.reduce((a, b) => a + b.grandTotal, 0);
      const profit = list.reduce((a, b) => a + b.profit, 0);
      const orders = list.length;
      const items = list.reduce((a, b) => a + b.items.reduce((x, y) => x + y.qty, 0), 0);
      const due = list.reduce((a, b) => a + b.dueAmount, 0);
      return { rev, profit, orders, avg: orders ? rev / orders : 0, items, due };
    };
    const cur = summarize(currentSales);
    const prev = summarize(prevSales);
    const expTotal = currentExpenses.reduce((a, b) => a + Number(b.amount || 0), 0);
    const pct = (c: number, p: number) => (p === 0 ? (c > 0 ? 100 : 0) : ((c - p) / p) * 100);
    return { cur, prev, expTotal, netProfit: cur.profit - expTotal, revDiff: pct(cur.rev, prev.rev), profDiff: pct(cur.profit, prev.profit) };
  }, [currentSales, prevSales, currentExpenses]);

  const trendSeries = useMemo(() => {
    const map: Record<string, { label: string; rev: number; profit: number }> = {};
    const keyFor = (iso: string) => {
      const d = new Date(iso);
      if (granularity === 'daily') return toDateKey(d);
      if (granularity === 'weekly') {
        const tmp = new Date(d);
        tmp.setDate(tmp.getDate() - tmp.getDay());
        return toDateKey(tmp);
      }
      if (granularity === 'monthly') return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      return String(d.getFullYear());
    };
    currentSales.forEach((s) => {
      const k = keyFor(s.date);
      if (!map[k]) map[k] = { label: k, rev: 0, profit: 0 };
      map[k].rev += s.grandTotal;
      map[k].profit += s.profit;
    });
    return Object.values(map).sort((a, b) => a.label.localeCompare(b.label));
  }, [currentSales, granularity]);

  const breakdowns = useMemo(() => {
    const catMap: Record<string, number> = {};
    const payMap: Record<string, number> = {};
    const prodMap: Record<string, { name: string; qty: number; rev: number; profit: number }> = {};
    const prodLookup = Object.fromEntries(data.products.map((p) => [p.id, p]));
    currentSales.forEach((s) => {
      payMap[s.paymentMethod] = (payMap[s.paymentMethod] || 0) + s.grandTotal;
      s.items.forEach((it) => {
        const p = prodLookup[it.productId];
        const cat = p ? p.category : 'Other';
        const lineRev = it.qty * it.sellingPrice;
        const lineProf = it.qty * (it.sellingPrice - it.purchasePrice);
        catMap[cat] = (catMap[cat] || 0) + lineRev;
        if (!prodMap[it.name]) prodMap[it.name] = { name: it.name, qty: 0, rev: 0, profit: 0 };
        prodMap[it.name].qty += it.qty;
        prodMap[it.name].rev += lineRev;
        prodMap[it.name].profit += lineProf;
      });
    });
    return {
      categories: Object.entries(catMap).sort((a, b) => b[1] - a[1]),
      payments: Object.entries(payMap).sort((a, b) => b[1] - a[1]),
      topSelling: Object.values(prodMap).sort((a, b) => b.qty - a.qty).slice(0, 5),
      topProfit: Object.values(prodMap).sort((a, b) => b.profit - a.profit).slice(0, 5),
    };
  }, [currentSales, data.products]);

  const invStats = useMemo(() => {
    const costVal = data.products.reduce((s, p) => s + p.quantity * p.purchasePrice, 0);
    const retailVal = data.products.reduce((s, p) => s + p.quantity * p.sellingPrice, 0);
    const lowCount = data.products.filter((p) => p.quantity <= (p.minStock ?? data.settings.defaultLowStockLimit)).length;
    return { costVal, retailVal, potential: retailVal - costVal, lowCount };
  }, [data.products, data.settings.defaultLowStockLimit]);

  /* =========================================================
     SHOP TIME ANALYSIS CALCULATIONS
     ========================================================= */
  const timeAnalysis = useMemo(() => {
    const dayMap: Record<
      string,
      {
        dateKey: string;
        totalMs: number;
        sessions: number;
        firstOpen: string;
        lastClose: string;
        isLive: boolean;
      }
    > = {};

    (data.shopSessions || []).forEach((s) => {
      const dk = s.dateKey || toDateKey(s.openedAt);
      const dur = s.durationMs || 0;
      if (!dayMap[dk]) {
        dayMap[dk] = {
          dateKey: dk,
          totalMs: dur,
          sessions: 1,
          firstOpen: s.openedAt,
          lastClose: s.closedAt || s.openedAt,
          isLive: false,
        };
      } else {
        dayMap[dk].totalMs += dur;
        dayMap[dk].sessions += 1;
        if (s.openedAt < dayMap[dk].firstOpen) dayMap[dk].firstOpen = s.openedAt;
        if ((s.closedAt || s.openedAt) > dayMap[dk].lastClose) dayMap[dk].lastClose = s.closedAt || s.openedAt;
      }
    });

    if (data.activeSession) {
      const dk = toDateKey(data.activeSession.openedAt);
      const activeDur = Math.max(0, nowMs - new Date(data.activeSession.openedAt).getTime());
      if (!dayMap[dk]) {
        dayMap[dk] = {
          dateKey: dk,
          totalMs: activeDur,
          sessions: 1,
          firstOpen: data.activeSession.openedAt,
          lastClose: '',
          isLive: true,
        };
      } else {
        dayMap[dk].totalMs += activeDur;
        dayMap[dk].sessions += 1;
        if (data.activeSession.openedAt < dayMap[dk].firstOpen) dayMap[dk].firstOpen = data.activeSession.openedAt;
        dayMap[dk].isLive = true;
      }
    }

    const todayKey = toDateKey(new Date());
    const todayMs = dayMap[todayKey]?.totalMs || 0;

    // Last 7 days series (oldest -> today)
    const last7Days: { dateKey: string; label: string; totalMs: number; hours: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const dk = toDateKey(d);
      const ms = dayMap[dk]?.totalMs || 0;
      last7Days.push({
        dateKey: dk,
        label: d.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' }),
        totalMs: ms,
        hours: ms / 3600000,
      });
    }

    const weeklyMs = last7Days.reduce((s, d) => s + d.totalMs, 0);
    const activeDayRows = Object.values(dayMap).sort((a, b) => b.dateKey.localeCompare(a.dateKey));
    const totalAllMs = activeDayRows.reduce((s, r) => s + r.totalMs, 0);
    const avgMs = activeDayRows.length > 0 ? totalAllMs / activeDayRows.length : 0;

    return { todayMs, weeklyMs, avgMs, daysRecorded: activeDayRows.length, last7Days, rows: activeDayRows };
  }, [data.shopSessions, data.activeSession, nowMs]);

  const maxTrend = Math.max(1, ...trendSeries.map((d) => Math.max(d.rev, d.profit)));
  const maxWeekHours = Math.max(1, ...timeAnalysis.last7Days.map((d) => d.hours));

  return (
    <div className="space-y-6">
      {/* Top Section Switcher: Sales Analysis vs Shop Time Analysis */}
      <div className="surface-card p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="segmented-bar">
          <button
            type="button"
            onClick={() => setSectionTab('sales')}
            className={`segmented-option ${sectionTab === 'sales' ? 'segmented-option-active !text-blue-600' : ''}`}
          >
            {t.salesAnalysisTab}
          </button>
          <button
            type="button"
            onClick={() => setSectionTab('time')}
            className={`segmented-option ${sectionTab === 'time' ? 'segmented-option-active !text-blue-600' : ''}`}
          >
            {t.timeAnalysisTab}
          </button>
        </div>
        {sectionTab === 'time' && <p className="text-xs text-slate-500">{t.auto24hNote}</p>}
      </div>

      {sectionTab === 'time' ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard title={t.todayHours} value={fmtDuration(timeAnalysis.todayMs)} subtitle={fmtHoursMinutes(timeAnalysis.todayMs)} color="indigo" icon="clock" />
            <StatCard title={t.weeklyShopHours} value={fmtHoursMinutes(timeAnalysis.weeklyMs)} subtitle={fmtDuration(timeAnalysis.weeklyMs)} color="emerald" icon="clock" />
            <StatCard title={t.avgDailyHours} value={fmtHoursMinutes(timeAnalysis.avgMs)} subtitle={fmtDuration(timeAnalysis.avgMs)} color="sky" icon="analytics" />
            <StatCard title={t.totalDaysOpen} value={fmtInt(timeAnalysis.daysRecorded)} subtitle={t.weeklyHoursChart} color="amber" icon="dashboard" />
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
            <h3 className="font-bold text-slate-800 mb-4">{t.weeklyHoursChart}</h3>
            <div className="overflow-x-auto pb-1">
              <div className="min-w-[440px] h-52 flex items-end gap-3 pt-6 px-2 border-b border-slate-200">
                {timeAnalysis.last7Days.map((d) => (
                  <div key={d.dateKey} className="flex-1 flex flex-col items-center gap-1.5">
                    <span className="text-[11px] font-mono font-bold text-slate-600 tabular-nums whitespace-nowrap">
                      {d.totalMs > 0 ? fmtHoursMinutes(d.totalMs) : '0m'}
                    </span>
                    <div className="w-full flex justify-center items-end h-36">
                      <div
                        style={{ height: `${d.totalMs > 0 ? Math.max(8, (d.hours / maxWeekHours) * 100) : 3}%` }}
                        className={`w-9 rounded-t-lg transition-all ${d.totalMs > 0 ? 'bg-indigo-600' : 'bg-slate-200'}`}
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium whitespace-nowrap">{d.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-2">
              <h3 className="font-bold text-slate-800">{t.dailyTimeLog}</h3>
              <span className="text-xs font-semibold text-slate-500 tabular-nums whitespace-nowrap">
                {timeAnalysis.rows.length} {t.totalDaysOpen}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left tabular-nums">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 whitespace-nowrap">{t.date}</th>
                    <th className="px-4 py-3 text-right whitespace-nowrap">{t.sessionsCount}</th>
                    <th className="px-4 py-3 whitespace-nowrap">{t.firstOpen}</th>
                    <th className="px-4 py-3 whitespace-nowrap">{t.lastClose}</th>
                    <th className="px-4 py-3 text-right whitespace-nowrap">{t.hoursOpen}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {timeAnalysis.rows.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-10 text-slate-400">
                        {t.noSessions}
                      </td>
                    </tr>
                  ) : (
                    timeAnalysis.rows.map((row) => (
                      <tr key={row.dateKey} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-4 py-3 font-semibold text-slate-800 whitespace-nowrap">{fmtDateLabel(row.dateKey)}</td>
                        <td className="px-4 py-3 text-right font-mono whitespace-nowrap">{row.sessions}</td>
                        <td className="px-4 py-3 text-xs font-mono text-slate-600 whitespace-nowrap">{fmtTimeOnly(row.firstOpen)}</td>
                        <td className="px-4 py-3 text-xs font-mono whitespace-nowrap">
                          {row.isLive ? <span className="font-bold text-emerald-600">{t.activeNow}</span> : fmtTimeOnly(row.lastClose)}
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-indigo-600 whitespace-nowrap">
                          {fmtHoursMinutes(row.totalMs)} <span className="text-xs font-mono text-slate-400">({fmtDuration(row.totalMs)})</span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-slate-200/90 p-4 flex flex-wrap gap-3 items-center justify-between">
            <div className="flex flex-wrap gap-1.5">
              {['today', 'yesterday', 'last7Days', 'last30Days', 'thisMonth', 'prevMonth', 'thisYear', 'customRange'].map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setPreset(p)}
                  className={`option-chip !py-1.5 ${preset === p ? 'option-chip-active' : ''}`}
                >
                  {t[p]}
                </button>
              ))}
            </div>
            {preset === 'customRange' && (
              <div className="flex items-center gap-2 text-xs">
                <CustomDatePicker value={customStart} onChange={setCustomStart} allowClear={false} className="w-36" />
                <span>→</span>
                <CustomDatePicker value={customEnd} onChange={setCustomEnd} allowClear={false} className="w-36" />
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title={t.revenue}
              value={fmtMoney(stats.cur.rev)}
              subtitle={`${stats.revDiff >= 0 ? '▲' : '▼'} ${Math.abs(stats.revDiff).toFixed(1)}% ${t.vsPrevious}`}
              color="indigo"
            />
            <StatCard title={t.grossProfit} value={fmtMoney(stats.cur.profit)} subtitle={`${t.netProfit}: ${fmtMoney(stats.netProfit)}`} color="emerald" />
            <StatCard title={t.totalExpenses} value={fmtMoney(stats.expTotal)} subtitle={`${t.totalOrders}: ${fmtInt(stats.cur.orders)}`} color="rose" />
            <StatCard title={t.totalItemsSold} value={fmtInt(stats.cur.items)} subtitle={`${t.outstandingDue}: ${fmtMoney(stats.cur.due)}`} color="amber" />
          </div>

          <div className="surface-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-bold text-slate-800">{t.revVsProfitTrend}</h3>
                <p className="text-xs text-slate-500">{t.periodicTrend}</p>
              </div>
              <div className="segmented-bar">
                {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((g) => (
                  <button
                    type="button"
                    key={g}
                    onClick={() => setGranularity(g)}
                    className={`segmented-option !px-3 !py-1.5 text-xs ${
                      granularity === g ? 'segmented-option-active !text-blue-600' : ''
                    }`}
                  >
                    {t[g]}
                  </button>
                ))}
              </div>
            </div>
            {trendSeries.length === 0 ? (
              <p className="text-center text-slate-400 py-12 text-sm">{t.noAnalyticsData}</p>
            ) : (
              <div className="overflow-x-auto pb-2">
                <div className="min-w-[480px] h-56 flex items-end gap-3 pt-6 px-2 border-b border-slate-200">
                  {trendSeries.map((pt) => (
                    <div key={pt.label} className="flex-1 flex flex-col items-center gap-1 min-w-[44px]">
                      <div className="w-full flex items-end justify-center gap-1 h-44">
                        <div
                          title={`${t.revenue}: ${fmtMoney(pt.rev)}`}
                          style={{ height: `${Math.max(4, (pt.rev / maxTrend) * 100)}%` }}
                          className="w-4 bg-indigo-500 rounded-t-md transition-all"
                        />
                        <div
                          title={`${t.profit}: ${fmtMoney(pt.profit)}`}
                          style={{ height: `${Math.max(4, (pt.profit / maxTrend) * 100)}%` }}
                          className="w-4 bg-emerald-500 rounded-t-md transition-all"
                        />
                      </div>
                      <span className="text-[10px] font-mono text-slate-500 truncate max-w-[60px]">{pt.label}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-5 mt-3 text-xs text-slate-600">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-sm bg-indigo-500" /> {t.revenue}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-sm bg-emerald-500" /> {t.grossProfit}
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
              <h3 className="font-bold text-slate-800 mb-4">{t.salesByCategory}</h3>
              {breakdowns.categories.length === 0 ? (
                <p className="text-sm text-slate-400">{t.noAnalyticsData}</p>
              ) : (
                <div className="space-y-3 tabular-nums">
                  {breakdowns.categories.map(([cat, val]) => {
                    const pct = stats.cur.rev > 0 ? (val / stats.cur.rev) * 100 : 0;
                    return (
                      <div key={cat}>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span>{cat}</span>
                          <span>
                            {fmtMoney(val)} ({pct.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
              <h3 className="font-bold text-slate-800 mb-4">{t.salesByPaymentMethod}</h3>
              {breakdowns.payments.length === 0 ? (
                <p className="text-sm text-slate-400">{t.noAnalyticsData}</p>
              ) : (
                <div className="space-y-3 tabular-nums">
                  {breakdowns.payments.map(([pm, val]) => {
                    const pct = stats.cur.rev > 0 ? (val / stats.cur.rev) * 100 : 0;
                    return (
                      <div key={pm}>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span>{t[pm] || pm}</span>
                          <span>
                            {fmtMoney(val)} ({pct.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
              <h3 className="font-bold text-slate-800 mb-3">{t.topSellingProducts}</h3>
              {breakdowns.topSelling.length === 0 ? (
                <p className="text-sm text-slate-400">{t.noAnalyticsData}</p>
              ) : (
                <div className="divide-y divide-slate-100 text-sm tabular-nums">
                  {breakdowns.topSelling.map((p, i) => (
                    <div key={p.name} className="py-2.5 flex justify-between">
                      <span>
                        <span className="font-bold text-slate-400 mr-2">#{i + 1}</span>
                        {p.name}
                      </span>
                      <span className="font-bold text-slate-800">
                        {p.qty} {t.units} · {fmtMoney(p.rev)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
              <h3 className="font-bold text-slate-800 mb-3">{t.highestProfitProducts}</h3>
              {breakdowns.topProfit.length === 0 ? (
                <p className="text-sm text-slate-400">{t.noAnalyticsData}</p>
              ) : (
                <div className="divide-y divide-slate-100 text-sm tabular-nums">
                  {breakdowns.topProfit.map((p, i) => (
                    <div key={p.name} className="py-2.5 flex justify-between">
                      <span>
                        <span className="font-bold text-slate-400 mr-2">#{i + 1}</span>
                        {p.name}
                      </span>
                      <span className="font-bold text-emerald-600">+{fmtMoney(p.profit)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/90 p-5">
            <h3 className="font-bold text-slate-800 mb-3">{t.inventoryAnalysis}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm tabular-nums">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <p className="text-xs text-slate-500">{t.costValue}</p>
                <p className="text-lg font-extrabold text-slate-800">{fmtMoney(invStats.costVal)}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <p className="text-xs text-slate-500">{t.retailValue}</p>
                <p className="text-lg font-extrabold text-indigo-600">{fmtMoney(invStats.retailVal)}</p>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100">
                <p className="text-xs text-emerald-700">{t.potentialProfit}</p>
                <p className="text-lg font-extrabold text-emerald-700">{fmtMoney(invStats.potential)}</p>
              </div>
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-100">
                <p className="text-xs text-amber-700">{t.lowStockItems}</p>
                <p className="text-lg font-extrabold text-amber-700">{invStats.lowCount}</p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
