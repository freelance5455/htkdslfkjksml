import React, { useEffect, useRef } from 'react';
import { CAR_LIST } from '../data/cars.ts';
import { TRACK_LIST } from '../data/tracks.ts';
import { CarModel, TrackId } from '../types.ts';
import { getCarCanvas } from '../utils/pixelRenderer.ts';
import { Award, Volume2, VolumeX, Tv, HelpCircle } from 'lucide-react';

interface MenuModalProps {
  selectedCar: CarModel;
  selectedTrackId: TrackId;
  highScore: number;
  isMuted: boolean;
  isCrtEnabled: boolean;
  onSelectCar: (car: CarModel) => void;
  onSelectTrack: (trackId: TrackId) => void;
  onStartGame: () => void;
  onToggleMute: () => void;
  onToggleCrt: () => void;
  onShowLeaderboard: () => void;
}

export const MenuModal: React.FC<MenuModalProps> = ({
  selectedCar,
  selectedTrackId,
  highScore,
  isMuted,
  isCrtEnabled,
  onSelectCar,
  onSelectTrack,
  onStartGame,
  onToggleMute,
  onToggleCrt,
  onShowLeaderboard
}) => {
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Redraw preview whenever car changes
  useEffect(() => {
    if (previewCanvasRef.current) {
      const cv = previewCanvasRef.current;
      const ctx = cv.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, cv.width, cv.height);
        const carCanvas = getCarCanvas(selectedCar, 4, false);
        ctx.drawImage(carCanvas, (cv.width - carCanvas.width) / 2, (cv.height - carCanvas.height) / 2);
      }
    }
  }, [selectedCar]);

  return (
    <div className="absolute inset-0 bg-gradient-to-b from-[#18002e] via-[#3a0840] to-[#12001a] z-30 flex flex-col items-center justify-between p-3 sm:p-6 overflow-y-auto">
      {/* Top Banner & Title */}
      <div className="text-center pt-2 sm:pt-4">
        <div className="flex items-center justify-center gap-2 mb-1">
          <span className="text-2xl">🇩🇿</span>
          <span className="text-amber-400 font-bold text-xs sm:text-sm tracking-widest font-press-start">
            RETRO ATARI ARCADE
          </span>
          <span className="text-2xl">🇩🇿</span>
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-amber-300 font-press-start tracking-tight arcade-text-glow leading-tight">
          CHAMSOU RACE
        </h1>
        <h2 className="text-base sm:text-xl font-black text-rose-400 font-cairo mt-1 tracking-wider arcade-text-red">
          ⚡ AMROU PC EDITION ⚡
        </h2>

        {/* High Score & Quick settings bar */}
        <div className="flex items-center justify-center gap-4 mt-3 text-xs">
          <div className="flex items-center gap-2 bg-black/50 border border-amber-500/40 px-3 py-1.5 rounded-full text-amber-200">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="font-cairo">أعلى سكور:</span>
            <span className="font-press-start text-amber-300">{highScore}</span>
          </div>

          <button
            onClick={onToggleMute}
            className="flex items-center gap-1.5 bg-black/50 hover:bg-black/70 border border-gray-700 px-3 py-1.5 rounded-full text-gray-300 hover:text-white transition-colors"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            <span className="font-cairo">{isMuted ? 'صوت مغلق' : 'صوت مفعل'}</span>
          </button>

          <button
            onClick={onToggleCrt}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-colors ${
              isCrtEnabled ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-black/50 border-gray-700 text-gray-400'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span className="font-cairo">CRT 80s</span>
          </button>
        </div>
      </div>

      {/* Main Content: Car Showcase & Track Chooser */}
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 gap-4 my-3">
        {/* Left: Car Showcase and Stats */}
        <div className="md:col-span-5 bg-black/60 border-2 border-amber-500/60 rounded-2xl p-4 flex flex-col items-center shadow-xl">
          <span className="text-xs text-amber-400 font-bold uppercase tracking-wider font-cairo mb-2">
            السيارة المختارة / SELECTED CAR
          </span>

          {/* Canvas sprite render */}
          <div className="w-36 h-36 bg-gradient-to-b from-gray-900 to-black rounded-xl border border-amber-500/30 flex items-center justify-center p-2 shadow-inner my-1">
            <canvas ref={previewCanvasRef} width={80} height={120} className="image-pixelated" />
          </div>

          <div className="text-center mt-2">
            <h3 className="text-lg font-black text-amber-300 font-press-start">{selectedCar.name}</h3>
            <p className="text-sm font-bold text-gray-200 font-cairo">{selectedCar.arabicName}</p>
            <p className="text-[11px] text-gray-400 font-cairo mt-1 leading-relaxed px-2">{selectedCar.description}</p>
          </div>

          {/* Stats Bar */}
          <div className="w-full mt-3 space-y-1.5 text-[11px]">
            <div>
              <div className="flex justify-between text-gray-300 font-cairo">
                <span>السرعة القصوى / SPEED</span>
                <span className="font-mono font-bold text-amber-300">{Math.round(selectedCar.maxSpeed * 15)} km/h</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden mt-0.5">
                <div className="h-full bg-emerald-500" style={{ width: `${(selectedCar.maxSpeed / 14) * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-gray-300 font-cairo">
                <span>التسارع / ACCELERATION</span>
                <span className="font-mono font-bold text-amber-300">{Math.round(selectedCar.acceleration * 500)}</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden mt-0.5">
                <div className="h-full bg-amber-500" style={{ width: `${(selectedCar.acceleration / 0.2) * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-gray-300 font-cairo">
                <span>التحكم والمناورة / HANDLING</span>
                <span className="font-mono font-bold text-amber-300">{selectedCar.handling}</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden mt-0.5">
                <div className="h-full bg-blue-500" style={{ width: `${(selectedCar.handling / 4.2) * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-gray-300 font-cairo">
                <span>المتانة / DURABILITY</span>
                <span className="font-mono font-bold text-amber-300">{selectedCar.health} HP</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden mt-0.5">
                <div className="h-full bg-rose-500" style={{ width: `${(selectedCar.health / 120) * 100}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Car Grid & Track Selection */}
        <div className="md:col-span-7 flex flex-col gap-3">
          {/* Cars Grid */}
          <div className="bg-black/60 border-2 border-amber-500/60 rounded-2xl p-3.5 shadow-xl">
            <span className="text-xs text-amber-400 font-bold uppercase tracking-wider font-cairo block mb-2">
              اختر سيارتك الكلاسيكية 🇩🇿
            </span>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {CAR_LIST.map((car) => {
                const isSelected = car.id === selectedCar.id;
                return (
                  <button
                    key={car.id}
                    onClick={() => onSelectCar(car)}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-black border-white scale-105 shadow-lg shadow-amber-500/40 font-bold'
                        : 'bg-black/80 hover:bg-gray-800 border-amber-500/30 text-white hover:border-amber-400'
                    }`}
                  >
                    <div className="w-8 h-12 flex items-center justify-center mb-1">
                      <div
                        className="w-5 h-9 rounded-sm shadow-sm"
                        style={{ backgroundColor: car.color, border: `2px solid ${car.accent}` }}
                      />
                    </div>
                    <span className="text-[10px] font-press-start text-center truncate w-full">{car.name}</span>
                    <span className={`text-[9px] font-cairo truncate w-full text-center ${isSelected ? 'text-gray-900 font-bold' : 'text-gray-400'}`}>
                      {car.arabicName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Track Selection */}
          <div className="bg-black/60 border-2 border-amber-500/60 rounded-2xl p-3.5 shadow-xl">
            <span className="text-xs text-amber-400 font-bold uppercase tracking-wider font-cairo block mb-2">
              اختر مسار السباق في الجزائر 🗺️
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {TRACK_LIST.map((track) => {
                const isSelected = track.id === selectedTrackId;
                return (
                  <button
                    key={track.id}
                    onClick={() => onSelectTrack(track.id)}
                    className={`p-2.5 rounded-xl border-2 text-right transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black border-white shadow-md scale-102 font-bold'
                        : 'bg-black/80 hover:bg-gray-800 border-gray-700 text-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <span>{track.id === 'sahara' ? '🏜️' : track.id === 'corniche' ? '🌊' : '🏔️'}</span>
                      <span className="text-xs font-bold font-cairo">{track.arabicName}</span>
                    </div>
                    <span className="text-[9px] font-mono text-gray-300 block">{track.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Start Button & Controls Summary */}
      <div className="flex flex-col items-center gap-2 pb-2">
        <button
          onClick={onStartGame}
          className="bg-gradient-to-r from-amber-500 via-rose-600 to-amber-500 hover:from-amber-400 hover:to-rose-500 active:scale-95 text-white font-press-start text-xl sm:text-2xl px-10 py-4 rounded-2xl border-4 border-amber-300 shadow-2xl arcade-glow-gold cursor-pointer transition-all flex items-center gap-3"
        >
          <span>▶</span>
          <span>START RACE</span>
          <span>انطلاق</span>
        </button>

        {/* Controls Reminder */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] text-gray-300 font-cairo bg-black/60 px-4 py-1.5 rounded-full border border-white/10 mt-1">
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>اللمس: دواسة البنزين والفرامل على اليسار ⛽</span>
          <span>·</span>
          <span>التوجيه يمين/يسار على اليمين ◄ ►</span>
          <span>·</span>
          <span>📱 إمالة الهاتف (Tilt)</span>
          <span>·</span>
          <span>🎵 موسيقى خفيفة</span>
        </div>

        <p className="text-[10px] text-gray-400 font-mono mt-1">
          © 2026 AMROU PC & CHAMSOU - RETRO ATARI RACING
        </p>
      </div>
    </div>
  );
};
