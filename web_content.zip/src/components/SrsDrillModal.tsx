import React, { useState } from 'react';
import {
  X,
  Brain,
  Volume2,
  Eye,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Clock,
  Layers,
  Award
} from 'lucide-react';
import { WordData, SrsItem, SrsRating } from '../types';
import { SrsEngine, EBBINGHAUS_STAGES } from '../services/srs';
import { speakWord, sound } from '../services/sound';

interface SrsDrillModalProps {
  dueWords: (WordData & { srs: SrsItem })[];
  voiceLang?: 'en-US' | 'en-GB';
  onClose: () => void;
  onRateWord: (word: string, rating: SrsRating) => void;
  onOpenWordDetail: (word: WordData) => void;
}

export const SrsDrillModal: React.FC<SrsDrillModalProps> = ({
  dueWords,
  voiceLang = 'en-US',
  onClose,
  onRateWord,
  onOpenWordDetail,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [completedList, setCompletedList] = useState<{ word: string; rating: SrsRating; newStage: number }[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  const currentItem = dueWords[currentIndex];

  const handleRate = (rating: SrsRating) => {
    if (!currentItem) return;

    // Trigger audio feedback
    if (rating === 'again') sound.wrong();
    else if (rating === 'easy') sound.triggerFloatingXp(25);
    else sound.correct();

    const { updatedItem } = SrsEngine.reviewWord(currentItem.srs, rating);

    onRateWord(currentItem.word, rating);

    setCompletedList(prev => [
      ...prev,
      { word: currentItem.word, rating, newStage: updatedItem.stage }
    ]);

    setIsFlipped(false);

    if (currentIndex + 1 < dueWords.length) {
      setCurrentIndex(c => c + 1);
    } else {
      setIsFinished(true);
      sound.triggerCelebration();
    }
  };

  // If no words are due
  if (!currentItem && !isFinished) {
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white dark:bg-[#0f172a] rounded-3xl p-6 max-w-sm w-full text-center space-y-4 border border-slate-200 dark:border-slate-800 shadow-2xl">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto text-2xl">
            🧠
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Memory Traces 100% Consolidated!
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-bengali">
              আজকের জন্য কোনো শব্দ ভোলার ঝুঁকিতে নেই। চমৎকার মেমরি রিটেনশন বজায় রেখেছেন!
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-md transition-all active:scale-95"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  // Finished Session Screen
  if (isFinished) {
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
        <div className="bg-white dark:bg-[#0f172a] rounded-3xl p-6 max-w-sm w-full space-y-5 border border-slate-200 dark:border-slate-800 shadow-2xl text-center">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 flex items-center justify-center mx-auto text-3xl shadow-lg">
            🏆
          </div>

          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-full">
              Forgetting Curve Reset Complete
            </span>
            <h3 className="text-xl font-black text-slate-900 dark:text-white mt-1">
              Memory Traces Solidified!
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-bengali">
              এবিংহাউস স্পেসড রিপিটেশন সফলভাবে সম্পন্ন হয়েছে। স্মৃতিশক্তি দীর্ঘমেয়াদী মেমরিতে স্থানান্তরিত হয়েছে।
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 text-left bg-slate-50 dark:bg-slate-900/60 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-bold">Words Reviewed</div>
              <div className="text-lg font-black text-slate-900 dark:text-white">{completedList.length} Words</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-bold">XP Gained</div>
              <div className="text-lg font-black text-amber-500">+{completedList.length * 15} XP</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm rounded-2xl shadow-[0_4px_0_0_#059669] active:translate-y-0.5 transition-all"
          >
            Return to Home Tab
          </button>
        </div>
      </div>
    );
  }

  const srs = currentItem.srs;
  const stageInfo = EBBINGHAUS_STAGES[srs.stage] || EBBINGHAUS_STAGES[0];
  const retention = srs.retentionScore;

  // Retention color coding
  let retentionColor = 'text-emerald-600 dark:text-emerald-400';
  let retentionBg = 'bg-emerald-500';
  let statusBadge = 'Stable Memory';
  if (retention < 50) {
    retentionColor = 'text-rose-600 dark:text-rose-400';
    retentionBg = 'bg-rose-500';
    statusBadge = 'Critical Decay ⚠️';
  } else if (retention < 80) {
    retentionColor = 'text-amber-600 dark:text-amber-400';
    retentionBg = 'bg-amber-500';
    statusBadge = 'Memory Fading ⚡';
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white dark:bg-[#0f172a] rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]">
        
        {/* Modal Top Bar */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                Ebbinghaus SRS Drill
                <span className="text-[10px] font-mono font-bold px-2 py-0.2 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {currentIndex + 1} / {dueWords.length}
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Active Recall Interval Training
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          
          {/* Ebbinghaus Decay Status Indicator */}
          <div className="bg-slate-50 dark:bg-slate-900/80 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  Current Retention Probability:
                </span>
              </div>
              <span className={`font-mono font-black ${retentionColor}`}>
                {retention}% ({statusBadge})
              </span>
            </div>

            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${retentionBg}`}
                style={{ width: `${retention}%` }}
              />
            </div>

            <div className="flex justify-between items-center text-[10px] text-slate-400 pt-0.5">
              <span>{stageInfo.label} ({stageInfo.desc})</span>
              <span>Stability: {srs.stability}d</span>
            </div>
          </div>

          {/* Prompt Word Showcase */}
          <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-950 text-white rounded-3xl p-6 text-center shadow-lg relative overflow-hidden space-y-3">
            <div className="flex justify-between items-center text-[10px] font-bold text-indigo-300 uppercase">
              <span className="capitalize">{currentItem.pos}</span>
              <span className="font-mono">{currentItem.ipa}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-wide">
              {currentItem.word}
            </h2>

            <div className="text-xs text-indigo-200 font-bengali">
              {currentItem.bengaliPron}
            </div>

            <div className="flex items-center justify-center gap-2 pt-1">
              <button
                onClick={() => speakWord(currentItem.word, voiceLang)}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white flex items-center gap-1 transition-all active:scale-95"
              >
                <Volume2 className="w-4 h-4 text-amber-300" /> Pronounce
              </button>

              <button
                onClick={() => onOpenWordDetail(currentItem)}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white flex items-center gap-1 transition-all active:scale-95"
              >
                Dossier
              </button>
            </div>
          </div>

          {/* Flipped Card Details (Reveal Answer) */}
          {!isFlipped ? (
            <button
              onClick={() => setIsFlipped(true)}
              className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-sm rounded-2xl shadow-[0_4px_0_0_#6b21a8] flex items-center justify-center gap-2 active:translate-y-0.5 transition-all"
            >
              <Eye className="w-4 h-4" />
              <span>Reveal Bengali Meaning & Context (উত্তর দেখুন)</span>
            </button>
          ) : (
            <div className="space-y-3 animate-fadeIn">
              {/* Meaning */}
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 font-bengali space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 block">
                  বাংলা অর্থ ও সংজ্ঞা:
                </span>
                <p className="text-base font-black text-slate-900 dark:text-white">
                  {currentItem.bengali}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-normal">
                  {currentItem.simpleDef}
                </p>
              </div>

              {/* Mnemonic Hook */}
              {currentItem.mnemonicBengali && (
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 font-bengali text-xs">
                  <strong className="text-amber-800 dark:text-amber-300 block font-bold">
                    স্মৃতি সহায়ক টেকনিক (Mnemonic):
                  </strong>
                  <span className="text-slate-700 dark:text-slate-300">
                    {currentItem.mnemonicBengali}
                  </span>
                </div>
              )}

              {/* Sample Context Sentence */}
              {currentItem.sentences?.[0] && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Context Sentence:</span>
                  <p className="italic text-slate-800 dark:text-slate-200">
                    "{currentItem.sentences[0].en}"
                  </p>
                  <p className="font-bengali text-slate-500 text-[11px]">
                    {currentItem.sentences[0].bn}
                  </p>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Ebbinghaus 4-Tier Rating Controls */}
        {isFlipped && (
          <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 space-y-2">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 text-center">
              Rate Recall Quality (স্মরণ করার সহজতা নির্বাচন করুন)
            </div>

            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => handleRate('again')}
                className="p-2.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 active:scale-95 transition-all text-center flex flex-col items-center justify-between"
              >
                <RotateCcw className="w-4 h-4 mb-1 text-rose-600" />
                <span className="text-[11px] font-extrabold leading-tight">Again</span>
                <span className="text-[9px] text-slate-400 font-mono mt-0.5">&lt; 1d</span>
              </button>

              <button
                onClick={() => handleRate('hard')}
                className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800 active:scale-95 transition-all text-center flex flex-col items-center justify-between"
              >
                <Clock className="w-4 h-4 mb-1 text-amber-600" />
                <span className="text-[11px] font-extrabold leading-tight">Hard</span>
                <span className="text-[9px] text-slate-400 font-mono mt-0.5">
                  {SrsEngine.formatInterval(Math.max(1, srs.stability * 1.3))}
                </span>
              </button>

              <button
                onClick={() => handleRate('good')}
                className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800 active:scale-95 transition-all text-center flex flex-col items-center justify-between"
              >
                <CheckCircle2 className="w-4 h-4 mb-1 text-blue-600" />
                <span className="text-[11px] font-extrabold leading-tight">Good</span>
                <span className="text-[9px] text-slate-400 font-mono mt-0.5">
                  {SrsEngine.formatInterval(EBBINGHAUS_STAGES[Math.min(6, srs.stage + 1)]?.days || 3)}
                </span>
              </button>

              <button
                onClick={() => handleRate('easy')}
                className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 active:scale-95 transition-all text-center flex flex-col items-center justify-between"
              >
                <Sparkles className="w-4 h-4 mb-1 text-emerald-600" />
                <span className="text-[11px] font-extrabold leading-tight">Easy</span>
                <span className="text-[9px] text-slate-400 font-mono mt-0.5">
                  {SrsEngine.formatInterval(EBBINGHAUS_STAGES[Math.min(6, srs.stage + 2)]?.days || 7)}
                </span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
