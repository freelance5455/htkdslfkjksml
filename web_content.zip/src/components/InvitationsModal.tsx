import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { TeamInvitation, TEAM_ROLE_LABELS } from '../types';
import { hartTeamService } from '../services/hartTeamService';
import { SmartImage } from './SmartImage';
import { X, Mail, Check, AlertCircle, Shield, ArrowRight } from 'lucide-react';

interface InvitationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefresh?: () => void;
}

export const InvitationsModal: React.FC<InvitationsModalProps> = ({
  isOpen,
  onClose,
  onRefresh
}) => {
  const { user, profile } = useAuth();
  const [invitations, setInvitations] = useState<TeamInvitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string>('');
  const [actionError, setActionError] = useState<string>('');

  useEffect(() => {
    if (!isOpen || !user) {
      setInvitations([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    // Listen to pending invitations where user is the receiver
    const q = query(
      collection(db, 'team_invitations'),
      where('receiverId', '==', user.uid),
      where('status', '==', 'pending')
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: TeamInvitation[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...(docSnap.data() as Omit<TeamInvitation, 'id'>) });
        });
        setInvitations(items);
        setLoading(false);
      },
      (err) => {
        console.error('Error fetching invitations:', err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [isOpen, user]);

  if (!isOpen || !user) return null;

  const handleRespond = async (invitation: TeamInvitation, accept: boolean) => {
    if (!profile) return;
    setActionLoadingId(invitation.id);
    setActionError('');
    setActionSuccessMsg('');

    try {
      await hartTeamService.respondToInvitation({
        invitation,
        accept,
        currentUser: profile
      });

      if (accept) {
        setActionSuccessMsg(`تهانينا! لقد انضممت بنجاح إلى فريق "${invitation.teamName}" بصفتك ${TEAM_ROLE_LABELS[invitation.role] || invitation.role}.`);
      } else {
        setActionSuccessMsg(`تم رفض دعوة الانضمام إلى فريق "${invitation.teamName}".`);
      }

      if (onRefresh) onRefresh();

      setTimeout(() => {
        setActionSuccessMsg('');
      }, 3500);
    } catch (err: any) {
      console.error('Error responding to invitation:', err);
      setActionError(err.message || 'حدث خطأ أثناء معالجة الدعوة');
    } finally {
      setActionLoadingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/5 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-900/30 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">دعوات الانضمام للفرق</h2>
              <p className="text-xs text-gray-400">
                الدعوات الرسمية المرسلة إليك من قادة ومدراء فرق الترجمة
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert */}
        {actionSuccessMsg && (
          <div className="mb-4 p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{actionSuccessMsg}</span>
          </div>
        )}

        {actionError && (
          <div className="mb-4 p-3 rounded-2xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* List of Invitations */}
        <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar pr-1">
          {loading ? (
            <div className="py-12 text-center text-xs text-gray-400">
              جاري فحص وتحديث الدعوات...
            </div>
          ) : invitations.length > 0 ? (
            invitations.map((inv) => {
              const isProcessing = actionLoadingId === inv.id;
              return (
                <div
                  key={inv.id}
                  className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 hover:border-purple-500/30 transition-all flex flex-col gap-3"
                >
                  <div className="flex items-center gap-3.5">
                    <SmartImage
                      src={inv.teamLogo || ''}
                      alt={inv.teamName}
                      fallbackText={inv.teamName}
                      containerClassName="w-12 h-12 rounded-xl border border-purple-500/30 shrink-0 bg-[#0d121f]"
                      className="w-full h-full object-cover"
                    />

                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-bold text-white truncate">{inv.teamName}</h3>
                      <div className="flex items-center gap-2 text-[11px] text-gray-400 mt-0.5">
                        <span>المرسل: <strong className="text-gray-300">{inv.senderName}</strong></span>
                        <span>•</span>
                        <span>{new Date(inv.createdAt).toLocaleDateString('ar-EG')}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end">
                      <span className="text-[10px] text-purple-300 font-bold bg-purple-950 px-2.5 py-1 rounded-lg border border-purple-800/40 flex items-center gap-1">
                        <Shield className="w-3 h-3 text-pink-400" />
                        <span>{TEAM_ROLE_LABELS[inv.role] || inv.role}</span>
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-white/5">
                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={() => handleRespond(inv, false)}
                      className="px-4 py-1.5 rounded-xl text-xs font-bold text-gray-400 hover:text-red-300 bg-white/5 hover:bg-red-950/40 border border-transparent hover:border-red-500/30 transition-all disabled:opacity-50"
                    >
                      {isProcessing ? 'جاري...' : 'رفض'}
                    </button>

                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={() => handleRespond(inv, true)}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 shadow-md shadow-purple-900/30 transition-all disabled:opacity-50"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isProcessing ? 'جاري الانضمام...' : 'قبول الدعوة والانضمام'}</span>
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-gray-400">
              <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-white/5 flex items-center justify-center text-gray-500">
                <Mail className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-gray-300 mb-1">لا توجد دعوات معلقة حالياً</p>
              <p className="text-[11px] text-gray-500 max-w-xs mx-auto">
                عندما يرسل لك قائد أو مدير فريق دعوة للانضمام باستخدام معرّفك الفريد ستظهر هنا فوراً.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/5 flex items-center justify-between mt-2">
          <span className="text-[11px] text-gray-500">
            معرّفك الفريد: <strong className="text-purple-300 font-mono">{profile?.uniqueId || user.uid.substring(0, 8)}</strong>
          </span>

          <button
            onClick={onClose}
            className="flex items-center gap-1 text-xs text-purple-400 hover:text-purple-300 font-bold"
          >
            <span>إغلاق النافذة</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
