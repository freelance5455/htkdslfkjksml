import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Tv,
  CheckCircle,
  AlertCircle,
  Sparkles,
  DollarSign,
  User,
  ArrowRight,
  TrendingUp,
  Copy,
  Layers,
  Flame,
  Radio,
} from 'lucide-react';
import {
  Sponsor,
  Talent,
  TimeSlotConfig,
  TimeSlotId,
  TVProgram,
  WeeklySchedule,
  WeeklySponsors,
} from '../types/game';
import { soundFx } from '../utils/audio';

const WEEKDAY_TABS = [
  { index: 0, short: 'Seg', name: 'Segunda-Feira', subtitle: 'Abertura da semana' },
  { index: 1, short: 'Ter', name: 'Terça-Feira', subtitle: 'Grade clássica' },
  { index: 2, short: 'Qua', name: 'Quarta-Feira', subtitle: 'Noite de futebol/filme' },
  { index: 3, short: 'Qui', name: 'Quinta-Feira', subtitle: 'Pré-fim de semana' },
  { index: 4, short: 'Sex', name: 'Sexta-Feira', subtitle: 'Linha de shows' },
  { index: 5, short: 'Sáb', name: 'Sábado Especial', subtitle: 'Auditórios & cinema' },
  { index: 6, short: 'Dom', name: 'Domingo Show', subtitle: 'Disputa de gigantes' },
];

interface SchedulePlannerProps {
  slots: TimeSlotConfig[];
  programs: TVProgram[];
  talents: Talent[];
  sponsors: Sponsor[];
  weeklySchedule: WeeklySchedule;
  weeklySponsors: WeeklySponsors;
  currentDayWeekdayIndex: number;
  onAssignProgram: (weekday: number, slotId: TimeSlotId, programId: string | null) => void;
  onAssignSponsor: (weekday: number, slotId: TimeSlotId, sponsorId: string | null) => void;
  onCopyScheduleToAllDays: (sourceWeekday: number) => void;
  onCopyScheduleToWeekdays: (sourceWeekday: number) => void;
  onCopyScheduleToWeekend: (sourceWeekday: number) => void;
  onOpenNewProduction: () => void;
}

export const SchedulePlanner: React.FC<SchedulePlannerProps> = ({
  slots,
  programs,
  talents,
  sponsors,
  weeklySchedule,
  weeklySponsors,
  currentDayWeekdayIndex,
  onAssignProgram,
  onAssignSponsor,
  onCopyScheduleToAllDays,
  onCopyScheduleToWeekdays,
  onCopyScheduleToWeekend,
  onOpenNewProduction,
}) => {
  const [selectedWeekday, setSelectedWeekday] = useState<number>(currentDayWeekdayIndex);
  const [activeSlotModal, setActiveSlotModal] = useState<TimeSlotId | null>(null);
  const [activeSponsorModal, setActiveSponsorModal] = useState<TimeSlotId | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const getProgramById = (id: string | null) => programs.find((p) => p.id === id);
  const getTalentById = (id: string | null) => talents.find((t) => t.id === id);
  const getSponsorById = (id: string | null) => sponsors.find((s) => s.id === id);

  const activeDaySchedule = weeklySchedule[selectedWeekday] || {
    morning: null,
    afternoon: null,
    primetime: null,
    latenight: null,
  };

  const activeDaySponsors = weeklySponsors[selectedWeekday] || {
    morning: null,
    afternoon: null,
    primetime: null,
    latenight: null,
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const selectedWeekdayInfo = WEEKDAY_TABS[selectedWeekday] || WEEKDAY_TABS[0];

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg border border-emerald-400 flex items-center gap-2 animate-bounce">
          <CheckCircle className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Info Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400" />
            Grade Semanal de Programação
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Programe individualmente cada dia da semana. De segunda a sexta você pode manter sua grade padrão e nos sábados e domingos escalar grandes filmes e shows!
          </p>
        </div>

        <button
          onClick={() => {
            soundFx.playClick();
            onOpenNewProduction();
          }}
          className="min-h-[44px] px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wide transition-all shadow-md shadow-amber-950/40 flex items-center gap-1.5 cursor-pointer active:scale-95"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Criar / Comprar Atração</span>
        </button>
      </div>

      {/* Weekdays Interactive Selector Pills */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-2.5 shadow-md flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            Selecione o Dia da Semana
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            Dia no ar: <strong className="text-amber-400">{WEEKDAY_TABS[currentDayWeekdayIndex].name}</strong>
          </span>
        </div>

        {/* 7 Days Button Row */}
        <div className="grid grid-cols-7 gap-1.5">
          {WEEKDAY_TABS.map((w) => {
            const isSelected = w.index === selectedWeekday;
            const isToday = w.index === currentDayWeekdayIndex;
            const daySched = weeklySchedule[w.index] || {};
            const filledSlotsCount = [
              daySched.morning,
              daySched.afternoon,
              daySched.primetime,
              daySched.latenight,
            ].filter(Boolean).length;

            return (
              <button
                key={w.index}
                onClick={() => {
                  soundFx.playClick();
                  setSelectedWeekday(w.index);
                }}
                className={`min-h-[48px] py-1.5 px-1 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer relative active:scale-95 ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-md shadow-amber-500/20'
                    : isToday
                    ? 'bg-slate-950 border-amber-500/60 text-amber-300'
                    : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                {/* On-air beacon */}
                {isToday && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                )}

                <span className="text-xs font-black uppercase leading-tight">{w.short}</span>
                <span
                  className={`text-[9px] font-mono leading-tight mt-0.5 ${
                    isSelected
                      ? 'text-slate-900 font-bold'
                      : filledSlotsCount === 4
                      ? 'text-emerald-400'
                      : filledSlotsCount > 0
                      ? 'text-amber-400'
                      : 'text-red-400'
                  }`}
                >
                  {filledSlotsCount}/4
                </span>
              </button>
            );
          })}
        </div>

        {/* Day Header & Batch Propagation Actions */}
        <div className="mt-1 pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>Editando: {selectedWeekdayInfo.name}</span>
              {selectedWeekday === currentDayWeekdayIndex && (
                <span className="px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-500 text-[10px] text-emerald-300 font-mono font-bold">
                  TRANSMITINDO HOJE
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400">{selectedWeekdayInfo.subtitle}</div>
          </div>

          {/* Fast copy shortcuts */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => {
                soundFx.playCash();
                onCopyScheduleToAllDays(selectedWeekday);
                showToast(`Grade de ${selectedWeekdayInfo.short} copiada para toda a semana!`);
              }}
              title="Copiar a programação deste dia para todos os 7 dias da semana"
              className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer active:scale-95"
            >
              <Copy className="w-3 h-3 text-amber-400" />
              <span>Copiar p/ Todos os Dias</span>
            </button>

            <button
              onClick={() => {
                soundFx.playCash();
                onCopyScheduleToWeekdays(selectedWeekday);
                showToast(`Grade aplicada de Segunda a Sexta!`);
              }}
              title="Copiar esta programação para Segunda a Sexta"
              className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer active:scale-95"
            >
              <Copy className="w-3 h-3 text-blue-400" />
              <span>Aplicar Seg-Sex</span>
            </button>

            <button
              onClick={() => {
                soundFx.playCash();
                onCopyScheduleToWeekend(selectedWeekday);
                showToast(`Grade aplicada para Sábado e Domingo!`);
              }}
              title="Copiar esta programação para Sábado e Domingo"
              className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer active:scale-95"
            >
              <Copy className="w-3 h-3 text-purple-400" />
              <span>Aplicar Fim de Semana</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Time Slots Grid for Selected Day */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {slots.map((slot) => {
          const assignedProgId = activeDaySchedule[slot.id];
          const assignedProg = getProgramById(assignedProgId);
          const assignedTalent = assignedProg ? getTalentById(assignedProg.assignedTalentId) : null;
          const assignedSponsorId = activeDaySponsors[slot.id];
          const assignedSponsor = getSponsorById(assignedSponsorId);

          const hasGenreSynergy = assignedProg && slot.idealGenres.includes(assignedProg.genre);
          const cost = assignedProg?.productionCost || 0;
          const revenue = assignedSponsor?.payoutPerSlot || 0;
          const net = revenue - cost;

          return (
            <div
              key={slot.id}
              className={`rounded-xl border p-3.5 flex flex-col justify-between transition-all shadow-md ${
                slot.id === 'primetime'
                  ? 'bg-gradient-to-br from-slate-900 via-amber-950/20 to-slate-900 border-amber-500/40 shadow-amber-950/20'
                  : 'bg-slate-900/90 border-slate-800'
              }`}
            >
              {/* Slot Header */}
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-slate-950 border border-slate-700 flex items-center justify-center text-amber-400 font-bold">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        {slot.label}
                        {slot.id === 'primetime' && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-black uppercase">
                            Disputa Pesada
                          </span>
                        )}
                      </h3>
                      <div className="text-xs font-mono text-slate-400">{slot.timeRange}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-mono text-slate-400 block">POTENCIAL PÚBLICO</span>
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      {Math.round(slot.audiencePotential * 100)}% de alcance
                    </span>
                  </div>
                </div>

                {/* Genre Synergy Advice */}
                <div className="mt-2.5 flex items-center gap-2 text-[11px] text-slate-400">
                  <span className="text-slate-400 font-semibold">Gêneros Favoritos:</span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {slot.idealGenres.map((g) => (
                      <span key={g} className="text-slate-300 font-medium capitalize">
                        {g}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Program Card in Slot */}
                <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Atração Escalada ({selectedWeekdayInfo.short})
                    </span>
                    {hasGenreSynergy ? (
                      <span className="text-[10px] font-semibold text-emerald-400 flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Sinergia +30% Audiência
                      </span>
                    ) : assignedProg ? (
                      <span className="text-[10px] text-amber-400/80 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Sinergia Regular
                      </span>
                    ) : null}
                  </div>

                  {assignedProg ? (
                    <div>
                      <div className="flex items-center justify-between gap-1">
                        <h4 className="text-sm font-bold text-white truncate max-w-[200px]">
                          {assignedProg.title}
                        </h4>
                        <div className="flex items-center gap-1 shrink-0">
                          {assignedProg.sourceChannelName && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-950 border border-red-500 text-red-300 font-bold uppercase">
                              {assignedProg.sourceChannelName}
                            </span>
                          )}
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                            {assignedProg.genre}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2.5 text-xs text-slate-400 mt-2 flex-wrap">
                        <span className="flex items-center gap-1 text-slate-300">
                          <User className="w-3.5 h-3.5 text-amber-400" />
                          {assignedTalent?.name || 'Sem apresentador'}
                        </span>
                        <span>·</span>
                        <span>Qualidade: {assignedProg.quality}%</span>
                        <span>·</span>
                        <span className={assignedProg.productionCost === 0 ? 'text-emerald-400 font-bold' : ''}>
                          Custo: {assignedProg.productionCost === 0 ? 'GRÁTIS (Canal do Grupo)' : `R$ ${assignedProg.productionCost.toLocaleString('pt-BR')}`}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="py-2 text-center text-xs text-red-400/90 italic">
                      Nenhum programa no ar nesta faixa em {selectedWeekdayInfo.name}! A emissora perderá audiência.
                    </div>
                  )}

                  <div className="mt-3 flex items-center justify-end gap-2 pt-2 border-t border-slate-800/60">
                    <button
                      onClick={() => {
                        soundFx.playClick();
                        setActiveSlotModal(slot.id);
                      }}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer active:scale-95"
                    >
                      {assignedProg ? 'Trocar Programa' : 'Escalar Programa'}
                    </button>
                    {assignedProg && (
                      <button
                        onClick={() => {
                          soundFx.playClick();
                          onAssignProgram(selectedWeekday, slot.id, null);
                        }}
                        className="min-h-[38px] px-2 py-1.5 text-xs text-red-400 hover:text-red-300 cursor-pointer"
                      >
                        Remover
                      </button>
                    )}
                  </div>
                </div>

                {/* Sponsor Card in Slot */}
                <div className="mt-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Cota de Patrocínio ({selectedWeekdayInfo.short})
                    </span>
                    <button
                      onClick={() => {
                        soundFx.playClick();
                        setActiveSponsorModal(slot.id);
                      }}
                      className="text-xs text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                    >
                      {assignedSponsor ? 'Alterar' : 'Vincular Cota'}
                    </button>
                  </div>

                  {assignedSponsor ? (
                    <div className="flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: assignedSponsor.logoColor }}
                          />
                          {assignedSponsor.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Meta: {assignedSponsor.targetRating.toFixed(1)} pts IBOPE
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-emerald-400">
                          + R$ {assignedSponsor.payoutPerSlot.toLocaleString('pt-BR')}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          Restam {assignedSponsor.contractDaysRemaining} dias
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-slate-500 italic">
                      Nenhum anúncio veiculado neste horário de {selectedWeekdayInfo.short}.
                    </div>
                  )}
                </div>
              </div>

              {/* Slot Financial Bottom Strip */}
              <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Balanço deste Bloco:</span>
                <span
                  className={`font-mono font-bold ${
                    net >= 0 ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {net >= 0 ? '+' : ''} R$ {net.toLocaleString('pt-BR')}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Program Selector Modal */}
      {activeSlotModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-6 shadow-2xl flex flex-col max-h-[88vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">
                  Escalar para {selectedWeekdayInfo.name} ({slots.find((s) => s.id === activeSlotModal)?.label})
                </h3>
                <p className="text-xs text-slate-400">
                  Selecione uma atração do seu acervo ou retransmita dos canais do grupo
                </p>
              </div>
              <button
                onClick={() => setActiveSlotModal(null)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer px-2 py-1"
              >
                Fechar
              </button>
            </div>

            <div className="overflow-y-auto space-y-2.5 my-3 pr-1">
              {programs.map((prog) => {
                const isCurrentSlot = activeDaySchedule[activeSlotModal] === prog.id;
                const talent = getTalentById(prog.assignedTalentId);

                return (
                  <div
                    key={prog.id}
                    onClick={() => {
                      soundFx.playClick();
                      onAssignProgram(selectedWeekday, activeSlotModal, prog.id);
                      setActiveSlotModal(null);
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isCurrentSlot
                        ? 'border-amber-400 bg-amber-500/10'
                        : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white text-sm">{prog.title}</span>
                        {prog.sourceChannelName && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-red-950 border border-red-500 text-red-300 font-bold uppercase">
                            {prog.sourceChannelName}
                          </span>
                        )}
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono uppercase">
                          {prog.genre}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                        <span>Apresentador: {talent?.name || 'Nenhum'}</span>
                        <span>·</span>
                        <span>Qualidade: {prog.quality}%</span>
                        <span>·</span>
                        <span className={prog.productionCost === 0 ? 'text-emerald-400 font-bold' : ''}>
                          Custo: {prog.productionCost === 0 ? 'GRÁTIS (Canal do Grupo)' : `R$ ${prog.productionCost.toLocaleString('pt-BR')}`}
                        </span>
                      </div>
                    </div>

                    <button className="min-h-[38px] px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0 cursor-pointer">
                      {isCurrentSlot ? 'Manter' : 'Selecionar'}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
              <button
                onClick={() => {
                  soundFx.playClick();
                  onOpenNewProduction();
                  setActiveSlotModal(null);
                }}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                + Criar / Comprar Nova Produção
              </button>
              <button
                onClick={() => setActiveSlotModal(null)}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-slate-800 text-xs text-slate-200 cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sponsor Selector Modal */}
      {activeSponsorModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-6 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                Vincular Cota ({selectedWeekdayInfo.short} - {slots.find((s) => s.id === activeSponsorModal)?.label})
              </h3>
              <button
                onClick={() => setActiveSponsorModal(null)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer px-2 py-1"
              >
                Fechar
              </button>
            </div>

            <div className="overflow-y-auto space-y-2.5 my-3 pr-1">
              {sponsors.map((sp) => {
                const isSelected = activeDaySponsors[activeSponsorModal] === sp.id;
                return (
                  <div
                    key={sp.id}
                    onClick={() => {
                      soundFx.playClick();
                      onAssignSponsor(selectedWeekday, activeSponsorModal, isSelected ? null : sp.id);
                      setActiveSponsorModal(null);
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-emerald-400 bg-emerald-500/10'
                        : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: sp.logoColor }}
                        />
                        <span className="font-bold text-white text-sm">{sp.name}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        {sp.productType} · Meta mínima: {sp.targetRating.toFixed(1)} pts IBOPE
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono font-bold text-emerald-400 text-sm">
                        + R$ {sp.payoutPerSlot.toLocaleString('pt-BR')}
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {isSelected ? 'Cota Atribuída' : 'Clique para Vincular'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveSponsorModal(null)}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-slate-800 text-xs text-slate-200 cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
