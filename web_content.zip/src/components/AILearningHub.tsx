import React, { useState } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  ChevronRight, 
  Award, 
  Target, 
  Flame, 
  Zap, 
  Brain, 
  CheckCircle2, 
  ArrowRight, 
  TrendingUp, 
  SlidersHorizontal, 
  RotateCcw,
  Search,
  Filter,
  Layers
} from 'lucide-react';
import { ExamType, Language, UserProfile } from '../types';
import { SUBJECT_SYLLABUS_MAP, SubjectSyllabus, getSubjectSyllabus } from '../data/subjectSyllabusData';
import { COMPETITIVE_EXAM_SUBJECTS, CompetitiveSubject } from '../data/competitiveSubjects';
import SubjectDetailView from './SubjectDetailView';
import SubjectSelectionModal from './SubjectSelectionModal';

interface AILearningHubProps {
  language: Language;
  targetExam: string;
  setTargetExam?: (exam: ExamType) => void;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
  onIncrementQuestion?: () => void;
  onNavigateToTab?: (tab: string) => void;
}

export default function AILearningHub({
  language,
  targetExam,
  setTargetExam,
  userProfile,
  setUserProfile,
  onIncrementQuestion,
  onNavigateToTab
}: AILearningHubProps) {
  // If user tapped on a specific subject, render the deep SubjectDetailView
  const [selectedSubjectKey, setSelectedSubjectKey] = useState<string | null>(null);
  const [showSubjectModal, setShowSubjectModal] = useState<boolean>(false);
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const activeTargetExam = userProfile?.targetExam || targetExam || 'SSC CHSL';

  // Standard subjects list
  const selectedSubjects = userProfile?.selectedSubjects && userProfile.selectedSubjects.length > 0
    ? userProfile.selectedSubjects
    : COMPETITIVE_EXAM_SUBJECTS.map(s => s.id);

  const handleSelectSubject = (subKey: string) => {
    setSelectedSubjectKey(subKey);
  };

  const handleSaveSubjects = (newSubjects: string[]) => {
    if (setUserProfile && userProfile) {
      const updated: UserProfile = {
        ...userProfile,
        selectedSubjects: newSubjects
      };
      setUserProfile(updated);
      try {
        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      } catch (e) {}
    }
  };

  // If a subject is currently selected, render the dedicated Subject Page
  if (selectedSubjectKey) {
    return (
      <SubjectDetailView
        subjectKey={selectedSubjectKey}
        targetExam={activeTargetExam}
        language={language}
        userProfile={userProfile}
        onBack={() => setSelectedSubjectKey(null)}
        onIncrementQuestion={onIncrementQuestion}
      />
    );
  }

  // Filter all competitive subjects by category and search
  const categories = [
    { id: 'all', labelBn: `সকল বিষয় (${COMPETITIVE_EXAM_SUBJECTS.length})`, labelEn: `All Subjects (${COMPETITIVE_EXAM_SUBJECTS.length})` },
    { id: 'general_studies', labelBn: 'জিকে ও রাষ্ট্রবিজ্ঞান', labelEn: 'GS & Polity' },
    { id: 'science', labelBn: 'সাধারণ বিজ্ঞান', labelEn: 'General Science' },
    { id: 'aptitude', labelBn: 'গণিত ও রিজনিং', labelEn: 'Math & Reasoning' },
    { id: 'gk_current', labelBn: 'কারেন্ট ও স্ট্যাটিক জিকে', labelEn: 'Current & Static GK' }
  ];

  const filteredSubjects = COMPETITIVE_EXAM_SUBJECTS.filter(s => {
    const matchesCategory = categoryFilter === 'all' || s.category === categoryFilter;
    if (!matchesCategory) return false;

    if (!searchFilter.trim()) return true;
    const term = searchFilter.toLowerCase();
    return s.nameEn.toLowerCase().includes(term) ||
           s.nameBn.toLowerCase().includes(term) ||
           s.id.toLowerCase().includes(term);
  });

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 text-slate-100 p-4 md:p-8 space-y-6 font-sans">
      
      {/* 1. AI LEARNING HUB HERO HEADER */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border border-indigo-700/40 p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-purple-500/10 via-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-500/20 to-indigo-500/20 border border-purple-500/30 text-purple-300 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>Learn • Practice • Revise • Unlimited Q&A</span>
            </div>

            <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
              <span>{language === 'bn' ? 'শিক্ষা হাব (AI Learning Hub)' : 'AI Learning Hub'}</span>
            </h1>

            <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
              {language === 'bn' 
                ? 'পরীক্ষার সমস্ত বিষয়ের পূর্ণাঙ্গ সিলেবাস, এআই কনসেপ্ট নোটস এবং প্রতিটি অধ্যায়ে আনলিমিটেড প্রশ্নোত্তর অনুশীলন।' 
                : 'Comprehensive syllabus for all competitive subjects with AI concept lessons and unlimited dynamic Q&A practice.'}
            </p>

            {/* Target Exam Indicator & Switcher */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 bg-slate-900/90 border border-indigo-500/40 px-3.5 py-1.5 rounded-xl text-xs font-bold text-slate-200">
                <Target className="w-4 h-4 text-indigo-400" />
                <span>
                  {language === 'bn' ? 'টার্গেট পরীক্ষা: ' : 'Target Exam: '}
                  <strong className="text-amber-300">{activeTargetExam}</strong>
                </span>
              </div>

              {setTargetExam && (
                <select
                  value={activeTargetExam}
                  onChange={(e) => {
                    const newExam = e.target.value as ExamType;
                    setTargetExam(newExam);
                    if (setUserProfile && userProfile) {
                      const updated = { ...userProfile, targetExam: newExam };
                      setUserProfile(updated);
                      try { localStorage.setItem('edumind_user_profile', JSON.stringify(updated)); } catch(e){}
                    }
                  }}
                  className="bg-slate-900 border border-slate-700 text-indigo-300 text-xs font-bold rounded-xl px-3 py-1.5 cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="SSC CHSL">SSC CHSL</option>
                  <option value="SSC CGL">SSC CGL</option>
                  <option value="SSC MTS">SSC MTS / GD</option>
                  <option value="WBCS Prelims">WBCS Prelims</option>
                  <option value="WBP Constable">WBP Constable / SI</option>
                  <option value="Kolkata Police">Kolkata Police</option>
                  <option value="RRB NTPC">Railway RRB NTPC</option>
                  <option value="RRB Group D">Railway Group D</option>
                  <option value="IBPS Clerk">Banking IBPS / SBI</option>
                  <option value="WB Primary TET">WB Primary TET</option>
                </select>
              )}
            </div>
          </div>

          {/* Quick Hub Stats Card */}
          <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4 md:p-5 flex flex-col gap-3 min-w-[240px]">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-bold">{language === 'bn' ? 'উপলব্ধ বিষয়' : 'Available Subjects'}</span>
              <span className="text-emerald-400 font-black">{COMPETITIVE_EXAM_SUBJECTS.length} Subjects</span>
            </div>

            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-400 h-2 rounded-full w-[100%]" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-center text-xs pt-1">
              <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">{language === 'bn' ? 'প্রশ্নব্যাংক' : 'Practice Bank'}</span>
                <strong className="text-amber-300 font-black text-sm">{language === 'bn' ? 'আনলিমিটেড ∞' : 'Unlimited ∞'}</strong>
              </div>
              <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">{language === 'bn' ? 'অধ্যায় সংখ্যা' : 'Syllabus Chapters'}</span>
                <strong className="text-indigo-300 font-black text-sm">120+</strong>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. SUBJECTS SECTION HEADER & FILTER */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg md:text-xl font-black text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              {language === 'bn' ? 'সকল পরীক্ষার বিষয়সমূহ (All Subjects)' : 'Complete Subject Library'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'bn' 
                ? 'পরীক্ষা বাটনে থাকা সমস্ত বিষয় এখানে অন্তর্ভুক্ত — যে কোনো বিষয়ে ক্লিক করে আনলিমিটেড প্রশ্ন অনুশীলন করুন' 
                : 'All subjects from Exam Center with complete syllabus chapters and unlimited Q&A.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={language === 'bn' ? 'বিষয় খুঁজুন...' : 'Search subject...'}
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-xs text-slate-200 pl-8 pr-3 py-1.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 w-36 sm:w-48"
              />
            </div>

            <button
              onClick={() => setShowSubjectModal(true)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all shrink-0"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">{language === 'bn' ? 'বিষয় বাছুন' : 'Filter'}</span>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
          {categories.map(cat => {
            const isSelected = categoryFilter === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer shrink-0 border ${
                  isSelected 
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30' 
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                {language === 'bn' ? cat.labelBn : cat.labelEn}
              </button>
            );
          })}
        </div>

        {/* 3. INTERACTIVE SUBJECT CARDS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSubjects.map((sub) => {
            const syllabusData = getSubjectSyllabus(sub.id);
            const chapterCount = syllabusData.topics.length || 6;
            const currentChapterName = language === 'bn' ? sub.chapterHintBn : sub.chapterHintEn;

            return (
              <div
                key={sub.id}
                onClick={() => handleSelectSubject(sub.id)}
                className="bg-slate-900 border border-slate-800 hover:border-indigo-500/80 rounded-3xl p-5 md:p-6 transition-all duration-300 hover:scale-[1.01] flex flex-col justify-between shadow-xl group relative overflow-hidden cursor-pointer"
              >
                {/* Background soft glow */}
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none group-hover:bg-indigo-500/20 transition-colors" />

                <div className="space-y-4 relative z-10">
                  {/* Card Header: Emoji + Subject Name + Category */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-slate-950/90 border border-slate-800 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                        {sub.icon}
                      </div>
                      <div>
                        <h3 className="font-black text-sm md:text-base text-white group-hover:text-indigo-200 transition-colors">
                          {language === 'bn' ? sub.nameBn : sub.nameEn}
                        </h3>
                        <span className="text-[11px] text-slate-400 font-semibold block mt-0.5">
                          {sub.category.replace('_', ' ')} • {chapterCount} {language === 'bn' ? 'অধ্যায়' : 'Chapters'}
                        </span>
                      </div>
                    </div>

                    <span className="px-2.5 py-1 bg-indigo-950/60 border border-indigo-500/30 rounded-xl text-xs font-black text-indigo-300 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      <span>{sub.totalQsHint || 500}+ Qs</span>
                    </span>
                  </div>

                  {/* Chapter Hint Box */}
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-3 space-y-1">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-300 flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-indigo-400" />
                      {language === 'bn' ? 'গুরুত্বপূর্ণ অধ্যায় ও সিলেবাস:' : 'Key Syllabus Topics:'}
                    </span>
                    <p className="text-xs font-bold text-slate-200 line-clamp-1">
                      {currentChapterName}
                    </p>
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-4 mt-3 border-t border-slate-800/80 relative z-10 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 group-hover:text-indigo-300 transition-colors">
                    {language === 'bn' ? 'আনলিমিটেড প্রশ্নোত্তর অনুশীলন' : 'Unlimited Practice & Notes'}
                  </span>
                  <div className="p-2 rounded-xl bg-indigo-600/20 group-hover:bg-indigo-600 text-indigo-300 group-hover:text-white transition-all">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. QUICK REVISION & MISTAKES BANK */}
      <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/60 border border-slate-800 rounded-3xl p-5 md:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-purple-500/20 text-purple-300 rounded-2xl shrink-0">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm md:text-base font-black text-white">
              {language === 'bn' ? 'স্মার্ট রিভিশন ও ভুল খাতা (Mistakes Bank)' : 'Smart Spaced Revision & Mistakes Bank'}
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'bn' 
                ? 'যে বিষয়গুলিতে অতীতে ভুল হয়েছে তা এআই স্পেসড রিপিটেশনের মাধ্যমে পুনরায় ঝালিয়ে নিন।' 
                : 'Revisit past mistakes with step-by-step AI solutions and concept refreshers.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => handleSelectSubject('Reasoning')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl cursor-pointer transition-all shadow-lg shadow-indigo-600/30"
          >
            {language === 'bn' ? 'রিভিশন শুরু করুন' : 'Start Revision'}
          </button>
        </div>
      </div>

      {/* Subject Selection Modal */}
      {showSubjectModal && (
        <SubjectSelectionModal
          language={language}
          selectedSubjects={selectedSubjects}
          onSave={handleSaveSubjects}
          onClose={() => setShowSubjectModal(false)}
        />
      )}

    </div>
  );
}
