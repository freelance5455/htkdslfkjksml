import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bell,
  Bot,
  ChevronLeft,
  ChevronRight,
  Globe2,
  History,
  House,
  Menu,
  Newspaper,
  RefreshCw,
  Search,
  Settings,
  Star,
  Trophy,
  ChartColumn,
} from "lucide-react";
import { LEAGUES, SUGGESTED_CLUBS, leagueById, type SuggestedClub } from "@/lib/football/catalog";
import { askAssistant, fetchBoard, fetchH2H, fetchHome, fetchLeague, fetchMatch, fetchPlayer, fetchSearch, fetchTeam } from "@/lib/football/api";
import { readCache, writeCache } from "@/lib/football/cache";
import { copy } from "@/lib/football/i18n";
import { estimate } from "@/lib/football/predict";
import type { Fixture, HomePayload, Lang, LeaguePayload, MatchPayload, PlayerPayload, SearchHit, StandingRow, TeamPayload } from "@/lib/football/types";
import { Crest, Empty, Freshness, MatchCard, SectionTitle, StandingTable, formatWhen } from "./ui";

type Fav = SuggestedClub;
type Recent = { kind: string; id: string; leagueId?: string; teamId?: string; title: string; logo: string | null };
type Prefs = {
  lang: Lang;
  mode: "dark" | "light";
  theme: "green" | "blue" | "purple" | "orange";
  font: "sm" | "md" | "lg";
  favs: Fav[];
  favLeagues: string[];
  recent: Recent[];
  notify: boolean;
};

type Screen =
  | { name: "home" | "matches" | "leagues" | "insights" | "ai" | "news" | "settings" | "search" | "favorites" | "nations" | "history" }
  | { name: "league"; id: string }
  | { name: "match"; leagueId: string; id: string }
  | { name: "team"; leagueId: string; id: string }
  | { name: "player"; leagueId: string; id: string; teamId?: string };

const PREFS_KEY = "fap-prefs-v1";
const DEFAULT_PREFS: Prefs = {
  lang: "ar",
  mode: "dark",
  theme: "green",
  font: "md",
  favs: [],
  favLeagues: ["eng.1", "ksa.1", "egy"],
  recent: [],
  notify: false,
};

function loadPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return DEFAULT_PREFS;
    return { ...DEFAULT_PREFS, ...(JSON.parse(raw) as Partial<Prefs>) };
  } catch {
    return DEFAULT_PREFS;
  }
}

function ymd(date = new Date()) {
  return `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
}

function shift(days: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return ymd(date);
}

function leagueName(id: string, lang: Lang) {
  const league = leagueById(id);
  if (!league) return id;
  return lang === "ar" ? league.nameAr : league.nameEn;
}

export function FootballApp() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [ready, setReady] = useState(false);
  const [stack, setStack] = useState<Screen[]>([{ name: "home" }]);
  const [menu, setMenu] = useState(false);
  const [bell, setBell] = useState(false);
  const [home, setHome] = useState<HomePayload | null>(null);
  const [homeAt, setHomeAt] = useState<string>();
  const [homeStale, setHomeStale] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const screen = stack[stack.length - 1];
  const t = copy(prefs.lang);
  const seen = useRef(new Set<string>());
  const booted = useRef(false);

  useEffect(() => {
    const stored = loadPrefs();
    setPrefs(stored);
    const cached = readCache<HomePayload>("home");
    if (cached) {
      setHome(cached.data);
      setHomeAt(cached.at);
      setHomeStale(true);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    root.lang = prefs.lang;
    root.dir = prefs.lang === "ar" ? "rtl" : "ltr";
    root.classList.toggle("light", prefs.mode === "light");
    root.classList.remove("theme-blue", "theme-purple", "theme-orange");
    if (prefs.theme !== "green") root.classList.add(`theme-${prefs.theme}`);
    root.classList.remove("font-sm", "font-lg");
    if (prefs.font === "sm") root.classList.add("font-sm");
    if (prefs.font === "lg") root.classList.add("font-lg");
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    } catch {
      /* ignore */
    }
  }, [prefs, ready]);

  const savePrefs = (patch: Partial<Prefs>) => setPrefs((prev) => ({ ...prev, ...patch }));

  const remember = (item: Recent) => {
    setPrefs((prev) => ({
      ...prev,
      recent: [item, ...prev.recent.filter((r) => !(r.kind === item.kind && r.id === item.id))].slice(0, 12),
    }));
  };

  const open = (next: Screen) => setStack((prev) => [...prev, next]);
  const tab = (name: Screen["name"]) => setStack([{ name } as Screen]);
  const back = () => setStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));

  const loadHome = useCallback(async (force = false) => {
    if (!force) {
      const cached = readCache<HomePayload>("home");
      if (cached && Date.now() - new Date(cached.at).getTime() < 45_000) {
        setHome(cached.data);
        setHomeAt(cached.at);
        setHomeStale(false);
        return;
      }
    }
    setBusy(true);
    setError("");
    try {
      const data = await fetchHome({ data: { today: ymd(), tomorrow: shift(1) } });
      setHome(data);
      setHomeAt(data.updatedAt);
      setHomeStale(Boolean(data.stale));
      if (!data.stale && !data.error) writeCache("home", data);
      if (data.error) setError(t.failed);
    } catch {
      const cached = readCache<HomePayload>("home");
      if (cached) {
        setHome(cached.data);
        setHomeAt(cached.at);
        setHomeStale(true);
      }
      setError(t.offline);
    } finally {
      setBusy(false);
    }
  }, [t.failed, t.offline]);

  useEffect(() => {
    if (!ready) return;
    void loadHome(true);
  }, [ready, loadHome]);

  useEffect(() => {
    if (!ready) return;
    const tick = window.setInterval(() => {
      if (document.visibilityState !== "visible") return;
      void loadHome(false);
    }, 60_000);
    const onVis = () => {
      if (document.visibilityState === "visible") void loadHome(false);
    };
    const onNet = () => {
      if (navigator.onLine) void loadHome(true);
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("online", onNet);
    return () => {
      window.clearInterval(tick);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("online", onNet);
    };
  }, [ready, loadHome]);

  useEffect(() => {
    if (!home || !prefs.notify || typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const interesting = [...home.live, ...home.today].filter((m) =>
      prefs.favs.some((f) => f.id === m.home.id || f.id === m.away.id),
    );
    for (const match of interesting) {
      const key = `${match.id}:${match.status}:${match.home.score}:${match.away.score}`;
      if (!booted.current) {
        seen.current.add(key);
        continue;
      }
      if (seen.current.has(key)) continue;
      seen.current.add(key);
      const title = `${match.home.name} ${match.home.score ?? ""}-${match.away.score ?? ""} ${match.away.name}`;
      try {
        new Notification(title, { body: match.statusText });
      } catch {
        /* denied at runtime */
      }
    }
    booted.current = true;
  }, [home, prefs.favs, prefs.notify]);

  const alerts = useMemo(() => {
    if (!home) return [] as Fixture[];
    const soon = Date.now() + 2 * 3600_000;
    return [...home.live, ...home.today, ...home.upcoming].filter((m) => {
      const fav = prefs.favs.some((f) => f.id === m.home.id || f.id === m.away.id);
      const start = new Date(m.kickoff).getTime();
      return fav && (m.status === "in" || (m.status === "pre" && start < soon));
    }).slice(0, 8);
  }, [home, prefs.favs]);

  if (!ready) return <main className="p-6 text-sm text-muted">{t.loading}</main>;

  return (
    <div className="mx-auto min-h-screen max-w-3xl bg-bg pb-24 text-fg">
      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-surface px-3 py-3">
        {stack.length > 1 ? (
          <button type="button" aria-label={t.back} onClick={back} className="grid size-10 place-items-center rounded-full border border-line">
            {prefs.lang === "ar" ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
          </button>
        ) : (
          <span className="grid size-10 place-items-center rounded-full bg-accent text-sm font-black text-onaccent">FA</span>
        )}
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-black tracking-wide">{t.app}</div>
          <Freshness at={homeAt} stale={homeStale} busy={busy} t={t} lang={prefs.lang} />
        </div>
        <button type="button" aria-label={t.notificationsTitle} onClick={() => setBell(true)} className="relative grid size-10 place-items-center rounded-full border border-line">
          <Bell className="size-5" />
          {alerts.length ? <span className="absolute top-1 end-1 size-2 rounded-full bg-live" /> : null}
        </button>
        <button type="button" aria-label={t.search} onClick={() => tab("search")} className="grid size-10 place-items-center rounded-full border border-line">
          <Search className="size-5" />
        </button>
        <button type="button" aria-label="menu" onClick={() => setMenu(true)} className="grid size-10 place-items-center rounded-full border border-line">
          <Menu className="size-5" />
        </button>
      </header>

      {error ? <p className="mx-4 mt-3 rounded-xl border border-line bg-surface px-3 py-2 text-sm text-warn">{error}</p> : null}

      {screen.name === "home" && (
        <HomeScreen
          home={home}
          prefs={prefs}
          t={t}
          busy={busy}
          onRefresh={() => void loadHome(true)}
          onMatch={(m) => open({ name: "match", leagueId: m.leagueId, id: m.id })}
          onLeague={(id) => {
            remember({ kind: "league", id, title: leagueName(id, prefs.lang), logo: leagueById(id)?.logo ?? null });
            open({ name: "league", id });
          }}
          onTeam={(leagueId, id, name, logo) => {
            remember({ kind: "team", id, leagueId, title: name, logo });
            open({ name: "team", leagueId, id });
          }}
        />
      )}
      {screen.name === "matches" && (
        <MatchesScreen
          lang={prefs.lang}
          t={t}
          onMatch={(m) => open({ name: "match", leagueId: m.leagueId, id: m.id })}
        />
      )}
      {screen.name === "leagues" && (
        <LeagueList
          title={t.leagues}
          leagues={LEAGUES}
          lang={prefs.lang}
          favs={prefs.favLeagues}
          onToggle={(id) =>
            savePrefs({
              favLeagues: prefs.favLeagues.includes(id) ? prefs.favLeagues.filter((x) => x !== id) : [...prefs.favLeagues, id],
            })
          }
          onOpen={(id) => {
            remember({ kind: "league", id, title: leagueName(id, prefs.lang), logo: leagueById(id)?.logo ?? null });
            open({ name: "league", id });
          }}
        />
      )}
      {screen.name === "league" && (
        <LeagueScreen
          id={screen.id}
          lang={prefs.lang}
          t={t}
          onMatch={(m) => open({ name: "match", leagueId: m.leagueId, id: m.id })}
          onTeam={(id) => open({ name: "team", leagueId: screen.id, id })}
          onPlayer={(playerId, teamId) => open({ name: "player", leagueId: screen.id, id: playerId, teamId })}
        />
      )}
      {screen.name === "match" && (
        <MatchScreen leagueId={screen.leagueId} id={screen.id} lang={prefs.lang} t={t} onTeam={(id) => open({ name: "team", leagueId: screen.leagueId, id })} />
      )}
      {screen.name === "team" && (
        <TeamScreen
          leagueId={screen.leagueId}
          id={screen.id}
          lang={prefs.lang}
          t={t}
          fav={prefs.favs.some((f) => f.id === screen.id)}
          onFav={(club) =>
            savePrefs({
              favs: prefs.favs.some((f) => f.id === club.id) ? prefs.favs.filter((f) => f.id !== club.id) : [...prefs.favs, club],
            })
          }
          onMatch={(m) => open({ name: "match", leagueId: m.leagueId, id: m.id })}
          onPlayer={(playerId) => open({ name: "player", leagueId: screen.leagueId, id: playerId, teamId: screen.id })}
        />
      )}
      {screen.name === "player" && <PlayerScreen leagueId={screen.leagueId} id={screen.id} teamId={screen.teamId} lang={prefs.lang} t={t} />}
      {screen.name === "insights" && (
        <InsightsScreen
          lang={prefs.lang}
          t={t}
          onMatch={(m) => open({ name: "match", leagueId: m.leagueId, id: m.id })}
          onPlayer={(leagueId, playerId, teamId) => open({ name: "player", leagueId, id: playerId, teamId })}
        />
      )}
      {screen.name === "ai" && <AiScreen lang={prefs.lang} t={t} />}
      {screen.name === "news" && <NewsScreen home={home} lang={prefs.lang} t={t} />}
      {screen.name === "settings" && <SettingsScreen prefs={prefs} t={t} onChange={savePrefs} />}
      {screen.name === "search" && (
        <SearchScreen
          lang={prefs.lang}
          t={t}
          onLeague={(id) => open({ name: "league", id })}
          onTeam={(leagueId, id) => open({ name: "team", leagueId, id })}
          onPlayer={(leagueId, id) => open({ name: "player", leagueId, id })}
        />
      )}
      {screen.name === "favorites" && (
        <FavoritesScreen
          prefs={prefs}
          t={t}
          onTeam={(f) => open({ name: "team", leagueId: f.leagueId, id: f.id })}
          onLeague={(id) => open({ name: "league", id })}
          onAdd={(club) => savePrefs({ favs: prefs.favs.some((f) => f.id === club.id) ? prefs.favs : [...prefs.favs, club] })}
        />
      )}
      {screen.name === "nations" && (
        <LeagueList
          title={t.nations}
          leagues={LEAGUES.filter((l) => l.national)}
          lang={prefs.lang}
          favs={prefs.favLeagues}
          onToggle={(id) =>
            savePrefs({
              favLeagues: prefs.favLeagues.includes(id) ? prefs.favLeagues.filter((x) => x !== id) : [...prefs.favLeagues, id],
            })
          }
          onOpen={(id) => open({ name: "league", id })}
        />
      )}
      {screen.name === "history" && (
        <HistoryScreen
          items={prefs.recent}
          t={t}
          onOpen={(item) => {
            if (item.kind === "league") open({ name: "league", id: item.id });
            else if (item.kind === "team" && item.leagueId) open({ name: "team", leagueId: item.leagueId, id: item.id });
            else if (item.kind === "match" && item.leagueId) open({ name: "match", leagueId: item.leagueId, id: item.id });
            else if (item.kind === "player" && item.leagueId) open({ name: "player", leagueId: item.leagueId, id: item.id, teamId: item.teamId });
          }}
        />
      )}

      {menu && (
        <button type="button" className="fixed inset-0 z-30 bg-bg/70" onClick={() => setMenu(false)}>
          <div className="absolute inset-x-4 bottom-24 rounded-2xl border border-line bg-surface p-2 text-start" onClick={(e) => e.stopPropagation()}>
            {[
              ["news", t.news],
              ["settings", t.settings],
              ["nations", t.nations],
              ["favorites", t.favorites],
              ["history", t.history],
            ].map(([name, label]) => (
              <button
                key={name}
                type="button"
                className="block w-full rounded-xl px-3 py-3 text-start hover:bg-surface-2"
                onClick={() => {
                  setMenu(false);
                  tab(name as Screen["name"]);
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </button>
      )}
      {bell && (
        <button type="button" className="fixed inset-0 z-30 bg-bg/70" onClick={() => setBell(false)}>
          <div className="absolute inset-x-4 top-20 rounded-2xl border border-line bg-surface p-3 text-start" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-2 font-bold">{t.notificationsTitle}</h2>
            {alerts.length === 0 ? <Empty text={t.noAlerts} /> : alerts.map((m) => (
              <div key={m.id} className="border-t border-line py-2 text-sm">
                {m.home.name} {m.home.score ?? ""}–{m.away.score ?? ""} {m.away.name}
                <div className="text-xs text-muted">{m.statusText} · {formatWhen(m.kickoff, prefs.lang)}</div>
              </div>
            ))}
            <p className="mt-2 text-xs text-muted">{t.notifyHint}</p>
          </div>
        </button>
      )}

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface">
        <div className="mx-auto flex max-w-3xl">
          {[
            ["home", t.home, House],
            ["matches", t.matches, Globe2],
            ["leagues", t.leagues, Trophy],
            ["insights", t.insights, ChartColumn],
            ["ai", t.assistant, Bot],
          ].map(([name, label, Icon]) => {
            const active = screen.name === name;
            const Glyph = Icon as typeof House;
            return (
              <button key={String(name)} type="button" onClick={() => tab(name as Screen["name"])} className={`flex flex-1 flex-col items-center gap-1 py-2 text-xs ${active ? "text-accent" : "text-muted"}`}>
                <Glyph className="size-5" />
                {String(label)}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function HomeScreen({
  home,
  prefs,
  t,
  busy,
  onRefresh,
  onMatch,
  onLeague,
  onTeam,
}: {
  home: HomePayload | null;
  prefs: Prefs;
  t: ReturnType<typeof copy>;
  busy: boolean;
  onRefresh: () => void;
  onMatch: (m: Fixture) => void;
  onLeague: (id: string) => void;
  onTeam: (leagueId: string, id: string, name: string, logo: string | null) => void;
}) {
  const lang = prefs.lang;
  const groups: { title: string; items: typeof LEAGUES }[] = [
    { title: t.featured, items: LEAGUES.filter((l) => l.featured) },
    { title: t.arab, items: LEAGUES.filter((l) => l.arab || l.region === "arab") },
    { title: t.europe, items: LEAGUES.filter((l) => l.region === "europe") },
    { title: t.africaWorld, items: LEAGUES.filter((l) => l.region === "africa" || l.national) },
    { title: t.asia, items: LEAGUES.filter((l) => l.region === "asia" || l.id === "ksa.1" || l.id === "uae" || l.id === "qat") },
    { title: t.americas, items: LEAGUES.filter((l) => l.region === "americas" || l.id === "conmebol.america") },
  ];
  return (
    <div className="space-y-5 py-4">
      <div className="flex items-center justify-between px-4">
        <h1 className="text-lg font-black">{t.today}</h1>
        <button type="button" onClick={onRefresh} className="inline-flex items-center gap-1 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent">
          <RefreshCw className={`size-4 ${busy ? "animate-spin" : ""}`} />
          {t.refresh}
        </button>
      </div>
      {!home ? <Empty text={t.loading} /> : null}
      {home && home.live.length > 0 && (
        <section>
          <SectionTitle>{t.live}</SectionTitle>
          <div className="space-y-2 px-4">{home.live.map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />)}</div>
        </section>
      )}
      <section>
        <SectionTitle>{t.today}</SectionTitle>
        <div className="space-y-2 px-4">
          {home && home.today.length === 0 ? <Empty text={t.emptyMatches} /> : null}
          {home?.today.slice(0, 8).map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />)}
        </div>
      </section>
      <section>
        <SectionTitle>{t.upcoming}</SectionTitle>
        <div className="flex gap-2 overflow-x-auto px-4 pb-1">
          {home?.upcoming.slice(0, 10).map((m) => (
            <button key={m.id} type="button" onClick={() => onMatch(m)} className="w-44 shrink-0 rounded-2xl border border-line bg-surface p-3 text-start">
              <div className="mb-2 text-xs text-muted">{lang === "ar" ? m.leagueNameAr : m.leagueNameEn}</div>
              <div className="flex items-center gap-2 text-sm"><Crest src={m.home.logo} name={m.home.name} className="size-6" />{m.home.name}</div>
              <div className="mt-1 flex items-center gap-2 text-sm"><Crest src={m.away.logo} name={m.away.name} className="size-6" />{m.away.name}</div>
              <div className="mt-2 text-xs text-accent">{formatWhen(m.kickoff, lang)}</div>
            </button>
          ))}
        </div>
      </section>
      {groups.map((group) => (
        <section key={group.title}>
          <SectionTitle>{group.title}</SectionTitle>
          <div className="grid grid-cols-2 gap-2 px-4 sm:grid-cols-3">
            {group.items.map((league) => (
              <button key={league.id + group.title} type="button" onClick={() => onLeague(league.id)} className="rounded-2xl border border-line bg-surface p-3 text-start">
                <Crest src={league.logo} name={lang === "ar" ? league.nameAr : league.nameEn} className="size-12" />
                <div className="mt-2 text-sm font-bold">{lang === "ar" ? league.nameAr : league.nameEn}</div>
                <div className="text-xs text-muted">{lang === "ar" ? league.countryAr : league.countryEn}</div>
              </button>
            ))}
          </div>
        </section>
      ))}
      <section>
        <SectionTitle>{t.news}</SectionTitle>
        <div className="space-y-2 px-4">
          {home && home.news.length === 0 ? <Empty text={t.emptyNews} /> : null}
          {home?.news.slice(0, 6).map((story) => (
            <a key={story.id} href={story.url} target="_blank" rel="noreferrer" className="flex gap-3 rounded-2xl border border-line bg-surface p-3">
              {story.image ? <img src={story.image} alt="" className="size-16 rounded-xl object-cover" /> : <span className="grid size-16 place-items-center rounded-xl bg-surface-2"><Newspaper className="size-5 text-muted" /></span>}
              <span>
                <span className="line-clamp-2 text-sm font-semibold">{story.title}</span>
                <span className="mt-1 block text-xs text-muted">{story.source} · {formatWhen(story.published, lang, false)}</span>
              </span>
            </a>
          ))}
        </div>
      </section>
      {home?.tables.map((table) => (
        <section key={table.leagueId}>
          <SectionTitle
            action={<button type="button" className="text-xs font-semibold text-accent" onClick={() => onLeague(table.leagueId)}>{t.open}</button>}
          >
            {`${t.standings} · ${lang === "ar" ? table.nameAr : table.nameEn}`}
          </SectionTitle>
          {table.partial ? <p className="px-4 pb-2 text-xs text-warn">{t.partial} · {table.season}</p> : <p className="px-4 pb-2 text-xs text-muted">{t.season}: {table.season}</p>}
          <div className="px-2">
            <StandingTable rows={table.rows} t={t} onTeam={(id) => {
              const row = table.rows.find((r) => r.team.id === id);
              onTeam(table.leagueId, id, row?.team.name ?? id, row?.team.logo ?? null);
            }} />
          </div>
        </section>
      ))}
      <section>
        <SectionTitle action={<button type="button" className="text-xs font-semibold text-accent" onClick={() => onLeague("eng.1")}>{t.favorites}</button>}>
          {t.favorites}
        </SectionTitle>
        <div className="flex gap-3 overflow-x-auto px-4">
          {(prefs.favs.length ? prefs.favs : SUGGESTED_CLUBS.slice(0, 8)).map((club) => (
            <button key={club.id} type="button" onClick={() => onTeam(club.leagueId, club.id, lang === "ar" ? club.nameAr : club.name, club.logo)} className="flex w-20 shrink-0 flex-col items-center gap-1">
              <Crest src={club.logo} name={club.name} />
              <span className="line-clamp-2 text-center text-xs">{lang === "ar" ? club.nameAr : club.name}</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function MatchesScreen({ lang, t, onMatch }: { lang: Lang; t: ReturnType<typeof copy>; onMatch: (m: Fixture) => void }) {
  const [filter, setFilter] = useState<"today" | "tomorrow" | "live" | "week" | "past">("today");
  const [query, setQuery] = useState("");
  const [date, setDate] = useState("");
  const [matches, setMatches] = useState<Fixture[]>([]);
  const [at, setAt] = useState<string>();
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(true);

  const load = useCallback(async () => {
    setBusy(true);
    const dates = filter === "today" ? [ymd()]
      : filter === "tomorrow" ? [shift(1)]
      : filter === "past" ? [shift(-1), shift(-2)]
      : [0, 1, 2, 3, 4, 5, 6].map((n) => shift(n));
    if (date) dates.splice(0, dates.length, date.replaceAll("-", ""));
    try {
      const data = await fetchBoard({ data: { dates } });
      let list = data.matches;
      if (filter === "live") list = list.filter((m) => m.status === "in");
      if (filter === "past") list = list.filter((m) => m.status === "post");
      if (filter === "week") list = list.filter((m) => m.status !== "post");
      setMatches(list);
      setAt(data.updatedAt);
      setStale(data.stale);
    } catch {
      setStale(true);
    } finally {
      setBusy(false);
    }
  }, [filter, date]);

  useEffect(() => { void load(); }, [load]);

  const shown = matches.filter((m) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return m.home.name.toLowerCase().includes(q) || m.away.name.toLowerCase().includes(q);
  });

  return (
    <div className="py-3">
      <div className="flex gap-2 overflow-x-auto px-4">
        {(["today", "tomorrow", "live", "week", "past"] as const).map((key) => (
          <button key={key} type="button" onClick={() => { setDate(""); setFilter(key); }} className={`rounded-full px-3 py-2 text-sm ${filter === key && !date ? "bg-accent text-onaccent" : "border border-line text-fg"}`}>
            {t[key === "week" ? "week" : key]}
          </button>
        ))}
      </div>
      <div className="mt-3 flex gap-2 px-4">
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t.searchPh} className="min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm" />
        <button type="button" onClick={() => void load()} className="rounded-xl border border-line px-3"><RefreshCw className="size-4" /></button>
      </div>
      <div className="px-4 pt-2"><Freshness at={at} stale={stale} busy={busy} t={t} lang={lang} /></div>
      <div className="mt-2 space-y-2 px-4">
        {busy && !shown.length ? <Empty text={t.loading} /> : null}
        {!busy && !shown.length ? <Empty text={t.emptyMatches} /> : null}
        {shown.map((m) => <MatchCard key={m.id + m.kickoff} match={m} lang={lang} onOpen={() => onMatch(m)} />)}
      </div>
    </div>
  );
}

function LeagueList({
  title,
  leagues,
  lang,
  favs,
  onToggle,
  onOpen,
}: {
  title: string;
  leagues: typeof LEAGUES;
  lang: Lang;
  favs: string[];
  onToggle: (id: string) => void;
  onOpen: (id: string) => void;
}) {
  const [q, setQ] = useState("");
  const list = leagues.filter((l) => `${l.nameAr} ${l.nameEn} ${l.countryAr}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="py-4">
      <h1 className="px-4 text-lg font-black">{title}</h1>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={title} className="mx-4 mt-3 w-[calc(100%-2rem)] rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm" />
      <div className="mt-3 grid grid-cols-2 gap-2 px-4">
        {list.map((league) => (
          <div key={league.id} className="rounded-2xl border border-line bg-surface p-3">
            <button type="button" onClick={() => onOpen(league.id)} className="w-full text-start">
              <Crest src={league.logo} name={lang === "ar" ? league.nameAr : league.nameEn} className="size-12" />
              <div className="mt-2 text-sm font-bold">{lang === "ar" ? league.nameAr : league.nameEn}</div>
              <div className="text-xs text-muted">{lang === "ar" ? league.countryAr : league.countryEn}</div>
            </button>
            <button type="button" onClick={() => onToggle(league.id)} className="mt-2 text-xs text-accent">
              <Star className={`inline size-3 ${favs.includes(league.id) ? "fill-accent" : ""}`} /> {favs.includes(league.id) ? "★" : "+"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function LeagueScreen({
  id,
  lang,
  t,
  onMatch,
  onTeam,
  onPlayer,
}: {
  id: string;
  lang: Lang;
  t: ReturnType<typeof copy>;
  onMatch: (m: Fixture) => void;
  onTeam: (id: string) => void;
  onPlayer: (playerId: string, teamId?: string) => void;
}) {
  const [tabName, setTab] = useState<"standings" | "results" | "fixtures" | "teams" | "scorers" | "assists">("standings");
  const [data, setData] = useState<LeaguePayload | null>(null);
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    setBusy(true);
    try {
      const next = await fetchLeague({ data: id });
      setData(next);
      setStale(Boolean(next.stale));
      if (!next.error) writeCache(`league:${id}`, next);
    } catch {
      setStale(true);
    } finally {
      setBusy(false);
    }
  }, [id]);
  useEffect(() => {
    const cached = readCache<LeaguePayload>(`league:${id}`);
    if (cached) {
      setData(cached.data);
      setStale(true);
    }
    void load();
  }, [id, load]);
  const name = data ? (lang === "ar" ? data.nameAr : data.nameEn) : leagueName(id, lang);
  return (
    <div className="py-4">
      <div className="flex items-center gap-3 px-4">
        <Crest src={data?.logo ?? leagueById(id)?.logo} name={name} className="size-14" />
        <div>
          <h1 className="text-lg font-black">{name}</h1>
          <Freshness at={data?.updatedAt} stale={stale} busy={busy} t={t} lang={lang} />
          <div className="text-xs text-muted">{t.season}: {data?.season || "—"}</div>
        </div>
        <button type="button" onClick={() => void load()} className="ms-auto rounded-full border border-line p-2"><RefreshCw className="size-4" /></button>
      </div>
      {data?.noteAr || data?.noteEn ? <p className="mx-4 mt-3 rounded-xl bg-surface-2 px-3 py-2 text-xs text-warn">{lang === "ar" ? data.noteAr : data.noteEn}</p> : null}
      <div className="mt-3 flex gap-2 overflow-x-auto px-4">
        {(["standings", "results", "fixtures", "teams", "scorers", "assists"] as const).map((key) => (
          <button key={key} type="button" onClick={() => setTab(key)} className={`rounded-full px-3 py-2 text-sm ${tabName === key ? "bg-accent text-onaccent" : "border border-line"}`}>{t[key]}</button>
        ))}
      </div>
      <div className="mt-3">
        {!data && busy ? <Empty text={t.loading} /> : null}
        {tabName === "standings" && data && (data.standings.length ? <StandingTable rows={data.standings} t={t} onTeam={onTeam} /> : <Empty text={lang === "ar" ? "لا يوجد ترتيب من المصدر." : "No table from the source."} />)}
        {tabName === "results" && <div className="space-y-2 px-4">{data?.results.length ? data.results.map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />) : <Empty text={t.emptyMatches} />}</div>}
        {tabName === "fixtures" && <div className="space-y-2 px-4">{data?.upcoming.length ? data.upcoming.map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />) : <Empty text={t.emptyMatches} />}</div>}
        {tabName === "teams" && (
          <div className="grid grid-cols-2 gap-2 px-4">
            {data?.teams.map((team) => (
              <button key={team.id} type="button" onClick={() => onTeam(team.id)} className="flex items-center gap-2 rounded-2xl border border-line bg-surface p-3 text-start">
                <Crest src={team.logo} name={team.name} className="size-8" />
                <span className="text-sm">{team.name}</span>
              </button>
            ))}
            {data && !data.teams.length ? <Empty text={t.emptyMatches} /> : null}
          </div>
        )}
        {tabName === "scorers" && <ScorerList rows={data?.scorers ?? []} empty={t.noScorers} onOpen={onPlayer} />}
        {tabName === "assists" && <ScorerList rows={data?.assists ?? []} empty={t.noAssists} onOpen={onPlayer} />}
      </div>
    </div>
  );
}

function ScorerList({ rows, empty, onOpen }: { rows: LeaguePayload["scorers"]; empty: string; onOpen: (id: string, teamId?: string) => void }) {
  if (!rows.length) return <Empty text={empty} />;
  return (
    <div className="space-y-2 px-4">
      {rows.map((row, index) => (
        <button key={row.id} type="button" onClick={() => onOpen(row.id, row.teamId)} className="flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start">
          <span className="w-5 font-bold text-accent">{index + 1}</span>
          <Crest src={row.teamLogo} name={row.teamName} className="size-8" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-semibold">{row.name}</span>
            <span className="block truncate text-xs text-muted">{row.teamName}</span>
          </span>
          <span className="text-lg font-black tabular-nums">{row.value}</span>
        </button>
      ))}
    </div>
  );
}

function MatchScreen({ leagueId, id, lang, t, onTeam }: { leagueId: string; id: string; lang: Lang; t: ReturnType<typeof copy>; onTeam: (id: string) => void }) {
  const [data, setData] = useState<MatchPayload | null>(null);
  const [busy, setBusy] = useState(true);
  useEffect(() => {
    let cancel = false;
    setBusy(true);
    fetchMatch({ data: { leagueId, eventId: id } })
      .then((next) => { if (!cancel) setData(next); })
      .catch(() => { if (!cancel) setData(null); })
      .finally(() => { if (!cancel) setBusy(false); });
    return () => { cancel = true; };
  }, [leagueId, id]);
  if (busy && !data) return <Empty text={t.loading} />;
  if (!data) return <Empty text={t.failed} />;
  const match = data.match;
  return (
    <div className="space-y-4 py-4">
      <div className="px-4 text-center">
        <div className="text-xs text-muted">{lang === "ar" ? match.leagueNameAr : match.leagueNameEn}</div>
        <div className="mt-3 flex items-center justify-between">
          <button type="button" onClick={() => onTeam(match.home.id)} className="flex w-28 flex-col items-center gap-1">
            <Crest src={match.home.logo} name={match.home.name} className="size-14" />
            <span className="text-sm font-bold">{match.home.name}</span>
          </button>
          <div>
            <div className="text-3xl font-black tabular-nums text-accent">{match.status === "pre" ? "–" : `${match.home.score ?? 0} - ${match.away.score ?? 0}`}</div>
            <div className="text-xs text-muted">{match.status === "in" ? match.statusText : formatWhen(match.kickoff, lang)}</div>
          </div>
          <button type="button" onClick={() => onTeam(match.away.id)} className="flex w-28 flex-col items-center gap-1">
            <Crest src={match.away.logo} name={match.away.name} className="size-14" />
            <span className="text-sm font-bold">{match.away.name}</span>
          </button>
        </div>
        {match.venue ? <p className="mt-2 text-xs text-muted">{t.venue}: {match.venue}</p> : null}
        <Freshness at={data.updatedAt} stale={data.stale} t={t} lang={lang} />
      </div>
      {data.noteAr || data.noteEn ? <p className="mx-4 text-xs text-warn">{lang === "ar" ? data.noteAr : data.noteEn}</p> : null}
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.stats}</h2>
        {data.stats.length === 0 ? <Empty text={lang === "ar" ? "لا إحصائيات تفصيلية من المصدر لهذه المباراة." : "No detailed stats from the source for this match."} /> : (
          <div className="space-y-2">
            {data.stats.map((stat) => (
              <div key={stat.label} className="grid grid-cols-[3rem_1fr_3rem] items-center text-sm">
                <span className="font-bold tabular-nums">{stat.home}</span>
                <span className="text-center text-xs text-muted">{stat.label}</span>
                <span className="text-end font-bold tabular-nums">{stat.away}</span>
              </div>
            ))}
          </div>
        )}
      </section>
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.timeline}</h2>
        {data.timeline.length === 0 ? <Empty text={lang === "ar" ? "لا أحداث مفصلة." : "No event feed."} /> : data.timeline.filter((item) => item.scoring || item.text).slice(0, 16).map((item, i) => (
          <div key={i} className="border-t border-line py-2 text-sm">
            <span className="text-accent">{item.minute}</span> {item.text} <span className="text-xs text-muted">{item.team}</span>
          </div>
        ))}
      </section>
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.h2h}</h2>
        {data.h2hSummary ? <p className="mb-2 text-xs text-muted">{data.h2hSummary}</p> : null}
        {data.h2h.length === 0 ? <Empty text={lang === "ar" ? "لا سجل مواجهات من المصدر." : "No head-to-head from the source."} /> : data.h2h.map((m) => <div key={m.id} className="mb-2"><MatchCard match={m} lang={lang} onOpen={() => undefined} /></div>)}
      </section>
    </div>
  );
}

function TeamScreen({
  leagueId,
  id,
  lang,
  t,
  fav,
  onFav,
  onMatch,
  onPlayer,
}: {
  leagueId: string;
  id: string;
  lang: Lang;
  t: ReturnType<typeof copy>;
  fav: boolean;
  onFav: (club: Fav) => void;
  onMatch: (m: Fixture) => void;
  onPlayer: (id: string) => void;
}) {
  const [data, setData] = useState<TeamPayload | null>(null);
  const [busy, setBusy] = useState(true);
  useEffect(() => {
    let cancel = false;
    setBusy(true);
    fetchTeam({ data: { leagueId, teamId: id } })
      .then((next) => { if (!cancel) setData(next); })
      .finally(() => { if (!cancel) setBusy(false); });
    return () => { cancel = true; };
  }, [leagueId, id]);
  if (busy && !data) return <Empty text={t.loading} />;
  if (!data) return <Empty text={t.failed} />;
  const club = data.club;
  return (
    <div className="space-y-4 py-4">
      <div className="flex items-center gap-3 px-4">
        <Crest src={club.logo} name={club.name} className="size-16" />
        <div className="min-w-0 flex-1">
          <h1 className="text-lg font-black">{club.name}</h1>
          <p className="text-xs text-muted">{lang === "ar" ? club.leagueNameAr : club.leagueNameEn}</p>
          {club.standing ? <p className="text-xs">{club.standing}</p> : null}
          {data.row ? <p className="text-sm font-semibold text-accent">{data.row.pts} {t.pts} · {t.gd} {data.row.gd}</p> : null}
        </div>
        <button
          type="button"
          onClick={() => onFav({ id: club.id, name: club.name, nameAr: club.name, leagueId: club.leagueId, logo: club.logo })}
          className="rounded-full border border-line px-3 py-2 text-xs"
        >
          <Star className={`inline size-3 ${fav ? "fill-accent text-accent" : ""}`} /> {fav ? t.added : t.add}
        </button>
      </div>
      <div className="px-4"><Freshness at={data.updatedAt} stale={data.stale} t={t} lang={lang} /></div>
      {data.noteAr || data.noteEn ? <p className="px-4 text-xs text-warn">{lang === "ar" ? data.noteAr : data.noteEn}</p> : null}
      <section>
        <SectionTitle>{t.matches}</SectionTitle>
        <div className="space-y-2 px-4">{data.matches.length ? data.matches.slice(-12).map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />) : <Empty text={t.emptyMatches} />}</div>
      </section>
      <section>
        <SectionTitle>{t.squad}</SectionTitle>
        {data.squad.length === 0 ? <Empty text={t.noSquad} /> : (
          <div className="grid grid-cols-1 gap-2 px-4">
            {data.squad.map((player) => (
              <button key={player.id} type="button" onClick={() => onPlayer(player.id)} className="flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start">
                <Crest src={player.headshot} name={player.name} className="size-10" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{player.name}</span>
                  <span className="text-xs text-muted">{player.position} {player.jersey ? `· ${player.jersey}` : ""}</span>
                </span>
                {player.goals !== undefined ? <span className="text-xs text-accent">{player.goals} {t.goals}</span> : null}
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function PlayerScreen({ leagueId, id, teamId, lang, t }: { leagueId: string; id: string; teamId?: string; lang: Lang; t: ReturnType<typeof copy> }) {
  const [data, setData] = useState<PlayerPayload | null>(null);
  useEffect(() => {
    let cancel = false;
    fetchPlayer({ data: { leagueId, playerId: id, teamId } }).then((next) => { if (!cancel) setData(next); });
    return () => { cancel = true; };
  }, [leagueId, id, teamId]);
  if (!data) return <Empty text={t.loading} />;
  const player = data.player;
  return (
    <div className="py-6 px-4">
      <div className="flex items-center gap-3">
        <Crest src={player.headshot || player.teamLogo} name={player.name} className="size-16" />
        <div>
          <h1 className="text-lg font-black">{player.name}</h1>
          <p className="text-sm text-muted">{player.teamName}</p>
        </div>
      </div>
      <dl className="mt-4 space-y-2 text-sm">
        {player.position ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">{t.position}</dt><dd>{player.position}</dd></div> : null}
        {player.jersey ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">#</dt><dd>{player.jersey}</dd></div> : null}
        {player.age ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">{t.age}</dt><dd>{player.age}</dd></div> : null}
        {player.nationality ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">{t.nation}</dt><dd>{player.nationality}</dd></div> : null}
        {player.goals !== undefined ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">{t.goals}</dt><dd>{player.goals}</dd></div> : null}
        {player.assists !== undefined ? <div className="flex justify-between border-b border-line py-2"><dt className="text-muted">{t.assists}</dt><dd>{player.assists}</dd></div> : null}
      </dl>
      <p className="mt-3 text-xs text-muted">{lang === "ar" ? data.noteAr : data.noteEn}</p>
      {data.error ? <p className="mt-2 text-sm text-warn">{t.failed}</p> : null}
    </div>
  );
}

function InsightsScreen({
  lang,
  t,
  onMatch,
  onPlayer,
}: {
  lang: Lang;
  t: ReturnType<typeof copy>;
  onMatch: (m: Fixture) => void;
  onPlayer: (leagueId: string, playerId: string, teamId?: string) => void;
}) {
  const [leagueId, setLeagueId] = useState("eng.1");
  const [data, setData] = useState<LeaguePayload | null>(null);
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [pa, setPa] = useState("");
  const [pb, setPb] = useState("");
  const [h2h, setH2h] = useState<Fixture[]>([]);
  const [note, setNote] = useState("");
  useEffect(() => {
    let cancel = false;
    fetchLeague({ data: leagueId }).then((next) => { if (!cancel) { setData(next); setA(""); setB(""); setPa(""); setPb(""); setH2h([]); } });
    return () => { cancel = true; };
  }, [leagueId]);
  const byId = new Map((data?.standings ?? []).map((row) => [row.team.id, row]));
  const picks = data?.upcoming.slice(0, 6) ?? [];
  return (
    <div className="space-y-4 py-4">
      <div className="px-4">
        <h1 className="text-lg font-black">{t.insights}</h1>
        <select value={leagueId} onChange={(e) => setLeagueId(e.target.value)} className="mt-2 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm">
          {LEAGUES.map((l) => <option key={l.id} value={l.id}>{lang === "ar" ? l.nameAr : l.nameEn}</option>)}
        </select>
        {data?.partial ? <p className="mt-2 text-xs text-warn">{t.partial}</p> : null}
      </div>
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.prediction}</h2>
        <p className="mb-2 text-xs text-warn">{t.notFact}</p>
        {picks.map((m) => {
          const home = byId.get(m.home.id);
          const away = byId.get(m.away.id);
          const est = home && away ? estimate(home, away) : null;
          return (
            <div key={m.id} className="mb-2 rounded-2xl border border-line bg-surface p-3">
              <button type="button" onClick={() => onMatch(m)} className="text-sm font-semibold">{m.home.name} {t.vs} {m.away.name}</button>
              {est ? (
                <p className="mt-1 text-sm tabular-nums">{est.home}% / {est.draw}% / {est.away}% · xG {est.goals}</p>
              ) : <p className="mt-1 text-xs text-muted">{t.insufficient}</p>}
            </div>
          );
        })}
        {!picks.length ? <Empty text={t.emptyMatches} /> : null}
      </section>
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.compareTeams}</h2>
        <div className="grid grid-cols-2 gap-2">
          <TeamSelect rows={data?.standings ?? []} value={a} onChange={setA} />
          <TeamSelect rows={data?.standings ?? []} value={b} onChange={setB} />
        </div>
        {a && b && byId.get(a) && byId.get(b) ? <CompareRows left={byId.get(a) as StandingRow} right={byId.get(b) as StandingRow} t={t} /> : null}
        <button
          type="button"
          disabled={!a || !b}
          onClick={() => {
            void fetchH2H({ data: { leagueId, teamA: a, teamB: b } }).then((res) => {
              setH2h(res.matches);
              setNote(lang === "ar" ? res.noteAr : res.noteEn);
            });
          }}
          className="mt-2 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent disabled:opacity-40"
        >
          {t.h2h}
        </button>
        {note ? <p className="mt-2 text-xs text-muted">{note}</p> : null}
        <div className="mt-2 space-y-2">{h2h.map((m) => <MatchCard key={m.id} match={m} lang={lang} onOpen={() => onMatch(m)} />)}</div>
      </section>
      <section className="px-4">
        <h2 className="mb-2 font-bold">{t.comparePlayers}</h2>
        <div className="grid grid-cols-2 gap-2">
          <PlayerSelect rows={data?.scorers ?? []} value={pa} onChange={setPa} />
          <PlayerSelect rows={data?.scorers ?? []} value={pb} onChange={setPb} />
        </div>
        {pa && pb ? (
          <PlayerCompare
            left={(data?.scorers ?? []).find((s) => s.id === pa)}
            right={(data?.scorers ?? []).find((s) => s.id === pb)}
            assists={data?.assists ?? []}
            onOpen={(pid, teamId) => onPlayer(leagueId, pid, teamId)}
          />
        ) : null}
        {!data?.scorers.length ? <Empty text={t.noScorers} /> : null}
      </section>
    </div>
  );
}

function TeamSelect({ rows, value, onChange }: { rows: StandingRow[]; value: string; onChange: (v: string) => void }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-2 py-2 text-sm">
      <option value="">—</option>
      {rows.map((row) => <option key={row.team.id} value={row.team.id}>{row.team.name}</option>)}
    </select>
  );
}

function PlayerSelect({ rows, value, onChange }: { rows: LeaguePayload["scorers"]; value: string; onChange: (v: string) => void }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-2 py-2 text-sm">
      <option value="">—</option>
      {rows.map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}
    </select>
  );
}

function CompareRows({ left, right, t }: { left: StandingRow; right: StandingRow; t: ReturnType<typeof copy> }) {
  const lines = [
    [t.pts, left.pts, right.pts],
    [t.gd, left.gd, right.gd],
    [t.goals, left.gf, right.gf],
    ["GA", left.ga, right.ga],
    [t.played, left.played, right.played],
  ] as const;
  return (
    <div className="mt-3 rounded-2xl border border-line bg-surface p-3 text-sm">
      <div className="mb-2 flex items-center justify-between font-bold">
        <span className="flex items-center gap-1"><Crest src={left.team.logo} name={left.team.name} className="size-6" />{left.team.name}</span>
        <span className="flex items-center gap-1">{right.team.name}<Crest src={right.team.logo} name={right.team.name} className="size-6" /></span>
      </div>
      {lines.map(([label, l, r]) => (
        <div key={String(label)} className="grid grid-cols-3 border-t border-line py-1 text-center">
          <span>{l}</span><span className="text-xs text-muted">{label}</span><span>{r}</span>
        </div>
      ))}
    </div>
  );
}

function PlayerCompare({
  left,
  right,
  assists,
  onOpen,
}: {
  left?: LeaguePayload["scorers"][number];
  right?: LeaguePayload["scorers"][number];
  assists: LeaguePayload["assists"];
  onOpen: (id: string, teamId?: string) => void;
}) {
  if (!left || !right) return null;
  const ag = assists.find((s) => s.id === left.id)?.value ?? "—";
  const bg = assists.find((s) => s.id === right.id)?.value ?? "—";
  return (
    <div className="mt-3 rounded-2xl border border-line bg-surface p-3 text-sm">
      <div className="flex justify-between font-bold">
        <button type="button" onClick={() => onOpen(left.id, left.teamId)}>{left.name}</button>
        <button type="button" onClick={() => onOpen(right.id, right.teamId)}>{right.name}</button>
      </div>
      <div className="mt-2 grid grid-cols-3 text-center"><span>{left.value}</span><span className="text-xs text-muted">G</span><span>{right.value}</span></div>
      <div className="grid grid-cols-3 text-center"><span>{ag}</span><span className="text-xs text-muted">A</span><span>{bg}</span></div>
      <p className="mt-2 text-xs text-muted">{left.teamName} / {right.teamName}</p>
    </div>
  );
}

function AiScreen({ lang, t }: { lang: Lang; t: ReturnType<typeof copy> }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<{ role: "user" | "ai"; text: string }[]>([
    { role: "ai", text: lang === "ar" ? "اسأل عن نتيجة أو ترتيب أو موعد من البيانات المحمّلة. التوقعات تُذكر صراحةً وليست نتائج." : "Ask about a score, table, or kickoff from loaded data. Forecasts are labeled and are not results." },
  ]);
  const send = async () => {
    const question = text.trim();
    if (!question || busy) return;
    setText("");
    setLog((prev) => [...prev, { role: "user", text: question }]);
    setBusy(true);
    try {
      const answer = await askAssistant({ data: { question, lang, today: ymd() } });
      setLog((prev) => [...prev, { role: "ai", text: answer.text }]);
    } catch {
      setLog((prev) => [...prev, { role: "ai", text: t.failed }]);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="flex min-h-[70vh] flex-col py-4">
      <div className="flex-1 space-y-2 px-4">
        {log.map((msg, i) => (
          <div key={i} className={`max-w-[90%] rounded-2xl px-3 py-2 text-sm ${msg.role === "user" ? "ms-auto bg-accent text-onaccent" : "bg-surface border border-line"}`}>
            {msg.text}
          </div>
        ))}
        {busy ? <p className="text-xs text-muted">{t.thinking}</p> : null}
      </div>
      <div className="sticky bottom-20 flex gap-2 px-4 pt-3">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void send(); }} placeholder={t.ask} className="min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm" />
        <button type="button" onClick={() => void send()} className="rounded-xl bg-accent px-3 font-bold text-onaccent">{t.send}</button>
      </div>
    </div>
  );
}

function NewsScreen({ home, lang, t }: { home: HomePayload | null; lang: Lang; t: ReturnType<typeof copy> }) {
  return (
    <div className="space-y-2 px-4 py-4">
      <h1 className="text-lg font-black">{t.news}</h1>
      {home?.news.length ? home.news.map((story) => (
        <a key={story.id} href={story.url} target="_blank" rel="noreferrer" className="block rounded-2xl border border-line bg-surface p-3">
          {story.image ? <img src={story.image} alt="" className="mb-2 h-36 w-full rounded-xl object-cover" /> : null}
          <div className="font-semibold">{story.title}</div>
          <p className="mt-1 text-sm text-muted">{story.summary}</p>
          <div className="mt-2 text-xs text-accent">{story.source} · {formatWhen(story.published, lang)}</div>
        </a>
      )) : <Empty text={t.emptyNews} />}
    </div>
  );
}

function SettingsScreen({ prefs, t, onChange }: { prefs: Prefs; t: ReturnType<typeof copy>; onChange: (patch: Partial<Prefs>) => void }) {
  const enable = async () => {
    if (typeof Notification === "undefined") return;
    const perm = await Notification.requestPermission();
    onChange({ notify: perm === "granted" });
  };
  return (
    <div className="space-y-4 px-4 py-4">
      <h1 className="text-lg font-black">{t.settings}</h1>
      <label className="block text-sm">{t.language}
        <select value={prefs.lang} onChange={(e) => onChange({ lang: e.target.value as Lang })} className="mt-1 w-full rounded-xl border border-line bg-surface-2 px-3 py-2">
          <option value="ar">العربية</option>
          <option value="en">English</option>
        </select>
      </label>
      <div>
        <div className="mb-2 text-sm">{t.theme}</div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => onChange({ mode: prefs.mode === "dark" ? "light" : "dark" })} className="rounded-full border border-line px-3 py-2 text-sm">{prefs.mode === "dark" ? t.light : t.dark}</button>
          {(["green", "blue", "purple", "orange"] as const).map((theme) => (
            <button key={theme} type="button" onClick={() => onChange({ theme })} className={`rounded-full px-3 py-2 text-sm ${prefs.theme === theme ? "bg-accent text-onaccent" : "border border-line"}`}>{theme}</button>
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 text-sm">{t.font}</div>
        <div className="flex gap-2">
          {(["sm", "md", "lg"] as const).map((font) => (
            <button key={font} type="button" onClick={() => onChange({ font })} className={`rounded-full px-3 py-2 text-sm ${prefs.font === font ? "bg-accent text-onaccent" : "border border-line"}`}>{t[font]}</button>
          ))}
        </div>
      </div>
      <div className="rounded-2xl border border-line bg-surface p-3">
        <div className="font-semibold">{t.notify}</div>
        <p className="mt-1 text-xs text-muted">{t.notifyHint}</p>
        <button type="button" onClick={() => void enable()} className="mt-2 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent">{t.enableNotify}</button>
      </div>
      <p className="text-xs leading-6 text-muted">{t.sources}</p>
      <button type="button" onClick={() => onChange(DEFAULT_PREFS)} className="w-full rounded-xl border border-line py-3 text-sm">{t.reset}</button>
    </div>
  );
}

function SearchScreen({
  lang,
  t,
  onLeague,
  onTeam,
  onPlayer,
}: {
  lang: Lang;
  t: ReturnType<typeof copy>;
  onLeague: (id: string) => void;
  onTeam: (leagueId: string, id: string) => void;
  onPlayer: (leagueId: string, id: string) => void;
}) {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (q.trim().length < 2) {
      setHits([]);
      return;
    }
    const timer = window.setTimeout(() => {
      setBusy(true);
      fetchSearch({ data: q })
        .then(setHits)
        .catch(() => setHits([]))
        .finally(() => setBusy(false));
    }, 300);
    return () => window.clearTimeout(timer);
  }, [q]);
  return (
    <div className="px-4 py-4">
      <h1 className="text-lg font-black">{t.search}</h1>
      <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.searchPh} className="mt-3 w-full rounded-xl border border-line bg-surface-2 px-3 py-3 text-sm" />
      {busy ? <p className="mt-3 text-xs text-muted">{t.loading}</p> : null}
      <div className="mt-3 space-y-2">
        {hits.map((hit) => (
          <button
            key={`${hit.kind}-${hit.id}`}
            type="button"
            onClick={() => {
              if (hit.kind === "league") onLeague(hit.id);
              else if (hit.kind === "team" && hit.leagueId) onTeam(hit.leagueId, hit.id);
              else if (hit.kind === "player" && hit.leagueId) onPlayer(hit.leagueId, hit.id);
            }}
            className="flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start"
          >
            <Crest src={hit.logo} name={hit.title} className="size-9" />
            <span>
              <span className="block text-sm font-semibold">{hit.title}</span>
              <span className="text-xs text-muted">{hit.kind} · {hit.subtitle}</span>
            </span>
          </button>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted">{lang === "ar" ? "البحث يطابق البطولات محلياً والأندية واللاعبين عبر ESPN." : "Search matches competitions locally, and clubs or players via ESPN."}</p>
    </div>
  );
}

function FavoritesScreen({
  prefs,
  t,
  onTeam,
  onLeague,
  onAdd,
}: {
  prefs: Prefs;
  t: ReturnType<typeof copy>;
  onTeam: (f: Fav) => void;
  onLeague: (id: string) => void;
  onAdd: (club: Fav) => void;
}) {
  const lang = prefs.lang;
  return (
    <div className="space-y-4 px-4 py-4">
      <h1 className="text-lg font-black">{t.favorites}</h1>
      {prefs.favs.length === 0 ? <Empty text={t.noFav} /> : prefs.favs.map((club) => (
        <button key={club.id} type="button" onClick={() => onTeam(club)} className="flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start">
          <Crest src={club.logo} name={club.name} />
          <span>{lang === "ar" ? club.nameAr : club.name}</span>
        </button>
      ))}
      <h2 className="font-bold">{t.pickFav}</h2>
      <div className="grid grid-cols-2 gap-2">
        {SUGGESTED_CLUBS.map((club) => (
          <button key={club.id} type="button" onClick={() => onAdd(club)} className="flex items-center gap-2 rounded-2xl border border-line bg-surface p-2 text-start text-sm">
            <Crest src={club.logo} name={club.name} className="size-8" />
            {lang === "ar" ? club.nameAr : club.name}
          </button>
        ))}
      </div>
      <h2 className="font-bold">{t.leagues}</h2>
      {prefs.favLeagues.map((id) => (
        <button key={id} type="button" onClick={() => onLeague(id)} className="block w-full rounded-xl border border-line px-3 py-2 text-start text-sm">{leagueName(id, lang)}</button>
      ))}
    </div>
  );
}

function HistoryScreen({ items, t, onOpen }: { items: Recent[]; t: ReturnType<typeof copy>; onOpen: (item: Recent) => void }) {
  return (
    <div className="px-4 py-4">
      <h1 className="mb-3 flex items-center gap-2 text-lg font-black"><History className="size-5" />{t.history}</h1>
      {items.length === 0 ? <Empty text={t.history} /> : items.map((item) => (
        <button key={item.kind + item.id} type="button" onClick={() => onOpen(item)} className="mb-2 flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start">
          <Crest src={item.logo} name={item.title} className="size-8" />
          <span className="text-sm">{item.title}</span>
        </button>
      ))}
    </div>
  );
}
