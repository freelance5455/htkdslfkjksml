import { Fragment, useState, type ReactNode } from "react";
import { initials } from "@/lib/football/catalog";
import type { Copy } from "@/lib/football/i18n";
import type { Fixture, Lang, StandingRow } from "@/lib/football/types";

export function Crest({
  src,
  name,
  className = "size-10",
}: {
  src?: string | null;
  name: string;
  className?: string;
}) {
  const [ok, setOk] = useState(Boolean(src));
  if (!src || !ok) {
    return (
      <span
        className={`${className} grid shrink-0 place-items-center rounded-full border border-line bg-surface-2 text-xs font-bold text-fg`}
      >
        {initials(name)}
      </span>
    );
  }
  return (
    <img
      src={src}
      alt=""
      className={`${className} shrink-0 rounded-full border border-line bg-surface-2 object-contain`}
      onError={() => setOk(false)}
    />
  );
}

export function formatWhen(iso: string, lang: Lang, withTime = true) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
    month: "short",
    day: "numeric",
    hour: withTime ? "2-digit" : undefined,
    minute: withTime ? "2-digit" : undefined,
  }).format(date);
}

export function Freshness({
  at,
  stale,
  busy,
  t,
  lang,
}: {
  at?: string;
  stale?: boolean;
  busy?: boolean;
  t: Copy;
  lang: Lang;
}) {
  return (
    <p className="text-xs text-muted">
      {busy ? t.refreshing : stale ? t.saved : t.updated}
      {at ? ` · ${formatWhen(at, lang)}` : ""}
    </p>
  );
}

export function Empty({ text }: { text: string }) {
  return <p className="px-4 py-8 text-center text-sm text-muted">{text}</p>;
}

export function MatchCard({
  match,
  lang,
  onOpen,
}: {
  match: Fixture;
  lang: Lang;
  onOpen: () => void;
}) {
  const league = lang === "ar" ? match.leagueNameAr : match.leagueNameEn;
  const score =
    match.status === "pre" ? "–" : `${match.home.score ?? 0} - ${match.away.score ?? 0}`;
  return (
    <button
      type="button"
      onClick={onOpen}
      className="flex w-full items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-3 text-start"
    >
      <TeamSide name={match.home.name} logo={match.home.logo} />
      <div className="min-w-16 flex-1 text-center">
        <div className="text-lg font-bold tabular-nums text-accent">{score}</div>
        <div className="text-xs text-muted">{formatWhen(match.kickoff, lang)}</div>
        <div className="mt-1 flex items-center justify-center gap-1">
          {match.status === "in" ? (
            <span className="rounded-full bg-live px-2 py-0.5 text-xs font-bold text-onlive">{match.statusText || "LIVE"}</span>
          ) : (
            <span className="text-xs text-muted">{league}</span>
          )}
        </div>
      </div>
      <TeamSide name={match.away.name} logo={match.away.logo} />
    </button>
  );
}

function TeamSide({ name, logo }: { name: string; logo: string | null }) {
  return (
    <span className="flex w-24 flex-col items-center gap-1">
      <Crest src={logo} name={name} />
      <span className="line-clamp-2 text-center text-xs font-medium">{name}</span>
    </span>
  );
}

export function StandingTable({
  rows,
  t,
  onTeam,
}: {
  rows: StandingRow[];
  t: Copy;
  onTeam: (id: string) => void;
}) {
  let lastGroup = "";
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[36rem] text-center text-sm">
        <thead className="text-xs text-muted">
          <tr>
            <th className="px-1 py-2">#</th>
            <th className="px-1 py-2 text-start">{t.teams}</th>
            <th className="px-1 py-2">{t.played}</th>
            <th className="px-1 py-2">W</th>
            <th className="px-1 py-2">D</th>
            <th className="px-1 py-2">L</th>
            <th className="px-1 py-2">{t.gd}</th>
            <th className="px-1 py-2">{t.pts}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const showGroup = row.group && row.group !== lastGroup;
            if (row.group) lastGroup = row.group;
            return (
              <Fragment key={`${row.group ?? ""}-${row.team.id}-${row.rank}`}>
                {showGroup ? (
                  <tr>
                    <td colSpan={8} className="bg-surface-2 px-3 py-1 text-start text-xs font-semibold text-muted">
                      {row.group}
                    </td>
                  </tr>
                ) : null}
                <tr className="border-t border-line">
                  <td className="py-2 font-bold text-accent">{row.rank || "–"}</td>
                  <td className="py-2">
                    <button type="button" onClick={() => onTeam(row.team.id)} className="flex items-center gap-2 text-start">
                      <Crest src={row.team.logo} name={row.team.name} className="size-7" />
                      <span className="text-sm">{row.team.name}</span>
                    </button>
                  </td>
                  <td>{row.played}</td>
                  <td>{row.won}</td>
                  <td>{row.draw}</td>
                  <td>{row.lost}</td>
                  <td>{row.gd}</td>
                  <td className="font-bold">{row.pts}</td>
                </tr>
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function SectionTitle({ children, action }: { children: string; action?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between px-4">
      <h2 className="text-base font-bold">{children}</h2>
      {action}
    </div>
  );
}
