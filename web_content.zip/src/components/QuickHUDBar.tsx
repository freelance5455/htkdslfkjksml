import React from 'react';
import { BatteryCharging, Battery, Clock, CloudSun, Shield, Volume2, Camera, Bell, Phone, Activity, Smartphone, Database, Scan, Layers, Download } from 'lucide-react';
import { BatteryStatus, WeatherData } from '../types';

interface QuickHUDBarProps {
  battery: BatteryStatus;
  weather: WeatherData | null;
  indiaTime: string;
  onOpenBlueprint: () => void;
  onOpenVision: () => void;
  onOpenAlarms: () => void;
  onOpenPhone: () => void;
  onOpenSecurity: () => void;
  onOpenMemory: () => void;
  onOpenDiagnostics: () => void;
  onOpenAndroid: () => void;
  onOpenVirtualXRay: () => void;
  onOpenFeatureBuilder: () => void;
  onOpenAuth: () => void;
  onTriggerEmergency: () => void;
  onTakeScreenshot: () => void;
  onPlayVoiceSample?: () => void;
  onOpenVoiceSettings?: () => void;
  onOpenMissionControl?: () => void;
  onOpenDevices?: () => void;
}

export const QuickHUDBar: React.FC<QuickHUDBarProps> = ({
  battery,
  weather,
  indiaTime,
  onOpenBlueprint,
  onOpenVision,
  onOpenAlarms,
  onOpenPhone,
  onOpenSecurity,
  onOpenMemory,
  onOpenDiagnostics,
  onOpenAndroid,
  onOpenVirtualXRay,
  onOpenFeatureBuilder,
  onOpenAuth,
  onTriggerEmergency,
  onTakeScreenshot,
  onPlayVoiceSample,
  onOpenVoiceSettings,
  onOpenMissionControl,
  onOpenDevices,
}) => {
  return (
    <header className="w-full bg-gray-950/90 backdrop-blur-md border-b border-cyan-500/30 sticky top-0 z-40 px-3 py-2 sm:px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2">
        {/* Left: Branding & Time */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse glow-cyan-sm" />
            <h1 className="font-tech text-base sm:text-lg font-bold tracking-widest text-cyan-100 flex items-center gap-1.5">
              J.A.R.V.I.S.
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono-tech border border-cyan-500/40">
                MARK VII
              </span>
            </h1>
          </div>

          {/* Time & India Clock (Strict 12-Hour AM/PM) */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-900 border border-cyan-500/20 text-xs font-mono-tech text-cyan-300">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{indiaTime || '12:00:00 AM'}</span>
          </div>
        </div>

        {/* Center: Live Telemetry (Battery & Real Location Weather) */}
        <div className="flex items-center gap-2 sm:gap-3 text-xs font-mono-tech">
          {/* Weather Pill with Real Location, Sunrise & Sunset */}
          {weather && (
            <div 
              title={`Live GPS Location: ${weather.location} | Sunrise: ${weather.sunrise12 || '6:30 AM'} | Sunset: ${weather.sunset12 || '5:48 PM'}`}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-900 border border-cyan-500/20 text-cyan-200"
            >
              <CloudSun className="w-3.5 h-3.5 text-amber-400" />
              <span>{Math.round(weather.temperature)}°C</span>
              <span className="text-cyan-400/90 font-medium truncate max-w-[110px] sm:max-w-[150px]">
                {weather.location}
              </span>
              {weather.sunrise12 && weather.sunset12 && (
                <span className="text-[10px] text-cyan-300/80 hidden lg:inline font-mono-tech border-l border-cyan-500/30 pl-1.5 ml-0.5">
                  ↑ {weather.sunrise12} • ↓ {weather.sunset12}
                </span>
              )}
            </div>
          )}

          {/* Battery Pill */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-900 border border-cyan-500/20 text-cyan-200">
            {battery.charging ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className={`w-4 h-4 ${battery.level <= 15 ? 'text-red-400' : 'text-cyan-400'}`} />
            )}
            <span className={battery.level <= 15 ? 'text-red-400 font-bold' : ''}>
              {battery.supported ? `${battery.level}%` : 'Batt N/A'}
            </span>
          </div>

          {/* Permanent Natural Male Voice Locked Badge & Reference Player */}
          <button
            onClick={() => {
              if (onOpenVoiceSettings) onOpenVoiceSettings();
              else if (onPlayVoiceSample) onPlayVoiceSample();
            }}
            type="button"
            title="JARVIS Master Core // Permanent ElevenLabs George (Voice ID: JBFqnCBsd6RMkjVDRZzb, Multilingual V2) — Click to open Voice Calibration & Preview Console"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-950/80 hover:bg-cyan-900/90 border border-cyan-500/40 text-[10px] text-cyan-200 font-tech uppercase glow-cyan-sm select-none transition-all cursor-pointer active:scale-95"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold tracking-wider">ELEVENLABS GEORGE // BRITISH MALE</span>
          </button>
        </div>

        {/* Right: Quick Action Hub Buttons */}
        <div className="flex items-center gap-1.5 w-full md:w-auto justify-end overflow-x-auto py-0.5">
          {onOpenMissionControl && (
            <button
              onClick={onOpenMissionControl}
              title="Mission Control // 10-Agent System"
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400 text-indigo-200 text-xs font-tech uppercase flex items-center gap-1 transition-all glow-cyan-sm cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-indigo-300 animate-pulse" />
              <span className="font-bold">Agents</span>
            </button>
          )}

          {onOpenDevices && (
            <button
              onClick={onOpenDevices}
              title="Universal Device Registry (Car, TV, Bluetooth)"
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Devices</span>
            </button>
          )}
          <button
            onClick={onOpenBlueprint}
            title="Iron Man Blueprint Scanner"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase flex items-center gap-1 transition-all glow-cyan-sm"
          >
            <Scan className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
            <span className="font-bold">Blueprint</span>
          </button>

          <button
            onClick={onOpenVision}
            title="Vision AI (Google Lens)"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors"
          >
            <Camera className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Vision</span>
          </button>

          <button
            onClick={onOpenAlarms}
            title="Alarm System"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors"
          >
            <Bell className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Alarm</span>
          </button>

          <button
            onClick={onOpenPhone}
            title="Calls & Phone Control"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Phone</span>
          </button>

          <button
            onClick={onOpenSecurity}
            title="Website Security Shield"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Safe Web</span>
          </button>

          <button
            onClick={onOpenMemory}
            title="Neural Memory & Privacy"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors"
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Memory</span>
          </button>

          <button
            onClick={onOpenDiagnostics}
            title="System Diagnostics & Health"
            className="p-1.5 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 transition-colors"
          >
            <Activity className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onOpenVirtualXRay}
            title="3D Virtual X-Ray CAD Engine"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400 text-indigo-200 text-xs font-tech uppercase flex items-center gap-1 transition-all glow-cyan-sm cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden sm:inline font-bold">3D X-Ray</span>
          </button>

          <button
            onClick={onOpenAuth}
            title="Biometric Passkey & Voice Lock"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Passkey</span>
          </button>

          <button
            onClick={onOpenFeatureBuilder}
            title="JARVIS Modular Feature Builder"
            className="p-1.5 rounded-lg bg-gray-900 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 transition-colors cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onTriggerEmergency}
            title="Emergency SOS Dispatcher"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 text-red-300 text-xs font-tech uppercase flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Phone className="w-3.5 h-3.5 text-red-400" />
            <span className="hidden sm:inline">SOS</span>
          </button>

          <button
            onClick={onOpenAndroid}
            title="Android APK Bridge & Export Center"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-300" />
            <span className="hidden sm:inline">APK</span>
          </button>

          <a
            href="/Jarvis_Complete_Project.zip"
            download="Jarvis_Complete_Project.zip"
            title="Download Complete JARVIS Project ZIP Backup"
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400 text-emerald-200 text-xs font-tech uppercase flex items-center gap-1 transition-all cursor-pointer glow-cyan-sm shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-emerald-300" />
            <span className="hidden sm:inline font-bold">ZIP</span>
          </a>
        </div>
      </div>
    </header>
  );
};
