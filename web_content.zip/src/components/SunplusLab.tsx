import React, { useState, useEffect } from 'react';
import { Radio, Play, Pause, RotateCw, Check, Sparkles, Terminal, Sliders, Cpu, Save } from 'lucide-react';
import { SUNPLUS_PROFILES } from '../data/defaultIrDatabase';
import { IrEncoder } from '../services/irEncoder';
import { IrPatternResult } from '../types/remote';

interface Props {
  onTestSignal: (signal: IrPatternResult, name: string) => void;
}

export const SunplusLab: React.FC<Props> = ({ onTestSignal }) => {
  const [selectedProfileIndex, setSelectedProfileIndex] = useState(0);
  const [customerHex, setCustomerHex] = useState('0x00FF');
  const [commandHex, setCommandHex] = useState('0x12');
  const [manualPronto, setManualPronto] = useState('0000 006D 0022 0000 0156 00AB 0015 0015 0015 0040 0015 0015');

  // Automated Code Hunter / Test Mode state
  const [isHunting, setIsHunting] = useState(false);
  const [huntIndex, setHuntIndex] = useState(0);

  const testCodes = [
    { title: 'كود 1: Sunplus 1506G القياسي', cust: 0x00FF, cmd: 0x12 },
    { title: 'كود 2: Sunplus Classic القديم', cust: 0xBF40, cmd: 0x40 },
    { title: 'كود 3: Sunplus Tiger / StarNet', cust: 0x807F, cmd: 0x45 },
    { title: 'كود 4: Sunplus Geant / Starsat', cust: 0x708F, cmd: 0x12 },
    { title: 'كود 5: Sunplus Redline', cust: 0x01FE, cmd: 0x12 },
    { title: 'كود 6: كود بديل 40BF', cust: 0x40BF, cmd: 0x12 },
  ];

  const currentHunt = testCodes[huntIndex];

  // Auto hunt effect
  useEffect(() => {
    let timer: any;
    if (isHunting) {
      timer = setInterval(() => {
        setHuntIndex((prev) => {
          const next = (prev + 1) % testCodes.length;
          const candidate = testCodes[next];
          const sig = IrEncoder.encodeSunplus(candidate.cust, candidate.cmd);
          onTestSignal(sig, `[فحص تلقائي] ${candidate.title}`);
          return next;
        });
      }, 2000);
    }
    return () => clearInterval(timer);
  }, [isHunting, testCodes, onTestSignal]);

  const handleManualTest = () => {
    try {
      const custVal = parseInt(customerHex, 16);
      const cmdVal = parseInt(commandHex, 16);
      const sig = IrEncoder.encodeSunplus(custVal, cmdVal);
      onTestSignal(sig, `Sunplus مخصص (Cust: ${customerHex}, Cmd: ${commandHex})`);
    } catch (e: any) {
      alert('صيغة Hex غير صحيحة');
    }
  };

  const handleTestPronto = () => {
    try {
      const sig = IrEncoder.parseProntoHex(manualPronto);
      onTestSignal(sig, 'Pronto Hex يدوي');
    } catch (e: any) {
      alert(e.message || 'خطأ في تنسيق Pronto');
    }
  };

  const sendSingleHuntCode = (index: number) => {
    setHuntIndex(index);
    const candidate = testCodes[index];
    const sig = IrEncoder.encodeSunplus(candidate.cust, candidate.cmd);
    onTestSignal(sig, `[تجربة يدوية] ${candidate.title}`);
  };

  return (
    <div className="space-y-6">
      {/* Intro Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/20 rounded-2xl p-4 flex items-start gap-3">
        <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl mt-0.5">
          <Cpu className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-bold text-white text-base">مختبر معالجات صن بلص (Sunplus Receiver Lab)</h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            يدعم معالجات SPHE1506G و 1506TV و 1507 و 2507 و Tiger و Senator و Redline. يعتمد بروتوكول NEC Extended بتردد 38kHz مع كود عميل 16-bit وأمر 8-bit.
          </p>
        </div>
      </div>

      {/* Code Hunting Mode (وضع تجربة الأكواد لزر الباور) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h4 className="font-bold text-white text-sm">وضع تجربة الأكواد (Code Hunting & Pairing)</h4>
          </div>

          <button
            onClick={() => {
              if (!isHunting) {
                // start and test first
                const candidate = testCodes[huntIndex];
                const sig = IrEncoder.encodeSunplus(candidate.cust, candidate.cmd);
                onTestSignal(sig, `[بدء الفحص] ${candidate.title}`);
              }
              setIsHunting(!isHunting);
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              isHunting
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950'
            }`}
          >
            {isHunting ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isHunting ? 'إيقاف التجربة التلقائية' : 'بدء فحص الأكواد تلقائياً (كل ثانيتين)'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          وجّه الهاتف نحو جهاز الريسيفر. يقوم التطبيق ببث أكواد زر Power المختلفة بالتتابع حتى يطفأ أو يشتغل الريسيفر:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 mb-4">
          {testCodes.map((item, idx) => (
            <div
              key={idx}
              onClick={() => sendSingleHuntCode(idx)}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                huntIndex === idx
                  ? 'bg-amber-500/20 border-amber-500/80 shadow-md ring-1 ring-amber-500/40'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-xs text-white">{item.title}</span>
                {huntIndex === idx && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>}
              </div>
              <div className="font-mono text-[11px] text-slate-400">
                Cust: 0x{item.cust.toString(16).toUpperCase().padStart(4, '0')} | Cmd: 0x{item.cmd.toString(16).toUpperCase()}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
          <div className="text-xs">
            <span className="text-slate-400">الكود النشط حالياً: </span>
            <span className="font-mono font-bold text-amber-400">{currentHunt.title}</span>
          </div>
          <button
            onClick={() => {
              setIsHunting(false);
              alert(`تهانينا! تم حفظ البروفايل ${currentHunt.title} بنجاح.`);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
          >
            <Check className="w-4 h-4" />
            <span>جهازي استجاب! احفظ هذا الكود</span>
          </button>
        </div>
      </div>

      {/* Manual Hex Input & Testing Mode */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-4">
          <Terminal className="w-5 h-5 text-cyan-400" />
          <h4 className="font-bold text-white text-sm">محرر الأكواد اليدوي (Manual Hex & Address Injection)</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              كود العميل (Customer Code 16-bit)
            </label>
            <input
              type="text"
              value={customerHex}
              onChange={(e) => setCustomerHex(e.target.value)}
              placeholder="0x00FF"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-cyan-400 font-mono text-sm focus:border-cyan-500 outline-none"
            />
            <span className="text-[10px] text-slate-500 mt-0.5 block">أمثلة: 0x00FF, 0xBF40, 0x807F</span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              كود الأمر (Command Code 8-bit)
            </label>
            <input
              type="text"
              value={commandHex}
              onChange={(e) => setCommandHex(e.target.value)}
              placeholder="0x12"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-cyan-400 font-mono text-sm focus:border-cyan-500 outline-none"
            />
            <span className="text-[10px] text-slate-500 mt-0.5 block">0x12 (Power), 0x1A (Vol+), 0x10 (Mute)</span>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleManualTest}
              className="w-full py-2.5 bg-cyan-500 hover:bg-cyan-400 active:scale-95 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Radio className="w-4 h-4" />
              <span>إرسال وتجربة الإشارة الآن</span>
            </button>
          </div>
        </div>

        {/* Pronto Hex input */}
        <div className="border-t border-slate-800/80 pt-4 mt-2">
          <label className="block text-xs font-medium text-purple-400 mb-1">
            صيغة Pronto Hex (أكواد LIRC و RemoteCentral)
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={manualPronto}
              onChange={(e) => setManualPronto(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-purple-300 font-mono text-xs focus:border-purple-500 outline-none"
            />
            <button
              onClick={handleTestPronto}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5"
            >
              <Radio className="w-4 h-4" />
              <span>فحص Pronto</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
