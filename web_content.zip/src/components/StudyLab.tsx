import React, { useState } from 'react';
import { 
  ClipboardList, 
  Sparkles, 
  BookOpen, 
  RotateCw, 
  Plus, 
  RefreshCw, 
  AlertCircle, 
  Bookmark, 
  Lightbulb, 
  ChevronRight, 
  Check, 
  Layers,
  Award
} from 'lucide-react';
import { Subject, NotesType, Flashcard } from '../types';

interface StudyLabProps {
  language: string;
}

export default function StudyLab({ language }: StudyLabProps) {
  const [activeTab, setActiveTab] = useState<'notes' | 'flashcards'>('notes');

  // Notes States
  const [notesTopic, setNotesTopic] = useState<string>('');
  const [notesSubject, setNotesSubject] = useState<Subject>('Science');
  const [notesType, setNotesType] = useState<NotesType>('short');
  const [notesLoading, setNotesLoading] = useState<boolean>(false);
  const [notesResult, setNotesResult] = useState<any | null>(null);
  const [notesError, setNotesError] = useState<string>('');

  // Flashcards States
  const [cardDeckTopic, setCardDeckTopic] = useState<string>('');
  const [cardsLoading, setCardsLoading] = useState<boolean>(false);
  const [cards, setCards] = useState<Flashcard[]>([
    { id: '1', front: 'পলাশীর যুদ্ধ কবে হয়েছিল এবং কার কার মধ্যে হয়েছিল?', back: '১৭৫৭ সালের ২৩শে জুন। বাংলার শেষ স্বাধীন নবাব সিরাজউদ্দৌলা এবং ব্রিটিশ ইস্ট ইন্ডিয়া কোম্পানির রবার্ট ক্লাইভের মধ্যে যুদ্ধ হয়েছিল।', subject: 'History' },
    { id: '2', front: 'সালোকসংশ্লেষের প্রধান কাঁচামাল কী কী?', back: '১. জল (H2O) - যা উদ্ভিদ শিকড় দ্বারা শোষণ করে।\n২. কার্বন ডাইঅক্সাইড (CO2) - যা পাতা বাতাস থেকে গ্রহণ করে।', subject: 'Science' },
    { id: '3', front: 'একচল বিশিষ্ট দ্বিঘাত সমীকরণ কী?', back: 'যে সমীকরণকে ax² + bx + c = 0 আকারে প্রকাশ করা যায়, যেখানে a, b, c বাস্তব সংখ্যা এবং a ≠ 0।', subject: 'Mathematics' }
  ]);
  const [activeCardIndex, setActiveCardIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [cardsError, setCardsError] = useState<string>('');

  const translations: Record<string, Record<string, string>> = {
    en: {
      lab: 'Study Lab & Active Recall',
      labSub: 'Double your retention rates with custom study sheets, summaries, and interactive active recall flashcards.',
      tabNotes: 'Smart Study Notes',
      tabCards: 'Active Recall Flashcards',
      topicLabel: 'What topic do you need study notes for?',
      topicPlaceholder: 'E.g., Indian Independence Movement or Organic Chemistry',
      notesTypeLabel: 'Notes Format Type:',
      notesTypeClass: 'Class Lecture Notes',
      notesTypeShort: 'Short Fact Sheets',
      notesTypeExam: 'Exam Prep Q&As',
      notesTypeLast: 'Last-Minute Revision Sheet',
      generateNotes: 'Generate Study Notes',
      generateCards: 'Generate Flashcards with AI',
      cardPrompt: 'Enter topic to generate interactive cards:',
      cardPlaceholder: 'E.g., Trigonometry formulas or Periodic table',
      revealBtn: 'Click Card to Flip / Reveal',
      prev: 'Previous Card',
      next: 'Next Card',
      noNotes: 'Type a topic and click generate to populate premium notes here.',
      notesHeading: 'AI Generated Classroom Notes',
      smartSummary: 'Summary Takeaway',
      smartEmphasis: 'Important Alert / Formula',
      studyProgress: 'Active Recall Flashcards Deck',
      cardCount: 'Card Number'
    },
    bn: {
      lab: 'স্টাডি ল্যাব (Smart Notes & Flash Cards)',
      labSub: 'পরীক্ষার প্রস্তুতি দ্রুত করার জন্য নিখুঁত সেলফ-স্টাডি নোটস তৈরি ও ফ্ল্যাশ কার্ড দিয়ে অনুশীলন করো।',
      tabNotes: 'স্মার্ট ক্লাস নোটস',
      tabCards: 'অ্যাক্টিভ ফ্ল্যাশ কার্ড',
      topicLabel: 'কোন বিষয়ে স্টাডি নোটস প্রয়োজন?',
      topicPlaceholder: 'যেমন: ভারতের স্বাধীনতা আন্দোলন বা জৈব রসায়ন',
      notesTypeLabel: 'নোটসের ধরন নির্বাচন করুন:',
      notesTypeClass: 'বিস্তারিত লেকচার নোটস',
      notesTypeShort: 'সংक्षिप्त রিভিশন নোটস',
      notesTypeExam: 'পরীক্ষামুখী প্রশ্ন-উত্তর',
      notesTypeLast: 'শেষ মুহূর্তের শিট (Cheat sheet)',
      generateNotes: 'নোটস তৈরি করুন',
      generateCards: 'AI ফ্ল্যাশ কার্ড তৈরি করুন',
      cardPrompt: 'যে বিষয়ের ফ্ল্যাশ কার্ড বানাতে চাও লেখো:',
      cardPlaceholder: 'যেমন: সালোকসংশ্লেষ বা মুঘল সাম্রাজ্য',
      revealBtn: 'উত্তর দেখতে ট্যাপ করুন (Flip)',
      prev: 'আগের কার্ড',
      next: 'পরের কার্ড',
      noNotes: 'স্টাডি নোটস তৈরির জন্য বিষয়বস্তু লিখুন।',
      notesHeading: 'AI জেনারেটেড ক্লাস নোটস',
      smartSummary: 'সংक्षिप्त সারকথা',
      smartEmphasis: 'বিশেষ দ্রষ্টব্য (Note)',
      studyProgress: 'আজকের ফ্ল্যাশ কার্ড ডেক',
      cardCount: 'কার্ড নম্বর'
    },
    hi: {
      lab: 'स्टडी लैब और एक्टिव रिकॉल',
      labSub: 'कस्टम अध्ययन पत्रक, सारांश, और इंटरैक्टिव एक्टिव रिकॉल फ्लैशकार्ड के साथ अपनी स्मरण शक्ति बढ़ाएं।',
      tabNotes: 'स्मार्ट स्टडी नोट्स',
      tabCards: 'एक्टिव रिकॉल फ्लैशकार्ड',
      topicLabel: 'आपको किस विषय के लिए स्टडी नोट्स चाहिए?',
      topicPlaceholder: 'जैसे: भारतीय स्वतंत्रता आंदोलन या कार्बनिक रसायन विज्ञान',
      notesTypeLabel: 'नोट्स का प्रारूप:',
      notesTypeClass: 'विस्तृत व्याख्यान नोट्स',
      notesTypeShort: 'संक्षिप्त तथ्य पत्रक',
      notesTypeExam: 'परीक्षा तैयारी प्रश्न-उत्तर',
      notesTypeLast: 'अंतिम मिनट संशोधन पत्रक',
      generateNotes: 'स्टडी नोट्स बनाएं',
      generateCards: 'एआई फ्लैशकार्ड बनाएं',
      cardPrompt: 'फ्लैशकार्ड बनाने के लिए विषय लिखें:',
      cardPlaceholder: 'जैसे: त्रिकोणमिति सूत्र या आवर्त सारणी',
      revealBtn: 'उत्तर देखने के लिए क्लिक करें (Flip)',
      prev: 'पिछला कार्ड',
      next: 'अगला कार्ड',
      noNotes: 'विषय लिखें और प्रीमियम नोट्स देखने के लिए जनरेट पर क्लिक करें।',
      notesHeading: 'एआई जनरेटेड क्लास नोट्स',
      smartSummary: 'संक्षिप्त निष्कर्ष',
      smartEmphasis: 'विशेष नोट / सूत्र',
      studyProgress: 'एक्टिव रिकॉल फ्लैशकार्ड डेक',
      cardCount: 'कार्ड संख्या'
    },
    es: {
      lab: 'Laboratorio de Estudio y Memorización',
      labSub: 'Duplica tu tasa de retención con resúmenes, guías de estudio personalizadas y flashcards interactivas.',
      tabNotes: 'Notas de Estudio Inteligentes',
      tabCards: 'Flashcards de Memorización Activa',
      topicLabel: '¿Para qué tema necesitas notas de estudio?',
      topicPlaceholder: 'Ej. Revolución de Independencia o Química Orgánica',
      notesTypeLabel: 'Formato de Notas:',
      notesTypeClass: 'Notas de Conferencia Completas',
      notesTypeShort: 'Fichas de Datos Cortas',
      notesTypeExam: 'Preguntas y Respuestas para Examen',
      notesTypeLast: 'Hoja de Repaso de Último Minuto',
      generateNotes: 'Generar Notas de Estudio',
      generateCards: 'Generar Flashcards con IA',
      cardPrompt: 'Ingresa un tema para generar tarjetas interactivas:',
      cardPlaceholder: 'Ej. Fórmulas de Trigonometría o Tabla Periódica',
      revealBtn: 'Haz clic en la tarjeta para voltear / revelar',
      prev: 'Tarjeta Anterior',
      next: 'Siguiente Tarjeta',
      noNotes: 'Escribe un tema y haz clic en generar para obtener notas de estudio prémium.',
      notesHeading: 'Notas de Clase Generadas por IA',
      smartSummary: 'Resumen Clave',
      smartEmphasis: 'Alerta Importante / Fórmula',
      studyProgress: 'Mazo de Flashcards Activas',
      cardCount: 'Número de Tarjeta'
    },
    fr: {
      lab: 'Labo d\'Étude & Flashcards',
      labSub: 'Doublez votre taux de mémorisation avec des fiches de révision sur mesure et des flashcards interactives.',
      tabNotes: 'Notes d\'Études Intelligentes',
      tabCards: 'Flashcards de Mémorisation Active',
      topicLabel: 'Pour quel sujet avez-vous besoin de notes d\'étude ?',
      topicPlaceholder: 'Ex. Révolution française ou Chimie Organique',
      notesTypeLabel: 'Format des notes :',
      notesTypeClass: 'Notes de Cours Complètes',
      notesTypeShort: 'Fiches de Faits Synthétiques',
      notesTypeExam: 'Questions-Réponses de Préparation',
      notesTypeLast: 'Fiche de Révision de Dernière Minute',
      generateNotes: 'Générer des Notes d\'Étude',
      generateCards: 'Générer des Flashcards par IA',
      cardPrompt: 'Saisissez un sujet pour générer des cartes interactives :',
      cardPlaceholder: 'Ex. Formules de trigonométrie ou Tableau périodique',
      revealBtn: 'Cliquez sur la carte pour la retourner / révéler',
      prev: 'Carte Précédente',
      next: 'Carte Suivante',
      noNotes: 'Saisissez un sujet et cliquez sur générer pour afficher des notes de révision prémium.',
      notesHeading: 'Notes de Cours Générées par l\'IA',
      smartSummary: 'Résumé Synthétique',
      smartEmphasis: 'Alerte Importante / Formule',
      studyProgress: 'Paquet de Flashcards Actives',
      cardCount: 'Numéro de Carte'
    },
    ar: {
      lab: 'مختبر الدراسة والخرائط الذهنية',
      labSub: 'ضاعف مستوى استيعابك للمعلومات باستخدام خطط المذاكرة المخصصة والبطاقات التعليمية الذكية (Flashcards).',
      tabNotes: 'ملخصات وملاحظات الدراسة الذكية',
      tabCards: 'بطاقات التذكر النشط الذكية',
      topicLabel: 'ما الموضوع الذي تحتاج إلى ملاحظات دراسية فيه؟',
      topicPlaceholder: 'مثال: الثورة الفرنسية أو الكيمياء العضوية',
      notesTypeLabel: 'نوع وصيغة الملاحظات:',
      notesTypeClass: 'شرح وملاحظات محاضرات كاملة',
      notesTypeShort: 'ملخصات وحقائق سريعة',
      notesTypeExam: 'سؤال وجواب لتهيئة الامتحانات',
      notesTypeLast: 'ورقة المراجعة ولخصات اللحظة الأخيرة',
      generateNotes: 'إنشاء ملاحظات الدراسة',
      generateCards: 'إنشاء بطاقات ذكية بالذكاء الاصطناعي',
      cardPrompt: 'اكتب اسم الدرس لإنشاء البطاقات التعليمية التفاعلية:',
      cardPlaceholder: 'مثال: قوانين المثلثات أو الجدول الدوري',
      revealBtn: 'اضغط على البطاقة لقلبها وعرض الإجابة',
      prev: 'البطاقة السابقة',
      next: 'البطاقة التالية',
      noNotes: 'اكتب اسم الدرس واضغط على زر الإنشاء لإنشاء ملخصات وملاحظات دراسية ممتازة.',
      notesHeading: 'ملخصات الدرس المصممة بالذكاء الاصطناعي',
      smartSummary: 'أهم خلاصات الدرس',
      smartEmphasis: 'تنبيه هام / قانون أساسي',
      studyProgress: 'مجموعة بطاقات التذكر النشط الفعالة',
      cardCount: 'رقم البطاقة'
    }
  };

  const t = translations[language] || translations['en'];
  // Generate Smart Notes Call
  const handleGenerateNotes = async () => {
    if (!notesTopic.trim()) {
      setNotesError('Please type a topic to generate notes.');
      return;
    }

    setNotesLoading(true);
    setNotesError('');
    setNotesResult(null);

    try {
      const response = await fetch('/api/gemini/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: notesTopic,
          subject: notesSubject,
          notesType,
          language
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate study notes.');
      }

      const data = await response.json();
      setNotesResult(data);
    } catch (err: any) {
      setNotesError(err.message || 'Error occurred generating notes.');
    } finally {
      setNotesLoading(false);
    }
  };

  // Generate Flashcards Call
  const handleGenerateCards = async () => {
    if (!cardDeckTopic.trim()) {
      setCardsError('Please type a topic for flashcards.');
      return;
    }

    setCardsLoading(true);
    setCardsError('');

    try {
      const response = await fetch('/api/gemini/flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: cardDeckTopic,
          subject: 'General',
          language
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate flashcards.');
      }

      const data = await response.json();
      if (data.cards && data.cards.length > 0) {
        const mappedCards = data.cards.map((c: any, index: number) => ({
          id: `ai-${index}-${Date.now()}`,
          front: c.front,
          back: c.back,
          subject: 'General'
        }));
        setCards(mappedCards);
        setActiveCardIndex(0);
        setIsFlipped(false);
      } else {
        throw new Error('No flashcards returned from AI.');
      }
    } catch (err: any) {
      setCardsError(err.message || 'Error occurred.');
    } finally {
      setCardsLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 md:p-10 space-y-8">
      {/* Title */}
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-800 font-display tracking-tight flex items-center gap-2">
          <ClipboardList className="w-7 h-7 text-indigo-500" /> {t.lab}
        </h1>
        <p className="text-sm text-slate-500 mt-1">{t.labSub}</p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => { setActiveTab('notes'); }}
          className={`py-3 px-6 text-sm font-bold border-b-2 transition-all ${
            activeTab === 'notes'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          📝 {t.tabNotes}
        </button>
        <button
          onClick={() => { setActiveTab('flashcards'); }}
          className={`py-3 px-6 text-sm font-bold border-b-2 transition-all ${
            activeTab === 'flashcards'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          🎴 {t.tabCards}
        </button>
      </div>

      {/* TAB 1: NOTES GENERATOR */}
      {activeTab === 'notes' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Notes Configurator */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5 h-fit">
            <div>
              <h3 className="font-bold text-slate-800 text-base">নোটস সেটআপ</h3>
              <p className="text-xs text-slate-500 mt-0.5">আপনার অধ্যায়ের নোটসের ফরম্যাট পছন্দ করুন</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">{t.topicLabel}</label>
                <input
                  type="text"
                  placeholder={t.topicPlaceholder}
                  value={notesTopic}
                  onChange={(e) => setNotesTopic(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl py-3 px-4 text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">বিষয় নির্বাচন করুন</label>
                <select
                  value={notesSubject}
                  onChange={(e) => setNotesSubject(e.target.value as Subject)}
                  className="w-full border border-slate-200 rounded-xl py-3 px-4 text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                >
                  <option value="Science">Science (বিজ্ঞান)</option>
                  <option value="Mathematics">Mathematics (গণিত)</option>
                  <option value="History">History (ইতিহাস)</option>
                  <option value="Geography">Geography (ভূগোল)</option>
                  <option value="English">English (ইংরেজি)</option>
                  <option value="Bengali">Bengali (বাংলা)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t.notesTypeLabel}</label>
                <div className="space-y-2">
                  {[
                    { id: 'class', label: t.notesTypeClass },
                    { id: 'short', label: t.notesTypeShort },
                    { id: 'exam', label: t.notesTypeExam },
                    { id: 'last_minute', label: t.notesTypeLast }
                  ].map((item) => (
                    <label
                      key={item.id}
                      onClick={() => setNotesType(item.id as NotesType)}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        notesType === item.id
                          ? 'bg-indigo-50 border-indigo-400 font-semibold text-indigo-900'
                          : 'bg-slate-50 border-slate-100 hover:bg-slate-100 text-slate-600'
                      }`}
                    >
                      <input
                        type="radio"
                        name="notesType"
                        checked={notesType === item.id}
                        onChange={() => {}}
                        className="hidden"
                      />
                      <span className="text-xs">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerateNotes}
                disabled={notesLoading}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                {notesLoading ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    AI স্টাডি নোটস সাজাচ্ছে...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    {t.generateNotes}
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Notes Result Board */}
          <div className="lg:col-span-2 space-y-6">
            {notesLoading && (
              <div className="bg-white rounded-2xl border border-slate-200 p-10 shadow-sm flex flex-col items-center justify-center text-center space-y-4 min-h-[450px]">
                <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
                <h3 className="font-bold text-slate-800 text-lg">স্মার্ট নোটস তৈরি হচ্ছে</h3>
                <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                  পরীক্ষার জন্য অত্যন্ত উপযোগী, পয়েন্ট পয়েন্ট করা স্টাডি নোটস এবং সংক্ষিপ্ত সূত্রগুলো AI গুছিয়ে আনছে। একটু অপেক্ষা করুন...
                </p>
              </div>
            )}

            {notesError && (
              <div className="bg-rose-50 border border-rose-100 text-rose-800 p-5 rounded-2xl flex items-start gap-3">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-500 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm">নোটস তৈরিতে সমস্যা হয়েছে</h4>
                  <p className="text-xs text-rose-600 mt-1">{notesError}</p>
                </div>
              </div>
            )}

            {!notesResult && !notesLoading && !notesError && (
              <div className="bg-white rounded-2xl border border-slate-200 p-10 shadow-sm flex flex-col items-center justify-center text-center space-y-3 min-h-[450px] text-slate-400">
                <ClipboardList className="w-16 h-16 text-slate-300 stroke-[1.5]" />
                <h3 className="font-bold text-slate-700 text-base">{t.notesHeading}</h3>
                <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                  বামদিকের বক্সে যেকোনো অধ্যায়ের নাম লিখে জেনারেট বাটনে চাপুন। AI আপনার জন্য সম্পূর্ণ রেডিমেড পরীক্ষার নোটস তৈরি করে সাজিয়ে দেবে।
                </p>
              </div>
            )}

            {notesResult && !notesLoading && (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-sm animate-fade-in space-y-6">
                <div className="border-b border-slate-100 pb-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-bold uppercase tracking-wider">{notesType}</span>
                    <h2 className="text-xl md:text-2xl font-bold font-display text-slate-800 mt-1">{notesResult.title}</h2>
                  </div>
                  <span className="text-xs font-bold text-slate-400">{notesSubject}</span>
                </div>

                {/* Notes Sections */}
                <div className="space-y-6">
                  {notesResult.sections?.map((sec: any, idx: number) => (
                    <div key={idx} className="space-y-3">
                      <h4 className="font-extrabold text-sm text-slate-800 flex items-center gap-2">
                        <span className="w-5 h-5 bg-indigo-600 text-white rounded-full flex items-center justify-center text-[10px] font-display font-bold">
                          {idx + 1}
                        </span>
                        {sec.heading}
                      </h4>
                      <ul className="space-y-2 pl-6 list-disc text-xs text-slate-600 leading-relaxed font-medium">
                        {sec.content?.map((point: string, pIdx: number) => (
                          <li key={pIdx}>{point}</li>
                        ))}
                      </ul>
                      {sec.emphasis && (
                        <div className="p-3 bg-indigo-50 border-l-4 border-indigo-500 rounded-r-xl text-xs text-indigo-950 font-bold flex gap-2">
                          <Lightbulb className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                          <span>{sec.emphasis}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Summary Quote */}
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl text-center italic text-xs text-slate-500 font-medium">
                  "{notesResult.summaryQuote}"
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: FLASHCARDS Recall */}
      {activeTab === 'flashcards' && (
        <div className="max-w-2xl mx-auto space-y-8">
          
          {/* AI Flashcard Generator section */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
                AI ফ্ল্যাশ কার্ড জেনারেটর (AI Flashcards)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">যেকোনো বিষয় বা অধ্যায়ের নাম লিখে জেনারেট বাটনে চাপুন। AI আপনার জন্য ৪টি দারুণ একটিভ রিকল ফ্ল্যাশ কার্ড তৈরি করবে।</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                placeholder={t.cardPlaceholder}
                value={cardDeckTopic}
                onChange={(e) => setCardDeckTopic(e.target.value)}
                className="flex-1 border border-slate-200 rounded-xl py-2.5 px-4 text-xs font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
              <button
                onClick={handleGenerateCards}
                disabled={cardsLoading}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 shrink-0"
              >
                {cardsLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    তৈরি হচ্ছে...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    {t.generateCards}
                  </>
                )}
              </button>
            </div>
            {cardsError && (
              <p className="text-xs font-semibold text-rose-500 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {cardsError}
              </p>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5 text-center">
            <div>
              <h3 className="font-bold text-slate-800 text-base">{t.studyProgress}</h3>
              <p className="text-xs text-slate-500 mt-0.5">সঠিক উত্তর মনে করার কুইজ প্র্যাকটিস করো</p>
            </div>

            {/* Flashcard container with flip animation */}
            <div 
              onClick={() => setIsFlipped(!isFlipped)}
              className="group relative w-full h-80 cursor-pointer [perspective:1000px]"
            >
              <div 
                className={`relative w-full h-full duration-500 [transform-style:preserve-3d] ${
                  isFlipped ? '[transform:rotateY(180deg)]' : ''
                }`}
              >
                {/* Front Side */}
                <div className="absolute inset-0 w-full h-full rounded-3xl bg-gradient-to-tr from-slate-900 to-indigo-950 border border-slate-800 p-6 flex flex-col justify-between text-white shadow-xl [backface-visibility:hidden]">
                  <div className="flex justify-between items-center text-xs text-slate-400 font-semibold tracking-wider">
                    <span>{t.cardCount} {activeCardIndex + 1}/{cards.length}</span>
                    <span className="bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded font-bold uppercase tracking-wider">{cards[activeCardIndex]?.subject}</span>
                  </div>
                  
                  <div className="text-center px-4 py-8">
                    <h3 className="text-lg md:text-xl font-bold font-display leading-relaxed">
                      {cards[activeCardIndex]?.front}
                    </h3>
                  </div>

                  <div className="text-center text-[10px] font-bold text-indigo-400 tracking-wider flex items-center justify-center gap-1.5 uppercase">
                    <RotateCw className="w-3.5 h-3.5" />
                    {t.revealBtn}
                  </div>
                </div>

                {/* Back Side */}
                <div className="absolute inset-0 w-full h-full rounded-3xl bg-white border border-slate-200 p-6 flex flex-col justify-between text-slate-800 shadow-xl [transform:rotateY(180deg)] [backface-visibility:hidden]">
                  <div className="flex justify-between items-center text-xs text-slate-400 font-semibold">
                    <span>ANSWER / সমাধান</span>
                    <span className="bg-emerald-50 text-emerald-600 px-2.5 py-0.5 rounded-full font-bold">VERIFIED</span>
                  </div>
                  
                  <div className="text-center px-4 py-8 overflow-y-auto max-h-48">
                    <p className="text-sm md:text-base font-bold text-slate-700 leading-relaxed whitespace-pre-wrap">
                      {cards[activeCardIndex]?.back}
                    </p>
                  </div>

                  <div className="text-center text-[10px] font-bold text-emerald-600 tracking-wider flex items-center justify-center gap-1.5 uppercase">
                    <Check className="w-3.5 h-3.5" />
                    মনে পড়েছে? আবার ফ্লিপ করতে চাপুন
                  </div>
                </div>
              </div>
            </div>

            {/* Pagination / Controls */}
            <div className="flex items-center justify-between gap-4 max-w-xs mx-auto">
              <button
                onClick={() => {
                  setIsFlipped(false);
                  setActiveCardIndex(prev => Math.max(0, prev - 1));
                }}
                disabled={activeCardIndex === 0}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-50 disabled:opacity-40 text-slate-600 font-semibold text-xs rounded-xl transition-colors"
              >
                ← {t.prev}
              </button>
              
              <button
                onClick={() => {
                  setIsFlipped(false);
                  setActiveCardIndex(prev => Math.min(cards.length - 1, prev + 1));
                }}
                disabled={activeCardIndex === cards.length - 1}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-950 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition-all"
              >
                {t.next} →
              </button>
            </div>
          </div>

          {/* Custom Flashcard Creator Block */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-500" /> নতুন ফ্ল্যাশ কার্ড যুক্ত করুন
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">প্রশ্ন / সামনের দিক (Front)</label>
                <input
                  type="text"
                  placeholder="যেমন: ব্যাকটেরিওফাজ কী?"
                  id="card-front-input"
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">উত্তর / পিছনের দিক (Back)</label>
                <input
                  type="text"
                  placeholder="ব্যাকটেরিয়া ধ্বংসকারী ভাইরাস"
                  id="card-back-input"
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs font-semibold"
                />
              </div>
            </div>
            <button
              onClick={() => {
                const front = (document.getElementById('card-front-input') as HTMLInputElement)?.value;
                const back = (document.getElementById('card-back-input') as HTMLInputElement)?.value;
                if (front && back) {
                  setCards([...cards, {
                    id: String(cards.length + 1),
                    front,
                    back,
                    subject: 'General'
                  }]);
                  (document.getElementById('card-front-input') as HTMLInputElement).value = '';
                  (document.getElementById('card-back-input') as HTMLInputElement).value = '';
                }
              }}
              className="w-full py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 font-bold text-xs rounded-lg transition-colors"
            >
              ডেকে কার্ডটি সেভ করুন
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
