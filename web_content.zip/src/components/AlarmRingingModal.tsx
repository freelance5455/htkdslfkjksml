import React from 'react';
import { AlarmClockOff, Clock } from 'lucide-react';
import type { Language, RingingAlert } from '../types/study';
import { BellDomeIcon } from './LiquidIcons';

interface AlarmRingingModalProps {
  lang: Language;
  alert: RingingAlert | null;
  onDismiss: () => void;
  onSnooze: () => void;
}

export const AlarmRingingModal: React.FC<AlarmRingingModalProps> = ({
  lang,
  alert,
  onDismiss,
  onSnooze,
}) => {
  if (!alert) return null;

  const isBn = lang === 'bn';

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="ringing-alert-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-md"
    >
      <div className="liquid-glass-elevated w-full max-w-md rounded-3xl p-7 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-sky-300/40 bg-sky-400/20 text-sky-200 shadow-inner">
          <BellDomeIcon active className="h-8 w-8 animate-bounce" />
        </div>

        <p className="mt-4 text-xs font-medium text-sky-300">
          {alert.kind === 'alarm'
            ? isBn
              ? 'অ্যালার্ম'
              : 'Alarm'
            : alert.kind === 'pomodoro'
              ? isBn
                ? 'পোমোডোরো'
                : 'Pomodoro'
              : isBn
                ? 'টাইমার'
                : 'Timer'}
        </p>

        <h2 id="ringing-alert-title" className="mt-1.5 text-2xl font-bold text-white text-balance">
          {alert.title}
        </h2>
        <p className="mt-2 text-sm text-slate-300">{alert.subtitle}</p>

        <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {alert.kind === 'alarm' && (
            <button
              type="button"
              onClick={onSnooze}
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/20 whitespace-nowrap"
            >
              <Clock className="h-4 w-4" aria-hidden="true" />
              <span>{isBn ? '৫ মিনিট স্নুজ' : 'Snooze 5m'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={onDismiss}
            className={`inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-4 py-2.5 text-sm font-semibold text-slate-950 transition hover:bg-sky-300 whitespace-nowrap ${
              alert.kind !== 'alarm' ? 'sm:col-span-2' : ''
            }`}
          >
            <AlarmClockOff className="h-4 w-4" aria-hidden="true" />
            <span>{isBn ? 'বন্ধ করুন' : 'Dismiss'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
