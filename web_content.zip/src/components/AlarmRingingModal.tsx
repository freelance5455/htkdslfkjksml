import React, { useState } from 'react';
import { Bell, BellOff, Clock, CheckCircle2, VolumeX, Layers } from 'lucide-react';
import { Task } from '../types';
import { useApp } from '../context/AppContext';
import { SOUND_LIBRARY } from '../utils/audioManager';

interface AlarmRingingModalProps {
  task: Task | null;
  tasks?: Task[];
  onDismiss: (taskId?: string) => void;
  onDismissAll?: () => void;
  onSnooze: (task: Task) => void;
  onComplete: (task: Task) => void;
  onSilence?: () => void;
}

export const AlarmRingingModal: React.FC<AlarmRingingModalProps> = ({
  task,
  tasks = [],
  onDismiss,
  onDismissAll,
  onSnooze,
  onComplete,
  onSilence,
}) => {
  const { language } = useApp();
  const isBn = language === 'bn';

  // Determine active task list
  const activeTaskList = tasks.length > 0 ? tasks : task ? [task] : [];
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(0);

  if (activeTaskList.length === 0) return null;

  // Safe active task selection
  const currentTask = activeTaskList[selectedTaskIndex] || activeTaskList[0];
  const soundName = SOUND_LIBRARY.find((s) => s.id === currentTask.ringtone)?.nameBn || currentTask.ringtone || 'Morning Birds';

  const handleStopCurrent = () => {
    onDismiss(currentTask.id);
  };

  const handleStopAll = () => {
    if (onDismissAll) {
      onDismissAll();
    } else {
      onDismiss();
    }
  };

  const handleSnoozeCurrent = () => {
    onSnooze(currentTask);
  };

  const handleCompleteCurrent = () => {
    onComplete(currentTask);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-linear-to-b from-slate-900 via-slate-900 to-indigo-950 border border-slate-700/80 p-5 shadow-2xl text-white text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Multi-Alarm Selector Tabs if multiple alarms are ringing at once */}
        {activeTaskList.length > 1 && (
          <div className="mb-3 p-1.5 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center gap-1 overflow-x-auto">
            <span className="text-[10px] text-amber-400 font-bold px-2 flex items-center gap-1 shrink-0">
              <Layers size={12} />
              {isBn ? `${activeTaskList.length}টি অ্যালার্ম:` : `${activeTaskList.length} Alarms:`}
            </span>
            {activeTaskList.map((t, idx) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setSelectedTaskIndex(idx)}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold truncate max-w-[110px] transition-all ${
                  idx === selectedTaskIndex
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {t.title}
              </button>
            ))}
          </div>
        )}

        {/* Animated Ringing Bell Icon */}
        <div className="relative mx-auto my-3 w-20 h-20 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />
          <div className="absolute inset-1.5 rounded-full bg-violet-500/30 animate-pulse" />
          <div className="relative w-16 h-16 rounded-full bg-linear-to-tr from-rose-600 to-violet-600 flex items-center justify-center shadow-lg shadow-rose-500/40">
            <Bell size={32} className="text-white animate-bounce" />
          </div>
        </div>

        {/* Alarm Title & Tone Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-[11px] font-bold uppercase tracking-wider mb-2">
          <span>{isBn ? '🔔 স্মার্ট অ্যালার্ম বাজছে!' : '🔔 SMART ALARM RINGING!'}</span>
        </div>

        <h3 className="text-xl font-black text-white tracking-tight mb-1.5 line-clamp-2">
          {currentTask.title}
        </h3>

        {/* Scheduled Due Time */}
        <div className="flex items-center justify-center gap-2 text-xs text-slate-300 font-mono mb-2">
          <Clock size={14} className="text-violet-400" />
          <span>
            {isBn ? 'নির্ধারিত সময়: ' : 'Due Time: '}
            <strong className="text-white">{currentTask.dueTime || currentTask.dueDate}</strong>
          </span>
          {currentTask.alarmMinutesBefore ? (
            <span className="px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold text-[10px]">
              {currentTask.alarmMinutesBefore} {isBn ? 'মিনিট আগে' : 'min before'}
            </span>
          ) : null}
        </div>

        {/* Active Sound Tone Info */}
        <div className="text-[11px] text-slate-400 mb-3 flex items-center justify-center gap-1">
          <span>🎵 {isBn ? 'সুর: ' : 'Tone: '}</span>
          <span className="text-violet-300 font-semibold">{soundName}</span>
        </div>

        {/* Notes if provided */}
        {currentTask.notes && (
          <p className="text-xs text-slate-300 line-clamp-2 mb-4 italic bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60 text-left">
            "{currentTask.notes}"
          </p>
        )}

        {/* Hardware button silencing advice (Requirement 4) */}
        <div className="mb-4 py-1.5 px-3 rounded-xl bg-slate-800/80 border border-slate-700/80 text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
          <VolumeX size={13} className="text-amber-400 shrink-0" />
          <span>
            {isBn
              ? 'মোবাইলের ভলিউম বাটন চেপে এখনই সাউন্ড মিউট করতে পারেন'
              : 'Press Volume Up / Down or Power to silence sound'}
          </span>
        </div>

        {/* Action Buttons (Requirement 3: Large touch-friendly buttons) */}
        <div className="space-y-2.5">
          {/* 1. Mark Complete */}
          <button
            type="button"
            onClick={handleCompleteCurrent}
            className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 active:scale-95 transition-all"
          >
            <CheckCircle2 size={18} />
            <span>{isBn ? 'কাজটি সম্পন্ন চিহ্নিত করুন' : 'Mark Task as Completed'}</span>
          </button>

          {/* 2. Dismiss / Stop Alarm */}
          <button
            type="button"
            onClick={handleStopCurrent}
            className="w-full py-3 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-rose-600/30 active:scale-95 transition-all"
          >
            <BellOff size={16} />
            <span>
              {activeTaskList.length > 1
                ? (isBn ? 'এই অ্যালার্মটি বন্ধ করুন' : 'Dismiss This Alarm')
                : (isBn ? 'অ্যালার্ম বন্ধ করুন' : 'Dismiss / Stop Alarm')}
            </span>
          </button>

          {/* 3. Snooze for 5 minutes */}
          <button
            type="button"
            onClick={handleSnoozeCurrent}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition-all flex items-center justify-center gap-1.5"
          >
            <Clock size={13} className="text-violet-400" />
            <span>{isBn ? '⏰ ৫ মিনিট পরে আবার বাজান (Snooze)' : '⏰ Snooze for 5 minutes'}</span>
          </button>

          {/* If multiple alarms, offer instant "Stop All" */}
          {activeTaskList.length > 1 && (
            <button
              type="button"
              onClick={handleStopAll}
              className="w-full py-2 px-3 rounded-lg bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 font-bold text-[11px] border border-rose-800/60 transition-colors"
            >
              {isBn ? 'একসাথে সব অ্যালার্ম বন্ধ করুন' : 'Dismiss All Alarms'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
