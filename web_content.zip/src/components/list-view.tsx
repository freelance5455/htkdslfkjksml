import { useMemo, useState, type FormEvent } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Download, Trash2 } from "lucide-react";
import { PickAreaMap, type AreaCount } from "@/components/area-map";
import { StatusPill } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FieldLabel, Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  confirmRented,
  createRoom,
  deleteRoom,
  listLeadsForRoom,
  listRoomCommissions,
  markCommissionPaid,
  reopenRoom,
} from "@/lib/rooms-api";
import {
  computeCommission,
  computeRenterCommission,
  downloadTextFile,
  fmtMoney,
  type RoomOwned,
  type RoomPublic,
} from "@/lib/rooms-model";
import { errorMessage } from "@/lib/utils";

export function ListView({
  rooms,
  mine,
  signedIn,
  loadingMine,
}: {
  rooms: RoomPublic[];
  mine: RoomOwned[];
  signedIn: boolean;
  loadingMine: boolean;
}) {
  const qc = useQueryClient();
  const [picked, setPicked] = useState("");
  const [posting, setPosting] = useState(false);

  const groups: AreaCount[] = useMemo(() => {
    const map: Record<string, number> = {};
    rooms.forEach((r) => {
      const area = (r.location || "").trim();
      if (area) map[area] = (map[area] || 0) + 1;
    });
    return Object.entries(map).map(([area, count]) => ({ area, count }));
  }, [rooms]);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!signedIn) {
      toast("Sign in to post a listing.");
      return;
    }
    const location = picked.trim();
    if (!location) {
      toast("Tap a pin or type an area name.");
      return;
    }
    const fd = new FormData(e.currentTarget);
    const num = (key: string) => {
      const v = String(fd.get(key) || "").trim();
      return v === "" ? 0 : Number(v);
    };
    setPosting(true);
    try {
      await createRoom({
        data: {
          title: String(fd.get("title") || ""),
          location,
          rent: num("rent"),
          currency: String(fd.get("currency") || ""),
          deposit: num("deposit"),
          availableFrom: String(fd.get("availableFrom") || ""),
          phone: String(fd.get("phone") || ""),
          whatsapp: String(fd.get("whatsapp") || ""),
          description: String(fd.get("description") || ""),
          commissionType: fd.get("commissionType") === "fixed" ? "fixed" : "percent",
          commissionValue: num("commissionValue"),
          renterCommissionType: fd.get("renterCommissionType") === "fixed" ? "fixed" : "percent",
          renterCommissionValue: num("renterCommissionValue"),
        },
      });
      toast("Listing posted.");
      e.currentTarget.reset();
      setPicked("");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["rooms"] }),
        qc.invalidateQueries({ queryKey: ["my-rooms"] }),
      ]);
    } catch (err) {
      toast(errorMessage(err, "Couldn't post listing — try again."));
    } finally {
      setPosting(false);
    }
  }

  function downloadCsv() {
    if (!mine.length) {
      toast("You have no listings to download yet.");
      return;
    }
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const header = ["Title", "Area", "Rent", "Currency", "Deposit", "Available from", "Status", "Phone", "WhatsApp", "Description"];
    const rows = mine.map((r) =>
      [r.title, r.location, r.rent, r.currency, r.deposit, r.availableFrom, r.status, r.phone, r.whatsapp, r.description]
        .map(esc)
        .join(","),
    );
    downloadTextFile("my-rentdirect-listings.csv", `\uFEFF${header.map(esc).join(",")}\n${rows.join("\n")}`);
    toast("Listings downloaded.");
  }

  return (
    <div>
      <section className="mb-6.5 rounded-lg border border-line bg-card p-5.5">
        <h2 className="font-serif mb-4 text-[19px] font-semibold">Post a room</h2>
        {!signedIn ? (
          <p className="mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
            Sign in to post a listing and get a trackable referral link.
          </p>
        ) : null}
        <form onSubmit={onSubmit}>
          <div className="mb-3.5">
            <FieldLabel htmlFor="f-title">Title</FieldLabel>
            <Input id="f-title" name="title" required placeholder="e.g. Sunny single room near campus" disabled={!signedIn} />
          </div>
          <div className="mb-3.5">
            <FieldLabel htmlFor="f-area">Room area</FieldLabel>
            <p className="mb-2 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
              Tap an existing area pin, or type a neighborhood. No street address needed.
            </p>
            <PickAreaMap groups={groups} picked={picked} onPickExisting={setPicked} />
            <Input
              id="f-area"
              className="mt-2"
              value={picked}
              onChange={(e) => setPicked(e.target.value)}
              placeholder="e.g. Thamel, Kathmandu"
              disabled={!signedIn}
            />
            <p className="mt-2 text-[13px] font-semibold text-ink-soft">
              {picked ? `Picked: ${picked}` : "No area picked yet"}
            </p>
          </div>
          <div className="mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <FieldLabel htmlFor="f-rent">Rent (per month)</FieldLabel>
              <Input id="f-rent" name="rent" type="number" min={0} step="0.01" required placeholder="e.g. 8000" disabled={!signedIn} />
            </div>
            <div>
              <FieldLabel htmlFor="f-currency">Currency</FieldLabel>
              <Input id="f-currency" name="currency" defaultValue="NPR" placeholder="e.g. NPR, USD, INR" disabled={!signedIn} />
            </div>
          </div>
          <div className="mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <FieldLabel htmlFor="f-deposit">Deposit (optional)</FieldLabel>
              <Input id="f-deposit" name="deposit" type="number" min={0} step="0.01" placeholder="e.g. 8000" disabled={!signedIn} />
            </div>
            <div>
              <FieldLabel htmlFor="f-available">Available from (optional)</FieldLabel>
              <Input id="f-available" name="availableFrom" placeholder="e.g. Oct 1, or 'now'" disabled={!signedIn} />
            </div>
          </div>
          <div className="mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <FieldLabel htmlFor="f-phone">Owner phone (for Call)</FieldLabel>
              <Input id="f-phone" name="phone" required placeholder="+977 98XXXXXXXX" disabled={!signedIn} />
            </div>
            <div>
              <FieldLabel htmlFor="f-whatsapp">WhatsApp number (optional)</FieldLabel>
              <Input id="f-whatsapp" name="whatsapp" placeholder="Include country code" disabled={!signedIn} />
            </div>
          </div>
          <p className="mb-3.5 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
            Your number is never shown in full on Browse. Signed-in members reveal it only when they tap Call or WhatsApp.
          </p>
          <div className="mb-3.5">
            <FieldLabel htmlFor="f-desc">Description</FieldLabel>
            <Textarea id="f-desc" name="description" rows={3} placeholder="Room size, amenities, house rules…" disabled={!signedIn} />
          </div>
          <div className="mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <FieldLabel htmlFor="f-comm-type">Commission from owner (you)</FieldLabel>
              <NativeSelect id="f-comm-type" name="commissionType" defaultValue="percent" disabled={!signedIn}>
                <option value="percent">% of first month's rent</option>
                <option value="fixed">Fixed amount</option>
              </NativeSelect>
            </div>
            <div>
              <FieldLabel htmlFor="f-comm-value">Amount you pay</FieldLabel>
              <Input id="f-comm-value" name="commissionValue" type="number" min={0} step="0.01" required placeholder="e.g. 10" defaultValue="10" disabled={!signedIn} />
            </div>
          </div>
          <div className="mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <FieldLabel htmlFor="f-comm-type-renter">Commission from renter (optional)</FieldLabel>
              <NativeSelect id="f-comm-type-renter" name="renterCommissionType" defaultValue="percent" disabled={!signedIn}>
                <option value="percent">% of first month's rent</option>
                <option value="fixed">Fixed amount</option>
              </NativeSelect>
            </div>
            <div>
              <FieldLabel htmlFor="f-comm-value-renter">Amount the renter pays</FieldLabel>
              <Input id="f-comm-value-renter" name="renterCommissionValue" type="number" min={0} step="0.01" placeholder="e.g. 0" disabled={!signedIn} />
            </div>
          </div>
          <p className="mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
            If you set a renter-side amount, it's shown upfront on the listing so the renter knows before they call — both amounts go to whoever referred the successful rental.
          </p>
          <Button type="submit" variant="brass" disabled={!signedIn || posting}>
            {posting ? "Posting…" : "Post listing"}
          </Button>
        </form>
      </section>

      <section className="rounded-lg border border-line bg-card p-5.5">
        <h2 className="font-serif mb-4 text-[19px] font-semibold">Your listings</h2>
        {signedIn ? (
          <Button size="sm" variant="secondary" className="mb-3.5" onClick={downloadCsv}>
            <Download className="size-3.5" />
            Download listings (CSV)
          </Button>
        ) : null}
        {loadingMine ? <Skeleton className="h-24" /> : null}
        {!loadingMine && signedIn && mine.length === 0 ? (
          <p className="py-8 text-center text-sm text-ink-soft">You haven't posted any rooms yet.</p>
        ) : null}
        <div className="space-y-3">
          {mine.map((room) => (
            <MyListingCard key={room.id} room={room} />
          ))}
        </div>
      </section>
    </div>
  );
}

function MyListingCard({ room }: { room: RoomOwned }) {
  const qc = useQueryClient();
  const [pickerOpen, setPickerOpen] = useState(false);
  const commission = computeCommission(room);
  const renterAmt = computeRenterCommission(room);

  const leadsQuery = useQuery({
    queryKey: ["leads", room.id],
    queryFn: () => listLeadsForRoom({ data: room.id }),
    enabled: pickerOpen,
  });

  const commQuery = useQuery({
    queryKey: ["room-commissions", room.id],
    queryFn: () => listRoomCommissions({ data: room.id }),
  });

  const invalidate = () =>
    Promise.all([
      qc.invalidateQueries({ queryKey: ["rooms"] }),
      qc.invalidateQueries({ queryKey: ["my-rooms"] }),
      qc.invalidateQueries({ queryKey: ["room-commissions", room.id] }),
      qc.invalidateQueries({ queryKey: ["my-commissions"] }),
    ]);

  async function onDelete() {
    if (!window.confirm("Delete this listing? This can't be undone.")) return;
    try {
      await deleteRoom({ data: room.id });
      toast("Listing deleted.");
      await invalidate();
    } catch (err) {
      toast(errorMessage(err, "Couldn't delete — try again."));
    }
  }

  async function onReopen() {
    try {
      await reopenRoom({ data: room.id });
      toast("Listing reopened.");
      await invalidate();
    } catch (err) {
      toast(errorMessage(err, "Couldn't reopen — try again."));
    }
  }

  const [chosen, setChosen] = useState("");

  async function onConfirm() {
    try {
      const result = await confirmRented({
        data: { roomId: room.id, referrerId: chosen || null },
      });
      toast(result.createdCommission ? "Marked as rented — commission created." : "Marked as rented.");
      setPickerOpen(false);
      await invalidate();
    } catch (err) {
      toast(errorMessage(err, "Something went wrong. Try again."));
    }
  }

  return (
    <div className="rounded-md border border-line bg-card px-4 py-3.5">
      <div className="flex flex-wrap items-baseline justify-between gap-2.5">
        <h4 className="font-serif text-base font-semibold">{room.title}</h4>
        <StatusPill tone={room.status === "rented" ? "rented" : "available"}>
          {room.status === "rented" ? "Rented" : "Available"}
        </StatusPill>
      </div>
      <p className="mt-1 text-[12.5px] text-ink-soft">
        {room.location} · {fmtMoney(room.rent, room.currency)}/mo · total referral commission{" "}
        {fmtMoney(commission, room.currency)}
        {renterAmt > 0 ? ` (${fmtMoney(renterAmt, room.currency)} billed to renter)` : ""}
      </p>
      <div className="mt-2.5 flex flex-wrap gap-2">
        {room.status === "rented" ? (
          <Button size="sm" variant="secondary" onClick={() => void onReopen()}>
            Reopen listing
          </Button>
        ) : (
          <Button
            size="sm"
            variant="brass"
            onClick={() => {
              setPickerOpen((v) => !v);
              setChosen("");
            }}
          >
            Mark as rented
          </Button>
        )}
        <Button size="sm" variant="secondary" onClick={() => void onDelete()}>
          <Trash2 className="size-3.5" />
          Delete
        </Button>
      </div>

      {pickerOpen ? (
        <div className="mt-3 border-t border-line pt-3">
          <p className="mb-1.5 text-[12.5px] text-ink-soft">Who found this room?</p>
          {leadsQuery.isLoading ? (
            <p className="text-[12.5px] text-ink-soft">Loading referrals…</p>
          ) : leadsQuery.isError ? (
            <p className="text-[12.5px] text-ink-soft">Could not load referrals. Try again.</p>
          ) : (
            <div className="space-y-1">
              <label className="flex min-h-11 items-center gap-2 text-[13.5px] font-normal text-ink">
                <input type="radio" name={`lead-${room.id}`} checked={chosen === ""} onChange={() => setChosen("")} />
                Direct — not via a referral
              </label>
              {(leadsQuery.data ?? []).map((lead) => (
                <label key={lead.referrerId} className="flex min-h-11 items-center gap-2 text-[13.5px] font-normal text-ink">
                  <input
                    type="radio"
                    name={`lead-${room.id}`}
                    checked={chosen === lead.referrerId}
                    onChange={() => setChosen(lead.referrerId)}
                  />
                  Referred by {lead.name}
                </label>
              ))}
              <div className="mt-2.5 flex gap-2">
                <Button size="sm" variant="brass" onClick={() => void onConfirm()}>
                  Confirm rented
                </Button>
                <Button size="sm" variant="secondary" onClick={() => setPickerOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      ) : null}

      {(commQuery.data ?? []).map((c) => (
        <div key={c.id} className="mt-2 flex items-center justify-between rounded-sm bg-paper-alt px-2.5 py-2 text-[13px]">
          <span>Referral commission: {fmtMoney(c.amount, c.currency)}</span>
          <span className="flex items-center gap-2">
            <StatusPill tone={c.status === "paid" ? "paid" : "pending"}>{c.status}</StatusPill>
            {c.status !== "paid" ? (
              <Button
                size="sm"
                variant="ghost"
                className="min-h-8 px-2 text-xs"
                onClick={async () => {
                  try {
                    await markCommissionPaid({ data: c.id });
                    toast("Marked as paid.");
                    await qc.invalidateQueries({ queryKey: ["room-commissions", room.id] });
                    await qc.invalidateQueries({ queryKey: ["my-commissions"] });
                  } catch (err) {
                    toast(errorMessage(err));
                  }
                }}
              >
                Mark paid
              </Button>
            ) : null}
          </span>
        </div>
      ))}
    </div>
  );
}
