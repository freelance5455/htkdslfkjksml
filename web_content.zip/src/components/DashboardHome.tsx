import React from 'react';
import {
  Atom,
  Bell,
  Bookmark,
  BookOpen,
  Calculator,
  ChevronRight,
  Download,
  Globe,
  Languages,
  Leaf,
  Lock,
  Play,
  Sparkles,
} from 'lucide-react';
import {
  getAllNotesForClassAndLang,
  getAllVideosForClassAndLang,
  getSubjectsForClass,
} from '../data/curriculum';
import {
  Announcement,
  AppScreen,
  ClassLevel,
  CustomSubject,
  LanguageCode,
  NoteDownloadRecord,
  RecentNoteRecord,
  SavedNoteRecord,
  StudentProfile,
  Subject,
  VideoHistoryRecord,
} from '../types/edutoon';
import { Logo } from './Logo';

export function SubjectIcon({
  iconKey,
  className = 'h-5 w-5',
}: {
  iconKey: Subject['iconKey'];
  className?: string;
}) {
  switch (iconKey) {
    case 'math':
      return <Calculator className={className} />;
    case 'science':
      return <Atom className={className} />;
    case 'evs':
      return <Leaf className={className} />;
    case 'social':
      return <Globe className={className} />;
    case 'english':
    case 'hindi':
      return <Languages className={className} />;
    default:
      return <Sparkles className={className} />;
  }
}

interface DashboardHomeProps {
  profile: StudentProfile;
  recentNotes: RecentNoteRecord[];
  videoHistory: VideoHistoryRecord[];
  savedNotes: SavedNoteRecord[];
  downloads: NoteDownloadRecord[];
  announcements: Announcement[];
  customSubjects?: CustomSubject[];
  onSelectSubject: (subjectId: string) => void;
  onNavigate: (screen: AppScreen) => void;
  onOpenRecentNote: (rec: RecentNoteRecord) => void;
  onOpenRecentVideo: (rec: VideoHistoryRecord) => void;
  onOpenClassChangeModal: () => void;
}

export const DashboardHome: React.FC<DashboardHomeProps> = ({
  profile,
  recentNotes,
  videoHistory,
  savedNotes,
  downloads,
  announcements,
  customSubjects = [],
  onSelectSubject,
  onNavigate,
  onOpenRecentNote,
  onOpenRecentVideo,
  onOpenClassChangeModal,
}) => {
  const classLevel = (profile.selectedClass || 1) as ClassLevel;
  const lang = (profile.language || 'en') as LanguageCode;
  const isHi = lang === 'hi';

  const builtInSubjects = getSubjectsForClass(classLevel);
  const extraSubjects: Subject[] = customSubjects
    .filter((cs) => cs.minClass <= classLevel && cs.maxClass >= classLevel)
    .filter((cs) => !builtInSubjects.some((b) => b.id === cs.slug))
    .map((cs) => ({
      id: cs.slug,
      classLevel,
      titleEn: cs.titleEn,
      titleHi: cs.titleHi,
      descriptionEn: cs.descriptionEn,
      descriptionHi: cs.descriptionHi,
      accentHex: cs.accentHex,
      iconKey: cs.iconKey,
    }));
  const subjects = [...builtInSubjects, ...extraSubjects];
  const totalNotes = getAllNotesForClassAndLang(classLevel, lang).length;
  const totalVideos = getAllVideosForClassAndLang(classLevel, lang).length;
  const completedNotes = profile.completedNoteIds.length;
  const completedVideos = profile.completedVideoIds.length;
  const totalItems = Math.max(1, totalNotes + totalVideos);
  const overallProgress = Math.min(
    100,
    Math.round(((completedNotes + completedVideos) / totalItems) * 100)
  );

  return (
    <div className="space-y-6">
      {/* Welcome & Student Context Banner */}
      <section className="bg-[#0B1633] text-white rounded-3xl p-5 sm:p-7 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-start sm:items-center gap-4">
          <Logo size="lg" glow className="hidden sm:block" />
          <Logo size="md" glow className="sm:hidden" />
          <div>
            <p className="text-xs font-medium text-sky-300">
              {isHi ? `कक्षा ${classLevel}` : `Class ${classLevel}`} ·{' '}
              {isHi ? 'हिंदी माध्यम' : 'English Medium'} · Session {profile.academicSession}
            </p>
            <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold text-white">
              {isHi ? `नमस्ते, ${profile.displayName}` : `Welcome back, ${profile.displayName}`}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              ANIMATION SE AASAAN PADHAI —{' '}
              {isHi
                ? 'आज का विषय चुनें या पिछला अध्याय जारी रखें।'
                : 'Pick a subject below or resume where you left off.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenClassChangeModal}
            className="min-h-[44px] px-4 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-xs sm:text-sm font-semibold text-slate-100 inline-flex items-center gap-2 cursor-pointer"
          >
            <Lock className="h-4 w-4 text-sky-400" />
            <span>
              {isHi ? `कक्षा ${classLevel} लॉक` : `Class ${classLevel} Locked`}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('subjects')}
            className="min-h-[44px] px-5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs sm:text-sm font-bold inline-flex items-center gap-2 cursor-pointer"
          >
            <span>{isHi ? 'सभी विषय देखें' : 'Browse Subjects'}</span>
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </section>

      {/* Learning Progress + Quick Shortcuts */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-xs font-semibold text-slate-500">
            {isHi ? 'कुल सीखने की प्रगति' : 'Overall Learning Progress'}
          </p>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-display text-3xl font-bold text-slate-900 font-mono-num">
              {overallProgress}%
            </span>
            <span className="text-xs text-slate-500 font-mono-num">
              {completedNotes} notes · {completedVideos} videos
            </span>
          </div>
          <div className="mt-3 h-2 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-sky-600 transition-all duration-300"
              style={{ width: `${overallProgress}%` }}
            />
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('saved')}
          className="bg-white rounded-2xl border border-slate-200 hover:border-sky-300 p-5 text-left flex items-center justify-between transition-colors cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500">
              {isHi ? 'बुकमार्क शॉर्टकट' : 'Saved Notes Shortcut'}
            </p>
            <p className="mt-1.5 font-display text-xl font-bold text-slate-900">
              {savedNotes.length} {isHi ? 'सेव किए नोट्स' : 'Saved Notes'}
            </p>
            <p className="mt-0.5 text-xs text-sky-700 font-semibold">
              {isHi ? 'खोलें →' : 'Open Library →'}
            </p>
          </div>
          <div className="h-11 w-11 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <Bookmark className="h-5 w-5" />
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('downloads')}
          className="bg-white rounded-2xl border border-slate-200 hover:border-sky-300 p-5 text-left flex items-center justify-between transition-colors cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500">
              {isHi ? 'PDF डाउनलोड शॉर्टकट' : 'Downloads Shortcut'}
            </p>
            <p className="mt-1.5 font-display text-xl font-bold text-slate-900">
              {downloads.length} {isHi ? 'PDF फ़ाइलें' : 'Downloaded PDFs'}
            </p>
            <p className="mt-0.5 text-xs text-sky-700 font-semibold">
              {isHi ? 'डाउनलोड देखें →' : 'View Downloads →'}
            </p>
          </div>
          <div className="h-11 w-11 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center shrink-0">
            <Download className="h-5 w-5" />
          </div>
        </button>
      </section>

      {/* Subjects Grid */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg sm:text-xl font-bold text-slate-900">
            {isHi ? `कक्षा ${classLevel} के विषय` : `Class ${classLevel} Subjects`}
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('subjects')}
            className="text-xs sm:text-sm font-semibold text-sky-700 hover:text-sky-800 cursor-pointer"
          >
            {isHi ? 'हिंदी / English अनुभाग →' : 'All Subjects & Mediums →'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjects.map((sub) => (
            <button
              key={sub.id}
              type="button"
              onClick={() => onSelectSubject(sub.id)}
              className="bg-white rounded-2xl border border-slate-200 hover:border-sky-400 p-5 text-left transition-all flex items-start gap-4 cursor-pointer group"
            >
              <div
                className="h-12 w-12 rounded-2xl flex items-center justify-center shrink-0 text-white"
                style={{ backgroundColor: sub.accentHex }}
              >
                <SubjectIcon iconKey={sub.iconKey} className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-display text-base sm:text-lg font-bold text-slate-900 group-hover:text-sky-700 transition-colors">
                  {isHi ? sub.titleHi : sub.titleEn}
                </h3>
                <p className="mt-1 text-xs sm:text-sm text-slate-600 line-clamp-2">
                  {isHi ? sub.descriptionHi : sub.descriptionEn}
                </p>
                <p className="mt-2.5 text-xs font-semibold text-sky-700">
                  {isHi ? 'नोट्स और वीडियो खोलें →' : 'Open Notes & Videos →'}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Recently Opened Notes & Recently Watched Videos */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Notes */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">
              {isHi ? 'हाल ही में पढ़े गए नोट्स' : 'Recently Opened Notes'}
            </h2>
            <BookOpen className="h-4 w-4 text-slate-400" />
          </div>

          {recentNotes.length === 0 ? (
            <p className="text-sm text-slate-500 py-4">
              {isHi
                ? 'आपके द्वारा खोले गए अध्याय नोट्स यहाँ दिखाई देंगे।'
                : 'Chapter notes you open will appear here for quick access.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentNotes.slice(0, 4).map((rec) => (
                <button
                  key={rec.noteId}
                  type="button"
                  onClick={() => onOpenRecentNote(rec)}
                  className="w-full py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3 text-left hover:bg-slate-50 rounded-xl px-2 -mx-2 transition-colors cursor-pointer"
                >
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500">
                      Class {rec.classLevel} · Ch {rec.chapterNumber} ·{' '}
                      {rec.language === 'hi' ? 'हिंदी' : 'English'}
                    </p>
                    <p className="text-sm font-semibold text-slate-900 truncate">{rec.title}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Recently Watched Videos */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">
              {isHi ? 'हाल ही में देखे गए वीडियो' : 'Recently Watched Videos'}
            </h2>
            <Play className="h-4 w-4 text-slate-400" />
          </div>

          {videoHistory.length === 0 ? (
            <p className="text-sm text-slate-500 py-4">
              {isHi
                ? 'आपके द्वारा देखे गए एनिमेटेड वीडियो और प्रगति यहाँ दिखेगी।'
                : 'Animated video lessons you watch will appear here with progress.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {videoHistory.slice(0, 4).map((vid) => (
                <button
                  key={vid.videoId}
                  type="button"
                  onClick={() => onOpenRecentVideo(vid)}
                  className="w-full py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3 text-left hover:bg-slate-50 rounded-xl px-2 -mx-2 transition-colors cursor-pointer"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-slate-500">
                      Class {vid.classLevel} · Ch {vid.chapterNumber} ·{' '}
                      <span className="font-mono-num font-semibold text-sky-700">
                        {vid.completed ? '100% Done' : `${vid.progressPercent}%`}
                      </span>
                    </p>
                    <p className="text-sm font-semibold text-slate-900 truncate">{vid.title}</p>
                  </div>
                  <Play className="h-4 w-4 text-sky-600 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Announcements Strip */}
      <section className="bg-white rounded-3xl border border-slate-200 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 text-sky-600" />
            <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">
              {isHi ? 'ताज़ा सूचनाएँ (Announcements)' : 'Latest Announcements'}
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('announcements')}
            className="text-xs sm:text-sm font-semibold text-sky-700 hover:text-sky-800 cursor-pointer"
          >
            {isHi ? 'सभी देखें →' : 'View All →'}
          </button>
        </div>

        {announcements.length === 0 ? (
          <p className="text-sm text-slate-500">
            {isHi
              ? 'अभी कोई नई घोषणा नहीं है।'
              : 'No new school announcements for your class right now.'}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {announcements.slice(0, 2).map((ann) => (
              <div
                key={ann.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1"
              >
                <p className="text-xs text-slate-500">
                  {ann.category} · {ann.targetClass === 0 ? 'All Classes' : `Class ${ann.targetClass}`}
                </p>
                <h3 className="font-display text-sm sm:text-base font-bold text-slate-900">
                  {ann.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 line-clamp-2">{ann.body}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
