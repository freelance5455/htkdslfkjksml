import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Cpu,
  RefreshCw,
  Power,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Thermometer,
  Wind,
  Zap,
  Activity,
  Server,
  ShieldCheck,
  RotateCcw,
  Sliders,
  Sparkles,
  Wifi,
  WifiOff,
  Flame
} from 'lucide-react';
import { ImsiWalletBalances } from '../lib/imsiEngine';

export type RigStatus = 'ACTIVE' | 'OFFLINE' | 'THERMAL_THROTTLED' | 'REBOOTING';

export interface MiningHardwareUnit {
  id: string;
  name: string;
  model: string;
  ipAddress: string;
  macAddress: string;
  status: RigStatus;
  hashrateTh: number;
  targetHashrateTh: number;
  temperatureC: number;
  maxSafeTempC: number;
  fanRpm: number;
  powerWatts: number;
  voltageV: number;
  efficiencyJth: number;
  uptimeHours: number;
  boardsOnline: string; // e.g. "3/3"
  rebootProgress?: number; // 0 to 100 during reboot
  lastSeen: string;
  rebootCount: number;
  rackPosition: string;
}

const INITIAL_RIG_UNITS: MiningHardwareUnit[] = [
  {
    id: 'rig-01',
    name: 'Altar-Pod Alpha 01',
    model: 'Antminer S21 Pro Hydro (335 TH/s)',
    ipAddress: '142.250.190.46:3001',
    macAddress: '70:B3:D5:8C:4A:11',
    status: 'ACTIVE',
    hashrateTh: 234.5,
    targetHashrateTh: 234.0,
    temperatureC: 64.2,
    maxSafeTempC: 85.0,
    fanRpm: 5800,
    powerWatts: 3510,
    voltageV: 230,
    efficiencyJth: 15.0,
    uptimeHours: 342,
    boardsOnline: '3/3',
    lastSeen: 'Just now',
    rebootCount: 2,
    rackPosition: 'Rack A - Slot 01'
  },
  {
    id: 'rig-02',
    name: 'Sovereign M60S 02',
    model: 'Whatsminer M60S+ Immersion',
    ipAddress: '142.250.190.46:3002',
    macAddress: '70:B3:D5:8C:4A:22',
    status: 'ACTIVE',
    hashrateTh: 186.2,
    targetHashrateTh: 186.0,
    temperatureC: 68.9,
    maxSafeTempC: 85.0,
    fanRpm: 6100,
    powerWatts: 3440,
    voltageV: 228,
    efficiencyJth: 18.5,
    uptimeHours: 512,
    boardsOnline: '3/3',
    lastSeen: 'Just now',
    rebootCount: 1,
    rackPosition: 'Rack A - Slot 02'
  },
  {
    id: 'rig-03',
    name: 'Hydro Pod Gamma 03',
    model: 'JUHNKRIX Custom Hydro Cluster',
    ipAddress: '142.250.190.46:3003',
    macAddress: '70:B3:D5:8C:4A:33',
    status: 'THERMAL_THROTTLED',
    hashrateTh: 142.8,
    targetHashrateTh: 350.0,
    temperatureC: 89.4,
    maxSafeTempC: 85.0,
    fanRpm: 7200,
    powerWatts: 2890,
    voltageV: 225,
    efficiencyJth: 20.2,
    uptimeHours: 89,
    boardsOnline: '2/3',
    lastSeen: '12s ago',
    rebootCount: 4,
    rackPosition: 'Rack B - Slot 01'
  },
  {
    id: 'rig-04',
    name: 'Avalon Eco Matrix 04',
    model: 'Avalon Nano 1466 Solar Array',
    ipAddress: '142.250.190.46:3004',
    macAddress: '70:B3:D5:8C:4A:44',
    status: 'OFFLINE',
    hashrateTh: 0.0,
    targetHashrateTh: 145.0,
    temperatureC: 28.1,
    maxSafeTempC: 85.0,
    fanRpm: 0,
    powerWatts: 12,
    voltageV: 0,
    efficiencyJth: 0,
    uptimeHours: 0,
    boardsOnline: '0/3',
    lastSeen: '45 mins ago',
    rebootCount: 7,
    rackPosition: 'Rack B - Slot 02'
  },
  {
    id: 'rig-05',
    name: 'Kingdom Sovereign 05',
    model: 'Antminer S21 Pro Hydro (335 TH/s)',
    ipAddress: '142.250.190.46:3005',
    macAddress: '70:B3:D5:8C:4A:55',
    status: 'ACTIVE',
    hashrateTh: 236.1,
    targetHashrateTh: 234.0,
    temperatureC: 61.8,
    maxSafeTempC: 85.0,
    fanRpm: 5650,
    powerWatts: 3495,
    voltageV: 231,
    efficiencyJth: 14.8,
    uptimeHours: 1204,
    boardsOnline: '3/3',
    lastSeen: 'Just now',
    rebootCount: 0,
    rackPosition: 'Rack C - Slot 01'
  }
];

interface MiningRigHealthWidgetProps {
  wallet?: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
}

export const MiningRigHealthWidget: React.FC<MiningRigHealthWidgetProps> = ({ onShowToast }) => {
  const [units, setUnits] = useState<MiningHardwareUnit[]>(() => {
    const saved = localStorage.getItem('juhnkrix_rig_units');
    return saved ? JSON.parse(saved) : INITIAL_RIG_UNITS;
  });

  const [autoHealEnabled, setAutoHealEnabled] = useState<boolean>(true);
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'OFFLINE' | 'THERMAL_THROTTLED'>('ALL');
  const [isRefreshingAll, setIsRefreshingAll] = useState<boolean>(false);

  // Persist units state
  useEffect(() => {
    localStorage.setItem('juhnkrix_rig_units', JSON.stringify(units));
  }, [units]);

  // Periodic telemetry fluctuation & auto-recovery simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setUnits((prevUnits) =>
        prevUnits.map((u) => {
          if (u.status === 'REBOOTING') {
            const nextProgress = (u.rebootProgress || 0) + 20;
            if (nextProgress >= 100) {
              return {
                ...u,
                status: 'ACTIVE',
                hashrateTh: u.targetHashrateTh * (0.98 + Math.random() * 0.04),
                temperatureC: +(58 + Math.random() * 6).toFixed(1),
                fanRpm: Math.round(5500 + Math.random() * 400),
                powerWatts: Math.round(u.model.includes('350') ? 4850 : 3480),
                voltageV: 230,
                boardsOnline: '3/3',
                uptimeHours: 1,
                rebootProgress: undefined,
                lastSeen: 'Just now'
              };
            }
            return {
              ...u,
              rebootProgress: nextProgress
            };
          }

          if (u.status === 'ACTIVE') {
            const tempDrift = (Math.random() - 0.5) * 1.2;
            const hashDrift = (Math.random() - 0.5) * 2.5;
            const newTemp = +(u.temperatureC + tempDrift).toFixed(1);
            return {
              ...u,
              temperatureC: Math.min(84, Math.max(55, newTemp)),
              hashrateTh: +(u.targetHashrateTh + hashDrift).toFixed(1),
              lastSeen: 'Just now'
            };
          }

          if (u.status === 'THERMAL_THROTTLED' && autoHealEnabled && Math.random() > 0.75) {
            // Auto-heal cooling intervention
            return {
              ...u,
              status: 'ACTIVE',
              temperatureC: 69.5,
              hashrateTh: +(u.targetHashrateTh * 0.95).toFixed(1),
              boardsOnline: '3/3',
              lastSeen: 'Just now'
            };
          }

          return u;
        })
      );
    }, 3000);

    return () => clearInterval(interval);
  }, [autoHealEnabled]);

  const handleRemoteReset = (unitId: string) => {
    const target = units.find((u) => u.id === unitId);
    if (!target) return;

    setUnits((prev) =>
      prev.map((u) => {
        if (u.id === unitId) {
          return {
            ...u,
            status: 'REBOOTING',
            rebootProgress: 10,
            hashrateTh: 0,
            fanRpm: 7500, // Fan purge spin
            rebootCount: u.rebootCount + 1,
            lastSeen: 'Rebooting...'
          };
        }
        return u;
      })
    );

    onShowToast?.(`🔄 Initiated Remote Power Cycle & Kernel Reset for ${target.name} (${target.ipAddress})`);
  };

  const handleRebootAllProblematic = () => {
    setIsRefreshingAll(true);
    let count = 0;
    setUnits((prev) =>
      prev.map((u) => {
        if (u.status === 'OFFLINE' || u.status === 'THERMAL_THROTTLED') {
          count++;
          return {
            ...u,
            status: 'REBOOTING',
            rebootProgress: 15,
            hashrateTh: 0,
            fanRpm: 7500,
            rebootCount: u.rebootCount + 1,
            lastSeen: 'Rebooting...'
          };
        }
        return u;
      })
    );

    setTimeout(() => setIsRefreshingAll(false), 800);
    if (count > 0) {
      onShowToast?.(`⚡ Remotely dispatched reboot sequence to ${count} stuck hardware node(s)!`);
    } else {
      onShowToast?.('✓ All mining hardware nodes are already running in optimal state!');
    }
  };

  const handleResetToFactory = () => {
    setUnits(INITIAL_RIG_UNITS);
    onShowToast?.('✓ Mining Hardware telemetry restored to default baseline matrix.');
  };

  // Calculations
  const totalHashrate = units.reduce((acc, u) => acc + (u.status === 'ACTIVE' ? u.hashrateTh : 0), 0);
  const targetTotalHashrate = units.reduce((acc, u) => acc + u.targetHashrateTh, 0);
  const activeCount = units.filter((u) => u.status === 'ACTIVE').length;
  const throttledCount = units.filter((u) => u.status === 'THERMAL_THROTTLED').length;
  const offlineCount = units.filter((u) => u.status === 'OFFLINE').length;
  const rebootingCount = units.filter((u) => u.status === 'REBOOTING').length;
  const avgTemp = units.filter((u) => u.status === 'ACTIVE').reduce((acc, u, _, arr) => acc + u.temperatureC / (arr.length || 1), 0);

  const filteredUnits = units.filter((u) => {
    if (filter === 'ALL') return true;
    return u.status === filter;
  });

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Cpu className="w-4 h-4 text-amber-400" />
            <span>MINING RIG HEALTH & HARDWARE NODE TELEMETRY</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Real-Time Node Status & Remote Reset Engine
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Live connection health indicators for individual ASIC units (Active, Offline, Thermal Throttled) with one-click remote kernel power cycling to restart stuck nodes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setAutoHealEnabled(!autoHealEnabled)}
            className={`px-3 py-2 rounded-xl text-xs font-bold border flex items-center space-x-1.5 transition-all ${
              autoHealEnabled
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40 shadow-sm'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
            title="Automatically dispatch cooling & reboot interventions"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>AUTO-HEAL: {autoHealEnabled ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={handleRebootAllProblematic}
            disabled={isRefreshingAll}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 disabled:opacity-50 cursor-pointer"
          >
            <RotateCcw className={`w-4 h-4 ${isRefreshingAll ? 'animate-spin' : ''}`} />
            <span>RESTART STUCK NODES</span>
          </button>
        </div>
      </div>

      {/* Health Overview Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {/* Total Cluster Hashrate */}
        <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider flex items-center space-x-1">
            <Activity className="w-3 h-3 text-cyan-400" />
            <span>Cluster Hashrate</span>
          </span>
          <div className="text-xl font-black text-cyan-100 font-mono">
            {totalHashrate.toFixed(1)} <span className="text-xs text-cyan-400">TH/s</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">
            Target: {targetTotalHashrate.toFixed(1)} TH/s ({((totalHashrate / targetTotalHashrate) * 100).toFixed(0)}%)
          </p>
        </div>

        {/* Active Units */}
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Active & Online</span>
          </span>
          <div className="text-xl font-black text-emerald-300 font-mono">
            {activeCount} <span className="text-xs text-slate-400">/ {units.length} Nodes</span>
          </div>
          <p className="text-[9px] text-emerald-400 font-mono">100% Chip Sync</p>
        </div>

        {/* Throttled Units */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-1">
            <Flame className="w-3 h-3 text-amber-400" />
            <span>Thermal Throttled</span>
          </span>
          <div className="text-xl font-black text-amber-300 font-mono">
            {throttledCount} <span className="text-xs text-slate-400">Nodes</span>
          </div>
          <p className="text-[9px] text-amber-400 font-mono">Temp &gt; 85°C Safety Cut</p>
        </div>

        {/* Offline Units */}
        <div className="bg-slate-900/90 border border-rose-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-rose-300 uppercase tracking-wider flex items-center space-x-1">
            <XCircle className="w-3 h-3 text-rose-400" />
            <span>Offline / Disconnected</span>
          </span>
          <div className="text-xl font-black text-rose-300 font-mono">
            {offlineCount} <span className="text-xs text-slate-400">Nodes</span>
          </div>
          <p className="text-[9px] text-rose-400 font-mono">Requires Remote Reset</p>
        </div>

        {/* Avg Cluster Temperature */}
        <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider flex items-center space-x-1">
            <Thermometer className="w-3 h-3 text-purple-400" />
            <span>Avg Exhaust Temp</span>
          </span>
          <div className="text-xl font-black text-purple-200 font-mono">
            {avgTemp.toFixed(1)}°C
          </div>
          <p className="text-[9px] text-slate-400 font-mono">Cooling Loop Nominal</p>
        </div>
      </div>

      {/* Filter Tabs & Quick Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['ALL', 'ACTIVE', 'THERMAL_THROTTLED', 'OFFLINE'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filter === tab
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab === 'ALL' && `All Hardware (${units.length})`}
              {tab === 'ACTIVE' && `Active (${activeCount})`}
              {tab === 'THERMAL_THROTTLED' && `Throttled (${throttledCount})`}
              {tab === 'OFFLINE' && `Offline (${offlineCount})`}
            </button>
          ))}
        </div>

        <button
          onClick={handleResetToFactory}
          className="text-xs text-slate-400 hover:text-amber-300 underline font-mono cursor-pointer"
        >
          Reset Baseline Matrix
        </button>
      </div>

      {/* Hardware Units Grid Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredUnits.map((unit) => {
          const isRebooting = unit.status === 'REBOOTING';
          const isActive = unit.status === 'ACTIVE';
          const isThrottled = unit.status === 'THERMAL_THROTTLED';
          const isOffline = unit.status === 'OFFLINE';

          return (
            <div
              key={unit.id}
              className={`rounded-2xl border p-4.5 space-y-3 transition-all relative overflow-hidden flex flex-col justify-between ${
                isActive
                  ? 'bg-slate-900/90 border-emerald-500/40 hover:border-emerald-400 shadow-lg'
                  : isThrottled
                  ? 'bg-slate-900/90 border-amber-500/50 hover:border-amber-400 shadow-lg ring-1 ring-amber-500/30'
                  : isRebooting
                  ? 'bg-slate-900/90 border-cyan-500/50 animate-pulse shadow-lg'
                  : 'bg-slate-950/90 border-rose-500/40 opacity-80'
              }`}
            >
              {/* Top Banner Status Indicator */}
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <Server className="w-4 h-4 text-amber-400" />
                    <span className="text-sm font-black text-amber-100">{unit.name}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono truncate">{unit.model}</p>
                </div>

                {/* Status Badge */}
                <div className="flex items-center space-x-1.5">
                  <span
                    className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                      isActive
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                        : isThrottled
                        ? 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                        : isRebooting
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-400/40'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isActive
                          ? 'bg-emerald-400 animate-pulse'
                          : isThrottled
                          ? 'bg-amber-400 animate-ping'
                          : isRebooting
                          ? 'bg-cyan-400 animate-spin'
                          : 'bg-rose-400'
                      }`}
                    />
                    <span>{unit.status.replace('_', ' ')}</span>
                  </span>
                </div>
              </div>

              {/* Progress Bar for Rebooting State */}
              {isRebooting && (
                <div className="space-y-1 bg-slate-950 p-2.5 rounded-xl border border-cyan-500/30">
                  <div className="flex justify-between text-[10px] text-cyan-300 font-bold font-mono">
                    <span>REMOTE RESTART IN PROGRESS...</span>
                    <span>{unit.rebootProgress || 10}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-cyan-400 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${unit.rebootProgress || 10}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Telemetry Metrics Box */}
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Hashrate</span>
                  <span className={`font-bold text-sm ${isActive ? 'text-cyan-300' : isThrottled ? 'text-amber-300' : 'text-slate-500'}`}>
                    {unit.hashrateTh.toFixed(1)} <span className="text-[10px]">TH/s</span>
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Temperature</span>
                  <span
                    className={`font-bold text-sm flex items-center space-x-1 ${
                      unit.temperatureC >= 85
                        ? 'text-rose-400 font-black'
                        : unit.temperatureC >= 75
                        ? 'text-amber-400'
                        : 'text-emerald-300'
                    }`}
                  >
                    <span>{unit.temperatureC}°C</span>
                    {unit.temperatureC >= 85 && <Flame className="w-3 h-3 text-rose-400" />}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Power / Fans</span>
                  <span className="text-slate-300 text-xs">
                    {unit.powerWatts}W • {unit.fanRpm} RPM
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Hashboards</span>
                  <span className={`text-xs font-bold ${unit.boardsOnline === '3/3' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {unit.boardsOnline} Online
                  </span>
                </div>
              </div>

              {/* Network Details & Position */}
              <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono px-1">
                <span>IP: <strong className="text-slate-200">{unit.ipAddress}</strong></span>
                <span>{unit.rackPosition}</span>
              </div>

              {/* Action Controls */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                <div className="text-[10px] text-slate-500 font-mono">
                  Uptime: <span className="text-slate-300">{unit.uptimeHours}h</span> (Resets: {unit.rebootCount})
                </div>

                <button
                  onClick={() => handleRemoteReset(unit.id)}
                  disabled={isRebooting}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer ${
                    isOffline || isThrottled
                      ? 'bg-rose-500 hover:bg-rose-400 text-slate-950 font-black shadow-md'
                      : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
                  } disabled:opacity-40`}
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isRebooting ? 'animate-spin' : ''}`} />
                  <span>{isRebooting ? 'REBOOTING...' : 'REMOTE RESET'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
