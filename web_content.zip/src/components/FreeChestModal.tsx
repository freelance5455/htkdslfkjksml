/**
 * SPR - Sahil Powerful Run
 * Free Mystery Runner Chest Modal
 */

import React, { useState } from 'react';
import { X, Sparkles, Gift, CheckCircle2 } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';

interface Props {
  onClose: () => void;
  onRewardClaimed?: () => void;
}

export const FreeChestModal: React.FC<Props> = ({ onClose, onRewardClaimed }) => {
  const [chestOpened, setChestOpened] = useState<boolean>(false);
  const [reward, setReward] = useState<{ coins: number; diamonds: number } | null>(null);

  const chestStatus = saveManager.getChestProgress();

  const handleOpenChest = () => {
    if (chestOpened) return;
    soundManager.playPowerupSound();

    // Reward coins and diamonds
    const coinsWon = 800 + Math.floor(Math.random() * 600);
    const diamondsWon = 3 + Math.floor(Math.random() * 4);

    saveManager.addCoins(coinsWon);
    saveManager.addDiamonds(diamondsWon);
    saveManager.incrementChestProgress(-10); // reset chest progress

    setReward({ coins: coinsWon, diamonds: diamondsWon });
    setChestOpened(true);

    if (onRewardClaimed) onRewardClaimed();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 via-yellow-950/30 to-black border-2 border-amber-500/50 rounded-3xl p-6 shadow-[0_0_50px_rgba(245,158,11,0.4)] flex flex-col items-center text-center">
        <button
          onClick={() => {
            soundManager.playButtonClick();
            onClose();
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-600 via-yellow-500 to-amber-300 flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.6)] mb-3 animate-pulse">
          <span className="text-4xl">🎁</span>
        </div>

        <h2 className="text-2xl font-black text-white uppercase tracking-wider font-heading">
          FREE MYSTERY CHEST
        </h2>
        <p className="text-xs text-amber-200 mt-1">
          Collect coins & diamonds to gear up your runner!
        </p>

        {reward ? (
          <div className="my-5 p-4 bg-slate-800/90 border border-amber-400 rounded-2xl w-full animate-bounce">
            <span className="text-xs text-amber-300 uppercase font-bold block mb-1">
              CHEST REWARDS UNLOCKED!
            </span>
            <div className="flex items-center justify-center gap-4 text-xl font-black text-white font-display">
              <span className="text-amber-400">🪙 +₹{reward.coins.toLocaleString()}</span>
              <span className="text-cyan-400">💎 +{reward.diamonds}</span>
            </div>
          </div>
        ) : (
          <div className="my-5 p-4 bg-slate-800/80 border border-slate-700 rounded-2xl w-full">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300 mb-1.5">
              <span>Chest Progress</span>
              <span className="text-amber-400 font-mono">
                {chestStatus.progress}/{chestStatus.max} Runs
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-700 rounded-full overflow-hidden mb-2">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (chestStatus.progress / chestStatus.max) * 100)}%` }}
              />
            </div>
            <span className="text-[11px] text-slate-400">
              Run tracks and collect coins to recharge free chests!
            </span>
          </div>
        )}

        {reward ? (
          <button
            onClick={() => {
              soundManager.playButtonClick();
              onClose();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-sm uppercase rounded-2xl shadow-lg cursor-pointer"
          >
            CLAIM & CLOSE
          </button>
        ) : (
          <button
            onClick={handleOpenChest}
            className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 text-slate-950 font-black text-base uppercase rounded-2xl shadow-[0_0_20px_rgba(245,158,11,0.5)] active:scale-95 transition cursor-pointer font-display"
          >
            OPEN FREE CHEST NOW
          </button>
        )}
      </div>
    </div>
  );
};
