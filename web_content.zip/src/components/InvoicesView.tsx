import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  Image as ImageIcon,
  MessageCircle,
  Plus,
  UserPlus,
} from 'lucide-react';
import { Client, Invoice, StudioSettings } from '../types';
import { downloadInvoiceImage, downloadInvoicePDF } from '../utils/exports';
import { buildWhatsAppUrl, formatDateShort, formatINR } from '../utils/formatters';

interface InvoicesViewProps {
  clients: Client[];
  invoices: Invoice[];
  settings: StudioSettings;
  preselectedClientId?: string | null;
  onCreateInvoice: (invoice: Omit<Invoice, 'id'>) => Invoice;
  onMarkInvoicePaid: (invoiceId: string) => void;
  onAddClientClick: () => void;
  onToast: (msg: string) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  clients,
  invoices,
  settings,
  preselectedClientId,
  onCreateInvoice,
  onMarkInvoicePaid,
  onAddClientClick,
  onToast,
}) => {
  const [viewMode, setViewMode] = useState<'create' | 'list'>('create');

  const nextInvoiceNumber = useMemo(() => {
    const maxNum = invoices.reduce((max, inv) => {
      const m = inv.invoiceNumber.match(/(\d+)$/);
      const val = m ? parseInt(m[1], 10) : 0;
      return Math.max(max, val);
    }, 0);
    return `CS-${String(maxNum + 1).padStart(3, '0')}`;
  }, [invoices]);

  const [invoiceNumber, setInvoiceNumber] = useState(nextInvoiceNumber);
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [clientId, setClientId] = useState<string>(preselectedClientId || clients[0]?.id || '');
  const [projectName, setProjectName] = useState('');
  const [totalAmount, setTotalAmount] = useState('0');
  const [advancePaid, setAdvancePaid] = useState('0');
  const [previewInvoiceId, setPreviewInvoiceId] = useState<string | null>(null);

  useEffect(() => {
    setInvoiceNumber(nextInvoiceNumber);
  }, [nextInvoiceNumber]);

  useEffect(() => {
    if (preselectedClientId) {
      setClientId(preselectedClientId);
      setViewMode('create');
      setPreviewInvoiceId(null);
    } else if (!clientId && clients[0]) {
      setClientId(clients[0].id);
    }
  }, [preselectedClientId, clients, clientId]);

  const selectedClient = useMemo(
    () => clients.find((c) => c.id === clientId),
    [clients, clientId]
  );

  useEffect(() => {
    if (selectedClient && !previewInvoiceId) {
      setProjectName(`${selectedClient.projectTitle} (${selectedClient.projectType})`);
      setTotalAmount(String(selectedClient.totalAmount));
      setAdvancePaid(String(selectedClient.paidAmount));
    }
  }, [selectedClient, previewInvoiceId]);

  const parsedTotal = Math.max(0, Number(totalAmount) || 0);
  const parsedAdvance = Math.max(0, Math.min(parsedTotal, Number(advancePaid) || 0));
  const calculatedBalance = Math.max(0, parsedTotal - parsedAdvance);

  const activePreviewInvoice: Invoice = useMemo(() => {
    if (previewInvoiceId) {
      const found = invoices.find((i) => i.id === previewInvoiceId);
      if (found) return found;
    }
    return {
      id: 'draft',
      invoiceNumber,
      date,
      clientId,
      projectName: projectName || 'Project Deliverable',
      totalAmount: parsedTotal,
      advancePaid: parsedAdvance,
      status: calculatedBalance === 0 && parsedTotal > 0 ? 'Paid' : 'Unpaid',
    };
  }, [
    previewInvoiceId,
    invoices,
    invoiceNumber,
    date,
    clientId,
    projectName,
    parsedTotal,
    parsedAdvance,
    calculatedBalance,
  ]);

  const previewClient = useMemo(
    () => clients.find((c) => c.id === activePreviewInvoice.clientId),
    [clients, activePreviewInvoice.clientId]
  );

  const previewBalance = Math.max(
    0,
    activePreviewInvoice.totalAmount - activePreviewInvoice.advancePaid
  );

  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) return;
    const created = onCreateInvoice({
      invoiceNumber,
      date,
      clientId,
      projectName: projectName.trim() || 'Digital Services',
      totalAmount: parsedTotal,
      advancePaid: parsedAdvance,
      status: calculatedBalance === 0 && parsedTotal > 0 ? 'Paid' : 'Unpaid',
    });
    setPreviewInvoiceId(created.id);
    onToast(`Invoice ${created.invoiceNumber} saved`);
  };

  const whatsappShareUrl = useMemo(() => {
    const msg = `Namaste Sir, ${settings.companyName} se invoice #${activePreviewInvoice.invoiceNumber} share kar rahe hai.\nProject: ${activePreviewInvoice.projectName}\nTotal: ${formatINR(activePreviewInvoice.totalAmount)}\nAdvance Paid: ${formatINR(activePreviewInvoice.advancePaid)}\nBalance Due: ${formatINR(previewBalance)}\nUPI: ${settings.upiId}\nThank You!`;
    return buildWhatsAppUrl(previewClient?.phone ?? '', msg);
  }, [activePreviewInvoice, previewBalance, previewClient, settings]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">Invoice Studio</h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {settings.companyName} · {settings.companyAddress}
          </p>
        </div>

        <div className="flex sm:inline-flex w-full sm:w-auto p-1 rounded-[12px] border border-slate-200 bg-white gap-1">
          <button
            type="button"
            onClick={() => {
              setPreviewInvoiceId(null);
              setViewMode('create');
            }}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-[8px] text-xs font-semibold whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
              viewMode === 'create'
                ? 'bg-[#0F172A] text-white'
                : 'text-slate-600 hover:text-[#0F172A]'
            }`}
          >
            Create &amp; Preview
          </button>
          <button
            type="button"
            onClick={() => setViewMode('list')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-[8px] text-xs font-semibold whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
              viewMode === 'list'
                ? 'bg-[#0F172A] text-white'
                : 'text-slate-600 hover:text-[#0F172A]'
            }`}
          >
            Invoice List ({invoices.length})
          </button>
        </div>
      </div>

      {clients.length === 0 ? (
        <div className="surface-card p-10 text-center space-y-3">
          <p className="font-display text-base font-bold text-[#0F172A]">Add a client first</p>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Create your first client profile to auto-fill invoices, share on WhatsApp, and export PDFs.
          </p>
          <button
            type="button"
            onClick={onAddClientClick}
            className="btn-primary px-4 py-2.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" strokeWidth={1.75} />
            <span>Add First Client</span>
          </button>
        </div>
      ) : viewMode === 'list' ? (
        <section className="surface-card overflow-hidden">
          {invoices.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <p className="text-sm text-slate-500">No invoices saved yet.</p>
              <button
                type="button"
                onClick={() => setViewMode('create')}
                className="btn-primary px-4 py-2.5 text-xs font-semibold cursor-pointer"
              >
                Create First Invoice
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {invoices.map((inv) => {
                const client = clients.find((c) => c.id === inv.clientId);
                const balance = Math.max(0, inv.totalAmount - inv.advancePaid);
                const isPaid = inv.status === 'Paid' || balance === 0;

                return (
                  <div
                    key={inv.id}
                    className="p-5 flex flex-wrap items-center justify-between gap-4"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-sm font-bold text-[#0F172A]">
                          {inv.invoiceNumber}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-[6px] border text-[11px] font-semibold ${
                            isPaid
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-red-50 text-red-700 border-red-200'
                          }`}
                        >
                          {isPaid ? 'Paid' : `Due ${formatINR(balance)}`}
                        </span>
                      </div>
                      <h2 className="font-display text-base font-bold text-[#0F172A] truncate">
                        {client?.name ?? 'Client'}
                      </h2>
                      <p className="text-xs text-slate-500 truncate">
                        {inv.projectName} · {formatDateShort(inv.date)}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-base font-bold text-[#0F172A] tabular-nums mr-2">
                        {formatINR(inv.totalAmount)}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setPreviewInvoiceId(inv.id);
                          setViewMode('create');
                        }}
                        className="btn-secondary h-9 px-3 text-xs font-semibold cursor-pointer"
                      >
                        Preview
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          downloadInvoicePDF(inv, client, settings);
                          onToast(`Downloaded ${inv.invoiceNumber}.pdf`);
                        }}
                        className="btn-primary h-9 px-3 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-4 h-4" strokeWidth={1.75} />
                        <span>PDF</span>
                      </button>
                      {!isPaid && (
                        <button
                          type="button"
                          onClick={() => onMarkInvoicePaid(inv.id)}
                          className="btn-secondary h-9 px-3 text-xs font-semibold text-emerald-700 inline-flex items-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4" strokeWidth={1.75} />
                          <span>Mark Paid</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Form Surface */}
          <form onSubmit={handleSaveInvoice} className="lg:col-span-5 surface-card p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="font-display text-base font-bold text-[#0F172A]">
                {previewInvoiceId ? `Viewing ${activePreviewInvoice.invoiceNumber}` : 'Create Invoice'}
              </h2>
              {previewInvoiceId && (
                <button
                  type="button"
                  onClick={() => setPreviewInvoiceId(null)}
                  className="text-xs font-semibold text-[#0F172A] hover:underline cursor-pointer"
                >
                  New Draft
                </button>
              )}
            </div>

            <div className="py-2 border-b border-slate-100 text-xs text-slate-500 space-y-0.5">
              <p className="font-semibold text-[#0F172A]">{settings.companyName}</p>
              <p>{settings.companyAddress}</p>
              <p>{settings.adminEmail}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">Invoice No.</label>
                <input
                  type="text"
                  value={previewInvoiceId ? activePreviewInvoice.invoiceNumber : invoiceNumber}
                  onChange={(e) => {
                    setPreviewInvoiceId(null);
                    setInvoiceNumber(e.target.value);
                  }}
                  className="w-full h-10 px-3 text-sm font-mono field-input"
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">Invoice Date</label>
                <input
                  type="date"
                  value={previewInvoiceId ? activePreviewInvoice.date : date}
                  onChange={(e) => {
                    setPreviewInvoiceId(null);
                    setDate(e.target.value);
                  }}
                  className="w-full h-10 px-3 text-sm field-input"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Select Client</label>
              <select
                value={previewInvoiceId ? activePreviewInvoice.clientId : clientId}
                onChange={(e) => {
                  setPreviewInvoiceId(null);
                  setClientId(e.target.value);
                }}
                className="w-full h-10 px-3 text-sm field-input"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.city})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-600">Project Name</label>
              <input
                type="text"
                value={previewInvoiceId ? activePreviewInvoice.projectName : projectName}
                onChange={(e) => {
                  setPreviewInvoiceId(null);
                  setProjectName(e.target.value);
                }}
                placeholder="Website + App Development"
                className="w-full h-10 px-3 text-sm field-input"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">Total Amount (₹)</label>
                <input
                  type="number"
                  min={0}
                  value={previewInvoiceId ? activePreviewInvoice.totalAmount : totalAmount}
                  onChange={(e) => {
                    setPreviewInvoiceId(null);
                    setTotalAmount(e.target.value);
                  }}
                  className="w-full h-10 px-3 text-sm tabular-nums field-input"
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">Advance Paid (₹)</label>
                <input
                  type="number"
                  min={0}
                  value={previewInvoiceId ? activePreviewInvoice.advancePaid : advancePaid}
                  onChange={(e) => {
                    setPreviewInvoiceId(null);
                    setAdvancePaid(e.target.value);
                  }}
                  className="w-full h-10 px-3 text-sm tabular-nums field-input"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Balance Auto-Calculated</span>
              <span className="font-display text-lg font-bold text-[#0F172A] tabular-nums">
                {formatINR(previewBalance)}
              </span>
            </div>

            {!previewInvoiceId && (
              <button
                type="submit"
                className="btn-primary w-full h-11 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" strokeWidth={1.75} />
                <span>Save Invoice</span>
              </button>
            )}
          </form>

          {/* Invoice Document Preview Surface */}
          <div className="lg:col-span-7 space-y-4">
            <div className="surface-card overflow-hidden">
              <div className="p-6 bg-[#0F172A] text-white flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-[8px] bg-slate-800 border border-slate-700 flex items-center justify-center font-display text-sm font-bold text-white shrink-0">
                    {settings.companyName.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="space-y-0.5">
                    <h3 className="font-display text-lg font-bold">{settings.companyName}</h3>
                    <p className="text-xs text-slate-300 max-w-xs">{settings.companyAddress}</p>
                    <p className="text-xs text-slate-400">{settings.adminEmail}</p>
                  </div>
                </div>

                <div className="text-left sm:text-right space-y-0.5">
                  <p className="font-display text-xl font-bold tracking-tight">INVOICE</p>
                  <p className="font-mono text-xs text-slate-300">
                    #{activePreviewInvoice.invoiceNumber}
                  </p>
                  <p className="text-xs text-slate-400">
                    {formatDateShort(activePreviewInvoice.date)}
                  </p>
                </div>
              </div>

              <div className="p-6 space-y-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="space-y-0.5">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                      Bill To
                    </p>
                    <p className="font-display text-base font-bold text-[#0F172A]">
                      {previewClient?.name ?? 'Client'}
                    </p>
                    {previewClient && (
                      <p className="text-xs text-slate-500">
                        {previewClient.city} · {previewClient.projectType} · {previewClient.phone}
                      </p>
                    )}
                  </div>

                  <div className="text-left sm:text-right space-y-0.5">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                      Payment Status
                    </p>
                    <p
                      className={`font-display text-sm font-bold ${
                        previewBalance === 0 && activePreviewInvoice.totalAmount > 0
                          ? 'text-emerald-700'
                          : 'text-red-600'
                      }`}
                    >
                      {previewBalance === 0 && activePreviewInvoice.totalAmount > 0
                        ? 'PAID IN FULL'
                        : `BALANCE DUE · ${formatINR(previewBalance)}`}
                    </p>
                    <p className="text-xs text-slate-500 font-mono">UPI: {settings.upiId}</p>
                  </div>
                </div>

                <div className="border-t border-b border-slate-200 divide-y divide-slate-200">
                  <div className="py-2.5 flex items-center justify-between text-xs font-semibold text-slate-500">
                    <span>PROJECT DESCRIPTION</span>
                    <span>AMOUNT</span>
                  </div>
                  <div className="py-4 flex items-center justify-between gap-4">
                    <div className="space-y-0.5">
                      <p className="text-sm font-semibold text-[#0F172A]">
                        {activePreviewInvoice.projectName}
                      </p>
                      <p className="text-xs text-slate-500">
                        {previewClient?.projectType ?? 'Professional Services'} Deliverable
                      </p>
                    </div>
                    <p className="font-display text-base font-bold text-[#0F172A] tabular-nums shrink-0">
                      {formatINR(activePreviewInvoice.totalAmount)}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
                  <div className="text-xs text-slate-500 max-w-sm space-y-0.5">
                    <p className="font-semibold text-[#0F172A]">{settings.invoiceNote}</p>
                    <p>Direct UPI Settlement: {settings.upiId}</p>
                  </div>

                  <div className="w-full sm:w-64 space-y-2 text-sm">
                    <div className="flex items-center justify-between text-slate-600">
                      <span>Subtotal</span>
                      <span className="font-semibold text-[#0F172A] tabular-nums">
                        {formatINR(activePreviewInvoice.totalAmount)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>Advance Paid</span>
                      <span className="font-semibold text-emerald-700 tabular-nums">
                        - {formatINR(activePreviewInvoice.advancePaid)}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between font-display text-base font-bold text-[#0F172A]">
                      <span>Balance Due</span>
                      <span className="tabular-nums">{formatINR(previewBalance)}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-5 border-t border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <FileText className="w-4 h-4" strokeWidth={1.75} />
                    <span>{settings.companyName}</span>
                  </div>
                  <div className="text-right space-y-0.5">
                    <p className="font-display text-sm font-bold text-[#0F172A]">
                      {settings.adminName}, {settings.companyName}
                    </p>
                    <p className="text-[11px] text-slate-500">{settings.adminTitle}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => {
                  downloadInvoicePDF(activePreviewInvoice, previewClient, settings);
                  onToast(`Downloaded ${activePreviewInvoice.invoiceNumber}.pdf`);
                }}
                className="btn-primary h-11 text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" strokeWidth={1.75} />
                <span>Download PDF</span>
              </button>

              <a
                href={whatsappShareUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary h-11 text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-700" strokeWidth={1.75} />
                <span>Share on WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  downloadInvoiceImage(activePreviewInvoice, previewClient, settings);
                  onToast(`Downloaded ${activePreviewInvoice.invoiceNumber}.png`);
                }}
                className="btn-secondary h-11 text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <ImageIcon className="w-4 h-4" strokeWidth={1.75} />
                <span>Share as Image</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
