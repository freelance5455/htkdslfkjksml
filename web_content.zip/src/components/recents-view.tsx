import { Avatar } from "@/components/avatar";
import { ScreenHeader } from "@/components/phone-shell";
import { formatPhone } from "@/lib/emergency";
import { dayGroupLabel, formatCallWhen, formatDuration } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import type { CallRecord } from "@/lib/types";
import { AudioLines, PhoneIncoming, PhoneMissed, PhoneOutgoing } from "lucide-react";

function DirectionIcon({ call }: { call: CallRecord }) {
  if (call.direction === "missed") return <PhoneMissed className="size-3.5 text-destructive" />;
  if (call.direction === "outgoing") return <PhoneOutgoing className="size-3.5 text-success" />;
  return <PhoneIncoming className="size-3.5 text-muted-foreground" />;
}

export function RecentsView() {
  const calls = useAppStore((s) => s.calls);
  const setOverlay = useAppStore((s) => s.setOverlay);
  const placeOutgoing = useAppStore((s) => s.placeOutgoing);

  const groups = new Map<string, CallRecord[]>();
  for (const c of calls) {
    const key = dayGroupLabel(c.startedAt);
    const list = groups.get(key) ?? [];
    list.push(c);
    groups.set(key, list);
  }

  return (
    <div>
      <ScreenHeader title="Recents" subtitle="Calls on this device" />
      {calls.length === 0 ? (
        <p className="px-5 text-sm text-muted-foreground">No calls yet.</p>
      ) : (
        [...groups.entries()].map(([label, list]) => (
          <section key={label} className="mb-4">
            <h2 className="px-5 pb-2 text-xs tracking-wide text-subtle uppercase">{label}</h2>
            <ul>
              {list.map((call) => (
                <li key={call.id}>
                  <button
                    type="button"
                    onClick={() =>
                      call.summaryId || call.handler === "lisa"
                        ? setOverlay({ kind: "call-detail", callId: call.id })
                        : placeOutgoing(call.number)
                    }
                    className="flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60"
                  >
                    <Avatar name={call.name} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="truncate font-medium">
                          {call.name === "Unknown" ? formatPhone(call.number) : call.name}
                        </p>
                        {call.handler === "lisa" ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[0.65rem] text-accent">
                            <AudioLines className="size-3" />
                            Lisa
                          </span>
                        ) : null}
                      </div>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <DirectionIcon call={call} />
                        <span>
                          {call.direction === "missed"
                            ? "Missed"
                            : call.direction === "outgoing"
                              ? "Outgoing"
                              : "Incoming"}
                        </span>
                        {call.durationSec > 0 ? <span>· {formatDuration(call.durationSec)}</span> : null}
                        {call.summaryId ? <span>· Summary</span> : null}
                      </p>
                    </div>
                    <span className="text-xs tabular-nums text-subtle">{formatCallWhen(call.startedAt)}</span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ))
      )}
    </div>
  );
}
