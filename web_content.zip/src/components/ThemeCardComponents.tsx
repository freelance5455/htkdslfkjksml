import React from "react";
import { NoteFlowThemeStyle, getNoteFlowTokens } from "../utils/themeTokens";
import { StickyNote, Terminal, Cpu, Network, Building2, Tag, Calendar, ChevronRight, Shield, Pin, CheckCircle2, AlertCircle } from "lucide-react";
import { Note } from "../types";

interface CardComponentProps {
  note?: Partial<Note>;
  onClick?: () => void;
  title?: string;
  content?: string;
  category?: string;
  isPinned?: boolean;
}

// --------------------------------1. MINIMALIST CARD --------------------------------
export const MinimalistCard: React.FC<CardComponentProps> = ({
  title = "Not Başlığı",
  content = "Yüksek okunabilirlik ve sade kenarlıklarla tasarlanmış minimalist not içeriği...",
  category = "Genel",
  onClick,
}) => {
  const tokens = getNoteFlowTokens(NoteFlowThemeStyle.Minimalist);

  return (
    <div
      onClick={onClick}
      style={{
        backgroundColor: tokens.colors.surface,
        borderColor: tokens.colors.border,
        borderRadius: tokens.borderRadius.medium,
        boxShadow: tokens.elevation.low,
      }}
      className="p-5 border transition-all hover:shadow-md cursor-pointer space-y-3"
    >
      <div className="flex items-center justify-between">
        <span
          style={{
            backgroundColor: `${tokens.colors.primary}15`,
            color: tokens.colors.primary,
          }}
          className="text-[11px] font-bold px-2.5 py-0.5 rounded-full"
        >
          {category}
        </span>
        <StickyNote className="w-4 h-4 text-slate-400" />
      </div>

      <h3
        style={{
          fontFamily: tokens.typography.fontFamily,
          color: tokens.colors.textPrimary,
        }}
        className="text-base font-bold tracking-tight"
      >
        {title}
      </h3>

      <p
        style={{ color: tokens.colors.textSecondary }}
        className="text-xs line-clamp-3 leading-relaxed"
      >
        {content}
      </p>
    </div>
  );
};

// --------------------------------2. TERMINAL LOG CARD --------------------------------
export const TerminalLogCard: React.FC<CardComponentProps> = ({
  title = "LOG_NOTE_01.sh",
  content = "[INFO] Core sync initialized successfully.\n[ERR] Connection timeout on remote backup stream retry #2.\n[OK] Local database transaction committed.",
  onClick,
}) => {
  const tokens = getNoteFlowTokens(NoteFlowThemeStyle.Terminal);

  return (
    <div
      onClick={onClick}
      style={{
        backgroundColor: tokens.colors.surface,
        borderColor: tokens.colors.border,
        borderRadius: tokens.borderRadius.small,
        boxShadow: tokens.elevation.low,
        fontFamily: tokens.typography.fontFamily,
      }}
      className="p-4 border font-mono transition-all hover:border-emerald-500/80 cursor-pointer space-y-2.5 text-emerald-400"
    >
      <div className="flex items-center justify-between border-b border-emerald-950 pb-2">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-500" />
          <span className="text-xs font-bold text-emerald-300">{title}</span>
        </div>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
          EXEC_OK
        </span>
      </div>

      <div className="text-xs space-y-1 text-emerald-300/90 whitespace-pre-wrap leading-relaxed">
        {content.split("\n").map((line, idx) => {
          const isErr = line.includes("[ERR]");
          const isInfo = line.includes("[INFO]");
          const isOk = line.includes("[OK]");

          return (
            <div key={idx} className="flex items-start gap-1.5">
              {isErr && (
                <span className="px-1 bg-red-950 text-red-400 rounded text-[10px] font-bold shrink-0">
                  ERR
                </span>
              )}
              {isInfo && (
                <span className="px-1 bg-blue-950 text-cyan-400 rounded text-[10px] font-bold shrink-0">
                  INFO
                </span>
              )}
              {isOk && (
                <span className="px-1 bg-emerald-950 text-emerald-400 rounded text-[10px] font-bold shrink-0">
                  OK
                </span>
              )}
              <span>{line.replace(/\[ERR\]|\[INFO\]|\[OK\]/g, "")}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// --------------------------------3. CYBERPUNK GLOW CARD --------------------------------
export const CyberpunkGlowCard: React.FC<CardComponentProps> = ({
  title = "NEON_PROJECT_PHASE",
  content = "Aktif projeler ve sabitlenmiş notlar için neon dış ışıma efektine sahip enerjik koyu kart düzeni.",
  category = "CYBER_GRID",
  isPinned = true,
  onClick,
}) => {
  const tokens = getNoteFlowTokens(NoteFlowThemeStyle.CyberpunkGlow);

  return (
    <div
      onClick={onClick}
      style={{
        backgroundColor: tokens.colors.surface,
        borderColor: tokens.colors.border,
        borderRadius: tokens.borderRadius.medium,
        boxShadow: isPinned ? tokens.elevation.glow : tokens.elevation.medium,
      }}
      className="p-5 border transition-all hover:scale-[1.02] cursor-pointer space-y-3 relative overflow-hidden"
    >
      <div className="flex items-center justify-between">
        <span
          style={{
            backgroundColor: `${tokens.colors.primary}25`,
            color: tokens.colors.textPrimary,
            borderColor: tokens.colors.primary,
          }}
          className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border uppercase tracking-wider"
        >
          {category}
        </span>
        {isPinned && <Pin className="w-4 h-4 text-cyan-400 fill-cyan-400" />}
      </div>

      <h3
        style={{ color: tokens.colors.textPrimary }}
        className="text-base font-black tracking-wide"
      >
        {title}
      </h3>

      <p style={{ color: tokens.colors.textSecondary }} className="text-xs leading-relaxed">
        {content}
      </p>

      {/* Cyberpunk accent bar bottom */}
      <div className="h-0.5 w-full bg-gradient-to-r from-cyan-500 via-purple-500 to-rose-500 rounded-full" />
    </div>
  );
};

// --------------------------------4. MIND MAP NODE WIDGET --------------------------------
export const MindMapNodeWidget: React.FC<CardComponentProps> = ({
  title = "Ana Bilgi Düğümü",
  content = "Bağlantılı zihin haritası ve ilişkilendirilmiş alt notlar...",
  onClick,
}) => {
  const tokens = getNoteFlowTokens(NoteFlowThemeStyle.MindMap);

  return (
    <div
      onClick={onClick}
      style={{
        backgroundColor: tokens.colors.surface,
        borderColor: tokens.colors.border,
        borderRadius: tokens.borderRadius.large,
        boxShadow: tokens.elevation.medium,
      }}
      className="p-4 border transition-all hover:border-indigo-400 cursor-pointer space-y-2.5 relative"
    >
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-indigo-500 ring-4 ring-indigo-500/20 animate-pulse" />
        <span className="text-xs font-bold text-indigo-300 flex items-center gap-1">
          <Network className="w-3.5 h-3.5" /> Düğüm #204
        </span>
      </div>

      <h4
        style={{ color: tokens.colors.textPrimary }}
        className="text-sm font-extrabold"
      >
        {title}
      </h4>

      <p style={{ color: tokens.colors.textSecondary }} className="text-xs leading-relaxed">
        {content}
      </p>

      <div className="pt-2 border-t border-slate-700/80 flex items-center justify-between text-[10px] text-indigo-400">
        <span>3 Alt Bağlantı Var</span>
        <ChevronRight className="w-3.5 h-3.5" />
      </div>
    </div>
  );
};

// --------------------------------5. ENTERPRISE PKM DASHBOARD --------------------------------
export const EnterprisePKMDashboard: React.FC<{
  notes?: Partial<Note>[];
  onOpenNote?: (note: Partial<Note>) => void;
}> = ({ notes = [], onOpenNote }) => {
  const tokens = getNoteFlowTokens(NoteFlowThemeStyle.EnterprisePKM);

  return (
    <div
      style={{
        backgroundColor: tokens.colors.background,
        color: tokens.colors.textPrimary,
      }}
      className="w-full p-6 rounded-2xl border border-slate-300 dark:border-slate-800 space-y-6"
    >
      {/* Dashboard Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-300 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-black tracking-tight">
              Kurumsal PKM Bilgi Paneli (Enterprise Studio)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Sol zaman çizelgesi, orta proje kartları ve sağ denetim izi yönetimi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold px-3 py-1 bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 rounded-full border border-blue-300 dark:border-blue-800 flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" /> Denetimli Arşiv
          </span>
        </div>
      </div>

      {/* 3-Column Enterprise PKM Layout Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Left Column: Timeline Stream */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-600" />
            Zaman Çizelgesi
          </h3>
          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-semibold block">10:30 - Bugün</span>
              <strong className="text-slate-800 dark:text-slate-200">Sistem Yedekleme Raporu</strong>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-semibold block">Dün - 16:45</span>
              <strong className="text-slate-800 dark:text-slate-200">Proje Kriter Dokümanı</strong>
            </div>
          </div>
        </div>

        {/* Middle Column: Active Projects */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <StickyNote className="w-3.5 h-3.5 text-blue-600" />
            Aktif Proje Kartları
          </h3>
          <div className="space-y-2">
            <MinimalistCard
              title="NoteFlow Sürüm 2.4 Mimarisi"
              content="Cross-platform performans geliştirmeleri ve GMS bağımsız Huawei entegrasyonu."
              category="Yazılım"
            />
          </div>
        </div>

        {/* Right Column: Quick Action Audit Panel */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            Eylem & Güvenlik
          </h3>
          <div className="space-y-2 text-xs">
            <button className="w-full py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all text-left flex items-center justify-between">
              <span>Toplu Dışa Aktar (ZIP)</span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="w-full py-2 px-3 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold transition-all text-left flex items-center justify-between">
              <span>E-Posta Senkronizasyonu</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
