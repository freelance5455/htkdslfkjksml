import React, { useState } from 'react';
import { Bell, Check, Clock, X, Pill, ShieldAlert, Sparkles, Smile, Meh, Frown } from 'lucide-react';
import { DoseRecord, ReminderLanguage, FeelingEffect } from '../types/reminder';
import { TRANSLATIONS } from '../data/reminderData';

interface DoseAlertModalProps {
  dose: DoseRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onTaken: (doseId: string, effect?: FeelingEffect) => void;
  onSnooze: (doseId: string) => void;
  onSkip: (doseId: string) => void;
  language: ReminderLanguage;
}

export const DoseAlertModal: React.FC<DoseAlertModalProps> = ({
  dose,
  isOpen,
  onClose,
  onTaken,
  onSnooze,
  onSkip,
  language
}) => {
  const [selectedEffect, setSelectedEffect] = useState<FeelingEffect | undefined>('better');

  if (!isOpen || !dose) return null;
  const t = TRANSLATIONS[language];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden border border-amber-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Animated Banner Header */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white p-5 text-center relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="mx-auto w-14 h-14 bg-white/20 rounded-2xl backdrop-blur-md flex items-center justify-center mb-2 shadow-inner border border-white/20 animate-bounce">
            <Bell className="w-8 h-8 text-white fill-amber-100" />
          </div>

          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-black tracking-widest bg-white/20 px-3 py-0.5 rounded-full backdrop-blur-xs text-amber-50">
            <Sparkles className="w-3 h-3 text-amber-200" /> Scheduled Medicine Alarm
          </span>

          <h3 className="font-extrabold text-xl mt-1 text-white">{dose.medicineName}</h3>
          <p className="text-xs text-amber-100 font-medium">
            {dose.strength} • {dose.medicineType}
          </p>
        </div>

        {/* Dose Info Body */}
        <div className="p-5 space-y-4">
          <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-3.5 space-y-2 text-center">
            <div className="flex items-center justify-center gap-2 text-amber-900">
              <Clock className="w-4 h-4 text-amber-600" />
              <span className="font-mono font-bold text-sm">{dose.scheduledTime}</span>
            </div>

            <div className="text-xs font-bold text-slate-800">
              Dose Quantity: <span className="text-teal-700">{dose.dosePerTime} {dose.medicineType}(s)</span>
            </div>

            {dose.reason && (
              <p className="text-[11px] text-slate-600 italic">
                For: {dose.reason}
              </p>
            )}
          </div>

          {/* MEDICINE EFFECT TRACKER prompt */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 space-y-2 text-center">
            <span className="text-xs font-bold text-slate-700 block">{t.howFeeling}</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedEffect('better')}
                className={`py-2 rounded-xl text-xs font-bold border flex flex-col items-center gap-1 transition-all ${
                  selectedEffect === 'better'
                    ? 'bg-emerald-100 border-emerald-400 text-emerald-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Smile className={`w-5 h-5 ${selectedEffect === 'better' ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span>{t.better}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedEffect('no_change')}
                className={`py-2 rounded-xl text-xs font-bold border flex flex-col items-center gap-1 transition-all ${
                  selectedEffect === 'no_change'
                    ? 'bg-amber-100 border-amber-400 text-amber-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Meh className={`w-5 h-5 ${selectedEffect === 'no_change' ? 'text-amber-600' : 'text-slate-400'}`} />
                <span>{t.noChange}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedEffect('worse')}
                className={`py-2 rounded-xl text-xs font-bold border flex flex-col items-center gap-1 transition-all ${
                  selectedEffect === 'worse'
                    ? 'bg-rose-100 border-rose-400 text-rose-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Frown className={`w-5 h-5 ${selectedEffect === 'worse' ? 'text-rose-600' : 'text-slate-400'}`} />
                <span>{t.worse}</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1 text-[10px] text-slate-500 justify-center">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
            <span>Marking "Taken" updates your pill inventory automatically.</span>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 gap-2 pt-1">
            {/* TAKEN */}
            <button
              onClick={() => {
                onTaken(dose.id, selectedEffect);
                onClose();
              }}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>✔ {t.taken}</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              {/* SNOOZE */}
              <button
                onClick={() => {
                  onSnooze(dose.id);
                  onClose();
                }}
                className="py-2.5 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Clock className="w-3.5 h-3.5 text-amber-700" />
                <span>⏰ {t.snooze}</span>
              </button>

              {/* SKIP */}
              <button
                onClick={() => {
                  onSkip(dose.id);
                  onClose();
                }}
                className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <X className="w-3.5 h-3.5 text-slate-500" />
                <span>❌ {t.skip}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
