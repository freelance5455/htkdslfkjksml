import React, { useState } from "react";
import { Sparkles, Wand2, Hash, Music, Feather, Check } from "lucide-react";
import {
  GenerationMode,
  GenerationParams,
  Tone,
  LanguageStyle,
  GhazalFormat,
  SongGenre,
  BaitBaziType,
  RhymeToolType
} from "../types";
import {
  TONE_OPTIONS,
  STYLE_OPTIONS,
  GHAZAL_FORMATS,
  SONG_GENRES,
  URDU_LETTERS,
  QUICK_TOPIC_SUGGESTIONS,
  MODE_METADATA
} from "../data/constants";

interface PoetryGeneratorProps {
  mode: GenerationMode;
  onGenerate: (params: GenerationParams) => void;
  isLoading: boolean;
}

export const PoetryGenerator: React.FC<PoetryGeneratorProps> = ({
  mode,
  onGenerate,
  isLoading
}) => {
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState<Tone>("romantic");
  const [style, setStyle] = useState<LanguageStyle>("classic");
  const [format, setFormat] = useState<GhazalFormat>("sher_2_line");
  const [genre, setGenre] = useState<SongGenre>("sufi");
  const [letter, setLetter] = useState("ن");
  const [baziType, setBaziType] = useState<BaitBaziType>("counter_sher");
  const [toolType, setToolType] = useState<RhymeToolType>("complete_sher");
  const [userLine, setUserLine] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTopic = topic.trim() || (mode === "bait_bazi" ? `حرف '${letter}' پر بیت بازی` : "عشق و زیست");

    onGenerate({
      mode,
      topic: finalTopic,
      tone,
      style,
      format,
      genre,
      letter,
      baziType,
      toolType,
      userLine: userLine.trim()
    });
  };

  const handleQuickTopic = (suggested: string) => {
    setTopic(suggested);
  };

  const currentMeta = MODE_METADATA[mode];

  return (
    <div className="bg-stone-900/90 rounded-3xl p-5 md:p-6 border border-emerald-900/50 shadow-xl relative overflow-hidden mb-6">
      {/* Subtle top decoration */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-stone-800/80">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          <h3 className="font-urdu-title text-xl text-amber-200 font-bold">
            {currentMeta.titleUrdu}
          </h3>
        </div>
        <span className="text-xs font-urdu-sans px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-700/60 text-emerald-300">
          {currentMeta.badge}
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* MODE SPECIFIC: Bait Bazi Letter Selector */}
        {mode === "bait_bazi" && (
          <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold font-urdu-sans text-amber-300 flex items-center gap-2">
                <Hash className="w-4 h-4 text-amber-400" />
                <span>مطلوبہ حرف برائے بیت بازی (Starting Letter):</span>
              </label>
              <span className="text-xl font-urdu font-bold text-amber-300 px-3 py-0.5 rounded-lg bg-stone-900 border border-amber-400/50">
                حرف: {letter}
              </span>
            </div>

            {/* Urdu Alphabet Quick Grid */}
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-stone-900/70 rounded-xl border border-stone-800">
              {URDU_LETTERS.map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLetter(l)}
                  className={`w-8 h-8 rounded-lg font-urdu text-sm font-bold transition-all ${
                    letter === l
                      ? "bg-amber-500 text-stone-950 shadow-md scale-105"
                      : "bg-stone-800/90 text-stone-300 hover:bg-stone-700 hover:text-white"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            {/* Bait Bazi Type */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              {[
                { id: "counter_sher", label: "فوری جوابی شعر" },
                { id: "powerful_verse", label: "طاقتور شعر" },
                { id: "rare_gem", label: "نایاب کلاسیکی گوہر" }
              ].map((type) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setBaziType(type.id as BaitBaziType)}
                  className={`py-1.5 px-2 rounded-xl text-xs font-urdu-sans border transition-all ${
                    baziType === type.id
                      ? "bg-amber-500/20 border-amber-400 text-amber-200"
                      : "bg-stone-900/60 border-stone-800 text-stone-400 hover:bg-stone-800"
                  }`}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* MODE SPECIFIC: Ghazal Format Selector */}
        {mode === "ghazal_shayari" && (
          <div>
            <label className="block text-xs font-semibold font-urdu-sans text-stone-300 mb-2">
              شاعری کی ہئیت / فارمیٹ (Poetry Format):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {GHAZAL_FORMATS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFormat(f.id)}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    format === f.id
                      ? "bg-emerald-950/80 border-emerald-500 text-amber-200 shadow-md ring-1 ring-emerald-500/50"
                      : "bg-stone-900/70 border-stone-800 text-stone-400 hover:bg-stone-800"
                  }`}
                >
                  <p className="font-urdu-sans font-bold text-sm">{f.labelUrdu}</p>
                  <p className="text-[10px] font-ui text-stone-400 mt-0.5">{f.labelEn}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* MODE SPECIFIC: Song Genre Selector */}
        {mode === "song_lyrics" && (
          <div>
            <label className="block text-xs font-semibold font-urdu-sans text-stone-300 mb-2 flex items-center gap-1.5">
              <Music className="w-3.5 h-3.5 text-emerald-400" />
              <span>موسیقی کی صنف (Musical Genre):</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {SONG_GENRES.map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => setGenre(g.id)}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 ${
                    genre === g.id
                      ? "bg-teal-950/70 border-teal-500 text-teal-200 shadow-md ring-1 ring-teal-500/50"
                      : "bg-stone-900/70 border-stone-800 text-stone-400 hover:bg-stone-800"
                  }`}
                >
                  <span className="text-base">{g.icon}</span>
                  <div>
                    <p className="font-urdu-sans text-xs font-bold leading-tight">{g.labelUrdu}</p>
                    <p className="text-[10px] font-ui text-stone-400">{g.labelEn}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* MODE SPECIFIC: Rhyme & Meter Helper Selector */}
        {mode === "rhyme_meter" && (
          <div className="space-y-3">
            <label className="block text-xs font-semibold font-urdu-sans text-stone-300 mb-1">
              مدد کی قسم منتخب کریں (Helper Type):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "complete_sher", label: "نامکمل شعر مکمل کریں" },
                { id: "qafiya_finder", label: "ہم قافیہ الفاظ" },
                { id: "meter_check", label: "وزن و تقطیع کی جانچ" }
              ].map((tool) => (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => setToolType(tool.id as RhymeToolType)}
                  className={`p-2 rounded-xl border text-center text-xs font-urdu-sans transition-all ${
                    toolType === tool.id
                      ? "bg-emerald-950/80 border-amber-400 text-amber-200"
                      : "bg-stone-900/70 border-stone-800 text-stone-400 hover:bg-stone-800"
                  }`}
                >
                  {tool.label}
                </button>
              ))}
            </div>

            <div>
              <label className="block text-xs font-urdu-sans text-stone-300 mb-1">
                آپ کا مصرع یا نامکمل شعر (Your Line / Verse):
              </label>
              <input
                type="text"
                value={userLine}
                onChange={(e) => setUserLine(e.target.value)}
                placeholder="مثال: دل ہی تو ہے نہ سنگ و خشت درد سے بھر نہ آئے کیوں..."
                className="w-full px-4 py-2.5 rounded-xl bg-stone-950 border border-stone-700/80 focus:border-amber-400 focus:outline-none text-stone-100 font-urdu text-base placeholder:text-stone-600 shadow-inner"
              />
            </div>
          </div>
        )}

        {/* 1. TOPIC / KEYWORD INPUT */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="topic-input"
              className="text-xs font-semibold font-urdu-sans text-stone-300 flex items-center gap-1.5"
            >
              <Feather className="w-3.5 h-3.5 text-amber-400" />
              <span>موضوع یا کلیدی الفاظ (Topic / Keywords):</span>
            </label>
            <span className="text-[11px] font-ui text-stone-400">e.g. Ishq, Rain, Dosti</span>
          </div>

          <div className="relative">
            <input
              id="topic-input"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="مثلاً: بارش اور تنہائی، عشقِ حقیقی، وطن کی محبت، جدائی کا درد..."
              className="w-full px-4 py-3 rounded-xl bg-stone-950 border border-stone-700/80 focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 focus:outline-none text-amber-100 font-urdu text-lg placeholder:text-stone-600 placeholder:font-urdu-sans placeholder:text-sm shadow-inner transition-colors"
            />
          </div>

          {/* Quick topic suggestion chips */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            <span className="text-[11px] font-urdu-sans text-stone-400 self-center">
              تجویز کردہ:
            </span>
            {QUICK_TOPIC_SUGGESTIONS.slice(0, 5).map((sug) => (
              <button
                key={sug}
                type="button"
                onClick={() => handleQuickTopic(sug)}
                className="text-[11px] font-urdu-sans px-2.5 py-1 rounded-full bg-stone-800/80 hover:bg-stone-700/80 text-stone-300 hover:text-amber-300 border border-stone-700/50 transition-colors"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>

        {/* 2. TONE & 3. LANGUAGE STYLE CONTROLS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          {/* Tone Selector Dropdown & Chips */}
          <div>
            <label
              htmlFor="tone-selector"
              className="block text-xs font-semibold font-urdu-sans text-stone-300 mb-1.5"
            >
              لہجہ اور کیفیت (Tone / Emotion):
            </label>
            <div className="relative">
              <select
                id="tone-selector"
                value={tone}
                onChange={(e) => setTone(e.target.value as Tone)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-950 border border-stone-700/80 focus:border-amber-400 focus:outline-none text-amber-200 font-urdu-sans text-sm appearance-none cursor-pointer"
              >
                {TONE_OPTIONS.map((t) => (
                  <option key={t.id} value={t.id} className="bg-stone-900 text-stone-100">
                    {t.icon} {t.labelUrdu} — {t.labelEn}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-stone-400">
                ▼
              </div>
            </div>
          </div>

          {/* Language / Style Toggle (Simple Urdu vs Classic Literary Urdu) */}
          <div>
            <label className="block text-xs font-semibold font-urdu-sans text-stone-300 mb-1.5">
              اسلوبِ بیان (Language / Style):
            </label>
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-stone-950 border border-stone-800">
              {STYLE_OPTIONS.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setStyle(s.id)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-urdu-sans transition-all text-center flex items-center justify-center gap-1 ${
                    style === s.id
                      ? "bg-emerald-800 text-amber-200 font-bold shadow-sm"
                      : "text-stone-400 hover:text-stone-200"
                  }`}
                >
                  {style === s.id && <Check className="w-3 h-3 text-amber-300" />}
                  <span>{s.labelUrdu}</span>
                </button>
              ))}
            </div>
            <p className="text-[10px] font-urdu-sans text-stone-400 mt-1">
              {STYLE_OPTIONS.find((s) => s.id === style)?.desc}
            </p>
          </div>
        </div>

        {/* SUBMIT BUTTON */}
        <div className="pt-2">
          <button
            type="submit"
            id="generate-poetry-button"
            disabled={isLoading}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-500 hover:from-emerald-500 hover:to-amber-400 active:scale-[0.99] text-stone-950 font-bold text-lg font-urdu-sans shadow-lg shadow-emerald-950/60 transition-all flex items-center justify-center gap-2 border border-amber-300/40 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Wand2 className="w-5 h-5 text-stone-950" />
            <span>
              {mode === "song_lyrics"
                ? "نغمہ تخلیق کیجیے (Compose Lyrics)"
                : mode === "bait_bazi"
                ? "بیت بازی کا شعر حاصل کریں (Get Verse)"
                : mode === "rhyme_meter"
                ? "ردیف و قافیہ رہنمائی حاصل کریں"
                : "شاعری تخلیق کیجیے (Compose Poetry)"}
            </span>
            <Sparkles className="w-4 h-4 text-stone-950" />
          </button>
        </div>
      </form>
    </div>
  );
};
