import React, { useState } from 'react';
import type { MartingaleStep } from '../types';
import { cyberAudio } from '../audio';
import { Calculator, ShieldCheck, TrendingUp, AlertTriangle } from 'lucide-react';

export const SevenStepMatrix: React.FC = () => {
  const [balance, setBalance] = useState<number>(1000);
  const [levels, setLevels] = useState<number>(7);

  // Multipliers for standard Martingale risk distribution
  const MULTIPLIERS = [1, 3, 9, 27, 81, 243, 729];
  const STAGE_TITLES = [
    'Starter Node',
    'Double Up',
    'Recovery Lvl 1',
    'Recovery Lvl 2',
    'High Prob VIP',
    'Absolute Safe',
    'GX Wall Defense',
  ];

  // Calculate base unit so total sum of bets <= balance
  const totalWeight = MULTIPLIERS.slice(0, levels).reduce((acc, m) => acc + m, 0);
  const baseUnit = Math.max(1, Math.floor(balance / totalWeight));

  const steps: MartingaleStep[] = [];
  let cumulative = 0;

  for (let i = 0; i < levels; i++) {
    const mult = MULTIPLIERS[i];
    const amount = baseUnit * mult;
    cumulative += amount;
    const winReturn = amount * 1.96 - cumulative; // 1.96x standard payout

    steps.push({
      level: i + 1,
      mult,
      text: STAGE_TITLES[i] || `Level ${i + 1}`,
      amount,
      cumulative,
      winReturn: Math.round(winReturn),
    });
  }

  const handlePreset = (amt: number) => {
    cyberAudio.playClick();
    setBalance(amt);
  };

  return (
    <div className="flex flex-col flex-1 w-full max-w-md mx-auto p-3 space-y-3 select-none pb-24">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-[#041d28] via-[#052938] to-[#031922] border border-cyan-500/40 p-4 shadow-[0_4px_20px_rgba(6,182,212,0.2)]">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-wider">7-STEP MATRIX MKR</h2>
            <span className="text-[10px] text-cyan-300 font-mono">GX TEAM RISK HEDGING ENGINE</span>
          </div>
        </div>

        {/* Bengali Instructional Note */}
        <div className="p-2.5 rounded-xl bg-black/50 border border-cyan-500/30 text-[11px] text-slate-200 leading-relaxed font-sans shadow-inner">
          💡 <strong>লুজ এড়াতে সবসময় মোট ব্যালেন্সকে এই স্তরে ভাগ করে খেলুন</strong>, কোনো স্তরে হেরে গেলে পরবর্তী লেভেলে নির্দিষ্ট অ্যামাউন্ট দিয়ে খেললে শেষ পর্যন্ত উইন আসলে পেছনের সব লস রিকভার হয়ে প্রফিট চলে আসবে ✅
        </div>
      </div>

      {/* Balance Input & Presets */}
      <div className="p-3.5 rounded-2xl bg-[#02131c]/90 border border-cyan-900/60 shadow-md space-y-2.5">
        <label className="text-xs font-bold text-cyan-300 flex items-center justify-between">
          <span>মোট ব্যালেন্স (TOTAL BALANCE)</span>
          <span className="text-[10px] text-slate-400 font-mono">BDT (৳)</span>
        </label>

        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-400 font-bold text-base">
            ৳
          </span>
          <input
            type="number"
            value={balance}
            onChange={(e) => setBalance(Math.max(10, Number(e.target.value) || 0))}
            className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-black/60 border border-cyan-500/40 text-white font-mono font-bold text-lg focus:outline-none focus:border-cyan-400"
          />
        </div>

        {/* Presets */}
        <div className="grid grid-cols-5 gap-1.5 pt-1">
          {[500, 1000, 2000, 5000, 10000].map((amt) => (
            <button
              key={amt}
              onClick={() => handlePreset(amt)}
              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold font-mono transition-all cursor-pointer ${
                balance === amt
                  ? 'bg-cyan-500 text-black shadow-[0_0_10px_#06b6d4]'
                  : 'bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-300 border border-cyan-500/30'
              }`}
            >
              ৳{amt}
            </button>
          ))}
        </div>
      </div>

      {/* Step Level Selector */}
      <div className="p-3 rounded-xl bg-[#02131c]/80 border border-cyan-900/60 flex items-center justify-between">
        <span className="text-xs font-bold text-cyan-300">পরিকল্পিত লেভেল (STEPS):</span>
        <div className="flex gap-1">
          {[3, 4, 5, 6, 7].map((lvl) => (
            <button
              key={lvl}
              onClick={() => {
                cyberAudio.playClick();
                setLevels(lvl);
              }}
              className={`w-7 h-7 rounded-lg text-xs font-bold font-mono transition-all cursor-pointer ${
                levels === lvl
                  ? 'bg-cyan-400 text-black shadow-[0_0_8px_#22d3ee]'
                  : 'bg-black/60 text-slate-400 hover:text-white border border-cyan-900'
              }`}
            >
              {lvl}
            </button>
          ))}
        </div>
      </div>

      {/* Results Matrix Table */}
      <div className="rounded-2xl border border-cyan-500/40 bg-[#010c12] overflow-hidden shadow-[0_0_20px_rgba(6,182,212,0.1)]">
        <div className="grid grid-cols-5 gap-1 p-2.5 bg-cyan-950/60 text-[9px] font-black text-cyan-300 uppercase font-mono border-b border-cyan-900/50 text-center">
          <span>Level</span>
          <span>Stage</span>
          <span>Bet (৳)</span>
          <span>Total (৳)</span>
          <span>Net Profit</span>
        </div>

        <div className="divide-y divide-cyan-950/50">
          {steps.map((st) => (
            <div
              key={st.level}
              className="grid grid-cols-5 gap-1 p-2.5 text-[11px] font-mono items-center text-center hover:bg-cyan-950/20"
            >
              <span className="font-bold text-cyan-400">L-{st.level}</span>
              <span className="text-[9.5px] font-bold text-slate-300 truncate">{st.text}</span>
              <span className="font-black text-white">৳{st.amount}</span>
              <span className="text-slate-400 text-[10px]">৳{st.cumulative}</span>
              <span className="font-black text-emerald-400">+৳{st.winReturn}</span>
            </div>
          ))}
        </div>

        <div className="p-2.5 bg-cyan-950/40 border-t border-cyan-900/60 flex items-center justify-between text-[11px] font-mono">
          <span className="text-slate-300 font-bold">মোট ইনভেস্টমেন্ট ক্যাপ:</span>
          <span className="font-black text-cyan-300">৳{steps[steps.length - 1]?.cumulative || balance}</span>
        </div>
      </div>
    </div>
  );
};
export default SevenStepMatrix;
