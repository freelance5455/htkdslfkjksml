/**
 * GODEX v0.0.1 - AI Model Configuration Modal
 */

import React from 'react';
import { Settings, Cpu, X, Sparkles, Check } from 'lucide-react';
import { ModelProviderConfig } from '../types';

interface ModelSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ModelProviderConfig;
  onSaveConfig: (config: ModelProviderConfig) => void;
}

export const ModelSettingsModal: React.FC<ModelSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig
}) => {
  const [model, setModel] = React.useState(config.model);
  const [temperature, setTemperature] = React.useState(config.temperature);
  const [provider, setProvider] = React.useState(config.provider);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveConfig({
      ...config,
      model,
      temperature,
      provider
    });
    onClose();
  };

  const modelsList = [
    { id: 'local-deterministic-engine', name: 'Local Deterministic Engine', desc: 'Active: Client Browser / CPU + AST grounding and deterministic synthesis (Reference: Core i3-1215U)' },
    { id: 'local-ast-reasoner', name: 'Local AST Deep Analysis Engine', desc: 'Syntax verification, AST parsing, and deterministic graph analysis' },
    { id: 'local-media-processor', name: 'Local Media Processor', desc: 'Hardware-accelerated media composition, WebGL / Quick Sync transcoding' },
    { id: 'local-grounded-model', name: 'Local Grounded Intelligence', desc: 'Truthful source-referenced reasoning with zero synthetic fabrication' },
  ];

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-lg bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <Settings className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                AI_ENGINE.MODEL_SETTINGS
              </h2>
              <p className="text-[10px] text-neutral-400 font-sans">Configure foundation model and reasoning temperature parameters</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#07080D]">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
              Selected Foundation Model
            </label>
            <div className="space-y-2">
              {modelsList.map(m => (
                <div
                  key={m.id}
                  onClick={() => setModel(m.id)}
                  className={`p-3 rounded border cursor-pointer transition-all ${
                    model === m.id
                      ? 'border-cyan-500/80 bg-[#101B2A] shadow-sm shadow-cyan-950'
                      : 'border-[#1B2232] bg-[#0D1018] hover:border-[#28354E]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{m.name}</span>
                    {model === m.id && <Check className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-0.5 font-sans">{m.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Temperature Slider */}
          <div className="pt-2 space-y-2">
            <div className="flex justify-between text-xs font-bold text-neutral-300">
              <span>Reasoning Temperature</span>
              <span className="font-mono text-cyan-400">{temperature.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
              <span>Deterministic (0.0)</span>
              <span>Balanced (0.7)</span>
              <span>Creative (1.0)</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-end gap-2 shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
          >
            CANCEL
          </button>
          <button
            onClick={handleSave}
            className="px-3 py-1 rounded bg-[#0E2A38] hover:bg-[#133A4E] border border-cyan-500/60 text-xs font-bold text-cyan-300 shadow transition-all"
          >
            APPLY_SETTINGS
          </button>
        </div>
      </div>
    </div>
  );
};
