import React, { useState, useEffect } from 'react';
import { Music, Play, Square, Copy, Check, Bookmark, Sparkles, Volume2, VolumeX, Sliders } from 'lucide-react';
import { rhythmPlayer, speakText, stopSpeaking } from '../utils/audio.ts';
import confetti from 'canvas-confetti';

interface MusicTabProps {
  onSave: (type: 'music', title: string, subtitle: string, content: string) => void;
  showToast: (msg: string) => void;
}

export const MusicTab: React.FC<MusicTabProps> = ({ onSave, showToast }) => {
  const [genre, setGenre] = useState('Chichewa Gospel Praise & Worship');
  const [language, setLanguage] = useState('Chichewa');
  const [topic, setTopic] = useState('');
  const [isComposing, setIsComposing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Metronome & Rhythm clicker state
  const [isMetronomePlaying, setIsMetronomePlaying] = useState(false);
  const [bpm, setBpm] = useState(115);
  const [activeBeat, setActiveBeat] = useState(0);

  useEffect(() => {
    return () => {
      rhythmPlayer.stop();
      stopSpeaking();
    };
  }, []);

  const toggleMetronome = () => {
    if (isMetronomePlaying) {
      rhythmPlayer.stop();
      setIsMetronomePlaying(false);
    } else {
      rhythmPlayer.start(bpm, (beat) => setActiveBeat(beat));
      setIsMetronomePlaying(true);
    }
  };

  const handleBpmChange = (newBpm: number) => {
    setBpm(newBpm);
    rhythmPlayer.setBpm(newBpm);
  };

  const presets = [
    {
      title: '🇲🇼 Gospel Praise & Grace',
      style: 'Chichewa Gospel Praise & Worship',
      lang: 'Chichewa',
      prompt: 'Chikondi cha Mulungu pa moyo wanga, kumuyamika chifukwa chonditeteza mu mavuto onse (God’s unending grace and protection through trials)',
    },
    {
      title: '🎹 Amapiano Log Drum Anthem',
      style: 'Amapiano (Log drum, soulful vocals)',
      lang: 'Bilingual Chichewa & English',
      prompt: 'A weekend party anthem celebrating life, success, and pure rhythm with deep log drum drops and energetic chants',
    },
    {
      title: '🌅 Lake Malawi Love Song',
      style: 'Afro-Pop Acoustic Love Song',
      lang: 'Bilingual Chichewa & English',
      prompt: 'A romantic acoustic guitar serenade along the golden sunset beaches of Cape Maclear, expressing eternal commitment',
    },
  ];

  const handleCompose = async () => {
    if (!topic.trim()) {
      showToast('Please enter a song inspiration or topic');
      return;
    }

    setIsComposing(true);
    setResult(null);
    setSaved(false);

    try {
      const res = await fetch('/api/lyrics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ genre, language, topic }),
      });
      const data = await res.json();

      if (data.result) {
        setResult(data.result);
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 },
            colors: ['#fae48c', '#d4af37', '#9b51e0'],
          });
        } catch {
          // ignore if canvas not supported
        }

        // Try extracting BPM from result if present
        const bpmMatch = data.result.match(/(\d{2,3})\s*BPM/i);
        if (bpmMatch && bpmMatch[1]) {
          const parsedBpm = parseInt(bpmMatch[1], 10);
          if (parsedBpm >= 60 && parsedBpm <= 180) {
            setBpm(parsedBpm);
          }
        }
      } else {
        showToast(data.error || 'Failed to compose track');
      }
    } catch {
      showToast('Network error while composing track');
    } finally {
      setIsComposing(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    showToast('Song lyrics & chords copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveItem = () => {
    if (!result) return;
    const titleMatch = result.match(/^#\s*(.+)$/m);
    const title = titleMatch ? titleMatch[1].replace(/[*#]/g, '').trim() : `${genre} Track`;
    onSave('music', title, `${genre} • ${language}`, result);
    setSaved(true);
    showToast('Saved to your vault!');
  };

  const toggleSpeech = () => {
    if (!result) return;
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      speakText(result, undefined, () => setIsSpeaking(false));
    }
  };

  return (
    <div className="p-3.5 space-y-4 max-w-2xl mx-auto">
      {/* Title Card */}
      <div className="bg-[#1b0a33] border border-[#d4af37]/35 rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#d4af37]/15 to-transparent rounded-bl-full pointer-events-none" />

        <div className="flex items-center gap-2 mb-1">
          <Music className="w-5 h-5 text-[#fae48c]" />
          <h2 className="royal-heading text-lg font-bold gold-gradient-text">
            Music & Lyrics Creator
          </h2>
        </div>
        <p className="text-xs text-[#bfaad4] leading-relaxed">
          Compose studio-ready songs with chords, arrangement cues, and performance notes. Specially tuned for authentic Malawian gospel, Amapiano log drums, and African love ballads.
        </p>

        {/* Quick Presets */}
        <div className="mt-3 pt-3 border-t border-[#d4af37]/15">
          <label className="text-[10px] tracking-wider uppercase text-[#d4af37] font-semibold block mb-1.5">
            Quick Inspirations
          </label>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setGenre(preset.style);
                  setLanguage(preset.lang);
                  setTopic(preset.prompt);
                }}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-[#250f44] border border-[#d4af37]/25 hover:border-[#fae48c] text-[11px] text-[#fae48c] text-left transition-all active:scale-95"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        {/* Form Controls */}
        <div className="mt-3.5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
                Style & Vibe
              </label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none transition-colors"
              >
                <option value="Chichewa Gospel Praise & Worship">Chichewa Gospel (Praise & Worship)</option>
                <option value="Amapiano (Log drum, soulful vocals)">Amapiano (Log Drum & Soulful)</option>
                <option value="Afro-Pop Acoustic Love Song">Afro-Pop Acoustic Love Song</option>
                <option value="English Contemporary Pop/R&B">English Pop / R&B</option>
                <option value="Malawian Roots Reggae / Dancehall">Malawian Roots Reggae</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
                Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none transition-colors"
              >
                <option value="Chichewa">Chichewa</option>
                <option value="Bilingual Chichewa & English">Bilingual (Chichewa + English)</option>
                <option value="English">English</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
              Song Story or Inspiration
            </label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              rows={3}
              placeholder="e.g. Chikondi cha Mulungu pa moyo wanga, or a romantic story along the shores of Lake Malawi..."
              className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none placeholder-[#8771a3] transition-colors resize-none"
            />
          </div>

          <button
            onClick={handleCompose}
            disabled={isComposing || !topic.trim()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#fae48c] via-[#d4af37] to-[#8d6f1a] text-[#120422] font-bold text-sm tracking-wide shadow-[0_3px_15px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {isComposing ? 'Composing Your Masterpiece...' : 'Compose Track'}
          </button>
        </div>
      </div>

      {/* Rhythm Metronome Tool */}
      <div className="bg-[#18082f] border border-[#d4af37]/25 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={toggleMetronome}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              isMetronomePlaying
                ? 'bg-rose-500 text-white shadow-[0_0_12px_#f43f5e]'
                : 'bg-[#280e4d] text-[#fae48c] hover:bg-[#341264]'
            }`}
            title={isMetronomePlaying ? 'Stop Metronome' : 'Start Metronome'}
          >
            {isMetronomePlaying ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#fae48c]">
              <span>Rhythm Metronome</span>
              <span className="text-[#a48ebc] font-normal">({bpm} BPM)</span>
            </div>
            {/* Visual Beat Indicator Dots */}
            <div className="flex gap-1.5 mt-1">
              {[0, 1, 2, 3].map((b) => (
                <span
                  key={b}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-75 ${
                    isMetronomePlaying && activeBeat === b
                      ? b === 0
                        ? 'bg-[#fae48c] scale-125 shadow-[0_0_8px_#fae48c]'
                        : 'bg-[#d4af37] scale-110'
                      : 'bg-[#2f1454]'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* BPM Slider */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Sliders className="w-3.5 h-3.5 text-[#bfaad4]" />
          <input
            type="range"
            min="60"
            max="160"
            value={bpm}
            onChange={(e) => handleBpmChange(Number(e.target.value))}
            className="w-full sm:w-28 accent-[#d4af37] cursor-pointer"
          />
          <span className="text-[11px] font-mono text-[#fae48c] w-8 text-right">{bpm}</span>
        </div>
      </div>

      {/* Generated Song Output */}
      {result && (
        <div className="bg-[#18082f] border border-[#d4af37]/40 rounded-2xl p-4 shadow-2xl space-y-3 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-[#d4af37]/20 pb-3 flex-wrap gap-2">
            <span className="text-xs uppercase font-bold tracking-widest gold-gradient-text flex items-center gap-1.5">
              <Music className="w-4 h-4 text-[#fae48c]" />
              Song Chart & Lyrics
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={toggleSpeech}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#240e45] text-xs text-[#fae48c] border border-[#d4af37]/30 hover:bg-[#30125c] transition-colors"
                title="Listen to lyrics"
              >
                {isSpeaking ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                    <span>Stop</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Listen</span>
                  </>
                )}
              </button>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#240e45] text-xs text-[#fae48c] border border-[#d4af37]/30 hover:bg-[#30125c] transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={handleSaveItem}
                disabled={saved}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#d4af37] text-xs text-[#120422] font-bold hover:brightness-110 transition-colors disabled:opacity-60"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{saved ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>

          {/* Formatted Song Content */}
          <div className="text-[13px] leading-relaxed text-[#eee4f5] whitespace-pre-wrap font-sans bg-[#110424] p-3.5 rounded-xl border border-[#d4af37]/15 overflow-x-auto max-h-[500px] overflow-y-auto">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};
