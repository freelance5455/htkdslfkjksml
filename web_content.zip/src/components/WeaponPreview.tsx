import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildGun } from '../game/models';
import { W } from '../game/weapons';
import type { SkinColors } from '../game/store';

export default function WeaponPreview({ id, skin }: { id: string; skin: SkinColors }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef<{ r: THREE.WebGLRenderer; scene: THREE.Scene; cam: THREE.PerspectiveCamera; holder: THREE.Group; raf: number; drag: boolean; vy: number; lx: number } | null>(null);

  useEffect(() => {
    const c = ref.current!;
    const r = new THREE.WebGLRenderer({ canvas: c, antialias: true, alpha: true });
    r.setPixelRatio(Math.min(2, window.devicePixelRatio));
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    const scene = new THREE.Scene();
    const cam = new THREE.PerspectiveCamera(30, 1, 0.01, 50);
    cam.position.set(0, 0.12, 2.1);
    scene.add(new THREE.HemisphereLight('#ffffff', '#443322', 1.4));
    const d1 = new THREE.DirectionalLight('#fff3e0', 2.4); d1.position.set(2, 3, 2); scene.add(d1);
    const d2 = new THREE.DirectionalLight('#7fb6ff', 1.2); d2.position.set(-3, 1, -2); scene.add(d2);
    const holder = new THREE.Group(); scene.add(holder);
    const s = { r, scene, cam, holder, raf: 0, drag: false, vy: 0.5, lx: 0 };
    st.current = s;
    const resize = () => {
      const w = c.clientWidth, h = c.clientHeight;
      r.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(c);
    let last = performance.now();
    const loop = () => {
      s.raf = requestAnimationFrame(loop);
      const now = performance.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (!s.drag) { s.vy += (0.5 - s.vy) * dt * 2; }
      holder.rotation.y += s.vy * dt;
      holder.position.y = Math.sin(now / 900) * 0.02;
      r.render(scene, cam);
    };
    loop();
    const down = (e: PointerEvent) => { s.drag = true; s.lx = e.clientX; c.setPointerCapture(e.pointerId); };
    const move = (e: PointerEvent) => { if (!s.drag) return; const dx = e.clientX - s.lx; s.lx = e.clientX; holder.rotation.y += dx * 0.01; s.vy = dx * 0.6; };
    const up = () => { s.drag = false; };
    c.addEventListener('pointerdown', down); c.addEventListener('pointermove', move); c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    return () => {
      cancelAnimationFrame(s.raf); ro.disconnect(); r.dispose();
      c.removeEventListener('pointerdown', down); c.removeEventListener('pointermove', move); c.removeEventListener('pointerup', up);
    };
  }, []);

  useEffect(() => {
    const s = st.current; if (!s) return;
    s.holder.clear();
    const def = W[id];
    const g = buildGun(def, skin, false).group;
    const box = new THREE.Box3().setFromObject(g);
    const size = box.getSize(new THREE.Vector3()); const center = box.getCenter(new THREE.Vector3());
    g.position.sub(center);
    const sc = 1.25 / Math.max(size.x, size.y, size.z, 0.2);
    const wrap = new THREE.Group(); wrap.add(g); wrap.scale.setScalar(sc);
    wrap.rotation.y = Math.PI / 2;
    s.holder.add(wrap);
  }, [id, skin]);

  return <canvas ref={ref} className="w-full h-full block cursor-grab active:cursor-grabbing" style={{ touchAction: 'none' }} />;
}
