import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import { HuntingWorld, type LoadoutSpec, type WorldCallbacks, type WorldMode } from "@/game/world";
import type { MapId } from "@/data";

export interface WorldCanvasHandle {
  fire: () => void;
  reload: () => void;
  toggleAim: () => boolean;
  setMove: (code: string, active: boolean) => void;
  setLoadout: (loadout: LoadoutSpec) => void;
  setMoveAxes: (x: number, y: number) => void;
  setLookSensitivity: (value: number) => void;
  setInfiniteAmmo: (value: boolean) => void;
  setMap: (id: MapId) => void;
  beginWave: (index: number, population: number) => void;
  resetHunt: () => void;
}

interface Props {
  mode: WorldMode;
  paused: boolean;
  loadout: LoadoutSpec;
  callbacks: WorldCallbacks;
}

const WorldCanvas = forwardRef<WorldCanvasHandle, Props>(function WorldCanvas({ mode, paused, loadout, callbacks }, ref) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<HuntingWorld | null>(null);
  const callbackRef = useRef(callbacks);
  callbackRef.current = callbacks;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const world = new HuntingWorld(canvas, {
      onAmmo: (magazine, reserve) => callbackRef.current.onAmmo(magazine, reserve),
      onReload: (active) => callbackRef.current.onReload(active),
      onShot: (result) => callbackRef.current.onShot(result),
      onEmpty: () => callbackRef.current.onEmpty(),
      onTarget: (target) => callbackRef.current.onTarget(target),
      onHeading: (degrees) => callbackRef.current.onHeading(degrees),
      onAim: (aiming) => callbackRef.current.onAim(aiming),
      onSpotted: (species) => callbackRef.current.onSpotted(species),
      onFlash: () => callbackRef.current.onFlash?.(),
    });
    worldRef.current = world;
    world.setLoadout(loadout);
    return () => {
      world.dispose();
      worldRef.current = null;
    };
    // The world is created once; prop changes are handled by the effects below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    worldRef.current?.setMode(mode);
  }, [mode]);

  useEffect(() => {
    worldRef.current?.setPaused(paused);
  }, [paused]);

  useEffect(() => {
    worldRef.current?.setLoadout(loadout);
  }, [loadout]);

  useImperativeHandle(
    ref,
    () => ({
      fire: () => worldRef.current?.fire(),
      reload: () => worldRef.current?.reload(),
      toggleAim: () => worldRef.current?.toggleAim() ?? false,
      setMove: (code, active) => worldRef.current?.setMove(code, active),
      setLoadout: (next: LoadoutSpec) => worldRef.current?.setLoadout(next),
      setMoveAxes: (x, y) => worldRef.current?.setMoveAxes(x, y),
      setLookSensitivity: (value) => worldRef.current?.setLookSensitivity(value),
      setInfiniteAmmo: (value) => worldRef.current?.setInfiniteAmmo(value),
      setMap: (id) => worldRef.current?.setMap(id),
      beginWave: (index, population) => worldRef.current?.beginWave(index, population),
      resetHunt: () => worldRef.current?.resetHunt(),
    }),
    [],
  );

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none select-none" aria-label="Interactive 3D wilderness" />;
});

export default WorldCanvas;
