import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatMessage } from '../types.ts';
import { PlayerHead } from './PlayerHead.tsx';
import {
  Send,
  Edit2,
  Check,
  AlertCircle
} from 'lucide-react';

export const ChatView: React.FC = () => {
  // Load saved profile or username from localStorage
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('helden_chat_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.name?.trim()) return parsed;
      }
      const rawName = localStorage.getItem('helden_chat_username');
      const rawPlatform = localStorage.getItem('helden_chat_platform') as 'java' | 'bedrock' | null;
      if (rawName && rawName.trim()) {
        const isBedrock = rawPlatform === 'bedrock' || rawName.startsWith('.');
        const clean = isBedrock ? (rawName.startsWith('.') ? rawName : '.' + rawName) : rawName;
        return { name: clean, platform: isBedrock ? 'bedrock' : 'java' };
      }
      return null;
    } catch {
      return null;
    }
  });

  const [inputName, setInputName] = useState<string>(() => {
    if (profile?.name) return profile.name;
    try {
      return localStorage.getItem('helden_chat_username') || '';
    } catch {
      return '';
    }
  });

  const [platform, setPlatform] = useState<'java' | 'bedrock'>(() => {
    if (profile?.platform) return profile.platform;
    try {
      return (localStorage.getItem('helden_chat_platform') as 'java' | 'bedrock') || 'java';
    } catch {
      return 'java';
    }
  });

  // Only edit mode if no profile name is saved yet
  const [isEditingProfile, setIsEditingProfile] = useState(!profile?.name);

  // Auto-persist username and platform on any change so it's never lost
  useEffect(() => {
    if (inputName.trim()) {
      try {
        localStorage.setItem('helden_chat_username', inputName.trim());
        localStorage.setItem('helden_chat_platform', platform);
      } catch {
        // ignore
      }
    }
  }, [inputName, platform]);

  // Persist full profile to localStorage
  useEffect(() => {
    if (profile?.name) {
      try {
        localStorage.setItem('helden_chat_profile', JSON.stringify(profile));
        localStorage.setItem('helden_chat_username', profile.name);
        localStorage.setItem('helden_chat_platform', profile.platform);
      } catch {
        // ignore
      }
    }
  }, [profile]);

  // Chat message state
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [sendSuccess, setSendSuccess] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Live Server Chat listener: SSE stream + periodic polling fallback
  useEffect(() => {
    // 1. Initial fetch of recent chat history from server
    const fetchRecentMessages = async () => {
      try {
        const res = await fetch('/api/chat/messages');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.messages)) {
            setMessages((prev) => {
              const map = new Map<string, ChatMessage>();
              prev.forEach((m) => map.set(m.id, m));
              data.messages.forEach((m: ChatMessage) => map.set(m.id, m));
              return Array.from(map.values()).sort((a, b) => a.timestamp - b.timestamp);
            });
          }
        }
      } catch {
        // ignore network error
      }
    };

    fetchRecentMessages();

    // 2. Real-time Server-Sent Events (SSE) listener
    let evtSource: EventSource | null = null;
    try {
      evtSource = new EventSource('/api/chat/stream');

      evtSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'init' && Array.isArray(payload.messages)) {
            setMessages((prev) => {
              const map = new Map<string, ChatMessage>();
              prev.forEach((m) => map.set(m.id, m));
              payload.messages.forEach((m: ChatMessage) => map.set(m.id, m));
              return Array.from(map.values()).sort((a, b) => a.timestamp - b.timestamp);
            });
          } else if (payload.sender && payload.text) {
            setMessages((prev) => {
              // Avoid duplicate if already in state
              if (prev.some((m) => m.id === payload.id)) return prev;
              return [...prev, payload].sort((a, b) => a.timestamp - b.timestamp);
            });
          }
        } catch {
          // ignore parse errors
        }
      };
    } catch {
      // EventSource not supported or failed
    }

    // 3. Polling backup every 3.5 seconds
    const interval = setInterval(fetchRecentMessages, 3500);

    return () => {
      if (evtSource) evtSource.close();
      clearInterval(interval);
    };
  }, []);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (!isEditingProfile) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isEditingProfile]);

  // Handle Bedrock / Java platform toggle with automatic dot prefix
  const handlePlatformChange = (newPlatform: 'java' | 'bedrock') => {
    setPlatform(newPlatform);
    if (newPlatform === 'bedrock') {
      if (inputName && !inputName.startsWith('.')) {
        setInputName('.' + inputName);
      }
    } else {
      if (inputName.startsWith('.')) {
        setInputName(inputName.replace(/^\.+/, ''));
      }
    }
  };

  // Handle typing name: keep dot if bedrock
  const handleNameInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value;
    if (platform === 'bedrock') {
      if (val.length > 0 && !val.startsWith('.')) {
        val = '.' + val;
      }
    }
    setInputName(val);
  };

  // Save profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    let finalName = inputName.trim();
    if (!finalName) return;

    if (platform === 'bedrock' && !finalName.startsWith('.')) {
      finalName = '.' + finalName;
    } else if (platform === 'java' && finalName.startsWith('.')) {
      finalName = finalName.replace(/^\.+/, '');
    }

    const newProfile: UserProfile = {
      name: finalName,
      platform,
    };

    setProfile(newProfile);
    setInputName(finalName);
    try {
      localStorage.setItem('helden_chat_profile', JSON.stringify(newProfile));
      localStorage.setItem('helden_chat_username', finalName);
      localStorage.setItem('helden_chat_platform', platform);
    } catch {
      // ignore
    }
    setIsEditingProfile(false);
  };

  // Send message to ServerTap / Minecraft server
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !profile || isSending) return;

    const textToSend = message.trim();
    setIsSending(true);
    setSendError(null);
    setSendSuccess(false);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: profile.name,
          message: textToSend,
          platform: profile.platform,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Fehler beim Senden (${res.status})`);
      }

      const newMsg: ChatMessage = {
        id: `local-${Date.now()}`,
        sender: profile.name,
        text: textToSend,
        timestamp: Date.now(),
        platform: profile.platform,
        isOffline: true,
      };

      setMessages((prev) => [...prev, newMsg]);
      setMessage('');
      setSendSuccess(true);
      setTimeout(() => setSendSuccess(false), 2000);
    } catch (err: any) {
      setSendError(err.message || 'Verbindung zum Server fehlgeschlagen');
    } finally {
      setIsSending(false);
    }
  };

  const isMyMessage = (sender: string) => {
    if (!profile?.name) return false;
    const cleanSender = sender.replace(/^\.+/, '').toLowerCase();
    const cleanMyName = profile.name.replace(/^\.+/, '').toLowerCase();
    return cleanSender === cleanMyName;
  };

  return (
    <div className="w-full space-y-4">
      {/* Mode 1: Profile Setup (Open form without nested box) */}
      {isEditingProfile ? (
        <form onSubmit={handleSaveProfile} className="space-y-4 py-2">
          {/* Avatar & Name Preview */}
          <div className="flex flex-col items-center justify-center py-2 space-y-2">
            <PlayerHead
              identifier={inputName.trim() || (platform === 'bedrock' ? '.Steve' : 'Steve')}
              size="lg"
              className="w-16 h-16 shadow-md ring-2 ring-emerald-500/40 rounded-xl"
            />
            <div className="text-center">
              <span className="text-sm font-semibold text-zinc-200 font-mono">
                {inputName.trim() || 'Spielername eingeben'}
              </span>
              <p className="text-[11px] text-zinc-500">
                Wähle deinen Minecraft-Namen und deine Edition
              </p>
            </div>
          </div>

          {/* Edition Selector */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider px-1">
              Edition
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-900/80 border border-zinc-800">
              <button
                type="button"
                onClick={() => handlePlatformChange('java')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                  platform === 'java'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Java Edition
              </button>
              <button
                type="button"
                onClick={() => handlePlatformChange('bedrock')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                  platform === 'bedrock'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Bedrock Edition
              </button>
            </div>
            <p className="text-[11px] text-zinc-500 px-1">
              {platform === 'bedrock'
                ? '✓ Bedrock: Der Punkt (.) wird automatisch vor deinen Namen gesetzt.'
                : '✓ Java: Name ohne Punkt.'}
            </p>
          </div>

          {/* Name Input */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider px-1">
              Minecraft Name
            </label>
            <input
              type="text"
              value={inputName}
              onChange={handleNameInputChange}
              placeholder={platform === 'bedrock' ? '.DeinName' : 'DeinName'}
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2">
            {profile && (
              <button
                type="button"
                onClick={() => setIsEditingProfile(false)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              >
                Abbrechen
              </button>
            )}
            <button
              type="submit"
              disabled={!inputName.trim()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-50 shadow-sm"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Fertig</span>
            </button>
          </div>
        </form>
      ) : (
        /* Mode 2: Live Chat Stream */
        <div className="space-y-3">
          {/* Sticky Subtle User Bar */}
          <div className="sticky top-[64px] sm:top-[76px] z-20 flex items-center justify-between px-2 py-2 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/50">
            <div className="flex items-center gap-2.5 min-w-0">
              <PlayerHead
                identifier={profile!.name}
                size="sm"
                className="w-7 h-7 rounded-lg shadow-sm"
              />
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-semibold text-zinc-200 truncate font-mono text-xs">
                  {profile!.name}
                </span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[10px] font-semibold uppercase ${
                    profile!.platform === 'bedrock'
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                  }`}
                >
                  {profile!.platform === 'bedrock' ? 'Bedrock' : 'Java'}
                </span>
                <span className="text-[10px] text-zinc-500 font-mono">
                  [Offline]
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setInputName(profile!.name);
                setPlatform(profile!.platform);
                setIsEditingProfile(true);
              }}
              title="Namen oder Edition ändern"
              className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded-md hover:bg-zinc-800/80 transition-colors"
            >
              <Edit2 className="w-3 h-3" />
              <span>Ändern</span>
            </button>
          </div>

          {/* Open Stream of Messages (Both Other Players and Yours!) */}
          <div className="space-y-3 min-h-[200px] max-h-[calc(100vh-290px)] overflow-y-auto px-1 py-2 overscroll-contain">
            {messages.length === 0 ? (
              <div className="text-center py-10 text-zinc-500 space-y-1">
                <p className="text-xs">Noch keine Chat-Nachrichten vorhanden.</p>
                <p className="text-[11px] text-zinc-600">
                  Nachrichten von Spielern auf dem Server und aus dieser App erscheinen hier live.
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const mine = isMyMessage(msg.sender);

                if (mine) {
                  // Eigene Nachricht (rechts ausgerichtet)
                  return (
                    <div key={msg.id} className="flex flex-col items-end gap-0.5">
                      <div className="flex items-baseline gap-1.5 text-[10px] text-zinc-500 mr-1.5">
                        {msg.isOffline && <span className="text-emerald-400 font-mono font-medium">[Offline]</span>}
                        <span className="font-semibold text-zinc-300">Du</span>
                        <span>·</span>
                        <span>
                          {new Date(msg.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <div className="max-w-[85%] px-3.5 py-2 rounded-2xl bg-emerald-600 text-white rounded-tr-xs shadow-xs text-xs leading-relaxed break-words">
                        {msg.text}
                      </div>
                    </div>
                  );
                }

                // Nachricht von anderen Spielern auf dem Server (links ausgerichtet mit Spielerkopf)
                return (
                  <div key={msg.id} className="flex items-start gap-2.5">
                    <PlayerHead
                      identifier={msg.sender}
                      size="sm"
                      className="w-7 h-7 rounded-lg shrink-0 mt-0.5 shadow-sm ring-1 ring-zinc-700/50"
                    />
                    <div className="flex flex-col items-start gap-0.5 max-w-[85%]">
                      <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 ml-1">
                        <span className="font-semibold text-zinc-200">{msg.sender}</span>
                        <span
                          className={`px-1 py-0.2 rounded text-[9px] font-semibold uppercase ${
                            msg.platform === 'bedrock' || msg.sender.startsWith('.')
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                          }`}
                        >
                          {msg.platform === 'bedrock' || msg.sender.startsWith('.') ? 'Bedrock' : 'Java'}
                        </span>
                        {msg.isOffline && (
                          <span className="text-emerald-400 font-mono text-[9px]">[Offline]</span>
                        )}
                        <span className="text-zinc-600">·</span>
                        <span className="text-zinc-500">
                          {new Date(msg.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <div className="px-3.5 py-2 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-tl-xs shadow-xs text-xs leading-relaxed break-words">
                        {msg.text}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Error / Success Notices */}
          {sendError && (
            <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="truncate">{sendError}</span>
            </div>
          )}
          {sendSuccess && (
            <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Nachricht an Minecraft-Server gesendet!</span>
            </div>
          )}

          {/* Sticky Clean Input Field pinned right above floating navbar */}
          <div className="sticky bottom-18 sm:bottom-20 z-20 pt-2 pb-1 bg-zinc-950/90 backdrop-blur-md">
            <form
              onSubmit={handleSendMessage}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Nachricht an den Server schreiben..."
                disabled={isSending}
                className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!message.trim() || isSending}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all disabled:opacity-50 shadow-sm active:scale-95 shrink-0"
                title="Nachricht senden"
              >
                <Send className={`w-4 h-4 ${isSending ? 'animate-pulse' : ''}`} />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
