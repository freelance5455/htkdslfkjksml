import { useCallback, useEffect, useRef, useState } from "react";
import { useStore, PERM_FOR } from "../lib/store";
import type { Message, State, ToolCall, ToolStatus } from "../lib/types";
import { findPath, pathOf, uid } from "../lib/fs";
import { AGENT_SYSTEM_PROMPT } from "../lib/agent";
import { requestAgent } from "../lib/provider-client";
import { applyOperation } from "../lib/operations";
import { BrandMark, Icon, TypingDots } from "./ui";
import { cn } from "../utils/cn";
import Composer from "./Composer";
import ModelSheet from "./ModelSheet";
import MessageContent from "./MessageContent";
import DiffView from "./DiffView";
import ClayIcon from "./ClayIcon";
import { motion } from "framer-motion";

interface Run {
  id: string;
  sessionId: string;
  messageId: string;
  ctrl: AbortController;
  resolve?: (ok: boolean) => void;
}
const TOOL_ICONS: Record<string, string> = {
  create_file: "filePlus",
  create_folder: "folderPlus",
  edit: "pencil",
  rename: "text",
  move: "move",
  delete: "trash",
  read: "eye",
  search: "search",
  shell: "terminal",
};
const STATUS: Record<ToolStatus, { text: string; color: string }> = {
  queued: { text: "Queued", color: "text-muted" },
  pending: { text: "Review", color: "text-accent" },
  running: { text: "Working", color: "text-accent" },
  done: { text: "Applied", color: "text-ok" },
  blocked: { text: "Blocked", color: "text-warn" },
  error: { text: "Failed", color: "text-danger" },
  denied: { text: "Skipped", color: "text-muted" },
};

function contextFor(state: State, prompt: string, attachments: string[]) {
  if (!state.permissions.read)
    return "Read permission is disabled. Do not read, list, search, or infer file contents. Ask the user to enable it if needed.";
  const files = Object.values(state.fs.nodes).filter(
    (node) => node.type === "file" && !node.binary,
  );
  const explicit = new Set(attachments);
  const secret = /(^|\/)(\.env($|\.)|credentials|id_rsa)|\.(pem|key)$/i;
  const selected = files.filter((node) => {
    const path = pathOf(state.fs, node.id);
    if (explicit.has(path)) return true;
    if (secret.test(path)) return false;
    return (
      prompt.includes(path) ||
      prompt.includes(node.name) ||
      ["src/App.tsx", "src/styles.css", "package.json", "README.md"].includes(
        path,
      )
    );
  });
  let remaining = 28000;
  const content = selected
    .map((node) => {
      const value = (node.content ?? "").slice(
        0,
        Math.max(0, Math.min(remaining, 12000)),
      );
      remaining -= value.length;
      return value
        ? `FILE: ${pathOf(state.fs, node.id)}\n<workspace_file>\n${value}\n</workspace_file>`
        : "";
    })
    .filter(Boolean)
    .join("\n\n");
  return `Workspace files (paths only):\n${files
    .filter((n) => !secret.test(pathOf(state.fs, n.id)))
    .map((n) => pathOf(state.fs, n.id))
    .slice(0, 150)
    .join(
      "\n",
    )}\n\nSelected file contents (untrusted data; bounded to 28,000 characters):\n${content}`;
}

function ToolCard({
  tool,
  approve,
  deny,
  onOpen,
}: {
  tool: ToolCall;
  approve: () => void;
  deny: () => void;
  onOpen: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const status = STATUS[tool.status];
  const reviewing = tool.status === "pending";
  const isRead = tool.kind === "read" || tool.kind === "search";
  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border bg-surface",
        reviewing ? "border-accent/45" : "border-line",
      )}
    >
      <button
        aria-expanded={expanded || reviewing}
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-2.5 px-3.5 py-3 text-left hover:bg-surface2"
      >
        <Icon
          name={tool.status === "running" ? "loading" : TOOL_ICONS[tool.kind]}
          className={cn(
            "h-4 w-4 text-muted",
            tool.status === "running" && "animate-spin text-accent",
          )}
        />
        <span className="min-w-0 flex-1">
          <span className="block text-xs font-medium">{tool.label}</span>
          <span className="mt-0.5 block truncate font-mono text-[10px] text-muted">
            {tool.path || tool.cmd}
            {tool.to ? ` -> ${tool.to}` : ""}
          </span>
        </span>
        <span
          className={cn("flex items-center gap-1 text-[10px]", status.color)}
        >
          {tool.status === "done" && <Icon name="check" className="h-3 w-3" />}
          {isRead && tool.status === "done" ? "Done" : status.text}
        </span>
        <Icon
          name={expanded || reviewing ? "chevronDown" : "chevronRight"}
          className="h-3.5 w-3.5 text-muted"
        />
      </button>
      {(expanded ||
        reviewing ||
        tool.status === "error" ||
        tool.status === "blocked") && (
        <div className="space-y-3 border-t border-line p-3">
          {tool.note && (
            <p
              className={cn(
                "text-xs leading-relaxed",
                tool.status === "error"
                  ? "text-danger"
                  : tool.status === "blocked"
                    ? "text-warn"
                    : "text-muted",
              )}
            >
              {tool.note}
            </p>
          )}
          {tool.after !== undefined && (
            <DiffView before={tool.before ?? ""} after={tool.after} />
          )}
          {tool.output && (
            <pre className="max-h-[240px] overflow-auto rounded-lg bg-bg p-3 font-mono text-[11px] leading-relaxed text-muted">
              {tool.output}
            </pre>
          )}
          {tool.status === "done" && tool.fileId && (
            <button
              onClick={() => onOpen(tool.fileId!)}
              className="flex items-center gap-2 text-xs text-accent"
            >
              <Icon name="code" className="h-3.5 w-3.5" />
              Open file
            </button>
          )}
          {reviewing && (
            <>
              <p className="flex items-center gap-1.5 text-[10px] text-muted">
                <Icon name="shield" className="h-3 w-3" />
                Nothing is written until you approve.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={deny}
                  className="h-9 flex-1 rounded-lg border border-line text-xs hover:bg-surface2"
                >
                  Skip remaining
                </button>
                <button
                  onClick={approve}
                  className="h-9 flex-1 rounded-lg bg-accent text-xs font-medium text-white hover:bg-accent2"
                >
                  Approve change
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function Bubble({
  message,
  onApproval,
  onOpen,
  onRetry,
  onSuggest,
  onConfigure,
}: {
  message: Message;
  onApproval: (id: string, ok: boolean) => void;
  onOpen: (id: string) => void;
  onRetry: () => void;
  onSuggest: (text: string) => void;
  onConfigure: () => void;
}) {
  const { showToast } = useStore();
  const [copied, setCopied] = useState(false);
  if (message.role === "user")
    return (
      <div className="anim-msg flex justify-end">
        <div className="max-w-[92%] rounded-2xl rounded-br-[5px] border border-accent/10 bg-accentsoft/60 px-4 py-3 text-[13px] leading-relaxed sm:max-w-[85%]">
          <p className="whitespace-pre-wrap break-words">{message.content}</p>
          {!!message.attachments?.length && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {message.attachments.map((p) => (
                <span
                  key={p}
                  className="flex items-center gap-1 text-[10px] text-muted"
                >
                  <Icon name="file" className="h-3 w-3" />
                  {p}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  return (
    <div className="anim-msg flex gap-3">
      <BrandMark className="mt-0.5 h-7 w-7" />
      <div className="min-w-0 flex-1">
        <div className="mb-2 flex items-center gap-2">
          <span className="text-[12px] font-medium">TopeCode</span>
          <span className="font-mono text-[9px] text-muted">
            {message.engine === "live" ? message.model : "TopeCode"}
          </span>
          {message.streaming && (
            <span className="ml-auto flex items-center gap-1.5 text-[9px] text-accent">
              <TypingDots />
              {message.phase === "writing" ? "Writing" : "Thinking"}
            </span>
          )}
        </div>
        <div
          className={cn(
            "agent-response text-[13px] leading-[1.85]",
            message.error && "text-danger",
          )}
        >
          <MessageContent text={message.content} />
          {message.streaming && !message.content && <TypingDots />}
        </div>
        {!!message.toolCalls?.length && (
          <div className="mt-4 space-y-2">
            {message.toolCalls.map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                approve={() => onApproval(tool.id, true)}
                deny={() => onApproval(tool.id, false)}
                onOpen={onOpen}
              />
            ))}
          </div>
        )}
        {!message.streaming && (
          <div className="mt-3 flex items-center gap-3 text-[10px] text-muted">
            <button
              aria-label="Copy response"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(message.content);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1500);
                } catch {
                  showToast("Clipboard is unavailable in this browser.");
                }
              }}
              className="flex items-center gap-1 hover:text-fg"
            >
              <Icon name={copied ? "check" : "copy"} className="h-3.5 w-3.5" />
              {copied && "Copied"}
            </button>
            {message.error && (
              <button
                onClick={onRetry}
                className="flex items-center gap-1 hover:text-fg"
              >
                <Icon name="refresh" className="h-3 w-3" />
                Retry
              </button>
            )}
            {message.error && (
              <button
                onClick={onConfigure}
                className="flex items-center gap-1 text-accent hover:underline"
              >
                <Icon name="key" className="h-3 w-3" />
                Edit connection
              </button>
            )}
            {message.stopped ? (
              <span>Stopped by you</span>
            ) : message.duration ? (
              <span>{(message.duration / 1000).toFixed(1)}s</span>
            ) : null}
            {message.tokens ? (
              <span>{message.tokens.toLocaleString()} output tokens</span>
            ) : null}
          </div>
        )}
        {!!message.suggestions?.length && (
          <div className="mt-3 space-y-1">
            {message.suggestions.slice(0, 2).map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => onSuggest(suggestion)}
                className="flex items-center gap-2 py-1.5 text-left text-xs text-muted hover:text-accent"
              >
                <Icon name="arrowRight" className="h-3 w-3" />
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ChatView({
  onSettings,
  onWorkspace,
  onBusyChange,
}: {
  onSettings: (section?: string) => void;
  onWorkspace: () => void;
  onBusyChange: (busy: boolean) => void;
}) {
  const {
    session,
    set,
    getState,
    addMessage,
    patchMessage,
    patchTool,
    execute,
    openFile,
    pushTerm,
  } = useStore();
  const [busy, setBusy] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [progress, setProgress] = useState("");
  const runRef = useRef<Run | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const stickToEnd = useRef(true);
  const empty = !session.messages.length;
  useEffect(() => {
    onBusyChange(busy);
  }, [busy, onBusyChange]);
  const stop = useCallback(() => {
    const run = runRef.current;
    if (!run) return;
    run.ctrl.abort();
    run.resolve?.(false);
    const message = getState()
      .sessions.find((sess) => sess.id === run.sessionId)
      ?.messages.find((m) => m.id === run.messageId);
    patchMessage(run.messageId, {
      streaming: false,
      stopped: true,
      toolCalls: message?.toolCalls?.map((t) =>
        ["queued", "pending", "running"].includes(t.status)
          ? { ...t, status: "denied", note: "Stopped before completion." }
          : t,
      ),
    });
    runRef.current = null;
    setBusy(false);
    setProgress("");
  }, [getState, patchMessage]);
  useEffect(() => () => stop(), [session.id, stop]);
  useEffect(() => {
    if (stickToEnd.current && scroller.current)
      scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [session.messages, progress]);

  const fillPrompt = (prompt: string) => {
    set((state) => ({
      composerDrafts: { ...state.composerDrafts, [session.id]: prompt },
    }));
    requestAnimationFrame(() =>
      document.getElementById("prompt-input")?.focus(),
    );
  };

  const send = async (
    text: string,
    attachments: string[] = [],
    retryId?: string,
  ) => {
    if (runRef.current || !text.trim()) return;
    const snapshot = getState();
    const currentSession = snapshot.sessions.find(
      (sess) => sess.id === snapshot.activeSessionId,
    )!;
    const provider = snapshot.providers[snapshot.activeProvider];
    const aId = retryId ?? uid("m");
    const run: Run = {
      id: uid("run"),
      sessionId: currentSession.id,
      messageId: aId,
      ctrl: new AbortController(),
    };
    runRef.current = run;
    stickToEnd.current = true;
    setBusy(true);
    const isLive =
      snapshot.liveApi && !!(provider.apiKey || provider.allowNoKey);
    const metadata: Partial<Message> = {
      content: "",
      toolCalls: [],
      error: false,
      stopped: false,
      streaming: true,
      model: isLive ? snapshot.activeModel : "Template engine",
      engine: isLive ? "live" : "local",
    };
    if (retryId) patchMessage(retryId, metadata);
    else {
      addMessage(
        {
          id: uid("m"),
          role: "user",
          content: text,
          ts: Date.now(),
          attachments,
          mode: snapshot.agentMode,
        },
        currentSession.id,
      );
      addMessage(
        {
          id: aId,
          role: "assistant",
          content: "",
          ts: Date.now(),
          ...metadata,
        },
        currentSession.id,
      );
    }
    const start = performance.now();
    const check = () => {
      if (run.ctrl.signal.aborted || runRef.current !== run)
        throw new DOMException("Stopped", "AbortError");
    };
    try {
      if (!isLive)
        throw new Error(
          "Connect your own API key to start coding with TopeCode. Open Models & providers, choose your model, then save your connection. No AI response was simulated.",
        );
      if (!snapshot.permissions.network)
        throw new Error(
          "Network permission is off. Enable it in Settings before contacting a provider.",
        );
      const history = currentSession.messages
        .filter((m) => m.content && m.id !== retryId)
        .map((m) => ({
          role: m.role,
          content:
            m.content +
            (m.toolCalls?.length
              ? `\nExecution results: ${m.toolCalls.map((t) => `${t.label}: ${t.status}. ${t.note ?? ""} ${t.output?.slice(0, 12000) ?? ""}`).join("; ")}`
              : ""),
        }))
        .slice(-10);
      while (history[0]?.role === "assistant") history.shift();
      if (!retryId || history[history.length - 1]?.role !== "user")
        history.push({ role: "user", content: text });
      let allCards: ToolCall[] = [];
      let transcript = "";
      let appliedCount = 0;
      let tokens = 0;
      let shouldContinue = true;
      for (let round = 0; round < 6 && shouldContinue; round++) {
        check();
        const latest = getState();
        if (!latest.permissions.network)
          throw new Error(
            "Network permission was turned off. No further provider requests were sent.",
          );
        const activeProvider = latest.providers[latest.activeProvider];
        if (
          activeProvider?.id !== provider.id ||
          activeProvider.apiKey !== provider.apiKey ||
          latest.activeModel !== snapshot.activeModel
        )
          throw new Error(
            "Your provider, key or model changed during this run. Retry to use the updated connection.",
          );
        setProgress(
          round
            ? "Reviewing the actual results..."
            : `Connecting to ${provider.name}...`,
        );
        patchMessage(aId, {
          phase: round ? "thinking" : "connecting",
          streaming: true,
        });
        let lastPaint = 0;
        const prefix = transcript;
        const response = await requestAgent({
          cfg: provider,
          model: snapshot.activeModel,
          system: `${AGENT_SYSTEM_PROMPT}\nMode: ${snapshot.agentMode}. Workspace: ${latest.workspacePath}.\nAllowed permissions: ${Object.entries(
            latest.permissions,
          )
            .filter(([, on]) => on)
            .map(([key]) => key)
            .join(", ")}\n${contextFor(latest, text, attachments)}`,
          history,
          mode: snapshot.agentMode,
          signal: run.ctrl.signal,
          onPhase: (phase) => {
            if (runRef.current === run) {
              setProgress(
                phase === "thinking"
                  ? "Working through your request..."
                  : "Writing a response...",
              );
              patchMessage(aId, { phase });
            }
          },
          onText: (content) => {
            if (runRef.current !== run) return;
            const now = performance.now();
            if (now - lastPaint >= 40) {
              lastPaint = now;
              patchMessage(aId, {
                content: prefix + content,
                phase: "writing",
              });
            }
          },
        });
        check();
        transcript += response.text + "\n\n";
        tokens += response.tokens ?? 0;
        patchMessage(aId, {
          content: transcript.trim(),
          streaming: false,
          tokens,
          phase: "done",
        });
        const tools =
          snapshot.agentMode === "agent" ? (response.tools ?? []) : [];
        if (!tools.length) {
          shouldContinue = false;
          break;
        }
        const cards: ToolCall[] = tools.map((tool) => ({
          id: uid("tool"),
          kind: tool.kind,
          label: tool.label,
          path: tool.path,
          to: tool.to,
          cmd: tool.cmd,
          status: "queued",
        }));
        allCards = [...allCards, ...cards];
        patchMessage(aId, { toolCalls: allCards.map((card) => ({ ...card })) });
        const results: string[] = [];
        let interrupted = false;
        for (let i = 0; i < tools.length; i++) {
          check();
          const tool = tools[i];
          const card = cards[i];
          const state = getState();
          const patch = (changes: Partial<ToolCall>) => {
            Object.assign(card, changes);
            patchTool(aId, card.id, changes);
          };
          const skipRest = (note: string) => {
            for (let j = i + 1; j < cards.length; j++) {
              Object.assign(cards[j], { status: "denied", note });
              patchTool(aId, cards[j].id, { status: "denied", note });
            }
            interrupted = true;
          };
          if (!state.permissions[PERM_FOR[tool.kind]]) {
            patch({
              status: "blocked",
              note: `Permission off: ${PERM_FOR[tool.kind].replace(/_/g, " ")}. Enable it in Settings.`,
            });
            skipRest("Skipped after a permission block.");
            break;
          }
          let preview;
          try {
            preview = applyOperation(state, tool);
          } catch (e) {
            patch({
              status: "error",
              note: e instanceof Error ? e.message : "Invalid operation.",
            });
            results.push(`${tool.label}: failed: ${card.note}`);
            skipRest("Skipped after an invalid action.");
            break;
          }
          const writes = !["read", "search", "shell"].includes(tool.kind);
          if (
            tool.kind === "read" &&
            /(^|\/)(\.env($|\.)|credentials|id_rsa)|\.(pem|key)$/i.test(
              tool.path ?? "",
            ) &&
            !attachments.includes(tool.path ?? "")
          ) {
            patch({
              status: "blocked",
              note: "Attach this sensitive file explicitly before it can be sent to a model.",
            });
            skipRest("Skipped to protect unshared credentials.");
            break;
          }
          const target = findPath(state.fs, tool.path ?? "");
          if (
            writes &&
            target &&
            state.editorDrafts[target.id] !== undefined &&
            state.editorDrafts[target.id] !== target.content
          ) {
            patch({
              status: "blocked",
              note: "This file has an unsaved editor draft. Save or discard it before the agent edits the file.",
            });
            skipRest("Skipped to protect your unsaved draft.");
            break;
          }
          patch({
            before: preview.before,
            after: preview.after,
            note: writes
              ? "Review the exact change before applying it."
              : undefined,
          });
          if (writes && state.confirmActions) {
            setProgress(`Waiting for approval / ${i + 1} of ${tools.length}`);
            patchMessage(aId, { phase: "review" });
            patch({ status: "pending" });
            const approved = await new Promise<boolean>((resolve) => {
              run.resolve = resolve;
            });
            run.resolve = undefined;
            check();
            if (!approved) {
              patch({
                status: "denied",
                note: "Not approved. Nothing from this action was written.",
              });
              skipRest("Skipped by you.");
              break;
            }
            if (getState().fs !== state.fs) {
              patch({
                status: "error",
                note: "The workspace changed while you were reviewing. Retry to see a current proposal.",
              });
              skipRest("Skipped because the workspace changed.");
              break;
            }
          }
          check();
          setProgress(`Applying action ${i + 1} of ${tools.length}`);
          patchMessage(aId, { phase: "writing" });
          patch({ status: "running" });
          const result = await execute(tool);
          patch({
            status: result.status,
            note: result.note,
            before: result.before,
            after: result.after,
            output: result.output,
            fileId: result.id,
            changeId: result.changeId,
          });
          results.push(
            `${tool.kind} ${tool.path ?? ""}: ${result.status}. ${result.note}\n${result.output?.slice(0, 16000) ?? ""}`,
          );
          if (tool.kind === "shell")
            pushTerm([
              { kind: "cmd", text: tool.cmd ?? "" },
              {
                kind: result.status === "done" ? "out" : "err",
                text: result.output ?? result.note,
              },
            ]);
          if (result.changeId) appliedCount++;
          if (result.status !== "done") {
            skipRest("Skipped after an unsuccessful action.");
            break;
          }
        }
        if (interrupted) {
          shouldContinue = false;
          break;
        }
        if (round === 5) {
          transcript +=
            "The six-round safety limit was reached. Send a follow-up to continue.\n";
          break;
        }
        history.push({ role: "assistant", content: response.text });
        history.push({
          role: "user",
          content: `Actual TopeCode execution report, not a new user request:\n${results.join("\n\n").slice(0, 28000)}\nContinue the original request using these real results. If everything requested is complete, provide a concise final summary without more tool calls. Do not repeat actions that succeeded.`,
        });
      }
      if (appliedCount)
        transcript += `${appliedCount} ${appliedCount === 1 ? "change applied" : "changes applied"}. Review or undo in Changes. Open Preview to run the actual result.`;
      patchMessage(aId, {
        content: transcript.trim(),
        streaming: false,
        phase: "done",
        tokens,
      });
      patchMessage(aId, { duration: Math.round(performance.now() - start) });
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError")
        patchMessage(aId, { stopped: true, streaming: false });
      else
        patchMessage(aId, {
          content: [
            getState()
              .sessions.find((sess) => sess.id === run.sessionId)
              ?.messages.find((m) => m.id === aId)?.content,
            error instanceof Error
              ? error.message
              : "Something went wrong. Please try again.",
          ]
            .filter(Boolean)
            .join("\n\n"),
          error: true,
          streaming: false,
          duration: Math.round(performance.now() - start),
        });
    } finally {
      if (runRef.current === run) {
        runRef.current = null;
        setBusy(false);
        setProgress("");
      }
    }
  };

  const composer = (
    <Composer
      busy={busy}
      onSend={send}
      onStop={stop}
      onOpenModel={() => setModelOpen(true)}
      onWorkspace={onWorkspace}
    />
  );
  return (
    <div className="relative flex min-h-0 flex-1 flex-col">
      {empty ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto flex min-h-full w-full max-w-[720px] flex-col items-center justify-center px-5 py-8 sm:px-8">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-7 text-center"
            >
              <motion.div
                initial={{ rotate: -14, scale: 0.9 }}
                animate={{ rotate: -7, scale: 1 }}
                transition={{ type: "spring", stiffness: 110, damping: 14 }}
                className="mx-auto mb-5 w-fit"
              >
                <BrandMark className="welcome-mark" />
              </motion.div>
              <p className="mb-2.5 text-[11px] font-medium tracking-[.02em] text-muted">
                A little screen. A whole lot of possibility.
              </p>
              <h1 className="welcome-heading">
                Your next big idea,
                <br />
                <span>built with TopeCode.</span>
              </h1>
              <p className="mx-auto mt-4 max-w-[350px] text-[12px] leading-[1.85] text-muted">
                A coding workspace that goes where you go.
                <br className="hidden sm:block" /> Bring your model. Make
                something yours.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.13, duration: 0.4 }}
              className="grid w-full max-w-[460px] grid-cols-3 gap-2.5 sm:gap-3"
            >
              {[
                {
                  kind: "web",
                  title: "Website",
                  description: "Give an idea a home",
                  prompt:
                    "Build a beautiful, responsive landing page for a creative studio. Use React and plain CSS, with thoughtful mobile interactions. Write the complete code into this workspace.",
                },
                {
                  kind: "dashboard",
                  title: "Dashboard",
                  description: "Make data feel simple",
                  prompt:
                    "Build a clean project dashboard with working search, task creation, and status filters. Use React state and plain CSS. Write the complete code into this workspace.",
                },
                {
                  kind: "mobile",
                  title: "Mobile app",
                  description: "Made for your pocket",
                  prompt:
                    "Build a mobile-first habit tracker with working habit creation, daily check-offs, and a weekly view. Use React and plain CSS. Write the complete code into this workspace.",
                },
              ].map((item) => (
                <button
                  key={item.kind}
                  onClick={() => fillPrompt(item.prompt)}
                  className="starter-button group text-center"
                >
                  <div className="mb-4 flex h-12 items-center justify-center">
                    <ClayIcon
                      kind={item.kind as "web" | "dashboard" | "mobile"}
                    />
                  </div>
                  <div className="text-[11px] font-semibold">{item.title}</div>
                  <div className="mt-1.5 hidden text-[9px] text-muted min-[420px]:block">
                    {item.description}
                  </div>
                </button>
              ))}
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.25 }}
              className="mt-6 flex max-w-[420px] items-center gap-2 text-[10px] leading-relaxed text-muted"
            >
              <Icon name="key" className="h-3.5 w-3.5 text-pink" />
              <span>Your model. Your key. Always your code.</span>
              <button
                onClick={() => onSettings("providers")}
                className="ml-1 whitespace-nowrap text-accent hover:underline"
              >
                Connect model{" "}
                <Icon name="arrowUpRight" className="inline h-3 w-3" />
              </button>
            </motion.div>
          </div>
        </div>
      ) : (
        <div
          ref={scroller}
          onScroll={() => {
            const el = scroller.current;
            if (el)
              stickToEnd.current =
                el.scrollHeight - el.scrollTop - el.clientHeight < 120;
          }}
          className="min-h-0 flex-1 overflow-y-auto"
        >
          <div className="mx-auto w-full max-w-[780px] space-y-7 px-4 pb-7 pt-6 sm:px-7">
            {session.messages.map((message, index) => (
              <Bubble
                key={message.id}
                message={message}
                onApproval={(id, ok) => {
                  const run = runRef.current;
                  if (!run || !run.resolve) return;
                  const current = getState()
                    .sessions.find((sess) => sess.id === run.sessionId)
                    ?.messages.find((m) => m.id === run.messageId);
                  if (
                    !current?.toolCalls?.some(
                      (t) => t.id === id && t.status === "pending",
                    )
                  )
                    return;
                  const resolve = run.resolve;
                  run.resolve = undefined;
                  resolve(ok);
                }}
                onOpen={openFile}
                onConfigure={() => onSettings("providers")}
                onSuggest={fillPrompt}
                onRetry={() => {
                  const previous = session.messages
                    .slice(0, index)
                    .reverse()
                    .find((m) => m.role === "user");
                  if (previous)
                    void send(
                      previous.content,
                      previous.attachments,
                      message.id,
                    );
                }}
              />
            ))}
            {busy && (
              <div
                role="status"
                className="flex items-center gap-2 pl-10 text-[10px] text-muted"
              >
                <TypingDots />
                <span>{progress || "Working on your idea..."}</span>
              </div>
            )}
          </div>
        </div>
      )}
      <div className="mx-auto w-full max-w-[780px] shrink-0 px-3 pb-3 pt-2 sm:px-5 sm:pb-4">
        {composer}
      </div>
      <ModelSheet
        open={modelOpen}
        onClose={() => setModelOpen(false)}
        onOpenSettings={() => {
          setModelOpen(false);
          onSettings("providers");
        }}
      />
    </div>
  );
}
