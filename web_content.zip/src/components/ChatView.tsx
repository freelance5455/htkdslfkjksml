import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatRoom, ChatMessage } from '../types';
import { db } from '../firebase';
import {
  collection,
  doc,
  addDoc,
  setDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  getDocs,
  getDoc
} from 'firebase/firestore';
import { formatTime, formatLastSeen, fileToBase64, formatFileSize, isUserActuallyOnline } from '../utils/helpers';
import { playAppSound, VoiceRecorder } from '../utils/audio';
import { VipName } from './VipName';
import { GiftModal, ROYAL_GIFTS } from './GiftModal';
import { RoyalGift } from '../types';
import confetti from 'canvas-confetti';
import {
  ArrowRight,
  MoreVertical,
  Paperclip,
  Image as ImageIcon,
  Mic,
  Send,
  X,
  Trash2,
  Ban,
  Clock,
  Download,
  Users,
  Palette,
  Search,
  Copy,
  Smile,
  Heart,
  Volume2,
  Gift,
  Sparkles,
  Shield
} from 'lucide-react';

interface ChatViewProps {
  chat: ChatRoom;
  currentUser: UserProfile;
  peerUser?: UserProfile | null;
  allUsersMap?: Record<string, UserProfile>;
  wallpaper: string;
  overlayOpacity: number;
  onBack: () => void;
  onOpenGroupMembers: () => void;
  onOpenWallpaperModal: () => void;
  onUpdateCurrentUserPoints?: (newPoints: number) => void;
  onToast: (msg: string) => void;
}

const EMOJI_REACTIONS = ['❤️', '😂', '😮', '🔥', '👑', '👍'];

export const ChatView: React.FC<ChatViewProps> = ({
  chat,
  currentUser,
  peerUser,
  allUsersMap,
  wallpaper,
  overlayOpacity,
  onBack,
  onOpenGroupMembers,
  onOpenWallpaperModal,
  onUpdateCurrentUserPoints,
  onToast
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [inputText, setInputText] = useState('');
  const [replyTarget, setReplyTarget] = useState<ChatMessage | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [disappearingMode, setDisappearingMode] = useState(chat.disappearing || false);
  const [isBlocked, setIsBlocked] = useState(
    peerUser ? currentUser.blockedUsers?.includes(peerUser.id) || false : false
  );

  // In-chat search
  const [showSearchInChat, setShowSearchInChat] = useState(false);
  const [chatSearchQuery, setChatSearchQuery] = useState('');

  // Image zoom modal
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Gift modal
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [showQuickGiftTray, setShowQuickGiftTray] = useState(true);

  // Reaction picker for specific message
  const [activeReactionMsgId, setActiveReactionMsgId] = useState<string | null>(null);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const voiceRecorderRef = useRef<VoiceRecorder | null>(null);
  const recordingTimerRef = useRef<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom helper
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  // Subscribe to messages in Firestore
  useEffect(() => {
    setLoading(true);
    const msgsRef = collection(db, 'chats', chat.id, 'messages');
    const q = query(msgsRef, orderBy('timestamp', 'asc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: ChatMessage[] = [];
        const now = Date.now();
        snapshot.forEach((d) => {
          const data = d.data() as ChatMessage;
          if (data.expiresAt && data.expiresAt < now) {
            deleteDoc(doc(db, 'chats', chat.id, 'messages', d.id)).catch(() => {});
            return;
          }
          list.push({ ...data, id: d.id });
        });
        setMessages(list);
        setLoading(false);
        setTimeout(() => scrollToBottom('auto'), 80);
      },
      (err) => {
        console.error('Messages snapshot err:', err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [chat.id]);

  // First-contact 3-message limit protection for direct chats
  const isDirectChat = !chat.isGroup && !!peerUser;
  const peerHasReplied = isDirectChat
    ? messages.some((m) => m.senderId === peerUser?.id)
    : true;
  const mySentMessagesCount = isDirectChat
    ? messages.filter((m) => m.senderId === currentUser.id).length
    : 0;
  const isPendingPeerReply = isDirectChat && !peerHasReplied && mySentMessagesCount >= 3;

  // Handle Send text message
  const handleSendMessage = async () => {
    const text = inputText.trim();
    if (!text) return;

    if (isBlocked) {
      onToast('لا يمكنك إرسال رسائل لأن المستخدم محظور');
      return;
    }

    if (isPendingPeerReply) {
      playAppSound('alert');
      onToast('لا يمكنك إرسال أكثر من 3 رسائل حتى يقوم الطرف الآخر بالرد عليك 🛡️');
      return;
    }

    setInputText('');
    playAppSound('send');

    const expiresAt = disappearingMode ? Date.now() + 24 * 3600 * 1000 : null;

    const newMsg: Partial<ChatMessage> = {
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
      text: text,
      type: 'text',
      timestamp: serverTimestamp(),
      ...(replyTarget
        ? {
            replyToText: replyTarget.text || (replyTarget.type === 'image' ? '📷 صورة' : '📎 مرفق'),
            replyToSender:
              replyTarget.senderId === currentUser.id ? 'أنت' : replyTarget.senderName
          }
        : {}),
      ...(expiresAt ? { expiresAt } : {})
    };

    setReplyTarget(null);

    try {
      const chatDocRef = doc(db, 'chats', chat.id);
      await addDoc(collection(chatDocRef, 'messages'), newMsg);

      const updateData: any = {
        lastMessage: text,
        lastMessageTime: serverTimestamp(),
        lastSenderName: currentUser.name,
        isGroup: chat.isGroup
      };

      if (!chat.isGroup) {
        updateData.members = chat.members;
        updateData.idA = currentUser.id;
        updateData.idB = peerUser?.id || '';
      }

      await setDoc(chatDocRef, updateData, { merge: true });
    } catch (err) {
      console.error('Send error:', err);
      onToast('تنبيه: أنت غير متصل، ستصل الرسالة عند استقرار الاتصال');
    }
  };

  // Add Reaction to Message
  const handleToggleReaction = async (msgId: string, emoji: string) => {
    playAppSound('click');
    setActiveReactionMsgId(null);
    try {
      const msgRef = doc(db, 'chats', chat.id, 'messages', msgId);
      const currentReactions = messages.find((m) => m.id === msgId)?.reactions || {};
      const updated = { ...currentReactions };
      if (updated[currentUser.id] === emoji) {
        delete updated[currentUser.id];
      } else {
        updated[currentUser.id] = emoji;
      }
      await setDoc(msgRef, { reactions: updated }, { merge: true });
    } catch (err) {
      console.error(err);
    }
  };

  // Send Royal Digital Gift (وردة بـ 1 نجمة، أسد بـ 10، قلب حب بـ 15...)
  const handleSendGift = async (gift: RoyalGift, targetRecipient: UserProfile) => {
    const currentPoints = currentUser.points || 0;
    if (currentPoints < gift.cost) {
      playAppSound('alert');
      onToast(`رصيدك من النجوم (${currentPoints} ⭐) غير كافٍ لشراء ${gift.name} (${gift.cost} ⭐)`);
      return;
    }

    const newSenderPoints = currentPoints - gift.cost;

    // Fetch recipient's fresh points to ensure accurate balance
    let recipientCurrentPoints = 0;
    try {
      const recDoc = await getDoc(doc(db, 'users', targetRecipient.id));
      if (recDoc.exists()) {
        recipientCurrentPoints = recDoc.data()?.points || 0;
      } else {
        recipientCurrentPoints = allUsersMap?.[targetRecipient.id]?.points ?? targetRecipient.points ?? 0;
      }
    } catch {
      recipientCurrentPoints = allUsersMap?.[targetRecipient.id]?.points ?? targetRecipient.points ?? 0;
    }
    const newRecipientPoints = recipientCurrentPoints + gift.cost;

    try {
      // 1. Deduct points from sender in Firestore
      await setDoc(doc(db, 'users', currentUser.id), { points: newSenderPoints }, { merge: true });
      currentUser.points = newSenderPoints;
      if (onUpdateCurrentUserPoints) {
        onUpdateCurrentUserPoints(newSenderPoints);
      }

      // 2. Add points to recipient in Firestore
      await setDoc(doc(db, 'users', targetRecipient.id), { points: newRecipientPoints }, { merge: true });

      // 3. Post interactive gift message into chat
      const chatDocRef = doc(db, 'chats', chat.id);
      const giftAnnouncement = `🎁 أهداك ${gift.name} ${gift.icon} بقيمة ${gift.cost} نجمة!`;

      await addDoc(collection(chatDocRef, 'messages'), {
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
        type: 'gift',
        text: giftAnnouncement,
        gift: {
          ...gift,
          recipientId: targetRecipient.id,
          recipientName: targetRecipient.name
        },
        timestamp: serverTimestamp(),
      });

      await setDoc(
        chatDocRef,
        {
          lastMessage: `🎁 هدية: ${gift.name} (${gift.cost} ⭐)`,
          lastMessageTime: serverTimestamp(),
          lastSenderName: currentUser.name
        },
        { merge: true }
      );

      // Trigger celebratory sound & confetti
      playAppSound('vip');
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
      } catch {}
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Quick 1-tap send for featured gifts (وردة بـ 1 نجمة، أسد بـ 10، قلب حب بـ 15)
  const handleQuickSend = async (giftId: 'rose' | 'lion' | 'cyber_heart') => {
    if (isPendingPeerReply) {
      playAppSound('alert');
      onToast('لا يمكنك إرسال أكثر من 3 رسائل حتى يقوم الطرف الآخر بالرد عليك 🛡️');
      return;
    }

    const gift = ROYAL_GIFTS.find((g) => g.id === giftId);
    if (!gift) return;

    if (chat.isGroup) {
      // In group chats, open the gift modal to select recipient
      setShowGiftModal(true);
      return;
    }

    if (!peerUser) {
      onToast('لم يتم العثور على المستلم');
      return;
    }

    if (peerUser.id === currentUser.id) {
      onToast('لا يمكنك إرسال هدية لنفسك! كافئ أصدقاءك بالهدايا');
      return;
    }

    const currentPoints = currentUser.points || 0;
    if (currentPoints < gift.cost) {
      playAppSound('alert');
      onToast(`رصيدك غير كافٍ! الهدية تتطلب ${gift.cost} نجمة ورصيدك الحالي ${currentPoints} ⭐`);
      return;
    }

    try {
      await handleSendGift(gift, peerUser);
      onToast(`🎁 تم إرسال ${gift.name} ${gift.icon} بنجاح إلى ${peerUser.name}!`);
    } catch {
      onToast('حدث خطأ أثناء إرسال الهدية');
    }
  };

  // Send image
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isPendingPeerReply) {
      playAppSound('alert');
      onToast('لا يمكنك إرسال أكثر من 3 رسائل حتى يقوم الطرف الآخر بالرد عليك 🛡️');
      return;
    }

    const file = e.target.files?.[0];
    if (!file) return;

    onToast('جارِ إرسال الصورة...');
    try {
      const base64 = await fileToBase64(file);
      playAppSound('send');

      const chatDocRef = doc(db, 'chats', chat.id);
      await addDoc(collection(chatDocRef, 'messages'), {
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
        type: 'image',
        fileUrl: base64,
        fileName: file.name,
        timestamp: serverTimestamp(),
        ...(disappearingMode ? { expiresAt: Date.now() + 24 * 3600 * 1000 } : {})
      });

      await setDoc(
        chatDocRef,
        {
          lastMessage: '📷 صورة مرفقة',
          lastMessageTime: serverTimestamp(),
          lastSenderName: currentUser.name
        },
        { merge: true }
      );
    } catch (err) {
      console.error(err);
      onToast('تعذر إرسال الصورة');
    } finally {
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  // Send document/file
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isPendingPeerReply) {
      playAppSound('alert');
      onToast('لا يمكنك إرسال أكثر من 3 رسائل حتى يقوم الطرف الآخر بالرد عليك 🛡️');
      return;
    }

    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      onToast('الحد الأقصى لحجم الملف هو 15 ميجابايت');
      return;
    }

    onToast('جارِ رفع الملف...');
    try {
      const base64 = await fileToBase64(file);
      playAppSound('send');

      const chatDocRef = doc(db, 'chats', chat.id);
      await addDoc(collection(chatDocRef, 'messages'), {
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
        type: 'file',
        fileUrl: base64,
        fileName: file.name,
        fileSize: formatFileSize(file.size),
        timestamp: serverTimestamp(),
        ...(disappearingMode ? { expiresAt: Date.now() + 24 * 3600 * 1000 } : {})
      });

      await setDoc(
        chatDocRef,
        {
          lastMessage: `📎 ملف: ${file.name}`,
          lastMessageTime: serverTimestamp(),
          lastSenderName: currentUser.name
        },
        { merge: true }
      );
    } catch (err) {
      console.error(err);
      onToast('تعذر إرسال الملف');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Voice recording toggle
  const startRecording = async () => {
    if (isPendingPeerReply) {
      playAppSound('alert');
      onToast('لا يمكنك إرسال أكثر من 3 رسائل حتى يقوم الطرف الآخر بالرد عليك 🛡️');
      return;
    }
    if (!voiceRecorderRef.current) {
      voiceRecorderRef.current = new VoiceRecorder();
    }
    const started = await voiceRecorderRef.current.start();
    if (started) {
      setIsRecording(true);
      setRecordingSeconds(0);
      playAppSound('click');
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      onToast('يرجى السماح بالوصول للميكروفون لتسجيل الصوت');
    }
  };

  const stopAndSendRecording = async () => {
    if (!isRecording || !voiceRecorderRef.current) return;
    clearInterval(recordingTimerRef.current);
    setIsRecording(false);

    const audioData = await voiceRecorderRef.current.stop();
    if (audioData) {
      playAppSound('send');
      try {
        const chatDocRef = doc(db, 'chats', chat.id);
        await addDoc(collection(chatDocRef, 'messages'), {
          senderId: currentUser.id,
          senderName: currentUser.name,
          senderVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
          type: 'audio',
          fileUrl: audioData,
          fileName: `تسجيل_صوتي_${Date.now()}.webm`,
          timestamp: serverTimestamp(),
          ...(disappearingMode ? { expiresAt: Date.now() + 24 * 3600 * 1000 } : {})
        });

        await setDoc(
          chatDocRef,
          {
            lastMessage: '🎙️ تسجيل صوتي',
            lastMessageTime: serverTimestamp(),
            lastSenderName: currentUser.name
          },
          { merge: true }
        );
      } catch (err) {
        console.error(err);
        onToast('حدث خطأ في إرسال التسجيل');
      }
    }
  };

  const cancelRecording = () => {
    if (voiceRecorderRef.current) {
      voiceRecorderRef.current.cancel();
    }
    clearInterval(recordingTimerRef.current);
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  // Delete message
  const handleDeleteMessage = async (msgId: string) => {
    try {
      await deleteDoc(doc(db, 'chats', chat.id, 'messages', msgId));
      playAppSound('click');
      onToast('تم حذف الرسالة بنجاح');
    } catch {
      onToast('تعذر حذف الرسالة');
    }
  };

  // Copy message text
  const handleCopyText = (text?: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    playAppSound('click');
    onToast('تم نسخ نص الرسالة 📋');
  };

  // Clear chat history
  const handleClearHistory = async () => {
    if (!window.confirm('هل أنت متأكد من مسح جميع رسائل هذه المحادثة؟')) return;
    setShowDropdown(false);
    try {
      const snap = await getDocs(collection(db, 'chats', chat.id, 'messages'));
      const deletions = snap.docs.map((d) => deleteDoc(d.ref));
      await Promise.all(deletions);
      onToast('تم مسح سجل المحادثة بنجاح 🗑️');
    } catch {
      onToast('حدث خطأ أثناء مسح الرسائل');
    }
  };

  // Toggle Disappearing messages
  const handleToggleDisappearing = async () => {
    const nextState = !disappearingMode;
    setDisappearingMode(nextState);
    setShowDropdown(false);
    try {
      await setDoc(doc(db, 'chats', chat.id), { disappearing: nextState }, { merge: true });
      onToast(
        nextState
          ? 'تم تفعيل الرسائل ذاتية الاختفاء (تُحذف تلقائياً بعد 24 ساعة) ⏳'
          : 'تم إيقاف ميزة الاختفاء التلقائي'
      );
    } catch {
      // ignore
    }
  };

  // Toggle Block user
  const handleToggleBlock = async () => {
    if (!peerUser) return;
    setShowDropdown(false);
    const nextBlocked = !isBlocked;
    setIsBlocked(nextBlocked);

    let list = currentUser.blockedUsers || [];
    if (nextBlocked) {
      list = [...list, peerUser.id];
      onToast(`تم حظر ${peerUser.name} 🚫`);
    } else {
      list = list.filter((id) => id !== peerUser.id);
      onToast(`تم إلغاء حظر ${peerUser.name}`);
    }
    currentUser.blockedUsers = list;
    try {
      await setDoc(doc(db, 'users', currentUser.id), { blockedUsers: list }, { merge: true });
    } catch {
      // ignore
    }
  };

  const displayName = chat.isGroup
    ? chat.groupName || 'مجموعة ملكية'
    : peerUser?.name || chat.nameA || 'محادثة';

  // Filter messages if search is active
  const filteredMessages = chatSearchQuery.trim()
    ? messages.filter((m) =>
        m.text?.toLowerCase().includes(chatSearchQuery.toLowerCase().trim())
      )
    : messages;

  return (
    /* CRITICAL FIX: Fixed inset-0 z-[100] with dedicated wallpaper background so underlying chat list NEVER shows */
    <div className="fixed inset-0 z-[100] w-full h-full flex flex-col bg-[#0b141a] text-[#e9edef] overflow-hidden">
      {/* Background layer */}
      <div
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center transition-all duration-500"
        style={{ backgroundImage: `url('${wallpaper}')` }}
      />
      <div
        className="fixed inset-0 pointer-events-none z-0 transition-all duration-300"
        style={{ backgroundColor: `rgba(11, 20, 26, ${overlayOpacity})` }}
      />

      {/* Top Header Bar */}
      <header className="relative z-20 glass-panel-heavy border-b border-white/10 px-3 py-2.5 flex items-center justify-between gap-2 shadow-xl shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer flex items-center gap-1 text-xs font-bold shrink-0"
            title="رجوع للقائمة"
          >
            <ArrowRight className="w-4 h-4" />
            <span>رجوع</span>
          </button>

          {/* Avatar */}
          <div
            onClick={() => {
              if (chat.isGroup) onOpenGroupMembers();
            }}
            className="w-10 h-10 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-sm shrink-0 overflow-hidden relative border border-white/15 cursor-pointer shadow-md"
          >
            {chat.isGroup ? (
              <span className="text-base">👥</span>
            ) : peerUser?.avatar ? (
              <img src={peerUser.avatar} alt="" className="w-full h-full object-cover" />
            ) : (
              (displayName[0] || 'A').toUpperCase()
            )}
            {!chat.isGroup && isUserActuallyOnline(peerUser) && (
              <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] border-2 border-[#111b21] absolute bottom-0 right-0 shadow" />
            )}
          </div>

          {/* Name & status */}
          <div
            className="min-w-0 cursor-pointer"
            onClick={() => {
              if (chat.isGroup) onOpenGroupMembers();
            }}
          >
            <VipName
              name={displayName}
              vipLevel={chat.isGroup ? 0 : peerUser?.vipLevel}
              isFounder={peerUser?.id === 'ASEF-777777'}
              className="text-sm font-black text-white"
            />
            <div className="text-[11px] text-gray-300 truncate">
              {chat.isGroup
                ? `${chat.members?.length || 1} أعضاء في المجموعة الملكية`
                : formatLastSeen(peerUser?.lastSeen, isUserActuallyOnline(peerUser))}
            </div>
          </div>
        </div>

        {/* Actions & Menu */}
        <div className="flex items-center gap-1 shrink-0 relative">
          {/* Search Toggle */}
          <button
            onClick={() => {
              setShowSearchInChat(!showSearchInChat);
              if (showSearchInChat) setChatSearchQuery('');
            }}
            title="بحث في المحادثة"
            className={`p-2 rounded-xl transition ${
              showSearchInChat ? 'bg-[#25d366] text-black font-bold' : 'text-gray-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Quick Gift Open Button in Header */}
          <button
            onClick={() => setShowGiftModal(true)}
            title="إرسال هدية رقمية (وردة، أسد، قلب حب...)"
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#ffd700]/20 to-[#ffa500]/20 hover:from-[#ffd700]/30 hover:to-[#ffa500]/30 border border-[#ffd700]/40 text-[#ffd700] text-xs font-black flex items-center gap-1 transition shadow-sm cursor-pointer"
          >
            <Gift className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">إهداء 🎁</span>
          </button>

          {/* Group members */}
          {chat.isGroup && (
            <button
              onClick={onOpenGroupMembers}
              title="إدارة أعضاء المجموعة"
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-[#25d366] text-xs font-semibold flex items-center gap-1 transition"
            >
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">الأعضاء</span>
            </button>
          )}

          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 transition"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {/* Dropdown menu */}
          {showDropdown && (
            <div className="absolute left-0 top-11 w-56 glass-panel-heavy rounded-2xl border border-white/10 shadow-2xl py-1.5 z-50 text-right animate-in fade-in zoom-in-95">
              <button
                onClick={() => {
                  setShowDropdown(false);
                  onOpenWallpaperModal();
                }}
                className="w-full px-3.5 py-2.5 text-xs text-white hover:bg-white/10 flex items-center justify-between transition"
              >
                <span>تخصيص خلفية التطبيق 🎨</span>
                <Palette className="w-3.5 h-3.5 text-[#25d366]" />
              </button>

              <button
                onClick={handleToggleDisappearing}
                className="w-full px-3.5 py-2.5 text-xs text-white hover:bg-white/10 flex items-center justify-between transition"
              >
                <span>
                  {disappearingMode ? 'إلغاء رسائل الاختفاء' : 'رسائل ذاتية الاختفاء ⏳'}
                </span>
                <Clock className="w-3.5 h-3.5 text-amber-400" />
              </button>

              {!chat.isGroup && (
                <button
                  onClick={handleToggleBlock}
                  className="w-full px-3.5 py-2.5 text-xs text-white hover:bg-white/10 flex items-center justify-between transition"
                >
                  <span className={isBlocked ? 'text-[#25d366]' : 'text-red-400'}>
                    {isBlocked ? 'إلغاء حظر المستخدم' : 'حظر هذا المستخدم 🚫'}
                  </span>
                  <Ban className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                onClick={handleClearHistory}
                className="w-full px-3.5 py-2.5 text-xs text-red-400 hover:bg-red-500/10 flex items-center justify-between transition border-t border-white/10"
              >
                <span>مسح سجل الرسائل 🗑️</span>
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Search in chat input bar */}
      {showSearchInChat && (
        <div className="relative z-20 glass-panel border-b border-white/10 px-3 py-2 flex items-center gap-2">
          <input
            type="text"
            placeholder="ابحث عن نص رسالة داخل المحادثة..."
            value={chatSearchQuery}
            onChange={(e) => setChatSearchQuery(e.target.value)}
            className="flex-1 glass-input rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-[#25d366]"
          />
          {chatSearchQuery && (
            <button
              onClick={() => setChatSearchQuery('')}
              className="text-xs text-gray-400 hover:text-white"
            >
              مسح
            </button>
          )}
          <button
            onClick={() => {
              setShowSearchInChat(false);
              setChatSearchQuery('');
            }}
            className="p-1 rounded-lg text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Disappearing Messages Active Banner */}
      {disappearingMode && (
        <div className="relative z-10 bg-amber-500/15 border-b border-amber-500/20 px-3 py-1.5 text-[11px] text-amber-300 text-center flex items-center justify-center gap-1.5">
          <Clock className="w-3.5 h-3.5" />
          <span>ميزة الرسائل ذاتية الاختفاء مفعّلة (تُحذف الرسائل تلقائياً بعد 24 ساعة)</span>
        </div>
      )}

      {/* Reply Preview Bar */}
      {replyTarget && (
        <div className="relative z-20 glass-panel px-3 py-1.5 flex items-center justify-between border-b border-white/10 text-xs shadow-inner">
          <div className="min-w-0 pr-2 border-r-3 border-[#25d366]">
            <span className="text-[#25d366] font-bold block">
              الرد على {replyTarget.senderId === currentUser.id ? 'أنت' : replyTarget.senderName}:
            </span>
            <span className="text-gray-300 truncate block text-[11px]">
              {replyTarget.text || 'مرفق'}
            </span>
          </div>
          <button
            onClick={() => setReplyTarget(null)}
            className="p-1 text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* SNAPCHAT STYLE MESSAGES STREAM (NO BUBBLE BOXES, CLEAN SEPARATOR & VIP COLORED NAMES) */}
      <div className="relative z-10 flex-1 overflow-y-auto p-3 sm:p-5 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center h-full text-xs text-gray-400">
            جارِ تحميل المحادثة...
          </div>
        ) : filteredMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 text-gray-400">
            <div className="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center text-2xl mb-2">
              💬
            </div>
            <p className="text-sm font-bold text-white mb-1">
              {chatSearchQuery ? 'لا توجد نتائج مطابقة للبحث' : 'لا توجد رسائل بعد'}
            </p>
            <p className="text-xs">
              {chatSearchQuery
                ? 'جرب البحث بكلمة أخرى'
                : 'ابدأ المحادثة على طريقة السناب الفاخرة!'}
            </p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;

            // Resolve sender details accurately from live user profile or message metadata
            const senderUser = isMe
              ? currentUser
              : (allUsersMap?.[msg.senderId] || (msg.senderId === peerUser?.id ? peerUser : null));

            const senderVipLevel = isMe
              ? Number(currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0))
              : Number(senderUser?.vipLevel ?? msg.senderVip ?? 0);

            const isSenderFounder =
              (isMe && currentUser.id === 'ASEF-777777') ||
              msg.senderId === 'ASEF-777777' ||
              senderUser?.id === 'ASEF-777777';

            // Current user identifies as 'أنت' (You) while other users display their actual name
            const senderDisplayName = isMe
              ? 'أنت'
              : (senderUser?.name || msg.senderName || 'عضو');

            return (
              <div
                key={msg.id}
                className="relative group border-b border-white/5 pb-2.5 transition hover:bg-white/[0.02] rounded-lg px-2 -mx-2"
              >
                {/* Header: Sender Label (أنت vs اسم الشخص) + Timestamp */}
                <div className="flex items-center justify-between gap-2 mb-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Snapchat Sender Name Line: VIP coloring/rainbow applied consistently */}
                    <VipName
                      name={senderDisplayName}
                      vipLevel={senderVipLevel}
                      isFounder={isSenderFounder}
                      className="text-xs font-black"
                    />

                    {/* Snapchat subtle accent indicator */}
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isMe ? 'bg-[#25d366]' : 'bg-[#00a884]'
                      }`}
                    />
                  </div>

                  <div className="flex items-center gap-2 text-[10px] text-gray-400 shrink-0">
                    {msg.expiresAt && <span title="مؤقت">⏳</span>}
                    <span>{formatTime(msg.timestamp)}</span>
                  </div>
                </div>

                {/* Reply Quote preview if replied */}
                {msg.replyToText && (
                  <div className="bg-white/5 border-r-3 border-[#25d366] rounded-md px-2.5 py-1 mb-1.5 text-[11px] text-gray-300">
                    <span className="text-[#25d366] font-bold block">{msg.replyToSender}</span>
                    <span className="truncate block">{msg.replyToText}</span>
                  </div>
                )}

                {/* Message Body Content (Direct text / image / audio / file without rounded bubble wrapper) */}
                <div className="pr-1 text-sm text-[#e9edef] leading-relaxed break-words selectable-text">
                  {/* Image Type */}
                  {msg.type === 'image' && msg.fileUrl && (
                    <div className="my-1.5 max-w-sm rounded-xl overflow-hidden border border-white/10 shadow-lg">
                      <img
                        src={msg.fileUrl}
                        alt="صورة"
                        className="w-full max-h-80 object-cover cursor-pointer hover:opacity-95 transition"
                        onClick={() => setPreviewImage(msg.fileUrl || null)}
                      />
                    </div>
                  )}

                  {/* Audio Type */}
                  {msg.type === 'audio' && msg.fileUrl && (
                    <div className="my-1.5 p-2 rounded-xl bg-white/5 border border-white/10 max-w-sm flex items-center gap-2">
                      <Volume2 className="w-5 h-5 text-[#25d366] shrink-0" />
                      <audio controls src={msg.fileUrl} className="w-full h-8 rounded" />
                    </div>
                  )}

                  {/* File Type */}
                  {msg.type === 'file' && msg.fileUrl && (
                    <a
                      href={msg.fileUrl}
                      download={msg.fileName || 'ملف'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="my-1.5 inline-flex items-center gap-2.5 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-[#25d366] font-bold transition shadow-sm"
                    >
                      <Download className="w-4 h-4 shrink-0" />
                      <div className="min-w-0">
                        <div className="truncate text-white">{msg.fileName || 'ملف مرفق'}</div>
                        <div className="text-[10px] text-gray-400 font-normal">
                          {msg.fileSize || 'اضغط للتحميل'}
                        </div>
                      </div>
                    </a>
                  )}

                  {/* Interactive Digital Royal Gift Card */}
                  {msg.type === 'gift' && msg.gift && (
                    <div className="my-2.5 p-4 rounded-3xl bg-gradient-to-br from-[#ffd700]/25 via-black/85 to-[#ffd700]/15 border-2 border-[#ffd700]/50 max-w-md shadow-2xl relative overflow-hidden backdrop-blur-xl animate-in zoom-in-95">
                      {/* Top decorative sparkles & banner */}
                      <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-[#ffd700]/20 text-[11px]">
                        <div className="flex items-center gap-1.5 font-black text-[#ffd700]">
                          <Sparkles className="w-4 h-4 text-[#ffd700]" />
                          <span>هدية رقمية ملكية معتمدة 👑</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-[#ffd700]/20 border border-[#ffd700]/40 text-[#ffd700] font-black text-[10px]">
                          ⭐ {msg.gift.cost} نجمة
                        </span>
                      </div>

                      {/* Main gift animation & details */}
                      <div className="flex items-start gap-3.5 mb-3">
                        <div
                          onClick={() => {
                            try {
                              confetti({ particleCount: 80, spread: 60 });
                            } catch {}
                            playAppSound('click');
                          }}
                          className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#ffd700]/30 to-[#ffa500]/20 border border-[#ffd700]/40 flex items-center justify-center text-4xl shrink-0 shadow-lg cursor-pointer transform hover:scale-110 active:scale-95 transition"
                          title="اضغط للاحتفال 🎉"
                        >
                          <span className="drop-shadow-lg animate-pulse">{msg.gift.icon}</span>
                        </div>

                        <div className="min-w-0 flex-1">
                          <h4 className="text-sm font-black text-white flex items-center gap-1.5 flex-wrap">
                            <span className="text-[#ffd700]">{msg.gift.name}</span>
                          </h4>
                          <div className="text-[11px] text-gray-300 mt-1 leading-relaxed">
                            {msg.gift.description || 'هدية فاخرة وراقية'}
                          </div>

                          {/* Transfer breakdown */}
                          <div className="mt-2 text-[10px] bg-black/60 p-2.5 rounded-xl border border-white/5 space-y-1">
                            <div className="flex items-center justify-between text-gray-300">
                              <span>الراسل الكريم:</span>
                              <b className="text-white">{isMe ? 'أنت' : msg.senderName}</b>
                            </div>
                            <div className="flex items-center justify-between text-gray-300">
                              <span>المستلم المحظوظ:</span>
                              <b className="text-[#25d366]">{msg.gift.recipientName || 'المستلم'}</b>
                            </div>
                            <div className="pt-1 border-t border-white/10 flex items-center justify-between text-[#2ecc71] font-bold">
                              <span>حالة الرصيد:</span>
                              <span>✅ تم الخصم والإيداع الفوري ({msg.gift.cost} ⭐)</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Interactive Action Buttons Bar */}
                      <div className="flex items-center gap-2 pt-2 border-t border-[#ffd700]/20">
                        {/* Thank you button */}
                        <button
                          onClick={() => {
                            handleToggleReaction(msg.id, '❤️');
                            try {
                              confetti({ particleCount: 70, spread: 50 });
                            } catch {}
                            playAppSound('vip');
                            onToast('تم إرسال شكر ومحبة ❤️');
                          }}
                          className="flex-1 py-1.5 rounded-xl bg-white/10 hover:bg-[#25d366]/20 border border-white/10 hover:border-[#25d366]/40 text-xs font-bold text-white transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Heart className="w-3.5 h-3.5 text-red-400" />
                          <span>شكراً لك! 🌸</span>
                        </button>

                        {/* Gift back button */}
                        <button
                          onClick={() => {
                            playAppSound('click');
                            setShowGiftModal(true);
                          }}
                          className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-[#ffd700]/20 to-[#ffa500]/20 hover:from-[#ffd700]/30 hover:to-[#ffa500]/30 border border-[#ffd700]/40 text-xs font-bold text-[#ffd700] transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Gift className="w-3.5 h-3.5" />
                          <span>رد بهدية 🎁</span>
                        </button>

                        {/* Celebrate confetti button */}
                        <button
                          onClick={() => {
                            try {
                              confetti({ particleCount: 120, spread: 90 });
                            } catch {}
                            playAppSound('vip');
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/15 text-xs text-amber-300 font-bold transition flex items-center justify-center cursor-pointer"
                          title="احتفال بالهدية"
                        >
                          🎉
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Text Message Content */}
                  {msg.text && msg.type !== 'gift' && (
                    <p className="whitespace-pre-wrap font-normal text-white/95">{msg.text}</p>
                  )}
                </div>

                {/* Emoji Reactions Pill Bar */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                    {Object.entries(msg.reactions).map(([uId, emoji]) => (
                      <span
                        key={uId}
                        onClick={() => handleToggleReaction(msg.id, emoji)}
                        className={`text-xs px-2 py-0.5 rounded-full border cursor-pointer transition ${
                          uId === currentUser.id
                            ? 'bg-[#25d366]/20 border-[#25d366] text-white shadow-sm'
                            : 'bg-white/10 border-white/10 text-gray-300'
                        }`}
                      >
                        {emoji}
                      </span>
                    ))}
                  </div>
                )}

                {/* Snapchat Quick Floating Actions toolbar */}
                <div className="hidden group-hover:flex items-center gap-1.5 absolute left-2 bottom-1 bg-[#111b21] border border-white/10 rounded-full px-2 py-1 shadow-lg z-20">
                  {/* Reaction trigger */}
                  <button
                    onClick={() =>
                      setActiveReactionMsgId(activeReactionMsgId === msg.id ? null : msg.id)
                    }
                    title="تفاعل"
                    className="p-1 text-gray-300 hover:text-amber-400 transition"
                  >
                    <Smile className="w-3.5 h-3.5" />
                  </button>

                  {/* Reply */}
                  <button
                    onClick={() => setReplyTarget(msg)}
                    title="رد"
                    className="p-1 text-gray-300 hover:text-white transition text-xs"
                  >
                    ↩
                  </button>

                  {/* Copy */}
                  {msg.text && (
                    <button
                      onClick={() => handleCopyText(msg.text)}
                      title="نسخ"
                      className="p-1 text-gray-300 hover:text-white transition"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Delete (if author) */}
                  {isMe && (
                    <button
                      onClick={() => handleDeleteMessage(msg.id)}
                      title="حذف"
                      className="p-1 text-gray-300 hover:text-red-400 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Floating Emoji Picker Popover */}
                {activeReactionMsgId === msg.id && (
                  <div className="absolute left-2 -top-8 bg-[#1f2c34] border border-white/15 rounded-full px-2.5 py-1 flex items-center gap-1.5 shadow-2xl z-30 animate-in fade-in zoom-in-95">
                    {EMOJI_REACTIONS.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => handleToggleReaction(msg.id, emoji)}
                        className="text-sm hover:scale-125 active:scale-95 transition"
                      >
                        {emoji}
                      </button>
                    ))}
                    <button
                      onClick={() => setActiveReactionMsgId(null)}
                      className="text-gray-400 hover:text-white p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Voice recording live bar */}
      {isRecording && (
        <div className="relative z-20 glass-panel px-4 py-2 flex items-center justify-between border-t border-red-500/30 shrink-0 animate-pulse">
          <div className="flex items-center gap-2 text-red-400 text-xs font-bold">
            <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
            <span>جارِ التسجيل الصوتي ({recordingSeconds} ثانية)...</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={cancelRecording}
              className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-gray-300 text-xs"
            >
              إلغاء
            </button>
            <button
              onClick={stopAndSendRecording}
              className="px-3.5 py-1 rounded-lg bg-[#25d366] text-black font-extrabold text-xs"
            >
              إرسال 🚀
            </button>
          </div>
        </div>
      )}

      {/* Quick Digital Gifts Tray (وردة بـ 1 نجمة، أسد بـ 10، قلب حب بـ 15) */}
      {showQuickGiftTray && (
        <div className="relative z-20 bg-black/80 backdrop-blur-md border-t border-[#ffd700]/30 px-3 py-2 flex items-center justify-between gap-2 overflow-x-auto text-xs animate-in slide-in-from-bottom-2">
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[11px] font-black text-[#ffd700] flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#ffd700]" />
              <span className="hidden xs:inline">الهدايا:</span>
            </span>

            {/* 1. Rose (1 Star) */}
            <button
              onClick={() => handleQuickSend('rose')}
              className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-[#ffd700]/20 border border-white/10 hover:border-[#ffd700]/40 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer active:scale-95"
              title="إرسال وردة ملكية فاخرة بـ 1 نجمة"
            >
              <span className="text-sm">🌹</span>
              <span>وردة</span>
              <span className="text-[#ffd700] font-black text-[10px]">(1 ⭐)</span>
            </button>

            {/* 2. Lion (10 Stars) */}
            <button
              onClick={() => handleQuickSend('lion')}
              className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-[#ffd700]/20 border border-white/10 hover:border-[#ffd700]/40 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer active:scale-95"
              title="إرسال الأسد الذهبي الملكي بـ 10 نجوم"
            >
              <span className="text-sm">🦁</span>
              <span>أسد</span>
              <span className="text-[#ffd700] font-black text-[10px]">(10 ⭐)</span>
            </button>

            {/* 3. Love Heart (15 Stars) */}
            <button
              onClick={() => handleQuickSend('cyber_heart')}
              className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-[#ffd700]/20 border border-white/10 hover:border-[#ffd700]/40 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer active:scale-95"
              title="إرسال قلب حب أسطوري حديث بـ 15 نجمة"
            >
              <span className="text-sm">💖</span>
              <span>قلب حب</span>
              <span className="text-[#ffd700] font-black text-[10px]">(15 ⭐)</span>
            </button>

            {/* All gifts */}
            <button
              onClick={() => setShowGiftModal(true)}
              className="px-2 py-1 rounded-xl bg-gradient-to-r from-[#ffd700]/20 to-[#ffa500]/20 hover:from-[#ffd700]/30 hover:to-[#ffa500]/30 border border-[#ffd700]/40 text-[#ffd700] font-black text-xs transition cursor-pointer"
            >
              المزيد ✨
            </button>
          </div>

          <div className="flex items-center gap-2 text-[10px] text-gray-300 shrink-0 font-bold bg-black/40 px-2.5 py-1 rounded-xl border border-white/5">
            <span>رصيدك:</span>
            <span className="text-[#ffd700] font-black text-xs">⭐ {currentUser.points || 0}</span>
            <button
              onClick={() => setShowQuickGiftTray(false)}
              className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
              title="إخفاء شريط الهدايا السريع"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}

      {/* First Contact 3-Message Limit Protection Alert Banners */}
      {isPendingPeerReply && (
        <div className="relative z-20 bg-amber-500/20 border-t border-amber-500/30 px-3.5 py-2.5 text-xs text-amber-200 flex items-center justify-between gap-2 shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              🛡️ <b>حماية المحادثات الأولى:</b> أرسلت 3 رسائل كحد أقصى. لا يمكنك إرسال المزيد حتى يقوم {peerUser?.name || 'الطرف الآخر'} بالرد عليك حفاظاً على الخصوصية ومكافحة الإزعاج.
            </span>
          </div>
        </div>
      )}

      {!isPendingPeerReply && isDirectChat && !peerHasReplied && mySentMessagesCount > 0 && mySentMessagesCount < 3 && (
        <div className="relative z-20 bg-blue-500/15 border-t border-blue-500/25 px-3 py-1.5 text-[11px] text-blue-200 flex items-center justify-between shadow backdrop-blur-md">
          <div className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-blue-400" />
            <span>محادثة جديدة: متبقي لك {3 - mySentMessagesCount} رسائل قبل رد الطرف الآخر.</span>
          </div>
        </div>
      )}

      {/* Chat Composer */}
      <footer className="relative z-20 glass-panel-heavy border-t border-white/10 p-2 sm:p-3 flex items-center gap-1.5 sm:gap-2 shrink-0">
        <input
          type="file"
          ref={imageInputRef}
          accept="image/*"
          className="hidden"
          onChange={handleImageUpload}
        />
        <input
          type="file"
          ref={fileInputRef}
          accept=".pdf,.doc,.docx,.zip,.rar,.txt,.xls,.xlsx"
          className="hidden"
          onChange={handleFileUpload}
        />

        {/* Image Attachment Button */}
        <button
          onClick={() => imageInputRef.current?.click()}
          disabled={isPendingPeerReply}
          title="إرسال صورة"
          className={`p-2 rounded-full transition ${isPendingPeerReply ? 'opacity-40 cursor-not-allowed' : 'text-gray-300 hover:text-white hover:bg-white/10'}`}
        >
          <ImageIcon className="w-5 h-5 text-[#25d366]" />
        </button>

        {/* File Attachment Button */}
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isPendingPeerReply}
          title="إرسال ملف أو مستند"
          className={`p-2 rounded-full transition ${isPendingPeerReply ? 'opacity-40 cursor-not-allowed' : 'text-gray-300 hover:text-white hover:bg-white/10'}`}
        >
          <Paperclip className="w-5 h-5 text-gray-300" />
        </button>

        {/* Royal Gift Button */}
        <button
          onClick={() => {
            if (isPendingPeerReply) {
              onToast('لا يمكنك إرسال هدايا أو رسائل حتى يرد الطرف الآخر 🛡️');
              return;
            }
            if (!showQuickGiftTray) {
              setShowQuickGiftTray(true);
            } else {
              setShowGiftModal(true);
            }
          }}
          disabled={isPendingPeerReply}
          title="إرسال هدية ملكية 🎁 (وردة، أسد، قلب حب)"
          className={`p-2 rounded-full text-[#ffd700] hover:text-white hover:bg-[#ffd700]/20 transition relative cursor-pointer ${isPendingPeerReply ? 'opacity-40 cursor-not-allowed' : ''}`}
        >
          <Gift className="w-5 h-5" />
          {!isPendingPeerReply && <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#ffd700] animate-ping" />}
        </button>

        {/* Voice Note Button */}
        <button
          onClick={isRecording ? stopAndSendRecording : startRecording}
          disabled={isPendingPeerReply}
          title={isRecording ? 'إيقاف وإرسال الصوت' : 'تسجيل صوتي'}
          className={`p-2 rounded-full transition ${
            isRecording
              ? 'bg-red-500 text-white animate-bounce'
              : isPendingPeerReply
              ? 'opacity-40 cursor-not-allowed text-gray-500'
              : 'text-gray-300 hover:text-white hover:bg-white/10'
          }`}
        >
          <Mic className="w-5 h-5" />
        </button>

        {/* Text Input */}
        <textarea
          rows={1}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          placeholder={
            isBlocked
              ? 'المستخدم محظور...'
              : isPendingPeerReply
              ? 'أرسلت 3 رسائل، انتظر رد الطرف الآخر...'
              : 'اكتب رسالة على طريقة السناب...'
          }
          disabled={isBlocked || isPendingPeerReply}
          className="flex-1 glass-input rounded-2xl px-3.5 py-2 text-sm text-white placeholder-gray-400 outline-none focus:border-[#25d366] resize-none max-h-24 transition disabled:opacity-50"
        />

        {/* Send Button */}
        <button
          onClick={handleSendMessage}
          disabled={!inputText.trim() || isBlocked || isPendingPeerReply}
          className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition shadow-lg ${
            inputText.trim() && !isBlocked && !isPendingPeerReply
              ? 'bg-[#25d366] hover:bg-[#20ba59] text-black active:scale-95 shadow-[#25d366]/30 cursor-pointer'
              : 'bg-white/10 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </footer>

      {/* Royal Gifts Modal */}
      {showGiftModal && (
        <GiftModal
          currentUser={currentUser}
          recipientUser={peerUser}
          groupMembers={chat.isGroup && allUsersMap ? chat.members.map((id) => allUsersMap[id] || { id, name: 'عضو', username: 'user', pass: '', points: 0, vipLevel: 0 }) : []}
          isGroup={chat.isGroup}
          onSendGift={handleSendGift}
          onClose={() => setShowGiftModal(false)}
          onToast={onToast}
        />
      )}

      {/* Fullscreen Image Preview Lightbox */}
      {previewImage && (
        <div
          className="fixed inset-0 z-[99999] bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setPreviewImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-2 left-2 p-2 rounded-full bg-black/60 text-white hover:bg-black/90 transition z-10"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewImage}
              alt="معاينة"
              className="max-w-full max-h-[85vh] object-contain rounded-2xl border border-white/10 shadow-2xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
