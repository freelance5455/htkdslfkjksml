import { features } from "../data/content";
import {
  SparklesIcon,
  LinkIcon,
  ChartIcon,
  ShieldIcon,
  LayersIcon,
  UsersIcon,
} from "./icons";

const iconMap = {
  sparkles: SparklesIcon,
  link: LinkIcon,
  chart: ChartIcon,
  shield: ShieldIcon,
  layers: LayersIcon,
  users: UsersIcon,
};

export function Features() {
  return (
    <section id="features" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-brand-900/15 to-transparent" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
            Features
          </p>
          <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl lg:text-[2.75rem]">
            Everything you need to{" "}
            <span className="text-gradient-brand">operate at warp speed</span>
          </h2>
          <p className="reveal delay-200 mt-4 text-base leading-relaxed text-ink-400 sm:text-lg">
            Cascade combines intelligent automation, deep integrations, and
            enterprise controls into one elegant command center.
          </p>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
          {features.map((feature, i) => {
            const Icon = iconMap[feature.icon];
            const delays = ["delay-100", "delay-200", "delay-300"] as const;
            return (
              <article
                key={feature.title}
                className={`reveal ${delays[i % 3]} group card-lift relative overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-6 sm:p-7`}
              >
                <div
                  className={`pointer-events-none absolute -top-12 -right-12 h-40 w-40 rounded-full bg-gradient-to-br ${feature.accent} opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100`}
                />
                <div className="relative">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 text-brand-300 transition-transform duration-300 group-hover:scale-110 group-hover:border-brand-400/30">
                    <Icon size={20} />
                  </div>
                  <h3 className="mt-5 text-lg font-semibold tracking-tight text-white">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-400">
                    {feature.description}
                  </p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
