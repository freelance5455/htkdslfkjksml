import { useEffect, useRef } from "react";
import { useShield } from "@/lib/store";
import { nextAttack, nextBaseline } from "@/lib/traffic-sim";

export function ProtectionLoop() {
  const protectionOn = useShield((s) => s.protectionOn);
  const pending = useShield((s) => s.pending);
  const ingest = useShield((s) => s.ingest);
  const ticks = useRef(0);

  useEffect(() => {
    if (!protectionOn) return;
    const id = window.setInterval(() => {
      if (useShield.getState().pending) return;
      ticks.current += 1;
      const sample =
        ticks.current % 11 === 0 ? nextAttack() : nextBaseline();
      ingest(sample);
    }, 2200);
    return () => window.clearInterval(id);
  }, [protectionOn, ingest]);

  useEffect(() => {
    if (!pending) return;
    if (!("Notification" in window) || Notification.permission !== "granted") {
      return;
    }
    try {
      new Notification("Netzschild fragt nach", {
        body: `${pending.app} → ${pending.domain}`,
        tag: pending.id,
      });
    } catch {
      /* ignore */
    }
  }, [pending]);

  return null;
}
