import { useCallback, useEffect, useRef, useState } from "react";
import type { GameHandle } from "@/game/engine";
import { clearSave, loadSave } from "@/game/save";
import type { DayReport, HudSnap, PanelId } from "@/game/types";
import { Hud } from "./hud";
import { TouchControls } from "./joystick";
import { DayEnd, GamePanel, PauseMenu } from "./panels";
import { TitleScreen } from "./title-screen";

type Phase = "title" | "playing" | "paused" | "dayend";

const emptyHud: HudSnap = {
  money: 0,
  rating: 0,
  day: 1,
  clock: "8:00 AM",
  open: false,
  prompt: "",
  holding: null,
  cleanliness: 1,
  customers: 0,
  queue: 0,
  event: null,
  tutorial: null,
  interact: false,
  speed: 0,
  yaw: 0,
  px: 0,
  pz: 0,
  storeLevel: 1,
  location: "town",
  xp: 0,
};

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameHandle | null>(null);
  const [phase, setPhase] = useState<Phase>("title");
  const [ready, setReady] = useState(false);
  const [hasSave, setHasSave] = useState(false);
  const [hud, setHud] = useState<HudSnap>(emptyHud);
  const [toast, setToast] = useState<string | null>(null);
  const [panel, setPanel] = useState<PanelId>(null);
  const [report, setReport] = useState<DayReport | null>(null);
  const [portrait, setPortrait] = useState(false);
  const toastT = useRef<number | null>(null);

  useEffect(() => {
    setHasSave(loadSave().day > 1 || loadSave().money !== 2800 || loadSave().xp > 0);
  }, []);

  useEffect(() => {
    const onResize = () => setPortrait(window.innerHeight > window.innerWidth + 40);
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let handle: GameHandle | null = null;
    void import("@/game/engine").then(({ createGame }) => {
      if (dead || !canvasRef.current) return;
      handle = createGame(canvasRef.current, {
        onHud: (h) => setHud(h),
        onToast: (t) => {
          setToast(t);
          if (toastT.current) window.clearTimeout(toastT.current);
          toastT.current = window.setTimeout(() => setToast(null), 2800);
        },
        onDayEnd: (r) => {
          setReport(r);
          setPhase("dayend");
          handle?.stop();
        },
      });
      gameRef.current = handle;
      setReady(true);
    });
    return () => {
      dead = true;
      handle?.dispose();
      gameRef.current = null;
    };
  }, []);

  const play = () => {
    const g = gameRef.current;
    if (!g) return;
    g.audio.unlock();
    g.start();
    g.sim.s.seenHelp = true;
    setPhase("playing");
    setPanel(null);
  };

  const fresh = () => {
    clearSave();
    window.location.reload();
  };

  const onMove = useCallback((x: number, y: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.input.stick.x = x;
    g.input.stick.y = y;
  }, []);
  const onLook = useCallback((x: number, y: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.input.look.x = x * 0.35;
    g.input.look.y = y * 0.35;
  }, []);

  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    g.input.enabled = phase === "playing" && !panel;
  }, [phase, panel]);

  const game = gameRef.current;

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onPointerDown={() => {
          if (phase !== "playing" || panel) return;
          const c = canvasRef.current;
          if (c && window.matchMedia("(pointer:fine)").matches) {
            c.requestPointerLock?.();
          }
        }}
      />
      {!ready ? (
        <div className="absolute inset-0 z-10 grid place-items-center bg-bg">
          <p className="font-display text-xl tracking-widest text-muted">LOADING AISLES</p>
        </div>
      ) : null}

      {phase === "title" ? <TitleScreen hasSave={hasSave} onPlay={play} onFresh={fresh} /> : null}

      {phase === "playing" || phase === "paused" || phase === "dayend" ? (
        <Hud
          hud={hud}
          toast={toast}
          panel={panel}
          onPanel={setPanel}
          onOpen={() => gameRef.current?.sim.toggleOpen()}
          onPause={() => {
            setPhase("paused");
            gameRef.current?.stop();
            document.exitPointerLock?.();
          }}
          onInteract={() => {
            const g = gameRef.current;
            if (!g) return;
            g.input.interactHeld = true;
            window.setTimeout(() => {
              if (g.input) g.input.interactHeld = false;
            }, 80);
          }}
          onSprint={(v) => {
            const g = gameRef.current;
            if (g) g.input.sprintTouch = v;
          }}
          portrait={portrait}
        />
      ) : null}

      {phase === "playing" ? <TouchControls onMove={onMove} onLook={onLook} /> : null}

      {game && panel ? (
        <GamePanel
          panel={panel}
          game={game}
          onClose={() => setPanel(null)}
          onRebuild={() => game.rebuild()}
        />
      ) : null}

      {phase === "paused" ? (
        <PauseMenu
          onResume={() => {
            setPhase("playing");
            gameRef.current?.start();
          }}
          onSettings={() => {
            setPanel("settings");
            setPhase("playing");
            gameRef.current?.start();
          }}
          onTitle={() => {
            setPhase("title");
            gameRef.current?.stop();
          }}
        />
      ) : null}

      {phase === "dayend" && report ? (
        <DayEnd
          report={report}
          onNext={() => {
            gameRef.current?.sim.nextDay();
            setReport(null);
            setPhase("playing");
            gameRef.current?.start();
          }}
        />
      ) : null}
    </div>
  );
}
