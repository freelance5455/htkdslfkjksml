import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  Award,
  CarFront,
  CircleDollarSign,
  Crosshair,
  Flag,
  Gem,
  LayoutGrid,
  Lock,
  Phone,
  Radio,
  Settings,
  ShoppingBag,
  Sparkles,
  Star,
  Swords,
  Trophy,
  User,
  Users,
  Vault,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { CARS, CREW, MISSIONS, MODES, OUTFITS, PASS, PROPS, WEAPONS } from "@/game/content";
import type { GameAPI } from "@/game/engine";
import type { HudState, ModeId, WeaponId } from "@/game/types";

const PAINTS = ["#161616", "#e23b4a", "#f5c400", "#2a9d8f", "#3d5a80", "#f4f4f4", "#6d597a"];

function cash(n: number) {
  return "$" + Math.floor(n).toLocaleString("en-US");
}

const INITIAL: HudState = {
  phase: "load",
  load: 0.04,
  tip: "Jack a ride with F. Park it like you paid for it.",
  name: "DARKFIRE",
  rank: 34,
  money: 23820,
  gems: 86,
  health: 100,
  armor: 25,
  stars: 0,
  weapon: "jade",
  weaponName: "Jade SMG",
  mag: 30,
  reserve: 90,
  grenades: 2,
  inCar: false,
  carName: "Veto GT",
  speed: 0,
  district: "Bahia Bay",
  clock: "9:00 PM",
  radio: "NEON FM",
  radioOn: true,
  outfit: "darkfire",
  ownedWeapons: ["fists", "pistol", "jade"],
  ownedCars: ["veto", "issi"],
  ownedProps: [],
  carColor: "#161616",
  missionsDone: [],
  xp: 0,
  passClaimed: 0,
  missionName: "",
  objective: "",
  hold: 0,
  notes: [],
  hint: "",
  interact: "",
  paused: false,
  phone: false,
  down: "",
  pain: 0,
  mode: "freeroam",
  volume: 0.45,
  muted: false,
  crouch: false,
  raceLap: "",
  bestRace: null,
  vaultReady: true,
  ownedOutfits: ["darkfire"],
};

type Panel = "store" | "crates" | "character" | "vault" | "crew" | "collection" | "weapons" | "pass" | "missions" | "settings" | "invite" | null;

const RAIL: { id: Exclude<Panel, null>; label: string; icon: typeof ShoppingBag }[] = [
  { id: "store", label: "Store", icon: ShoppingBag },
  { id: "crates", label: "Crates", icon: Sparkles },
  { id: "character", label: "Character", icon: User },
  { id: "vault", label: "Vault", icon: Vault },
  { id: "crew", label: "Crew", icon: Users },
  { id: "collection", label: "Collection", icon: LayoutGrid },
  { id: "weapons", label: "Weapons", icon: Crosshair },
];

export function GameApp() {
  const glRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const posterRef = useRef<HTMLCanvasElement>(null);
  const phoneRef = useRef<HTMLCanvasElement>(null);
  const api = useRef<GameAPI | null>(null);
  const [hud, setHud] = useState<HudState>(INITIAL);
  const [panel, setPanel] = useState<Panel>(null);
  const [mode, setMode] = useState<ModeId>("freeroam");
  const [stick, setStick] = useState({ x: 0, y: 0 });
  const modeInfo = MODES.find((m) => m.id === mode) ?? MODES[0]!;

  useEffect(() => {
    const canvas = glRef.current;
    const mini = miniRef.current;
    const poster = posterRef.current;
    const phoneMap = phoneRef.current;
    if (!canvas || !mini || !poster || !phoneMap) return;
    let dead = false;
    let current: GameAPI | null = null;
    void import("@/game/engine").then(({ mountGame }) => {
      if (dead) return;
      current = mountGame({ canvas, mini, poster, phoneMap, onHud: setHud });
      api.current = current;
    });
    return () => {
      dead = true;
      current?.destroy();
      api.current = null;
    };
  }, []);

  const open = (id: Panel) => {
    api.current?.blip();
    setPanel((p) => (p === id ? null : id));
  };

  return (
    <main className="game-root">
      <canvas ref={glRef} className={hud.down ? "gl is-down" : "gl"} />
      <canvas ref={miniRef} width={256} height={256} className={hud.phase === "play" ? "minimap" : "offscreen"} />
      <div className="vignette" style={{ ["--pain" as string]: String(hud.pain) }} />

      {hud.phase === "load" && (
        <div className="loader" onClick={() => api.current?.skipLoad()} role="presentation">
          <div className="letterbox top" />
          <div className="letterbox bot" />
          <div className="loader-copy">
            <p className="eyebrow">County of Rico</p>
            <h1>DARKFIRE</h1>
            <p className="sub">Bahia Bay</p>
            <div className="star-row" aria-hidden>
              <Star size={18} fill="currentColor" />
              <Star size={18} fill="currentColor" />
              <Star size={18} fill="currentColor" />
              <Star size={18} fill="currentColor" />
              <Star size={18} />
            </div>
          </div>
          <div className="skyline" aria-hidden>
            {[40, 70, 48, 110, 64, 90, 36, 80, 52, 120, 44, 76, 58].map((h, i) => (
              <i key={i} style={{ height: h }} />
            ))}
          </div>
          <div className="loader-foot">
            <p className="tip">{hud.tip}</p>
            <div className="loadbar" style={{ ["--p" as string]: String(Math.round(hud.load * 100)) }}>
              <span />
            </div>
            <p className="load-meta">Loading street data · {Math.round(hud.load * 100)}% · click to skip</p>
          </div>
        </div>
      )}

      <div className={hud.phase === "lobby" ? "lobby" : "lobby is-hidden"}>
        <header className="topbar">
          <div className="rank">{hud.rank}</div>
          <div className="who">
            <strong>{hud.name}</strong>
            <em>Gold · Street King</em>
          </div>
          <div className="currencies">
            <span className="pill gem">
              <Gem size={14} /> {hud.gems}
            </span>
            <span className="pill cash">
              <CircleDollarSign size={14} /> {hud.money.toLocaleString("en-US")}
            </span>
          </div>
          <p className="brand-lockup">DARKFIRE</p>
        </header>
        <nav className="rail" aria-label="Lobby">
          {RAIL.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} className={panel === item.id ? "on" : ""} onClick={() => open(item.id)}>
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="right-col">
          <div className="mode-slot">
            <canvas ref={posterRef} width={256} height={256} />
            <button
              className="mode-hit"
              onClick={() => setMode(MODES[(MODES.findIndex((m) => m.id === mode) + 1) % MODES.length]!.id)}
            >
              <span>{modeInfo.kicker}</span>
              <strong>{modeInfo.map}</strong>
              <em>{modeInfo.title}</em>
            </button>
          </div>
          <button className="invite" onClick={() => open("invite")}>
            Invite
          </button>
          <div className="events">
            <button className="event-btn" aria-label="Missions" onClick={() => open("missions")}>
              <Flag size={18} />
            </button>
            <button className="event-btn" aria-label="Records" onClick={() => open("missions")}>
              <Trophy size={18} />
            </button>
            <button className="event-btn" aria-label="Settings" onClick={() => open("settings")}>
              <Settings size={18} />
            </button>
          </div>
        </div>
        <button className="pass-orb" onClick={() => open("pass")} aria-label="City pass">
          <Award size={26} />
          <small>Pass</small>
        </button>
        <button
          className="start-btn"
          onClick={() => {
            api.current?.blip();
            api.current?.startMode(mode);
          }}
        >
          <span>Start</span>
        </button>
        {panel && hud.phase === "lobby" && (
          <div className="sheet" onClick={() => setPanel(null)}>
            <div className="sheet-card" onClick={(e) => e.stopPropagation()}>
              <PanelBody panel={panel} hud={hud} api={api.current} close={() => setPanel(null)} />
            </div>
          </div>
        )}
      </div>

      <div className={hud.phase === "play" && hud.phone ? "sheet" : "is-hidden"}>
        <div className="sheet-card">
          <canvas ref={phoneRef} width={640} height={360} className="phone-map" />
          <div className="sheet-head">
            <h2>Phone</h2>
            <button className="icon-btn" onClick={() => api.current?.setPhone(false)} aria-label="Close">
              <X size={18} />
            </button>
          </div>
          <div className="row-actions">
            <button className="item" onClick={() => api.current?.deliverCar(hud.ownedCars[0] ?? "veto")}>
              <CarFront size={16} /> Deliver car
            </button>
            <button className="item" onClick={() => api.current?.tap("radio")}>
              <Radio size={16} /> {hud.radio}
            </button>
          </div>
          <PlayMenus hud={hud} api={api.current} />
        </div>
      </div>

      {hud.phase === "play" && (
        <div className="hud">
          <button className="menu-btn" aria-label="Pause" onClick={() => api.current?.setPaused(true)}>
            <Settings size={18} />
          </button>
          {hud.missionName && (
            <div className="mission-banner">
              <strong>{hud.missionName}</strong>
              <p>{hud.objective}</p>
              {hud.raceLap && <p>{hud.raceLap}</p>}
              {hud.hold > 0 && (
                <div className="hold" style={{ ["--h" as string]: String(hud.hold) }}>
                  <span />
                </div>
              )}
            </div>
          )}
          <div className="clock-block">
            <b>{hud.clock}</b>
            <span>{hud.district}</span>
            <span>{cash(hud.money)}</span>
          </div>
          <div className="notes">
            {hud.notes.map((n) => (
              <p key={n.id}>{n.text}</p>
            ))}
          </div>
          {hud.hint && <p className="hint">{hud.hint}</p>}
          {!hud.paused && !hud.phone && <div className="crosshair" />}
          <div className="minimap-wrap">
            <div className="stars" aria-label={`${hud.stars} stars`}>
              {[0, 1, 2, 3, 4].map((i) => (
                <Star key={i} size={16} className={i < hud.stars ? "on" : ""} fill={i < hud.stars ? "currentColor" : "none"} />
              ))}
            </div>
            <div className="bars">
              <div className="bar hp" style={{ ["--n" as string]: String(hud.health) }}>
                <span />
              </div>
              <div className="bar ar" style={{ ["--n" as string]: String(hud.armor) }}>
                <span />
              </div>
            </div>
          </div>
          <div className="weapon-hud">
            <strong>{hud.weaponName}</strong>
            <em>{hud.weapon === "fists" ? "Melee" : `${hud.mag} / ${hud.reserve}`}</em>
            <div>Grenades {hud.grenades}</div>
          </div>
          {hud.inCar && !hud.phone && <div className="radio-hud">{hud.radio}</div>}
          {hud.interact && <div className="interact">{hud.interact}</div>}
          {!hud.paused && !hud.phone && !hud.down && <Touch api={api.current} stick={stick} setStick={setStick} />}
          {hud.down && (
            <div className={hud.down === "busted" ? "down-copy busted" : "down-copy"}>
              <div>
                <h2>{hud.down === "busted" ? "BUSTED" : "WASTED"}</h2>
                <p>County general has a bed</p>
              </div>
            </div>
          )}
          {hud.paused && !hud.phone && !hud.down && (
            <div className="sheet">
              <div className="sheet-card">
                <div className="sheet-head">
                  <h2>Paused</h2>
                  <button className="icon-btn" onClick={() => api.current?.setPaused(false)} aria-label="Close">
                    <X size={18} />
                  </button>
                </div>
                <div className="stack">
                  <button className="item" onClick={() => api.current?.setPaused(false)}>
                    Resume
                  </button>
                  <button
                    className="item"
                    onClick={() => {
                      api.current?.setPaused(false);
                      api.current?.setPhone(true);
                    }}
                  >
                    <Phone size={16} /> Open phone
                  </button>
                  <button className="item" onClick={() => api.current?.buyKit("armor")}>
                    Armor refill · $500
                  </button>
                  <button className="item" onClick={() => api.current?.buyKit("health")}>
                    Medkit · $200
                  </button>
                  <button className="item" onClick={() => api.current?.goLobby()}>
                    Back to lobby
                  </button>
                </div>
                <p className="muted">WASD drive or walk · A left, D right · mouse orbits · click or Ctrl shoots · F vehicle · E buy or save · G grenade · C crouch · Z radio · N time skip · 1-5 weapons</p>
              </div>
            </div>
          )}
        </div>
      )}
    </main>
  );
}

function Touch({
  api,
  stick,
  setStick,
}: {
  api: GameAPI | null;
  stick: { x: number; y: number };
  setStick: (v: { x: number; y: number }) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (e: ReactPointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    let x = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    let y = -((e.clientY - (r.top + r.height / 2)) / (r.height / 2));
    const m = Math.hypot(x, y) || 1;
    if (m > 1) {
      x /= m;
      y /= m;
    }
    setStick({ x, y });
    api?.setAnalog(x, y);
  };
  return (
    <div className="touch">
      <div
        className="stick"
        ref={ref}
        style={{ ["--x" as string]: String(stick.x), ["--y" as string]: String(stick.y) }}
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          move(e);
        }}
        onPointerMove={(e) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e);
        }}
        onPointerUp={() => {
          setStick({ x: 0, y: 0 });
          api?.setAnalog(0, 0);
        }}
      >
        <i />
      </div>
      <div className="touch-actions">
        <button onPointerDown={() => api?.setHeld("brake", true)} onPointerUp={() => api?.setHeld("brake", false)} onPointerLeave={() => api?.setHeld("brake", false)}>
          Brake
        </button>
        <button onPointerDown={() => api?.setHeld("shoot", true)} onPointerUp={() => api?.setHeld("shoot", false)} onPointerLeave={() => api?.setHeld("shoot", false)}>
          Fire
        </button>
        <button onClick={() => api?.tap("action")}>Car</button>
        <button onClick={() => api?.tap("weapon")}>Gun</button>
        <button onClick={() => api?.tap("grenade")}>Nade</button>
        <button onClick={() => api?.tap("radio")}>Radio</button>
      </div>
    </div>
  );
}

function PanelBody({ panel, hud, api, close }: { panel: Exclude<Panel, null>; hud: HudState; api: GameAPI | null; close: () => void }) {
  return (
    <>
      <div className="sheet-head">
        <h2>{title(panel)}</h2>
        <button className="icon-btn" onClick={close} aria-label="Close">
          <X size={18} />
        </button>
      </div>
      {panel === "store" && (
        <div className="stack">
          <p className="muted">Cash {cash(hud.money)} · Gems {hud.gems}</p>
          {WEAPONS.filter((w) => w.price > 0).map((w) => (
            <button key={w.id} className="item" onClick={() => api?.buyWeapon(w.id)}>
              {w.name}
              <small>{hud.ownedWeapons.includes(w.id) ? "Owned — tap to equip" : cash(w.price)}</small>
            </button>
          ))}
          {CARS.map((c) => (
            <button key={c.id} className="item" onClick={() => api?.buyCar(c.id)}>
              {c.name}
              <small>{hud.ownedCars.includes(c.id) ? "Deliver" : cash(c.price)}</small>
            </button>
          ))}
          <button className="item" onClick={() => api?.buyKit("armor")}>
            Armor · $500
          </button>
          <button className="item" onClick={() => api?.buyKit("health")}>
            Medkit · $200
          </button>
          <button className="item" onClick={() => api?.buyGrenades()}>
            Grenade brick · $600
          </button>
          {PROPS.map((p) => (
            <button key={p.id} className="item" onClick={() => api?.buyProperty(p.id)}>
              {p.name}
              <small>{hud.ownedProps.includes(p.id) ? "Owned" : `${cash(p.price)} · ${p.blurb}`}</small>
            </button>
          ))}
        </div>
      )}
      {panel === "weapons" && (
        <div className="stack">
          {WEAPONS.map((w) => (
            <button key={w.id} className={hud.weapon === w.id ? "item on" : "item"} onClick={() => api?.equipWeapon(w.id as WeaponId)}>
              {w.name}
              <small>{hud.ownedWeapons.includes(w.id) ? "Owned" : `Locked · ${cash(w.price)}`}</small>
            </button>
          ))}
        </div>
      )}
      {panel === "character" && (
        <div className="stack">
          <label className="muted">
            Street name
            <input className="name-input" maxLength={12} defaultValue={hud.name} onBlur={(e) => api?.setName(e.target.value)} />
          </label>
          {OUTFITS.map((o) => (
            <button key={o.id} className={hud.outfit === o.id ? "item on" : "item"} onClick={() => api?.setOutfit(o.id)}>
              {o.name}
              <small>{hud.ownedOutfits.includes(o.id) || hud.outfit === o.id ? "In the closet" : cash(o.price)}</small>
            </button>
          ))}
          <p className="muted">Respray the personal car</p>
          <div className="swatches">
            {PAINTS.map((c) => (
              <button key={c} className="swatch" style={{ background: c }} aria-label={`Paint ${c}`} onClick={() => api?.paintCar(c)} />
            ))}
          </div>
        </div>
      )}
      {panel === "vault" && (
        <div className="stack">
          <p>Street cash {cash(hud.money)}</p>
          <p className="muted">Gems {hud.gems}. The vault pays once every 20 hours.</p>
          <button className="item" onClick={() => api?.claimVault()}>
            {hud.vaultReady ? "Collect street cut" : "Already collected"}
          </button>
        </div>
      )}
      {panel === "crates" && (
        <div className="stack">
          <p>40 gems a pull. Cash, grenades, or a gem jackpot.</p>
          <button className="item" onClick={() => api?.openCrate()}>
            Open crate
          </button>
        </div>
      )}
      {panel === "crew" && (
        <div className="stack">
          {CREW.map((c) => (
            <article key={c.name} className="crew">
              <b>{c.name}</b>
              <small>{c.role}</small>
              <p>{c.line}</p>
            </article>
          ))}
          <p className="muted">They ride along in the jobs. This bay is yours alone.</p>
        </div>
      )}
      {panel === "invite" && (
        <div className="stack">
          <p>No network lobby — your crew is already in the city.</p>
          {CREW.map((c) => (
            <article key={c.name} className="crew">
              <b>{c.name}</b>
              <small>{c.role}</small>
            </article>
          ))}
        </div>
      )}
      {panel === "collection" && (
        <div className="grid-list">
          {CARS.filter((c) => hud.ownedCars.includes(c.id)).map((c) => (
            <button key={c.id} className="item" onClick={() => api?.deliverCar(c.id)}>
              {c.name}
              <small>Deliver</small>
            </button>
          ))}
          {OUTFITS.filter((o) => hud.ownedOutfits.includes(o.id) || o.id === hud.outfit).map((o) => (
            <div key={o.id} className="item">
              {o.name}
              <small>Outfit</small>
            </div>
          ))}
        </div>
      )}
      {panel === "pass" && (
        <div className="stack">
          <p className="muted">XP {hud.xp}</p>
          {PASS.map((row, i) => (
            <button key={row.label} className={i < hud.passClaimed ? "item done" : "item"} onClick={() => api?.claimPass()} disabled={i !== hud.passClaimed}>
              {row.label}
              <small>
                {i < hud.passClaimed ? "Claimed" : `${row.xp} XP · ${row.cash ? cash(row.cash) : ""} ${row.gems ? `${row.gems} gems` : ""}`}
              </small>
            </button>
          ))}
        </div>
      )}
      {panel === "missions" && <PlayMenus hud={hud} api={api} />}
      {panel === "settings" && (
        <div className="stack">
          <label className="muted">
            Volume
            <input className="range" type="range" min={0} max={1} step={0.01} defaultValue={hud.volume} onChange={(e) => api?.setVolume(Number(e.target.value))} />
          </label>
          <button className="item" onClick={() => api?.toggleMute()}>
            {hud.muted ? <VolumeX size={16} /> : <Volume2 size={16} />} {hud.muted ? "Unmute" : "Mute"}
          </button>
          {hud.bestRace !== null && <p className="muted">Best ring {hud.bestRace.toFixed(1)}s</p>}
        </div>
      )}
    </>
  );
}

function PlayMenus({ hud, api }: { hud: HudState; api: GameAPI | null }) {
  return (
    <div className="stack">
      {MISSIONS.map((m) => {
        const locked = !!m.unlockAfter && !hud.missionsDone.includes(m.unlockAfter);
        const done = hud.missionsDone.includes(m.id);
        return (
          <button key={m.id} className={done ? "mission done" : "mission"} disabled={locked} onClick={() => api?.startMission(m.id)}>
            {locked ? <Lock size={14} /> : <Swords size={14} />} {m.name}
            <small>
              {m.chapter} · {"★".repeat(m.difficulty)} · {done ? "Cleared" : locked ? "Locked" : `${cash(m.reward)} · ${m.blurb}`}
            </small>
          </button>
        );
      })}
    </div>
  );
}

function title(panel: Exclude<Panel, null>) {
  const map: Record<Exclude<Panel, null>, string> = {
    store: "Store",
    crates: "Crates",
    character: "Character",
    vault: "Vault",
    crew: "Crew",
    collection: "Collection",
    weapons: "Weapons",
    pass: "City Pass",
    missions: "Jobs",
    settings: "Settings",
    invite: "Invite",
  };
  return map[panel];
}
