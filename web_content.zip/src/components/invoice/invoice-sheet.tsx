import type { CSSProperties } from "react";
import { useInvoiceStore } from "@/lib/invoice/store";
import { faNum, formatPayId, lineAmount, lineTitle, safeHex, totals } from "@/lib/invoice/model";

export function InvoiceSheet() {
  const draft = useInvoiceStore((state) => state.draft);
  const settings = useInvoiceStore((state) => state.settings);
  const doctor = useInvoiceStore((state) => state.doctors.find((item) => item.id === state.draft.doctorId) ?? null);
  const color = doctor ? safeHex(doctor.color) : undefined;
  const sum = totals(draft.items, draft.discount);
  const note = draft.invoiceNotes.trim() || settings.defaultNote || "—";
  const pad = Math.max(0, Math.min(2, 4 - draft.items.length));

  return (
    <article className="sheet" style={color ? ({ "--sheet-accent": color } as CSSProperties) : undefined} aria-label="پیش‌نمایش فاکتور قابل چاپ">
      <header className="sheet-top">
        <div className="sheet-brand">
          <div className="sheet-logo">آ</div>
          <div>
            <h2 className="sheet-lab">{settings.labName}</h2>
            <p className="sheet-tagline">ساخت و ترمیم روکش و خدمات لابراتواری دندان</p>
          </div>
        </div>
        <div className="sheet-id">
          <h3>فاکتور خدمات لابراتوار</h3>
          <p>
            شماره: <b>{draft.invoiceNo || "—"}</b>
          </p>
        </div>
      </header>

      <div className="sheet-meta">
        <div>
          <b>تاریخ</b>
          <span>{draft.date || "—"}</span>
        </div>
        <div>
          <b>پزشک</b>
          <span>{doctor?.name || "—"}</span>
        </div>
        <div>
          <b>مدیریت</b>
          <span>{settings.manager || "—"}</span>
        </div>
        <div>
          <b>تعداد دندان</b>
          <span>{faNum(draft.selectedTeeth.length)}</span>
        </div>
      </div>

      <div className="sheet-patient">
        <p>
          <b>نام بیمار: </b>
          {draft.patientName || "—"}
        </p>
        <p>
          <b>شماره تماس: </b>
          <span className="num">{draft.patientPhone || "—"}</span>
        </p>
        <p>
          <b>دندان‌ها: </b>
          {draft.selectedTeeth.length ? draft.selectedTeeth.join("، ") : "—"}
        </p>
        <p>
          <b>توضیحات سفارش: </b>
          {draft.patientNotes || "—"}
        </p>
      </div>

      <div className="sheet-table-wrap">
        <table>
          <thead>
            <tr>
              <th>ردیف</th>
              <th>دندان</th>
              <th>شرح خدمات / نوع روکش</th>
              <th>رنگ</th>
              <th>تعداد</th>
              <th>قیمت واحد</th>
              <th>جمع (تومان)</th>
            </tr>
          </thead>
          <tbody>
            {draft.items.length ? (
              draft.items.map((item, index) => (
                <tr key={item.id}>
                  <td>{faNum(index + 1)}</td>
                  <td className="num">{item.tooth ?? "—"}</td>
                  <td>{lineTitle(item)}</td>
                  <td>{item.shade || "—"}</td>
                  <td>{faNum(item.qty)}</td>
                  <td className="num">{item.price === "" ? "—" : faNum(item.price)}</td>
                  <td className="num">{item.price === "" ? "—" : faNum(lineAmount(item))}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7}>خدمتی ثبت نشده است.</td>
              </tr>
            )}
            {Array.from({ length: pad }, (_, index) => (
              <tr key={`blank-${index}`}>
                <td> </td>
                <td> </td>
                <td> </td>
                <td> </td>
                <td> </td>
                <td> </td>
                <td> </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="sheet-bottom">
        <div className="sheet-pay">
          <h4>اطلاعات پرداخت</h4>
          <p>
            <b>شماره کارت: </b>
            <span className="num">{formatPayId(draft.labCardNumber)}</span>
          </p>
          <p>
            <b>شماره شبا: </b>
            <span className="num">{draft.labShebaNumber.trim() || "—"}</span>
          </p>
          <p>
            <b>توضیحات: </b>
            {note}
          </p>
        </div>
        <div className="sheet-totals">
          <div>
            <span>جمع خدمات</span>
            <strong className="num">{faNum(sum.subtotal)} تومان</strong>
          </div>
          <div>
            <span>تخفیف</span>
            <strong className="num">{faNum(sum.discount)} تومان</strong>
          </div>
          <div>
            <span>مبلغ قابل پرداخت</span>
            <strong className="num">{faNum(sum.total)} تومان</strong>
          </div>
        </div>
      </div>

      <footer className="sheet-foot">
        <span>امضای تحویل‌گیرنده: ................................</span>
        <span>
          مهر و امضای لابراتوار: <b>{settings.manager}</b>
        </span>
      </footer>
    </article>
  );
}
