import { useEffect, useRef, useState } from "react";
import { Archive, Download, Settings, Upload } from "lucide-react";
import { Toaster, toast } from "sonner";
import { ConfirmDialog, SettingsDialog } from "@/components/invoice/dialogs";
import { InvoiceSheet } from "@/components/invoice/invoice-sheet";
import { ArchiveView, StageItems, StagePatient, StageReview, StageTeeth } from "@/components/invoice/stages";
import { Button } from "@/components/invoice/ui";
import { faNum, parseBackup, type Persisted } from "@/lib/invoice/model";
import { useInvoiceStore, type Step } from "@/lib/invoice/store";
import { cn } from "@/lib/utils";

const STEPS: { n: Step; short: string; title: string }[] = [
  { n: 1, short: "بیمار", title: "اطلاعات بیمار" },
  { n: 2, short: "دندان", title: "انتخاب دندان" },
  { n: 3, short: "قیمت", title: "جزئیات و قیمت" },
  { n: 4, short: "چاپ", title: "فاکتور نهایی" },
];

export function InvoiceApp() {
  const hydrated = useInvoiceStore((state) => state.hydrated);
  const hydrate = useInvoiceStore((state) => state.hydrate);
  const warning = useInvoiceStore((state) => state.storageWarning);
  const clearWarning = useInvoiceStore((state) => state.clearWarning);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!warning) return;
    toast.error(warning);
    clearWarning();
  }, [warning, clearWarning]);

  if (!hydrated) {
    return (
      <main className="grid min-h-screen place-items-center px-6">
        <div className="text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-primary text-xl font-extrabold text-on-primary">آ</div>
          <p className="mt-4 font-bold">فاکتورساز آرمان</p>
          <p className="text-sm text-muted">در حال باز کردن پرونده‌ها…</p>
        </div>
      </main>
    );
  }

  return <Shell />;
}

function Shell() {
  const step = useInvoiceStore((state) => state.step);
  const view = useInvoiceStore((state) => state.view);
  const openArchive = useInvoiceStore((state) => state.openArchive);
  const exportPayload = useInvoiceStore((state) => state.exportPayload);
  const replaceAll = useInvoiceStore((state) => state.replaceAll);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [pendingBackup, setPendingBackup] = useState<Persisted | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [step, view]);

  function downloadBackup() {
    const payload = exportPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `arman-invoice-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    toast.success("فایل پشتیبان آماده شد. اطلاعات بیماران داخلش است.");
  }

  return (
    <div className="min-h-screen">
      <header className="no-print mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="grid size-12 place-items-center rounded-2xl bg-primary text-lg font-extrabold text-on-primary">آ</div>
          <div>
            <h1 className="text-xl font-extrabold leading-tight">فاکتورساز آرمان</h1>
            <p className="text-xs text-muted">لابراتوار دندانسازی · ثبت مرحله‌ای فاکتور</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button aria-label="فاکتورهای ذخیره‌شده" onClick={openArchive}>
            <Archive className="size-4" />
            <span className="hidden sm:inline">بایگانی</span>
          </Button>
          <Button aria-label="دانلود پشتیبان" onClick={downloadBackup}>
            <Download className="size-4" />
            <span className="hidden sm:inline">پشتیبان</span>
          </Button>
          <Button aria-label="بازیابی نسخه" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4" />
            <span className="hidden sm:inline">بازیابی</span>
          </Button>
          <Button aria-label="تنظیمات" onClick={() => setSettingsOpen(true)}>
            <Settings className="size-4" />
            <span className="hidden sm:inline">تنظیمات</span>
          </Button>
          <input
            ref={fileRef}
            className="hidden"
            type="file"
            accept="application/json,.json"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              void file.text().then((text) => {
                try {
                  const parsed = parseBackup(JSON.parse(text) as unknown);
                  if (!parsed) {
                    toast.error("این فایل پشتیبان آرمان نیست.");
                    return;
                  }
                  setPendingBackup(parsed);
                } catch {
                  toast.error("فایل انتخاب‌شده قابل خواندن نیست.");
                }
              });
            }}
          />
        </div>
      </header>

      <main className="mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-4 px-4 pb-16">
        {view === "wizard" ? (
          <ol className="no-print grid grid-cols-4 gap-2" aria-label="مراحل ثبت فاکتور">
            {STEPS.map((item) => {
              const active = item.n === step;
              const done = item.n < step;
              return (
                <li
                  key={item.n}
                  aria-current={active ? "step" : undefined}
                  className={cn(
                    "flex min-w-0 items-center gap-2 rounded-2xl border px-2 py-2 sm:px-3",
                    active && "border-primary bg-primary-soft text-primary-ink",
                    done && "border-line bg-surface text-ink",
                    !active && !done && "border-line bg-surface text-muted",
                  )}
                >
                  <span className={cn("grid size-8 shrink-0 place-items-center rounded-full text-sm font-extrabold", active || done ? "bg-primary text-on-primary" : "bg-canvas text-muted")}>
                    {faNum(item.n)}
                  </span>
                  <span className="truncate text-sm font-bold">
                    <span className="sm:hidden">{item.short}</span>
                    <span className="hidden sm:inline">{item.title}</span>
                  </span>
                </li>
              );
            })}
          </ol>
        ) : null}

        <div className="no-print flex flex-col gap-4">
          {view === "archive" ? <ArchiveView /> : null}
          {view === "wizard" && step === 1 ? <StagePatient /> : null}
          {view === "wizard" && step === 2 ? <StageTeeth /> : null}
          {view === "wizard" && step === 3 ? <StageItems /> : null}
          {view === "wizard" && step === 4 ? <StageReview /> : null}
        </div>

        {view === "wizard" && step === 4 ? (
          <div className="sheet-frame">
            <InvoiceSheet />
          </div>
        ) : null}

        <p className="no-print text-center text-xs text-muted">اطلاعات در حافظه همین مرورگر می‌ماند. برای جابه‌جایی بین دستگاه‌ها فایل پشتیبان بگیر.</p>
      </main>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
      <ConfirmDialog
        open={pendingBackup != null}
        title="بازیابی پشتیبان"
        body="اطلاعات فعلی این مرورگر با فایل انتخاب‌شده عوض شود؟"
        confirmLabel="جایگزینی"
        onOpenChange={(open) => {
          if (!open) setPendingBackup(null);
        }}
        onConfirm={() => {
          if (!pendingBackup) return;
          const ok = replaceAll(pendingBackup);
          toast.success(ok ? "بازیابی انجام شد." : "بازیابی در حافظه ماند ولی فضای مرورگر کم است.");
        }}
      />
      <div className="no-print">
        <Toaster position="bottom-center" dir="rtl" />
      </div>
    </div>
  );
}
