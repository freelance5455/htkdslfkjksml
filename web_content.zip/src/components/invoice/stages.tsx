import { useMemo, useState } from "react";
import { ImagePlus, Plus, Printer, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { ConfirmDialog, DoctorDialog } from "@/components/invoice/dialogs";
import { Odontogram } from "@/components/invoice/odontogram";
import { Button, Field, Panel, SelectInput, TextArea, TextInput } from "@/components/invoice/ui";
import {
  faNum,
  fileToInvoiceImage,
  formatPayId,
  isMeaningfulDraft,
  lineAmount,
  LOWER_LEFT,
  LOWER_RIGHT,
  LOWER_TEETH,
  parseMoney,
  parseQty,
  sameInvoice,
  SHADES,
  TOOTH_ORDER,
  totals,
  UPPER_LEFT,
  UPPER_RIGHT,
  UPPER_TEETH,
  WORK_TYPES,
  type LineItem,
} from "@/lib/invoice/model";
import { useInvoiceStore } from "@/lib/invoice/store";
import { cn } from "@/lib/utils";

function moneyText(value: number | "") {
  return value === "" ? "" : String(value);
}

export function StagePatient() {
  const draft = useInvoiceStore((state) => state.draft);
  const doctors = useInvoiceStore((state) => state.doctors);
  const patchDraft = useInvoiceStore((state) => state.patchDraft);
  const goTo = useInvoiceStore((state) => state.goTo);
  const [doctorOpen, setDoctorOpen] = useState(false);
  const doctor = doctors.find((item) => item.id === draft.doctorId);

  async function onImage(file: File | undefined) {
    if (!file) return;
    try {
      patchDraft({ imageData: await fileToInvoiceImage(file) });
    } catch (error) {
      const reason = error instanceof Error ? error.message : "";
      toast.error(reason === "size" ? "حجم تصویر زیاد است؛ یکی کوچک‌تر انتخاب کن." : "این تصویر قابل استفاده نیست.");
    }
  }

  return (
    <Panel
      eyebrow="مرحله ۱ از ۴"
      title="مشخصات بیمار و پزشک"
      text="هر فاکتور برای یک بیمار است. نام بیمار و پزشک برای ادامه لازم‌اند."
      aside={<span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink">{draft.savedId ? "ذخیره‌شده" : "فاکتور جدید"}</span>}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="نام بیمار" required>
          <TextInput value={draft.patientName} autoComplete="off" placeholder="نام و نام خانوادگی" onChange={(event) => patchDraft({ patientName: event.target.value })} />
        </Field>
        <Field label="نام پزشک" required>
          <div className="flex gap-2">
            <SelectInput value={draft.doctorId} onChange={(event) => patchDraft({ doctorId: event.target.value })}>
              <option value="">انتخاب پزشک</option>
              {doctors.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </SelectInput>
            <Button variant="soft" onClick={() => setDoctorOpen(true)}>
              <Plus className="size-4" />
              پزشک
            </Button>
          </div>
        </Field>
        <Field label="تاریخ فاکتور">
          <TextInput value={draft.date} onChange={(event) => patchDraft({ date: event.target.value })} />
        </Field>
        <Field label="شماره تماس بیمار" hint="(اختیاری)">
          <TextInput value={draft.patientPhone} inputMode="tel" dir="ltr" className="text-left" placeholder="09..." onChange={(event) => patchDraft({ patientPhone: event.target.value })} />
        </Field>
        <Field label="شماره فاکتور">
          <TextInput value={draft.invoiceNo} readOnly dir="ltr" className="text-left" />
        </Field>
        <div className="flex items-end gap-2 text-sm text-muted">
          {doctor ? (
            <span className="mb-3 inline-flex items-center gap-2">
              <span className="size-3.5 rounded-full" style={{ backgroundColor: doctor.color }} />
              رنگ فاکتور {doctor.name}
            </span>
          ) : (
            <span className="mb-3">اگر پزشک در فهرست نیست، اول ثبتش کن.</span>
          )}
        </div>
        <div className="sm:col-span-2">
          <Field label="توضیحات سفارش">
            <TextArea value={draft.patientNotes} placeholder="توضیح مربوط به سفارش یا بیمار" onChange={(event) => patchDraft({ patientNotes: event.target.value })} />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <div className="flex flex-col gap-3 rounded-2xl border border-dashed border-line bg-canvas p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="flex items-center gap-2 font-bold"><ImagePlus className="size-4" /> تصویر بیمار یا سفارش</p>
              <p className="text-xs text-muted">اختیاری است و روی فاکتور چاپ نمی‌شود. برای مراجعه بعدی کنار همین فاکتور می‌ماند.</p>
              <input
                className="mt-3 block max-w-full text-sm"
                type="file"
                accept="image/*"
                onChange={(event) => {
                  void onImage(event.target.files?.[0]);
                  event.target.value = "";
                }}
              />
            </div>
            {draft.imageData ? (
              <div className="flex items-center gap-3">
                <img src={draft.imageData} alt="پیش‌نمایش تصویر سفارش" className="h-20 w-28 rounded-lg object-cover" />
                <Button variant="danger" onClick={() => patchDraft({ imageData: "" })}>حذف</Button>
              </div>
            ) : null}
          </div>
        </div>
      </div>
      <div className="mt-6 flex items-center justify-between gap-3 border-t border-line pt-4">
        <p className="text-xs text-muted">موارد ستاره‌دار لازم‌اند.</p>
        <Button
          variant="primary"
          onClick={() => {
            const name = draft.patientName.trim();
            if (!name) {
              toast.error("نام بیمار را وارد کن.");
              return;
            }
            if (!draft.doctorId) {
              toast.error("پزشک را انتخاب کن یا پزشک جدید ثبت کن.");
              return;
            }
            patchDraft({ patientName: name, patientPhone: draft.patientPhone.trim(), patientNotes: draft.patientNotes.trim() });
            goTo(2);
          }}
        >
          ادامه: انتخاب دندان‌ها
        </Button>
      </div>
      <DoctorDialog open={doctorOpen} onOpenChange={setDoctorOpen} />
    </Panel>
  );
}

export function StageTeeth() {
  const selected = useInvoiceStore((state) => state.draft.selectedTeeth);
  const toggleTooth = useInvoiceStore((state) => state.toggleTooth);
  const addTeeth = useInvoiceStore((state) => state.addTeeth);
  const setTeeth = useInvoiceStore((state) => state.setTeeth);
  const goTo = useInvoiceStore((state) => state.goTo);

  return (
    <Panel
      eyebrow="مرحله ۲ از ۴"
      title="دندان‌ها را انتخاب کن"
      text="شماره‌ها سیستم FDI است: سمت چپ نمودار، راست بیمار است. اگر خدمت به دندان خاصی وصل نیست، بدون انتخاب ادامه بده."
      aside={<span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink">{faNum(selected.length)} دندان</span>}
    >
      <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="min-w-0">
          <QuadrantPad selected={selected} onToggle={toggleTooth} />
          <div className="hidden md:block">
            <Odontogram selected={selected} onToggle={toggleTooth} />
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-4 text-xs text-muted">
            <span className="inline-flex items-center gap-2"><span className="size-3.5 rounded border border-line bg-surface" />انتخاب‌نشده</span>
            <span className="inline-flex items-center gap-2"><span className="size-3.5 rounded bg-primary" />انتخاب‌شده</span>
          </div>
        </div>
        <aside className="rounded-2xl border border-line p-4">
          <h3 className="font-extrabold">دندان‌های انتخاب‌شده</h3>
          <p className="mt-1 text-sm text-muted">در مرحله بعد برای هر دندان نوع کار، رنگ و قیمت جدا می‌نویسی.</p>
          <div className="mt-3 flex items-center justify-between rounded-xl bg-canvas px-3 py-2">
            <span>تعداد</span>
            <strong>{faNum(selected.length)}</strong>
          </div>
          <div className="mt-3 flex max-h-40 min-h-12 flex-wrap gap-2 overflow-y-auto" dir="ltr">
            {selected.length ? selected.map((tooth) => (
              <button key={tooth} type="button" className="rounded-lg bg-primary-soft px-2 py-1 text-sm font-extrabold text-primary-ink" onClick={() => toggleTooth(tooth)}>
                {tooth} ×
              </button>
            )) : <p className="text-sm text-muted">هنوز دندانی انتخاب نشده.</p>}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={() => addTeeth(UPPER_TEETH)}>فک بالا</Button>
            <Button onClick={() => addTeeth(LOWER_TEETH)}>فک پایین</Button>
            <Button onClick={() => setTeeth(TOOTH_ORDER)}>همه</Button>
            <Button onClick={() => setTeeth([])}>پاک کردن</Button>
          </div>
        </aside>
      </div>
      <div className="mt-6 flex items-center justify-between gap-3 border-t border-line pt-4">
        <Button onClick={() => goTo(1)}>بازگشت</Button>
        <Button variant="primary" onClick={() => goTo(3)}>ادامه: نوع کار و قیمت</Button>
      </div>
    </Panel>
  );
}

function QuadrantPad({ selected, onToggle }: { selected: number[]; onToggle: (tooth: number) => void }) {
  const blocks = [
    ["بالا، راست بیمار", UPPER_RIGHT],
    ["بالا، چپ بیمار", UPPER_LEFT],
    ["پایین، راست بیمار", LOWER_RIGHT],
    ["پایین، چپ بیمار", LOWER_LEFT],
  ] as const;
  return (
    <div className="grid gap-3 md:hidden" dir="ltr">
      {blocks.map(([title, teeth]) => (
        <div key={title} className="rounded-2xl border border-line bg-canvas p-3">
          <p className="mb-2 text-xs font-bold text-muted" dir="rtl">{title}</p>
          <div className="grid grid-cols-4 gap-2">
            {teeth.map((tooth) => {
              const on = selected.includes(tooth);
              return (
                <button
                  key={tooth}
                  type="button"
                  aria-pressed={on}
                  onClick={() => onToggle(tooth)}
                  className={cn("h-11 rounded-xl border text-sm font-extrabold", on ? "border-primary bg-primary text-on-primary" : "border-line bg-surface text-ink")}
                >
                  {tooth}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

export function StageItems() {
  const draft = useInvoiceStore((state) => state.draft);
  const updateItem = useInvoiceStore((state) => state.updateItem);
  const removeItem = useInvoiceStore((state) => state.removeItem);
  const addService = useInvoiceStore((state) => state.addService);
  const patchDraft = useInvoiceStore((state) => state.patchDraft);
  const goTo = useInvoiceStore((state) => state.goTo);
  const sum = totals(draft.items, draft.discount);
  const missingPrice = draft.items.some((item) => item.price === "");

  return (
    <Panel
      eyebrow="مرحله ۳ از ۴"
      title="جزئیات سفارش و قیمت"
      text="قیمت‌ها به تومان است. فقط پست، قالب ایمپلنت و لایرینگ قیمت پیشنهادی دارند؛ بقیه را خودت وارد کن."
      aside={<span className="rounded-full bg-canvas px-3 py-1 text-xs font-bold">{faNum(draft.items.length)} ردیف</span>}
    >
      {draft.items.length ? (
        <div className="flex flex-col gap-3">
          <div className="hidden grid-cols-12 gap-2 px-1 text-xs font-bold text-muted md:grid">
            <span className="col-span-2">دندان</span>
            <span className="col-span-3">نوع کار</span>
            <span className="col-span-2">رنگ</span>
            <span className="col-span-1">تعداد</span>
            <span className="col-span-2">قیمت واحد</span>
            <span className="col-span-1">جمع</span>
            <span className="col-span-1">حذف</span>
          </div>
          {draft.items.map((item) => (
            <ItemRow key={item.id} item={item} onChange={(partial) => updateItem(item.id, partial)} onRemove={() => removeItem(item.id)} />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">هنوز ردیفی نیست. برگرد و دندان انتخاب کن، یا یک خدمت بدون شماره دندان اضافه کن.</div>
      )}

      <div className="mt-4">
        <Button variant="soft" onClick={addService}>
          <Plus className="size-4" />
          افزودن خدمت دیگر
        </Button>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <Field label="تخفیف فاکتور (تومان)">
          <TextInput
            value={draft.discount ? String(draft.discount) : ""}
            inputMode="numeric"
            dir="ltr"
            className="text-left tabular-nums"
            placeholder="0"
            onChange={(event) => {
              const parsed = parseMoney(event.target.value);
              patchDraft({ discount: parsed === "" ? 0 : parsed });
            }}
          />
        </Field>
        <Field label="یادداشت روی فاکتور" hint="(اختیاری)">
          <TextInput value={draft.invoiceNotes} placeholder="مثلاً زمان تحویل" onChange={(event) => patchDraft({ invoiceNotes: event.target.value })} />
        </Field>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        <Total label="جمع خدمات" value={faNum(sum.subtotal)} />
        <Total label="تخفیف" value={faNum(sum.discount)} />
        <Total label="قابل پرداخت" value={faNum(sum.total)} strong />
      </div>
      {missingPrice ? <p className="mt-3 text-xs text-muted">بعضی ردیف‌ها هنوز قیمت ندارند و در فاکتور با خط تیره می‌آیند.</p> : null}

      <div className="mt-6 flex items-center justify-between gap-3 border-t border-line pt-4">
        <Button onClick={() => goTo(2)}>بازگشت</Button>
        <Button
          variant="primary"
          onClick={() => {
            if (!draft.items.length) {
              toast.error("حداقل یک خدمت یا دندان اضافه کن.");
              return;
            }
            goTo(4);
            if (missingPrice) toast("بعضی ردیف‌ها هنوز قیمت ندارند.");
          }}
        >
          ادامه: پیش‌نمایش فاکتور
        </Button>
      </div>
    </Panel>
  );
}

function Total({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={cn("rounded-2xl border border-line px-3 py-2", strong && "border-primary bg-primary-soft")}>
      <p className="text-xs text-muted">{label}</p>
      <p className="text-lg font-extrabold tabular-nums" dir="ltr">{value}</p>
    </div>
  );
}

function ItemRow({ item, onChange, onRemove }: { item: LineItem; onChange: (partial: Partial<LineItem>) => void; onRemove: () => void }) {
  const shades = item.shade && !SHADES.includes(item.shade) ? [item.shade, ...SHADES] : SHADES;
  return (
    <div className="grid gap-3 rounded-2xl border border-line p-3 md:grid-cols-12 md:items-start md:rounded-none md:border-x-0 md:border-t-0 md:px-1">
      <label className="md:col-span-2">
        <span className="mb-1 block text-xs font-bold text-muted md:sr-only">دندان</span>
        <SelectInput value={item.tooth ?? ""} onChange={(event) => onChange({ tooth: event.target.value ? Number(event.target.value) : null })}>
          <option value="">—</option>
          {TOOTH_ORDER.map((tooth) => (
            <option key={tooth} value={tooth}>{tooth}</option>
          ))}
        </SelectInput>
      </label>
      <div className="flex flex-col gap-2 md:col-span-3">
        <SelectInput value={item.type} aria-label="نوع کار" onChange={(event) => onChange({ type: event.target.value as LineItem["type"] })}>
          {WORK_TYPES.map((type) => (
            <option key={type.id} value={type.id}>{type.label}</option>
          ))}
        </SelectInput>
        <TextInput value={item.description} placeholder="توضیح دلخواه" aria-label="توضیح خدمت" onChange={(event) => onChange({ description: event.target.value })} />
      </div>
      <label className="md:col-span-2">
        <span className="mb-1 block text-xs font-bold text-muted md:sr-only">رنگ</span>
        <SelectInput value={item.shade} onChange={(event) => onChange({ shade: event.target.value })}>
          <option value="">انتخاب رنگ</option>
          {shades.map((shade) => (
            <option key={shade} value={shade}>{shade}</option>
          ))}
        </SelectInput>
      </label>
      <label className="md:col-span-1">
        <span className="mb-1 block text-xs font-bold text-muted md:sr-only">تعداد</span>
        <TextInput
          value={String(item.qty)}
          inputMode="numeric"
          dir="ltr"
          className="text-center tabular-nums"
          aria-label="تعداد"
          onChange={(event) => onChange({ qty: parseQty(event.target.value) })}
        />
      </label>
      <label className="md:col-span-2">
        <span className="mb-1 block text-xs font-bold text-muted md:sr-only">قیمت واحد</span>
        <TextInput
          value={moneyText(item.price)}
          inputMode="numeric"
          dir="ltr"
          className="text-left tabular-nums"
          placeholder="تومان"
          aria-label="قیمت واحد"
          onWheel={(event) => event.currentTarget.blur()}
          onChange={(event) => onChange({ price: parseMoney(event.target.value) })}
        />
      </label>
      <div className="md:col-span-1">
        <p className="text-xs text-muted md:sr-only">جمع</p>
        <p className="flex h-11 items-center text-sm font-extrabold tabular-nums" dir="ltr">{item.price === "" ? "—" : faNum(lineAmount(item))}</p>
      </div>
      <div className="md:col-span-1">
        <Button variant="danger" className="w-full px-0 md:w-11" aria-label="حذف ردیف" onClick={onRemove}>
          <Trash2 className="size-4" />
        </Button>
      </div>
    </div>
  );
}

export function StageReview() {
  const draft = useInvoiceStore((state) => state.draft);
  const invoices = useInvoiceStore((state) => state.invoices);
  const doctor = useInvoiceStore((state) => state.doctors.find((item) => item.id === draft.doctorId) ?? null);
  const patchDraft = useInvoiceStore((state) => state.patchDraft);
  const saveCurrent = useInvoiceStore((state) => state.saveCurrent);
  const startNew = useInvoiceStore((state) => state.startNew);
  const goTo = useInvoiceStore((state) => state.goTo);
  const usePaymentAsDefault = useInvoiceStore((state) => state.usePaymentAsDefault);
  const sum = totals(draft.items, draft.discount);
  const [confirmNew, setConfirmNew] = useState(false);
  const saved = useMemo(() => invoices.find((invoice) => invoice.savedId && invoice.savedId === draft.savedId), [invoices, draft.savedId]);

  return (
    <Panel
      eyebrow="مرحله ۴ از ۴"
      title="بررسی، ذخیره و چاپ"
      text="پیش‌نمایش پایین همان چیزی است که روی برگه A4 چاپ می‌شود. اول ذخیره کن، بعد چاپ."
      aside={<span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink">آماده چاپ</span>}
    >
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="rounded-2xl border border-line p-4">
          <h3 className="font-extrabold">خلاصه سفارش</h3>
          <dl className="mt-3 grid gap-3 sm:grid-cols-2">
            <Summary label="بیمار" value={draft.patientName || "—"} />
            <Summary label="پزشک" value={doctor?.name || "—"} />
            <Summary label="تاریخ" value={draft.date || "—"} />
            <Summary label="شماره" value={draft.invoiceNo || "—"} />
            <Summary label="دندان‌ها" value={draft.selectedTeeth.length ? draft.selectedTeeth.join("، ") : "بدون شماره"} />
            <Summary label="مبلغ نهایی" value={`${faNum(sum.total)} تومان`} />
          </dl>
          {draft.imageData ? <img src={draft.imageData} alt="تصویر همراه سفارش" className="mt-4 h-28 rounded-xl object-cover" /> : null}
          <p className="mt-4 text-xs text-pretty text-muted">اطلاعات فقط روی همین دستگاه می‌ماند. برای جابه‌جایی، از دکمه پشتیبان فایل JSON بگیر.</p>
        </div>
        <div className="rounded-2xl border border-line p-4">
          <h3 className="mb-3 font-extrabold">عملیات</h3>
          <div className="flex flex-col gap-3">
            <Field label="شماره کارت لابراتوار">
              <TextInput value={draft.labCardNumber} dir="ltr" className="text-left" placeholder="شماره کارت" onChange={(event) => patchDraft({ labCardNumber: event.target.value })} />
            </Field>
            <Field label="شماره شبا">
              <TextInput value={draft.labShebaNumber} dir="ltr" className="text-left" placeholder="IR..." onChange={(event) => patchDraft({ labShebaNumber: event.target.value })} />
            </Field>
            <Button
              onClick={() => {
                usePaymentAsDefault();
                toast.success("شماره کارت و شبا برای فاکتورهای بعدی پیش‌فرض شد.");
              }}
            >
              ثبت به عنوان پیش‌فرض پرداخت
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                const result = saveCurrent();
                if (!result.ok) toast.error(result.reason);
                else toast.success(`فاکتور ${result.invoiceNo} ذخیره شد.`);
              }}
            >
              ذخیره فاکتور
            </Button>
            <Button variant="primary" onClick={() => window.print()}>
              <Printer className="size-4" />
              چاپ یا ذخیره PDF
            </Button>
            <Button onClick={() => goTo(3)}>ویرایش قیمت‌ها</Button>
            <Button
              onClick={() => {
                const dirty = isMeaningfulDraft(draft) && (!saved || !sameInvoice(saved, draft));
                if (dirty) setConfirmNew(true);
                else startNew();
              }}
            >
              فاکتور جدید
            </Button>
            <p className="text-xs text-muted">{draft.savedId ? `این فاکتور ذخیره شده: ${draft.invoiceNo}` : "هنوز ذخیره نشده است."}</p>
            {draft.labCardNumber ? <p className="text-xs text-muted" dir="ltr">{formatPayId(draft.labCardNumber)}</p> : null}
          </div>
        </div>
      </div>
      <div className="mt-6">
        <Button onClick={() => goTo(3)}>بازگشت به قیمت‌ها</Button>
      </div>
      <ConfirmDialog
        open={confirmNew}
        title="فاکتور جدید"
        body="تغییرهای ذخیره‌نشده این فاکتور کنار گذاشته شود؟"
        confirmLabel="کنار گذاشتن"
        onOpenChange={setConfirmNew}
        onConfirm={startNew}
      />
    </Panel>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="font-bold break-words">{value}</dd>
    </div>
  );
}

export function ArchiveView() {
  const invoices = useInvoiceStore((state) => state.invoices);
  const doctors = useInvoiceStore((state) => state.doctors);
  const loadInvoice = useInvoiceStore((state) => state.loadInvoice);
  const deleteInvoice = useInvoiceStore((state) => state.deleteInvoice);
  const closeArchive = useInvoiceStore((state) => state.closeArchive);
  const [query, setQuery] = useState("");
  const [pendingId, setPendingId] = useState<string | null>(null);
  const filtered = invoices.filter((invoice) => {
    const doctor = doctors.find((item) => item.id === invoice.doctorId);
    const hay = `${invoice.patientName} ${invoice.invoiceNo} ${invoice.patientPhone} ${doctor?.name ?? ""}`.toLocaleLowerCase("fa");
    return hay.includes(query.trim().toLocaleLowerCase("fa"));
  });

  return (
    <Panel eyebrow="بایگانی" title="فاکتورهای ذخیره‌شده" text="هر ردیف یک فاکتور جدا برای یک بیمار است. جستجو روی نام، شماره و پزشک کار می‌کند." aside={<Button onClick={closeArchive}>بازگشت به فاکتور</Button>}>
      <TextInput value={query} onChange={(event) => setQuery(event.target.value)} placeholder="جستجوی بیمار، پزشک یا شماره فاکتور" />
      <div className="mt-4 flex flex-col gap-3">
        {filtered.length ? filtered.map((invoice) => {
          const doctor = doctors.find((item) => item.id === invoice.doctorId);
          const sum = totals(invoice.items, invoice.discount);
          return (
            <article key={invoice.savedId} className="flex flex-col gap-3 rounded-2xl border border-line p-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex min-w-0 items-center gap-3">
                {invoice.imageData ? <img src={invoice.imageData} alt="" className="size-14 rounded-lg object-cover" /> : null}
                <div className="min-w-0">
                  <h3 className="font-extrabold">{invoice.patientName || "بدون نام"} <span className="text-xs font-bold text-muted">{invoice.invoiceNo}</span></h3>
                  <p className="text-xs text-muted">پزشک: {doctor?.name || "—"} · {invoice.date || "—"} · {faNum(sum.total)} تومان</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => loadInvoice(invoice.savedId || "", false)}>مشاهده / چاپ</Button>
                <Button onClick={() => loadInvoice(invoice.savedId || "", true)}>ویرایش</Button>
                <Button variant="danger" onClick={() => setPendingId(invoice.savedId)}>حذف</Button>
              </div>
            </article>
          );
        }) : <div className="rounded-2xl border border-dashed border-line px-4 py-10 text-center text-sm text-muted">{invoices.length ? "چیزی با این جستجو پیدا نشد." : "هنوز فاکتوری ذخیره نشده است."}</div>}
      </div>
      <ConfirmDialog
        open={pendingId != null}
        title="حذف فاکتور"
        body="این فاکتور از حافظه همین مرورگر پاک شود؟"
        confirmLabel="حذف"
        onOpenChange={(open) => {
          if (!open) setPendingId(null);
        }}
        onConfirm={() => {
          if (pendingId) deleteInvoice(pendingId);
          toast.success("فاکتور حذف شد.");
        }}
      />
    </Panel>
  );
}
