import { LOWER_TEETH, UPPER_TEETH } from "@/lib/invoice/model";
import { cn } from "@/lib/utils";

const SLOT = 46;
const MID_GAP = 26;
const WIDTH = 820;
const LEFT = (WIDTH - (15 * SLOT + MID_GAP)) / 2;

function point(index: number, which: "upper" | "lower") {
  const x = LEFT + index * SLOT + (index >= 8 ? MID_GAP : 0);
  const t = index / 15;
  const bow = Math.sin(Math.PI * t);
  const y = which === "upper" ? 92 + bow * 112 : 438 - bow * 112;
  const fan = (t - 0.5) * 46;
  const rot = which === "upper" ? fan : 180 + fan;
  return { x, y, rot };
}

function kindOf(num: number): "molar" | "premolar" | "canine" | "incisor" {
  const digit = num % 10;
  if (digit >= 6) return "molar";
  if (digit >= 4) return "premolar";
  if (digit === 3) return "canine";
  return "incisor";
}

function Shape({ kind }: { kind: ReturnType<typeof kindOf> }) {
  if (kind === "molar") {
    return (
      <g>
        <rect className="tooth-face" x="-16" y="-18" width="32" height="36" rx="8" />
        <path className="tooth-groove" d="M -7 -8 L 7 8 M 7 -8 L -7 8" />
      </g>
    );
  }
  if (kind === "premolar") {
    return (
      <g>
        <rect className="tooth-face" x="-12" y="-16" width="24" height="32" rx="8" />
        <path className="tooth-groove" d="M 0 -10 L 0 10" />
      </g>
    );
  }
  if (kind === "canine") {
    return (
      <g>
        <path className="tooth-face" d="M 0 -18 C 10 -16 12 -4 9 16 C 6 18 -6 18 -9 16 C -12 -4 -10 -16 0 -18 Z" />
        <path className="tooth-groove" d="M 0 -8 L 0 10" />
      </g>
    );
  }
  return (
    <g>
      <rect className="tooth-face" x="-8" y="-16" width="16" height="32" rx="6" />
      <path className="tooth-groove" d="M -5 0 L 5 0" />
    </g>
  );
}

function Arch({
  which,
  teeth,
  selected,
  onToggle,
}: {
  which: "upper" | "lower";
  teeth: number[];
  selected: number[];
  onToggle: (tooth: number) => void;
}) {
  return (
    <>
      {teeth.map((num, index) => {
        const { x, y, rot } = point(index, which);
        const on = selected.includes(num);
        return (
          <g
            key={num}
            className={cn("tooth", on && "is-on")}
            transform={`translate(${x} ${y})`}
            tabIndex={0}
            role="button"
            aria-pressed={on}
            aria-label={`دندان ${num}`}
            onClick={() => onToggle(num)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onToggle(num);
              }
            }}
          >
            <g transform={`rotate(${rot})`}>
              <rect x="-20" y="-24" width="40" height="48" fill="transparent" />
              <Shape kind={kindOf(num)} />
            </g>
            <text className="tooth-label" y={which === "upper" ? -30 : 36} textAnchor="middle">
              {num}
            </text>
          </g>
        );
      })}
    </>
  );
}

export function Odontogram({ selected, onToggle }: { selected: number[]; onToggle: (tooth: number) => void }) {
  return (
    <div className="min-w-0 max-w-full overflow-x-auto rounded-2xl border border-line bg-canvas" dir="ltr">
      <svg width={WIDTH} height="520" viewBox={`0 0 ${WIDTH} 520`} role="group" aria-label="نمودار دندان‌ها" className="block touch-manipulation">
        <line x1="410" y1="28" x2="410" y2="214" stroke="var(--color-line)" strokeDasharray="3 6" />
        <line x1="410" y1="318" x2="410" y2="492" stroke="var(--color-line)" strokeDasharray="3 6" />
        <text className="arch-label" x="410" y="252" textAnchor="middle" style={{ direction: "rtl" }}>
          فک بالا
        </text>
        <text className="arch-label" x="410" y="286" textAnchor="middle" style={{ direction: "rtl" }}>
          فک پایین
        </text>
        <Arch which="upper" teeth={UPPER_TEETH} selected={selected} onToggle={onToggle} />
        <Arch which="lower" teeth={LOWER_TEETH} selected={selected} onToggle={onToggle} />
      </svg>
    </div>
  );
}
