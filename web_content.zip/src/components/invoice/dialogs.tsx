import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { DOCTOR_COLORS } from "@/lib/invoice/model";
import { useInvoiceStore } from "@/lib/invoice/store";
import { Button, Field, TextInput } from "@/components/invoice/ui";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function Modal({
  open,
  onOpenChange,
  title,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="no-print fixed inset-0 z-40 bg-ink/40" />
        <Dialog.Content className="no-print fixed inset-x-4 top-16 z-50 mx-auto max-h-[80vh] max-w-xl overflow-y-auto rounded-3xl border border-line bg-surface p-5 shadow-xl">
          <div className="mb-4 flex items-center justify-between gap-3">
            <Dialog.Title className="text-lg font-extrabold">{title}</Dialog.Title>
            <Dialog.Close className="grid size-11 place-items-center rounded-xl bg-canvas" aria-label="بستن">
              <X className="size-5" />
            </Dialog.Close>
          </div>
          {children}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

export function DoctorDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const addDoctor = useInvoiceStore((state) => state.addDoctor);
  const [name, setName] = useState("");
  const [color, setColor] = useState<string>(DOCTOR_COLORS[0]);
  const [error, setError] = useState("");

  function save() {
    const result = addDoctor(name, color);
    if (!result.ok) {
      setError(result.reason);
      return;
    }
    setName("");
    setColor(DOCTOR_COLORS[0]);
    setError("");
    onOpenChange(false);
    toast.success(result.existed ? "این پزشک قبلاً ثبت شده بود و انتخاب شد." : "پزشک جدید ذخیره شد.");
  }

  return (
    <Modal
      open={open}
      title="ثبت پزشک جدید"
      onOpenChange={(next) => {
        if (!next) setError("");
        onOpenChange(next);
      }}
    >
      <form
        className="flex flex-col gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
      >
        <Field label="نام پزشک" required>
          <TextInput value={name} onChange={(event) => setName(event.target.value)} placeholder="نام و نام خانوادگی پزشک" autoComplete="off" />
        </Field>
        <div>
          <p className="mb-2 text-sm font-bold">رنگ نوار فاکتور این پزشک</p>
          <div className="flex flex-wrap gap-2">
            {DOCTOR_COLORS.map((swatch) => (
              <button
                key={swatch}
                type="button"
                aria-label={`رنگ ${swatch}`}
                aria-pressed={color === swatch}
                onClick={() => setColor(swatch)}
                className={cn("size-9 rounded-full", color === swatch && "ring-2 ring-ink ring-offset-2")}
                style={{ backgroundColor: swatch }}
              />
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">رنگ فقط روی فاکتورهای همین پزشک می‌آید و قالب برنامه ثابت می‌ماند.</p>
        </div>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <div className="flex justify-end gap-2">
          <Button type="button" onClick={() => onOpenChange(false)}>
            انصراف
          </Button>
          <Button type="submit" variant="primary">
            ذخیره پزشک
          </Button>
        </div>
      </form>
    </Modal>
  );
}

export function SettingsDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const settings = useInvoiceStore((state) => state.settings);
  const saveSettings = useInvoiceStore((state) => state.saveSettings);
  const [labName, setLabName] = useState(settings.labName);
  const [manager, setManager] = useState(settings.manager);
  const [card, setCard] = useState(settings.card);
  const [sheba, setSheba] = useState(settings.sheba);
  const [defaultNote, setDefaultNote] = useState(settings.defaultNote);

  useEffect(() => {
    if (!open) return;
    setLabName(settings.labName);
    setManager(settings.manager);
    setCard(settings.card);
    setSheba(settings.sheba);
    setDefaultNote(settings.defaultNote);
  }, [open, settings]);

  return (
    <Modal open={open} onOpenChange={onOpenChange} title="تنظیمات لابراتوار">
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(event) => {
          event.preventDefault();
          saveSettings({ labName, manager, card, sheba, defaultNote });
          toast.success("تنظیمات ذخیره شد.");
          onOpenChange(false);
        }}
      >
        <Field label="نام لابراتوار">
          <TextInput value={labName} onChange={(event) => setLabName(event.target.value)} />
        </Field>
        <Field label="نام / امضای مدیریت">
          <TextInput value={manager} onChange={(event) => setManager(event.target.value)} />
        </Field>
        <Field label="شماره کارت">
          <TextInput value={card} onChange={(event) => setCard(event.target.value)} dir="ltr" className="text-left" inputMode="numeric" />
        </Field>
        <Field label="شماره شبا">
          <TextInput value={sheba} onChange={(event) => setSheba(event.target.value)} dir="ltr" className="text-left" placeholder="IR..." />
        </Field>
        <div className="sm:col-span-2">
          <Field label="متن پیش‌فرض پایین فاکتور" hint="(اختیاری)">
            <TextInput value={defaultNote} onChange={(event) => setDefaultNote(event.target.value)} placeholder="با تشکر از اعتماد شما" />
          </Field>
        </div>
        <div className="flex justify-end gap-2 sm:col-span-2">
          <Button type="button" onClick={() => onOpenChange(false)}>
            انصراف
          </Button>
          <Button type="submit" variant="primary">
            ذخیره تنظیمات
          </Button>
        </div>
      </form>
    </Modal>
  );
}

export function ConfirmDialog({
  open,
  title,
  body,
  confirmLabel,
  onConfirm,
  onOpenChange,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Modal open={open} onOpenChange={onOpenChange} title={title}>
      <p className="text-sm text-pretty text-muted">{body}</p>
      <div className="mt-5 flex justify-end gap-2">
        <Button onClick={() => onOpenChange(false)}>انصراف</Button>
        <Button
          variant="danger"
          onClick={() => {
            onConfirm();
            onOpenChange(false);
          }}
        >
          {confirmLabel}
        </Button>
      </div>
    </Modal>
  );
}
