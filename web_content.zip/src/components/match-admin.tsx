"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { removeMatch } from "@/lib/match-repo";
import { clearLocal } from "@/lib/local-store";

/** Deletes a single match (with confirmation). */
export function DeleteMatchButton({ id, title }: { id: string; title: string }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  async function remove() {
    setBusy(true);
    try {
      // Removes the local copy and the cloud copy (when reachable).
      await removeMatch(id);
      router.refresh();
    } finally {
      setBusy(false);
      setConfirming(false);
    }
  }

  if (!confirming) {
    return (
      <button
        onClick={() => setConfirming(true)}
        title={`Delete ${title}`}
        aria-label={`Delete ${title}`}
        className="mc-btn rounded-lg border border-slate-700 px-2.5 py-2 text-sm text-slate-500 hover:border-red-500/60 hover:text-red-400"
      >
        🗑
      </button>
    );
  }

  return (
    <div className="flex gap-1.5">
      <button
        onClick={() => setConfirming(false)}
        className="mc-btn rounded-lg border border-slate-700 px-2.5 py-2 text-xs font-bold text-slate-300"
      >
        Cancel
      </button>
      <button
        onClick={remove}
        disabled={busy}
        className="mc-btn rounded-lg bg-red-600 px-3 py-2 text-xs font-black text-white disabled:opacity-50"
      >
        {busy ? "…" : "Delete"}
      </button>
    </div>
  );
}

/** Danger-zone action that removes every match and resets the app to zero. */
export function ClearAllMatchesButton({ count }: { count: number }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function wipe() {
    setBusy(true);
    try {
      await clearLocal();
      if (process.env.NEXT_PUBLIC_STATIC_EXPORT !== "1") {
        try {
          await fetch("/api/matches?all=1", { method: "DELETE" });
        } catch {
          /* cloud unreachable — local data is already cleared */
        }
      }
      setOpen(false);
      setText("");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        disabled={count === 0}
        className="mc-btn rounded-lg border border-red-500/50 bg-red-500/10 px-3 py-2 text-xs font-black text-red-300 hover:bg-red-500/20 disabled:opacity-40"
      >
        Clear All Matches
      </button>

      {open && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/75 p-4">
          <div className="mc-pop mc-card w-full max-w-md px-5 py-5">
            <h3 className="text-lg font-black uppercase tracking-wide text-red-400">
              Delete all matches
            </h3>
            <p className="mt-2 text-sm text-slate-300">
              This permanently removes <span className="font-black text-white">{count}</span>{" "}
              {count === 1 ? "match" : "matches"} — including every ball, scorecard, player
              statistic, commentary line and award. This cannot be undone.
            </p>
            <p className="mt-3 text-xs font-bold uppercase tracking-wider text-slate-400">
              Type <span className="text-red-400">DELETE</span> to confirm
            </p>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="DELETE"
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm outline-none focus:border-red-500"
            />
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => {
                  setOpen(false);
                  setText("");
                }}
                className="mc-btn flex-1 rounded-xl border border-slate-700 py-3 font-bold"
              >
                Cancel
              </button>
              <button
                onClick={wipe}
                disabled={text.trim().toUpperCase() !== "DELETE" || busy}
                className="mc-btn flex-1 rounded-xl bg-red-600 py-3 font-black text-white disabled:opacity-40"
              >
                {busy ? "Deleting…" : "Delete everything"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
