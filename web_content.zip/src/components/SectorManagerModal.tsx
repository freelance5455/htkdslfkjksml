import React, { useState } from 'react';
import {
  X,
  Plus,
  Layers,
  Trash2,
  Check,
  FolderKanban,
  AlertCircle
} from 'lucide-react';
import { Sector, MetricFieldDef } from '../types/report';
import { SectorIcon } from './SectorIcon';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  sectors: Sector[];
  onSaveSectors: (updatedSectors: Sector[]) => void;
}

export const SectorManagerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  sectors,
  onSaveSectors
}) => {
  if (!isOpen) return null;

  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newSectorName, setNewSectorName] = useState('');
  const [newShortCode, setNewShortCode] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newIconName, setNewIconName] = useState('Cog');
  const [metricFields, setMetricFields] = useState<MetricFieldDef[]>([
    { key: 'parametro1', label: 'Parametro Principale', type: 'number', unit: 'unità', defaultValue: 0 }
  ]);
  const [errorMsg, setErrorMsg] = useState('');

  const availableIcons = [
    'Factory',
    'Wrench',
    'ShieldAlert',
    'PackageCheck',
    'CheckCircle2',
    'Briefcase',
    'Cpu',
    'Truck',
    'HardHat',
    'Cog',
    'FileCheck'
  ];

  const handleAddField = () => {
    const key = `campo_${Date.now().toString(36).slice(-4)}`;
    setMetricFields([
      ...metricFields,
      { key, label: `Nuovo Parametro ${metricFields.length + 1}`, type: 'number', unit: '' }
    ]);
  };

  const handleRemoveField = (index: number) => {
    setMetricFields(metricFields.filter((_, idx) => idx !== index));
  };

  const handleUpdateField = (index: number, updated: Partial<MetricFieldDef>) => {
    setMetricFields(
      metricFields.map((f, idx) => (idx === index ? { ...f, ...updated } : f))
    );
  };

  const handleCreateSector = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSectorName.trim()) {
      setErrorMsg('Inserisci il nome del settore.');
      return;
    }
    const id = newSectorName.toLowerCase().replace(/[^a-z0-9]/g, '_');
    if (sectors.some((s) => s.id === id)) {
      setErrorMsg('Un settore con questo nome o ID esiste già.');
      return;
    }

    const newSector: Sector = {
      id,
      name: newSectorName.trim(),
      shortCode: newShortCode.trim().toUpperCase() || newSectorName.slice(0, 3).toUpperCase(),
      description: newDescription.trim() || 'Settore aziendale operativo',
      iconName: newIconName,
      badgeColor: 'neutral',
      metricFields,
      isCustom: true
    };

    onSaveSectors([...sectors, newSector]);
    setIsCreatingNew(false);
    setNewSectorName('');
    setNewShortCode('');
    setNewDescription('');
    setErrorMsg('');
  };

  const handleDeleteSector = (sectorId: string) => {
    if (window.confirm('Rimuovere questo settore? I report esistenti non verranno cancellati.')) {
      onSaveSectors(sectors.filter((s) => s.id !== sectorId));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-xl border border-neutral-200 w-full max-w-3xl max-h-[88vh] flex flex-col overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-50">
          <div className="flex items-center gap-2.5">
            <FolderKanban className="w-5 h-5 text-neutral-800" />
            <div>
              <h2 className="text-base font-bold text-neutral-900">
                Gestione Settori Aziendali & Modelli Schede
              </h2>
              <p className="text-xs text-neutral-500">
                Configura i reparti e personalizza i campi metrici di reportistica
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* New Sector Form */}
          {isCreatingNew ? (
            <form onSubmit={handleCreateSector} className="p-5 bg-neutral-50 border border-neutral-300 rounded-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                  Crea Nuovo Settore Operativo
                </h3>
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="text-xs text-neutral-500 hover:text-neutral-900 underline"
                >
                  Annulla
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-medium text-neutral-700 mb-1">
                    Nome Settore / Reparto <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newSectorName}
                    onChange={(e) => setNewSectorName(e.target.value)}
                    placeholder="es. Laboratorio R&D, Impianti Eolici, Facility IT..."
                    className="w-full px-3 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-neutral-700 mb-1">
                    Sigla Breve (3-4 lettere)
                  </label>
                  <input
                    type="text"
                    maxLength={5}
                    value={newShortCode}
                    onChange={(e) => setNewShortCode(e.target.value.toUpperCase())}
                    placeholder="es. RND"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900 font-mono"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-medium text-neutral-700 mb-1">
                    Descrizione Reparto e Obiettivi
                  </label>
                  <input
                    type="text"
                    value={newDescription}
                    onChange={(e) => setNewDescription(e.target.value)}
                    placeholder="es. Ispezione prototipi e collaudi di durabilità"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                </div>
              </div>

              {/* Icon selection */}
              <div>
                <label className="block text-[11px] font-medium text-neutral-700 mb-1.5">
                  Icona Rappresentativa
                </label>
                <div className="flex flex-wrap gap-2">
                  {availableIcons.map((ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() => setNewIconName(ic)}
                      className={`p-2 rounded border flex items-center gap-1.5 text-xs transition-colors ${
                        newIconName === ic
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                      }`}
                    >
                      <SectorIcon name={ic} className="w-3.5 h-3.5" />
                      <span className="text-[10px]">{ic}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Metric Fields definition */}
              <div className="space-y-2 pt-2 border-t border-neutral-200">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-semibold text-neutral-700">
                    Parametri & Metriche di Default per questo Settore
                  </label>
                  <button
                    type="button"
                    onClick={handleAddField}
                    className="text-[11px] text-neutral-900 font-medium hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Aggiungi Parametro</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {metricFields.map((field, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-white p-2 border border-neutral-200 rounded">
                      <input
                        type="text"
                        value={field.label}
                        onChange={(e) => handleUpdateField(idx, { label: e.target.value })}
                        placeholder="Nome parametro (es. Temperatura)"
                        className="flex-1 px-2 py-1 text-xs border border-neutral-300 rounded"
                      />
                      <select
                        value={field.type}
                        onChange={(e) => handleUpdateField(idx, { type: e.target.value as any })}
                        className="px-2 py-1 text-xs border border-neutral-300 rounded"
                      >
                        <option value="number">Numero</option>
                        <option value="text">Testo</option>
                      </select>
                      <input
                        type="text"
                        value={field.unit || ''}
                        onChange={(e) => handleUpdateField(idx, { unit: e.target.value })}
                        placeholder="Unità (€, %, min, °C)"
                        className="w-20 px-2 py-1 text-xs border border-neutral-300 rounded font-mono"
                      />
                      {metricFields.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveField(idx)}
                          className="text-neutral-400 hover:text-rose-600 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="px-3 py-1.5 text-xs text-neutral-600 hover:bg-neutral-100 rounded"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-neutral-900 rounded hover:bg-neutral-800"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Salva Settore</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="flex justify-between items-center">
              <span className="text-xs text-neutral-500">
                {sectors.length} settori attivi configurati
              </span>
              <button
                onClick={() => setIsCreatingNew(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Crea Nuovo Settore</span>
              </button>
            </div>
          )}

          {/* List of Existing Sectors */}
          <div className="space-y-3">
            {sectors.map((sec) => (
              <div
                key={sec.id}
                className="p-4 bg-white border border-neutral-200 rounded-lg flex items-start justify-between gap-4 hover:border-neutral-300 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-neutral-100 flex items-center justify-center text-neutral-700 shrink-0 border border-neutral-200">
                    <SectorIcon name={sec.iconName} className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-neutral-900">{sec.name}</h4>
                      <span className="font-mono text-[11px] text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded tabular-nums">
                        {sec.shortCode}
                      </span>
                      {sec.isCustom && (
                        <span className="text-[10px] text-neutral-500 italic">
                          (Personalizzato)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-500 mt-0.5">{sec.description}</p>
                    
                    {sec.metricFields && sec.metricFields.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {sec.metricFields.map((f) => (
                          <span
                            key={f.key}
                            className="text-[10px] bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded font-mono"
                          >
                            {f.label} {f.unit ? `[${f.unit}]` : ''}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {sec.isCustom && (
                  <button
                    onClick={() => handleDeleteSector(sec.id)}
                    title="Elimina settore personalizzato"
                    className="text-neutral-400 hover:text-rose-600 p-1.5 rounded transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
