import React, { useMemo, useState } from 'react';
import { Award, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { ClanDashboardState, ROLE_LABELS_RU } from '../shared/cocData';
import {
  buildElevenLeaderboards,
  computeClanPlayerRatings,
} from '../utils/clanAnalytics';

interface RankingsViewProps {
  state: ClanDashboardState;
  nowMs?: number;
  onSelectPlayer: (tag: string) => void;
}

export const RankingsView: React.FC<RankingsViewProps> = ({
  state,
  nowMs,
  onSelectPlayer,
}) => {
  const [mode, setMode] = useState<'composite' | 'eleven'>('composite');
  const [expandedTag, setExpandedTag] = useState<string | null>(null);
  const [selectedBoardId, setSelectedBoardId] = useState<string>('all');

  const safeNowMs = nowMs ?? Date.now();

  const ratings = useMemo(
    () => computeClanPlayerRatings(state, safeNowMs),
    [state, safeNowMs]
  );

  const elevenBoards = useMemo(
    () => buildElevenLeaderboards(state, ratings),
    [state, ratings]
  );

  if (!state.clan || state.players.length === 0) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы рассчитать рейтинг участников от 0 до 1000 баллов и 11 специализированных таблиц.
      </div>
    );
  }

  const visibleBoards =
    selectedBoardId === 'all'
      ? elevenBoards
      : elevenBoards.filter((b) => b.id === selectedBoardId);

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Рейтинг участников клана
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Комплексный рейтинг 0–1000 баллов с нормализацией по уровню Ратуши и 11 отдельных таблиц лидеров
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start lg:self-auto">
          <button
            type="button"
            onClick={() => setMode('composite')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              mode === 'composite'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Главный рейтинг (0–1000)
          </button>
          <button
            type="button"
            onClick={() => setMode('eleven')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              mode === 'eleven'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            11 таблиц рейтинга
          </button>
        </div>
      </section>

      {/* Weight Methodology Strip */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-4 space-y-2.5">
        <div className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <span>
            <strong className="text-slate-100">Честный расчёт без выдуманных баллов:</strong> итоговый балл (0–1000) складывается из 6 весовых категорий и нормализуется относительно уровня Ратуши (TH), чтобы игроки младших TH оценивались справедливо. Если данные по КВ, рейдам Столицы или динамике снимков недоступны, баллы не начисляются наугад, а игрок отмечается как{' '}
            <strong className="text-amber-400">Предварительный</strong>.
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] sm:grid-cols-3 lg:grid-cols-6 font-mono">
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Аккаунт</span>
            <span className="text-amber-400 font-semibold">25% (250)</span>
          </div>
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Активность</span>
            <span className="text-emerald-400 font-semibold">20% (200)</span>
          </div>
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Войны</span>
            <span className="text-sky-400 font-semibold">20% (200)</span>
          </div>
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Донаты</span>
            <span className="text-emerald-400 font-semibold">15% (150)</span>
          </div>
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Герои/войска</span>
            <span className="text-slate-200 font-semibold">10% (100)</span>
          </div>
          <div className="rounded border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 flex justify-between">
            <span className="text-slate-400">Столица</span>
            <span className="text-amber-400 font-semibold">10% (100)</span>
          </div>
        </div>
      </section>

      {mode === 'composite' ? (
        <>
          {/* Top 3 Podium */}
          <section className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {ratings.slice(0, 3).map((r, idx) => (
              <button
                key={r.player.tag}
                type="button"
                onClick={() => onSelectPlayer(r.player.tag)}
                className="rounded-lg border border-slate-800 bg-[#121824] p-5 text-left hover:border-amber-500/50 transition-colors"
              >
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="inline-flex items-center gap-1.5 font-mono font-semibold text-amber-400">
                    <Award className="h-4 w-4" />#{idx + 1} место
                  </span>
                  <span className="font-mono">
                    TH{r.player.townHallLevel}
                    {r.isPreliminary ? ' · Предв.' : ''}
                  </span>
                </div>
                <div className="mt-2 truncate font-display text-lg font-bold text-slate-100">
                  {r.player.name}
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  {r.player.tag} · {ROLE_LABELS_RU[r.player.role]}
                </div>
                <div className="mt-4 flex items-baseline justify-between border-t border-slate-800/80 pt-3">
                  <span className="text-xs text-slate-400">Общий балл</span>
                  <span className="font-mono text-2xl font-bold tabular-nums text-amber-400">
                    {r.totalScore}
                    <span className="text-xs font-normal text-slate-500"> / 1000</span>
                  </span>
                </div>
              </button>
            ))}
          </section>

          {/* Full Composite Ranking Table */}
          <section className="rounded-lg border border-slate-800 bg-[#121824]">
            <div className="border-b border-slate-800 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Полная таблица общего рейтинга ({ratings.length})
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                Нажмите на строку для детализации баллов по каждой категории и причин предварительного статуса
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                    <th className="px-4 py-2.5">#</th>
                    <th className="px-4 py-2.5">Игрок</th>
                    <th className="px-2.5 py-2.5 text-right">TH</th>
                    <th className="px-2.5 py-2.5 text-right">Акк. /250</th>
                    <th className="px-2.5 py-2.5 text-right">Акт. /200</th>
                    <th className="px-2.5 py-2.5 text-right">Войны /200</th>
                    <th className="px-2.5 py-2.5 text-right">Донат /150</th>
                    <th className="px-2.5 py-2.5 text-right">Армия /100</th>
                    <th className="px-2.5 py-2.5 text-right">Стол. /100</th>
                    <th className="px-3 py-2.5 text-right">Статус</th>
                    <th className="px-4 py-2.5 text-right">Итого</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {ratings.map((r, idx) => {
                    const isOpen = expandedTag === r.player.tag;
                    const byCat = Object.fromEntries(r.categories.map((c) => [c.id, c]));
                    return (
                      <React.Fragment key={r.player.tag}>
                        <tr
                          onClick={() =>
                            setExpandedTag((cur) => (cur === r.player.tag ? null : r.player.tag))
                          }
                          className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                        >
                          <td className="px-4 py-2.5 font-mono font-semibold tabular-nums text-amber-400">
                            <span className="inline-flex items-center gap-1">
                              #{idx + 1}
                              {isOpen ? (
                                <ChevronUp className="h-3.5 w-3.5 text-slate-500" />
                              ) : (
                                <ChevronDown className="h-3.5 w-3.5 text-slate-500" />
                              )}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 whitespace-nowrap">
                            <div className="font-medium text-slate-100">{r.player.name}</div>
                            <div className="font-mono text-[11px] text-slate-500">
                              {r.player.tag}
                            </div>
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-amber-400">
                            {r.player.townHallLevel}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-slate-200">
                            {byCat.account?.score ?? 0}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                            {byCat.activity?.score ?? 0}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-sky-400">
                            {byCat.wars?.score ?? 0}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                            {byCat.donations?.score ?? 0}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-slate-200">
                            {byCat.heroes_troops?.score ?? 0}
                          </td>
                          <td className="px-2.5 py-2.5 text-right font-mono tabular-nums text-slate-300">
                            {byCat.capital?.score ?? 0}
                          </td>
                          <td className="px-3 py-2.5 text-right text-xs whitespace-nowrap">
                            {r.isPreliminary ? (
                              <span className="text-amber-400">Предварительный</span>
                            ) : (
                              <span className="text-emerald-400">Полный</span>
                            )}
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono font-bold tabular-nums text-amber-400">
                            {r.totalScore}
                          </td>
                        </tr>
                        {isOpen && (
                          <tr className="bg-[#0B0F17]/75">
                            <td colSpan={11} className="px-5 py-4">
                              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                                <div className="text-xs font-semibold text-slate-200">
                                  Детализация рейтинга: {r.player.name} ({r.player.tag})
                                </div>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onSelectPlayer(r.player.tag);
                                  }}
                                  className="rounded-md bg-amber-500 px-3 py-1 text-xs font-semibold text-slate-950 hover:bg-amber-400"
                                >
                                  Открыть профиль игрока
                                </button>
                              </div>

                              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 text-xs">
                                {r.categories.map((cat) => (
                                  <div
                                    key={cat.id}
                                    className="rounded border border-slate-800 bg-[#121824] p-3"
                                  >
                                    <div className="flex items-center justify-between font-medium">
                                      <span className="text-slate-200">
                                        {cat.label} ({cat.weightPct}%)
                                      </span>
                                      <span className="font-mono font-bold text-amber-400">
                                        {cat.score} / {cat.maxPoints}
                                      </span>
                                    </div>
                                    <p className="mt-1 text-[11px] text-slate-400">{cat.note}</p>
                                  </div>
                                ))}
                              </div>

                              {r.missingReasons.length > 0 && (
                                <div className="mt-3 text-xs text-amber-300">
                                  <span className="font-semibold">
                                    Почему статус «Предварительный»:{' '}
                                  </span>
                                  {r.missingReasons.join('; ')}.
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </>
      ) : (
        <div className="space-y-6">
          {/* Board Switcher */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setSelectedBoardId('all')}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedBoardId === 'all'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'bg-[#121824] text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              Все 11 рейтингов
            </button>
            {elevenBoards.map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => setSelectedBoardId(b.id)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  selectedBoardId === b.id
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'bg-[#121824] text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {b.title}
              </button>
            ))}
          </div>

          <section
            className={`grid grid-cols-1 gap-6 ${
              selectedBoardId === 'all' ? 'lg:grid-cols-2' : ''
            }`}
          >
            {visibleBoards.map((board) => {
              const displayRows =
                selectedBoardId === 'all' ? board.rows.slice(0, 10) : board.rows;
              return (
                <div
                  key={board.id}
                  className="rounded-lg border border-slate-800 bg-[#121824] flex flex-col"
                >
                  <div className="flex items-start justify-between gap-3 border-b border-slate-800 px-5 py-4">
                    <div>
                      <h2 className="font-display text-base font-semibold text-slate-100">
                        {board.title}
                      </h2>
                      <p className="mt-0.5 text-xs text-slate-400">{board.subtitle}</p>
                    </div>
                    {selectedBoardId === 'all' && board.rows.length > 10 && (
                      <button
                        type="button"
                        onClick={() => setSelectedBoardId(board.id)}
                        className="text-xs text-amber-400 hover:text-amber-300 whitespace-nowrap shrink-0"
                      >
                        Все ({board.rows.length}) →
                      </button>
                    )}
                  </div>

                  {board.emptyReason || displayRows.length === 0 ? (
                    <div className="p-6 text-xs text-slate-400 leading-relaxed">
                      {board.emptyReason ?? 'Недостаточно данных для построения таблицы.'}
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-800/80 text-slate-400 bg-[#0B0F17]/40">
                            <th className="px-4 py-2">#</th>
                            <th className="px-3 py-2">Игрок</th>
                            <th className="px-3 py-2 text-right">TH</th>
                            <th className="px-4 py-2 text-right">Показатель</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {displayRows.map((row) => (
                            <tr
                              key={`${board.id}-${row.tag}`}
                              onClick={() => onSelectPlayer(row.tag)}
                              className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                            >
                              <td className="px-4 py-2 font-mono font-semibold tabular-nums text-amber-400">
                                #{row.rank}
                              </td>
                              <td className="px-3 py-2 whitespace-nowrap">
                                <span className="font-medium text-slate-100">{row.name}</span>
                                <span className="ml-2 font-mono text-[11px] text-slate-500">
                                  {row.tag}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-300">
                                TH{row.townHallLevel}
                              </td>
                              <td className="px-4 py-2 text-right font-mono tabular-nums whitespace-nowrap">
                                <span className="font-semibold text-emerald-400">
                                  {row.valueText}
                                </span>
                                {row.subText && (
                                  <span className="ml-1.5 text-[11px] text-slate-500">
                                    ({row.subText})
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </section>
        </div>
      )}
    </div>
  );
};
