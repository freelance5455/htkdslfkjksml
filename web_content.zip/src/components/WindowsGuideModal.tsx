import React, { useState } from 'react';
import { X, Copy, Check, Terminal, Laptop, ShieldCheck, Download, HardDrive, PackageCheck } from 'lucide-react';

interface WindowsGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownloadZip: () => void;
}

export const WindowsGuideModal: React.FC<WindowsGuideModalProps> = ({
  isOpen,
  onClose,
  onDownloadZip
}) => {
  if (!isOpen) return null;

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 rounded-lg text-stone-800">
              <Laptop className="w-6 h-6 text-stone-800" />
            </div>
            <div>
              <h2 className="font-serif text-2xl font-semibold text-stone-900">
                Windows Setup & Desktop Application Guide
              </h2>
              <p className="text-xs text-stone-500">
                Complete instructions for running locally, packaging as a desktop app, and offline backups.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="mt-6 space-y-6 text-xs text-stone-700 leading-relaxed">
          {/* Quick Action Banner */}
          <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="font-semibold text-amber-950 text-sm">Download Project Source ZIP</h3>
              <p className="text-amber-800 text-xs mt-0.5">
                Includes all source code, components, Vite config, and an automated <code className="bg-amber-100 px-1 rounded font-mono">RUN_WINDOWS.bat</code> runner.
              </p>
            </div>
            <button
              onClick={onDownloadZip}
              className="px-4 py-2 bg-stone-900 text-white hover:bg-stone-800 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer shrink-0 shadow-2xs"
            >
              <Download className="w-4 h-4" />
              <span>Download ZIP (All Files)</span>
            </button>
          </div>

          {/* Section 1: Running on Windows */}
          <div className="space-y-3">
            <h3 className="font-serif text-base font-semibold text-stone-900 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-stone-700" />
              <span>1. How to Run on Windows (Step-by-Step)</span>
            </h3>

            <div className="space-y-3 pl-2">
              <div className="flex gap-3">
                <span className="font-bold text-stone-900">Step A:</span>
                <div>
                  <p className="font-medium text-stone-800">Install Node.js (Free & Open Source)</p>
                  <p className="text-stone-500 mt-0.5">
                    Download and run the installer for <strong>Node.js LTS</strong> from <a href="https://nodejs.org" target="_blank" rel="noreferrer" className="text-stone-900 underline font-medium">https://nodejs.org</a>. It includes npm automatically.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="font-bold text-stone-900">Step B:</span>
                <div>
                  <p className="font-medium text-stone-800">Extract the ZIP Archive</p>
                  <p className="text-stone-500 mt-0.5">
                    Right-click the downloaded <code className="bg-stone-100 px-1 py-0.5 rounded font-mono">bait-ul-ukasha-home-essentials-source.zip</code> and select <strong>"Extract All..."</strong> to a folder like <code className="bg-stone-100 px-1 py-0.5 rounded font-mono">C:\BaitUlUkasha</code>.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="font-bold text-stone-900">Step C:</span>
                <div className="flex-1">
                  <p className="font-medium text-stone-800">1-Click Launch (Batch Script) or Terminal</p>
                  <p className="text-stone-500 mt-0.5 mb-2">
                    Simply double-click <strong>RUN_WINDOWS.bat</strong>, OR open PowerShell / Command Prompt inside the folder and paste:
                  </p>

                  <div className="bg-stone-900 text-stone-100 p-3 rounded-lg font-mono text-[11px] flex items-center justify-between">
                    <span>npm install && npm run dev</span>
                    <button
                      onClick={() => copyToClipboard('npm install && npm run dev', 'run')}
                      className="text-stone-400 hover:text-white p-1"
                      title="Copy command"
                    >
                      {copiedKey === 'run' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-stone-500 mt-1 text-[11px]">
                    Once running, open your browser to <code className="text-stone-800 font-mono">http://localhost:3000</code>.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Building an Installable Application */}
          <div className="space-y-3 pt-3 border-t border-stone-200">
            <h3 className="font-serif text-base font-semibold text-stone-900 flex items-center gap-2">
              <PackageCheck className="w-4 h-4 text-stone-700" />
              <span>2. How to Build an Installable Windows Desktop App (.exe)</span>
            </h3>

            <div className="space-y-3 pl-2">
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <p className="font-semibold text-stone-900 mb-1">Option A: Native PWA Desktop App (Instant, 0 setup required)</p>
                <p className="text-stone-600 mb-2">
                  When viewing the site in Google Chrome or Microsoft Edge on Windows, look at the right side of the address bar:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-stone-600 text-[11px]">
                  <li>Click the computer icon or <strong>"App available. Install Bait ul Ukasha"</strong>.</li>
                  <li>Click <strong>Install</strong>.</li>
                  <li>The app opens as a standalone desktop window with a Windows taskbar icon and desktop shortcut! It works fully offline without internet.</li>
                </ol>
              </div>

              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <p className="font-semibold text-stone-900 mb-1">Option B: Standalone Windows .exe with Electron</p>
                <p className="text-stone-600 mb-2">
                  To produce an official <code className="bg-stone-200 px-1 py-0.5 rounded font-mono">.exe</code> installer:
                </p>
                <div className="bg-stone-900 text-stone-100 p-2.5 rounded font-mono text-[11px] flex items-center justify-between mb-2">
                  <span>npm install --save-dev electron electron-builder</span>
                  <button
                    onClick={() => copyToClipboard('npm install --save-dev electron electron-builder', 'electron')}
                    className="text-stone-400 hover:text-white p-1"
                  >
                    {copiedKey === 'electron' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-stone-500 text-[11px]">
                  Run <code className="text-stone-800 font-mono">npm run build</code> and <code className="text-stone-800 font-mono">npx electron-builder --win</code> to produce your final Windows installer in the <code className="text-stone-800 font-mono">dist/</code> folder.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Data Backup & Offline Safety */}
          <div className="space-y-3 pt-3 border-t border-stone-200">
            <h3 className="font-serif text-base font-semibold text-stone-900 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-stone-700" />
              <span>3. How to Back Up Files & Local Data</span>
            </h3>

            <div className="space-y-2 pl-2 text-stone-600">
              <p>
                <strong>Source Code Backup:</strong> Keep the downloaded ZIP archive stored on your Windows hard drive, an external USB stick, or a Git repository.
              </p>
              <p>
                <strong>Customer & Order Data Backup:</strong> All your cart items, past orders, reviews, addresses, and room checklists are preserved safely in your browser's local storage. Use the <strong>"Backup Data"</strong> tool in the top navigation to export a <code className="bg-stone-100 px-1 py-0.5 rounded font-mono">.json</code> snapshot anytime.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
          >
            Got It, Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
