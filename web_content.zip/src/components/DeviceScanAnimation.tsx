import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  ShieldCheck,
  Cpu,
  Layers,
  Terminal,
  Key,
  HardDrive,
  Radio,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  Lock,
  Search,
  Hash,
  Database,
  Sliders,
  Check
} from 'lucide-react';
import {
  extractHardwareIdentifiers,
  performEncryptedIntegrityCheck,
  HardwareIdentifiers,
  DeviceIntegrityReport,
  SecurityCheckItem
} from '../lib/deviceSecurityScanner';

interface DeviceScanAnimationProps {
  onScanComplete?: (report: DeviceIntegrityReport) => void;
  autoStart?: boolean;
  compact?: boolean;
  title?: string;
  subtitle?: string;
}

export const DeviceScanAnimation: React.FC<DeviceScanAnimationProps> = ({
  onScanComplete,
  autoStart = true,
  compact = false,
  title = 'Hardware Security & Telemetry Inspection',
  subtitle = 'Scanning IMEI, Model, Manufacturer & Decentralized Storage Integrity'
}) => {
  const [identifiers, setIdentifiers] = useState<HardwareIdentifiers>(() => extractHardwareIdentifiers());
  const [progress, setProgress] = useState<number>(0);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [report, setReport] = useState<DeviceIntegrityReport | null>(null);
  const [stepStatuses, setStepStatuses] = useState<{ [id: string]: 'PENDING' | 'SCANNING' | 'VERIFIED' | 'FAILED' }>({
    imei: 'PENDING',
    manufacturer: 'PENDING',
    model: 'PENDING',
    version: 'PENDING',
    serial: 'PENDING',
    storage_integrity: 'PENDING',
    mesh_consensus: 'PENDING'
  });

  const STEPS: {
    id: 'imei' | 'manufacturer' | 'model' | 'version' | 'serial' | 'storage_integrity' | 'mesh_consensus';
    label: string;
    sublabel: string;
    icon: React.FC<{ className?: string }>;
    value: string;
  }[] = [
    {
      id: 'imei',
      label: 'IMEI Hardware TAC & Luhn Check',
      sublabel: 'Validates 15-digit mobile terminal identifier and carrier signature',
      icon: Smartphone,
      value: identifiers.imei
    },
    {
      id: 'model',
      label: 'Device Model & Architecture',
      sublabel: 'Inspects CPU instruction set, GPU cores, and memory capacity',
      icon: Cpu,
      value: identifiers.model
    },
    {
      id: 'manufacturer',
      label: 'Manufacturer Provenance',
      sublabel: 'Authenticates genuine hardware origin and bootloader authority',
      icon: ShieldCheck,
      value: identifiers.manufacturer
    },
    {
      id: 'version',
      label: 'OS Kernel & Sandbox Version',
      sublabel: 'Verifies native operating system security sandbox privileges',
      icon: Terminal,
      value: identifiers.version
    },
    {
      id: 'serial',
      label: 'Hardware Serial & Product Key',
      sublabel: 'Confirms sovereign cryptographic 25-character product allocation',
      icon: Key,
      value: `${identifiers.serialNumber} (${identifiers.productKey})`
    },
    {
      id: 'storage_integrity',
      label: 'Decentralized Storage Merkle Root',
      sublabel: 'Cryptographic hash check against local self-custodial storage',
      icon: HardDrive,
      value: 'Merkle Root 0x777A...F92B (Pristine)'
    },
    {
      id: 'mesh_consensus',
      label: '50M Peer Swarm Consensus',
      sublabel: 'Zero-cloning verification across global decentralized user devices',
      icon: Radio,
      value: '50,000,000 Nodes Verified Unanimous'
    }
  ];

  const startScan = async () => {
    setIsScanning(true);
    setProgress(0);
    setCurrentStepIndex(0);
    setReport(null);

    // Refresh telemetry
    const currentId = extractHardwareIdentifiers();
    setIdentifiers(currentId);

    const initialStatuses: { [id: string]: 'PENDING' | 'SCANNING' | 'VERIFIED' | 'FAILED' } = {};
    STEPS.forEach(s => { initialStatuses[s.id] = 'PENDING'; });
    setStepStatuses(initialStatuses);

    // Sequential step verification animation
    for (let i = 0; i < STEPS.length; i++) {
      const step = STEPS[i];
      setCurrentStepIndex(i);

      // Mark scanning
      setStepStatuses(prev => ({ ...prev, [step.id]: 'SCANNING' }));
      setProgress(Math.round(((i + 0.4) / STEPS.length) * 100));

      // Wait for simulated deep hardware inspection duration
      await new Promise(r => setTimeout(r, 450));

      // Mark verified
      setStepStatuses(prev => ({ ...prev, [step.id]: 'VERIFIED' }));
      setProgress(Math.round(((i + 1) / STEPS.length) * 100));
      await new Promise(r => setTimeout(r, 120));
    }

    // Complete encrypted integrity report
    const fullReport = await performEncryptedIntegrityCheck(currentId);
    setReport(fullReport);
    setIsScanning(false);
    setProgress(100);

    if (onScanComplete) {
      onScanComplete(fullReport);
    }
  };

  useEffect(() => {
    if (autoStart) {
      startScan();
    }
  }, [autoStart]);

  return (
    <div className={`w-full bg-slate-950/90 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl backdrop-blur-xl ${compact ? 'text-xs' : 'text-sm'}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="font-bold text-white font-serif tracking-wide sm:text-base">
              {title}
            </h3>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            {subtitle}
          </p>
        </div>

        <div className="flex items-center space-x-3 self-end sm:self-auto">
          <div className="px-3 py-1 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold flex items-center space-x-1.5">
            {isScanning ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>{isScanning ? `INSPECTING ${progress}%` : progress === 100 ? 'AUTHENTICATED' : 'READY'}</span>
          </div>

          <button
            onClick={startScan}
            disabled={isScanning}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 hover:border-slate-600 transition-all cursor-pointer disabled:opacity-40"
            title="Re-run deep hardware scan"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Progress Bar with glowing pulse */}
      <div className="mt-4 space-y-1.5">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-slate-400">
            {isScanning
              ? `Inspecting: ${STEPS[currentStepIndex]?.label || 'Analyzing System...'}`
              : progress === 100
              ? '✓ All 7 Hardware Telemetry Specifications Cryptographically Verified'
              : 'Standby for Hardware Telemetry Verification'}
          </span>
          <span className="text-emerald-400 font-bold">{progress}%</span>
        </div>

        <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 shadow-[0_0_12px_rgba(52,211,153,0.8)]"
            initial={{ width: '0%' }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: 'easeOut', duration: 0.3 }}
          />
        </div>
      </div>

      {/* Visual Step-by-Step Status Grid */}
      <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-2.5">
        {STEPS.map((step, idx) => {
          const Icon = step.icon;
          const status = stepStatuses[step.id];
          const isCurrent = isScanning && currentStepIndex === idx;

          return (
            <div
              key={step.id}
              className={`p-3 rounded-2xl border transition-all duration-200 flex items-start space-x-3 ${
                isCurrent
                  ? 'bg-slate-900/95 border-emerald-400/80 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-400/50'
                  : status === 'VERIFIED'
                  ? 'bg-slate-900/70 border-emerald-500/30'
                  : 'bg-slate-900/40 border-slate-800/80 opacity-60'
              }`}
            >
              {/* Status Icon */}
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border transition-colors ${
                  status === 'VERIFIED'
                    ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-300'
                    : isCurrent
                    ? 'bg-amber-500/20 border-amber-400/60 text-amber-300 animate-pulse'
                    : 'bg-slate-800 border-slate-700 text-slate-500'
                }`}
              >
                {status === 'VERIFIED' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : isCurrent ? (
                  <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
                ) : (
                  <Icon className="w-4 h-4 text-slate-400" />
                )}
              </div>

              {/* Step info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white font-mono truncate">
                    {step.label}
                  </span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                      status === 'VERIFIED'
                        ? 'text-emerald-400'
                        : isCurrent
                        ? 'text-amber-400 animate-pulse'
                        : 'text-slate-500'
                    }`}
                  >
                    {status === 'VERIFIED' ? 'VERIFIED' : isCurrent ? 'SCANNING...' : 'PENDING'}
                  </span>
                </div>

                <div className="text-[11px] font-mono text-emerald-300/90 truncate font-semibold mt-0.5">
                  {step.value}
                </div>

                <div className="text-[10px] text-slate-400 truncate mt-0.5">
                  {step.sublabel}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Verified Hardware Cryptographic Proof Footer */}
      {report && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-5 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-100 space-y-2.5 font-mono text-xs"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-500/20 pb-2">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-bold text-emerald-300">
                Device Authorization Integrity Certificate: PASSED (100%)
              </span>
            </div>
            <span className="text-[10px] text-slate-400">
              Anchored to 50,000,000 Peer Mesh
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
            <div>
              <span className="text-slate-500">Device Fingerprint: </span>
              <span className="text-amber-300 font-bold font-mono">
                {report.identifiers.hardwareFingerprintSha256.slice(0, 20)}...
              </span>
            </div>
            <div>
              <span className="text-slate-500">Decentralized Storage Root: </span>
              <span className="text-cyan-300 font-bold font-mono">
                0x{report.networkStorageMerkleRoot.slice(0, 16)}...
              </span>
            </div>
          </div>

          <p className="text-[11px] text-emerald-200/90 pt-1 leading-relaxed">
            {report.verdictMessage}
          </p>
        </motion.div>
      )}
    </div>
  );
};
