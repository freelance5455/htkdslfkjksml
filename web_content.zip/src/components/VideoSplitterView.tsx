import React, { useState, useEffect, useRef } from 'react';
import {
  Scissors, Play, Pause, Download, FolderArchive, Sparkles,
  Clock, CheckCircle, AlertCircle, RefreshCw, Layers, Film
} from 'lucide-react';
import { VideoProject, VideoSegment } from '../types/project';
import { calculateVideoSegments, formatTime, SplitMode, estimateFileSizeMB } from '../utils/videoMath';
import { exportVideoSegment, exportAllSegments, ExportProgress } from '../utils/videoExporter';

interface VideoSplitterViewProps {
  project: VideoProject;
  onUpdateProject: (updated: Partial<VideoProject>) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  lang: 'ar' | 'en';
}

export const VideoSplitterView: React.FC<VideoSplitterViewProps> = ({
  project,
  onUpdateProject,
  videoRef,
  lang
}) => {
  const [splitMode, setSplitMode] = useState<SplitMode>(project.splitSettings?.mode || 'duration');
  const [splitDuration, setSplitDuration] = useState<number>(project.splitSettings?.value || 40);
  const [customDurationInput, setCustomDurationInput] = useState<string>('40');
  const [partsCount, setPartsCount] = useState<number>(4);
  const [segments, setSegments] = useState<VideoSegment[]>([]);

  const [activePreviewIndex, setActivePreviewIndex] = useState<number | null>(null);
  const [isPlayingClip, setIsPlayingClip] = useState(false);

  // Export states
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<ExportProgress | null>(null);
  const [exportSuccessMessage, setExportSuccessMessage] = useState<string | null>(null);
  const [resolution, setResolution] = useState<'480p' | '720p' | '1080p'>('720p');

  const presetDurations = [10, 15, 20, 30, 40, 50, 60];

  // Recalculate segments whenever mode, value, or project duration changes
  useEffect(() => {
    const dur = project.duration || 60;
    const value = splitMode === 'duration' ? splitDuration : partsCount;
    const segs = calculateVideoSegments(dur, splitMode, value);
    setSegments(segs);

    onUpdateProject({
      splitSettings: { mode: splitMode, value }
    });
  }, [project.duration, splitMode, splitDuration, partsCount]);

  // Handle clip preview playback
  const handlePreviewClip = (seg: VideoSegment) => {
    const video = videoRef.current;
    if (!video) return;

    setActivePreviewIndex(seg.index);
    video.currentTime = seg.startTime;
    video.play().catch(() => {});
    setIsPlayingClip(true);

    const onTimeUpdate = () => {
      if (video.currentTime >= seg.endTime) {
        video.pause();
        video.currentTime = seg.startTime;
        setIsPlayingClip(false);
        video.removeEventListener('timeupdate', onTimeUpdate);
      }
    };

    video.addEventListener('timeupdate', onTimeUpdate);
  };

  const handleStopPreview = () => {
    const video = videoRef.current;
    if (video) {
      video.pause();
    }
    setIsPlayingClip(false);
  };

  // Export single clip
  const handleExportSingleClip = async (seg: VideoSegment) => {
    const video = videoRef.current;
    if (!video) return;

    setIsExporting(true);
    setExportProgress({
      currentClipIndex: 1,
      totalClips: 1,
      progressPercent: 0,
      message: `جاري تجهيز وتصدير ${seg.title}...`
    });

    try {
      const blob = await exportVideoSegment(
        video,
        project,
        seg.startTime,
        seg.endTime,
        resolution,
        (pct) => {
          setExportProgress({
            currentClipIndex: 1,
            totalClips: 1,
            progressPercent: pct,
            message: `معالجة ${seg.title}: ${pct}%`
          });
        }
      );

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Designo_${project.name}_Part_${seg.index}.webm`;
      a.click();

      setExportSuccessMessage(`تم تصدير وحفظ المقطع ${seg.index} بنجاح!`);
      setTimeout(() => setExportSuccessMessage(null), 5000);
    } catch (err: any) {
      console.error('Export error:', err);
      alert('فشل تصدير المقطع: ' + err?.message);
    } finally {
      setIsExporting(false);
      setExportProgress(null);
    }
  };

  // Export all clips as ZIP
  const handleExportAllZip = async () => {
    const video = videoRef.current;
    if (!video || segments.length === 0) return;

    setIsExporting(true);
    try {
      const { zipBlob } = await exportAllSegments(
        video,
        project,
        segments,
        resolution,
        true,
        (prog) => setExportProgress(prog)
      );

      if (zipBlob) {
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Designo_${project.name}_All_${segments.length}_Clips.zip`;
        a.click();

        setExportSuccessMessage(`تم تصدير وتنزيل ملف ZIP يحتوي على جميع الـ ${segments.length} مقاطع!`);
        setTimeout(() => setExportSuccessMessage(null), 7000);
      }
    } catch (err: any) {
      console.error('Zip export error:', err);
      alert('فشل تصدير المقاطع: ' + err?.message);
    } finally {
      setIsExporting(false);
      setExportProgress(null);
    }
  };

  const totalDuration = project.duration || 60;
  const estimatedSize = estimateFileSizeMB(totalDuration, resolution, 'medium');

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-6 pb-24">
      {/* Header Info */}
      <div className="bg-gradient-to-r from-purple-950/60 via-[#131428] to-slate-900/60 border border-purple-800/40 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-inner">
              <Scissors className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <span>{lang === 'ar' ? 'أداة تقسيم الفيديو الذكية' : 'Smart Video Splitter'}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-purple-900/80 text-purple-300 border border-purple-700/50">
                  {segments.length} {lang === 'ar' ? 'أجزاء' : 'Parts'}
                </span>
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                {lang === 'ar'
                  ? 'قسّم الفيديو إلى مقاطع متساوية أو محددة بالثواني مع تصدير عالي الدقة وملف ZIP'
                  : 'Split into equal or exact timed clips with high quality video exports'}
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-4 bg-purple-950/40 border border-purple-900/40 px-3.5 py-2 rounded-xl text-xs">
            <div className="text-center">
              <span className="text-slate-400 block text-[10px]">{lang === 'ar' ? 'المدة الكلية' : 'Total'}</span>
              <span className="font-bold text-white font-mono">{formatTime(totalDuration)}</span>
            </div>
            <div className="w-px h-6 bg-purple-800/40" />
            <div className="text-center">
              <span className="text-slate-400 block text-[10px]">{lang === 'ar' ? 'عدد المقاطع' : 'Clips'}</span>
              <span className="font-bold text-purple-300">{segments.length}</span>
            </div>
            <div className="w-px h-6 bg-purple-800/40" />
            <div className="text-center">
              <span className="text-slate-400 block text-[10px]">{lang === 'ar' ? 'الحجم التقديري' : 'Est. Size'}</span>
              <span className="font-bold text-emerald-400">~{estimatedSize} MB</span>
            </div>
          </div>
        </div>

        {/* Visual Timeline Segments Bar */}
        <div className="mt-5 space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{lang === 'ar' ? 'مخطط تقسيم المقاطع الزمني:' : 'Timeline segments:'}</span>
            <span className="font-mono text-purple-300">{formatTime(totalDuration)}</span>
          </div>
          <div className="h-6 w-full rounded-lg bg-black/50 border border-purple-900/40 flex overflow-hidden p-0.5 gap-0.5">
            {segments.map((seg) => {
              const pct = (seg.duration / totalDuration) * 100;
              const isActive = activePreviewIndex === seg.index;
              return (
                <div
                  key={seg.index}
                  onClick={() => handlePreviewClip(seg)}
                  style={{ width: `${pct}%` }}
                  className={`h-full rounded transition-all cursor-pointer flex items-center justify-center text-[10px] font-bold select-none ${
                    isActive
                      ? 'bg-purple-500 text-white shadow-md shadow-purple-500/50 ring-1 ring-white'
                      : seg.index % 2 === 0
                      ? 'bg-purple-800/70 hover:bg-purple-700 text-purple-200'
                      : 'bg-indigo-700/70 hover:bg-indigo-600 text-indigo-100'
                  }`}
                  title={`${seg.title} (${seg.duration}s)`}
                >
                  {pct > 8 && `${seg.duration}s`}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Control Configuration Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Splitting Options Mode */}
        <div className="bg-[#111224] border border-purple-900/40 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>{lang === 'ar' ? 'خيارات وطريقة التقسيم' : 'Splitting Options'}</span>
          </div>

          {/* Mode Switch: Duration vs Parts Count */}
          <div className="grid grid-cols-2 gap-2 bg-[#090a14] p-1 rounded-xl border border-purple-950">
            <button
              onClick={() => setSplitMode('duration')}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer ${
                splitMode === 'duration'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'ar' ? 'حسب المدة (ثواني)' : 'By Duration (Sec)'}
            </button>
            <button
              onClick={() => setSplitMode('count')}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer ${
                splitMode === 'count'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'ar' ? 'حسب عدد الأجزاء' : 'By Number of Parts'}
            </button>
          </div>

          {/* Duration Presets */}
          {splitMode === 'duration' ? (
            <div className="space-y-3">
              <label className="text-xs text-slate-300 font-medium block">
                {lang === 'ar' ? 'اختر مدة كل مقطع:' : 'Select segment duration:'}
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
                {presetDurations.map((sec) => (
                  <button
                    key={sec}
                    onClick={() => {
                      setSplitDuration(sec);
                      setCustomDurationInput(sec.toString());
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      splitDuration === sec
                        ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-900/40'
                        : 'bg-purple-950/40 border-purple-900/50 text-slate-300 hover:bg-purple-900/40'
                    }`}
                  >
                    {sec} {lang === 'ar' ? 'ث' : 's'}
                  </button>
                ))}
              </div>

              {/* Custom Duration Input */}
              <div className="flex items-center gap-2 pt-2">
                <span className="text-xs text-slate-400">{lang === 'ar' ? 'أو مدة مخصصة:' : 'Or custom:'}</span>
                <input
                  type="number"
                  min="3"
                  max="600"
                  value={customDurationInput}
                  onChange={(e) => {
                    setCustomDurationInput(e.target.value);
                    const val = parseInt(e.target.value, 10);
                    if (val > 0) setSplitDuration(val);
                  }}
                  className="w-24 px-3 py-1.5 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-sm font-mono text-white text-center focus:outline-none focus:border-purple-400"
                />
                <span className="text-xs text-slate-400">{lang === 'ar' ? 'ثانية لكل جزء' : 'seconds'}</span>
              </div>
            </div>
          ) : (
            /* Parts Count Mode */
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">{lang === 'ar' ? 'عدد الأجزاء المتساوية:' : 'Equal parts count:'}</span>
                <span className="font-bold text-purple-300 text-base">{partsCount}</span>
              </div>
              <input
                type="range"
                min="2"
                max="20"
                value={partsCount}
                onChange={(e) => setPartsCount(parseInt(e.target.value, 10))}
                className="w-full accent-purple-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>2 {lang === 'ar' ? 'أجزاء' : 'parts'}</span>
                <span>10</span>
                <span>20 {lang === 'ar' ? 'جزء' : 'parts'}</span>
              </div>
            </div>
          )}
        </div>

        {/* Export Configuration & Bulk Action */}
        <div className="bg-[#111224] border border-purple-900/40 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Download className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'ar' ? 'إعدادات الجودة والتصدير الجماعي' : 'Export & Quality Settings'}</span>
            </div>

            {/* Resolution Selector */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-300">{lang === 'ar' ? 'دقة الإخراج:' : 'Resolution:'}</span>
              <div className="grid grid-cols-3 gap-2">
                {(['480p', '720p', '1080p'] as const).map((res) => (
                  <button
                    key={res}
                    onClick={() => setResolution(res)}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition cursor-pointer ${
                      resolution === res
                        ? 'bg-purple-900/80 border-purple-400 text-white'
                        : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    {res} {res === '1080p' ? 'Full HD' : res === '720p' ? 'HD' : 'SD'}
                  </button>
                ))}
              </div>
            </div>

            {/* Note on audio preservation */}
            <div className="p-2.5 rounded-xl bg-purple-950/20 border border-purple-900/30 text-[11px] text-purple-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                {lang === 'ar'
                  ? 'يتم الاحتفاظ بالصوت الأصلي بدقة تامة في جميع المقاطع المجتزأة.'
                  : 'Original audio is preserved with full fidelity across all split clips.'}
              </span>
            </div>
          </div>

          {/* Bulk Export Button */}
          <button
            onClick={handleExportAllZip}
            disabled={isExporting || segments.length === 0}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-purple-900/40 disabled:opacity-50 transition active:scale-98 cursor-pointer"
          >
            <FolderArchive className="w-5 h-5" />
            <span>
              {lang === 'ar'
                ? `تصدير وتنزيل الكل في ملف ZIP (${segments.length} مقطع)`
                : `Export All as ZIP (${segments.length} Clips)`}
            </span>
          </button>
        </div>
      </div>

      {/* Export Progress Overlay / Banner */}
      {isExporting && exportProgress && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950 via-[#18132e] to-indigo-950 border border-purple-500/50 shadow-2xl space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between text-sm font-bold text-white">
            <span className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
              <span>{exportProgress.message}</span>
            </span>
            <span className="font-mono text-purple-300">{exportProgress.progressPercent}%</span>
          </div>

          <div className="h-3 w-full bg-black/60 rounded-full overflow-hidden p-0.5 border border-purple-800/40">
            <div
              className="h-full bg-gradient-to-r from-purple-500 via-indigo-400 to-emerald-400 rounded-full transition-all duration-200"
              style={{ width: `${exportProgress.progressPercent}%` }}
            />
          </div>

          <p className="text-[11px] text-slate-400 text-center">
            {lang === 'ar'
              ? 'يرجى إبقاء هذه الصفحة مفتوحة حتى يكتمل التصدير والتنزيل...'
              : 'Please keep this page open until processing completes...'}
          </p>
        </div>
      )}

      {/* Success Notification */}
      {exportSuccessMessage && (
        <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-600/50 flex items-center gap-3 text-emerald-200 text-sm animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{exportSuccessMessage}</span>
        </div>
      )}

      {/* Segments Preview & Individual Export Cards List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Film className="w-4 h-4 text-purple-400" />
            <span>{lang === 'ar' ? 'قائمة المقاطع الناتجة والمعاينة' : 'Generated Clips & Previews'}</span>
          </h2>
          <span className="text-xs text-slate-400">
            {lang === 'ar' ? 'انقر للمعاينة أو التصدير الفردي' : 'Click to preview or export individually'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {segments.map((seg) => {
            const isPlaying = activePreviewIndex === seg.index && isPlayingClip;
            const isRemainder = seg.duration !== splitDuration && splitMode === 'duration';

            return (
              <div
                key={seg.index}
                className={`p-4 rounded-xl border transition-all ${
                  activePreviewIndex === seg.index
                    ? 'bg-purple-950/40 border-purple-500 shadow-lg shadow-purple-950/50'
                    : 'bg-[#111224] border-purple-900/30 hover:border-purple-700/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-purple-900/60 text-purple-300 font-bold text-xs flex items-center justify-center">
                      {seg.index}
                    </span>
                    <span className="font-semibold text-xs text-white truncate max-w-[140px]">
                      {seg.title}
                    </span>
                  </div>
                  {isRemainder && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/40">
                      {lang === 'ar' ? 'الجزء الأخير' : 'Remainder'}
                    </span>
                  )}
                </div>

                {/* Timestamps */}
                <div className="flex items-center justify-between text-xs font-mono text-slate-400 py-1 border-y border-purple-900/20 mb-3">
                  <span>{formatTime(seg.startTime)}</span>
                  <span className="text-purple-400 font-bold">{seg.duration}s</span>
                  <span>{formatTime(seg.endTime)}</span>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => (isPlaying ? handleStopPreview() : handlePreviewClip(seg))}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      isPlaying
                        ? 'bg-amber-600 text-white'
                        : 'bg-purple-900/40 hover:bg-purple-800/60 text-purple-200'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isPlaying ? (lang === 'ar' ? 'إيقاف' : 'Pause') : (lang === 'ar' ? 'معاينة' : 'Preview')}</span>
                  </button>

                  <button
                    onClick={() => handleExportSingleClip(seg)}
                    disabled={isExporting}
                    className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition cursor-pointer disabled:opacity-50"
                    title={lang === 'ar' ? 'تصدير هذا المقطع وحده' : 'Export this clip'}
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{lang === 'ar' ? 'تصدير' : 'Export'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
