import React, { useState, useRef } from "react";
import {
  X,
  Stamp,
  Scissors,
  Plus,
  Trash2,
  Copy,
  Check,
  Search,
  Upload,
  Info,
  Layers,
  Sparkles,
  ArrowRight,
  Maximize2
} from "lucide-react";
import { ElementSnippet, Note, ThemeAccent } from "../types";
import { THEME_ACCENTS } from "../utils/theme";

interface ElementsLibraryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onToggle?: () => void;
  elements: ElementSnippet[];
  onAddElement: (element: ElementSnippet) => void;
  onDeleteElement: (id: string) => void;
  onInsertIntoNote: (element: ElementSnippet, size?: "small" | "medium" | "large") => void;
  onTriggerLassoMode?: () => void;
  isNoteEditorOpen?: boolean;
  activeNote?: Note | null;
  themeAccent?: ThemeAccent;
}

export const ElementsLibraryDrawer: React.FC<ElementsLibraryDrawerProps> = ({
  isOpen,
  onClose,
  elements,
  onAddElement,
  onDeleteElement,
  onInsertIntoNote,
  onTriggerLassoMode,
  isNoteEditorOpen = false,
  activeNote = null,
  themeAccent = "teal",
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("Tümü");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [addedId, setAddedId] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<"small" | "medium" | "large">("medium");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const accentConfig = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  const categories = [
    "Tümü",
    "Kırpıntılarım (Snippets)",
    "Çıkartmalar (Stickers)",
    "Post-it & Notlar",
    "Şekil & İşaretçiler",
  ];

  const filteredElements = elements.filter((elem) => {
    const matchesCategory =
      selectedCategory === "Tümü" || elem.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === "" ||
      elem.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (elem.sourceText && elem.sourceText.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        if (dataUrl) {
          const newElem: ElementSnippet = {
            id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name.replace(/\.[^/.]+$/, "").slice(0, 30) || "Özel Çıkartma",
            category: "Kırpıntılarım (Snippets)",
            type: "upload",
            data: dataUrl,
            createdAt: new Date().toISOString(),
          };
          onAddElement(newElem);
        }
      };
      reader.readAsDataURL(file);
    }
    e.target.value = "";
  };

  const handleCopySticker = (elem: ElementSnippet) => {
    navigator.clipboard.writeText(elem.data);
    setCopiedId(elem.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleInsert = (elem: ElementSnippet) => {
    onInsertIntoNote(elem, selectedSize);
    setAddedId(elem.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end pointer-events-none">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs pointer-events-auto transition-opacity"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-md sm:max-w-lg h-full bg-white dark:bg-slate-900 shadow-2xl flex flex-col pointer-events-auto border-l border-slate-200 dark:border-slate-800 z-10 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-500/10 dark:bg-teal-400/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-black">
              <Stamp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Öğeler Kütüphanesi
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  Goodnotes & Notability
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kırpıntı (Snippet) & Çıkartma Koleksiyonu
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Kapat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Action Toolbar */}
        <div className="p-3 bg-gradient-to-r from-teal-50/90 via-emerald-50/70 to-teal-50/90 dark:from-teal-950/40 dark:via-emerald-950/30 dark:to-teal-950/40 border-b border-teal-100 dark:border-teal-900/50 flex items-center justify-between gap-2">
          {onTriggerLassoMode && (
            <button
              onClick={() => {
                onClose();
                onTriggerLassoMode();
              }}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Kementle Seç & Kırp</span>
            </button>
          )}

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold shadow-2xs active:scale-95 transition-all"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Çıkartma Yükle</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/png,image/svg+xml,image/webp,image/jpeg"
            className="hidden"
            onChange={handleFileUpload}
          />
        </div>

        {/* Search and Size Preference */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Öğe veya çıkartma ara..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-0 focus:ring-2 focus:ring-teal-500 text-slate-800 dark:text-slate-200 placeholder:text-slate-400"
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-[11px] font-semibold text-slate-500">
              Ekleme Boyutu:
            </span>
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
              {(["small", "medium", "large"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                    selectedSize === s
                      ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 shadow-2xs"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"
                  }`}
                >
                  {s === "small" ? "Küçük" : s === "medium" ? "Orta" : "Büyük"}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Categories Pills */}
        <div className="px-3 py-2 border-b border-slate-200/80 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? "bg-teal-600 text-white shadow-xs"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Elements Grid */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredElements.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                <Stamp className="w-7 h-7" />
              </div>
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                Öğe bulunamadı
              </p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Notlarınızdan Kement (Lasso) aracı ile seçim yaparak veya 'Çıkartma Yükle' ile koleksiyonunuza yeni öğeler ekleyebilirsiniz.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {filteredElements.map((elem) => (
                <div
                  key={elem.id}
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("text/plain", elem.data);
                    e.dataTransfer.setData("application/noteflow-element", JSON.stringify(elem));
                  }}
                  className="group relative bg-slate-50 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-500 rounded-2xl p-2.5 flex flex-col justify-between transition-all shadow-2xs hover:shadow-md cursor-grab active:cursor-grabbing"
                >
                  {/* Preview Box */}
                  <div
                    onClick={() => handleInsert(elem)}
                    className="w-full h-24 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 flex items-center justify-center p-2 overflow-hidden cursor-pointer"
                    title="Notun içine eklemek için tıklayın"
                  >
                    <img
                      src={elem.data}
                      alt={elem.name}
                      className="max-h-full max-w-full object-contain pointer-events-none drop-shadow-xs group-hover:scale-105 transition-transform"
                    />
                  </div>

                  {/* Details & Actions */}
                  <div className="pt-2 flex items-center justify-between gap-1">
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate flex-1">
                      {elem.name}
                    </span>

                    {/* Delete Custom Clip if not default preset */}
                    {elem.id.startsWith("snippet-") || elem.id.startsWith("custom-") || elem.id.startsWith("lasso-") ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`"${elem.name}" öğesini silmek istiyor musunuz?`)) {
                            onDeleteElement(elem.id);
                          }
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        title="Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    ) : null}
                  </div>

                  {/* Quick Insert Button Overlay on Hover */}
                  <div className="mt-1.5 flex items-center gap-1">
                    <button
                      onClick={() => handleInsert(elem)}
                      className={`flex-1 flex items-center justify-center gap-1 py-1 px-2 rounded-lg text-[11px] font-bold transition-all ${
                        addedId === elem.id
                          ? "bg-emerald-600 text-white"
                          : "bg-teal-600 hover:bg-teal-700 text-white shadow-2xs active:scale-95"
                      }`}
                    >
                      {addedId === elem.id ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>Eklendi</span>
                        </>
                      ) : (
                        <>
                          <ArrowRight className="w-3 h-3" />
                          <span>Nota Ekle</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleCopySticker(elem)}
                      className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-600 dark:text-slate-300"
                      title="Kopyala"
                    >
                      {copiedId === elem.id ? (
                        <Check className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Info */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-2">
          <Info className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed">
            <strong>Kullanım İpucu:</strong> Çıkartmaları tek tıkla veya sürükleyip bırakarak nota ekleyebilirsiniz. Not düzenleyicideki <strong>Kement (Lasso)</strong> butonu ile kendi el yazınızı, çiziminizi veya metninizi daireye alıp buraya kaydedebilirsiniz.
          </p>
        </div>
      </div>
    </div>
  );
};
