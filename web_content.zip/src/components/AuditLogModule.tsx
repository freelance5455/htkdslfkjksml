import React, { useMemo, useState } from 'react';
import { Download, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatDateTime } from '../utils/calculations';
import { exportToCsv } from '../utils/storage';
import type { AuditAction } from '../types';

const ACTIONS: AuditAction[] = [
  'Create',
  'Edit',
  'Delete',
  'Restore',
  'Permanent Delete',
  'Import/Restore',
  'Settings Change',
];

export const AuditLogModule: React.FC = () => {
  const { state, tr } = useApp();
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [moduleFilter, setModuleFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const dateFmt = state.settings.dateFormat;

  const uniqueModules = useMemo(() => {
    const set = new Set<string>();
    state.auditLog.forEach((e) => set.add(e.module));
    return Array.from(set).sort();
  }, [state.auditLog]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.auditLog.filter((entry) => {
      const d = entry.timestamp.slice(0, 10);
      if (fromDate && d < fromDate) return false;
      if (toDate && d > toDate) return false;
      if (actionFilter && entry.action !== actionFilter) return false;
      if (moduleFilter && entry.module !== moduleFilter) return false;
      if (q) {
        const hay = `${entry.action} ${entry.module} ${entry.recordRef} ${entry.summary}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [state.auditLog, search, actionFilter, moduleFilter, fromDate, toDate]);

  const handleExport = () => {
    exportToCsv(
      'audit-log.csv',
      ['Timestamp', 'Action', 'Module', 'Record Reference', 'Summary'],
      filtered.map((e) => [e.timestamp, e.action, e.module, e.recordRef, e.summary])
    );
  };

  return (
    <div className="space-y-5">
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">{tr('nav_audit_log')}</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable activity trail of all create, edit, delete, restore, import, and settings changes.
          </p>
        </div>
        <button
          type="button"
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
        >
          <Download className="h-3.5 w-3.5" />
          <span>{tr('export_csv')}</span>
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5">
          <div className="relative lg:col-span-2">
            <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search audit log..."
              aria-label="Search audit log"
              className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
            />
          </div>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            aria-label="Filter audit log by action"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
          >
            <option value="">All Actions</option>
            {ACTIONS.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
          <select
            value={moduleFilter}
            onChange={(e) => setModuleFilter(e.target.value)}
            aria-label="Filter audit log by module"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
          >
            <option value="">All Modules</option>
            {uniqueModules.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            aria-label="Filter audit log from date"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
          />
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            aria-label="Filter audit log to date"
            className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
          />
        </div>

        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center text-sm text-slate-500">
            No audit events match your filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <tr>
                  <th className="px-4 py-3 text-start">Date / Time</th>
                  <th className="px-4 py-3 text-start">Action</th>
                  <th className="px-4 py-3 text-start">Module</th>
                  <th className="px-4 py-3 text-start">Summary</th>
                  <th className="px-4 py-3 text-start">Ref</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 whitespace-nowrap tabular-nums text-xs text-slate-600">
                      {formatDateTime(entry.timestamp, dateFmt)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs font-semibold">
                      <span
                        className={
                          entry.action === 'Delete' || entry.action === 'Permanent Delete'
                            ? 'text-red-700'
                            : entry.action === 'Create' || entry.action === 'Restore'
                              ? 'text-emerald-700'
                              : 'text-slate-700'
                        }
                      >
                        {entry.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-slate-700">
                      {entry.module}
                    </td>
                    <td className="px-4 py-3 text-slate-900">{entry.summary}</td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-[11px] text-slate-400">
                      {entry.recordRef}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
