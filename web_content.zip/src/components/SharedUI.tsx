import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Calendar, Check, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { fmtQty } from '../categoryTemplates';
import type { Sale, StoreSettings } from '../types';
import { fmtDateTime, fmtMoney, toDateKey } from '../utils';
import { Icon, IconName } from './Icon';

/* =========================================================
   0. TACTILE TOGGLE SWITCH
   ========================================================= */
interface ToggleSwitchProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  label?: string;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ checked, onChange, label }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={label}
    onClick={() => onChange(!checked)}
    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors duration-150 ${
      checked
        ? 'bg-blue-600 border-blue-600 shadow-[inset_0_1px_2px_rgba(15,23,42,0.18)]'
        : 'bg-slate-200 border-slate-300/80 shadow-[inset_0_1px_2px_rgba(15,23,42,0.12)]'
    }`}
  >
    <span
      className={`inline-block h-4.5 w-4.5 rounded-full bg-white shadow-[0_1px_3px_rgba(15,23,42,0.28)] transition-transform duration-150 ${
        checked ? 'translate-x-5.5' : 'translate-x-0.5'
      }`}
    />
  </button>
);

/* =========================================================
   1. IN-APP MODAL
   ========================================================= */
interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}

export const Modal: React.FC<ModalProps> = ({ open, onClose, title, children, maxWidth = 'max-w-lg' }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-[2px] p-0 sm:p-4" onClick={onClose}>
      <div
        className={`bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full ${maxWidth} max-h-[90vh] flex flex-col overflow-hidden border border-slate-200`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 sm:px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <h3 className="text-base sm:text-lg font-bold text-slate-900 truncate pr-4">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 transition shrink-0"
          >
            <Icon name="x" className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 sm:p-6 overflow-y-auto custom-scrollbar">{children}</div>
      </div>
    </div>
  );
};

/* =========================================================
   2. IN-APP CONFIRMATION DIALOG (REPLACES window.confirm)
   ========================================================= */
interface ConfirmModalProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  open,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  danger = true,
  onConfirm,
  onCancel,
}) => (
  <Modal open={open} onClose={onCancel} title={title} maxWidth="max-w-md">
    <div className="space-y-5">
      <p className="text-sm text-slate-600 leading-relaxed">{message}</p>
      <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
        <button type="button" onClick={onCancel} className="btn-secondary px-4 py-2.5 text-sm">
          {cancelLabel}
        </button>
        <button
          type="button"
          onClick={onConfirm}
          className={`px-5 py-2.5 rounded-xl text-sm font-bold text-white shadow-sm ${
            danger ? 'bg-rose-600 hover:bg-rose-700' : 'btn-primary'
          }`}
        >
          {confirmLabel}
        </button>
      </div>
    </div>
  </Modal>
);

/* =========================================================
   3. CUSTOM IN-APP DROPDOWN (REPLACES NATIVE <select>)
   ========================================================= */
export interface SelectOption {
  value: string;
  label: string;
  sublabel?: string;
}

interface CustomSelectProps {
  value: string;
  onChange: (val: string) => void;
  options: SelectOption[];
  placeholder?: string;
  searchable?: boolean;
  className?: string;
  compact?: boolean;
}

export const CustomSelect: React.FC<CustomSelectProps> = ({
  value,
  onChange,
  options,
  placeholder = 'Select...',
  searchable = false,
  className = '',
  compact = false,
}) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const rootRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuStyle, setMenuStyle] = useState<React.CSSProperties>({});

  const updatePosition = () => {
    const rect = btnRef.current?.getBoundingClientRect();
    if (!rect) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const minW = Math.max(rect.width, 220);
    const width = Math.min(minW, vw - 24);
    let left = rect.left;
    if (left + width > vw - 12) {
      left = Math.max(12, vw - width - 12);
    }
    const spaceBelow = vh - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const openUpward = spaceBelow < 220 && spaceAbove > spaceBelow;
    const maxH = Math.max(160, Math.min(280, openUpward ? spaceAbove : spaceBelow));

    setMenuStyle({
      position: 'fixed',
      left: `${left}px`,
      width: `${width}px`,
      ...(openUpward ? { bottom: `${vh - rect.top + 6}px` } : { top: `${rect.bottom + 6}px` }),
      maxHeight: `${maxH}px`,
      zIndex: 100,
    });
  };

  useEffect(() => {
    if (!open) return;
    updatePosition();
    const handleOutside = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
        setQ('');
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        setQ('');
      }
    };
    const handleScrollOrResize = (e: Event) => {
      if (menuRef.current && e.target instanceof Node && menuRef.current.contains(e.target)) return;
      updatePosition();
    };
    document.addEventListener('pointerdown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    window.addEventListener('resize', handleScrollOrResize);
    window.addEventListener('scroll', handleScrollOrResize, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
      window.removeEventListener('resize', handleScrollOrResize);
      window.removeEventListener('scroll', handleScrollOrResize, true);
    };
  }, [open]);

  const selected = useMemo(() => options.find((o) => o.value === value), [options, value]);
  const filtered = useMemo(() => {
    if (!searchable || !q.trim()) return options;
    const lq = q.toLowerCase();
    return options.filter(
      (o) => o.label.toLowerCase().includes(lq) || (o.sublabel && o.sublabel.toLowerCase().includes(lq))
    );
  }, [options, searchable, q]);

  return (
    <div ref={rootRef} className={`relative ${className}`}>
      <button
        ref={btnRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`w-full flex items-center justify-between gap-2 rounded-xl border bg-gradient-to-b from-white to-slate-50/70 text-left outline-none min-h-[42px] shadow-[0_1px_2px_rgba(15,23,42,0.06),inset_0_1px_0_rgba(255,255,255,0.9)] ${
          open ? 'border-blue-500 ring-2 ring-blue-100 to-white' : 'border-slate-200/95 hover:border-slate-300 hover:to-white'
        } ${compact ? 'px-3 py-1.5 text-xs' : 'px-3.5 py-2 text-sm'}`}
      >
        <span className={`truncate font-semibold ${selected ? 'text-slate-900' : 'text-slate-400'}`}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-150 ${open ? 'rotate-180 text-blue-600' : ''}`} />
      </button>

      {open && (
        <div
          ref={menuRef}
          style={menuStyle}
          className="bg-white border border-slate-200/95 rounded-2xl shadow-[0_20px_48px_-10px_rgba(15,23,42,0.22),0_0_0_1px_rgba(15,23,42,0.03)] flex flex-col overflow-hidden"
        >
          {searchable && (
            <div className="p-2 border-b border-slate-100 bg-slate-50/80 shrink-0">
              <input
                type="text"
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Type to filter..."
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>
          )}
          <div className="overflow-y-auto custom-scrollbar p-1.5 space-y-1 flex-1">
            {filtered.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-5">No matching options</p>
            ) : (
              filtered.map((opt) => {
                const isSelected = opt.value === value;
                return (
                  <button
                    type="button"
                    key={opt.value}
                    onClick={() => {
                      onChange(opt.value);
                      setOpen(false);
                      setQ('');
                    }}
                    className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-xl text-left text-sm border ${
                      isSelected
                        ? 'bg-blue-50/90 border-blue-200/80 text-blue-700 font-semibold shadow-[0_1px_2px_rgba(37,99,235,0.08)]'
                        : 'border-transparent text-slate-700 hover:bg-slate-100/80 hover:text-slate-950'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate">{opt.label}</p>
                      {opt.sublabel && <p className="text-[11px] text-slate-400 truncate mt-0.5">{opt.sublabel}</p>}
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                        <Check className="w-3 h-3 stroke-[2.5]" />
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* =========================================================
   3B. SMART AUTOCOMPLETE COMBO FIELD (TAP OR TYPE 2-3 CHARS)
   ========================================================= */
interface SmartComboFieldProps {
  value: string;
  onChange: (val: string) => void;
  suggestions: string[];
  placeholder?: string;
  className?: string;
  quickChipsCount?: number;
}

export const SmartComboField: React.FC<SmartComboFieldProps> = ({
  value,
  onChange,
  suggestions,
  placeholder = 'Tap to choose or type 2-3 letters...',
  className = '',
  quickChipsCount = 4,
}) => {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuStyle, setMenuStyle] = useState<React.CSSProperties>({});

  const updatePos = () => {
    const rect = inputRef.current?.getBoundingClientRect();
    if (!rect) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const width = Math.min(Math.max(rect.width, 220), vw - 24);
    let left = rect.left;
    if (left + width > vw - 12) left = Math.max(12, vw - width - 12);
    const spaceBelow = vh - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const openUpward = spaceBelow < 200 && spaceAbove > spaceBelow;
    const maxH = Math.max(140, Math.min(240, openUpward ? spaceAbove : spaceBelow));
    setMenuStyle({
      position: 'fixed',
      left: `${left}px`,
      width: `${width}px`,
      ...(openUpward ? { bottom: `${vh - rect.top + 6}px` } : { top: `${rect.bottom + 6}px` }),
      maxHeight: `${maxH}px`,
      zIndex: 110,
    });
  };

  useEffect(() => {
    if (!open) return;
    updatePos();
    const handleOutside = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleScrollOrResize = (e: Event) => {
      if (menuRef.current && e.target instanceof Node && menuRef.current.contains(e.target)) return;
      updatePos();
    };
    document.addEventListener('pointerdown', handleOutside);
    window.addEventListener('resize', handleScrollOrResize);
    window.addEventListener('scroll', handleScrollOrResize, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutside);
      window.removeEventListener('resize', handleScrollOrResize);
      window.removeEventListener('scroll', handleScrollOrResize, true);
    };
  }, [open]);

  const uniqueSuggestions = useMemo(
    () => Array.from(new Set(suggestions.filter((s) => s.trim() !== ''))),
    [suggestions]
  );

  const filtered = useMemo(() => {
    const q = value.trim().toLowerCase();
    if (!q) return uniqueSuggestions;
    return uniqueSuggestions.filter((s) => s.toLowerCase().includes(q));
  }, [uniqueSuggestions, value]);

  const topQuickChips = useMemo(
    () => uniqueSuggestions.slice(0, quickChipsCount),
    [uniqueSuggestions, quickChipsCount]
  );

  return (
    <div ref={rootRef} className={`space-y-1.5 ${className}`}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onFocus={() => setOpen(true)}
          onClick={() => setOpen(true)}
          onChange={(e) => {
            onChange(e.target.value);
            setOpen(true);
          }}
          placeholder={placeholder}
          className="w-full rounded-xl border border-slate-200 bg-white pl-3.5 pr-12 py-2.5 text-sm font-medium outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-0.5">
          {value && (
            <button
              type="button"
              onClick={() => {
                onChange('');
                inputRef.current?.focus();
              }}
              className="p-1 text-slate-400 hover:text-slate-600"
              aria-label="Clear field"
            >
              <Icon name="x" className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="p-1 text-slate-400 hover:text-blue-600"
            aria-label="Toggle suggestions"
          >
            <ChevronDown className={`w-4 h-4 transition-transform ${open ? 'rotate-180 text-blue-600' : ''}`} />
          </button>
        </div>
      </div>

      {topQuickChips.length > 0 && !value.trim() && (
        <div className="flex flex-wrap gap-1">
          {topQuickChips.map((chip) => (
            <button
              type="button"
              key={chip}
              onClick={() => {
                onChange(chip);
                setOpen(false);
              }}
              className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 border border-slate-200/80 text-[11px] font-medium"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {open && (filtered.length > 0 || value.trim()) && (
        <div
          ref={menuRef}
          style={menuStyle}
          className="bg-white border border-slate-200 rounded-2xl shadow-[0_20px_48px_-10px_rgba(15,23,42,0.22)] flex flex-col overflow-hidden"
        >
          <div className="overflow-y-auto custom-scrollbar p-1.5 space-y-0.5 flex-1">
            {filtered.map((opt) => {
              const isSelected = opt.toLowerCase() === value.trim().toLowerCase();
              return (
                <button
                  type="button"
                  key={opt}
                  onClick={() => {
                    onChange(opt);
                    setOpen(false);
                  }}
                  className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-left text-xs sm:text-sm ${
                    isSelected ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="truncate">{opt}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                </button>
              );
            })}
            {value.trim() && !filtered.some((s) => s.toLowerCase() === value.trim().toLowerCase()) && (
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="w-full px-3 py-2 rounded-xl text-left text-xs font-semibold text-blue-700 bg-blue-50/70 hover:bg-blue-100"
              >
                Use "{value.trim()}"
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* =========================================================
   4. CUSTOM IN-APP DATE PICKER (REPLACES NATIVE <input type="date">)
   ========================================================= */
interface CustomDatePickerProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  allowClear?: boolean;
  className?: string;
}

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  value,
  onChange,
  placeholder = 'Select date',
  allowClear = true,
  className = '',
}) => {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  const [popStyle, setPopStyle] = useState<React.CSSProperties>({});

  const initialDate = value ? new Date(value + 'T00:00:00') : new Date();
  const [viewYear, setViewYear] = useState(initialDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(initialDate.getMonth());

  const updatePos = () => {
    const rect = btnRef.current?.getBoundingClientRect();
    if (!rect) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const width = 264;
    let left = rect.left;
    if (left + width > vw - 12) {
      left = Math.max(12, vw - width - 12);
    }
    const spaceBelow = vh - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const openUpward = spaceBelow < 300 && spaceAbove > spaceBelow;
    setPopStyle({
      position: 'fixed',
      left: `${left}px`,
      width: `${width}px`,
      ...(openUpward ? { bottom: `${vh - rect.top + 6}px` } : { top: `${rect.bottom + 6}px` }),
      zIndex: 100,
    });
  };

  useEffect(() => {
    if (value) {
      const d = new Date(value + 'T00:00:00');
      if (!Number.isNaN(d.getTime())) {
        setViewYear(d.getFullYear());
        setViewMonth(d.getMonth());
      }
    }
  }, [value]);

  useEffect(() => {
    if (!open) return;
    updatePos();
    const handleOutside = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('pointerdown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    window.addEventListener('resize', updatePos);
    window.addEventListener('scroll', updatePos, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
      window.removeEventListener('resize', updatePos);
      window.removeEventListener('scroll', updatePos, true);
    };
  }, [open]);

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const firstDay = new Date(viewYear, viewMonth, 1).getDay();
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

  const prevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };
  const nextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  return (
    <div ref={rootRef} className={`relative ${className}`}>
      <button
        ref={btnRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl border bg-gradient-to-b from-white to-slate-50/70 text-xs font-semibold min-h-[42px] outline-none shadow-[0_1px_2px_rgba(15,23,42,0.06),inset_0_1px_0_rgba(255,255,255,0.9)] ${
          open ? 'border-blue-500 ring-2 ring-blue-100 to-white' : 'border-slate-200/95 hover:border-slate-300 hover:to-white'
        }`}
      >
        <span className={`truncate tabular-nums ${value ? 'text-slate-900' : 'text-slate-400'}`}>{value || placeholder}</span>
        <Calendar className={`w-3.5 h-3.5 shrink-0 ${open ? 'text-blue-600' : 'text-slate-400'}`} />
      </button>

      {open && (
        <div style={popStyle} className="bg-white border border-slate-200/95 rounded-2xl shadow-[0_20px_48px_-10px_rgba(15,23,42,0.22),0_0_0_1px_rgba(15,23,42,0.03)] p-3">
          <div className="flex items-center justify-between mb-2">
            <button type="button" onClick={prevMonth} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-900">
              {monthNames[viewMonth]} {viewYear}
            </span>
            <button type="button" onClick={nextMonth} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-semibold text-slate-400 mb-1">
            {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
              <div key={d}>{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1 text-center text-xs tabular-nums">
            {Array.from({ length: firstDay }).map((_, idx) => (
              <div key={`empty-${idx}`} />
            ))}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const day = idx + 1;
              const dk = `${viewYear}-${String(viewMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const isSelected = dk === value;
              const isToday = dk === toDateKey(new Date());
              return (
                <button
                  type="button"
                  key={dk}
                  onClick={() => {
                    onChange(dk);
                    setOpen(false);
                  }}
                  className={`py-1.5 rounded-lg font-medium ${
                    isSelected
                      ? 'bg-blue-600 text-white font-bold shadow-xs'
                      : isToday
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-2 mt-2 border-t border-slate-100 text-[11px]">
            <button
              type="button"
              onClick={() => {
                onChange(toDateKey(new Date()));
                setOpen(false);
              }}
              className="font-bold text-blue-600 hover:underline"
            >
              Today
            </button>
            {allowClear && value && (
              <button
                type="button"
                onClick={() => {
                  onChange('');
                  setOpen(false);
                }}
                className="font-semibold text-slate-500 hover:text-rose-600"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* =========================================================
   5. STAT CARD & RECEIPT
   ========================================================= */
interface StatCardProps {
  title: string;
  value: string;
  subtitle?: string;
  color?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'sky' | 'violet';
  icon?: IconName;
}

export const StatCard: React.FC<StatCardProps> = ({ title, value, subtitle, color = 'indigo', icon }) => {
  const palette: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    emerald: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    rose: 'bg-rose-50 text-rose-600 border-rose-100',
    sky: 'bg-sky-50 text-sky-600 border-sky-100',
    violet: 'bg-violet-50 text-violet-600 border-violet-100',
  };

  return (
    <div className="surface-card p-5 transition-all hover:border-slate-300">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-slate-500 truncate">{title}</p>
          <p className="text-2xl font-extrabold text-slate-900 mt-1.5 tabular-nums tracking-tight">{value}</p>
          {subtitle && <p className="text-xs text-slate-500 mt-1.5 tabular-nums truncate">{subtitle}</p>}
        </div>
        {icon && (
          <div className={`p-2.5 rounded-xl border shrink-0 ${palette[color] || palette.indigo}`}>
            <Icon name={icon} className="w-5 h-5" />
          </div>
        )}
      </div>
    </div>
  );
};

interface ReceiptContentProps {
  sale: Sale | null;
  settings: StoreSettings;
  t: Record<string, string>;
}

export const ReceiptContent: React.FC<ReceiptContentProps> = ({ sale, settings, t }) => {
  if (!sale) return null;
  return (
    <div className="max-w-sm mx-auto text-slate-900 text-xs font-mono p-4 bg-white">
      <div className="text-center border-b border-dashed border-slate-400 pb-3 mb-3">
        {settings.storeLogo && <img src={settings.storeLogo} alt="Store logo" className="h-12 mx-auto mb-2 object-contain" />}
        <h2 className="text-lg font-bold uppercase tracking-wide">{settings.storeName || 'My Store'}</h2>
        {settings.showCustomerPhoneOnReceipt !== false && settings.storePhone && (
          <p className="text-[11px] text-slate-700 font-semibold mt-0.5">{settings.storePhone}</p>
        )}
        {settings.receiptHeader && <p className="text-[11px] text-slate-600 mt-0.5">{settings.receiptHeader}</p>}
      </div>
      <div className="space-y-1 mb-3 text-[11px]">
        <div className="flex justify-between">
          <span>{t.invoiceNo}:</span>
          <span className="font-bold">{sale.invoiceNo}</span>
        </div>
        <div className="flex justify-between">
          <span>{t.date}:</span>
          <span>{fmtDateTime(sale.date)}</span>
        </div>
        <div className="flex justify-between">
          <span>{t.customer}:</span>
          <span>{sale.customerName}</span>
        </div>
        <div className="flex justify-between">
          <span>{t.paymentMethod}:</span>
          <span>{t[sale.paymentMethod] || sale.paymentMethod}</span>
        </div>
      </div>
      <table className="w-full border-t border-b border-dashed border-slate-400 py-2 my-2 text-[11px] tabular-nums">
        <thead>
          <tr className="border-b border-slate-300 text-left">
            <th className="py-1">{t.items}</th>
            <th className="py-1 text-right">{t.qty}</th>
            <th className="py-1 text-right">{t.price}</th>
            <th className="py-1 text-right">{t.total}</th>
          </tr>
        </thead>
        <tbody>
          {sale.items.map((it, idx) => (
            <tr key={idx}>
              <td className="py-1 pr-1">
                {it.name}
                {it.model ? ` (${it.model})` : ''}
              </td>
              <td className="py-1 text-right">{fmtQty(it.qty, it.unit)}</td>
              <td className="py-1 text-right">{Number(it.sellingPrice).toFixed(2)}</td>
              <td className="py-1 text-right">{Number(it.qty * it.sellingPrice).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="space-y-1 text-[11px] pt-1 tabular-nums">
        <div className="flex justify-between">
          <span>{t.subtotal}:</span>
          <span>{fmtMoney(sale.subtotal)}</span>
        </div>
        {sale.discount > 0 && (
          <div className="flex justify-between">
            <span>{t.discount}:</span>
            <span>-{fmtMoney(sale.discount)}</span>
          </div>
        )}
        <div className="flex justify-between font-bold text-sm border-t border-slate-300 pt-1">
          <span>{t.grandTotal}:</span>
          <span>{fmtMoney(sale.grandTotal)}</span>
        </div>
        <div className="flex justify-between">
          <span>{t.paidAmount}:</span>
          <span>{fmtMoney(sale.paidAmount)}</span>
        </div>
        {sale.dueAmount > 0 && (
          <div className="flex justify-between font-bold text-rose-600">
            <span>{t.dueAmount}:</span>
            <span>{fmtMoney(sale.dueAmount)}</span>
          </div>
        )}
        {sale.changeReturn > 0 && (
          <div className="flex justify-between">
            <span>{t.changeReturn}:</span>
            <span>{fmtMoney(sale.changeReturn)}</span>
          </div>
        )}
      </div>
      {settings.receiptFooter && (
        <div className="text-center border-t border-dashed border-slate-400 mt-4 pt-3 text-[10px] text-slate-600">{settings.receiptFooter}</div>
      )}
    </div>
  );
};
