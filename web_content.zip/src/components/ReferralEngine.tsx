import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Share2, 
  Copy, 
  Check, 
  Coins, 
  Award, 
  Users, 
  Sparkles, 
  QrCode, 
  Gift, 
  Zap, 
  Crown, 
  CheckCircle2,
  ArrowLeft
} from 'lucide-react';

export const ReferralEngine: React.FC = () => {
  const { 
    user, 
    referralCode, 
    secretCoins, 
    invitedFriends, 
    simulateInviteFriend, 
    redeemCoins, 
    setActiveTab 
  } = useApp();

  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [redeemFeedback, setRedeemFeedback] = useState<string | null>(null);

  const deepLink = `https://secretgossip.app/join?campus=${user.collegeCode}&ref=${referralCode}`;

  const shareMessage = `🔥 Psst! Have you seen what students are secretly confessing in ${user.collegeName}? Join our private verified campus feed on Secret Gossip anonymously with my invite link:\n\n${deepLink}\n\nUse invite code: ${referralCode}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(deepLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  const handleTelegramShare = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(deepLink)}&text=${encodeURIComponent(`🤫 Secret campus confessions from ${user.collegeName}. Join anonymously!`)}`;
    window.open(url, '_blank');
  };

  const handleRedeem = (itemKey: string, cost: number, title: string) => {
    if (secretCoins < cost) {
      setRedeemFeedback(`Need ${cost - secretCoins} more Secret Coins! Invite more friends to earn.`);
      setTimeout(() => setRedeemFeedback(null), 3000);
      return;
    }
    const success = redeemCoins(itemKey, cost);
    if (success) {
      setRedeemFeedback(`🎉 Successfully redeemed: ${title}!`);
      setTimeout(() => setRedeemFeedback(null), 3500);
    }
  };

  // Milestone achievements
  const milestones = [
    { target: 1, badge: 'Campus Scout 🎖️', coins: 100, desc: 'Unlock Campus Scout badge', unlocked: (user.referralCount || 0) >= 1 },
    { target: 3, badge: 'Secret Recruiter 🌟', coins: 300, desc: '1 Free Post Boost pass', unlocked: (user.referralCount || 0) >= 3 },
    { target: 5, badge: 'Campus Ambassador 👑', coins: 500, desc: 'Golden Neon Persona Aura', unlocked: (user.referralCount || 0) >= 5 },
    { target: 10, badge: 'Shadow Influencer 🚀', coins: 1000, desc: 'Lifetime VIP Pass', unlocked: (user.referralCount || 0) >= 10 },
  ];

  return (
    <div className="space-y-4 pb-16">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>

      {/* Hero Reward Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#12162b] via-[#0d1224] to-[#080a14] border border-cyan-500/40 p-5 sm:p-7 shadow-2xl neon-glow-cyan">
        
        {/* Glow orb */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-60 h-60 bg-gradient-to-br from-cyan-500/20 via-purple-600/15 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono text-[11px] font-bold">
                CAMPUS REFERRAL ENGINE
              </span>
              <span className="text-xs text-amber-400 font-medium flex items-center gap-1">
                <Gift className="w-3.5 h-3.5" />
                <span>+100 Coins / Friend</span>
              </span>
            </div>
            <h2 className="font-display font-black text-xl sm:text-2xl text-slate-100 tracking-tight">
              Invite Friends & Rule Secret Gossip
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg leading-relaxed">
              Grow your college network. When classmates join with your deep-link, both of you earn <strong className="text-amber-300 font-semibold">Secret Coins</strong> and unlock <strong className="text-cyan-300 font-semibold">Exclusive VIP Badges</strong>!
            </p>
          </div>

          {/* Current Balance Box */}
          <div className="w-full md:w-auto p-4 rounded-2xl bg-slate-900/90 border border-amber-500/40 shadow-lg flex md:flex-col items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 text-xl shadow-inner">
                🪙
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Secret Coins Balance
                </span>
                <span className="font-mono text-2xl font-black text-amber-300 tabular-nums">
                  {secretCoins}
                </span>
              </div>
            </div>
            <div className="text-right md:text-center text-[11px] text-slate-400 font-mono">
              <span className="text-cyan-400 font-bold">{user.referralCount || 0}</span> friends invited
            </div>
          </div>
        </div>
      </div>

      {/* Unique Deep Link & Share Actions */}
      <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-4 sm:p-5 space-y-4">
        
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div>
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Share2 className="w-4 h-4 text-cyan-400" />
              <span>Your Unique Campus Deep-Link</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Universal link auto-routes friends to {user.collegeName} group
            </p>
          </div>
          <button
            onClick={() => setShowQrModal(!showQrModal)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
          >
            <QrCode className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Show QR</span>
          </button>
        </div>

        {/* Link Field with Copy */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 font-mono text-xs text-cyan-300 truncate select-all">
            {deepLink}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md flex items-center justify-center gap-1.5"
            >
              {copiedLink ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4 text-slate-950" />}
              <span>{copiedLink ? 'Copied Link!' : 'Copy Link'}</span>
            </button>
            <button
              onClick={handleCopyCode}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-mono font-bold transition-all"
              title="Copy referral code only"
            >
              {copiedCode ? 'Code Copied!' : `Code: ${referralCode}`}
            </button>
          </div>
        </div>

        {/* Social Share Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={handleWhatsAppShare}
            className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-500/40 text-xs font-semibold text-emerald-300 transition-all active:scale-98"
          >
            <span className="text-base">💬</span>
            <span>WhatsApp Invite</span>
          </button>

          <button
            onClick={handleTelegramShare}
            className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-sky-950/60 hover:bg-sky-900/70 border border-sky-500/40 text-xs font-semibold text-sky-300 transition-all active:scale-98"
          >
            <span className="text-base">✈️</span>
            <span>Telegram Channel</span>
          </button>

          <button
            onClick={simulateInviteFriend}
            className="col-span-2 sm:col-span-1 flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-gradient-to-r from-purple-900/70 to-indigo-900/70 hover:from-purple-800 hover:to-indigo-800 border border-purple-500/40 text-xs font-semibold text-purple-200 transition-all active:scale-98"
            title="Simulate someone joining with your link for instant demo testing"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Test Simulate Invite (+100 🪙)</span>
          </button>
        </div>

        {/* QR Code Card if toggled */}
        {showQrModal && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 text-center space-y-2 animate-fadeIn">
            <span className="text-[11px] font-semibold text-cyan-300 uppercase tracking-wider block">
              Scan with Smartphone Camera in Canteen / Lecture Hall
            </span>
            <div className="w-40 h-40 bg-white p-3 rounded-2xl mx-auto flex items-center justify-center shadow-lg">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <rect x="0" y="0" width="100" height="100" fill="white" />
                <rect x="8" y="8" width="28" height="28" fill="#07080d" rx="4" />
                <rect x="14" y="14" width="16" height="16" fill="white" rx="2" />
                <rect x="18" y="18" width="8" height="8" fill="#06b6d4" />
                
                <rect x="64" y="8" width="28" height="28" fill="#07080d" rx="4" />
                <rect x="70" y="14" width="16" height="16" fill="white" rx="2" />
                <rect x="74" y="18" width="8" height="8" fill="#06b6d4" />

                <rect x="8" y="64" width="28" height="28" fill="#07080d" rx="4" />
                <rect x="14" y="70" width="16" height="16" fill="white" rx="2" />
                <rect x="18" y="74" width="8" height="8" fill="#06b6d4" />

                {/* Random QR Pattern Dots */}
                <rect x="42" y="12" width="6" height="6" fill="#07080d" />
                <rect x="52" y="18" width="6" height="6" fill="#07080d" />
                <rect x="42" y="28" width="10" height="6" fill="#07080d" />
                <rect x="40" y="42" width="20" height="20" fill="#a855f7" rx="3" />
                <rect x="12" y="44" width="8" height="6" fill="#07080d" />
                <rect x="24" y="48" width="8" height="6" fill="#07080d" />
                <rect x="68" y="44" width="12" height="6" fill="#07080d" />
                <rect x="78" y="56" width="8" height="10" fill="#07080d" />
                <rect x="44" y="72" width="8" height="14" fill="#07080d" />
                <rect x="60" y="70" width="14" height="6" fill="#07080d" />
                <rect x="78" y="82" width="8" height="8" fill="#07080d" />
              </svg>
            </div>
            <p className="font-mono text-xs text-slate-400">
              Code: <strong className="text-cyan-300 font-bold">{referralCode}</strong>
            </p>
          </div>
        )}
      </div>

      {/* Milestones & Badges Progress */}
      <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-purple-400" />
            <span>Exclusive Profile Badges & Milestones</span>
          </h3>
          <span className="text-xs text-cyan-400 font-mono font-semibold">
            {user.referralCount || 0} / 10 Invites
          </span>
        </div>

        {/* Milestone Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {milestones.map((m, i) => (
            <div 
              key={i}
              className={`p-3.5 rounded-2xl border transition-all ${
                m.unlocked 
                  ? 'bg-purple-950/20 border-purple-500/50 shadow-sm' 
                  : 'bg-slate-950/40 border-slate-800/80 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-slate-100">{m.badge}</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                  m.unlocked ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                }`}>
                  {m.unlocked ? 'Unlocked 🔓' : `${m.target} invites needed`}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-snug">
                {m.desc} • <span className="text-amber-400 font-mono">+{m.coins} 🪙</span>
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Secret Coins Redeem Store */}
      <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>Secret Coins Rewards Shop</span>
          </h3>
          <span className="text-xs text-amber-300 font-mono font-bold">
            Balance: {secretCoins} 🪙
          </span>
        </div>

        {redeemFeedback && (
          <div className="p-2.5 rounded-xl bg-indigo-950/50 border border-cyan-500/40 text-xs text-cyan-200 flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{redeemFeedback}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          {/* Shop Item 1 */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 font-semibold text-xs text-slate-100">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Post Flame Boost</span>
              </div>
              <p className="text-[10px] text-slate-400">
                Pushes your confession to #1 trending slot for 24h
              </p>
            </div>
            <button
              onClick={() => handleRedeem('post_boost', 150, 'Post Flame Boost')}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs shrink-0 transition-all active:scale-95"
            >
              150 🪙
            </button>
          </div>

          {/* Shop Item 2 */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 font-semibold text-xs text-slate-100">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>Golden Neon Persona Aura</span>
              </div>
              <p className="text-[10px] text-slate-400">
                Gives your masked avatar a glowing cyber ring
              </p>
            </div>
            <button
              onClick={() => handleRedeem('neon_aura', 250, 'Golden Neon Aura')}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs shrink-0 transition-all active:scale-95"
            >
              250 🪙
            </button>
          </div>

          {/* Shop Item 3 */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 font-semibold text-xs text-slate-100">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>Campus Batch Clue</span>
              </div>
              <p className="text-[10px] text-slate-400">
                Reveals department of an anonymous confession
              </p>
            </div>
            <button
              onClick={() => handleRedeem('batch_clue', 300, 'Campus Batch Clue')}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs shrink-0 transition-all active:scale-95"
            >
              300 🪙
            </button>
          </div>

          {/* Shop Item 4 */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 font-semibold text-xs text-slate-100">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>Secret Gossip+ VIP Month</span>
              </div>
              <p className="text-[10px] text-slate-400">
                Unlimited anonymous DMs & VIP crown
              </p>
            </div>
            <button
              onClick={() => handleRedeem('vip_pass', 500, 'Secret Gossip+ VIP Month')}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs shrink-0 transition-all active:scale-95"
            >
              500 🪙
            </button>
          </div>
        </div>
      </div>

      {/* Friends Who Joined via Your Link */}
      <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-4 sm:p-5 space-y-3">
        <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
          <Users className="w-4 h-4 text-cyan-400" />
          <span>Friends Invited ({invitedFriends.length})</span>
        </h3>
        {invitedFriends.length === 0 ? (
          <p className="text-center py-6 text-xs text-slate-500">
            No classmates have joined with your link yet. Share your deep-link above to earn your first 100 Secret Coins!
          </p>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {invitedFriends.map(f => (
              <div key={f.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-sm">
                    {f.avatarEmoji}
                  </div>
                  <div>
                    <span className="font-semibold text-slate-200 block">{f.avatarName}</span>
                    <span className="font-mono text-[10px] text-slate-500">{f.maskedId} • {f.joinedAt}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-2 py-0.5 rounded-full block">
                    +{f.coinsAwarded} Coins
                  </span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wider">Verified Campus</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
