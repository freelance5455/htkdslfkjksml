import React from 'react';
import { DoorOpen, Eye, Users, X } from 'lucide-react';
import {
  BOX_IDS,
  OUTSIDE_PEN_CAPACITY,
  PUP_ADULT_AGE_SEC,
  formatDurationShort,
  formatLocationLabel,
} from '../data/kennelConstants';
import { isPup } from '../engine/simulation';
import { Dog, GameState, HabitatLocationId } from '../types/kennel';
import { DogPortrait } from './DogPortrait';

interface FacilityViewProps {
  state: GameState;
  onEnterLocation: (loc: HabitatLocationId | 'corridor') => void;
  onObserveLocation: (loc: HabitatLocationId | null) => void;
  onSelectDogJournal: (dogId: string) => void;
}

export const FacilityView: React.FC<FacilityViewProps> = ({
  state,
  onEnterLocation,
  onObserveLocation,
  onSelectDogJournal,
}) => {
  const outsideDogs = state.dogs.filter((d) => d.location === 'outside_pen');
  const nurseryDogs = state.dogs.filter((d) => d.location === 'nursery_pen');
  const adultCount = state.dogs.filter((d) => !isPup(d)).length;
  const pupCount = state.dogs.filter((d) => isPup(d)).length;

  const observedLoc = state.observingLocation;
  const observedDogs: Dog[] = observedLoc
    ? state.dogs.filter((d) => d.location === observedLoc)
    : [];

  return (
    <div className="space-y-6">
      {/* Summary Header Strip */}
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#DFDBD0]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18]">
            Kennel Facility Map
          </h1>
          <p className="mt-1 text-sm text-[#5C584F] max-w-2xl">
            21 individual stalls, the 6-dog Outside Pen, and the Nursery Pen. Detailed behavior logs remain unseen unless you step inside a habitat.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#5C584F] font-mono-tabular">
          <span>Adults: {adultCount}</span>
          <span aria-hidden="true">·</span>
          <span>Pups: {pupCount}</span>
          <span aria-hidden="true">·</span>
          <span>Credits: {state.kennelCredits}</span>
          <span aria-hidden="true">·</span>
          <span>At: {formatLocationLabel(state.playerLocation)}</span>
        </div>
      </section>

      {/* Outside Observation Drawer when peeking from Corridor */}
      {observedLoc && (
        <section className="rounded-2xl bg-white border border-[#DFDBD0] p-4 sm:p-5">
          <div className="flex items-start justify-between gap-4 pb-3 border-b border-[#EFECE4]">
            <div>
              <p className="text-xs font-medium text-[#9A5B13]">
                Observing from Outside Gate · Internal events remain hidden
              </p>
              <h2 className="font-display text-xl font-semibold text-[#1C1B18] mt-0.5">
                {formatLocationLabel(observedLoc)}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onEnterLocation(observedLoc)}
                className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors whitespace-nowrap cursor-pointer"
              >
                <DoorOpen className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Enter Habitat</span>
              </button>
              <button
                type="button"
                onClick={() => onObserveLocation(null)}
                aria-label="Close observation"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border border-[#DFDBD0] text-[#5C584F] hover:bg-[#EFECE4] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-[#5C584F] font-mono-tabular">
            <span>Feed bowl: {Math.round(state.bowls[observedLoc].food)}%</span>
            <span aria-hidden="true">·</span>
            <span>Water bowl: {Math.round(state.bowls[observedLoc].water)}%</span>
            <span className="font-sans text-[#7A7467]">
              (Enter the habitat to refill bowls or interact.)
            </span>
          </div>

          {observedDogs.length === 0 ? (
            <p className="mt-4 text-sm text-[#5C584F]">
              Looking through the mesh: the enclosure is empty right now.
            </p>
          ) : (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {observedDogs.map((dog) => {
                const pup = isPup(dog);
                return (
                  <div
                    key={dog.id}
                    className="rounded-xl bg-[#F7F5F0] border border-[#DFDBD0] p-3 flex flex-col gap-2.5"
                  >
                    <DogPortrait
                      name={dog.name}
                      genetics={dog.genetics}
                      isPup={pup}
                      compact
                    />
                    <div className="flex items-baseline justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onSelectDogJournal(dog.id)}
                        className="font-semibold text-sm text-[#1C1B18] hover:underline text-left cursor-pointer"
                      >
                        {dog.name}
                      </button>
                      <span className="text-xs text-[#5C584F] font-mono-tabular">
                        {dog.gender} · {pup ? 'Pup' : 'Adult'}
                      </span>
                    </div>
                    <p className="text-xs text-[#4A463E]">
                      Visible through mesh: {dog.currentBehavior}.
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* Shared Enclosures: Outside Pen & Nursery Pen */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Outside Pen */}
        <div className="rounded-2xl bg-white border border-[#DFDBD0] p-5 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium text-[#5C584F] font-mono-tabular">
                  Shared Run · {outsideDogs.length}/{OUTSIDE_PEN_CAPACITY} Housed
                </p>
                <h2 className="font-display text-xl font-semibold text-[#1C1B18] mt-0.5">
                  Outside Pen
                </h2>
              </div>
              {state.playerLocation === 'outside_pen' && (
                <span className="text-xs font-semibold text-[#1F4E3D]">You are here</span>
              )}
            </div>
            <p className="mt-2 text-sm text-[#5C584F]">
              Houses up to 6 dogs with climbing timber, digging earth, rope toys, and open pack dynamics.
            </p>
            {outsideDogs.length > 0 && (
              <p className="mt-3 text-xs text-[#1C1B18]">
                Occupants: {outsideDogs.map((d) => d.name).join(', ')}
              </p>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#EFECE4]">
            <button
              type="button"
              onClick={() => onEnterLocation('outside_pen')}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
            >
              <DoorOpen className="w-4 h-4" aria-hidden="true" />
              <span>{state.playerLocation === 'outside_pen' ? 'View Outside Pen' : 'Enter Pen'}</span>
            </button>
            <button
              type="button"
              onClick={() => onObserveLocation('outside_pen')}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
            >
              <Eye className="w-4 h-4" aria-hidden="true" />
              <span>Observe Outside</span>
            </button>
          </div>
        </div>

        {/* Nursery Pen */}
        <div className="rounded-2xl bg-white border border-[#DFDBD0] p-5 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium text-[#5C584F] font-mono-tabular">
                  Juvenile Wing · {nurseryDogs.length} Pups
                </p>
                <h2 className="font-display text-xl font-semibold text-[#1C1B18] mt-0.5">
                  Nursery Pen
                </h2>
              </div>
              {state.playerLocation === 'nursery_pen' && (
                <span className="text-xs font-semibold text-[#1F4E3D]">You are here</span>
              )}
            </div>
            <p className="mt-2 text-sm text-[#5C584F]">
              Born pups remain here until adulthood (1 hour). Pups appear patternless until full maturation.
            </p>
            {nurseryDogs.length > 0 ? (
              <p className="mt-3 text-xs text-[#1C1B18]">
                Pups:{' '}
                {nurseryDogs
                  .map((p) => {
                    const left = Math.max(0, PUP_ADULT_AGE_SEC - p.ageSeconds);
                    return `${p.name} (${formatDurationShort(left)} to adult)`;
                  })
                  .join(', ')}
              </p>
            ) : (
              <p className="mt-3 text-xs text-[#7A7467]">No newborn pups currently housed.</p>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#EFECE4]">
            <button
              type="button"
              onClick={() => onEnterLocation('nursery_pen')}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
            >
              <Users className="w-4 h-4" aria-hidden="true" />
              <span>{state.playerLocation === 'nursery_pen' ? 'View Nursery' : 'Enter Nursery'}</span>
            </button>
            <button
              type="button"
              onClick={() => onObserveLocation('nursery_pen')}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
            >
              <Eye className="w-4 h-4" aria-hidden="true" />
              <span>Observe Outside</span>
            </button>
          </div>
        </div>
      </section>

      {/* 21 Kennel Boxes */}
      <section>
        <div className="flex items-baseline justify-between gap-4 mb-3">
          <h2 className="font-display text-xl font-semibold text-[#1C1B18]">
            Kennel Boxes (01–21)
          </h2>
          <button
            type="button"
            onClick={() => onEnterLocation('corridor')}
            className="text-xs font-medium text-[#1F4E3D] hover:underline cursor-pointer"
          >
            Stand in Outside Corridor
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {BOX_IDS.map((boxId) => {
            const occupant = state.dogs.find((d) => d.location === boxId);
            const bowl = state.bowls[boxId];
            const isHere = state.playerLocation === boxId;

            return (
              <div
                key={boxId}
                className={`rounded-xl bg-white border p-3.5 flex flex-col justify-between gap-3 transition-colors ${
                  isHere ? 'border-[#1F4E3D] ring-1 ring-[#1F4E3D]/30' : 'border-[#DFDBD0]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono-tabular text-xs font-semibold text-[#5C584F]">
                      {formatLocationLabel(boxId)}
                    </span>
                    {isHere && (
                      <span className="text-[11px] font-semibold text-[#1F4E3D]">Inside</span>
                    )}
                  </div>

                  {occupant ? (
                    <div className="mt-1.5">
                      <button
                        type="button"
                        onClick={() => onSelectDogJournal(occupant.id)}
                        className="font-semibold text-base text-[#1C1B18] hover:underline text-left cursor-pointer"
                      >
                        {occupant.name}
                      </button>
                      <p className="text-xs text-[#5C584F] capitalize mt-0.5">
                        {occupant.gender} · {occupant.genetics.coat} · {isPup(occupant) ? 'Pup' : occupant.genetics.pattern}
                      </p>
                      <div className="mt-1.5 flex items-center gap-3 text-[11px] text-[#5C584F] font-mono-tabular">
                        <span>HP {Math.round(occupant.stats.health)}%</span>
                        <span>Hunger {Math.round(occupant.stats.hunger)}%</span>
                      </div>
                    </div>
                  ) : (
                    <p className="mt-2 text-sm text-[#8A8478]">Empty box</p>
                  )}

                  <div className="mt-2 flex items-center gap-3 text-[11px] text-[#7A7467] font-mono-tabular">
                    <span>Food {Math.round(bowl.food)}%</span>
                    <span>Water {Math.round(bowl.water)}%</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-[#EFECE4]">
                  <button
                    type="button"
                    onClick={() => onEnterLocation(boxId)}
                    className="flex-1 min-h-[40px] px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
                  >
                    {isHere ? 'Active' : 'Enter'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onObserveLocation(boxId)}
                    className="min-h-[40px] px-3 py-1.5 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
                  >
                    Observe
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
