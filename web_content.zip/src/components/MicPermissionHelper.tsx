import React from 'react';
import { MicOff, Settings, RefreshCw, AlertTriangle } from 'lucide-react';

interface MicPermissionHelperProps {
  errorType: 'denied' | 'notfound' | 'error';
  onRetry: () => void;
  onDismiss: () => void;
}

export const MicPermissionHelper: React.FC<MicPermissionHelperProps> = ({
  errorType,
  onRetry,
  onDismiss,
}) => {
  return (
    <div className="p-4 mx-4 my-3 bg-amber-50/90 border border-amber-200 rounded-2xl shadow-xs text-xs text-amber-950">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
          <MicOff className="w-4 h-4" />
        </div>
        <div className="flex-1 space-y-1.5">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-amber-900 text-sm">Microphone Access Needed</h4>
            <button
              onClick={onDismiss}
              className="text-amber-700 hover:text-amber-900 font-semibold text-[11px] cursor-pointer"
            >
              Dismiss
            </button>
          </div>
          <p className="text-amber-800 leading-relaxed">
            {errorType === 'denied'
              ? 'Microphone permission was declined. To speak naturally with Blame:'
              : 'Could not access audio device. Please check your microphone connection.'}
          </p>

          <div className="bg-white/80 p-2.5 rounded-xl border border-amber-200/60 space-y-1 text-[11px] text-amber-900">
            <p className="font-semibold flex items-center gap-1">
              <Settings className="w-3 h-3 text-amber-600" />
              On Mobile (Android Chrome / Safari):
            </p>
            <ol className="list-decimal list-inside space-y-0.5 text-amber-800 pl-1">
              <li>Tap the <strong>Lock / Settings icon (🔒)</strong> in the top browser bar</li>
              <li>Select <strong>Permissions</strong> &gt; <strong>Microphone</strong></li>
              <li>Change to <strong>Allow</strong>, then tap Retry below</li>
            </ol>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={onRetry}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Permission</span>
            </button>
            <span className="text-[11px] text-amber-700">Or use Text Fallback below anytime</span>
          </div>
        </div>
      </div>
    </div>
  );
};
