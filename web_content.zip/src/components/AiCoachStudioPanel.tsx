import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Lightbulb,
  Mic,
  PenTool,
  Play,
  RefreshCw,
  RotateCcw,
  Send,
  Sparkles,
  Square,
  Volume2,
} from 'lucide-react';
import type {
  ArticleItem,
  CefrBand,
  PictureScenePrompt,
  WritingEvaluationResult,
  WritingTopicPrompt,
} from '../types';
import {
  blobToBase64,
  evaluateWritingTaskWithAi,
  generateWritingTopicWithAi,
} from '../utils/aiApi';
import { speakEn } from '../utils/audio';
import {
  buildDiffSegments,
  PICTURE_SCENES,
  WRITING_TOPICS,
} from '../utils/writingLogic';

interface AiCoachStudioPanelProps {
  mode: 'picture' | 'topic' | 'article_summary';
  level: CefrBand;
  ttsRate: number;
  unsplashKey: string;
  activeArticle: ArticleItem | null;
  onOpenArticles: () => void;
  onToast: (msg: string) => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}
interface SpeechRecognitionResultLike {
  0: SpeechRecognitionAlternativeLike;
}
interface SpeechRecognitionEventLike {
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRec(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export function AiCoachStudioPanel({
  mode,
  level,
  ttsRate,
  unsplashKey,
  activeArticle,
  onOpenArticles,
  onToast,
}: AiCoachStudioPanelProps) {
  // Picture Scene state
  const [sceneIdx, setSceneIdx] = useState(0);
  const [livePhotoUrl, setLivePhotoUrl] = useState<string>('');
  const [photoCredit, setPhotoCredit] = useState<string>('');
  const [loadingPhoto, setLoadingPhoto] = useState(false);

  // Topic Writing state
  const [topicIdx, setTopicIdx] = useState(0);
  const [customTopic, setCustomTopic] = useState<WritingTopicPrompt | null>(null);
  const [generatingTopic, setGeneratingTopic] = useState(false);
  const seenTopicTitlesRef = useRef<string[]>(WRITING_TOPICS.map((t) => t.titleEn));

  // Article peek toggle
  const [showArticleBody, setShowArticleBody] = useState(false);

  // Learner draft + voice + evaluation state
  const [draftText, setDraftText] = useState('');
  const [evaluating, setEvaluating] = useState(false);
  const [evaluation, setEvaluation] = useState<WritingEvaluationResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const [recording, setRecording] = useState(false);
  const [liveSpeech, setLiveSpeech] = useState('');
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordedMime, setRecordedMime] = useState('audio/webm');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const baseDraftRef = useRef('');
  const audioUrlRef = useRef<string | null>(null);

  const currentScene: PictureScenePrompt = PICTURE_SCENES[sceneIdx % PICTURE_SCENES.length];
  const currentTopic: WritingTopicPrompt = customTopic || WRITING_TOPICS[topicIdx % WRITING_TOPICS.length];

  const cleanupRecording = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    mediaRecorderRef.current = null;
    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupRecording();
      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
    };
  }, [cleanupRecording]);

  // Reset draft & results when mode or active article changes
  useEffect(() => {
    cleanupRecording();
    setRecording(false);
    setLiveSpeech('');
    setDraftText('');
    setEvaluation(null);
    setErrorMsg('');
    setRecordedBlob(null);
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    setAudioUrl(null);
  }, [mode, activeArticle?.id, cleanupRecording]);

  // Fetch crisp Unsplash photo when scene changes in picture mode (with instant fallback URL)
  useEffect(() => {
    if (mode !== 'picture') return;
    let active = true;
    setLivePhotoUrl(currentScene.fallbackImageUrl);
    setPhotoCredit('');

    if (!unsplashKey) return;
    setLoadingPhoto(true);
    const loadScenePhoto = async () => {
      try {
        const url = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(
          currentScene.unsplashQuery
        )}&page=1&per_page=8&orientation=landscape&content_filter=high&client_id=${encodeURIComponent(
          unsplashKey
        )}`;
        const res = await fetch(url);
        if (!res.ok) return;
        const data = (await res.json()) as {
          results?: Array<{
            urls?: { regular?: string };
            user?: { name?: string };
          }>;
        };
        const items = data.results || [];
        if (active && items.length > 0) {
          const pick = items[sceneIdx % items.length];
          if (pick.urls?.regular) {
            setLivePhotoUrl(pick.urls.regular);
            setPhotoCredit(pick.user?.name || '');
          }
        }
      } catch {
        // Keep reliable curated fallback URL
      } finally {
        if (active) setLoadingPhoto(false);
      }
    };
    void loadScenePhoto();
    return () => {
      active = false;
    };
  }, [mode, sceneIdx, currentScene.unsplashQuery, currentScene.fallbackImageUrl, unsplashKey]);

  const handleNextScene = () => {
    setSceneIdx((i) => (i + 1) % PICTURE_SCENES.length);
    setDraftText('');
    setEvaluation(null);
    setErrorMsg('');
    setRecordedBlob(null);
  };

  const handleNextTopic = async (useAi: boolean) => {
    setDraftText('');
    setEvaluation(null);
    setErrorMsg('');
    setRecordedBlob(null);

    if (!useAi) {
      setCustomTopic(null);
      setTopicIdx((i) => (i + 1) % WRITING_TOPICS.length);
      return;
    }

    setGeneratingTopic(true);
    try {
      const fresh = await generateWritingTopicWithAi({
        level,
        previousTitles: seenTopicTitlesRef.current,
      });
      seenTopicTitlesRef.current = [...seenTopicTitlesRef.current.slice(-10), fresh.titleEn];
      setCustomTopic(fresh);
    } catch (err) {
      // Fallback smoothly to next curated topic if AI rate-limited
      setCustomTopic(null);
      setTopicIdx((i) => (i + 1) % WRITING_TOPICS.length);
      onToast(err instanceof Error ? err.message : 'تم التبديل لموضوع جديد.');
    } finally {
      setGeneratingTopic(false);
    }
  };

  const stopVoiceCapture = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;
    const rec = mediaRecorderRef.current;
    if (rec && rec.state !== 'inactive') {
      rec.stop();
    } else {
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
      setRecording(false);
    }
  }, []);

  const startVoiceCapture = useCallback(async () => {
    if (recording) {
      stopVoiceCapture();
      return;
    }
    if (evaluating) return;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    baseDraftRef.current = draftText.trim();
    transcriptRef.current = '';
    chunksRef.current = [];
    setLiveSpeech('');
    setErrorMsg('');
    setRecording(true);

    const SR = getSpeechRec();
    if (SR) {
      try {
        const rec = new SR();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (ev) => {
          let spoken = '';
          for (let i = 0; i < ev.results.length; i++) {
            spoken += ev.results[i][0].transcript + ' ';
          }
          const clean = spoken.trim();
          transcriptRef.current = clean;
          setLiveSpeech(clean);
          const merged = baseDraftRef.current
            ? `${baseDraftRef.current} ${clean}`.trim()
            : clean;
          setDraftText(merged);
        };
        rec.onerror = () => {
          // Audio MediaRecorder still captures voice
        };
        rec.start();
        speechRecRef.current = rec;
      } catch {
        speechRecRef.current = null;
      }
    }

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm'
            : MediaRecorder.isTypeSupported('audio/mp4')
              ? 'audio/mp4'
              : '';

        const recorder = preferredMime
          ? new MediaRecorder(stream, { mimeType: preferredMime })
          : new MediaRecorder(stream);
        const actualMime = (recorder.mimeType || preferredMime || 'audio/webm').split(';')[0];

        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
        };

        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: actualMime });
          chunksRef.current = [];
          mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
          mediaStreamRef.current = null;
          mediaRecorderRef.current = null;
          setRecording(false);

          if (audioUrlRef.current) {
            URL.revokeObjectURL(audioUrlRef.current);
            audioUrlRef.current = null;
          }
          if (blob.size > 400) {
            const url = URL.createObjectURL(blob);
            audioUrlRef.current = url;
            setAudioUrl(url);
            setRecordedBlob(blob);
            setRecordedMime(actualMime);
          }
        };

        mediaRecorderRef.current = recorder;
        recorder.start();
      } catch {
        if (!speechRecRef.current) {
          setRecording(false);
          onToast('يرجى السماح بصلاحية الميكروفون أو الكتابة مباشرة.');
        }
      }
    } else if (!speechRecRef.current) {
      setRecording(false);
      onToast('التسجيل الصوتي غير مدعوم في هذا المتصفح، يمكنك الكتابة أدناه.');
    }
  }, [recording, evaluating, draftText, stopVoiceCapture, onToast]);

  const handleSubmitEvaluation = async () => {
    const cleanText = draftText.trim();
    if (!cleanText && !recordedBlob) {
      setErrorMsg('اكتب جملك بالإنجليزية أو سجّلها بصوتك أولاً ثم اضغط على زر التصحيح.');
      return;
    }

    if (mode === 'article_summary' && !activeArticle) {
      setErrorMsg('اختر مقالة أولاً من قسم المقالات لتلخيصها.');
      return;
    }

    setEvaluating(true);
    setErrorMsg('');
    try {
      const contextTitle =
        mode === 'picture'
          ? currentScene.titleEn
          : mode === 'topic'
            ? currentTopic.titleEn
            : activeArticle!.title;

      const contextText =
        mode === 'picture'
          ? currentScene.sceneDescriptionEn
          : mode === 'topic'
            ? currentTopic.promptEn
            : activeArticle!.paragraphs.join('\n\n');

      const audioBase64 =
        recordedBlob && recordedBlob.size > 400 && !cleanText
          ? await blobToBase64(recordedBlob)
          : undefined;

      const res = await evaluateWritingTaskWithAi({
        taskType: mode,
        level,
        contextTitle,
        contextText,
        userText: cleanText || undefined,
        audioBase64,
        audioMimeType: recordedMime,
      });

      if (res.userText && !cleanText) {
        setDraftText(res.userText);
      }
      setEvaluation(res);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'تعذر تصحيح إجابتك حالياً. حاول مرة أخرى.');
    } finally {
      setEvaluating(false);
    }
  };

  // Empty state if user clicked Article Summary tab directly without selecting an article first
  if (mode === 'article_summary' && !activeArticle) {
    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-[#162032]">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
          <BookOpen className="h-7 w-7" aria-hidden="true" />
        </div>
        <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
          اختر مقالة أولاً لتلخيصها مع الذكاء الاصطناعي
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-slate-500 dark:text-slate-400">
          انتقل إلى قسم «المقالات»، اقرأ أي مقالة أو قصة قصيرة تحبها، ثم اضغط على زر «لخّص هذه المقالة مع الذكاء الاصطناعي» لتتدرّب على تلخيصها بالصوت أو بالكتابة.
        </p>
        <button
          type="button"
          onClick={onOpenArticles}
          className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-6 text-sm font-bold text-white hover:bg-indigo-700"
        >
          <BookOpen className="h-4 w-4" aria-hidden="true" />
          <span>الانتقال إلى قسم المقالات</span>
        </button>
      </section>
    );
  }

  const wordCount = draftText.trim() ? draftText.trim().split(/\s+/).length : 0;
  const sentenceCount = draftText.trim()
    ? draftText
        .trim()
        .split(/[.!?؟\n]+/)
        .filter((s) => s.trim().length > 2).length
    : 0;

  const evalDiffSegments = evaluation
    ? buildDiffSegments(evaluation.userText, evaluation.correctedText, evaluation.wrongParts)
    : [];

  return (
    <div className="space-y-4">
      {/* ===================== 1) PICTURE DESCRIPTION PROMPT ===================== */}
      {mode === 'picture' && (
        <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#162032]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-5 py-3.5 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4 text-indigo-500" aria-hidden="true" />
              <h2 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 sm:text-base">
                صف هذه الصورة بعدة جمل إنجليزية ({currentScene.titleAr})
              </h2>
            </div>
            <button
              type="button"
              onClick={handleNextScene}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loadingPhoto ? 'animate-spin' : ''}`} aria-hidden="true" />
              <span>صورة جديدة</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-5 p-5 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <div className="relative h-56 w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-700 dark:bg-slate-900 sm:h-72">
                <img
                  src={livePhotoUrl || currentScene.fallbackImageUrl}
                  alt={currentScene.titleEn}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                {photoCredit && (
                  <span className="absolute bottom-2 left-2 rounded-md bg-slate-950/65 px-2 py-0.5 text-[10px] font-semibold text-white">
                    Photo: {photoCredit}
                  </span>
                )}
              </div>
            </div>

            <div className="flex flex-col justify-between space-y-4 lg:col-span-5">
              <div>
                <div className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                  أسئلة مساعدة لوصف الصورة:
                </div>
                <ul className="mt-2 space-y-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {currentScene.guidingQuestionsAr.map((q, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-indigo-50 font-code text-[10px] font-bold text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-300">
                        {idx + 1}
                      </span>
                      <span>{q}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <div className="mb-1.5 text-xs font-bold text-slate-500 dark:text-slate-400">
                  كلمات مفيدة يمكنك استخدامها:
                </div>
                <div className="flex flex-wrap gap-1.5" dir="ltr">
                  {currentScene.helpfulWords.map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => speakEn(w, ttsRate, onToast)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 font-en text-xs font-bold text-slate-700 hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ===================== 2) TOPIC WRITING PROMPT ===================== */}
      {mode === 'topic' && (
        <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#162032]">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                <Lightbulb className="h-4 w-4" aria-hidden="true" />
                <span>موضوع الكتابة المقترح ({currentTopic.level})</span>
              </div>
              <h2 className="font-en text-xl font-extrabold text-slate-900 dark:text-slate-100" dir="ltr">
                {currentTopic.titleEn}
              </h2>
              <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                {currentTopic.titleAr}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={generatingTopic}
                onClick={() => void handleNextTopic(false)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>موضوع آخر</span>
              </button>
              <button
                type="button"
                disabled={generatingTopic}
                onClick={() => void handleNextTopic(true)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50"
              >
                <Sparkles className={`h-3.5 w-3.5 ${generatingTopic ? 'animate-spin' : ''}`} aria-hidden="true" />
                <span>{generatingTopic ? 'جاري التوليد...' : 'فكرة جديدة بالذكاء الاصطناعي'}</span>
              </button>
            </div>
          </div>

          <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700/80 dark:bg-slate-900/60">
            <p dir="ltr" className="text-left font-en text-sm font-bold text-slate-800 dark:text-slate-100">
              {currentTopic.promptEn}
            </p>
            <p className="mt-2 border-t border-slate-200/80 pt-2 text-xs font-semibold text-slate-600 dark:border-slate-700/80 dark:text-slate-300">
              {currentTopic.promptAr}
            </p>
            {currentTopic.keywords.length > 0 && (
              <div className="mt-3 flex flex-wrap items-center gap-1.5" dir="ltr">
                {currentTopic.keywords.map((kw) => (
                  <span
                    key={kw}
                    className="rounded-md border border-indigo-200/70 bg-indigo-50/70 px-2.5 py-0.5 font-en text-xs font-bold text-indigo-700 dark:border-indigo-700/50 dark:bg-indigo-950/40 dark:text-indigo-300"
                  >
                    {kw}
                  </span>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ===================== 3) ARTICLE SUMMARY PROMPT ===================== */}
      {mode === 'article_summary' && activeArticle && (
        <section className="rounded-2xl border border-indigo-200 bg-white p-5 dark:border-indigo-500/40 dark:bg-[#162032]">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                <BookOpen className="h-4 w-4" aria-hidden="true" />
                <span>مهمة تلخيص المقالة مع الذكاء الاصطناعي ({activeArticle.level})</span>
              </div>
              <h2 className="mt-1 font-en text-xl font-extrabold text-slate-900 dark:text-slate-100" dir="ltr">
                {activeArticle.title}
              </h2>
              <p className="text-sm font-bold text-slate-600 dark:text-slate-300">
                {activeArticle.titleAr}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setShowArticleBody((v) => !v)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                {showArticleBody ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                <span>{showArticleBody ? 'إخفاء نص المقالة' : 'مراجعة نص المقالة'}</span>
              </button>
              <button
                type="button"
                onClick={onOpenArticles}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50 px-3 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-700/60 dark:bg-indigo-950/40 dark:text-indigo-300"
              >
                <span>تغيير المقالة</span>
              </button>
            </div>
          </div>

          <div className="mt-4 rounded-xl border border-indigo-200/70 bg-indigo-50/50 p-4 dark:border-indigo-800/50 dark:bg-indigo-950/30">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p dir="ltr" className="text-left font-en text-sm font-bold text-slate-900 dark:text-slate-100">
                  Great job reading &ldquo;{activeArticle.title}&rdquo;! Now please summarize the main ideas in 3 to 5 English sentences — you can speak or write your summary below.
                </p>
                <p className="mt-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  أحسنت قراءة المقالة! الآن قدّم لي تلخيصاً بأسلوبك الخاص بالإنجليزية (بالصوت أو بالكتابة) في 3 إلى 5 جمل، وسأصحح لغتك وأقيّم استيعابك للأفكار الرئيسية.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  speakEn(
                    `Great job reading ${activeArticle.title}. Now please summarize the main ideas in your own words.`,
                    ttsRate,
                    onToast
                  )
                }
                aria-label="استمع لطلب المدرب"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-indigo-200 bg-white text-indigo-600 hover:bg-indigo-50 dark:border-indigo-700 dark:bg-slate-800 dark:text-indigo-300"
              >
                <Volume2 className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          {showArticleBody && (
            <div
              dir="ltr"
              className="mt-3 max-h-60 space-y-2.5 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-4 text-left font-en text-sm leading-relaxed text-slate-700 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-200"
            >
              {activeArticle.paragraphs.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>
          )}
        </section>
      )}

      {/* ===================== LEARNER VOICE + WRITING COMPOSER ===================== */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#162032]">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-slate-100">
            <PenTool className="h-4 w-4 text-indigo-500" aria-hidden="true" />
            <span>
              {mode === 'picture'
                ? 'تحدّث أو اكتب عدة جمل لوصف الصورة'
                : mode === 'topic'
                  ? 'اكتب (أو أمْلِ بصوتك) عدة جمل عن الموضوع'
                  : 'قدّم تلخيصك للمقالة بالصوت أو بالكتابة'}
            </span>
          </div>

          <div className="flex items-center gap-3 font-code text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>{sentenceCount} جمل</span>
            <span aria-hidden="true">·</span>
            <span>{wordCount} كلمة</span>
          </div>
        </div>

        <textarea
          dir="ltr"
          rows={5}
          value={draftText}
          disabled={evaluating}
          onChange={(e) => {
            setDraftText(e.target.value);
            if (errorMsg) setErrorMsg('');
          }}
          aria-label="مساحة الكتابة أو التفريغ الصوتي بالإنجليزية"
          placeholder={
            mode === 'picture'
              ? 'Describe the picture in 3-5 English sentences (or tap the mic button to speak)...'
              : mode === 'topic'
                ? 'Write 3-5 English sentences about this topic...'
                : 'Write or speak your summary of the article in English...'
          }
          className="w-full rounded-xl border border-slate-200 bg-slate-50 p-4 text-left font-en text-sm leading-relaxed font-semibold text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100 dark:focus:border-indigo-400 dark:focus:bg-slate-900 sm:text-base"
        />

        {recording && (
          <div className="mt-3 rounded-xl border border-rose-300 bg-rose-50 p-3 dark:border-rose-800 dark:bg-rose-950/40">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-600" />
                جاري تسجيل صوتك بالإنجليزية... تحدث بعدة جمل ثم اضغط «إيقاف التسجيل»
              </div>
              <button
                type="button"
                onClick={stopVoiceCapture}
                className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-rose-600 px-3 text-xs font-bold text-white hover:bg-rose-700"
              >
                <Square className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>إيقاف التسجيل</span>
              </button>
            </div>
            {liveSpeech && (
              <p dir="ltr" className="mt-2 text-left font-en text-xs font-semibold text-slate-800 dark:text-slate-200">
                {liveSpeech}
              </p>
            )}
          </div>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={evaluating}
              onClick={() => void startVoiceCapture()}
              className={`inline-flex h-11 items-center gap-2 rounded-xl px-4 text-xs font-bold text-white transition-colors disabled:opacity-50 ${
                recording ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {recording ? (
                <>
                  <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                  <span>إيقاف التسجيل</span>
                </>
              ) : (
                <>
                  <Mic className="h-4 w-4" aria-hidden="true" />
                  <span>تحدث بصوتك (إضافة جمل)</span>
                </>
              )}
            </button>

            {audioUrl && !recording && (
              <button
                type="button"
                onClick={() => {
                  const a = new Audio(audioUrl);
                  void a.play().catch(() => {});
                }}
                className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                <span>اسمع صوتك</span>
              </button>
            )}

            {(draftText || recordedBlob || evaluation) && !evaluating && !recording && (
              <button
                type="button"
                onClick={() => {
                  setDraftText('');
                  setEvaluation(null);
                  setErrorMsg('');
                  setRecordedBlob(null);
                }}
                className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>مسح</span>
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={evaluating || recording || (!draftText.trim() && !recordedBlob)}
            onClick={() => void handleSubmitEvaluation()}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-6 text-sm font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-45"
          >
            <Send className="h-4 w-4" aria-hidden="true" />
            <span>
              {evaluating
                ? 'المدرب يصحح جملك...'
                : mode === 'picture'
                  ? 'انتهيت — صحّح جملي'
                  : mode === 'topic'
                    ? 'صحّح كتابتي الآن'
                    : 'إرسال التلخيص للتصحيح'}
            </span>
          </button>
        </div>

        {errorMsg && (
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-700 dark:border-rose-700/60 dark:bg-rose-950/35 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>{errorMsg}</span>
          </div>
        )}
      </section>

      {/* ===================== DETAILED AI CORRECTION REPORT ===================== */}
      {evaluation && !evaluating && (
        <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#162032]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              {evaluation.hasErrors ? (
                <AlertCircle className="h-5 w-5 text-amber-500" aria-hidden="true" />
              ) : (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" aria-hidden="true" />
              )}
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  {evaluation.hasErrors
                    ? 'تقرير التصحيح الشامل لجملك'
                    : 'أداء رائع! جملك صحيحة وطبيعية جداً'}
                </h3>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  {evaluation.overallFeedbackAr}
                </p>
              </div>
            </div>

            <span
              className={`rounded-xl px-3.5 py-1.5 font-code text-sm font-extrabold tabular-nums text-white ${
                evaluation.score >= 85
                  ? 'bg-emerald-600'
                  : evaluation.score >= 65
                    ? 'bg-amber-500'
                    : 'bg-rose-600'
              }`}
            >
              التقييم {evaluation.score}%
            </span>
          </div>

          {evaluation.contentFeedbackAr && (
            <div className="rounded-xl border border-indigo-200/70 bg-indigo-50/50 p-3.5 text-xs leading-relaxed font-semibold text-indigo-900 dark:border-indigo-800/50 dark:bg-indigo-950/30 dark:text-indigo-200">
              <span className="font-extrabold">تقييم المحتوى والأفكار: </span>
              {evaluation.contentFeedbackAr}
            </div>
          )}

          {/* Original Text with RED Underlines + Full Corrected Text Underneath */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700/80 dark:bg-slate-900/60">
            <div className="mb-1.5 text-xs font-bold text-slate-500 dark:text-slate-400">
              ما قلته / كتبته (الأخطاء تحتها خط أحمر):
            </div>
            <p
              dir="ltr"
              className="text-left font-en text-sm leading-relaxed font-bold text-slate-900 dark:text-slate-100 sm:text-base"
            >
              {evalDiffSegments.map((seg, i) =>
                seg.isError && evaluation.hasErrors ? (
                  <span
                    key={i}
                    className="rounded bg-rose-500/15 px-1 text-rose-600 underline decoration-rose-500 decoration-wavy decoration-2 underline-offset-4 dark:text-rose-400 dark:decoration-rose-400"
                  >
                    {seg.text}
                  </span>
                ) : (
                  <span key={i}>{seg.text}</span>
                )
              )}
            </p>

            <div className="mt-4 border-t border-slate-200 pt-3.5 dark:border-slate-700">
              <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-extrabold text-emerald-700 dark:text-emerald-400">
                  النص بالطريقة الصحيحة:
                </span>
                <button
                  type="button"
                  onClick={() => speakEn(evaluation.correctedText, ttsRate, onToast)}
                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 text-[11px] font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-700/60 dark:bg-emerald-950/50 dark:text-emerald-300"
                >
                  <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>اسمع النص الصحيح</span>
                </button>
              </div>
              <p
                dir="ltr"
                className="text-left font-en text-sm leading-relaxed font-extrabold text-emerald-700 dark:text-emerald-300 sm:text-base"
              >
                {evaluation.correctedText}
              </p>
            </div>
          </div>

          {/* Sentence-by-Sentence Breakdown */}
          {evaluation.sentenceFeedback.length > 0 && (
            <div className="space-y-2.5">
              <div className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
                تصحيح الجمل جملةً بجملة:
              </div>
              {evaluation.sentenceFeedback.map((item, idx) => {
                const segs = buildDiffSegments(item.original, item.corrected);
                return (
                  <div
                    key={idx}
                    className={`rounded-xl border p-3.5 text-xs sm:text-sm ${
                      item.hasError
                        ? 'border-rose-200 bg-rose-50/40 dark:border-rose-800/50 dark:bg-rose-950/20'
                        : 'border-emerald-200 bg-emerald-50/40 dark:border-emerald-800/50 dark:bg-emerald-950/20'
                    }`}
                  >
                    <p dir="ltr" className="text-left font-en font-bold text-slate-900 dark:text-slate-100">
                      {segs.map((s, si) =>
                        s.isError && item.hasError ? (
                          <span
                            key={si}
                            className="text-rose-600 underline decoration-rose-500 decoration-wavy decoration-2 underline-offset-4 dark:text-rose-400"
                          >
                            {s.text}
                          </span>
                        ) : (
                          <span key={si}>{s.text}</span>
                        )
                      )}
                    </p>
                    {item.hasError && item.corrected && (
                      <p
                        dir="ltr"
                        className="mt-1.5 text-left font-en font-extrabold text-emerald-700 dark:text-emerald-300"
                      >
                        ✓ {item.corrected}
                      </p>
                    )}
                    {item.explanationAr && (
                      <p className="mt-1.5 text-xs font-medium text-slate-600 dark:text-slate-300">
                        {item.explanationAr}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Improved Native Version + Useful Vocabulary */}
          {evaluation.improvedVersionEn && (
            <div className="rounded-xl border border-indigo-200 bg-indigo-50/40 p-4 dark:border-indigo-800/50 dark:bg-indigo-950/25">
              <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-indigo-700 dark:text-indigo-300">
                  <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>صياغة طبيعية مقترحة بمستوى متحدث أصلي ({level}):</span>
                </span>
                <button
                  type="button"
                  onClick={() => speakEn(evaluation.improvedVersionEn, ttsRate, onToast)}
                  className="inline-flex h-8 items-center gap-1 rounded-lg bg-white px-2.5 text-[11px] font-bold text-indigo-700 hover:bg-indigo-50 dark:bg-slate-800 dark:text-indigo-300"
                >
                  <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>استمع</span>
                </button>
              </div>
              <p dir="ltr" className="text-left font-en text-sm leading-relaxed font-semibold text-slate-800 dark:text-slate-100">
                {evaluation.improvedVersionEn}
              </p>
            </div>
          )}

          {evaluation.vocabularyTips.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                مفردات مفيدة لهذا الموضوع:
              </span>
              {evaluation.vocabularyTips.map((tip, i) => (
                <span
                  key={i}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  {tip}
                </span>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
