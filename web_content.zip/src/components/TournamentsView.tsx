import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { TournamentMatch } from '../types/index.ts';

export const TournamentsView: React.FC = () => {
  const { openJoinModal, setCurrentTab, showToast } = useApp();
  const [modeFilter, setModeFilter] = useState<'all' | 'solo' | 'squad'>('all');
  const [mapFilter, setMapFilter] = useState<string>('all');

  const matches: TournamentMatch[] = [
    {
      id: 'solo_1042',
      matchNumber: '#1042',
      title: 'Solo Battle Royale #1042',
      mode: 'solo',
      map: 'Bermuda',
      kickoffTime: '9.00 PM IST',
      kickoffSubtext: 'Today',
      entryFee: 30,
      bountyOrPrize: '₹20 / Elimination',
      bountyDescription: 'Earn ₹20 on every verified in-game kill! Even without Booyah, 2 kills recovers your entry fee + profit.',
      registeredCount: 38,
      totalCapacity: 48,
      statusBadge: 'Solo Bounty',
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQYORTQBzPK3DcSNwzz7dUFOxMJ-fwJZS9uGByOn6cITRZeiEXSgwNj4bpkKUp7LFWfBD1QmZt5O7x1EnZCip2xWF2YnKqGULpRRRfDTNtOjfojLSyJZRfSNoaQ2LKEVwM_ectW_4KFh7QoTRDT56SEPXtMr_0UAR7OW6wP0EmNg-JHREezOKPesK1GP39HbIDAXJV2JPiGFTLO7w9h1qIbA7mUWPD7ARe24fnCtnzHMcSkrudnkPiXQ',
      imageAlt: 'Free Fire Bermuda Sunset battleground landscape',
    },
    {
      id: 'squad_1045',
      matchNumber: '#1045',
      title: 'Squad Battle Royale #1045 (Prime Time)',
      mode: 'squad',
      map: 'Bermuda',
      kickoffTime: '11.00 PM IST',
      kickoffSubtext: 'Tonight',
      entryFee: 50,
      bountyOrPrize: '₹200 Coins (#1)',
      bountyDescription: 'Winning prize disbursed directly to squad leader or split equally across team.',
      registeredCount: 11,
      totalCapacity: 12,
      statusBadge: 'Prime Squad Cup',
      isHot: true,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBSe0QkW9t5GdDiIvVrf51m_kpYB2pxl1ngpijWFGg3cvPh9-4acxgo2yCmpTspPNUW_NM-TuMvDcsN21HI8pxZeL2e4vVtAMlwVFl6_k5w6UYRcz7djHAju7MaZgsyQ9g0FnizEpk4-g6NPsoTAmbvm9pg4V8odbYVXjzyMm9QfpVftM60_TKJi5pSEURA3WlnZAeu6HIvXfaZTr-yJ9r8mXvGa-FqTH87PEk4iGEUA9M7l5919FeO7A',
      imageAlt: 'Free Fire Bermuda Mill nighttime tactical battlefield',
    },
  ];

  const filteredMatches = matches.filter((m) => {
    const matchMode = modeFilter === 'all' || m.mode === modeFilter;
    const matchMap = mapFilter === 'all' || m.map === mapFilter;
    return matchMode && matchMap;
  });

  return (
    <div className="flex flex-col w-full">
      <div className="relative w-full overflow-hidden px-4 sm:px-6 lg:px-10 py-6">
        <div className="absolute -top-32 -left-20 w-96 h-96 rounded-full bg-primary-container/10 blur-3xl pointer-events-none"></div>
        <div className="absolute top-20 right-10 w-80 h-80 rounded-full bg-tertiary-container/10 blur-3xl pointer-events-none"></div>

        {/* HUD Meta Status Strip */}
        <div className="w-full flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 bg-[#191c22] px-6 py-2.5 rounded shadow-md">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff5e00] animate-ping"></span>
              <span className="font-label-sm text-label-sm uppercase text-primary font-bold">Lobby Engine v4.2</span>
            </div>
            <span className="text-surface-variant font-label-sm">/</span>
            <div className="flex items-center gap-1 text-on-surface-variant font-label-md text-label-md">
              <span className="material-symbols-outlined text-sm text-[#00dbe9]">bolt</span>
              <span>Room Verification: Instant OCR Auto-Audit</span>
            </div>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">
              Server Ping: <span className="text-tertiary-fixed font-bold">19ms</span> (South Asia)
            </span>
            <span className="text-surface-variant font-label-sm">/</span>
            <span className="font-label-sm text-label-sm uppercase text-secondary font-bold">Anti-Cheat: Active</span>
          </div>
        </div>

        {/* Page Header & Mode Metric Banner */}
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-end mb-10">
          <div className="lg:col-span-8 flex flex-col gap-1">
            <div className="flex items-center gap-1.5">
              <span className="px-1.5 py-0.5 rounded bg-[#272a31] text-[#ff5e00] font-label-sm text-label-sm uppercase font-bold tracking-widest">
                Live Arena Deck
              </span>
              <span className="text-surface-variant font-label-sm">#FF-COMPETITIVE</span>
            </div>
            <div className="flex flex-wrap items-baseline gap-2">
              <span className="font-display-xl text-3xl sm:text-5xl uppercase text-on-surface font-bold tracking-tight">
                Deployment Hub
              </span>
              <span className="font-headline-sm text-headline-sm uppercase text-[#00dbe9] font-bold">
                [Vetted Scrims]
              </span>
            </div>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-2xl">
              Lock your roster for validated mobile tournaments. Automatic Room ID distribution via encrypted notification, live kill-bounty claims, and instant wallet settlement upon match closure.
            </p>
          </div>

          {/* Quick Telemetry HUD Block */}
          <div className="lg:col-span-4 bg-surface-container p-4 rounded shadow-lg flex flex-col gap-2">
            <div className="flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm uppercase">
              <span>Daily Prize Pool Deployed</span>
              <span className="text-primary font-bold">₹18,500 COINS</span>
            </div>
            <div className="w-full bg-[#0b0e14] h-2 rounded overflow-hidden">
              <div className="bg-gradient-to-r from-primary-container to-secondary-container h-full w-3/4"></div>
            </div>
            <div className="flex items-center justify-between font-label-sm text-label-sm text-on-surface-variant">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00dbe9]"></span> 4 Rooms Live Now
              </span>
              <span className="text-tertiary-fixed font-bold">100% Payout Guaranteed</span>
            </div>
          </div>
        </div>

        {/* Master Filter Deck */}
        <div className="w-full bg-[#0b0e14] p-4 rounded shadow-xl mb-10 flex flex-col gap-4">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            {/* Mode Tabs */}
            <div className="flex flex-wrap items-center gap-1">
              <button
                onClick={() => setModeFilter('all')}
                className={`px-4 py-2 rounded font-label-md text-label-md uppercase tracking-wider font-bold transition-all cursor-pointer ${
                  modeFilter === 'all'
                    ? 'bg-[#ff5e00] text-[#531900] shadow-md'
                    : 'bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
                }`}
              >
                All Matches
              </button>
              <button
                onClick={() => setModeFilter('solo')}
                className={`px-4 py-2 rounded font-label-md text-label-md uppercase tracking-wider font-bold transition-all cursor-pointer ${
                  modeFilter === 'solo'
                    ? 'bg-[#ff5e00] text-[#531900] shadow-md'
                    : 'bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
                }`}
              >
                Solo Mode (₹30 Entry | ₹20/Kill)
              </button>
              <button
                onClick={() => setModeFilter('squad')}
                className={`px-4 py-2 rounded font-label-md text-label-md uppercase tracking-wider font-bold transition-all cursor-pointer ${
                  modeFilter === 'squad'
                    ? 'bg-[#ff5e00] text-[#531900] shadow-md'
                    : 'bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
                }`}
              >
                Squad Battle Royale (₹50 Entry | ₹200 Win)
              </button>
            </div>

            {/* Map Quick Selector & Rule Tab Button */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center bg-[#191c22] px-2 py-1 rounded">
                <span className="material-symbols-outlined text-sm text-on-surface-variant mr-1">map</span>
                {['all', 'Bermuda', 'Purgatory', 'Kalahari'].map((m) => (
                  <button
                    key={m}
                    onClick={() => setMapFilter(m)}
                    className={`font-label-sm text-label-sm uppercase px-2 py-1 rounded font-bold cursor-pointer transition-colors ${
                      mapFilter === m ? 'text-[#ff5e00] bg-surface-container' : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    {m === 'all' ? 'All' : m}
                  </button>
                ))}
              </div>
              <a
                href="#rules-section"
                className="flex items-center gap-1.5 px-4 py-2 rounded bg-surface-container-high text-tertiary-fixed font-label-md text-label-md uppercase hover:bg-surface-variant transition-colors"
              >
                <span className="material-symbols-outlined text-sm">menu_book</span>
                Tournament Rules
              </a>
            </div>
          </div>
        </div>

        {/* Match Cards Grid */}
        <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {filteredMatches.map((m) => {
            const isSquad = m.mode === 'squad';
            const progress = (m.registeredCount / m.totalCapacity) * 100;
            return (
              <div
                key={m.id}
                className="group relative bg-surface-container rounded overflow-hidden shadow-xl flex flex-col justify-between hover:bg-surface-container-high transition-all"
              >
                <div
                  className={`h-1.5 w-full bg-gradient-to-r ${
                    isSquad
                      ? 'from-secondary via-primary-container to-secondary'
                      : 'from-primary-container via-secondary-container to-primary-container'
                  }`}
                ></div>

                <div className="p-6 flex flex-col gap-4">
                  {/* Card Top Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span
                          className={`px-2 py-0.5 rounded font-label-sm text-label-sm uppercase font-bold ${
                            isSquad
                              ? 'bg-secondary/20 text-secondary'
                              : 'bg-primary-container/20 text-primary-container'
                          }`}
                        >
                          {m.statusBadge}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-[#0b0e14] text-[#00dbe9] font-label-sm text-label-sm uppercase font-bold">
                          Match {m.matchNumber}
                        </span>
                      </div>
                      <span
                        className={`font-headline-md text-headline-md uppercase text-on-surface font-bold transition-colors ${
                          isSquad ? 'group-hover:text-secondary' : 'group-hover:text-primary'
                        }`}
                      >
                        {m.title}
                      </span>
                    </div>

                    <div className="flex flex-col items-end">
                      <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                        Kickoff Time
                      </span>
                      <span className="font-headline-sm text-headline-sm uppercase text-secondary font-bold flex items-center gap-1">
                        <span className="material-symbols-outlined text-base">alarm</span>
                        {m.kickoffTime}
                      </span>
                      <span className="font-label-sm text-label-sm text-tertiary-fixed font-bold">
                        {m.kickoffSubtext}
                      </span>
                    </div>
                  </div>

                  {/* Graphic Strip Visual */}
                  <div className="relative w-full h-32 rounded overflow-hidden bg-[#0b0e14]">
                    <img className="w-full h-full object-cover" alt={m.imageAlt} src={m.image} />
                    <div className="absolute inset-0 bg-gradient-to-t from-surface-container via-transparent to-transparent"></div>
                    <div className="absolute bottom-2 left-3 flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-[#0b0e14]/90 backdrop-blur-md text-on-surface font-label-sm text-label-sm uppercase font-bold flex items-center gap-1">
                        <span className="material-symbols-outlined text-xs text-primary-container">explore</span>
                        {m.map}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-[#0b0e14]/90 backdrop-blur-md text-on-surface font-label-sm text-label-sm uppercase font-bold flex items-center gap-1">
                        <span className="material-symbols-outlined text-xs text-tertiary">
                          {isSquad ? 'military_tech' : 'smartphone'}
                        </span>
                        {isSquad ? 'Squad (4v4)' : 'Mobile Only'}
                      </span>
                    </div>

                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-[#0b0e14]/90 backdrop-blur-md font-label-sm text-label-sm uppercase font-bold flex items-center gap-1">
                      {isSquad ? (
                        <span className="text-error flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-error animate-pulse"></span> ALMOST FULL
                        </span>
                      ) : (
                        <span className="text-primary">Verified Arbiters</span>
                      )}
                    </div>
                  </div>

                  {/* Economics Matrix */}
                  <div className="grid grid-cols-3 gap-2 bg-[#0b0e14] p-4 rounded">
                    <div className="flex flex-col">
                      <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                        Entry Fee
                      </span>
                      <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                        ₹{m.entryFee}{' '}
                        <span className="text-xs font-normal text-on-surface-variant">
                          {isSquad ? '/ Team' : 'Coins'}
                        </span>
                      </span>
                    </div>

                    <div className="flex flex-col">
                      <span className={`font-label-sm text-label-sm uppercase font-semibold ${isSquad ? 'text-secondary' : 'text-primary'}`}>
                        {isSquad ? 'Winning Prize' : 'Kill Bounty'}
                      </span>
                      <span
                        className={`font-headline-sm text-headline-sm uppercase font-bold ${
                          isSquad ? 'text-secondary' : 'text-primary'
                        }`}
                      >
                        {isSquad ? '₹200' : '₹20'}{' '}
                        <span className="text-xs font-normal text-on-surface-variant">
                          {isSquad ? 'Coins (#1)' : '/ Elimination'}
                        </span>
                      </span>
                    </div>

                    <div className="flex flex-col items-end">
                      <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                        {isSquad ? 'Slot Status' : 'Spectators'}
                      </span>
                      <span className="font-headline-sm text-headline-sm uppercase text-primary font-bold">
                        {isSquad ? '1 Slot Left' : 'Live Bot'}
                      </span>
                    </div>
                  </div>

                  {/* Incentive Tagline */}
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#191c22] text-on-surface-variant font-body-sm text-body-sm">
                    <span className="material-symbols-outlined text-base text-[#ff5e00]">military_tech</span>
                    <span>
                      {isSquad ? (
                        <>Winning squad earns <strong className="text-secondary">₹200 Coins</strong> disbursed to leader wallet.</>
                      ) : (
                        <>Earn <strong className="text-primary">₹20 on every verified in-game kill</strong>! 2 kills recovers entry fee + profit.</>
                      )}
                    </span>
                  </div>

                  {/* Capacity Progress Bar */}
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between font-label-sm text-label-sm uppercase">
                      <span className="text-on-surface-variant font-semibold">
                        {isSquad ? 'Squad Capacity' : 'Registration Capacity'}
                      </span>
                      <span className="text-on-surface font-bold">
                        {isSquad
                          ? `${m.registeredCount} / ${m.totalCapacity} Squads Registered `
                          : `${m.registeredCount} / ${m.totalCapacity} Players `}
                        <span className="text-primary-container">
                          ({m.totalCapacity - m.registeredCount} {isSquad ? 'Final Slot!' : 'Left'})
                        </span>
                      </span>
                    </div>
                    <div className="w-full h-2.5 rounded bg-[#0b0e14] overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary-container to-secondary-container rounded"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Action Card Footer */}
                <div className="px-6 py-4 bg-[#0b0e14] flex items-center justify-between gap-4">
                  <div className="flex items-center gap-1.5 text-on-surface-variant font-label-sm text-label-sm uppercase font-semibold">
                    <span className="material-symbols-outlined text-sm text-[#00dbe9]">
                      {isSquad ? 'local_fire_department' : 'key'}
                    </span>
                    <span>{isSquad ? 'Fast Filling Match' : 'ID/Pass Sent 15m Prior'}</span>
                  </div>
                  <button
                    onClick={() => openJoinModal(m)}
                    className="px-6 py-2.5 rounded font-label-md text-label-md uppercase tracking-wider font-bold bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] transition-all shadow-md active:scale-95 flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{isSquad ? `Register Squad (₹${m.entryFee})` : `Join Now (₹${m.entryFee})`}</span>
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* TOURNAMENT RULEBOOK & PROTOCOLS SECTION */}
        <div className="w-full bg-[#191c22] rounded p-6 shadow-xl mb-10 flex flex-col gap-6" id="rules-section">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-primary text-base">policy</span>
                <span className="font-label-sm text-label-sm uppercase text-primary font-bold tracking-widest">
                  Protocol V3.9
                </span>
              </div>
              <span className="font-headline-lg text-2xl sm:text-4xl uppercase text-on-surface font-bold">
                Tournament Rulebook &amp; Compliance
              </span>
              <p className="font-body-md text-body-md text-on-surface-variant max-w-3xl">
                To ensure zero fraud, instant kill bounties, and safe withdrawals, every registered participant must adhere strictly to the following 4 tactical operational directives.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-surface-container px-4 py-2 rounded">
              <span className="material-symbols-outlined text-tertiary text-base">military_tech</span>
              <span className="font-label-sm text-label-sm uppercase text-tertiary-fixed font-bold">
                Instant Kill Auto-Auditor
              </span>
            </div>
          </div>

          {/* 4 Core Tactical Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Pillar 1 */}
            <div className="bg-surface-container p-4 rounded flex flex-col gap-2">
              <div className="w-10 h-10 rounded bg-primary-container/20 flex items-center justify-center text-primary-container">
                <span className="material-symbols-outlined text-2xl">document_scanner</span>
              </div>
              <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                1. Screenshot Verification
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Immediately upon elimination or victory, take a clear uncropped screenshot of the post-match summary showing your IGN, rank, and elimination tally. Upload within <strong>15 minutes</strong> via Match Room.
              </p>
              <div className="mt-auto pt-2 flex items-center gap-1.5 text-primary font-label-sm text-label-sm uppercase font-semibold">
                <span className="material-symbols-outlined text-xs">check_circle</span> Auto OCR OCR Validation
              </div>
            </div>

            {/* Pillar 2 */}
            <div className="bg-surface-container p-4 rounded flex flex-col gap-2">
              <div className="w-10 h-10 rounded bg-[#00dbe9]/20 flex items-center justify-center text-[#00dbe9]">
                <span className="material-symbols-outlined text-2xl">vpn_key</span>
              </div>
              <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                2. Room ID Distribution
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Custom room credentials (Room ID and Room Password) are published strictly <strong>15 minutes before</strong> scheduled kickoff on the dedicated Match Room tab and pushed via SMS alerts.
              </p>
              <div className="mt-auto pt-2 flex items-center gap-1.5 text-tertiary font-label-sm text-label-sm uppercase font-semibold">
                <span className="material-symbols-outlined text-xs">lock_clock</span> Lock-In at 5 Min Mark
              </div>
            </div>

            {/* Pillar 3 */}
            <div className="bg-surface-container p-4 rounded flex flex-col gap-2">
              <div className="w-10 h-10 rounded bg-secondary/20 flex items-center justify-center text-secondary">
                <span className="material-symbols-outlined text-2xl">badge</span>
              </div>
              <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                3. UID Roster Match
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Your registered Free Fire numeric UID and in-game name must strictly correspond to the character inside the custom room. Any unregistered guest or account swap will result in disqualification.
              </p>
              <div className="mt-auto pt-2 flex items-center gap-1.5 text-secondary font-label-sm text-label-sm uppercase font-semibold">
                <span className="material-symbols-outlined text-xs">verified</span> Anti-Impersonation Rule
              </div>
            </div>

            {/* Pillar 4 */}
            <div className="bg-surface-container p-4 rounded flex flex-col gap-2">
              <div className="w-10 h-10 rounded bg-error-container/40 flex items-center justify-center text-error">
                <span className="material-symbols-outlined text-2xl">security</span>
              </div>
              <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                4. Fair Play Protocol
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Third-party emulators, root injection mods, teaming in Solo modes, or macro scripts incur a permanent device blacklist and wallet forfeiture. Matches are live spectated by human arbiters.
              </p>
              <div className="mt-auto pt-2 flex items-center gap-1.5 text-error font-label-sm text-label-sm uppercase font-semibold">
                <span className="material-symbols-outlined text-xs">gavel</span> Zero-Tolerance Policy
              </div>
            </div>
          </div>

          {/* FAQ Accordion Matrix */}
          <div className="w-full bg-[#0b0e14] p-6 rounded flex flex-col gap-4">
            <span className="font-label-lg text-label-lg uppercase tracking-wider text-primary font-bold">
              Frequently Asked Questions
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1">
                <span className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                  When are kill bounties credited?
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  In Solo Mode, each confirmed kill credits ₹20 Coins directly into your IGNITE FF wallet within 10 minutes after screenshot telemetry review finishes.
                </p>
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                  What if a player does not show up?
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  The room starts promptly at the stated kickoff time. Unclaimed slots are opened to standby queue players. No refunds for late arrival once the lobby timer hits zero.
                </p>
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                  Can I participate from PC Emulator?
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  No. All matches hosted in this hub are mobile-only (Android/iOS). Emulator bypass attempts trigger automated lobby kick before landing.
                </p>
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                  How is the Squad ₹200 distributed?
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  The full ₹200 Coin winning prize is disbursed automatically to the squad leader's account, or split equally across 4 registered team members upon request in match settings.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Arbiter Hotline Strip */}
        <div className="w-full bg-surface-container p-4 rounded flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="material-symbols-outlined text-2xl text-[#00dbe9]">headset_mic</span>
            <div className="flex flex-col">
              <span className="font-label-md text-label-md text-on-surface uppercase font-bold">
                Need Arbiter Assistance?
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                Live discord match arbiters respond in &lt; 90 seconds for room discrepancies.
              </span>
            </div>
          </div>
          <button
            onClick={() => setCurrentTab('match-room')}
            className="px-4 py-2 rounded bg-surface-container-high text-on-surface hover:text-primary font-label-md text-label-md uppercase transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>Open Arbiter Ticket</span>
            <span className="material-symbols-outlined text-sm">open_in_new</span>
          </button>
        </div>
      </div>
    </div>
  );
};
