import { useMemo, useRef, useState } from "react";
import { useStore } from "../lib/store";
import type { FSNode } from "../lib/types";
import {
  childrenOf,
  findPath,
  isDescendant,
  pathOf,
  searchFS,
  statLine,
} from "../lib/fs";
import { Button, Dialog, Icon, IconButton, Sheet, useLongPress } from "./ui";
import { cn } from "../utils/cn";

type Mode =
  | null
  | "actions"
  | "rename"
  | "move"
  | "newFile"
  | "newFolder"
  | "delete";

export default function FilesView() {
  const { s, set, execute, openFile, showToast, perm } = useStore();
  const [mode, setMode] = useState<Mode>(null);
  const [target, setTarget] = useState<FSNode | null>(null);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);

  const cwdNode = useMemo(
    () => findPath(s.fs, s.cwd) ?? s.fs.nodes[s.fs.rootId],
    [s.fs, s.cwd],
  );
  const crumbs = s.cwd === "" ? [] : s.cwd.split("/");
  const items = useMemo(() => childrenOf(s.fs, cwdNode.id), [s.fs, cwdNode.id]);
  const hits = useMemo(
    () => (query.trim() ? searchFS(s.fs, query, 30) : []),
    [query, s.fs],
  );

  const rel = (n: FSNode) => pathOf(s.fs, n.id);
  const lpNode = useRef<FSNode | null>(null);
  const openActions = (n: FSNode) => {
    setTarget(n);
    setDraft(n.name);
    setMode("actions");
  };
  const lp = useLongPress(() => {
    const n = lpNode.current;
    if (n) openActions(n);
  }, 400);

  const open = (n: FSNode) => {
    if (n.type === "dir") set({ cwd: rel(n) });
    else {
      openFile(n.id);
      set({ view: "code" });
    }
  };

  const parentFolderId = target?.parentId ?? cwdNode.id;

  const doCreate = async (kind: "create_file" | "create_folder") => {
    const name = draft.trim();
    if (!name) return;
    const path = s.cwd ? `${s.cwd}/${name}` : name;
    const res = await execute({
      kind,
      label: kind === "create_file" ? "Create file" : "Create folder",
      path,
      content: "",
    });
    showToast(res.status === "done" ? `${name} created` : res.note);
    setDraft("");
    setMode(null);
  };

  const doRename = async () => {
    if (!target) return;
    const res = await execute({
      kind: "rename",
      label: "Rename",
      path: rel(target),
      to: draft.trim(),
    });
    showToast(res.status === "done" ? `Renamed to ${draft.trim()}` : res.note);
    setDraft("");
    setMode(null);
    setTarget(null);
  };

  const doDelete = async () => {
    if (!target) return;
    const res = await execute({
      kind: "delete",
      label: "Delete",
      path: rel(target),
    });
    showToast(res.status === "done" ? res.note : res.note);
    setMode(null);
    setTarget(null);
  };

  const folders = useMemo(() => {
    const out: FSNode[] = [s.fs.nodes[s.fs.rootId]];
    const walk = (id: string) => {
      childrenOf(s.fs, id).forEach((n) => {
        if (n.type === "dir") {
          out.push(n);
          walk(n.id);
        }
      });
    };
    walk(s.fs.rootId);
    return out.filter(
      (node) => !target || !isDescendant(s.fs, node.id, target.id),
    );
  }, [s.fs, target]);

  if (!perm("read"))
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
        <Icon name="lock" className="h-7 w-7 text-muted" />
        <h2 className="text-base">Read permission is off.</h2>
        <p className="max-w-[320px] text-xs leading-relaxed text-muted">
          Enable it to inspect the text files in this workspace.
        </p>
        <Button
          variant="secondary"
          onClick={() =>
            set((state) => ({
              permissions: { ...state.permissions, read: true },
            }))
          }
        >
          Enable read access
        </Button>
      </div>
    );

  return (
    <div className="mx-auto flex min-h-0 w-full max-w-[1000px] flex-1 flex-col sm:px-5 sm:pt-5">
      {/* path bar */}
      <div className="flex items-center gap-1 border-b border-line px-2 py-1.5">
        {searching ? (
          <>
            <IconButton
              name="chevronLeft"
              label="Back"
              onClick={() => {
                setSearching(false);
                setQuery("");
              }}
            />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search workspace"
              className="h-9 min-w-0 flex-1 rounded-xl border border-line bg-surface2 px-3 text-[14px] outline-none focus:border-accent"
            />
          </>
        ) : (
          <>
            <button
              onClick={() => setSearching(true)}
              aria-label="Search"
              className="tap grid h-9 w-9 place-items-center rounded-full text-muted active:bg-surface2"
            >
              <Icon name="search" className="h-[18px] w-[18px]" />
            </button>
            <div className="no-scrollbar flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto">
              <button
                onClick={() => set({ cwd: "" })}
                className="flex shrink-0 items-center gap-1.5 rounded-lg px-1.5 py-1 text-[13px] font-medium active:bg-surface2"
              >
                <Icon name="folderOpen" className="h-4 w-4 text-accent" />
                {s.fs.nodes[s.fs.rootId].name}
              </button>
              {crumbs.map((c, i) => (
                <button
                  key={`${c}-${i}`}
                  onClick={() => set({ cwd: crumbs.slice(0, i + 1).join("/") })}
                  className="flex shrink-0 items-center gap-0.5 rounded-lg px-1 py-1 text-[13px] text-muted active:bg-surface2"
                >
                  <Icon
                    name="chevronRight"
                    className="h-3.5 w-3.5 opacity-50"
                  />
                  <span className={i === crumbs.length - 1 ? "text-fg" : ""}>
                    {c}
                  </span>
                </button>
              ))}
            </div>
            <IconButton
              name="plus"
              label="New"
              onClick={() => {
                setDraft("");
                setMode("newFile");
              }}
              className="text-accent"
            />
          </>
        )}
      </div>

      {/* list */}
      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto pb-24">
        {searching ? (
          hits.length === 0 ? (
            <p className="px-4 py-6 text-[13.5px] text-muted">
              No matches{query ? ` for “${query}”` : ""}.
            </p>
          ) : (
            hits.map((h, i) => (
              <button
                key={`${h.path}-${h.line}-${i}`}
                onClick={() => {
                  const n = findPath(s.fs, h.path);
                  if (n) {
                    openFile(n.id);
                    set({ view: "code" });
                  }
                }}
                className="block w-full border-b border-line px-4 py-2.5 text-left active:bg-surface2"
              >
                <div className="truncate font-mono text-[12.5px]">{h.path}</div>
                {h.snippet ? (
                  <div className="mt-0.5 truncate font-mono text-[11.5px] text-muted">
                    {h.line}:{h.snippet}
                  </div>
                ) : null}
              </button>
            ))
          )
        ) : items.length === 0 ? (
          <div className="px-4 py-10 text-center">
            <Icon name="folder" className="mx-auto h-7 w-7 text-muted" />
            <p className="mt-2 text-[13.5px] text-muted">Empty folder</p>
          </div>
        ) : (
          items.map((n) => (
            <div key={n.id} className="border-b border-line/70">
              <div
                {...lp.handlers}
                onPointerDown={() => {
                  lpNode.current = n;
                  lp.handlers.onPointerDown();
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter") open(n);
                }}
                onClick={() => {
                  if (lp.fired) return;
                  open(n);
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setTarget(n);
                  setDraft(n.name);
                  setMode("actions");
                }}
                className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-surface2"
              >
                <span
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-lg",
                    n.type === "dir"
                      ? "bg-accentsoft text-accent"
                      : "bg-surface2 text-muted",
                  )}
                >
                  <Icon
                    name={n.type === "dir" ? "folder" : "file"}
                    className="h-[18px] w-[18px]"
                  />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14.5px]">{n.name}</span>
                  <span className="block truncate text-[11.5px] text-muted">
                    {statLine(s.fs, n.id)} ·{" "}
                    {new Date(n.updatedAt).toLocaleDateString([], {
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                </span>
                <button
                  aria-label={`Actions for ${n.name}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    setTarget(n);
                    setDraft(n.name);
                    setMode("actions");
                  }}
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-muted active:bg-surface3"
                >
                  <Icon name="dots" className="h-[18px] w-[18px]" />
                </button>
              </div>
            </div>
          ))
        )}
        {!searching ? (
          <p className="px-4 py-4 font-mono text-[11px] leading-relaxed text-muted">
            {s.workspacePath}/{s.cwd}
          </p>
        ) : null}
      </div>

      {/* new item fab-ish quick sheet */}
      <Sheet
        open={mode === "newFile" || mode === "newFolder"}
        onClose={() => setMode(null)}
        title="New"
        subtitle={`${s.workspacePath}/${s.cwd}`}
      >
        <div className="space-y-3 p-4">
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={mode === "newFolder" ? "components" : "Button.tsx"}
            className="h-11 w-full rounded-xl border border-line bg-surface2 px-3 font-mono text-[14px] outline-none focus:border-accent"
          />
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="secondary"
              icon="filePlus"
              onClick={() => doCreate("create_file")}
              disabled={!draft.trim() || !perm("create_file")}
            >
              File
            </Button>
            <Button
              variant="secondary"
              icon="folderPlus"
              onClick={() => doCreate("create_folder")}
              disabled={!draft.trim() || !perm("create_folder")}
            >
              Folder
            </Button>
          </div>
          {!perm("create_file") || !perm("create_folder") ? (
            <p className="text-[12px] text-warn">
              Creation is disabled in Agent permissions.
            </p>
          ) : null}
        </div>
      </Sheet>

      {/* actions */}
      <Sheet
        open={mode === "actions" && !!target}
        onClose={() => setMode(null)}
        title={target?.name}
        subtitle={`${statLine(s.fs, target?.id ?? "")} · ${rel(target ?? s.fs.nodes[s.fs.rootId])}`}
      >
        <div className="pb-2">
          {target?.type === "file" ? (
            <SheetRow
              icon="code"
              label="Open in editor"
              onClick={() => {
                openFile(target.id);
                set({ view: "code" });
                setMode(null);
              }}
            />
          ) : target ? (
            <SheetRow
              icon="folderOpen"
              label="Open folder"
              onClick={() => {
                open(target);
                setMode(null);
              }}
            />
          ) : null}
          <SheetRow
            icon="copy"
            label="Copy path"
            onClick={() => {
              if (navigator.clipboard)
                navigator.clipboard
                  .writeText(`${s.workspacePath}/${rel(target!)}`)
                  .then(() => showToast("Path copied"))
                  .catch(() => showToast("Clipboard unavailable"));
              else showToast("Clipboard unavailable");
              setMode(null);
            }}
          />
          <SheetRow
            icon="text"
            label="Rename"
            onClick={() => setMode("rename")}
          />
          <SheetRow
            icon="move"
            label="Move to…"
            onClick={() => setMode("move")}
          />
          <SheetRow
            icon="trash"
            label="Delete"
            danger
            onClick={() => setMode("delete")}
          />
        </div>
      </Sheet>

      {/* rename */}
      <Sheet
        open={mode === "rename"}
        onClose={() => setMode(null)}
        title="Rename"
        footer={
          <Button
            block
            variant="primary"
            disabled={!draft.trim()}
            onClick={doRename}
          >
            Rename
          </Button>
        }
      >
        <div className="p-4">
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            className="h-11 w-full rounded-xl border border-line bg-surface2 px-3 font-mono text-[14px] outline-none focus:border-accent"
          />
          <p className="mt-2 text-[12px] text-muted">
            {rel(target ?? s.fs.nodes[s.fs.rootId])}
          </p>
        </div>
      </Sheet>

      {/* move */}
      <Sheet
        open={mode === "move"}
        onClose={() => setMode(null)}
        title="Move to folder"
        subtitle="Pick a destination"
      >
        <div className="pb-2">
          {folders.map((f) => (
            <button
              key={f.id}
              onClick={async () => {
                const res = await execute({
                  kind: "move",
                  label: "Move",
                  path: rel(target!),
                  to: rel(f),
                });
                showToast(res.status === "done" ? res.note : res.note);
                setMode(null);
              }}
              className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-surface2"
            >
              <Icon name="folder" className="h-[18px] w-[18px] text-accent" />
              <span className="min-w-0 flex-1 truncate font-mono text-[13px]">
                {rel(f) || "/"}
              </span>
              {parentFolderId === f.id ? (
                <Icon name="check" className="h-4 w-4 text-muted" />
              ) : null}
            </button>
          ))}
        </div>
      </Sheet>

      <Dialog
        open={mode === "delete"}
        title={`Delete ${target?.type === "dir" ? "folder" : "file"}?`}
        body={
          <>
            <span className="font-mono text-fg">
              {rel(target ?? s.fs.nodes[s.fs.rootId])}
            </span>
            {target?.type === "dir" ? " and everything inside it" : ""} will be
            removed from your storage.
          </>
        }
        confirmLabel="Delete"
        cancelLabel="Keep"
        danger
        icon="trash"
        onCancel={() => setMode(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}

function SheetRow({
  icon,
  label,
  onClick,
  danger,
}: {
  icon: string;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 px-4 py-3 text-left active:bg-surface2",
        danger && "text-danger",
      )}
    >
      <Icon name={icon} className="h-[18px] w-[18px]" />
      <span className="flex-1 text-[15px]">{label}</span>
    </button>
  );
}
