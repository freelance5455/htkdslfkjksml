import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  FileCode2,
  FileText,
  FileJson,
  FileType,
  Trash2,
  Copy,
  Pencil,
  Star,
  Search,
  Plus,
  FolderPlus,
} from "lucide-react";
import type { StudioApi, StudioFile } from "@/hooks/useStudio";
import { LANG_LABEL, type LangId } from "@/lib/language";
import { cn } from "@/lib/utils";

interface Props {
  studio: StudioApi;
  onOpenFiles: () => void;
  onNewProject: () => void;
}

function iconFor(lang: LangId) {
  switch (lang) {
    case "html":
    case "xml":
      return FileCode2;
    case "json":
      return FileJson;
    case "css":
      return FileType;
    default:
      return FileText;
  }
}

function formatSize(content: string) {
  const bytes = new Blob([content]).size;
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} KB`;
}

export function FilesView({ studio, onOpenFiles, onNewProject }: Props) {
  const { files, activeFileId, setActiveFile, deleteFile, duplicateFile, renameFile, setMainFile, createFile } = studio;
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"name" | "type" | "date">("name");
  const [newName, setNewName] = useState("");
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const list = files.filter((f) =>
      f.name.toLowerCase().includes(query.toLowerCase())
    );
    return [...list].sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "type") return a.language.localeCompare(b.language);
      return b.updatedAt - a.updatedAt;
    });
  }, [files, query, sort]);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    await createFile(newName.trim());
    setNewName("");
  };

  const startRename = (f: StudioFile) => {
    setRenamingId(f.id);
    setRenameValue(f.name);
  };

  const commitRename = async () => {
    if (renamingId) await renameFile(renamingId, renameValue);
    setRenamingId(null);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto bg-slate-100 p-4 dark:bg-slate-950">
      <div className="mb-4 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="بحث عن ملف..."
            className="ps-9"
          />
        </div>
        <Button onClick={onNewProject} variant="outline" className="gap-1">
          <FolderPlus className="h-4 w-4" />
          <span className="hidden sm:inline">مشروع</span>
        </Button>
      </div>

      <div className="mb-4 flex gap-2">
        {(["name", "type", "date"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setSort(s)}
            className={cn(
              "rounded-full px-3 py-1 text-xs font-medium transition-colors",
              sort === s
                ? "bg-sky-600 text-white"
                : "bg-white text-slate-600 hover:bg-slate-200 dark:bg-slate-900 dark:text-slate-300"
            )}
          >
            {s === "name" ? "الاسم" : s === "type" ? "النوع" : "التاريخ"}
          </button>
        ))}
      </div>

      <Card className="mb-4 border-sky-200 bg-sky-50 dark:border-sky-900 dark:bg-sky-950/40">
        <CardContent className="flex items-center gap-2 p-3">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="اسم ملف جديد (مثال: app.js)"
            className="flex-1 bg-white dark:bg-slate-900"
          />
          <Button onClick={handleCreate} className="gap-1 bg-sky-600 hover:bg-sky-700">
            <Plus className="h-4 w-4" />
            إنشاء
          </Button>
        </CardContent>
      </Card>

      {filtered.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
          <div className="rounded-2xl bg-slate-200 p-5 dark:bg-slate-800">
            <FileText className="h-8 w-8 text-slate-500" />
          </div>
          <p className="text-sm text-muted-foreground">لا توجد ملفات مطابقة</p>
          <Button onClick={onOpenFiles} variant="outline">
            إنشاء ملف
          </Button>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((f) => {
            const Icon = iconFor(f.language as LangId);
            const active = f.id === activeFileId;
            return (
              <Card
                key={f.id}
                className={cn(
                  "border-slate-200 transition-shadow hover:shadow-md dark:border-slate-800",
                  active && "ring-2 ring-sky-500"
                )}
              >
                <CardContent className="flex items-center gap-3 p-3">
                  <div
                    className={cn(
                      "rounded-lg p-2",
                      active
                        ? "bg-sky-600 text-white"
                        : "bg-slate-100 text-sky-600 dark:bg-slate-800 dark:text-sky-400"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                  </div>

                  <div className="min-w-0 flex-1">
                    {renamingId === f.id ? (
                      <Input
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onBlur={commitRename}
                        onKeyDown={(e) => e.key === "Enter" && commitRename()}
                        autoFocus
                        className="h-8"
                      />
                    ) : (
                      <>
                        <div className="flex items-center gap-1.5">
                          <span className="truncate text-sm font-semibold">{f.name}</span>
                          {f.isMain && (
                            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                          )}
                          {f.dirty && (
                            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                          )}
                        </div>
                        <p className="text-[11px] text-muted-foreground">
                          {LANG_LABEL[f.language as LangId]} · {formatSize(f.content)} ·{" "}
                          {new Date(f.updatedAt).toLocaleDateString("ar")}
                        </p>
                      </>
                    )}
                  </div>

                  <div className="flex shrink-0 items-center gap-0.5">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setActiveFile(f.id);
                        onOpenFiles();
                      }}
                      className="h-8 px-2 text-xs"
                    >
                      فتح
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setMainFile(f.id)}
                      className="h-8 w-8 p-0"
                      title="تعيين كملف رئيسي"
                    >
                      <Star className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => startRename(f)}
                      className="h-8 w-8 p-0"
                      title="إعادة تسمية"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => duplicateFile(f.id)}
                      className="h-8 w-8 p-0"
                      title="نسخ"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setConfirmId(f.id)}
                      className="h-8 w-8 p-0 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950"
                      title="حذف"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {confirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <Card className="w-full max-w-sm">
            <CardContent className="p-5">
              <h3 className="mb-2 text-lg font-bold">تأكيد الحذف</h3>
              <p className="mb-4 text-sm text-muted-foreground">
                هل أنت متأكد من حذف هذا الملف؟ لا يمكن التراجع عن هذه العملية.
              </p>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setConfirmId(null)}>
                  إلغاء
                </Button>
                <Button
                  onClick={async () => {
                    await deleteFile(confirmId);
                    setConfirmId(null);
                  }}
                  className="bg-rose-600 hover:bg-rose-700"
                >
                  حذف
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}