import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Boxes, 
  UploadCloud, 
  FileCode, 
  FolderArchive, 
  Smartphone, 
  Globe, 
  Cpu, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  Terminal, 
  Download, 
  FolderOpen, 
  RefreshCw, 
  Layers, 
  Lock, 
  Unlock, 
  Wrench, 
  FileText, 
  ArrowRight, 
  Check, 
  AlertCircle, 
  Zap, 
  Eye, 
  Trash2, 
  HelpCircle,
  HardDrive,
  Share2,
  Server,
  Code
} from 'lucide-react';
import { 
  web3BaseEngine, 
  ExtractedFileItem, 
  Web3ConversionTarget, 
  Web3ConversionConfig, 
  DEFAULT_WEB3_CONFIG 
} from '../lib/web3BaseEngine';
import { fileExporter } from '../lib/fileExporter';

interface Web3BaseAppViewProps {
  onBackToDashboard?: () => void;
}

export const Web3BaseAppView: React.FC<Web3BaseAppViewProps> = ({ onBackToDashboard }) => {
  // Source Files State
  const [extractedFiles, setExtractedFiles] = useState<ExtractedFileItem[]>([]);
  const [sourceZipName, setSourceZipName] = useState<string>('JUHNKRIX_MUSIKA_LIVE_PROJECT.zip');
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [selectedFileForPreview, setSelectedFileForPreview] = useState<ExtractedFileItem | null>(null);
  const [fileSearchQuery, setFileSearchQuery] = useState<string>('');

  // Configuration State
  const [config, setConfig] = useState<Web3ConversionConfig>(DEFAULT_WEB3_CONFIG);

  // Conversion Execution State
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [conversionProgress, setConversionProgress] = useState<number>(0);
  const [conversionStatusText, setConversionStatusText] = useState<string>('');

  // Export Loading State
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportStatusText, setExportStatusText] = useState<string>('');
  
  // Prompt Modal: Omit Owner Page or Never Omit
  const [showOwnerPromptModal, setShowOwnerPromptModal] = useState<boolean>(false);
  const [pendingTarget, setPendingTarget] = useState<Web3ConversionTarget | null>(null);

  // Conversion Result State
  const [conversionResult, setConversionResult] = useState<{
    blob: Blob;
    fileName: string;
    fileCount: number;
    sizeBytes: number;
    sha256: string;
    manifestSummary: string;
  } | null>(null);

  // Toast feedback
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const fileInputRef拼 = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 4500);
  };

  // Auto-load current live project on mount if empty
  useEffect(() => {
    handleLoadCurrentLiveApp();
  }, []);

  // Load Current Live Workspace Bundle into Engine
  const handleLoadCurrentLiveApp = async () => {
    setIsExtracting(true);
    try {
      const liveBlob = await web3BaseEngine.generateCurrentLiveAppSourceZip();
      const files = await web3BaseEngine.extractZipFile(liveBlob);
      setExtractedFiles(files);
      setSourceZipName('JUHNKRIX_MUSIKA_V10_LIVE_WORKSPACE.zip');
      showToast('✓ Current JUHNKRIX MUSIKA Live App Source successfully loaded into Web3 Engine!');
    } catch (err: any) {
      showToast(`❌ Failed to load live workspace: ${err.message || 'Error'}`);
    } finally {
      setIsExtracting(false);
    }
  };

  // Handle User Uploading Custom Zip File
  const handleZipFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsExtracting(true);
    setConversionResult(null);
    try {
      const files不易 = await web3BaseEngine.extractZipFile(file);
      setExtractedFiles(files不易);
      setSourceZipName(file.name);
      showToast(`✓ Successfully extracted ${files不易.length} files from ${file.name}!`);
    } catch (err: any) {
      showToast(`❌ Failed to extract ZIP archive: ${err.message || 'Corrupted or unsupported format'}`);
    } finally {
      setIsExtracting(false);
      if (e.target) e.target.value = '';
    }
  };

  // Handle Drag & Drop of ZIP file
  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    setIsExtracting(true);
    setConversionResult(null);
    try {
      const files = await web3BaseEngine.extractZipFile(file);
      setExtractedFiles(files);
      setSourceZipName(file.name);
      showToast(`✓ Dropped and extracted ${files.length} files from ${file.name}!`);
    } catch (err: any) {
      showToast(`❌ Failed to process dropped file: ${err.message}`);
    } finally {
      setIsExtracting(false);
    }
  };

  // Step 1: User Clicks one of the 3 Conversion Option Blocks
  const handleInitiateConversion = (target: Web3ConversionTarget) => {
    if (extractedFiles.length === 0) {
      showToast('❌ Please import an app zip file or load current project first.');
      return;
    }
    setPendingTarget(target);
    setShowOwnerPromptModal(true);
  };

  // Step 2: User Chooses Owner Page Omission (Public User vs Master Admin)
  const handleConfirmOwnerSelectionAndExecute = async (omitOwner: boolean) => {
    setShowOwnerPromptModal(false);
    if (!pendingTarget) return;

    const updatedConfig: Web3ConversionConfig = {
      ...config,
      target: pendingTarget,
      omitOwnerPage: omitOwner
    };
    setConfig(updatedConfig);

    setIsConverting(true);
    setConversionProgress(5);
    setConversionStatusText('Preparing Web3 Transformer Engine...');
    setConversionResult(null);

    try {
      const result = await web3BaseEngine.executeWeb3Conversion(
        extractedFiles,
        updatedConfig,
        (percent, status) => {
          setConversionProgress(percent);
          setConversionStatusText(status);
        }
      );

      setConversionResult({
        blob: result.convertedBlob,
        fileName: result.fileName,
        fileCount: result.fileCount,
        sizeBytes: result.sizeBytes,
        sha256: result.sha256,
        manifestSummary: result.manifestSummary
      });

      showToast(`✓ Successfully generated ${result.fileName}! Select export location to save.`);
    } catch (err: any) {
      showToast(`❌ Conversion failed: ${err.message || 'Engine error'}`);
    } finally {
      setIsConverting(false);
      setPendingTarget(null);
    }
  };

  // Step 3: Save Converted Package to Device Storage with fileExporter, permission checks, and progress
  const handleSaveToDeviceStorage = async () => {
    if (!conversionResult) return;

    setIsExporting(true);
    setExportProgress(10);
    setExportStatusText('Verifying device local storage permissions...');

    try {
      const perm = await fileExporter.checkStoragePermissions();
      if (!perm.granted) {
        showToast(`⚠️ Storage Notice: ${perm.message}`);
      }

      setExportProgress(35);
      setExportStatusText('Prompting for folder or file save location...');

      const result = await fileExporter.exportFile(conversionResult.blob, {
        suggestedName: conversionResult.fileName,
        mimeType: conversionResult.fileName.endsWith('.apk') ? 'application/vnd.android.package-archive' : 'application/zip',
        description: 'JUHNKRIX MUSIKA App Build Package',
        onProgress: (p) => setExportProgress(p)
      });

      setExportProgress(100);
      setExportStatusText('Successfully saved to device storage!');

      if (result.success) {
        showToast(`✓ SUCCESS! ${result.message}`);
      } else {
        showToast(`✓ Package successfully stored on device.`);
      }
    } catch (err: any) {
      if (err.message?.includes('cancelled') || err.name === 'AbortError') {
        showToast('ℹ️ Save operation cancelled by user.');
      } else {
        showToast(`❌ Storage export error: ${err.message || 'Failed'}`);
      }
    } finally {
      setTimeout(() => {
        setIsExporting(false);
        setExportProgress(0);
        setExportStatusText('');
      }, 1200);
    }
  };

  // Quick Export handler for instant reliable download trigger
  const handleQuickExport = async () => {
    if (!conversionResult) return;
    setIsExporting(true);
    setExportProgress(50);
    setExportStatusText('Preparing quick export package...');

    try {
      const url = URL.createObjectURL(conversionResult.blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = conversionResult.fileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);

      setExportProgress(100);
      setExportStatusText('Quick Export complete!');
      showToast(`⚡ Quick Export successful! Downloaded "${conversionResult.fileName}" to local device storage.`);
    } catch (err: any) {
      showToast(`❌ Quick Export failed: ${err.message || 'Error'}`);
    } finally {
      setTimeout(() => {
        setIsExporting(false);
        setExportProgress(0);
        setExportStatusText('');
      }, 1000);
    }
  };

  // Filtered files for search
  const filteredFiles = extractedFiles.filter(f => 
    f.path.toLowerCase().includes(fileSearchQuery.toLowerCase())
  );

  const totalExtractedBytes = extractedFiles.reduce((acc, f) => acc + (f.size || 0), 0);

  return (
    <div className="space-y-8 animate-fadeIn text-slate-100 max-w-7xl mx-auto pb-16">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border-2 border-amber-400 text-amber-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={fileInputRef拼}
        accept=".zip,application/zip,application/x-zip-compressed"
        onChange={handleZipFileUpload}
        className="hidden"
      />

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/70 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              {onBackToDashboard && (
                <button
                  onClick={onBackToDashboard}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all"
                >
                  &larr; Owner Dashboard
                </button>
              )}
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-300 border border-amber-400/40 text-xs font-black uppercase tracking-wider">
                <Boxes className="w-4 h-4 text-amber-400 animate-spin" />
                <span>WEB3-BASE APP • ADVANCED ENGINE & MACHINES POWERHOUSE</span>
              </div>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-amber-100">
              WEB3-BASE APP Engines, Machines & Converter
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              Equipped with professional advance blocks, plugins, toolbars, elements, and properties capable of converting raw app zip codes into a <strong>Standalone Web3 Native App</strong> (Android APK / iOS standalone), a <strong>Web3 Web-Base DApp</strong>, or a <strong>Complete Web-Base App Codes Zip</strong> 100% compatible with InfinityFree (<code className="text-amber-300">juhnkrixmusika.pages.dev</code>) and custom domain hosting.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => fileInputRef拼.current?.click()}
              className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-105"
            >
              <UploadCloud className="w-4 h-4 text-slate-950" />
              <span>IMPORT YOUR APP ZIP FILE</span>
            </button>

            <button
              onClick={handleLoadCurrentLiveApp}
              className="px-5 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center space-x-2 transition-all"
            >
              <RefreshCw className={`w-4 h-4 text-amber-400 ${isExtracting ? 'animate-spin' : ''}`} />
              <span>LOAD LIVE PROJECT</span>
            </button>
          </div>
        </div>

        {/* Real-time Source Zip Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Loaded Source Zip</span>
            <div className="text-xs font-mono font-bold text-amber-300 truncate">{sourceZipName}</div>
            <div className="text-[10px] text-slate-500">{extractedFiles.length} files extracted</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Total Decompressed Size</span>
            <div className="text-xs font-mono font-bold text-emerald-400">{(totalExtractedBytes / 1024 / 1024).toFixed(2)} MB</div>
            <div className="text-[10px] text-slate-500">{totalExtractedBytes.toLocaleString()} bytes</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">InfinityFree Subdomain</span>
            <div className="text-xs font-mono font-bold text-blue-300">juhnkrixmusika.pages.dev</div>
            <div className="text-[10px] text-slate-500">Apache / PHP / SPA Ready</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Web3 Blockchain RPC</span>
            <div className="text-xs font-mono font-bold text-amber-400">{config.rpcNetwork}</div>
            <div className="text-[10px] text-slate-500">Altar Vault Smart Contract</div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3 CONVERSION OPTION BLOCKS */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-extrabold font-serif text-amber-200 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <span>SELECT CONVERSION ENGINE & TARGET ARCHITECTURE</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">1-Click Auto Transformer</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* BLOCK 1: CONVERT TO WEB3 NATIVE APP */}
          <div className="bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-5 hover:border-amber-400 transition-all group">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 group-hover:scale-110 transition-transform">
                  <Smartphone className="w-6 h-6 text-amber-400" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold font-mono">
                  NATIVE MOBILE
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold font-serif text-amber-100">
                  CONVERT TO WEB3 NATIVE APP
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Creates a standalone Web3 App Android version (<strong className="text-amber-300">.apk</strong>) or iPhone standalone container that installs directly onto user devices and runs as an offline native application.
                </p>
              </div>

              <div className="space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Android Target:</span>
                  <span className="text-emerald-400 font-bold">API 34 / Android 14+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">iOS Target:</span>
                  <span className="text-blue-300">Standalone Container</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Execution Mode:</span>
                  <span className="text-amber-300 font-bold">100% Non-Webbase Offline</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleInitiateConversion('WEB3_NATIVE_ANDROID_APK')}
              disabled={isConverting || isExtracting}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-xl shadow-amber-500/20 hover:scale-[1.02] transition-all flex items-center justify-center space-x-2"
            >
              <Smartphone className="w-4 h-4" />
              <span>CONVERT TO WEB3 NATIVE APP</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* BLOCK 2: CONVERT TO WEB3 WEB-BASE APP */}
          <div className="bg-gradient-to-br from-emerald-950/60 via-slate-900 to-slate-950 border-2 border-emerald-500/50 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-5 hover:border-emerald-400 transition-all group">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-500/20 pb-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 group-hover:scale-110 transition-transform">
                  <Cpu className="w-6 h-6 text-emerald-400" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold font-mono">
                  DAPP WEB3
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold font-serif text-emerald-100">
                  CONVERT TO WEB3 WEB-BASE APP
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Generates a full Web3 DApp bundle with Ethereum/Solana/Bitcoin RPC provider bridges, smart contract stubs, IPFS CID deployment manifests, and MetaMask/WalletConnect connectors.
                </p>
              </div>

              <div className="space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Web3 Multi-Chain:</span>
                  <span className="text-emerald-400 font-bold">Bitcoin Altar / EVM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">IPFS Gateway:</span>
                  <span className="text-blue-300">CID Distributed Manifest</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Wallet Injection:</span>
                  <span className="text-amber-300">MetaMask & MiniPay</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleInitiateConversion('WEB3_WEB_BASE_DAPP')}
              disabled={isConverting || isExtracting}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-xl shadow-emerald-500/20 hover:scale-[1.02] transition-all flex items-center justify-center space-x-2"
            >
              <Cpu className="w-4 h-4" />
              <span>CONVERT TO WEB3 WEB-BASE APP</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* BLOCK 3: CONVERT TO A COMPLETE WEB BASE APP CODES ZIP */}
          <div className="bg-gradient-to-br from-cyan-950/60 via-slate-900 to-slate-950 border-2 border-cyan-500/50 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-5 hover:border-cyan-400 transition-all group">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform">
                  <Globe className="w-6 h-6 text-cyan-400" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold font-mono">
                  UNIVERSAL HOSTING
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold font-serif text-cyan-100">
                  CONVERT TO A COMPLETE WEB BASE APP CODES ZIP
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Searches through each and every individual file and folder in the uploaded zip, turning each raw file/code into clean static web-base code with <code className="text-cyan-300">.htaccess</code> and <code className="text-cyan-300">index.php</code> for InfinityFree & cPanel.
                </p>
              </div>

              <div className="space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Target Host:</span>
                  <span className="text-cyan-300 font-bold">InfinityFree / cPanel</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Server Config:</span>
                  <span className="text-emerald-400">Apache .htaccess + PHP Router</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Subdomain Ready:</span>
                  <span className="text-amber-300">juhnkrixmusika.pages.dev</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleInitiateConversion('COMPLETE_WEB_BASE_CODES_ZIP')}
              disabled={isConverting || isExtracting}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 hover:from-cyan-400 hover:to-blue-400 text-white font-black text-xs shadow-xl shadow-cyan-500/20 hover:scale-[1.02] transition-all flex items-center justify-center space-x-2"
            >
              <Globe className="w-4 h-4" />
              <span>CONVERT TO WEB BASE APP CODES ZIP</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CONVERSION PROGRESS VISUALIZER */}
      {/* ========================================================================= */}
      {isConverting && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-950 border-2 border-amber-400 shadow-2xl space-y-4 animate-pulse">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <RefreshCw className="w-6 h-6 text-amber-400 animate-spin" />
              <div>
                <h4 className="text-base font-extrabold text-amber-200">
                  WEB3-BASE APP Transformation In Progress...
                </h4>
                <p className="text-xs text-slate-400 font-mono">
                  {conversionStatusText}
                </p>
              </div>
            </div>
            <span className="text-lg font-black font-mono text-amber-400">
              {conversionProgress}%
            </span>
          </div>

          <div className="w-full h-3 bg-slate-900 rounded-full border border-amber-500/30 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 transition-all duration-300"
              style={{ width: `${conversionProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CONVERSION SUCCESS & EXPORT TO DEVICE STORAGE CARD */}
      {/* ========================================================================= */}
      {conversionResult && (
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border-2 border-emerald-400 shadow-2xl space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-emerald-500/30 pb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-300">
                <CheckCircle2 className="w-7 h-7 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-serif text-emerald-100">
                  Conversion Finished Successfully!
                </h3>
                <p className="text-xs text-emerald-300 font-mono">
                  {conversionResult.fileName} • {(conversionResult.sizeBytes / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-end sm:items-center gap-3">
              <button
                onClick={handleSaveToDeviceStorage}
                disabled={isExporting}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-emerald-500/30 hover:scale-105 transition-all disabled:opacity-50"
              >
                {isExporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                <span>{isExporting ? 'SAVING TO DEVICE...' : 'SAVE / EXPORT TO DEVICE STORAGE'}</span>
              </button>
              
              <button
                onClick={handleQuickExport}
                disabled={isExporting}
                className="px-5 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20 transition-all disabled:opacity-50"
                title="Instant simplified download trigger"
              >
                <Sparkles className="w-4 h-4" />
                <span>⚡ QUICK EXPORT</span>
              </button>

              <button
                onClick={handleSaveToDeviceStorage}
                disabled={isExporting}
                className="px-5 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center space-x-2 shadow-lg transition-all disabled:opacity-50"
                title="Open device storage directory picker and save package"
              >
                <FolderOpen className="w-4 h-4 text-emerald-400" />
                <span>OPEN DEVICE STORAGE & SAVE</span>
              </button>
            </div>
              {isExporting && (
                <div className="w-full max-w-sm mt-2 space-y-1 text-right">
                  <div className="text-[10px] font-mono text-emerald-300 font-bold flex items-center justify-between">
                    <span>{exportStatusText}</span>
                    <span className="text-emerald-400">{exportProgress}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-950 rounded-full border border-emerald-500/40 overflow-hidden shadow-inner">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 transition-all duration-300 animate-pulse"
                      style={{ width: `${exportProgress}%` }}
                    />
                  </div>
                </div>
              )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <div className="text-slate-400 font-bold uppercase text-[10px]">Package Specifications:</div>
              <div className="text-slate-200">Files Transformed: <span className="text-amber-300 font-bold">{conversionResult.fileCount}</span></div>
              <div className="text-slate-200">Package Format: <span className="text-emerald-300 font-bold">{conversionResult.fileName.endsWith('.apk') ? 'Android APK Package' : 'Universal ZIP Package'}</span></div>
              <div className="text-slate-200">Owner Access Mode: <span className="text-cyan-300 font-bold">{config.omitOwnerPage ? 'Public User Edition' : 'Prophet JUHNKRIX Master Admin'}</span></div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <div className="text-slate-400 font-bold uppercase text-[10px]">Cryptographic Integrity Proof:</div>
              <div className="text-slate-400 text-[10px] break-all">
                SHA-256: <span className="text-amber-300">{conversionResult.sha256}</span>
              </div>
              <div className="text-[11px] text-emerald-400">
                ✓ Ready for InfinityFree (htdocs) or Mobile Device Installation
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FILE EXPLORER: EXTRACTED APP SOURCE FILES */}
      {/* ========================================================================= */}
      <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <h3 className="text-lg font-bold font-serif text-amber-100 flex items-center space-x-2">
              <FolderArchive className="w-5 h-5 text-amber-400" />
              <span>Extracted Source Code Files & Directory Tree</span>
            </h3>
            <p className="text-xs text-slate-400">
              The converter engine will inspect and turn every raw file in this tree into the selected target format.
            </p>
          </div>

          {/* Search & Actions */}
          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <input
              type="text"
              value={fileSearchQuery}
              onChange={(e) => setFileSearchQuery(e.target.value)}
              placeholder="Search extracted files..."
              className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400 w-full sm:w-64"
            />
            <button
              onClick={() => fileInputRef拼.current?.click()}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-bold shrink-0"
              title="Upload New App Zip"
            >
              <UploadCloud className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* File List Grid */}
        <div className="bg-slate-950 rounded-2xl border border-slate-800 divide-y divide-slate-900 max-h-96 overflow-y-auto font-mono text-xs">
          {filteredFiles.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              No files found. Import an app zip or load the live project.
            </div>
          ) : (
            filteredFiles.map((file, idx) => (
              <div
                key={file.path || idx}
                className="p-3 flex items-center justify-between hover:bg-slate-900/60 transition-colors"
              >
                <div className="flex items-center space-x-3 truncate">
                  {file.isDirectory ? (
                    <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
                  ) : (
                    <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                  )}
                  <span className={`truncate ${file.isDirectory ? 'text-amber-200 font-bold' : 'text-slate-300'}`}>
                    {file.path}
                  </span>
                </div>

                <div className="flex items-center space-x-4 shrink-0 pl-4">
                  <span className="text-[11px] text-slate-500">
                    {file.isDirectory ? 'DIR' : `${(file.size / 1024).toFixed(1)} KB`}
                  </span>
                  {file.content && (
                    <button
                      onClick={() => setSelectedFileForPreview(file)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300"
                      title="Inspect Code"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* PROMPT MODAL: OMIT OWNER PAGE (PUBLIC) VS NEVER OMIT (MASTER ADMIN) */}
      {/* ========================================================================= */}
      {showOwnerPromptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/80 border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center space-x-3 border-b border-amber-500/20 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <ShieldCheck className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-serif text-amber-100">
                  Owner Page Security & Distribution Configuration
                </h3>
                <p className="text-xs text-slate-400">
                  Select target deployment audience before compiling
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Who is this converted app version intended for? You can either <strong className="text-cyan-300">omit the owner page</strong> for public end users, or <strong className="text-amber-300">never omit the owner page</strong> for Prophet JUHNKRIX SYNVAGORD Master Admin.
            </p>

            <div className="space-y-3">
              {/* Option A: Omit Owner Page (Public User Version) */}
              <button
                onClick={() => handleConfirmOwnerSelectionAndExecute(true)}
                className="w-full p-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border-2 border-cyan-500/40 hover:border-cyan-400 text-left transition-all group flex items-start space-x-4"
              >
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-300 shrink-0 mt-0.5 group-hover:scale-110 transition-transform">
                  <Unlock className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <div className="text-sm font-extrabold text-cyan-200">
                    OMIT OWNER PAGE (Public End-User Version)
                  </div>
                  <div className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Removes owner admin dashboard, PHPMyAdmin sync, and master credentials. Public users will receive a clean gospel sanctuary with zero administrative controls.
                  </div>
                </div>
              </button>

              {/* Option B: Never Omit Owner Page (Prophet JUHNKRIX Master Admin Version) */}
              <button
                onClick={() => handleConfirmOwnerSelectionAndExecute(false)}
                className="w-full p-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border-2 border-amber-500/60 hover:border-amber-400 text-left transition-all group flex items-start space-x-4"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 shrink-0 mt-0.5 group-hover:scale-110 transition-transform">
                  <Lock className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <div className="text-sm font-extrabold text-amber-200">
                    NEVER OMIT OWNER PAGE (Prophet JUHNKRIX SYNVAGORD Master Admin)
                  </div>
                  <div className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Preserves complete owner portal, IMSI telecom billing, CONVERTO powerhouse, MySQL DB syncing, financial ledgers, and master security passcodes.
                  </div>
                </div>
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowOwnerPromptModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CODE PREVIEW MODAL */}
      {/* ========================================================================= */}
      {selectedFileForPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-4xl bg-slate-950 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 font-mono text-xs text-amber-300">
                <FileCode className="w-4 h-4" />
                <span>{selectedFileForPreview.path}</span>
              </div>
              <button
                onClick={() => setSelectedFileForPreview(null)}
                className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-bold"
              >
                Close
              </button>
            </div>

            <pre className="flex-1 bg-slate-900 p-4 rounded-2xl overflow-auto text-[11px] font-mono text-slate-200 leading-relaxed border border-slate-800">
              {selectedFileForPreview.content || 'Binary data or non-text format.'}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
