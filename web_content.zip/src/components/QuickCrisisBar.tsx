import React from 'react';
import {
  AlertCircle,
  Zap,
  ShieldAlert,
  Flame,
  LifeBuoy,
  HeartPulse,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface QuickCrisisBarProps {
  onTriggerAction: (toolId: string, initialVersion?: 'short' | 'full') => void;
}

export const QuickCrisisBar: React.FC<QuickCrisisBarProps> = ({
  onTriggerAction,
}) => {
  const { t } = useTranslation();

  const crisisButtons = [
    {
      id: 'grounding_54321',
      label: t('quickCrisis.feelBad'),
      subtitle: 'Ancrage sensoriel immédiat',
      icon: LifeBuoy,
      gradient: 'from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700',
      badge: 'SOS Immédiat',
    },
    {
      id: 'panic_protocol',
      label: t('quickCrisis.panicAttack'),
      subtitle: 'Reset souffle 60 secondes',
      icon: Zap,
      gradient: 'from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700',
      badge: 'Ultra-rapide',
    },
    {
      id: 'phobia_protocol',
      label: t('quickCrisis.phobia'),
      subtitle: 'Découplage de la peur',
      icon: ShieldAlert,
      gradient: 'from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700',
      badge: 'Découplage',
    },
    {
      id: 'dissociation_exit',
      label: t('quickCrisis.flashback'),
      subtitle: 'Retour au corps & présent',
      icon: HeartPulse,
      gradient: 'from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700',
      badge: 'Proprioception',
    },
    {
      id: 'parent_child_crisis',
      label: t('quickCrisis.childCrisis'),
      subtitle: 'Co-régulation d’urgence',
      icon: Flame,
      gradient: 'from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700',
      badge: 'Espace Parents',
    },
    {
      id: 'parental_stress_reset',
      label: t('quickCrisis.parentHelp'),
      subtitle: 'Désamorcer avant d’exploser',
      icon: AlertCircle,
      gradient: 'from-cyan-600 to-blue-700 hover:from-cyan-700 hover:to-blue-800',
      badge: 'Reset 90s',
    },
  ];

  return (
    <section className="my-6">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wide">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            {t('quickCrisis.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t('quickCrisis.subtitle')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {crisisButtons.map((btn) => {
          const Icon = btn.icon;
          return (
            <button
              key={btn.id}
              onClick={() => onTriggerAction(btn.id, 'short')}
              className={`relative group flex flex-col justify-between p-3.5 sm:p-4 rounded-2xl bg-gradient-to-br ${btn.gradient} text-white shadow-md hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all text-left overflow-hidden min-h-[105px]`}
            >
              {/* Subtle background glow circle */}
              <div className="absolute -right-4 -bottom-4 w-16 h-16 rounded-full bg-white/10 blur-sm pointer-events-none group-hover:scale-150 transition-transform" />

              <div className="flex items-center justify-between w-full mb-1">
                <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
                  <Icon className="w-4 h-4 stroke-[2.5]" />
                </div>
                <span className="text-[9px] uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded-md bg-black/20 text-white/90">
                  {btn.badge}
                </span>
              </div>

              <div>
                <span className="block font-extrabold text-xs sm:text-sm leading-tight text-white drop-shadow-xs">
                  {btn.label}
                </span>
                <span className="text-[10px] text-white/80 line-clamp-1 mt-0.5 font-medium">
                  {btn.subtitle}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
