import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  RefreshCw,
  Video,
  VideoOff,
  Volume2,
} from 'lucide-react';

export interface ActiveCallSession {
  callId: string;
  peerUid: string;
  peerName: string;
  callType: 'voice' | 'video';
  direction: 'outgoing' | 'incoming';
  status: 'ringing' | 'connecting' | 'connected' | 'ended';
  offerSdp?: RTCSessionDescriptionInit;
}

interface CallOverlayProps {
  session: ActiveCallSession | null;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  onAccept: () => void;
  onReject: () => void;
  onHangup: () => void;
  onSwitchCamera: () => void;
}

export const CallOverlay: React.FC<CallOverlayProps> = ({
  session,
  localStream,
  remoteStream,
  onAccept,
  onReject,
  onHangup,
  onSwitchCamera,
}) => {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [speaker, setSpeaker] = useState(true);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
    if (remoteAudioRef.current && remoteStream) {
      remoteAudioRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  useEffect(() => {
    if (!session || session.status !== 'connected') {
      setSeconds(0);
      return;
    }
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [session]);

  if (!session) return null;

  const toggleMute = () => {
    if (!localStream) return;
    localStream.getAudioTracks().forEach((tr) => {
      tr.enabled = muted;
    });
    setMuted(!muted);
  };

  const toggleVideo = () => {
    if (!localStream) return;
    localStream.getVideoTracks().forEach((tr) => {
      tr.enabled = videoOff;
    });
    setVideoOff(!videoOff);
  };

  const formatTimer = (total: number) => {
    const mins = Math.floor(total / 60).toString().padStart(2, '0');
    const secs = (total % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between p-6">
      <audio ref={remoteAudioRef} autoPlay muted={!speaker} />

      <div className="text-center space-y-1 pt-4">
        <p className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">
          {session.callType === 'video' ? 'WebRTC Video Call' : 'WebRTC Voice Call'}
        </p>
        <h2 className="font-display text-2xl font-bold">{session.peerName}</h2>
        <p className="text-sm text-slate-400 tabular-nums">
          {session.status === 'ringing'
            ? session.direction === 'incoming'
              ? 'Incoming call...'
              : 'Ringing...'
            : session.status === 'connecting'
            ? 'Connecting...'
            : formatTimer(seconds)}
        </p>
      </div>

      {/* Video Stage */}
      <div className="relative flex-1 my-6 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center max-w-3xl w-full mx-auto">
        {session.callType === 'video' && remoteStream ? (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-28 h-28 rounded-full bg-blue-700/30 border-2 border-blue-500 flex items-center justify-center font-display text-3xl font-bold">
            {session.peerName.slice(0, 2).toUpperCase()}
          </div>
        )}

        {session.callType === 'video' && localStream && !videoOff && (
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className="absolute bottom-4 right-4 w-28 sm:w-36 aspect-video rounded-xl object-cover border border-white/30 bg-black"
          />
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4 pb-4">
        {session.direction === 'incoming' && session.status === 'ringing' ? (
          <>
            <button
              type="button"
              onClick={onReject}
              className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-700 flex items-center justify-center cursor-pointer"
              title="Reject call"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
            <button
              type="button"
              onClick={onAccept}
              className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center cursor-pointer"
              title="Accept call"
            >
              <Phone className="w-6 h-6" />
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={toggleMute}
              title="Mute mic"
              className={`w-12 h-12 rounded-full flex items-center justify-center cursor-pointer ${
                muted ? 'bg-red-600' : 'bg-slate-800 hover:bg-slate-700'
              }`}
            >
              {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {session.callType === 'video' && (
              <>
                <button
                  type="button"
                  onClick={toggleVideo}
                  title="Toggle camera"
                  className={`w-12 h-12 rounded-full flex items-center justify-center cursor-pointer ${
                    videoOff ? 'bg-red-600' : 'bg-slate-800 hover:bg-slate-700'
                  }`}
                >
                  {videoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                </button>
                <button
                  type="button"
                  onClick={onSwitchCamera}
                  title="Switch camera"
                  className="w-12 h-12 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center cursor-pointer"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              </>
            )}

            <button
              type="button"
              onClick={() => setSpeaker(!speaker)}
              title="Speaker mode"
              className={`w-12 h-12 rounded-full flex items-center justify-center cursor-pointer ${
                speaker ? 'bg-blue-700' : 'bg-slate-800 hover:bg-slate-700'
              }`}
            >
              <Volume2 className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={onHangup}
              title="End call"
              className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-700 flex items-center justify-center cursor-pointer"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
