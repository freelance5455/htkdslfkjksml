import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Upload,
  Smartphone,
  Users,
  User,
  Plus,
  Trash2,
  Calendar,
  Clock,
  MapPin,
  Sparkles,
  CheckCircle2,
  Image as ImageIcon,
  ArrowRight,
  TrendingUp,
  Ticket,
  Mail,
  ChevronLeft,
} from 'lucide-react';
import { EventCategory, CustomGroupTier, EventTicketTier } from '../types';
import { triggerHaptic } from '../utils/haptics';

export const CreatePage: React.FC = () => {
  const {
    user,
    addEvent,
    showToast,
    setCurrentPage,
  } = useApp();

  // Core Event creation state
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState<EventCategory>('concerts');
  const [city, setCity] = useState('Nairobi');
  const [venue, setVenue] = useState('');
  const [address, setAddress] = useState('');
  const [date, setDate] = useState('Saturday, Dec 12, 2026');
  const [time, setTime] = useState('6:00 PM');
  const [doorTime, setDoorTime] = useState('5:00 PM (1 hr prior)');
  const [personalPrice, setPersonalPrice] = useState('3000');
  const [capacity, setCapacity] = useState('1200');

  // Admission Ticket Tiers with Customizable Passes to Sell to Any Amount
  const [admissionTiers, setAdmissionTiers] = useState<EventTicketTier[]>([
    {
      id: 'tier_early',
      name: 'Early Bird Pass',
      price: 2000,
      capacity: 250, // Passes to sell customization to any amount
      description: 'Exclusive early admission discount with expedited entry',
      perks: 'Expedited turnstile pass',
    },
    {
      id: 'tier_regular',
      name: 'Regular Admission',
      price: 3000,
      capacity: 800, // Passes to sell customization to any amount
      description: 'Standard festival entry to all main grounds & stages',
      perks: 'General admission, all stages',
    },
    {
      id: 'tier_vip',
      name: 'VIP Raised Lounge',
      price: 6500,
      capacity: 150, // Passes to sell customization to any amount
      description: 'Elevated balcony deck, private bar, express turnstile',
      perks: 'VIP Lounge, private bar',
    },
    {
      id: 'tier_vvip',
      name: 'VVIP Diamond Access',
      price: 14000,
      capacity: 50, // Passes to sell customization to any amount
      description: 'Backstage pass, artist meet & greet, complimentary champagne',
      perks: 'All-inclusive backstage pass',
    },
  ]);

  const [customGroupTiers, setCustomGroupTiers] = useState<CustomGroupTier[]>([
    {
      id: 'tier_1',
      name: 'Squad Group Pass (4 Guests)',
      size: 4,
      price: 10500,
      perks: '4 wristbands, 15% group discount, priority turnstile lane',
    },
    {
      id: 'tier_2',
      name: 'VIP Table Experience (8 Guests)',
      size: 8,
      price: 26000,
      perks: '8 VIP passes, raised lounge seating, complimentary bottle service',
    },
  ]);
  const [hostMpesa, setHostMpesa] = useState(user?.mpesaNumber || user?.phone || '0712 345 678');
  const [hostName, setHostName] = useState(user?.name || 'Eventra Host');
  const [description, setDescription] = useState('');
  const [posterImage, setPosterImage] = useState('/src/assets/images/event_hero_festival_1793028386968.jpg');

  // Rich Event Options & Email Dispatch
  const [hostEmail, setHostEmail] = useState(user?.email || 'host@eventra.live');
  const [autoSendBuyerEmail, setAutoSendBuyerEmail] = useState(true);
  const [ageRestriction, setAgeRestriction] = useState('All Ages');
  const [dressCode, setDressCode] = useState('Smart Casual');
  const [parkingInfo, setParkingInfo] = useState('Designated secure venue parking & VIP drop-off');
  const [refundPolicy, setRefundPolicy] = useState('100% Automated Refund on Event Cancellation');

  // Social Links
  const [instagram, setInstagram] = useState('@eventra.live');
  const [tiktok, setTiktok] = useState('@eventra');
  const [gmail, setGmail] = useState('tickets@eventra.live');
  const [website, setWebsite] = useState('https://eventra.live');
  const [tags, setTags] = useState('Live Music, Concert, Nairobi Nightlife');

  const [isPublishing, setIsPublishing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const presetPosters = [
    { label: 'Festival Stage', url: '/src/assets/images/event_hero_festival_1793028386968.jpg' },
    { label: 'Acoustic Symphony', url: '/src/assets/images/event_concert_orchestra_1793028388592.jpg' },
    { label: 'Modular Rig', url: '/src/assets/images/event_electronic_live_1793028386854.jpg' },
    { label: 'Stadium Arena', url: '/src/assets/images/event_stadium_modern_1793028389434.jpg' },
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPosterImage(reader.result);
          showToast('Custom poster uploaded successfully!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Admission Tier Handlers
  const handleAddAdmissionTier = (preset?: { name: string; price: number; capacity: number; description: string; perks: string }) => {
    triggerHaptic('light');
    const newTier: EventTicketTier = preset
      ? {
          id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          ...preset,
        }
      : {
          id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          name: 'Custom Admission Tier',
          price: 3500,
          capacity: 200,
          description: 'Special access pass',
          perks: 'Gate entry',
        };
    setAdmissionTiers((prev) => [...prev, newTier]);
  };

  const handleUpdateAdmissionTier = (index: number, updates: Partial<EventTicketTier>) => {
    setAdmissionTiers((prev) =>
      prev.map((tier, i) => (i === index ? { ...tier, ...updates } : tier))
    );
  };

  const handleRemoveAdmissionTier = (index: number) => {
    triggerHaptic('light');
    setAdmissionTiers((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddTier = () => {
    triggerHaptic('light');
    const newTier: CustomGroupTier = {
      id: `tier_${Date.now()}`,
      name: 'Squad Bundle Pass',
      size: 4,
      price: 12000,
      perks: 'Group express entry wristbands',
    };
    setCustomGroupTiers((prev) => [...prev, newTier]);
  };

  const handleUpdateTier = (index: number, updates: Partial<CustomGroupTier>) => {
    setCustomGroupTiers((prev) =>
      prev.map((tier, i) => (i === index ? { ...tier, ...updates } : tier))
    );
  };

  const handleRemoveTier = (index: number) => {
    triggerHaptic('light');
    setCustomGroupTiers((prev) => prev.filter((_, i) => i !== index));
  };

  const handlePublishSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !venue.trim()) {
      triggerHaptic('warning');
      showToast('Please provide an event title and venue');
      return;
    }

    triggerHaptic('medium');
    setIsPublishing(true);
    const pPrice = admissionTiers.length > 0 ? admissionTiers[0].price : (parseInt(personalPrice, 10) || 2500);
    const defaultGroupPrice = customGroupTiers.length > 0 ? customGroupTiers[0].price : pPrice * 4 * 0.85;
    const defaultGroupSize = customGroupTiers.length > 0 ? customGroupTiers[0].size : 4;
    const totalTierCapacity = admissionTiers.reduce((acc, t) => acc + (t.capacity || 0), 0) || (parseInt(capacity, 10) || 1000);

    const created = await addEvent({
      title,
      subtitle: subtitle || 'Curated Live Experience in Kenya',
      category,
      categoryLabel:
        category === 'concerts'
          ? 'Festival & Live'
          : category === 'classical'
          ? 'Symphony & Hall'
          : category === 'electronic'
          ? 'Electronic & Club'
          : category === 'sports'
          ? 'Stadium & Match'
          : 'Theatre & Stage',
      city,
      venue,
      address: address || `${venue}, ${city}, Kenya`,
      mapsUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${venue} ${city}`)}`,
      date,
      time,
      doorTime: doorTime || '1 hour prior',
      isoDate: new Date().toISOString(),
      image: posterImage,
      price: pPrice,
      personalPrice: pPrice,
      groupPrice: defaultGroupPrice,
      groupSize: defaultGroupSize,
      tiers: admissionTiers,
      groupTiers: customGroupTiers,
      hostMpesa: hostMpesa || user?.mpesaNumber || '0712 345 678',
      hostName: hostName || user?.name || 'Verified Host',
      organizer: hostName || user?.name || 'Verified Host',
      description: description || 'Extraordinary live experience with direct contactless entry and spatial acoustics.',
      highlights: [
        'Personal & Custom Group ticket tiers',
        `Direct M-Pesa payout to host (${hostMpesa})`,
        'Turnstile verified pass with distinct code',
        'Automated digital ticket dispatch to buyer email',
      ],
      hostEmail,
      autoSendBuyerEmail,
      ageRestriction,
      dressCode,
      parkingInfo,
      refundPolicy,
      capacity: totalTierCapacity,
      instagram,
      tiktok,
      gmail,
      website,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
      isUserCreated: true,
      isFeatured: true,
    });

    setIsPublishing(false);
    showToast(`"${created.title}" published! Opening Host Dashboard.`);
    setCurrentPage('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#090a0d] pt-24 pb-28 text-[#f4f4f6]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1f2229]">
          <div>
            <button
              onClick={() => setCurrentPage('dashboard')}
              className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer mb-2"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Back to Host Dashboard</span>
            </button>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Create New Event
            </h1>
            <p className="text-xs text-[#9496a1] mt-1">
              Publish an event listing worldwide with automated Safaricom M-Pesa & PayPal ticket settlement.
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('dashboard')}
            className="px-4 py-2 rounded-full border border-[#232733] bg-[#16181f] text-xs font-bold text-[#9496a1] hover:text-white transition-colors cursor-pointer self-start sm:self-auto"
          >
            View My Events
          </button>
        </div>

        {/* Creation Form */}
        <form onSubmit={handlePublishSubmit} className="space-y-8 animate-in fade-in duration-200">
          {/* Step 1: Artwork & Details */}
          <div className="p-6 sm:p-8 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#f4f4f6]">
              1. Event Details & Artwork
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              <div className="md:col-span-5 relative h-52 rounded-2xl overflow-hidden border border-[#262934] bg-[#090a0d]">
                <img
                  src={posterImage}
                  alt="Event Poster Preview"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <span className="absolute bottom-2 left-3 text-[10px] font-semibold text-white/80 uppercase tracking-wider">
                  Poster Preview
                </span>
              </div>

              <div className="md:col-span-7 space-y-3">
                <div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handlePhotoUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full h-12 px-4 rounded-2xl border-2 border-dashed border-[#262934] hover:border-emerald-500 transition-colors flex items-center justify-center gap-2 text-xs font-semibold text-[#f4f4f6] bg-[#16181f] cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-emerald-400" />
                    <span>Upload Custom Photo Poster (From Device)</span>
                  </button>
                </div>

                <div>
                  <span className="text-[11px] text-[#9496a1] block mb-1.5">
                    Or choose curated high-resolution artwork:
                  </span>
                  <div className="grid grid-cols-4 gap-2">
                    {presetPosters.map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => setPosterImage(preset.url)}
                        className={`p-1.5 rounded-xl border text-[10px] font-medium truncate cursor-pointer transition-colors ${
                          posterImage === preset.url
                            ? 'border-emerald-500 bg-emerald-500/15 text-emerald-400 font-bold'
                            : 'border-[#262934] bg-[#16181f] text-[#9496a1] hover:text-[#f4f4f6]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Event Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Sol Fest Live Experience 2026"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none transition-all"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Subtitle / Experience Theme
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="e.g. An immersive outdoor audio-visual festival"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as EventCategory)}
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white font-medium focus:border-emerald-500 focus:outline-none"
                >
                  <option value="concerts">Festival & Live Concert</option>
                  <option value="classical">Symphony, Hall & Opera</option>
                  <option value="electronic">Electronic, Club & Rave</option>
                  <option value="sports">Stadium & Championship Match</option>
                  <option value="theatre">Theatre, Ballet & Drama</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Host / Brand Name
                </label>
                <input
                  type="text"
                  value={hostName}
                  onChange={(e) => setHostName(e.target.value)}
                  placeholder="e.g. SoundWave Collective"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {/* Step 2: Date, Time & Venue */}
          <div className="p-6 sm:p-8 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#f4f4f6]">
              2. Schedule & Venue Location
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Event Date
                </label>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="Saturday, Nov 21, 2026"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Showtime (Main Act)
                </label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="7:30 PM"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Doors Open
                </label>
                <input
                  type="text"
                  value={doorTime}
                  onChange={(e) => setDoorTime(e.target.value)}
                  placeholder="5:30 PM (2 hrs prior)"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Venue Name
                </label>
                <input
                  type="text"
                  value={venue}
                  onChange={(e) => setVenue(e.target.value)}
                  placeholder="e.g. Uhuru Gardens Grounds"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  City & County
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Nairobi, Kenya"
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {/* Step 3: Ticket Pricing & Custom Group Passes */}
          <div className="p-6 sm:p-8 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-6">
            <div className="flex items-center justify-between pb-2 border-b border-[#1f2229]">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-[#f4f4f6]">
                  3. Admission Tiers & Pricing
                </h2>
                <p className="text-xs text-[#9496a1] mt-0.5">
                  Configure standard individual admission price and custom group passes.
                </p>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                <Smartphone className="w-3.5 h-3.5" />
                <span>Safaricom M-Pesa Integrated</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Standard Individual Pass (KSh)
                </label>
                <input
                  type="number"
                  value={personalPrice}
                  onChange={(e) => setPersonalPrice(e.target.value)}
                  className="w-full h-12 px-4 text-sm font-mono font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Total Capacity (Passes)
                </label>
                <input
                  type="number"
                  value={capacity}
                  onChange={(e) => setCapacity(e.target.value)}
                  className="w-full h-12 px-4 text-sm font-mono font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Host Payout Mobile (M-Pesa)
                </label>
                <input
                  type="text"
                  value={hostMpesa}
                  onChange={(e) => setHostMpesa(e.target.value)}
                  placeholder="0712 345 678"
                  className="w-full h-12 px-4 text-sm font-mono font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            {/* Individual Admission Tiers (Early Bird, Regular, VIP, VVIP) with Capacity Customization to Any Amount */}
            <div className="space-y-4 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                      Admission Ticket Tiers ({admissionTiers.length})
                    </h3>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-mono">
                      {admissionTiers.reduce((acc, t) => acc + (t.capacity || 0), 0)} Total Passes
                    </span>
                  </div>
                  <p className="text-[11px] text-[#9496a1] mt-0.5">
                    Customize ticket tiers (e.g. Early Bird, Regular, VIP) and set passes to sell quota to any amount.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleAddAdmissionTier({
                      name: 'Early Bird Pass',
                      price: Math.round((parseInt(personalPrice, 10) || 3000) * 0.8),
                      capacity: 200,
                      description: 'Early admission discount with expedited gate entry',
                      perks: 'Fast-track gate pass',
                    })}
                    className="px-2.5 py-1 rounded-full border border-[#262934] bg-[#16181f] text-[10px] font-bold text-[#b8b9c2] hover:text-white hover:border-emerald-500/50 transition-colors cursor-pointer"
                  >
                    + Early Bird
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddAdmissionTier({
                      name: 'VIP Raised Lounge',
                      price: Math.round((parseInt(personalPrice, 10) || 3000) * 2),
                      capacity: 100,
                      description: 'VIP elevated viewing deck and private bar',
                      perks: 'VIP Lounge access',
                    })}
                    className="px-2.5 py-1 rounded-full border border-[#262934] bg-[#16181f] text-[10px] font-bold text-[#b8b9c2] hover:text-white hover:border-emerald-500/50 transition-colors cursor-pointer"
                  >
                    + VIP Lounge
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddAdmissionTier()}
                    className="px-3.5 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Tier</span>
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {admissionTiers.map((tier, idx) => (
                  <div
                    key={tier.id}
                    className="p-4 rounded-2xl bg-[#16181f] border border-[#262934] hover:border-[#353a4b] transition-all space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <Ticket className="w-4 h-4 text-emerald-400 shrink-0" />
                        <input
                          type="text"
                          value={tier.name}
                          onChange={(e) => handleUpdateAdmissionTier(idx, { name: e.target.value })}
                          className="h-10 px-3 text-xs font-bold rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none w-full max-w-xs"
                          placeholder="Tier Name (e.g. Early Bird, Regular Admission)"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAdmissionTier(idx)}
                        className="text-rose-400 hover:text-rose-300 p-2 rounded-xl hover:bg-rose-500/10 transition-colors cursor-pointer shrink-0"
                        title="Remove tier"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Price per Pass (KSh)
                        </label>
                        <input
                          type="number"
                          value={tier.price}
                          onChange={(e) => handleUpdateAdmissionTier(idx, { price: parseInt(e.target.value, 10) || 0 })}
                          className="w-full h-10 px-3 text-xs font-mono font-bold rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Passes to Sell / Quota (Any Amount)
                        </label>
                        <input
                          type="number"
                          value={tier.capacity}
                          onChange={(e) => handleUpdateAdmissionTier(idx, { capacity: parseInt(e.target.value, 10) || 0 })}
                          placeholder="e.g. 50, 200, 1500, 10000"
                          className="w-full h-10 px-3 text-xs font-mono font-bold rounded-xl border border-[#262934] bg-[#111317] text-emerald-400 focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Description & Perks
                        </label>
                        <input
                          type="text"
                          value={tier.description || ''}
                          onChange={(e) => handleUpdateAdmissionTier(idx, { description: e.target.value, perks: e.target.value })}
                          placeholder="e.g. Early entry turnstile pass"
                          className="w-full h-10 px-3 text-xs rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Group Tiers */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
                    Custom Group Tiers ({customGroupTiers.length})
                  </h3>
                  <p className="text-[11px] text-[#646875]">
                    Allow groups of friends or VIPs to buy bundled passes with special perks.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddTier}
                  className="px-3.5 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Group Tier</span>
                </button>
              </div>

              <div className="space-y-3">
                {customGroupTiers.map((tier, idx) => (
                  <div
                    key={tier.id}
                    className="p-4 rounded-2xl bg-[#16181f] border border-[#262934] space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-emerald-400" />
                        <input
                          type="text"
                          value={tier.name}
                          onChange={(e) => handleUpdateTier(idx, { name: e.target.value })}
                          className="h-10 px-3 text-xs font-bold rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none w-56 sm:w-72"
                          placeholder="Tier Name (e.g. VIP Table for 6)"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveTier(idx)}
                        className="text-rose-400 hover:text-rose-300 p-2 rounded-xl hover:bg-rose-500/10 transition-colors cursor-pointer"
                        title="Remove tier"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Pass Quantity
                        </label>
                        <input
                          type="number"
                          value={tier.size}
                          onChange={(e) => handleUpdateTier(idx, { size: parseInt(e.target.value, 10) || 2 })}
                          className="w-full h-10 px-3 text-xs font-mono rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Bundle Price (KSh)
                        </label>
                        <input
                          type="number"
                          value={tier.price}
                          onChange={(e) => handleUpdateTier(idx, { price: parseInt(e.target.value, 10) || 5000 })}
                          className="w-full h-10 px-3 text-xs font-mono rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-[#9496a1] block mb-1">
                          Perks / Amenities
                        </label>
                        <input
                          type="text"
                          value={tier.perks || ''}
                          onChange={(e) => handleUpdateTier(idx, { perks: e.target.value })}
                          placeholder="VIP seating, express lane, bottle service"
                          className="w-full h-10 px-3 text-xs rounded-xl border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Step 4: Social Channels & Contact */}
          <div className="p-6 sm:p-8 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#f4f4f6]">
              4. Social Channels & Customer Support
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Instagram Handle
                </label>
                <input
                  type="text"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  placeholder="@yourbrand"
                  className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  TikTok Handle
                </label>
                <input
                  type="text"
                  value={tiktok}
                  onChange={(e) => setTiktok(e.target.value)}
                  placeholder="@yourbrand"
                  className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Support / Inquiry Gmail
                </label>
                <input
                  type="email"
                  value={gmail}
                  onChange={(e) => setGmail(e.target.value)}
                  placeholder="contact@brand.com"
                  className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Submit Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isPublishing}
              className="w-full h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white font-extrabold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-98"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isPublishing ? 'Publishing Event...' : 'Publish Event Worldwide & Open Host Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
