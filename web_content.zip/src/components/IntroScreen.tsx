import React from 'react';
import { YinYangIcon } from './icons/DaoIcons';
import { soundEngine } from '../services/audioEngine';
import { Play, RotateCcw } from 'lucide-react';

interface IntroScreenProps {
  hasSaveData: boolean;
  onStartNewGame: () => void;
  onContinueGame: () => void;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({
  hasSaveData,
  onStartNewGame,
  onContinueGame
}) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 bg-gradient-to-b from-[#04120e] via-[#072018] to-[#020b08] text-[#fce18b] overflow-hidden select-none">
      {/* Subtle Ambient Mist Glow */}
      <div className="absolute inset-0 pointer-events-none opacity-30">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-[#e2b054]/20 blur-3xl animate-pulse" />
        <div className="absolute bottom-12 left-12 w-72 h-72 rounded-full bg-[#10b981]/15 blur-2xl" />
      </div>

      {/* Centered Emblem, Title & Enter / New Game Buttons Only */}
      <div className="relative z-10 flex flex-col items-center text-center space-y-6 w-full max-w-md">
        <div className="relative">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-[#0d3326] border-2 border-[#e2b054] shadow-[0_0_35px_rgba(226,176,84,0.35)] flex items-center justify-center animate-spin-slow">
            <YinYangIcon className="w-16 h-16 sm:w-20 sm:h-20 text-[#fce18b]" />
          </div>
          <div className="absolute -inset-2 rounded-full border border-[#fce18b]/30 animate-ping opacity-25" />
        </div>

        <h1 className="text-3xl sm:text-5xl font-bold font-dao tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-[#fce18b] via-[#ffffff] to-[#e2b054] drop-shadow-md leading-tight">
          Amazing Sect Cultivation
        </h1>

        <div className="w-full max-w-xs space-y-3 pt-2">
          {hasSaveData && (
            <button
              onClick={() => {
                soundEngine.playGong();
                soundEngine.startBGM();
                onContinueGame();
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e2b054] via-[#fce18b] to-[#d49e38] text-[#072018] font-dao font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl hover:brightness-110 active:scale-[0.98] transition-all min-h-[48px]"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Enter Sect</span>
            </button>
          )}

          <button
            onClick={() => {
              soundEngine.playGong();
              soundEngine.startBGM();
              onStartNewGame();
            }}
            className={`w-full py-3.5 px-6 rounded-2xl font-dao font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] transition-all min-h-[48px] ${
              hasSaveData
                ? 'bg-[#123d30] hover:bg-[#1a4f3f] border border-[#e2b054]/50 text-[#fce18b]'
                : 'bg-gradient-to-r from-[#e2b054] via-[#fce18b] to-[#d49e38] text-[#072018] hover:brightness-110'
            }`}
          >
            {hasSaveData ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{hasSaveData ? 'New Game' : 'Enter New Game'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
