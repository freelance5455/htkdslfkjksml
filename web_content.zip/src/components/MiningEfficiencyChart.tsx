import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Cpu, Activity } from 'lucide-react';

export const MiningEfficiencyChart: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    // Clear any existing content
    d3.select(svgRef.current).selectAll('*').remove();

    const width = svgRef.current.clientWidth || 600;
    const height = 250;
    const margin = { top: 20, right: 30, bottom: 30, left: 40 };

    const svg = d3.select(svgRef.current)
      .attr('width', '100%')
      .attr('height', height)
      .attr('viewBox', `0 0 ${width} ${height}`);

    // Mock data: 7 days of mining metrics
    const data = [
      { day: 'Mon', hashRate: 105, power: 3100, profit: 12 },
      { day: 'Tue', hashRate: 110, power: 3250, profit: 15 },
      { day: 'Wed', hashRate: 108, power: 3200, profit: 13 },
      { day: 'Thu', hashRate: 115, power: 3400, profit: 18 },
      { day: 'Fri', hashRate: 112, power: 3300, profit: 16 },
      { day: 'Sat', hashRate: 120, power: 3500, profit: 22 },
      { day: 'Sun', hashRate: 118, power: 3450, profit: 20 },
    ];

    const x = d3.scalePoint()
      .domain(data.map(d => d.day))
      .range([margin.left, width - margin.right])
      .padding(0.5);

    // Hash rate scale (left axis)
    const yHash = d3.scaleLinear()
      .domain([90, 130])
      .range([height - margin.bottom, margin.top]);

    // Profit scale (right axis)
    const yProfit = d3.scaleLinear()
      .domain([0, 30])
      .range([height - margin.bottom, margin.top]);

    // Add X axis
    svg.append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x))
      .attr('color', '#64748b')
      .style('font-family', 'monospace');

    // Add Hash Rate line
    const hashLine = d3.line<any>()
      .x(d => x(d.day)!)
      .y(d => yHash(d.hashRate))
      .curve(d3.curveMonotoneX);

    svg.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#38bdf8')
      .attr('stroke-width', 3)
      .attr('d', hashLine);

    // Add Profit line
    const profitLine = d3.line<any>()
      .x(d => x(d.day)!)
      .y(d => yProfit(d.profit))
      .curve(d3.curveMonotoneX);

    svg.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#fbbf24') // amber-400
      .attr('stroke-width', 3)
      .attr('d', profitLine);

    // Add dots for hash rate
    svg.selectAll('.dot-hash')
      .data(data)
      .enter()
      .append('circle')
      .attr('cx', d => x(d.day)!)
      .attr('cy', d => yHash(d.hashRate))
      .attr('r', 4)
      .attr('fill', '#0f172a')
      .attr('stroke', '#38bdf8')
      .attr('stroke-width', 2);

    // Add dots for profit
    svg.selectAll('.dot-profit')
      .data(data)
      .enter()
      .append('circle')
      .attr('cx', d => x(d.day)!)
      .attr('cy', d => yProfit(d.profit))
      .attr('r', 4)
      .attr('fill', '#0f172a')
      .attr('stroke', '#fbbf24')
      .attr('stroke-width', 2);

  }, []);

  return (
    <div className="bg-slate-950/80 border border-amber-500/20 rounded-3xl p-6 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20">
            <Cpu className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-amber-100">Mining Efficiency Metrics</h4>
            <p className="text-[10px] text-slate-400">Hash Rate (TH/s) vs Profit Margin ($)</p>
          </div>
        </div>
        <div className="flex items-center space-x-4 text-[10px] font-bold uppercase tracking-wider">
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
            <span className="text-sky-300">Hash Rate</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="text-amber-300">Net Profit</span>
          </div>
        </div>
      </div>
      <div className="relative w-full overflow-hidden">
        <svg ref={svgRef} className="w-full h-full overflow-visible" />
      </div>
    </div>
  );
};
