import React, { useEffect } from 'react';
import { ActiveAlarmTrigger, ClockTheme } from '../types/clock';
import { soundService } from '../services/soundService';
import { Bell, Moon, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AlarmTriggerModalProps {
  activeTrigger: ActiveAlarmTrigger;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
  theme: ClockTheme;
  hour12: boolean;
}

export const AlarmTriggerModal: React.FC<AlarmTriggerModalProps> = ({
  activeTrigger,
  onDismiss,
  onSnooze,
  theme,
  hour12,
}) => {
  const { alarm } = activeTrigger;

  // Start sound loop on mount and clean up on unmount
  useEffect(() => {
    soundService.startAlarmLoop(alarm.sound, alarm.volume);

    // Try browser notification if granted
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`⏰ Alarm: ${alarm.label}`, {
          body: `It's ${alarm.time}! Time to wake up.`,
          icon: '/favicon.ico',
        });
      } catch {
        // Notification failed or blocked
      }
    }

    return () => {
      soundService.stopAlarm();
    };
  }, [alarm]);

  const handleDismiss = () => {
    soundService.stopAlarm();
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // Ignored
    }
    onDismiss();
  };

  const handleSnooze = () => {
    soundService.stopAlarm();
    onSnooze(alarm.snoozeDurationMinutes || 9);
  };

  // 12-hour formatted time
  const formatTime = (timeStr: string) => {
    if (!hour12) return timeStr;
    const [h, m] = timeStr.split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH}:${m.toString().padStart(2, '0')} ${period}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div
        className="relative w-full max-w-md p-8 rounded-3xl border text-center shadow-2xl overflow-hidden"
        style={{
          backgroundColor: theme.surfaceBg,
          borderColor: theme.border,
          boxShadow: `0 0 50px rgba(255, 60, 60, 0.25)`,
        }}
      >
        {/* Animated ambient backdrop pulse */}
        <div className="absolute inset-0 bg-red-500/10 animate-pulse pointer-events-none" />

        {/* Pulsing Bell Icon */}
        <div className="relative inline-flex items-center justify-center w-24 h-24 mb-6 rounded-full bg-red-500/20 text-red-500 animate-bounce">
          <Bell className="w-12 h-12 animate-pulse" />
        </div>

        {/* Alarm Time */}
        <div
          className="text-5xl font-mono font-extrabold tracking-tight tabular-nums mb-2"
          style={{ color: theme.textPrimary }}
        >
          {formatTime(alarm.time)}
        </div>

        {/* Alarm Label */}
        <h2 className="text-xl font-bold tracking-tight mb-2" style={{ color: theme.textAccent }}>
          {alarm.label}
        </h2>

        <p className="text-xs text-slate-400 mb-8">
          Sound: <span className="capitalize text-slate-200">{alarm.sound}</span>
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleSnooze}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border font-semibold text-sm transition-all hover:bg-white/5 active:scale-95"
            style={{
              borderColor: theme.border,
              color: theme.textSecondary,
              backgroundColor: theme.background,
            }}
          >
            <Moon className="w-4 h-4" />
            <span>Snooze {alarm.snoozeDurationMinutes}m</span>
          </button>

          <button
            onClick={handleDismiss}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-sm bg-red-600 hover:bg-red-500 text-white shadow-lg active:scale-95 transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Dismiss Alarm</span>
          </button>
        </div>
      </div>
    </div>
  );
};
