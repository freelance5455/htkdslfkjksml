import React from 'react';
import { Maximize2, Unlock } from 'lucide-react';
import type { Language } from '../types/study';
import { FocusLockVectorIcon } from './LiquidIcons';

interface FocusLockBannerProps {
  lang: Language;
  active: boolean;
  lockRemainingSec: number;
  lockTotalSec: number;
  blockedAppNames: string[];
  escapeAttempts: number;
  needsFullscreenRestore: boolean;
  warningMessage: string | null;
  onRestoreFullscreen: () => void;
  onOpenBlockerList: () => void;
  onAttemptUnlock: () => void;
}

function formatMMSS(sec: number): string {
  const safe = Math.max(0, Math.floor(sec));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const FocusLockBanner: React.FC<FocusLockBannerProps> = ({
  lang,
  active,
  lockRemainingSec,
  lockTotalSec,
  blockedAppNames,
  escapeAttempts,
  needsFullscreenRestore,
  warningMessage,
  onRestoreFullscreen,
  onOpenBlockerList,
  onAttemptUnlock,
}) => {
  if (!active) return null;

  const isBn = lang === 'bn';
  const isLocked = lockRemainingSec > 0;
  const formattedRemaining = formatMMSS(lockRemainingSec);
  const safeTotal = lockTotalSec > 0 ? lockTotalSec : 3600;
  const elapsedPct = Math.min(100, Math.max(0, ((safeTotal - lockRemainingSec) / safeTotal) * 100));

  const appsPreview =
    blockedAppNames.length > 0
      ? blockedAppNames.slice(0, 3).join(', ') +
        (blockedAppNames.length > 3 ? ` +${blockedAppNames.length - 3}` : '')
      : isBn
        ? 'অ্যাপস'
        : 'Apps';

  return (
    <div
      role="status"
      aria-live="polite"
      className="liquid-glass-elevated mb-4 overflow-hidden rounded-2xl border border-amber-300/40 px-4 py-3 text-xs shadow-lg"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-amber-300/40 bg-amber-400/20 text-amber-200">
            <FocusLockVectorIcon active className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-amber-100">
              {isLocked
                ? isBn
                  ? `ব্লক সক্রিয় — ${appsPreview}`
                  : `Blocked — ${appsPreview}`
                : isBn
                  ? 'লক সময় সম্পন্ন'
                  : 'Lock Complete'}
            </p>
            <div className="mt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-slate-300 tabular-nums">
              <span className="font-mono-tabular font-semibold text-sky-200">
                {isLocked ? `${formattedRemaining}` : '00:00'}
              </span>
              {escapeAttempts > 0 && (
                <>
                  <span aria-hidden="true" className="text-slate-500">
                    ·
                  </span>
                  <span className="text-amber-300">
                    {isBn ? `চেষ্টা: ${escapeAttempts}` : `Attempts: ${escapeAttempts}`}
                  </span>
                </>
              )}
              {warningMessage && (
                <>
                  <span aria-hidden="true" className="text-slate-500">
                    ·
                  </span>
                  <span className="text-rose-200">{warningMessage}</span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenBlockerList}
            className="inline-flex min-h-[38px] items-center rounded-xl border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
          >
            {isBn
              ? `ব্লক তালিকা (${blockedAppNames.length})`
              : `Blocked (${blockedAppNames.length})`}
          </button>

          {needsFullscreenRestore && (
            <button
              type="button"
              onClick={onRestoreFullscreen}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-sky-400 px-3 py-1.5 text-xs font-semibold text-slate-950 transition hover:bg-sky-300 whitespace-nowrap"
            >
              <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{isBn ? 'ফুল-স্ক্রিন' : 'Fullscreen'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onAttemptUnlock}
            aria-disabled={isLocked}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border px-3.5 py-1.5 text-xs font-semibold transition whitespace-nowrap ${
              isLocked
                ? 'cursor-not-allowed border-amber-300/30 bg-amber-400/12 text-amber-200/80'
                : 'border-emerald-300/60 bg-emerald-400/25 text-emerald-100 hover:bg-emerald-400/35'
            }`}
          >
            {isLocked ? (
              <>
                <FocusLockVectorIcon active className="h-3.5 w-3.5" />
                <span className="font-mono-tabular">{formattedRemaining}</span>
              </>
            ) : (
              <>
                <Unlock className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{isBn ? 'আনলক' : 'Unlock'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Progress Line */}
      <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            isLocked ? 'bg-amber-300' : 'bg-emerald-400'
          }`}
          style={{ width: `${elapsedPct}%` }}
        />
      </div>
    </div>
  );
};
