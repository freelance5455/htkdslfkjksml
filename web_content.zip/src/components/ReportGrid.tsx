import React, { useState, useMemo } from 'react';
import {
  Image as ImageIcon,
  Search,
  Filter,
  Maximize2,
  Calendar,
  User,
  Tag,
  ArrowRight
} from 'lucide-react';
import { OperationalReport, Sector, ReportImage, ImageTag } from '../types/report';
import { formatDate } from '../utils/formatters';
import { SectorIcon } from './SectorIcon';

interface Props {
  reports: OperationalReport[];
  sectors: Sector[];
  selectedSectorId: string;
  onOpenReport: (report: OperationalReport) => void;
  onOpenPhotoLightbox: (image: ReportImage, report: OperationalReport) => void;
  onOpenNewReportModal: () => void;
}

export const ReportGrid: React.FC<Props> = ({
  reports,
  sectors,
  selectedSectorId,
  onOpenReport,
  onOpenPhotoLightbox,
  onOpenNewReportModal
}) => {
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const sectorMap = useMemo(() => new Map(sectors.map((s) => [s.id, s])), [sectors]);

  // Flatten all images with their parent report
  const allImagesWithReport = useMemo(() => {
    const list: Array<{ image: ReportImage; report: OperationalReport }> = [];
    reports.forEach((rep) => {
      // Sector filter
      if (selectedSectorId !== 'all' && rep.sectorId !== selectedSectorId) {
        return;
      }
      rep.images.forEach((img) => {
        // Tag filter
        if (selectedTag !== 'all' && img.tag !== selectedTag) {
          return;
        }
        // Search filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchCaption = (img.caption || '').toLowerCase().includes(q);
          const matchReport = rep.title.toLowerCase().includes(q);
          const matchProtocol = rep.protocolNumber.toLowerCase().includes(q);
          const matchOperator = rep.operatorName.toLowerCase().includes(q);
          if (!matchCaption && !matchReport && !matchProtocol && !matchOperator) {
            return;
          }
        }
        list.push({ image: img, report: rep });
      });
    });
    return list;
  }, [reports, selectedSectorId, selectedTag, searchQuery]);

  const tags: ImageTag[] = [
    'Prima Intervento',
    'Durante',
    'Dopo Intervento',
    'Anomalia / Danno',
    'Conferma / Verbale',
    'DDT / Scheda Tecnica',
    'Altro'
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-900">
            Archivio Fotografico Operativo
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Verbali visivi, prove di conformità, documentazione prima/dopo e rilievi guasti
          </p>
        </div>
      </div>

      {/* Filter bar */}
      <div className="bg-white border border-neutral-200 rounded-lg p-3 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-2.5">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cerca foto per didascalia, report, operatore o codice..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 focus:bg-white text-neutral-900"
            />
          </div>

          {/* Tag filter tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
            <button
              onClick={() => setSelectedTag('all')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap transition-colors ${
                selectedTag === 'all'
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              Tutte ({allImagesWithReport.length})
            </button>
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap transition-colors ${
                  selectedTag === tag
                    ? 'bg-neutral-900 text-white font-medium'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Image Grid */}
      {allImagesWithReport.length === 0 ? (
        <div className="bg-white border border-neutral-200 rounded-lg py-16 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-neutral-100 mx-auto flex items-center justify-center text-neutral-400">
            <ImageIcon className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-neutral-900">
              Nessuna immagine trovata
            </h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              Non sono presenti immagini per i filtri selezionati. Aggiungi nuove foto all&apos;interno dei tuoi report operativi.
            </p>
          </div>
          <div>
            <button
              onClick={onOpenNewReportModal}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors"
            >
              Crea Report con Immagini
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {allImagesWithReport.map(({ image, report }) => {
            const sector = sectorMap.get(report.sectorId);

            return (
              <div
                key={image.id}
                className="bg-white border border-neutral-200 rounded-lg overflow-hidden group hover:border-neutral-300 transition-all flex flex-col justify-between"
              >
                {/* Photo container */}
                <div
                  className="relative aspect-4/3 bg-neutral-100 overflow-hidden cursor-pointer"
                  onClick={() => onOpenPhotoLightbox(image, report)}
                >
                  <img
                    src={image.url}
                    alt={image.caption || 'Immagine operativa'}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  />
                  
                  {/* Subtle dark gradient scrim at bottom */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />

                  {/* Clean unboxed tag */}
                  <div className="absolute top-2.5 left-2.5 text-[10px] font-semibold text-white bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                    {image.tag}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenPhotoLightbox(image, report);
                    }}
                    title="Ingrandisci a schermo intero"
                    className="absolute top-2.5 right-2.5 w-7 h-7 rounded bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs hover:bg-black/80"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Caption overlay */}
                  <div className="absolute bottom-2 left-2.5 right-2.5 text-white">
                    <p className="text-xs font-medium line-clamp-2 leading-tight">
                      {image.caption || 'Nessuna didascalia fornita'}
                    </p>
                  </div>
                </div>

                {/* Card Footer details */}
                <div className="p-3 bg-white space-y-2 text-xs flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-[11px] text-neutral-500 mb-1">
                      <SectorIcon name={sector?.iconName || 'Layers'} className="w-3 h-3 text-neutral-400" />
                      <span className="truncate">{sector?.name}</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums">{report.protocolNumber}</span>
                    </div>

                    <h4
                      onClick={() => onOpenReport(report)}
                      className="font-medium text-neutral-900 hover:text-neutral-600 cursor-pointer line-clamp-1"
                    >
                      {report.title}
                    </h4>
                  </div>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-[11px] text-neutral-500">
                    <span className="font-mono tabular-nums">
                      {formatDate(image.uploadedAt || report.timestamp)}
                    </span>
                    <button
                      onClick={() => onOpenReport(report)}
                      className="inline-flex items-center gap-1 text-neutral-900 font-medium hover:underline text-[11px]"
                    >
                      <span>Vedi scheda</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
