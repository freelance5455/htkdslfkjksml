import { useEffect, useState } from "react";
import {
  Activity,
  Plane,
  Radio,
  RotateCcw,
  Volume2,
  VolumeX,
  Wallet,
  Zap,
} from "lucide-react";
import { FlightCanvas } from "@/components/flight-canvas";
import { Button } from "@/components/ui/button";
import { clampBet, formatMoney, formatX, START_BANK } from "@/lib/engine";
import { useGame } from "@/lib/store";
import { cn } from "@/lib/utils";

export function AviatorApp() {
  const hydrate = useGame((s) => s.hydrate);
  const tick = useGame((s) => s.tick);
  const started = useGame((s) => s.started);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      tick(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [tick]);

  return (
    <div className="relative flex min-h-dvh max-w-full flex-col overflow-x-hidden bg-bg text-fg">
      <TopBar />
      <HistoryStrip />
      <div className="mx-auto flex w-full max-w-[1180px] flex-1 flex-col gap-3 p-3 pb-6 md:gap-3 md:p-4">
        <div className="grid flex-1 gap-3 lg:grid-cols-[minmax(0,1.35fr)_292px] lg:grid-rows-[minmax(280px,1fr)_auto]">
          <Playfield />
          <div className="lg:row-span-2">
            <SignalPanel />
          </div>
          <BetsRow />
        </div>
        <p className="px-1 text-pretty text-center text-xs leading-relaxed text-faint">
          AeroPulse is a paper-trade simulator. Real crash games are random and
          cannot be predicted — including this one. Play for the signal, not the
          payout.
        </p>
      </div>
      {!started && <StartGate />}
    </div>
  );
}

function TopBar() {
  const balance = useGame((s) => s.balance);
  const live = useGame((s) => s.live);
  const muted = useGame((s) => s.muted);
  const setMutedFlag = useGame((s) => s.setMutedFlag);
  const round = useGame((s) => s.round);
  const roomCode = useGame((s) => s.roomCode);
  const hash = useGame((s) => s.hash);
  const resetBank = useGame((s) => s.resetBank);
  const phase = useGame((s) => s.phase);

  return (
    <header className="border-b border-line bg-surface">
      <div className="mx-auto flex h-14 max-w-[1180px] items-center gap-2 px-3 md:gap-3 md:px-4">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-crash text-fg">
            <Plane className="size-4" strokeWidth={2.2} />
          </span>
          <div className="min-w-0 leading-tight">
            <p className="font-display text-sm font-semibold tracking-wide">AEROPULSE</p>
            <p className="hidden text-[11px] text-muted xs:block sm:block">Live multiplier signal</p>
          </div>
        </div>

        <div className="ml-auto flex shrink-0 items-center gap-1 md:gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-line bg-surface-2 px-3 py-1.5 text-[11px] text-muted lg:flex">
            <span
              className={cn(
                "size-1.5 rounded-full",
                live && phase !== "idle" ? "bg-lift animate-pulse" : "bg-faint",
              )}
            />
            <span className="font-medium text-fg">{roomCode}</span>
            <span className="text-faint">·</span>
            <span className="tabular-nums">#{round}</span>
            <span className="hidden font-mono text-[10px] text-faint md:inline">{hash}</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-full border border-line bg-surface-2 px-3 py-1.5">
            <Wallet className="size-3.5 text-muted" />
            <span className="font-display text-sm font-semibold tabular-nums">{formatMoney(balance)}</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            aria-label={muted ? "Unmute" : "Mute"}
            onClick={() => setMutedFlag(!muted)}
          >
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="hidden size-10 sm:inline-flex"
            aria-label="Reset bank"
            onClick={resetBank}
          >
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}

function HistoryStrip() {
  const history = useGame((s) => s.history);
  return (
    <div className="border-b border-line bg-bg">
      <div className="mx-auto flex max-w-[1180px] gap-1.5 overflow-x-auto px-3 py-2 md:px-4">
        {history.length === 0 && (
          <span className="text-xs text-faint">Waiting for the first round…</span>
        )}
        {history.map((h, i) => (
          <span
            key={`${h.id}-${i}`}
            className={cn(
              "shrink-0 rounded-full px-2.5 py-1 font-display text-xs font-semibold tabular-nums",
              h.crash < 2 && "bg-surface-2 text-muted",
              h.crash >= 2 && h.crash < 10 && "bg-lift/15 text-lift",
              h.crash >= 10 && "bg-crash/20 text-crash",
            )}
            title={`Signal ${formatX(h.signal)} · ${h.hit ? "HIT" : "MISS"}`}
          >
            {formatX(h.crash)}
          </span>
        ))}
      </div>
    </div>
  );
}

function Playfield() {
  const phase = useGame((s) => s.phase);
  const multiplier = useGame((s) => s.multiplier);
  const waitLeft = useGame((s) => s.waitLeft);
  const crashAt = useGame((s) => s.crashAt);
  const lastProfit = useGame((s) => s.lastProfit);

  const flying = phase === "flying";
  const crashed = phase === "crashed";
  const waiting = phase === "waiting" || phase === "idle";

  return (
    <section className="relative min-h-[240px] overflow-hidden rounded-xl border border-line bg-surface md:min-h-[320px] lg:min-h-[360px] h-full">
      <FlightCanvas />
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        {waiting && (
          <div className="text-center">
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Next round in</p>
            <p className="font-display text-5xl font-semibold tabular-nums text-fg md:text-6xl">
              {Math.max(0, waitLeft).toFixed(1)}
            </p>
            <p className="mt-1 text-sm text-muted">Locking signal</p>
          </div>
        )}
        {flying && (
          <p className="font-display text-6xl font-semibold tabular-nums leading-none text-lift md:text-8xl">
            {formatX(multiplier)}
          </p>
        )}
        {crashed && (
          <div className="text-center">
            <p className="text-[11px] uppercase tracking-[0.28em] text-crash">Flew away</p>
            <p className="font-display text-5xl font-semibold tabular-nums text-crash md:text-7xl">
              {formatX(crashAt)}
            </p>
            {lastProfit !== 0 && (
              <p
                className={cn(
                  "mt-2 font-display text-lg font-semibold tabular-nums",
                  lastProfit > 0 ? "text-lift" : "text-muted",
                )}
              >
                {lastProfit > 0 ? "+" : ""}
                {formatMoney(lastProfit)}
              </p>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function SignalPanel() {
  const signal = useGame((s) => s.signal);
  const phase = useGame((s) => s.phase);
  const hits = useGame((s) => s.hits);
  const misses = useGame((s) => s.misses);
  const autoPilot = useGame((s) => s.autoPilot);
  const setAutoPilot = useGame((s) => s.setAutoPilot);
  const roomCode = useGame((s) => s.roomCode);
  const setRoomCode = useGame((s) => s.setRoomCode);
  const resetBank = useGame((s) => s.resetBank);
  const shakeOff = useGame((s) => s.shakeOff);
  const setShakeOff = useGame((s) => s.setShakeOff);
  const history = useGame((s) => s.history);
  const total = hits + misses;
  const rate = total === 0 ? 0 : Math.round((hits / total) * 100);

  return (
    <aside className="flex flex-col gap-3">
      <div className="rounded-xl border border-line bg-surface p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-muted">
            <Radio className="size-4 text-lift" />
            <span className="text-[11px] uppercase tracking-[0.18em]">Next signal</span>
          </div>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              signal?.risk === "safe" && "bg-lift/15 text-lift",
              signal?.risk === "pulse" && "bg-surface-2 text-fg",
              signal?.risk === "moon" && "bg-crash/20 text-crash",
              !signal && "bg-surface-2 text-muted",
            )}
          >
            {signal?.risk ?? "scan"}
          </span>
        </div>

        <p className="font-display text-5xl font-semibold leading-none tabular-nums text-fg">
          {signal ? formatX(signal.flyTo) : "—.——"}
        </p>
        <p className="mt-1 text-sm text-muted">
          Cash-out target{" "}
          <span className="font-display font-semibold tabular-nums text-lift">
            {signal ? formatX(signal.cashOut) : "—"}
          </span>
        </p>

        <div className="mt-4">
          <div className="mb-1 flex justify-between text-[11px] text-muted">
            <span>Confidence</span>
            <span className="tabular-nums">{signal?.confidence ?? 0}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-lift transition-[width] duration-500"
              style={{ width: `${signal?.confidence ?? 0}%` }}
            />
          </div>
        </div>

        {phase === "waiting" && (
          <p className="mt-3 flex items-center gap-2 text-xs text-muted">
            <Zap className="size-3.5 text-lift" />
            Scanning round hash · place bets now
          </p>
        )}
      </div>

      <div className="rounded-xl border border-line bg-surface p-4">
        <div className="mb-3 flex items-center gap-2 text-muted">
          <Activity className="size-4" />
          <span className="text-[11px] uppercase tracking-[0.18em]">Accuracy</span>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <Stat label="Hits" value={`${hits}`} />
          <Stat label="Miss" value={`${misses}`} />
          <Stat label="Rate" value={`${rate}%`} />
        </div>
        <div className="mt-3 flex flex-wrap gap-1">
          {history.slice(0, 12).map((h, i) => (
            <span
              key={`${h.id}-bar-${i}`}
              className={cn(
                "h-1.5 flex-1 min-w-3 rounded-full",
                h.hit ? "bg-lift" : "bg-crash/70",
              )}
            />
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-line bg-surface p-4">
        <label className="text-[11px] uppercase tracking-[0.18em] text-muted" htmlFor="room">
          Linked room
        </label>
        <input
          id="room"
          value={roomCode}
          onChange={(e) => setRoomCode(e.target.value)}
          className="mt-2 h-11 w-full rounded-md border border-line bg-surface-2 px-3 font-display text-sm tracking-wide text-fg outline-none focus:ring-2 focus:ring-lift/40"
          maxLength={24}
          spellCheck={false}
        />
        <p className="mt-2 text-pretty text-xs text-faint">
          Same room code + round produces the same crash seed in this simulator.
        </p>
        <div className="mt-3 flex flex-col gap-2">
          <ToggleRow
            label="Auto-pilot bets"
            on={autoPilot}
            onToggle={() => setAutoPilot(!autoPilot)}
          />
          <ToggleRow
            label="Reduce shake"
            on={shakeOff}
            onToggle={() => setShakeOff(!shakeOff)}
          />
          <button
            type="button"
            onClick={resetBank}
            className="flex h-11 items-center justify-between rounded-md px-1 text-sm text-muted sm:hidden"
          >
            Reset bank
            <RotateCcw className="size-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-surface-2 px-2 py-2">
      <p className="font-display text-lg font-semibold tabular-nums">{value}</p>
      <p className="text-[10px] uppercase tracking-wide text-muted">{label}</p>
    </div>
  );
}

function ToggleRow({
  label,
  on,
  onToggle,
}: {
  label: string;
  on: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="flex h-11 items-center justify-between rounded-md px-1 text-sm text-fg"
    >
      <span>{label}</span>
      <span
        className={cn(
          "relative h-6 w-10 rounded-full transition-colors",
          on ? "bg-lift" : "bg-surface-2",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-5 rounded-full bg-fg transition-transform",
            on ? "translate-x-4" : "translate-x-0.5",
          )}
        />
      </span>
    </button>
  );
}

function BetsRow() {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <BetCard slot={0} label="Bet A" />
      <BetCard slot={1} label="Bet B" />
    </div>
  );
}

function BetCard({ slot, label }: { slot: 0 | 1; label: string }) {
  const bet = useGame((s) => s.bets[slot]);
  const phase = useGame((s) => s.phase);
  const setBetAmount = useGame((s) => s.setBetAmount);
  const placeBet = useGame((s) => s.placeBet);
  const cashOut = useGame((s) => s.cashOut);
  const toggleAutoCash = useGame((s) => s.toggleAutoCash);
  const setAutoCashAt = useGame((s) => s.setAutoCashAt);
  const multiplier = useGame((s) => s.multiplier);
  const balance = useGame((s) => s.balance);
  const [draft, setDraft] = useState(String(bet.amount));
  const [cashDraft, setCashDraft] = useState(String(bet.autoCashAt));

  useEffect(() => {
    setDraft(String(bet.amount));
  }, [bet.amount]);

  useEffect(() => {
    setCashDraft(String(bet.autoCashAt));
  }, [bet.autoCashAt]);

  const canBet = phase === "waiting" && !bet.placed && balance >= bet.amount;
  const canCash = phase === "flying" && bet.placed && bet.cashedAt === null;
  const livePayout = bet.placed && bet.cashedAt === null && phase === "flying"
    ? bet.amount * multiplier
    : bet.payout;

  const commitAmount = () => {
    const n = clampBet(Number(draft));
    setBetAmount(slot, n);
    setDraft(String(n));
  };

  const commitCash = () => {
    const n = Math.max(1.01, Number(cashDraft) || 2);
    setAutoCashAt(slot, Math.round(n * 100) / 100);
    setCashDraft(String(Math.round(n * 100) / 100));
  };

  return (
    <div className="rounded-xl border border-line bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-[11px] uppercase tracking-[0.18em] text-muted">{label}</p>
        {bet.result === "win" && (
          <span className="font-display text-sm font-semibold tabular-nums text-lift">
            +{formatMoney(bet.payout - bet.amount)}
          </span>
        )}
        {bet.result === "lose" && (
          <span className="font-display text-sm font-semibold tabular-nums text-crash">
            −{formatMoney(bet.amount)}
          </span>
        )}
        {bet.placed && bet.cashedAt === null && phase === "flying" && (
          <span className="font-display text-sm font-semibold tabular-nums text-fg">
            {formatMoney(livePayout)}
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
        <div className="flex h-11 min-w-0 items-center rounded-md border border-line bg-surface-2">
          <button
            type="button"
            className="h-11 w-11 text-lg text-muted"
            disabled={bet.placed}
            onClick={() => setBetAmount(slot, clampBet(bet.amount / 2))}
            aria-label="Halve bet"
          >
            −
          </button>
          <input
            className="h-11 min-w-0 flex-1 bg-transparent text-center font-display text-lg font-semibold tabular-nums outline-none"
            value={draft}
            disabled={bet.placed}
            inputMode="decimal"
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commitAmount}
            aria-label={`${label} amount`}
          />
          <button
            type="button"
            className="h-11 w-11 text-lg text-muted"
            disabled={bet.placed}
            onClick={() => setBetAmount(slot, clampBet(bet.amount * 2))}
            aria-label="Double bet"
          >
            +
          </button>
        </div>
        {canCash ? (
          <Button variant="lift" className="w-full min-w-0 sm:min-w-[148px] sm:w-auto" onClick={() => cashOut(slot)}>
            Cash out {formatX(multiplier)}
          </Button>
        ) : (
          <Button
            variant={bet.placed ? "outline" : "default"}
            className="w-full min-w-0 sm:min-w-[148px] sm:w-auto"
            disabled={!canBet}
            onClick={() => placeBet(slot)}
          >
            {bet.placed ? "In play" : "Bet"}
          </Button>
        )}
      </div>

      <div className="mt-3 flex items-center gap-3">
        <button
          type="button"
          onClick={() => toggleAutoCash(slot)}
          className="flex h-11 items-center gap-2 text-sm text-muted"
        >
          <span
            className={cn(
              "flex size-4 items-center justify-center rounded-sm border",
              bet.autoCash ? "border-lift bg-lift" : "border-line",
            )}
          >
            {bet.autoCash && <span className="size-1.5 rounded-full bg-bg" />}
          </span>
          Auto {formatX(bet.autoCashAt)}
        </button>
        <input
          className="h-11 w-24 rounded-md border border-line bg-surface-2 px-2 text-center font-display text-sm tabular-nums outline-none focus:ring-2 focus:ring-lift/40"
          value={cashDraft}
          onChange={(e) => setCashDraft(e.target.value)}
          onBlur={commitCash}
          inputMode="decimal"
          aria-label="Auto cash-out multiplier"
        />
        <span className="text-xs text-faint">x</span>
      </div>
    </div>
  );
}

function StartGate() {
  const startLive = useGame((s) => s.startLive);
  return (
    <div className="fixed inset-0 z-20 flex items-center justify-center bg-bg/80 p-6">
      <div className="w-full max-w-md rounded-xl border border-line bg-surface p-6 text-center shadow-[0_24px_80px_rgba(0,0,0,0.45)]">
        <span className="mx-auto mb-4 flex size-12 items-center justify-center rounded-lg bg-crash">
          <Plane className="size-6" />
        </span>
        <h1 className="font-display text-3xl font-semibold tracking-tight">AeroPulse</h1>
        <p className="mt-2 text-pretty text-sm leading-relaxed text-muted">
          Link a room, read the next fly-to signal, and paper-trade the climb.
          Auto-pilot keeps calling cash-outs while the plane runs.
        </p>
        <Button className="mt-6 w-full" size="lg" onClick={startLive}>
          Start live feed
        </Button>
        <p className="mt-3 text-xs text-faint">Bank {formatMoney(START_BANK)} · simulator only</p>
      </div>
    </div>
  );
}
