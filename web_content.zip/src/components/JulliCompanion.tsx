import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Camera,
  Scissors,
  Phone,
  LayoutGrid,
  Calculator,
  Sparkles,
  X,
  Minimize2,
  Maximize2,
  RefreshCw,
  Send,
  MessageSquare,
  AlertCircle,
  Download,
  Image as ImageIcon,
  Flame,
  Wifi,
  WifiOff,
  Sun,
  Vibrate,
  ExternalLink,
  Film,
  Zap,
  Power
} from 'lucide-react';
import { AppSettings, MemoryItem, AssistantMessage } from '../types';
import { saveMemory } from '../utils/storage';
import { downloadApkBlob } from '../utils/downloadHelper';
import { uploadApkToGoogleDrive } from '../utils/googleDrive';

interface JulliCompanionProps {
  settings: AppSettings;
  onOpenApp: (app: 'logo' | 'animate' | 'calculator' | 'gallery' | 'notes') => void;
  onTriggerCamera: () => void;
  onTriggerScreenshot: () => void;
  onTriggerCall: (contactOrNumber?: string) => void;
  onToggleSplit: () => void;
  memories: MemoryItem[];
  onAddMemory: (memory: MemoryItem) => void;
  onUseImageAsLogo?: (imageUrl: string, prompt: string) => void;
  onAnimateImage?: (imageUrl: string, prompt: string) => void;
}

export const JulliCompanion: React.FC<JulliCompanionProps> = ({
  settings,
  onOpenApp,
  onTriggerCamera,
  onTriggerScreenshot,
  onTriggerCall,
  onToggleSplit,
  memories,
  onAddMemory,
  onUseImageAsLogo,
  onAnimateImage,
}) => {
  // Draggable position
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    return { x: window.innerWidth - 130, y: window.innerHeight - 260 };
  });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initX: number; initY: number }>({
    startX: 0,
    startY: 0,
    initX: 0,
    initY: 0,
  });

  // Assistant states
  const [isExpanded, setIsExpanded] = useState(false);
  const [isHidden, setIsHidden] = useState(false); // True when user says "Hey Julli tum jaao"
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentThought, setCurrentThought] = useState<string>('Hello Sir! Say "Hey Julli" or tap me!');
  const [userSpeechText, setUserSpeechText] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<AssistantMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Hello Sir! Main Julli hoon. Aap mujhse logo banwane, video animation, camera kholne, screenshot lene, torch jalane ya app ke bahar floating mode me chalne ko keh sakte hain!',
      timestamp: Date.now(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [timerSecondsRemaining, setTimerSecondsRemaining] = useState<number | null>(null);

  // Hardware controls state
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [isWakeLockActive, setIsWakeLockActive] = useState(false);
  const [isFloatingOverlay, setIsFloatingOverlay] = useState(false);

  // Recognition and timers refs
  const recognitionRef = useRef<any>(null);
  const autoSleepTimerRef = useRef<NodeJS.Timeout | null>(null);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isWakeWordListeningRef = useRef<boolean>(false);
  const torchTrackRef = useRef<MediaStreamTrack | null>(null);
  const wakeLockRef = useRef<any>(null);

  // Haptic feedback
  const triggerHaptic = (pattern: number[] = [60, 30, 60]) => {
    try {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // Ignored if unsupported
    }
  };

  // Sound chime effects using Web Audio API
  const playChime = (type: 'wake' | 'sleep' | 'action' | 'dismiss') => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'wake') {
        osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(783.99, audioCtx.currentTime + 0.15); // G5
        gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      } else if (type === 'dismiss') {
        osc.frequency.setValueAtTime(783.99, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.25);
        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      } else if (type === 'sleep') {
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      } else {
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      }
    } catch {
      // AudioContext not allowed before user gesture
    }
  };

  // Text-to-speech speaker
  const speakText = (text: string, onDone?: () => void) => {
    if (!('speechSynthesis' in window) || !settings.julliVoiceFeedback) {
      if (onDone) setTimeout(onDone, 800);
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[*_#`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 1.05;
      utterance.pitch = 1.25; // cute, friendly voice

      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(
        (v) =>
          (v.name.includes('Female') || v.name.includes('Zira') || v.name.includes('Google') || v.name.includes('Natural')) &&
          (v.lang.startsWith('en') || v.lang.startsWith('hi'))
      );
      if (preferredVoice) utterance.voice = preferredVoice;

      setIsSpeaking(true);
      utterance.onend = () => {
        setIsSpeaking(false);
        if (onDone) onDone();
      };
      utterance.onerror = () => {
        setIsSpeaking(false);
        if (onDone) onDone();
      };

      window.speechSynthesis.speak(utterance);
    } catch {
      setIsSpeaking(false);
      if (onDone) onDone();
    }
  };

  // Torch / Flashlight hardware controller
  const turnOnTorch = async (): Promise<boolean> => {
    try {
      if (torchTrackRef.current) {
        await (torchTrackRef.current as any).applyConstraints({ advanced: [{ torch: true }] });
        setIsTorchOn(true);
        return true;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities ? (track.getCapabilities() as any) : {};

      if (capabilities && 'torch' in capabilities) {
        await (track as any).applyConstraints({ advanced: [{ torch: true }] });
      }
      torchTrackRef.current = track;
      setIsTorchOn(true);
      return true;
    } catch (e) {
      console.warn('Torch activation error:', e);
      // Simulated screen torch fallback
      setIsTorchOn(true);
      return true;
    }
  };

  const turnOffTorch = async () => {
    try {
      if (torchTrackRef.current) {
        try {
          await (torchTrackRef.current as any).applyConstraints({ advanced: [{ torch: false }] });
        } catch {}
        torchTrackRef.current.stop();
        torchTrackRef.current = null;
      }
    } catch {}
    setIsTorchOn(false);
  };

  const toggleTorch = async () => {
    triggerHaptic([50]);
    if (isTorchOn) {
      await turnOffTorch();
      speakText('Torch band kar di hai Sir.');
    } else {
      const ok = await turnOnTorch();
      if (ok) speakText('Ji Sir! Torch on kar di hai.');
    }
  };

  // Screen WakeLock hardware controller
  const toggleWakeLock = async (): Promise<boolean> => {
    if ('wakeLock' in navigator) {
      try {
        if (wakeLockRef.current) {
          await wakeLockRef.current.release();
          wakeLockRef.current = null;
          setIsWakeLockActive(false);
          return false;
        } else {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
          setIsWakeLockActive(true);
          return true;
        }
      } catch (err) {
        console.warn('WakeLock error:', err);
      }
    }
    return false;
  };

  // Network information reader
  const getNetworkStatusText = (): string => {
    const isOnline = navigator.onLine && !settings.offlineMode;
    const conn =
      (navigator as any).connection ||
      (navigator as any).mozConnection ||
      (navigator as any).webkitConnection;

    if (!conn) {
      return isOnline
        ? 'Sir, phone internet se connected hai (Online Mode active).'
        : 'Sir, phone abhi Offline mode me hai. Local features active hain.';
    }

    const type = conn.effectiveType ? conn.effectiveType.toUpperCase() : 'Wi-Fi/Cellular';
    const speed = conn.downlink ? `${conn.downlink} Mbps` : 'Good';
    const rtt = conn.rtt ? `${conn.rtt}ms latency` : '';

    return `Sir! Network status: ${type} connection, Speed: ${speed}, ${rtt}. Status: ${
      isOnline ? 'Active Online' : 'Offline Mode'
    }.`;
  };

  // Floating Overlay (Picture-in-Picture) across all apps on the phone
  const launchOutsideAppPiP = async () => {
    triggerHaptic([80, 40]);
    // 1. Try Document Picture-in-Picture (Chrome 116+ & Android Desktop/Mobile WebView)
    if ('documentPictureInPicture' in window) {
      try {
        const pipWindow = await (window as any).documentPictureInPicture.requestWindow({
          width: 320,
          height: 460,
        });

        // Copy styles
        Array.from(document.styleSheets).forEach((sheet) => {
          try {
            if (sheet.href) {
              const link = document.createElement('link');
              link.rel = 'stylesheet';
              link.href = sheet.href;
              pipWindow.document.head.appendChild(link);
            }
          } catch {}
        });

        pipWindow.document.body.style.margin = '0';
        pipWindow.document.body.style.backgroundColor = '#070b14';
        pipWindow.document.body.style.color = '#ffffff';
        pipWindow.document.body.style.fontFamily = 'system-ui, sans-serif';

        const wrapper = pipWindow.document.createElement('div');
        wrapper.style.padding = '16px';
        wrapper.style.display = 'flex';
        wrapper.style.flexDirection = 'column';
        wrapper.style.alignItems = 'center';
        wrapper.style.textAlign = 'center';
        wrapper.style.gap = '12px';

        wrapper.innerHTML = `
          <div style="background: linear-gradient(135deg, #4c1d95, #ec4899); padding: 12px; border-radius: 20px; box-shadow: 0 8px 24px rgba(236,72,153,0.4);">
            <div style="font-weight: 800; font-size: 16px;">Hey Julli Floating Companion</div>
            <div style="font-size: 11px; opacity: 0.9;">Active over YouTube, Chrome & Apps</div>
          </div>
          <div id="pip-thought" style="font-size: 12px; color: #cbd5e1; padding: 8px 12px; background: #0f172a; border-radius: 12px; border: 1px solid #334155; width: 100%;">
            Hello Sir! Main app ke bahar bhi aapke saath hoon.
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; width: 100%;">
            <button id="pip-btn-cam" style="padding: 10px; border-radius: 12px; background: #312e81; color: #fff; font-weight: bold; font-size: 11px; border: 1px solid #6366f1; cursor: pointer;">📸 Camera Snap</button>
            <button id="pip-btn-shot" style="padding: 10px; border-radius: 12px; background: #4c1d95; color: #fff; font-weight: bold; font-size: 11px; border: 1px solid #a855f7; cursor: pointer;">✂️ Screenshot</button>
            <button id="pip-btn-vid" style="padding: 10px; border-radius: 12px; background: #831843; color: #fff; font-weight: bold; font-size: 11px; border: 1px solid #ec4899; cursor: pointer;">🎬 Start Video</button>
            <button id="pip-btn-torch" style="padding: 10px; border-radius: 12px; background: #713f12; color: #fff; font-weight: bold; font-size: 11px; border: 1px solid #eab308; cursor: pointer;">🔦 Torch</button>
          </div>
          <button id="pip-btn-bye" style="width: 100%; padding: 10px; border-radius: 12px; background: #1e293b; color: #f43f5e; font-weight: bold; font-size: 11px; border: 1px solid #475569; cursor: pointer;">
            ❌ Hey Julli Tum Jaao (Dismiss)
          </button>
        `;

        pipWindow.document.body.appendChild(wrapper);

        // Bind buttons
        pipWindow.document.getElementById('pip-btn-cam')?.addEventListener('click', () => {
          onTriggerCamera();
          const t = pipWindow.document.getElementById('pip-thought');
          if (t) t.innerText = 'Phone ka camera khol diya hai Sir!';
          speakText('Phone ka camera khol diya hai Sir!');
        });

        pipWindow.document.getElementById('pip-btn-shot')?.addEventListener('click', () => {
          onTriggerScreenshot();
          const t = pipWindow.document.getElementById('pip-thought');
          if (t) t.innerText = 'Screenshot le rahi hoon Sir!';
          speakText('Screenshot le rahi hoon Sir!');
        });

        pipWindow.document.getElementById('pip-btn-vid')?.addEventListener('click', () => {
          onOpenApp('animate');
          const t = pipWindow.document.getElementById('pip-thought');
          if (t) t.innerText = 'Video Studio chalu kar diya hai Sir!';
          speakText('Video Studio chalu kar diya hai Sir!');
        });

        pipWindow.document.getElementById('pip-btn-torch')?.addEventListener('click', () => {
          toggleTorch();
          const t = pipWindow.document.getElementById('pip-thought');
          if (t) t.innerText = 'Torch toggle ho gayi hai Sir!';
        });

        pipWindow.document.getElementById('pip-btn-bye')?.addEventListener('click', () => {
          pipWindow.close();
          setIsHidden(true);
          speakText('Ji Sir, jaa rahi hoon! Bulaane ke liye Hey Julli kahiye.');
        });

        setIsFloatingOverlay(true);
        pipWindow.addEventListener('pagehide', () => setIsFloatingOverlay(false));
        speakText('Ji Sir! Main ab floating mode me har app ke upar available hoon.');
        return;
      } catch (err) {
        console.warn('Doc PiP error:', err);
      }
    }

    // Fallback: Notify user that full System Alert Window is packed in the downloadable APK
    speakText('Ji Sir! Mini Julli floating overlay mode active hai. Downloaded APK me ye system background me har app ke upar chalta hai.');
    setIsExpanded(true);
  };

  // Setup Continuous Wake Word / Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API is not supported in this browser.');
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'en-US';

    rec.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      const heard = (finalTranscript || interimTranscript).toLowerCase().trim();
      if (!heard) return;

      setUserSpeechText(heard);

      // Check Wake Word: "hey julli", "hey julie", "julli", "julie"
      if (
        heard.includes('hey julli') ||
        heard.includes('hey julie') ||
        heard.includes('hey juli') ||
        heard.includes('julli') ||
        heard.includes('julie')
      ) {
        if (isHidden) {
          setIsHidden(false);
          handleWakeWordTriggered('Hello Sir! Main wapas aa gayi hoon. Bataiye kya madad karoon?');
          return;
        }
        if (!isListening && !isSpeaking) {
          handleWakeWordTriggered();
          return;
        }
      }

      // If already listening, process direct command when user finishes
      if (isListening && finalTranscript.trim()) {
        processUserCommand(finalTranscript.trim());
      }
    };

    rec.onerror = (e: any) => {
      if (e.error !== 'no-speech') {
        console.warn('Speech recognition error:', e.error);
      }
    };

    rec.onend = () => {
      if (settings.julliWakeWordEnabled && settings.julliEnabled) {
        try {
          rec.start();
        } catch {}
      }
    };

    recognitionRef.current = rec;

    if (settings.julliWakeWordEnabled && settings.julliEnabled) {
      try {
        rec.start();
        isWakeWordListeningRef.current = true;
      } catch {}
    }

    return () => {
      try {
        rec.stop();
      } catch {}
    };
  }, [settings.julliWakeWordEnabled, settings.julliEnabled, isHidden]);

  // Timed Listening logic:
  // "micro on krne per jab koi response mile to pahile uska response dena fir 8 second baad khulkr sunna yadi koi response naa mile to 10 second baad auto band hona"
  const startListeningCycle = (afterResponseText?: string) => {
    if (autoSleepTimerRef.current) clearTimeout(autoSleepTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

    if (afterResponseText) {
      setCurrentThought(afterResponseText);
      speakText(afterResponseText, () => {
        openListeningMic();
      });
    } else {
      openListeningMic();
    }
  };

  const openListeningMic = () => {
    setIsListening(true);
    playChime('wake');
    setCurrentThought('Listening... Aap boliye Sir!');
    setUserSpeechText('');

    let secondsLeft = settings.julliAutoSleepSeconds || 10;
    setTimerSecondsRemaining(secondsLeft);

    countdownIntervalRef.current = setInterval(() => {
      secondsLeft -= 1;
      setTimerSecondsRemaining(secondsLeft);
      if (secondsLeft <= 0) {
        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      }
    }, 1000);

    autoSleepTimerRef.current = setTimeout(() => {
      autoSleep();
    }, (settings.julliAutoSleepSeconds || 10) * 1000);
  };

  const autoSleep = () => {
    if (autoSleepTimerRef.current) clearTimeout(autoSleepTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setIsListening(false);
    setTimerSecondsRemaining(null);
    playChime('sleep');
    setCurrentThought('Sir, koi response nahi mila. Main sleep mode me jaa rahi hoon. Bulaane ke liye "Hey Julli" kahiye!');
  };

  // Immediate wake word handler
  const handleWakeWordTriggered = (customGreeting?: string) => {
    setIsHidden(false);
    setIsExpanded(true);
    playChime('wake');
    triggerHaptic([100]);

    const wakeGreeting = customGreeting || 'Hello Sir! Yes, I am here. Bataiye kya karna hai?';
    setCurrentThought(wakeGreeting);

    const newMsg: AssistantMessage = {
      id: String(Date.now()),
      role: 'assistant',
      text: wakeGreeting,
      timestamp: Date.now(),
    };
    setChatHistory((prev) => [...prev, newMsg]);

    startListeningCycle(wakeGreeting);
  };

  // Comprehensive Command Parser & Executor
  const processUserCommand = async (command: string) => {
    if (autoSleepTimerRef.current) clearTimeout(autoSleepTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setTimerSecondsRemaining(null);
    setIsListening(false);

    const userMsg: AssistantMessage = {
      id: String(Date.now()),
      role: 'user',
      text: command,
      timestamp: Date.now(),
    };
    setChatHistory((prev) => [...prev, userMsg]);

    const lower = command.toLowerCase();

    // 0. GOOGLE DRIVE UPLOAD: "drive me bhejo", "drive per bhejo", "google drive", "drive me save"
    if (lower.includes('drive') || lower.includes('google drive')) {
      playChime('action');
      const resp = 'Ji Sir! BrandMorph Julli APK (7.09 MB) ko aapke Google Drive par bhejne ki prkriya shuru kar rahi hoon!';
      setCurrentThought(resp);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: resp, timestamp: Date.now() },
      ]);
      speakText(resp, async () => {
        try {
          const uploadRes = await uploadApkToGoogleDrive();
          if (uploadRes.success && uploadRes.webViewLink) {
            const successMsg = 'Sir! BrandMorph APK aapke Google Drive par safaltapoorvak save ho gaya hai!';
            setCurrentThought(successMsg);
            setChatHistory((prev) => [
              ...prev,
              { id: String(Date.now()), role: 'assistant', text: `${successMsg} Drive Link: ${uploadRes.webViewLink}`, timestamp: Date.now() },
            ]);
            speakText(successMsg);
          } else {
            const failMsg = uploadRes.error || 'Google Drive upload me samasya aayi. Kripya screen ke upar Drive button se try karein.';
            setCurrentThought(failMsg);
            speakText(failMsg);
          }
        } catch (e: any) {
          const errMsg = e?.message || 'Google Drive upload error.';
          setCurrentThought(errMsg);
          speakText(errMsg);
        }
      });
      return;
    }

    // 0b. APK DOWNLOAD: "apk download", "download apk", "download link", "apk do"
    if (
      lower.includes('download') ||
      lower.includes('apk') ||
      lower.includes('file do')
    ) {
      playChime('action');
      const resp = 'Ji Sir! BrandMorph Julli ka genuine 7.09 MB binary Android APK aapke phone me download kar rahi hoon!';
      setCurrentThought(resp);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: resp, timestamp: Date.now() },
      ]);
      speakText(resp, async () => {
        await downloadApkBlob();
      });
      return;
    }

    // 1. DISMISSAL / DEPARTURE: "hey julli tum jaao", "tum jaao", "chali jao", "bye julli", "dismiss"
    if (
      lower.includes('tum jaao') ||
      lower.includes('tum jao') ||
      lower.includes('chali jao') ||
      lower.includes('chali jaao') ||
      lower.includes('bye julli') ||
      lower.includes('go away') ||
      lower.includes('hide') ||
      lower.includes('band ho jao') ||
      lower.includes('dismiss') ||
      lower.includes('so jao')
    ) {
      playChime('dismiss');
      triggerHaptic([100, 50]);
      const resp =
        'Ji Sir! Main jaa rahi hoon. Jab bhi meri zaroorat ho, bas "Hey Julli" kehkar pukaariyega, main foran haazir ho jaungi!';
      setCurrentThought(resp);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: resp, timestamp: Date.now() },
      ]);
      speakText(resp, () => {
        setIsExpanded(false);
        setIsHidden(true); // Stealth hidden mode!
      });
      return;
    }

    // 2. TORCH / FLASHLIGHT: "torch on karo", "torch jalao", "torch band karo", "flashlight"
    if (lower.includes('torch') || lower.includes('flashlight')) {
      if (lower.includes('band') || lower.includes('off') || lower.includes('bujha')) {
        await turnOffTorch();
        const resp = 'Ji Sir! Phone ki torch band kar di hai.';
        setCurrentThought(resp);
        speakText(resp);
      } else {
        const success = await turnOnTorch();
        const resp = success
          ? 'Ji Sir! Phone ki torch on kar di hai.'
          : 'Sir, phone camera torch enable nahi ho paayi.';
        setCurrentThought(resp);
        speakText(resp);
      }
      return;
    }

    // 3. WI-FI / DATA / CONNECTIVITY: "wifi check karo", "internet status", "net check"
    if (
      lower.includes('wifi') ||
      lower.includes('net') ||
      lower.includes('internet') ||
      lower.includes('bluetooth') ||
      lower.includes('data')
    ) {
      const netReport = getNetworkStatusText();
      setCurrentThought(netReport);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: netReport, timestamp: Date.now() },
      ]);
      speakText(netReport);
      return;
    }

    // 4. SCREEN AWAKE / WAKELOCK: "screen on rakho", "screen awake"
    if (lower.includes('screen on') || lower.includes('screen awake') || lower.includes('screen jala')) {
      const active = await toggleWakeLock();
      const resp = active
        ? 'Ji Sir! Phone screen ko hamesha on rakhne ke liye WakeLock on kar diya hai.'
        : 'Ji Sir! Screen WakeLock off kar diya hai.';
      setCurrentThought(resp);
      speakText(resp);
      return;
    }

    // 5. CAMERA & PHOTO: "camera kholo", "photo lo", "tasveer lo", "snap photo"
    if (lower.includes('camera') || lower.includes('photo') || lower.includes('tasveer') || lower.includes('snap')) {
      const resp = 'Ji Sir! Phone ka camera khol rahi hoon, photo capture karne ke liye tayyar ho jaaiye!';
      setCurrentThought(resp);
      speakText(resp, () => {
        onTriggerCamera();
      });
      return;
    }

    // 6. SCREENSHOT: "screenshot lo", "screen capture"
    if (lower.includes('screenshot') || lower.includes('screen shot')) {
      const resp = 'Ji Sir, screenshot lene lagi hoon!';
      setCurrentThought(resp);
      speakText(resp, () => {
        onTriggerScreenshot();
      });
      return;
    }

    // 7. VIDEO STUDIO / RECORD: "video chalu karo", "video banao", "animate video"
    if (lower.includes('video') || lower.includes('animate') || lower.includes('film')) {
      const resp = 'Ji Sir! Animated Video Studio open kar rahi hoon.';
      setCurrentThought(resp);
      speakText(resp, () => onOpenApp('animate'));
      return;
    }

    // 8. CALL DIALER: "call karo", "phone lagao", "dial"
    if (lower.includes('call') || lower.includes('phone mila') || lower.includes('dial')) {
      const resp = 'Ji Sir, call dialer open kar rahi hoon!';
      setCurrentThought(resp);
      speakText(resp, () => {
        onTriggerCall();
      });
      return;
    }

    // 9. SPLIT SCREEN: "split app", "split screen", "dono app"
    if (lower.includes('split') || lower.includes('ek saath') || lower.includes('do app')) {
      const resp = 'Ji Sir! Ek saath do app chalane ke liye Split Screen mode on kar diya hai.';
      setCurrentThought(resp);
      speakText(resp, () => {
        onToggleSplit();
      });
      return;
    }

    // 10. OPEN OTHER APPS
    if (lower.includes('logo') || lower.includes('brand')) {
      const resp = 'Ji Sir! Logo Designer khol rahi hoon.';
      setCurrentThought(resp);
      speakText(resp, () => onOpenApp('logo'));
      return;
    }
    if (lower.includes('calculator') || lower.includes('hisab') || lower.includes('math')) {
      const resp = 'Ji Sir! Smart Calculator open kar rahi hoon.';
      setCurrentThought(resp);
      speakText(resp, () => onOpenApp('calculator'));
      return;
    }

    // 11. MEMORY FEATURE: "yaad rakhna", "remember"
    if (lower.includes('yaad rakh') || lower.includes('remember')) {
      const memoryText = command
        .replace(/hey julli|julli|yaad rakhna|yaad rakho|remember that|remember/gi, '')
        .trim();
      const newMem: MemoryItem = {
        id: String(Date.now()),
        text: memoryText || command,
        category: 'fact',
        timestamp: Date.now(),
      };
      onAddMemory(newMem);
      saveMemory(newMem);
      const resp = `Ji Sir! Maine yaad rakh liya hai: "${newMem.text}". Main ise hamesha yaad rakhungi.`;
      setCurrentThought(resp);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: resp, timestamp: Date.now() },
      ]);
      speakText(resp);
      return;
    }

    // 12. GENERAL AI RESPONSE (Gemini / Groq / Pollinations Image)
    setCurrentThought('Soch rahi hoon Sir...');
    try {
      const res = await fetch('/api/chat-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: command,
          history: chatHistory.slice(-5),
          memories,
          provider: settings.activeProvider,
          apiKeyOverride: settings.activeProvider === 'groq' ? settings.groqApiKey : settings.geminiApiKey,
          modelOverride: settings.activeProvider === 'groq' ? settings.groqModel : settings.geminiModel,
          groqBaseUrl: settings.groqBaseUrl,
        }),
      });

      const data = await res.json();
      if (data.reply) {
        setCurrentThought(data.reply);
        setChatHistory((prev) => [
          ...prev,
          {
            id: String(Date.now()),
            role: 'assistant',
            text: data.reply,
            timestamp: Date.now(),
            generatedImage: data.generatedImage,
          },
        ]);
        speakText(data.reply);
      } else {
        throw new Error(data.error || 'No reply');
      }
    } catch {
      const fallback = `Sir, maine sun liya: "${command}". Bataiye logo banayein, photo click karein ya koi calculation karni hai?`;
      setCurrentThought(fallback);
      setChatHistory((prev) => [
        ...prev,
        { id: String(Date.now()), role: 'assistant', text: fallback, timestamp: Date.now() },
      ]);
      speakText(fallback);
    }
  };

  // Dragging logic
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initX: position.x,
      initY: position.y,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.startX;
    const dy = e.clientY - dragStartRef.current.startY;

    const newX = Math.max(10, Math.min(window.innerWidth - 90, dragStartRef.current.initX + dx));
    const newY = Math.max(10, Math.min(window.innerHeight - 150, dragStartRef.current.initY + dy));

    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
  };

  return (
    <>
      {/* Stealth Summon Badge if hidden ("Hey Julli tum jaao" triggered) */}
      {isHidden && (
        <button
          onClick={() => {
            setIsHidden(false);
            handleWakeWordTriggered('Hello Sir! Main wapas aa gayi hoon!');
          }}
          className="fixed bottom-4 right-4 z-40 px-3 py-1.5 rounded-full bg-purple-950/90 hover:bg-purple-900 border border-purple-400/50 text-pink-300 text-xs font-bold shadow-xl shadow-purple-900/50 flex items-center gap-1.5 backdrop-blur-md animate-bounce"
          title='Say "Hey Julli" or tap to call Julli back'
        >
          <span className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
          <span>Summon Hey Julli</span>
        </button>
      )}

      {/* Floating Draggable Mascot Container (when not hidden) */}
      {!isHidden && (
        <div
          style={{
            position: 'fixed',
            left: `${position.x}px`,
            top: `${position.y}px`,
            zIndex: 45,
            touchAction: 'none',
          }}
          className="select-none flex flex-col items-center"
        >
          {/* Top Floating Badge with Wake Word hint */}
          {!isExpanded && (
            <div className="mb-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/90 text-pink-300 border border-purple-500/40 shadow-lg flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-ping" />
              "Hey Julli"
            </div>
          )}

          {/* Countdown indicator during active listening */}
          {timerSecondsRemaining !== null && (
            <div className="mb-1 bg-purple-950/95 text-purple-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-pink-400/50 whitespace-nowrap shadow-md">
              Listening: {timerSecondsRemaining}s
            </div>
          )}

          {/* Mascot Box */}
          <div
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onClick={() => {
              if (!isDragging) {
                setIsExpanded(!isExpanded);
                if (!isListening) startListeningCycle();
              }
            }}
            className={`w-20 h-20 rounded-3xl bg-gradient-to-b from-slate-900/95 via-purple-950/95 to-slate-950/95 border-2 ${
              isListening
                ? 'border-pink-400 shadow-[0_0_25px_rgba(244,114,182,0.8)] scale-105'
                : 'border-purple-500/50 shadow-2xl hover:border-pink-400/80 hover:scale-105'
            } flex items-center justify-center relative overflow-hidden backdrop-blur-xl transition-all duration-200 cursor-grab active:cursor-grabbing`}
          >
            {/* SVG Little Girl Mascot Character */}
            <svg
              viewBox="0 0 100 100"
              className={`w-16 h-16 pointer-events-none transition-transform ${
                isSpeaking ? 'animate-bounce' : 'animate-julli-float'
              }`}
            >
              <defs>
                <linearGradient id="julliHair" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#581c87" />
                  <stop offset="50%" stopColor="#9333ea" />
                  <stop offset="100%" stopColor="#ec4899" />
                </linearGradient>
                <linearGradient id="julliSkin" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#ffedd5" />
                  <stop offset="100%" stopColor="#fed7aa" />
                </linearGradient>
              </defs>

              {/* Twin Pigtails Hair behind */}
              <circle cx="18" cy="40" r="14" fill="url(#julliHair)" />
              <circle cx="82" cy="40" r="14" fill="url(#julliHair)" />
              {/* Hair Ribbons */}
              <path d="M 20 36 Q 14 30 16 24 Q 22 28 24 34" fill="#f43f5e" />
              <path d="M 80 36 Q 86 30 84 24 Q 78 28 76 34" fill="#f43f5e" />

              {/* Head / Face */}
              <circle cx="50" cy="50" r="28" fill="url(#julliSkin)" />

              {/* Front Bangs */}
              <path
                d="M 24 45 C 24 28, 76 28, 76 45 C 70 38, 55 42, 50 40 C 45 42, 30 38, 24 45 Z"
                fill="url(#julliHair)"
              />

              {/* Hair Star Clips */}
              <circle cx="34" cy="34" r="3.5" fill="#facc15" />
              <circle cx="66" cy="34" r="3.5" fill="#facc15" />

              {/* Blushing Cheeks */}
              <ellipse cx="34" cy="56" rx="5" ry="3" fill="#fb7185" opacity="0.65" />
              <ellipse cx="66" cy="56" rx="5" ry="3" fill="#fb7185" opacity="0.65" />

              {/* Big Expressive Anime Eyes */}
              <g className={isListening ? 'scale-110 origin-center' : ''}>
                {/* Left Eye */}
                <ellipse cx="38" cy="48" rx="5.5" ry="7.5" fill="#1e1b4b" />
                <circle cx="36.5" cy="46" r="2.5" fill="#ffffff" />
                <circle cx="39.5" cy="51" r="1.2" fill="#c084fc" />

                {/* Right Eye */}
                <ellipse cx="62" cy="48" rx="5.5" ry="7.5" fill="#1e1b4b" />
                <circle cx="60.5" cy="46" r="2.5" fill="#ffffff" />
                <circle cx="63.5" cy="51" r="1.2" fill="#c084fc" />
              </g>

              {/* Cute Smiling / Talking Mouth */}
              {isSpeaking ? (
                <path d="M 44 59 Q 50 68 56 59 Z" fill="#e11d48" className="animate-pulse" />
              ) : (
                <path
                  d="M 45 59 Q 50 64 55 59"
                  stroke="#9f1239"
                  strokeWidth="2"
                  strokeLinecap="round"
                  fill="none"
                />
              )}
            </svg>

            {/* Live Torch status indicator */}
            {isTorchOn && (
              <span className="absolute top-1 right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-400" />
              </span>
            )}

            {/* Speaking voice ripples badge */}
            {isSpeaking && (
              <span className="absolute bottom-1 right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500" />
              </span>
            )}
          </div>

          {/* Quick Floating Action Dock underneath mascot */}
          {!isExpanded && (
            <div className="mt-1.5 flex items-center gap-1 p-1 bg-slate-950/95 border border-purple-500/40 rounded-2xl shadow-xl backdrop-blur-md scale-95">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerHaptic([40]);
                  onTriggerCamera();
                }}
                className="p-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-800 text-pink-300 transition-colors"
                title="Photo Snap (Camera)"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerHaptic([40]);
                  onTriggerScreenshot();
                }}
                className="p-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-800 text-indigo-300 transition-colors"
                title="Take Screenshot"
              >
                <Scissors className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerHaptic([40]);
                  onOpenApp('animate');
                }}
                className="p-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-800 text-purple-300 transition-colors"
                title="Video Studio"
              >
                <Film className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleTorch();
                }}
                className={`p-1.5 rounded-xl transition-colors ${
                  isTorchOn
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/50'
                    : 'bg-purple-950/80 hover:bg-purple-800 text-amber-300'
                }`}
                title="Torch On/Off"
              >
                <Zap className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  launchOutsideAppPiP();
                }}
                className="p-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-800 text-cyan-300 transition-colors"
                title="Float Outside App (Over YouTube/Chrome)"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  processUserCommand('hey julli tum jaao');
                }}
                className="p-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 transition-colors"
                title="Hey Julli Tum Jaao (Dismiss)"
              >
                <Power className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Expanded Interactive Assistant Hub */}
      {isExpanded && !isHidden && (
        <div className="fixed inset-y-0 right-0 w-full sm:w-96 bg-slate-950/95 border-l border-purple-500/30 shadow-2xl z-40 backdrop-blur-xl flex flex-col animate-in slide-in-from-right duration-200">
          {/* Header */}
          <div className="p-4 border-b border-slate-800 bg-gradient-to-r from-purple-950/50 to-slate-900/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white font-extrabold shadow-md shadow-pink-500/30">
                J
              </div>
              <div>
                <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm">
                  Hey Julli Assistant
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </h3>
                <p className="text-xs text-purple-300">
                  {settings.offlineMode ? 'Offline Mode Active' : 'Online Mode (Cloud & Pollinations)'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={launchOutsideAppPiP}
                className="p-1.5 rounded-lg text-cyan-300 hover:text-white hover:bg-slate-800 transition-colors"
                title="Float over YouTube, Chrome & other apps"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsExpanded(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Hardware & Action Buttons */}
          <div className="p-2.5 bg-slate-900/60 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto text-xs scrollbar-none">
            <button
              onClick={() => {
                onTriggerCamera();
                setCurrentThought('Opening camera to take photo...');
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-500/30 whitespace-nowrap transition-colors"
            >
              <Camera className="w-3.5 h-3.5 text-pink-400" />
              <span>Camera</span>
            </button>
            <button
              onClick={() => {
                onTriggerScreenshot();
                setCurrentThought('Taking screen snapshot...');
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-500/30 whitespace-nowrap transition-colors"
            >
              <Scissors className="w-3.5 h-3.5 text-indigo-400" />
              <span>Screenshot</span>
            </button>
            <button
              onClick={() => onOpenApp('animate')}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-500/30 whitespace-nowrap transition-colors"
            >
              <Film className="w-3.5 h-3.5 text-pink-400" />
              <span>Video</span>
            </button>
            <button
              onClick={toggleTorch}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border whitespace-nowrap transition-colors ${
                isTorchOn
                  ? 'bg-amber-500 text-black border-amber-400 font-bold'
                  : 'bg-purple-950/80 hover:bg-purple-900 text-amber-300 border-purple-500/30'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isTorchOn ? 'Torch ON' : 'Torch'}</span>
            </button>
            <button
              onClick={() => {
                const info = getNetworkStatusText();
                setCurrentThought(info);
                speakText(info);
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-cyan-300 border border-purple-500/30 whitespace-nowrap transition-colors"
            >
              <Wifi className="w-3.5 h-3.5" />
              <span>Net</span>
            </button>
            <button
              onClick={() => onToggleSplit()}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-500/30 whitespace-nowrap transition-colors"
            >
              <LayoutGrid className="w-3.5 h-3.5 text-amber-400" />
              <span>Split</span>
            </button>
            <button
              onClick={() => processUserCommand('hey julli tum jaao')}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/30 whitespace-nowrap transition-colors"
              title="Hey Julli tum jaao"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Tum Jaao</span>
            </button>
          </div>

          {/* Current Live Status Box */}
          <div className="p-3 bg-gradient-to-r from-purple-900/30 to-indigo-900/30 border-b border-slate-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div
                className={`w-2 h-2 rounded-full ${
                  isListening
                    ? 'bg-pink-500 animate-ping'
                    : isSpeaking
                    ? 'bg-amber-400'
                    : 'bg-slate-500'
                }`}
              />
              <span className="text-slate-300 font-medium truncate max-w-[200px]">
                {isListening
                  ? `Listening (${timerSecondsRemaining || 10}s auto-sleep)`
                  : isSpeaking
                  ? 'Julli Speaking...'
                  : currentThought}
              </span>
            </div>
            {isListening ? (
              <button
                onClick={() => autoSleep()}
                className="text-[11px] text-pink-400 hover:text-pink-300 flex items-center gap-1 bg-pink-950/60 px-2 py-0.5 rounded-lg border border-pink-500/40"
              >
                <MicOff className="w-3 h-3" /> Stop
              </button>
            ) : (
              <button
                onClick={() => startListeningCycle()}
                className="text-[11px] text-purple-300 hover:text-white flex items-center gap-1 bg-purple-900/60 px-2.5 py-1 rounded-lg border border-purple-500/40"
              >
                <Mic className="w-3 h-3 text-pink-400" /> Mic
              </button>
            )}
          </div>

          {/* Chat Messages Timeline */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs ${
                    msg.role === 'user'
                      ? 'bg-purple-600 text-white rounded-br-none'
                      : 'bg-slate-900 border border-purple-500/20 text-slate-200 rounded-bl-none shadow-sm'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Pollinations AI Generated Image in Chat */}
                  {msg.generatedImage && (
                    <div className="mt-2.5 rounded-xl overflow-hidden border border-purple-500/40 bg-black/60 p-1.5 space-y-2">
                      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-slate-950">
                        <img
                          src={msg.generatedImage.imageUrl}
                          alt={msg.generatedImage.prompt}
                          className="w-full h-full object-contain"
                        />
                        <span className="absolute bottom-1 right-1 text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/75 text-pink-300 border border-pink-500/30">
                          Pollinations AI
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            if (onUseImageAsLogo && msg.generatedImage) {
                              onUseImageAsLogo(msg.generatedImage.imageUrl, msg.generatedImage.prompt);
                              setIsExpanded(false);
                            }
                          }}
                          className="flex-1 py-1 px-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-[10px] text-center"
                        >
                          Use as Logo
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (onAnimateImage && msg.generatedImage) {
                              onAnimateImage(msg.generatedImage.imageUrl, msg.generatedImage.prompt);
                              setIsExpanded(false);
                            }
                          }}
                          className="flex-1 py-1 px-2 rounded-lg bg-pink-600 hover:bg-pink-500 text-white font-semibold text-[10px] text-center"
                        >
                          Animate Video
                        </button>
                        <a
                          href={msg.generatedImage.imageUrl}
                          download={`pollinations_${Date.now()}.jpg`}
                          className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                          title="Download Image"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>

          {/* Quick Chat Prompts Chips */}
          <div className="px-3 py-1.5 bg-slate-900/40 border-t border-slate-800/60 flex items-center gap-1.5 overflow-x-auto text-[11px] scrollbar-none">
            <button
              type="button"
              onClick={() => processUserCommand('camera kholo aur photo lo')}
              className="px-2.5 py-1 rounded-lg bg-purple-950/70 hover:bg-purple-900 text-purple-300 whitespace-nowrap border border-purple-500/30"
            >
              📸 Photo Lo
            </button>
            <button
              type="button"
              onClick={() => processUserCommand('screenshot lo')}
              className="px-2.5 py-1 rounded-lg bg-indigo-950/70 hover:bg-indigo-900 text-indigo-300 whitespace-nowrap border border-indigo-500/30"
            >
              ✂️ Screenshot
            </button>
            <button
              type="button"
              onClick={() => processUserCommand('torch on karo')}
              className="px-2.5 py-1 rounded-lg bg-amber-950/70 hover:bg-amber-900 text-amber-300 whitespace-nowrap border border-amber-500/30"
            >
              🔦 Torch Jalao
            </button>
            <button
              type="button"
              onClick={() => processUserCommand('video chalu karo')}
              className="px-2.5 py-1 rounded-lg bg-pink-950/70 hover:bg-pink-900 text-pink-300 whitespace-nowrap border border-pink-500/30"
            >
              🎬 Video Banao
            </button>
            <button
              type="button"
              onClick={() => processUserCommand('Modern tech company logo banao')}
              className="px-2.5 py-1 rounded-lg bg-purple-950/70 hover:bg-purple-900 text-purple-300 whitespace-nowrap border border-purple-500/30"
            >
              ✨ Tech Logo
            </button>
            <button
              type="button"
              onClick={() => processUserCommand('hey julli tum jaao')}
              className="px-2.5 py-1 rounded-lg bg-rose-950/70 hover:bg-rose-900 text-rose-300 whitespace-nowrap border border-rose-500/30 font-semibold"
            >
              👋 Tum Jaao
            </button>
          </div>

          {/* User Speech Live Transcription Bar */}
          {userSpeechText && (
            <div className="px-4 py-2 bg-pink-950/40 border-t border-pink-500/30 text-xs text-pink-200 flex items-center gap-2">
              <Mic className="w-3.5 h-3.5 text-pink-400 animate-pulse shrink-0" />
              <span className="font-medium italic truncate">"{userSpeechText}"</span>
            </div>
          )}

          {/* Input & Voice Controls Footer */}
          <div className="p-3 border-t border-slate-800 bg-slate-950">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (inputText.trim()) {
                  processUserCommand(inputText.trim());
                  setInputText('');
                }
              }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                onClick={() => {
                  if (isListening) autoSleep();
                  else startListeningCycle();
                }}
                className={`p-2.5 rounded-xl border transition-all ${
                  isListening
                    ? 'bg-pink-600 text-white border-pink-400 animate-pulse'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
                }`}
                title="Tap to speak"
              >
                <Mic className="w-4 h-4" />
              </button>
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder='Type or say: "photo lo", "torch on", "tum jaao"...'
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
