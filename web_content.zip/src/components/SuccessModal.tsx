import React from 'react';
import {
  CheckCircle2,
  Sparkles,
  Instagram,
  Clock,
  ShieldCheck,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

interface SuccessModalProps {
  username: string;
  followersCount: number;
  orderId: string;
  onClose: () => void;
  onOpenAdmin?: () => void;
  isAdminUnlocked?: boolean;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({
  username,
  followersCount,
  orderId,
  onClose,
  onOpenAdmin,
  isAdminUnlocked,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-300">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-purple-500/40 p-6 sm:p-8 shadow-2xl shadow-purple-950/90 text-center overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top Success Icon */}
        <div className="relative mx-auto w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-emerald-400 p-[2px] shadow-xl shadow-emerald-950/60 mb-5 animate-bounce" style={{ animationDuration: '2s' }}>
          <div className="w-full h-full rounded-3xl bg-slate-950 flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          </div>
        </div>

        {/* Main Success Title */}
        <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Order Submitted Successfully! 🎉
        </h3>

        {/* Followers count badge */}
        <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-pink-500/20 border border-pink-500/40 shadow-inner">
          <TrendingUp className="w-5 h-5 text-pink-400" />
          <span className="text-xl sm:text-2xl font-black text-pink-300 font-mono">
            +{followersCount.toLocaleString()} Real Followers
          </span>
        </div>

        {/* Prompt specific Hindi text requirement */}
        <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-950/80 to-purple-950/60 border border-purple-500/30">
          <p className="text-base sm:text-lg font-bold text-amber-300 flex items-center justify-center gap-2">
            <Clock className="w-5 h-5 text-amber-400 shrink-0" />
            <span>24 घंटे के अंदर आपके followers बढ़ जाएंगे</span>
          </p>
          <p className="text-xs text-slate-300 mt-1">
            (Your followers will safely increase within 24 hours via high-retention gradual organic drip)
          </p>
        </div>

        {/* Order Details Grid */}
        <div className="mt-5 p-4 rounded-2xl bg-slate-950/70 border border-purple-500/15 text-xs text-left space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Target Account:</span>
            <span className="text-white font-mono font-semibold flex items-center gap-1">
              <Instagram className="w-3.5 h-3.5 text-pink-400" />
              @{username}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Order ID:</span>
            <span className="text-purple-300 font-mono font-medium">{orderId}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Queue Status:</span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-semibold font-mono text-[11px] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              Processing (In Queue)
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Protection:</span>
            <span className="text-slate-200 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Anti-Drop 30-Day Refill
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:brightness-110 active:scale-95 text-white font-bold text-sm transition-all shadow-lg shadow-purple-950"
          >
            Done & Add Another
          </button>

          {isAdminUnlocked && onOpenAdmin && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenAdmin();
              }}
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-200 text-sm font-semibold transition-all border border-purple-500/30 flex items-center justify-center gap-1.5"
            >
              <span>View in Admin</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
