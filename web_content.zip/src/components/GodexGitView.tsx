/**
 * GODEX Phase 8 - Git Intelligence, Operations & Release Center View
 * Complete GitOps console:
 * - Current State & Controlled Operations (Stage, Commit, Branch, Checkpoint)
 * - Branches & Ahead/Behind Tracking
 * - Semantic Commits & Change-to-Symbol Analysis
 * - Diff & Working Tree Inspection
 * - 3-Way AST Merge & Conflict Analyzer
 * - Comprehensive 11-Dimension Release Center & Readiness Score
 */

import React, { useState, useEffect } from 'react';
import { 
  GitBranch, 
  RotateCcw, 
  Plus, 
  FileCode, 
  Clock, 
  ShieldCheck, 
  GitCommit, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle,
  Shield, 
  Layers, 
  Search, 
  History, 
  Activity, 
  FileText,
  GitMerge,
  GitPullRequest,
  Check,
  X,
  Play,
  Flame,
  Zap,
  Lock,
  Unlock,
  RefreshCw,
  Sliders,
  ExternalLink,
  ChevronRight,
  Package,
  Terminal,
  FileDiff
} from 'lucide-react';
import { Checkpoint } from '../types';
import { GitIntelligence } from '../git/gitIntelligence';
import { GitCommitEntry, CommitAnalysis, FileHistoryEntry } from '../git/gitTypes';
import { GitOperationPlanner } from '../gitops/gitOperationPlanner';
import { GitOperationExecutor } from '../gitops/gitOperationExecutor';
import { GitOperationHistory } from '../gitops/gitOperationHistory';
import { GitApprovalGate } from '../gitops/gitApprovalGate';
import { ReleasePlanner, ReleasePlan } from '../gitops/releasePlanner';
import { ReleaseVerification } from '../gitops/releaseVerification';
import { ReleaseAudit, GitOperationProposal, MergeProposal } from '../gitops/gitOperationTypes';

interface GodexGitViewProps {
  checkpoints: Checkpoint[];
  files: Record<string, string>;
  onCreateCheckpoint: (name: string, description: string) => void;
  onRollback: (checkpointId: string) => void;
  onOpenDiff: () => void;
}

export const GodexGitView: React.FC<GodexGitViewProps> = ({
  checkpoints,
  files,
  onCreateCheckpoint,
  onRollback,
  onOpenDiff
}) => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<
    'CURRENT_STATE' | 'OPERATIONS' | 'BRANCHES' | 'COMMITS' | 'DIFF' | 'MERGE' | 'RELEASE' | 'CHECKPOINTS'
  >('CURRENT_STATE');

  // Operation forms & local state
  const [currentBranch, setCurrentBranch] = useState<string>('main');
  const [newBranchName, setNewBranchName] = useState('');
  const [commitMessage, setCommitMessage] = useState('');
  const [selectedCommit, setSelectedCommit] = useState<CommitAnalysis | null>(null);
  const [isCreatingCheckpoint, setIsCreatingCheckpoint] = useState(false);
  const [cpName, setCpName] = useState('');
  const [cpDescription, setCpDescription] = useState('');
  const [selectedFileForHistory, setSelectedFileForHistory] = useState<string>('src/App.tsx');
  const [fileHistory, setFileHistory] = useState<FileHistoryEntry[]>([]);

  // Merge state
  const [mergeSourceBranch, setMergeSourceBranch] = useState<string>('feature/phase-7-memory-git');
  const [mergeTargetBranch, setMergeTargetBranch] = useState<string>('main');
  const [activeMergePlan, setActiveMergePlan] = useState<MergeProposal | null>(null);

  // Release Center state
  const [releaseAudit, setReleaseAudit] = useState<ReleaseAudit | null>(null);
  const [releasePlan, setReleasePlan] = useState<ReleasePlan | null>(null);
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [verificationFeedback, setVerificationFeedback] = useState<string | null>(null);

  // Pending proposals & history triggers
  const [pendingProposals, setPendingProposals] = useState<GitOperationProposal[]>([]);
  const [operationLogs, setOperationLogs] = useState(GitOperationHistory.getHistory(15));
  const [actionNotice, setActionNotice] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const gitIntel = GitIntelligence.getInstance();
  const repoState = gitIntel.getRepositoryState(files);
  const commits = gitIntel.getRecentCommits(15);
  const branches = gitIntel.getBranches();
  const workingTree = GitOperationPlanner.getWorkingTreeState(files, currentBranch);

  const showNotice = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setActionNotice({ type, text });
    setTimeout(() => setActionNotice(null), 5000);
  };

  const refreshState = () => {
    setPendingProposals(GitApprovalGate.getPendingProposals());
    setOperationLogs(GitOperationHistory.getHistory(15));
  };

  useEffect(() => {
    refreshState();
    // Initialize release audit
    const plan = ReleasePlanner.planRelease({
      projectTitle: 'GODEX Autonomous Studio',
      targetBranch: currentBranch,
      files
    });
    setReleasePlan(plan);
    setReleaseAudit(plan.audit);
  }, [files, currentBranch]);

  // Handle Stage File
  const handleStageFile = async (filePath: string) => {
    const proposal = GitOperationPlanner.planOperation({
      type: 'STAGE_FILES',
      targetFiles: [filePath],
      title: `Stage ${filePath}`
    }, files, currentBranch);

    const res = await GitOperationExecutor.execute(proposal, {
      workspaceFiles: files,
      currentBranch
    });

    if (res.status === 'SUCCESS') {
      showNotice(`Staged ${filePath}`, 'success');
    } else {
      showNotice(`Failed to stage: ${res.message}`, 'error');
    }
    refreshState();
  };

  // Handle Commit
  const handleCreateCommit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commitMessage.trim()) return;

    const proposal = GitOperationPlanner.planOperation({
      type: 'CREATE_COMMIT',
      suggestedCommitMessage: commitMessage.trim(),
      title: `Commit: ${commitMessage.trim()}`
    }, files, currentBranch);

    if (proposal.policyResult?.requiresApproval) {
      proposal.approvalMode = 'USER_APPROVED';
      proposal.status = 'APPROVED';
    }

    const res = await GitOperationExecutor.execute(proposal, {
      workspaceFiles: files,
      currentBranch
    });

    if (res.status === 'SUCCESS') {
      showNotice(`Created commit [${res.commitHash?.slice(0, 7)}]: ${commitMessage}`, 'success');
      setCommitMessage('');
    } else {
      showNotice(`Commit failed: ${res.message}`, 'error');
    }
    refreshState();
  };

  // Handle Create Branch
  const handleCreateBranch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchName.trim()) return;

    const proposal = GitOperationPlanner.planOperation({
      type: 'CREATE_BRANCH',
      targetBranch: newBranchName.trim(),
      title: `Create branch '${newBranchName.trim()}'`
    }, files, currentBranch);

    const res = await GitOperationExecutor.execute(proposal, {
      workspaceFiles: files,
      currentBranch
    });

    if (res.status === 'SUCCESS') {
      showNotice(`Created branch '${newBranchName.trim()}'`, 'success');
      setNewBranchName('');
    } else {
      showNotice(`Branch creation failed: ${res.message}`, 'error');
    }
    refreshState();
  };

  // Handle Switch Branch
  const handleSwitchBranch = async (targetBranch: string) => {
    const proposal = GitOperationPlanner.planOperation({
      type: 'SWITCH_BRANCH',
      targetBranch,
      title: `Switch to '${targetBranch}'`,
      userExplicitApproval: true
    }, files, currentBranch);

    const res = await GitOperationExecutor.execute(proposal, {
      workspaceFiles: files,
      currentBranch,
      onBranchChanged: (b) => setCurrentBranch(b)
    });

    if (res.status === 'SUCCESS') {
      setCurrentBranch(targetBranch);
      showNotice(`Switched to branch '${targetBranch}'`, 'success');
    } else {
      showNotice(`Failed to switch branch: ${res.message}`, 'error');
    }
    refreshState();
  };

  // Handle Prepare Merge
  const handlePrepareMerge = () => {
    const sourceFiles = GitOperationExecutor.getBranchFiles(mergeSourceBranch) || files;
    const targetFiles = GitOperationExecutor.getBranchFiles(mergeTargetBranch) || files;
    const plan = GitOperationPlanner.planMerge(mergeSourceBranch, mergeTargetBranch, sourceFiles, targetFiles);
    setActiveMergePlan(plan);
    showNotice(`Evaluated merge from '${mergeSourceBranch}' into '${mergeTargetBranch}': ${plan.conflicts.length} conflicts`, 'info');
  };

  // Handle Execute Merge
  const handleExecuteMerge = async () => {
    if (!activeMergePlan || activeMergePlan.isBlocked) return;

    const proposal = GitOperationPlanner.planOperation({
      type: 'MERGE',
      targetBranch: activeMergePlan.sourceBranch,
      baseBranch: activeMergePlan.targetBranch,
      title: `Merge '${activeMergePlan.sourceBranch}' into '${activeMergePlan.targetBranch}'`,
      userExplicitApproval: true
    }, files, currentBranch);

    proposal.approvalMode = 'USER_APPROVED';
    proposal.status = 'APPROVED';

    const res = await GitOperationExecutor.execute(proposal, {
      workspaceFiles: files,
      currentBranch
    });

    if (res.status === 'SUCCESS') {
      showNotice(`Successfully merged '${activeMergePlan.sourceBranch}' into '${activeMergePlan.targetBranch}'!`, 'success');
      setActiveMergePlan(null);
    } else {
      showNotice(`Merge execution failed: ${res.message}`, 'error');
    }
    refreshState();
  };

  // Handle Approve Proposal
  const handleApproveProposal = async (proposalId: string) => {
    const approved = GitApprovalGate.approveProposal(proposalId, 'USER');
    if (approved) {
      const res = await GitOperationExecutor.execute(approved, {
        workspaceFiles: files,
        currentBranch
      });
      showNotice(`Approved & Executed: ${res.message}`, res.status === 'SUCCESS' ? 'success' : 'error');
      refreshState();
    }
  };

  // Handle Reject Proposal
  const handleRejectProposal = (proposalId: string) => {
    GitApprovalGate.rejectProposal(proposalId, 'User rejected in GitOps view');
    showNotice('Proposal rejected and cancelled.', 'info');
    refreshState();
  };

  // Handle Run Release Audit
  const handleRunReleaseAudit = async () => {
    setIsAuditing(true);
    setVerificationFeedback(null);
    setTimeout(async () => {
      const plan = ReleasePlanner.planRelease({
        projectTitle: 'GODEX Autonomous Studio',
        targetBranch: currentBranch,
        files
      });
      const verResult = await ReleaseVerification.verifyRelease(plan, files);
      setReleasePlan(plan);
      setReleaseAudit(verResult.audit);
      setIsAuditing(false);
      setVerificationFeedback(verResult.summary);
      showNotice(`Release Audit complete: Score ${verResult.score.score}/100 (${verResult.score.status})`, verResult.verified ? 'success' : 'error');
    }, 400);
  };

  return (
    <div className="flex-1 h-full flex flex-col bg-[#08090D] overflow-y-auto select-none font-sans p-4 md:p-6 space-y-6">
      {/* Action Notice Banner */}
      {actionNotice && (
        <div className={`p-3 rounded-xl flex items-center justify-between text-xs font-mono border ${
          actionNotice.type === 'success' 
            ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' 
            : actionNotice.type === 'error'
              ? 'bg-rose-950/60 border-rose-500/40 text-rose-300'
              : 'bg-blue-950/60 border-blue-500/40 text-blue-300'
        }`}>
          <div className="flex items-center gap-2">
            {actionNotice.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{actionNotice.text}</span>
          </div>
          <button onClick={() => setActionNotice(null)} className="text-neutral-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1C2230] pb-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#141A26] border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-md">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-wide">Git Intelligence & Release Center</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                PHASE 8 GITOPS
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono">
              Controlled Git Operations • 3-Way AST Merges • Stale-State Defense • 11-Pillar Release Readiness
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onOpenDiff}
            className="px-3 py-1.5 rounded-lg bg-[#141A26] hover:bg-[#1E2638] text-neutral-300 hover:text-white font-semibold text-xs transition-colors flex items-center gap-1.5 border border-[#232C40]"
          >
            <FileDiff className="w-3.5 h-3.5 text-blue-400" />
            <span>Workspace Diff</span>
          </button>
          <button
            onClick={() => setIsCreatingCheckpoint(!isCreatingCheckpoint)}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm font-sans"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Snapshot</span>
          </button>
        </div>
      </div>

      {/* Repository State Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col">
          <span className="text-[10px] text-neutral-400">Current Branch</span>
          <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 mt-1">
            <GitBranch className="w-3.5 h-3.5" />
            <span>{currentBranch}</span>
          </div>
          <span className="text-[9px] text-neutral-500 mt-0.5 truncate">Fingerprint: {workingTree.fingerprint.slice(0, 16)}</span>
        </div>

        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col">
          <span className="text-[10px] text-neutral-400">HEAD Commit</span>
          <div className="text-xs font-bold text-white mt-1">
            {workingTree.headShortHash}
          </div>
          <span className="text-[9px] text-neutral-500 mt-0.5">Ahead: {workingTree.aheadCount} | Behind: {workingTree.behindCount}</span>
        </div>

        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col">
          <span className="text-[10px] text-neutral-400">Working Tree</span>
          <div className={`text-xs font-bold mt-1 ${workingTree.isClean ? 'text-emerald-400' : 'text-amber-400'}`}>
            {workingTree.isClean ? 'Clean' : `${workingTree.modifiedFiles.length} Modified • ${workingTree.stagedFiles.length} Staged`}
          </div>
          <span className="text-[9px] text-neutral-500 mt-0.5">{Object.keys(files).length} Total Workspace Files</span>
        </div>

        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col">
          <span className="text-[10px] text-neutral-400">Release Quality Score</span>
          <div className={`text-xs font-bold mt-1 ${
            (releaseAudit?.score.score || 0) >= 80 ? 'text-emerald-400' : (releaseAudit?.score.score || 0) >= 50 ? 'text-amber-400' : 'text-rose-400'
          }`}>
            {releaseAudit?.score.score ?? 100} / 100 ({releaseAudit?.score.status ?? 'READY'})
          </div>
          <span className="text-[9px] text-neutral-500 mt-0.5">{releaseAudit?.score.blockers.length || 0} Blockers • {releaseAudit?.score.warnings.length || 0} Warnings</span>
        </div>
      </div>

      {/* Create Checkpoint Modal/Form */}
      {isCreatingCheckpoint && (
        <form onSubmit={(e) => {
          e.preventDefault();
          if (!cpName.trim()) return;
          onCreateCheckpoint(cpName.trim(), cpDescription.trim() || 'Manual user checkpoint');
          setCpName('');
          setCpDescription('');
          setIsCreatingCheckpoint(false);
          showNotice(`Checkpoint "${cpName}" created successfully.`, 'success');
        }} className="p-4 rounded-xl bg-[#0D111A] border border-blue-500/40 space-y-3 font-sans">
          <div className="text-xs font-bold text-blue-300">Create New Workspace Snapshot</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input
              type="text"
              autoFocus
              placeholder="Checkpoint Title (e.g. Added Video Timeline Component)"
              value={cpName}
              onChange={e => setCpName(e.target.value)}
              className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-blue-500"
            />
            <input
              type="text"
              placeholder="Description of changes..."
              value={cpDescription}
              onChange={e => setCpDescription(e.target.value)}
              className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreatingCheckpoint(false)}
              className="px-3 py-1 rounded bg-[#171E2C] text-neutral-300 text-xs hover:bg-[#202A3D]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded bg-blue-600 text-white font-semibold text-xs hover:bg-blue-500"
            >
              Save Snapshot
            </button>
          </div>
        </form>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#1C2436] pb-2 font-mono overflow-x-auto">
        {[
          { id: 'CURRENT_STATE', label: 'Current State & Ops', icon: Activity },
          { id: 'BRANCHES', label: 'Branches', icon: GitBranch },
          { id: 'COMMITS', label: 'Commit History', icon: GitCommit },
          { id: 'DIFF', label: 'Working Tree Diff', icon: FileDiff },
          { id: 'MERGE', label: '3-Way Merge', icon: GitMerge },
          { id: 'RELEASE', label: 'Release Center', icon: ShieldCheck },
          { id: 'CHECKPOINTS', label: `Checkpoints (${checkpoints.length})`, icon: Clock }
        ].map(tab => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                active 
                  ? 'bg-blue-950/80 text-blue-300 border border-blue-500/40 shadow-sm' 
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#121622]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: CURRENT STATE & CONTROLLED OPERATIONS */}
      {activeTab === 'CURRENT_STATE' && (
        <div className="space-y-6">
          {/* Pending Approval Requests */}
          {pendingProposals.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 space-y-3 font-sans">
              <div className="flex items-center gap-2 text-amber-300 text-xs font-bold">
                <Lock className="w-4 h-4 text-amber-400" />
                <span>Pending Approval Gate Requests ({pendingProposals.length})</span>
              </div>
              <div className="space-y-2">
                {pendingProposals.map(prop => (
                  <div key={prop.id} className="p-3 rounded-lg bg-[#0F1420] border border-amber-500/20 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-500/30">
                          {prop.type}
                        </span>
                        <span className="font-semibold text-white">{prop.title}</span>
                      </div>
                      <p className="text-neutral-400 text-[11px] mt-1">{prop.description}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleApproveProposal(prop.id)}
                        className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>
                      <button
                        onClick={() => handleRejectProposal(prop.id)}
                        className="px-2.5 py-1 rounded bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/30 text-xs flex items-center gap-1"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Staging & Commit Creation Form */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 font-sans">
            {/* Commit Form */}
            <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <GitCommit className="w-3.5 h-3.5 text-blue-400" />
                  <span>Create Verified Commit</span>
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Branch: {currentBranch}</span>
              </div>
              <form onSubmit={handleCreateCommit} className="space-y-2">
                <input
                  type="text"
                  placeholder="Commit message (e.g. feat(auth): add OAuth validation gate)"
                  value={commitMessage}
                  onChange={e => setCommitMessage(e.target.value)}
                  className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-2 rounded-lg outline-none focus:border-blue-500 font-mono"
                />
                <div className="flex items-center justify-between text-[11px] text-neutral-400">
                  <span>Staged files will be committed. Stale-state protection active.</span>
                  <button
                    type="submit"
                    disabled={!commitMessage.trim()}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Commit Changes</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Quick Branch Creator */}
            <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Create New Branch</span>
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Base: {currentBranch}</span>
              </div>
              <form onSubmit={handleCreateBranch} className="space-y-2">
                <input
                  type="text"
                  placeholder="Branch name (e.g. feature/checkout-flow)"
                  value={newBranchName}
                  onChange={e => setNewBranchName(e.target.value)}
                  className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-2 rounded-lg outline-none focus:border-cyan-500 font-mono"
                />
                <div className="flex items-center justify-between text-[11px] text-neutral-400">
                  <span>Policy checked automatically before creation.</span>
                  <button
                    type="submit"
                    disabled={!newBranchName.trim()}
                    className="px-3 py-1.5 rounded-lg bg-cyan-700 hover:bg-cyan-600 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Create Branch</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Staged & Modified Files Manager */}
          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-3 font-sans">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                <span>Working Tree Changes ({workingTree.modifiedFiles.length + workingTree.stagedFiles.length})</span>
              </span>
              <span className="text-[10px] font-mono text-neutral-500">Selective Staging Gate</span>
            </div>

            {workingTree.isClean ? (
              <div className="p-6 text-center text-xs text-neutral-400 font-mono border border-dashed border-[#1C2436] rounded-lg">
                Working tree is clean. No uncommitted modifications.
              </div>
            ) : (
              <div className="space-y-1.5">
                {workingTree.modifiedFiles.map(path => (
                  <div key={path} className="flex items-center justify-between p-2 rounded-lg bg-[#121722] border border-[#1F2738] text-xs font-mono">
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-amber-400 font-bold">M</span>
                      <span className="text-white truncate">{path}</span>
                    </div>
                    <button
                      onClick={() => handleStageFile(path)}
                      className="px-2 py-1 rounded bg-[#1A2334] hover:bg-blue-600 text-blue-300 hover:text-white text-[10px] font-semibold transition-colors shrink-0"
                    >
                      Stage
                    </button>
                  </div>
                ))}
                {workingTree.stagedFiles.map(path => (
                  <div key={path} className="flex items-center justify-between p-2 rounded-lg bg-[#0F1B1F] border border-emerald-500/30 text-xs font-mono">
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-emerald-400 font-bold">STAGED</span>
                      <span className="text-emerald-200 truncate">{path}</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-semibold">Ready to Commit</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Operation History Audit Log */}
          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-3 font-sans">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-neutral-400" />
                <span>Executed Operation Audit Evidence ({operationLogs.length})</span>
              </span>
              <span className="text-[10px] font-mono text-neutral-500">Immutable Telemetry</span>
            </div>

            {operationLogs.length === 0 ? (
              <div className="p-6 text-center text-xs text-neutral-500 font-mono">
                No Git operations executed in this session yet.
              </div>
            ) : (
              <div className="space-y-2">
                {operationLogs.map(log => (
                  <div key={log.operationId} className="p-2.5 rounded-lg bg-[#111622] border border-[#1E2538] text-xs font-mono flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                        log.status === 'SUCCESS' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' : 'bg-rose-950 text-rose-300 border border-rose-500/30'
                      }`}>
                        {log.status}
                      </span>
                      <span className="text-white font-semibold">{log.type}</span>
                      <span className="text-neutral-400 truncate text-[11px]">{log.message}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-neutral-500 shrink-0">
                      <span>Branch: {log.branchAfter}</span>
                      <span>Risk: {log.evidence.risk}</span>
                      <span>{new Date(log.evidence.timestamp).toLocaleTimeString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: BRANCHES */}
      {activeTab === 'BRANCHES' && (
        <div className="space-y-3 font-sans">
          {branches.map(b => (
            <div key={b.name} className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <GitBranch className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white font-mono">{b.name}</span>
                    {b.name === currentBranch && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-500/30 font-bold">
                        ACTIVE HEAD
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono block mt-0.5">
                    Upstream: {b.upstreamBranch} • Last: [{b.lastCommitHash.slice(0, 7)}] {b.lastCommitMessage}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right text-[10px] font-mono text-neutral-400">
                  <div>Ahead: {b.ahead} | Behind: {b.behind}</div>
                  <div className="text-neutral-500">{new Date(b.lastCommitDate).toLocaleDateString()}</div>
                </div>
                {b.name !== currentBranch && (
                  <button
                    onClick={() => handleSwitchBranch(b.name)}
                    className="px-2.5 py-1 rounded bg-[#162030] hover:bg-cyan-600 text-cyan-300 hover:text-white text-xs font-semibold transition-colors font-mono"
                  >
                    Switch
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: COMMITS */}
      {activeTab === 'COMMITS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-3 font-sans">
            {commits.map(commit => (
              <div
                key={commit.hash}
                onClick={() => {
                  const analysis = gitIntel.analyzeCommit(commit.hash, files);
                  setSelectedCommit(analysis);
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedCommit?.commitId === commit.hash
                    ? 'bg-[#121824] border-blue-500/50 shadow-md'
                    : 'bg-[#0D111A] border-[#1C2436] hover:border-[#2C3852]'
                }`}
              >
                <div className="flex items-center justify-between gap-2 flex-wrap font-mono">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#172033] text-blue-300 border border-blue-500/30">
                      {commit.shortHash}
                    </span>
                    <span className="text-xs font-bold text-white font-sans">{commit.message}</span>
                  </div>
                  <span className="text-[10px] text-neutral-500">
                    {new Date(commit.date).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 pt-2 mt-2 border-t border-[#182030]">
                  <span>{commit.author}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">+{commit.insertions}</span>
                    <span className="text-rose-400">-{commit.deletions}</span>
                    <span>{commit.changedFiles.length} files</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Commit Inspector Sidebar */}
          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-4 font-sans text-xs">
            <span className="font-bold text-white block pb-2 border-b border-[#1C2436]">Commit Semantics</span>
            {selectedCommit ? (
              <div className="space-y-3">
                <div>
                  <span className="text-neutral-400 block text-[10px] font-mono">Message</span>
                  <p className="text-white font-semibold mt-0.5">{selectedCommit.message}</p>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[10px] font-mono">Architectural Layers</span>
                  <div className="flex gap-1 flex-wrap mt-1">
                    {selectedCommit.architecturalLayers.map(l => (
                      <span key={l} className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500/30 text-[10px] font-mono">
                        {l}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[10px] font-mono">Symbols Impacted ({selectedCommit.symbolsAffected.length})</span>
                  <div className="space-y-1 mt-1 font-mono text-[11px] text-neutral-300">
                    {selectedCommit.symbolsAffected.map((sym, sIdx) => (
                      <div key={sIdx} className="p-1 rounded bg-[#131824] truncate">
                        <strong className="text-cyan-400">{sym}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-neutral-500 font-mono text-center py-8">Select a commit to view semantic AST impact.</p>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: WORKING TREE DIFF */}
      {activeTab === 'DIFF' && (
        <div className="space-y-4 font-sans">
          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white">Full Workspace Working Tree Comparison</span>
              <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
                Authoritative file differences between working tree and last commit
              </p>
            </div>
            <button
              onClick={onOpenDiff}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5"
            >
              <FileDiff className="w-3.5 h-3.5" />
              <span>Launch Side-by-Side Diff Viewer</span>
            </button>
          </div>

          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-2 font-mono text-xs">
            <span className="text-neutral-400 block font-bold">Modified Files Summary</span>
            {workingTree.modifiedFiles.map(path => (
              <div key={path} className="p-2 rounded bg-[#121722] border border-[#1E2538] flex items-center justify-between">
                <span className="text-amber-300">{path}</span>
                <span className="text-[10px] text-neutral-500">{(files[path] || '').split('\n').length} lines</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: 3-WAY AST MERGE & CONFLICTS */}
      {activeTab === 'MERGE' && (
        <div className="space-y-4 font-sans">
          <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <GitMerge className="w-4 h-4 text-purple-400" />
                  <span>3-Way AST Merge & Conflict Analyzer</span>
                </span>
                <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
                  Evaluates file-level, symbol-level, and dependency conflicts before execution
                </p>
              </div>
              <button
                onClick={handlePrepareMerge}
                className="px-3 py-1.5 rounded-lg bg-purple-700 hover:bg-purple-600 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Evaluate Merge</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Source Branch (to merge in)</label>
                <select
                  value={mergeSourceBranch}
                  onChange={e => setMergeSourceBranch(e.target.value)}
                  className="w-full bg-[#131824] border border-[#222E46] text-white px-3 py-2 rounded-lg outline-none"
                >
                  {branches.map(b => (
                    <option key={b.name} value={b.name}>{b.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Target Base Branch</label>
                <select
                  value={mergeTargetBranch}
                  onChange={e => setMergeTargetBranch(e.target.value)}
                  className="w-full bg-[#131824] border border-[#222E46] text-white px-3 py-2 rounded-lg outline-none"
                >
                  {branches.map(b => (
                    <option key={b.name} value={b.name}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {activeMergePlan && (
            <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    activeMergePlan.isBlocked 
                      ? 'bg-rose-950 text-rose-300 border border-rose-500/30' 
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                  }`}>
                    {activeMergePlan.status}
                  </span>
                  <span className="text-xs font-bold text-white">
                    Merge '{activeMergePlan.sourceBranch}' into '{activeMergePlan.targetBranch}'
                  </span>
                </div>
                <button
                  disabled={activeMergePlan.isBlocked}
                  onClick={handleExecuteMerge}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Execute Merge</span>
                </button>
              </div>

              {/* Conflict list */}
              <div className="space-y-2 font-mono text-xs">
                <span className="text-neutral-400 font-bold block">AST Conflict Findings ({activeMergePlan.conflicts.length})</span>
                {activeMergePlan.conflicts.length === 0 ? (
                  <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
                    ✓ Clean 3-way merge. No conflicting symbols or delete/modify clashes detected.
                  </div>
                ) : (
                  activeMergePlan.conflicts.map((conf, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-rose-950/40 border border-rose-500/40 text-rose-200">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">{conf.conflictType}</span>
                        <span>in {conf.filePath}</span>
                      </div>
                      <p className="text-[11px] text-neutral-300 mt-1">{conf.description}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: RELEASE CENTER */}
      {activeTab === 'RELEASE' && (
        <div className="space-y-6 font-sans">
          {/* Release Readiness Hero Bar */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-[#0D121F] to-[#12192B] border border-[#1E2840] space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">Production Release Readiness Center</h3>
                  <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                    (releaseAudit?.score.score || 0) >= 80 ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' : 'bg-amber-950 text-amber-300 border border-amber-500/40'
                  }`}>
                    {releaseAudit?.score.status || 'READY'}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 font-mono mt-1">
                  Target Branch: <strong className="text-cyan-300">{currentBranch}</strong> • Evidence-grounded quality assertion
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleRunReleaseAudit}
                  disabled={isAuditing}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 shadow-md"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isAuditing ? 'Auditing Codebase...' : 'Execute Release Audit'}</span>
                </button>
              </div>
            </div>

            {/* Score & Summary Banner */}
            <div className="p-3.5 rounded-xl bg-[#090C14] border border-[#182133] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <div className="text-2xl font-black font-mono text-emerald-400">
                  {releaseAudit?.score.score ?? 100}%
                </div>
                <div>
                  <span className="font-bold text-white block">Quality & Safety Index</span>
                  <span className="text-[11px] text-neutral-400">{releaseAudit?.score.summary}</span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-neutral-400 font-mono text-[11px]">
                <span>Blockers: <strong className="text-rose-400">{releaseAudit?.score.blockers.length || 0}</strong></span>
                <span>Warnings: <strong className="text-amber-400">{releaseAudit?.score.warnings.length || 0}</strong></span>
              </div>
            </div>
          </div>

          {/* 11-Dimension Release Audit Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {releaseAudit?.score.auditItems.map(item => (
              <div key={item.id} className="p-3.5 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{item.title}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                    item.status === 'PASS' 
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' 
                      : item.status === 'WARN'
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/30'
                        : 'bg-rose-950 text-rose-300 border border-rose-500/30'
                  }`}>
                    {item.status}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-400">{item.message}</p>
                <div className="text-[9px] font-mono text-neutral-500 pt-1 border-t border-[#161D2B]">
                  Category: {item.category}
                </div>
              </div>
            ))}
          </div>

          {/* Release Plan Steps */}
          {releasePlan && (
            <div className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] space-y-3">
              <span className="text-xs font-bold text-white block">Automated Release Execution Checklist</span>
              <div className="space-y-2 font-mono text-xs">
                {releasePlan.steps.map(step => (
                  <div key={step.id} className="p-2.5 rounded-lg bg-[#121722] border border-[#1E2538] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-neutral-500 font-bold">{step.stepNumber}.</span>
                      <span className="text-white font-semibold">{step.name}</span>
                      <span className="text-[10px] text-neutral-400">({step.details})</span>
                    </div>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                      step.status === 'PASSED' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'
                    }`}>
                      {step.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 7: CHECKPOINTS */}
      {activeTab === 'CHECKPOINTS' && (
        <div className="space-y-3 font-sans">
          {checkpoints.length === 0 ? (
            <div className="p-12 text-center rounded-xl bg-[#0D111A] border border-[#1C2230]">
              <Clock className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
              <p className="text-xs text-neutral-400 font-mono">No restore checkpoints recorded yet.</p>
            </div>
          ) : (
            checkpoints.map(cp => (
              <div
                key={cp.id}
                className="p-4 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{cp.name}</span>
                    <span className="text-[10px] font-mono text-neutral-500">({cp.id})</span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">{cp.description}</p>
                  <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                    {new Date(cp.timestamp).toLocaleString()} • {Object.keys(cp.files).length} files captured
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onRollback(cp.id)}
                    className="px-3 py-1.5 rounded-lg bg-[#162030] hover:bg-blue-600 text-blue-300 hover:text-white font-semibold text-xs transition-colors flex items-center gap-1.5 border border-blue-500/30 font-sans"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore Snapshot</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
