/**
 * GODEX Phase 0 - Command Palette
 * Fast, keyboard-first command launcher (Ctrl/Cmd + K / Ctrl/Cmd + P)
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  FileCode, 
  Terminal, 
  ShieldCheck, 
  Layers, 
  GitBranch, 
  Database, 
  Settings, 
  Play, 
  RotateCcw, 
  Eye, 
  Bot, 
  Sparkles, 
  Command,
  LayoutDashboard
} from 'lucide-react';
import { CommandPaletteItem, WorkspaceViewMode } from '../types';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: Record<string, string>;
  onSelectFile: (path: string) => void;
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  onOpenCheckpoints: () => void;
  onOpenMemory: () => void;
  onOpenModelSettings: () => void;
  onOpenTemplates: () => void;
  onOpenImportProject?: () => void;
  onRunVerification: () => void;
  onToggleTerminal: () => void;
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  files,
  onSelectFile,
  onSelectWorkspaceView,
  onOpenCheckpoints,
  onOpenMemory,
  onOpenModelSettings,
  onOpenTemplates,
  onOpenImportProject,
  onRunVerification,
  onToggleTerminal
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const defaultCommands: CommandPaletteItem[] = [
    {
      id: 'view-mission-control',
      title: 'Open Mission Control Center',
      subtitle: 'Manage autonomous engineering missions, DAG task graphs, and verification',
      category: 'Navigation',
      shortcut: '⌘ 0',
      icon: 'bot',
      action: () => { onSelectWorkspaceView('mission-control'); onClose(); }
    },
    {
      id: 'view-dashboard',
      title: 'Open Project Dashboard',
      subtitle: 'View system health, metrics, and project hub',
      category: 'Navigation',
      shortcut: '⌘ 1',
      icon: 'dashboard',
      action: () => { onSelectWorkspaceView('dashboard'); onClose(); }
    },
    {
      id: 'view-editor',
      title: 'Open Code Editor',
      subtitle: 'Inspect and edit workspace source code',
      category: 'Workspace',
      shortcut: '⌘ 2',
      icon: 'editor',
      action: () => { onSelectWorkspaceView('editor'); onClose(); }
    },
    {
      id: 'view-preview',
      title: 'Open Live Sandbox Preview',
      subtitle: 'View reactive live execution sandbox',
      category: 'Workspace',
      shortcut: '⌘ 3',
      icon: 'preview',
      action: () => { onSelectWorkspaceView('preview'); onClose(); }
    },
    {
      id: 'view-architecture',
      title: 'Open Architecture Intelligence Graph',
      subtitle: 'Inspect dependencies, component tree, and modules',
      category: 'Intelligence',
      shortcut: '⌘ 4',
      icon: 'architecture',
      action: () => { onSelectWorkspaceView('architecture'); onClose(); }
    },
    {
      id: 'view-memory',
      title: 'Open Project Memory Vault',
      subtitle: 'Inspect architecture decisions and tech preferences',
      category: 'Intelligence',
      shortcut: '⌘ 5',
      icon: 'memory',
      action: () => { onSelectWorkspaceView('memory'); onClose(); }
    },
    {
      id: 'view-git',
      title: 'Open Git & Checkpoints Manager',
      subtitle: 'Inspect branch status and version snapshots',
      category: 'Engineering',
      shortcut: '⌘ 6',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'action-verify',
      title: 'Run 5-Pillar Verification Matrix',
      subtitle: 'Trigger AST, Lint, Build, and Browser checks',
      category: 'Engineering',
      shortcut: '⌘ Shift V',
      icon: 'verify',
      action: () => { onRunVerification(); onClose(); }
    },
    {
      id: 'action-terminal',
      title: 'Toggle Bottom Engineering Terminal',
      subtitle: 'Open or collapse the sandbox terminal and logs',
      category: 'Engineering',
      shortcut: '⌘ J',
      icon: 'terminal',
      action: () => { onToggleTerminal(); onClose(); }
    },
    {
      id: 'action-checkpoints',
      title: 'Create or Rollback Checkpoint',
      subtitle: 'Manage snapshot versions of the project workspace',
      category: 'Engineering',
      icon: 'checkpoint',
      action: () => { onOpenCheckpoints(); onClose(); }
    },
    {
      id: 'action-templates',
      title: 'Switch Project Template',
      subtitle: 'Load standard application architectures',
      category: 'Workspace',
      icon: 'template',
      action: () => { onOpenTemplates(); onClose(); }
    },
    {
      id: 'action-import-project',
      title: 'Import Project from ZIP Archive',
      subtitle: 'Extract and inspect local ZIP archive into workspace',
      category: 'Workspace',
      icon: 'template',
      action: () => { if (onOpenImportProject) onOpenImportProject(); onClose(); }
    },
    {
      id: 'action-settings',
      title: 'Model & Provider Settings',
      subtitle: 'Configure AI reasoning engines and temperature',
      category: 'Agent',
      shortcut: '⌘ ,',
      icon: 'settings',
      action: () => { onOpenModelSettings(); onClose(); }
    },
    {
      id: 'git-status',
      title: 'Git: Status',
      subtitle: 'Inspect working tree cleanliness and active branch state',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-create-branch',
      title: 'Git: Create Branch',
      subtitle: 'Create a new feature or release branch safely',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-switch-branch',
      title: 'Git: Switch Branch',
      subtitle: 'Safely switch active working branch',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-compare-branches',
      title: 'Git: Compare Branches',
      subtitle: 'Compare branches and detect AST symbol differences',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-propose-commit',
      title: 'Git: Propose Commit',
      subtitle: 'Formulate verified commit proposal with security check',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-prepare-merge',
      title: 'Git: Prepare Merge',
      subtitle: 'Analyze 3-way AST merge conflicts and breaking changes',
      category: 'Engineering',
      icon: 'git',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    },
    {
      id: 'git-release-audit',
      title: 'Git: Release Audit',
      subtitle: 'Evaluate 11-dimension production release readiness matrix',
      category: 'Engineering',
      icon: 'shield',
      action: () => { onSelectWorkspaceView('git'); onClose(); }
    }
  ];

  // Also include project files in the search
  const fileCommands: CommandPaletteItem[] = Object.keys(files).map((path) => ({
    id: `file-${path}`,
    title: path.split('/').pop() || path,
    subtitle: path,
    category: 'Workspace',
    icon: 'file',
    action: () => {
      onSelectFile(path);
      onSelectWorkspaceView('editor');
      onClose();
    }
  }));

  const allItems = [...defaultCommands, ...fileCommands];

  const filtered = allItems.filter(item => {
    if (!query.trim()) return item.category !== 'Workspace' || item.id.startsWith('view-');
    const q = query.toLowerCase();
    return item.title.toLowerCase().includes(q) || 
      (item.subtitle && item.subtitle.toLowerCase().includes(q)) ||
      item.category.toLowerCase().includes(q);
  });

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % (filtered.length || 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filtered.length) % (filtered.length || 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        filtered[selectedIndex].action();
      }
    }
  };

  const renderIcon = (icon: string) => {
    switch (icon) {
      case 'dashboard': return <LayoutDashboard className="w-4 h-4 text-indigo-400" />;
      case 'editor': return <FileCode className="w-4 h-4 text-cyan-400" />;
      case 'preview': return <Eye className="w-4 h-4 text-emerald-400" />;
      case 'architecture': return <Layers className="w-4 h-4 text-purple-400" />;
      case 'memory': return <Database className="w-4 h-4 text-amber-400" />;
      case 'git': return <GitBranch className="w-4 h-4 text-blue-400" />;
      case 'verify': return <ShieldCheck className="w-4 h-4 text-emerald-400" />;
      case 'terminal': return <Terminal className="w-4 h-4 text-cyan-400" />;
      case 'checkpoint': return <RotateCcw className="w-4 h-4 text-rose-400" />;
      case 'template': return <Sparkles className="w-4 h-4 text-indigo-400" />;
      case 'settings': return <Settings className="w-4 h-4 text-neutral-400" />;
      default: return <FileCode className="w-4 h-4 text-neutral-400" />;
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-start justify-center pt-24 px-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl bg-[#0C0F17] border border-[#222B3D] rounded-xl shadow-2xl overflow-hidden flex flex-col font-sans"
        onClick={e => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#1E2536] bg-[#0F131D]">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Type a command, filename, or search action... (e.g. 'preview', 'verify', 'App.tsx')"
            className="flex-1 bg-transparent text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none font-sans"
          />
          <div className="flex items-center gap-1.5 shrink-0 font-mono text-[10px] text-neutral-400 px-2 py-0.5 rounded bg-[#161B28] border border-[#232B3C]">
            <Command className="w-3 h-3 text-cyan-400" />
            <span>ESC to close</span>
          </div>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-[#181F2E]/60 select-none">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No matching commands or files found for "{query}".
            </div>
          ) : (
            filtered.map((item, idx) => (
              <button
                key={item.id}
                onClick={item.action}
                onMouseEnter={() => setSelectedIndex(idx)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition-colors ${
                  selectedIndex === idx
                    ? 'bg-[#151D2C] border border-[#263550] text-white'
                    : 'text-neutral-300 hover:bg-[#111622] border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-1.5 rounded-md bg-[#0A0D14] border border-[#1E2638] shrink-0">
                    {renderIcon(item.icon)}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-neutral-100 flex items-center gap-2">
                      <span className="truncate">{item.title}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#101420] text-neutral-400 border border-[#1D2536]">
                        {item.category}
                      </span>
                    </div>
                    {item.subtitle && (
                      <div className="text-[11px] text-neutral-400 truncate mt-0.5">
                        {item.subtitle}
                      </div>
                    )}
                  </div>
                </div>

                {item.shortcut && (
                  <div className="shrink-0 font-mono text-[10px] text-neutral-400 px-2 py-0.5 rounded bg-[#0E121B] border border-[#1D2536]">
                    {item.shortcut}
                  </div>
                )}
              </button>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 border-t border-[#181F2E] bg-[#090B10] flex items-center justify-between text-[10px] font-mono text-neutral-500">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>Esc Dismiss</span>
          </div>
          <div className="flex items-center gap-1 text-cyan-400">
            <Sparkles className="w-3 h-3" />
            <span>GODEX Command Engine</span>
          </div>
        </div>
      </div>
    </div>
  );
};
