import React, { useState, useEffect } from 'react';
import { Customer, SaleInvoice, FinancialTransaction } from '../types/business';
import { StorageService } from '../db/storage';
import {
  Users,
  Search,
  Plus,
  Phone,
  MessageCircle,
  Edit2,
  Trash2,
  Receipt,
  User,
  MapPin,
  Calendar,
  X,
  Camera,
  ArrowLeft,
  ChevronRight,
  Eye,
} from 'lucide-react';

interface CustomerManagementProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  onViewInvoice: (invoice: SaleInvoice) => void;
}

export const CustomerManagement: React.FC<CustomerManagementProps> = ({
  lang,
  onBack,
  onViewInvoice,
}) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Add / Edit Modal state
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [phone2, setPhone2] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [address, setAddress] = useState('');
  const [photo, setPhoto] = useState('');
  const [deleteCandidate, setDeleteCandidate] = useState<Customer | null>(null);

  const refreshCustomers = () => {
    setCustomers(StorageService.getCustomers());
  };

  useEffect(() => {
    refreshCustomers();
  }, []);

  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setName('');
    setPhone('');
    setPhone2('');
    setWhatsapp('');
    setAddress('');
    setPhoto('');
    setShowModal(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setEditingCustomer(c);
    setName(c.name);
    setPhone(c.phone);
    setPhone2(c.phone2 || '');
    setWhatsapp(c.whatsapp || '');
    setAddress(c.address || '');
    setPhoto(c.photo || '');
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      alert(lang === 'bn' ? 'কাস্টমারের নাম ও মোবাইল নম্বর পূরণ করুন' : 'Name and phone required');
      return;
    }

    if (editingCustomer) {
      StorageService.updateCustomer({
        ...editingCustomer,
        name: name.trim(),
        phone: phone.trim(),
        phone2: phone2.trim() || undefined,
        whatsapp: whatsapp.trim() || undefined,
        address: address.trim(),
        photo: photo || undefined,
      });
      if (selectedCustomer?.id === editingCustomer.id) {
        setSelectedCustomer({
          ...selectedCustomer,
          name: name.trim(),
          phone: phone.trim(),
          phone2: phone2.trim() || undefined,
          whatsapp: whatsapp.trim() || undefined,
          address: address.trim(),
          photo: photo || undefined,
        });
      }
    } else {
      StorageService.addCustomer({
        name: name.trim(),
        phone: phone.trim(),
        phone2: phone2.trim() || undefined,
        whatsapp: whatsapp.trim() || undefined,
        address: address.trim(),
        photo: photo || undefined,
      });
    }

    setShowModal(false);
    refreshCustomers();
  };

  const handleDelete = () => {
    if (deleteCandidate) {
      StorageService.deleteCustomer(deleteCandidate.id);
      if (selectedCustomer?.id === deleteCandidate.id) {
        setSelectedCustomer(null);
      }
      setDeleteCandidate(null);
      refreshCustomers();
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Filter customers
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      (c.whatsapp && c.whatsapp.includes(searchQuery)) ||
      (c.address && c.address.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Invoices for selected customer
  const customerInvoices = selectedCustomer
    ? StorageService.getInvoices().filter((inv) => inv.customerId === selectedCustomer.id)
    : [];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <span>{lang === 'bn' ? 'কাস্টমার কন্টাক্ট ও হিসাব' : 'Customer Contacts'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? `মোট ${customers.length} জন কাস্টমার রেজিস্টার্ড`
                  : `Total ${customers.length} registered customers`}
              </p>
            </div>
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'bn' ? 'নতুন কাস্টমার' : 'Add Customer'}</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 border-t border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="কাস্টমার নাম, ফোন, হোয়াটসঅ্যাপ বা ঠিকানা দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* CUSTOMER LIST (7 Cols) */}
          <div className="lg:col-span-7 space-y-3">
            {filteredCustomers.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 text-center border border-slate-200">
                <Users className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                <h4 className="font-bold text-slate-800 text-sm">কোন কাস্টমার পাওয়া যায়নি</h4>
                <p className="text-xs text-slate-500 mt-1">
                  নতুন কাস্টমার যোগ করতে উপরের বোতাম চাপুন।
                </p>
              </div>
            ) : (
              filteredCustomers.map((c) => {
                const isSelected = selectedCustomer?.id === c.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedCustomer(c)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                      isSelected
                        ? 'bg-indigo-50/50 border-indigo-300 ring-2 ring-indigo-200 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 overflow-hidden shrink-0 flex items-center justify-center font-bold text-indigo-700">
                        {c.photo ? (
                          <img src={c.photo} alt={c.name} className="w-full h-full object-cover" />
                        ) : (
                          c.name.slice(0, 1).toUpperCase()
                        )}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight">{c.name}</h4>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                          <Phone className="w-3 h-3" />
                          <span>{c.phone}</span>
                        </div>
                        {c.address && (
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">{c.address}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      {c.currentDue > 0 ? (
                        <div className="text-right">
                          <span className="text-[10px] text-amber-700 block font-bold">বাকি</span>
                          <span className="text-xs font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                            ৳{c.currentDue.toLocaleString()}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[11px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
                          পরিশোধিত
                        </span>
                      )}

                      {/* Quick Call & WA */}
                      <a
                        href={`tel:${c.phone}`}
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-blue-600 transition-colors"
                        title="Call"
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                      <a
                        href={`https://wa.me/${c.whatsapp || c.phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-emerald-600 transition-colors"
                        title="WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* CUSTOMER PROFILE & INVOICES (5 Cols) */}
          <div className="lg:col-span-5">
            {selectedCustomer ? (
              <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-md sticky top-24 space-y-4">
                {/* Profile Header */}
                <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-lg text-indigo-700">
                      {selectedCustomer.photo ? (
                        <img src={selectedCustomer.photo} alt={selectedCustomer.name} className="w-full h-full object-cover" />
                      ) : (
                        selectedCustomer.name.slice(0, 1).toUpperCase()
                      )}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-base">{selectedCustomer.name}</h3>
                      <p className="text-xs text-slate-500">{selectedCustomer.phone}</p>
                      {selectedCustomer.address && (
                        <p className="text-[11px] text-slate-400 mt-0.5">{selectedCustomer.address}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(selectedCustomer)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                      title="Edit Profile"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteCandidate(selectedCustomer)}
                      className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 cursor-pointer"
                      title="Delete Customer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Lifetime Metrics */}
                <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-2xl border border-slate-100 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">মোট ক্রয়</span>
                    <span className="font-bold text-slate-800">
                      ৳{selectedCustomer.totalPurchases.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">মোট জমা</span>
                    <span className="font-bold text-emerald-600">
                      ৳{selectedCustomer.totalPaid.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">বর্তমান বাকি</span>
                    <span className="font-black text-amber-700">
                      ৳{selectedCustomer.currentDue.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Direct Actions */}
                <div className="grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${selectedCustomer.phone}`}
                    className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>কল করুন</span>
                  </a>
                  <a
                    href={`https://wa.me/${selectedCustomer.whatsapp || selectedCustomer.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>হোয়াটসঅ্যাপ</span>
                  </a>
                </div>

                {/* Customer Invoices History */}
                <div>
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                    <span>ক্রয়কৃত চালানের তালিকা ({customerInvoices.length})</span>
                  </h4>

                  {customerInvoices.length === 0 ? (
                    <p className="text-xs text-slate-400 italic py-4 text-center">
                      এখনো কোন ইনভয়েস নেই
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                      {customerInvoices.map((inv) => (
                        <div
                          key={inv.id}
                          className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors flex items-center justify-between text-xs"
                        >
                          <div>
                            <span className="font-mono font-bold text-indigo-700 block">
                              {inv.invoiceNumber}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {inv.date} • {inv.totalQuantity} pcs
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="text-right">
                              <span className="font-bold text-slate-900 block">
                                ৳{inv.finalPayableAmount.toLocaleString()}
                              </span>
                              {inv.dueAmount > 0 && (
                                <span className="text-[10px] text-amber-700 font-bold block">
                                  বাকি: ৳{inv.dueAmount}
                                </span>
                              )}
                            </div>
                            <button
                              onClick={() => onViewInvoice(inv)}
                              className="p-1 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400 text-xs">
                <User className="w-12 h-12 mx-auto text-slate-300 mb-2 stroke-1" />
                <p>বিস্তারিত হিসাব ও চালানের তালিকা দেখতে বাম পাশ থেকে কাস্টমার নির্বাচন করুন।</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ADD / EDIT CUSTOMER MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-indigo-600" />
                <span>{editingCustomer ? 'কাস্টমার তথ্য সম্পাদনা' : 'নতুন কাস্টমার নিবন্ধন'}</span>
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  কাস্টমারের নাম *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: মোঃ আল-আমিন"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  মোবাইল নম্বর ১ *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    মোবাইল নম্বর ২ (ঐচ্ছিক)
                  </label>
                  <input
                    type="tel"
                    value={phone2}
                    onChange={(e) => setPhone2(e.target.value)}
                    placeholder="018xxxxxxxx"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    হোয়াটসঅ্যাপ নম্বর
                  </label>
                  <input
                    type="tel"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ঠিকানা
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="বালাগঞ্জ বাজার, সিলেট"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-500/20"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 text-center border border-slate-100">
            <h3 className="font-bold text-slate-900 text-base mb-2">
              কাস্টমার রেকর্ড মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-slate-500 mb-4">{deleteCandidate.name} ({deleteCandidate.phone})</p>
            <p className="text-[11px] text-slate-400 mb-5">
              (কাস্টমারের পূর্বের সমস্ত বিক্রয় চালান ও হিসাব ডাটাবেজে অক্ষত থাকবে)
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-bold text-xs"
              >
                মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
