import React, { useState } from 'react';
import {
  Sparkles,
  Download,
  Copy,
  Check,
  Maximize2,
  RefreshCw,
  Image as ImageIcon,
  Wand2,
  Sliders,
  Layers,
  Send,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { GeneratedImage } from '../types/chat';

interface ImageStudioProps {
  onSendToChat?: (image: GeneratedImage) => void;
}

export const ImageStudio: React.FC<ImageStudioProps> = ({ onSendToChat }) => {
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '21:9'>('1:1');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [style, setStyle] = useState('Photorealistic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<GeneratedImage[]>([]);
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const stylePresets = [
    { id: 'Photorealistic', labelAr: 'واقعي فوتوغرافي 📸', desc: 'إضاءة طبيعية وتفاصيل سينمائية فائقة' },
    { id: 'Cyberpunk', labelAr: 'سايبربانك مستقبلي 🏙️', desc: 'أضواء نيون وظلال تكنولوجية داكنة' },
    { id: 'Anime', labelAr: 'أنمي رقمي ياباني 🎨', desc: 'رسوم كارتونية ملونة بأسلوب استوديو جيبلي' },
    { id: '3D Render', labelAr: 'رندر ثلاثي الأبعاد 🧊', desc: 'محاكاة بصرية محرك Unreal Engine' },
    { id: 'Oil Painting', labelAr: 'لوحة زيتية كلاسيكية 🖌️', desc: 'ضربات فرشاة فنية وملمس لوحات المتاحف' },
    { id: 'Fantasy Art', labelAr: 'خيال أسطوري 🐉', desc: 'أجواء سحرية وعوالم خيالية مذهلة' },
    { id: 'Minimalist Vector', labelAr: 'تصميم تبسيطي وشعار ✒️', desc: 'أشكال نظيفة وألوان متناسقة' },
  ];

  const aspectRatios = [
    { id: '1:1', label: '1:1 (مربع)', icon: 'w-6 h-6 border-2 border-current rounded' },
    { id: '16:9', label: '16:9 (عريض / يوتيوب)', icon: 'w-8 h-4.5 border-2 border-current rounded' },
    { id: '9:16', label: '9:16 (عمودي / ريلز)', icon: 'w-4.5 h-8 border-2 border-current rounded' },
    { id: '4:3', label: '4:3 (شاشة كلاسيكية)', icon: 'w-7 h-5 border-2 border-current rounded' },
    { id: '3:4', label: '3:4 (بورتريه)', icon: 'w-5 h-7 border-2 border-current rounded' },
    { id: '21:9', label: '21:9 (سينمائي فائق العرض)', icon: 'w-9 h-4 border-2 border-current rounded' },
  ] as const;

  const quickIdeas = [
    'صقر عربي ذهبي يحلق فوق مدينة دبي المستقبلية مع أبراج نيون متلألئة في الليل',
    'واحة صحراوية خضراء سحرية تعكس نجوماً متلألئة في السماء بأسلوب تصوير فلكي فائق',
    'روبوت ذكاء اصطناعي أنيق يقرأ كتاباً قديماً في مكتبة خشبية دافئة بإضاءة سينمائية',
    'سيارة رياضية كهربائية تسبق العاصفة في طريق جبلي وعر بتفاصيل بدقة 8k',
  ];

  const handleEnhancePrompt = () => {
    if (!prompt.trim()) return;
    const enhancements = [
      'masterpiece, 8k resolution, photorealistic cinematic lighting, ultra-detailed textures, volumetric rays, award winning photography',
      'intricate details, hyperrealistic rendering, dramatic shadows, octane render, vivid colors',
      'concept art, highly detailed digital painting, trending on ArtStation, dynamic composition',
    ];
    const picked = enhancements[Math.floor(Math.random() * enhancements.length)];
    setPrompt(prev => `${prev.trim()}, ${picked}`);
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          imageSize,
          style,
          negativePrompt: negativePrompt.trim(),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'فشل في توليد الصورة من خادم الذكاء الاصطناعي.');
      }

      const data = await response.json();
      if (data.images && data.images.length > 0) {
        const newImages: GeneratedImage[] = data.images;
        setHistory(prev => [...newImages, ...prev]);
        setSelectedImage(newImages[0]);
      } else {
        throw new Error('لم يرجع النموذج أية نتائج، حاول صياغة الوصف بطريقة أخرى.');
      }
    } catch (err: any) {
      console.error('Image generation error:', err);
      setError(err.message || 'حدث خطأ أثناء الاتصال بنموذج توليد الصور.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (img: GeneratedImage) => {
    const link = document.createElement('a');
    link.href = img.url;
    link.download = `onyxmind-image-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyLink = (img: GeneratedImage, index: number) => {
    navigator.clipboard.writeText(img.url);
    setCopiedId(`img-${index}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-300">
      
      {/* Studio Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-800 pb-6">
        <div>
          <div className="flex items-center gap-2.5 text-cyan-400 mb-1">
            <Sparkles className="w-5 h-5" />
            <span className="text-xs font-semibold uppercase tracking-wider">Onyx Imagine Studio</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-neutral-100">
            استوديو تصميم وتوليد الصور بالذكاء الاصطناعي
          </h1>
          <p className="text-sm text-neutral-400 mt-1">
            حوّل أفكارك وخيالك إلى تصاميم بصرية فائقة الدقة والجودة بدعم نماذج التوليد الحديثة
          </p>
        </div>

        {/* Resolution selector */}
        <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 p-1.5 rounded-xl self-start md:self-auto">
          <span className="text-xs text-neutral-400 px-2 font-medium">الدقة:</span>
          {(['1K', '2K', '4K'] as const).map((size) => (
            <button
              key={size}
              onClick={() => setImageSize(size)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                imageSize === size
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Controls & Prompt */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Prompt Box */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
                <span>وصف الصورة (Prompt)</span>
                <span className="text-xs text-cyan-400 font-normal">يدعم العربية والإنجليزية</span>
              </label>
              <button
                onClick={handleEnhancePrompt}
                disabled={!prompt.trim() || isGenerating}
                className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 disabled:opacity-40 transition-colors"
                title="تحسين الوصف وإضافة تفاصيل جمالية تلقائياً"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>تحسين الوصف</span>
              </button>
            </div>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="اكتب وصفاً مفصلاً للصورة، مثلاً: صقر عربي يحلق فوق صحراء ساحرة في وقت الغروب مع إضاءة درامية..."
              rows={4}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
            />

            {/* Quick Inspiration Prompts */}
            <div className="space-y-2">
              <span className="text-xs text-neutral-400 font-medium">أفكار سريعة للإلهام:</span>
              <div className="flex flex-wrap gap-2">
                {quickIdeas.map((idea, i) => (
                  <button
                    key={i}
                    onClick={() => setPrompt(idea)}
                    className="text-xs bg-neutral-950/60 hover:bg-neutral-800 text-neutral-300 border border-neutral-800/80 px-3 py-1.5 rounded-lg text-right truncate max-w-full transition-colors"
                  >
                    {idea.slice(0, 42)}...
                  </button>
                ))}
              </div>
            </div>

            {/* Negative Prompt (Optional) */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                عناصر مستبعدة من الصورة (Negative Prompt - اختياري):
              </label>
              <input
                type="text"
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                placeholder="تشويش، نص غير مفهوم، جودة منخفضة، عيوب بصرية..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Aspect Ratio Selector */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 space-y-3">
            <label className="text-sm font-semibold text-neutral-200 block">
              أبعاد ونسبة الصورة (Aspect Ratio)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {aspectRatios.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setAspectRatio(item.id)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                    aspectRatio === item.id
                      ? 'border-cyan-500 bg-cyan-950/30 text-cyan-300'
                      : 'border-neutral-800 bg-neutral-950/50 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                  }`}
                >
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Style Presets */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 space-y-3">
            <label className="text-sm font-semibold text-neutral-200 block">
              الأسلوب الفني (Artistic Style)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {stylePresets.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={`flex flex-col items-start p-3 rounded-xl border text-right transition-all ${
                    style === s.id
                      ? 'border-cyan-500 bg-cyan-950/30 text-neutral-100'
                      : 'border-neutral-800 bg-neutral-950/50 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                  }`}
                >
                  <span className="text-xs font-semibold text-neutral-200">{s.labelAr}</span>
                  <span className="text-[11px] text-neutral-400 mt-0.5">{s.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-4 bg-rose-950/40 border border-rose-800/80 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-base shadow-lg shadow-cyan-600/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>جاري إبداع وتوليد الصورة بدقة عالية...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>توليد الصورة الآن ({imageSize})</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Preview & History */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 min-h-[500px] flex flex-col">
            <h3 className="text-sm font-semibold text-neutral-200 mb-4">
              معاينة العمل المولد
            </h3>

            {isGenerating ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full border-2 border-cyan-500 border-t-transparent animate-spin" />
                  <Sparkles className="w-8 h-8 text-cyan-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-neutral-200">الذكاء الاصطناعي يرسم لوحتك...</p>
                  <p className="text-xs text-neutral-400">يتم تطبيق الأبعاد ({aspectRatio}) والدقة ({imageSize})</p>
                </div>
              </div>
            ) : selectedImage ? (
              <div className="flex-1 flex flex-col space-y-4">
                <div className="relative group rounded-xl overflow-hidden bg-neutral-950 flex items-center justify-center max-h-[480px]">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.prompt}
                    className="max-h-[480px] w-auto object-contain rounded-xl"
                  />

                  {/* Overlay Action Bar */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                    <button
                      onClick={() => handleDownload(selectedImage)}
                      className="p-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl shadow-lg transition-colors"
                      title="تحميل الصورة"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    {onSendToChat && (
                      <button
                        onClick={() => onSendToChat(selectedImage)}
                        className="p-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl shadow-lg transition-colors flex items-center gap-1.5 text-xs font-medium"
                        title="إرسال إلى المحادثة للتحليل"
                      >
                        <Send className="w-4 h-4" />
                        <span>إرسال للمحادثة</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Prompt Info */}
                <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-xs text-neutral-300 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-medium">الوصف المستخدم:</span>
                    <button
                      onClick={() => handleDownload(selectedImage)}
                      className="text-xs flex items-center gap-1 text-neutral-400 hover:text-white"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>حفظ الصورة</span>
                    </button>
                  </div>
                  <p className="leading-relaxed">{selectedImage.prompt}</p>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3 text-neutral-500">
                <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <ImageIcon className="w-10 h-10 text-neutral-600" />
                </div>
                <p className="text-sm font-medium text-neutral-400">لا توجد صور مولدة بعد</p>
                <p className="text-xs max-w-xs">
                  أدخل وصف الصورة واضغط على زر التوليد لمشاهدة النتيجة الفورية هنا
                </p>
              </div>
            )}

            {/* Generated History Thumbnails */}
            {history.length > 0 && (
              <div className="mt-6 pt-4 border-t border-neutral-800 space-y-2">
                <span className="text-xs font-medium text-neutral-400">معرض الجلسة الحالية ({history.length}):</span>
                <div className="flex gap-2.5 overflow-x-auto pb-2">
                  {history.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(img)}
                      className={`relative shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage?.url === img.url
                          ? 'border-cyan-500 ring-2 ring-cyan-500/30'
                          : 'border-neutral-800 hover:border-neutral-600'
                      }`}
                    >
                      <img src={img.url} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
};
