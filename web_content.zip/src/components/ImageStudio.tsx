import React, { useState } from "react";
import {
  Sparkles,
  Download,
  ArrowRight,
  RefreshCw,
  Search,
  Check,
  Maximize2,
} from "lucide-react";
import { GeneratedImageItem } from "../types";

interface ImageStudioProps {
  onSelectForEdit: (imageUrl: string) => void;
  savedImages: GeneratedImageItem[];
  onSaveImage: (item: GeneratedImageItem) => void;
}

const PRESET_PROMPTS = [
  "মহাদেবের ছবি",
  "রবীন্দ্রনাথ ঠাকুর",
  "তাজমহল",
  "রয়েল বেঙ্গল টাইগার",
  "মা দুর্গা",
  "হিমালয় পর্বত ও সূর্যোদয়",
  "একটি সুন্দর বিড়াল",
];

const STYLES = [
  { id: "photorealistic", label: "ফটোরিয়েলিস্টিক" },
  { id: "artistic", label: "ডিজিটাল আর্ট" },
  { id: "futuristic", label: "ফিউচারিস্টিক" },
  { id: "cyberpunk", label: "সাইবারপাঙ্ক" },
  { id: "watercolor", label: "জলরং পেইন্টিং" },
];

export const ImageStudio: React.FC<ImageStudioProps> = ({
  onSelectForEdit,
  savedImages,
  onSaveImage,
}) => {
  const [prompt, setPrompt] = useState("");
  const [selectedStyle, setSelectedStyle] = useState("photorealistic");
  const [aspectRatio, setAspectRatio] = useState<"1:1" | "16:9" | "9:16">("1:1");
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState("");
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const [currentImage, setCurrentImage] = useState<GeneratedImageItem | null>(() => {
    return (
      savedImages[0] || {
        id: "default-mahadev",
        prompt: "মহাদেবের ছবি",
        title: "মহাদেব (Lord Shiva)",
        url: "https://upload.wikimedia.org/wikipedia/commons/5/52/Bangalore_Shiva.jpg",
        timestamp: "এখনই সক্রিয়",
        style: "ফটোরিয়েলিস্টিক",
        tags: ["মহাদেব", "শিব", "Lord Shiva", "আধ্যাত্মিক"],
        colors: { primary: "#0ea5e9", secondary: "#6366f1" },
        alternativeImages: [
          {
            title: "মহাদেব - Bangalore Shiva Statue",
            url: "https://upload.wikimedia.org/wikipedia/commons/5/52/Bangalore_Shiva.jpg",
          },
        ],
      }
    );
  });

  const getProxiedUrl = (url: string) => {
    if (!url) return "";
    // If it is already a data URL or local URL, use as is
    if (url.startsWith("data:") || url.startsWith("/api/")) return url;
    return `/api/image-proxy?url=${encodeURIComponent(url)}`;
  };

  const handleGenerate = async (presetText?: string) => {
    const textToUse = (presetText || prompt).trim();
    if (!textToUse || loading) return;

    if (presetText) {
      setPrompt(presetText);
    }

    setLoading(true);
    setLoadingText(`"${textToUse}" এর সঠিক ছবি খোঁজা ও তৈরি করা হচ্ছে...`);
    setSelectedImageIndex(0);

    try {
      const res = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToUse,
          style: selectedStyle,
          aspectRatio,
        }),
      });

      const data = await res.json();
      const altImages = data.alternativeImages || [];
      const primaryUrl = data.imageUrl || (altImages[0]?.url) || "";

      const newItem: GeneratedImageItem = {
        id: "img-" + Date.now(),
        prompt: textToUse,
        title: data.title || textToUse,
        url: primaryUrl,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        style: selectedStyle,
        tags: data.tags || ["ছবি", textToUse],
        colors: data.colors,
        alternativeImages: altImages,
      };

      setCurrentImage(newItem);
      onSaveImage(newItem);
    } catch (err) {
      console.error("Image generation error:", err);
      // Construct direct fallback to high quality AI visual
      const seed = Math.floor(Math.random() * 1000000);
      const directAiUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
        textToUse + ", high quality realistic masterpiece"
      )}?width=1024&height=1024&seed=${seed}&nologo=true`;

      const fallbackItem: GeneratedImageItem = {
        id: "img-" + Date.now(),
        prompt: textToUse,
        title: textToUse,
        url: directAiUrl,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        style: selectedStyle,
        alternativeImages: [{ title: textToUse, url: directAiUrl }],
      };
      setCurrentImage(fallbackItem);
      onSaveImage(fallbackItem);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAlternative = (imgUrl: string, idx: number) => {
    setSelectedImageIndex(idx);
    if (currentImage) {
      const updated = { ...currentImage, url: imgUrl };
      setCurrentImage(updated);
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full px-3 sm:px-4 py-4 pb-24">
      {/* Search Header Banner */}
      <div className="mb-4 text-center sm:text-left">
        <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight flex items-center justify-center sm:justify-start gap-2">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <span>স্মার্ট ছবি সার্চ ও জেনারেটর</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          এখানে যে নাম লিখবেন — সাথে সাথে তার আসল ও নির্ভুল ছবি চলে আসবে।
        </p>
      </div>

      {/* Preset Fast Chips */}
      <div className="mb-4">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
          <span className="text-xs text-slate-400 font-semibold shrink-0 mr-1">
            পপুলার নাম:
          </span>
          {PRESET_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleGenerate(p)}
              className="text-xs px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-indigo-600/30 border border-slate-700/60 hover:border-indigo-400/50 text-slate-300 hover:text-white transition-all shrink-0 flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Search className="w-3 h-3 text-cyan-400" />
              <span>{p}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Search Input & Generation Box */}
      <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 shadow-xl mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleGenerate();
              }}
              placeholder="এখানে যে নাম লিখবেন সেই ছবি আসবে (যেমন: মহাদেবের ছবি, রবীন্দ্রনাথ ঠাকুর)..."
              className="w-full glass-input rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          </div>

          <button
            onClick={() => handleGenerate()}
            disabled={!prompt.trim() || loading}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-cyan-600 to-indigo-600 hover:from-indigo-500 hover:to-cyan-500 disabled:opacity-50 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all shrink-0 active:scale-95"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>ছবি আসছে...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>ছবি আনুন</span>
              </>
            )}
          </button>
        </div>

        {/* Style & Aspect Ratio Selection */}
        <div className="mt-4 pt-3.5 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-slate-400 font-medium mr-1">স্টাইল:</span>
            {STYLES.map((st) => (
              <button
                key={st.id}
                onClick={() => setSelectedStyle(st.id)}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedStyle === st.id
                    ? "bg-indigo-600 text-white shadow"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium mr-1">অনুপাত:</span>
            {(["1:1", "16:9", "9:16"] as const).map((ratio) => (
              <button
                key={ratio}
                onClick={() => setAspectRatio(ratio)}
                className={`px-2.5 py-1 rounded-lg font-mono font-medium transition-colors ${
                  aspectRatio === ratio
                    ? "bg-cyan-600 text-white shadow"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading state visual indicator */}
      {loading && (
        <div className="glass-panel rounded-2xl p-8 text-center border border-cyan-500/30 shadow-xl mb-6 animate-pulse">
          <RefreshCw className="w-10 h-10 text-cyan-400 animate-spin mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">
            ছবি প্রস্তুত করা হচ্ছে
          </h3>
          <p className="text-xs text-slate-300">{loadingText}</p>
        </div>
      )}

      {/* Displayed Image Showcase */}
      {currentImage && !loading && (
        <div className="glass-panel-elevated rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
          {/* Main Visual Frame */}
          <div className="relative w-full bg-slate-950/80 flex items-center justify-center min-h-[320px] max-h-[560px] overflow-hidden">
            <img
              src={currentImage.url}
              alt={currentImage.prompt}
              referrerPolicy="no-referrer"
              className="w-full h-full max-h-[560px] object-contain transition-all duration-300"
              onError={(e) => {
                // If direct link fails, try via internal proxy
                const currentSrc = e.currentTarget.src;
                if (!currentSrc.includes("/api/image-proxy") && currentImage.url.startsWith("http")) {
                  e.currentTarget.src = getProxiedUrl(currentImage.url);
                } else if (
                  currentImage.alternativeImages &&
                  currentImage.alternativeImages.length > 1
                ) {
                  // Fall back to next available alternative image
                  const nextImg =
                    currentImage.alternativeImages.find(
                      (a) => a.url !== currentImage.url
                    )?.url || "";
                  if (nextImg) {
                    e.currentTarget.src = nextImg;
                  }
                }
              }}
            />

            {/* Quick badge */}
            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-semibold text-cyan-300 shadow">
              Ranabir Smart Visual
            </div>
          </div>

          {/* Alternative Variations / Gallery Picker (if multiple found) */}
          {currentImage.alternativeImages && currentImage.alternativeImages.length > 1 && (
            <div className="p-3 bg-slate-950/50 border-t border-white/5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  আরো সম্পর্কিত ছবি (Click to switch):
                </span>
                <span className="text-[10px] text-slate-400">
                  {currentImage.alternativeImages.length} টি ছবি পাওয়া গেছে
                </span>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {currentImage.alternativeImages.map((alt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectAlternative(alt.url, idx)}
                    className={`relative w-20 h-16 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                      currentImage.url === alt.url
                        ? "border-cyan-400 scale-105 shadow-md shadow-cyan-500/30 ring-2 ring-cyan-400/30"
                        : "border-white/10 opacity-70 hover:opacity-100 hover:border-indigo-400"
                    }`}
                    title={alt.title}
                  >
                    <img
                      src={alt.thumbnail || alt.url}
                      alt={alt.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const proxied = getProxiedUrl(alt.url);
                        if (e.currentTarget.src !== proxied) {
                          e.currentTarget.src = proxied;
                        }
                      }}
                    />
                    {currentImage.url === alt.url && (
                      <div className="absolute inset-0 bg-cyan-600/20 flex items-center justify-center">
                        <Check className="w-4 h-4 text-white drop-shadow-md" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Meta & Download Action Controls */}
          <div className="p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/80 border-t border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{currentImage.title}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5 max-w-lg truncate">
                প্রম্পট: &quot;{currentImage.prompt}&quot;
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <a
                href={currentImage.url}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-white/10"
                title="ফুল ভিউ খুলুন (Open Full Resolution)"
              >
                <Maximize2 className="w-4 h-4" />
              </a>

              <a
                href={currentImage.url}
                download={`${currentImage.prompt || "image"}.jpg`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-initial px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-white/10 active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ডাউনলোড</span>
              </a>

              <button
                onClick={() => {
                  if (currentImage.url) {
                    onSelectForEdit(currentImage.url);
                  }
                }}
                className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-600/30 active:scale-95"
              >
                <span>ভিডিও ও রিল বানান</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
