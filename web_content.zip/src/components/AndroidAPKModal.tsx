import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  CheckCircle2,
  Copy,
  ExternalLink,
  X,
  Sparkles,
  QrCode,
  ShieldCheck,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { sound } from '../utils/audio';

interface AndroidAPKModalProps {
  onClose: () => void;
  isSimulatorActive: boolean;
  onToggleSimulator: () => void;
}

export const AndroidAPKModal: React.FC<AndroidAPKModalProps> = ({
  onClose,
  isSimulatorActive,
  onToggleSimulator,
}) => {
  const { isInstallable, isInstalled, isAndroid, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  const handleInstallClick = async () => {
    sound.play('station');
    const ok = await install();
    if (ok) {
      setInstallSuccess(true);
      sound.play('victory');
    }
  };

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl).then(() => {
        setCopied(true);
        sound.play('capsule');
        setTimeout(() => setCopied(false), 2500);
      });
    }
  };

  // PWABuilder direct link for generating a signed .apk file
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?url=${encodeURIComponent(
    currentUrl
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#030615e6] backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl bg-gradient-to-b from-[#131f49] to-[#070d24] border border-[#5d82db] shadow-[0_0_50px_rgba(76,245,255,0.25)] text-white overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#293d75]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#094030] border border-[#38ef7d66] flex items-center justify-center text-2xl shadow-sm">
              🤖
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[#4cf5ff] flex items-center gap-2">
                <span>تثبيت اللعبة بصيغة أندرويد (APK)</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-[#0e3b2e] text-[#38ef7d] border border-[#38ef7d80]">
                  Android APK
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                طرق تثبيت اللعبة وتشغيلها كتطبيق حقيقي على هواتف أندرويد
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-[#14224e] hover:bg-[#1d316e] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-right">
          {/* Method 1: Direct WebAPK Install on Android Device */}
          <div className="rounded-2xl p-4 bg-[#0d183d] border border-[#2b3e75] hover:border-[#4cf5ff60] transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#38ef7d] flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-[#38ef7d]" /> الطريقة الأسرع والأسهل
              </span>
              <span className="text-xs text-[#ffe18a] font-bold">1. تثبيت WebAPK المباشر</span>
            </div>

            <h3 className="text-base font-extrabold text-white mb-1.5">
              تثبيت مباشر كتطبيق نظام في أندرويد
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              نظام أندرويد يقوم تلقائياً بإنشاء حزمة <strong>WebAPK</strong> معتمدة ومثبتة في درج
              تطبيقات الهاتف مع أيقونة اللعبة، وتعمل بملء الشاشة وبدون إنترنت (Offline).
            </p>

            {isInstalled || installSuccess ? (
              <div className="p-3 rounded-xl bg-[#094030] border border-[#38ef7d] text-[#b4ffd8] text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#38ef7d]" />
                <span>تم تثبيت التطبيق بنجاح على هذا الجهاز!</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={handleInstallClick}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#38ef7d] to-[#11998e] text-[#061f15] font-black text-sm shadow-md hover:opacity-95 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت اللعبة على الأندرويد الآن (APK)</span>
              </button>
            ) : isAndroid ? (
              <div className="p-3 rounded-xl bg-[#14234f] border border-[#38539c] text-xs text-slate-300 leading-relaxed">
                <strong className="text-[#ffe18a] block mb-1">خطوات التثبيت من متصفح الهاتف:</strong>
                1. اضغط على القائمة (الثلاث نقاط ⋮) في متصفح Chrome أو متصفح جهازك.<br />
                2. اختر <strong className="text-[#4cf5ff]">«تثبيت التطبيق» (Install App)</strong> أو{' '}
                <strong className="text-[#4cf5ff]">«إضافة إلى الشاشة الرئيسية»</strong>.<br />
                3. سيقوم أندرويد بتوليد حزمة APK الرسمية وتثبيتها بجهازك فوراً.
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-[#14234f] border border-[#38539c] text-xs text-slate-300 leading-relaxed">
                إذا كنت تتصفح من الكمبيوتر، افتح هذا الرابط من متصفح Chrome على هاتف أندرويد،
                وستظهر لك نافذة التثبيت كملف وتطبيق APK تلقائياً.
              </div>
            )}
          </div>

          {/* Method 2: Standalone .APK File Generation via PWABuilder */}
          <div className="rounded-2xl p-4 bg-[#0d183d] border border-[#2b3e75] hover:border-[#4cf5ff60] transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#ffe18a]">أداة مايكروسوفت الرسمية</span>
              <span className="text-xs text-[#ffe18a] font-bold">2. تنزيل ملف .APK قابل للتثبيت</span>
            </div>

            <h3 className="text-base font-extrabold text-white mb-1.5">
              توليد ملف حزمة أندرويد (.APK Package)
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              هل تريد ملف <code className="text-[#4cf5ff] font-mono">.apk</code> خام لتنزيله وتثبيته يدوياً (Sideload) أو رفعه على متجر Google Play؟ تم إعداد ملفات الـ Manifest والأيقونات لتكون جاهزة 100% للتوليد.
            </p>

            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 rounded-xl bg-[#1a2d66] hover:bg-[#233c87] border border-[#4cf5ff80] text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <span>فتح PWABuilder لتنزيل ملف الـ APK</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#4cf5ff]" />
            </a>
          </div>

          {/* Method 3: Share/Copy Link to Android Phone */}
          <div className="rounded-2xl p-4 bg-[#0d183d] border border-[#2b3e75]">
            <h3 className="text-sm font-bold text-[#ffe18a] mb-2 flex items-center gap-1.5">
              <QrCode className="w-4 h-4 text-[#4cf5ff]" />
              <span>مشاركة الرابط مع هاتفك الأندرويد:</span>
            </h3>

            <div className="flex items-center gap-2" dir="ltr">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="flex-1 bg-[#091129] border border-[#2d417c] rounded-xl px-3 py-2 text-xs text-slate-300 font-mono focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className="px-3.5 py-2 rounded-xl bg-[#4cf5ff] text-[#071129] font-bold text-xs flex items-center gap-1 cursor-pointer hover:opacity-90 active:scale-95 transition-all shrink-0"
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Android Simulator Frame Toggle for Desktop */}
          <div className="p-3.5 rounded-2xl bg-[#0b1434] border border-[#ffe18a4d] flex items-center justify-between">
            <div className="text-right">
              <div className="font-bold text-xs text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-[#4cf5ff]" />
                <span>محاكي إطار هاتف أندرويد (Android Frame Simulator)</span>
              </div>
              <div className="text-[11px] text-slate-300 mt-0.5">
                تجربة اللعبة داخل أبعاد شاشة هاتف الأندرويد المخصصة
              </div>
            </div>

            <button
              onClick={onToggleSimulator}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isSimulatorActive
                  ? 'bg-[#38ef7d] text-[#061f15]'
                  : 'bg-[#182755] text-slate-300 hover:text-white border border-[#3b5293]'
              }`}
            >
              {isSimulatorActive ? 'مفعّل ✓' : 'تفعيل الإطار'}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#293d75] bg-[#0a1230] flex items-center justify-between">
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#ffe18a]" />
            اللعبة تدعم نظام Android 8.0+ و Chrome تلقائياً
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#071129] font-bold text-sm cursor-pointer hover:opacity-95"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
