import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Billboard, Line } from "@react-three/drei";
import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import {
  ACCENT,
  BELT_COLOR,
  BODIES,
  BODY_MAP,
  MOON_COLOR,
  ORBIT_LINE,
  SCENE_BG,
  SUN_LIGHT,
  orbitOmega,
  type BodyFacts,
  type BodyId,
} from "@/lib/solar/data";
import { useSolar } from "@/lib/solar/store";
import { getSolarTextures, type SolarTextures } from "@/components/solar/textures";

const HOME = { r: 62, theta: 0.58, phi: 1.08 };
const TRAIL = 200;
const BELT_COUNT = 380;

const clock = { t: 0 };

const worldPos: Record<BodyId, THREE.Vector3> = {
  sun: new THREE.Vector3(),
  mercury: new THREE.Vector3(),
  venus: new THREE.Vector3(),
  earth: new THREE.Vector3(),
  mars: new THREE.Vector3(),
  jupiter: new THREE.Vector3(),
  saturn: new THREE.Vector3(),
  uranus: new THREE.Vector3(),
  neptune: new THREE.Vector3(),
};

const moonPos = new THREE.Vector3();
const ORIGIN = new THREE.Vector3();

function placeOnOrbit(
  angle: number,
  radius: number,
  inclination: number,
  target: THREE.Vector3,
) {
  const x = Math.cos(angle) * radius;
  const z = Math.sin(angle) * radius;
  target.set(x, -z * Math.sin(inclination), z * Math.cos(inclination));
  return target;
}

function sphericalToVec(r: number, theta: number, phi: number, target: THREE.Vector3) {
  const sinPhi = Math.sin(phi);
  target.set(r * sinPhi * Math.sin(theta), r * Math.cos(phi), r * sinPhi * Math.cos(theta));
  return target;
}

function lerpAngle(a: number, b: number, t: number) {
  const delta = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + delta * t;
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

const SUN_VERT = /* glsl */ `
  varying vec3 vPos;
  varying vec3 vNormalView;
  varying vec3 vView;
  void main() {
    vPos = position;
    vec4 world = modelMatrix * vec4(position, 1.0);
    vec4 mv = viewMatrix * world;
    vView = -mv.xyz;
    vNormalView = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * mv;
  }
`;

const SUN_FRAG = /* glsl */ `
  varying vec3 vPos;
  varying vec3 vNormalView;
  varying vec3 vView;
  uniform float uTime;
  void main() {
    vec3 n = normalize(vPos);
    float bands = sin(n.y * 9.0 + uTime * 0.55) * 0.5 + 0.5;
    float cells = sin(n.x * 7.0 + uTime * 0.35) * sin(n.z * 6.0 - uTime * 0.28);
    float hot = clamp(0.42 + bands * 0.38 + cells * 0.18, 0.0, 1.0);
    vec3 deep = vec3(0.72, 0.28, 0.08);
    vec3 mid = vec3(1.0, 0.62, 0.24);
    vec3 high = vec3(1.0, 0.94, 0.82);
    vec3 col = mix(deep, mid, hot);
    col = mix(col, high, smoothstep(0.62, 1.0, hot));
    float fres = pow(1.0 - max(dot(normalize(vNormalView), normalize(vView)), 0.0), 2.4);
    col += vec3(1.0, 0.78, 0.5) * fres * 0.28;
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const ATMOS_VERT = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorld;
  void main() {
    vNormal = normalize(normalMatrix * normal);
    vec4 world = modelMatrix * vec4(position, 1.0);
    vWorld = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;

const ATMOS_FRAG = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorld;
  uniform vec3 uColor;
  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorld);
    float rim = pow(1.0 - max(dot(normalize(vNormal), viewDir), 0.0), 2.6);
    gl_FragColor = vec4(uColor, rim * 0.42);
    #include <colorspace_fragment>
  }
`;

const RING_VERT = /* glsl */ `
  varying vec3 vLocal;
  void main() {
    vLocal = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const RING_FRAG = /* glsl */ `
  varying vec3 vLocal;
  uniform float uInner;
  uniform float uOuter;
  uniform vec3 uColor;
  uniform float uStrength;
  void main() {
    float r = length(vLocal.xy);
    float t = clamp((r - uInner) / (uOuter - uInner), 0.0, 1.0);
    float bands = 0.35 + 0.65 * smoothstep(0.2, 0.8, abs(sin(t * 34.0)));
    float gap = smoothstep(0.018, 0.0, abs(t - 0.46));
    float edge = smoothstep(0.0, 0.04, t) * smoothstep(1.0, 0.9, t);
    float alpha = bands * (1.0 - gap * 0.85) * edge * uStrength;
    if (alpha < 0.03) discard;
    vec3 col = mix(uColor * 0.72, uColor, bands);
    gl_FragColor = vec4(col, alpha);
    #include <colorspace_fragment>
  }
`;

const STAR_VERT = /* glsl */ `
  attribute float size;
  varying vec3 vColor;
  uniform float uTime;
  void main() {
    float twinkle = 0.78 + 0.22 * sin(uTime * 0.7 + position.x * 0.15);
    vColor = color * twinkle;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = size * (170.0 / max(1.0, -mv.z));
    gl_Position = projectionMatrix * mv;
  }
`;

const STAR_FRAG = /* glsl */ `
  varying vec3 vColor;
  void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    float alpha = smoothstep(0.5, 0.12, d);
    if (alpha < 0.02) discard;
    gl_FragColor = vec4(vColor, alpha);
    #include <colorspace_fragment>
  }
`;

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function Simulator() {
  useFrame((_, delta) => {
    const step = Math.min(delta, 0.1);
    const { paused, speed } = useSolar.getState();
    if (!paused) clock.t += step * speed;
  }, -1);
  return null;
}

function Starfield() {
  const geometry = useMemo(() => {
    const count = 1500;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const rnd = mulberry32(11);
    for (let i = 0; i < count; i += 1) {
      const radius = 80 + rnd() * 70;
      const theta = rnd() * Math.PI * 2;
      const phi = Math.acos(2 * rnd() - 1);
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.cos(phi) * 0.75;
      positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
      const light = 0.62 + rnd() * 0.38;
      colors[i * 3] = light;
      colors[i * 3 + 1] = light;
      colors[i * 3 + 2] = light * (0.94 + rnd() * 0.06);
      sizes[i] = 0.7 + rnd() * 1.7;
    }
    const geom = new THREE.BufferGeometry();
    geom.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geom.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geom.setAttribute("size", new THREE.BufferAttribute(sizes, 1));
    return geom;
  }, []);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 } },
        vertexShader: STAR_VERT,
        fragmentShader: STAR_FRAG,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        vertexColors: true,
      }),
    [],
  );

  useFrame((state) => {
    material.uniforms.uTime.value = state.clock.elapsedTime;
  });

  return <points geometry={geometry} material={material} frustumCulled={false} />;
}

function OrbitPath({ radius, inclination }: { radius: number; inclination: number }) {
  const points = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const steps = 180;
    for (let i = 0; i <= steps; i += 1) {
      const angle = (i / steps) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius));
    }
    return pts;
  }, [radius]);

  return (
    <group rotation={[inclination, 0, 0]}>
      <Line
        points={points}
        color={ORBIT_LINE}
        transparent
        opacity={0.42}
        lineWidth={1}
        depthWrite={false}
      />
    </group>
  );
}

function MotionTrail({
  color,
  position,
}: {
  color: string;
  position: RefObject<THREE.Vector3 | null>;
}) {
  const geometry = useMemo(() => {
    const geom = new THREE.BufferGeometry();
    geom.setAttribute("position", new THREE.BufferAttribute(new Float32Array(TRAIL * 3), 3));
    geom.setAttribute("color", new THREE.BufferAttribute(new Float32Array(TRAIL * 3), 3));
    geom.setDrawRange(0, 0);
    return geom;
  }, []);
  const history = useMemo(() => Array.from({ length: TRAIL }, () => new THREE.Vector3()), []);
  const head = useRef(0);
  const count = useRef(0);
  const base = useMemo(() => new THREE.Color(color), [color]);
  const material = useMemo(
    () =>
      new THREE.LineBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      }),
    [],
  );
  const line = useMemo(() => {
    const object = new THREE.Line(geometry, material);
    object.frustumCulled = false;
    return object;
  }, [geometry, material]);

  useFrame(() => {
    const current = position.current;
    if (!current) return;
    if (!useSolar.getState().paused) {
      const previous = history[(head.current - 1 + TRAIL) % TRAIL];
      if (count.current === 0 || previous.distanceToSquared(current) > 0.0008) {
        history[head.current].copy(current);
        head.current = (head.current + 1) % TRAIL;
        count.current = Math.min(TRAIL, count.current + 1);
      }
    }
    const n = count.current;
    const posAttr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const colAttr = geometry.getAttribute("color") as THREE.BufferAttribute;
    const pos = posAttr.array as Float32Array;
    const col = colAttr.array as Float32Array;
    const start = (head.current - n + TRAIL) % TRAIL;
    for (let i = 0; i < n; i += 1) {
      const point = history[(start + i) % TRAIL];
      pos[i * 3] = point.x;
      pos[i * 3 + 1] = point.y;
      pos[i * 3 + 2] = point.z;
      const fade = n <= 1 ? 1 : (i / (n - 1)) ** 1.6;
      col[i * 3] = base.r * fade;
      col[i * 3 + 1] = base.g * fade;
      col[i * 3 + 2] = base.b * fade;
    }
    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
    geometry.setDrawRange(0, Math.max(0, n));
  });

  return <primitive object={line} />;
}

function AsteroidBelt() {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const seeds = useMemo(() => {
    const rnd = mulberry32(23);
    return Array.from({ length: BELT_COUNT }, () => ({
      base: rnd() * Math.PI * 2,
      radius: 13.35 + rnd() * 1.55,
      y: (rnd() - 0.5) * 0.42,
      scale: 0.025 + rnd() * 0.055,
      speed: 0.035 + rnd() * 0.03,
      tilt: rnd() * Math.PI,
    }));
  }, []);

  useLayoutSeed(mesh, seeds, dummy);

  useFrame(() => {
    const inst = mesh.current;
    if (!inst) return;
    const time = clock.t;
    for (let i = 0; i < seeds.length; i += 1) {
      const seed = seeds[i];
      const angle = seed.base + time * seed.speed;
      dummy.position.set(Math.cos(angle) * seed.radius, seed.y, Math.sin(angle) * seed.radius);
      dummy.scale.setScalar(seed.scale);
      dummy.rotation.set(seed.tilt, angle, seed.tilt * 0.3);
      dummy.updateMatrix();
      inst.setMatrixAt(i, dummy.matrix);
    }
    inst.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, BELT_COUNT]} frustumCulled={false} raycast={() => null}>
      <dodecahedronGeometry args={[1, 0]} />
      <meshStandardMaterial color={BELT_COLOR} roughness={0.92} metalness={0.04} />
    </instancedMesh>
  );
}

function useLayoutSeed(
  mesh: RefObject<THREE.InstancedMesh | null>,
  seeds: Array<{ base: number; radius: number; y: number; scale: number; tilt: number }>,
  dummy: THREE.Object3D,
) {
  useEffect(() => {
    const inst = mesh.current;
    if (!inst) return;
    for (let i = 0; i < seeds.length; i += 1) {
      const seed = seeds[i];
      dummy.position.set(Math.cos(seed.base) * seed.radius, seed.y, Math.sin(seed.base) * seed.radius);
      dummy.scale.setScalar(seed.scale);
      dummy.rotation.set(seed.tilt, seed.base, 0);
      dummy.updateMatrix();
      inst.setMatrixAt(i, dummy.matrix);
    }
    inst.instanceMatrix.needsUpdate = true;
  }, [dummy, mesh, seeds]);
}

function PlanetRings({
  inner,
  outer,
  color,
  strength,
}: {
  inner: number;
  outer: number;
  color: string;
  strength: number;
}) {
  const uniforms = useMemo(
    () => ({
      uInner: { value: inner },
      uOuter: { value: outer },
      uColor: { value: new THREE.Color(color) },
      uStrength: { value: strength },
    }),
    [color, inner, outer, strength],
  );

  return (
    <mesh rotation={[Math.PI / 2, 0, 0]} raycast={() => null}>
      <ringGeometry args={[inner, outer, 96]} />
      <shaderMaterial
        uniforms={uniforms}
        vertexShader={RING_VERT}
        fragmentShader={RING_FRAG}
        transparent
        depthWrite={false}
        side={THREE.DoubleSide}
        toneMapped={false}
      />
    </mesh>
  );
}

function Atmosphere({ radius, color }: { radius: number; color: string }) {
  const uniforms = useMemo(() => ({ uColor: { value: new THREE.Color(color) } }), [color]);
  return (
    <mesh raycast={() => null}>
      <sphereGeometry args={[radius * 1.08, 40, 32]} />
      <shaderMaterial
        uniforms={uniforms}
        vertexShader={ATMOS_VERT}
        fragmentShader={ATMOS_FRAG}
        transparent
        depthWrite={false}
        side={THREE.FrontSide}
      />
    </mesh>
  );
}

const labelScratch = new THREE.Vector3();

function labelTexture(text: string, active: boolean) {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Não foi possível criar o rótulo.");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.font = "500 56px Outfit, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.lineWidth = 10;
  ctx.strokeStyle = "rgba(7, 8, 12, 0.88)";
  ctx.strokeText(text, 256, 64);
  ctx.fillStyle = active ? ACCENT : "#e8eaef";
  ctx.fillText(text, 256, 64);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;
  return texture;
}

function BodyLabel({
  name,
  active,
  radius,
}: {
  name: string;
  active: boolean;
  radius: number;
}) {
  const sprite = useRef<THREE.Sprite>(null);
  const [fontTick, setFontTick] = useState(0);
  const texture = useMemo(() => labelTexture(name, active), [name, active, fontTick]);

  useEffect(() => {
    let live = true;
    void document.fonts.load("500 56px Outfit").then(() => {
      if (live) setFontTick(1);
    });
    return () => {
      live = false;
    };
  }, []);

  useFrame((state) => {
    const object = sprite.current;
    if (!object) return;
    const dist = state.camera.position.distanceTo(object.getWorldPosition(labelScratch));
    const heightPx = 15;
    const fov = (state.camera as THREE.PerspectiveCamera).fov;
    const worldPerPixel =
      (2 * Math.tan((fov * Math.PI) / 360) * Math.max(dist, 0.001)) / Math.max(state.size.height, 1);
    const height = heightPx * worldPerPixel;
    object.scale.set(height * 4, height, 1);
    object.position.y = radius + height * 0.65 + 8 * worldPerPixel;
  });

  return (
    <sprite ref={sprite} raycast={() => null}>
      <spriteMaterial map={texture} transparent depthWrite={false} toneMapped={false} />
    </sprite>
  );
}

function SelectionRing({ radius }: { radius: number }) {
  const material = useRef<THREE.MeshBasicMaterial>(null);
  const reduced = useRef(false);
  useEffect(() => {
    reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);
  useFrame((state) => {
    if (!material.current || reduced.current) return;
    material.current.opacity = 0.45 + Math.sin(state.clock.elapsedTime * 2.1) * 0.22;
  });
  return (
    <Billboard>
      <mesh raycast={() => null}>
        <ringGeometry args={[radius * 1.42, radius * 1.56, 64]} />
        <meshBasicMaterial
          ref={material}
          color={ACCENT}
          transparent
          opacity={0.7}
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>
    </Billboard>
  );
}

function Body({ body, textures }: { body: BodyFacts; textures: SolarTextures }) {
  const anchor = useRef<THREE.Group>(null);
  const spin = useRef<THREE.Group>(null);
  const clouds = useRef<THREE.Group>(null);
  const moon = useRef<THREE.Group>(null);
  const pos = useRef<THREE.Vector3>(worldPos[body.id]);
  const selected = useSolar((state) => state.selected === body.id);
  const omega = body.orbitDays > 0 ? orbitOmega(body.orbitDays) : 0;
  const map = body.id === "sun" ? null : textures[body.id as Exclude<BodyId, "sun">];

  useFrame(() => {
    if (body.orbit > 0) {
      placeOnOrbit(body.phase + clock.t * omega, body.orbit, body.inclination, pos.current);
    } else {
      pos.current.set(0, 0, 0);
    }
    anchor.current?.position.copy(pos.current);
    if (spin.current) spin.current.rotation.y = clock.t * body.spin;
    if (clouds.current) clouds.current.rotation.y = clock.t * body.spin * 0.78;
    if (moon.current && body.moon) {
      const angle = clock.t * 1.35;
      moonPos.set(
        pos.current.x + Math.cos(angle) * 0.78,
        pos.current.y + Math.sin(angle * 0.35) * 0.06,
        pos.current.z + Math.sin(angle) * 0.78,
      );
      moon.current.position.copy(moonPos);
    }
  });

  const select = (event: { stopPropagation: () => void }) => {
    event.stopPropagation();
    useSolar.getState().select(body.id);
  };
  const setCursor = (value: string) => {
    document.body.style.cursor = value;
  };

  return (
    <group>
      {body.orbit > 0 && <OrbitPath radius={body.orbit} inclination={body.inclination} />}
      {body.orbit > 0 && <MotionTrail color={body.color} position={pos} />}
      <group ref={anchor}>
        <group rotation={[0, 0, body.tilt]}>
          <group ref={spin}>
            {body.id === "sun" ? (
              <SunSurface />
            ) : (
              <mesh raycast={() => null}>
                <sphereGeometry args={[body.radius, body.radius > 0.6 ? 56 : 40, body.radius > 0.6 ? 40 : 28]} />
                <meshStandardMaterial
                  map={map}
                  emissiveMap={map}
                  emissive="white"
                  emissiveIntensity={0.26}
                  roughness={body.kind.startsWith("Gigante") ? 0.62 : 0.88}
                  metalness={0.02}
                />
              </mesh>
            )}
          </group>
          {body.clouds && (
            <group ref={clouds}>
              <mesh raycast={() => null}>
                <sphereGeometry args={[body.radius * 1.025, 40, 28]} />
                <meshStandardMaterial
                  map={textures.clouds}
                  transparent
                  opacity={0.55}
                  depthWrite={false}
                  roughness={1}
                />
              </mesh>
            </group>
          )}
          {body.atmosphere && <Atmosphere radius={body.radius} color={body.atmosphere} />}
          {body.ring && (
            <PlanetRings
              inner={body.ring.inner}
              outer={body.ring.outer}
              color={body.color}
              strength={body.id === "uranus" ? 0.45 : 0.82}
            />
          )}
        </group>
        {selected && <SelectionRing radius={body.id === "sun" ? body.radius * 1.35 : Math.max(body.radius, 0.28)} />}
        <BodyLabel name={body.name} active={selected} radius={body.radius * (body.id === "sun" ? 1.15 : 1)} />
        <mesh
          onClick={select}
          onPointerOver={(event) => {
            event.stopPropagation();
            setCursor("pointer");
          }}
          onPointerOut={() => setCursor("")}
        >
          <sphereGeometry args={[Math.max(body.radius * 1.55, body.id === "sun" ? body.radius : 0.52), 16, 12]} />
          <meshBasicMaterial transparent opacity={0} depthWrite={false} />
        </mesh>
      </group>
      {body.moon && (
        <group ref={moon}>
          <mesh raycast={() => null}>
            <sphereGeometry args={[0.09, 20, 16]} />
            <meshStandardMaterial color={MOON_COLOR} roughness={0.95} emissive={MOON_COLOR} emissiveIntensity={0.2} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function SunSurface() {
  const material = useRef<THREE.ShaderMaterial>(null);
  const uniforms = useMemo(() => ({ uTime: { value: 0 } }), []);
  useFrame((state) => {
    if (material.current) material.current.uniforms.uTime.value = state.clock.elapsedTime;
  });
  return (
    <mesh raycast={() => null}>
      <sphereGeometry args={[BODY_MAP.sun.radius, 64, 48]} />
      <shaderMaterial
        ref={material}
        uniforms={uniforms}
        vertexShader={SUN_VERT}
        fragmentShader={SUN_FRAG}
        toneMapped={false}
      />
    </mesh>
  );
}

function SunGlow({ texture }: { texture: THREE.Texture }) {
  return (
    <group>
      <sprite scale={[8.2, 8.2, 1]} raycast={() => null}>
        <spriteMaterial
          map={texture}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          toneMapped={false}
          opacity={0.85}
        />
      </sprite>
      <pointLight color={SUN_LIGHT} intensity={320} distance={120} decay={2} />
    </group>
  );
}

function CameraRig() {
  const { camera, gl, size } = useThree();
  const focus = useRef(new THREE.Vector3());
  const offset = useRef(new THREE.Vector3());
  const spherical = useRef({ ...HOME });
  const goal = useRef({ ...HOME });
  const applied = useRef(-1);
  const idle = useRef(0);
  const reduced = useRef(false);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const drag = useRef<{ x: number; y: number; active: boolean } | null>(null);
  const pinch = useRef<number | null>(null);

  useEffect(() => {
    reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const element = gl.domElement;

    const minRadius = () => {
      const selected = useSolar.getState().selected;
      if (!selected) return 16;
      return Math.max(0.85, BODY_MAP[selected].view * 0.42);
    };

    const onDown = (event: PointerEvent) => {
      pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
      idle.current = 0;
      if (pointers.current.size === 1) {
        drag.current = { x: event.clientX, y: event.clientY, active: false };
      }
    };
    const onMove = (event: PointerEvent) => {
      if (!pointers.current.has(event.pointerId)) return;
      pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
      idle.current = 0;
      if (pointers.current.size >= 2) {
        const pts = [...pointers.current.values()];
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        if (pinch.current && dist > 0) {
          const next = clamp(goal.current.r * (pinch.current / dist), minRadius(), 120);
          goal.current.r = next;
          spherical.current.r = next;
        }
        pinch.current = dist;
        return;
      }
      pinch.current = null;
      if (!drag.current) return;
      const dx = event.clientX - drag.current.x;
      const dy = event.clientY - drag.current.y;
      if (!drag.current.active) {
        if (Math.hypot(dx, dy) < 5) return;
        drag.current.active = true;
      }
      drag.current.x = event.clientX;
      drag.current.y = event.clientY;
      spherical.current.theta -= dx * 0.005;
      spherical.current.phi = clamp(spherical.current.phi - dy * 0.004, 0.24, Math.PI - 0.24);
      goal.current.theta = spherical.current.theta;
      goal.current.phi = spherical.current.phi;
    };
    const onUp = (event: PointerEvent) => {
      pointers.current.delete(event.pointerId);
      if (pointers.current.size < 2) pinch.current = null;
      if (pointers.current.size === 0) drag.current = null;
    };
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      idle.current = 0;
      goal.current.r = clamp(goal.current.r * Math.exp(event.deltaY * 0.0011), minRadius(), 120);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.code === "ArrowLeft") {
        event.preventDefault();
        goal.current.theta += 0.08;
      } else if (event.code === "ArrowRight") {
        event.preventDefault();
        goal.current.theta -= 0.08;
      } else if (event.code === "ArrowUp") {
        event.preventDefault();
        goal.current.phi = clamp(goal.current.phi - 0.06, 0.24, Math.PI - 0.24);
      } else if (event.code === "ArrowDown") {
        event.preventDefault();
        goal.current.phi = clamp(goal.current.phi + 0.06, 0.24, Math.PI - 0.24);
      }
    };

    element.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    element.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("keydown", onKey);
    return () => {
      element.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      element.removeEventListener("wheel", onWheel);
      window.removeEventListener("keydown", onKey);
      document.body.style.cursor = "";
    };
  }, [gl]);

  useFrame((_, delta) => {
    const step = Math.min(delta, 0.1);
    const state = useSolar.getState();
    if (state.focusTick !== applied.current) {
      applied.current = state.focusTick;
      const body = state.selected ? BODY_MAP[state.selected] : null;
      goal.current.r = body ? body.view : HOME.r;
      if (!body) {
        goal.current.theta = HOME.theta;
        goal.current.phi = HOME.phi;
      }
    }

    idle.current += step;
    const dragging = drag.current?.active || pointers.current.size > 0;
    if (
      !dragging &&
      idle.current > 2.4 &&
      !state.selected &&
      !reduced.current &&
      !state.paused
    ) {
      const drift = step * 0.045 * Math.min(state.speed, 2);
      spherical.current.theta += drift;
      goal.current.theta += drift;
    }

    const response = reduced.current ? 16 : 3.1;
    const k = 1 - Math.exp(-response * step);
    const s = spherical.current;
    const g = goal.current;
    s.r += (g.r - s.r) * k;
    s.theta = lerpAngle(s.theta, g.theta, k);
    s.phi += (g.phi - s.phi) * k;

    const target = state.selected ? worldPos[state.selected] : ORIGIN;
    const follow = 1 - Math.exp(-(reduced.current ? 14 : 5.5) * step);
    focus.current.lerp(target, follow);
    sphericalToVec(s.r, s.theta, s.phi, offset.current);
    camera.position.copy(focus.current).add(offset.current);
    camera.lookAt(focus.current);
    if (!state.selected && size.width < 820) camera.translateY(-9);
  });

  return null;
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.16} />
      <hemisphereLight args={["#c5ccd8", "#14161c", 0.28]} />
    </>
  );
}

export function SolarScene() {
  const textures = useMemo(() => getSolarTextures(), []);
  const home = useMemo(() => sphericalToVec(HOME.r, HOME.theta, HOME.phi, new THREE.Vector3()), []);

  return (
    <Canvas
      className="stage-canvas"
      camera={{ fov: 42, near: 0.08, far: 260, position: [home.x, home.y, home.z] }}
      dpr={[1, 1.6]}
      gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
      onCreated={({ camera, gl }) => {
        camera.lookAt(0, 0, 0);
        gl.setClearColor(SCENE_BG);
      }}
    >
      <color attach="background" args={[SCENE_BG]} />
      <Simulator />
      <Lights />
      <Starfield />
      <SunGlow texture={textures.glow} />
      <AsteroidBelt />
      {BODIES.map((body) => (
        <Body key={body.id} body={body} textures={textures} />
      ))}
      <CameraRig />
    </Canvas>
  );
}
