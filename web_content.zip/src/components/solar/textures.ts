import * as THREE from "three";

function hash(ix: number, iy: number): number {
  const s = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

function noise(x: number, y: number): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash(xi, yi);
  const b = hash(xi + 1, yi);
  const c = hash(xi, yi + 1);
  const d = hash(xi + 1, yi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(x: number, y: number): number {
  let value = 0;
  let amplitude = 0.5;
  let frequency = 1;
  for (let i = 0; i < 3; i += 1) {
    value += amplitude * noise(x * frequency, y * frequency);
    frequency *= 2;
    amplitude *= 0.5;
  }
  return value;
}

function clamp01(n: number): number {
  return Math.min(1, Math.max(0, n));
}

type RGB = [number, number, number];

function mix(a: RGB, b: RGB, t: number): RGB {
  const k = clamp01(t);
  return [
    a[0] + (b[0] - a[0]) * k,
    a[1] + (b[1] - a[1]) * k,
    a[2] + (b[2] - a[2]) * k,
  ];
}

function write(data: Uint8ClampedArray, index: number, rgb: RGB, alpha = 255) {
  data[index] = rgb[0];
  data[index + 1] = rgb[1];
  data[index + 2] = rgb[2];
  data[index + 3] = alpha;
}

function makeTexture(
  width: number,
  height: number,
  paint: (data: Uint8ClampedArray, w: number, h: number) => void,
): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Não foi possível criar a textura.");
  const image = ctx.createImageData(width, height);
  paint(image.data, width, height);
  ctx.putImageData(image, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
}

function paintRocky(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  low: RGB,
  high: RGB,
  crater = 0,
) {
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const n = fbm(x * 0.02, y * 0.035);
      const n2 = fbm(x * 0.06 + 4, y * 0.06);
      let rgb = mix(low, high, n * 0.75 + n2 * 0.25);
      if (crater > 0) {
        const c = noise(x * 0.18, y * 0.18);
        if (c > 0.72) rgb = mix(rgb, [70, 68, 64], (c - 0.72) * 2.2);
      }
      write(data, (y * w + x) * 4, rgb);
    }
  }
}

function continent(lon: number, lat: number): number {
  const spots: Array<[number, number, number, number]> = [
    [20, 6, 26, 34],
    [14, 48, 18, 14],
    [78, 42, 48, 24],
    [105, 62, 28, 14],
    [-102, 46, 30, 22],
    [-62, -18, 16, 30],
    [134, -25, 16, 12],
    [-42, 72, 14, 8],
  ];
  let mask = 0;
  for (const [lo, la, slo, sla] of spots) {
    const dx = (lon - lo) / slo;
    const dy = (lat - la) / sla;
    mask += Math.exp(-(dx * dx + dy * dy));
  }
  return mask;
}

function paintEarth(data: Uint8ClampedArray, w: number, h: number) {
  const oceanA: RGB = [18, 62, 112];
  const oceanB: RGB = [36, 104, 150];
  const landA: RGB = [62, 102, 58];
  const landB: RGB = [150, 132, 86];
  const ice: RGB = [226, 232, 236];
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const lon = (x / w) * 360 - 180;
      const lat = 90 - (y / h) * 180;
      const n = fbm(x * 0.03, y * 0.03);
      const land = continent(lon, lat) * 0.9 + (n - 0.48) * 0.55;
      let rgb: RGB;
      if (Math.abs(lat) > 70) {
        rgb = mix(land > 0.4 ? landA : oceanA, ice, clamp01((Math.abs(lat) - 70) / 14));
      } else if (land > 0.42) {
        rgb = mix(landA, landB, n);
        if (Math.abs(lat) < 10 && n > 0.55) rgb = mix(rgb, [46, 110, 62], 0.45);
      } else {
        rgb = mix(oceanA, oceanB, n);
      }
      write(data, (y * w + x) * 4, rgb);
    }
  }
}

function paintVenus(data: Uint8ClampedArray, w: number, h: number) {
  const a: RGB = [186, 164, 118];
  const b: RGB = [232, 214, 176];
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const n = fbm(x * 0.02, y * 0.045);
      const swirl = fbm(x * 0.05 + n * 2, y * 0.02);
      write(data, (y * w + x) * 4, mix(a, b, swirl * 0.7 + n * 0.3));
    }
  }
}

function paintMars(data: Uint8ClampedArray, w: number, h: number) {
  const low: RGB = [112, 48, 32];
  const high: RGB = [186, 96, 58];
  const dust: RGB = [210, 150, 110];
  const ice: RGB = [230, 226, 220];
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const lat = Math.abs(90 - (y / h) * 180);
      const n = fbm(x * 0.028, y * 0.04);
      let rgb = mix(low, high, n);
      if (n > 0.62) rgb = mix(rgb, dust, (n - 0.62) * 1.6);
      if (lat > 72) rgb = mix(rgb, ice, clamp01((lat - 72) / 12));
      write(data, (y * w + x) * 4, rgb);
    }
  }
}

function paintBands(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  palette: RGB[],
  bands: number,
  spot?: { x: number; y: number; rx: number; ry: number; color: RGB },
) {
  for (let y = 0; y < h; y += 1) {
    const lat = y / h;
    const warp = fbm(0.4, lat * 6);
    for (let x = 0; x < w; x += 1) {
      const streak = fbm(x * 0.01, lat * 4);
      const t = Math.sin((lat * bands + warp * 0.35 + streak * 0.15) * Math.PI * 2) * 0.5 + 0.5;
      const index = Math.min(palette.length - 2, Math.floor(t * (palette.length - 1)));
      const local = t * (palette.length - 1) - index;
      let rgb = mix(palette[index], palette[index + 1], local);
      if (spot) {
        const dx = (x - spot.x * w) / spot.rx;
        const dy = (y - spot.y * h) / spot.ry;
        const d = dx * dx + dy * dy;
        if (d < 1) rgb = mix(rgb, spot.color, 1 - d);
      }
      write(data, (y * w + x) * 4, rgb);
    }
  }
}

function paintClouds(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const n = fbm(x * 0.03 + 2, y * 0.05);
      const alpha = n > 0.52 ? Math.floor((n - 0.52) * 520) : 0;
      write(data, (y * w + x) * 4, [244, 246, 248], Math.min(170, alpha));
    }
  }
}

function makeGlow(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Não foi possível criar o brilho.");
  const gradient = ctx.createRadialGradient(128, 128, 8, 128, 128, 128);
  gradient.addColorStop(0, "rgba(255, 246, 230, 0.95)");
  gradient.addColorStop(0.16, "rgba(255, 214, 150, 0.55)");
  gradient.addColorStop(0.38, "rgba(255, 170, 80, 0.16)");
  gradient.addColorStop(1, "rgba(255, 140, 40, 0)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, size, size);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

export interface SolarTextures {
  mercury: THREE.CanvasTexture;
  venus: THREE.CanvasTexture;
  earth: THREE.CanvasTexture;
  mars: THREE.CanvasTexture;
  jupiter: THREE.CanvasTexture;
  saturn: THREE.CanvasTexture;
  uranus: THREE.CanvasTexture;
  neptune: THREE.CanvasTexture;
  clouds: THREE.CanvasTexture;
  glow: THREE.CanvasTexture;
}

let cache: SolarTextures | null = null;

export function getSolarTextures(): SolarTextures {
  if (cache) return cache;
  const w = 256;
  const h = 128;
  cache = {
    mercury: makeTexture(w, h, (data, width, height) =>
      paintRocky(data, width, height, [92, 90, 86], [168, 164, 156], 1),
    ),
    venus: makeTexture(w, h, paintVenus),
    earth: makeTexture(w, h, paintEarth),
    mars: makeTexture(w, h, paintMars),
    jupiter: makeTexture(w, h, (data, width, height) =>
      paintBands(
        data,
        width,
        height,
        [
          [116, 74, 48],
          [214, 176, 124],
          [168, 116, 72],
          [232, 214, 186],
          [140, 86, 52],
        ],
        7,
        { x: 0.64, y: 0.62, rx: 18, ry: 10, color: [176, 72, 48] },
      ),
    ),
    saturn: makeTexture(w, h, (data, width, height) =>
      paintBands(
        data,
        width,
        height,
        [
          [196, 170, 130],
          [230, 214, 180],
          [176, 150, 112],
          [236, 224, 198],
        ],
        6,
      ),
    ),
    uranus: makeTexture(w, h, (data, width, height) =>
      paintBands(
        data,
        width,
        height,
        [
          [150, 196, 192],
          [196, 224, 220],
          [168, 208, 204],
        ],
        3,
      ),
    ),
    neptune: makeTexture(w, h, (data, width, height) =>
      paintBands(
        data,
        width,
        height,
        [
          [24, 52, 128],
          [48, 86, 176],
          [30, 64, 148],
          [70, 112, 196],
        ],
        4,
        { x: 0.42, y: 0.38, rx: 12, ry: 8, color: [120, 168, 210] },
      ),
    ),
    clouds: makeTexture(w, h, paintClouds),
    glow: makeGlow(),
  };
  return cache;
}
