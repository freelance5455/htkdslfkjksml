import { Pause, Play } from "lucide-react";
import { useEffect } from "react";
import { BODIES, BODY_MAP, type BodyId } from "@/lib/solar/data";
import { useSolar } from "@/lib/solar/store";

function formatSpeed(speed: number) {
  const text = speed >= 10 ? String(Math.round(speed)) : speed.toFixed(1).replace(".", ",");
  return `${text}×`;
}

const FACTS: Array<{ key: "diameter" | "distance" | "period" | "day" | "moons"; label: string }> = [
  { key: "diameter", label: "Diâmetro" },
  { key: "distance", label: "Distância ao Sol" },
  { key: "period", label: "Órbita" },
  { key: "day", label: "Dia" },
  { key: "moons", label: "Luas" },
];

export function Overlay() {
  const paused = useSolar((state) => state.paused);
  const speed = useSolar((state) => state.speed);
  const selected = useSolar((state) => state.selected);
  const togglePaused = useSolar((state) => state.togglePaused);
  const setSpeed = useSolar((state) => state.setSpeed);
  const select = useSolar((state) => state.select);
  const body = selected ? BODY_MAP[selected] : null;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      if (event.code === "Space") {
        event.preventDefault();
        useSolar.getState().togglePaused();
      } else if (event.code === "Escape") {
        useSolar.getState().select(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="hud">
      <p className="sr-only" aria-live="polite">
        {body ? `${body.name}. ${body.kind}.` : "Visão geral do sistema solar."}
      </p>

      <header className="topbar">
        <div className="brand">
          <span className="mark" aria-hidden="true" />
          <div>
            <h1>Órbita</h1>
            <p>Observatório do sistema solar</p>
          </div>
        </div>
        <div className="controls">
          <button type="button" className="btn" onClick={() => select(null)} aria-pressed={selected === null}>
            <span className="wide">Visão geral</span>
            <span className="narrow">Geral</span>
          </button>
          <label className="speed">
            <span className="speed-label">
              Velocidade
              <span className="tabular">{formatSpeed(speed)}</span>
            </span>
            <input
              type="range"
              min={0.25}
              max={8}
              step={0.05}
              value={speed}
              aria-valuetext={formatSpeed(speed)}
              onChange={(event) => setSpeed(Number(event.target.value))}
            />
          </label>
          <button type="button" className="btn btn-primary" onClick={togglePaused} aria-pressed={paused}>
            {paused ? <Play size={16} aria-hidden="true" /> : <Pause size={16} aria-hidden="true" />}
            <span>{paused ? "Retomar" : "Pausar"}</span>
          </button>
        </div>
      </header>

      <aside className="rail">
        <nav className="panel nav" aria-label="Corpos do sistema solar">
          {BODIES.map((item) => (
            <button
              key={item.id}
              type="button"
              className="nav-btn"
              aria-pressed={selected === item.id}
              onClick={() => select(item.id as BodyId)}
            >
              {item.name}
            </button>
          ))}
        </nav>

        <section className="panel info" aria-label={body ? body.name : "Sobre o sistema"}>
          <div key={selected ?? "system"} className="info-body">
            {body ? (
              <>
                <p className="kicker">{body.kind}</p>
                <h2>{body.name}</h2>
                <p className="blurb">{body.blurb}</p>
                <dl>
                  {FACTS.map((fact) => (
                    <div key={fact.key}>
                      <dt>{fact.label}</dt>
                      <dd className="tabular">{body[fact.key]}</dd>
                    </div>
                  ))}
                </dl>
              </>
            ) : (
              <>
                <p className="kicker">Vista do conjunto</p>
                <h2>Oito planetas</h2>
                <p className="blurb">
                  Clique num mundo, ou escolha-o na lista, para a câmara se aproximar e o seguir na órbita.
                </p>
              </>
            )}
            <p className="note">
              Tamanhos e distâncias estão comprimidos. O tempo é ilustrativo: a Terra completa uma volta em cerca de
              meio minuto a 1×.
            </p>
          </div>
        </section>
      </aside>

      <p className="hint">Arraste para orbitar · pinça ou roda para aproximar · Espaço pausa · Esc visão geral</p>
    </div>
  );
}
