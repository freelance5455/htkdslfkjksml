import React, { useState } from 'react';
import { 
  Share2, 
  X, 
  Send, 
  Copy, 
  Check, 
  Phone, 
  MessageSquare, 
  AlertCircle, 
  CheckCircle2, 
  Globe, 
  Sparkles,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { Customer, Payment, Bill, BusinessProfile, Language } from '../types';
import { receiptService, DuesTemplateType } from '../services/receiptService';
import { translations } from '../translations';

export interface WhatsAppDispatchPayload {
  mode: 'RECEIPT' | 'DUES';
  customer: Customer;
  payment?: Payment;
  bill?: Bill;
}

interface WhatsAppDispatchModalProps {
  payload: WhatsAppDispatchPayload;
  profile: BusinessProfile;
  appLanguage: Language;
  activeMonth: string;
  onClose: () => void;
  onNoticeSent?: (customerId: string) => void;
}

export const WhatsAppDispatchModal: React.FC<WhatsAppDispatchModalProps> = ({
  payload,
  profile,
  appLanguage,
  activeMonth,
  onClose,
  onNoticeSent,
}) => {
  const t = translations[appLanguage];

  // Configurable fields
  const [targetPhone, setTargetPhone] = useState<string>(payload.customer.mobile);
  const [selectedLang, setSelectedLang] = useState<Language>(appLanguage);
  const [templateType, setTemplateType] = useState<DuesTemplateType>(
    payload.customer.totalOutstanding > payload.customer.monthlyAmount ? 'URGENT' : 'STANDARD'
  );
  const [copied, setCopied] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  // Generate message preview
  const messageText = payload.mode === 'RECEIPT' && payload.payment
    ? receiptService.buildPaymentReceiptMessage(payload.payment, payload.customer, profile, selectedLang)
    : receiptService.buildOutstandingDuesMessage(payload.customer, profile, {
        bill: payload.bill,
        templateType,
        lang: selectedLang,
        activeMonth,
      });

  const whatsappUrl = payload.mode === 'RECEIPT' && payload.payment
    ? receiptService.getWhatsAppReceiptUrl(payload.payment, payload.customer, profile, selectedLang, targetPhone)
    : receiptService.getWhatsAppOutstandingDuesUrl(payload.customer, profile, {
        bill: payload.bill,
        templateType,
        lang: selectedLang,
        activeMonth,
        customMobile: targetPhone,
      });

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSend = () => {
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSentSuccess(true);
    if (onNoticeSent) {
      onNoticeSent(payload.customer.id);
    }
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden my-6 space-y-0">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>WhatsApp {payload.mode === 'RECEIPT' ? 'Receipt' : 'Dues Notice'}</span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  Direct Dispatch
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                To: <strong className="text-slate-200">{payload.customer.name}</strong> ({payload.customer.customerCode})
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4">
          
          {/* Target Mobile Number & Language Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Recipient Mobile Number</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-mono">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={targetPhone.replace(/^91/, '')}
                  onChange={(e) => setTargetPhone(e.target.value.replace(/\D/g, ''))}
                  className="w-full pl-10 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs sm:text-sm text-white font-mono"
                  placeholder="10-digit mobile"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>Message Language</span>
              </label>
              <div className="flex rounded-xl bg-slate-800 border border-slate-700 p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedLang('or')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition lang-odia ${
                    selectedLang === 'or' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ଓଡ଼ିଆ
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedLang('hi')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition lang-hindi ${
                    selectedLang === 'hi' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  हिंदी
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedLang('en')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition ${
                    selectedLang === 'en' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

          </div>

          {/* If Dues Mode, select tone template */}
          {payload.mode === 'DUES' && (
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Notice Tone / Template
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setTemplateType('STANDARD')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    templateType === 'STANDARD'
                      ? 'bg-slate-800 border-cyan-500 text-cyan-300 font-bold'
                      : 'bg-slate-850 border-slate-750 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="block font-semibold">Monthly Bill Notice</span>
                  <span className="text-[10px] text-slate-500 font-normal">Regular calendar billing</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTemplateType('URGENT')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    templateType === 'URGENT'
                      ? 'bg-rose-950/40 border-rose-500 text-rose-300 font-bold'
                      : 'bg-slate-850 border-slate-750 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="block font-semibold flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3 text-rose-400" />
                    <span>Urgent Overdue Alert</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-normal">Disconnect warning</span>
                </button>
              </div>
            </div>
          )}

          {/* WhatsApp Chat Preview Bubble */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span className="font-semibold uppercase tracking-wider text-[11px]">
                WhatsApp Message Preview
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1 text-slate-300 hover:text-white text-xs transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            </div>

            {/* Chat Bubble with WhatsApp Wallpaper Look */}
            <div className="p-4 rounded-2xl bg-[#0b141a] border border-[#1f2c34] shadow-inner font-sans text-xs text-[#e9edef] whitespace-pre-wrap max-h-56 overflow-y-auto leading-relaxed selection:bg-[#00a884]">
              <div className="bg-[#005c4b] p-3 rounded-2xl rounded-tl-sm text-[#e9edef] shadow-sm">
                {messageText}
                <div className="text-right text-[10px] text-emerald-200/80 mt-1 flex items-center justify-end gap-1 font-mono">
                  <span>Just now</span>
                  <span>✓✓</span>
                </div>
              </div>
            </div>
          </div>

          {/* Feedback notice if sent */}
          {sentSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>WhatsApp launched! Message queued for {payload.customer.name}.</span>
            </div>
          )}

          {/* Action Footer */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSend}
              className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-emerald-950/60 transition flex items-center gap-2 active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>Send on WhatsApp</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
