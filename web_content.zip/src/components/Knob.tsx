import React, { useRef, useState, useEffect } from 'react';

interface KnobProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  defaultValue?: number;
  unit?: string;
  size?: number;
  color?: string;
  onChange: (val: number) => void;
}

export const Knob: React.FC<KnobProps> = ({
  label,
  value,
  min,
  max,
  step = 1,
  defaultValue,
  unit = '',
  size = 46,
  color = '#ff7700',
  onChange,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const startYRef = useRef(0);
  const startValRef = useRef(value);

  const normalized = Math.max(0, Math.min(1, (value - min) / (max - min)));
  // Angle: -135deg to +135deg (total 270deg rotation)
  const angle = -135 + normalized * 270;

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(true);
    startYRef.current = e.clientY;
    startValRef.current = value;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dy = startYRef.current - e.clientY;
    const range = max - min;
    const sensitivity = 150; // pixels to travel full range
    const change = (dy / sensitivity) * range;
    let next = startValRef.current + change;

    if (step > 0) {
      next = Math.round(next / step) * step;
    }
    next = Math.max(min, Math.min(max, next));
    onChange(next);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  };

  const handleDoubleClick = () => {
    if (defaultValue !== undefined) {
      onChange(defaultValue);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const direction = e.deltaY > 0 ? -1 : 1;
    const delta = (step || (max - min) / 50) * direction;
    const next = Math.max(min, Math.min(max, value + delta));
    onChange(Number(next.toFixed(2)));
  };

  // SVG arc calculation for standard 270deg sweep
  const radius = size * 0.38;
  const strokeWidth = 3;
  const circumference = 2 * Math.PI * radius;
  const arcLength = circumference * 0.75; // 270 deg
  const strokeDashoffset = arcLength - normalized * arcLength;

  return (
    <div
      className="flex flex-col items-center select-none group touch-none"
      onWheel={handleWheel}
      title={`${label}: ${value.toFixed(1)}${unit} (drag up/down, double-click reset)`}
    >
      <div
        className="relative flex items-center justify-center cursor-ns-resize"
        style={{ width: size, height: size }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onDoubleClick={handleDoubleClick}
      >
        <svg
          className="absolute inset-0 -rotate-225 pointer-events-none"
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
        >
          {/* Background track arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#262c38"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
          />
          {/* Active colored arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </svg>

        {/* Knob core rotor */}
        <div
          className="rounded-full bg-[#1e232e] border border-[#333b4d] shadow-inner flex items-center justify-center transition-transform"
          style={{
            width: size * 0.65,
            height: size * 0.65,
            transform: `rotate(${angle}deg)`,
          }}
        >
          {/* Indicator tick */}
          <div
            className="w-1 rounded-full shadow-sm"
            style={{
              height: size * 0.22,
              backgroundColor: isDragging ? '#ffffff' : color,
              marginTop: -size * 0.1,
            }}
          />
        </div>
      </div>

      {/* Label and formatted numeric readout */}
      <span className="text-[10px] font-medium tracking-tight text-slate-400 mt-0.5 truncate max-w-[64px]">
        {label}
      </span>
      <span className="text-[9px] font-mono tabular-nums text-slate-300">
        {value >= 1000 ? `${(value / 1000).toFixed(1)}k` : value.toFixed(value % 1 !== 0 ? 1 : 0)}
        {unit}
      </span>
    </div>
  );
};
