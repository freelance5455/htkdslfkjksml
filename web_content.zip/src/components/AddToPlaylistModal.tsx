import React, { useState } from 'react';
import { Track, Playlist } from '../types/audio';
import { X, ListMusic, Plus, Check } from 'lucide-react';

interface Props {
  track: Track | null;
  playlists: Playlist[];
  isOpen: boolean;
  onClose: () => void;
  onAddToPlaylist: (playlistId: string, trackId: string) => void;
  onCreatePlaylist: (name: string) => void;
}

export const AddToPlaylistModal: React.FC<Props> = ({
  track,
  playlists,
  isOpen,
  onClose,
  onAddToPlaylist,
  onCreatePlaylist,
}) => {
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [addedMap, setAddedMap] = useState<Record<string, boolean>>({});

  if (!isOpen || !track) return null;

  const handleToggle = (playlist: Playlist) => {
    onAddToPlaylist(playlist.id, track.id);
    setAddedMap((prev) => ({ ...prev, [playlist.id]: !prev[playlist.id] }));
  };

  const handleCreateAndAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    onCreatePlaylist(newPlaylistName.trim());
    setNewPlaylistName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative text-left">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-sm font-semibold text-white mb-1">Añadir a Lista de Reproducción</h3>
        <p className="text-xs text-slate-400 truncate mb-4">
          Canción: <strong className="text-slate-200">{track.title}</strong>
        </p>

        {/* Existing playlists */}
        <div className="space-y-2 max-h-56 overflow-y-auto pr-1 mb-4">
          {playlists.map((pl) => {
            const hasTrack = pl.trackIds.includes(track.id) || addedMap[pl.id];
            return (
              <button
                key={pl.id}
                onClick={() => handleToggle(pl)}
                className={`w-full p-3 rounded-xl border flex items-center justify-between transition text-left ${
                  hasTrack
                    ? 'bg-indigo-600/15 border-indigo-500/80 text-white'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <ListMusic className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span className="text-xs font-medium truncate">{pl.name}</span>
                </div>
                {hasTrack ? (
                  <span className="flex items-center gap-1 text-[11px] text-indigo-400 font-semibold shrink-0">
                    <Check className="w-3.5 h-3.5" />
                    <span>Añadido</span>
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-400 shrink-0">+ Añadir</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Create new playlist inline */}
        <form onSubmit={handleCreateAndAdd} className="pt-3 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            placeholder="Nueva lista..."
            value={newPlaylistName}
            onChange={(e) => setNewPlaylistName(e.target.value)}
            className="flex-1 px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none"
          />
          <button
            type="submit"
            className="px-3.5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm"
          >
            Crear
          </button>
        </form>
      </div>
    </div>
  );
};
