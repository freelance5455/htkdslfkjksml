import { SubscribeButton } from "@/components/subscribe-button";
import { Badge } from "@/components/ui/badge";
import { formatCount } from "@/lib/utils";
import type { ChannelSummary } from "@/lib/youtube/types";
import { Link } from "@tanstack/react-router";

export function ChannelCard({ channel }: { channel: ChannelSummary }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-3">
      <div className="flex items-start gap-3">
        <Link
          to="/channel/$channelId"
          params={{ channelId: channel.id }}
          className="flex min-w-0 flex-1 items-start gap-3"
        >
          {channel.thumbnail ? (
            <img
              src={channel.thumbnail}
              alt=""
              className="size-14 shrink-0 rounded-full object-cover"
            />
          ) : (
            <span className="flex size-14 shrink-0 items-center justify-center rounded-full bg-muted text-lg font-medium">
              {channel.title.slice(0, 1)}
            </span>
          )}
          <span className="min-w-0 flex-1">
            <span className="block truncate font-medium text-foreground">
              {channel.title}
            </span>
            <span className="mt-0.5 block truncate text-xs text-muted-foreground">
              {channel.handle ? `${channel.handle} · ` : ""}
              {channel.subscriberText ||
                `${formatCount(channel.subscriberCount)} subscribers`}
            </span>
            {channel.subscriberCount === 0 ? (
              <span className="mt-1.5 inline-flex">
                <Badge variant="outline">0 subscribers</Badge>
              </span>
            ) : null}
          </span>
        </Link>
        <div className="shrink-0">
          <SubscribeButton channel={channel} />
        </div>
      </div>
    </div>
  );
}

export function ChannelCardSkeleton() {
  return (
    <div className="flex gap-3 rounded-2xl border border-border bg-card p-3">
      <div className="size-14 animate-pulse rounded-full bg-muted" />
      <div className="flex-1 space-y-2 pt-1">
        <div className="h-3.5 w-40 animate-pulse rounded bg-muted" />
        <div className="h-3 w-28 animate-pulse rounded bg-muted" />
      </div>
    </div>
  );
}
