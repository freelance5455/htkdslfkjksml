import React, { useState } from 'react';
import { IrPatternResult } from '../types/remote';
import { Activity, Copy, Check, Radio, Zap } from 'lucide-react';

interface Props {
  signal: IrPatternResult | null;
  lastCommandName?: string;
}

export const IrSignalVisualizer: React.FC<Props> = ({ signal, lastCommandName }) => {
  const [copied, setCopied] = useState(false);
  const [copiedPronto, setCopiedPronto] = useState(false);

  if (!signal) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-center text-slate-400">
        <Activity className="w-8 h-8 mx-auto mb-2 text-cyan-500 opacity-60 animate-pulse" />
        <p className="font-medium text-sm">اضغط على أي زر في الريموت لتوليد إشارة الأشعة تحت الحمراء وفحص موجة التردد والنبضات</p>
      </div>
    );
  }

  const copyKotlinArray = () => {
    const code = `// ${lastCommandName || 'IR Command'} - ${signal.frequencyHz}Hz\nval pattern = intArrayOf(\n    ${signal.patternMicros.join(', ')}\n)\nconsumerIrManager.transmit(${signal.frequencyHz}, pattern)`;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyPronto = () => {
    // Generate Pronto hex approximation
    const timeBase = 1000000 / signal.frequencyHz;
    const prontoTokens = ['0000', Math.round(1000000 / (signal.frequencyHz * 0.241246)).toString(16).padStart(4, '0').toUpperCase()];
    const pairsCount = Math.floor(signal.patternMicros.length / 2);
    prontoTokens.push(pairsCount.toString(16).padStart(4, '0').toUpperCase());
    prontoTokens.push('0000');
    signal.patternMicros.forEach((us) => {
      const counts = Math.max(1, Math.round(us / timeBase));
      prontoTokens.push(counts.toString(16).padStart(4, '0').toUpperCase());
    });
    const prontoStr = prontoTokens.join(' ');
    navigator.clipboard.writeText(prontoStr);
    setCopiedPronto(true);
    setTimeout(() => setCopiedPronto(false), 2000);
  };

  // Build SVG waveform path
  const maxVal = Math.max(...signal.patternMicros);
  const scale = 500 / Math.max(signal.totalDurationMs * 1000, 10000);
  let currentX = 0;
  let isPulse = true;
  let pathD = 'M 0 50';

  signal.patternMicros.slice(0, 30).forEach((micros) => {
    const width = Math.max(2, (micros / 1000) * 12);
    const y = isPulse ? 15 : 65;
    pathD += ` L ${currentX} ${y} L ${currentX + width} ${y}`;
    currentX += width;
    isPulse = !isPulse;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/10 rounded-lg text-cyan-400">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              راسم الإشارة والموجات (IR Oscilloscope)
              {lastCommandName && (
                <span className="text-xs bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full font-mono">
                  {lastCommandName}
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">تحليل النبضات الدقيقة لمُرسل ConsumerIrManager</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyKotlinArray}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs rounded-lg transition-colors border border-slate-700"
            title="نسخ مصفوفة Kotlin intArrayOf"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ كود Kotlin'}</span>
          </button>
          <button
            onClick={copyPronto}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-purple-400 text-xs rounded-lg transition-colors border border-slate-700"
            title="نسخ بتنسيق Pronto Hex"
          >
            {copiedPronto ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Zap className="w-3.5 h-3.5" />}
            <span>{copiedPronto ? 'تم النسخ!' : 'Pronto Hex'}</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <span className="text-[11px] text-slate-400 block">تردد الحامل (Carrier)</span>
          <span className="font-mono font-bold text-emerald-400 text-sm">
            {(signal.frequencyHz / 1000).toFixed(1)} kHz
          </span>
        </div>
        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <span className="text-[11px] text-slate-400 block">زمن البث الإجمالي</span>
          <span className="font-mono font-bold text-cyan-400 text-sm">
            {signal.totalDurationMs} ms
          </span>
        </div>
        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <span className="text-[11px] text-slate-400 block">عدد التبديلات (Pulses/Spaces)</span>
          <span className="font-mono font-bold text-amber-400 text-sm">
            {signal.pulseCount} عنصر
          </span>
        </div>
        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <span className="text-[11px] text-slate-400 block">التمثيل الست عشري (Hex)</span>
          <span className="font-mono font-bold text-purple-400 text-xs truncate block" title={signal.hexRepresentation}>
            {signal.hexRepresentation}
          </span>
        </div>
      </div>

      {/* Visual Waveform SVG */}
      <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 mb-3 overflow-hidden">
        <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mb-1">
          <span>HIGH (38kHz Burst)</span>
          <span>موجة النبضات الزمنية (Microsecond Waveform)</span>
          <span>LOW (Space)</span>
        </div>
        <div className="overflow-x-auto py-2">
          <svg className="w-full h-20 min-w-[500px]" viewBox="0 0 600 80">
            <line x1="0" y1="15" x2="600" y2="15" stroke="#334155" strokeDasharray="2 2" strokeWidth="1" />
            <line x1="0" y1="65" x2="600" y2="65" stroke="#334155" strokeDasharray="2 2" strokeWidth="1" />
            <path
              d={pathD}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2.5"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>

      {/* Raw timings snippet */}
      <div className="bg-slate-950/90 rounded-xl p-3 border border-slate-800 text-[11px] font-mono text-slate-300 max-h-24 overflow-y-auto">
        <div className="text-slate-500 mb-1">توقيتات المايكروثانية (Microseconds Raw Pattern):</div>
        <div className="leading-relaxed break-words text-cyan-300/90">
          [{signal.patternMicros.slice(0, 40).join(', ')}{signal.patternMicros.length > 40 ? '...' : ''}]
        </div>
      </div>
    </div>
  );
};
