import React from 'react';
import { 
  BellRing, 
  X, 
  Volume2, 
  CheckCheck,
  Zap,
  Radio,
  Repeat
} from 'lucide-react';
import { TriggeredAlertEvent } from '../types/market';

interface TriggeredAlertBannerProps {
  event: TriggeredAlertEvent | null;
  onDismiss: () => void;
  onReplayAudio: (event: TriggeredAlertEvent) => void;
  onAcknowledgeAlert?: (alertId: string) => void;
  repeatInfo?: {
    current: number;
    limit: number | 'unlimited';
    intervalMinutes: number;
  };
}

export const TriggeredAlertBanner: React.FC<TriggeredAlertBannerProps> = ({
  event,
  onDismiss,
  onReplayAudio,
  onAcknowledgeAlert,
  repeatInfo,
}) => {
  if (!event) return null;

  const isUp = event.condition === 'above' || event.condition === 'pct_gain';
  const isStrobe = event.screenAlertEffect === 'flash_strobe';

  return (
    <div className="relative">
      {/* 1. Innovative Screen Alert: Full-Screen Neon Strobe Border */}
      {isStrobe && (
        <div 
          className={`fixed inset-0 pointer-events-none z-50 transition-all duration-300 ${
            isUp 
              ? 'ring-8 ring-emerald-500/80 shadow-[inset_0_0_80px_rgba(16,185,129,0.35)] animate-pulse' 
              : 'ring-8 ring-rose-500/80 shadow-[inset_0_0_80px_rgba(244,63,94,0.35)] animate-pulse'
          }`} 
        />
      )}

      {/* 2. Tactical Triggered Alert Banner */}
      <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-xl px-4 animate-in slide-in-from-top-4 duration-300">
        <div className={`p-4 rounded-3xl shadow-2xl border backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-4 ${
          isUp 
            ? 'bg-slate-950/95 border-emerald-500/80 shadow-emerald-500/30 text-emerald-100 ring-2 ring-emerald-400/50' 
            : 'bg-slate-950/95 border-rose-500/80 shadow-rose-500/30 text-rose-100 ring-2 ring-rose-400/50'
        }`}>
          
          <div className="flex items-center gap-3 overflow-hidden w-full sm:w-auto">
            <div className={`p-3 rounded-2xl flex items-center justify-center animate-bounce shrink-0 ${
              isUp ? 'bg-emerald-500 text-slate-950' : 'bg-rose-500 text-white'
            }`}>
              <BellRing className="w-5 h-5" />
            </div>

            <div className="overflow-hidden flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-extrabold text-sm font-['Chakra_Petch'] tracking-wide">
                  ALERTE VOCALE DÉCLENCHÉE
                </span>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-black/50 border border-white/20">
                  {event.assetSymbol}
                </span>
                <span className="text-xs font-mono font-bold">
                  ${event.currentPrice.toLocaleString()}
                </span>
              </div>

              <p className="text-xs opacity-90 truncate mt-0.5 italic font-mono">
                "{event.voiceScript}"
              </p>

              {/* Repetition Info Pill */}
              {repeatInfo && (
                <div className="flex items-center gap-1.5 text-[10px] font-mono mt-1 opacity-75">
                  <Repeat className="w-3 h-3" />
                  <span>
                    Rappel : {repeatInfo.current} / {repeatInfo.limit === 'unlimited' ? '∞' : repeatInfo.limit} (toutes les {repeatInfo.intervalMinutes} min)
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
            <button
              onClick={() => onReplayAudio(event)}
              className="p-2 rounded-xl bg-black/40 hover:bg-black/60 text-white transition-colors cursor-pointer"
              title="Réécouter le son & la voix"
            >
              <Volume2 className="w-4 h-4" />
            </button>

            {onAcknowledgeAlert && (
              <button
                onClick={() => onAcknowledgeAlert(event.alertId)}
                className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                title="Acquitter l'alerte pour stopper les rappels automatiques"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Acquitter</span>
              </button>
            )}

            <button
              onClick={onDismiss}
              className="p-2 rounded-xl bg-black/40 hover:bg-black/60 text-white transition-colors cursor-pointer"
              title="Fermer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
