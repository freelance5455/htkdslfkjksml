import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  buildVault,
  detectDevice,
  EICAR_TEST,
  inspect,
  scoreFrom,
  type DeviceInfo,
  type Pack,
  type ScanFile,
  type ScanKind,
  type ScanSnapshot,
  type VaultFile,
} from "@/lib/shield/engine";

const STORAGE_KEY = "daylight-shield-v1";

export type ScanProgress = {
  done: number;
  total: number;
  current: string;
  phase: string;
  threats: number;
  recent: { id: string; label: string; bad: boolean }[];
};

type Persisted = {
  pack: Pack;
  held: string[];
  snapshot: ScanSnapshot | null;
  history: ScanSnapshot[];
};

type ScanItem = VaultFile & { bytesHead?: Uint8Array };

function wait(ms: number) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function isPack(value: unknown): value is Pack {
  return value === 1 || value === 2;
}

function isSnapshot(value: unknown): value is ScanSnapshot {
  if (!value || typeof value !== "object") return false;
  const snapshot = value as ScanSnapshot;
  return typeof snapshot.id === "string" && Array.isArray(snapshot.files) && typeof snapshot.deviceLabel === "string";
}

export function useShield() {
  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [pack, setPack] = useState<Pack>(1);
  const [held, setHeld] = useState<string[]>([]);
  const [snapshot, setSnapshot] = useState<ScanSnapshot | null>(null);
  const [history, setHistory] = useState<ScanSnapshot[]>([]);
  const [tab, setTab] = useState<"home" | "files" | "hold">("home");
  const [progress, setProgress] = useState<ScanProgress | null>(null);
  const [hydrated, setHydrated] = useState(false);

  const gen = useRef(0);
  const packRef = useRef(pack);
  const heldRef = useRef(held);
  const snapshotRef = useRef(snapshot);
  const deviceRef = useRef(device);
  const partialRef = useRef<{
    kind: ScanKind;
    label: string;
    files: ScanFile[];
    total: number;
  } | null>(null);

  packRef.current = pack;
  heldRef.current = held;
  snapshotRef.current = snapshot;
  deviceRef.current = device;

  useEffect(() => {
    setDevice(detectDevice());
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw) as Partial<Persisted>;
        if (isPack(data.pack)) setPack(data.pack);
        if (Array.isArray(data.held)) setHeld(data.held.filter((id) => typeof id === "string"));
        if (isSnapshot(data.snapshot)) setSnapshot(data.snapshot);
        if (Array.isArray(data.history)) setHistory(data.history.filter(isSnapshot).slice(0, 6));
      }
    } catch {
      /* ignore a broken save */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const data: Persisted = { pack, held, snapshot, history: history.slice(0, 6) };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [hydrated, pack, held, snapshot, history]);

  useEffect(() => {
    return () => {
      gen.current += 1;
    };
  }, []);

  const commit = useCallback((next: ScanSnapshot) => {
    const previous = snapshotRef.current;
    if (previous && previous.id !== next.id) {
      setHistory((items) => [previous, ...items].slice(0, 6));
    }
    setSnapshot(next);
    setProgress(null);
    setTab("home");
  }, []);

  const scanItems = useCallback(
    async (args: { kind: ScanKind; label: string; items: ScanItem[]; intro: boolean }) => {
      if (args.items.length === 0) return;
      const id = ++gen.current;
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const pause = (ms: number) => wait(reduce ? 0 : ms);
      setTab("home");
      setProgress({
        done: 0,
        total: args.items.length,
        current: args.intro ? "Common phone folders" : "Chosen files",
        phase: args.intro ? "Leaving installed apps alone" : "Reading chosen files",
        threats: 0,
        recent: [],
      });
      partialRef.current = { kind: args.kind, label: args.label, files: [], total: args.items.length };

      if (args.intro) {
        await pause(360);
        if (gen.current !== id) return;
        setProgress((current) =>
          current
            ? {
                ...current,
                phase: "Opening folders",
                current: "Camera, Downloads, Documents, Messages, Audio",
              }
            : current,
        );
        await pause(320);
      }

      const doneFiles: ScanFile[] = [];
      let threats = 0;
      for (let index = 0; index < args.items.length; index += 1) {
        if (gen.current !== id) return;
        const item = args.items[index];
        if (!item) continue;
        const finding = inspect({ name: item.name, text: item.text, bytes: item.bytesHead }, packRef.current);
        if (finding) threats += 1;
        const scanned: ScanFile = {
          id: item.id,
          name: item.name,
          folder: item.folder,
          bytes: item.bytes,
          finding,
        };
        doneFiles.push(scanned);
        partialRef.current = {
          kind: args.kind,
          label: args.label,
          files: doneFiles.slice(),
          total: args.items.length,
        };
        setProgress({
          done: index + 1,
          total: args.items.length,
          current: `${item.folder} / ${item.name}`,
          phase: `Checking ${item.folder}`,
          threats,
          recent: doneFiles.slice(-4).map((file) => ({
            id: file.id,
            label: `${file.folder} / ${file.name}`,
            bad: file.finding !== null,
          })),
        });
        await pause(44);
      }

      if (gen.current !== id) return;
      partialRef.current = null;
      const securedAtFinish = scoreFrom(doneFiles, new Set(heldRef.current)).secured;
      commit({
        id: `scan-${Date.now()}`,
        kind: args.kind,
        deviceLabel: args.label,
        finishedAt: Date.now(),
        files: doneFiles,
        scannedPercent: 100,
        pack: packRef.current,
        securedAtFinish,
      });
    },
    [commit],
  );

  const startMainScan = useCallback(() => {
    if (progress) return;
    const info = deviceRef.current ?? detectDevice();
    if (!deviceRef.current) setDevice(info);
    if (info.kind === "computer") {
      void scanItems({
        kind: "sample",
        label: "Sample phone",
        items: buildVault("sample-phone", "sample"),
        intro: true,
      });
      return;
    }
    void scanItems({
      kind: "phone",
      label: info.label,
      items: buildVault(info.seed, "device"),
      intro: true,
    });
  }, [progress, scanItems]);

  const startPicked = useCallback(
    async (list: FileList | File[]) => {
      if (progress) return;
      const files = [...list].slice(0, 40);
      if (files.length === 0) return;
      const items: ScanItem[] = [];
      for (const file of files) {
        const buffer = await file.slice(0, 256 * 1024).arrayBuffer();
        const bytesHead = new Uint8Array(buffer);
        const text = new TextDecoder("utf-8", { fatal: false }).decode(bytesHead.slice(0, 65_536));
        items.push({
          id: `chosen/${file.name}/${file.size}/${file.lastModified}`,
          name: file.name,
          folder: "Chosen",
          bytes: file.size,
          text,
          bytesHead,
        });
      }
      await scanItems({ kind: "picked", label: "Chosen files", items, intro: false });
    },
    [progress, scanItems],
  );

  const startEicar = useCallback(() => {
    if (progress) return;
    void scanItems({
      kind: "picked",
      label: "EICAR test",
      intro: false,
      items: [
        {
          id: "chosen/eicar.com",
          name: "eicar.com",
          folder: "Chosen",
          bytes: EICAR_TEST.length,
          text: EICAR_TEST,
        },
      ],
    });
  }, [progress, scanItems]);

  const stop = useCallback(() => {
    const partial = partialRef.current;
    partialRef.current = null;
    gen.current += 1;
    setProgress(null);
    if (!partial || partial.files.length === 0 || partial.files.length >= partial.total) return;
    const securedAtFinish = scoreFrom(partial.files, new Set(heldRef.current)).secured;
    commit({
      id: `scan-${Date.now()}`,
      kind: partial.kind,
      deviceLabel: partial.label,
      finishedAt: Date.now(),
      files: partial.files,
      scannedPercent: Math.max(1, Math.round((partial.files.length / partial.total) * 100)),
      pack: packRef.current,
      securedAtFinish,
    });
  }, [commit]);

  const quarantine = useCallback((id: string) => {
    setHeld((current) => (current.includes(id) ? current : [...current, id]));
  }, []);

  const restore = useCallback((id: string) => {
    setHeld((current) => current.filter((item) => item !== id));
  }, []);

  const updateSignatures = useCallback(() => {
    setPack(2);
  }, []);

  const heldSet = useMemo(() => new Set(held), [held]);
  const scored = useMemo(
    () => (snapshot ? scoreFrom(snapshot.files, heldSet) : null),
    [snapshot, heldSet],
  );

  const activeThreats = useMemo(
    () => snapshot?.files.filter((file) => file.finding && !heldSet.has(file.id)) ?? [],
    [snapshot, heldSet],
  );

  const heldFiles = useMemo(
    () => snapshot?.files.filter((file) => file.finding && heldSet.has(file.id)) ?? [],
    [snapshot, heldSet],
  );

  const primaryLabel = !snapshot
    ? device?.kind === "tablet"
      ? "Scan this tablet"
      : device?.kind === "phone"
        ? "Scan this phone"
        : device?.kind === "computer"
          ? "Sample phone scan"
          : "Start scan"
    : "Scan again";

  return {
    device,
    pack,
    tab,
    setTab,
    snapshot,
    history,
    progress,
    score: scored?.secured ?? null,
    capped: scored?.capped ?? false,
    activeThreats,
    heldFiles,
    heldSet,
    scanning: progress !== null,
    primaryLabel,
    startMainScan,
    startPicked,
    startEicar,
    stop,
    quarantine,
    restore,
    updateSignatures,
  };
}
