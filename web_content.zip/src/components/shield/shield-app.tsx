import { useRef, useState, type ReactNode } from "react";
import {
  FileSearch,
  FolderOpen,
  Laptop,
  Lock,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Tablet,
} from "lucide-react";
import { cn } from "@/lib/cn";
import {
  folderStats,
  formatBytes,
  formatWhen,
  type ScanFile,
} from "@/lib/shield/engine";
import { useShield } from "@/components/shield/use-shield";

const tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";

function ScoreDial({
  value,
  caption,
  tone,
  busy,
}: {
  value: number | null;
  caption: string;
  tone: "good" | "bad" | "idle";
  busy?: boolean;
}) {
  const radius = 86;
  const circumference = 2 * Math.PI * radius;
  const shown = value ?? 0;
  const offset = circumference - (shown / 100) * circumference;
  const stroke =
    tone === "bad" ? "var(--color-danger)" : tone === "idle" ? "var(--color-line)" : "var(--color-primary)";

  return (
    <div
      className="relative mx-auto grid size-56 place-items-center"
      role={busy ? "progressbar" : "meter"}
      aria-valuenow={value ?? 0}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={caption}
    >
      <svg viewBox="0 0 220 220" className="size-56" aria-hidden="true">
        <circle cx="110" cy="110" r={radius} fill="none" stroke="var(--color-line)" strokeWidth="12" />
        {value !== null && value > 0 ? (
          <circle
            cx="110"
            cy="110"
            r={radius}
            fill="none"
            stroke={stroke}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            transform="rotate(-90 110 110)"
            className="transition-[stroke-dashoffset] duration-150 ease-out"
          />
        ) : null}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center">
        <p className="font-serif text-6xl leading-none tracking-tight tabular-nums text-ink">
          {value === null ? "–" : value}
          {value !== null ? <span className="text-3xl">%</span> : null}
        </p>
        <p className="mt-2 text-sm font-medium text-muted">{caption}</p>
      </div>
    </div>
  );
}

function ActionButton({
  children,
  onClick,
  variant,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant: "primary" | "quiet" | "danger" | "soft";
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl px-4 text-base font-semibold",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
        "disabled:opacity-50",
        tap,
        variant === "primary" && "bg-primary text-surface",
        variant === "quiet" && "border border-line bg-surface text-ink",
        variant === "danger" && "bg-danger-soft text-danger",
        variant === "soft" && "bg-primary-soft text-primary",
      )}
    >
      {children}
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-3 py-3">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-serif text-2xl leading-none tabular-nums text-ink">{value}</p>
    </div>
  );
}

function ThreatCard({
  file,
  action,
  actionLabel,
  variant,
}: {
  file: ScanFile;
  action: () => void;
  actionLabel: string;
  variant: "danger" | "soft";
}) {
  if (!file.finding) return null;
  return (
    <article className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex items-start gap-3">
        <span
          className={cn(
            "grid size-11 shrink-0 place-items-center rounded-xl",
            variant === "danger" ? "bg-danger-soft text-danger" : "bg-primary-soft text-primary",
          )}
        >
          {variant === "danger" ? <ShieldAlert className="size-5" /> : <Lock className="size-5" />}
        </span>
        <div className="min-w-0">
          <h3 className="font-semibold text-ink">{file.finding.title}</h3>
          <p className="truncate text-sm text-muted">
            {file.folder} / {file.name}
          </p>
          <p className="mt-1 text-sm leading-relaxed text-ink">{file.finding.detail}</p>
          <p className="mt-1 text-sm tabular-nums text-muted">
            {formatBytes(file.bytes)}
            {variant === "danger" ? ` · −${file.finding.penalty} from the score` : " · left out of the score"}
          </p>
        </div>
      </div>
      <div className="mt-3">
        <ActionButton variant={variant === "danger" ? "danger" : "soft"} onClick={action}>
          {variant === "soft" ? <RotateCcw className="size-4" /> : <Lock className="size-4" />}
          {actionLabel}
        </ActionButton>
      </div>
    </article>
  );
}

export function ShieldApp() {
  const shield = useShield();
  const fileRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "risk" | "clean">("all");
  const scanning = shield.scanning;
  const progress = shield.progress;
  const snapshot = shield.snapshot;
  const scannedNow = progress && progress.total > 0 ? Math.round((progress.done / progress.total) * 100) : 0;
  const dialValue = scanning ? scannedNow : shield.score;
  const dialCaption = scanning ? "scanned" : snapshot ? "secured" : "not scanned yet";
  const tone = scanning || shield.score === null ? (scanning ? "good" : "idle") : shield.score >= 90 ? "good" : "bad";

  const visibleFiles = (snapshot?.files ?? []).filter((file) => {
    const matchesQuery = `${file.folder} ${file.name}`.toLowerCase().includes(query.trim().toLowerCase());
    if (!matchesQuery) return false;
    if (filter === "risk") return file.finding !== null && !shield.heldSet.has(file.id);
    if (filter === "clean") return file.finding === null || shield.heldSet.has(file.id);
    return true;
  });

  return (
    <div className="min-h-dvh bg-bg text-ink">
      <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col">
        <header className="sticky top-0 z-10 flex items-end justify-between bg-bg/90 px-5 py-4 backdrop-blur-md">
          <div>
            <p className="font-serif text-3xl leading-none text-ink">Daylight</p>
            <p className="mt-1 text-sm text-muted">Phone and tablet file shield</p>
          </div>
          <p className="pb-1 text-sm tabular-nums text-muted">Pack {shield.pack}</p>
        </header>

        <main className="flex flex-1 flex-col gap-6 px-5 pb-6">
          {scanning && progress ? (
            <section className="flex flex-col gap-5" aria-busy="true">
              <ScoreDial value={dialValue} caption={dialCaption} tone="good" busy />
              <div className="text-center">
                <p className="text-sm font-medium text-ink">{progress.phase}</p>
                <p className="mt-1 truncate text-sm text-muted">{progress.current}</p>
                <p className="mt-2 text-sm tabular-nums text-muted">
                  {progress.done} of {progress.total} files
                  {progress.threats > 0
                    ? ` · ${progress.threats} risky`
                    : ""}
                </p>
              </div>
              <ul className="space-y-2" aria-live="polite">
                {progress.recent.map((row) => (
                  <li key={row.id} className="flex items-center justify-between gap-3 text-sm">
                    <span className="truncate text-ink">{row.label}</span>
                    <span className={row.bad ? "font-semibold text-danger" : "text-muted"}>
                      {row.bad ? "Risk" : "Clean"}
                    </span>
                  </li>
                ))}
              </ul>
              <ActionButton variant="quiet" onClick={shield.stop}>
                Stop scan
              </ActionButton>
            </section>
          ) : null}

          {!scanning && shield.tab === "home" ? (
            <HomePane
              shield={shield}
              dialValue={dialValue}
              dialCaption={dialCaption}
              tone={tone === "idle" ? "idle" : tone}
              onPick={() => fileRef.current?.click()}
            />
          ) : null}

          {!scanning && shield.tab === "files" ? (
            <section className="flex flex-col gap-4">
              <div>
                <h1 className="font-serif text-3xl text-ink">Files</h1>
                <p className="mt-1 text-sm leading-relaxed text-muted">
                  Everything from the latest scan. Installed apps are not in this list.
                </p>
              </div>
              {snapshot ? (
                <>
                  <label className="block">
                    <span className="sr-only">Search scanned files</span>
                    <input
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      placeholder="Search files"
                      className="min-h-12 w-full rounded-2xl border border-line bg-surface px-4 text-base text-ink placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                    />
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        ["all", "All"],
                        ["risk", "Risks"],
                        ["clean", "Clean"],
                      ] as const
                    ).map(([id, label]) => (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setFilter(id)}
                        className={cn(
                          "min-h-11 rounded-2xl text-sm font-semibold",
                          tap,
                          filter === id ? "bg-primary text-surface" : "border border-line bg-surface text-ink",
                        )}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                  <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                    {visibleFiles.length === 0 ? (
                      <li className="px-4 py-6 text-sm text-muted">No files match.</li>
                    ) : (
                      visibleFiles.map((file) => {
                        const held = shield.heldSet.has(file.id);
                        const risky = file.finding !== null && !held;
                        return (
                          <li key={file.id} className="flex items-center gap-3 px-4 py-3">
                            <FolderOpen className="size-5 shrink-0 text-muted" />
                            <div className="min-w-0 flex-1">
                              <p className="truncate font-medium text-ink">{file.name}</p>
                              <p className="truncate text-sm text-muted">
                                {file.folder} · {formatBytes(file.bytes)}
                              </p>
                            </div>
                            <span
                              className={cn(
                                "shrink-0 rounded-full px-2.5 py-1 text-sm font-semibold",
                                risky && "bg-danger-soft text-danger",
                                held && "bg-bg text-muted",
                                !risky && !held && "bg-primary-soft text-primary",
                              )}
                            >
                              {risky ? "Risk" : held ? "Held" : "Clean"}
                            </span>
                          </li>
                        );
                      })
                    )}
                  </ul>
                </>
              ) : (
                <EmptyNote
                  title="Nothing scanned yet"
                  body="Run a scan from Home. Daylight will list the files it checked."
                />
              )}
            </section>
          ) : null}

          {!scanning && shield.tab === "hold" ? (
            <section className="flex flex-col gap-4">
              <div>
                <h1 className="font-serif text-3xl text-ink">Quarantine</h1>
                <p className="mt-1 text-sm leading-relaxed text-muted">
                  Held files stay out of the secured percentage until you restore them.
                </p>
              </div>
              {shield.heldFiles.length === 0 ? (
                <EmptyNote
                  title="Nothing is held"
                  body="When a scan finds a virus or a risky file, quarantine it here. The percentage goes up as soon as you do."
                />
              ) : (
                <div className="flex flex-col gap-3">
                  {shield.heldFiles.map((file) => (
                    <ThreatCard
                      key={file.id}
                      file={file}
                      variant="soft"
                      actionLabel="Restore"
                      action={() => shield.restore(file.id)}
                    />
                  ))}
                </div>
              )}
            </section>
          ) : null}
        </main>

        {scanning ? null : (
          <nav className="sticky bottom-0 z-10 grid grid-cols-3 border-t border-line bg-bg/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-md">
            <NavButton
              label="Home"
              active={shield.tab === "home"}
              onClick={() => shield.setTab("home")}
              icon={<ShieldCheck className="size-5" />}
            />
            <NavButton
              label="Files"
              active={shield.tab === "files"}
              onClick={() => shield.setTab("files")}
              icon={<FolderOpen className="size-5" />}
            />
            <NavButton
              label="Quarantine"
              active={shield.tab === "hold"}
              onClick={() => shield.setTab("hold")}
              icon={<Lock className="size-5" />}
            />
          </nav>
        )}
      </div>

      <input
        ref={fileRef}
        type="file"
        multiple
        className="sr-only"
        onChange={(event) => {
          const list = event.target.files;
          if (!list || list.length === 0) return;
          const files = [...list];
          event.target.value = "";
          void shield.startPicked(files);
        }}
      />
    </div>
  );
}

function HomePane({
  shield,
  dialValue,
  dialCaption,
  tone,
  onPick,
}: {
  shield: ReturnType<typeof useShield>;
  dialValue: number | null;
  dialCaption: string;
  tone: "good" | "bad" | "idle";
  onPick: () => void;
}) {
  const snapshot = shield.snapshot;
  const folders = snapshot ? folderStats(snapshot.files, shield.heldSet) : [];
  const device = shield.device;

  return (
    <>
      {device?.kind === "computer" ? (
        <section className="rounded-2xl border border-line bg-surface p-4">
          <div className="flex gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-bg text-ink">
              <Laptop className="size-5" />
            </span>
            <div>
              <h2 className="font-semibold text-ink">Laptops stay out</h2>
              <p className="mt-1 text-sm leading-relaxed text-muted">
                Daylight scans phones and tablets — Android, iPhone, and iPad. It does not scan this computer.
                Use the sample phone scan, or open Daylight on your phone.
              </p>
            </div>
          </div>
        </section>
      ) : null}

      {device && device.kind !== "computer" ? (
        <section className="rounded-2xl bg-primary-soft p-4 text-ink">
          <div className="flex items-center gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-surface text-primary">
              {device.kind === "tablet" ? <Tablet className="size-5" /> : <Smartphone className="size-5" />}
            </span>
            <div>
              <h2 className="font-semibold">{device.label}</h2>
              <p className="text-sm leading-relaxed text-muted">
                Ready to scan files and viruses. Installed apps are skipped.
              </p>
            </div>
          </div>
        </section>
      ) : null}

      <ScoreDial value={dialValue} caption={dialCaption} tone={tone} />

      {snapshot ? (
        <div className="text-center">
          <p className="text-sm text-muted">
            {snapshot.deviceLabel}
            {snapshot.kind === "sample" ? " · not this computer" : ""}
            {" · "}
            {formatWhen(snapshot.finishedAt)}
          </p>
          {snapshot.scannedPercent < 100 ? (
            <p className="mt-1 text-sm text-danger">Scan stopped at {snapshot.scannedPercent}% of files.</p>
          ) : (
            <p className="mt-1 text-sm font-medium text-ink">100% of files scanned</p>
          )}
        </div>
      ) : (
        <p className="text-center text-sm leading-relaxed text-muted">
          Checks files for viruses. You get a clear percentage — 100% secured means nothing active was found.
        </p>
      )}

      <div className="flex flex-col gap-3">
        <ActionButton variant="primary" onClick={shield.startMainScan}>
          <ShieldCheck className="size-5" />
          {shield.primaryLabel}
        </ActionButton>
        <ActionButton variant="quiet" onClick={onPick}>
          <FileSearch className="size-5" />
          Check chosen files
        </ActionButton>
        <button
          type="button"
          onClick={shield.startEicar}
          className={cn(
            "min-h-11 text-sm font-semibold text-primary",
            "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
            tap,
          )}
        >
          Try a test virus
        </button>
      </div>

      {snapshot ? (
        <div className="grid grid-cols-3 gap-2">
          <Stat label="Files scanned" value={`${snapshot.scannedPercent}%`} />
          <Stat label="Still at risk" value={String(shield.activeThreats.length)} />
          <Stat label="Quarantined" value={String(shield.heldFiles.length)} />
        </div>
      ) : null}

      {shield.activeThreats.length > 0 ? (
        <section className="flex flex-col gap-3">
          <h2 className="font-serif text-2xl text-ink">Needs attention</h2>
          {shield.activeThreats.map((file) => (
            <ThreatCard
              key={file.id}
              file={file}
              variant="danger"
              actionLabel="Quarantine"
              action={() => shield.quarantine(file.id)}
            />
          ))}
        </section>
      ) : null}

      {snapshot && shield.activeThreats.length === 0 ? (
        <section className="rounded-2xl bg-primary-soft px-4 py-4 text-ink">
          <p className="font-semibold">No active threats</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            {shield.heldFiles.length > 0
              ? "Risky files are quarantined, so they are not counted."
              : "Every file in this scan came back clean."}
          </p>
        </section>
      ) : null}

      {snapshot && shield.activeThreats.length > 0 ? (
        <section className="rounded-2xl border border-line bg-surface p-4">
          <h2 className="font-semibold text-ink">How this percentage is made</h2>
          <ul className="mt-3 space-y-2 text-sm">
            <li className="flex items-center justify-between gap-3">
              <span className="text-muted">Starting point</span>
              <span className="tabular-nums text-ink">100</span>
            </li>
            {shield.activeThreats.map((file) => (
              <li key={file.id} className="flex items-center justify-between gap-3">
                <span className="truncate text-muted">{file.finding?.title}</span>
                <span className="shrink-0 tabular-nums text-danger">−{file.finding?.penalty}</span>
              </li>
            ))}
            <li className="flex items-center justify-between gap-3 border-t border-line pt-2 font-semibold">
              <span>Secured</span>
              <span className="tabular-nums">{shield.score}%</span>
            </li>
          </ul>
          {shield.capped ? (
            <p className="mt-2 text-sm text-muted">The score stops at 55% when many files are risky.</p>
          ) : (
            <p className="mt-2 text-sm text-muted">Quarantine a file and that subtraction comes off.</p>
          )}
        </section>
      ) : null}

      {folders.length > 0 ? (
        <section>
          <h2 className="font-serif text-2xl text-ink">Folders checked</h2>
          <p className="mt-1 text-sm text-muted">Apps are not a folder here, and they are not scanned.</p>
          <ul className="mt-3 grid grid-cols-2 gap-2">
            {folders.map((folder) => (
              <li key={folder.name} className="rounded-2xl border border-line bg-surface px-3 py-3">
                <p className="text-sm text-muted">{folder.name}</p>
                <p className="mt-1 font-semibold tabular-nums text-ink">
                  {folder.total - folder.issues}/{folder.total} clean
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="font-semibold text-ink">Virus signatures</h2>
            <p className="text-sm text-muted">
              {shield.pack === 2 ? "22 Nov 2026 · pack 2" : "18 Nov 2026 · pack 1"}
            </p>
          </div>
          {shield.pack === 1 ? (
            <button
              type="button"
              onClick={shield.updateSignatures}
              className={cn(
                "min-h-11 shrink-0 rounded-2xl bg-primary px-4 text-sm font-semibold text-surface",
                tap,
              )}
            >
              Update signatures
            </button>
          ) : (
            <span className="text-sm font-semibold text-primary">Current</span>
          )}
        </div>
        {snapshot && snapshot.pack < shield.pack ? (
          <p className="mt-3 text-sm leading-relaxed text-muted">
            This report still used pack {snapshot.pack}. Scan again so the newer pattern is included.
          </p>
        ) : null}
      </section>

      {shield.history.length > 0 ? (
        <section>
          <h2 className="font-serif text-2xl text-ink">Earlier scans</h2>
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
            {shield.history.map((item) => (
              <li key={item.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate font-medium text-ink">{item.deviceLabel}</p>
                  <p className="text-sm text-muted">{formatWhen(item.finishedAt)}</p>
                </div>
                <div className="text-right">
                  <p className="font-serif text-2xl leading-none tabular-nums text-ink">{item.securedAtFinish}%</p>
                  <p className="text-sm text-muted">secured</p>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <p className="text-sm leading-relaxed text-muted">
        Daylight never scans installed apps, and it never scans a laptop or desktop. Chosen files are read on this
        device only — the first 256 KB of each one.
      </p>
    </>
  );
}

function EmptyNote({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-6">
      <p className="font-semibold text-ink">{title}</p>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function NavButton({
  label,
  active,
  onClick,
  icon,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl text-sm font-semibold",
        tap,
        active ? "text-primary" : "text-muted",
      )}
    >
      {icon}
      {label}
    </button>
  );
}
