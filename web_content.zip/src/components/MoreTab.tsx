import React, { useState } from 'react';
import {
  BookMarked,
  Microscope,
  FileSpreadsheet,
  Download,
  Info,
  ChevronRight,
  Search,
  Sparkles,
  Smartphone,
  CheckCircle2
} from 'lucide-react';
import { BIOLOGY_DICTIONARY } from '../data/biologyData';

export const MoreTab: React.FC = () => {
  const [dictSearch, setDictSearch] = useState('');
  const [selectedTool, setSelectedTool] = useState<'tools' | 'dictionary' | 'lab_manual' | 'android_source'>('tools');

  const filteredDict = BIOLOGY_DICTIONARY.filter(
    (item) =>
      item.term.toLowerCase().includes(dictSearch.toLowerCase()) ||
      item.eng.toLowerCase().includes(dictSearch.toLowerCase()) ||
      item.def.toLowerCase().includes(dictSearch.toLowerCase())
  );

  return (
    <div className="w-full max-w-md mx-auto px-4 pt-3 pb-24 space-y-4">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800 font-devanagari">
            अन्य उपयोगी संसाधन (Extra Tools)
          </h2>
          <p className="text-xs text-slate-500">
            शब्दावली, प्रयोगशाला कार्य, फॉर्मूला बैंक व एंड्रॉइड पैकेज
          </p>
        </div>
      </div>

      {/* Selector Tabs if inside subtool */}
      {selectedTool !== 'tools' && (
        <button
          onClick={() => setSelectedTool('tools')}
          className="text-xs font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1 font-devanagari"
        >
          ← वापस सभी टूल्स पर जाएँ
        </button>
      )}

      {/* Main Tools View */}
      {selectedTool === 'tools' && (
        <div className="space-y-3">
          {/* 1. Android APK & Source Code Download Card */}
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200 rounded-2xl p-4 shadow-sm space-y-2.5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 font-devanagari">
                    Android ऐप सोर्स कोड (ZIP)
                  </h3>
                  <span className="text-[11px] text-indigo-700 font-semibold">
                    ऑफ़लाइन मोबाइल पैकेज
                  </span>
                </div>
              </div>
              <span className="text-[10px] bg-indigo-600 text-white font-bold px-2 py-0.5 rounded-full">
                डाउनलोड
              </span>
            </div>

            <p className="text-xs text-slate-600 font-devanagari leading-relaxed">
              इस ऐप का पूर्ण Android-ready सोर्स कोड (Capacitor/Web) आपके लिए उपलब्ध है। इसे अपने फोन में बिना इंटरनेट के भी चला सकते हैं।
            </p>

            <a
              href="/assets/aistudio/Jeev_Vigyan_Saathi_Android_Source_24c246df.zip"
              download="Jeev_Vigyan_Saathi_Android_Source.zip"
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>सोर्स कोड ZIP डाउनलोड करें (24 KB)</span>
            </a>
          </div>

          {/* 2. Biology Dictionary (शब्दावली) */}
          <button
            onClick={() => setSelectedTool('dictionary')}
            className="w-full bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between text-left shadow-xs transition-colors group cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                <BookMarked className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 font-devanagari group-hover:text-teal-700 transition-colors">
                  जीव विज्ञान शब्दावली (Dictionary)
                </h4>
                <p className="text-xs text-slate-500">
                  हिंदी-अंग्रेजी महत्वपूर्ण वैज्ञानिक परिभाषाएँ
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-700" />
          </button>

          {/* 3. Lab Manual & Experiments (प्रयोगशाला निर्देशिका) */}
          <button
            onClick={() => setSelectedTool('lab_manual')}
            className="w-full bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between text-left shadow-xs transition-colors group cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                <Microscope className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 font-devanagari group-hover:text-amber-700 transition-colors">
                  प्रैक्टिकल लैब मैनुअल (Lab Manual)
                </h4>
                <p className="text-xs text-slate-500">
                  प्रयोग, वाइवा प्रश्न एवं स्लाइड पहचान गाइड
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-700" />
          </button>

          {/* 4. NEET Important Charts */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>बायोलॉजी क्विक रिवीजन चार्ट्स</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs font-devanagari pt-1">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="block text-slate-900 mb-0.5">वर्णक चार्ट</strong>
                <span className="text-[11px] text-slate-500">क्लोरोफिल a, b, c, d एवं फाइकोएरिथ्रिन</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="block text-slate-900 mb-0.5">एंजाइम सूची</strong>
                <span className="text-[11px] text-slate-500">RuBisCO, PEP कार्बोक्सीलेज, पेप्सिन</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="block text-slate-900 mb-0.5">हार्मोन तालिका</strong>
                <span className="text-[11px] text-slate-500">ऑक्सिन, जिबरेलिन, साइटोकाइनिन, ABA</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="block text-slate-900 mb-0.5">रोग एवं लक्षण</strong>
                <span className="text-[11px] text-slate-500">जीवाणु, विषाणु एवं कवक जनित रोग</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dictionary Sub-view */}
      {selectedTool === 'dictionary' && (
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={dictSearch}
              onChange={(e) => setDictSearch(e.target.value)}
              placeholder="वैज्ञानिक शब्द खोजें (उदा. उपापचय, रुबिस्को)..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00838f] text-slate-800"
            />
          </div>

          <div className="space-y-2.5">
            {filteredDict.map((item, idx) => (
              <div key={idx} className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-teal-800 font-devanagari">
                    {item.term}
                  </h4>
                  <span className="text-[11px] font-semibold text-slate-400 font-mono">
                    {item.eng}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-devanagari leading-relaxed">
                  {item.def}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Lab Manual Sub-view */}
      {selectedTool === 'lab_manual' && (
        <div className="space-y-3">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-devanagari">
            <strong>कक्षा 11 प्रायोगिक जीव विज्ञान:</strong> प्रमुख प्रयोग, स्लाइड निर्माण एवं मौखिक (Viva) प्रश्नोत्तर।
          </div>

          <div className="space-y-2.5">
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                प्रयोग 1
              </span>
              <h4 className="text-xs font-bold text-slate-900 font-devanagari">
                प्याज की झिल्ली (Onion Peel) की अस्थाई स्लाइड तैयार कर पादप कोशिका का अध्ययन
              </h4>
              <p className="text-xs text-slate-600 font-devanagari">
                अभिरंजक (Stain): सैफ्रानिन (Safranin) का उपयोग किया जाता है। कोशिका भित्ति, कोशिका द्रव्य व केंद्रक स्पष्ट दिखाई देते हैं।
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                प्रयोग 2
              </span>
              <h4 className="text-xs font-bold text-slate-900 font-devanagari">
                प्याज के मूलाग्र (Root Tip) में समसूत्री विभाजन की विभिन्न अवस्थाओं का अध्ययन
              </h4>
              <p className="text-xs text-slate-600 font-devanagari">
                अभिरंजक: एसीटोकार्मिन (Acetocarmine)। प्रोफेज, मेटाफेज (मध्य रेखा पर गुणसूत्र), एनाफेज एवं टेलोफेज का सूक्ष्मदर्शी अवलोकन।
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                प्रयोग 3
              </span>
              <h4 className="text-xs font-bold text-slate-900 font-devanagari">
                पत्ती की निचली सतह पर रंध्रों (Stomata) के वितरण का अध्ययन
              </h4>
              <p className="text-xs text-slate-600 font-devanagari">
                द्विबीजपत्री पत्तियों में वृक्काकार (Kidney shaped) तथा एकबीजपत्री (घास) में डंबलाकार (Dumbbell shaped) द्वार कोशिकाएँ पाई जाती हैं।
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
