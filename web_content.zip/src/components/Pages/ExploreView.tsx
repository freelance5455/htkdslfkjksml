import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { INITIAL_SONGS, GENRE_CHIPS } from '../../data/musicCatalog';
import { Play, TrendingUp, Compass, Sparkles, Radio, Award } from 'lucide-react';

interface ExploreViewProps {
  onSelectTab: (tab: string) => void;
}

export const ExploreView: React.FC<ExploreViewProps> = ({ onSelectTab }) => {
  const { playSong } = useMusic();

  const genreCards = [
    { name: 'Bollywood & Hindi', color: 'from-orange-600 to-rose-700', songs: INITIAL_SONGS.filter(s => s.genre === 'Bollywood') },
    { name: 'Punjabi Hits', color: 'from-amber-500 to-red-600', songs: INITIAL_SONGS.filter(s => s.genre === 'Punjabi') },
    { name: 'Pop & Viral Hits', color: 'from-pink-600 to-rose-700', songs: INITIAL_SONGS.filter(s => s.genre === 'Pop') },
    { name: 'Hip-Hop & Rap', color: 'from-amber-600 to-red-700', songs: INITIAL_SONGS.filter(s => s.genre === 'Hip-Hop') },
    { name: 'Electronic & Dance', color: 'from-blue-600 to-indigo-800', songs: INITIAL_SONGS.filter(s => s.genre === 'Electronic') },
    { name: 'Lo-Fi & Chill Beats', color: 'from-emerald-600 to-teal-800', songs: INITIAL_SONGS.filter(s => s.genre === 'Lo-Fi') },
    { name: 'Synthwave & Retro', color: 'from-purple-600 to-fuchsia-800', songs: INITIAL_SONGS.filter(s => s.genre === 'Synthwave') },
    { name: 'Acoustic & Folk', color: 'from-orange-600 to-amber-800', songs: INITIAL_SONGS.filter(s => s.genre === 'Acoustic') },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 max-w-6xl mx-auto w-full text-white select-none pb-28 md:pb-20">
      <div className="flex items-center gap-3 pb-6 border-b border-white/10">
        <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-red-600 to-orange-500 text-white shadow-lg">
          <Compass className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Explore & Discover</h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-0.5">
            Global charts, viral shorts audio, and new releases across every genre.
          </p>
        </div>
      </div>

      {/* Top 3 Quick Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-6">
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-[#141414] border border-white/5 hover:border-white/15 transition cursor-pointer">
          <div className="p-3 rounded-xl bg-red-600 text-white">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Top 50 Global</h3>
            <p className="text-xs text-neutral-400">Updated Daily</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 rounded-2xl bg-[#141414] border border-white/5 hover:border-white/15 transition cursor-pointer">
          <div className="p-3 rounded-xl bg-indigo-600 text-white">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Viral Music Hits</h3>
            <p className="text-xs text-neutral-400">Top Trending</p>
          </div>
        </div>

        <div
          onClick={() => {
            const first = INITIAL_SONGS[0];
            if (first) playSong(first, INITIAL_SONGS);
          }}
          className="flex items-center gap-3 p-4 rounded-2xl bg-[#141414] border border-white/5 hover:border-white/15 transition cursor-pointer"
        >
          <div className="p-3 rounded-xl bg-purple-600 text-white">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Non-Stop Radio</h3>
            <p className="text-xs text-neutral-400">Personalized Mix</p>
          </div>
        </div>
      </div>

      {/* Genre Tile Grid */}
      <div className="mb-8">
        <h2 className="text-xl font-bold tracking-tight mb-4">Moods & Genres</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {genreCards.map((genre) => (
            <div
              key={genre.name}
              onClick={() => {
                if (genre.songs.length > 0) {
                  playSong(genre.songs[0], genre.songs);
                } else {
                  playSong(INITIAL_SONGS[0]);
                }
              }}
              className={`relative h-28 sm:h-32 rounded-2xl bg-gradient-to-br ${genre.color} p-4 flex flex-col justify-between overflow-hidden shadow-lg hover:scale-[1.02] active:scale-95 transition cursor-pointer group`}
            >
              <h3 className="font-black text-base sm:text-lg text-white leading-tight drop-shadow">
                {genre.name}
              </h3>
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/80 font-medium">Listen Now</span>
                <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition shadow">
                  <Play className="w-4 h-4 fill-black ml-0.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* New Releases Section */}
      <div>
        <h2 className="text-xl font-bold tracking-tight mb-4">New Releases</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {INITIAL_SONGS.map((song) => (
            <div
              key={song.id}
              onClick={() => playSong(song, INITIAL_SONGS)}
              className="flex items-center justify-between p-3 rounded-2xl bg-[#121212] hover:bg-[#181818] border border-white/5 transition cursor-pointer group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={song.coverUrl}
                  alt={song.title}
                  className="w-14 h-14 rounded-xl object-cover shrink-0"
                />
                <div className="min-w-0">
                  <p className="font-bold text-sm text-white truncate leading-tight group-hover:text-red-400 transition">
                    {song.title}
                  </p>
                  <p className="text-xs text-neutral-400 truncate mt-0.5">{song.artist}</p>
                  <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 text-neutral-300">
                    {song.genre}
                  </span>
                </div>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playSong(song, INITIAL_SONGS);
                }}
                className="w-10 h-10 rounded-full bg-white/10 group-hover:bg-red-600 group-hover:text-white text-neutral-300 flex items-center justify-center transition shrink-0 ml-2"
              >
                <Play className="w-4 h-4 fill-current ml-0.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
