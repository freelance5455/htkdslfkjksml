import React, { useState, useEffect, useRef } from 'react';
import { useMusic } from '../../context/MusicContext';
import { INITIAL_SONGS, INITIAL_ARTISTS } from '../../data/musicCatalog';
import { searchYouTubeMusic, isKidsSong } from '../../services/youtubeSearchService';
import { formatTime } from '../../utils/formatTime';
import { Song, Artist } from '../../types/music';
import {
  Search,
  Play,
  Heart,
  Download,
  Youtube,
  Link as LinkIcon,
  CheckCircle,
  MoreVertical,
  Plus,
  Flame,
  TrendingUp,
  X,
  Bell,
  ListPlus,
  Mic,
  Share2,
  Radio,
  Clock,
  Sparkles,
  Volume2,
  Power,
  Globe,
  Loader2,
  Check
} from 'lucide-react';

interface SearchViewProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const STORAGE_KEY_RECENT_SEARCHES = 'ytm_recent_searches';

const SEARCH_PRESETS = [
  'Kesariya Brahmastra',
  'Chuttamalle Devara',
  'Apna Bana Le Bhediya',
  'Tauba Tauba Bad Newz',
  'Arijit Singh romantic',
  'Diljit Dosanjh Lover',
  'G.O.A.T. Diljit',
  'Starboy The Weeknd',
  'Blinding Lights',
  'Karan Aujla Softly',
  'Sidhu Moose Wala 295',
  'AP Dhillon Brown Munde',
  'Tum Hi Ho Arijit',
  'Pasoori Ali Sethi',
  'Believer Imagine Dragons',
  'Lofi Girl chill beats',
  'Hukum Jailer',
  'Illuminati Aavesham',
  'Bhojpuri trending hit',
  'Espresso Sabrina Carpenter'
];

export const SearchView: React.FC<SearchViewProps> = ({ searchQuery, onSearchChange }) => {
  const {
    playSong,
    playYouTubeTrack,
    likedSongIds,
    toggleLike,
    downloadedSongIds,
    toggleDownload,
    addToQueue,
    currentSong,
    isPlaying,
    stopMusic,
    isSameTypeMode,
    toggleSameTypeMode,
    vibeMode,
    setVibeMode,
    startVibeRadio
  } = useMusic();

  const [activeTab, setActiveTab] = useState<string>('All YouTube');
  const [customYtInput, setCustomYtInput] = useState('');
  const [showYtInput, setShowYtInput] = useState(false);
  const [subscribedArtists, setSubscribedArtists] = useState<Set<string>>(new Set());
  const [isVoiceListening, setIsVoiceListening] = useState(false);

  // YouTube live search results state
  const [ytResults, setYtResults] = useState<Song[]>([]);
  const [isSearchingYT, setIsSearchingYT] = useState(false);
  const [ytSearchError, setYtSearchError] = useState<string | null>(null);
  const searchTimeoutRef = useRef<number | null>(null);

  // Recent Searches
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_RECENT_SEARCHES);
      return saved ? JSON.parse(saved) : ['Kesariya', 'Chuttamalle', 'Diljit Dosanjh', 'Starboy'];
    } catch {
      return ['Kesariya', 'Chuttamalle', 'Diljit Dosanjh', 'Starboy'];
    }
  });

  const query = searchQuery.trim();

  // Save query to recent searches
  const saveRecentSearch = (term: string) => {
    if (!term.trim()) return;
    setRecentSearches((prev) => {
      const filtered = prev.filter((item) => item.toLowerCase() !== term.toLowerCase());
      const next = [term, ...filtered].slice(0, 10);
      localStorage.setItem(STORAGE_KEY_RECENT_SEARCHES, JSON.stringify(next));
      return next;
    });
  };

  const removeRecentSearch = (term: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches((prev) => {
      const next = prev.filter((item) => item !== term);
      localStorage.setItem(STORAGE_KEY_RECENT_SEARCHES, JSON.stringify(next));
      return next;
    });
  };

  const clearAllRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem(STORAGE_KEY_RECENT_SEARCHES);
  };

  const toggleSubscribe = (artistId: string) => {
    setSubscribedArtists((prev) => {
      const next = new Set(prev);
      if (next.has(artistId)) next.delete(artistId);
      else next.add(artistId);
      return next;
    });
  };

  // Perform live YouTube search whenever searchQuery changes
  useEffect(() => {
    if (!query) {
      setYtResults([]);
      setIsSearchingYT(false);
      return;
    }

    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);

    setIsSearchingYT(true);
    setYtSearchError(null);

    searchTimeoutRef.current = window.setTimeout(async () => {
      try {
        const results = await searchYouTubeMusic(query);
        setYtResults(results);
      } catch (err: any) {
        setYtSearchError('Failed to load YouTube tracks');
      } finally {
        setIsSearchingYT(false);
      }
    }, 350);

    return () => {
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    };
  }, [query]);

  // Fallback / local catalog filtered results
  const matchingLocalSongs = INITIAL_SONGS.filter((s) => {
    if (!query) return true;
    const qLower = query.toLowerCase();
    const inTitle = s.title.toLowerCase().includes(qLower);
    const inArtist = s.artist.toLowerCase().includes(qLower);
    const inAlbum = s.album.toLowerCase().includes(qLower);
    const inGenre = s.genre.toLowerCase().includes(qLower);
    return inTitle || inArtist || inAlbum || inGenre;
  });

  // Combine results: YouTube live search results prioritized, supplemented with local matches
  const displaySongs: Song[] = query
    ? ytResults.length > 0
      ? ytResults
      : matchingLocalSongs
    : INITIAL_SONGS;

  // Matching artists for Official Channel Card
  const matchingArtists = query
    ? INITIAL_ARTISTS.filter(
        (a) =>
          a.name.toLowerCase().includes(query.toLowerCase()) ||
          a.bio.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const handlePlayCustomYT = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customYtInput.trim()) return;
    saveRecentSearch(customYtInput.trim());
    playYouTubeTrack(customYtInput.trim());
    setCustomYtInput('');
    setShowYtInput(false);
  };

  const handlePlayDynamicSearch = () => {
    if (!query) return;
    saveRecentSearch(query);

    if (displaySongs.length > 0) {
      playSong(displaySongs[0], displaySongs);
    } else {
      playYouTubeTrack('BddP6PYo2gs', query, 'YouTube Music Official');
    }
  };

  const handleVoiceSearch = () => {
    setIsVoiceListening(true);
    const randomPick = SEARCH_PRESETS[Math.floor(Math.random() * SEARCH_PRESETS.length)];
    setTimeout(() => {
      onSearchChange(randomPick);
      saveRecentSearch(randomPick);
      setIsVoiceListening(false);
    }, 700);
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-5 max-w-5xl mx-auto w-full text-white select-none pb-28 md:pb-20">
      {/* Top Banner: Turn Off Music Button & Active Vibe Status */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 mb-4 p-3 rounded-2xl bg-[#141414] border border-white/10">
        <div className="flex items-center gap-2 min-w-0">
          <Globe className="w-4 h-4 text-red-500 shrink-0 animate-pulse" />
          <p className="text-xs font-semibold text-neutral-300 truncate">
            YouTube Music Search Engine • All songs on YouTube available
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0 ml-auto">
          {/* Off Music Button if Playing */}
          {isPlaying && (
            <button
              onClick={stopMusic}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/80 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 text-xs font-bold transition cursor-pointer shadow-sm active:scale-95"
              title="Turn Off Music"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Turn Off Music</span>
            </button>
          )}

          {/* Same Wave / Vibe Tuner Button */}
          <button
            onClick={() => {
              if (!isSameTypeMode) {
                toggleSameTypeMode();
              } else {
                const modes: ('same-wave' | 'discover-different' | 'chill' | 'upbeat' | 'same-artist')[] = [
                  'same-wave',
                  'discover-different',
                  'chill',
                  'upbeat',
                  'same-artist'
                ];
                const curIdx = modes.indexOf(vibeMode as any);
                setVibeMode(modes[(curIdx + 1) % modes.length]);
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition cursor-pointer active:scale-95 ${
              isSameTypeMode
                ? 'bg-red-950/60 text-red-300 border border-red-500/50 shadow-sm'
                : 'bg-white/5 text-neutral-400 hover:text-white'
            }`}
            title="Click to cycle YouTube Music Vibe Tuner (Same wave, different songs)"
          >
            <Radio className={`w-3.5 h-3.5 ${isSameTypeMode ? 'text-red-500 animate-pulse' : ''}`} />
            <span>
              {vibeMode === 'same-wave'
                ? '🌊 Same Wave: Diverse'
                : vibeMode === 'discover-different'
                ? '✨ Fresh Artists'
                : vibeMode === 'chill'
                ? '🌙 Chill Wave'
                : vibeMode === 'upbeat'
                ? '⚡ Fast Wave'
                : '🎤 Same Artist'}
            </span>
          </button>
        </div>
      </div>

      {/* Main YouTube Search Input Bar */}
      <div className="mb-4">
        <div className="relative flex items-center max-w-3xl">
          <Search className="absolute left-4 w-5 h-5 text-neutral-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Search ANY song, movie, artist, Hindi, Punjabi, English, Bhojpuri on YouTube..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && query) {
                saveRecentSearch(query);
              }
            }}
            className="w-full bg-[#181818] hover:bg-[#202020] text-white text-sm sm:text-base rounded-full pl-12 pr-28 py-3.5 border border-white/10 focus:border-red-500 focus:outline-none transition shadow-xl placeholder:text-neutral-500"
          />

          <div className="absolute right-3.5 flex items-center gap-1.5">
            {isSearchingYT && (
              <Loader2 className="w-4 h-4 text-red-500 animate-spin mr-1" />
            )}

            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="text-neutral-400 hover:text-white p-1 rounded-full cursor-pointer transition"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={handleVoiceSearch}
              className={`p-1.5 rounded-full transition cursor-pointer ${
                isVoiceListening
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title="Voice Search on YouTube"
            >
              <Mic className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/5 mb-5 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-2 py-1">
          {[
            'All YouTube',
            'Bollywood',
            'Punjabi',
            'Pop Hits',
            'Hip-Hop',
            'Lo-Fi',
            'Bhojpuri',
            'South Indian',
            'Devotional'
          ].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setActiveTab(cat);
                if (cat !== 'All YouTube') {
                  onSearchChange(cat);
                  saveRecentSearch(cat);
                }
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition cursor-pointer ${
                activeTab === cat
                  ? 'bg-white text-black shadow-md'
                  : 'bg-white/10 hover:bg-white/20 text-neutral-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowYtInput(!showYtInput)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold text-neutral-300 hover:text-white transition cursor-pointer shrink-0"
        >
          <LinkIcon className="w-3.5 h-3.5 text-red-500" />
          <span>Paste YouTube URL</span>
        </button>
      </div>

      {/* Paste YouTube URL Modal / Drawer */}
      {showYtInput && (
        <form
          onSubmit={handlePlayCustomYT}
          className="mb-6 p-4 rounded-2xl bg-[#181818] border border-red-500/30 flex items-center gap-2 shadow-xl"
        >
          <input
            type="text"
            placeholder="Paste any YouTube video link (e.g. https://www.youtube.com/watch?v=... or youtu.be/...)"
            value={customYtInput}
            onChange={(e) => setCustomYtInput(e.target.value)}
            className="flex-1 bg-black/60 text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 border border-white/20 focus:border-red-500 focus:outline-none"
          />
          <button
            type="submit"
            className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer shrink-0"
          >
            Play Video/Audio
          </button>
        </form>
      )}

      {/* Search Query Results View */}
      {query.length > 0 ? (
        <div className="space-y-6">
          {/* Universal Play on YouTube Card */}
          <div
            onClick={handlePlayDynamicSearch}
            className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-red-950/50 via-[#181818] to-neutral-900 border border-red-500/40 hover:border-red-500/70 transition cursor-pointer group shadow-xl"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-12 h-12 rounded-xl bg-red-600/30 flex items-center justify-center shrink-0 border border-red-500/40 group-hover:scale-105 transition">
                <Youtube className="w-6 h-6 text-red-500 group-hover:text-white transition" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-400">
                  YouTube Music Official Stream
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white truncate">
                  Play &ldquo;{searchQuery}&rdquo; on YouTube Music
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5 truncate">
                  Continuous autoplay & same-vibe streaming ready
                </p>
              </div>
            </div>

            <button className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-red-600 text-white text-xs font-bold hover:bg-red-500 shadow-lg shadow-red-600/30 transition shrink-0 ml-2">
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Play Now</span>
            </button>
          </div>

          {/* Official YouTube Channel Card (If artist matched) */}
          {matchingArtists.length > 0 && (
            <div className="p-4 sm:p-5 rounded-2xl bg-[#141414] border border-white/10 shadow-lg">
              {matchingArtists.slice(0, 1).map((artist) => {
                const isSubscribed = subscribedArtists.has(artist.id);
                return (
                  <div key={artist.id}>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
                      <div className="flex items-center gap-4 min-w-0">
                        <img
                          src={artist.avatarUrl}
                          alt={artist.name}
                          className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover shadow-md ring-2 ring-white/10 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h2 className="text-lg sm:text-xl font-bold text-white truncate">
                              {artist.name}
                            </h2>
                            <CheckCircle className="w-4 h-4 text-neutral-400 fill-neutral-400 text-black shrink-0" />
                          </div>
                          <p className="text-xs text-neutral-400 mt-0.5">
                            @{artist.name.replace(/\s+/g, '')} • {artist.subscribers} subscribers • Official Channel
                          </p>
                          <p className="text-xs text-neutral-400 line-clamp-1 mt-1 hidden sm:block">
                            {artist.bio}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => toggleSubscribe(artist.id)}
                        className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition cursor-pointer shadow ${
                          isSubscribed
                            ? 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                            : 'bg-white text-black hover:bg-neutral-200'
                        }`}
                      >
                        <Bell className={`w-3.5 h-3.5 ${isSubscribed ? 'fill-current' : ''}`} />
                        <span>{isSubscribed ? 'Subscribed' : 'Subscribe'}</span>
                      </button>
                    </div>

                    {/* Artist Top Songs Row */}
                    <div className="mt-3">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 mb-2">
                        Top Tracks
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {artist.topSongs.slice(0, 4).map((s) => (
                          <div
                            key={s.id}
                            onClick={() => {
                              saveRecentSearch(s.title);
                              playSong(s, artist.topSongs);
                            }}
                            className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-white/10 transition cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img
                                src={s.coverUrl}
                                alt={s.title}
                                className="w-10 h-10 rounded-lg object-cover shrink-0"
                              />
                              <div className="min-w-0">
                                <p className="text-xs font-semibold text-white truncate">{s.title}</p>
                                <p className="text-[11px] text-neutral-400 truncate">{s.genre} • {formatTime(s.duration)}</p>
                              </div>
                            </div>
                            <Play className="w-4 h-4 text-neutral-400 hover:text-white shrink-0 ml-2" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* YouTube Search Results List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-2">
                <Youtube className="w-4 h-4 text-red-500" />
                <span>YouTube Music Tracks ({displaySongs.length})</span>
              </h3>
              <span className="text-[11px] text-neutral-500">Live YouTube Index</span>
            </div>

            {isSearchingYT ? (
              <div className="flex flex-col items-center justify-center py-12 bg-[#121212] rounded-2xl border border-white/5 p-6">
                <Loader2 className="w-8 h-8 text-red-500 animate-spin mb-2" />
                <p className="font-semibold text-white">Searching YouTube Music...</p>
                <p className="text-xs text-neutral-400 mt-1">Fetching live songs from YouTube for &ldquo;{query}&rdquo;</p>
              </div>
            ) : displaySongs.length === 0 ? (
              <div className="text-center py-12 bg-[#121212] rounded-2xl border border-white/5 p-6">
                <Search className="w-10 h-10 mx-auto mb-2 text-neutral-600" />
                <p className="font-semibold text-white">No results found for &ldquo;{query}&rdquo;</p>
                <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
                  Click the <strong>Play on YouTube Music</strong> card above to stream any song on demand!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {displaySongs.map((song) => {
                  const isThisPlaying = currentSong?.id === song.id && isPlaying;
                  const isLiked = likedSongIds.has(song.id);
                  const isDownloaded = downloadedSongIds.has(song.id);

                  return (
                    <div
                      key={song.id}
                      onClick={() => {
                        saveRecentSearch(song.title);
                        playSong(song, displaySongs);
                      }}
                      className={`group flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3 rounded-2xl border transition cursor-pointer ${
                        isThisPlaying
                          ? 'bg-red-950/30 border-red-500/40 shadow-lg'
                          : 'bg-[#141414] hover:bg-[#1c1c1c] border-white/5 hover:border-white/15'
                      }`}
                    >
                      {/* 16:9 YouTube Video Thumbnail with Duration Badge */}
                      <div className="relative w-full sm:w-48 aspect-video rounded-xl overflow-hidden bg-neutral-900 shrink-0 shadow">
                        <img
                          src={song.coverUrl}
                          alt={song.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        />

                        {/* YouTube Duration Badge in bottom-right */}
                        <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-md text-[10px] font-bold text-white tracking-wide">
                          {formatTime(song.duration)}
                        </span>

                        {/* Red Play Overlay on Hover */}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                          <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                            <Play className="w-5 h-5 fill-white ml-0.5" />
                          </div>
                        </div>

                        {isThisPlaying && (
                          <div className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full bg-red-600 text-[10px] font-bold text-white flex items-center gap-1 shadow">
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                            <span>PLAYING</span>
                          </div>
                        )}
                      </div>

                      {/* Video Details Column - Pure YouTube Music Style (No View Count) */}
                      <div className="flex-1 min-w-0 pr-2">
                        <h4 className={`text-sm sm:text-base font-bold leading-snug line-clamp-2 ${isThisPlaying ? 'text-red-400' : 'text-white group-hover:text-red-400'} transition`}>
                          {song.title}
                        </h4>

                        <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-1 flex-wrap">
                          <span className="font-semibold text-neutral-300 hover:text-white transition flex items-center gap-1">
                            {song.artist}
                            <CheckCircle className="w-3.5 h-3.5 text-neutral-400 fill-neutral-400 text-black inline" />
                          </span>
                          <span>•</span>
                          <span>{song.album || 'YouTube Music'}</span>
                          <span>•</span>
                          <span>{formatTime(song.duration)}</span>
                        </div>

                        <div className="flex items-center gap-2 mt-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 text-neutral-300 uppercase tracking-wide">
                            {song.genre}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-red-950/40 text-red-400 border border-red-500/20">
                            Same Vibe Radio
                          </span>
                        </div>
                      </div>

                      {/* Right Action Icons */}
                      <div className="flex items-center gap-1 sm:gap-1.5 ml-auto sm:ml-0 shrink-0 self-end sm:self-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            startVibeRadio(song, vibeMode);
                          }}
                          className="p-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-red-400 transition cursor-pointer"
                          title="Start Radio (Same Wave, Different Songs)"
                        >
                          <Radio className="w-4 h-4" />
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            addToQueue(song);
                          }}
                          className="p-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
                          title="Add to Up Next Queue"
                        >
                          <ListPlus className="w-4 h-4" />
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleDownload(song.id);
                          }}
                          className="p-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
                          title={isDownloaded ? 'Downloaded' : 'Download'}
                        >
                          <Download className={`w-4 h-4 ${isDownloaded ? 'text-emerald-400' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLike(song.id);
                          }}
                          className="p-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
                          title={isLiked ? 'Liked' : 'Like'}
                        >
                          <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-600 text-red-600' : ''}`} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Default Trending YouTube Music Searches + Recent Searches */
        <div className="space-y-6">
          {/* Recent Searches Row */}
          {recentSearches.length > 0 && (
            <div className="p-4 rounded-2xl bg-[#141414] border border-white/5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-neutral-400">
                  <Clock className="w-4 h-4 text-neutral-400" />
                  <span>Recent Searches</span>
                </div>
                <button
                  onClick={clearAllRecent}
                  className="text-xs text-neutral-500 hover:text-red-400 transition cursor-pointer"
                >
                  Clear all
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {recentSearches.map((term, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      onSearchChange(term);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-neutral-300 hover:text-white transition cursor-pointer group"
                  >
                    <Search className="w-3 h-3 text-neutral-500 group-hover:text-red-400" />
                    <span>{term}</span>
                    <button
                      onClick={(e) => removeRecentSearch(term, e)}
                      className="p-0.5 rounded-full text-neutral-500 hover:text-white ml-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Search Chips / Presets */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-4 h-4 text-red-500" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                Popular on YouTube Music
              </h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {SEARCH_PRESETS.map((term) => (
                <button
                  key={term}
                  onClick={() => {
                    saveRecentSearch(term);
                    onSearchChange(term);
                  }}
                  className="px-3 py-1.5 rounded-full text-xs font-medium bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition cursor-pointer flex items-center gap-1.5"
                >
                  <Search className="w-3 h-3 text-neutral-400" />
                  <span>{term}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Trending Searches Grid */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-red-500" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-neutral-300">
                Top Trending Tracks
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {INITIAL_SONGS.slice(0, 9).map((song) => (
                <div
                  key={song.id}
                  onClick={() => {
                    saveRecentSearch(song.title);
                    playSong(song, INITIAL_SONGS);
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl bg-[#141414] hover:bg-[#1e1e1e] border border-white/5 transition cursor-pointer group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-12 h-12 rounded-xl object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-white truncate group-hover:text-red-400 transition">
                        {song.title}
                      </p>
                      <p className="text-xs text-neutral-400 truncate">{song.artist}</p>
                    </div>
                  </div>
                  <Play className="w-4 h-4 text-neutral-400 group-hover:text-white group-hover:scale-110 transition shrink-0 ml-2" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
