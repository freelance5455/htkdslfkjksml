import React, { useState, useEffect, useMemo } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Song, Playlist } from '../../types/music';
import { INITIAL_SONGS, MOOD_CATEGORIES, INITIAL_ARTISTS } from '../../data/musicCatalog';
import { formatTime } from '../../utils/formatTime';
import {
  Play,
  Flame,
  Sparkles,
  Heart,
  ChevronRight,
  Music,
  Radio,
  RotateCw,
  Clock,
  Disc3,
  CheckCircle,
  Volume2
} from 'lucide-react';

interface HomeViewProps {
  onSelectPlaylist: (playlistId: string) => void;
  onSelectTab: (tab: string) => void;
}

// Utility to shuffle an array with a fresh random seed
function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export const HomeView: React.FC<HomeViewProps> = ({ onSelectPlaylist, onSelectTab }) => {
  const {
    playSong,
    currentSong,
    isPlaying,
    likedSongIds,
    toggleLike,
    playlists,
    startVibeRadio,
    vibeMode
  } = useMusic();

  const [selectedMood, setSelectedMood] = useState('all');
  const [refreshSeed, setRefreshSeed] = useState(0);

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  // Every time the app opens or the user clicks "Refresh", generate dynamic fresh selections!
  const shuffledCatalog = useMemo(() => {
    return shuffleArray(INITIAL_SONGS);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshSeed]);

  // Quick picks: 8 dynamic tracks from diverse artists and genres
  const dynamicQuickPicks = useMemo(() => {
    if (selectedMood === 'all') {
      return shuffledCatalog.slice(0, 8);
    }
    const filtered = INITIAL_SONGS.filter(
      (s) => s.mood.toLowerCase() === selectedMood.toLowerCase()
    );
    return shuffleArray(filtered).slice(0, 8);
  }, [shuffledCatalog, selectedMood]);

  // Shelves: Same Vibe, but Different Songs and Different Artists
  const vibeShelves = useMemo(() => {
    const bollywoodRomantic = INITIAL_SONGS.filter(
      (s) => s.genre === 'Bollywood' && (s.mood === 'Relax' || s.mood === 'Focus')
    );
    const punjabiEnergy = INITIAL_SONGS.filter(
      (s) => s.genre === 'Punjabi' || (s.genre === 'Hip-Hop' && s.mood === 'Energize')
    );
    const globalPop = INITIAL_SONGS.filter(
      (s) => s.genre === 'Pop' || s.genre === 'Synthwave'
    );
    const chillLofi = INITIAL_SONGS.filter(
      (s) => s.genre === 'Lo-Fi' || s.genre === 'Acoustic'
    );
    const southModern = INITIAL_SONGS.filter(
      (s) =>
        s.title.toLowerCase().includes('chuttamalle') ||
        s.title.toLowerCase().includes('illuminati') ||
        s.artist.toLowerCase().includes('anirudh') ||
        s.artist.toLowerCase().includes('sushin') ||
        s.genre === 'South Indian'
    );

    return [
      {
        id: 'vibe-bollywood',
        title: 'Same Vibe: Bollywood Romance & Soul',
        subtitle: 'Warm acoustic melodies • Different songs & artists',
        badge: 'Romantic Wave',
        color: 'from-amber-600/30 to-rose-600/20',
        songs: shuffleArray(bollywoodRomantic)
      },
      {
        id: 'vibe-punjabi',
        title: 'Same Vibe: Punjabi Energy & Bangers',
        subtitle: 'High energy party rhythm • Different artists & tracks',
        badge: 'Banger Wave',
        color: 'from-orange-600/30 to-red-600/20',
        songs: shuffleArray(punjabiEnergy)
      },
      {
        id: 'vibe-pop',
        title: 'Same Vibe: Global Synth & Pop Wave',
        subtitle: 'Late-night driving rhythm • Different chart hits',
        badge: 'Pop Wave',
        color: 'from-purple-600/30 to-indigo-600/20',
        songs: shuffleArray(globalPop)
      },
      {
        id: 'vibe-lofi',
        title: 'Same Vibe: Late Night Chill & Lo-Fi Beats',
        subtitle: 'Soothing instrumentals • Different relaxing artists',
        badge: 'Chill Wave',
        color: 'from-teal-600/30 to-emerald-600/20',
        songs: shuffleArray(chillLofi)
      },
      {
        id: 'vibe-south',
        title: 'Same Vibe: Modern Cinema Club & Fusion',
        subtitle: 'Electrifying beats & hooks • Different composers',
        badge: 'Cinema Wave',
        color: 'from-rose-600/30 to-amber-600/20',
        songs: southModern.length > 0 ? shuffleArray(southModern) : shuffleArray(INITIAL_SONGS).slice(0, 5)
      }
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshSeed]);

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-5 max-w-6xl mx-auto w-full text-white select-none pb-28 md:pb-20">
      {/* Mood Filter Chips */}
      <div className="flex items-center justify-between gap-2 pb-3 overflow-x-auto scrollbar-none border-b border-white/5">
        <div className="flex items-center gap-2">
          {MOOD_CATEGORIES.map((cat) => {
            const isSelected = selectedMood === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedMood(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition cursor-pointer active:scale-95 ${
                  isSelected
                    ? 'bg-white text-black shadow-md font-bold'
                    : 'bg-white/10 hover:bg-white/20 text-neutral-300'
                }`}
              >
                <span>{cat.emoji}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Refresh Picks Button (Changes the screen songs instantly like YT Music) */}
        <button
          onClick={() => setRefreshSeed((s) => s + 1)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white border border-white/10 text-xs font-semibold shrink-0 transition cursor-pointer active:scale-95"
          title="Show different songs on screen"
        >
          <RotateCw className="w-3.5 h-3.5 text-red-500" />
          <span className="hidden sm:inline">Refresh Recommendations</span>
          <span className="sm:hidden">Refresh</span>
        </button>
      </div>

      {/* Greeting Header */}
      <div className="flex items-center justify-between mt-5 mb-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight font-['YouTube_Sans',sans-serif]">
            {greeting()}
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Same-vibe continuous playback • High-res audio album covers & lyrics
          </p>
        </div>
      </div>

      {/* Quick Picks 4x2 Grid (Dynamic songs on each app open) */}
      <div className="mb-7">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-red-500" />
            <h2 className="text-base font-bold text-white tracking-wide">Quick Picks For You</h2>
          </div>
          <span className="text-[11px] text-neutral-400">Rotates every session</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {dynamicQuickPicks.map((song) => {
            const isThisPlaying = currentSong?.id === song.id && isPlaying;
            return (
              <div
                key={song.id}
                onClick={() => playSong(song, dynamicQuickPicks)}
                className={`group flex items-center justify-between p-2.5 rounded-xl border transition cursor-pointer ${
                  isThisPlaying
                    ? 'bg-red-950/40 border-red-500/50 shadow-lg shadow-red-950/30'
                    : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-white/15'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-neutral-800 shadow">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                      <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                    </div>
                  </div>
                  <div className="min-w-0">
                    <p className={`text-sm font-bold truncate leading-tight ${isThisPlaying ? 'text-red-400' : 'text-white'}`}>
                      {song.title}
                    </p>
                    <p className="text-xs text-neutral-400 truncate mt-0.5">
                      {song.artist}
                    </p>
                    <p className="text-[10px] text-neutral-500 truncate mt-0.5">
                      {song.album} • {formatTime(song.duration)}
                    </p>
                  </div>
                </div>

                {isThisPlaying ? (
                  <div className="shrink-0 flex items-end gap-1 pr-2 h-4" title="Now playing">
                    <span className="w-1 h-3.5 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.6s' }} />
                    <span className="w-1 h-2 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.4s' }} />
                    <span className="w-1 h-4 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.8s' }} />
                  </div>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      startVibeRadio(song, 'same-wave');
                    }}
                    className="p-2 rounded-full text-neutral-500 hover:text-red-400 hover:bg-white/10 opacity-0 group-hover:opacity-100 transition"
                    title="Play Same Vibe Radio"
                  >
                    <Radio className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* "Same Vibe, Different Songs" Shelves */}
      <div className="space-y-8 mb-8">
        {vibeShelves.map((shelf) => {
          if (!shelf.songs || shelf.songs.length === 0) return null;
          return (
            <div key={shelf.id} className="pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                      {shelf.title}
                    </h2>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-950/60 text-red-300 border border-red-500/30">
                      {shelf.badge}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {shelf.subtitle}
                  </p>
                </div>

                {/* Play Full Vibe Radio Button */}
                <button
                  onClick={() => {
                    startVibeRadio(shelf.songs[0], 'same-wave');
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-red-600 text-xs font-semibold text-neutral-200 hover:text-white transition cursor-pointer self-start sm:self-auto shrink-0 shadow-sm active:scale-95"
                >
                  <Radio className="w-3.5 h-3.5 text-red-500 group-hover:text-white" />
                  <span>Play Vibe Radio</span>
                </button>
              </div>

              {/* Horizontal Scrollable Carousel of Different Songs in this Vibe */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
                {shelf.songs.slice(0, 5).map((song) => {
                  const isThisPlaying = currentSong?.id === song.id && isPlaying;
                  const isLiked = likedSongIds.has(song.id);
                  return (
                    <div
                      key={song.id}
                      onClick={() => playSong(song, shelf.songs)}
                      className={`group p-3 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                        isThisPlaying
                          ? 'bg-red-950/40 border-red-500/50 shadow-md'
                          : 'bg-[#141414] hover:bg-[#1a1a1a] border-white/5 hover:border-white/15'
                      }`}
                    >
                      {/* Album Cover with Play Overlay */}
                      <div className="relative aspect-square rounded-xl overflow-hidden mb-2.5 bg-neutral-900 shadow">
                        <img
                          src={song.coverUrl}
                          alt={song.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            playSong(song, shelf.songs);
                          }}
                          className="absolute bottom-2 right-2 w-9 h-9 rounded-full bg-red-600 text-white flex items-center justify-center shadow-xl opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all hover:scale-110 active:scale-95"
                        >
                          <Play className="w-4 h-4 fill-white ml-0.5" />
                        </button>

                        {isThisPlaying && (
                          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-red-600 text-[9px] font-bold text-white flex items-center gap-1 shadow">
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                            <span>PLAYING</span>
                          </div>
                        )}
                      </div>

                      {/* Song Title and Artist (Different artists each card) */}
                      <div className="min-w-0">
                        <h4 className={`font-bold text-xs sm:text-sm truncate leading-snug ${isThisPlaying ? 'text-red-400' : 'text-white group-hover:text-red-400'} transition`}>
                          {song.title}
                        </h4>
                        <p className="text-xs text-neutral-400 truncate mt-0.5">
                          {song.artist}
                        </p>
                        <p className="text-[10px] text-neutral-500 truncate mt-1">
                          {song.album} • {formatTime(song.duration)}
                        </p>
                      </div>

                      {/* Footer Actions */}
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                        <span className="text-[10px] font-semibold text-neutral-400">
                          {song.genre}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLike(song.id);
                          }}
                          className="p-1 text-neutral-400 hover:text-white transition"
                        >
                          <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-red-600 text-red-600' : ''}`} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Featured Playlists Carousel */}
      <div className="mb-8 pt-4 border-t border-white/5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xl font-bold tracking-tight">Curated YouTube Music Mixes</h2>
          <button
            onClick={() => onSelectTab('explore')}
            className="text-xs font-semibold text-neutral-400 hover:text-white flex items-center gap-1 transition"
          >
            <span>See all</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {playlists.slice(0, 4).map((pl) => (
            <div
              key={pl.id}
              onClick={() => {
                onSelectPlaylist(pl.id);
                onSelectTab('playlist-detail');
              }}
              className="group p-3 rounded-2xl bg-[#141414] hover:bg-[#1a1a1a] border border-white/5 hover:border-white/15 transition cursor-pointer"
            >
              <div className="relative aspect-square rounded-xl overflow-hidden mb-3 bg-neutral-800 shadow-md">
                <img
                  src={pl.coverUrl}
                  alt={pl.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (pl.songs.length > 0) playSong(pl.songs[0], pl.songs);
                  }}
                  className="absolute bottom-2.5 right-2.5 w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center shadow-xl opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all hover:scale-105 active:scale-95"
                >
                  <Play className="w-5 h-5 fill-white ml-0.5" />
                </button>
              </div>

              <h3 className="font-bold text-sm text-white truncate leading-tight">
                {pl.title}
              </h3>
              <p className="text-xs text-neutral-400 truncate mt-1">
                {pl.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Artists Banner */}
      <div className="pt-6 border-t border-white/5">
        <h2 className="text-xl font-bold tracking-tight mb-4">Official Channels</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {INITIAL_ARTISTS.map((artist) => (
            <div
              key={artist.id}
              onClick={() => {
                if (artist.topSongs.length > 0) {
                  playSong(artist.topSongs[0], artist.topSongs);
                }
              }}
              className="flex flex-col items-center text-center p-4 rounded-2xl bg-[#141414] hover:bg-[#1a1a1a] border border-white/5 transition cursor-pointer group"
            >
              <img
                src={artist.avatarUrl}
                alt={artist.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover mb-3 shadow-lg group-hover:scale-105 transition"
              />
              <div className="flex items-center gap-1 justify-center w-full">
                <h4 className="font-bold text-sm text-white truncate">{artist.name}</h4>
                <CheckCircle className="w-3.5 h-3.5 text-neutral-400 fill-neutral-400 text-black shrink-0" />
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">{artist.subscribers} Subscribers</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (artist.topSongs.length > 0) startVibeRadio(artist.topSongs[0]);
                }}
                className="mt-3 px-3 py-1 rounded-full bg-white/10 hover:bg-red-600 hover:text-white text-xs font-semibold transition"
              >
                Play Radio
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
