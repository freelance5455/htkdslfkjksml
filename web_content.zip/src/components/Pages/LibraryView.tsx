import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { INITIAL_SONGS } from '../../data/musicCatalog';
import { formatTime } from '../../utils/formatTime';
import {
  Library,
  Heart,
  Download,
  Plus,
  Play,
  Clock,
  Music2,
  Trash2,
  CheckCircle2,
  FolderPlus
} from 'lucide-react';

interface LibraryViewProps {
  onSelectPlaylist: (playlistId: string) => void;
  onSelectTab: (tab: string) => void;
  onOpenCreatePlaylist: () => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  onSelectPlaylist,
  onSelectTab,
  onOpenCreatePlaylist,
}) => {
  const {
    playlists,
    likedSongIds,
    downloadedSongIds,
    historySongIds,
    playSong,
    toggleLike,
    toggleDownload,
  } = useMusic();

  const [activeFilter, setActiveFilter] = useState<'all' | 'playlists' | 'liked' | 'downloads' | 'history'>('all');

  const likedSongs = INITIAL_SONGS.filter((s) => likedSongIds.has(s.id));
  const downloadedSongs = INITIAL_SONGS.filter((s) => downloadedSongIds.has(s.id));
  const historySongs = historySongIds
    .map((id) => INITIAL_SONGS.find((s) => s.id === id))
    .filter(Boolean) as typeof INITIAL_SONGS;

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 max-w-6xl mx-auto w-full text-white select-none pb-28 md:pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-lg">
            <Library className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Your Library</h1>
            <p className="text-xs sm:text-sm text-neutral-400 mt-0.5">
              Saved music, offline downloads, custom playlists, and listening history.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenCreatePlaylist}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-semibold transition cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Playlist</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto py-4 scrollbar-none">
        {[
          { id: 'all', label: 'All Library' },
          { id: 'playlists', label: `Playlists (${playlists.length})` },
          { id: 'liked', label: `Liked Songs (${likedSongIds.size})` },
          { id: 'downloads', label: `Downloads (${downloadedSongIds.size})` },
          { id: 'history', label: 'History' },
        ].map((tab) => {
          const isActive = activeFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as typeof activeFilter)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition cursor-pointer ${
                isActive
                  ? 'bg-white text-black shadow-md'
                  : 'bg-white/10 hover:bg-white/20 text-neutral-300'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* SECTION 1: LIKED SONGS & DOWNLOADS HERO CARDS */}
      {(activeFilter === 'all' || activeFilter === 'liked' || activeFilter === 'downloads') && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-4">
          {/* Liked Songs Hero Card */}
          {(activeFilter === 'all' || activeFilter === 'liked') && (
            <div
              onClick={() => {
                if (likedSongs.length > 0) playSong(likedSongs[0], likedSongs);
              }}
              className="p-5 rounded-3xl bg-gradient-to-br from-indigo-900/50 via-purple-950/40 to-neutral-900 border border-indigo-500/20 hover:border-indigo-500/40 transition cursor-pointer group shadow-xl"
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg">
                  <Heart className="w-6 h-6 fill-white" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-lg group-hover:scale-110 active:scale-95 transition">
                  <Play className="w-5 h-5 fill-black ml-0.5" />
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-xl font-bold text-white">Liked Music</h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Auto-playlist • {likedSongIds.size} tracks saved
                </p>
              </div>
            </div>
          )}

          {/* Offline Downloads Hero Card */}
          {(activeFilter === 'all' || activeFilter === 'downloads') && (
            <div
              onClick={() => {
                if (downloadedSongs.length > 0) playSong(downloadedSongs[0], downloadedSongs);
              }}
              className="p-5 rounded-3xl bg-gradient-to-br from-emerald-950/50 via-teal-950/40 to-neutral-900 border border-emerald-500/20 hover:border-emerald-500/40 transition cursor-pointer group shadow-xl"
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg">
                  <Download className="w-6 h-6" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-lg group-hover:scale-110 active:scale-95 transition">
                  <Play className="w-5 h-5 fill-black ml-0.5" />
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-xl font-bold text-white">Offline Downloads</h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Cached in browser storage • Plays without internet • {downloadedSongIds.size} songs
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: USER PLAYLISTS */}
      {(activeFilter === 'all' || activeFilter === 'playlists') && (
        <div className="mt-8">
          <h2 className="text-xl font-bold tracking-tight mb-4">Your Playlists</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {playlists.map((pl) => (
              <div
                key={pl.id}
                onClick={() => {
                  onSelectPlaylist(pl.id);
                  onSelectTab('playlist-detail');
                }}
                className="group p-3 rounded-2xl bg-[#141414] hover:bg-[#1a1a1a] border border-white/5 hover:border-white/15 transition cursor-pointer"
              >
                <div className="relative aspect-square rounded-xl overflow-hidden mb-3 bg-neutral-800">
                  <img
                    src={pl.coverUrl}
                    alt={pl.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                    <Play className="w-8 h-8 fill-white text-white" />
                  </div>
                </div>
                <h3 className="font-bold text-sm text-white truncate">{pl.title}</h3>
                <p className="text-xs text-neutral-400 truncate mt-0.5">
                  Playlist • {pl.songs.length} songs
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 3: LISTENING HISTORY */}
      {(activeFilter === 'all' || activeFilter === 'history') && historySongs.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-4 h-4 text-neutral-400" />
            <h2 className="text-xl font-bold tracking-tight">Recently Played</h2>
          </div>
          <div className="divide-y divide-white/5 bg-[#121212] rounded-2xl border border-white/5 overflow-hidden">
            {historySongs.map((song) => (
              <div
                key={`history-${song.id}`}
                onClick={() => playSong(song)}
                className="flex items-center justify-between p-3 hover:bg-white/5 transition cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={song.coverUrl}
                    alt={song.title}
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{song.title}</p>
                    <p className="text-xs text-neutral-400 truncate">{song.artist}</p>
                  </div>
                </div>
                <span className="text-xs text-neutral-500">{formatTime(song.duration)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
