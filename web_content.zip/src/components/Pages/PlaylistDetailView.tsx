import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { formatTime } from '../../utils/formatTime';
import {
  Play,
  Shuffle,
  Heart,
  Download,
  Trash2,
  Clock,
  ArrowLeft,
  Share2,
  CheckCircle2
} from 'lucide-react';

interface PlaylistDetailViewProps {
  playlistId: string;
  onBack: () => void;
}

export const PlaylistDetailView: React.FC<PlaylistDetailViewProps> = ({ playlistId, onBack }) => {
  const {
    playlists,
    playSong,
    currentSong,
    isPlaying,
    likedSongIds,
    toggleLike,
    downloadedSongIds,
    toggleDownload,
    removeSongFromPlaylist,
  } = useMusic();

  const playlist = playlists.find((p) => p.id === playlistId) || playlists[0];

  if (!playlist) {
    return (
      <div className="flex-1 p-8 text-center text-white">
        <p>Playlist not found.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-white/10 rounded-xl text-xs">
          Go Back
        </button>
      </div>
    );
  }

  const totalDuration = playlist.songs.reduce((acc, s) => acc + s.duration, 0);

  const handlePlayAll = () => {
    if (playlist.songs.length > 0) {
      playSong(playlist.songs[0], playlist.songs);
    }
  };

  const handleShuffle = () => {
    if (playlist.songs.length > 0) {
      const shuffled = [...playlist.songs].sort(() => Math.random() - 0.5);
      playSong(shuffled[0], shuffled);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 max-w-6xl mx-auto w-full text-white select-none pb-28 md:pb-20">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-neutral-400 hover:text-white mb-4 text-xs font-semibold cursor-pointer transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Library</span>
      </button>

      {/* Playlist Hero Header */}
      <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6 pb-8 border-b border-white/10">
        <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-3xl overflow-hidden shadow-2xl bg-neutral-800 shrink-0">
          <img
            src={playlist.coverUrl}
            alt={playlist.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex-1 text-center sm:text-left">
          <span className="text-xs font-bold uppercase tracking-wider text-red-500">
            Playlist
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 leading-tight">
            {playlist.title}
          </h1>
          <p className="text-sm text-neutral-400 mt-2 max-w-xl">
            {playlist.description}
          </p>
          <div className="flex items-center justify-center sm:justify-start gap-2 text-xs text-neutral-400 mt-3">
            <span>{playlist.songs.length} songs</span>
            <span>•</span>
            <span>{formatTime(totalDuration)} total length</span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-center sm:justify-start gap-3 mt-5">
            <button
              onClick={handlePlayAll}
              className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-lg shadow-red-600/30 transition cursor-pointer active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Play All</span>
            </button>

            <button
              onClick={handleShuffle}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition cursor-pointer active:scale-95"
            >
              <Shuffle className="w-4 h-4" />
              <span>Shuffle</span>
            </button>
          </div>
        </div>
      </div>

      {/* Song List */}
      <div className="mt-6 divide-y divide-white/5">
        {playlist.songs.map((song, idx) => {
          const isThisPlaying = currentSong?.id === song.id && isPlaying;
          const isLiked = likedSongIds.has(song.id);
          const isDownloaded = downloadedSongIds.has(song.id);

          return (
            <div
              key={`${song.id}-${idx}`}
              onClick={() => playSong(song, playlist.songs)}
              className="group flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition cursor-pointer"
            >
              <div className="flex items-center gap-4 min-w-0">
                <span className="text-xs font-bold text-neutral-500 w-4 text-center shrink-0">
                  {idx + 1}
                </span>

                <div className="relative w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-neutral-800">
                  <img
                    src={song.coverUrl}
                    alt={song.title}
                    className="w-full h-full object-cover"
                  />
                  {isThisPlaying && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    </div>
                  )}
                </div>

                <div className="min-w-0">
                  <p className={`text-sm font-semibold truncate leading-tight ${isThisPlaying ? 'text-red-500' : 'text-white'}`}>
                    {song.title}
                  </p>
                  <p className="text-xs text-neutral-400 truncate mt-0.5">
                    {song.artist} • {song.album}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleDownload(song.id);
                  }}
                  className="p-1.5 text-neutral-400 hover:text-white transition"
                  title={isDownloaded ? 'Downloaded' : 'Download Offline'}
                >
                  {isDownloaded ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleLike(song.id);
                  }}
                  className="p-1.5 text-neutral-400 hover:text-white transition"
                  title={isLiked ? 'Liked' : 'Like'}
                >
                  <Heart
                    className={`w-4 h-4 ${isLiked ? 'fill-red-600 text-red-600' : ''}`}
                  />
                </button>

                {playlist.isCustom && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSongFromPlaylist(playlist.id, song.id);
                    }}
                    className="p-1.5 text-neutral-500 hover:text-red-400 transition"
                    title="Remove from playlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                <span className="text-xs text-neutral-500 w-10 text-right">
                  {formatTime(song.duration)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
