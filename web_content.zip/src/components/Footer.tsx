import { Globe, MessageCircle, Play, ShieldCheck, Tv, X } from "lucide-react";
import Logo from "./Logo";

const COLS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Producto",
    links: [
      { label: "World TV", href: "#demo" }, { label: "Sports Center", href: "#demo" },
      { label: "Movies & Series", href: "#demo" }, { label: "Music · Radio", href: "#demo" },
      { label: "Games Hub", href: "#demo" }, { label: "TV LO3 Store", href: "#precios" }, { label: "TV LO3 AI", href: "#demo" },
    ],
  },
  {
    title: "Empresa",
    links: [
      { label: "Sobre TV LO3", href: "#ventajas" }, { label: "Hoja de ruta Android TV", href: "#faq" },
      { label: "Panel de desarrolladores", href: "#precios" }, { label: "Prensa y medios", href: "#opiniones" }, { label: "Empleo", href: "#faq" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Términos de servicio", href: "#faq" }, { label: "Política de privacidad", href: "#faq" },
      { label: "Cookies", href: "#faq" }, { label: "Licencias y avisos", href: "#faq" }, { label: "Reporte de contenido", href: "#faq" },
    ],
  },
  {
    title: "Soporte",
    links: [
      { label: "Centro de ayuda", href: "#faq" }, { label: "Guía de instalación APK", href: "#descargar" },
      { label: "Compatibilidad de mandos", href: "#faq" }, { label: "Estado del servicio", href: "#faq" }, { label: "Contacto 24/7", href: "#descargar" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/8 bg-[#05081f]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-3">
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
              El centro de entretenimiento panorámico 16:9 para tu Android. World TV, deportes en vivo,
              cine, música, radio y juegos — sin cajas, sin cables.
            </p>
            <div className="mt-5 flex items-center gap-2 text-xs font-semibold text-emerald-300">
              <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" /></span>
              Todos los sistemas operativos
            </div>
            <div className="mt-4 flex items-center gap-3">
              {[
                { icon: X, label: "TV LO3 en X" },
                { icon: Play, label: "TV LO3 en YouTube" },
                { icon: Tv, label: "TV LO3 en Twitch" },
                { icon: MessageCircle, label: "Comunidad Discord" },
              ].map(({ icon: Icon, label }) => (
                <a key={label} href="#inicio" aria-label={label} className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-all hover:border-cyanx/40 hover:text-cyanx">
                  <Icon size={17} strokeWidth={2} />
                </a>
              ))}
            </div>
          </div>
          {COLS.map((col) => (
            <nav key={col.title} className="lg:col-span-2" aria-label={col.title}>
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">{col.title}</p>
              <ul className="mt-3 space-y-2">
                {col.links.map((l) => (
                  <li key={l.label}><a href={l.href} className="text-sm text-slate-400 transition-colors hover:text-white">{l.label}</a></li>
                ))}
              </ul>
            </nav>
          ))}
          <div className="lg:col-span-1" />
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-white/8 pt-6 text-[11px] text-slate-500 sm:flex-row sm:items-center">
          <p>© 2026 TV LO3 Labs S.L. · Madrid, España · TV LO3 Ultimate Edition v3.2.1</p>
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5"><ShieldCheck size={13} className="text-emerald-400" /> Contenido 100% autorizado</span>
            <button className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 font-semibold text-slate-300 transition-colors hover:text-white" aria-label="Cambiar idioma">
              <Globe size={13} /> Español (ES)
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
