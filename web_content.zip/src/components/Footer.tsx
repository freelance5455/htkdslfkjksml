import { brand, footerLinks } from "../data/content";
import {
  LogoIcon,
  TwitterIcon,
  LinkedInIcon,
  GitHubIcon,
  YouTubeIcon,
} from "./icons";

const socials = [
  { label: "X (Twitter)", icon: TwitterIcon, href: "#" },
  { label: "LinkedIn", icon: LinkedInIcon, href: "#" },
  { label: "GitHub", icon: GitHubIcon, href: "#" },
  { label: "YouTube", icon: YouTubeIcon, href: "#" },
];

export function Footer() {
  return (
    <footer className="relative border-t border-white/8 bg-ink-950">
      <div className="mx-auto max-w-6xl px-4 pt-16 pb-8 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-6 lg:gap-8">
          {/* Brand column */}
          <div className="sm:col-span-2 lg:col-span-2">
            <a href="#hero" className="inline-flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-700 text-white">
                <LogoIcon size={20} />
              </span>
              <span className="text-lg font-semibold text-white">
                {brand.name}
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-ink-500">
              {brand.tagline}. The AI-native operations platform for teams who
              refuse to settle for busywork.
            </p>
            <div className="mt-6 flex gap-2">
              {socials.map(({ label, icon: Icon, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-ink-400 transition-all duration-300 hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {(
            [
              ["Product", footerLinks.product],
              ["Company", footerLinks.company],
              ["Resources", footerLinks.resources],
              ["Legal", footerLinks.legal],
            ] as const
          ).map(([title, links]) => (
            <div key={title}>
              <h3 className="text-sm font-semibold text-white">{title}</h3>
              <ul className="mt-4 space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-ink-500 transition-colors duration-200 hover:text-ink-200"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="mt-14 flex flex-col gap-6 rounded-2xl border border-white/8 bg-white/[0.03] p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
          <div>
            <h3 className="text-base font-semibold text-white">
              Stay in the flow
            </h3>
            <p className="mt-1 text-sm text-ink-500">
              Monthly product updates, playbooks, and ops insights. No spam.
            </p>
          </div>
          <form
            className="flex w-full max-w-md flex-col gap-2 sm:flex-row"
            onSubmit={(e) => e.preventDefault()}
          >
            <label htmlFor="email-newsletter" className="sr-only">
              Email address
            </label>
            <input
              id="email-newsletter"
              type="email"
              required
              placeholder="you@company.com"
              className="h-11 flex-1 rounded-full border border-white/10 bg-white/5 px-4 text-sm text-white placeholder:text-ink-600 outline-none transition-colors focus:border-brand-400/50 focus:bg-white/8"
            />
            <button type="submit" className="btn-primary !h-11 shrink-0">
              Subscribe
            </button>
          </form>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/8 pt-8 sm:flex-row">
          <p className="text-xs text-ink-600">
            © {new Date().getFullYear()} Cascade Labs, Inc. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-ink-600">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              All systems operational
            </span>
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">Made for operators everywhere</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
