import React from 'react';
import { useApp } from '../context/AppContext';
import {
  BookOpen,
  ShieldCheck,
  Award,
  CreditCard,
  PhoneCall,
  Mail,
  MapPin,
  ExternalLink,
  Lock
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActiveTab, setSelectedCategory, categories, showToast } = useApp();

  return (
    <footer className="bg-[#07111E] text-slate-300 border-t border-[#1E3E62] pt-12 pb-24 md:pb-12 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Top 4 Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 border-b border-slate-800">
          {/* Col 1: Brand & About */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-[#0B192C]">
                <BookOpen className="w-5 h-5 font-bold" />
              </div>
              <span className="font-extrabold text-base text-white tracking-tight">
                NEXA <span className="text-amber-400">EXAM BOOKS</span>
              </span>
            </div>

            <p className="text-slate-400 leading-relaxed text-xs">
              Premier mobile-first digital publishing house dedicated to government exam preparation in Northeast India and nationwide. High-yield syllabus coverage for Railway, Assam Police, ADRE, SSC, Banking, and Defence recruitment tests.
            </p>

            <div className="pt-2 flex items-center gap-2">
              <span className="inline-flex items-center gap-1 bg-slate-800/80 text-emerald-400 px-2.5 py-1 rounded-full text-[11px] font-semibold border border-slate-700">
                <ShieldCheck className="w-3.5 h-3.5" /> 100% Genuine Syllabus
              </span>
              <span className="inline-flex items-center gap-1 bg-slate-800/80 text-amber-400 px-2.5 py-1 rounded-full text-[11px] font-semibold border border-slate-700">
                <Lock className="w-3.5 h-3.5" /> 256-Bit SSL Checkout
              </span>
            </div>
          </div>

          {/* Col 2: Exam Categories */}
          <div className="lg:col-span-3 space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider text-amber-400">
              Exam Streams
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              {categories.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => {
                      setSelectedCategory(c.id);
                      setActiveTab('categories');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-left"
                  >
                    {c.name} ({c.count} Books)
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Quick Student Links */}
          <div className="lg:col-span-2 space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider text-amber-400">
              Quick Links
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li>
                <button
                  onClick={() => {
                    setActiveTab('free-pdfs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Free PDF Library
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('exam-updates');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Official Exam Updates
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('current-affairs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Current Affairs Digests
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('my-books');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  My Purchased Books
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('admin');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-amber-300 hover:text-amber-400 transition-colors text-left font-bold"
                >
                  Admin Console
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Support & Contact */}
          <div className="lg:col-span-3 space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider text-amber-400">
              Student Helpdesk
            </h4>
            <div className="space-y-2 text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>NEXA Publication Center, Lachit Nagar, Guwahati, Assam 781007</span>
              </p>
              <p className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>WhatsApp Helpline: +91 98640 12345</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                <span>contact@nexaexambooks.com</span>
              </p>
            </div>

            <div className="pt-2">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                Supported Indian Payment Rails:
              </span>
              <div className="flex items-center gap-2 text-slate-300 font-bold text-[11px]">
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">UPI</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">RuPay</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">NetBanking</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">Wallets</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Disclaimer & Copyright */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-slate-400 text-[11px]">
          <p>
            © 2026 NEXA EXAM BOOKS. All Rights Reserved. Built with pride for Indian civil & defence exam aspirants.
          </p>

          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                setActiveTab('profile');
              }}
              className="hover:text-amber-400"
            >
              Privacy Policy
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setActiveTab('profile');
              }}
              className="hover:text-amber-400"
            >
              Terms & Conditions
            </button>
            <span>•</span>
            <button
              onClick={() => {
                showToast('24-Hour Digital Download Refund Policy applies if files fail to render.', 'info');
              }}
              className="hover:text-amber-400"
            >
              Refund Policy
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
