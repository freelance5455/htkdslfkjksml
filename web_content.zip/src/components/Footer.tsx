import { IconLogo, IconGithub, IconHf, IconBolt, IconWifiOff, IconLayers } from "./Icons";

export default function Footer() {
  return (
    <footer className="relative border-t border-line bg-ink2/70">
      <div className="mx-auto max-w-7xl px-5 py-14">
        <div className="grid md:grid-cols-[1.3fr_1fr_1fr] gap-10">
          <div>
            <a href="#top" className="flex items-center gap-2.5 mb-4">
              <IconLogo size={30} />
              <span className="font-display font-bold tracking-wide text-[15px] text-snow">
                YUNO<span className="text-ember">AI</span>
              </span>
            </a>
            <p className="text-[13px] text-fog leading-relaxed max-w-sm">
              The offline AI game forge. Open weights from Hugging Face and GitHub, inference on your own
              silicon, exports you can keep forever. Built for people who think games should belong to
              their players.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {[
                { icon: <IconWifiOff size={11} />, label: "0 TELEMETRY" },
                { icon: <IconBolt size={11} />, label: "0 ACCOUNTS" },
                { icon: <IconLayers size={11} />, label: "0 CLOUD" },
              ].map((b) => (
                <span key={b.label} className="flex items-center gap-1.5 font-mono text-[9px] tracking-[0.18em] text-teal border border-teal/35 px-2 py-1 clip-tag">
                  {b.icon} {b.label}
                </span>
              ))}
            </div>
          </div>

          <div>
            <p className="font-mono text-[10px] tracking-[0.26em] text-fog mb-4">OPEN WEIGHTS</p>
            <ul className="space-y-2.5">
              {[
                { href: "https://huggingface.co", label: "Hugging Face Hub", icon: <IconHf size={14} /> },
                { href: "https://github.com", label: "GitHub Repositories", icon: <IconGithub size={14} /> },
                { href: "https://huggingface.co/models", label: "Model Catalog", icon: <IconLayers size={14} /> },
              ].map((l) => (
                <li key={l.label}>
                  <a href={l.href} target="_blank" rel="noreferrer" className="flex items-center gap-2.5 text-[13px] text-mist hover:text-ember transition-colors group">
                    <span className="text-fog group-hover:text-ember transition-colors">{l.icon}</span>
                    {l.label}
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all">
                      <path d="M7 17 17 7M9 7h8v8" />
                    </svg>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-mono text-[10px] tracking-[0.26em] text-fog mb-4">THE FORGE</p>
            <ul className="space-y-2.5">
              {[
                { href: "#models", label: "Model Deck" },
                { href: "#forge", label: "Game Forge" },
                { href: "#arcade", label: "Your Arcade" },
                { href: "#voice", label: "Voice Module" },
              ].map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-[13px] text-mist hover:text-ember transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-line flex flex-wrap items-center justify-between gap-4">
          <p className="font-mono text-[10px] tracking-[0.16em] text-fog/80">
            YUNOAI — RUNS ENTIRELY ON YOUR MACHINE. FORGED WITH OPEN WEIGHTS.
          </p>
          <p className="font-mono text-[10px] tracking-[0.16em] text-fog/60">
            yuno-core v2.4.1 · wasm/webgpu
          </p>
        </div>
      </div>
    </footer>
  );
}
