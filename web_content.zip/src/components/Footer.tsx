import React from 'react';
import { Shield, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { t } from '../utils/translations';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const tr = t[language];

  return (
    <footer className="text-center py-8 px-4 text-[#8ccbe9] border-t border-[#16365a] bg-[#050b16] mt-8 text-xs space-y-2">
      <div className="flex items-center justify-center gap-1.5 font-bold tracking-[3px] text-cyan-300">
        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
        <span>{tr.footerBrand}</span>
        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
      </div>

      <div className="text-[11px] text-slate-400 font-mono tracking-wider">
        {tr.footerSub}
      </div>

      <div className="pt-2 flex items-center justify-center gap-2 text-[10px] text-slate-500">
        <Shield className="w-3 h-3 text-cyan-500/70" />
        <span>Compliant with Pakistan Telecommunication Authority (PTA) 668 SIM Registration Guidelines</span>
      </div>
    </footer>
  );
};
