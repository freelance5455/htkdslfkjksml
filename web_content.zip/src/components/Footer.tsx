import React, { useState } from 'react';
import { Download, Laptop, Database, Check } from 'lucide-react';

interface FooterProps {
  onOpenWindowsGuide: () => void;
  onOpenBackup: () => void;
  onOpenRoomPlanner: () => void;
  onDownloadZip: () => void;
  onScrollToCatalog: () => void;
  onScrollToHeritage: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenWindowsGuide,
  onOpenBackup,
  onOpenRoomPlanner,
  onDownloadZip,
  onScrollToCatalog,
  onScrollToHeritage
}) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    // Save to local storage
    const existing = JSON.parse(localStorage.getItem('bue_newsletter') || '[]');
    localStorage.setItem('bue_newsletter', JSON.stringify([...existing, email.trim()]));
    setEmail('');
  };

  return (
    <footer className="bg-[#262320] text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-stone-800/80">
          {/* Brand Info */}
          <div className="md:col-span-4 space-y-4">
            <span className="font-serif text-2xl font-bold tracking-wider text-[#FAF8F5] block">
              BAIT UL UKASHA
            </span>
            <p className="text-stone-400 text-xs leading-relaxed max-w-sm">
              Heirloom home essentials, French Normandy flax linen, hand-thrown ceramics, and bespoke oud fragrances. Curated for timeless dwellings.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
              <button
                onClick={onDownloadZip}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded text-xs flex items-center gap-1.5 cursor-pointer border border-stone-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Source ZIP</span>
              </button>
              <button
                onClick={onOpenWindowsGuide}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded text-xs flex items-center gap-1.5 cursor-pointer border border-stone-700"
              >
                <Laptop className="w-3.5 h-3.5" />
                <span>Windows Instructions</span>
              </button>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-stone-200 font-semibold">Sanctuary</h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button onClick={onScrollToCatalog} className="hover:text-stone-100 cursor-pointer">
                  All Collections
                </button>
              </li>
              <li>
                <button onClick={onOpenRoomPlanner} className="hover:text-stone-100 cursor-pointer">
                  Room Planner & Sets
                </button>
              </li>
              <li>
                <button onClick={onScrollToHeritage} className="hover:text-stone-100 cursor-pointer">
                  Craft Heritage
                </button>
              </li>
              <li>
                <button onClick={onOpenBackup} className="hover:text-stone-100 cursor-pointer">
                  Offline Data Backup
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Care */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-stone-200 font-semibold">Service</h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>Cash on Delivery (COD)</li>
              <li>Direct Wire / Raast Transfer</li>
              <li>30-Day Pure Return Guarantee</li>
              <li>Zero Subscription Guarantee</li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-stone-200 font-semibold">
              The Sanctuary Journal
            </h4>
            <p className="text-xs text-stone-400">
              Receive seasonal lookbooks, private batch releases, and interior care guides.
            </p>
            {subscribed ? (
              <p className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium pt-1">
                <Check className="w-4 h-4" />
                <span>Thank you for joining our private registry.</span>
              </p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 pt-1">
                <input
                  type="email"
                  required
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-stone-800/80 border border-stone-700 text-white placeholder:text-stone-500 px-3 py-2 rounded text-xs flex-1 focus:outline-none focus:border-stone-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-stone-100 hover:bg-white text-stone-900 rounded text-xs font-semibold cursor-pointer transition-colors"
                >
                  Join
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 pt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>© 2026 Bait ul Ukasha Home Essentials. All rights reserved.</p>
          <div className="flex items-center gap-4 text-xs">
            <span>Client-side Storage</span>
            <span>·</span>
            <span>Zero Tracking</span>
            <span>·</span>
            <span>Free & Open Source</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
