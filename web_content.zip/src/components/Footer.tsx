import React from 'react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { 
  Phone, 
  MessageCircle, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  DownloadCloud, 
  Laptop, 
  Video, 
  Wrench,
  HelpCircle,
  Heart
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { shopSettings, language, t, setIsAdminModalOpen, setIsPWAGuideOpen, openServiceModal } = useApp();
  const { isInstallable, install, isInstalled } = usePWAInstall();

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      {/* Top Banner with PWA download callout */}
      <div className="bg-gradient-to-r from-blue-950/60 via-slate-900 to-blue-950/60 border-b border-slate-800/80 px-4 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <DownloadCloud className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">
                {t.pwaBanner.installTitle}
              </h4>
              <p className="text-xs text-slate-400 max-w-xl">
                {t.pwaBanner.installDesc}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isInstallable && !isInstalled && (
              <button
                onClick={install}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>{t.pwaBanner.installBtn}</span>
              </button>
            )}

            <button
              onClick={() => setIsPWAGuideOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-300 font-semibold text-xs border border-slate-700 transition flex items-center gap-1.5"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{t.pwaBanner.howToInstall}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600">
                <img src="/icon.svg" alt="A K Golu" className="h-7 w-7 object-contain" />
              </div>
              <span className="text-lg font-extrabold text-white">
                {shopSettings.shopName}
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              {t.footer.about}
            </p>

            <div className="pt-1 flex items-center gap-2">
              <button
                onClick={() => setIsAdminModalOpen(true)}
                className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-300 transition"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.admin.title}</span>
              </button>
            </div>
          </div>

          {/* Quick Categories */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              {t.footer.quickLinks}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#products" className="hover:text-blue-400 transition">
                  {t.categories.laptops_refurbished}
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-blue-400 transition">
                  {t.categories.cctv_surveillance}
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-blue-400 transition">
                  {t.categories.computers_desktops}
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-blue-400 transition">
                  {t.categories.printers_toner}
                </a>
              </li>
              <li>
                <a href="#offers" className="hover:text-blue-400 transition">
                  {t.offers}
                </a>
              </li>
            </ul>
          </div>

          {/* Our Services */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              {t.footer.servicesTitle}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => openServiceModal()} className="hover:text-blue-400 transition text-left">
                  {language === 'hi' ? 'लैपटॉप व कंप्यूटर रिपेयर' : 'Laptop & PC Repair'}
                </button>
              </li>
              <li>
                <button onClick={() => openServiceModal()} className="hover:text-blue-400 transition text-left">
                  {language === 'hi' ? 'सीसीटीवी फिटिंग व मोबाइल सेटअप' : 'CCTV Installation & Mobile Setup'}
                </button>
              </li>
              <li>
                <button onClick={() => openServiceModal()} className="hover:text-blue-400 transition text-left">
                  {language === 'hi' ? 'विंडोज़ व सॉफ्टवेयर इनस्टॉल' : 'Windows & Software Setup'}
                </button>
              </li>
              <li>
                <button onClick={() => openServiceModal()} className="hover:text-blue-400 transition text-left">
                  {language === 'hi' ? '12A लेज़र टोनर रिफिलिंग' : 'Laser Toner Cartridge Refilling'}
                </button>
              </li>
              <li>
                <button onClick={() => openServiceModal()} className="hover:text-blue-400 transition text-left">
                  {language === 'hi' ? 'डोरस्टेप होम सर्विस' : 'Doorstep Home Visit'}
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Numbers & Hours */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              {t.footer.callUs}
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                <a href={`tel:${shopSettings.phone1}`} className="text-white hover:text-blue-400 font-semibold">
                  +91 {shopSettings.phone1}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                <a href={`tel:${shopSettings.phone2}`} className="text-white hover:text-blue-400 font-semibold">
                  +91 {shopSettings.phone2}
                </a>
              </div>
              <div className="flex items-start gap-2 pt-1 text-slate-400">
                <Clock className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span>{shopSettings.openingHours[language] || shopSettings.openingHours.en}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-12 pt-6 border-t border-slate-900 flex flex-wrap items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} {shopSettings.shopName}. {t.footer.rights}
          </div>
          <div className="flex items-center gap-4">
            <span>GST & Local Trade Compliant</span>
            <span>Made for Indian Tech Retail</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
