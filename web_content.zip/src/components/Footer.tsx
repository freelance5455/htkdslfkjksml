import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Building2, 
  HeartPulse, 
  Palmtree, 
  Plane, 
  Activity, 
  Globe2, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  ShieldAlert, 
  Send,
  LayoutDashboard,
  Crown
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';

  return (
    <footer className="bg-black text-zinc-400 border-t border-[#D4AF37]/30 text-xs pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand & Slogan Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <img 
                src="/assets/aistudio/logo_transparent.png" 
                alt="المواساة" 
                className="h-16 w-auto object-contain drop-shadow-[0_4px_12px_rgba(212,175,55,0.4)]"
              />
              <div>
                <span className="text-lg font-black bg-gradient-to-r from-amber-200 via-amber-400 to-[#D4AF37] bg-clip-text text-transparent tracking-tight">
                  {t.brandName}
                </span>
                <span className="text-[10px] block text-amber-300 font-mono">
                  AL-MOWASAT MEDICAL & TOURISM
                </span>
              </div>
            </div>

            <p className="text-amber-200/90 leading-relaxed max-w-sm text-xs font-semibold">
              {t.slogan}
            </p>

            <p className="text-zinc-400 leading-relaxed text-[11px]">
              {isAr
                ? 'منصة مصرية متكاملة تهدف إلى ربط المرضى بالمستشفيات والأطباء والمراكز الطبية ومراكز التأهيل، وتنسيق خدمات الرعاية والسياحة العلاجية واستقبال المرضى من داخل مصر وخارجها بأعلى معايير الجودة والضيافة.'
                : 'An integrated Egyptian platform connecting global patients with accredited tertiary hospitals, senior surgical professors, secluded rehabilitation retreats, and world-renowned climatotherapy sanctuaries.'}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => openRequestModalForService('medical_sector')}
                className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold px-4.5 py-2.5 rounded-xl text-xs transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5 text-black" />
                <span>{t.navRequestBtn}</span>
              </button>

              <button
                onClick={() => {
                  setCurrentView('admin');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-zinc-950 hover:bg-zinc-900 text-amber-300 font-semibold px-3 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-1.5 border border-[#D4AF37]/40"
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{isAr ? 'لوحة الإدارة' : 'Admin'}</span>
              </button>
            </div>
          </div>

          {/* Column 2: Pillars */}
          <div className="space-y-3">
            <h4 className="font-bold text-amber-300 text-xs uppercase tracking-wider">
              {isAr ? 'أقسام الخدمات الرئيسية' : 'Core Service Pillars'}
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => setCurrentView('medical')} className="hover:text-amber-300 transition-colors">
                  {t.navMedical}
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('rehab')} className="hover:text-amber-300 transition-colors">
                  {t.navRehab}
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('tourism')} className="hover:text-amber-300 transition-colors">
                  {t.navTourism}
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('reception')} className="hover:text-amber-300 transition-colors">
                  {t.navReception}
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('tracking')} className="hover:text-amber-300 transition-colors">
                  {t.navTracking}
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('international')} className="hover:text-amber-300 transition-colors">
                  {t.navInternational}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Sanctuaries & Regions */}
          <div className="space-y-3">
            <h4 className="font-bold text-amber-300 text-xs uppercase tracking-wider">
              {isAr ? 'الوجهات الاستشفائية بمصر' : 'Curative Sanctuaries'}
            </h4>
            <ul className="space-y-2 text-zinc-400">
              <li>{isAr ? 'واحة سيوة (بحيرات الملح وحمامات الرمال)' : 'Siwa Oasis (Salt Lakes & Sand)'}</li>
              <li>{isAr ? 'مدينة أسوان (العلاج المناخي بالنيل)' : 'Aswan (Nile Climatotherapy)'}</li>
              <li>{isAr ? 'مدينة سفاجا (الرمال السوداء والمياه)' : 'Safaga (Black Sands Bay)'}</li>
              <li>{isAr ? 'وادي النطرون (مراكز التأهيل النفسي)' : 'Wadi El-Natrun (Rehab Retreats)'}</li>
              <li>{isAr ? 'القاهرة الكبرى (المجمعات الطبية المعتمدة)' : 'Greater Cairo (Tertiary Centers)'}</li>
            </ul>
          </div>

          {/* Column 4: Contact & Demo Inquiries */}
          <div className="space-y-3">
            <h4 className="font-bold text-amber-300 text-xs uppercase tracking-wider">
              {isAr ? 'التواصل والاستفسارات' : 'Contact & Desk'}
            </h4>
            <ul className="space-y-2.5 text-zinc-400">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span className="font-mono text-zinc-200">+20 2 2400 9900</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span className="font-mono text-zinc-200">coordination@almowasat.eg</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{isAr ? 'القاهرة الجديدة، التجمع الخامس، جمهورية مصر العربية' : 'New Cairo, 5th Settlement, Egypt'}</span>
              </li>
              <li className="pt-2">
                <span className="inline-flex items-center gap-1.5 text-amber-400 font-bold text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                  {isAr ? 'مكتب التنسيق الطبي متاح 24/7' : 'Coordination Desk 24/7'}
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Regulatory & Safety Box in Footer in Black & Gold */}
        <div className="p-4 bg-zinc-950 border border-[#D4AF37]/30 rounded-2xl flex items-start gap-3 text-zinc-400">
          <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed text-[11px]">
            <strong className="text-amber-200 font-semibold">
              {isAr ? 'إخلاء المسؤولية الطبية وحدود الخدمة:' : 'Medical Disclaimer & Scope of Service:'}
            </strong>{' '}
            {isAr
              ? 'منصة المواساة هي منصة تقنية لتنسيق الرعاية الصحية والسياحة العلاجية والخدمات اللوجستية وتسهيل الوصول للجهات المعتمدة، ولا تقدم تشخيصاً طبياً آلياً أو وصفات علاجية. جميع القرارات الطبية والخطط العلاجية تخضع حصرياً لمراجعة وإقرار الأطباء والاستشاريين المؤهلين بالمستشفيات الشريكة. جميع البيانات في هذا النموذج هي بيانات تجريبية لأغراض العرض التوضيحي والتطوير.'
              : 'Al-Mowasat is a healthcare coordination and medical tourism management platform. It does not provide direct medical diagnoses or prescriptions. Clinical plans are formulated exclusively by certified physicians at accredited hospitals. All figures and mock listings are for investor prototyping.'}
          </p>
        </div>

        {/* Copyright */}
        <div className="pt-6 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
          <div>
            © {new Date().getFullYear()} {isAr ? 'منصة المواساة – AL-MOWASAT MEDICAL & TOURISM. جميع الحقوق محفوظة.' : 'AL-MOWASAT Medical & Tourism Platform. All rights reserved.'}
          </div>
          <div className="flex items-center gap-4">
            <span className="text-amber-400 font-medium">
              {isAr ? 'نموذج أولي تجريبي للعرض والاستثمار (الإصدار الذهبي)' : 'Interactive Investor Prototype (Gold Edition)'}
            </span>
            <span>•</span>
            <button onClick={() => setCurrentView('admin')} className="text-zinc-400 hover:text-amber-300 transition-colors">
              {t.navAdmin}
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
