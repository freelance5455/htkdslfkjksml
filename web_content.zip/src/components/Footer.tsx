import React from 'react';
import { useApp } from '../context/AppContext.tsx';

export const Footer: React.FC = () => {
  const { setCurrentTab, showToast } = useApp();

  return (
    <footer className="w-full bg-[#0b0e14] mt-10 border-t border-surface-container-high/40">
      <div className="w-full px-4 sm:px-6 lg:px-10 py-10 flex flex-col gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Col 1: Brand & Status */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <img
                alt="IGNITE FF Logo"
                className="h-8 w-auto object-contain"
                src="https://lh3.googleusercontent.com/aida/AEtjO1WMrXVu8fq9UEA1qAUOQXaV0jhcKmyCRUyUCl8tv1bn-tN29ljALZMSW_Na1O_g7VmSpzJW8MT2ty0xPq0aBe6V7_4XZK6j2GYJtpCfhaNa39x8G_LzdrMLBC5HmT1n04PPQZjMVbs-mh7YfWOK6z3MLGUrOVHsSGfvq4RvqjP41LUeyVAqKLdQ6AsF2mStlWPOcH9kOofWJF4BE_BMa0Y8wbeSmB855rvv-fPNrfspxJDPgtYDQi4ngD-1"
              />
              <span className="font-headline-sm text-headline-sm uppercase tracking-wider text-on-surface">
                IGNITE <span className="text-[#ff5e00]">FF</span>
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              The battle-tested arena platform for Free Fire competitive circuits, custom scrims, automated tournament bracket validation, and immediate reward distributions.
            </p>
            <div className="flex items-center gap-2 mt-2">
              <span className="w-2 h-2 rounded-full bg-[#7df4ff] animate-ping"></span>
              <span className="font-label-sm text-label-sm uppercase text-tertiary-fixed font-bold tracking-wider">
                Network Status: Operational
              </span>
            </div>
          </div>

          {/* Col 2: Fair Play & Security */}
          <div className="flex flex-col gap-2">
            <span className="font-label-lg text-label-lg uppercase tracking-wider text-primary font-bold">
              Fair Play &amp; Security
            </span>
            <ul className="flex flex-col gap-2 font-body-sm text-body-sm text-on-surface-variant">
              <li>
                <button
                  onClick={() => showToast('Anti-Cheat Guard V3.8 active: 0 tolerance for config or emulators', 'info')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-tertiary">verified_user</span>
                  Anti-Cheat Guard (V3.8)
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentTab('tournaments');
                    setTimeout(() => {
                      document.getElementById('rules-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-tertiary">gavel</span>
                  Tournament Rulebook
                </button>
              </li>
              <li>
                <button
                  onClick={() => showToast('Policy: PC Emulators strictly blocked. Mobile devices only.', 'info')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-tertiary">vpn_lock</span>
                  Emulator Policy &amp; Restrictions
                </button>
              </li>
              <li>
                <button
                  onClick={() => showToast('Dispute Settlement Board: Human arbiters resolve tickets in < 90s', 'info')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-tertiary">policy</span>
                  Dispute Settlement Board
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Support & Operations */}
          <div className="flex flex-col gap-2">
            <span className="font-label-lg text-label-lg uppercase tracking-wider text-primary font-bold">
              Support &amp; Operations
            </span>
            <ul className="flex flex-col gap-2 font-body-sm text-body-sm text-on-surface-variant">
              <li>
                <button
                  onClick={() => setCurrentTab('match-room')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-primary">support_agent</span>
                  24/7 Match Arbiters
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentTab('wallet')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-primary">account_balance_wallet</span>
                  Payout &amp; UPI Helpdesk
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentTab('wallet')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-primary">token</span>
                  Diamond Exchange Protocol
                </button>
              </li>
              <li>
                <button
                  onClick={() => showToast('Support Ticket Center active on WhatsApp +91 98200 XXXXX', 'info')}
                  className="hover:text-on-surface transition-colors flex items-center gap-2 text-left cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm text-primary">help</span>
                  Ticket Center
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Community Outposts */}
          <div className="flex flex-col gap-2">
            <span className="font-label-lg text-label-lg uppercase tracking-wider text-primary font-bold">
              Community Outposts
            </span>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Synchronize your squad and track live room updates across real-time telemetry hubs.
            </p>
            <div className="flex flex-wrap gap-2 mt-1">
              <a
                href="https://discord.com"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-3 py-1.5 rounded bg-surface-container font-label-md text-label-md text-on-surface hover:bg-surface-container-high transition-colors"
              >
                <span className="material-symbols-outlined text-base text-primary">forum</span>
                Discord Scrims
              </a>
              <a
                href="https://telegram.org"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-3 py-1.5 rounded bg-surface-container font-label-md text-label-md text-on-surface hover:bg-surface-container-high transition-colors"
              >
                <span className="material-symbols-outlined text-base text-tertiary">send</span>
                Telegram Alerts
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-3 py-1.5 rounded bg-surface-container font-label-md text-label-md text-on-surface hover:bg-surface-container-high transition-colors"
              >
                <span className="material-symbols-outlined text-base text-secondary">play_circle</span>
                Live Casts
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Legal / Copyright Strip */}
        <div className="w-full pt-4 border-t border-surface-container-high/40 flex flex-col md:flex-row items-center justify-between gap-4 text-on-surface-variant font-label-sm text-label-sm uppercase bg-[#0b0e14]">
          <div className="flex flex-wrap items-center gap-2">
            <span>© 2025 IGNITE FF TOURNAMENTS. ALL RIGHTS RESERVED.</span>
            <span>•</span>
            <span>NOT OFFICIALLY AFFILIATED WITH GARENA FREE FIRE</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => showToast('IGNITE FF Privacy Statement: Strict data encryption & zero third-party tracking', 'info')}
              className="hover:text-on-surface transition-colors cursor-pointer"
            >
              Privacy Statement
            </button>
            <button
              onClick={() => showToast('Terms of Competition: 18 fair-play directives enforced', 'info')}
              className="hover:text-on-surface transition-colors cursor-pointer"
            >
              Terms of Competition
            </button>
            <button
              onClick={() => showToast('Responsible Gaming: Play within bankroll limits. 18+ only.', 'info')}
              className="hover:text-on-surface transition-colors cursor-pointer"
            >
              Responsible Gaming
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
