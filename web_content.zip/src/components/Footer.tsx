import { useState, type FormEvent } from "react";
import { formatNumber } from "../data/game";
import {
  ArrowRight,
  ArrowUpRight,
  Bolt,
  Instagram,
  LogoMark,
  Play,
  Shield,
  Tiktok,
  Trophy,
  Youtube,
} from "./Icons";

const DRIVE_LINKS = [
  { label: "The midnight run", href: "#play" },
  { label: "Garage", href: "#garage" },
  { label: "The circuit", href: "#circuit" },
  { label: "How to play", href: "#how-to-play" },
];

const HOUSE_LINKS = [
  { label: "Our story", href: "#story" },
  { label: "Field notes", href: "#how-to-play" },
  { label: "Return to top", href: "#top" },
];

export function Footer({ personalBest, onStart }: { personalBest: number; onStart: () => void }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "done" | "error">("idle");

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
    if (!valid) {
      setStatus("error");
      return;
    }
    setStatus("done");
    setEmail("");
  };

  return (
    <footer className="relative overflow-hidden border-t border-white/8 pt-6">
      <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
        <div className="relative overflow-hidden rounded-[26px] border border-white/12 bg-ink-900">
          <img
            src="/images/night-highway.jpg"
            alt=""
            aria-hidden="true"
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/90 to-ink-950/40" />
          <div className="absolute inset-0 bg-[radial-gradient(60%_120%_at_100%_0%,rgba(201,250,60,0.12),transparent_60%)]" />
          <div className="relative grid gap-8 p-6 sm:p-9 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:p-11">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-volt/30 bg-volt/8 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.18em] text-volt">
                <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" /> The engine is warm
              </span>
              <h2 className="mt-4 text-balance text-[clamp(2rem,4.6vw,3.6rem)] font-semibold leading-[0.94] tracking-[-0.04em] text-bone">
                The night won't
                <br />
                drive <span className="font-serif font-normal italic text-volt">itself.</span>
              </h2>
              <p className="mt-3 max-w-sm text-[13px] leading-relaxed text-moss-300">
                The keys are in the bay, the coast road is clear, and the wall hasn't moved. Take one more run before sunrise.
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onStart}
                  className="group inline-flex items-center gap-2.5 rounded-full bg-volt px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-950 transition hover:bg-volt-bright hover:shadow-[0_0_40px_-10px_rgba(201,250,60,0.7)]"
                >
                  <Play className="h-2.5 w-2.5" /> Start the engine
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </button>
                <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-moss-500">
                  No sign-up · runs instantly
                </span>
              </div>
            </div>

            <div className="glass rounded-2xl border border-white/12 p-4 sm:p-5">
              <div className="flex items-center justify-between">
                <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-moss-400">Tonight's setup</p>
                <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-volt">Loaded</span>
              </div>
              <div className="mt-3 divide-y divide-white/8">
                {[
                  { icon: Shield, label: "Integrity", value: "3 shields" },
                  { icon: Bolt, label: "Nitro", value: "Charged at pickup" },
                  { icon: Trophy, label: "Your best", value: personalBest > 0 ? `${formatNumber(personalBest)} m` : "Unset" },
                  { icon: Play, label: "Top speed", value: "200 km/h" },
                ].map((row) => {
                  const Icon = row.icon;
                  return (
                    <div key={row.label} className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
                      <span className="flex items-center gap-2 text-[11.5px] text-moss-300">
                        <Icon className="h-3.5 w-3.5 text-moss-500" /> {row.label}
                      </span>
                      <span className="font-mono text-[10px] text-bone">{row.value}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-10 py-12 sm:py-14 lg:grid-cols-[1.25fr_1fr_1fr] lg:gap-10">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-volt text-ink-950">
                <LogoMark className="h-5 w-5" />
              </span>
              <span className="leading-none">
                <span className="block text-[17px] font-bold uppercase tracking-[0.2em] text-bone">Vanta</span>
                <span className="mt-1 block font-mono text-[7px] uppercase tracking-[0.24em] text-moss-500">Highway division</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-[12.5px] leading-relaxed text-moss-400">
              An endless night-highway runner built in Colombo for anyone who thinks the best driving happens after midnight.
            </p>
            <div className="mt-5 flex items-center gap-2">
              {[
                { icon: Instagram, label: "Instagram", href: "https://instagram.com" },
                { icon: Youtube, label: "YouTube", href: "https://youtube.com" },
                { icon: Tiktok, label: "TikTok", href: "https://tiktok.com" },
              ].map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noreferrer noopener"
                    aria-label={`VANTA on ${social.label}`}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/4 text-moss-400 transition hover:border-volt/40 hover:text-volt"
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                );
              })}
              <a
                href="mailto:crew@vanta.run"
                className="ml-1 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-moss-500 transition hover:text-bone"
              >
                crew@vanta.run <ArrowUpRight className="h-3 w-3" />
              </a>
            </div>

            <form onSubmit={submit} className="mt-6 max-w-sm">
              <label htmlFor="newsletter" className="font-mono text-[8px] uppercase tracking-[0.16em] text-moss-500">
                Join the night shift
              </label>
              <div className="mt-2 flex gap-2">
                <input
                  id="newsletter"
                  type="email"
                  value={email}
                  onChange={(event) => {
                    setEmail(event.target.value);
                    if (status !== "idle") setStatus("idle");
                  }}
                  placeholder="your@email.com"
                  autoComplete="email"
                  className="h-10 min-w-0 flex-1 rounded-lg border border-white/12 bg-white/4 px-3 text-[12px] text-bone placeholder:text-moss-600 transition focus:border-volt/50 focus:outline-none"
                  aria-invalid={status === "error"}
                />
                <button
                  type="submit"
                  className="flex h-10 shrink-0 items-center gap-1.5 rounded-lg bg-bone px-3.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-ink-950 transition hover:bg-volt"
                >
                  Join <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
              <p
                className={`mt-1.5 font-mono text-[9px] ${
                  status === "error" ? "text-ember" : status === "done" ? "text-volt" : "text-moss-600"
                }`}
                role="status"
              >
                {status === "error"
                  ? "Enter a valid email address."
                  : status === "done"
                    ? "You're in. Watch your inbox after dark."
                    : "One dispatch a month. No noise."}
              </p>
            </form>
          </div>

          <div>
            <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-moss-500">Drive</p>
            <ul className="mt-3.5 space-y-2.5">
              {DRIVE_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="group inline-flex items-center gap-1.5 text-[12.5px] text-moss-300 transition hover:text-bone"
                  >
                    {link.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-moss-500">The house</p>
            <ul className="mt-3.5 space-y-2.5">
              {HOUSE_LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="group inline-flex items-center gap-1.5 text-[12.5px] text-moss-300 transition hover:text-bone"
                  >
                    {link.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="mailto:press@vanta.run?subject=VANTA%20press%20kit"
                  className="group inline-flex items-center gap-1.5 text-[12.5px] text-moss-300 transition hover:text-bone"
                >
                  Press kit
                  <ArrowUpRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-3 border-t border-white/8 py-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">
            © {new Date().getFullYear()} Vanta Highway Division · All rights reserved
          </p>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 font-mono text-[8px] uppercase tracking-[0.1em] text-moss-600">
            <span>A fictional racing concept</span>
            <span className="h-1 w-1 rounded-full bg-moss-600/60" />
            <span>Ghost times are seeded</span>
            <span className="h-1 w-1 rounded-full bg-moss-600/60" />
            <span>Best with headphones</span>
          </div>
        </div>
      </div>

      <div className="pointer-events-none select-none overflow-hidden border-t border-white/5 pb-1 pt-4">
        <p className="whitespace-nowrap text-center font-serif text-[clamp(4rem,16vw,15rem)] italic leading-[0.7] text-white/[0.035]">
          Own the night.
        </p>
      </div>
    </footer>
  );
}
