import React from 'react';
import { MapPin, Phone, MessageCircle, Radio, ShieldCheck, Code, Smartphone } from 'lucide-react';

interface FooterProps {
  onOpenExportModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenExportModal }) => {
  return (
    <footer className="bg-black border-t border-zinc-900 pt-12 pb-24 sm:pb-12 px-4">
      <div className="max-w-4xl mx-auto text-center space-y-3 text-zinc-400 text-xs">
        <p className="font-black text-white text-lg tracking-tight uppercase">
          DJ EVAN PRO UG - THE CUE KING 👑
        </p>

        <p className="text-zinc-300 font-medium">
          📍 Kyebando, Kawempe - Kampala, Uganda | Available All Kampala, Wakiso, Mukono
        </p>

        <p className="flex items-center justify-center gap-3 flex-wrap text-zinc-300 font-bold">
          <a href="tel:+256742094651" className="hover:text-cyan-400 transition-colors">
            📞 0742094651
          </a>
          <span>·</span>
          <a href="https://tiktok.com/@djevanproug" target="_blank" rel="noopener noreferrer" className="hover:text-pink-400 transition-colors">
            TikTok @djevanproug
          </a>
          <span>·</span>
          <a href="https://wa.me/256742094651" target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline">
            WhatsApp 24/7
          </a>
        </p>

        {/* Business summary pills */}
        <div className="pt-2 flex items-center justify-center gap-2 flex-wrap text-[11px] text-zinc-500">
          <span>Parties (120K)</span>
          <span>·</span>
          <span>Night Clubs (150K)</span>
          <span>·</span>
          <span>Kwanjula (200K)</span>
          <span>·</span>
          <span>Weddings (300K)</span>
          <span>·</span>
          <span>DJ Drops (7K)</span>
          <span>·</span>
          <span>Used &amp; New Phones</span>
        </div>

        {/* Payment info */}
        <p className="text-[11px] text-zinc-500 pt-2 border-t border-zinc-900 max-w-md mx-auto">
          MTN MoMo &amp; Airtel Money Accepted (0742094651) · Cash on Delivery across Kampala
        </p>

        {/* Export HTML code option */}
        <div className="pt-2">
          <button
            onClick={onOpenExportModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white text-[11px] transition-colors"
          >
            <Code className="w-3.5 h-3.5 text-cyan-400" />
            <span>View / Export Single HTML File</span>
          </button>
        </div>

        <p className="text-[10px] text-zinc-600 pt-2">
          © {new Date().getFullYear()} DJ EVAN PRO UG. Built for real paying clients in Uganda.
        </p>
      </div>
    </footer>
  );
};
