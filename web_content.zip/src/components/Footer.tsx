import React from 'react';
import { GraduationCap, Heart, ShieldCheck, Mail, Globe } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const t = TRANSLATIONS[language];

  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 text-slate-400 text-xs py-12 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-extrabold">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-lg text-white">LankaPaperHub</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">{t.subtagline}</p>
            <div className="flex items-center gap-2 text-[11px] text-amber-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>National Examination Directory</span>
            </div>
          </div>

          {/* School Categories */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider">Exam Grades</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><a href="#" className="hover:text-amber-300">Grade 6 Past Papers</a></li>
              <li><a href="#" className="hover:text-amber-300">Grade 7 Past Papers</a></li>
              <li><a href="#" className="hover:text-amber-300">Grade 8 Past Papers</a></li>
              <li><a href="#" className="hover:text-amber-300">Grade 9 Past Papers</a></li>
              <li><a href="#" className="hover:text-amber-300">G.C.E. Ordinary Level (O/L)</a></li>
              <li><a href="#" className="hover:text-amber-300">G.C.E. Advanced Level (A/L)</a></li>
            </ul>
          </div>

          {/* Sri Lankan Provinces */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider">Provincial Evaluation Tests</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><a href="#" className="hover:text-amber-300">Western Province</a></li>
              <li><a href="#" className="hover:text-amber-300">Central Province</a></li>
              <li><a href="#" className="hover:text-amber-300">Southern Province</a></li>
              <li><a href="#" className="hover:text-amber-300">Northern & Eastern Provinces</a></li>
              <li><a href="#" className="hover:text-amber-300">North Western & North Central</a></li>
              <li><a href="#" className="hover:text-amber-300">Uva & Sabaragamuwa</a></li>
            </ul>
          </div>

          {/* Technology & Platform */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider">Enterprise Specs</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li>Next.js 15 & React 19 Engine</li>
              <li>Express & Node.js REST API</li>
              <li>Prisma ORM & PostgreSQL</li>
              <li>Google Gemini AI Analysis</li>
              <li>Docker & Vercel Deployment</li>
            </ul>
          </div>

        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <p>© {new Date().getFullYear()} LankaPaperHub. All rights reserved. Sri Lanka Education Network.</p>
          <div className="flex items-center gap-1 text-slate-400 font-medium">
            <span>Built with precision for Sri Lankan Students & Teachers</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-current ml-1" />
          </div>
        </div>

      </div>
    </footer>
  );
};
