import React from 'react';
import { Code2, Heart } from 'lucide-react';

interface FooterProps {
  onOpenExportModal: () => void;
  onScrollToSection: (id: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenExportModal, onScrollToSection }) => {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 py-12 px-4 sm:px-6 text-xs text-slate-400">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="hidden w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 items-center justify-center font-black text-white text-xs">
                SL
              </div>
              <span className="hidden text-xl font-black text-white">SL TIK TOK <span className="text-cyan-400">Video</span></span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              SL TIK TOK Video is a free, high-speed online video downloader. Developed by <strong className="text-cyan-400">Saleem Zakhme</strong> to easily save videos without watermarks in MP4 and MP3 on any device.
            </p>
            <div className="pt-1 hidden">
              <button
                onClick={onOpenExportModal}
                className="hidden items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 text-xs font-semibold transition cursor-pointer"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Single index.html Code (Export)</span>
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Tools & Features</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-cyan-400 transition cursor-pointer">
                  TikTok Video Downloader
                </button>
              </li>
              <li>
                <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-cyan-400 transition cursor-pointer">
                  TikTok to MP3 Audio
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('how-to')} className="hover:text-cyan-400 transition cursor-pointer">
                  How to Download
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('features')} className="hover:text-cyan-400 transition cursor-pointer">
                  Features
                </button>
              </li>
            </ul>
          </div>

          {/* Legal / Info */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Information</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button onClick={() => onScrollToSection('faq')} className="hover:text-cyan-400 transition cursor-pointer">
                  FAQ
                </button>
              </li>
              <li>
                <a href="#how-to" className="hover:text-cyan-400 transition">Privacy Policy</a>
              </li>
              <li>
                <a href="#how-to" className="hover:text-cyan-400 transition">Terms of Service</a>
              </li>
              <li>
                <a href="#how-to" className="hover:text-cyan-400 transition">Contact Us</a>
              </li>
            </ul>
          </div>

        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400 text-center sm:text-left">
          <p>
            Disclaimer: SL TIK TOK Video is not affiliated, associated, authorized, endorsed by, or in any way officially connected with TikTok or ByteDance.
          </p>
          <p className="shrink-0 flex items-center justify-center gap-1">
            &copy; 2026 SL TIK TOK Video. Developed by <strong className="text-cyan-400">Saleem Zakhme</strong>.
          </p>
        </div>
      </div>
    </footer>
  );
};
