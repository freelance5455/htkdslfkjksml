import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Logo } from './Logo.js';
import { ShieldCheck, Mail } from 'lucide-react';

interface FooterProps {
  compact?: boolean;
  className?: string;
}

export const Footer: React.FC<FooterProps> = ({ compact = false, className = '' }) => {
  const { setCurrentPage } = useAuth();

  if (compact) {
    return (
      <footer
        id="app-compact-footer"
        className={`w-full py-3 px-4 border-t border-slate-200/80 dark:border-slate-800/80 bg-white/70 dark:bg-slate-900/70 backdrop-blur-sm text-center text-xs text-slate-500 dark:text-slate-400 ${className}`}
      >
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 max-w-7xl mx-auto px-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              OWNER NAME: Ali ABDULLAH
            </span>
            <span>•</span>
            <span className="font-medium text-indigo-600 dark:text-indigo-400">
              BY :- aipocketchat.support@gmail.com
            </span>
          </div>
          <div className="text-[11px] text-slate-400 dark:text-slate-500">
            © 2026 AI Pocket Chat • OWNER NAME: Ali ABDULLAH • All Rights Reserved.
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer
      id="app-main-footer"
      className={`w-full border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 py-10 px-4 sm:px-6 lg:px-8 ${className}`}
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-8 pb-8 border-b border-slate-100 dark:border-slate-800/80">
        <div className="space-y-3 max-w-md">
          <Logo size="md" showTagline />
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            A fast, secure, mobile-first AI chat companion built for modern mobile browsers, tablets, and desktop. Ask anything, spark creative ideas, and organize your knowledge.
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-850">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
              <span>OWNER NAME: Ali ABDULLAH</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-850">
              <Mail className="w-3.5 h-3.5 text-emerald-500" />
              <span>BY :- aipocketchat.support@gmail.com</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-8 text-xs">
          <div>
            <h4 className="font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] mb-3">
              Application
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentPage('chat')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  AI Chat Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('landing')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  Features & Demo
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('about')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  About AI Pocket Chat
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] mb-3">
              Account & Legal
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentPage('privacy-security')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  Privacy & Security
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('help-support')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  Terms & Help Support
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('login')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                >
                  Secure Sign In
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] mb-3">
              Support & Creator
            </h4>
            <div className="space-y-2">
              <p className="font-medium text-slate-800 dark:text-slate-200">
                Ali ABDULLAH
              </p>
              <p className="text-[11px] text-slate-400">
                Support: <a href="mailto:aipocketchat.support@gmail.com" className="hover:underline text-indigo-500">aipocketchat.support@gmail.com</a>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="text-center sm:text-left">
          <p className="font-semibold text-slate-800 dark:text-slate-200">
            OWNER NAME: Ali ABDULLAH • BY :- aipocketchat.support@gmail.com
          </p>
          <p className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">
            © 2026 AI Pocket Chat • OWNER NAME: Ali ABDULLAH • All Rights Reserved.
          </p>
        </div>

        <div className="flex items-center gap-4 text-[11px] text-slate-500 dark:text-slate-400">
          <button onClick={() => setCurrentPage('privacy-security')} className="hover:underline">
            Privacy Policy
          </button>
          <span>•</span>
          <button onClick={() => setCurrentPage('help-support')} className="hover:underline">
            Terms of Service
          </button>
          <span>•</span>
          <button onClick={() => setCurrentPage('help-support')} className="hover:underline">
            Help & Support
          </button>
        </div>
      </div>
    </footer>
  );
};
