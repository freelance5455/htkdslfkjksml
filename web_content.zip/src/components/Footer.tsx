import React from 'react';
import { useVideo } from '../context/VideoContext';
import { Film, ShieldCheck, Database, HardDrive, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { stats, language, setLanguage } = useVideo();

  return (
    <footer className="bg-[#101010] border-t border-white/5 text-zinc-500 text-xs py-12 px-4 sm:px-6 lg:px-8 mt-16 select-none">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Brand & System Status */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/5 pb-6">
          <div className="flex items-center space-x-2">
            <span className="font-extrabold tracking-widest text-lg text-[#E50914] uppercase">
              CINESTREAM
            </span>
            <span className="text-zinc-600">|</span>
            <span className="text-zinc-400">
              {language === 'ur'
                ? 'نیٹ فلکس اسٹائل ویڈیو پلیٹ فارم اور ڈیٹا بیس'
                : 'Netflix-Style Video Streaming & Database Hub'}
            </span>
          </div>

          <div className="flex items-center space-x-4 text-[11px] text-zinc-400">
            <div className="flex items-center space-x-1.5 bg-zinc-900 px-2.5 py-1 rounded border border-white/5">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Database: Active ({stats.totalVideos} Videos)</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-zinc-900 px-2.5 py-1 rounded border border-white/5">
              <HardDrive className="w-3.5 h-3.5 text-blue-400" />
              <span>Storage: HTTP 206 Streaming</span>
            </div>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-zinc-400">
          <div className="space-y-2">
            <p className="font-bold text-zinc-300">Browse</p>
            <p className="hover:underline cursor-pointer">Trending Movies</p>
            <p className="hover:underline cursor-pointer">Original Series</p>
            <p className="hover:underline cursor-pointer">Top 10 Today</p>
            <p className="hover:underline cursor-pointer">Community Uploads</p>
          </div>
          <div className="space-y-2">
            <p className="font-bold text-zinc-300">Player Engine</p>
            <p className="hover:underline cursor-pointer">4K Ultra HD & HDR</p>
            <p className="hover:underline cursor-pointer">10s Forward / Rewind</p>
            <p className="hover:underline cursor-pointer">Variable Playback Speed</p>
            <p className="hover:underline cursor-pointer">Multi-language Subtitles</p>
          </div>
          <div className="space-y-2">
            <p className="font-bold text-zinc-300">Upload & Studio</p>
            <p className="hover:underline cursor-pointer">MP4 / WebM / MKV</p>
            <p className="hover:underline cursor-pointer">Auto Frame Capture</p>
            <p className="hover:underline cursor-pointer">Metadata & Genre Tags</p>
            <p className="hover:underline cursor-pointer">Range Seek Support</p>
          </div>
          <div className="space-y-2">
            <p className="font-bold text-zinc-300">Profiles & Data</p>
            <p className="hover:underline cursor-pointer">Watch History & Resume</p>
            <p className="hover:underline cursor-pointer">My Watchlist</p>
            <p className="hover:underline cursor-pointer">Likes & Feedback</p>
            <p className="hover:underline cursor-pointer">Kids Safe Filter</p>
          </div>
        </div>

        {/* Language selector & Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-6 border-t border-white/5 gap-4">
          <button
            onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
            className="px-3 py-1.5 rounded border border-zinc-700 bg-zinc-900 text-zinc-300 hover:text-white text-xs cursor-pointer"
          >
            🌐 {language === 'en' ? 'اردو زبان میں دیکھیں' : 'Switch to English'}
          </button>

          <p className="text-zinc-600 text-[11px] text-center">
            © {new Date().getFullYear()} CineStream. Built with Node.js Express Backend & Range Request Streaming.
          </p>
        </div>
      </div>
    </footer>
  );
};
