/**
 * greeting.js — the "Good Morning, Abbas!" welcome shown EVERY time the app opens.
 * Tap anywhere to continue; it also fades out by itself.
 */
import { el } from '../ui.js';
import { getProfile } from '../../core/profile/profileService.js';
import { greetingFor } from '../../core/utils/dateUtils.js';
import { hijriDate, getPrayerConfig } from '../../core/prayer/prayerService.js';
import { getDailyAffirmation } from '../../core/motivation/quotes.js';

const OPENERS = [
  'Ready to conquer today? Let\'s give it a try.',
  'Ready to conquer. Bismillah — let\'s go.',
  'A fresh page. Let\'s make it count.',
  'Show up today. That\'s the whole game.',
  'Let\'s build the person you\'re becoming.',
];

export async function showGreeting({ duration = 2600 } = {}) {
  const profile = await getProfile();
  const cfg = await getPrayerConfig();
  const now = new Date();
  const first = (profile.name || 'Champ').trim().split(/\s+/)[0] || 'Champ';
  const hj = hijriDate(now, cfg.hijriAdjust);

  const avatar = profile.photo
    ? Object.assign(el('img', 'greet-avatar'), { src: profile.photo, alt: '' })
    : el('div', 'greet-avatar greet-avatar--initial', first.slice(0, 1).toUpperCase());

  const overlay = el('div', 'greeting', [
    avatar,
    el('h1', 'greet-title', `${greetingFor(now)}, ${first}!`),
    el('p', 'greet-open', OPENERS[(now.getDate() + now.getMonth()) % OPENERS.length]),
    el('p', 'greet-date', `${now.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}${hj ? ` · ${hj.text}` : ''}`),
    el('p', 'greet-quote', `“${getDailyAffirmation(now)}”`),
    el('p', 'greet-hint', 'tap to continue'),
  ]);
  document.body.append(overlay);

  return new Promise((resolve) => {
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      overlay.classList.add('greeting--out');
      setTimeout(() => { overlay.remove(); resolve(); }, 450);
    };
    overlay.addEventListener('click', close);
    setTimeout(close, duration);
  });
}

