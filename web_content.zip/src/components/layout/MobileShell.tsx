import { useState } from 'react';
import {
  Home,
  Globe,
  Bot,
  Plane,
  User,
  Wallet,
  Navigation,
  FileCheck,
  Building2,
  Smartphone,
  Maximize2,
  Minimize2,
  Wifi,
  Battery,
  ShieldCheck,
  Layers,
  Luggage,
} from 'lucide-react';
import { Language, Currency, UserProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface MobileShellProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  language: Language;
  currency: Currency;
  user: UserProfile;
  children: React.ReactNode;
}

export function MobileShell({
  currentTab,
  onSelectTab,
  language,
  currency,
  user,
  children,
}: MobileShellProps) {
  const [isDeviceFrameMode, setIsDeviceFrameMode] = useState(false);
  const t = translations[language];
  const isRTL = language === 'ar';

  const primaryTabs = [
    { id: 'home', label: t.navHome, icon: <Home className="w-5 h-5" /> },
    { id: 'explore', label: t.navExplore, icon: <Globe className="w-5 h-5" /> },
    { id: 'assistant', label: t.navAssistant, icon: <Bot className="w-5 h-5" /> },
    { id: 'trips', label: t.navTrips, icon: <Plane className="w-5 h-5" /> },
    { id: 'profile', label: t.navProfile, icon: <User className="w-5 h-5" /> },
  ];

  const secondaryShortcuts = [
    { id: 'flights', label: t.services.flights, icon: <Plane className="w-3.5 h-3.5" /> },
    { id: 'hotels', label: t.services.hotels, icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'visa', label: t.services.visas, icon: <FileCheck className="w-3.5 h-3.5" /> },
    { id: 'packing', label: language === 'ar' ? 'مساعد الأمتعة' : 'Smart Packing', icon: <Luggage className="w-3.5 h-3.5 text-cyan-400" /> },
    { id: 'wallet', label: t.navWallet, icon: <Wallet className="w-3.5 h-3.5" /> },
    { id: 'ar', label: t.navAR, icon: <Navigation className="w-3.5 h-3.5" /> },
    { id: 'agency', label: t.navAgency, icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'architecture', label: 'Flutter Architecture', icon: <Layers className="w-3.5 h-3.5 text-cyan-400" /> },
  ];

  return (
    <div className="min-h-screen bg-[#030612] text-slate-100 flex flex-col items-center justify-start relative selection:bg-cyan-500 selection:text-white">
      {/* Top Utility Bar for Desktop Previewers: Device Viewport Toggle & Brand Indicator */}
      <header className="w-full max-w-7xl px-4 py-2.5 flex items-center justify-between border-b border-slate-800/80 bg-[#050814]/90 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-[0_0_15px_rgba(0,240,255,0.4)]">
            <div className="w-full h-full bg-[#070b1e] rounded-xl flex items-center justify-center font-black text-cyan-400 text-xs">
              TG
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black tracking-wider text-white">TAKI-GO</span>
              <span className="text-[10px] text-cyan-400 font-semibold hidden sm:inline">Tourism By Taki</span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">
              Flutter Mobile Production Baseline · Android & iOS
            </p>
          </div>
        </div>

        {/* Quick Nav Pills on top for easy testing */}
        <div className="hidden lg:flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {secondaryShortcuts.map(item => (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                currentTab === item.id
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(0,240,255,0.4)]'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Viewport Frame Switcher */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsDeviceFrameMode(!isDeviceFrameMode)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/30 text-xs text-cyan-300 hover:bg-slate-800 transition-colors"
            title="Toggle Smartphone Frame"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {isDeviceFrameMode ? (language === 'ar' ? 'عرض ممتد' : 'Expanded View') : (language === 'ar' ? 'إطار الهاتف' : 'Phone Frame')}
            </span>
          </button>
        </div>
      </header>

      {/* Main Content Area: Either Phone Mockup or Expanded Responsive View */}
      <main className="w-full flex justify-center py-4 px-2 md:px-4 flex-1">
        <div
          className={`w-full transition-all duration-300 ${
            isDeviceFrameMode
              ? 'max-w-[420px] rounded-[44px] border-[10px] border-[#131b34] shadow-[0_20px_70px_rgba(0,102,255,0.35)] bg-[#050814] relative overflow-hidden flex flex-col min-h-[820px]'
              : 'max-w-2xl sm:max-w-3xl lg:max-w-5xl'
          }`}
        >
          {/* Smartphone Dynamic Island Notch in Phone Mode */}
          {isDeviceFrameMode && (
            <div className="w-full pt-3 px-6 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none bg-[#050814] z-30">
              <span className="font-bold text-white">09:41</span>
              <div className="w-24 h-5 rounded-full bg-black border border-slate-800 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse mr-2" />
                <span className="text-[9px] text-cyan-300 font-sans">TAKI-GO</span>
              </div>
              <div className="flex items-center gap-1 text-slate-300">
                <Wifi className="w-3 h-3" />
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>
          )}

          {/* Children Screen Views */}
          <div className="flex-1 p-3 md:p-5">
            {children}
          </div>
        </div>
      </main>

      {/* FIXED BOTTOM NAVIGATION BAR */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 bg-[#070d24]/90 backdrop-blur-xl border-t border-cyan-500/20 shadow-[0_-5px_30px_rgba(0,102,255,0.2)]"
        aria-label="Bottom Navigation"
      >
        <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-2">
          {primaryTabs.map(tab => {
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex flex-col items-center justify-center py-1 transition-all group ${
                  isActive ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className={`p-1 rounded-xl transition-all ${
                  isActive ? 'bg-cyan-500/20 text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.3)]' : ''
                }`}>
                  {tab.icon}
                </div>
                <span className={`text-[10px] font-medium tracking-tight mt-0.5 ${
                  isActive ? 'text-cyan-400 font-bold' : 'text-slate-400'
                }`}>
                  {tab.label}
                </span>
                {isActive && (
                  <span className="w-1 h-1 rounded-full bg-cyan-400 shadow-[0_0_6px_#00f0ff] mt-0.5" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
