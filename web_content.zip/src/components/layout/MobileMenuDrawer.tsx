import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Flame, ShoppingBag, Users, Bookmark,
  ShieldAlert, Download, LogOut, Check, X,
  User as UserIcon, Smartphone
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface MobileMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  setCurrentTab: (tab: string) => void;
  onOpenExportModal: () => void;
}

export const MobileMenuDrawer: React.FC<MobileMenuDrawerProps> = ({
  isOpen,
  onClose,
  setCurrentTab,
  onOpenExportModal
}) => {
  const { currentUser, logout, switchUser, availableDemoUsers } = useAuth();
  const { isInstalled, install } = usePWAInstall();

  if (!isOpen) return null;

  const navigateTo = (tab: string) => {
    setCurrentTab(tab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
      <div
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl shadow-2xl p-6 text-slate-100 max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom duration-200"
      >
        {/* Grab bar */}
        <div className="w-10 h-1 bg-slate-700 rounded-full mx-auto mb-4 sm:hidden" />

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            {currentUser && (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-11 h-11 rounded-full object-cover ring-2 ring-amber-500"
              />
            )}
            <div>
              <h3 className="font-bold text-white text-base truncate font-display">{currentUser?.name}</h3>
              <p className="text-xs text-amber-400 font-mono">@{currentUser?.username} · 🇦🇴 {currentUser?.province}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-2 gap-2.5 py-4">
          <button
            onClick={() => navigateTo('profile')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <UserIcon className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Meu Perfil</p>
              <p className="text-[10px] text-slate-400">Ver posts e dados</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('trends')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Angola Agora 🇦🇴</p>
              <p className="text-[10px] text-slate-400">Tendências e notícias</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('marketplace')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Marketplace</p>
              <p className="text-[10px] text-slate-400">Comprar e vender</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('groups')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Grupos</p>
              <p className="text-[10px] text-slate-400">Comunidades locais</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('pages')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
              <Bookmark className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Páginas</p>
              <p className="text-[10px] text-slate-400">Empresas e marcas</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('saved')}
            className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
              <Bookmark className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-xs text-white">Salvos</p>
              <p className="text-[10px] text-slate-400">Publicações guardadas</p>
            </div>
          </button>

          {currentUser?.isAdmin && (
            <button
              onClick={() => navigateTo('admin')}
              className="col-span-2 flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/30 hover:border-amber-500/50 rounded-xl text-left"
            >
              <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-xs text-amber-300">Painel Administrativo 🛡️</p>
                <p className="text-[10px] text-amber-400/80">Moderação e estatísticas da plataforma</p>
              </div>
            </button>
          )}
        </div>

        {/* Install Native App Banner */}
        {!isInstalled && (
          <div className="p-3 bg-gradient-to-r from-amber-950/40 via-red-950/30 to-slate-950 border border-amber-500/40 rounded-2xl mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-red-600 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow">
                <Smartphone className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs font-bold text-white flex items-center gap-1.5">
                  Instalar App Real 🇦🇴
                </p>
                <p className="text-[10px] text-amber-300 mt-0.5">Sem barra de navegador · Abre offline</p>
              </div>
            </div>
            <button
              onClick={() => install()}
              className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-red-500 hover:brightness-110 text-white font-bold text-xs rounded-xl shadow-lg transition-all shrink-0 active:scale-95"
            >
              Instalar
            </button>
          </div>
        )}

        {/* Export project banner */}
        <div className="p-3 bg-gradient-to-r from-red-950/40 via-amber-950/30 to-slate-950 border border-amber-600/30 rounded-2xl mb-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-white flex items-center gap-1.5">
              <Download className="w-4 h-4 text-amber-400" />
              Exportar Projeto Completo (ZIP & APK)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">Código fonte + Configuração Android pronta</p>
          </div>
          <button
            onClick={() => { onClose(); onOpenExportModal(); }}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all shrink-0"
          >
            Baixar ZIP
          </button>
        </div>

        {/* Switch Account */}
        <div className="py-2 border-t border-slate-800">
          <p className="text-[11px] text-slate-400 font-semibold mb-2">Alternar Utilizador:</p>
          <div className="grid grid-cols-3 gap-2">
            {availableDemoUsers.map((u) => (
              <button
                key={u.id}
                onClick={() => { switchUser(u); onClose(); }}
                className={`flex flex-col items-center p-2 rounded-xl border text-center transition-all ${currentUser?.id === u.id ? 'bg-amber-500/10 border-amber-500/40 text-amber-300' : 'bg-slate-950 border-slate-800 text-slate-300'}`}
              >
                <img src={u.avatar} className="w-6 h-6 rounded-full object-cover mb-1" />
                <span className="text-[10px] font-semibold truncate w-full">{u.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Logout */}
        <div className="pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => { logout(); onClose(); }}
            className="flex items-center gap-2 text-xs text-red-400 hover:text-red-300 font-medium py-2 px-3 rounded-lg hover:bg-red-950/30"
          >
            <LogOut className="w-4 h-4" />
            <span>Terminar Sessão</span>
          </button>
        </div>
      </div>
    </div>
  );
};
