/**
 * celebrate.js — tiny confetti + pop feedback. Pure DOM/CSS (no library), skipped when the
 * phone asks for reduced motion. Listens to existing events; nothing else needs to know about it.
 */
import { getPrefsSync } from '../../core/profile/prefsService.js';
import { on } from '../../core/utils/eventBus.js';

const COLORS = ['#34D399', '#60A5FA', '#FBBF24', '#F472B6', '#A78BFA'];
const reduced = () => document.documentElement.dataset.motion !== 'full' || !getPrefsSync().celebrations;

export function burst(count = 18, originY = 0.7) {
  if (reduced()) return;
  const layer = document.createElement('div');
  layer.className = 'confetti-layer';
  for (let i = 0; i < count; i += 1) {
    const p = document.createElement('i');
    p.className = 'confetti';
    const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
    const dist = 70 + Math.random() * 110;
    p.style.setProperty('--dx', `${Math.cos(angle) * dist}px`);
    p.style.setProperty('--dy', `${Math.sin(angle) * dist - 40}px`);
    p.style.setProperty('--rot', `${Math.random() * 540 - 270}deg`);
    p.style.background = COLORS[i % COLORS.length];
    p.style.left = '50%';
    p.style.top = `${originY * 100}%`;
    layer.append(p);
  }
  document.body.append(layer);
  setTimeout(() => layer.remove(), 1100);
}

let lastBurst = 0;
export function initCelebrations() {
  const small = () => { if (Date.now() - lastBurst > 1500) { lastBurst = Date.now(); burst(12, 0.8); } };
  ['habit:completed', 'routine:completed', 'workout:completed', 'study:blockCompleted', 'anki:logged', 'skincare:completed'].forEach((e) => on(e, small));
  on('weeklyReview:completed', () => burst(30, 0.5));
  on('achievement:unlocked', () => burst(36, 0.45));
}
