import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  Sun,
  Moon,
  Clock,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  BookOpen,
  Pill,
  Cloud,
  Mail,
  Smartphone,
  Download,
} from 'lucide-react';
import { formatTime24to12 } from '../../utils/prayerCalculator';

interface HeaderProps {
  onOpenQuickStudy?: () => void;
  onOpenAuth?: () => void;
  onOpenApkModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenQuickStudy,
  onOpenAuth,
  onOpenApkModal,
}) => {
  const {
    theme,
    toggleTheme,
    currentTime,
    nextPrayer,
    nextMedicationDose,
    notifications,
    markNotificationAsRead,
    clearAllNotifications,
    unreadNotificationsCount,
    conflicts,
    setActiveTab,
    setShowQuranModal,
    currentUser,
    isSyncing,
  } = useApp();

  const [showNotificationsMenu, setShowNotificationsMenu] = useState(false);

  // Arabic date formatting
  const arabicDateStr = currentTime.toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const formattedCurrentTime = currentTime.toLocaleTimeString('ar-EG', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#180e15]/95 backdrop-blur-md border-b border-rose-100 dark:border-rose-950/60 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-rose-600 via-pink-500 to-rose-400 flex items-center justify-center text-white shadow-sm shadow-rose-500/25">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-rose-100 whitespace-nowrap">
                يومي المنظم
              </h1>
              <span className="text-[10px] sm:text-xs font-medium text-rose-600 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 px-1.5 sm:px-2 py-0.5 rounded-md border border-rose-200 dark:border-rose-800/40">
                My Smart Day
              </span>
            </div>
            <p className="text-[11px] text-rose-700/70 dark:text-rose-300/70 hidden md:block">
              المساعد الذكي لتنظيم الدراسة والصلوات والأدوية
            </p>
          </div>
        </div>

        {/* Zone 2: Contextual Snapshot (Date, Live Clock, Next Prayer, Next Med) */}
        <div className="hidden xl:flex items-center gap-3 text-xs text-slate-600 dark:text-rose-200/80">
          <div className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/50 dark:border-rose-900/40">
            <Calendar className="w-3.5 h-3.5 text-rose-400" />
            <span>{arabicDateStr}</span>
          </div>

          <div className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/50 dark:border-rose-900/40 font-mono tabular-nums">
            <Clock className="w-3.5 h-3.5 text-rose-500" />
            <span className="font-semibold text-slate-900 dark:text-rose-100">
              {formattedCurrentTime}
            </span>
          </div>

          {nextPrayer && (
            <button
              onClick={() => setActiveTab('prayers')}
              className="flex items-center gap-1.5 hover:text-rose-600 transition-colors"
              title="عرض جدول الصلاة"
            >
              <span className="text-slate-400">القادمة:</span>
              <span className="font-medium text-rose-600 dark:text-rose-400">
                {nextPrayer.nameAr} ({formatTime24to12(nextPrayer.time)})
              </span>
            </button>
          )}

          {nextMedicationDose && (
            <button
              onClick={() => setActiveTab('meds')}
              className="flex items-center gap-1.5 hover:text-amber-600 transition-colors"
              title="عرض جدول الأدوية"
            >
              <Pill className="w-3.5 h-3.5 text-amber-500" />
              <span className="truncate max-w-[120px] font-medium text-slate-700 dark:text-slate-200">
                {nextMedicationDose.medication.name} ({formatTime24to12(nextMedicationDose.time)})
              </span>
            </button>
          )}
        </div>

        {/* Zone 3: Android APK, Email Link, Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Android APK Download Button */}
          <button
            onClick={onOpenApkModal}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold transition shadow-xs shadow-emerald-600/20 whitespace-nowrap"
            title="تثبيت التطبيق على أندرويد وتجميع ملف APK"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">تحميل APK أندرويد</span>
            <span className="sm:hidden">APK</span>
          </button>

          {/* Email Sync Account Button */}
          <button
            onClick={onOpenAuth}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold border transition whitespace-nowrap ${
              currentUser
                ? 'bg-rose-50 text-rose-800 dark:bg-rose-950/60 dark:text-rose-200 border-rose-200 dark:border-rose-900/50'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-rose-100 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
            title={
              currentUser
                ? `الحساب المرتبط: ${currentUser.email}`
                : 'ربط بالميل لمزامنة البيانات سحابياً بين جميع الأجهزة'
            }
          >
            {currentUser ? (
              <>
                <Cloud className={`w-3.5 h-3.5 text-emerald-500 ${isSyncing ? 'animate-spin' : ''}`} />
                <span className="truncate max-w-[80px] sm:max-w-[120px]">
                  {currentUser.displayName || currentUser.email?.split('@')[0]}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </>
            ) : (
              <>
                <Mail className="w-3.5 h-3.5 text-rose-500" />
                <span className="hidden sm:inline">ربط بالميل</span>
                <span className="sm:hidden">مزامنة</span>
              </>
            )}
          </button>

          {/* Conflict indicator alert if any */}
          {conflicts.length > 0 && (
            <button
              onClick={() => setActiveTab('schedule')}
              className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 text-xs font-medium border border-amber-200 dark:border-amber-800 transition-colors hover:bg-amber-100"
              title={`${conflicts.length} تعارض في الجدول الأسبوعي`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 animate-bounce" />
              <span className="hidden md:inline">{conflicts.length} تعارض</span>
            </button>
          )}

          {/* Quran Verse quick button (desktop) */}
          <button
            onClick={() => setShowQuranModal(true)}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 dark:bg-rose-950/60 dark:text-rose-200 border border-rose-200/60 dark:border-rose-900/40 transition-colors whitespace-nowrap"
            title="آية اليوم وتفسيرها"
          >
            <Sparkles className="w-3.5 h-3.5 text-rose-500" />
            <span>آية وتفسيرها</span>
          </button>

          {/* Notification Menu */}
          <div className="relative">
            <button
              onClick={() => setShowNotificationsMenu(!showNotificationsMenu)}
              className="relative p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="الإشعارات والتنبيهات"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1 left-1 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-rose-500 text-white text-[9px] sm:text-[10px] font-bold flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {showNotificationsMenu && (
              <div className="absolute left-0 mt-2 w-72 sm:w-80 md:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-4 z-50 animate-in fade-in zoom-in-95">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100">
                    التنبيهات الذكية ({notifications.length})
                  </h3>
                  {notifications.length > 0 && (
                    <button
                      onClick={clearAllNotifications}
                      className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      مسح الكل
                    </button>
                  )}
                </div>

                <div className="mt-3 max-h-80 overflow-y-auto space-y-2.5">
                  {notifications.length === 0 ? (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                      لا توجد تنبيهات جديدة في الوقت الحالي
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => markNotificationAsRead(notif.id)}
                        className={`p-3 rounded-lg text-right transition-colors cursor-pointer border ${
                          notif.isRead
                            ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800'
                            : 'bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/40'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-semibold mb-1 text-slate-800 dark:text-slate-200">
                          <span>{notif.title}</span>
                          <span className="text-[10px] font-normal text-slate-400 font-mono">
                            {notif.timestamp}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                          {notif.message}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            className="p-1.5 sm:p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={theme === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الليلي'}
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-slate-600" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
