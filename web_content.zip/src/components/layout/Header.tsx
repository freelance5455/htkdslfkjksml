import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Bell, Search, Menu, Sparkles } from "lucide-react";
import { useSidebar } from "@/context/SidebarContext";
import { cn } from "@/lib/utils";
import { getNotifications } from "@/lib/core3/notificationStore";
import NotificationCenterModal from "@/components/features/NotificationCenterModal";
import DailyBriefModal from "@/components/features/DailyBriefModal";
import CreateContentDropdown from "@/components/features/CreateContentDropdown";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  const navigate = useNavigate();
  const { isOpen, toggleSidebar } = useSidebar();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showDailyBrief, setShowDailyBrief] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const checkUnread = () => {
      const all = getNotifications();
      setUnreadCount(all.filter((n) => !n.read).length);
    };
    checkUnread();
    const interval = setInterval(checkUnread, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <header className="h-14 flex items-center justify-between px-4 sm:px-6 border-b border-studio-border bg-studio-bg/80 backdrop-blur-sm sticky top-0 z-30">
        <div className="flex items-center gap-3">
          {/* Menu (três barras) de navegação na barra superior à esquerda */}
          <button
            id="toggle-sidebar-button-left"
            onClick={toggleSidebar}
            title={isOpen ? "Recolher / Fechar menu lateral" : "Abrir / Expandir menu de navegação"}
            aria-label={isOpen ? "Fechar menu de navegação" : "Abrir menu de navegação"}
            className={cn(
              "p-2 rounded-lg border transition-all flex items-center justify-center cursor-pointer",
              isOpen
                ? "bg-studio-blue/15 border-studio-blue/40 text-studio-blue shadow-sm shadow-studio-blue/10"
                : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text hover:border-studio-blue/40 hover:bg-studio-border"
            )}
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <h1 className="text-base font-bold text-studio-text font-display">{title}</h1>
            {subtitle && <p className="text-xs text-studio-text-muted">{subtitle}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowDailyBrief(true)}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-studio-panel hover:bg-studio-border border border-studio-border text-studio-text-dim hover:text-studio-text transition-all hidden md:flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-studio-gold" />
            <span>Daily Brief</span>
          </button>

          <button
            onClick={() => setShowNotifications(true)}
            className="p-2 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-all relative flex"
            title="Notificações & Alertas do Autopilot"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 min-w-4 h-4 px-1 bg-studio-red text-white text-[9px] font-bold rounded-full flex items-center justify-center font-mono animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          <CreateContentDropdown variant="header" id="btn-header-criar-conteudo" />
        </div>
      </header>

      {/* Header Modals */}
      <NotificationCenterModal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        onNavigate={(url) => navigate(url)}
      />

      <DailyBriefModal
        isOpen={showDailyBrief}
        onClose={() => setShowDailyBrief(false)}
        onSelectAction={() => navigate("/autopilot")}
      />
    </>
  );
}
