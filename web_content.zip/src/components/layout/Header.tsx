import React, { useState, useRef, useEffect, useMemo } from 'react';
import { OmazifyLogo } from '../common/OmazifyLogo';
import {
  User, Heart, Bell, X,
  ArrowRight, LogOut, Package, MapPin,
  ArrowLeft, Clock, Search, Globe
} from 'lucide-react';
import { Product } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { searchProducts, getSearchSuggestions } from '../../services/searchService';

interface HeaderProps {
  currentTab: string;
  onNavigate: (tab: string, categoryFilter?: string, searchQuery?: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  onOpenAuth?: (mode?: 'login' | 'register' | 'otp') => void;
  onOpenAccount?: (tab?: 'profile' | 'orders' | 'addresses' | 'security') => void;
  onOpenNotifications?: () => void;
  deliveryCity?: string;
  deliveryPincode?: string;
  onOpenDeliveryLocation?: () => void;
}

const RECENT_SEARCHES_STORAGE_KEY = 'omazify_recent_searches';
const DEFAULT_RECENT_SEARCHES = [
  'sneakers',
  'shoes',
  'bags',
  'watches',
  't-shirts',
  'electronics',
];

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  wishlistCount,
  products,
  onSelectProduct,
  searchQuery: externalSearchQuery,
  onSearchChange,
  onOpenAuth,
  onOpenAccount,
  onOpenNotifications,
  deliveryCity = '',
  onOpenDeliveryLocation,
  onOpenWishlist,
}) => {
  const { user, isAuthenticated, logout, unreadNotificationCount } = useAuth();
  const { t, currentLanguageMeta, openLanguageModal } = useLanguage();
  const [internalSearchQuery, setInternalSearchQuery] = useState(externalSearchQuery || '');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback
    }
    return DEFAULT_RECENT_SEARCHES;
  });
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (externalSearchQuery !== undefined) {
      setInternalSearchQuery(externalSearchQuery);
    }
  }, [externalSearchQuery]);

  const addRecentSearch = (query: string) => {
    const clean = query.trim();
    if (!clean) return;
    const updated = [clean, ...recentSearches.filter((item) => item.toLowerCase() !== clean.toLowerCase())].slice(0, 8);
    setRecentSearches(updated);
    try {
      localStorage.setItem(RECENT_SEARCHES_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  const clearRecentSearches = (e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_STORAGE_KEY);
    } catch {
      // Ignore
    }
  };

  const handleOpenSearch = () => {
    setIsSearchOpen(true);
    setTimeout(() => {
      searchInputRef.current?.focus();
    }, 60);
  };

  const handleCloseSearch = () => {
    setIsSearchOpen(false);
  };

  const activeQuery = externalSearchQuery !== undefined ? externalSearchQuery : internalSearchQuery;

  const handleQueryChange = (val: string) => {
    setInternalSearchQuery(val);
    onSearchChange?.(val);
  };

  const handleClearSearch = () => {
    setInternalSearchQuery('');
    onSearchChange?.('');
    searchInputRef.current?.focus();
  };

  const handleSearchSubmit = (e?: React.FormEvent, customQuery?: string) => {
    if (e) e.preventDefault();
    const q = customQuery !== undefined ? customQuery : activeQuery;
    const trimmedQuery = q.trim();
    if (trimmedQuery) {
      addRecentSearch(trimmedQuery);
      onNavigate('shop', undefined, trimmedQuery);
      handleCloseSearch();
    }
  };

  const searchResultsData = useMemo(() => {
    return searchProducts(products, activeQuery);
  }, [products, activeQuery]);

  const liveSuggestions = useMemo(() => {
    return getSearchSuggestions(products, activeQuery);
  }, [products, activeQuery]);

  const filteredProducts = searchResultsData.exactMatches;

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-white border-b border-[#EAEAEA] shadow-xs">
        {/* TOP ROW */}
        <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-[52px] sm:h-[60px] gap-2">
            {/* LEFT: OMAZIFY Logo & Delivery Location */}
            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
              <button
                onClick={() => onNavigate('home')}
                className="flex-shrink-0 cursor-pointer focus:outline-none rounded-lg active:scale-98 transition-transform"
                aria-label="OMAZIFY Home"
              >
                <OmazifyLogo size="md" />
              </button>
              {onOpenDeliveryLocation && (
                <button
                  onClick={onOpenDeliveryLocation}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#111111] text-[11px] font-semibold border border-[#EAEAEA] transition-colors cursor-pointer max-w-[150px] truncate"
                  title={t('deliveryTo')}
                >
                  <MapPin className="w-3.5 h-3.5 text-[#111111] flex-shrink-0" />
                  <span className="truncate text-[#111111] font-bold">{deliveryCity || 'Select Location'}</span>
                </button>
              )}
            </div>

            {/* RIGHT: Notifications, Wishlist, Account */}
            <div className="flex items-center gap-2 sm:gap-4 flex-shrink-0">
              {/* Notification Icon */}
              {onOpenNotifications && (
                <button
                  onClick={onOpenNotifications}
                  className="text-[#111111] hover:text-[#000000] hover:bg-[#FAFAFA] rounded-full p-2 transition-colors relative cursor-pointer"
                  aria-label={t('notifications')}
                >
                  <Bell className="w-5 h-5 text-[#111111]" />
                  {unreadNotificationCount > 0 && (
                    <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-[#FFD400] text-[#000000] text-[10px] font-black rounded-full flex items-center justify-center ring-2 ring-white shadow-xs">
                      {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
                    </span>
                  )}
                </button>
              )}

              {/* Wishlist Icon */}
              <button
                onClick={onOpenWishlist}
                className="text-[#111111] hover:text-[#000000] hover:bg-[#FAFAFA] rounded-full p-2 transition-colors relative cursor-pointer"
                aria-label={`${t('wishlist')}, ${wishlistCount} items`}
              >
                <Heart className="w-5 h-5 text-[#111111]" />
                {wishlistCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-[#FFD400] text-[#000000] text-[10px] font-black rounded-full flex items-center justify-center ring-2 ring-white shadow-xs">
                    {wishlistCount}
                  </span>
                )}
              </button>

              {/* Account Icon */}
              <div className="relative">
                <button
                  onClick={() => {
                    if (!isAuthenticated) {
                      onOpenAuth?.('login');
                    } else {
                      setIsAccountOpen(!isAccountOpen);
                    }
                  }}
                  className="text-[#111111] hover:text-[#000000] hover:bg-[#FAFAFA] rounded-full p-1.5 transition-colors cursor-pointer flex items-center justify-center"
                  aria-label={t('account')}
                >
                  {isAuthenticated && user?.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.name}
                      className="w-7 h-7 rounded-full object-cover border border-[#111111]"
                    />
                  ) : isAuthenticated && user ? (
                    <div className="w-7 h-7 rounded-full bg-[#000000] text-[#FFD400] font-black text-xs flex items-center justify-center shadow-xs">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  ) : (
                    <User className="w-5 h-5 text-[#111111]" />
                  )}
                </button>

                {isAccountOpen && isAuthenticated && user && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-[#EAEAEA] py-2 z-50 text-xs animate-in fade-in duration-150">
                    <div className="px-4 py-3 border-b border-[#EAEAEA] bg-[#FAFAFA] flex items-center gap-3">
                      {user.photoURL ? (
                        <img
                          src={user.photoURL}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover border border-[#EAEAEA] flex-shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-[#000000] text-[#FFD400] font-bold text-sm flex items-center justify-center flex-shrink-0">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="font-bold text-[#111111] text-sm truncate">{user.name}</p>
                        <p className="text-[#666666] text-[11px] truncate">{user.email}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onOpenAccount?.('orders');
                        setIsAccountOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-[#FFF9DB] text-[#111111] hover:text-[#000000] flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <Package className="w-4 h-4 text-[#111111]" />
                      <span>{t('orders')}</span>
                    </button>
                    <button
                      onClick={() => {
                        onOpenAccount?.('addresses');
                        setIsAccountOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-[#FFF9DB] text-[#111111] hover:text-[#000000] flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <MapPin className="w-4 h-4 text-[#111111]" />
                      <span>{t('savedAddresses')}</span>
                    </button>
                    <button
                      onClick={() => {
                        onOpenAccount?.('profile');
                        setIsAccountOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-[#FFF9DB] text-[#111111] hover:text-[#000000] flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <User className="w-4 h-4 text-[#111111]" />
                      <span>{t('profileDetails')}</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsAccountOpen(false);
                        openLanguageModal();
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-[#FFF9DB] text-[#111111] hover:text-[#000000] flex items-center justify-between cursor-pointer font-medium"
                    >
                      <div className="flex items-center gap-2.5">
                        <Globe className="w-4 h-4 text-[#111111]" />
                        <span>{t('language')}</span>
                      </div>
                      <span className="text-[11px] font-bold text-[#111111] bg-[#FAFAFA] border border-[#EAEAEA] px-2 py-0.5 rounded">
                        {currentLanguageMeta.nativeName}
                      </span>
                    </button>
                    <div className="border-t border-[#EAEAEA] my-1"></div>
                    <button
                      onClick={() => {
                        logout();
                        setIsAccountOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-rose-50 text-rose-700 flex items-center gap-2.5 font-bold cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t('signOut')}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* SEARCH BAR ROW */}
        <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pb-2.5 pt-0.5">
          <div
            onClick={handleOpenSearch}
            className="group relative flex items-center w-full h-[44px] sm:h-[46px] pl-3.5 pr-1.5 bg-white hover:bg-white border border-[#EAEAEA] hover:border-[#111111] focus-within:border-[#111111] rounded-xl text-[#666666] text-xs sm:text-sm font-medium cursor-pointer shadow-2xs transition-all"
          >
            <Search className="w-4 h-4 text-[#111111] mr-2.5 flex-shrink-0 group-hover:scale-105 transition-transform" />
            <span className="truncate flex-1 text-[#666666] font-normal">
              {externalSearchQuery || t('searchPlaceholder')}
            </span>
            <div className="h-8 px-3.5 bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs rounded-lg flex items-center gap-1 transition-colors flex-shrink-0">
              <span>Search</span>
            </div>
          </div>
        </div>
      </header>

      {/* Expanded Search Dropdown / Overlay */}
      {isSearchOpen && (
        <div
          onClick={handleCloseSearch}
          className="fixed inset-0 bg-black/60 z-50 backdrop-blur-xs flex flex-col justify-start animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full bg-white border-b border-[#EAEAEA] shadow-2xl max-h-[85vh] overflow-y-auto flex flex-col animate-in slide-in-from-top-2 duration-150"
          >
            {/* Top search input line */}
            <div className="max-w-4xl mx-auto w-full px-4 py-3 flex items-center gap-2.5 border-b border-[#EAEAEA]">
              <button
                onClick={handleCloseSearch}
                className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] transition-colors cursor-pointer flex-shrink-0"
                aria-label={t('close')}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <form onSubmit={handleSearchSubmit} className="relative flex-1 flex items-center">
                <input
                  ref={searchInputRef}
                  type="text"
                  value={activeQuery}
                  onChange={(e) => handleQueryChange(e.target.value)}
                  placeholder={t('searchProducts')}
                  className="w-full h-11 pl-4 pr-10 text-xs sm:text-sm bg-[#FAFAFA] focus:bg-white text-[#111111] placeholder:text-[#666666] rounded-xl border border-[#EAEAEA] focus:border-[#000000] focus:outline-none focus:ring-2 focus:ring-[#FFD400] transition-all"
                />
                {activeQuery.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearSearch}
                    className="absolute right-3 text-[#666666] hover:text-[#111111] p-1.5 rounded-full cursor-pointer transition-colors"
                    aria-label={t('clearAll')}
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </form>
              <button
                type="button"
                onClick={() => handleSearchSubmit()}
                className="h-11 px-4 bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs rounded-xl flex items-center justify-center transition-colors cursor-pointer flex-shrink-0"
              >
                Search
              </button>
            </div>

            <div className="max-w-4xl mx-auto w-full">
              {!activeQuery && recentSearches.length > 0 && (
                <div className="p-4 border-b border-[#EAEAEA]">
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#111111] flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#111111]" />
                      <span>{t('recentSearches')}</span>
                    </span>
                    <button
                      onClick={clearRecentSearches}
                      className="text-[11px] text-[#666666] hover:text-[#111111] font-semibold cursor-pointer"
                    >
                      {t('clearAll')}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {recentSearches.map((item) => (
                      <button
                        key={item}
                        onClick={() => handleSearchSubmit(undefined, item)}
                        className="px-3 py-1.5 bg-[#FAFAFA] hover:bg-[#FFF9DB] text-xs font-medium text-[#111111] rounded-lg border border-[#EAEAEA] hover:border-[#FFD400] transition-colors cursor-pointer"
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {activeQuery && liveSuggestions.length > 0 && (
                <div className="p-3 border-b border-[#EAEAEA] bg-[#FAFAFA]/50">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#666666] px-2 mb-1.5">
                    {t('searchSuggestions')}
                  </p>
                  <div className="space-y-1">
                    {liveSuggestions.map((sugg) => (
                      <button
                        key={sugg}
                        onClick={() => handleSearchSubmit(undefined, sugg)}
                        className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-[#111111] hover:bg-[#FFF9DB] flex items-center gap-2 transition-colors cursor-pointer"
                      >
                        <Search className="w-3.5 h-3.5 text-[#111111]" />
                        <span>{sugg}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {activeQuery && filteredProducts.length > 0 && (
                <div className="p-3 max-h-72 overflow-y-auto divide-y divide-[#EAEAEA]">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#666666] px-2 pb-1.5">
                    {t('matchingProducts')}
                  </p>
                  {filteredProducts.slice(0, 5).map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => {
                        onSelectProduct(prod);
                        handleCloseSearch();
                      }}
                      className="flex items-center gap-3 p-2 hover:bg-[#FFF9DB]/70 rounded-xl cursor-pointer transition-colors"
                    >
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        className="w-11 h-11 object-cover rounded-lg bg-white border border-[#EAEAEA] flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-[#111111] truncate">{prod.name}</p>
                        <p className="text-[11px] text-[#000000] font-extrabold">₹{prod.price.toLocaleString()}</p>
                      </div>
                      <span className="text-[10px] text-[#111111] font-bold bg-[#FFD400] px-2 py-0.5 rounded flex-shrink-0">
                        COD
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {activeQuery && (
                <div className="p-3 bg-[#FAFAFA] border-t border-[#EAEAEA] text-center">
                  <button
                    onClick={() => handleSearchSubmit()}
                    className="text-xs font-black text-[#111111] hover:text-[#000000] bg-[#FFD400] hover:bg-[#FFC800] px-4 py-2 rounded-lg inline-flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                  >
                    <span>{t('viewAllResults')} "{activeQuery}"</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
