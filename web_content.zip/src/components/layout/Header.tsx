// Supermarket Application Header
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Building2,
  Clock,
  Wifi,
  UserCheck,
  LogOut,
  ShieldAlert,
  ChevronDown,
} from 'lucide-react';

interface HeaderProps {
  onOpenSwitcher: () => void;
  onOpenLogin: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSwitcher, onOpenLogin }) => {
  const { currentUser, currentBranch, allBranches, setCurrentBranch, logout } = useAuth();
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 text-white flex items-center justify-between px-4 sm:px-6 select-none shrink-0 z-20">
      {/* Left Branding & Store Branch */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-white shadow-md shadow-emerald-900/30">
            A
          </div>
          <div>
            <div className="font-bold text-base tracking-tight leading-none text-slate-100 flex items-center gap-2">
              APEX GRAND
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-medium border border-emerald-500/30 uppercase tracking-widest">
                POS
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">Enterprise Retail System</div>
          </div>
        </div>

        {/* Branch Selector */}
        <div className="hidden md:flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/70 rounded-lg px-2.5 py-1 text-xs">
          <Building2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">Branch:</span>
          <select
            value={currentBranch.id}
            onChange={(e) => {
              const b = allBranches.find((br) => br.id === e.target.value);
              if (b) setCurrentBranch(b);
            }}
            className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer pr-1"
          >
            {allBranches.map((branch) => (
              <option key={branch.id} value={branch.id} className="bg-slate-900 text-white">
                {branch.name} ({branch.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Center Digital Clock & System Online Status */}
      <div className="hidden lg:flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-xs text-slate-300 bg-slate-800/50 px-3 py-1 rounded-md border border-slate-700/50">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-mono tracking-wide">{timeStr}</span>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 px-2.5 py-1 rounded-md">
          <Wifi className="w-3.5 h-3.5 animate-pulse" />
          <span className="font-semibold">ONLINE</span>
          <span className="text-[10px] text-emerald-300/70 font-mono">(Cloud Live)</span>
        </div>
      </div>

      {/* Right User & RBAC Controls */}
      <div className="flex items-center gap-3">
        {currentUser ? (
          <div className="flex items-center gap-2">
            {/* Quick RBAC Switcher Button */}
            <button
              onClick={onOpenSwitcher}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700/90 border border-slate-700 px-3 py-1.5 rounded-lg text-xs transition-colors"
              title="Switch user role for testing RBAC"
            >
              <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-slate-200 font-bold text-[10px]">
                {currentUser.name.charAt(0)}
              </div>
              <div className="text-left hidden sm:block">
                <div className="font-semibold text-slate-200 leading-tight flex items-center gap-1">
                  {currentUser.name.split(' ')[0]}
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </div>
                <div className="text-[10px] text-emerald-400 font-mono tracking-wider">
                  {currentUser.role}
                </div>
              </div>
            </button>

            <button
              onClick={logout}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenLogin}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs px-3.5 py-1.5 rounded-lg transition-colors"
          >
            <UserCheck className="w-4 h-4" />
            Sign In
          </button>
        )}
      </div>
    </header>
  );
};
