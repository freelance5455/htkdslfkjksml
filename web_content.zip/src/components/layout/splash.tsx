import { BrandMark, Wordmark } from "@/components/brand/logo";

export function Splash({ message = "در حال آماده‌سازی دفاتر" }: { message?: string }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-navy px-6 text-cream">
      <BrandMark className="size-16" />
      <div className="mt-8">
        <Wordmark light />
      </div>
      <p className="mt-8 text-sm text-cream/60">Professional Accounting System</p>
      <div className="gold-rule mt-10 w-40" />
      <p className="mt-6 text-xs tracking-wide text-gold-2">{message}</p>
    </div>
  );
}
