import React from 'react';
import { Home, Users, Clapperboard, MessageSquare, Menu } from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  unreadMessagesCount: number;
  onOpenMobileMenu: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  setCurrentTab,
  unreadMessagesCount,
  onOpenMobileMenu
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 md:hidden h-16 px-2 flex items-center justify-around">
      <button
        onClick={() => setCurrentTab('feed')}
        className={`flex flex-col items-center justify-center min-w-[54px] py-1 transition-colors ${
          currentTab === 'feed' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] tracking-tight mt-1">Início</span>
      </button>

      <button
        onClick={() => setCurrentTab('friends')}
        className={`flex flex-col items-center justify-center min-w-[54px] py-1 transition-colors ${
          currentTab === 'friends' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Users className="w-5 h-5" />
        <span className="text-[10px] tracking-tight mt-1">Amigos</span>
      </button>

      <button
        onClick={() => setCurrentTab('stories')}
        className={`flex flex-col items-center justify-center min-w-[54px] py-1 transition-colors ${
          currentTab === 'stories' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Clapperboard className="w-5 h-5" />
        <span className="text-[10px] tracking-tight mt-1">Stories</span>
      </button>

      <button
        onClick={() => setCurrentTab('messages')}
        className={`relative flex flex-col items-center justify-center min-w-[54px] py-1 transition-colors ${
          currentTab === 'messages' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <MessageSquare className="w-5 h-5" />
        {unreadMessagesCount > 0 && (
          <span className="absolute top-0.5 right-2 w-4 h-4 bg-red-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
            {unreadMessagesCount}
          </span>
        )}
        <span className="text-[10px] tracking-tight mt-1">Chat</span>
      </button>

      <button
        onClick={onOpenMobileMenu}
        className="flex flex-col items-center justify-center min-w-[54px] py-1 text-slate-400 hover:text-slate-200 transition-colors"
      >
        <Menu className="w-5 h-5" />
        <span className="text-[10px] tracking-tight mt-1">Menu</span>
      </button>
    </nav>
  );
};
