import React from 'react';

export type BottomNavTab = 'home' | 'categories' | 'deals' | 'account' | 'cart';

interface BottomNavProps {
  currentTab: string;
  onNavigateTab: (tab: BottomNavTab) => void;
  cartCount: number;
  activeCategoryFilter?: string;
}

/* =========================================================================
   INDIVIDUAL NAVIGATION ICONS
   Active: SOLID BLACK with YELLOW ACCENT (#FFD400) or FILLED BLACK
   Inactive: CLEAN NEUTRAL OUTLINE (#666666)
   ========================================================================= */

// 1. Home Icon
const HomeNavIcon: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (isActive) {
    return (
      <svg
        viewBox="0 0 24 24"
        className="w-[22px] h-[22px] transition-transform duration-150 transform scale-105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <path
          d="M10.84 2.37a1.6 1.6 0 0 1 2.32 0l7.8 7.02a1.6 1.6 0 0 1 .53 1.19V19.5a2.5 2.5 0 0 1-2.5 2.5H15a1 1 0 0 1-1-1v-5a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v5a1 1 0 0 1-1 1H5.01A2.5 2.5 0 0 1 2.5 19.5v-8.92a1.6 1.6 0 0 1 .53-1.19l7.81-7.02z"
          fill="#000000"
        />
        <circle cx="12" cy="11" r="2" fill="#FFD400" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      className="w-[22px] h-[22px] transition-colors duration-150 text-[#666666]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  );
};

// 2. Category Icon (4-Square Grid)
const CategoryNavIcon: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (isActive) {
    return (
      <svg
        viewBox="0 0 24 24"
        className="w-[22px] h-[22px] transition-transform duration-150 transform scale-105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <rect x="3" y="3" width="7.5" height="7.5" rx="1.8" fill="#000000" />
        <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.8" fill="#FFD400" />
        <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.8" fill="#000000" />
        <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.8" fill="#000000" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      className="w-[22px] h-[22px] transition-colors duration-150 text-[#666666]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect width="7.5" height="7.5" x="3" y="3" rx="1.5" />
      <rect width="7.5" height="7.5" x="13.5" y="3" rx="1.5" />
      <rect width="7.5" height="7.5" x="13.5" y="13.5" rx="1.5" />
      <rect width="7.5" height="7.5" x="3" y="13.5" rx="1.5" />
    </svg>
  );
};

// 3. Deals Icon
const DealsNavIcon: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (isActive) {
    return (
      <svg
        viewBox="0 0 24 24"
        className="w-[22px] h-[22px] transition-transform duration-150 transform scale-105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <path
          d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"
          fill="#000000"
        />
        <path d="m15 9-6 6" stroke="#FFD400" strokeWidth="2.4" strokeLinecap="round" />
        <circle cx="9.2" cy="9.2" r="1.3" fill="#FFD400" />
        <circle cx="14.8" cy="14.8" r="1.3" fill="#FFD400" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      className="w-[22px] h-[22px] transition-colors duration-150 text-[#666666]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" />
      <path d="m15 9-6 6" />
      <path d="M9 9h.01" />
      <path d="M15 15h.01" />
    </svg>
  );
};

// 4. Account Icon
const AccountNavIcon: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (isActive) {
    return (
      <svg
        viewBox="0 0 24 24"
        className="w-[22px] h-[22px] transition-transform duration-150 transform scale-105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <circle cx="12" cy="7" r="4.2" fill="#FFD400" stroke="#000000" strokeWidth="1" />
        <path
          d="M12 13c-4.42 0-8 2.24-8 5v1.2a1.8 1.8 0 0 0 1.8 1.8h12.4a1.8 1.8 0 0 0 1.8-1.8V18c0-2.76-3.58-5-8-5z"
          fill="#000000"
        />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      className="w-[22px] h-[22px] transition-colors duration-150 text-[#666666]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
};

// 5. Cart Icon
const CartNavIcon: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (isActive) {
    return (
      <svg
        viewBox="0 0 24 24"
        className="w-[22px] h-[22px] transition-transform duration-150 transform scale-105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <circle cx="8" cy="20.5" r="1.8" fill="#FFD400" />
        <circle cx="18.5" cy="20.5" r="1.8" fill="#FFD400" />
        <path
          d="M2 2.5h2.2l1.25 5.5h14.05a1 1 0 0 1 .98 1.22l-1.6 7a2 2 0 0 1-1.95 1.58H8.5a2 2 0 0 1-1.96-1.58L4.1 4.5H2a1 1 0 0 1 0-2z"
          fill="#000000"
        />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      className="w-[22px] h-[22px] transition-colors duration-150 text-[#666666]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <circle cx="8" cy="21" r="1.5" />
      <circle cx="19" cy="21" r="1.5" />
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
    </svg>
  );
};

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onNavigateTab,
  cartCount,
  activeCategoryFilter,
}) => {
  const navItems = [
    {
      id: 'home' as BottomNavTab,
      label: 'Home',
      renderIcon: (isActive: boolean) => <HomeNavIcon isActive={isActive} />,
    },
    {
      id: 'categories' as BottomNavTab,
      label: 'Categories',
      renderIcon: (isActive: boolean) => <CategoryNavIcon isActive={isActive} />,
    },
    {
      id: 'deals' as BottomNavTab,
      label: 'Deals',
      renderIcon: (isActive: boolean) => <DealsNavIcon isActive={isActive} />,
    },
    {
      id: 'account' as BottomNavTab,
      label: 'Account',
      renderIcon: (isActive: boolean) => <AccountNavIcon isActive={isActive} />,
    },
    {
      id: 'cart' as BottomNavTab,
      label: 'Cart',
      renderIcon: (isActive: boolean) => <CartNavIcon isActive={isActive} />,
      badge: cartCount > 0 ? cartCount : undefined,
    },
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#EAEAEA] shadow-[0_-2px_10px_rgba(0,0,0,0.05)] select-none"
      style={{
        paddingBottom: 'max(0.35rem, env(safe-area-inset-bottom, 0.35rem))',
      }}
      aria-label="Bottom Navigation Bar"
    >
      <div className="max-w-md md:max-w-lg mx-auto px-1 grid grid-cols-5 items-center h-[54px] sm:h-[58px]">
        {navItems.map((item) => {
          const isActive =
            currentTab === item.id ||
            (item.id === 'deals' && currentTab === 'shop' && activeCategoryFilter === 'Offers') ||
            (item.id === 'home' &&
              (currentTab === 'policies' || currentTab === 'support')) ||
            (item.id === 'account' &&
              (currentTab === 'orders' || currentTab === 'wishlist' || currentTab === 'addresses'));

          return (
            <button
              key={item.id}
              onClick={() => onNavigateTab(item.id)}
              className="group relative flex flex-col items-center justify-center w-full h-full py-1 cursor-pointer transition-transform active:scale-95 focus:outline-hidden"
              aria-label={item.label}
              aria-current={isActive ? 'page' : undefined}
            >
              {/* Icon Container with Badge */}
              <div className="relative flex items-center justify-center">
                {item.renderIcon(isActive)}

                {/* Cart Notification Badge */}
                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-[#000000] text-[#FFD400] text-[9px] font-black flex items-center justify-center ring-2 ring-white shadow-xs leading-none">
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
              </div>

              {/* Label directly underneath icon */}
              <span
                className={`text-[10px] sm:text-[11px] tracking-tight mt-0.5 leading-tight truncate max-w-full transition-colors duration-150 ${
                  isActive
                    ? 'text-[#000000] font-black'
                    : 'text-[#666666] font-medium group-hover:text-[#111111]'
                }`}
              >
                {item.label}
              </span>

              {/* Active dot indicator */}
              {isActive && (
                <div className="w-1 h-1 rounded-full mt-0.5 bg-[#FFD400]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
