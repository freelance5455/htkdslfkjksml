import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Compass, Calculator, Wrench, Menu } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { playSound, triggerHaptic } = useApp();

  const handleNavClick = () => {
    playSound('tab');
    triggerHaptic('light');
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0D0D0D]/95 backdrop-blur-lg border-t border-[#303030] xl:hidden transition-colors">
      <div className="grid grid-cols-5 h-16 max-w-lg mx-auto px-1">
        <NavLink
          to="/"
          onClick={handleNavClick}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 min-h-[44px] transition-all ${
              isActive ? 'text-[#D65A1F] font-semibold' : 'text-[#A9A39C] hover:text-[#F5F2ED]'
            }`
          }
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Home</span>
        </NavLink>

        <NavLink
          to="/explore"
          onClick={handleNavClick}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 min-h-[44px] transition-all ${
              isActive ? 'text-[#D65A1F] font-semibold' : 'text-[#A9A39C] hover:text-[#F5F2ED]'
            }`
          }
        >
          <Compass className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Explore</span>
        </NavLink>

        <NavLink
          to="/calculator"
          onClick={handleNavClick}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 min-h-[44px] transition-all ${
              isActive ? 'text-[#D65A1F] font-semibold' : 'text-[#A9A39C] hover:text-[#F5F2ED]'
            }`
          }
        >
          <div className="p-1 rounded-xl bg-[#232323] border border-[#303030]">
            <Calculator className="w-4 h-4 text-[#D65A1F]" />
          </div>
          <span className="text-[10px] tracking-tight">Calc</span>
        </NavLink>

        <NavLink
          to="/tools"
          onClick={handleNavClick}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 min-h-[44px] transition-all ${
              isActive ? 'text-[#D65A1F] font-semibold' : 'text-[#A9A39C] hover:text-[#F5F2ED]'
            }`
          }
        >
          <Wrench className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Tools</span>
        </NavLink>

        <NavLink
          to="/more"
          onClick={handleNavClick}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 min-h-[44px] transition-all ${
              isActive ? 'text-[#D65A1F] font-semibold' : 'text-[#A9A39C] hover:text-[#F5F2ED]'
            }`
          }
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">More</span>
        </NavLink>
      </div>
    </nav>
  );
};

