import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Heart, Library, MoreHorizontal, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const ITEMS = [
  { to: "/quran", label: "القرآن", icon: BookOpen, match: (p: string) => p === "/" || p.startsWith("/quran") },
  { to: "/adhkar", label: "الأذكار", icon: Sparkles, match: (p: string) => p.startsWith("/adhkar") },
  { to: "/library", label: "المكتبة", icon: Library, match: (p: string) => p.startsWith("/library") },
  { to: "/favorites", label: "المفضلة", icon: Heart, match: (p: string) => p.startsWith("/favorites") },
  { to: "/more", label: "المزيد", icon: MoreHorizontal, match: (p: string) => p.startsWith("/more") || p.startsWith("/listen") || p.startsWith("/search") },
];

export function BottomNav() {
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-paper/95 backdrop-blur-md"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="التنقل الرئيسي"
    >
      <ul className="mx-auto grid max-w-lg grid-cols-5">
        {ITEMS.map((item) => {
          const active = item.match(path);
          const Icon = item.icon;
          return (
            <li key={item.to}>
              <Link
                to={item.to}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium transition-colors duration-[var(--motion-quick)]",
                  active ? "text-accent" : "text-muted-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                <span>{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
