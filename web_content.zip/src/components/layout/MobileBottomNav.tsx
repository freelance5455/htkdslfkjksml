import React, { useState } from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  CalendarDays,
  Compass,
  Grid,
  Bell,
  Pill,
  BookOpen,
  Calendar,
  Timer,
  BarChart3,
  Settings,
  Smartphone,
  Cloud,
  X,
  Sparkles,
  Download,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface MobileBottomNavProps {
  onOpenAuth: () => void;
  onOpenApkModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  onOpenAuth,
  onOpenApkModal,
}) => {
  const {
    activeTab,
    setActiveTab,
    conflicts,
    currentUser,
    isSyncing,
    alarms,
    medications,
    nextPrayer,
  } = useApp();

  const [showMoreDrawer, setShowMoreDrawer] = useState(false);

  const enabledAlarms = alarms.filter((a) => a.isEnabled).length;
  const activeMeds = medications.filter((m) => m.active).length;

  const handleTabSelect = (tabId: string) => {
    setActiveTab(tabId);
    setShowMoreDrawer(false);
  };

  return (
    <>
      {/* Mobile Drawer (Android Bottom Sheet) */}
      {showMoreDrawer && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div
            className="fixed inset-0"
            onClick={() => setShowMoreDrawer(false)}
          />
          <div className="relative bg-white dark:bg-[#1c0f1b] rounded-t-3xl border-t border-rose-200 dark:border-rose-900 shadow-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom">
            {/* Sheet Handle */}
            <div className="w-12 h-1.5 rounded-full bg-slate-300 dark:bg-rose-900/60 mx-auto -mt-1 mb-2" />

            <div className="flex items-center justify-between pb-3 border-b border-rose-100 dark:border-rose-950/60">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 dark:text-rose-100 text-sm">
                  كافة أقسام التطبيق
                </span>
                <span className="text-[10px] font-semibold text-rose-600 bg-rose-50 dark:bg-rose-950/80 px-2 py-0.5 rounded-full">
                  Android Drawer
                </span>
              </div>
              <button
                onClick={() => setShowMoreDrawer(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-rose-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Actions (APK Download & Cloud Sync) */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  setShowMoreDrawer(false);
                  onOpenApkModal();
                }}
                className="p-3 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/20 border border-emerald-200 dark:border-emerald-800 text-right flex flex-col justify-between transition active:scale-98"
              >
                <div className="flex items-center justify-between">
                  <Smartphone className="w-5 h-5 text-emerald-600" />
                  <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                    APK
                  </span>
                </div>
                <div className="mt-2">
                  <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 block">
                    تثبيت APK
                  </span>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-300">
                    تحميل لهاتف أندرويد
                  </span>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowMoreDrawer(false);
                  onOpenAuth();
                }}
                className="p-3 rounded-2xl bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/40 dark:to-pink-950/20 border border-rose-200 dark:border-rose-900 text-right flex flex-col justify-between transition active:scale-98"
              >
                <div className="flex items-center justify-between">
                  <Cloud className={`w-5 h-5 text-rose-600 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span className="text-[10px] font-bold bg-rose-600 text-white px-2 py-0.5 rounded-full">
                    {currentUser ? 'متصل' : 'سجل الآن'}
                  </span>
                </div>
                <div className="mt-2">
                  <span className="text-xs font-bold text-rose-900 dark:text-rose-200 block">
                    مزامنة البريد
                  </span>
                  <span className="text-[10px] text-rose-700 dark:text-rose-300 truncate block">
                    {currentUser ? currentUser.email : 'حفظ البيانات سحابياً'}
                  </span>
                </div>
              </button>
            </div>

            {/* Menu Grid */}
            <div className="grid grid-cols-2 gap-2 text-right">
              <button
                onClick={() => handleTabSelect('calendar')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'calendar'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <Calendar className="w-4 h-4 text-rose-500 shrink-0" />
                <span>التقويم والمهام</span>
              </button>

              <button
                onClick={() => handleTabSelect('adhkar')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'adhkar'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <BookOpen className="w-4 h-4 text-rose-500 shrink-0" />
                <span>أذكار الصباح والمساء</span>
              </button>

              <button
                onClick={() => handleTabSelect('alarms')}
                className={`flex items-center justify-between p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'alarms'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>المنبهات الذكية</span>
                </div>
                {enabledAlarms > 0 && (
                  <span className="text-[10px] bg-rose-200 dark:bg-rose-900 text-rose-900 dark:text-rose-100 px-1.5 py-0.2 rounded-full font-mono">
                    {enabledAlarms}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleTabSelect('meds')}
                className={`flex items-center justify-between p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'meds'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Pill className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>متتبع الأدوية</span>
                </div>
                {activeMeds > 0 && (
                  <span className="text-[10px] bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 px-1.5 py-0.2 rounded-full font-mono">
                    {activeMeds}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleTabSelect('pomodoro')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'pomodoro'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <Timer className="w-4 h-4 text-rose-500 shrink-0" />
                <span>مؤقت التركيز</span>
              </button>

              <button
                onClick={() => handleTabSelect('stats')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'stats'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-rose-500 shrink-0" />
                <span>الإحصائيات والتقدم</span>
              </button>

              <button
                onClick={() => handleTabSelect('settings')}
                className={`col-span-2 flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-semibold transition ${
                  activeTab === 'settings'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-300 dark:border-slate-800 text-slate-800 dark:text-rose-100 hover:bg-rose-50/50'
                }`}
              >
                <Settings className="w-4 h-4 text-slate-500 shrink-0" />
                <span>الإعدادات والنسخ الاحتياطي السحابي</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Docked Android Bottom Navigation Bar */}
      <nav
        aria-label="شريط تنقل الهاتف"
        className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-white/95 dark:bg-[#180e15]/95 backdrop-blur-lg border-t border-rose-200/70 dark:border-rose-950/80 px-2 py-1.5 transition-colors shadow-lg"
      >
        <div className="max-w-md mx-auto grid grid-cols-5 items-center">
          {/* Tab 1: Dashboard */}
          <button
            onClick={() => handleTabSelect('dashboard')}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative ${
              activeTab === 'dashboard'
                ? 'text-rose-600 dark:text-rose-400 font-bold'
                : 'text-slate-500 dark:text-rose-300/60 hover:text-slate-900'
            }`}
          >
            <div
              className={`p-1 rounded-xl transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-rose-100 dark:bg-rose-950/80 scale-105'
                  : ''
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
            </div>
            <span className="text-[11px] mt-0.5">الرئيسية</span>
          </button>

          {/* Tab 2: Study */}
          <button
            onClick={() => handleTabSelect('study')}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative ${
              activeTab === 'study'
                ? 'text-rose-600 dark:text-rose-400 font-bold'
                : 'text-slate-500 dark:text-rose-300/60 hover:text-slate-900'
            }`}
          >
            <div
              className={`p-1 rounded-xl transition-all ${
                activeTab === 'study' ? 'bg-rose-100 dark:bg-rose-950/80 scale-105' : ''
              }`}
            >
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="text-[11px] mt-0.5">المذاكرة</span>
          </button>

          {/* Tab 3: Schedule */}
          <button
            onClick={() => handleTabSelect('schedule')}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative ${
              activeTab === 'schedule'
                ? 'text-rose-600 dark:text-rose-400 font-bold'
                : 'text-slate-500 dark:text-rose-300/60 hover:text-slate-900'
            }`}
          >
            <div
              className={`p-1 rounded-xl transition-all relative ${
                activeTab === 'schedule'
                  ? 'bg-rose-100 dark:bg-rose-950/80 scale-105'
                  : ''
              }`}
            >
              <CalendarDays className="w-5 h-5" />
              {conflicts.length > 0 && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              )}
            </div>
            <span className="text-[11px] mt-0.5">الجدول</span>
          </button>

          {/* Tab 4: Prayers */}
          <button
            onClick={() => handleTabSelect('prayers')}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative ${
              activeTab === 'prayers'
                ? 'text-rose-600 dark:text-rose-400 font-bold'
                : 'text-slate-500 dark:text-rose-300/60 hover:text-slate-900'
            }`}
          >
            <div
              className={`p-1 rounded-xl transition-all ${
                activeTab === 'prayers'
                  ? 'bg-rose-100 dark:bg-rose-950/80 scale-105'
                  : ''
              }`}
            >
              <Compass className="w-5 h-5" />
            </div>
            <span className="text-[11px] mt-0.5">الصلوات</span>
          </button>

          {/* Tab 5: More Drawer */}
          <button
            onClick={() => setShowMoreDrawer(true)}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative ${
              showMoreDrawer
                ? 'text-rose-600 dark:text-rose-400 font-bold'
                : 'text-slate-500 dark:text-rose-300/60 hover:text-slate-900'
            }`}
          >
            <div className="p-1 rounded-xl transition-all relative">
              <Grid className="w-5 h-5" />
              {currentUser && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500" />
              )}
            </div>
            <span className="text-[11px] mt-0.5">المزيد</span>
          </button>
        </div>
      </nav>
    </>
  );
};
