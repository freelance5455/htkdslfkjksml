// Enterprise Supermarket Application Shell
import React, { useState } from 'react';
import { Header } from './Header';
import { Sidebar, ActiveTab } from './Sidebar';
import { DashboardView } from '../dashboard/DashboardView';
import { POSView } from '../pos/POSView';
import { ProductsView } from '../products/ProductsView';
import { InventoryView } from '../inventory/InventoryView';
import { PurchasingView } from '../purchasing/PurchasingView';
import { SuppliersView } from '../suppliers/SuppliersView';
import { CustomersView } from '../customers/CustomersView';
import { CashRegisterView } from '../cash-register/CashRegisterView';
import { ReportsView } from '../reports/ReportsView';
import { AuditLogsView } from '../audit-logs/AuditLogsView';
import { DatabaseView } from '../database/DatabaseView';
import { SettingsView } from '../settings/SettingsView';
import { UserRoleSwitcher } from '../auth/UserRoleSwitcher';
import { LoginModal } from '../auth/LoginModal';

export const AppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Application Bar */}
      <Header
        onOpenSwitcher={() => setIsSwitcherOpen(true)}
        onOpenLogin={() => setIsLoginOpen(true)}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} />

        {/* Content Canvas */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {activeTab === 'dashboard' && <DashboardView onNavigate={setActiveTab} />}
          {activeTab === 'pos' && <POSView />}
          {activeTab === 'products' && <ProductsView />}
          {activeTab === 'inventory' && <InventoryView />}
          {activeTab === 'purchasing' && <PurchasingView />}
          {activeTab === 'suppliers' && <SuppliersView />}
          {activeTab === 'customers' && <CustomersView />}
          {activeTab === 'cash-register' && <CashRegisterView />}
          {activeTab === 'reports' && <ReportsView />}
          {activeTab === 'audit-logs' && <AuditLogsView />}
          {activeTab === 'database' && <DatabaseView />}
          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Auth & RBAC Modals */}
      <UserRoleSwitcher isOpen={isSwitcherOpen} onClose={() => setIsSwitcherOpen(false)} />
      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
    </div>
  );
};
