import { useEffect, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Pause, Play, Timer } from 'lucide-react';
import { BottomNav, MobileTopBar, MoreSheetBody, Sidebar } from './Nav';
import { Modal } from '../ui/Feedback';
import { useProfile } from '../../hooks/useProfile';
import { useSettings } from '../../hooks/useSettings';
import { EMPTY_WALLET, rewardForId } from '../../services/economy';
import { KEYS, useStored } from '../../services/storage';
import { syncAchievementUnlocks } from '../../services/gamification';
import { StudySessionProvider, useStudySession } from '../../hooks/useStudySession';
import { subjects } from '../../data/content';
import { EMPTY_FARM } from '../../services/farmModel';

function clock(seconds: number): string {
  const minutes = Math.floor(Math.max(0, seconds) / 60);
  const rest = Math.max(0, seconds) % 60;
  return `${minutes.toString().padStart(2, '0')}:${rest.toString().padStart(2, '0')}`;
}

export function AppShell() {
  return <StudySessionProvider><AppShellLayout /></StudySessionProvider>;
}

function StudySessionBanner() {
  const session = useStudySession();
  const sessionSubject = subjects.find((subject) => subject.id === session.subjectId)?.name ?? 'الدراسة';

  if (session.status === 'idle') return null;
  return (
    <div className="mx-auto w-full max-w-4xl px-4 pt-2 lg:px-8" role="status" aria-live="polite">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 py-2 shadow-sm">
        <span className="text-xs font-semibold text-[var(--ink)]">{session.status === 'completed' ? 'اكتملت الجلسة' : session.status === 'paused' ? session.pauseReason === 'hidden' ? 'توقفت عند إخفاء التطبيق' : session.pauseReason === 'idle' ? 'توقفت بعد خمس دقائق بلا نشاط' : 'الجلسة متوقفة مؤقتاً' : 'جلسة نشطة'} · {sessionSubject}</span>
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm tabular-nums text-[var(--ink)]">{clock(session.elapsedSeconds)} / {clock(session.durationSeconds)}</span>
          <Link to="/study-session" className="focus-ring flex min-h-11 items-center gap-1 rounded-xl bg-[var(--gold-soft)] px-3 text-xs font-semibold text-[var(--ink)]"><Timer size={15} /> المؤقت</Link>
          {session.status === 'running' ? (
            <button type="button" onClick={session.pause} aria-label="إيقاف الجلسة مؤقتاً" className="focus-ring flex min-h-11 items-center gap-1 rounded-xl bg-[var(--surface-2)] px-3 text-xs text-[var(--ink)]"><Pause size={15} /> إيقاف</button>
          ) : session.status === 'paused' ? (
            <button type="button" onClick={session.resume} aria-label="استئناف الجلسة" className="focus-ring flex min-h-11 items-center gap-1 rounded-xl bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]"><Play size={15} /> استئناف</button>
          ) : null}
          <button type="button" onClick={session.end} className="focus-ring min-h-11 rounded-xl px-2 text-xs text-[var(--ink-soft)]">إنهاء</button>
        </div>
      </div>
    </div>
  );
}

function SyncStudySessionWithRoute() {
  const location = useLocation();
  const session = useStudySession();
  useEffect(() => {
    const match = location.pathname.match(/^\/(?:lesson|subject)\/([^/]+)/);
    const subjectId = match?.[1];
    if (subjectId && subjectId !== session.subjectId && subjects.some((subject) => subject.id === subjectId)) {
      session.setSubject(subjectId);
    }
  }, [location.pathname, session.subjectId, session.setSubject]);
  return null;
}

function AppShellLayout() {
  useSettings();
  const { profile } = useProfile();
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const progress = useStored(KEYS.progress, {});
  const stats = useStored(KEYS.stats, { days: {} });
  const quizzes = useStored(KEYS.quizzes, []);
  const cards = useStored(KEYS.cards, {});
  const farm = useStored(KEYS.farm, EMPTY_FARM);
  const practiceAttempts = useStored(KEYS.practiceAttempts, []);
  const writtenAnswers = useStored(KEYS.writtenAnswers, []);
  const [moreOpen, setMoreOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const root = document.documentElement;
    const attributes: Array<[string, string | undefined]> = [
      ['rewardAccent', rewardForId(wallet.equipped.accent)?.value],
      ['rewardFrame', rewardForId(wallet.equipped.frame)?.value],
      ['rewardBanner', rewardForId(wallet.equipped.banner)?.value],
    ];
    for (const [key, value] of attributes) {
      if (value) root.dataset[key] = value;
      else delete root.dataset[key];
    }
  }, [wallet.equipped]);

  useEffect(() => {
    void syncAchievementUnlocks().catch((error: unknown) => console.error('تعذّر مزامنة الإنجازات', error));
  }, [wallet, progress, stats, quizzes, cards, farm, practiceAttempts, writtenAnswers]);

  return (
    <div className="min-h-dvh bg-[var(--bg)] lg:grid lg:grid-cols-[17rem_1fr]">
      <Sidebar studentName={profile.name} balance={wallet.balance} />
      <div className="flex min-h-dvh flex-col">
        <MobileTopBar balance={wallet.balance} />
        <SyncStudySessionWithRoute />
        <StudySessionBanner />
        <AnimatePresence mode="wait">
          <motion.main
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="mx-auto w-full max-w-3xl flex-1 px-4 pb-28 pt-3 lg:max-w-4xl lg:px-8 lg:pb-12 lg:pt-8"
            id="main-content"
          >
            <Outlet />
          </motion.main>
        </AnimatePresence>
      </div>
      <BottomNav onMore={() => setMoreOpen(true)} />
      <Modal open={moreOpen} onClose={() => setMoreOpen(false)} title="المزيد">
        <MoreSheetBody onNavigate={() => setMoreOpen(false)} />
      </Modal>
    </div>
  );
}
