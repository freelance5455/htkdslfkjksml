import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  Calculator,
  Wrench,
  BookOpen,
  History,
  Bookmark,
  Settings,
  Volume2,
  VolumeX,
  Search,
  Sigma,
  Sparkles
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { settings, updateSettings, playSound, triggerHaptic } = useApp();
  const navigate = useNavigate();

  const toggleSound = () => {
    const next = !settings.soundEnabled;
    updateSettings({ soundEnabled: next });
    if (next) playSound('button');
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#303030] bg-[#0D0D0D]/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <Link
            to="/"
            onClick={() => playSound('tab')}
            className="flex items-center gap-3 group shrink-0"
          >
            <div className="w-9 h-9 rounded-xl bg-[#232323] border border-[#303030] flex items-center justify-center text-[#D65A1F] group-hover:border-[#D65A1F] transition-colors shadow-sm">
              <Sigma className="w-5 h-5 text-[#D65A1F]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight text-[#F5F2ED] group-hover:text-[#D65A1F] transition-colors">
                  FormulaX
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#232323] text-[#D65A1F] border border-[#303030] uppercase tracking-wider">
                  Pro
                </span>
              </div>
              <p className="text-[10px] text-[#A9A39C] font-mono tracking-tight -mt-0.5 hidden sm:block">
                Calculate. Understand. Engineer.
              </p>
            </div>
          </Link>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1 text-xs font-semibold text-[#A9A39C]">
            <NavLink
              to="/"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Home
            </NavLink>
            <NavLink
              to="/explore"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Explore
            </NavLink>
            <NavLink
              to="/formulas"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Formula Library
            </NavLink>
            <NavLink
              to="/calculator"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Calculator
            </NavLink>
            <NavLink
              to="/tools"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Tools
            </NavLink>
            <NavLink
              to="/practice"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Practice
            </NavLink>
            <NavLink
              to="/history"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              History
            </NavLink>
            <NavLink
              to="/favorites"
              onClick={() => playSound('tab')}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-[#232323] text-[#D65A1F] border border-[#303030]' : 'hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
                }`
              }
            >
              Favorites
            </NavLink>
          </nav>

          {/* Quick Actions (Sound toggle, Search, Settings) */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playSound('button');
                navigate('/formulas');
              }}
              className="p-2 rounded-xl text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#1C1C1C] transition-colors"
              title="Search formulas"
              aria-label="Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Sound toggle button */}
            <button
              onClick={toggleSound}
              className={`p-2 rounded-xl transition-colors border ${
                settings.soundEnabled
                  ? 'text-[#D65A1F] bg-[#1C1C1C] border-[#303030]'
                  : 'text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#1C1C1C] border-transparent'
              }`}
              title={settings.soundEnabled ? 'Sound Effects: ON' : 'Sound Effects: OFF'}
              aria-label="Toggle Sound Effects"
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            <Link
              to="/settings"
              onClick={() => playSound('tab')}
              className="p-2 rounded-xl text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#1C1C1C] transition-colors"
              title="App Settings"
              aria-label="Settings"
            >
              <Settings className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};
