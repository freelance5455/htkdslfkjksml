import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Bell, MessageSquare, Sun, Moon,
  Users, Bookmark, ShieldAlert,
  Download, LogOut, Check, Search
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  unreadMessagesCount: number;
  unreadNotifsCount: number;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenExportModal: () => void;
  onOpenNotifications: () => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  unreadMessagesCount,
  unreadNotifsCount,
  isDarkMode,
  setIsDarkMode,
  onOpenExportModal,
  onOpenNotifications,
  onOpenSearch
}) => {
  const { currentUser, logout, setAuthModalOpen, switchUser, availableDemoUsers } = useAuth();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">

        {/* Zone 1: Single Wordmark Brand */}
        <button
          onClick={() => setCurrentTab('feed')}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 font-display flex items-center gap-2 hover:opacity-95 transition-opacity text-left"
        >
          <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-red-600 via-amber-500 to-amber-400 flex items-center justify-center text-sm shadow-md shadow-amber-500/20">
            🇦🇴
          </span>
          <span className="bg-gradient-to-r from-white via-slate-100 to-amber-400 bg-clip-text text-transparent font-bold">
            Angola Connect
          </span>
        </button>

        {/* Zone 2: 5 Concise Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => setCurrentTab('feed')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentTab === 'feed'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Início
          </button>
          <button
            onClick={() => setCurrentTab('friends')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentTab === 'friends'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Amigos
          </button>
          <button
            onClick={() => setCurrentTab('stories')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentTab === 'stories'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Stories
          </button>
          <button
            onClick={() => setCurrentTab('messages')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
              currentTab === 'messages'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Mensagens</span>
            {unreadMessagesCount > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 bg-red-600 text-white text-[10px] font-bold rounded-full">
                {unreadMessagesCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setCurrentTab('trends')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentTab === 'trends'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Angola Agora 🇦🇴
          </button>
          <button
            onClick={() => setCurrentTab('marketplace')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentTab === 'marketplace'
                ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Marketplace
          </button>
        </nav>

        {/* Zone 3: Actions & Profile */}
        <div className="flex items-center gap-2.5 shrink-0">

          {/* Global Search Button */}
          <button
            onClick={onOpenSearch}
            aria-label="Pesquisar"
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            aria-label="Notificações"
            className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-slate-950">
                {unreadNotifsCount}
              </span>
            )}
          </button>

          {/* Theme Switcher */}
          <button
            onClick={() => setIsDarkMode(prev => !prev)}
            aria-label="Alternar tema"
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition-colors"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Export APK/ZIP Button */}
          <button
            onClick={onOpenExportModal}
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-amber-500/50 text-slate-200 hover:text-amber-400 text-xs font-semibold transition-all whitespace-nowrap shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Exportar ZIP & APK</span>
          </button>

          {/* User Profile / Menu Dropdown */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(prev => !prev)}
                className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-900 transition-colors"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-amber-500/40"
                />
                <span className="hidden sm:inline text-xs font-medium text-slate-200 max-w-[100px] truncate">
                  {currentUser.name.split(' ')[0]}
                </span>
              </button>

              {/* Dropdown Menu */}
              {isUserMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 text-xs text-slate-200 z-50 animate-in fade-in zoom-in-95"
                  onClick={() => setIsUserMenuOpen(false)}
                >
                  <div className="p-2.5 pb-2 border-b border-slate-800">
                    <p className="font-semibold text-white truncate text-sm">{currentUser.name}</p>
                    <p className="text-slate-400 text-[11px] font-mono">@{currentUser.username}</p>
                    <p className="text-[11px] text-amber-400 mt-0.5">🇦🇴 {currentUser.province}</p>
                  </div>

                  <div className="py-1 space-y-0.5">
                    <button
                      onClick={() => setCurrentTab('profile')}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-slate-300 hover:text-white"
                    >
                      <img src={currentUser.avatar} className="w-4 h-4 rounded-full object-cover" />
                      <span>Meu Perfil</span>
                    </button>
                    <button
                      onClick={() => setCurrentTab('groups')}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-slate-300 hover:text-white"
                    >
                      <Users className="w-4 h-4 text-amber-400" />
                      <span>Grupos & Comunidades</span>
                    </button>
                    <button
                      onClick={() => setCurrentTab('pages')}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-slate-300 hover:text-white"
                    >
                      <Bookmark className="w-4 h-4 text-emerald-400" />
                      <span>Páginas & Empresas</span>
                    </button>
                    <button
                      onClick={() => setCurrentTab('saved')}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-slate-300 hover:text-white"
                    >
                      <Bookmark className="w-4 h-4 text-blue-400" />
                      <span>Publicações Salvas</span>
                    </button>
                    {currentUser.isAdmin && (
                      <button
                        onClick={() => setCurrentTab('admin')}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-amber-400 font-semibold"
                      >
                        <ShieldAlert className="w-4 h-4 text-amber-400" />
                        <span>Painel Administrativo</span>
                      </button>
                    )}
                    <button
                      onClick={onOpenExportModal}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 flex items-center gap-2 text-slate-300 hover:text-white lg:hidden"
                    >
                      <Download className="w-4 h-4 text-amber-400" />
                      <span>Exportar ZIP & APK</span>
                    </button>
                  </div>

                  {/* Switch user quick bar */}
                  <div className="pt-2 mt-1 border-t border-slate-800">
                    <p className="px-2 text-[10px] text-slate-500 uppercase font-semibold tracking-wider">
                      Alternar Conta
                    </p>
                    <div className="mt-1 space-y-0.5">
                      {availableDemoUsers.map((u) => (
                        <button
                          key={u.id}
                          onClick={() => switchUser(u)}
                          className={`w-full text-left px-2 py-1.5 rounded-lg flex items-center justify-between text-xs ${u.id === currentUser.id ? 'bg-amber-500/10 text-amber-400 font-medium' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
                        >
                          <span className="truncate">{u.name}</span>
                          {u.id === currentUser.id && <Check className="w-3.5 h-3.5 shrink-0" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-1 mt-1 border-t border-slate-800">
                    <button
                      onClick={logout}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-red-950/40 text-red-400 hover:text-red-300 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Terminar Sessão</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all"
            >
              Entrar / Registar
            </button>
          )}

        </div>

      </div>
    </header>
  );
};
