import { useQuery } from "@tanstack/react-query";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BookOpen,
  CalendarCheck,
  Landmark,
  LayoutDashboard,
  ListChecks,
  MoreHorizontal,
  Plus,
  Search,
  Users,
  Wallet,
} from "lucide-react";
import { useState } from "react";
import { BrandMark } from "@/components/brand/logo";
import { searchBooks } from "@/lib/accounting/actions";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/dashboard", label: "داشبورد", icon: LayoutDashboard },
  { to: "/operations", label: "عملیات", icon: ListChecks },
  { to: "/parties", label: "اشخاص", icon: Users },
  { to: "/reports", label: "گزارش‌ها", icon: BookOpen },
];

const MORE = [
  { to: "/liquidity", label: "نقدینگی", icon: Wallet },
  { to: "/kpi", label: "شاخص‌ها", icon: Activity },
  { to: "/crm", label: "باشگاه مشتریان", icon: Users },
  { to: "/checks", label: "چک‌ها", icon: Landmark },
  { to: "/accounts", label: "کدینگ حساب‌ها" },
  { to: "/journals", label: "اسناد حسابداری" },
  { to: "/close-day", label: "بستن روز", icon: CalendarCheck },
  { to: "/audit", label: "حسابرسی" },
  { to: "/health", label: "سلامت سیستم" },
  { to: "/settings", label: "تنظیمات" },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const user = useCurrentUser();
  const [more, setMore] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="app-grain min-h-dvh bg-cream">
      <aside className="fixed top-0 right-0 z-30 hidden h-dvh w-[272px] flex-col border-l border-white/10 bg-navy text-cream lg:flex">
        <div className="flex items-center gap-3 px-5 pt-6 pb-5">
          <BrandMark className="size-10" />
          <div>
            <div className="font-display text-lg tracking-[0.14em] leading-none">MR,KHORASANI</div>
            <div className="mt-1 text-[10px] tracking-[0.18em] text-gold-2">ACCOUNTING</div>
          </div>
        </div>
        <div className="gold-rule mx-5" />
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-4">
          {NAV.map((item) => (
            <NavLink key={item.to} {...item} active={pathname.startsWith(item.to)} />
          ))}
          <div className="px-3 pt-5 pb-2 text-[10px] tracking-[0.2em] text-gold/80">ماژول‌ها</div>
          {MORE.map((item) => (
            <NavLink key={item.to} {...item} active={pathname.startsWith(item.to)} />
          ))}
        </nav>
        <div className="border-t border-white/10 p-4">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="truncate text-sm">{user?.displayName ?? "کاربر"}</div>
              <div className="truncate text-[11px] text-cream/50">{user?.primaryEmail ?? ""}</div>
            </div>
            <UserButton />
          </div>
        </div>
      </aside>

      <div className="lg:mr-[272px]">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-cream/90 px-4 py-3 backdrop-blur-md lg:px-8">
          <div className="flex items-center gap-2 lg:hidden">
            <BrandMark className="size-8" />
            <span className="font-display text-base tracking-[0.12em]">MR,KHORASANI</span>
          </div>
          <div className="hidden text-sm text-muted lg:block">سامانه حسابداری دوبل · سال مالی ۱۴۰۵</div>
          <div className="flex items-center gap-2">
            <Link
              to="/operations/new"
              className="inline-flex h-10 items-center gap-1.5 rounded-[10px] bg-navy px-3 text-sm text-cream"
            >
              <Plus className="size-4" />
              <span className="hidden sm:inline">ثبت عملیات</span>
            </Link>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="inline-flex size-10 items-center justify-center rounded-[10px] border border-line bg-paper"
              aria-label="جستجو"
            >
              <Search className="size-4" />
            </button>
            <div className="lg:hidden">
              <UserButton />
            </div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-5 lg:px-8 lg:pb-10">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden">
        <div className="grid grid-cols-5">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex flex-col items-center gap-1 py-2.5 text-[11px]",
                  active ? "text-navy" : "text-muted",
                )}
              >
                <Icon className={cn("size-5", active && "text-gold")} />
                {item.label}
              </Link>
            );
          })}
          <button
            type="button"
            onClick={() => setMore(true)}
            className="flex flex-col items-center gap-1 py-2.5 text-[11px] text-muted"
          >
            <MoreHorizontal className="size-5" />
            بیشتر
          </button>
        </div>
      </nav>

      {more ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button className="absolute inset-0 bg-navy/50" onClick={() => setMore(false)} aria-label="بستن" />
          <div className="absolute inset-x-0 bottom-0 rounded-t-[24px] bg-paper p-5 pb-10">
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-line" />
            <div className="grid grid-cols-3 gap-2">
              {MORE.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMore(false)}
                  className="rounded-[16px] border border-line bg-cream px-2 py-4 text-center text-xs"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {searchOpen ? <SearchOverlay onClose={() => setSearchOpen(false)} /> : null}
    </div>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-2.5 rounded-[12px] px-3 py-2.5 text-sm transition-colors",
        active ? "bg-white/10 text-gold-2" : "text-cream/75 hover:bg-white/5 hover:text-cream",
      )}
    >
      {Icon ? <Icon className="size-4 opacity-80" /> : <span className="size-1.5 rounded-full bg-gold/70" />}
      {label}
    </Link>
  );
}

function SearchOverlay({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState("");
  const { data, isFetching } = useQuery({
    queryKey: ["search", q],
    queryFn: () => searchBooks({ data: { q } }),
    enabled: q.trim().length >= 2,
  });
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-navy/50 p-4 pt-[12vh]">
      <button className="absolute inset-0" onClick={onClose} aria-label="بستن جستجو" />
      <div className="relative w-full max-w-lg rounded-[20px] border border-line bg-paper p-4 shadow-[var(--shadow-card)]">
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی شخص، سند، مبلغ، شرح…"
          className="h-12 w-full rounded-[12px] border border-line bg-cream px-3 text-sm outline-none focus:border-gold"
        />
        <p className="mt-3 text-xs text-muted">جستجو در دفتر کل، اشخاص و عملیات. حداقل دو نویسه.</p>
        {isFetching ? <div className="mt-3 h-16 animate-pulse rounded-xl bg-secondary" /> : null}
        {data && !data.length ? <div className="mt-3 text-sm text-muted">موردی یافت نشد.</div> : null}
        {data?.length ? (
          <ul className="mt-3 max-h-72 space-y-1 overflow-y-auto">
            {data.map((r) => (
              <li key={r.id}>
                <Link
                  to={r.to}
                  onClick={onClose}
                  className="flex items-center justify-between rounded-[12px] px-3 py-2.5 hover:bg-cream"
                >
                  <span className="text-sm">{r.title}</span>
                  <span className="text-[11px] text-muted">{r.kind}</span>
                </Link>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}
