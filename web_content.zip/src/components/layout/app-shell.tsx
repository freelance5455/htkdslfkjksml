import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { BottomNav } from "./bottom-nav";
import { PlayerBar } from "./player-bar";

export function AppShell({ children, full = false }: { children: React.ReactNode; full?: boolean }) {
  const settings = useAppStore((s) => s.settings);

  useEffect(() => {
    const root = document.documentElement;
    const dark =
      settings.theme === "dark" ||
      (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    root.classList.toggle("dark", dark);
    root.classList.toggle("large-ui", settings.largeDisplay);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (useAppStore.getState().settings.theme === "system") {
        document.documentElement.classList.toggle("dark", mq.matches);
      }
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [settings.theme, settings.largeDisplay]);

  return (
    <div className="mx-auto min-h-dvh max-w-lg bg-background text-foreground">
      <div className={full ? "" : "safe-bottom"}>{children}</div>
      <PlayerBar />
      <BottomNav />
    </div>
  );
}

export function TopBar({
  title,
  action,
  back,
}: {
  title: string;
  action?: React.ReactNode;
  back?: React.ReactNode;
}) {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background/90 px-3 py-2.5 backdrop-blur-md">
      <div className="flex size-11 items-center justify-center">{back}</div>
      <h1 className="flex-1 text-center text-base font-semibold">{title}</h1>
      <div className="flex size-11 items-center justify-center">{action}</div>
    </header>
  );
}
