"use client";

import { useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Award, GraduationCap, LayoutDashboard, Menu, School, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "لوحة القيادة", icon: LayoutDashboard },
  { to: "/students", label: "المترشحون", icon: Users },
  { to: "/results", label: "النتائج", icon: Award },
  { to: "/schools", label: "الثانويات", icon: School },
] as const;

function NavLinks({ onNavigate, compact }: { onNavigate?: () => void; compact?: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className={cn("flex flex-col gap-1", compact && "text-primary-fg")}>
      {NAV.map((item) => {
        const active =
          item.to === "/"
            ? pathname === "/"
            : pathname === item.to || pathname.startsWith(`${item.to}/`);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={cn(
              "flex min-h-11 items-center gap-3 rounded-sm px-3 text-sm font-medium transition-colors duration-150",
              compact
                ? active
                  ? "bg-primary-fg/15 text-primary-fg"
                  : "text-primary-fg/75 hover:bg-primary-fg/10 hover:text-primary-fg"
                : active
                  ? "bg-surface-2 text-fg"
                  : "text-muted hover:bg-surface-2 hover:text-fg",
            )}
          >
            <Icon className="size-4 shrink-0" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function Brand({ light }: { light?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <span
        className={cn(
          "flex size-10 items-center justify-center rounded-sm",
          light ? "bg-primary-fg/15 text-primary-fg" : "bg-primary text-primary-fg",
        )}
      >
        <GraduationCap className="size-5" />
      </span>
      <div className="min-w-0">
        <p className={cn("truncate text-sm font-semibold", light ? "text-primary-fg" : "text-fg")}>
          ديوان البكالوريا
        </p>
        <p className={cn("truncate text-xs", light ? "text-primary-fg/70" : "text-muted")}>
          تسيير شهادة التعليم الثانوي
        </p>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-64 flex-col bg-primary px-4 py-6 text-primary-fg lg:flex">
        <Brand light />
        <div className="mt-8 flex-1">
          <NavLinks compact />
        </div>
        <p className="text-xs text-primary-fg/60">دورة جوان 2025</p>
      </aside>

      <div className="lg:pr-64">
        <header className="no-print sticky top-0 z-20 flex h-14 items-center justify-between border-b border-border bg-bg/90 px-4 backdrop-blur-sm lg:hidden">
          <Brand />
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" aria-label="القائمة">
                <Menu className="size-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="flex flex-col gap-8">
              <Brand light />
              <NavLinks compact onNavigate={() => setOpen(false)} />
            </SheetContent>
          </Sheet>
        </header>

        <main className="mx-auto w-full max-w-6xl px-4 py-6 pb-24 sm:px-6 lg:py-8 lg:pb-8">
          {children}
        </main>
      </div>

      <nav className="no-print fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-border bg-surface lg:hidden">
        {NAV.map((item) => {
          const active =
            item.to === "/"
              ? pathname === "/"
              : pathname === item.to || pathname.startsWith(`${item.to}/`);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium",
                active ? "text-primary" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
