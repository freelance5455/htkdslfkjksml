// Supermarket POS Navigation Sidebar
import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Boxes,
  Truck,
  Users,
  CreditCard,
  BarChart3,
  ShieldCheck,
  Database,
  Settings,
  Lock,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'inventory'
  | 'purchasing'
  | 'suppliers'
  | 'customers'
  | 'cash-register'
  | 'reports'
  | 'audit-logs'
  | 'database'
  | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const { can, currentUser } = useAuth();

  const navItems: {
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    requiredPermission?: Parameters<typeof can>[0];
    badge?: string;
  }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'pos',
      label: 'POS Checkout',
      icon: ShoppingCart,
      requiredPermission: 'POS_ACCESS',
      badge: 'Cashier',
    },
    {
      id: 'products',
      label: 'Products & Barcodes',
      icon: Package,
      requiredPermission: 'PRODUCT_VIEW',
    },
    {
      id: 'inventory',
      label: 'Inventory & Stock',
      icon: Boxes,
      requiredPermission: 'INVENTORY_VIEW',
    },
    {
      id: 'purchasing',
      label: 'Purchasing Orders',
      icon: Truck,
      requiredPermission: 'PURCHASE_VIEW',
    },
    {
      id: 'suppliers',
      label: 'Suppliers',
      icon: Truck,
      requiredPermission: 'SUPPLIER_MANAGE',
    },
    {
      id: 'customers',
      label: 'Customers & Loyalty',
      icon: Users,
      requiredPermission: 'CUSTOMER_MANAGE',
    },
    {
      id: 'cash-register',
      label: 'Cash Register Sessions',
      icon: CreditCard,
      requiredPermission: 'CASH_REGISTER_MANAGE',
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: BarChart3,
      requiredPermission: 'REPORT_VIEW',
    },
    {
      id: 'audit-logs',
      label: 'Security & Audit Logs',
      icon: ShieldCheck,
      requiredPermission: 'AUDIT_LOG_VIEW',
    },
    {
      id: 'database',
      label: 'Postgres & Architecture',
      icon: Database,
      badge: 'SQL/M1',
    },
    {
      id: 'settings',
      label: 'Store Settings',
      icon: Settings,
      requiredPermission: 'SETTINGS_MANAGE',
    },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0 select-none text-slate-300">
      <div className="p-3 text-[11px] font-semibold tracking-wider text-slate-500 uppercase px-4 pt-4">
        Supermarket Management
      </div>

      <nav className="flex-1 px-2.5 space-y-1 overflow-y-auto py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isAllowed = !item.requiredPermission || can(item.requiredPermission);
          const isActive = activeTab === item.id;

          if (!isAllowed) {
            return (
              <div
                key={item.id}
                className="flex items-center justify-between px-3 py-2 text-xs font-medium text-slate-600 rounded-lg cursor-not-allowed opacity-50"
                title={`Requires permission: ${item.requiredPermission}`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4 text-slate-600" />
                  <span>{item.label}</span>
                </div>
                <Lock className="w-3 h-3 text-slate-600" />
              </div>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                isActive
                  ? 'bg-emerald-600 text-white font-semibold shadow-sm shadow-emerald-900/30'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'}`}
                />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                    isActive ? 'bg-emerald-700 text-white' : 'bg-slate-800 text-emerald-400 border border-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Role Card at Bottom */}
      {currentUser && (
        <div className="p-3 m-2.5 bg-slate-900/80 rounded-lg border border-slate-800 text-xs">
          <div className="text-slate-400 text-[11px]">Active Operator</div>
          <div className="font-semibold text-slate-200 truncate">{currentUser.name}</div>
          <div className="flex items-center gap-1.5 mt-1 text-[11px] text-emerald-400 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            Role: {currentUser.role}
          </div>
        </div>
      )}
    </aside>
  );
};
