import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useSidebar } from "@/context/SidebarContext";
import { APP_VERSION } from "@/constants";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, Sparkles, FolderOpen, Lightbulb,
  Library, CalendarDays, Palette, Tv2, Settings, LogOut,
  ChevronLeft, ChevronRight, Zap, X, BarChart2, Share2, Cpu, Layers, Film,
  Video, Copy
} from "lucide-react";

const NAV_ITEMS = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/content-factory", icon: Layers, label: "Content Factory 4.0" },
  { path: "/factory", icon: Tv2, label: "YouTube AI Factory" },
  { path: "/my-videos", icon: Film, label: "Meus Vídeos" },
  { path: "/external-videos", icon: Video, label: "Vídeos Externos" },
  { path: "/clone-studio", icon: Copy, label: "Clonar Estúdio" },
  { path: "/autopilot", icon: Cpu, label: "AI Autopilot" },
  { path: "/creator", icon: Sparkles, label: "AI Creator" },
  { path: "/projects", icon: FolderOpen, label: "Projetos" },
  { path: "/analytics", icon: BarChart2, label: "Analytics & IA" },
  { path: "/calendar", icon: CalendarDays, label: "Calendário & Fila" },
  { path: "/channels", icon: Share2, label: "Meus Canais" },
  { path: "/ideas", icon: Lightbulb, label: "Ideas Lab" },
  { path: "/library", icon: Library, label: "Biblioteca" },
  { path: "/brand", icon: Palette, label: "Brand Kit" },
  { path: "/settings", icon: Settings, label: "Configurações" },
];

export default function Sidebar() {
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { isOpen, closeSidebar, isMobile } = useSidebar();
  const [collapsed, setCollapsed] = useState(false);

  const handleNavClick = (path: string) => {
    navigate(path);
    if (isMobile) {
      closeSidebar();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobile && isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={closeSidebar}
          aria-hidden="true"
        />
      )}

      {/* Main Sidebar */}
      <aside
        id="vertical-sidebar-menu"
        className={cn(
          "flex flex-col h-screen bg-studio-surface border-r border-studio-border transition-all duration-300 z-50 shrink-0",
          // Mobile state
          "fixed lg:static inset-y-0 left-0 shadow-2xl lg:shadow-none",
          isMobile && (isOpen ? "translate-x-0 w-64" : "-translate-x-full w-64"),
          // Desktop state
          !isMobile && (
            isOpen
              ? (collapsed ? "w-16" : "w-60")
              : "w-0 opacity-0 overflow-hidden border-r-0 pointer-events-none p-0"
          )
        )}
      >
        {/* Logo & Header */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-studio-border shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-studio-blue to-studio-purple flex items-center justify-center shrink-0 shadow-sm shadow-studio-blue/20">
            <Zap className="w-4 h-4 text-white" />
          </div>
          {(!collapsed || isMobile) && (
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-studio-text font-display leading-tight">AI Creator</p>
              <p className="text-[11px] text-studio-text-muted">Studio · {APP_VERSION}</p>
            </div>
          )}

          {/* Desktop collapse or Mobile close */}
          {isMobile ? (
            <button
              onClick={closeSidebar}
              className="ml-auto p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-all"
              title="Fechar menu"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="ml-auto p-1 rounded-md text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-all"
              title={collapsed ? "Expandir" : "Recolher"}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const active = item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
            const isItemCollapsed = collapsed && !isMobile;
            return (
              <button
                key={item.path}
                onClick={() => handleNavClick(item.path)}
                title={isItemCollapsed ? item.label : undefined}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 text-sm font-medium",
                  active
                    ? "bg-studio-blue/10 text-studio-blue border border-studio-blue/20 shadow-xs"
                    : "text-studio-text-dim hover:text-studio-text hover:bg-studio-panel",
                  isItemCollapsed && "justify-center px-2"
                )}
              >
                <item.icon className={cn("w-4 h-4 shrink-0", active ? "text-studio-blue" : "text-studio-text-muted")} />
                {!isItemCollapsed && <span>{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* User Profile & Logout */}
        <div className="border-t border-studio-border p-3 shrink-0">
          {(!collapsed || isMobile) && user && (
            <div className="flex items-center gap-2.5 mb-3 px-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-studio-gold to-studio-orange flex items-center justify-center text-xs font-bold text-black shrink-0">
                {user.name.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-semibold text-studio-text truncate">{user.name}</p>
                <p className="text-[10px] text-studio-text-muted">Proprietário</p>
              </div>
            </div>
          )}
          <button
            onClick={logout}
            title="Sair"
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-studio-text-muted hover:text-studio-red hover:bg-studio-red/10 transition-all text-sm font-medium",
              collapsed && !isMobile && "justify-center px-2"
            )}
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {(!collapsed || isMobile) && <span>Sair</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
