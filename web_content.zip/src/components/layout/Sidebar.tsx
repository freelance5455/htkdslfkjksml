import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  GraduationCap,
  CalendarDays,
  Calendar,
  Compass,
  Pill,
  BarChart3,
  Timer,
  Settings,
  Sparkles,
  BookOpen,
  Bell,
  Cloud,
  Smartphone,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

interface SidebarProps {
  onOpenAuth?: () => void;
  onOpenApkModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenAuth, onOpenApkModal }) => {
  const {
    activeTab,
    setActiveTab,
    conflicts,
    subjects,
    medications,
    alarms,
    setShowQuranModal,
    currentUser,
    isSyncing,
    lastSyncTime,
  } = useApp();

  const enabledAlarmsCount = alarms.filter((a) => a.isEnabled).length;

  const navItems: NavItem[] = [
    {
      id: 'dashboard',
      label: 'لوحة التحكم الرئيسية',
      icon: LayoutDashboard,
    },
    {
      id: 'calendar',
      label: 'التقويم الشهري والمهام',
      icon: Calendar,
    },
    {
      id: 'study',
      label: 'تنظيم المذاكرة والمواد',
      icon: GraduationCap,
      badge: subjects.length,
    },
    {
      id: 'schedule',
      label: 'الجدول الأسبوعي واليومي',
      icon: CalendarDays,
      badge: conflicts.length > 0 ? conflicts.length : undefined,
    },
    {
      id: 'prayers',
      label: 'مواقيت الصلاة والشروق',
      icon: Compass,
    },
    {
      id: 'adhkar',
      label: 'أذكار الصباح والمساء',
      icon: BookOpen,
    },
    {
      id: 'alarms',
      label: 'المنبهات الذكية',
      icon: Bell,
      badge: enabledAlarmsCount > 0 ? enabledAlarmsCount : undefined,
    },
    {
      id: 'meds',
      label: 'متتبع الأدوية والعلاج',
      icon: Pill,
      badge: medications.filter((m) => m.active).length,
    },
    {
      id: 'pomodoro',
      label: 'مؤقت التركيز الذكي',
      icon: Timer,
    },
    {
      id: 'stats',
      label: 'الإحصائيات والتقدم',
      icon: BarChart3,
    },
    {
      id: 'settings',
      label: 'الإعدادات والنسخ الاحتياطي',
      icon: Settings,
    },
  ];

  return (
    <aside className="hidden lg:flex w-64 bg-white dark:bg-[#180e15] border-l border-rose-100 dark:border-rose-950/60 flex-col shrink-0 transition-colors">
      {/* Cloud Account Status Widget */}
      <div className="p-3 m-3 rounded-2xl bg-gradient-to-br from-rose-50/80 to-pink-50/50 dark:from-rose-950/40 dark:to-pink-950/20 border border-rose-200/60 dark:border-rose-900/40">
        {currentUser ? (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                متصل بالسحابة
              </span>
              <button
                onClick={onOpenAuth}
                className="text-[10px] text-rose-600 dark:text-rose-400 hover:underline font-semibold"
              >
                إدارة
              </button>
            </div>
            <p className="text-xs font-semibold text-slate-800 dark:text-rose-100 truncate">
              {currentUser.email}
            </p>
            {lastSyncTime && (
              <p className="text-[10px] text-slate-500 dark:text-rose-300/70 font-mono">
                آخر مزامنة: {lastSyncTime}
              </p>
            )}
          </div>
        ) : (
          <div className="space-y-2 text-right">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-800 dark:text-rose-200">
              <Cloud className="w-4 h-4 text-rose-500" />
              <span>مزامنة البيانات السحابية</span>
            </div>
            <p className="text-[11px] text-rose-700/80 dark:text-rose-300/80 leading-relaxed">
              اربط بريدك لحفظ جدولك وموادك والوصول إليها من هاتفك الأندرويد.
            </p>
            <button
              onClick={onOpenAuth}
              className="w-full py-1.5 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white text-xs font-bold transition shadow-xs"
            >
              ربط الحساب بالميل
            </button>
          </div>
        )}
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all w-full text-right ${
                isActive
                  ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-200 shadow-xs border border-rose-200/60 dark:border-rose-900/40'
                  : 'text-slate-600 dark:text-rose-200/70 hover:bg-rose-50/50 dark:hover:bg-rose-950/30 hover:text-rose-900 dark:hover:text-rose-100'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 ${
                  isActive ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400 dark:text-rose-400/50'
                }`}
              />
              <span className="flex-1">{item.label}</span>
              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                    item.id === 'schedule' && conflicts.length > 0
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                      : isActive
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-200'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Android APK Download Widget */}
      <div className="p-3 mx-3 mb-2 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/70 dark:border-emerald-900/40 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 dark:text-emerald-300">
            <Smartphone className="w-4 h-4 text-emerald-600" />
            <span>تطبيق أندرويد APK</span>
          </div>
          <span className="text-[10px] font-bold bg-emerald-600 text-white px-1.5 py-0.2 rounded-full">
            v1.0
          </span>
        </div>
        <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed">
          تثبيت فوري ومباشر كـ WebAPK أو تحميل حزمة التثبيت.
        </p>
        <button
          onClick={onOpenApkModal}
          className="w-full py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5"
        >
          <span>تنزيل APK للأندرويد</span>
        </button>
      </div>

      {/* Quran Verse & Daily Inspiration Trigger */}
      <div className="p-3 m-3 mt-0 rounded-2xl bg-gradient-to-br from-rose-500/10 via-pink-500/5 to-transparent border border-rose-400/20 space-y-1.5">
        <button
          onClick={() => setShowQuranModal(true)}
          className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 text-white text-xs font-bold shadow-xs hover:from-rose-700 hover:to-pink-700 transition-all flex items-center justify-center gap-1.5"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>آية اليوم وتفسيرها</span>
        </button>

        <p className="text-[10px] text-rose-800/80 dark:text-rose-200/80 leading-relaxed text-center">
          استفتح يومك بذكر الله وتدبر آياته العظيمة.
        </p>
      </div>
    </aside>
  );
};
