import { NavLink, useLocation } from 'react-router-dom';
import {
  BarChart3,
  Award,
  BookOpen,
  BookOpenCheck,
  CalendarDays,
  Coins,
  Ellipsis,
  GraduationCap,
  Home,
  Library,
  ListChecks,
  Search,
  Settings as SettingsIcon,
  Sparkles,
  Layers,
  ShoppingBag,
  Sprout,
  Target,
  Timer,
} from 'lucide-react';
import { cn } from '../../utils/format';

export interface NavItem {
  to: string;
  label: string;
  icon: typeof Home;
}

export const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'الرئيسية', icon: Home },
  { to: '/subjects', label: 'موادي', icon: GraduationCap },
  { to: '/library', label: 'المكتبة', icon: Library },
  { to: '/progress', label: 'تقدمي', icon: BarChart3 },
  { to: '/events', label: 'الفعاليات', icon: Sparkles },
];

export const MORE_ITEMS: NavItem[] = [
  { to: '/events', label: 'الفعاليات', icon: Sparkles },
  { to: '/study-session', label: 'جلسة الدراسة', icon: Timer },
  { to: '/farm', label: 'مزرعتي', icon: Sprout },
  { to: '/shop', label: 'متجر النقاط', icon: ShoppingBag },
  { to: '/challenges', label: 'التحديات', icon: Target },
  { to: '/achievements', label: 'إنجازاتي', icon: Award },
  { to: '/tests', label: 'الاختبارات', icon: ListChecks },
  { to: '/question-bank', label: 'بنك أسئلة المنهاج', icon: BookOpenCheck },
  { to: '/curriculum-progress', label: 'إنجاز المنهاج', icon: BookOpen },
  { to: '/review', label: 'مركز المراجعة', icon: Layers },
  { to: '/plan', label: 'جدول الدراسة', icon: CalendarDays },
  { to: '/daily-tasks', label: 'مهامي اليومية', icon: ListChecks },
  { to: '/gradebook', label: 'سجل العلامات', icon: BarChart3 },
  { to: '/certificates', label: 'شهاداتي', icon: Award },
  { to: '/notes', label: 'مركز الملاحظات', icon: BookOpen },
  { to: '/search', label: 'البحث السريع', icon: Search },
  { to: '/settings', label: 'الإعدادات', icon: SettingsIcon },
];

/** شعار المنارة: قوسان + صفحة كتاب */
export function ManaraLogo({ size = 34, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      role="img"
      aria-label="شعار منارة البكالوريا"
      className={className}
    >
      <defs>
        <linearGradient id="manara-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#F7D089" />
          <stop offset="100%" stopColor="#E6A52E" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="46" height="46" rx="14" fill="var(--brand)" />
      <path d="M24 10c5 2.4 8 6.3 8 10.5 0 2.6-1.2 4.9-3.2 6.6" stroke="url(#manara-gold)" strokeWidth="2.6" fill="none" strokeLinecap="round" />
      <path d="M24 16.5c2.6 1.3 4.2 3.3 4.2 5.6 0 1.4-.6 2.6-1.7 3.5" stroke="url(#manara-gold)" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      <path d="M13 27.5h22v9.2c-3.6 0-7.3-1.1-11-3.3-3.7 2.2-7.4 3.3-11 3.3v-9.2z" fill="#fff" opacity="0.92" />
      <path d="M24 33.4V27.5" stroke="var(--brand)" strokeWidth="1.6" strokeLinecap="round" opacity="0.35" />
    </svg>
  );
}

export function Sidebar({ studentName, balance }: { studentName: string; balance: number }) {
  const location = useLocation();
  const all = [...NAV_ITEMS, ...MORE_ITEMS.filter((item) => !NAV_ITEMS.some((navItem) => navItem.to === item.to))];
  return (
    <aside className="sticky top-0 hidden h-dvh shrink-0 border-e border-[var(--line)] bg-[var(--surface)] px-4 py-6 lg:flex lg:flex-col">
      <NavLink to="/" className="focus-ring mb-8 flex items-center gap-3 rounded-2xl px-1">
        <ManaraLogo size={40} />
        <span>
          <span className="block font-display text-base leading-tight text-[var(--ink)]">منارة البكالوريا</span>
          <span className="block text-[0.68rem] text-[var(--ink-soft)]">الفرع العلمي · منهاج سوريا</span>
        </span>
      </NavLink>

      <nav className="space-y-1" aria-label="التنقل الرئيسي">
        {all.map((item) => {
          const active = item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to);
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={cn(
                'focus-ring flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm transition-colors',
                active
                  ? 'bg-[var(--brand)] text-[var(--brand-ink)]'
                  : 'text-[var(--ink-soft)] hover:bg-[var(--surface-2)] hover:text-[var(--ink)]',
              )}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <NavLink to="/shop" className="focus-ring mb-3 flex items-center justify-between rounded-2xl bg-[var(--gold-soft)] px-3 py-2.5 text-[var(--ink)]">
        <span className="flex items-center gap-2 text-xs"><Coins size={16} className="text-[var(--gold)]" /> رصيد النقاط</span>
        <strong className="text-sm">{balance}</strong>
      </NavLink>
      <div className="mt-auto rounded-2xl bg-[var(--surface-2)] p-3">
        <p className="text-[0.7rem] text-[var(--ink-soft)]">مرحباً</p>
        <p className="truncate font-display text-sm text-[var(--ink)]">{studentName || 'طالب البكالوريا'}</p>
        <NavLink
          to="/welcome"
          className="focus-ring mt-2 inline-flex items-center gap-1 text-[0.7rem] text-[var(--ink-soft)] underline-offset-4 hover:underline"
        >
          <Sparkles size={12} /> تعديل ملفي
        </NavLink>
      </div>
    </aside>
  );
}

export function MobileTopBar({ title = 'منارة البكالوريا', balance }: { title?: string; balance: number }) {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-2 border-b border-[var(--line)] bg-[color-mix(in_srgb,var(--bg)_88%,transparent)] px-4 py-2.5 backdrop-blur lg:hidden">
      <NavLink to="/" className="focus-ring flex items-center gap-2">
        <ManaraLogo size={30} />
        <span className="font-display text-sm text-[var(--ink)]">{title}</span>
      </NavLink>
      <div className="flex items-center gap-1">
        <NavLink to="/shop" aria-label={`متجر النقاط، رصيدك ${balance}`} className="focus-ring flex h-10 items-center gap-1 rounded-full bg-[var(--gold-soft)] px-2 text-[0.7rem] text-[var(--ink)]">
          <Coins size={15} className="text-[var(--gold)]" /> <span>{balance}</span>
        </NavLink>
        <NavLink
          to="/search"
          aria-label="بحث"
          className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-[var(--ink-soft)]"
        >
          <Search size={19} />
        </NavLink>
        <NavLink
          to="/settings"
          aria-label="الإعدادات"
          className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-[var(--ink-soft)]"
        >
          <SettingsIcon size={19} />
        </NavLink>
      </div>
    </header>
  );
}

export function BottomNav({ onMore }: { onMore: () => void }) {
  const location = useLocation();
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-[var(--line)] bg-[color-mix(in_srgb,var(--surface)_94%,transparent)] pb-[env(safe-area-inset-bottom)] backdrop-blur-lg lg:hidden"
      aria-label="التنقل السفلي"
    >
      <div className="mx-auto flex max-w-md items-stretch justify-around px-1">
        {NAV_ITEMS.map((item) => {
          const active = item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to);
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={cn(
                'focus-ring relative flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[0.62rem] transition-colors',
                active ? 'text-[var(--ink)]' : 'text-[var(--ink-soft)]',
              )}
              aria-current={active ? 'page' : undefined}
            >
              <span
                className={cn(
                  'flex h-8 w-12 items-center justify-center rounded-full transition-colors',
                  active && 'bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]',
                )}
              >
                <item.icon size={19} strokeWidth={active ? 2.4 : 1.9} />
              </span>
              <span className={cn(active && 'font-semibold')}>{item.label}</span>
            </NavLink>
          );
        })}
        <button
          type="button"
          onClick={onMore}
          className="focus-ring flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[0.62rem] text-[var(--ink-soft)]"
          aria-label="المزيد من الأقسام"
        >
          <span className="flex h-8 w-12 items-center justify-center rounded-full">
            <Ellipsis size={19} />
          </span>
          <span>المزيد</span>
        </button>
      </div>
    </nav>
  );
}

export function MoreSheetBody({ onNavigate }: { onNavigate: () => void }) {
  return (
    <div className="space-y-1">
      {MORE_ITEMS.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          onClick={onNavigate}
          className="focus-ring flex items-center gap-3 rounded-2xl px-3 py-3 text-sm text-[var(--ink)] hover:bg-[var(--surface-2)]"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink-soft)]">
            <item.icon size={17} />
          </span>
          {item.label}
        </NavLink>
      ))}
      <NavLink
        to="/welcome"
        onClick={onNavigate}
        className="focus-ring flex items-center gap-3 rounded-2xl px-3 py-3 text-sm text-[var(--ink)] hover:bg-[var(--surface-2)]"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink-soft)]">
          <BookOpen size={17} />
        </span>
        ملف الطالب
      </NavLink>
    </div>
  );
}
