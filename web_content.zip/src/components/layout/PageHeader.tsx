import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { cn } from '../../utils/format';

export function PageHeader({
  title,
  subtitle,
  back,
  action,
  eyebrow,
  className,
}: {
  title: string;
  subtitle?: string;
  back?: string | boolean;
  action?: ReactNode;
  eyebrow?: string;
  className?: string;
}) {
  const navigate = useNavigate();
  return (
    <div className={cn('beam mb-4 flex items-start gap-2', className)}>
      {back ? (
        <button
          type="button"
          onClick={() => (typeof back === 'string' ? navigate(back) : navigate(-1))}
          aria-label="رجوع"
          className="focus-ring mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--surface)] text-[var(--ink-soft)] shadow-sm ring-1 ring-[var(--line)]"
        >
          <ChevronRight size={18} />
        </button>
      ) : null}
      <div className="min-w-0 flex-1">
        {eyebrow ? <p className="text-[0.7rem] font-medium text-[var(--ink-soft)]">{eyebrow}</p> : null}
        <h1 className="truncate font-display text-xl text-[var(--ink)] sm:text-2xl">{title}</h1>
        {subtitle ? <p className="mt-1 text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">{subtitle}</p> : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  );
}
