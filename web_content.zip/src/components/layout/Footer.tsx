import React from 'react';
import { Link } from 'react-router-dom';
import { Sigma, Terminal, Wrench, BookOpen, Sparkles, MessageSquare, Shield } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Footer: React.FC = () => {
  const { playSound } = useApp();

  return (
    <footer className="border-t border-[#303030] bg-[#0D0D0D] text-[#A9A39C] text-xs pb-24 xl:pb-8 pt-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#232323] border border-[#303030] flex items-center justify-center text-[#D65A1F]">
                <Sigma className="w-4 h-4 text-[#D65A1F]" />
              </div>
              <span className="font-extrabold text-base text-[#F5F2ED] tracking-tight">FormulaX Pro</span>
            </div>
            <p className="text-[#A9A39C] leading-relaxed text-xs">
              Calculate. Understand. Engineer. Comprehensive STEM formula computation and dynamic step solver platform.
            </p>
            <div className="flex items-center gap-2 text-[11px] font-mono text-[#D65A1F]">
              <Terminal className="w-3.5 h-3.5" />
              <span>v3.0 • Local-First Engineering Engine</span>
            </div>
          </div>

          {/* Core Navigation */}
          <div>
            <h4 className="font-semibold text-[#F5F2ED] text-sm mb-3">Formula Modules</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/explore" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Curated Engineering Explore
                </Link>
              </li>
              <li>
                <Link to="/formulas" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Formula Library (50+ Equations)
                </Link>
              </li>
              <li>
                <Link to="/calculator" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Dynamic Formula Calculator
                </Link>
              </li>
              <li>
                <Link to="/scientific-calculator" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Scientific Calculator
                </Link>
              </li>
              <li>
                <Link to="/unit-converter" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  SI Engineering Unit Converter
                </Link>
              </li>
            </ul>
          </div>

          {/* Tools & Learning */}
          <div>
            <h4 className="font-semibold text-[#F5F2ED] text-sm mb-3">Tools & Practice</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/tools" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors flex items-center gap-1.5">
                  <Wrench className="w-3.5 h-3.5 text-[#D65A1F]" />
                  <span>Engineering Calculators</span>
                </Link>
              </li>
              <li>
                <Link to="/practice" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#D65A1F]" />
                  <span>Interactive Practice Mode</span>
                </Link>
              </li>
              <li>
                <Link to="/favorites" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Saved & Favorite Formulas
                </Link>
              </li>
              <li>
                <Link to="/history" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  Calculation History Log
                </Link>
              </li>
              <li>
                <Link to="/settings" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors">
                  App Settings & Preferences
                </Link>
              </li>
            </ul>
          </div>

          {/* Architecture info */}
          <div>
            <h4 className="font-semibold text-[#F5F2ED] text-sm mb-3">About Platform</h4>
            <ul className="space-y-2">
              <li className="text-xs text-[#A9A39C]">
                Built for scientific rigor, peer-verified math, and high-performance engineering calculations.
              </li>
              <li>
                <Link to="/feedback" onClick={() => playSound('tab')} className="hover:text-[#D65A1F] transition-colors flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5 text-[#D65A1F]" />
                  <span>Submit Formula Suggestion</span>
                </Link>
              </li>
              <li className="pt-2">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-mono px-2 py-1 rounded-lg bg-[#1C1C1C] border border-[#303030] text-[#72A65A]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#72A65A]"></span>
                  100% Offline Capable
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-[#303030] flex flex-col sm:flex-row items-center justify-between gap-4 text-[#A9A39C] text-xs text-center sm:text-left">
          <p className="border-[#2b1900]" style={{ borderColor: '#2b1900' }}>©2027 FormulaX Pro • Calculation • Engineering</p>
          <div className="flex items-center gap-6 justify-center sm:justify-end">
            <span className="font-mono text-[11px] text-[#A9A39C]">Bangladesh Dhaka • Brothers Studio • PWA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

