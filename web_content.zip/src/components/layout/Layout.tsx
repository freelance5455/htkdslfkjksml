import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { BottomNav } from './BottomNav';
import { Footer } from './Footer';
import { ToastContainer } from '../common/Toast';

export const Layout: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-[#0D0D0D] text-[#F5F2ED] selection:bg-[#D65A1F]/30 selection:text-[#F5F2ED]">
      <Navbar />
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8 pb-24 xl:pb-12">
        <Outlet />
      </main>
      <Footer />
      <BottomNav />
      <ToastContainer />
    </div>
  );
};
