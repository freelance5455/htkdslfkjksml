import { Pause, Play, Square } from "lucide-react";
import { useEffect, useState } from "react";
import { audioEngine, type PlayerStatus } from "@/lib/audio";
import { cn } from "@/lib/utils";

export function PlayerBar() {
  const [status, setStatus] = useState<PlayerStatus>(audioEngine.status);

  useEffect(() => audioEngine.subscribe(setStatus), []);

  if (status.mode === "idle") return null;

  return (
    <div
      className={cn(
        "fixed inset-x-0 z-30 mx-auto max-w-lg px-3",
        "bottom-[calc(4.25rem+env(safe-area-inset-bottom))]",
      )}
    >
      <div className="flex items-center gap-3 rounded-2xl border border-border bg-accent px-3 py-2.5 text-accent-foreground shadow-[var(--shadow-border)]">
        <button
          type="button"
          className="tap-lg flex size-10 items-center justify-center rounded-full bg-accent-foreground/15"
          onClick={() => audioEngine.toggle()}
          aria-label={status.playing ? "إيقاف مؤقت" : "تشغيل"}
        >
          {status.playing ? <Pause className="size-5" /> : <Play className="size-5 ms-0.5" />}
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{status.title}</p>
          <p className="text-[11px] opacity-80">
            {status.mode === "speech" ? "قراءة الجهاز" : "تلاوة"}
            {status.ayah ? ` · آية ${status.ayah}` : ""}
          </p>
        </div>
        <button
          type="button"
          className="tap-lg flex size-10 items-center justify-center rounded-full hover:bg-accent-foreground/10"
          onClick={() => {
            audioEngine.stopSpeech();
            audioEngine.stop();
          }}
          aria-label="إيقاف"
        >
          <Square className="size-4" />
        </button>
      </div>
    </div>
  );
}
