import { formatRial, formatRialCompact } from "@/lib/accounting/format";
import { cn } from "@/lib/utils";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <div className="mb-1 text-[11px] tracking-[0.22em] text-gold uppercase">{eyebrow}</div>
        ) : null}
        <h1 className="text-2xl font-semibold tracking-tight text-navy">{title}</h1>
        {description ? <p className="mt-1 max-w-2xl text-sm text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2 no-print">{actions}</div> : null}
    </div>
  );
}

export function Money({
  value,
  compact = false,
  className,
}: {
  value: number;
  compact?: boolean;
  className?: string;
}) {
  return (
    <span className={cn("tabular", className)} dir="ltr">
      {compact ? formatRialCompact(value) : formatRial(value)}
    </span>
  );
}

export function StatCard({
  label,
  value,
  hint,
  gold = false,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  gold?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-[22px] border p-4 shadow-[var(--shadow-card)]",
        gold ? "border-gold/40 bg-navy text-cream" : "border-line bg-paper",
      )}
    >
      <div className={cn("text-[11px] tracking-wide", gold ? "text-gold-2" : "text-muted")}>{label}</div>
      <div className={cn("mt-2 text-lg font-semibold tabular", gold ? "text-gold-2" : "text-navy")}>
        {value}
      </div>
      {hint ? <div className={cn("mt-1 text-[11px]", gold ? "text-cream/50" : "text-muted")}>{hint}</div> : null}
    </div>
  );
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="rounded-[22px] border border-dashed border-line bg-paper px-6 py-14 text-center">
      <div className="text-sm font-medium text-navy">{title}</div>
      {hint ? <p className="mt-1 text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

export function SkeletonGrid({ n = 6 }: { n?: number }) {
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} className="h-24 animate-pulse rounded-[22px] bg-secondary" />
      ))}
    </div>
  );
}
