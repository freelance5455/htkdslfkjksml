/** quickAdd.js — floating "+" (above the nav bar). Two taps to log water, a task, study, weight, Mastery or start a focus timer. */
import { el, button, textInput, fieldLabel } from '../ui.js';
import { icon } from '../icons.js';
import { openSheet, closeSheet } from '../modal.js';
import { showToast } from '../../core/notifications/toast.js';
import { refreshRoute, navigate } from '../../core/router.js';
import { actionQuickHydration } from '../../modules/dashboard/quickActions.js';
import { openPomodoro } from '../../modules/mind/pomodoro/pomodoroUI.js';
import { openHabitForm } from '../../modules/discipline/habits/habitForm.js';
import { logWeight } from '../../modules/body/weight/weightService.js';
import { todaysMastery } from '../../modules/mastery/masteryService.js';
import { openLogSheet } from '../../modules/mastery/masteryUI.js';

function weightSheet() {
  openSheet('⚖️ Log weight', (body) => {
    const kg = textInput({ type: 'number', placeholder: 'Weight (kg)' }); kg.step = '0.1'; kg.inputMode = 'decimal';
    body.append(el('div', 'field', [fieldLabel('Today\'s weight'), kg]), el('div', 'bottom-sheet__footer', [button('Save', { block: true, onClick: async () => {
      const v = parseFloat(kg.value); if (!(v >= 25 && v <= 300)) { showToast('Enter a weight in kg.'); return; }
      await logWeight({ kg: v }); closeSheet(); showToast('Weight saved.'); refreshRoute();
    } })]));
  });
}

async function masterySheet() {
  const today = await todaysMastery();
  if (!today.length) { showToast('No Mastery skills planned today. Add some in Discipline → Mastery.'); return; }
  openSheet('🌱 Log a skill', (body) => {
    today.forEach((t) => body.append(el('div', 'mt-2', button(`${t.skill.emoji} ${t.skill.name}${t.done ? ' ✓' : ''}`, { block: true, variant: 'ghost', onClick: () => { closeSheet(); openLogSheet(t.skill, refreshRoute); } }))));
  });
}

export function initQuickAdd() {
  const fab = document.createElement('button');
  fab.id = 'quick-fab'; fab.setAttribute('aria-label', 'Quick add');
  fab.append(icon('plus') || document.createTextNode('+'));
  if (!fab.firstChild || !fab.textContent) fab.textContent = '+';
  fab.addEventListener('click', () => {
    openSheet('Quick add', (body) => {
      const item = (label, fn) => el('div', 'mt-2', button(label, { block: true, variant: 'ghost', onClick: fn }));
      body.append(
        item('💧 Water +250 ml', async () => { await actionQuickHydration(); closeSheet(); showToast('+250 ml logged.'); refreshRoute(); }),
        item('✅ Add a task or habit', () => { closeSheet(); openHabitForm({ onDone: refreshRoute }); }),
        item('⏱ Start a focus timer', () => { closeSheet(); openPomodoro(); }),
        item('🌱 Log a Mastery skill', () => { closeSheet(); masterySheet(); }),
        item('⚖️ Log my weight', () => { closeSheet(); weightSheet(); }),
        item('📚 Log a study session', () => { closeSheet(); navigate('/mind'); }),
      );
    });
  });
  document.body.appendChild(fab);
}
