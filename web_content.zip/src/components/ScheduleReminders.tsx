import React, { useState } from 'react';
import {
  CalendarEvent,
  Reminder,
} from '../types/jarvis';
import {
  formatDateDisplay,
  formatTimeDisplay,
} from '../utils/jarvisEngine';
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Circle,
  AlertTriangle,
  Bell,
  MapPin,
  Tag,
  Volume2,
  Check,
  X,
  Sparkles,
} from 'lucide-react';

interface ScheduleRemindersProps {
  events: CalendarEvent[];
  reminders: Reminder[];
  onAddEvent: (event: Omit<CalendarEvent, 'id' | 'notified'>) => void;
  onModifyEvent: (id: string, updates: Partial<CalendarEvent>) => void;
  onDeleteEvent: (id: string) => void;
  onAddReminder: (reminder: Omit<Reminder, 'id' | 'notified'>) => void;
  onModifyReminder: (id: string, updates: Partial<Reminder>) => void;
  onDeleteReminder: (id: string) => void;
  onVoiceCommandExecute: (cmd: string) => void;
  onRequestNotificationPermission: () => void;
  notificationPermissionGranted: boolean;
  onTestNotification: () => void;
}

export const ScheduleReminders: React.FC<ScheduleRemindersProps> = ({
  events,
  reminders,
  onAddEvent,
  onModifyEvent,
  onDeleteEvent,
  onAddReminder,
  onModifyReminder,
  onDeleteReminder,
  onVoiceCommandExecute,
  onRequestNotificationPermission,
  notificationPermissionGranted,
  onTestNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'agenda' | 'reminders' | 'alerts'>('agenda');

  // Event modal state
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [eventStartTime, setEventStartTime] = useState('14:00');
  const [eventEndTime, setEventEndTime] = useState('15:00');
  const [eventLocation, setEventLocation] = useState('Stark Tower');
  const [eventCategory, setEventCategory] = useState<'work' | 'personal' | 'ops' | 'health'>('work');
  const [eventPriority, setEventPriority] = useState<'low' | 'normal' | 'high'>('normal');

  // Reminder modal state
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [editingReminderId, setEditingReminderId] = useState<string | null>(null);
  const [reminderTitle, setReminderTitle] = useState('');
  const [reminderDueTime, setReminderDueTime] = useState('17:00');
  const [reminderHasTime, setReminderHasTime] = useState(true);
  const [reminderCategory, setReminderCategory] = useState('General');
  const [reminderPriority, setReminderPriority] = useState<'normal' | 'urgent'>('normal');

  // Open Event Modal for Add or Edit
  const openEventModal = (event?: CalendarEvent) => {
    if (event) {
      setEditingEventId(event.id);
      setEventTitle(event.title);
      setEventDate(event.startTime.slice(0, 10));
      setEventStartTime(event.startTime.slice(11, 16));
      setEventEndTime(event.endTime.slice(11, 16));
      setEventLocation(event.location || '');
      setEventCategory(event.category);
      setEventPriority(event.priority);
    } else {
      setEditingEventId(null);
      setEventTitle('');
      setEventDate(new Date().toISOString().slice(0, 10));
      setEventStartTime('15:00');
      setEventEndTime('16:00');
      setEventLocation('Stark Industries HQ');
      setEventCategory('work');
      setEventPriority('normal');
    }
    setShowEventModal(true);
  };

  const saveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim()) return;

    const startISO = `${eventDate}T${eventStartTime}:00`;
    const endISO = `${eventDate}T${eventEndTime}:00`;

    if (editingEventId) {
      onModifyEvent(editingEventId, {
        title: eventTitle.trim(),
        startTime: startISO,
        endTime: endISO,
        location: eventLocation.trim(),
        category: eventCategory,
        priority: eventPriority,
      });
    } else {
      onAddEvent({
        title: eventTitle.trim(),
        startTime: startISO,
        endTime: endISO,
        location: eventLocation.trim(),
        category: eventCategory,
        priority: eventPriority,
      });
    }
    setShowEventModal(false);
  };

  // Open Reminder Modal for Add or Edit
  const openReminderModal = (reminder?: Reminder) => {
    if (reminder) {
      setEditingReminderId(reminder.id);
      setReminderTitle(reminder.title);
      setReminderHasTime(Boolean(reminder.dueTime));
      setReminderDueTime(reminder.dueTime ? reminder.dueTime.slice(11, 16) : '18:00');
      setReminderCategory(reminder.category);
      setReminderPriority(reminder.priority);
    } else {
      setEditingReminderId(null);
      setReminderTitle('');
      setReminderHasTime(true);
      setReminderDueTime('18:00');
      setReminderCategory('General');
      setReminderPriority('normal');
    }
    setShowReminderModal(true);
  };

  const saveReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTitle.trim()) return;

    const todayStr = new Date().toISOString().slice(0, 10);
    const dueTimeISO = reminderHasTime ? `${todayStr}T${reminderDueTime}:00` : null;

    if (editingReminderId) {
      onModifyReminder(editingReminderId, {
        title: reminderTitle.trim(),
        dueTime: dueTimeISO,
        category: reminderCategory.trim(),
        priority: reminderPriority,
      });
    } else {
      onAddReminder({
        title: reminderTitle.trim(),
        dueTime: dueTimeISO,
        completed: false,
        category: reminderCategory.trim(),
        priority: reminderPriority,
      });
    }
    setShowReminderModal(false);
  };

  const activeRemindersCount = reminders.filter((r) => !r.completed).length;

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl shadow-cyan-950/40">
      {/* Header and Voice Assistant Prompt */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Calendar className="w-5 h-5" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Schedule & Reminders Core
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Voice-managed calendar engine with proactive predictive notifications
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 bg-gray-950 p-1 rounded-xl border border-gray-800 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('agenda')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all ${
              activeTab === 'agenda'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            Agenda ({events.length})
          </button>
          <button
            onClick={() => setActiveTab('reminders')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all ${
              activeTab === 'reminders'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            Reminders ({activeRemindersCount})
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all flex items-center gap-1 ${
              activeTab === 'alerts'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            Alerts
          </button>
        </div>
      </div>

      {/* Voice Quick Command Bar for Schedule Operations */}
      <div className="mb-4 p-2.5 rounded-xl bg-gray-950/70 border border-cyan-500/20 flex flex-wrap items-center gap-2">
        <span className="text-[11px] font-mono-code text-cyan-400 flex items-center gap-1 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Voice Command Shortcuts:
        </span>
        <button
          onClick={() => onVoiceCommandExecute('Schedule Stark Industries Board Meeting tomorrow at 3 PM')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Schedule meeting at 3 PM"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Reschedule Stark Industries Board Review to 4 PM')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Reschedule to 4 PM"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Remind me to check repulsor battery in 20 minutes')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Remind me in 20m"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('What is on my schedule today?')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Daily briefing"
        </button>
      </div>

      {/* TAB 1: AGENDA & CALENDAR */}
      {activeTab === 'agenda' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono-code uppercase text-cyan-400 tracking-wider">
              Today's Chronological Schedule
            </span>
            <button
              onClick={() => openEventModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold text-xs uppercase tracking-wider transition shadow-md shadow-cyan-600/30"
            >
              <Plus className="w-4 h-4" />
              Add Event
            </button>
          </div>

          {events.length === 0 ? (
            <div className="text-center py-10 border border-dashed border-gray-800 rounded-xl">
              <Calendar className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-sm text-slate-400 font-rajdhani">No events scheduled. Tell Jarvis to add one or click "Add Event".</p>
            </div>
          ) : (
            <div className="space-y-3">
              {events.map((evt) => {
                const priorityBadge =
                  evt.priority === 'high'
                    ? 'border-red-500/40 bg-red-950/40 text-red-300'
                    : evt.priority === 'low'
                    ? 'border-slate-700 bg-slate-900 text-slate-400'
                    : 'border-cyan-500/30 bg-cyan-950/40 text-cyan-300';

                const categoryColor =
                  evt.category === 'ops'
                    ? 'text-amber-400 border-amber-500/30 bg-amber-950/30'
                    : evt.category === 'personal'
                    ? 'text-purple-400 border-purple-500/30 bg-purple-950/30'
                    : evt.category === 'health'
                    ? 'text-emerald-400 border-emerald-500/30 bg-emerald-950/30'
                    : 'text-cyan-400 border-cyan-500/30 bg-cyan-950/30';

                return (
                  <div
                    key={evt.id}
                    className="group relative p-3.5 sm:p-4 rounded-xl bg-gray-950/80 border border-gray-800 hover:border-cyan-500/50 transition-all shadow-sm hover:shadow-cyan-900/20"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div className="flex items-start gap-3">
                        {/* Time Box */}
                        <div className="flex flex-col items-center justify-center min-w-[70px] px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 text-center">
                          <span className="font-mono-code text-xs font-bold text-cyan-300">
                            {formatTimeDisplay(evt.startTime)}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono-code">
                            {formatTimeDisplay(evt.endTime)}
                          </span>
                        </div>

                        {/* Title and Details */}
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-semibold text-slate-100 text-sm sm:text-base group-hover:text-cyan-200 transition">
                              {evt.title}
                            </h3>
                            <span className={`text-[10px] uppercase font-mono-code px-2 py-0.5 rounded border ${priorityBadge}`}>
                              {evt.priority}
                            </span>
                            <span className={`text-[10px] uppercase font-mono-code px-2 py-0.5 rounded border ${categoryColor}`}>
                              {evt.category}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-400">
                            {evt.location && (
                              <span className="flex items-center gap-1 text-slate-400">
                                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                                {evt.location}
                              </span>
                            )}
                            <span className="text-slate-500 font-mono-code">
                              {formatDateDisplay(evt.startTime)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 self-end sm:self-center mt-2 sm:mt-0">
                        <button
                          onClick={() => openEventModal(evt)}
                          aria-label={`Edit ${evt.title}`}
                          className="p-1.5 rounded-lg bg-gray-900 border border-gray-700 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/50 transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteEvent(evt.id)}
                          aria-label={`Delete ${evt.title}`}
                          className="p-1.5 rounded-lg bg-gray-900 border border-gray-700 text-slate-400 hover:text-red-400 hover:border-red-500/50 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: REMINDERS & ACTION ITEMS */}
      {activeTab === 'reminders' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono-code uppercase text-cyan-400 tracking-wider">
              Pending Tasks & Timed Reminders
            </span>
            <button
              onClick={() => openReminderModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold text-xs uppercase tracking-wider transition shadow-md shadow-cyan-600/30"
            >
              <Plus className="w-4 h-4" />
              Add Reminder
            </button>
          </div>

          {reminders.length === 0 ? (
            <div className="text-center py-10 border border-dashed border-gray-800 rounded-xl">
              <CheckCircle2 className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-sm text-slate-400 font-rajdhani">All reminders resolved. Say "Remind me to..." to add one.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {reminders.map((rem) => {
                return (
                  <div
                    key={rem.id}
                    className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      rem.completed
                        ? 'bg-gray-950/40 border-gray-800/60 opacity-60'
                        : rem.priority === 'urgent'
                        ? 'bg-gray-950/90 border-amber-500/40 shadow-sm shadow-amber-950/20'
                        : 'bg-gray-950/80 border-gray-800 hover:border-cyan-500/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => onModifyReminder(rem.id, { completed: !rem.completed })}
                        aria-label={`Toggle reminder ${rem.title}`}
                        className={`p-1 rounded-md transition ${
                          rem.completed
                            ? 'text-emerald-400 hover:text-slate-400'
                            : 'text-cyan-400 hover:text-emerald-400'
                        }`}
                      >
                        {rem.completed ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div>
                        <p
                          className={`text-sm font-medium transition ${
                            rem.completed
                              ? 'line-through text-slate-500'
                              : 'text-slate-200'
                          }`}
                        >
                          {rem.title}
                        </p>

                        <div className="flex items-center gap-2 mt-1 text-[11px] font-mono-code text-slate-400">
                          {rem.dueTime && (
                            <span className="flex items-center gap-1 text-cyan-300">
                              <Clock className="w-3 h-3" />
                              {formatTimeDisplay(rem.dueTime)}
                            </span>
                          )}
                          <span className="px-1.5 py-0.5 rounded bg-gray-900 border border-gray-800 text-[10px] text-slate-400">
                            {rem.category}
                          </span>
                          {rem.priority === 'urgent' && (
                            <span className="text-[10px] text-amber-400 font-bold tracking-wider uppercase">
                              URGENT
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openReminderModal(rem)}
                        aria-label={`Edit reminder ${rem.title}`}
                        className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-cyan-300 transition"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteReminder(rem.id)}
                        aria-label={`Delete reminder ${rem.title}`}
                        className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-red-400 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: ALERTS & TIMELY NOTIFICATIONS ENGINE */}
      {activeTab === 'alerts' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-gray-950/90 border border-cyan-500/30">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-orbitron text-sm font-bold text-cyan-300 flex items-center gap-2">
                  <Bell className="w-4 h-4 text-cyan-400" />
                  Jarvis Predictive Notification Engine
                </h3>
                <p className="text-xs text-slate-400 font-rajdhani mt-1">
                  Jarvis scans upcoming events and reminders continuously. When an item is due within 15 minutes, Jarvis speaks the reminder, vibrates the device, and fires a push notification.
                </p>
              </div>

              {!notificationPermissionGranted ? (
                <button
                  onClick={onRequestNotificationPermission}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-gray-950 text-xs font-bold font-orbitron uppercase tracking-wider transition shrink-0"
                >
                  Enable Push
                </button>
              ) : (
                <span className="px-2.5 py-1 rounded-md bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-mono-code font-bold uppercase shrink-0">
                  Active
                </span>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-gray-800 flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-mono-code text-slate-400">
                Notification Cadence: 15m prior, 5m prior, and at start
              </span>
              <button
                onClick={onTestNotification}
                className="px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/40 hover:bg-cyan-950 text-cyan-300 text-xs font-mono-code transition flex items-center gap-1.5"
              >
                <Volume2 className="w-3.5 h-3.5" />
                Test Voice & Haptic Alert
              </button>
            </div>
          </div>

          {/* Upcoming schedule summary */}
          <div className="p-3.5 rounded-xl bg-gray-950/60 border border-gray-800">
            <span className="text-xs font-mono-code uppercase text-slate-400 tracking-wider block mb-2">
              Upcoming Telemetry Queue:
            </span>
            <div className="space-y-1.5 text-xs text-slate-300 font-mono-code">
              {events.slice(0, 3).map((e) => (
                <div key={e.id} className="flex items-center justify-between py-1 border-b border-gray-800/50">
                  <span className="text-cyan-200">▶ {e.title}</span>
                  <span className="text-slate-400">{formatTimeDisplay(e.startTime)}</span>
                </div>
              ))}
              {reminders.filter((r) => !r.completed).slice(0, 2).map((r) => (
                <div key={r.id} className="flex items-center justify-between py-1 border-b border-gray-800/50">
                  <span className="text-amber-300">⚡ {r.title}</span>
                  <span className="text-slate-400">{r.dueTime ? formatTimeDisplay(r.dueTime) : 'Anytime'}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* EVENT ADD / EDIT MODAL */}
      {showEventModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <h3 className="font-orbitron text-sm font-bold text-cyan-300 uppercase tracking-wider">
                {editingEventId ? 'Modify Calendar Event' : 'Schedule New Event'}
              </h3>
              <button
                onClick={() => setShowEventModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={saveEvent} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  required
                  value={eventTitle}
                  onChange={(e) => setEventTitle(e.target.value)}
                  placeholder="e.g. Stark Industries Strategic Review"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    required
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    value={eventLocation}
                    onChange={(e) => setEventLocation(e.target.value)}
                    placeholder="e.g. Tower Penthouse"
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    required
                    value={eventStartTime}
                    onChange={(e) => setEventStartTime(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    required
                    value={eventEndTime}
                    onChange={(e) => setEventEndTime(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={eventCategory}
                    onChange={(e) => setEventCategory(e.target.value as any)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  >
                    <option value="work">Work / Stark</option>
                    <option value="personal">Personal</option>
                    <option value="ops">Ops / Mission</option>
                    <option value="health">Health</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={eventPriority}
                    onChange={(e) => setEventPriority(e.target.value as any)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  >
                    <option value="normal">Normal</option>
                    <option value="high">High Priority</option>
                    <option value="low">Low Priority</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowEventModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30"
                >
                  {editingEventId ? 'Update Event' : 'Confirm Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REMINDER ADD / EDIT MODAL */}
      {showReminderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <h3 className="font-orbitron text-sm font-bold text-cyan-300 uppercase tracking-wider">
                {editingReminderId ? 'Modify Reminder' : 'Set New Reminder'}
              </h3>
              <button
                onClick={() => setShowReminderModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={saveReminder} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Reminder Title
                </label>
                <input
                  type="text"
                  required
                  value={reminderTitle}
                  onChange={(e) => setReminderTitle(e.target.value)}
                  placeholder="e.g. Authorize lab supply order"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="hasTime"
                  checked={reminderHasTime}
                  onChange={(e) => setReminderHasTime(e.target.checked)}
                  className="rounded border-gray-700 text-cyan-500 focus:ring-0"
                />
                <label htmlFor="hasTime" className="text-xs text-slate-300 font-mono-code">
                  Specific Due Time Today
                </label>
              </div>

              {reminderHasTime && (
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Due Time
                  </label>
                  <input
                    type="time"
                    required={reminderHasTime}
                    value={reminderDueTime}
                    onChange={(e) => setReminderDueTime(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={reminderCategory}
                    onChange={(e) => setReminderCategory(e.target.value)}
                    placeholder="General / Lab / Comms"
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={reminderPriority}
                    onChange={(e) => setReminderPriority(e.target.value as any)}
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                  >
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowReminderModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30"
                >
                  {editingReminderId ? 'Update Reminder' : 'Set Reminder'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
