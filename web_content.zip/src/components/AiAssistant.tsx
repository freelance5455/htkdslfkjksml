import React, { useState, useRef, useEffect } from "react";
import { ChatMessage, CategoryItem } from "../types";
import { speechManager, ttsManager, isSpeechRecognitionSupported } from "../utils/speech";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Trash2,
  Bot,
  User,
  Sparkles,
  ArrowDown,
  Info,
  Loader2,
} from "lucide-react";

interface AiAssistantProps {
  rates: Record<string, number | null>;
  categories: CategoryItem[];
  isOpen: boolean;
  onClose: () => void;
  onApplyCalculation?: (categoryId: string, length: number, width: number) => void;
}

export const AiAssistant: React.FC<AiAssistantProps> = ({
  rates,
  categories,
  isOpen,
  onClose,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-msg",
      role: "assistant",
      text: "Namaste! Main aapka **Ceiling Calculation AI Assistant** hoon. \n\nAap mujhse ceiling material (Gypsum, PVC, POP, Grid), wall panels, rates, aur kisi bhi room size ke kharche ke baare mein pooch sakte hain. \n\n*Aap mic button daba kar bol bhi sakte hain!*",
      timestamp: Date.now(),
    },
  ]);

  const [inputVal, setInputVal] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  // Clean up speech when closing
  useEffect(() => {
    return () => {
      ttsManager.stop();
      speechManager.stop();
    };
  }, []);

  const samplePrompts = [
    "10 × 12 room mein PVC ceiling ka kitna kharcha hoga?",
    "Gypsum aur PVC ceiling mein kya difference hai?",
    "Mere living room ke liye kaunsa material achha rahega?",
    "Fluted panel aur Louver panel ke rates kya hain?",
    "10 × 10 room mein POP ceiling ka estimate batao",
  ];

  // Send message to backend /api/ai/chat with offline fallback safety
  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || inputVal).trim();
    if (!textToSend || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user_${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!customText) setInputVal("");
    setIsLoading(true);
    setSpeechError(null);

    // Stop ongoing speech
    ttsManager.stop();
    setSpeakingMsgId(null);

    try {
      // Fetch with timeout fallback
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          history: messages.slice(-5),
          rates,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage: ChatMessage = {
        id: `ai_${Date.now()}`,
        role: "assistant",
        text: data.reply || "Aapke room ka estimate calculate kar liya gaya hai.",
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.warn("AI Chat API call failed, generating instant fallback:", err);
      // Generate instant fallback answer using local rates
      const localReply = generateLocalAiAnswer(textToSend, rates);
      const fallbackMsg: ChatMessage = {
        id: `ai_${Date.now()}`,
        role: "assistant",
        text: localReply,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Local fallback response generator if server is busy or offline
  const generateLocalAiAnswer = (prompt: string, currentRates: Record<string, number | null>): string => {
    const lower = prompt.toLowerCase();
    const dimMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:x|\*|by|×)\s*(\d+(?:\.\d+)?)/i);
    const sqftMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:sq\s*ft|sqft|square\s*feet|gaj)/i);

    let l = 10, w = 10, area = 100;
    if (dimMatch) {
      l = parseFloat(dimMatch[1]);
      w = parseFloat(dimMatch[2]);
      area = l * w;
    } else if (sqftMatch) {
      area = parseFloat(sqftMatch[1]);
      l = Math.round(Math.sqrt(area));
      w = Math.round(area / l);
    }

    const s = area / 100;

    // 1. Wallpaper
    if (lower.includes("wallpaper")) {
      const rolls = Number(((area / 100) * 3).toFixed(2));
      const matTotal = rolls * 1500;
      const labTotal = rolls * 400;
      const grand = matTotal + labTotal;
      return `📦 **Wallpaper BOQ (${area} sq ft / ${l}×${w} ft):**\n\n• **Material**: ${rolls} Rolls @ ₹1,500 = ₹${matTotal.toLocaleString("en-IN")}\n• **Labour**: ${rolls} Rolls @ ₹400 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 2. Grid Ceiling
    if (lower.includes("grid") || lower.includes("greet") || lower.includes("2x2")) {
      const matTotal = Number((2642.50 * s).toFixed(2));
      const labTotal = Number((area * 10).toFixed(2));
      const grand = Number((matTotal + labTotal).toFixed(2));
      return `📦 **Grid Ceiling 2x2 BOQ (${area} sq ft):**\n\n• **Material BOQ (7 items)**: ₹${matTotal.toLocaleString("en-IN")}\n  (Tiles, L-Profile, Manti, 4ft, 2ft, Gitti, Box)\n• **Labour**: ${area} sq ft @ ₹10 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 3. Fluted Panel
    if (lower.includes("fluted")) {
      const matTotal = Number((9280 * s).toFixed(2));
      const labTotal = Number((area * 15).toFixed(2));
      const grand = Number((matTotal + labTotal).toFixed(2));
      return `📦 **Fluted Panel BOQ (${area} sq ft):**\n\n• **Material Total**: ₹${matTotal.toLocaleString("en-IN")}\n  (Panels, U-Bedding, Keel)\n• **Labour**: ${area} sq ft @ ₹15 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 4. Louver Panel
    if (lower.includes("louver") || lower.includes("lower")) {
      const matTotal = Number((17290 * s).toFixed(2));
      const labTotal = Number((area * 15).toFixed(2));
      const grand = Number((matTotal + labTotal).toFixed(2));
      return `📦 **Louver Panel BOQ (${area} sq ft):**\n\n• **Material Total**: ₹${matTotal.toLocaleString("en-IN")}\n  (20 Panels @ ₹855, L-Profile, Keel)\n• **Labour**: ${area} sq ft @ ₹15 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 5. PVC Wall Panel
    if (lower.includes("wall panel") || (lower.includes("pvc") && lower.includes("wall"))) {
      const matTotal = Number((2490 * s).toFixed(2));
      const labTotal = Number((area * 12).toFixed(2));
      const grand = Number((matTotal + labTotal).toFixed(2));
      return `📦 **PVC Wall Panel BOQ (${area} sq ft):**\n\n• **Material Total**: ₹${matTotal.toLocaleString("en-IN")}\n  (13 Panels @ ₹170, U-Bedding, Keel)\n• **Labour**: ${area} sq ft @ ₹12 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 6. PVC Ceiling
    if (lower.includes("pvc")) {
      const rate = currentRates["pvc_ceiling"] ?? 60;
      const matTotal = area * rate;
      const labTotal = area * 18;
      const grand = matTotal + labTotal;
      return `📐 **PVC Ceiling Estimate (${area} sq ft / ${l}×${w} ft):**\n\n• **Material Cost**: ${area} sq ft @ ₹${rate} = ₹${matTotal.toLocaleString("en-IN")}\n• **Labour Cost**: ${area} sq ft @ ₹18 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 7. Gypsum Ceiling
    if (lower.includes("gypsum")) {
      const rate = currentRates["gypsum_ceiling"] ?? 65;
      const matTotal = area * rate;
      const labTotal = area * 20;
      const grand = matTotal + labTotal;
      return `📐 **Gypsum Ceiling Estimate (${area} sq ft / ${l}×${w} ft):**\n\n• **Material Cost**: ${area} sq ft @ ₹${rate} = ₹${matTotal.toLocaleString("en-IN")}\n• **Labour Cost**: ${area} sq ft @ ₹20 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**\n*(Note: Gypsum itemized BOQ not fully configured, using base material estimate)*`;
    }

    // 8. POP Ceiling
    if (lower.includes("pop")) {
      const rate = currentRates["pop_ceiling"] ?? 120;
      const matTotal = area * rate;
      const labTotal = area * 25;
      const grand = matTotal + labTotal;
      return `📐 **POP Ceiling Estimate (${area} sq ft / ${l}×${w} ft):**\n\n• **Material Cost**: ${area} sq ft @ ₹${rate} = ₹${matTotal.toLocaleString("en-IN")}\n• **Labour Cost**: ${area} sq ft @ ₹25 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    // 9. UV Marble Sheet
    if (lower.includes("uv") || lower.includes("marble")) {
      const sheetCount = Number((1 * s).toFixed(1));
      const sheetMat = Number((sheetCount * 32 * 120).toFixed(2));
      const lowerLMat = Number((5 * s * 45).toFixed(2));
      const siliconeMat = Number((2 * s * 300).toFixed(2));
      const matTotal = sheetMat + lowerLMat + siliconeMat;
      const labTotal = Number((area * 20).toFixed(2));
      const grand = matTotal + labTotal;

      return `📦 **UV Marble Sheet BOQ (${area} sq ft):**\n\n• **Material BOQ**:\n  1. UV Marble Sheet (8×4 ft / 32 sq ft): ${sheetCount} sheet @ ₹120/sq ft = ₹${sheetMat.toLocaleString("en-IN")}\n  2. Lower Panel (6 inch): ${(15 * s).toFixed(1)} pcs (Rate not configured)\n  3. Lower L: ${(5 * s).toFixed(1)} pcs @ ₹45 = ₹${lowerLMat.toLocaleString("en-IN")}\n  4. Bond Silicone: ${(2 * s).toFixed(1)} pcs @ ₹300 = ₹${siliconeMat.toLocaleString("en-IN")} *(included in material)*\n• **Material Total**: ₹${matTotal.toLocaleString("en-IN")}\n• **Labour**: ${area} sq ft @ ₹20 = ₹${labTotal.toLocaleString("en-IN")}\n• **Grand Total**: **₹${grand.toLocaleString("en-IN")}**`;
    }

    if (lower.includes("difference") || (lower.includes("gypsum") && lower.includes("pvc"))) {
      return `💡 **Gypsum vs PVC Ceiling:**\n\n1. **Gypsum (₹65 material + ₹20 labour = ₹85/sq ft)**: Premium smooth look, cove lights aur hall/bedroom ke liye best.\n2. **PVC (₹60 material + ₹18 labour = ₹78/sq ft)**: Waterproof, termite-proof, easy clean, bathroom/kitchen aur normal rooms ke liye best.`;
    }

    return `Ceiling materials ke exact rates & BOQ formulas available hain:\n• Gypsum Ceiling: ₹65 material + ₹20 labour\n• PVC Ceiling: ₹60 material + ₹18 labour\n• Grid Ceiling: Detailed 7-item BOQ (₹2,642.50/100 sq ft) + ₹10 labour\n• Wallpaper: 3 Rolls @ ₹1,500 + ₹400 labour/roll\n• Fluted Panel: Detailed BOQ (₹9,280/100 sq ft) + ₹15 labour\n• Louver Panel: Detailed BOQ (₹17,290/100 sq ft) + ₹15 labour\n• PVC Wall Panel: Detailed BOQ (₹2,490/100 sq ft) + ₹12 labour\n\nAap apna room size (jaise 10×12 ft) batayein, main turant BOQ generate kar dunga!`;
  };

  // Voice Input (Microphone)
  const handleToggleMic = () => {
    if (isListening) {
      speechManager.stop();
      setIsListening(false);
    } else {
      setSpeechError(null);
      speechManager.listen(
        (transcript) => {
          setIsListening(false);
          if (transcript.trim()) {
            setInputVal(transcript);
            handleSendMessage(transcript);
          }
        },
        (listening) => {
          setIsListening(listening);
        },
        (error) => {
          setIsListening(false);
          setSpeechError(error);
          setTimeout(() => setSpeechError(null), 5000);
        }
      );
    }
  };

  // Voice Output (Speaker)
  const handleToggleSpeaker = (msg: ChatMessage) => {
    if (speakingMsgId === msg.id) {
      ttsManager.stop();
      setSpeakingMsgId(null);
    } else {
      ttsManager.speak(
        msg.id,
        msg.text,
        (id) => setSpeakingMsgId(id),
        () => setSpeakingMsgId(null),
        (err) => {
          setSpeakingMsgId(null);
          setSpeechError(err);
          setTimeout(() => setSpeechError(null), 3000);
        }
      );
    }
  };

  const handleClearChat = () => {
    ttsManager.stop();
    setSpeakingMsgId(null);
    setMessages([
      {
        id: `welcome_${Date.now()}`,
        role: "assistant",
        text: "Chat cleared. Aap koi naya sawaal pooch sakte hain ya room size bata sakte hain!",
        timestamp: Date.now(),
      },
    ]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex flex-col justify-end sm:justify-center sm:p-4">
      <div className="bg-slate-900 text-white w-full sm:max-w-lg sm:rounded-3xl h-[92vh] sm:h-[85vh] max-h-[750px] mx-auto flex flex-col shadow-2xl border border-slate-800 overflow-hidden animate-slide-up">
        {/* Chat Header */}
        <div className="p-4 sm:p-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-bold shadow-md shadow-indigo-600/30">
              <Bot className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-sm sm:text-base text-white">
                  Ceiling AI Assistant
                </h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-400">
                Hindi / Hinglish & Live Rate Calculations
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleClearChat}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              title="Clear Chat"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                ttsManager.stop();
                speechManager.stop();
                onClose();
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl text-slate-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>

        {/* Speech Error Banner */}
        {speechError && (
          <div className="bg-amber-500/20 border-b border-amber-500/30 px-3 py-2 text-xs text-amber-200 flex items-center gap-2 shrink-0">
            <Info className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{speechError}</span>
          </div>
        )}

        {/* Chat Messages List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-950/60">
          {messages.map((msg) => {
            const isUser = msg.role === "user";
            const isSpeaking = speakingMsgId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isUser ? "justify-end" : "justify-start"}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? "bg-indigo-600 text-white font-medium rounded-tr-none shadow-md"
                      : "bg-white text-slate-900 border border-slate-200 rounded-tl-none space-y-2 shadow-sm"
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.text}</div>

                  {/* Speaker Button on AI Messages */}
                  {!isUser && (
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <button
                        onClick={() => handleToggleSpeaker(msg)}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors ${
                          isSpeaking
                            ? "bg-indigo-50 text-indigo-700 font-bold border border-indigo-200"
                            : "hover:bg-slate-100 text-slate-600 hover:text-slate-900"
                        }`}
                        title={isSpeaking ? "Stop reading" : "Read aloud (Hindi/English)"}
                      >
                        {isSpeaking ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                            <span>Stop Audio</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Listen</span>
                          </>
                        )}
                      </button>

                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex gap-2.5 justify-start">
              <div className="w-7 h-7 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center shrink-0 mt-0.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
              </div>
              <div className="bg-white text-slate-800 rounded-2xl rounded-tl-none p-3.5 text-xs flex items-center gap-2 border border-slate-200 shadow-sm">
                <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                <span>AI calculating estimate...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Sample Questions */}
        <div className="px-3 py-2.5 bg-slate-900 border-t border-slate-800 flex gap-1.5 overflow-x-auto scrollbar-none shrink-0">
          {samplePrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              disabled={isLoading}
              className="text-[11px] bg-slate-800 hover:bg-slate-750 text-slate-300 px-3 py-1 rounded-full whitespace-nowrap border border-slate-700/80 shrink-0 transition-colors disabled:opacity-50"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar with Microphone and Send Button */}
        <div className="p-3.5 bg-slate-900 border-t border-slate-800 flex items-center gap-2 shrink-0">
          {/* Microphone Button */}
          <button
            type="button"
            onClick={handleToggleMic}
            className={`p-3 rounded-xl flex items-center justify-center transition-all ${
              isListening
                ? "bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/30"
                : "bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-slate-700"
            }`}
            title={isListening ? "Listening... (Tap to stop)" : "Speak your question (Mic)"}
          >
            {isListening ? (
              <MicOff className="w-5 h-5" />
            ) : (
              <Mic className="w-5 h-5" />
            )}
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              placeholder={
                isListening
                  ? "Aapki aawaz sun raha hoon..."
                  : "Type in Hindi/English (e.g. 10x12 PVC ceiling cost?)"
              }
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSendMessage();
                }
              }}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-3 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Send Button */}
          <button
            type="button"
            onClick={() => handleSendMessage()}
            disabled={!inputVal.trim() || isLoading}
            className="p-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white font-bold rounded-xl transition-all active:scale-95 shadow-md shadow-indigo-600/20"
            title="Send Message"
          >
            <Send className="w-5 h-5 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
