"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import ProductCard, { type ProductCardData } from "./ProductCard";

type SortMode = "featured" | "price-asc" | "price-desc" | "newest" | "name";

export default function Marketplace({
  products,
  categories,
}: {
  products: ProductCardData[];
  categories: string[];
}) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState<SortMode>("featured");

  const filtered = useMemo(() => {
    let list = products.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.modelNumber.toLowerCase().includes(search.toLowerCase()) ||
        p.category.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === "All" || p.category === category;
      return matchesSearch && matchesCategory;
    });

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "newest":
        list = [...list].sort((a, b) => Number(b.isNewArrival) - Number(a.isNewArrival) || b.id - a.id);
        break;
      case "name":
        list = [...list].sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        list = [...list].sort(
          (a, b) =>
            Number(b.isFeatured) - Number(a.isFeatured) ||
            Number(b.isBestSeller) - Number(a.isBestSeller) ||
            b.id - a.id
        );
    }
    return list;
  }, [products, search, category, sort]);

  return (
    <div>
      {/* Search + Filter bar */}
      <div className="mb-10 grid gap-4 rounded-3xl border border-white/10 bg-white/[0.03] p-4 backdrop-blur-xl md:grid-cols-[1fr_auto]">
        <div className="relative">
          <svg className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M17 10a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search models, names or model numbers..."
            className="w-full rounded-2xl border border-white/10 bg-black/40 py-3.5 pl-11 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
          />
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortMode)}
          className="rounded-2xl border border-white/10 bg-black/40 px-4 py-3.5 text-sm text-white focus:border-purple-400/60 focus:outline-none"
        >
          <option value="featured">Sort: Featured</option>
          <option value="price-asc">Price: Low → High</option>
          <option value="price-desc">Price: High → Low</option>
          <option value="newest">Newest First</option>
          <option value="name">Name A–Z</option>
        </select>
      </div>

      {/* Category chips */}
      <div className="mb-8 flex flex-wrap gap-2">
        {["All", ...categories].map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              category === c
                ? "bg-gradient-to-r from-purple-500 to-blue-600 text-white shadow-[0_0_16px_rgba(139,92,246,0.5)]"
                : "border border-white/10 bg-white/5 text-slate-300 hover:border-purple-400/50 hover:text-white"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] py-20 text-center">
          <p className="text-4xl">🔍</p>
          <p className="mt-3 text-slate-400">No models found matching your search.</p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}

      <motion.div className="mt-12 text-center text-sm text-slate-500">
        Showing <span className="text-purple-300">{filtered.length}</span> of {products.length} models
      </motion.div>
    </div>
  );
}