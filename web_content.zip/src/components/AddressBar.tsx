"use client";
import { useEffect, useRef, useState } from "react";
import { SEARCH_ENGINES, hostOf, isSecure, type SearchEngineId } from "@/lib/browser";
import { Icon, IconButton } from "./ui";

type Suggestion = { type: string; text: string; url?: string; title?: string };

export function AddressBar({
  url,
  engine,
  loading,
  blockedCount,
  onNavigate,
  onEngineChange,
  onSearchWith,
  inputRef,
}: {
  url: string;
  engine: SearchEngineId;
  loading: boolean;
  blockedCount: number;
  onNavigate: (input: string) => void;
  onEngineChange: (e: SearchEngineId) => void;
  onSearchWith: (e: SearchEngineId, q: string) => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
}) {
  const [value, setValue] = useState(url === "nova://home" ? "" : url);
  const [focused, setFocused] = useState(false);
  const [sugs, setSugs] = useState<Suggestion[]>([]);
  const [sel, setSel] = useState(-1);
  const [engineMenu, setEngineMenu] = useState(false);
  const [listening, setListening] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!focused) setValue(url === "nova://home" ? "" : url);
  }, [url, focused]);

  useEffect(() => {
    if (!focused) return;
    const q = value.trim();
    if (!q || q === url) {
      setSugs([]);
      return;
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/suggest?q=${encodeURIComponent(q)}&engine=${engine}`);
        const d = (await r.json()) as { suggestions: Suggestion[] };
        setSugs(d.suggestions || []);
        setSel(-1);
      } catch {
        setSugs([]);
      }
    }, 180);
  }, [value, focused, engine, url]);

  const submit = (v?: string) => {
    const text = (v ?? value).trim();
    if (!text) return;
    onNavigate(text);
    inputRef.current?.blur();
    setFocused(false);
    setSugs([]);
  };

  const startVoice = () => {
    const W = window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike; SpeechRecognition?: new () => SpeechRecognitionLike };
    const SR = W.SpeechRecognition || W.webkitSpeechRecognition;
    if (!SR) return alert("Голосовой ввод не поддерживается этим устройством");
    const rec = new SR();
    rec.lang = "ru-RU";
    rec.onresult = (e) => {
      const t = e.results[0][0].transcript;
      setValue(t);
      submit(t);
    };
    rec.onend = () => setListening(false);
    setListening(true);
    rec.start();
  };

  const secure = isSecure(url);
  const isHome = url === "nova://home";
  const E = SEARCH_ENGINES[engine];

  return (
    <div className="relative min-w-0 flex-1">
      <div
        className={`accent-ring flex h-10 items-center gap-1 rounded-full border bg-white pl-1 pr-1 transition dark:bg-white/5
          ${focused ? "border-transparent shadow-lg" : "border-black/5 dark:border-white/10"}`}
      >
        {/* Переключатель поисковика */}
        <button
          type="button"
          onClick={() => setEngineMenu((v) => !v)}
          title={`Поиск: ${E.name} (нажмите для смены)`}
          className="flex h-8 shrink-0 items-center gap-1 rounded-full px-2 text-xs font-bold text-white"
          style={{ background: E.color }}
        >
          {E.icon}
          <Icon name="chevron" size={12} />
        </button>

        {/* Индикатор безопасности */}
        {!isHome && !focused && (
          <span
            title={secure ? "Защищённое соединение (HTTPS)" : "Соединение не защищено (HTTP)"}
            className={`hidden shrink-0 items-center sm:flex ${secure ? "text-emerald-600 dark:text-emerald-400" : "text-amber-500"}`}
          >
            <Icon name={secure ? "lock" : "unlock"} size={14} />
          </span>
        )}

        <input
          ref={inputRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={(e) => {
            setFocused(true);
            setTimeout(() => e.target.select(), 0);
          }}
          onBlur={() => setTimeout(() => setFocused(false), 150)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              if (sel >= 0 && sugs[sel]) submit(sugs[sel].url || sugs[sel].text);
              else submit();
            } else if (e.key === "ArrowDown") {
              e.preventDefault();
              setSel((s) => Math.min(s + 1, sugs.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setSel((s) => Math.max(s - 1, -1));
            } else if (e.key === "Escape") {
              inputRef.current?.blur();
              setValue(url === "nova://home" ? "" : url);
            }
          }}
          placeholder={`Введите адрес или запрос в ${E.name}`}
          className="min-w-0 flex-1 bg-transparent px-1 text-sm outline-none placeholder:text-slate-400"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          inputMode="url"
        />

        {!focused && !isHome && blockedCount > 0 && (
          <span title={`Заблокировано трекеров: ${blockedCount}`} className="hidden items-center gap-0.5 rounded-full bg-emerald-500/10 px-1.5 text-[10px] font-semibold text-emerald-600 sm:flex dark:text-emerald-400">
            <Icon name="shield" size={11} /> {blockedCount}
          </span>
        )}
        {loading && <span className="h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-slate-300 border-t-[var(--accent)]" />}
        <IconButton icon="mic" label="Голосовой ввод" size={16} onClick={startVoice} className={`!h-8 !w-8 ${listening ? "animate-pulse accent-text" : ""}`} />
      </div>

      {/* Меню поисковиков */}
      {engineMenu && (
        <div className="absolute left-0 top-11 z-50 w-56 overflow-hidden rounded-2xl border border-black/5 bg-white p-1 shadow-2xl dark:border-white/10 dark:bg-slate-900">
          <div className="px-3 py-1.5 text-[11px] font-semibold uppercase text-slate-400">Поисковая система</div>
          {(Object.keys(SEARCH_ENGINES) as SearchEngineId[]).map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                onEngineChange(id);
                setEngineMenu(false);
              }}
              className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm hover:bg-black/5 dark:hover:bg-white/10"
            >
              <span className="flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold text-white" style={{ background: SEARCH_ENGINES[id].color }}>
                {SEARCH_ENGINES[id].icon}
              </span>
              <span className="flex-1">{SEARCH_ENGINES[id].name}</span>
              {id === engine && <Icon name="check" size={14} className="accent-text" />}
            </button>
          ))}
          <div className="px-3 py-1.5 text-[10px] text-slate-400">Подсказка: «g запрос» — Google, «y запрос» — Яндекс</div>
        </div>
      )}

      {/* Автодополнение */}
      {focused && (sugs.length > 0 || value.trim()) && (
        <div className="absolute left-0 right-0 top-11 z-50 overflow-hidden rounded-2xl border border-black/5 bg-white py-1 shadow-2xl dark:border-white/10 dark:bg-slate-900">
          {value.trim() && (
            <div className="flex items-center gap-1 border-b border-black/5 px-2 py-1.5 dark:border-white/10">
              <span className="px-1 text-[11px] text-slate-400">Искать «{value.trim().slice(0, 30)}» в:</span>
              <button type="button" onMouseDown={() => onSearchWith("google", value)} className="rounded-full px-2 py-0.5 text-xs font-semibold text-white" style={{ background: SEARCH_ENGINES.google.color }}>
                Google
              </button>
              <button type="button" onMouseDown={() => onSearchWith("yandex", value)} className="rounded-full px-2 py-0.5 text-xs font-semibold text-white" style={{ background: SEARCH_ENGINES.yandex.color }}>
                Яндекс
              </button>
            </div>
          )}
          {sugs.map((s, i) => (
            <button
              key={i}
              type="button"
              onMouseDown={() => submit(s.url || s.text)}
              className={`flex w-full items-center gap-3 px-3 py-2 text-left text-sm hover:bg-black/5 dark:hover:bg-white/10 ${i === sel ? "bg-black/5 dark:bg-white/10" : ""}`}
            >
              <Icon name={s.type === "search" ? "search" : s.type === "bookmark" ? "star" : "history"} size={15} className="shrink-0 text-slate-400" />
              <span className="min-w-0 flex-1 truncate">
                {s.title && s.title !== s.text ? <span>{s.title}</span> : <span>{s.text}</span>}
                {s.url && <span className="ml-2 text-xs text-slate-400">{hostOf(s.url)}</span>}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

type SpeechRecognitionLike = {
  lang: string;
  start: () => void;
  onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
};
