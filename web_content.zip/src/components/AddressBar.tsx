import React, { useState, useEffect, useRef } from 'react';
import { Shield, ShieldAlert, Lock, Flame, MoreVertical, X, Search, RotateCw } from 'lucide-react';
import { Tab } from '../types/browser';

interface AddressBarProps {
  currentTab: Tab;
  tabCount: number;
  onNavigate: (url: string) => void;
  onRefresh: () => void;
  onOpenShield: () => void;
  onOpenTabs: () => void;
  onOpenMenu: () => void;
  onTriggerFire: () => void;
}

export const AddressBar: React.FC<AddressBarProps> = ({
  currentTab,
  tabCount,
  onNavigate,
  onRefresh,
  onOpenShield,
  onOpenTabs,
  onOpenMenu,
  onTriggerFire,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isEditing) {
      setInputValue(currentTab.url);
    }
  }, [currentTab.url, isEditing]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onNavigate(inputValue.trim());
      setIsEditing(false);
    }
  };

  const startEditing = () => {
    setInputValue(currentTab.url === 'about:blank' || currentTab.url === 'aegis://home' ? '' : currentTab.url);
    setIsEditing(true);
    setTimeout(() => {
      inputRef.current?.select();
    }, 50);
  };

  const getCleanDomain = (url: string) => {
    if (!url || url === 'about:blank' || url === 'aegis://home') {
      return 'Search or type URL';
    }
    try {
      const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
      return parsed.hostname.replace(/^www\./, '');
    } catch {
      return url;
    }
  };

  const isHome = currentTab.url === 'about:blank' || currentTab.url === 'aegis://home';
  const totalBlocked = currentTab.trackersBlocked + currentTab.fingerprintsBlocked + currentTab.cookiesBlocked;

  return (
    <div className="relative w-full bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 px-3 py-2 z-30 shadow-2xl">
      {/* Top Loading Progress Line */}
      {currentTab.isLoading && (
        <div className="absolute top-0 left-0 right-0 h-0.5 bg-slate-800 overflow-hidden">
          <div className="h-full bg-emerald-400 animate-[loading_1.2s_ease-in-out_infinite] w-2/3" />
        </div>
      )}

      <div className="flex items-center gap-2">
        {/* URL Pill Container */}
        <div className="flex-1 min-w-0 flex items-center bg-slate-850 bg-slate-950/80 rounded-2xl border border-slate-750/80 hover:border-slate-600/80 transition-all shadow-inner px-2.5 py-1.5 focus-within:ring-2 focus-within:ring-emerald-500/50">
          {/* Shield Pill / Indicator */}
          <button
            id="address-shield-btn"
            type="button"
            onClick={onOpenShield}
            title="Aegis Privacy Shield"
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded-lg text-xs font-semibold transition-all active:scale-95 ${
              currentTab.shieldsEnabled
                ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/50 hover:bg-emerald-900/60'
                : 'bg-amber-950/80 text-amber-400 border border-amber-800/50'
            }`}
          >
            {currentTab.shieldsEnabled ? (
              <Shield className="w-3.5 h-3.5 fill-emerald-400/20 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="text-[11px] font-mono font-bold leading-none">{totalBlocked}</span>
          </button>

          {/* Form / URL Display */}
          {isEditing ? (
            <form onSubmit={handleSubmit} className="flex-1 flex items-center min-w-0 ml-2">
              <Search className="w-3.5 h-3.5 text-slate-400 mr-1.5 shrink-0" />
              <input
                ref={inputRef}
                type="text"
                id="omnibox-input"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onBlur={() => {
                  // slight delay to allow form submit button click if any
                  setTimeout(() => setIsEditing(false), 200);
                }}
                placeholder="Search DuckDuckGo or enter URL"
                className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none font-medium truncate"
                autoFocus
              />
              {inputValue && (
                <button
                  type="button"
                  onClick={() => setInputValue('')}
                  className="p-1 text-slate-400 hover:text-slate-200"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </form>
          ) : (
            <div
              onClick={startEditing}
              className="flex-1 flex items-center min-w-0 ml-2 cursor-pointer select-none"
            >
              {!isHome && (
                <Lock className="w-3 h-3 text-emerald-400/90 mr-1.5 shrink-0" />
              )}
              <span
                className={`text-sm truncate font-medium ${
                  isHome ? 'text-slate-400' : 'text-slate-200'
                }`}
              >
                {getCleanDomain(currentTab.url)}
              </span>
            </div>
          )}

          {/* Quick Refresh / Clear Action */}
          {!isEditing && !isHome && (
            <button
              id="address-refresh-btn"
              type="button"
              onClick={onRefresh}
              className="p-1 text-slate-400 hover:text-slate-200 rounded-md transition-colors active:rotate-180 duration-300 ml-1"
              title="Reload page"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* The Fire Button (Burner / Shredder) */}
        <button
          id="address-fire-btn"
          type="button"
          onClick={onTriggerFire}
          title="Burn all tabs and browsing traces"
          className="relative p-2 rounded-2xl bg-orange-950/40 hover:bg-orange-900/60 border border-orange-700/50 text-orange-400 active:scale-90 transition-transform flex items-center justify-center shadow-lg hover:shadow-orange-900/30"
          aria-label="Burn Data"
        >
          <Flame className="w-4 h-4 fill-orange-500/20 text-orange-400 animate-pulse" />
        </button>

        {/* Tab Count Switcher */}
        <button
          id="address-tabs-btn"
          type="button"
          onClick={onOpenTabs}
          title="Open tab switcher"
          className="relative w-8 h-8 rounded-xl border border-slate-700 hover:border-slate-500 bg-slate-800 text-slate-200 font-mono text-xs font-bold flex items-center justify-center active:scale-95 transition-all shadow-sm"
          aria-label="Tabs Switcher"
        >
          {tabCount}
        </button>

        {/* 3-Dots Android Menu */}
        <button
          id="address-menu-btn"
          type="button"
          onClick={onOpenMenu}
          title="Browser options"
          className="p-1.5 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors active:scale-95"
          aria-label="More options"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
