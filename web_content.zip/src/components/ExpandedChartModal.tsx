"use client";

import { useState } from "react";
import { X } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { multiTimeframeEngine } from "@/services/multiTimeframeEngine";
import CandleChart from "./CandleChart";
import { ALL_INTERVALS, FMT, Interval, SYMBOL_META } from "@/types";

export default function ExpandedChartModal() {
  const modal = useTradingStore((s) => s.chartModal);
  const setModal = useTradingStore((s) => s.setChartModal);
  const prices = useTradingStore((s) => s.prices);
  const mtf = useTradingStore((s) => s.mtf);
  const [interval, setIntervalV] = useState<Interval>("5m");

  if (!modal) return null;
  const { symbol } = modal;
  const candles = multiTimeframeEngine.getCandles(symbol, interval);
  const analysis = mtf[symbol]?.intervals[interval];

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm" onClick={() => setModal(null)}>
      <div
        className="slide-in w-full max-w-5xl rounded-2xl border border-slate-700 bg-slate-900 p-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex flex-wrap items-center gap-3">
          <span className="text-lg font-black" style={{ color: SYMBOL_META[symbol].color }}>
            {symbol.replace("USDT", "/USDT")}
          </span>
          <span className="num text-lg font-bold text-white">${FMT.price(prices[symbol])}</span>
          <div className="flex flex-wrap gap-1">
            {ALL_INTERVALS.map((iv) => (
              <button
                key={iv}
                onClick={() => setIntervalV(iv)}
                className={`rounded px-2 py-1 text-[11px] font-bold ${
                  interval === iv ? "bg-emerald-500 text-slate-950" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                {iv}
              </button>
            ))}
          </div>
          <button onClick={() => setModal(null)} className="mr-auto rounded-lg bg-slate-800 p-2 text-slate-400 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>

        <CandleChart candles={candles} height={380} livePrice={prices[symbol]} />

        {analysis && (
          <div className="mt-3 grid grid-cols-3 gap-2 text-center sm:grid-cols-6">
            {[
              ["RSI", analysis.rsi.toFixed(1)],
              ["EMA9", FMT.price(analysis.ema9)],
              ["EMA50", FMT.price(analysis.ema50)],
              ["VWAP", FMT.price(analysis.vwap)],
              ["ATR%", `${analysis.atrPct.toFixed(2)}%`],
              ["ADX", analysis.adx.toFixed(0)],
            ].map(([k, v]) => (
              <div key={k} className="rounded-lg bg-slate-800/70 px-2 py-1.5">
                <div className="text-[9px] text-slate-400">{k}</div>
                <div className="num text-xs font-bold text-white">{v}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
