import React, { useState } from 'react';
import { Copy, Check, Download, X, Code2 } from 'lucide-react';

interface ExportHtmlModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportHtmlModal: React.FC<ExportHtmlModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const standaloneHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DJ EVAN PRO UG - THE CUE KING | Kyebando Kawempe Kampala</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@700;900&display=swap'); body{font-family:'Outfit',sans-serif}</style>
</head>
<body class="bg-black text-white">

<!-- HERO WITH YOUR LOGO -->
<div class="text-center p-6 bg-gradient-to-br from-purple-700 via-fuchsia-600 to-cyan-500">
<img src="djlogo.jpg" onerror="this.src='https://via.placeholder.com/300?text=DJ+EVAN+PRO+UG'" class="w-64 h-64 mx-auto rounded-full border-4 border-white object-cover shadow-[0_0_50px_rgba(255,255,255,0.8)]">
<h1 class="text-4xl font-black mt-4">DJ EVAN PRO UG</h1>
<p class="text-2xl font-black text-yellow-200">THE CUE KING 👑 🇺🇬</p>
<p class="mt-2 font-bold">Kyebando, Kawempe | Kampala's #1 DJ</p>
<p class="text-xs mt-1 opacity-80">Parties | Weddings | Kwanjula & Kuhingira | Clubs | Phones & DJ Apps</p>
<div class="mt-5 flex flex-col gap-3 justify-center items-center">
<a href="https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20want%20to%20book%20you%20in%20Kyebando%20Kampala" class="bg-green-500 px-8 py-4 rounded-full font-black text-lg w-full max-w-xs text-center">💬 WhatsApp 0742094651</a>
<a href="https://tiktok.com/@djevanproug" target="_blank" class="bg-black px-8 py-3 rounded-full font-bold border border-white w-full max-w-xs text-center">🔴 TikTok LIVE 8PM @djevanproug</a>
</div>
</div>

<!-- SERVICES - REAL PRICES -->
<div class="p-4 max-w-4xl mx-auto">
<h2 class="text-2xl font-black mb-3">🎧 DJ BOOKING - Kyebando Base, All Kampala</h2>
<div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">🎂 Birthday Party</h3><p class="text-cyan-400 font-black text-xl">120K UGX</p><p class="text-[10px] text-zinc-500">3hrs + Setup</p></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">🎧 Night Club</h3><p class="text-cyan-400 font-black text-xl">150K UGX</p><p class="text-[10px] text-zinc-500">Per Night</p></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">💍 Kwanjula</h3><p class="text-pink-400 font-black text-xl">200K UGX</p><p class="text-[10px] text-zinc-500">Traditional Mix</p></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">💒 Wedding</h3><p class="text-purple-400 font-black text-xl">300K UGX</p><p class="text-[10px] text-zinc-500">Full Day</p></div>
</div>
</div>

<!-- DJ APPS & DROPS SHOP -->
<div class="p-4 max-w-4xl mx-auto">
<h2 class="text-2xl font-black mb-3">🛒 DJ APPS & DROPS SHOP</h2>
<div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
<div class="bg-white text-black p-4 rounded-2xl"><h3 class="font-bold text-sm">🎤 DJ Drops (2 Drops)</h3><p class="font-black text-lg">7K UGX</p><a href="https://wa.me/256742094651?text=I%20want%20DJ%20Drops%202%20for%207K" class="block bg-black text-white text-center py-2 rounded-full mt-2 text-xs font-black">BUY ON WHATSAPP</a></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">📱 CrossDJ Pro Apps</h3><p class="text-cyan-400 font-black text-lg">15K Each</p><a href="https://wa.me/256742094651?text=I%20want%20CrossDJ%20Pro%2015K" class="block bg-white text-black text-center py-2 rounded-full mt-2 text-xs font-black">BUY</a></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">🎧 Djay Apps Unlocked</h3><p class="text-cyan-400 font-black text-lg">10K UGX</p><a href="https://wa.me/256742094651?text=I%20want%20Djay%20Unlocked%2010K" class="block bg-white text-black text-center py-2 rounded-full mt-2 text-xs font-black">BUY</a></div>
<div class="bg-zinc-900 p-4 rounded-2xl border border-zinc-800"><h3 class="font-bold text-sm">💻 Virtual Softwares</h3><p class="text-cyan-400 font-black text-lg">20K UGX</p><a href="https://wa.me/256742094651?text=I%20want%20Virtual%20DJ%2020K" class="block bg-white text-black text-center py-2 rounded-full mt-2 text-xs font-black">BUY</a></div>
</div>
</div>

<!-- PHONES BUSINESS -->
<div class="p-4 max-w-4xl mx-auto">
<div class="bg-gradient-to-br from-yellow-400 to-orange-500 text-black rounded-3xl p-6">
<h2 class="text-xl font-black">📱 USED & NEW PHONES - Kyebando, Kawempe, Kampala</h2>
<p class="text-sm font-bold mt-1">We deal in used and unused phones. Tell us what you have and where you are, we come to you.</p>
<div class="mt-3 bg-black p-4 rounded-2xl">
<input id="phoneModel" placeholder="What phone do you have? e.g Tecno Spark, iPhone" class="w-full p-3 rounded-xl bg-zinc-800 text-white mb-2">
<input id="phonePlace" placeholder="Where are you? e.g Kyebando, Bwaise" class="w-full p-3 rounded-xl bg-zinc-800 text-white mb-2">
<button onclick="phoneSell()" class="w-full bg-yellow-400 py-3 rounded-full font-black text-black">SEND TO WHATSAPP</button>
</div>
</div>
</div>

<!-- BOOKING FORM -->
<div class="p-4 max-w-4xl mx-auto">
<h2 class="text-2xl font-black mb-3">📅 Book Now - Get Discount Today</h2>
<input id="name" placeholder="Your Name" class="w-full p-3 rounded-xl bg-zinc-800 mb-2 border border-zinc-700 text-white">
<select id="event" class="w-full p-3 rounded-xl bg-zinc-800 mb-2 border border-zinc-700 text-white">
<option>Birthday Party - 120K</option><option>Night Club - 150K</option><option>Kwanjula & Kuhingira - 200K</option><option>Wedding - 300K</option><option>DJ Drops - 7K</option><option>CrossDJ Pro - 15K</option><option>Djay App - 10K</option><option>Virtual DJ - 20K</option><option>Phone Business</option>
</select>
<input id="date" type="date" class="w-full p-3 rounded-xl bg-zinc-800 mb-2 border border-zinc-700 text-white">
<input id="place" placeholder="Location e.g Kyebando, Kawempe, Kampala" value="Kyebando, Kawempe, Kampala" class="w-full p-3 rounded-xl bg-zinc-800 mb-2 border border-zinc-700 text-white">
<button onclick="book()" class="w-full bg-gradient-to-r from-purple-600 to-cyan-500 py-4 rounded-full font-black text-xl mt-2 text-white">BOOK ON WHATSAPP 🚀</button>
</div>

<script>
function book(){
let n=document.getElementById('name').value||'Boss';
let e=document.getElementById('event').value;
let d=document.getElementById('date').value;
let p=document.getElementById('place').value;
let msg=\`Hello DJ EVAN PRO UG THE CUE KING 👑%0A%0AI am \${n}%0AEvent: \${e}%0ADate: \${d}%0ALocation: \${p} (Kyebando, Kawempe, Kampala)%0A%0AI want to buy/book. What is your last price?\`;
window.open(\`https://wa.me/256742094651?text=\${msg}\`);
}
function phoneSell(){
let m=document.getElementById('phoneModel').value;
let l=document.getElementById('phonePlace').value;
let msg=\`Hello Cue King, I have phone to sell/buy%0APhone: \${m}%0ALocation: \${l} - Kampala%0A%0AWhat is price?\`;
window.open(\`https://wa.me/256742094651?text=\${msg}\`);
}
</script>

<div class="p-6 text-center text-zinc-500 text-xs mt-6 border-t border-zinc-900 max-w-4xl mx-auto">
<p class="font-black text-white">DJ EVAN PRO UG - THE CUE KING 👑</p>
<p>📍 Kyebando, Kawempe - Kampala, Uganda | Available All Kampala, Wakiso, Mukono</p>
<p>📞 0742094651 | TikTok @djevanproug | WhatsApp 24/7</p>
</div>

<a href="https://wa.me/256742094651" class="fixed bottom-5 right-5 bg-green-500 w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-2xl">💬</a>
</body>
</html>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(standaloneHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const blob = new Blob([standaloneHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'djevanpro-kyebando.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-2 rounded-xl bg-zinc-900"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs font-mono font-bold text-yellow-300 uppercase tracking-widest mb-2">
          <Code2 className="w-4 h-4" />
          Single-File HTML Code
        </div>
        <h3 className="text-xl font-black text-white uppercase font-['Outfit']">
          DJ EVAN PRO UG — Kyebando Single File HTML
        </h3>
        <p className="text-xs text-zinc-300 mt-1 mb-4">
          Here is your exact standalone HTML file with Tailwind CDN, Kyebando base location, updated prices (120k, 150k, 200k, 300k), DJ drops shop (7k), and Used Phones trade-in.
        </p>

        <div className="bg-black rounded-xl p-3 border border-zinc-800 font-mono text-[11px] text-zinc-300 max-h-48 overflow-y-auto mb-4 select-all">
          <pre>{standaloneHtml}</pre>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleCopy}
            className="flex-1 py-3 rounded-full bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'HTML Copied to Clipboard!' : 'Copy Entire HTML'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex-1 py-3 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download .html File</span>
          </button>
        </div>
      </div>
    </div>
  );
};
