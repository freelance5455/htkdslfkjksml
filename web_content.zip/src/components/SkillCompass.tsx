import React, { useState } from 'react';
import { SKILL_QUIZ_QUESTIONS } from '../data/scriptData';
import {
  calculateSkillMatchScore,
  generateStudyPlan,
  StudyPlan,
} from '../utils/scriptUtils';
import {
  Compass,
  CheckCircle2,
  Calendar,
  Clock,
  Target,
  Sparkles,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';

export const SkillCompass: React.FC = () => {
  const [answers, setAnswers] = useState<Record<string, string>>({
    background: 'student',
    interest: 'automation',
    mathComfort: 'high',
    creativityPreference: 'logical',
  });

  const [dailyHours, setDailyHours] = useState<number>(2);
  const [completedMilestones, setCompletedMilestones] = useState<Record<string, boolean>>({});

  const handleSelectAnswer = (questionId: string, optionValue: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: optionValue }));
  };

  const matchResults = calculateSkillMatchScore(answers);
  const topMatch = matchResults[0];

  const studyPlan: StudyPlan = generateStudyPlan(topMatch.skillId, dailyHours, 'beginner');

  const toggleMilestone = (key: string) => {
    setCompletedMilestones((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-800/40 p-6 sm:p-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono mb-2">
          <Compass className="w-3.5 h-3.5 text-emerald-400" />
          ২০২৭ স্কিল ফাইন্ডার ও রুটিন প্ল্যানার
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-bengali">
          আপনার জন্য ২০২৭ সালের সেরা স্কিল কোনটি?
        </h1>
        <p className="mt-1 text-sm text-slate-300 font-bengali max-w-2xl">
          স্ক্রিপ্টের বার্তা অনুসারে: "একসাথে সব স্কিল শেখার দরকার নেই। এই ৫টি স্কিলের মধ্যে যেটা আপনার আগ্রহের সাথে সবচেয়ে বেশি মেলে, সেটা বেছে নিন এবং প্রতিদিন অন্তত ১-২ ঘণ্টা সময় দিন।"
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Assessment */}
        <div className="lg:col-span-6 space-y-5">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
            <h2 className="text-base font-bold text-white font-bengali pb-3 border-b border-slate-800">
              দ্রুত সেলফ-অ্যাসেসমেন্ট (৪টি প্রশ্ন):
            </h2>

            <div className="mt-4 space-y-5">
              {SKILL_QUIZ_QUESTIONS.map((q, idx) => (
                <div key={q.id} className="space-y-2">
                  <p className="text-xs sm:text-sm font-bold text-slate-200 font-bengali flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-mono flex items-center justify-center">
                      {idx + 1}
                    </span>
                    {q.questionBn}
                  </p>

                  <div className="space-y-1.5 pl-7">
                    {q.options.map((opt) => {
                      const isSelected = answers[q.id] === opt.value;
                      return (
                        <button
                          key={opt.value}
                          onClick={() => handleSelectAnswer(q.id, opt.value)}
                          className={`w-full p-2.5 rounded-xl text-left text-xs font-bengali transition cursor-pointer border ${
                            isSelected
                              ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-medium ring-1 ring-emerald-500/30'
                              : 'bg-slate-950/50 border-slate-800/80 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                                isSelected ? 'border-emerald-400 bg-emerald-500' : 'border-slate-600'
                              }`}
                            >
                              {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                            </div>
                            <span>{opt.labelBn}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* All 5 Skills Match Breakdown */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali mb-3">
              ৫টি স্কিলের সাথে আপনার আগ্রহের সামঞ্জস্য:
            </h3>

            <div className="space-y-2.5">
              {matchResults.map((result, idx) => (
                <div key={result.skillId} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bengali font-bold text-slate-200">
                      #{idx + 1} {result.titleBn}
                    </span>
                    <span className="font-mono font-bold text-emerald-400">
                      {result.matchPercent}% Match
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-800 mt-2 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                      style={{ width: `${result.matchPercent}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Tailored Recommendation & 1-2h Daily Routine */}
        <div className="lg:col-span-6 space-y-5">
          {/* Top Recommendation Box */}
          <div className="bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-900 rounded-2xl border border-emerald-500/50 p-6 shadow-2xl space-y-4">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-mono font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              আপনার জন্য এক নম্বর রিকমেন্ডেশন ({topMatch.matchPercent}% ম্যাচ)
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white font-bengali">
                {topMatch.titleBn}
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-300 font-bengali leading-relaxed">
                {topMatch.reasonBn}
              </p>
            </div>
          </div>

          {/* Daily 1-2 Hours Routine Generator */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <h3 className="text-base font-bold text-white font-bengali flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  প্রতিদিনের রুটিন ও ৮-সপ্তাহের অ্যাকশন প্ল্যান
                </h3>
                <span className="text-xs text-slate-400 font-bengali">
                  আপনার দৈনিক সময় নির্বাচন করুন:
                </span>
              </div>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                {[1, 2, 3].map((hr) => (
                  <button
                    key={hr}
                    onClick={() => setDailyHours(hr)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bengali transition cursor-pointer ${
                      dailyHours === hr
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {hr} ঘণ্টা/দিন
                  </button>
                ))}
              </div>
            </div>

            {/* Daily Schedule Breakdown */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-300 font-bengali block">
                দৈনিক {dailyHours} ঘণ্টার আদর্শ ভাগ (Time-boxing):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {studyPlan.dailySchedule.map((slot, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[11px] font-mono text-emerald-400 font-bold block">
                      {slot.timeSlot}
                    </span>
                    <p className="text-xs text-slate-300 font-bengali mt-1">
                      {slot.activity}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* 8-Week Roadmap with Milestone Checklists */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold text-slate-300 font-bengali block">
                ৮-সপ্তাহের প্রোগ্রেসিভ মাইলস্টোন ট্র্যাকার:
              </span>

              <div className="space-y-3">
                {studyPlan.phases.map((phase, pIdx) => (
                  <div key={pIdx} className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bengali font-bold text-xs sm:text-sm text-emerald-300">
                        {phase.phase}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {phase.weeklyHours}h/week
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 font-mono">
                      {phase.focus}
                    </p>

                    <div className="space-y-1.5 pt-1">
                      {phase.milestones.map((milestone, mIdx) => {
                        const key = `${pIdx}-${mIdx}`;
                        const isDone = completedMilestones[key];
                        return (
                          <button
                            key={mIdx}
                            onClick={() => toggleMilestone(key)}
                            className="w-full flex items-center gap-2.5 text-left text-xs font-bengali text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-slate-900 transition cursor-pointer"
                          >
                            <CheckCircle2
                              className={`w-4 h-4 flex-shrink-0 ${
                                isDone ? 'text-emerald-400 fill-emerald-500/20' : 'text-slate-600'
                              }`}
                            />
                            <span className={isDone ? 'line-through text-slate-500' : ''}>
                              {milestone}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
