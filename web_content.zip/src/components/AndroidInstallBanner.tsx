import React, { useState } from 'react';
import { Smartphone, Download, Check, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';
import { AndroidInstallModal } from './AndroidInstallModal';
import { triggerVibration } from '../utils/audioFeedback';

export const AndroidInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [showModal, setShowModal] = useState<boolean>(false);
  const [installing, setInstalling] = useState<boolean>(false);

  const handleDirectInstall = async (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerVibration(true, 'tap');
    if (isInstallable) {
      setInstalling(true);
      await install();
      setInstalling(false);
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <div 
        onClick={() => {
          triggerVibration(true, 'light');
          setShowModal(true);
        }}
        className="w-full mb-4 p-3 bg-gradient-to-r from-[#032319] via-[#053827] to-[#032319] border border-amber-500/40 rounded-2xl shadow-lg cursor-pointer hover:border-amber-400/70 transition-all group"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5 flex items-center justify-center shrink-0 shadow-md">
              <Smartphone className="w-5 h-5 text-[#042017]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-amber-300 font-cairo">
                  {isInstalled ? 'تطبيق أندرويد مثبت' : 'افتحه كتطبيق أندرويد على هاتفك'}
                </span>
                <span className="text-[9px] bg-amber-400/20 text-amber-200 border border-amber-400/30 px-1.5 py-0.2 rounded-full font-semibold">
                  Android
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/80">
                {isInstalled 
                  ? 'يعمل بملء الشاشة مع حفظ البيانات بدون إنترنت' 
                  : 'تثبيت فوري على شاشة الهاتف، ملء الشاشة، وبدون إنترنت'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isInstalled ? (
              <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-300 bg-emerald-900/60 px-2.5 py-1.5 rounded-xl border border-emerald-600/40">
                <Check className="w-3.5 h-3.5" />
                <span>مثبت</span>
              </span>
            ) : (
              <button
                onClick={handleDirectInstall}
                disabled={installing}
                className="flex items-center gap-1 text-xs font-bold text-[#042017] bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 px-3 py-1.5 rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
              >
                {isInstallable ? <Download className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{installing ? 'جارٍ...' : (isInstallable ? 'تثبيت' : 'تفاصيل')}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <AndroidInstallModal 
        isOpen={showModal} 
        onClose={() => setShowModal(false)} 
      />
    </>
  );
};
