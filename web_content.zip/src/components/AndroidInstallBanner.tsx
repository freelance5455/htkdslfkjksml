import React, { useState } from 'react';
import { Smartphone, Download, X, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { ThemeMode } from '../types/market';

interface AndroidInstallBannerProps {
  theme: ThemeMode;
  onOpenInstallModal: () => void;
}

export const AndroidInstallBanner: React.FC<AndroidInstallBannerProps> = ({
  theme,
  onOpenInstallModal,
}) => {
  const isLight = theme === 'light';
  const { isInstallable, isInstalled, install, triggerHaptic } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);

  // If already running standalone or user dismissed for this session, hide banner
  if (isInstalled || isDismissed) {
    return null;
  }

  const handleQuickInstall = async (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(20);
    if (isInstallable) {
      await install();
    } else {
      onOpenInstallModal();
    }
  };

  return (
    <div className={`border-b transition-all py-2.5 px-4 ${
      isLight 
        ? 'bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100 border-emerald-200 text-slate-800' 
        : 'bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/50 border-emerald-500/30 text-emerald-200'
    }`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs">
        
        {/* Left Info */}
        <div 
          onClick={onOpenInstallModal}
          className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity"
        >
          <div className="w-7 h-7 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 shadow-sm shadow-emerald-500/30">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold font-['Chakra_Petch'] tracking-tight">
                APPLICATION ANDROID OFFICIELLE
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                WebAPK
              </span>
            </div>
            <p className={`text-[11px] hidden sm:block ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
              Installez Trading Flow Alerts sur votre smartphone pour profiter des alertes plein écran et du vibreur haptique.
            </p>
          </div>
        </div>

        {/* Right CTA */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleQuickInstall}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Installer l'App</span>
          </button>

          <button
            onClick={() => setIsDismissed(true)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isLight ? 'hover:bg-slate-200 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
            }`}
            title="Masquer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
