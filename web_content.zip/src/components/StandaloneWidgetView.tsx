import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  MapPin,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Clock,
  ExternalLink,
  Layers,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { CalendarDay, LocationPreset, UserSettings, ZmanItem } from '../types';
import { calculateZmanim, UpcomingHolidayCountdown } from '../services/hebrewCalendarService';
import { getDailyVerseForDate } from '../services/dailyVerseService';

interface StandaloneWidgetViewProps {
  todayDay: CalendarDay;
  location: LocationPreset;
  nextZman: ZmanItem | null;
  nextHoliday?: UpcomingHolidayCountdown | null;
  settings: UserSettings;
  onOpenFullApp: () => void;
  onOpenSettings?: () => void;
}

export const StandaloneWidgetView: React.FC<StandaloneWidgetViewProps> = ({
  todayDay,
  location,
  nextZman,
  nextHoliday,
  settings,
  onOpenFullApp,
}) => {
  const [widgetSize, setWidgetSize] = useState<'small' | 'medium' | 'large'>('medium');
  const isRtl = settings.language === 'he';

  const zmanimData = calculateZmanim(todayDay.gregorianDate, location);
  const dailyVerse = getDailyVerseForDate(todayDay.gregorianDate);

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#D1D1D1] flex flex-col items-center justify-between p-4 sm:p-8 font-sans selection:bg-[#C5A267]/30 selection:text-white">
      {/* Top Bar */}
      <div className="w-full max-w-lg flex items-center justify-between py-2 border-b border-[#222222]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg overflow-hidden border border-[#C5A267]/40 bg-[#161616] shrink-0">
            <img
              src="/app-icon.jpg"
              alt="לוחות בה"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                const target = e.currentTarget;
                target.style.display = 'none';
                if (target.parentElement) {
                  target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold font-serif-hebrew text-xs">בה</div>';
                }
              }}
            />
          </div>
          <div>
            <h1 className="text-xs font-bold text-white leading-tight font-serif-hebrew">
              {isRtl ? 'לוחות בה • וידג׳ט' : 'Luchot BH Widget'}
            </h1>
            <p className="text-[10px] text-[#888888]">
              {isRtl ? location.nameHe || location.name : location.name}
            </p>
          </div>
        </div>

        <button
          onClick={onOpenFullApp}
          className="px-3 py-1.5 rounded-lg bg-[#1C1C1C] hover:bg-[#252525] border border-[#333333] text-xs font-semibold text-[#EAEAEA] flex items-center gap-1.5 transition-colors"
        >
          <span>{isRtl ? 'פתח לוח שנה מלא' : 'Open Full Calendar'}</span>
          {isRtl ? <ArrowLeft className="w-3.5 h-3.5 text-[#C5A267]" /> : <ArrowRight className="w-3.5 h-3.5 text-[#C5A267]" />}
        </button>
      </div>

      {/* Center Widget Canvas */}
      <div className="w-full max-w-lg flex flex-col items-center justify-center my-auto py-6">
        {/* Size selector buttons */}
        <div className="flex items-center gap-2 mb-6 bg-[#161616] p-1.5 rounded-xl border border-[#2A2A2A]">
          {(['small', 'medium', 'large'] as const).map((sz) => (
            <button
              key={sz}
              onClick={() => setWidgetSize(sz)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                widgetSize === sz
                  ? 'bg-[#C5A267] text-[#0F0F0F] font-bold shadow-xs'
                  : 'text-[#888888] hover:text-[#EAEAEA]'
              }`}
            >
              {sz === 'small'
                ? isRtl ? '2x2 קומפקטי' : '2x2 Compact'
                : sz === 'medium'
                ? isRtl ? '4x2 קלאסי' : '4x2 Classic'
                : isRtl ? '4x4 מורחב' : '4x4 Expanded'}
            </button>
          ))}
        </div>

        {/* 1. Small Widget (2x2) */}
        {widgetSize === 'small' && (
          <div className="w-72 bg-[#1A1A1A] rounded-[30px] p-5 border border-[#333333] shadow-2xl relative flex flex-col justify-between">
            <div className="flex justify-between items-start mb-3">
              <div className="w-8 h-8 rounded-xl overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                <img
                  src="/app-icon.jpg"
                  alt="לוחות בה"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    if (target.parentElement) {
                      target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold text-xs">בה</div>';
                    }
                  }}
                />
              </div>
              <div className="text-right">
                <p className="text-[11px] text-[#C5A267] font-bold uppercase tracking-wider">{isRtl ? location.nameHe || location.name : location.name.split(' ')[0]}</p>
                <p className="text-[9px] text-[#888888]">{location.country}</p>
              </div>
            </div>

            <div className="my-1">
              <p className="text-xl font-serif text-white font-bold" dir="rtl">{todayDay.hebrewDayLetters} {todayDay.hebrewMonthNameHe}</p>
              <p className="text-[11px] text-[#888888] mt-0.5">{todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</p>
            </div>

            <div className="mt-3 pt-2.5 border-t border-[#2A2A2A] space-y-2 text-xs">
              {nextHoliday && (
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-xs">🍯</span>
                    <span className="text-[11px] font-bold text-[#E5C287] font-serif-hebrew truncate" dir="rtl">{nextHoliday.nameHe}</span>
                  </div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#C5A267]/20 text-[#E5C287] font-bold shrink-0">
                    {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום' : 'Today') : `${nextHoliday.daysRemaining}d`}
                  </span>
                </div>
              )}

              {nextZman && (
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-xs">⏳</span>
                    <span className="text-[11px] font-bold text-[#C5A267] font-serif-hebrew truncate" dir="rtl">{nextZman.hebrewTitle}</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-white shrink-0">{nextZman.formattedTime}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 2. Medium Widget (4x2) */}
        {widgetSize === 'medium' && (
          <div className="w-full max-w-md bg-[#1A1A1A] rounded-[32px] p-6 border border-[#333333] shadow-2xl relative">
            <div className="flex justify-between items-start mb-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                <img
                  src="/app-icon.jpg"
                  alt="לוחות בה"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    if (target.parentElement) {
                      target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold text-sm">בה</div>';
                    }
                  }}
                />
              </div>
              <div className="text-right">
                <p className="text-xs text-[#C5A267] font-bold uppercase tracking-wider">{isRtl ? location.nameHe || location.name : location.name}</p>
                <p className="text-[10px] text-[#888888]">{location.country}</p>
              </div>
            </div>

            <p className="text-3xl font-serif text-white font-bold" dir="rtl">
              {todayDay.hebrewDayLetters} {todayDay.hebrewMonthNameHe} {todayDay.hebrewYearLetters}
            </p>
            <p className="text-xs text-[#888888] mt-1">
              {todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
                weekday: 'long',
                month: 'short',
                day: 'numeric',
              })}
            </p>

            <div className="mt-4 pt-3 border-t border-[#2A2A2A] space-y-2">
              {nextHoliday && (
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <span className="text-sm">🍯</span>
                    <div className="truncate">
                      <span className="text-[9px] text-[#888888] uppercase tracking-wider block">
                        {isRtl ? 'החג הקרוב' : 'UPCOMING HOLIDAY'}
                      </span>
                      <span className="text-xs font-bold text-[#E5C287] font-serif-hebrew" dir="rtl">
                        {nextHoliday.nameHe}
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-1 rounded bg-[#C5A267] text-[#0F0F0F] font-bold text-xs font-mono shrink-0">
                    {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום!' : 'Today!') : `${nextHoliday.daysRemaining} ${nextHoliday.daysRemaining === 1 ? (isRtl ? 'יום' : 'day') : (isRtl ? 'ימים' : 'days')}`}
                  </span>
                </div>
              )}

              {nextZman && (
                <div className="flex justify-between items-center text-xs pt-2 border-t border-[#252525]">
                  <div className="flex items-center gap-2 truncate">
                    <span className="text-sm">⏳</span>
                    <div className="truncate">
                      <span className="text-[9px] text-[#888888] uppercase tracking-wider block">
                        {isRtl ? 'הזמן הבא' : 'NEXT ZMAN'}
                      </span>
                      <span className="text-xs font-bold text-[#C5A267] font-serif-hebrew" dir="rtl">
                        {nextZman.hebrewTitle}
                      </span>
                    </div>
                  </div>
                  <span className="text-sm font-mono text-white font-bold shrink-0">
                    {nextZman.formattedTime}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. Large Widget (4x4) */}
        {widgetSize === 'large' && (
          <div className="w-full max-w-md bg-[#1A1A1A] rounded-[32px] p-6 border border-[#333333] shadow-2xl relative space-y-4">
            <div className="flex justify-between items-start">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                <img
                  src="/app-icon.jpg"
                  alt="לוחות בה"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    if (target.parentElement) {
                      target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold text-sm">בה</div>';
                    }
                  }}
                />
              </div>
              <div className="text-right">
                <p className="text-xs text-[#C5A267] font-bold uppercase">{isRtl ? location.nameHe || location.name : location.name}</p>
                <p className="text-[10px] text-[#888888] font-hebrew" dir="rtl">{todayDay.hebrewDateStrHe}</p>
              </div>
            </div>

            <div>
              <p className="text-3xl font-serif text-white font-bold" dir="rtl">
                {todayDay.hebrewDateStrHe}
              </p>
              <p className="text-xs text-[#888888] mt-1">
                {todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
                  weekday: 'long',
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#141414] border border-[#2A2A2A] space-y-2">
              {nextHoliday && (
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <span>🍯</span>
                    <span className="font-bold text-[#E5C287] font-serif-hebrew truncate" dir="rtl">{nextHoliday.nameHe}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#C5A267]/20 text-[#E5C287] font-bold text-[11px] font-mono shrink-0">
                    {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום' : 'Today') : `עוד ${nextHoliday.daysRemaining} ימים`}
                  </span>
                </div>
              )}

              {nextZman && (
                <div className="flex justify-between items-center text-xs pt-2 border-t border-[#222222]">
                  <div className="flex items-center gap-2 truncate">
                    <span>⏳</span>
                    <span className="font-bold text-[#C5A267] font-serif-hebrew truncate" dir="rtl">{nextZman.hebrewTitle}</span>
                  </div>
                  <span className="font-mono text-white font-bold shrink-0">{nextZman.formattedTime}</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-[#141414] border border-[#2A2A2A]">
                <span className="text-[10px] text-[#888888] font-bold uppercase">{isRtl ? 'הנץ החמה' : 'Sunrise (Netz)'}</span>
                <p className="text-sm font-mono text-[#EAEAEA] font-bold">
                  {zmanimData.items.find(z => z.id === 'sunrise')?.formattedTime}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-[#141414] border border-[#2A2A2A]">
                <span className="text-[10px] text-[#888888] font-bold uppercase">{isRtl ? 'שקיעת החמה' : 'Sunset (Shkiah)'}</span>
                <p className="text-sm font-mono text-[#EAEAEA] font-bold">
                  {zmanimData.items.find(z => z.id === 'sunset')?.formattedTime}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#141414] border border-[#2A2A2A] text-xs">
              <p className="text-xs font-serif text-[#C5A267] text-right font-bold" dir="rtl">
                {dailyVerse.hebrew}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom info */}
      <div className="w-full max-w-lg text-center text-[11px] text-[#666666] pt-4 border-t border-[#1C1C1C]">
        {isRtl
          ? 'לחיצה ארוכה על מסך הבית בטלפון -> יישומונים (Widgets) -> בחר Hebrew Calendar'
          : 'Long-press on your phone home screen -> Widgets -> Hebrew Calendar'}
      </div>
    </div>
  );
};
