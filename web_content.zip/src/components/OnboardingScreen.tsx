import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, ArrowRight, Check, Shield, Zap, Heart, TrendingUp, Clock } from 'lucide-react';
import { sound } from '../utils/sound';

export const OnboardingScreen: React.FC = () => {
  const { completeOnboarding, profile } = useApp();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [name, setName] = useState(profile.name || 'Alex');
  const [wakeTime, setWakeTime] = useState(profile.wakeTime || '07:00');
  const [selectedFocus, setSelectedFocus] = useState<string[]>([
    'Productivity',
    'Smart Budgeting',
    'Mindful Habits',
  ]);

  const toggleFocus = (item: string) => {
    sound.playClick();
    setSelectedFocus((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  const handleNext = () => {
    sound.playClick();
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    } else {
      completeOnboarding({
        name,
        wakeTime,
        focusAreas: selectedFocus,
      });
    }
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-6 bg-gradient-to-b from-indigo-50/70 via-white to-violet-50/50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950/30 transition-colors">
      {/* Top Branding */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-2xl overflow-hidden shadow-md shadow-indigo-500/20 bg-white p-0.5 border border-indigo-100 dark:border-indigo-900/50">
            <img
              src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
              alt="HiBuddy Logo"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="font-bold text-lg text-slate-900 dark:text-white tracking-tight">
              HiBuddy
            </span>
            <span className="text-[11px] text-indigo-600 dark:text-indigo-400 block font-medium">
              AI Life Copilot
            </span>
          </div>
        </div>

        {/* Step dots */}
        <div className="flex items-center gap-1.5">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full transition-all duration-300 ${
                s === step
                  ? 'w-6 bg-indigo-600 dark:bg-indigo-400'
                  : 'w-2 bg-slate-200 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Main Content by Step */}
      <div className="my-auto py-4">
        {step === 1 && (
          <div className="space-y-6">
            {/* Visual */}
            <div className="relative rounded-3xl overflow-hidden shadow-xl shadow-indigo-500/10 border border-indigo-100/80 dark:border-slate-800 aspect-[4/3] bg-indigo-900/5">
              <img
                src="/src/assets/images/hibuddy_onboarding_visual_1794042543662.jpg"
                alt="HiBuddy Life Assistant"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
                <span className="text-white text-xs font-medium tracking-wide uppercase bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                  Intelligent Personal Assistant
                </span>
              </div>
            </div>

            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-snug">
                Your life. Your goals. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-500">
                  Your buddy.
                </span>
              </h2>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                HiBuddy synchronizes your daily tasks, financial clarity, mindful habits, and personal memory into one seamless, peaceful flow.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
                <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-200">
                  Smart AI Scheduling
                </span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
                <TrendingUp className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-200">
                  Money & Budget
                </span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
                <Heart className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-200">
                  Habit Streaks
                </span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
                <Shield className="w-4 h-4 text-indigo-500 shrink-0" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-200">
                  Private Memory
                </span>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <div>
              <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 tracking-wider uppercase">
                Step 2 of 3
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tracking-tight">
                What matters most to you?
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                HiBuddy tailors your daily briefing and assistant suggestions based on your focus.
              </p>
            </div>

            <div className="space-y-2.5">
              {[
                {
                  id: 'Productivity',
                  title: 'Peak Productivity & Focus',
                  desc: 'Time blocking, task triage, and deep work scheduling',
                  icon: Zap,
                  color: 'text-amber-500',
                },
                {
                  id: 'Smart Budgeting',
                  title: 'Financial Peace & Tracking',
                  desc: 'Monitor spending, stay under budget, and grow savings',
                  icon: TrendingUp,
                  color: 'text-emerald-500',
                },
                {
                  id: 'Mindful Habits',
                  title: 'Daily Habits & Energy',
                  desc: 'Hydration, workouts, meditation, and healthy sleep',
                  icon: Heart,
                  color: 'text-rose-500',
                },
                {
                  id: 'Life Balance',
                  title: 'Life Balance & Organization',
                  desc: 'Never forget family dates, errands, or important ideas',
                  icon: Sparkles,
                  color: 'text-violet-500',
                },
              ].map((item) => {
                const isSelected = selectedFocus.includes(item.id);
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => toggleFocus(item.id)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-400 dark:border-indigo-600 shadow-sm'
                        : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div
                      className={`p-2.5 rounded-xl mt-0.5 ${
                        isSelected
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-slate-900 dark:text-white">
                          {item.title}
                        </span>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-indigo-600 flex items-center justify-center text-white">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        {item.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div>
              <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 tracking-wider uppercase">
                Step 3 of 3
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tracking-tight">
                Let's set your rhythm
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Your Buddy will prepare your personalized morning brief right on time.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  What should HiBuddy call you?
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your preferred name"
                  className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  What time do you usually begin your day?
                </label>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <Clock className="w-5 h-5 text-indigo-500" />
                  <input
                    type="time"
                    value={wakeTime}
                    onChange={(e) => setWakeTime(e.target.value)}
                    className="bg-transparent text-sm font-semibold text-slate-900 dark:text-white focus:outline-none"
                  />
                  <span className="text-xs text-slate-400 ml-auto">Morning Briefing time</span>
                </div>
              </div>

              {/* Ready summary preview */}
              <div className="p-4 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border border-white dark:border-slate-700 shadow-sm">
                  <img
                    src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                    alt="HiBuddy"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-xs text-slate-700 dark:text-slate-200">
                  <p className="font-semibold text-indigo-950 dark:text-indigo-300">
                    "Awesome to meet you, {name}!"
                  </p>
                  <p className="mt-0.5 text-slate-600 dark:text-slate-400">
                    Your personal workspace is configured and ready.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom CTA & Skip */}
      <div className="pt-4 space-y-2">
        <button
          onClick={handleNext}
          className="w-full h-13 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 hover:shadow-indigo-600/35 active:scale-[0.98] transition-all cursor-pointer"
        >
          <span>{step === 3 ? 'Launch My Assistant' : 'Continue'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1 pt-1">
          {step > 1 ? (
            <button
              onClick={() => {
                sound.playClick();
                setStep((s) => (s - 1) as any);
              }}
              className="hover:text-slate-900 dark:hover:text-white"
            >
              Back
            </button>
          ) : (
            <span>Private & encrypted</span>
          )}
          <button
            onClick={() => completeOnboarding()}
            className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline"
          >
            Quick Explore Demo
          </button>
        </div>
      </div>
    </div>
  );
};
