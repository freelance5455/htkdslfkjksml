import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, PhoneCall, User, X, Volume2, Mic, MicOff, Delete } from 'lucide-react';

interface CallDialerModalProps {
  onClose: () => void;
  initialContact?: string;
}

const PRESET_CONTACTS = [
  { name: 'Lead Brand Designer', number: '+1 (555) 234-5678', avatar: '🎨' },
  { name: 'Creative Director', number: '+1 (555) 876-5432', avatar: '👔' },
  { name: 'Marketing & PR Agency', number: '+1 (555) 345-6789', avatar: '📢' },
  { name: 'Customer Support', number: '+1 (800) 123-4567', avatar: '🎧' },
];

export const CallDialerModal: React.FC<CallDialerModalProps> = ({ onClose, initialContact }) => {
  const [phoneNumber, setPhoneNumber] = useState(initialContact || '');
  const [callState, setCallState] = useState<'idle' | 'calling' | 'connected'>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (callState === 'calling') {
      timer = setTimeout(() => {
        setCallState('connected');
      }, 2000);
    } else if (callState === 'connected') {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      clearTimeout(timer);
      clearInterval(timer);
    };
  }, [callState]);

  const startCall = (num?: string) => {
    const target = num || phoneNumber;
    if (!target) return;
    setPhoneNumber(target);
    setCallState('calling');
    setCallDuration(0);
  };

  const endCall = () => {
    setCallState('idle');
    setCallDuration(0);
  };

  const appendDigit = (digit: string) => {
    setPhoneNumber((prev) => prev + digit);
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full max-w-sm shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Phone Dialer & Calling</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Call View: Idle vs Active Call */}
        {callState !== 'idle' ? (
          <div className="p-8 flex flex-col items-center justify-center text-center space-y-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-slate-900 border-2 border-emerald-500/50 flex items-center justify-center text-4xl shadow-2xl animate-pulse">
                👤
              </div>
              <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-950 flex items-center justify-center text-[10px] text-white">
                ✓
              </span>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white">{phoneNumber}</h4>
              <p className="text-xs text-emerald-400 font-semibold mt-1">
                {callState === 'calling' ? 'Calling...' : `Connected (${formatDuration(callDuration)})`}
              </p>
            </div>

            {/* In-call controls */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3 rounded-full border ${
                  isMuted ? 'bg-amber-600 text-white border-amber-400' : 'bg-slate-900 text-slate-300 border-slate-800'
                }`}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
              <button
                onClick={endCall}
                className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/30"
                title="End Call"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
              <button
                onClick={() => window.open(`tel:${phoneNumber}`, '_self')}
                className="p-3 rounded-full bg-slate-900 text-slate-300 border border-slate-800"
                title="Open Native Phone App"
              >
                <PhoneCall className="w-5 h-5 text-emerald-400" />
              </button>
            </div>
          </div>
        ) : (
          <div className="p-5 space-y-4">
            {/* Number display */}
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-center flex items-center justify-between">
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="Enter phone number..."
                className="w-full bg-transparent text-center text-lg font-mono text-white focus:outline-none"
              />
              {phoneNumber && (
                <button
                  onClick={() => setPhoneNumber((p) => p.slice(0, -1))}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <Delete className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Dialpad Keys */}
            <div className="grid grid-cols-3 gap-2 text-center">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((k) => (
                <button
                  key={k}
                  onClick={() => appendDigit(k)}
                  className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base transition-colors"
                >
                  {k}
                </button>
              ))}
            </div>

            {/* Call button */}
            <div className="flex justify-center pt-2">
              <button
                onClick={() => startCall()}
                disabled={!phoneNumber}
                className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 disabled:opacity-40 transition-all"
              >
                <Phone className="w-6 h-6" />
              </button>
            </div>

            {/* Quick Contacts */}
            <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
              <span className="text-[10px] text-slate-400 font-semibold block uppercase">Quick Contacts:</span>
              <div className="grid grid-cols-2 gap-1.5">
                {PRESET_CONTACTS.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => startCall(c.number)}
                    className="p-2 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-left border border-slate-800 text-[11px] truncate flex items-center gap-1.5"
                  >
                    <span>{c.avatar}</span>
                    <span className="truncate text-slate-200">{c.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
