import React, { useState } from 'react';
import { SubjectCategory, Topic, Flashcard } from '../types';
import { Layers, Play, Plus, BookOpen, Search, CheckCircle2 } from 'lucide-react';
import { getMasteryTier } from '../utils/spacedRepetition';

interface FlashcardsDeckViewProps {
  topics: Topic[];
  categories: SubjectCategory[];
  onStartReviewSession: (topic: Topic) => void;
  onManageFlashcards: (topic: Topic) => void;
  onOpenAddTopic: () => void;
  onOpenCategoryManager?: () => void;
}

export const FlashcardsDeckView: React.FC<FlashcardsDeckViewProps> = ({
  topics,
  categories,
  onStartReviewSession,
  onManageFlashcards,
  onOpenAddTopic,
  onOpenCategoryManager,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTopics = topics.filter((t) => {
    const matchesCat = selectedCategory === 'all' || t.categoryId === selectedCategory;
    const matchesSearch =
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.notes.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const totalCardsCount = topics.reduce((acc, t) => acc + (t.flashcards?.length || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header & Stats bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Active Recall Flashcard Decks
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Test yourself with 3D interactive flashcards to trigger synaptic reconsolidation.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-3 py-1.5 rounded-lg shrink-0">
          <Layers className="w-4 h-4 text-indigo-500" />
          <span>{totalCardsCount} Flashcards Total</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Segmented Control */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs font-medium">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              selectedCategory === 'all'
                ? 'bg-slate-900 dark:bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            All Subjects
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-slate-900 dark:bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
              <span>{cat.name}</span>
            </button>
          ))}

          {onOpenCategoryManager && (
            <button
              type="button"
              onClick={onOpenCategoryManager}
              className="px-2.5 py-1.5 rounded-lg text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-xs font-medium whitespace-nowrap transition-colors"
            >
              + Add Subject
            </button>
          )}
        </div>

        {/* Search input */}
        <div className="relative min-w-[200px]">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search decks..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Topics / Decks Grid */}
      {filteredTopics.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
          <Layers className="w-10 h-10 text-slate-400 mx-auto" />
          <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No matching flashcard decks found
          </div>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search criteria or create a new topic with active flashcards.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTopics.map((topic) => {
            const cat = categories.find((c) => c.id === topic.categoryId);
            const cardCount = topic.flashcards?.length || 0;
            const tier = getMasteryTier(topic.masteryScore);

            return (
              <div
                key={topic.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1.5 font-medium">
                      {cat && (
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: cat.color }}
                        />
                      )}
                      <span>{cat?.name || 'General'}</span>
                    </span>
                    <span className="font-mono text-[11px] font-semibold text-indigo-600 dark:text-indigo-400">
                      {cardCount} {cardCount === 1 ? 'card' : 'cards'}
                    </span>
                  </div>

                  <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 line-clamp-1">
                    {topic.title}
                  </h3>

                  {topic.notes && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                      {topic.notes}
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => onManageFlashcards(topic)}
                    className="text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors py-1 px-1"
                  >
                    Manage Cards ({cardCount})
                  </button>

                  <button
                    type="button"
                    onClick={() => onStartReviewSession(topic)}
                    disabled={cardCount === 0}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Practice Deck</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
