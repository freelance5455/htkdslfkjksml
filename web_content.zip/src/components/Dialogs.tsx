import { useEffect, useState, type ReactNode } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowUpRight, CheckCircle2, Clipboard, Copy, ExternalLink, Eye, EyeOff,
  Gauge, Heart, Info, LoaderCircle, Plus, Radio, RefreshCw, Send, Server, Settings2,
  ShieldCheck, Trash2, X, XCircle,
} from "lucide-react";
import { PROXY_SOURCES, COUNTRY_NAMES } from "../data/sources";
import { formatFullDate, relativeTime, telegramDeepLink, telegramWebLink, typeLabel } from "../lib/proxy";
import type { AppSettings, ProxyRecord, SourceState } from "../types";

interface DialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow?: string;
  children: ReactNode;
  wide?: boolean;
}

export function Dialog({ open, onClose, title, eyebrow, children, wide }: DialogProps) {
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[100] flex items-end justify-center p-0 sm:items-center sm:p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.button aria-label="Закрыть окно" onClick={onClose} className="absolute inset-0 bg-[#07100d]/65 backdrop-blur-md" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />
          <motion.section
            role="dialog"
            aria-modal="true"
            aria-label={title}
            initial={reduced ? { opacity: 0 } : { opacity: 0, y: 45, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduced ? { opacity: 0 } : { opacity: 0, y: 30, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className={`relative max-h-[92svh] w-full overflow-y-auto rounded-t-[28px] border border-white/10 bg-[#f6f7f3] text-ink shadow-2xl sm:rounded-[28px] ${wide ? "sm:max-w-[760px]" : "sm:max-w-[540px]"}`}
          >
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-ink/[0.07] bg-[#f6f7f3]/95 px-5 py-5 backdrop-blur-xl sm:px-7">
              <div>{eyebrow && <div className="mb-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-ink/35">{eyebrow}</div>}<h2 className="font-display text-2xl font-semibold tracking-[-0.04em]">{title}</h2></div>
              <button onClick={onClose} className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-ink/10 text-ink/45 transition-colors hover:bg-ink hover:text-white" aria-label="Закрыть"><X size={17} /></button>
            </div>
            {children}
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function ConnectDialog({ proxy, onClose, onCopy, onLinkOpened }: {
  proxy: ProxyRecord | null;
  onClose: () => void;
  onCopy: (text: string, label: string) => void;
  onLinkOpened: () => void;
}) {
  return (
    <Dialog open={Boolean(proxy)} onClose={onClose} title="Добавить в Telegram" eyebrow="Подключение в один клик">
      {proxy && <div className="p-5 sm:p-7">
        <div className="rounded-2xl border border-ink/[0.08] bg-white p-5">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#e9f5e1] text-[#467c3c]"><Server size={20} /></span>
            <div className="min-w-0"><div className="truncate font-mono text-sm font-semibold">{proxy.server}</div><div className="mt-1 text-xs text-ink/40">Порт {proxy.port} · {typeLabel(proxy.type)}</div></div>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 border-t border-ink/[0.07] pt-4 text-xs">
            <div><span className="text-ink/35">RTT источника</span><div className="mt-1 font-semibold">{proxy.latency !== null ? `${proxy.latency} мс` : "Нет данных"}</div></div>
            <div><span className="text-ink/35">Оценка маршрута</span><div className="mt-1 font-semibold">{proxy.score} / 100</div></div>
          </div>
        </div>

        <ol className="my-6 space-y-3">
          {["Откройте Telegram по кнопке ниже.", "В карточке прокси нажмите «Подключить».", "При необходимости включите «Использовать прокси»."].map((step, index) => (
            <li key={step} className="flex items-center gap-3 text-xs leading-5 text-ink/60"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-ink font-mono text-[10px] text-white">{index + 1}</span>{step}</li>
          ))}
        </ol>

        <a href={telegramDeepLink(proxy)} onClick={onLinkOpened} className="group flex h-14 w-full items-center justify-center gap-3 rounded-full bg-[#279bd5] text-sm font-bold text-white transition-all hover:bg-[#208dc4] hover:shadow-[0_10px_35px_rgba(39,155,213,.22)]">
          <Send size={18} /> Открыть Telegram <ArrowUpRight size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </a>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <a href={telegramWebLink(proxy)} target="_blank" rel="noreferrer" onClick={onLinkOpened} className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-ink/10 text-[11px] font-semibold text-ink/65 hover:bg-white">Через t.me <ExternalLink size={13} /></a>
          <button onClick={() => onCopy(telegramWebLink(proxy), "Ссылка на прокси скопирована")} className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-ink/10 text-[11px] font-semibold text-ink/65 hover:bg-white"><Copy size={13} /> Копировать ссылку</button>
        </div>
        <p className="mt-5 flex gap-2 text-[10px] leading-4 text-ink/40"><Info size={14} className="mt-0.5 shrink-0" />Если приложение не открылось, установите Telegram или скопируйте ссылку в любой чат и нажмите на неё. Браузер не может подтвердить, включили ли вы прокси в приложении.</p>
      </div>}
    </Dialog>
  );
}

export function AddProxyDialog({ open, onClose, onAdd }: {
  open: boolean;
  onClose: () => void;
  onAdd: (value: string) => { ok: true; proxy: ProxyRecord; duplicate: boolean } | { ok: false; error: string };
}) {
  const [value, setValue] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { if (open) { setValue(""); setError(""); } }, [open]);
  const submit = () => {
    const result = onAdd(value);
    if (!result.ok) setError(result.error);
    else onClose();
  };
  return (
    <Dialog open={open} onClose={onClose} title="Свой MTProto-прокси" eyebrow="Ручное добавление">
      <div className="p-5 sm:p-7">
        <label className="text-[11px] font-semibold text-ink/55" htmlFor="proxy-input">Ссылка или server:port:secret</label>
        <textarea id="proxy-input" value={value} onChange={(event) => { setValue(event.target.value); setError(""); }} onKeyDown={(event) => { if ((event.metaKey || event.ctrlKey) && event.key === "Enter") submit(); }} placeholder="https://t.me/proxy?server=…&port=443&secret=…" rows={4} className="mt-2 w-full resize-none rounded-2xl border border-ink/10 bg-white p-4 font-mono text-xs leading-5 outline-none transition-colors placeholder:text-ink/25 focus:border-[#72a85b] focus:ring-4 focus:ring-[#c0ff72]/15" />
        {error && <div className="mt-2 flex items-center gap-2 text-xs text-[#a64e45]"><XCircle size={14} />{error}</div>}
        <div className="mt-4 rounded-xl bg-ink/[0.035] p-4 text-[11px] leading-5 text-ink/45">Поддерживаются ссылки <span className="font-mono text-ink/65">tg://proxy</span>, <span className="font-mono text-ink/65">t.me/proxy</span> и строка <span className="font-mono text-ink/65">host:port:secret</span>. Запись сохранится только в вашем браузере и будет отмечена как непроверенная.</div>
        <button onClick={submit} disabled={!value.trim()} className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-ink text-sm font-bold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-30"><Plus size={16} />Добавить в каталог</button>
      </div>
    </Dialog>
  );
}

export function DetailsDialog({ proxy, onClose, onConnect, onCopy, onFavorite, favorite, onCheck, onRemove }: {
  proxy: ProxyRecord | null;
  onClose: () => void;
  onConnect: () => void;
  onCopy: (text: string, label: string) => void;
  onFavorite: () => void;
  favorite: boolean;
  onCheck: () => void;
  onRemove: () => void;
}) {
  const [showSecret, setShowSecret] = useState(false);
  useEffect(() => setShowSecret(false), [proxy?.id]);
  const sources = proxy ? PROXY_SOURCES.filter((source) => proxy.sourceIds.includes(source.id)) : [];
  return (
    <Dialog open={Boolean(proxy)} onClose={onClose} title="Паспорт маршрута" eyebrow="Технические данные" wide>
      {proxy && <div className="p-5 sm:p-7">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0"><div className="break-all font-mono text-lg font-semibold sm:text-xl">{proxy.server}<span className="text-ink/30">:{proxy.port}</span></div><div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-ink/45"><span className="rounded-md bg-[#e8f5df] px-2 py-1 font-semibold text-[#477c3b]">{typeLabel(proxy.type)}</span><span>{proxy.country ? `${proxy.country} · ${COUNTRY_NAMES[proxy.country] ?? ""}` : "Страна не указана"}</span></div></div>
          <div className="flex shrink-0 items-center gap-2"><button onClick={onFavorite} className={`inline-flex h-10 items-center gap-2 rounded-full border px-4 text-[11px] font-semibold ${favorite ? "border-[#b6d5a5] bg-[#eaf5e2] text-[#477c3b]" : "border-ink/10 text-ink/55"}`}><Heart size={14} fill={favorite ? "currentColor" : "none"} />{favorite ? "В избранном" : "В избранное"}</button>{proxy.isManual && <button onClick={onRemove} className="grid h-10 w-10 place-items-center rounded-full border border-[#d9aaa3] text-[#a64e45]" aria-label="Удалить свой прокси"><Trash2 size={15} /></button>}</div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-ink/[0.08] bg-ink/[0.08] sm:grid-cols-4">
          {[
            { label: `RTT · ${proxy.latencyFrom ?? "источника"}`, value: proxy.latency !== null ? `${proxy.latency} мс` : "—", icon: Gauge },
            { label: "Uptime", value: proxy.uptime !== null ? `${proxy.uptime.toFixed(proxy.uptime < 99 ? 1 : 0)}%` : "—", icon: CheckCircle2 },
            { label: "Оценка", value: `${proxy.score}/100`, icon: Radio },
            { label: "Подтверждения", value: String(proxy.sourceIds.filter((id) => id !== "manual").length), icon: ShieldCheck },
          ].map((item) => <div key={item.label} className="bg-white p-4"><item.icon size={15} className="text-ink/30" /><div className="mt-4 font-display text-xl font-semibold">{item.value}</div><div className="mt-1 text-[9px] uppercase tracking-wider text-ink/35">{item.label}</div></div>)}
        </div>

        <div className="mt-5 space-y-px overflow-hidden rounded-2xl border border-ink/[0.08] bg-white">
          <div className="flex items-center justify-between gap-4 border-b border-ink/[0.06] p-4"><span className="text-[11px] text-ink/40">Секрет</span><div className="flex min-w-0 items-center gap-2"><code className="max-w-[170px] truncate font-mono text-[10px] text-ink/65 sm:max-w-[330px]">{showSecret ? proxy.secret : "•".repeat(32)}</code><button onClick={() => setShowSecret((value) => !value)} className="text-ink/35 hover:text-ink" aria-label={showSecret ? "Скрыть секрет" : "Показать секрет"}>{showSecret ? <EyeOff size={15} /> : <Eye size={15} />}</button><button onClick={() => onCopy(proxy.secret, "Секрет скопирован")} className="text-ink/35 hover:text-ink" aria-label="Копировать секрет"><Copy size={14} /></button></div></div>
          {[
            ["IP после DNS", proxy.ip ?? "Не указан источником"],
            ["Провайдер / AS", proxy.provider ?? "Не указан источником"],
            ["Fake-TLS домен", proxy.fakeTlsDomain ?? "Не задан или не распознан"],
            ["Проверка источника", proxy.lastChecked ? formatFullDate(proxy.lastChecked) : "Нет — ручная запись"],
            ["Доступен из регионов", proxy.reachableFrom.length ? proxy.reachableFrom.join(", ") : "Нет региональных данных"],
          ].map(([label, value]) => <div key={label} className="flex items-start justify-between gap-4 border-b border-ink/[0.06] p-4 last:border-0"><span className="shrink-0 text-[11px] text-ink/40">{label}</span><span className="break-all text-right font-mono text-[10px] leading-4 text-ink/65">{value}</span></div>)}
        </div>

        {proxy.live && <div className={`mt-4 rounded-xl border p-4 text-[11px] ${proxy.live.state === "online" ? "border-[#b8d9c4] bg-[#edf7f0] text-[#347052]" : proxy.live.state === "checking" ? "border-ink/10 bg-white text-ink/50" : "border-[#e2bcb6] bg-[#fff3f1] text-[#9c4e45]"}`}><div className="flex items-center gap-2 font-semibold">{proxy.live.state === "checking" ? <LoaderCircle size={14} className="animate-spin" /> : proxy.live.state === "online" ? <CheckCircle2 size={14} /> : <XCircle size={14} />}{proxy.live.state === "online" ? `Checker подтвердил доступность${proxy.live.latency !== null ? ` · ${proxy.live.latency} мс` : ""}` : proxy.live.state === "offline" ? "Checker сообщил: прокси недоступен" : proxy.live.state === "checking" ? "Выполняется проверка" : "Проверка не выполнена"}</div>{proxy.live.message && <p className="mt-1.5 leading-4 opacity-75">{proxy.live.message}</p>}<div className="mt-1.5 opacity-55">{relativeTime(proxy.live.checkedAt)} · результат вашего checker API</div></div>}

        <div className="mt-5"><div className="mb-3 text-[9px] font-bold uppercase tracking-[0.16em] text-ink/35">Независимые источники</div><div className="flex flex-wrap gap-2">{sources.length ? sources.map((source) => <a key={source.id} href={source.homepage} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-ink/10 bg-white px-3 py-2 text-[10px] font-semibold text-ink/55 hover:border-ink/25">{source.shortName}<ExternalLink size={11} /></a>) : <span className="text-xs text-ink/40">Ручная запись — внешняя проверка ещё не выполнялась.</span>}</div></div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <button onClick={onConnect} className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-ink text-xs font-bold text-white"><Send size={15} />Подключить в Telegram</button>
          <button onClick={() => onCopy(`${proxy.server}:${proxy.port}:${proxy.secret}`, "Конфигурация скопирована")} className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-ink/10 px-5 text-xs font-semibold text-ink/60"><Clipboard size={15} />Конфигурация</button>
          <button onClick={onCheck} disabled={proxy.live?.state === "checking"} className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-ink/10 px-5 text-xs font-semibold text-ink/60 disabled:opacity-50"><RefreshCw size={14} className={proxy.live?.state === "checking" ? "animate-spin" : ""} />Проверить</button>
        </div>
      </div>}
    </Dialog>
  );
}

export function SettingsDialog({ open, onClose, settings, setSettings, states, onRefresh, isRefreshing }: {
  open: boolean;
  onClose: () => void;
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  states: Record<string, SourceState>;
  onRefresh: () => void;
  isRefreshing: boolean;
}) {
  const toggleSource = (id: string) => setSettings((previous) => ({
    ...previous,
    enabledSources: previous.enabledSources.includes(id) ? previous.enabledSources.filter((item) => item !== id) : [...previous.enabledSources, id],
  }));
  return (
    <Dialog open={open} onClose={onClose} title="Источники и проверка" eyebrow="Настройки" wide>
      <div className="p-5 sm:p-7">
        <div className="flex items-center justify-between"><div><h3 className="text-sm font-semibold">Каталоги прокси</h3><p className="mt-1 text-[11px] text-ink/40">Изменения применяются и сохраняются сразу.</p></div><button onClick={onRefresh} disabled={isRefreshing || !settings.enabledSources.length} className="inline-flex h-9 items-center gap-2 rounded-full border border-ink/10 px-3 text-[10px] font-semibold disabled:opacity-40"><RefreshCw size={13} className={isRefreshing ? "animate-spin" : ""} />Обновить</button></div>
        <div className="mt-4 space-y-2">
          {PROXY_SOURCES.map((source) => {
            const enabled = settings.enabledSources.includes(source.id);
            const state = states[source.id];
            return <div key={source.id} className={`rounded-2xl border p-4 transition-colors ${enabled ? "border-ink/10 bg-white" : "border-ink/[0.06] bg-transparent opacity-55"}`}>
              <div className="flex items-start gap-3"><button role="switch" aria-checked={enabled} onClick={() => toggleSource(source.id)} className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors ${enabled ? "bg-ink" : "bg-ink/15"}`}><span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${enabled ? "translate-x-6" : "translate-x-1"}`} /></button><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><a href={source.homepage} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold hover:underline">{source.name}<ExternalLink size={11} /></a>{state && <span className={`rounded-full px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider ${state.status === "success" ? "bg-[#e7f4e9] text-[#3b7c51]" : state.status === "error" ? "bg-[#fff0ed] text-[#a04b42]" : "bg-ink/[0.05] text-ink/40"}`}>{state.status === "loading" ? "Загрузка" : state.status === "success" ? `${state.count} записей` : state.status === "cached" ? "Кэш" : state.status === "error" ? "Ошибка" : "Не загружен"}</span>}</div><p className="mt-1.5 text-[10px] leading-4 text-ink/45">{source.description}</p><div className="mt-2 text-[9px] text-ink/30">{source.refresh} · {source.location}{state?.updated ? ` · данные ${relativeTime(state.updated)}` : ""}</div>{state?.message && <div className="mt-2 text-[10px] text-[#a45b50]">{state.message}</div>}</div></div>
            </div>;
          })}
        </div>

        <div className="mt-7 border-t border-ink/[0.08] pt-6"><h3 className="text-sm font-semibold">Автообновление</h3><div className="mt-3 flex items-center justify-between gap-4 rounded-2xl bg-white p-4"><div><div className="text-xs font-medium">Обновлять в фоне</div><div className="mt-1 text-[10px] text-ink/40">Только пока страница открыта.</div></div><button role="switch" aria-checked={settings.autoRefresh} onClick={() => setSettings((previous) => ({ ...previous, autoRefresh: !previous.autoRefresh }))} className={`relative h-6 w-11 rounded-full ${settings.autoRefresh ? "bg-ink" : "bg-ink/15"}`}><span className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${settings.autoRefresh ? "translate-x-6" : "translate-x-1"}`} /></button></div><label className="mt-3 flex items-center justify-between gap-4 text-xs text-ink/55">Интервал<select value={settings.refreshMinutes} onChange={(event) => setSettings((previous) => ({ ...previous, refreshMinutes: Number(event.target.value) }))} disabled={!settings.autoRefresh} className="rounded-xl border border-ink/10 bg-white px-3 py-2 text-xs outline-none disabled:opacity-40"><option value={15}>15 минут</option><option value={30}>30 минут</option><option value={60}>60 минут</option><option value={120}>2 часа</option></select></label></div>

        <div className="mt-7 border-t border-ink/[0.08] pt-6"><div className="flex items-center gap-2"><Settings2 size={16} /><h3 className="text-sm font-semibold">Свой checker API <span className="font-normal text-ink/30">(необязательно)</span></h3></div><p className="mt-2 text-[10px] leading-5 text-ink/45">Браузер не может сам выполнить MTProto TCP-handshake. Укажите HTTPS-endpoint вашего сервера, чтобы кнопки «Проверить» делали реальный запрос. Мы добавим GET-параметры server, port и secret.</p><input type="url" value={settings.checkerUrl} onChange={(event) => setSettings((previous) => ({ ...previous, checkerUrl: event.target.value }))} placeholder="https://your-worker.dev/check" className="mt-3 h-12 w-full rounded-xl border border-ink/10 bg-white px-4 font-mono text-[11px] outline-none focus:border-[#72a85b]" /><div className="mt-3 rounded-xl bg-ink p-4 font-mono text-[10px] leading-5 text-white/60"><span className="text-accent">Ожидаемый JSON:</span><br />{"{ \"online\": true, \"latency_ms\": 84 }"}<br /><span className="text-white/30">Также поддерживаются ok и status: up/down.</span></div><p className="mt-2 text-[9px] leading-4 text-ink/35">Endpoint должен разрешать CORS. Секрет передаётся указанному вами серверу; не используйте чужой checker, которому не доверяете.</p></div>
      </div>
    </Dialog>
  );
}
