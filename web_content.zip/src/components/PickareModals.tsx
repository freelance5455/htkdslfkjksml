import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Eye, EyeOff, Play, Shield, Star, X } from 'lucide-react';
import { FriendProfile, WorldConfig } from '../types/game';
import { AvatarPreview3D } from './AvatarPreview3D';
import { GameThumbnail, MiniAvatarIcon } from './GameThumbnail';

export const RedeemModal: React.FC<{
  open: boolean;
  onClose: () => void;
  onRedeem: (code: string) => { ok: boolean; message: string };
}> = ({ open, onClose, onRedeem }) => {
  const [code, setCode] = useState('');
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <motion.div
        initial={{ scale: 0.94, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(420px,94vw)] rounded-2xl bg-zinc-950 border border-white/15 p-6 text-center shadow-2xl"
      >
        <h3 className="font-display text-lg font-bold text-white">Redeem Kode</h3>
        <p className="mt-1 text-xs text-zinc-400">
          Masukkan kode untuk mendapatkan Slapbux. (Contoh: SLAPBOX5000, SLAPBOX100)
        </p>
        <input
          type="text"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="MASUKKAN KODE"
          className="mt-4 w-full px-4 py-3 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white"
        />
        {feedback && (
          <p className={`mt-2 text-xs font-medium ${feedback.ok ? 'text-white' : 'text-zinc-300 underline'}`}>
            {feedback.message}
          </p>
        )}
        <button
          type="button"
          onClick={() => setFeedback(onRedeem(code.trim()))}
          className="mt-4 w-full py-3 rounded-xl bg-white hover:bg-zinc-200 text-sm font-bold text-black cursor-pointer"
        >
          Tukar kode
        </button>
        <button
          type="button"
          onClick={() => {
            setFeedback(null);
            onClose();
          }}
          className="mt-3 text-xs font-semibold text-zinc-400 hover:text-white cursor-pointer"
        >
          Tutup
        </button>
      </motion.div>
    </div>
  );
};

export const AdminListModal: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <motion.div
        initial={{ scale: 0.94, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(400px,94vw)] rounded-2xl bg-zinc-950 border border-white/15 p-6 shadow-2xl"
      >
        <h3 className="font-display text-lg font-bold text-white text-center">Daftar Admin</h3>
        <div className="mt-4 flex items-center gap-3 p-3 rounded-xl bg-zinc-900 border border-white/15">
          <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">HackTest</div>
            <div className="text-[11px] font-semibold text-zinc-400">OWNER</div>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full py-2.5 text-xs font-semibold text-zinc-300 hover:text-white cursor-pointer"
        >
          Tutup
        </button>
      </motion.div>
    </div>
  );
};

export const PlayerProfileModal: React.FC<{
  player: FriendProfile | null;
  friendStatus: 'none' | 'pending' | 'incoming' | 'friend';
  inParty: boolean;
  onClose: () => void;
  onSendFriendRequest: (id: string) => void;
  onCancelFriendRequest: (id: string) => void;
  onAcceptFriendRequest: (id: string) => void;
  onRemoveFriend: (id: string) => void;
  onOpenTrade: (p: FriendProfile) => void;
  onInviteParty: (id: string) => void;
}> = ({
  player,
  friendStatus,
  inParty,
  onClose,
  onSendFriendRequest,
  onCancelFriendRequest,
  onAcceptFriendRequest,
  onRemoveFriend,
  onOpenTrade,
  onInviteParty,
}) => {
  const [following, setFollowing] = useState(false);

  if (!player) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <motion.div
        initial={{ scale: 0.94, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(480px,96vw)] max-h-[90vh] overflow-y-auto rounded-2xl bg-zinc-950 border border-white/15 shadow-2xl"
      >
        <div className="relative h-56 bg-zinc-900">
          <AvatarPreview3D avatar={player.avatar} nameTag={player.name} />
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup profil"
            className="absolute top-3 left-3 p-2 rounded-full bg-black/70 text-white hover:bg-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/75 border border-white/15 text-[11px] font-bold text-white">
            {player.online ? '● Online' : '○ Offline'}
          </span>
        </div>

        <div className="p-5 space-y-4">
          <div className="text-center text-xs text-zinc-400">Geser avatar 3D untuk memutar</div>

          <div className="flex items-center gap-3">
            <MiniAvatarIcon avatar={player.avatar} size={44} />
            <div>
              <div className="font-display text-lg font-bold text-white">{player.name}</div>
              <div className="text-xs text-zinc-400">{player.username}</div>
            </div>
          </div>

          <div className="text-xs text-zinc-400">Bergabung sejak {player.joined}</div>

          <div className="flex items-center gap-4 text-xs text-zinc-200 font-mono-num">
            <span>{player.friendsCount + (friendStatus === 'friend' ? 1 : 0)} Teman</span>
            <span>·</span>
            <span>{player.followersCount + (following ? 1 : 0)} Pengikut</span>
            <span>·</span>
            <span>{player.followingCount} Mengikuti</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {friendStatus === 'friend' ? (
              <button
                type="button"
                onClick={() => onRemoveFriend(player.id)}
                className="py-2.5 px-3 rounded-xl text-xs font-bold bg-zinc-800 text-white border border-white/25 hover:bg-zinc-700 cursor-pointer"
              >
                Sudah Berteman ✓
              </button>
            ) : friendStatus === 'pending' ? (
              <button
                type="button"
                onClick={() => onCancelFriendRequest(player.id)}
                title="Klik untuk membatalkan permintaan"
                className="py-2.5 px-3 rounded-xl text-xs font-bold bg-zinc-900 text-amber-300 border border-amber-400/50 cursor-pointer"
              >
                Pending (Menunggu)
              </button>
            ) : friendStatus === 'incoming' ? (
              <button
                type="button"
                onClick={() => onAcceptFriendRequest(player.id)}
                className="py-2.5 px-3 rounded-xl text-xs font-bold bg-white hover:bg-zinc-200 text-black cursor-pointer"
              >
                Terima Pertemanan
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onSendFriendRequest(player.id)}
                className="py-2.5 px-3 rounded-xl text-xs font-bold bg-white hover:bg-zinc-200 text-black cursor-pointer"
              >
                Tambahkan Teman
              </button>
            )}

            <button
              type="button"
              onClick={() => setFollowing((f) => !f)}
              className="py-2.5 px-3 rounded-xl text-xs font-semibold bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-white cursor-pointer"
            >
              {following ? 'Mengikuti ✓' : 'Ikuti'}
            </button>

            <button
              type="button"
              onClick={() => onInviteParty(player.id)}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold cursor-pointer border ${
                inParty
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                  : 'bg-zinc-900 border-white/15 hover:bg-zinc-800 text-white'
              }`}
            >
              {inParty ? 'Sudah di Party Mabar' : 'Undang ke Party Mabar'}
            </button>

            <button
              type="button"
              onClick={() => onOpenTrade(player)}
              className="py-2.5 px-3 rounded-xl text-xs font-bold bg-zinc-900 border border-white/15 hover:bg-white hover:text-black text-white cursor-pointer"
            >
              Trade Aksesoris
            </button>
          </div>

          <div>
            <div className="text-sm font-bold text-white mb-2.5">Saat ini Memakai</div>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { label: 'Rambut', sub: player.avatar.hairStyle || 'Polos', color: player.avatar.hairColor || '#18181b' },
                { label: 'Baju', sub: 'Outfit', color: player.avatar.shirtColor },
                { label: 'Celana', sub: 'Pants', color: player.avatar.pantsColor },
                { label: 'Topi', sub: player.avatar.hatStyle, color: player.avatar.hatColor },
                { label: 'Sepatu', sub: player.avatar.shoeStyle, color: player.avatar.shoeColor },
                { label: 'Efek', sub: player.avatar.effect, color: player.avatar.skinColor },
              ].map((sw) => (
                <div key={sw.label} className="rounded-xl bg-zinc-900 border border-white/10 p-2.5">
                  <div
                    style={{ backgroundColor: sw.color }}
                    className="h-10 rounded-lg border border-white/15 mb-2"
                  />
                  <div className="text-xs font-semibold text-white">{sw.label}</div>
                  <div className="text-[11px] text-zinc-400 capitalize truncate">{sw.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export const GameDetailModal: React.FC<{
  world: WorldConfig | null;
  isFavorite: boolean;
  onClose: () => void;
  onToggleFavorite: (id: WorldConfig['id']) => void;
  onPlay: (id: WorldConfig['id']) => void;
}> = ({ world, isFavorite, onClose, onToggleFavorite, onPlay }) => {
  if (!world) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 12 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-[min(520px,95vw)] rounded-2xl bg-zinc-950 border border-white/15 overflow-hidden shadow-2xl"
      >
        <div className="relative h-52">
          <GameThumbnail theme={world.thumbTheme} />
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup detail game"
            className="absolute top-3 right-3 p-2 rounded-full bg-black/75 text-white hover:bg-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <h3 className="font-display text-xl font-bold text-white">{world.name}</h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Oleh {world.creator} · Suka {world.likes} · {world.activePlayers} aktif
            </p>
            <p className="text-sm text-zinc-200 mt-2.5 leading-relaxed">{world.subtitle}</p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => onPlay(world.id)}
              className="flex-1 inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-white hover:bg-zinc-200 text-sm font-bold text-black cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              Mainkan
            </button>
            <button
              type="button"
              onClick={() => onToggleFavorite(world.id)}
              className={`inline-flex items-center gap-1.5 px-4 py-3 rounded-xl text-xs font-semibold border cursor-pointer ${
                isFavorite
                  ? 'bg-white text-black border-white'
                  : 'bg-zinc-900 border-white/15 text-zinc-200 hover:text-white'
              }`}
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
              Favorit
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export const CreateProjectModal: React.FC<{
  open: boolean;
  onClose: () => void;
  onCreate: (kind: string) => void;
}> = ({ open, onClose, onCreate }) => {
  if (!open) return null;

  const mapTemplates = [
    { name: 'Baseplate Kosong', desc: 'Lapangan luas kosong untuk membangun map dari nol.' },
    { name: 'Obby Pelangi', desc: 'Map rintangan parkour & tangga melayang.' },
    { name: 'Arena Hangout', desc: 'Area santai dengan panggung & tempat berkumpul 10+ orang.' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <motion.div
        initial={{ scale: 0.94, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(440px,95vw)] max-h-[85vh] overflow-y-auto rounded-2xl bg-zinc-950 border border-white/15 p-5 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-display text-lg font-bold text-white">Buat Game / Map Baru</h3>
            <p className="text-[11px] text-zinc-400">Khusus proyek Game & Map 3D (terpisah dari UGC).</p>
          </div>
          <button type="button" onClick={onClose} className="text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2.5">
          {mapTemplates.map((tpl) => (
            <button
              key={tpl.name}
              type="button"
              onClick={() => onCreate(tpl.name)}
              className="w-full p-3.5 rounded-xl bg-zinc-900 border border-white/10 hover:bg-white hover:text-black text-left cursor-pointer transition-colors group"
            >
              <div className="text-xs font-bold">{tpl.name}</div>
              <div className="text-[11px] opacity-75 mt-0.5">{tpl.desc}</div>
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export const AuthModal: React.FC<{
  open: boolean;
  required?: boolean;
  onClose?: () => void;
  onLogin: (email: string, password: string) => { ok: boolean; message?: string };
  onRegister: (username: string, email: string, password: string) => { ok: boolean; message?: string };
}> = ({ open, required = false, onClose, onLogin, onRegister }) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!open) return null;

  const switchTab = (next: 'login' | 'register') => {
    setTab(next);
    setErrorMsg(null);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (tab === 'login') {
      const res = onLogin(email.trim(), password);
      if (!res.ok) {
        setErrorMsg(res.message || 'Gagal masuk.');
      }
    } else {
      const res = onRegister(username.trim(), email.trim(), password);
      if (!res.ok) {
        setErrorMsg(res.message || 'Gagal mendaftar.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black p-4">
      <motion.div
        initial={{ y: -24, opacity: 0, scale: 0.96 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        className="w-[min(410px,95vw)] rounded-3xl bg-zinc-950 border border-white/20 p-6 text-white shadow-2xl"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="font-display text-2xl font-black tracking-tight flex items-center gap-1">
              <span className="text-white">SLAP</span>
              <span className="px-1.5 py-0.5 rounded bg-white text-black text-xl">BOX</span>
            </div>
            <p className="text-xs text-zinc-400 mt-1.5">
              {tab === 'login'
                ? 'Punya akun? Masuk untuk lanjut bermain'
                : 'Belum punya akun? Daftar akun baru Slapbox'}
            </p>
          </div>
          {!required && onClose && (
            <button type="button" onClick={onClose} aria-label="Tutup" className="text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="mt-4 grid grid-cols-2 p-1 rounded-xl bg-zinc-900 border border-white/10">
          <button
            type="button"
            onClick={() => switchTab('login')}
            className={`py-2 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
              tab === 'login' ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Masuk
          </button>
          <button
            type="button"
            onClick={() => switchTab('register')}
            className={`py-2 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
              tab === 'register' ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Daftar
          </button>
        </div>

        <form onSubmit={submit} className="mt-4 space-y-3">
          {tab === 'register' && (
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">Nama Karakter / Username</label>
              <input
                type="text"
                required
                minLength={2}
                maxLength={20}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Contoh: JacoPro"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="nama@email.com"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1">Password</label>
            <div className="flex gap-2">
              <input
                type={showPass ? 'text' : 'password'}
                required
                minLength={4}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="min. 4 karakter"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
              />
              <button
                type="button"
                onClick={() => setShowPass((s) => !s)}
                className="px-3 rounded-xl bg-zinc-900 border border-white/15 text-xs font-medium text-zinc-200 cursor-pointer flex items-center gap-1"
              >
                {showPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                {showPass ? 'Tutup' : 'Lihat'}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="px-3 py-2 rounded-xl bg-zinc-900 border border-white/30 text-xs text-white space-y-1">
              <div>{errorMsg}</div>
              {tab === 'login' && (
                <button
                  type="button"
                  onClick={() => switchTab('register')}
                  className="text-zinc-200 underline font-bold cursor-pointer"
                >
                  Belum punya akun? Daftar sekarang
                </button>
              )}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-white hover:bg-zinc-200 text-sm font-bold text-black cursor-pointer"
          >
            {tab === 'login' ? 'Masuk' : 'Daftar Sekarang'}
          </button>
        </form>

        <p className="mt-4 text-[11px] text-center text-zinc-500 leading-relaxed">
          Dengan masuk, kamu setuju mengikuti aturan komunitas Slapbox. Akun yang melanggar aturan dapat diblokir.
        </p>
      </motion.div>
    </div>
  );
};

export const ToastBanner: React.FC<{ message: string | null }> = ({ message }) => {
  if (!message) return null;
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-black border border-zinc-300 text-xs font-bold shadow-2xl"
    >
      <Check className="w-4 h-4" />
      {message}
    </motion.div>
  );
};
