/**
 * HELENA - Biblioteca Anatômica Veterinária & Explorador 3D Online (Sketchfab)
 * 
 * Funcionalidades:
 * 1. Catálogo local de modelos 3D reais (.glb).
 * 2. Busca Online Sketchfab com TRADUÇÃO AUTOMÁTICA do Português para o Inglês:
 *    - O usuário escreve em português (ex: "esqueleto de vaca", "músculos da vaca", "coração bovino").
 *    - O sistema converte automaticamente para o termo em inglês ideal ("cow skeleton", "cow muscles", "cow heart").
 *    - Executa a busca na API oficial do Sketchfab v3 com o termo em inglês.
 *    - Filtra carros, armas, casas e modelos não biológicos.
 *    - Exibe uma galeria com miniaturas, visualizações, curtidas e botão de visualização 3D interativa.
 */

import React, { useEffect, useState, useMemo } from 'react';
import { 
  Box, 
  Search, 
  Globe, 
  X, 
  ExternalLink, 
  Sparkles, 
  Loader2, 
  ShieldCheck, 
  AlertTriangle,
  ChevronRight,
  BookOpen,
  ArrowLeft,
  Eye,
  Heart,
  RotateCcw,
  Check
} from 'lucide-react';
import { VeterinaryModelItem, SketchfabSearchResult, AppSettings } from '../types';
import { Viewer3D } from './Viewer3D';
import { 
  translatePtToEnForSketchfab,
  scoreSketchfabResult, 
  TranslationResult,
  BANNED_KEYWORDS
} from '../services/anatomySearch';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  initialQuery?: string;
}

const SKETCHFAB_CACHE_PREFIX = 'helena_sketchfab_search_v3_';
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 horas

// Format view counts like Sketchfab (e.g. 42139 -> 42.1k)
function formatCount(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
  return String(num || 0);
}

export const LibraryModal: React.FC<LibraryModalProps> = ({
  isOpen,
  onClose,
  settings,
  initialQuery,
}) => {
  // Local catalog states
  const [catalogo, setCatalogo] = useState<VeterinaryModelItem[]>([]);
  const [loadingLocal, setLoadingLocal] = useState(true);
  const [searchText, setSearchText] = useState('');
  const [selectedEspecie, setSelectedEspecie] = useState<string>('todas');
  const [selectedSistema, setSelectedSistema] = useState<string>('todos');

  // Active local 3D viewer
  const [activeLocalModel, setActiveLocalModel] = useState<VeterinaryModelItem | null>(null);

  // Online search states
  const [onlineTabActive, setOnlineTabActive] = useState(false);
  const [onlineQuery, setOnlineQuery] = useState('');
  const [searchingSketchfab, setSearchingSketchfab] = useState(false);
  const [sketchfabResults, setSketchfabResults] = useState<SketchfabSearchResult[]>([]);
  const [activeSketchfabModel, setActiveSketchfabModel] = useState<SketchfabSearchResult | null>(null);
  const [sketchfabError, setSketchfabError] = useState<string | null>(null);
  const [translationInfo, setTranslationInfo] = useState<TranslationResult | null>(null);

  // Popular search chips for 1-tap mobile search
  const quickSearchChips = [
    { label: 'Esqueleto de Vaca', pt: 'esqueleto de vaca' },
    { label: 'Músculos da Vaca', pt: 'músculos da vaca' },
    { label: 'Coração de Vaca', pt: 'coração de vaca' },
    { label: 'Crânio Canino', pt: 'crânio canino' },
    { label: 'Coração Equino', pt: 'coração equino' },
    { label: 'Tarso Equino', pt: 'tarso equino' },
    { label: 'Coluna Canina', pt: 'coluna canina' },
    { label: 'Crânio Felino', pt: 'crânio felino' },
  ];

  // Load local catalogue from /models/catalogo.json
  useEffect(() => {
    if (!isOpen) return;

    fetch('/models/catalogo.json')
      .then((res) => {
        if (!res.ok) throw new Error('Falha ao ler catalogo.json');
        return res.json();
      })
      .then((data: VeterinaryModelItem[]) => {
        setCatalogo(data);
        setLoadingLocal(false);
      })
      .catch((err) => {
        console.warn('Usando catálogo veterinário de contingência:', err);
        setCatalogo([
          {
            id: 'cranio_canino',
            nome: 'Crânio Canino (Canis lupus familiaris)',
            especie: 'cão',
            sistema: 'esquelético',
            arquivo: '/models/cranio_canino.glb',
            fonte: 'Laboratório de Osteologia Veterinária',
            autor: 'Prof. Dr. Vet 3D',
            licenca: 'Creative Commons BY-SA 4.0',
            descricao: 'Crânio mesocefálico canino com neurocrânio, maxila, arcos zigomáticos, mandíbula articulada e dentição carniceira completa.',
          },
          {
            id: 'coracao_equino',
            nome: 'Coração Equino (Equus caballus)',
            especie: 'cavalo',
            sistema: 'cardiovascular',
            arquivo: '/models/coracao_equino.glb',
            fonte: 'Faculdade de Medicina Veterinária',
            autor: 'Anatomia Comparada 3D',
            licenca: 'Creative Commons BY-NC 4.0',
            descricao: 'Coração equino tetracameral com ventrículos esquerdo e direito, aurículas, tronco aórtico, artérias pulmonares e sulco coronário.',
          },
          {
            id: 'estomago_bovino',
            nome: 'Estômago de Ruminante (Bovino)',
            especie: 'bovino',
            sistema: 'digestório',
            arquivo: '/models/estomago_bovino.glb',
            fonte: 'Atlas Anatômico Ruminantes',
            autor: 'Núcleo de Morfologia Veterinária',
            licenca: 'Creative Commons BY 4.0',
            descricao: 'Estômago pluricavitário com os 4 compartimentos: Rúmen (sacos dorsal e ventral), Retículo, Omaso e Abomaso.',
          },
          {
            id: 'tarso_equino',
            nome: 'Tarso e Dígito Equino (Pata & Casco)',
            especie: 'cavalo',
            sistema: 'locomotor',
            arquivo: '/models/tarso_equino.glb',
            fonte: 'Ortopedia e Podologia Equina',
            autor: 'Setor de Grandes Animais',
            licenca: 'Creative Commons BY-SA 4.0',
            descricao: 'Tarso, ossos sesamoides, metatarso III, falanges e estojo córneo do dígito de equino.',
          },
          {
            id: 'coluna_canina',
            nome: 'Coluna Vertebral & Caixa Torácica Canina',
            especie: 'cão',
            sistema: 'esquelético',
            arquivo: '/models/coluna_canina.glb',
            fonte: 'Diagnóstico por Imagem e Anatomia',
            autor: 'Núcleo Vet 3D',
            licenca: 'Creative Commons BY 4.0',
            descricao: 'Vértebras cervicais, torácicas e lombares com costelas articuladas e esterno canino.',
          },
          {
            id: 'cranio_felino',
            nome: 'Crânio Felino (Felis catus)',
            especie: 'gato',
            sistema: 'esquelético',
            arquivo: '/models/cranio_felino.glb',
            fonte: 'Osteologia de Pequenos Animais',
            autor: 'Clínica & Morfologia Felina',
            licenca: 'Creative Commons BY 4.0',
            descricao: 'Crânio felino com grandes órbitas oculares frontais, bolhas timpânicas e dentição carnívora.',
          }
        ]);
        setLoadingLocal(false);
      });

    if (initialQuery) {
      setSearchText(initialQuery);
      setOnlineQuery(initialQuery);
    }
  }, [isOpen, initialQuery]);

  // Filtered local catalogue
  const filteredCatalog = useMemo(() => {
    return catalogo.filter((item) => {
      const matchSearch = !searchText || 
        item.nome.toLowerCase().includes(searchText.toLowerCase()) ||
        item.especie.toLowerCase().includes(searchText.toLowerCase()) ||
        item.sistema.toLowerCase().includes(searchText.toLowerCase()) ||
        (item.descricao && item.descricao.toLowerCase().includes(searchText.toLowerCase()));

      const matchEspecie = selectedEspecie === 'todas' || item.especie.toLowerCase() === selectedEspecie.toLowerCase();
      const matchSistema = selectedSistema === 'todos' || item.sistema.toLowerCase() === selectedSistema.toLowerCase();

      return matchSearch && matchEspecie && matchSistema;
    });
  }, [catalogo, searchText, selectedEspecie, selectedSistema]);

  /**
   * Main Search Function:
   * 1. Translates Portuguese query to English (e.g. "esqueleto de vaca" -> "cow skeleton").
   * 2. Queries Sketchfab API v3 using the English terms.
   * 3. Filters out vehicles, weapons, buildings, etc.
   * 4. Populates matching models into the gallery.
   */
  const executeSearch = async (queryInput?: string, directEnglishQuery?: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = (queryInput || onlineQuery || searchText).trim();
    if (!query && !directEnglishQuery) return;

    setSearchingSketchfab(true);
    setSketchfabError(null);
    setActiveSketchfabModel(null);

    let englishTerm = directEnglishQuery || '';
    let transRes: TranslationResult | null = null;

    if (!directEnglishQuery) {
      // Step 1: Translate from Portuguese to clean English query
      transRes = await translatePtToEnForSketchfab(query, settings.geminiKey);
      englishTerm = transRes.englishQuery;
      setTranslationInfo(transRes);
    }

    const cacheKey = `${SKETCHFAB_CACHE_PREFIX}${englishTerm.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

    // Check 24h cache
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Date.now() - parsed.timestamp < CACHE_TTL_MS && Array.isArray(parsed.data) && parsed.data.length > 0) {
          setSketchfabResults(parsed.data);
          setSearchingSketchfab(false);
          return;
        }
      }
    } catch {}

    try {
      // Step 2: Query Sketchfab API with the clean English term
      const apiUrl = `https://api.sketchfab.com/v3/search?type=models&q=${encodeURIComponent(englishTerm)}`;
      const res = await fetch(apiUrl);

      if (!res.ok) {
        throw new Error(`Sketchfab API retornou status HTTP ${res.status}`);
      }

      const json = await res.json();
      const rawResults: any[] = json?.results || [];

      if (rawResults.length === 0) {
        setSketchfabError(`Nenhum modelo encontrado no Sketchfab para "${englishTerm}". Tente outra variação.`);
        setSketchfabResults([]);
        setSearchingSketchfab(false);
        return;
      }

      // Step 3: Filter and score results
      const trustedAuthors = (settings.trustedAuthors || []).map(a => a.toLowerCase().trim());
      const detectedAnimal = transRes?.detectedSpecies || '';
      const detectedStructure = transRes?.detectedStructure || '';

      const validModels: SketchfabSearchResult[] = [];

      for (const m of rawResults) {
        const evaluation = scoreSketchfabResult(m, detectedAnimal, detectedStructure, trustedAuthors);

        if (!evaluation.isValidAnatomy) {
          continue; // Skips cars, houses, weapons, non-biological items
        }

        // Get thumbnail URL (prefer ~720/1024 or largest available)
        const thumbnails = m.thumbnails?.images || [];
        const thumbUrl = thumbnails.length > 0
          ? (thumbnails[Math.min(2, thumbnails.length - 1)]?.url || thumbnails[0]?.url)
          : '';

        validModels.push({
          uid: m.uid,
          name: m.name,
          author: m.user?.displayName || m.user?.username || 'Autor 3D',
          authorUrl: m.user?.profileUrl || `https://sketchfab.com/${m.user?.username}`,
          license: m.license?.label || 'Visualização 3D',
          likes: m.likeCount || 0,
          viewCount: m.viewCount || 0,
          embedUrl: `https://sketchfab.com/models/${m.uid}/embed?autostart=1&ui_theme=dark&ui_infos=0&ui_watermark=0&ui_controls=1`,
          score: evaluation.score,
          reason: evaluation.reasons.join(' • ') || 'Espécime biológico validado',
          thumbnails: thumbUrl ? [thumbUrl] : [],
        });
      }

      if (validModels.length === 0) {
        setSketchfabError(`Os resultados retornados para "${englishTerm}" continham veículos ou itens não anatômicos. Tente selecionar outra estrutura abaixo.`);
        setSketchfabResults([]);
        setSearchingSketchfab(false);
        return;
      }

      // Sort by relevance score, views, and likes
      validModels.sort((a, b) => b.score !== a.score ? b.score - a.score : b.likes - a.likes);

      // Save to cache
      try {
        localStorage.setItem(cacheKey, JSON.stringify({
          timestamp: Date.now(),
          data: validModels,
        }));
      } catch {}

      setSketchfabResults(validModels);
    } catch (err: any) {
      console.error('Erro na busca Sketchfab:', err);
      setSketchfabError(err.message || 'Falha ao conectar com o Sketchfab.');
      setSketchfabResults([]);
    } finally {
      setSearchingSketchfab(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in font-sans">
        <div 
          className="w-full max-w-4xl max-h-[94dvh] flex flex-col rounded-2xl bg-[#030d06] border border-[#14502D] text-[#CDEBD8] shadow-2xl overflow-hidden"
          style={{ borderColor: 'var(--cor-borda)' }}
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between px-4 sm:px-5 py-3.5 border-b border-[#14502D]/60 bg-[#06180c]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F] shrink-0">
                <Box size={22} />
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-semibold tracking-wide text-white">
                  Modelos 3D Anatômicos Veterinários
                </h2>
                <p className="text-[11px] sm:text-xs text-[#CDEBD8]/70">
                  {onlineTabActive 
                    ? 'Pesquisa Sketchfab com tradução automática Português → Inglês' 
                    : 'Catálogo de arquivos .glb reais para osteologia e clínica'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/40 transition min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
              aria-label="Fechar"
            >
              <X size={20} />
            </button>
          </div>

          {/* Navigation Tabs (Mobile Optimized >= 48px) */}
          <div className="flex border-b border-[#14502D]/60 bg-[#041208] px-3 sm:px-5 pt-2 gap-2">
            <button
              onClick={() => {
                setOnlineTabActive(false);
                setActiveSketchfabModel(null);
              }}
              className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition min-h-[44px] cursor-pointer ${
                !onlineTabActive
                  ? 'border-[#2FD16F] text-[#2FD16F]'
                  : 'border-transparent text-[#CDEBD8]/60 hover:text-[#CDEBD8]'
              }`}
            >
              <BookOpen size={16} />
              <span>Catálogo Local (.glb)</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#0E7A3D]/40 text-white font-mono">
                {catalogo.length}
              </span>
            </button>

            <button
              onClick={() => {
                setOnlineTabActive(true);
                if (onlineQuery && sketchfabResults.length === 0) {
                  executeSearch(onlineQuery);
                }
              }}
              className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition min-h-[44px] cursor-pointer ${
                onlineTabActive
                  ? 'border-[#2FD16F] text-[#2FD16F]'
                  : 'border-transparent text-[#CDEBD8]/60 hover:text-[#CDEBD8]'
              }`}
            >
              <Globe size={16} />
              <span>Explorador Sketchfab 3D</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] bg-[#2FD16F]/20 text-[#2FD16F] border border-[#2FD16F]/40 font-mono">
                Auto-Tradução EN
              </span>
            </button>
          </div>

          {/* Tab Content Body */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4">
            {/* TAB 1: LOCAL CATALOG */}
            {!onlineTabActive && (
              <div className="space-y-4">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#CDEBD8]/50" />
                  <input
                    type="text"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    placeholder="Filtrar por nome, espécie (cão, cavalo, boi...) ou osso..."
                    className="w-full pl-10 pr-4 py-3 bg-black/60 border border-[#14502D] rounded-xl text-xs sm:text-sm text-white placeholder-[#CDEBD8]/40 focus:outline-none focus:border-[#2FD16F] transition min-h-[48px]"
                  />
                  {searchText && (
                    <button
                      onClick={() => setSearchText('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#CDEBD8]/50 hover:text-white"
                    >
                      Limpar
                    </button>
                  )}
                </div>

                {/* Filter Chips */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-[11px] text-[#CDEBD8]/60 mr-1">Espécie:</span>
                  {['todas', 'cão', 'cavalo', 'bovino', 'gato'].map((esp) => (
                    <button
                      key={esp}
                      onClick={() => setSelectedEspecie(esp)}
                      className={`px-3 py-1.5 rounded-lg capitalize transition min-h-[40px] cursor-pointer ${
                        selectedEspecie === esp
                          ? 'bg-[#0E7A3D] text-white border border-[#2FD16F] font-semibold'
                          : 'bg-black/50 text-[#CDEBD8]/70 border border-[#14502D] hover:bg-[#14502D]/40'
                      }`}
                    >
                      {esp}
                    </button>
                  ))}

                  <span className="text-[11px] text-[#CDEBD8]/60 ml-2 mr-1">Sistema:</span>
                  {['todos', 'esquelético', 'cardiovascular', 'digestório', 'locomotor'].map((sis) => (
                    <button
                      key={sis}
                      onClick={() => setSelectedSistema(sis)}
                      className={`px-3 py-1.5 rounded-lg capitalize transition min-h-[40px] cursor-pointer ${
                        selectedSistema === sis
                          ? 'bg-[#0E7A3D] text-white border border-[#2FD16F] font-semibold'
                          : 'bg-black/50 text-[#CDEBD8]/70 border border-[#14502D] hover:bg-[#14502D]/40'
                      }`}
                    >
                      {sis}
                    </button>
                  ))}
                </div>

                {/* Local Catalog Cards */}
                {loadingLocal ? (
                  <div className="py-12 flex flex-col items-center justify-center text-center">
                    <Loader2 size={24} className="animate-spin text-[#2FD16F] mb-2" />
                    <span className="text-xs text-[#CDEBD8]/70">Carregando catálogo de anatomia...</span>
                  </div>
                ) : filteredCatalog.length === 0 ? (
                  <div className="py-10 px-4 rounded-2xl border border-dashed border-[#14502D] text-center space-y-3">
                    <p className="text-sm text-[#CDEBD8]/80">
                      Nenhum espécime cadastrado com este filtro específico.
                    </p>
                    <button
                      onClick={() => {
                        setOnlineTabActive(true);
                        setOnlineQuery(searchText);
                        executeSearch(searchText);
                      }}
                      className="px-5 py-2.5 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-white text-xs font-semibold transition min-h-[44px] cursor-pointer"
                    >
                      Pesquisar "{searchText}" online no Sketchfab
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {filteredCatalog.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => setActiveLocalModel(item)}
                        className="p-4 rounded-xl border border-[#14502D] bg-[#05140a] hover:bg-[#092212] hover:border-[#2FD16F] transition cursor-pointer flex flex-col justify-between group min-h-[110px]"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h3 className="text-sm font-semibold text-white group-hover:text-[#2FD16F] transition">
                              {item.nome}
                            </h3>
                            <span className="px-2 py-0.5 rounded text-[10px] bg-[#0E7A3D]/40 text-[#2FD16F] border border-[#0E7A3D] capitalize shrink-0">
                              {item.especie}
                            </span>
                          </div>
                          <p className="text-xs text-[#CDEBD8]/70 line-clamp-2 mb-2">
                            {item.descricao || `Estrutura do sistema ${item.sistema}.`}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-[#14502D]/50 text-[11px] text-[#CDEBD8]/60">
                          <span className="capitalize">Sistema {item.sistema}</span>
                          <span className="text-[#2FD16F] flex items-center gap-1 font-semibold group-hover:underline">
                            Visualizar 3D <ChevronRight size={14} />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: ONLINE SKETCHFAB EXPLORER WITH AUTO PT->EN TRANSLATION */}
            {onlineTabActive && (
              <div className="space-y-4">
                {/* Search Form */}
                <form onSubmit={(e) => executeSearch(onlineQuery, undefined, e)} className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#CDEBD8]/50" />
                    <input
                      type="text"
                      value={onlineQuery}
                      onChange={(e) => setOnlineQuery(e.target.value)}
                      placeholder="Digite em português: ex: esqueleto de vaca, músculos da vaca, crânio canino..."
                      className="w-full pl-10 pr-4 py-3 bg-black/60 border border-[#14502D] rounded-xl text-xs sm:text-sm text-white placeholder-[#CDEBD8]/40 focus:outline-none focus:border-[#2FD16F] transition min-h-[48px]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!onlineQuery.trim() || searchingSketchfab}
                    className="px-4 sm:px-5 py-3 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-white font-semibold text-xs transition flex items-center gap-1.5 disabled:opacity-50 min-h-[48px] cursor-pointer shrink-0"
                  >
                    {searchingSketchfab ? (
                      <Loader2 size={16} className="animate-spin text-white" />
                    ) : (
                      <Sparkles size={16} />
                    )}
                    <span>Buscar no Sketchfab</span>
                  </button>
                </form>

                {/* Quick 1-Tap Search Pills */}
                <div className="space-y-1.5">
                  <span className="text-[10px] text-[#CDEBD8]/60 uppercase tracking-wider block font-mono">
                    Buscas Rápidas (Traduzidas Automaticamente):
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {quickSearchChips.map((chip) => (
                      <button
                        key={chip.label}
                        type="button"
                        onClick={() => {
                          setOnlineQuery(chip.pt);
                          executeSearch(chip.pt);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-black/50 hover:bg-[#0E7A3D]/40 border border-[#14502D] hover:border-[#2FD16F] text-xs text-[#CDEBD8] transition cursor-pointer min-h-[36px]"
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Live Translation Info Badge */}
                {translationInfo && (
                  <div className="p-3 rounded-xl bg-[#06180c] border border-[#14502D] space-y-2 animate-fade-in">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-[#0E7A3D]/30 text-[#2FD16F] font-mono text-[11px] font-semibold">
                          Tradução Ativa
                        </span>
                        <span className="text-[#CDEBD8]">
                          "{translationInfo.originalQuery}" ➔ <strong className="text-white font-semibold underline decoration-[#2FD16F]">"{translationInfo.englishQuery}"</strong>
                        </span>
                      </div>
                      <span className="text-[11px] text-[#CDEBD8]/60 font-mono">
                        Filtro anti-arquitetura / anti-carros ativo
                      </span>
                    </div>

                    {/* Alternative English Search Variations */}
                    {translationInfo.alternatives.length > 1 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-[#14502D]/40 text-xs">
                        <span className="text-[11px] text-[#CDEBD8]/60">Variações em inglês:</span>
                        {translationInfo.alternatives.map((alt) => (
                          <button
                            key={alt}
                            type="button"
                            onClick={() => executeSearch(undefined, alt)}
                            className={`px-2.5 py-1 rounded text-[11px] border transition cursor-pointer ${
                              translationInfo.englishQuery === alt
                                ? 'bg-[#0E7A3D] text-white border-[#2FD16F] font-semibold'
                                : 'bg-black/40 text-[#CDEBD8]/70 border-[#14502D] hover:text-white hover:border-[#2FD16F]'
                            }`}
                          >
                            {alt}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Loading State */}
                {searchingSketchfab && (
                  <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
                    <Loader2 size={32} className="animate-spin text-[#2FD16F]" />
                    <p className="text-xs text-[#CDEBD8] font-mono">
                      Convertendo termo para o inglês e consultando modelos veterinários no Sketchfab...
                    </p>
                  </div>
                )}

                {/* Error Banner */}
                {sketchfabError && !searchingSketchfab && (
                  <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-800 text-amber-200 text-xs space-y-1">
                    <div className="flex items-start gap-2">
                      <AlertTriangle size={16} className="shrink-0 text-amber-400 mt-0.5" />
                      <span>{sketchfabError}</span>
                    </div>
                  </div>
                )}

                {/* Active Selected Model Embed (Full View) */}
                {activeSketchfabModel && !searchingSketchfab && (
                  <div className="space-y-3 animate-fade-in">
                    {/* Top navigation back button */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 p-3 rounded-xl bg-black/60 border border-[#14502D]">
                      <button
                        onClick={() => setActiveSketchfabModel(null)}
                        className="px-3 py-1.5 rounded-lg bg-[#14502D]/60 hover:bg-[#14502D] text-xs text-white font-medium flex items-center gap-1.5 transition min-h-[38px] cursor-pointer"
                      >
                        <ArrowLeft size={15} />
                        <span>Voltar para a lista ({sketchfabResults.length} modelos)</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <div className="px-2.5 py-1 rounded-lg text-xs font-bold border flex items-center gap-1 bg-[#0E7A3D]/40 text-[#2FD16F] border-[#0E7A3D]">
                          <ShieldCheck size={14} />
                          Confiabilidade {activeSketchfabModel.score}%
                        </div>
                        <a
                          href={activeSketchfabModel.authorUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-xs text-[#2FD16F] hover:underline"
                        >
                          Sketchfab <ExternalLink size={12} />
                        </a>
                      </div>
                    </div>

                    {/* Official Sketchfab Iframe Embed */}
                    <div className="relative w-full aspect-video rounded-xl overflow-hidden border border-[#14502D] bg-black shadow-2xl">
                      <iframe
                        title={activeSketchfabModel.name}
                        src={activeSketchfabModel.embedUrl}
                        className="w-full h-full border-0"
                        allow="autoplay; fullscreen; xr-spatial-tracking"
                        allowFullScreen
                      />
                    </div>

                    {/* Model Details & Attribution */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 text-xs text-[#CDEBD8]/70 pt-1">
                      <div>
                        <strong className="text-white text-sm block">{activeSketchfabModel.name}</strong>
                        <span>Autor: {activeSketchfabModel.author} ({activeSketchfabModel.license})</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs font-mono text-[#CDEBD8]/60">
                        <span className="flex items-center gap-1">
                          <Eye size={13} /> {formatCount(activeSketchfabModel.viewCount)} visualizações
                        </span>
                        <span className="flex items-center gap-1 text-pink-400">
                          <Heart size={13} /> {activeSketchfabModel.likes} curtidas
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Model Results Grid Gallery */}
                {!activeSketchfabModel && !searchingSketchfab && sketchfabResults.length > 0 && (
                  <div className="space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between text-xs text-[#CDEBD8]/70 px-1">
                      <span>Modelos 3D Encontrados ({sketchfabResults.length}):</span>
                      <span className="font-mono text-[11px] text-[#2FD16F]">Toque em um modelo para visualizar</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {sketchfabResults.map((m) => (
                        <div
                          key={m.uid}
                          onClick={() => setActiveSketchfabModel(m)}
                          className="flex flex-col rounded-xl border border-[#14502D] bg-[#05140a] hover:bg-[#092212] hover:border-[#2FD16F] transition cursor-pointer overflow-hidden group shadow-lg"
                        >
                          {/* 16:9 Thumbnail preview image */}
                          <div className="relative w-full aspect-video bg-black/80 flex items-center justify-center overflow-hidden border-b border-[#14502D]/60">
                            {m.thumbnails && m.thumbnails[0] ? (
                              <img
                                src={m.thumbnails[0]}
                                alt={m.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                                loading="lazy"
                              />
                            ) : (
                              <Box size={32} className="text-[#2FD16F]/40" />
                            )}

                            {/* Score Pill Overlay */}
                            <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/80 border border-[#0E7A3D] text-[10px] text-[#2FD16F] font-semibold backdrop-blur-xs flex items-center gap-1">
                              <ShieldCheck size={11} /> {m.score}%
                            </div>
                          </div>

                          {/* Info Area */}
                          <div className="p-3 flex flex-col justify-between flex-1 space-y-2">
                            <div>
                              <h4 className="text-xs font-semibold text-white group-hover:text-[#2FD16F] line-clamp-1 transition">
                                {m.name}
                              </h4>
                              <p className="text-[11px] text-[#CDEBD8]/60 line-clamp-1">
                                {m.author}
                              </p>
                            </div>

                            <div className="flex items-center justify-between pt-2 border-t border-[#14502D]/40 text-[11px] text-[#CDEBD8]/60">
                              <div className="flex items-center gap-2.5 font-mono">
                                <span className="flex items-center gap-1" title="Visualizações">
                                  <Eye size={12} /> {formatCount(m.viewCount)}
                                </span>
                                <span className="flex items-center gap-1 text-pink-400" title="Curtidas">
                                  <Heart size={12} /> {m.likes}
                                </span>
                              </div>

                              <span className="text-[#2FD16F] font-semibold text-xs flex items-center gap-0.5 group-hover:underline">
                                Abrir 3D <ChevronRight size={13} />
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fullscreen 3D Local Model Viewer */}
      {activeLocalModel && (
        <Viewer3D
          modelItem={activeLocalModel}
          onClose={() => setActiveLocalModel(null)}
        />
      )}
    </>
  );
};
