import React, { useEffect, useRef } from 'react';

interface FloatingNote {
  x: number;
  y: number;
  symbol: string;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
  baseOpacity: number;
  angle: number;
  spin: number;
  color: string;
  wobbleSpeed: number;
  wobbleDist: number;
  baseX: number;
}

interface AmbientOrb {
  x: number;
  y: number;
  radius: number;
  color: string;
  speedX: number;
  speedY: number;
  alpha: number;
  phase: number;
}

const NOTE_SYMBOLS = ['♪', '♫', '♬', '♩', '✦', '✧', '𝄞', '𝅘𝅥𝅯'];
const NOTE_COLORS = [
  '#22d3ee', // Cyan
  '#a855f7', // Purple
  '#f43f5e', // Rose
  '#fbbf24', // Amber
  '#38bdf8', // Sky Blue
  '#ec4899', // Pink
  '#34d399', // Emerald
];

export const MusicalMenuBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initElements();
    };

    window.addEventListener('resize', handleResize);

    const notes: FloatingNote[] = [];
    const orbs: AmbientOrb[] = [];

    const initElements = () => {
      // 1. Floating Musical Notes
      notes.length = 0;
      const numNotes = Math.min(30, Math.floor(width * 0.04) + 16);
      for (let i = 0; i < numNotes; i++) {
        const baseX = Math.random() * width;
        const color = NOTE_COLORS[Math.floor(Math.random() * NOTE_COLORS.length)];
        const symbol = NOTE_SYMBOLS[Math.floor(Math.random() * NOTE_SYMBOLS.length)];
        const baseOpacity = 0.35 + Math.random() * 0.55;

        notes.push({
          x: baseX,
          y: Math.random() * height,
          symbol,
          size: 14 + Math.random() * 22,
          speedY: 0.35 + Math.random() * 0.55,
          speedX: (Math.random() - 0.5) * 0.3,
          opacity: baseOpacity,
          baseOpacity,
          angle: (Math.random() - 0.5) * 0.4,
          spin: (Math.random() - 0.5) * 0.015,
          color,
          wobbleSpeed: 0.02 + Math.random() * 0.03,
          wobbleDist: 15 + Math.random() * 25,
          baseX,
        });
      }

      // 2. Ambient Fluid Orbs
      orbs.length = 0;
      const orbColors = [
        'rgba(6, 182, 212, 0.25)',
        'rgba(168, 85, 247, 0.20)',
        'rgba(236, 72, 153, 0.18)',
        'rgba(59, 130, 246, 0.22)',
      ];

      for (let i = 0; i < 5; i++) {
        orbs.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: 80 + Math.random() * 140,
          color: orbColors[i % orbColors.length],
          speedX: (Math.random() - 0.5) * 0.4,
          speedY: (Math.random() - 0.5) * 0.4,
          alpha: 0.2 + Math.random() * 0.2,
          phase: Math.random() * Math.PI * 2,
        });
      }
    };

    initElements();

    let time = 0;

    const render = () => {
      time += 0.022;
      ctx.clearRect(0, 0, width, height);

      // A. Deep Rich Animated Twilight Backdrop
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(0.5, '#0d1527');
      bgGrad.addColorStop(1, '#070a12');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // B. Ambient Glowing Fluid Orbs
      orbs.forEach((orb) => {
        orb.x += orb.speedX;
        orb.y += orb.speedY;
        if (orb.x < -orb.radius) orb.x = width + orb.radius;
        if (orb.x > width + orb.radius) orb.x = -orb.radius;
        if (orb.y < -orb.radius) orb.y = height + orb.radius;
        if (orb.y > height + orb.radius) orb.y = -orb.radius;

        const pulseRadius = orb.radius + Math.sin(time + orb.phase) * 20;
        const radGrad = ctx.createRadialGradient(
          orb.x,
          orb.y,
          0,
          orb.x,
          orb.y,
          pulseRadius
        );
        radGrad.addColorStop(0, orb.color);
        radGrad.addColorStop(1, 'transparent');

        ctx.fillStyle = radGrad;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, pulseRadius, 0, Math.PI * 2);
        ctx.fill();
      });

      // C. Dynamic Musical Waveform Ribbons (Sine / Harmonic Visualizer Spectrum)
      const drawWaveRibbon = (
        baseYRatio: number,
        amplitude: number,
        freq: number,
        phaseOffset: number,
        strokeColor: string,
        fillGradientColors: [string, string],
        lineWidth: number
      ) => {
        ctx.save();
        const baseY = height * baseYRatio;
        ctx.beginPath();
        ctx.moveTo(0, baseY);

        for (let x = 0; x <= width; x += 12) {
          const harmonic1 = Math.sin(x * freq + time * 1.5 + phaseOffset) * amplitude;
          const harmonic2 = Math.cos(x * freq * 1.8 - time * 1.1 + phaseOffset) * (amplitude * 0.45);
          const harmonic3 = Math.sin(x * freq * 0.5 + time * 0.8) * (amplitude * 0.3);
          const y = baseY + harmonic1 + harmonic2 + harmonic3;
          ctx.lineTo(x, y);
        }

        ctx.lineTo(width, height);
        ctx.lineTo(0, height);
        ctx.closePath();

        // Ribbon Fill
        const ribbonFill = ctx.createLinearGradient(0, baseY - amplitude, 0, height);
        ribbonFill.addColorStop(0, fillGradientColors[0]);
        ribbonFill.addColorStop(1, fillGradientColors[1]);
        ctx.fillStyle = ribbonFill;
        ctx.fill();

        // Ribbon Glowing Line
        ctx.beginPath();
        ctx.moveTo(0, baseY);
        for (let x = 0; x <= width; x += 12) {
          const harmonic1 = Math.sin(x * freq + time * 1.5 + phaseOffset) * amplitude;
          const harmonic2 = Math.cos(x * freq * 1.8 - time * 1.1 + phaseOffset) * (amplitude * 0.45);
          const harmonic3 = Math.sin(x * freq * 0.5 + time * 0.8) * (amplitude * 0.3);
          const y = baseY + harmonic1 + harmonic2 + harmonic3;
          ctx.lineTo(x, y);
        }
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = lineWidth;
        ctx.shadowColor = strokeColor;
        ctx.shadowBlur = 14;
        ctx.stroke();

        ctx.restore();
      };

      // Layer 1: Violet / Deep Blue Bottom Wave
      drawWaveRibbon(
        0.75,
        45,
        0.0035,
        0,
        'rgba(139, 92, 246, 0.8)',
        ['rgba(124, 58, 237, 0.22)', 'rgba(15, 23, 42, 0.6)'],
        2.5
      );

      // Layer 2: Neon Pink / Magenta Mid Wave
      drawWaveRibbon(
        0.58,
        36,
        0.0045,
        Math.PI * 0.6,
        'rgba(236, 72, 153, 0.75)',
        ['rgba(219, 39, 119, 0.18)', 'transparent'],
        2.0
      );

      // Layer 3: Cyan / Sky Electric Wave (High Frequency Melodic Ribbon)
      drawWaveRibbon(
        0.42,
        28,
        0.006,
        Math.PI * 1.2,
        'rgba(34, 211, 238, 0.9)',
        ['rgba(6, 182, 212, 0.15)', 'transparent'],
        2.2
      );

      // Layer 4: Golden Amber High Wave (Twinkling Accent)
      drawWaveRibbon(
        0.28,
        20,
        0.0075,
        Math.PI * 1.7,
        'rgba(251, 191, 36, 0.8)',
        ['rgba(245, 158, 11, 0.1)', 'transparent'],
        1.5
      );

      // D. Floating Musical Notes & Sparkling Chimes
      notes.forEach((note, idx) => {
        note.y -= note.speedY;
        note.angle += note.spin;
        note.x =
          note.baseX +
          Math.sin(time * note.wobbleSpeed * 50 + idx) * note.wobbleDist;

        // Wrap to bottom when floating off top
        if (note.y < -30) {
          note.y = height + 20;
          note.baseX = Math.random() * width;
          note.x = note.baseX;
        }

        const pulseOpacity =
          note.baseOpacity + Math.sin(time * 2 + idx) * 0.18;

        ctx.save();
        ctx.translate(note.x, note.y);
        ctx.rotate(note.angle);

        ctx.font = `bold ${note.size}px "Plus Jakarta Sans", "Segoe UI Symbol", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Glowing text shadow
        ctx.shadowColor = note.color;
        ctx.shadowBlur = 12;
        ctx.fillStyle = note.color;
        ctx.globalAlpha = Math.max(0.1, Math.min(1, pulseOpacity));
        ctx.fillText(note.symbol, 0, 0);

        ctx.restore();
      });

      // E. Soft Shimmering Center Spotlight Flare
      const centerGlow = ctx.createRadialGradient(
        width / 2,
        height * 0.38,
        10,
        width / 2,
        height * 0.38,
        Math.min(width, height) * 0.55
      );
      centerGlow.addColorStop(0, 'rgba(56, 189, 248, 0.14)');
      centerGlow.addColorStop(0.5, 'rgba(168, 85, 247, 0.08)');
      centerGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = centerGlow;
      ctx.fillRect(0, 0, width, height);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
    />
  );
};
