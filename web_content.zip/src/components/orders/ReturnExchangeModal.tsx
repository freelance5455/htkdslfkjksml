import React, { useState } from 'react';
import {
  X,
  RotateCcw,
  RefreshCw,
  MapPin,
  CheckCircle2,
  Banknote
} from 'lucide-react';
import { Order } from '../../context/AuthContext';

interface ReturnExchangeModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReturnOrExchange: (orderId: string, payload: any) => Promise<void>;
}

const REASONS = [
  "Size doesn't fit / Size issue",
  'Item is defective or damaged',
  'Wrong item or variant delivered',
  'Product quality is not as expected',
  'Color / appearance looks different from images',
  'Missing accessories or parts',
];

const STANDARD_SIZES = ['UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11', 'Small', 'Medium', 'Large', 'Standard'];
const STANDARD_COLORS = ['Dusty Rose', 'Obsidian Black', 'Pure White', 'Muted Mauve', 'Graphite Grey'];

export const ReturnExchangeModal: React.FC<ReturnExchangeModalProps> = ({
  order,
  isOpen,
  onClose,
  onSubmitReturnOrExchange,
}) => {
  const [requestType, setRequestType] = useState<'return' | 'exchange'>('return');
  const [selectedReason, setSelectedReason] = useState(REASONS[0]);
  const [comments, setComments] = useState('');
  const [exchangeSize, setExchangeSize] = useState(STANDARD_SIZES[2]);
  const [exchangeColor, setExchangeColor] = useState(STANDARD_COLORS[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen || !order) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      await onSubmitReturnOrExchange(order.id, {
        type: requestType,
        reason: selectedReason,
        comments,
        exchangeSize: requestType === 'exchange' ? exchangeSize : undefined,
        exchangeColor: requestType === 'exchange' ? exchangeColor : undefined,
        pickupAddress: order.shippingAddress,
      });
      setSuccessMsg(
        requestType === 'exchange'
          ? `Exchange request created for #${order.id}. Courier will arrive for inspection and replacement within 48-72 hours.`
          : `Return request created for #${order.id}. Courier will pick up your package within 48-72 hours, and refund will be transferred to your bank account upon quality inspection.`
      );
      setTimeout(() => {
        setSuccessMsg(null);
        onClose();
      }, 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#FAFAFA] overflow-hidden my-auto">
        <div className="p-5 bg-[#000000] text-white border-b border-neutral-800 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 mb-1">
            <RotateCcw className="w-5 h-5 text-[#EAEAEA]" />
            <h3 className="text-base font-black">Return or Exchange</h3>
          </div>
          <p className="text-xs text-[#FAFAFA]">
            Order #{order.id} • 7-Day Hassle-Free Doorstep Reverse Pickup
          </p>
        </div>

        {successMsg ? (
          <div className="p-8 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
            <h4 className="text-base font-black text-slate-900">Request Registered!</h4>
            <p className="text-xs text-slate-600 leading-relaxed max-w-md mx-auto">{successMsg}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs">
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-50 text-red-800 font-semibold border border-red-200">
                {errorMsg}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
              <button
                type="button"
                onClick={() => setRequestType('return')}
                className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  requestType === 'return'
                    ? 'bg-white text-black font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Return for Refund
              </button>
              <button
                type="button"
                onClick={() => setRequestType('exchange')}
                className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  requestType === 'exchange'
                    ? 'bg-white text-black font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Exchange Variant
              </button>
            </div>

            {requestType === 'exchange' && (
              <div className="bg-[#FAFAFA]/60 p-4 rounded-2xl border border-[#FAFAFA] space-y-3">
                <p className="font-bold text-[#3B0764] flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 text-black font-bold" />
                  <span>Choose Replacement Variant</span>
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      New Size
                    </label>
                    <select
                      value={exchangeSize}
                      onChange={(e) => setExchangeSize(e.target.value)}
                      className="w-full h-9 px-2.5 bg-white border border-[#EAEAEA] rounded-xl focus:outline-none"
                    >
                      {STANDARD_SIZES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      New Color
                    </label>
                    <select
                      value={exchangeColor}
                      onChange={(e) => setExchangeColor(e.target.value)}
                      className="w-full h-9 px-2.5 bg-white border border-[#EAEAEA] rounded-xl focus:outline-none"
                    >
                      {STANDARD_COLORS.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Reason for {requestType === 'exchange' ? 'Exchange' : 'Return'}
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
              >
                {REASONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Additional Notes / Details
              </label>
              <textarea
                rows={2}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Mention condition of tags, packaging, or issue description..."
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
              />
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <MapPin className="w-3.5 h-3.5 text-black font-bold" />
                <span>Pickup Address</span>
              </div>
              <p className="text-slate-700 font-semibold">{order.shippingAddress.fullName}</p>
              <p className="text-slate-500">
                {order.shippingAddress.street}, {order.shippingAddress.city}, {order.shippingAddress.state} -{' '}
                {order.shippingAddress.pincode}
              </p>
              <p className="text-[11px] text-black font-bold font-semibold mt-1">
                Our courier will call {order.shippingAddress.phone} before pickup.
              </p>
            </div>

            {requestType === 'return' && (
              <div className="text-[11px] text-emerald-900 bg-emerald-50 p-3 rounded-xl border border-emerald-200 flex items-start gap-2">
                <Banknote className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <p>
                  Upon reverse pickup and standard verification at our facility, the refund of <strong>₹{order.total.toLocaleString()}</strong> will be transferred directly to your bank account via NEFT/IMPS.
                </p>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 font-bold text-slate-700 hover:bg-slate-100 rounded-xl border border-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 font-bold text-white bg-[#FFD400] hover:bg-neutral-800 rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                {isSubmitting
                  ? 'Submitting...'
                  : requestType === 'exchange'
                  ? 'Submit Exchange'
                  : 'Submit Return'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
