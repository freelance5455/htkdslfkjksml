import React, { useState, useEffect } from 'react';
import {
  ArrowLeft, Package, Truck, Search, RefreshCw, FileText, ChevronRight, Copy, Check
} from 'lucide-react';
import { useAuth, Order } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { TrackOrderModal } from './TrackOrderModal';
import { OrderDetailsModal } from './OrderDetailsModal';
import { CancelOrderModal } from './CancelOrderModal';
import { ReturnExchangeModal } from './ReturnExchangeModal';
import { TaxInvoiceModal } from './TaxInvoiceModal';

interface OrdersScreenProps {
  onBack: () => void;
  onStartShopping: () => void;
  onOpenAuth?: () => void;
}

type OrderFilter = 'All' | 'Active' | 'Delivered' | 'Cancelled';

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  onBack,
  onStartShopping,
  onOpenAuth,
}) => {
  const { orders, fetchOrders, cancelOrder, requestReturnOrExchange, isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const [filter, setFilter] = useState<OrderFilter>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [selectedTrackingOrder, setSelectedTrackingOrder] = useState<Order | null>(null);
  const [selectedDetailsOrder, setSelectedDetailsOrder] = useState<Order | null>(null);
  const [selectedCancelOrder, setSelectedCancelOrder] = useState<Order | null>(null);
  const [selectedReturnOrder, setSelectedReturnOrder] = useState<Order | null>(null);
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (isAuthenticated) {
      fetchOrders().catch(() => {});
    }
  }, [isAuthenticated]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await fetchOrders();
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleCopyOrderId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredOrders = orders.filter((ord) => {
    const status = ord.orderStatus ? ord.orderStatus.toLowerCase() : '';
    if (filter === 'Active') {
      const activeStatuses = ['pending', 'confirmed', 'processing', 'packed', 'ready_for_pickup', 'picked_up', 'shipped', 'in_transit', 'out_for_delivery'];
      if (!activeStatuses.includes(status)) return false;
    } else if (filter === 'Delivered') {
      if (status !== 'delivered') return false;
    } else if (filter === 'Cancelled') {
      if (status !== 'cancelled') return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchId = ord.id.toLowerCase().includes(q);
      const matchItems = ord.items.some((it) => it.productName?.toLowerCase().includes(q));
      if (!matchId && !matchItems) return false;
    }

    return true;
  });

  const getStatusColor = (status: string) => {
    const s = status ? status.toLowerCase() : '';
    if (s === 'delivered') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    if (s.includes('out_for_delivery')) return 'bg-[#FAFAFA] text-black font-bold border-[#EAEAEA]';
    if (s.includes('shipped') || s.includes('in_transit')) return 'bg-blue-50 text-blue-700 border-blue-200';
    if (s === 'cancelled') return 'bg-[#FAFAFA] text-black font-bold border-[#EAEAEA]';
    if (s.includes('return')) return 'bg-amber-50 text-amber-700 border-amber-200';
    return 'bg-[#FAFAFA] text-black font-bold border-[#EAEAEA]';
  };

  return (
    <div className="w-full min-h-screen bg-slate-50/70 pb-24 flex flex-col">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#FAFAFA] px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onBack}
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
                {t('myOrders')}
              </h1>
              <p className="text-[11px] text-slate-500 font-medium">
                {orders.length} {t('myOrders')}
              </p>
            </div>
          </div>

          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="w-8 h-8 rounded-full border border-[#FAFAFA] hover:bg-[#FAFAFA] text-slate-600 flex items-center justify-center cursor-pointer transition-colors"
            aria-label="Refresh orders"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-black font-bold' : ''}`} />
          </button>
        </div>

        <div className="mt-2.5 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchPlaceholder')}
            className="w-full h-10 pl-9 pr-8 text-xs font-semibold bg-slate-100/80 border border-slate-200/80 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-black transition-all placeholder:text-slate-400"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      <div className="bg-white border-b border-[#FAFAFA] px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {(['All', 'Active', 'Delivered', 'Cancelled'] as OrderFilter[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              filter === tab
                ? 'bg-[#FFD400] text-black font-black shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-[#FAFAFA] hover:text-black font-bold'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="max-w-4xl mx-auto w-full px-4 py-4 space-y-3 flex-1">
        {!isAuthenticated && orders.length === 0 ? (
          <div className="bg-white rounded-3xl border border-[#FAFAFA] p-8 text-center shadow-xs my-6">
            <div className="w-16 h-16 rounded-full bg-[#FAFAFA] text-black font-bold flex items-center justify-center mx-auto mb-3">
              <Package className="w-8 h-8" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900">
              Track Your Orders
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Sign in with your Google or Gmail account to view your past purchases, track live shipping status, and download tax invoices.
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              {onOpenAuth && (
                <button
                  onClick={onOpenAuth}
                  className="px-5 py-2.5 rounded-full bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 font-bold text-xs shadow-xs cursor-pointer"
                >
                  Continue with Google
                </button>
              )}
              <button
                onClick={onStartShopping}
                className="px-5 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs cursor-pointer"
              >
                Browse Products
              </button>
            </div>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-white rounded-3xl border border-[#FAFAFA] p-8 text-center shadow-xs my-6">
            <div className="w-16 h-16 rounded-full bg-[#FAFAFA] text-black font-bold flex items-center justify-center mx-auto mb-3">
              <Package className="w-8 h-8 text-[#C084FC]" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900">
              No orders found
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              {searchQuery
                ? 'No orders match your search query.'
                : 'You have not placed any orders in this section yet.'}
            </p>
            <button
              onClick={onStartShopping}
              className="mt-5 px-6 py-2.5 rounded-full bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 font-bold text-xs transition-colors cursor-pointer shadow-xs"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const firstItem = order.items[0];
            const otherItemsCount = order.items.length - 1;
            return (
              <div
                key={order.id}
                className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden transition-all hover:shadow-md"
              >
                <div className="p-3.5 sm:p-4 bg-white border-b border-[#FAFAFA] flex items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-extrabold text-slate-900">
                        #{order.id.slice(0, 14)}
                      </span>
                      <button
                        onClick={(e) => handleCopyOrderId(order.id, e)}
                        className="text-slate-400 hover:text-black font-bold p-0.5 cursor-pointer"
                        title="Copy Order ID"
                      >
                        {copiedId === order.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-bold uppercase tracking-wider border ${getStatusColor(
                      order.orderStatus
                    )}`}
                  >
                    {order.orderStatus.replace(/_/g, ' ')}
                  </span>
                </div>

                <div className="p-3.5 sm:p-4">
                  <div className="flex gap-3 sm:gap-4 items-center">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#FAFAFA] overflow-hidden flex items-center justify-center flex-shrink-0">
                      {firstItem?.image ? (
                        <img
                          src={firstItem.image}
                          alt={firstItem.productName}
                          className="w-full h-full object-cover object-center"
                        />
                      ) : (
                        <Package className="w-6 h-6 text-black font-bold" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                        {firstItem?.productName || 'Omazify Product'}
                      </h4>
                      {otherItemsCount > 0 && (
                        <p className="text-[11px] text-black font-bold font-semibold mt-0.5">
                          + {otherItemsCount} more {otherItemsCount === 1 ? 'item' : 'items'}
                        </p>
                      )}
                      <p className="text-xs font-extrabold text-slate-900 mt-1">
                        ₹{order.total.toLocaleString()} • <span className="text-black font-bold font-bold">Cash on Delivery</span>
                      </p>
                    </div>
                  </div>

                  <div className="mt-3.5 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                    <button
                      onClick={() => setSelectedTrackingOrder(order)}
                      className="px-3.5 py-1.5 rounded-xl bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Track Order</span>
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedInvoiceOrder(order)}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 hover:border-black text-slate-700 hover:text-black font-bold text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Invoice</span>
                      </button>
                      <button
                        onClick={() => setSelectedDetailsOrder(order)}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 hover:border-black text-slate-700 hover:text-black font-bold text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>Details</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <TrackOrderModal
        order={selectedTrackingOrder}
        onClose={() => setSelectedTrackingOrder(null)}
      />
      <OrderDetailsModal
        order={selectedDetailsOrder}
        onClose={() => setSelectedDetailsOrder(null)}
        onTrackOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedTrackingOrder(ord);
        }}
        onDownloadInvoice={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedInvoiceOrder(ord);
        }}
        onCancelOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedCancelOrder(ord);
        }}
        onReturnOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedReturnOrder(ord);
        }}
      />
      <CancelOrderModal
        order={selectedCancelOrder}
        isOpen={!!selectedCancelOrder}
        onClose={() => setSelectedCancelOrder(null)}
        onConfirmCancel={async (orderId, reason) => {
          await cancelOrder(orderId, reason);
          setSelectedCancelOrder(null);
          fetchOrders();
        }}
      />
      <ReturnExchangeModal
        order={selectedReturnOrder}
        isOpen={!!selectedReturnOrder}
        onClose={() => setSelectedReturnOrder(null)}
        onSubmitReturnOrExchange={async (orderId, payload) => {
          await requestReturnOrExchange(orderId, payload);
          setSelectedReturnOrder(null);
          fetchOrders();
        }}
      />
      <TaxInvoiceModal
        order={selectedInvoiceOrder}
        isOpen={!!selectedInvoiceOrder}
        onClose={() => setSelectedInvoiceOrder(null)}
      />
    </div>
  );
};
