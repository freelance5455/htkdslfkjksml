import React, { useRef, useEffect, useState } from 'react';
import { X, Printer } from 'lucide-react';
import { Order } from '../../context/AuthContext';
import { api } from '../../services/api';
import { OmazifyLogo } from '../common/OmazifyLogo';

interface TaxInvoiceModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const TaxInvoiceModal: React.FC<TaxInvoiceModalProps> = ({ order, isOpen, onClose }) => {
  const [invoiceData, setInvoiceData] = useState<any>(null);
  const [, setIsLoading] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && order) {
      setIsLoading(true);
      api
        .getOrderInvoice(order.id)
        .then((data) => setInvoiceData(data))
        .catch(() => setInvoiceData(null))
        .finally(() => setIsLoading(false));
    }
  }, [isOpen, order]);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const invoiceNo = invoiceData?.invoiceNumber || `INV-${order.id.replace('NTX-', '')}/25-26`;
  const seller = invoiceData?.seller || {
    companyName: 'OMAZIFY E-COMMERCE PRIVATE LIMITED',
    tradeName: 'OMAZIFY',
    cin: 'U52100KA2026PTC198420',
    gstin: '29ABCDE1234F1Z5',
    pan: 'ABCDE1234F',
    address: 'OMAZIFY Tower, 100 Feet Road, Indiranagar, Bengaluru, Karnataka 560038, India',
    email: 'support@omazify.com',
    phone: '1800-420-OMAZ',
  };

  return (
    <div className="fixed inset-0 z-70 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[94vh] flex flex-col print:m-0 print:p-0 print:border-none print:shadow-none print:max-h-none print:rounded-none">
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between flex-shrink-0 print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#EAEAEA]">
              Tax Invoice
            </span>
            <span className="text-xs text-slate-400 font-mono">#{invoiceNo}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 rounded-xl text-xs font-bold shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div
          ref={printRef}
          className="p-6 sm:p-8 overflow-y-auto font-sans text-slate-800 bg-white print:p-0"
        >
          <div className="flex flex-wrap items-start justify-between gap-4 pb-6 border-b-2 border-slate-800">
            <div>
              <div className="mb-2">
                <OmazifyLogo size="md" />
              </div>
              <h2 className="text-sm font-black text-slate-900">{seller.companyName}</h2>
              {seller.address ? (
                <p className="text-[11px] text-slate-600 max-w-xs leading-relaxed">{seller.address}</p>
              ) : null}
              {seller.gstin ? (
                <p className="text-[11px] text-slate-700 mt-1">
                  <strong>GSTIN:</strong> {seller.gstin} {seller.cin ? `| CIN: ${seller.cin}` : ''}
                </p>
              ) : null}
              <p className="text-[11px] text-slate-600">
                <strong>Email:</strong> {seller.email} {seller.phone ? `| Phone: ${seller.phone}` : ''}
              </p>
            </div>
            <div className="text-right sm:text-right">
              <span className="inline-block px-3 py-1 bg-[#FAFAFA] text-black font-bold rounded-md text-xs font-black uppercase tracking-wider mb-2">
                TAX INVOICE
              </span>
              <p className="text-xs font-bold text-slate-900">
                Invoice No:{' '}
                <span className="font-mono text-black font-bold">{invoiceNo}</span>
              </p>
              <p className="text-xs text-slate-600">
                Invoice Date:{' '}
                {new Date(order.createdAt).toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                })}
              </p>
              <p className="text-xs text-slate-600">
                Order ID: <span className="font-mono font-bold text-slate-800">#{order.id}</span>
              </p>
              <p className="text-xs text-slate-600">
                State of Supply:{' '}
                <span className="font-semibold text-slate-800">
                  {order.shippingAddress.state} (Code: 29)
                </span>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 py-4 border-b border-slate-200 text-xs">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Bill To / Ship To:
              </p>
              <p className="font-bold text-slate-900 text-sm">{order.shippingAddress.fullName}</p>
              <p className="text-slate-600 mt-0.5 leading-relaxed">
                {order.shippingAddress.street}, {order.shippingAddress.city},{' '}
                {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </p>
              <p className="text-slate-600 mt-1">
                <strong>Phone:</strong> {order.shippingAddress.phone}
              </p>
              <p className="text-slate-600">
                <strong>Email:</strong> {order.userEmail}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Payment & Logistics Details:
              </p>
              <p className="font-bold text-slate-900">
                Method:{' '}
                <span className="uppercase text-emerald-800 font-bold">
                  Cash on Delivery (COD)
                </span>
              </p>
              <p className="text-slate-600 text-[11px]">
                Status: {order.orderStatus === 'DELIVERED' ? 'Cash Collected on Delivery' : 'To be collected at doorstep'}
              </p>
              <p className="text-slate-600 mt-1">
                Courier:{' '}
                <span className="font-semibold">
                  {order.courierPartner || 'OMAZIFY Logistics Network'}
                </span>
              </p>
              <p className="text-slate-600 font-mono text-[11px]">
                AWB: {order.awbNumber || order.trackingNumber || 'Pending Dispatch'}
              </p>
            </div>
          </div>

          <div className="py-4">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-y border-slate-300">
                  <th className="py-2 px-2">#</th>
                  <th className="py-2 px-2">Description of Goods</th>
                  <th className="py-2 px-2">HSN</th>
                  <th className="py-2 px-2 text-center">Qty</th>
                  <th className="py-2 px-2 text-right">Rate</th>
                  <th className="py-2 px-2 text-right">Taxable Val</th>
                  <th className="py-2 px-2 text-right">CGST (9%)</th>
                  <th className="py-2 px-2 text-right">SGST (9%)</th>
                  <th className="py-2 px-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {order.items.map((it, idx) => {
                  const lineTotal = it.price * it.quantity;
                  const taxable = Math.round((lineTotal / 1.18) * 100) / 100;
                  const cgstVal = Math.round((taxable * 0.09) * 100) / 100;
                  const sgstVal = Math.round((taxable * 0.09) * 100) / 100;
                  return (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-2 text-slate-500">{idx + 1}</td>
                      <td className="py-2.5 px-2">
                        <p className="font-bold text-slate-900">{it.productName}</p>
                        <p className="text-[10px] text-slate-500">
                          {[it.selectedSize, it.selectedColor].filter(Boolean).join(' • ')}
                        </p>
                      </td>
                      <td className="py-2.5 px-2 text-slate-600 font-mono text-[11px]">640411</td>
                      <td className="py-2.5 px-2 text-center font-semibold">{it.quantity}</td>
                      <td className="py-2.5 px-2 text-right">₹{it.price.toLocaleString()}</td>
                      <td className="py-2.5 px-2 text-right font-mono">₹{taxable.toFixed(2)}</td>
                      <td className="py-2.5 px-2 text-right font-mono text-[11px]">₹{cgstVal.toFixed(2)}</td>
                      <td className="py-2.5 px-2 text-right font-mono text-[11px]">₹{sgstVal.toFixed(2)}</td>
                      <td className="py-2.5 px-2 text-right font-bold text-slate-900">
                        ₹{lineTotal.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="pt-4 border-t-2 border-slate-800 flex flex-col sm:flex-row justify-between gap-6 text-xs">
            <div className="max-w-xs space-y-2">
              <p className="text-slate-600 leading-relaxed text-[11px]">
                <strong>Amount in Words:</strong>
                <br />
                INR {order.total.toLocaleString()} Only (Payable via Cash on Delivery)
              </p>
              <p className="text-[10px] text-slate-500">
                Whether tax is payable on reverse charge basis: <strong>No</strong>
              </p>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[10px] text-slate-600 leading-relaxed">
                Computer generated tax invoice under Section 31 of CGST Act, 2017 & Rule 46 of CGST
                Rules, 2017. All returns/exchanges must cite invoice number.
              </div>
            </div>

            <div className="min-w-[260px] space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal:</span>
                <span>₹{order.subtotal.toLocaleString()}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Coupon Savings {order.couponCode ? `(${order.couponCode})` : ''}:</span>
                  <span>- ₹{order.discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery & Shipping:</span>
                <span>{order.shippingFee === 0 ? 'FREE' : `₹${order.shippingFee}`}</span>
              </div>
              <div className="flex justify-between text-slate-600 text-[11px]">
                <span>Total Tax Amount (CGST+SGST):</span>
                <span>₹{order.taxAmount.toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t-2 border-slate-900 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Amount to Pay (COD):</span>
                <span className="text-black font-bold text-base">₹{order.total.toLocaleString()}</span>
              </div>
              <div className="pt-6 text-right">
                <div className="inline-block text-center border-t border-dashed border-slate-400 pt-1">
                  <p className="text-[10px] font-bold text-slate-800 uppercase">
                    For {seller.companyName}
                  </p>
                  <p className="text-[9px] text-slate-500">Authorized Signatory</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
