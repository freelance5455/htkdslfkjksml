import React, { useState } from 'react';
import {
  X,
  Bell,
  Check,
  CheckCheck,
  Truck,
  Package,
  RotateCcw,
  AlertCircle,
  ExternalLink,
  Trash2,
  ShieldCheck,
  BellRing
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface NotificationsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOrder?: (orderId: string) => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({
  isOpen,
  onClose,
  onSelectOrder,
}) => {
  const {
    notifications,
    unreadNotificationCount,
    markNotificationRead,
    markAllNotificationsRead,
    deleteNotification,
    clearAllNotifications,
    requestNotificationPermission,
    notificationPermission,
  } = useAuth();
  const [removedToast, setRemovedToast] = useState<string | null>(null);
  const [isRequestingPermission, setIsRequestingPermission] = useState(false);

  if (!isOpen) return null;

  const handleClearAll = async () => {
    await clearAllNotifications();
    setRemovedToast('All notifications cleared');
    setTimeout(() => setRemovedToast(null), 2000);
  };

  const handleDeleteOne = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteNotification(id);
    setRemovedToast('Notification removed');
    setTimeout(() => setRemovedToast(null), 2000);
  };

  const handleEnableAlerts = async () => {
    setIsRequestingPermission(true);
    await requestNotificationPermission();
    setIsRequestingPermission(false);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'DELIVERED':
        return <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 flex-shrink-0"><Check className="w-4 h-4" /></div>;
      case 'OUT_FOR_DELIVERY':
      case 'IN_TRANSIT':
      case 'SHIPPED':
        return <div className="p-2 rounded-xl bg-[#FAFAFA] text-black font-bold flex-shrink-0"><Truck className="w-4 h-4" /></div>;
      case 'RETURN_APPROVED':
      case 'RETURN_REQUESTED':
      case 'REFUNDED':
        return <div className="p-2 rounded-xl bg-blue-100 text-blue-700 flex-shrink-0"><RotateCcw className="w-4 h-4" /></div>;
      case 'CANCELLED':
        return <div className="p-2 rounded-xl bg-red-100 text-red-700 flex-shrink-0"><AlertCircle className="w-4 h-4" /></div>;
      default:
        return <div className="p-2 rounded-xl bg-[#FAFAFA] text-black font-bold flex-shrink-0"><Package className="w-4 h-4" /></div>;
    }
  };

  const getChannelBadge = (channel: string) => {
    switch (channel) {
      case 'whatsapp':
        return <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">WhatsApp</span>;
      case 'sms':
        return <span className="text-[10px] font-bold text-blue-800 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">SMS</span>;
      case 'email':
        return <span className="text-[10px] font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">Email</span>;
      default:
        return <span className="text-[10px] font-bold text-black font-bold bg-[#FAFAFA] px-1.5 py-0.5 rounded border border-[#EAEAEA]">Live Alert</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex justify-end bg-black/50 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-md h-full bg-white shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-[#000000] border-b border-neutral-800 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/10 text-[#FAFAFA] border border-white/10">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Real Delivery Alerts</h3>
              <p className="text-[11px] text-[#EAEAEA]">
                {unreadNotificationCount > 0
                  ? `${unreadNotificationCount} unread update${unreadNotificationCount > 1 ? 's' : ''}`
                  : 'Live order tracking & updates'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {unreadNotificationCount > 0 && (
              <button
                onClick={() => markAllNotificationsRead()}
                className="text-[11px] font-bold text-[#EAEAEA] hover:text-white flex items-center gap-1 cursor-pointer transition-colors px-2 py-1 rounded-lg hover:bg-white/10"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mark read</span>
              </button>
            )}
            {notifications.length > 0 && (
              <button
                onClick={handleClearAll}
                className="text-[11px] font-bold text-[#FFD400] hover:text-[#FAFAFA] flex items-center gap-1 cursor-pointer transition-colors px-2 py-1 rounded-lg hover:bg-white/10"
                title="Clear all notifications"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-white cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Real Device Alert Opt-In Bar */}
        {notificationPermission !== 'granted' && notificationPermission !== 'unsupported' ? (
          <div className="p-3 bg-[#FAFAFA] border-b border-[#EAEAEA] flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <BellRing className="w-4 h-4 text-black font-bold flex-shrink-0 animate-bounce" />
              <div className="min-w-0">
                <p className="font-bold text-[#3B0764] truncate">Enable Phone / Browser Alerts</p>
                <p className="text-[11px] text-black font-bold/80 truncate">Get instant alerts when your COD package is out for delivery</p>
              </div>
            </div>
            <button
              type="button"
              disabled={isRequestingPermission}
              onClick={handleEnableAlerts}
              className="px-3 py-1.5 bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex-shrink-0 disabled:opacity-50"
            >
              {isRequestingPermission ? 'Enabling...' : 'Enable'}
            </button>
          </div>
        ) : notificationPermission === 'granted' ? (
          <div className="px-4 py-2 bg-emerald-50/80 border-b border-emerald-100 text-[11px] font-bold text-emerald-800 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Real device notifications enabled for live COD orders</span>
          </div>
        ) : null}

        {removedToast && (
          <div className="px-4 py-2 bg-emerald-50 border-b border-emerald-100 text-xs font-bold text-emerald-800 flex items-center justify-between animate-in fade-in">
            <span>{removedToast}</span>
            <button
              onClick={() => setRemovedToast(null)}
              className="text-emerald-600 hover:text-emerald-900 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        <div className="p-4 overflow-y-auto flex-1 divide-y divide-slate-100">
          {notifications.length === 0 ? (
            <div className="py-16 px-6 text-center text-slate-500 space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-[#FAFAFA] text-black font-bold flex items-center justify-center mx-auto border border-[#FAFAFA] shadow-2xs">
                <Bell className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <p className="font-black text-slate-900 text-sm">No Notifications Yet</p>
                <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                  Real updates about your orders, COD dispatch status, and doorstep delivery will appear here as soon as you place an order.
                </p>
              </div>
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => {
                  if (!n.read) markNotificationRead(n.id);
                  if (n.orderId && onSelectOrder) onSelectOrder(n.orderId);
                }}
                className={`py-3.5 px-3 rounded-2xl transition-all cursor-pointer flex items-start gap-3 ${
                  n.read ? 'bg-white hover:bg-slate-50' : 'bg-[#FAFAFA]/80 hover:bg-[#FAFAFA] border border-[#EAEAEA] shadow-2xs'
                }`}
              >
                {getNotificationIcon(n.type)}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <p className={`text-xs truncate ${n.read ? 'font-semibold text-slate-900' : 'font-bold text-[#3B0764]'}`}>
                      {n.title}
                    </p>
                    {getChannelBadge(n.channel)}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2">
                    <span>
                      {new Date(n.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {n.orderId && (
                      <span className="font-bold text-black font-bold flex items-center gap-0.5 hover:underline">
                        Track #{n.orderId}
                        <ExternalLink className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end justify-between self-stretch flex-shrink-0 gap-1">
                  {!n.read ? (
                    <span className="w-2 h-2 rounded-full bg-[#FFD400] mt-1 ring-2 ring-[#EAEAEA]" />
                  ) : (
                    <span className="w-2 h-2" />
                  )}
                  <button
                    type="button"
                    onClick={(e) => handleDeleteOne(n.id, e)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-black font-bold hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer"
                    title="Remove notification"
                    aria-label="Remove notification"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500 font-medium">
          Verified Express Logistics • Real-time SMS & In-App Tracking
        </div>
      </div>
    </div>
  );
};
