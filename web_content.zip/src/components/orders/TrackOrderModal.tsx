import React, { useState } from 'react';
import {
  X, Truck, Copy, Check, ExternalLink, MapPin, Clock, PhoneCall, MessageSquare, Banknote
} from 'lucide-react';
import { Order } from '../../context/AuthContext';
import { OrderTimeline } from './OrderTimeline';

interface TrackOrderModalProps {
  order: Order | null;
  onClose: () => void;
  onOpenSupport?: () => void;
}

export const TrackOrderModal: React.FC<TrackOrderModalProps> = ({
  order,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!order) return null;

  const handleCopyAwb = (awb: string) => {
    navigator.clipboard.writeText(awb);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const latestEvent =
    order.trackingEvents && order.trackingEvents.length > 0
      ? order.trackingEvents[order.trackingEvents.length - 1]
      : null;

  const courierName = order.courierPartner || 'OMAZIFY Logistics Network';
  const awbCode = order.awbNumber || order.trackingNumber || 'Pending Dispatch';
  const hasAwb = !!order.awbNumber || !!order.trackingNumber;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'DELIVERED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-600" />
            Delivered
          </span>
        );
      case 'OUT_FOR_DELIVERY':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#FAFAFA] text-black font-bold border border-[#EAEAEA] animate-pulse">
            <span className="w-2 h-2 rounded-full bg-[#FFD400]" />
            Out for Delivery
          </span>
        );
      case 'IN_TRANSIT':
      case 'SHIPPED':
      case 'PICKED_UP':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-900 border border-blue-300">
            <span className="w-2 h-2 rounded-full bg-blue-600" />
            In Transit
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
            Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
            Processing Order
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#FAFAFA] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        <div className="p-5 sm:p-6 bg-[#000000] border-b border-neutral-800 text-white relative flex-shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 rounded-xl bg-white/10 text-white">
              <Truck className="w-5 h-5" />
            </div>
            <span className="text-xs uppercase tracking-wider font-bold text-[#FAFAFA]">
              Live Shipment Tracking • Cash on Delivery
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 mt-2">
            <div>
              <h3 className="text-xl sm:text-2xl font-black tracking-tight">Order #{order.id}</h3>
              <p className="text-xs text-[#FAFAFA] mt-0.5">
                Placed on{' '}
                {new Date(order.createdAt).toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>
            <div>{getStatusBadge(order.orderStatus)}</div>
          </div>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#FAFAFA]/60 p-4 rounded-2xl border border-[#FAFAFA]">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Courier Partner
              </p>
              <p className="text-xs font-bold text-slate-900 mt-0.5 truncate">{courierName}</p>
            </div>

            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                AWB / Tracking
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-xs font-mono font-bold text-[#3B0764] truncate">
                  {awbCode}
                </span>
                {hasAwb && (
                  <button
                    onClick={() => handleCopyAwb(awbCode)}
                    className="p-1 text-black font-bold hover:text-black font-bold cursor-pointer"
                    title="Copy AWB Number"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  </button>
                )}
              </div>
            </div>

            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Payment Mode
              </p>
              <p className="text-xs font-bold text-emerald-700 mt-0.5 truncate flex items-center gap-1">
                <Banknote className="w-3.5 h-3.5" /> Cash on Delivery
              </p>
            </div>

            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                {order.orderStatus === 'DELIVERED' ? 'Delivered On' : 'Expected Delivery'}
              </p>
              <p className="text-xs font-bold text-emerald-800 mt-0.5">
                {order.orderStatus === 'DELIVERED' && order.deliveredAt
                  ? new Date(order.deliveredAt).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                    })
                  : order.expectedDeliveryDate
                  ? new Date(order.expectedDeliveryDate).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                    })
                  : '3-5 Business Days'}
              </p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Banknote className="w-4 h-4 text-emerald-700" />
              <span className="text-emerald-950 font-semibold">
                Amount to pay at delivery: <strong className="text-emerald-900 text-sm">₹{order.total.toLocaleString()}</strong>
              </span>
            </div>
            <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
              Cash on Delivery
            </span>
          </div>

          {latestEvent && (
            <div className="bg-white border-2 border-[#EAEAEA] rounded-2xl p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-black font-bold text-xs font-bold uppercase tracking-wider mb-1">
                <Clock className="w-3.5 h-3.5" />
                <span>Latest Tracking Update</span>
              </div>
              <p className="text-sm font-bold text-slate-900">{latestEvent.message}</p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-2">
                <span>
                  Updated on:{' '}
                  {new Date(latestEvent.timestamp).toLocaleString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
                {latestEvent.location && (
                  <span className="inline-flex items-center gap-1 font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    <MapPin className="w-3.5 h-3.5 text-black font-bold" />
                    {latestEvent.location}
                  </span>
                )}
              </div>
            </div>
          )}

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Delivery Timeline
            </h4>
            <OrderTimeline
              orderStatus={order.orderStatus}
              trackingEvents={order.trackingEvents}
              courierPartner={order.courierPartner}
              awbNumber={order.awbNumber}
              expectedDeliveryDate={order.expectedDeliveryDate}
              deliveredAt={order.deliveredAt}
              isCancelled={order.orderStatus === 'CANCELLED'}
              cancellationReason={order.cancellationReason}
            />
          </div>

          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs">
            <p className="font-bold text-slate-900 mb-1">Delivery Destination</p>
            <p className="text-slate-700 font-semibold">{order.shippingAddress.fullName}</p>
            <p className="text-slate-600">
              {order.shippingAddress.street}, {order.shippingAddress.city}, {order.shippingAddress.state} -{' '}
              {order.shippingAddress.pincode}
            </p>
            <p className="text-slate-500 mt-1">Contact: {order.shippingAddress.phone}</p>
          </div>

          <div className="bg-[#FAFAFA]/60 rounded-2xl p-4 border border-[#EAEAEA] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div>
              <p className="font-bold text-[#3B0764]">Need help with your shipment?</p>
              <p className="text-slate-600 text-[11px] mt-0.5">
                Our 24x7 customer support desk and grievance redressal officer are available.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <a
                href="tel:1800-420-OMAZ"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#EAEAEA] rounded-xl text-black font-bold font-bold hover:bg-[#FAFAFA] shadow-2xs cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>1800-420-OMAZ</span>
              </a>
              <a
                href="mailto:support@omazify.com?subject=Inquiry for Order"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FFD400] text-black font-black rounded-xl font-bold hover:bg-neutral-800 shadow-2xs cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Support</span>
              </a>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-shrink-0">
          {order.trackingUrl ? (
            <a
              href={order.trackingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-black font-bold hover:text-black font-bold"
            >
              <span>View on {courierName} Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          ) : (
            <span className="text-[11px] text-slate-500 font-medium">
              Verified by OMAZIFY Automated Courier Dispatch Engine
            </span>
          )}
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
