import React from 'react';
import {
  X, Truck, FileText, RotateCcw, Ban, MapPin, Calendar, CheckCircle2, Clock, Banknote
} from 'lucide-react';
import { Order } from '../../context/AuthContext';

interface OrderDetailsModalProps {
  order: Order | null;
  onClose: () => void;
  onTrackOrder: (order: Order) => void;
  onDownloadInvoice: (order: Order) => void;
  onCancelOrder: (order: Order) => void;
  onReturnOrder: (order: Order) => void;
}

export const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({
  order,
  onClose,
  onTrackOrder,
  onDownloadInvoice,
  onCancelOrder,
  onReturnOrder,
}) => {
  if (!order) return null;

  const isCancelable =
    order.orderStatus === 'PENDING' ||
    order.orderStatus === 'CONFIRMED' ||
    order.orderStatus === 'PROCESSING' ||
    order.orderStatus === 'PACKED';

  const isReturnEligible = order.orderStatus === 'DELIVERED';

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'DELIVERED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Delivered
          </span>
        );
      case 'OUT_FOR_DELIVERY':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-black font-bold bg-[#FAFAFA] px-3 py-1 rounded-full border border-[#EAEAEA] animate-pulse">
            <Truck className="w-3.5 h-3.5 text-black font-bold" />
            Out for Delivery
          </span>
        );
      case 'IN_TRANSIT':
      case 'SHIPPED':
      case 'PICKED_UP':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-900 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            <Truck className="w-3.5 h-3.5 text-blue-600" />
            In Transit
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-full border border-slate-300">
            Cancelled
          </span>
        );
      case 'RETURN_REQUESTED':
      case 'RETURN_APPROVED':
      case 'RETURNED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-black font-bold bg-[#FAFAFA] px-3 py-1 rounded-full border border-[#EAEAEA]">
            <RotateCcw className="w-3.5 h-3.5 text-black font-bold" />
            {status.replace('_', ' ')}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            Processing
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-[#FAFAFA] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        <div className="p-5 sm:p-6 bg-slate-50 border-b border-slate-200 relative flex-shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex flex-wrap items-center justify-between gap-3 pr-8">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-lg font-black text-slate-900">
                  Order Details #{order.id}
                </span>
                {getStatusBadge(order.orderStatus)}
              </div>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  Placed on{' '}
                  {new Date(order.createdAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onTrackOrder(order)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#FFD400] hover:bg-[#000000] text-white border-b border-neutral-800 rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                <Truck className="w-3.5 h-3.5" />
                <span>Track Shipment</span>
              </button>
              <button
                onClick={() => onDownloadInvoice(order)}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-[#FAFAFA] text-black font-bold border border-[#EAEAEA] rounded-xl text-xs font-bold shadow-2xs cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Invoice</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          <div className="bg-[#FAFAFA]/70 border border-[#FAFAFA] rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-1">
              <p className="font-bold text-[#3B0764] flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-black font-bold" />
                <span>
                  Courier Partner: {order.courierPartner || 'OMAZIFY Surface Express Network'}
                </span>
              </p>
              {order.awbNumber && (
                <p className="text-slate-600 font-mono text-[11px]">
                  Waybill / AWB No: <span className="font-bold text-slate-800">{order.awbNumber}</span>
                </p>
              )}
            </div>
            <div className="text-left sm:text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                {order.orderStatus === 'DELIVERED' ? 'Delivery Date' : 'Estimated Delivery'}
              </span>
              <span className="text-xs font-bold text-slate-900">
                {order.orderStatus === 'DELIVERED' && order.deliveredAt
                  ? new Date(order.deliveredAt).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })
                  : order.expectedDeliveryDate
                  ? new Date(order.expectedDeliveryDate).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })
                  : '3-5 Business Days'}
              </span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
              Items Ordered ({order.items.reduce((acc, it) => acc + it.quantity, 0)})
            </h4>
            <div className="border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden">
              {order.items.map((it, idx) => (
                <div key={idx} className="p-4 flex items-center gap-4 bg-white hover:bg-slate-50/50">
                  <img
                    src={it.image}
                    alt={it.productName}
                    className="w-16 h-16 object-contain rounded-xl bg-slate-50 border border-slate-100 p-1 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-900 truncate">{it.productName}</p>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-1">
                      {it.selectedSize && (
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium text-slate-700">
                          Size: {it.selectedSize}
                        </span>
                      )}
                      {it.selectedColor && (
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium text-slate-700">
                          Color: {it.selectedColor}
                        </span>
                      )}
                      <span className="text-slate-400">Qty: {it.quantity}</span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-slate-900">
                      ₹{(it.price * it.quantity).toLocaleString()}
                    </p>
                    <p className="text-[11px] text-slate-400">₹{it.price.toLocaleString()} each</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs space-y-2">
              <div className="flex items-center gap-2 text-slate-900 font-bold mb-1">
                <MapPin className="w-4 h-4 text-black font-bold" />
                <span>Delivery Address</span>
              </div>
              <p className="font-bold text-slate-900">{order.shippingAddress.fullName}</p>
              <p className="text-slate-600 leading-relaxed">
                {order.shippingAddress.street}, {order.shippingAddress.city},{' '}
                {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </p>
              <p className="text-slate-500 font-medium">Phone: {order.shippingAddress.phone}</p>
              <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500">
                Billing address matches shipping address under GST Rule 46.
              </div>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs space-y-2">
              <div className="flex items-center gap-2 text-slate-900 font-bold mb-1">
                <Banknote className="w-4 h-4 text-emerald-700" />
                <span>Payment & Cost Breakdown</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal</span>
                <span>₹{order.subtotal.toLocaleString()}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Coupon Discount {order.couponCode ? `(${order.couponCode})` : ''}</span>
                  <span>- ₹{order.discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery Charges</span>
                <span>
                  {order.shippingFee === 0 ? (
                    <span className="text-emerald-700 font-bold">FREE (Orders &gt; ₹999)</span>
                  ) : (
                    `₹${order.shippingFee}`
                  )}
                </span>
              </div>
              <div className="flex justify-between text-slate-600 text-[11px]">
                <span>
                  GST Breakdown (CGST 9% + SGST 9%)
                </span>
                <span>₹{order.taxAmount.toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Total Amount to Pay</span>
                <span className="text-black font-bold text-base">₹{order.total.toLocaleString()}</span>
              </div>
              <div className="pt-1 text-[11px] text-slate-600 flex items-center justify-between">
                <span>Payment Mode:</span>
                <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Cash on Delivery (COD)
                </span>
              </div>
              <div className="text-[10px] text-slate-500">
                {order.orderStatus === 'DELIVERED'
                  ? 'Paid in cash upon package delivery.'
                  : 'Pay cash to courier executive upon delivery.'}
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 flex-shrink-0">
          <div className="flex items-center gap-2">
            {isCancelable && (
              <button
                onClick={() => onCancelOrder(order)}
                className="px-4 py-2 border border-red-200 text-red-600 hover:bg-red-50 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <Ban className="w-3.5 h-3.5" />
                <span>Cancel Order</span>
              </button>
            )}
            {isReturnEligible && (
              <button
                onClick={() => onReturnOrder(order)}
                className="px-4 py-2 bg-[#FAFAFA] hover:bg-[#FAFAFA] text-black font-bold border border-[#EAEAEA] text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Return / Exchange</span>
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={() => onDownloadInvoice(order)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Tax Invoice</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
