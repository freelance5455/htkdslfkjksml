import React from 'react';
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  MapPin,
  RotateCcw
} from 'lucide-react';
import { TrackingEvent, OrderStatusType } from '../../types';

interface OrderTimelineProps {
  orderStatus: OrderStatusType;
  trackingEvents?: TrackingEvent[];
  courierPartner?: string;
  awbNumber?: string;
  expectedDeliveryDate?: string;
  deliveredAt?: string;
  isCancelled?: boolean;
  cancellationReason?: string;
}

export const STAGES = [
  { key: 'ORDER_PLACED', label: 'Order Placed (COD)' },
  { key: 'ORDER_CONFIRMED', label: 'Order Confirmed' },
  { key: 'PROCESSING', label: 'Processing' },
  { key: 'PACKED', label: 'Packed' },
  { key: 'READY_FOR_PICKUP', label: 'Ready for Pickup' },
  { key: 'PICKED_UP', label: 'Picked Up' },
  { key: 'SHIPPED', label: 'Shipped' },
  { key: 'IN_TRANSIT', label: 'In Transit' },
  { key: 'REACHED_DESTINATION_CITY', label: 'Reached Destination' },
  { key: 'OUT_FOR_DELIVERY', label: 'Out for Delivery' },
  { key: 'DELIVERED', label: 'Delivered (Cash Collected)' },
];

function getStageIndex(status: string): number {
  switch (status) {
    case 'PENDING':
      return 0;
    case 'CONFIRMED':
      return 1;
    case 'PROCESSING':
      return 2;
    case 'PACKED':
      return 3;
    case 'READY_FOR_PICKUP':
      return 4;
    case 'PICKED_UP':
      return 5;
    case 'SHIPPED':
      return 6;
    case 'IN_TRANSIT':
      return 7;
    case 'REACHED_DESTINATION_CITY':
      return 8;
    case 'OUT_FOR_DELIVERY':
      return 9;
    case 'DELIVERED':
      return 10;
    default:
      return 1;
  }
}

export const OrderTimeline: React.FC<OrderTimelineProps> = ({
  orderStatus,
  trackingEvents = [],
  courierPartner,
  awbNumber,
  expectedDeliveryDate,
  isCancelled,
  cancellationReason,
}) => {
  if (isCancelled || orderStatus === 'CANCELLED') {
    return (
      <div className="bg-red-50 border border-red-200 rounded-2xl p-5 my-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-red-900">Order Cancelled</h4>
            <p className="text-xs text-red-700 mt-1">
              {cancellationReason || 'This order was cancelled before dispatch.'}
            </p>
            <p className="text-[11px] text-emerald-800 mt-2 font-medium bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
              ✓ This was a Cash on Delivery order. No payment was deducted, so zero charges were incurred.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (
    orderStatus === 'RETURN_REQUESTED' ||
    orderStatus === 'RETURN_APPROVED' ||
    orderStatus === 'RETURN_PICKED_UP' ||
    orderStatus === 'RETURNED' ||
    orderStatus === 'REFUNDED'
  ) {
    return (
      <div className="bg-[#FAFAFA] border border-[#EAEAEA] rounded-2xl p-5 my-4">
        <div className="flex items-start gap-3">
          <RotateCcw className="w-5 h-5 text-black font-bold flex-shrink-0 mt-0.5" />
          <div className="space-y-2 flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-[#3B0764]">Return / Exchange In Progress</h4>
              <span className="text-[10px] font-bold text-black font-bold bg-[#FAFAFA] px-2 py-0.5 rounded-full uppercase">
                {orderStatus.replace('_', ' ')}
              </span>
            </div>
            <p className="text-xs text-black font-bold">
              Doorstep verification and pickup is being coordinated by our reverse logistics partner.
            </p>
            {trackingEvents.length > 0 && (
              <div className="pt-2 border-t border-[#EAEAEA]/60 space-y-2">
                {trackingEvents.map((ev) => (
                  <div key={ev.id} className="text-xs flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FFD400] mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800">{ev.message}</p>
                      <p className="text-[10px] text-slate-500">
                        {new Date(ev.timestamp).toLocaleString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {ev.location ? ` • ${ev.location}` : ''}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const currentIdx = getStageIndex(orderStatus);
  const hasCourierHandover =
    !!awbNumber ||
    trackingEvents.some(
      (e) => e.eventType === 'PICKED_UP' || e.eventType === 'SHIPPED' || e.eventType === 'IN_TRANSIT'
    );

  return (
    <div className="py-2">
      <div className="relative mb-6">
        <div className="flex items-center justify-between relative z-10 overflow-x-auto pb-2 scrollbar-none">
          {STAGES.map((stage, idx) => {
            const isCompleted = idx < currentIdx || (orderStatus === 'DELIVERED' && idx === 10);
            const isCurrent = idx === currentIdx && orderStatus !== 'DELIVERED';

            return (
              <div
                key={stage.key}
                className="flex flex-col items-center min-w-[70px] sm:min-w-[80px] text-center px-1 flex-1"
              >
                <div
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                    isCompleted
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : isCurrent
                      ? 'bg-[#FFD400] text-black font-black ring-4 ring-[#FAFAFA] shadow-sm animate-pulse'
                      : 'bg-slate-100 text-slate-400 border border-slate-200'
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  ) : isCurrent ? (
                    <span className="w-2.5 h-2.5 bg-white rounded-full" />
                  ) : (
                    <span>{idx + 1}</span>
                  )}
                </div>
                <span
                  className={`text-[10px] sm:text-[11px] mt-2 font-medium leading-tight line-clamp-2 max-w-[80px] ${
                    isCurrent
                      ? 'font-bold text-[#3B0764]'
                      : isCompleted
                      ? 'font-semibold text-slate-800'
                      : 'text-slate-400'
                  }`}
                >
                  {stage.label}
                </span>
              </div>
            );
          })}
        </div>

        <div className="hidden sm:block absolute top-4 left-8 right-8 h-0.5 bg-slate-200 -z-0">
          <div
            className="h-full bg-emerald-600 transition-all duration-500"
            style={{
              width: `${Math.min(100, Math.max(0, (currentIdx / (STAGES.length - 1)) * 100))}%`,
            }}
          />
        </div>
      </div>

      {!hasCourierHandover ? (
        <div className="bg-[#FAFAFA] border border-[#EAEAEA] rounded-2xl p-4 flex items-start gap-3 my-3">
          <Clock className="w-4 h-4 text-black font-bold flex-shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-semibold text-[#3B0764]">Cash on Delivery Order Being Prepared</p>
            <p className="text-slate-600 mt-0.5 leading-relaxed">
              Tracking updates will appear here once the shipment is handed over to the courier. You will pay cash upon arrival.
            </p>
            {expectedDeliveryDate && (
              <p className="text-[11px] text-black font-bold font-semibold mt-1.5">
                Expected delivery by: {new Date(expectedDeliveryDate).toLocaleDateString('en-IN', {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                })}
              </p>
            )}
          </div>
        </div>
      ) : (
        <div className="mt-4 bg-slate-50/80 border border-slate-200 rounded-2xl p-4 sm:p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
            <div>
              <span className="text-xs font-bold text-slate-900">Courier Tracking Updates</span>
              {courierPartner && (
                <span className="text-[11px] font-semibold text-black font-bold ml-2 bg-[#FAFAFA] px-2 py-0.5 rounded border border-[#EAEAEA]">
                  {courierPartner}
                </span>
              )}
            </div>
            {awbNumber && (
              <span className="text-[11px] font-mono font-bold text-slate-700">
                AWB: {awbNumber}
              </span>
            )}
          </div>

          {trackingEvents.length === 0 ? (
            <p className="text-xs text-slate-500 py-2">
              Tracking updates will appear here once the shipment is handed over to the courier.
            </p>
          ) : (
            <div className="space-y-4">
              {trackingEvents
                .slice()
                .reverse()
                .map((ev, i) => (
                  <div key={ev.id || i} className="flex items-start gap-3 text-xs relative">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-2.5 h-2.5 rounded-full ${
                          i === 0 ? 'bg-[#FFD400] ring-4 ring-[#FAFAFA]' : 'bg-slate-400'
                        }`}
                      />
                      {i < trackingEvents.length - 1 && (
                        <div className="w-0.5 h-8 bg-slate-200 my-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-1">
                      <div className="flex flex-wrap items-center justify-between gap-1">
                        <p
                          className={`font-semibold ${
                            i === 0 ? 'text-slate-900 font-bold' : 'text-slate-700'
                          }`}
                        >
                          {ev.status || ev.eventType.replace('_', ' ')}
                        </p>
                        <span className="text-[10px] text-slate-400">
                          {new Date(ev.timestamp).toLocaleString('en-IN', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{ev.message}</p>
                      {ev.location && (
                        <div className="inline-flex items-center gap-1 text-[10px] text-slate-500 font-medium mt-1 bg-white px-2 py-0.5 rounded border border-slate-200">
                          <MapPin className="w-2.5 h-2.5 text-black font-bold" />
                          <span>{ev.location}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
