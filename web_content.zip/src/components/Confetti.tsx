import { useEffect, useRef } from 'react';

type P = { x: number; y: number; vx: number; vy: number; size: number; color: string; rot: number; vr: number; shape: number; life: number };
const COLORS = ['#f43f5e', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#facc15'];

export default function Confetti({ burstKey, continuous = false }: { burstKey: number; continuous?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const particles = useRef<P[]>([]);
  const raf = useRef(0);

  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize(); window.addEventListener('resize', resize);
    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.current = particles.current.filter(p => p.life > 0 && p.y < canvas.height + 30);
      for (const p of particles.current) {
        p.x += p.vx; p.y += p.vy; p.vy += 0.12; p.vx *= 0.99; p.rot += p.vr; p.life -= 0.008;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = Math.max(0, Math.min(1, p.life));
        ctx.fillStyle = p.color;
        if (p.shape === 0) ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        else if (p.shape === 1) { ctx.beginPath(); ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2); ctx.fill(); }
        else { ctx.beginPath(); ctx.moveTo(0, -p.size / 2); ctx.lineTo(p.size / 2, p.size / 2); ctx.lineTo(-p.size / 2, p.size / 2); ctx.closePath(); ctx.fill(); }
        ctx.restore();
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf.current); window.removeEventListener('resize', resize); };
  }, []);

  useEffect(() => {
    if (!burstKey) return;
    const n = continuous ? 160 : 70;
    const cx = window.innerWidth / 2, cy = window.innerHeight * 0.35;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = 4 + Math.random() * 9;
      particles.current.push({
        x: continuous ? Math.random() * window.innerWidth : cx + (Math.random() - 0.5) * 120,
        y: continuous ? -20 - Math.random() * 120 : cy + (Math.random() - 0.5) * 60,
        vx: Math.cos(a) * sp, vy: continuous ? 1 + Math.random() * 2 : Math.sin(a) * sp - 4,
        size: 6 + Math.random() * 9, color: COLORS[Math.floor(Math.random() * COLORS.length)],
        rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.3, shape: Math.floor(Math.random() * 3), life: 1,
      });
    }
    if (particles.current.length > 400) particles.current = particles.current.slice(-400);
  }, [burstKey, continuous]);

  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-50" aria-hidden />;
}
