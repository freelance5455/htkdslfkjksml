import React from 'react';

interface GazeReticleOverlayProps {
  stereo: boolean;
  progress: number;
  hoveredTarget: string | null;
}

const SingleReticle: React.FC<{
  leftPercent: string;
  progress: number;
  active: boolean;
}> = ({ leftPercent, progress, active }) => {
  const radius = 14;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - Math.max(0, Math.min(1, progress)));

  return (
    <div
      style={{ left: leftPercent, top: '50%' }}
      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
    >
      <svg width="40" height="40" viewBox="0 0 40 40" aria-hidden="true">
        <circle
          cx="20"
          cy="20"
          r={radius}
          fill="none"
          stroke={active ? 'rgba(56, 189, 248, 0.35)' : 'rgba(255, 255, 255, 0.25)'}
          strokeWidth="2.5"
        />
        {active && progress > 0 && (
          <circle
            cx="20"
            cy="20"
            r={radius}
            fill="none"
            stroke="#38BDF8"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            transform="rotate(-90 20 20)"
          />
        )}
        <circle
          cx="20"
          cy="20"
          r={active ? 4.2 : 2.8}
          fill={active ? '#38BDF8' : '#FFFFFF'}
        />
      </svg>
    </div>
  );
};

export const GazeReticleOverlay: React.FC<GazeReticleOverlayProps> = ({
  stereo,
  progress,
  hoveredTarget,
}) => {
  const active = Boolean(hoveredTarget);

  if (stereo) {
    return (
      <div className="pointer-events-none fixed inset-0 z-20" aria-hidden="true">
        <SingleReticle leftPercent="25%" progress={progress} active={active} />
        <SingleReticle leftPercent="75%" progress={progress} active={active} />
        <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[3px] bg-black" />
      </div>
    );
  }

  return (
    <div className="pointer-events-none fixed inset-0 z-20" aria-hidden="true">
      <SingleReticle leftPercent="50%" progress={progress} active={active} />
    </div>
  );
};
