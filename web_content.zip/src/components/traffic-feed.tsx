import { Badge } from "@/components/ui/badge";
import { useShield, type TrafficEvent } from "@/lib/store";
import { verdictLabel, type Verdict } from "@/lib/reputation";

function toneFor(v: Verdict) {
  if (v === "malicious") return "danger" as const;
  if (v === "suspicious") return "warn" as const;
  if (v === "trusted") return "safe" as const;
  return "muted" as const;
}

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function Row({ e }: { e: TrafficEvent }) {
  return (
    <li className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 border-b border-border py-3 last:border-0">
      <p className="truncate font-mono text-xs text-fg">{e.domain}</p>
      <Badge tone={toneFor(e.verdict)}>{verdictLabel(e.verdict)}</Badge>
      <p className="text-xs text-muted">
        {e.app} · {e.proto} · {formatBytes(e.bytes)}
      </p>
      <p className="text-right text-[11px] uppercase tracking-wider text-subtle">
        {e.decision === "blocked"
          ? "Blockiert"
          : e.decision === "trusted"
            ? "Vertraut"
            : e.decision === "pending"
              ? "Wartet"
              : "Durch"}
      </p>
    </li>
  );
}

export function TrafficFeed() {
  const events = useShield((s) => s.events);

  if (!events.length) {
    return (
      <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted">
        Noch kein Verkehr. Schutz einschalten oder eine Website prüfen.
      </p>
    );
  }

  return (
    <ul className="rounded-xl border border-border bg-surface px-4">
      {events.map((e) => (
        <Row key={e.id} e={e} />
      ))}
    </ul>
  );
}
