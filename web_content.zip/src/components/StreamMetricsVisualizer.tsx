import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Wifi, Zap, ShieldCheck } from 'lucide-react';

interface StreamMetricsVisualizerProps {
  isPlaying: boolean;
}

export const StreamMetricsVisualizer: React.FC<StreamMetricsVisualizerProps> = ({ isPlaying }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = 180;
    const height = 45;
    svg.attr('width', width).attr('height', height);

    const dataPoints = Array.from({ length: 15 }, (_, i) => ({
      x: i * (width / 14),
      y: isPlaying ? 15 + Math.sin(i + Date.now() / 300) * 12 + Math.random() * 8 : 5
    }));

    const line = d3.line<{ x: number; y: number }>()
      .x(d => d.x)
      .y(d => height - d.y)
      .curve(d3.curveMonotoneX);

    // Gradient definition
    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient')
      .attr('id', 'stream-gradient')
      .attr('x1', '0%').attr('y1', '0%')
      .attr('x2', '100%').attr('y2', '0%');
    
    gradient.append('stop').attr('offset', '0%').attr('stop-color', '#eab308'); // gold
    gradient.append('stop').attr('offset', '100%').attr('stop-color', '#38bdf8'); // cyan

    svg.append('path')
      .datum(dataPoints)
      .attr('fill', 'none')
      .attr('stroke', 'url(#stream-gradient)')
      .attr('stroke-width', 2.5)
      .attr('d', line);

    // Render nodes
    svg.selectAll('circle')
      .data(dataPoints)
      .enter()
      .append('circle')
      .attr('cx', d => d.x)
      .attr('cy', d => height - d.y)
      .attr('r', 2.5)
      .attr('fill', '#eab308');

  }, [isPlaying]);

  return (
    <div className="hidden md:flex items-center gap-3 px-3 py-1.5 bg-neutral-900/80 border border-amber-500/30 rounded-xl text-xs text-neutral-300 backdrop-blur-md">
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 font-semibold text-amber-400">
          <Wifi className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
          <span>500KB Stream Velocity</span>
        </div>
        <div className="text-[10px] text-neutral-400 flex items-center gap-2">
          <span>Compression: <strong className="text-emerald-400">89.4%</strong></span>
          <span>•</span>
          <span className="flex items-center gap-0.5 text-cyan-400">
            <ShieldCheck className="w-3 h-3" /> Encrypted KV
          </span>
        </div>
      </div>
      <div className="bg-black/40 rounded-lg p-1 border border-neutral-800">
        <svg ref={svgRef} className="overflow-visible" />
      </div>
    </div>
  );
};
