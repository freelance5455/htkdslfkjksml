import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import type { Department } from '../types/attendance';

interface DepartmentModalProps {
  isOpen: boolean;
  editingDepartment: Department | null;
  onClose: () => void;
  onSave: (data: { name: string; supervisor: string }) => void;
}

export function DepartmentModal({
  isOpen,
  editingDepartment,
  onClose,
  onSave,
}: DepartmentModalProps) {
  const [name, setName] = useState('');
  const [supervisor, setSupervisor] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setName(editingDepartment?.name ?? '');
      setSupervisor(editingDepartment?.supervisor ?? '');
      setError('');
    }
  }, [isOpen, editingDepartment]);

  if (!isOpen) {
    return null;
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedSupervisor = supervisor.trim();
    if (!trimmedName) {
      setError('Please enter a department name.');
      return;
    }
    if (!trimmedSupervisor) {
      setError('Please enter a supervisor name.');
      return;
    }
    onSave({ name: trimmedName, supervisor: trimmedSupervisor });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dept-modal-title"
    >
      <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 id="dept-modal-title" className="text-lg font-semibold text-slate-900">
            {editingDepartment ? 'Edit Department' : 'Add Department'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close department modal"
            className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label htmlFor="dept-name-input" className="block text-sm font-medium text-slate-700 mb-1.5">
              Department Name
            </label>
            <input
              id="dept-name-input"
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Samir Eng"
              autoFocus
              className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          <div>
            <label htmlFor="dept-supervisor-input" className="block text-sm font-medium text-slate-700 mb-1.5">
              Supervisor Name
            </label>
            <input
              id="dept-supervisor-input"
              type="text"
              value={supervisor}
              onChange={(e) => {
                setSupervisor(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Ramesh Marandi"
              className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          {error && (
            <p role="alert" className="text-sm font-medium text-rose-600 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl shadow-xs transition-colors"
            >
              {editingDepartment ? 'Save Changes' : 'Create Department'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
