import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  ExternalLink,
  ShieldCheck,
  Clock,
  BookOpen,
  FileCheck2,
  AlertCircle
} from 'lucide-react';

export const ExamUpdatesView: React.FC = () => {
  const { examUpdates, setActiveTab, setSelectedCategory } = useApp();

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Header */}
      <div className="bg-[#0B192C] text-white rounded-2xl p-6 sm:p-8 mb-6 border border-[#1E3E62] shadow-lg">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-0.5 rounded border border-amber-400/20 uppercase tracking-wider">
              Official Government Portals Only
            </span>
            <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" /> 100% Verified
            </span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-white">
            Latest Exam Notifications & Calendars 2026
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            We never invent dates, vacancies, or exam news. All alerts are cross-verified with official state and central commissions.
          </p>
        </div>
      </div>

      {/* Feed list */}
      <div className="space-y-4">
        {examUpdates.map((update) => (
          <div
            key={update.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs hover:border-amber-400 transition-colors"
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-black text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-md">
                  {update.organization}
                </span>
                <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                  {update.category}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  update.status.includes('Admit')
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {update.status}
                </span>
              </div>

              <div className="text-[11px] text-slate-500 flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                <span>Last Updated: {update.lastUpdated}</span>
              </div>
            </div>

            <div className="mt-3">
              <h2 className="text-base sm:text-lg font-black text-[#0B192C]">
                {update.title}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                {update.summary}
              </p>
            </div>

            {/* Dates & Deadlines */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 my-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-semibold text-slate-400 uppercase block">Notification Date</span>
                <span className="text-xs font-bold text-slate-800">{update.notificationDate}</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-semibold text-slate-400 uppercase block">Application / Admit Card</span>
                <span className="text-xs font-bold text-slate-800">{update.lastDate || 'As per commission schedule'}</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-semibold text-slate-400 uppercase block">Exam Date Window</span>
                <span className="text-xs font-bold text-amber-700">{update.examDate || 'To be announced'}</span>
              </div>
            </div>

            {/* Syllabus Highlights */}
            <div className="bg-amber-50/50 border border-amber-200/60 p-3.5 rounded-xl space-y-1.5">
              <span className="text-xs font-bold text-amber-900 block uppercase tracking-wider">
                Official Syllabus Highlights:
              </span>
              <ul className="list-disc list-inside text-xs text-slate-700 space-y-1">
                {update.syllabusHighlights.map((point, idx) => (
                  <li key={idx}>{point}</li>
                ))}
              </ul>
            </div>

            {/* Source Note & Action Links */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="text-[11px] text-slate-500 italic flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>{update.sourceNote}</span>
              </div>

              <div className="flex items-center gap-3">
                <a
                  href={update.officialUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 hover:underline"
                >
                  <span>Official Portal Link</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => {
                    setActiveTab('categories');
                  }}
                  className="bg-[#0B192C] text-amber-400 font-bold px-3 py-1.5 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  View Study Books
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
