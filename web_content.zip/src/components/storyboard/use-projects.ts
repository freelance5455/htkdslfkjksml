import { useEffect } from "react";
import { useStory } from "@/lib/storyboard/store";

export function useProjects() {
  const ready = useStory((state) => state.ready);
  const load = useStory((state) => state.load);
  useEffect(() => {
    void load();
  }, [load]);
  return ready;
}
