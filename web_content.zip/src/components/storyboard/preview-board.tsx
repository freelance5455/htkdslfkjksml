import { useState } from "react";
import { Link } from "@tanstack/react-router";
import * as Switch from "@radix-ui/react-switch";
import { aspectFrameClass } from "@/lib/storyboard/prompts";
import type { Project } from "@/lib/storyboard/types";

function Flag({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex min-h-11 items-center justify-between gap-3 rounded-md border border-line bg-surface px-3">
      <span className="text-sm font-medium">{label}</span>
      <Switch.Root
        checked={checked}
        onCheckedChange={onChange}
        className="relative h-7 w-12 shrink-0 rounded-full bg-faint data-[state=checked]:bg-ink"
      >
        <Switch.Thumb className="block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" />
      </Switch.Root>
    </label>
  );
}

export function PreviewBoard({ project }: { project: Project }) {
  const [showNumber, setShowNumber] = useState(true);
  const [showTitle, setShowTitle] = useState(true);
  const columns = project.scenes.length === 9 ? "grid-cols-3" : "grid-cols-2";
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Storyboard preview</p>
          <h1 className="font-display text-3xl font-medium tracking-tight">{project.name}</h1>
        </div>
        <Link to="/storyboards/$id" params={{ id: project.id }} className="text-sm font-medium underline">
          Kembali ke editor
        </Link>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <Flag label="Show scene number" checked={showNumber} onChange={setShowNumber} />
        <Flag label="Show scene title" checked={showTitle} onChange={setShowTitle} />
      </div>
      <div className={`grid gap-2 ${columns}`}>
        {project.scenes.map((scene, index) => (
          <Link
            key={scene.id}
            to="/storyboards/$id"
            params={{ id: project.id }}
            hash={`scene-${scene.id}`}
            className="overflow-hidden rounded-md border border-line bg-surface"
          >
            <div className={`bg-bg ${aspectFrameClass(project.aspect)}`}>
              {scene.imageDataUrl ? (
                <img src={scene.imageDataUrl} alt="" className="h-full w-full object-contain" />
              ) : (
                <div className="flex h-full items-center justify-center text-xs text-muted">Belum ada gambar</div>
              )}
            </div>
            {showNumber || showTitle ? (
              <p className="px-2 py-2 text-xs leading-snug">
                {showNumber ? <span className="font-medium tabular-nums">{String(index + 1).padStart(2, "0")} </span> : null}
                {showTitle ? scene.title : null}
              </p>
            ) : null}
          </Link>
        ))}
      </div>
    </div>
  );
}
