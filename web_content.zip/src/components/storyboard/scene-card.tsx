import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, TextArea, TextInput } from "@/components/ui/field";
import { downloadDataUrl } from "@/lib/storyboard/download";
import { aspectFrameClass } from "@/lib/storyboard/prompts";
import type { Aspect, Scene, SceneDraft } from "@/lib/storyboard/types";

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      variant="secondary"
      className="w-full"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
        } catch {
          const area = document.createElement("textarea");
          area.value = text;
          document.body.appendChild(area);
          area.select();
          document.execCommand("copy");
          area.remove();
        }
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1600);
      }}
    >
      {copied ? "Copied!" : label}
    </Button>
  );
}

export function SceneCard({
  index,
  scene,
  aspect,
  busy,
  onPrompt,
  onGenerate,
  onSaveDraft,
}: {
  index: number;
  scene: Scene;
  aspect: Aspect;
  busy: boolean;
  onPrompt: (id: string, prompt: string) => void;
  onGenerate: (id: string) => void;
  onSaveDraft: (id: string, draft: SceneDraft) => void;
}) {
  const [editingPrompt, setEditingPrompt] = useState(false);
  const [prompt, setPrompt] = useState(scene.imagePrompt);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<SceneDraft>(scene);

  useEffect(() => {
    if (!editingPrompt) setPrompt(scene.imagePrompt);
  }, [scene.imagePrompt, editingPrompt]);

  useEffect(() => {
    if (!open) setDraft(scene);
  }, [scene, open]);

  const number = String(index + 1).padStart(2, "0");

  return (
    <article id={`scene-${scene.id}`} className="grid gap-3 rounded-xl border border-line bg-surface p-4">
      <header className="grid gap-1">
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Scene {number}</p>
        <h3 className="font-display text-2xl leading-tight font-medium tracking-tight">{scene.title}</h3>
        <p className="text-sm text-muted">{scene.description}</p>
      </header>
      <div className={`overflow-hidden rounded-md bg-bg ${aspectFrameClass(aspect)}`}>
        {scene.imageDataUrl ? (
          <img src={scene.imageDataUrl} alt={scene.title} className="h-full w-full object-contain" />
        ) : (
          <div className="flex h-full items-center justify-center px-4 text-center text-sm text-muted">
            {scene.status === "generating" ? "Membuat gambar scene ini." : scene.status === "queued" ? "Menunggu giliran." : "Gambar muncul di sini."}
          </div>
        )}
      </div>
      {scene.error ? <p className="text-sm text-danger">{scene.error}</p> : null}

      <div className="grid gap-2">
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Image prompt</p>
        {editingPrompt ? (
          <TextArea value={prompt} onChange={(event) => setPrompt(event.target.value)} rows={8} />
        ) : (
          <p className="max-h-48 overflow-y-auto text-sm whitespace-pre-wrap text-ink">{scene.imagePrompt}</p>
        )}
        <CopyButton text={editingPrompt ? prompt : scene.imagePrompt} label="Copy prompt" />
      </div>

      <div className="grid gap-2">
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Image-to-video prompt</p>
        <p className="max-h-48 overflow-y-auto text-sm whitespace-pre-wrap text-ink">{scene.videoPrompt}</p>
        <CopyButton text={scene.videoPrompt} label="Copy video prompt" />
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <Button
          variant="secondary"
          disabled={busy}
          onClick={() => {
            if (editingPrompt) onPrompt(scene.id, prompt);
            onGenerate(scene.id);
          }}
        >
          Regenerate scene
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            if (editingPrompt) {
              onPrompt(scene.id, prompt);
              setEditingPrompt(false);
            } else {
              setEditingPrompt(true);
            }
          }}
        >
          {editingPrompt ? "Simpan prompt" : "Edit prompt"}
        </Button>
        {editingPrompt ? (
          <Button
            disabled={busy}
            onClick={() => {
              onPrompt(scene.id, prompt);
              setEditingPrompt(false);
              onGenerate(scene.id);
            }}
          >
            Generate scene
          </Button>
        ) : null}
        <Button variant="secondary" onClick={() => setOpen(true)}>
          Edit scene
        </Button>
        <Button
          variant="secondary"
          disabled={!scene.imageDataUrl}
          onClick={() => {
            if (scene.imageDataUrl) void downloadDataUrl(scene.imageDataUrl, `scene-${number}.jpg`);
          }}
        >
          Download image
        </Button>
      </div>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
          <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-[92dvh] overflow-y-auto rounded-t-xl bg-surface p-4 sm:inset-x-auto sm:top-1/2 sm:bottom-auto sm:left-1/2 sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-xl">
            <div className="mb-4 flex items-start justify-between gap-3">
              <Dialog.Title className="font-display text-2xl font-medium tracking-tight">Edit scene</Dialog.Title>
              <Dialog.Close className="inline-flex size-11 items-center justify-center rounded-md" aria-label="Tutup">
                <X className="size-4" />
              </Dialog.Close>
            </div>
            <div className="grid gap-3">
              <Field label="Scene title">
                <TextInput value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} />
              </Field>
              <Field label="Scene description">
                <TextArea value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} />
              </Field>
              <Field label="Camera angle">
                <TextInput value={draft.cameraAngle} onChange={(event) => setDraft({ ...draft, cameraAngle: event.target.value })} />
              </Field>
              <Field label="Camera distance">
                <TextInput value={draft.cameraDistance} onChange={(event) => setDraft({ ...draft, cameraDistance: event.target.value })} />
              </Field>
              <Field label="Lighting">
                <TextInput value={draft.lighting} onChange={(event) => setDraft({ ...draft, lighting: event.target.value })} />
              </Field>
              <Field label="Background">
                <TextArea value={draft.background} onChange={(event) => setDraft({ ...draft, background: event.target.value })} />
              </Field>
              <Field label="Props">
                <TextArea value={draft.props} onChange={(event) => setDraft({ ...draft, props: event.target.value })} />
              </Field>
              <Field label="Human interaction">
                <TextArea
                  value={draft.humanInteraction}
                  onChange={(event) => setDraft({ ...draft, humanInteraction: event.target.value })}
                />
              </Field>
              <Field label="Mood">
                <TextInput value={draft.mood} onChange={(event) => setDraft({ ...draft, mood: event.target.value })} />
              </Field>
              <p className="text-sm text-muted">Menyimpan akan menyusun ulang image prompt dan video prompt.</p>
              <Button
                variant="secondary"
                onClick={() => {
                  onSaveDraft(scene.id, draft);
                  setOpen(false);
                }}
              >
                Simpan
              </Button>
              <Button
                disabled={busy}
                onClick={() => {
                  onSaveDraft(scene.id, draft);
                  setOpen(false);
                  onGenerate(scene.id);
                }}
              >
                Generate scene
              </Button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </article>
  );
}
