import { useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import * as Switch from "@radix-ui/react-switch";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, SelectInput, TextArea, TextInput } from "@/components/ui/field";
import { SceneCard } from "@/components/storyboard/scene-card";
import { downloadScenesZip } from "@/lib/storyboard/download";
import { runFullGenerate, runSceneGenerate } from "@/lib/storyboard/generate";
import { fileToStoredImage, isAllowedImage } from "@/lib/storyboard/images";
import { CAMPAIGNS, CATEGORIES, STYLES } from "@/lib/storyboard/options";
import { rebuildScenePrompts } from "@/lib/storyboard/prompts";
import { useStory } from "@/lib/storyboard/store";
import type { Aspect, Project, SceneDraft } from "@/lib/storyboard/types";
import { SCENE_COUNTS } from "@/lib/storyboard/types";

export function Editor({ project }: { project: Project }) {
  const patch = useStory((state) => state.patch);
  const remove = useStory((state) => state.remove);
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const navigate = useNavigate();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmAll, setConfirmAll] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const busy = project.phase === "planning" || project.phase === "generating";
  const hasImages = project.scenes.some((scene) => scene.imageDataUrl);

  function update(recipe: (current: Project) => Project, flush = false) {
    patch(project.id, recipe, flush);
  }

  async function addFiles(list: FileList | File[]) {
    const files = Array.from(list);
    const room = 10 - project.refs.length;
    if (room <= 0) {
      setUploadError("Maksimal 10 foto.");
      return;
    }
    const accepted = files.filter(isAllowedImage).slice(0, room);
    if (!accepted.length) {
      setUploadError("Hanya JPG, PNG, atau WEBP.");
      return;
    }
    if (accepted.length < files.length) setUploadError("Sebagian file dilewati. Hanya JPG, PNG, WEBP, maksimal 10.");
    else setUploadError(null);
    try {
      const next: { id: string; name: string; dataUrl: string }[] = [];
      for (const file of accepted) {
        if (file.size > 20_000_000) continue;
        const dataUrl = await fileToStoredImage(file);
        next.push({ id: crypto.randomUUID(), name: file.name, dataUrl });
      }
      update((current) => ({ ...current, refs: [...current.refs, ...next].slice(0, 10) }), true);
    } catch {
      setUploadError("Foto tidak bisa dibaca.");
    }
  }

  function move(from: number, to: number) {
    if (to < 0 || to >= project.refs.length || from === to) return;
    update((current) => {
      const refs = current.refs.slice();
      const [item] = refs.splice(from, 1);
      if (!item) return current;
      refs.splice(to, 0, item);
      return { ...current, refs };
    }, true);
  }

  function saveDraft(sceneId: string, draft: SceneDraft) {
    update((current) => {
      const scenes = current.scenes.map((scene) => {
        if (scene.id !== sceneId) return scene;
        const blob = `${draft.humanInteraction} ${draft.description}`.toLowerCase();
        let motion = scene.motion;
        if (/drawer/.test(blob)) motion = "A hand opens one existing drawer slightly, once. The product stays rigid.";
        else if (/lid|flap|tutup/.test(blob)) motion = "A hand lifts the existing lid slowly once. The product stays rigid.";
        else if (/no person|product alone|no hand/.test(blob)) motion = "slow camera push-in, background stable";
        else if (/hand|touch|finger/.test(blob)) motion = "one simple hand movement, product geometry frozen";
        return rebuildScenePrompts(current, { ...scene, ...draft, motion });
      });
      return { ...current, scenes };
    }, true);
  }

  function savePrompt(sceneId: string, imagePrompt: string) {
    update(
      (current) => ({
        ...current,
        scenes: current.scenes.map((scene) => (scene.id === sceneId ? { ...scene, imagePrompt } : scene)),
      }),
      true,
    );
  }

  const countDiffers = project.scenes.length > 0 && project.scenes.length !== project.sceneCount;

  return (
    <div className="grid gap-4">
      <div className="grid gap-2">
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Create storyboard</p>
        <TextInput
          aria-label="Nama storyboard"
          value={project.name}
          onChange={(event) => update((current) => ({ ...current, name: event.target.value }))}
          className="font-display text-2xl font-medium"
        />
      </div>

      <section className="grid gap-4 rounded-xl border border-line bg-surface p-4">
        <div>
          <h2 className="font-display text-2xl font-medium tracking-tight">Product reference</h2>
          <p className="mt-1 text-sm text-muted">
            1–10 foto. Semua dianggap satu produk yang sama: depan, samping, belakang, atau saat terbuka.
          </p>
        </div>
        <div
          className="grid gap-3 rounded-lg border border-dashed border-line bg-bg p-4"
          onDragOver={(event) => event.preventDefault()}
          onDrop={(event) => {
            event.preventDefault();
            if (event.dataTransfer.files.length) void addFiles(event.dataTransfer.files);
          }}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            className="sr-only"
            onChange={(event) => {
              if (event.target.files) void addFiles(event.target.files);
              event.target.value = "";
            }}
          />
          <Button variant="secondary" onClick={() => inputRef.current?.click()} disabled={project.refs.length >= 10}>
            Tambah foto
          </Button>
          <p className="text-sm text-muted">{project.refs.length} / 10 · JPG, PNG, WEBP</p>
          {uploadError ? <p className="text-sm text-danger">{uploadError}</p> : null}
          {project.refs.length ? (
            <ul className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {project.refs.map((ref, index) => (
                <li
                  key={ref.id}
                  className="overflow-hidden rounded-md border border-line bg-surface"
                  draggable
                  onDragStart={() => setDragIndex(index)}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={() => {
                    if (dragIndex !== null) move(dragIndex, index);
                    setDragIndex(null);
                  }}
                >
                  <div className="frame-1-1 bg-bg">
                    <img src={ref.dataUrl} alt="" className="h-full w-full object-contain" />
                  </div>
                  <div className="flex items-center justify-between gap-1 p-1">
                    <span className="px-1 text-xs tabular-nums text-muted">{index + 1}</span>
                    <div className="flex">
                      <button
                        type="button"
                        className="inline-flex size-11 items-center justify-center"
                        aria-label="Pindah ke kiri"
                        onClick={() => move(index, index - 1)}
                      >
                        <ChevronLeft className="size-4" />
                      </button>
                      <button
                        type="button"
                        className="inline-flex size-11 items-center justify-center"
                        aria-label="Pindah ke kanan"
                        onClick={() => move(index, index + 1)}
                      >
                        <ChevronRight className="size-4" />
                      </button>
                      <button
                        type="button"
                        className="inline-flex size-11 items-center justify-center"
                        aria-label="Hapus foto"
                        onClick={() =>
                          update((current) => ({ ...current, refs: current.refs.filter((item) => item.id !== ref.id) }), true)
                        }
                      >
                        <X className="size-4" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted">Tarik foto ke sini atau tambah dari galeri.</p>
          )}
        </div>
      </section>

      <section className="grid gap-4 rounded-xl border border-line bg-surface p-4">
        <div>
          <h2 className="font-display text-2xl font-medium tracking-tight">Product & story</h2>
          <p className="mt-1 text-sm text-muted">Kunci produk menyala supaya bentuknya tidak berubah antar-scene.</p>
        </div>
        <div className="flex min-h-11 items-center justify-between gap-4 rounded-md border border-line bg-bg px-3 py-2">
          <div>
            <p className="text-sm font-medium">Product consistency lock</p>
            <p className="text-sm text-muted">Default aktif. Hanya background, cahaya, kamera, properti, dan interaksi yang berubah.</p>
          </div>
          <Switch.Root
            checked={project.consistencyLock}
            onCheckedChange={(checked) => update((current) => ({ ...current, consistencyLock: checked }))}
            aria-label="Product consistency lock"
            className="relative h-7 w-12 shrink-0 rounded-full bg-faint data-[state=checked]:bg-ink"
          >
            <Switch.Thumb className="block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" />
          </Switch.Root>
        </div>
        <Field label="Product category">
          <SelectInput
            value={project.category}
            onChange={(event) => update((current) => ({ ...current, category: event.target.value }))}
          >
            {CATEGORIES.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
        {project.category === "Custom" ? (
          <Field label="Describe your product">
            <TextInput
              value={project.customCategory}
              onChange={(event) => update((current) => ({ ...current, customCategory: event.target.value }))}
              placeholder="Hardbox pohon Natal, dua laci"
            />
          </Field>
        ) : null}
        <Field label="Campaign / occasion">
          <SelectInput
            value={project.campaign}
            onChange={(event) => update((current) => ({ ...current, campaign: event.target.value }))}
          >
            {CAMPAIGNS.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
        {project.campaign === "Custom" ? (
          <Field label="Describe the occasion">
            <TextInput
              value={project.customCampaign}
              onChange={(event) => update((current) => ({ ...current, customCampaign: event.target.value }))}
            />
          </Field>
        ) : null}
        <Field label="What story do you want?">
          <TextArea
            value={project.story}
            maxLength={2000}
            placeholder="Buat cerita tentang hardbox sebagai hadiah Natal yang elegan dan berkesan."
            onChange={(event) => update((current) => ({ ...current, story: event.target.value }))}
          />
        </Field>
        <fieldset className="grid gap-2">
          <legend className="text-sm font-medium">Number of scenes</legend>
          <div className="flex flex-wrap gap-2">
            {SCENE_COUNTS.map((count) => (
              <button
                key={count}
                type="button"
                onClick={() => update((current) => ({ ...current, sceneCount: count }))}
                className={`inline-flex size-11 items-center justify-center rounded-md text-sm font-medium ${
                  project.sceneCount === count ? "bg-accent text-accent-fg" : "border border-line bg-bg"
                }`}
              >
                {count}
              </button>
            ))}
          </div>
        </fieldset>
        <Field label="Photography style" hint={project.style === "Natural Smartphone" ? "Terlihat seperti foto smartphone: cahaya natural, grain halus, tidak seperti render." : undefined}>
          <SelectInput value={project.style} onChange={(event) => update((current) => ({ ...current, style: event.target.value }))}>
            {STYLES.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
        {project.style === "Custom" ? (
          <Field label="Describe the photo style">
            <TextArea
              value={project.customStyle}
              onChange={(event) => update((current) => ({ ...current, customStyle: event.target.value }))}
            />
          </Field>
        ) : null}
        <Field label="Aspect ratio" hint="Berlaku untuk semua scene. Tidak ada pilihan resolusi.">
          <SelectInput
            value={project.aspect}
            onChange={(event) => update((current) => ({ ...current, aspect: event.target.value as Aspect }))}
          >
            {(["1:1", "4:5", "9:16", "16:9"] as Aspect[]).map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
      </section>

      <section className="grid gap-3 rounded-xl border border-line bg-surface p-4">
        <Button
          className="min-h-14 w-full text-base"
          disabled={busy || project.refs.length === 0}
          onClick={() => {
            if (hasImages && !confirmAll) {
              setConfirmAll(true);
              return;
            }
            setConfirmAll(false);
            void runFullGenerate(project.id);
          }}
        >
          {busy ? project.statusNote || "Menyusun storyboard" : confirmAll ? "Buat ulang semua scene" : "Generate storyboard"}
        </Button>
        {project.refs.length === 0 ? <p className="text-sm text-muted">Upload minimal satu foto produk.</p> : null}
        {confirmAll ? (
          <button type="button" className="text-sm text-muted underline" onClick={() => setConfirmAll(false)}>
            Batalkan
          </button>
        ) : null}
        {countDiffers ? (
          <p className="text-sm text-muted">
            Form memakai {project.sceneCount} scene, storyboard saat ini {project.scenes.length}. Generate akan menyusun ulang semuanya.
          </p>
        ) : null}
        {project.planError ? <p className="text-sm text-muted">{project.planError}</p> : null}
        <p className="text-sm text-muted">Satu storyboard membuat satu gambar untuk setiap scene. Foto referensi ikut terkirim saat generate.</p>
      </section>

      {project.profile ? (
        <section className="grid gap-2 rounded-xl border border-line bg-surface p-4">
          <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Product consistency profile</h2>
          <p className="text-sm whitespace-pre-wrap">{project.profile}</p>
        </section>
      ) : null}

      {project.scenes.length ? (
        <section className="grid gap-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 className="font-display text-3xl font-medium tracking-tight">Your storyboard</h2>
            <div className="flex flex-wrap gap-2">
              <Link
                to="/storyboards/$id/preview"
                params={{ id: project.id }}
                className="inline-flex min-h-11 items-center rounded-md border border-line bg-surface px-4 text-sm font-medium"
              >
                Storyboard preview
              </Link>
              <Button
                variant="secondary"
                disabled={!hasImages}
                onClick={() => void downloadScenesZip(project.scenes, `${slug(project.name)}.zip`)}
              >
                Download all
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  if (!confirmDelete) {
                    setConfirmDelete(true);
                    return;
                  }
                  remove(project.id);
                  void navigate({ to: "/storyboards" });
                }}
              >
                {confirmDelete ? "Ya, hapus" : "Hapus"}
              </Button>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {project.scenes.map((scene, index) => (
              <SceneCard
                key={scene.id}
                index={index}
                scene={scene}
                aspect={project.aspect}
                busy={busy || scene.status === "generating"}
                onPrompt={savePrompt}
                onGenerate={(id) => {
                  void runSceneGenerate(project.id, id);
                }}
                onSaveDraft={saveDraft}
              />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function slug(name: string) {
  const clean = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  return clean || "storyboard";
}
