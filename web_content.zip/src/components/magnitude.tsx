const STEPS = [
  { mag: "−1.5", label: "Sirius", size: "size-5" },
  { mag: "0", label: "Vega", size: "size-4" },
  { mag: "1", label: "Spica", size: "size-3.5" },
  { mag: "2", label: "Polaris", size: "size-2.5" },
  { mag: "3", label: "Megrez's neighbors", size: "size-2" },
  { mag: "4", label: "City limit", size: "size-1.5" },
];

export function MagnitudeLab() {
  return (
    <figure className="rounded-2xl border border-line bg-surface px-4 py-5">
      <figcaption className="text-xs uppercase tracking-widest text-gold">Brightness, not size</figcaption>
      <p className="mt-2 text-sm text-muted">
        Smaller magnitude, more light. Dots here are only a guide — stars are points, and the scale is logarithmic.
      </p>
      <ul className="mt-5 grid grid-cols-3 gap-4 sm:grid-cols-6">
        {STEPS.map((s) => (
          <li key={s.mag} className="flex flex-col items-center gap-2 text-center">
            <span className={`block rounded-full bg-fg ${s.size}`} />
            <span className="font-display text-lg tabular-nums text-fg">{s.mag}</span>
            <span className="text-xs text-faint">{s.label}</span>
          </li>
        ))}
      </ul>
    </figure>
  );
}
