import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LandlordPayment } from '../types';
import { calculateProRataRentForMonth, getLandlordFinancialSummary } from '../utils/calculations';
import { formatCurrency, formatNumber, formatDateBengali, getRoleTypeBadge } from '../utils/formatters';
import { 
  Home, 
  Plus, 
  Settings, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  Edit, 
  Printer, 
  User, 
  Phone, 
  MapPin, 
  FileCheck,
  X
} from 'lucide-react';

export const LandlordView: React.FC = () => {
  const { 
    labours, 
    messCollections, 
    roomOwnerConfig, 
    landlordPayments, 
    updateRoomOwnerConfig, 
    addLandlordPayment, 
    updateLandlordPayment, 
    deleteLandlordPayment 
  } = useApp();

  // Modals
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [editingPayment, setEditingPayment] = useState<LandlordPayment | null>(null);

  // Installment payment form
  const [paymentForm, setPaymentForm] = useState<{
    date: string;
    amount: number;
    forMonth: string;
    paymentMethod: 'cash' | 'bank' | 'upi' | 'cheque';
    receiptNo: string;
    note: string;
  }>({
    date: new Date().toISOString().slice(0, 10),
    amount: 3000,
    forMonth: roomOwnerConfig.billingMonth,
    paymentMethod: 'cash',
    receiptNo: '',
    note: ''
  });

  // Landlord Config Form
  const [configForm, setConfigForm] = useState({
    ownerName: roomOwnerConfig.ownerName,
    ownerPhone: roomOwnerConfig.ownerPhone,
    propertyAddress: roomOwnerConfig.propertyAddress,
    totalRooms: roomOwnerConfig.totalRooms,
    perHeadMonthlyRate: roomOwnerConfig.perHeadMonthlyRate,
    billingMonth: roomOwnerConfig.billingMonth
  });

  // Calculate Pro-Rata Rent
  const proRataData = calculateProRataRentForMonth(labours, roomOwnerConfig, messCollections);
  const summary = getLandlordFinancialSummary(
    proRataData.totalCalculatedRent, 
    landlordPayments, 
    roomOwnerConfig.billingMonth
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* বাড়িওয়ালার পরিচিতি ও সেটিং কার্ড */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Home className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-bold text-slate-900">
                বাড়িওয়ালার জন-প্রতি ভাড়া ও পার্ট পেমেন্ট (Pro-Rata Rent Ledger)
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1">
              <span className="flex items-center gap-1 font-medium text-slate-700">
                <User className="w-3.5 h-3.5 text-slate-400" />
                বাড়িওয়ালা: {roomOwnerConfig.ownerName} ({roomOwnerConfig.ownerPhone})
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {roomOwnerConfig.propertyAddress}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                হিসাবের মাস: <strong className="text-slate-800">{roomOwnerConfig.billingMonth}</strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 no-print"
            >
              <Printer className="w-4 h-4" />
              <span>স্টেটমেন্ট প্রিন্ট</span>
            </button>

            <button
              onClick={() => {
                setConfigForm({
                  ownerName: roomOwnerConfig.ownerName,
                  ownerPhone: roomOwnerConfig.ownerPhone,
                  propertyAddress: roomOwnerConfig.propertyAddress,
                  totalRooms: roomOwnerConfig.totalRooms,
                  perHeadMonthlyRate: roomOwnerConfig.perHeadMonthlyRate,
                  billingMonth: roomOwnerConfig.billingMonth
                });
                setShowConfigModal(true);
              }}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 no-print"
            >
              <Settings className="w-4 h-4" />
              <span>রেট ও সেটিংস পরিবর্তন</span>
            </button>
          </div>
        </div>

        {/* বাড়িওয়ালার আর্থিক ৪-কার্ড ওভারভিউ */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
            <span className="block text-[11px] text-slate-500 font-medium">নির্ধারিত জন-প্রতি রেট</span>
            <span className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900">
              {formatCurrency(roomOwnerConfig.perHeadMonthlyRate)}
            </span>
            <span className="block text-[10px] text-slate-400">প্রতি লেবার / মাস</span>
          </div>

          <div className="p-3 bg-amber-50/70 rounded-lg border border-amber-200/70">
            <span className="block text-[11px] text-amber-800 font-medium">প্রোরোটা মোট প্রদেয় ভাড়া</span>
            <span className="text-base sm:text-lg font-bold font-mono tabular-nums text-amber-950">
              {formatCurrency(proRataData.totalCalculatedRent)}
            </span>
            <span className="block text-[10px] text-amber-700">
              {proRataData.totalActiveMessLabours} জন লেবারের দিন গুনে হিসাব
            </span>
          </div>

          <div className="p-3 bg-emerald-50/70 rounded-lg border border-emerald-200/70">
            <span className="block text-[11px] text-emerald-800 font-medium">কিস্তিতে পরিশোধিত ভাড়া</span>
            <span className="text-base sm:text-lg font-bold font-mono tabular-nums text-emerald-700">
              {formatCurrency(summary.totalPaidToLandlord)}
            </span>
            <span className="block text-[10px] text-emerald-600">
              {landlordPayments.length} টি কিস্তিতে দেওয়া হয়েছে
            </span>
          </div>

          <div className="p-3 bg-rose-50/70 rounded-lg border border-rose-200/70">
            <span className="block text-[11px] text-rose-800 font-medium">বাড়িওয়ালার বকেয়া ভাড়া</span>
            <span className="text-base sm:text-lg font-bold font-mono tabular-nums text-rose-700">
              {formatCurrency(summary.pendingLandlordRent)}
            </span>
            <span className="block text-[10px] text-rose-600 font-medium">
              {summary.pendingLandlordRent === 0 ? 'সম্পূর্ণ পরিশোধিত' : 'পেন্ডিং রয়েছে'}
            </span>
          </div>
        </div>
      </div>

      {/* সেকশন ১: প্রোরোটা (Pro-Rata) জন-প্রতি ভাড়ার সম্পূর্ণ তালিকা */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-600" />
              <span>মেসে থাকা লেবারদের জন-প্রতি প্রোরোটা (Pro-Rata) ভাড়ার স্পষ্ট হিসাব</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              সবাই একদিনে মেসে ওঠে না বা থাকে না। তাই প্রত্যেকে চলতি মাসে কতদিন মেসে ছিল সেই অনুযায়ী সঠিক দৈনিক ভাড়া (প্রতিদিন ₹{(roomOwnerConfig.perHeadMonthlyRate / 31).toFixed(1)}) হারে হিসাব করা হয়েছে।
            </p>
          </div>

          <div className="text-xs font-mono bg-slate-100 px-3 py-1.5 rounded-lg text-slate-700 whitespace-nowrap">
            চলতি মাসের মেস সদস্য: {proRataData.totalActiveMessLabours} জন
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
              <tr>
                <th className="py-3 px-4">লেবারের নাম</th>
                <th className="py-3 px-3">কাজের ধরন</th>
                <th className="py-3 px-3">মেসে ওঠার তারিখ</th>
                <th className="py-3 px-3">মেস ছাড়ার তারিখ</th>
                <th className="py-3 px-3 text-right">মাসে থাকার দিন (Active Days)</th>
                <th className="py-3 px-3 text-right">দৈনিক ভাড়া রেট (₹/দিন)</th>
                <th className="py-3 px-4 text-right">প্রোরোটা ভাড়া (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {proRataData.list.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    মেসে কোনো লেবার পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                proRataData.list.map(item => {
                  const badge = getRoleTypeBadge(item.roleType);
                  return (
                    <tr key={item.labourId} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {item.labourName}
                        <div className="text-[11px] font-mono text-slate-400">{item.phone}</div>
                      </td>

                      <td className="py-3 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium border ${badge.badgeClass}`}>
                          {badge.label}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-slate-700 font-mono text-xs whitespace-nowrap">
                        {formatDateBengali(item.stayStartDate)}
                      </td>

                      <td className="py-3 px-3 font-mono text-xs whitespace-nowrap">
                        {item.stayEndDate ? (
                          <span className="text-rose-600 font-semibold">{formatDateBengali(item.stayEndDate)}</span>
                        ) : (
                          <span className="text-emerald-700 font-medium">চলতি রয়েছে</span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                        {formatNumber(item.activeDaysInMonth)} / {item.totalDaysInMonth} দিন
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-600">
                        ₹{item.dailyRate.toFixed(2)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-amber-950 text-sm">
                        {formatCurrency(item.calculatedRent)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            <tfoot className="bg-amber-50/60 border-t-2 border-amber-200 font-semibold text-slate-900">
              <tr>
                <td colSpan={6} className="py-3.5 px-4 text-right text-xs uppercase tracking-wide text-slate-700">
                  বাড়িওয়ালার মোট প্রদেয় ন্যায্য প্রোরোটা ভাড়া:
                </td>
                <td className="py-3.5 px-4 text-right font-mono tabular-nums font-bold text-base text-amber-950">
                  {formatCurrency(proRataData.totalCalculatedRent)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* সেকশন ২: বাড়িওয়ালাকে পার্ট পেমেন্ট বা কিস্তিতে পরিশোধের হিসাব (Installments Ledger) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <span>বাড়িওয়ালাকে কিস্তিতে (Part Payment) পরিশোধের তালিকা</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              বাড়িওয়ালাকে একসঙ্গে পুরো টাকা না দিয়ে বিভিন্ন কিস্তিতে পরিশোধের তারিখ, মাধ্যম ও এডিট করার ব্যবস্থা
            </p>
          </div>

          <button
            onClick={() => {
              setEditingPayment(null);
              setPaymentForm({
                date: new Date().toISOString().slice(0, 10),
                amount: Math.min(3000, summary.pendingLandlordRent || 3000),
                forMonth: roomOwnerConfig.billingMonth,
                paymentMethod: 'cash',
                receiptNo: '',
                note: `কিস্তি #${landlordPayments.length + 1}`
              });
              setShowPaymentModal(true);
            }}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap no-print"
          >
            <Plus className="w-4 h-4" />
            <span>+ কিস্তি পরিশোধ যোগ করুন</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
              <tr>
                <th className="py-3 px-4">তারিখ</th>
                <th className="py-3 px-3">পরিশোধের মাস</th>
                <th className="py-3 px-3">পেমেন্ট মাধ্যম</th>
                <th className="py-3 px-4">মানি রসিদ / বিবরণ</th>
                <th className="py-3 px-4 text-right">পরিশোধিত টাকা (₹)</th>
                <th className="py-3 px-4 text-center no-print">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {landlordPayments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    বাড়িওয়ালাকে এখনো কোনো কিস্তি বা পার্ট পেমেন্ট দেওয়া হয়নি।
                  </td>
                </tr>
              ) : (
                landlordPayments.map(payment => (
                  <tr key={payment.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono text-xs text-slate-700">
                      {formatDateBengali(payment.date)}
                    </td>

                    <td className="py-3 px-3 text-slate-800 font-medium">
                      {payment.forMonth}
                    </td>

                    <td className="py-3 px-3">
                      <span className="inline-block uppercase text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {payment.paymentMethod}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{payment.note || 'কিস্তি পরিশোধ'}</div>
                      {payment.receiptNo && (
                        <div className="text-[11px] font-mono text-slate-500 mt-0.5">রসিদ: {payment.receiptNo}</div>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-emerald-700 text-sm">
                      {formatCurrency(payment.amount)}
                    </td>

                    <td className="py-3 px-4 text-center no-print">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            setEditingPayment(payment);
                            setPaymentForm({
                              date: payment.date,
                              amount: payment.amount,
                              forMonth: payment.forMonth,
                              paymentMethod: payment.paymentMethod,
                              receiptNo: payment.receiptNo || '',
                              note: payment.note || ''
                            });
                            setShowPaymentModal(true);
                          }}
                          className="p-1 text-slate-500 hover:text-amber-700 rounded transition-colors"
                          title="এডিট করুন"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => {
                            if (window.confirm('আপনি কি এই কিস্তির রেকর্ড মুছে ফেলতে চান?')) {
                              deleteLandlordPayment(payment.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          title="মুছুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot className="bg-slate-50 border-t border-slate-200">
              <tr>
                <td colSpan={4} className="py-3 px-4 text-right text-xs font-semibold text-slate-600">
                  মোট পরিশোধিত কিস্তি:
                </td>
                <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-sm text-emerald-700">
                  {formatCurrency(summary.totalPaidToLandlord)}
                </td>
                <td className="no-print"></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* মডাল ১: কিস্তি এন্ট্রি বা এডিট ফরম */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingPayment ? 'কিস্তি পেমেন্ট এডিট করুন' : 'বাড়িওয়ালাকে নতুন কিস্তি পরিশোধ'}
              </h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!paymentForm.amount) return;
                if (editingPayment) {
                  updateLandlordPayment(editingPayment.id, {
                    ...paymentForm,
                    amount: Number(paymentForm.amount)
                  });
                } else {
                  addLandlordPayment({
                    ...paymentForm,
                    amount: Number(paymentForm.amount)
                  });
                }
                setShowPaymentModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                <input
                  type="number"
                  required
                  min="100"
                  step="100"
                  value={paymentForm.amount}
                  onChange={e => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-emerald-300 rounded-lg font-mono font-bold text-base text-emerald-800 bg-emerald-50/40"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                  <input
                    type="date"
                    required
                    value={paymentForm.date}
                    onChange={e => setPaymentForm({ ...paymentForm, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">কোন মাসের জন্য</label>
                  <input
                    type="text"
                    required
                    placeholder="2025-03"
                    value={paymentForm.forMonth}
                    onChange={e => setPaymentForm({ ...paymentForm, forMonth: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={paymentForm.paymentMethod}
                    onChange={e => setPaymentForm({ ...paymentForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="cash">নগদ (Cash)</option>
                    <option value="upi">UPI / অনলাইন</option>
                    <option value="bank">ব্যাংক ট্রান্সফার</option>
                    <option value="cheque">চেক (Cheque)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">মানি রসিদ নং (যদি থাকে)</label>
                  <input
                    type="text"
                    placeholder="যেমন: RCPT-004"
                    value={paymentForm.receiptNo}
                    onChange={e => setPaymentForm({ ...paymentForm, receiptNo: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">মন্তব্য / বিবরণ</label>
                <input
                  type="text"
                  placeholder="যেমন: মার্চ মাসের ২য় কিস্তি ভাড়া"
                  value={paymentForm.note}
                  onChange={e => setPaymentForm({ ...paymentForm, note: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium"
                >
                  {editingPayment ? 'আপডেট সংরক্ষণ' : 'কিস্তি নিশ্চিত করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ২: বাড়িওয়ালার প্রোফাইল ও জন-প্রতি রেট কনফিগারেশন */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">বাড়িওয়ালার প্রোফাইল ও ভাড়ার রেট</h3>
              <button onClick={() => setShowConfigModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                updateRoomOwnerConfig({
                  ownerName: configForm.ownerName,
                  ownerPhone: configForm.ownerPhone,
                  propertyAddress: configForm.propertyAddress,
                  totalRooms: Number(configForm.totalRooms),
                  perHeadMonthlyRate: Number(configForm.perHeadMonthlyRate),
                  billingMonth: configForm.billingMonth
                });
                setShowConfigModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">বাড়িওয়ালার নাম *</label>
                <input
                  type="text"
                  required
                  value={configForm.ownerName}
                  onChange={e => setConfigForm({ ...configForm, ownerName: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ফোন নম্বর</label>
                  <input
                    type="text"
                    value={configForm.ownerPhone}
                    onChange={e => setConfigForm({ ...configForm, ownerPhone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">মোট রুম সংখ্যা</label>
                  <input
                    type="number"
                    min="1"
                    value={configForm.totalRooms}
                    onChange={e => setConfigForm({ ...configForm, totalRooms: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">মেস বিল্ডিং ঠিকানা</label>
                <input
                  type="text"
                  value={configForm.propertyAddress}
                  onChange={e => setConfigForm({ ...configForm, propertyAddress: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              {/* প্রতি জন-প্রতি মাসিক রেট */}
              <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                <label className="block font-bold text-amber-950 mb-1">
                  জন-প্রতি মাসিক ভাড়া রেট (Per Head Rate ₹) *
                </label>
                <input
                  type="number"
                  required
                  min="200"
                  step="50"
                  value={configForm.perHeadMonthlyRate}
                  onChange={e => setConfigForm({ ...configForm, perHeadMonthlyRate: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-amber-300 rounded-lg font-mono font-bold text-base bg-white"
                />
                <span className="block text-[11px] text-amber-800 mt-1">
                  বাড়িওয়ালা প্রতি লেবারের জন্য মাসে এই পরিমাণ টাকা ধার্য করেন।
                </span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">হিসাবের চলতি মাস (YYYY-MM)</label>
                <input
                  type="month"
                  value={configForm.billingMonth}
                  onChange={e => setConfigForm({ ...configForm, billingMonth: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowConfigModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  সেটিংস সেভ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
