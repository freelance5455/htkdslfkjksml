"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { clearToken, getToken } from "@/lib/client-session";

/**
 * Se il browser ha ancora un token salvato (es. i cookie sono bloccati) riparte
 * direttamente dalla dashboard invece di mostrare di nuovo la pagina iniziale.
 */
export function SessionResume() {
  const router = useRouter();

  useEffect(() => {
    const token = getToken();
    if (!token) return;

    let cancelled = false;

    async function resume() {
      try {
        const response = await fetch("/api/squad", {
          headers: { "x-marvel-session": token as string },
          cache: "no-store",
        });
        if (cancelled) return;
        if (response.ok) {
          router.replace("/squad");
        } else if (response.status === 401) {
          clearToken();
        }
      } catch {
        // offline: restiamo sulla pagina iniziale
      }
    }

    void resume();
    return () => {
      cancelled = true;
    };
  }, [router]);

  return null;
}
