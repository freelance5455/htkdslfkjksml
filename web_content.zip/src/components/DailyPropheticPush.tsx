import React, { useState, useEffect } from 'react';
import { Bell, BellRing, Sparkles, ShieldCheck, Check } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';

interface DailyPropheticPushProps {
  onToggle?: (enabled: boolean) => void;
}

export const DailyPropheticPush: React.FC<DailyPropheticPushProps> = ({ onToggle }) => {
  const profile = offlineCache.getProfile();
  const [enabled, setEnabled] = useState<boolean>(profile.liveNotificationEnabled ?? true);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleTogglePush = async () => {
    if (!enabled) {
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          setEnabled(true);
          offlineCache.toggleLiveNotification();
          setStatusMsg('✓ Daily Prophetic Push notifications enabled successfully!');
          new Notification('JUHNKRIX MUSIKA Prophetic Alert', {
            body: 'Your spirit is now tuned to receive daily anointed words and breakthrough decrees.',
            icon: '/favicon.ico'
          });
        } else {
          alert('Notification permission was denied by browser settings.');
          return;
        }
      } else {
        alert('Browser Notifications are not supported on this device.');
        return;
      }
    } else {
      setEnabled(false);
      offlineCache.toggleLiveNotification();
      setStatusMsg('Daily Prophetic Push notifications disabled.');
    }
    if (onToggle) onToggle(!enabled);
    setTimeout(() => setStatusMsg(null), 3500);
  };

  const handleTestNotification = () => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('JUHNKRIX MUSIKA - Anointed Word of the Day', {
        body: '“The LORD shall go before you and make your crooked places straight. Your altar shall never lack fire!” - Prophet Juhnkrix Synvagord',
        icon: '/favicon.ico'
      });
      setStatusMsg('✓ Test prophetic notification dispatched!');
      setTimeout(() => setStatusMsg(null), 3000);
    } else {
      alert('Please enable notifications first.');
    }
  };

  return (
    <div className="bg-neutral-900/90 border border-amber-500/30 rounded-2xl p-5 text-white shadow-xl backdrop-blur-xl">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <BellRing className="w-5 h-5 animate-bounce" />
          </div>
          <div>
            <div className="font-bold text-sm text-white flex items-center gap-1.5">
              <span>Daily Prophetic Push Notifications</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-semibold">
                Browser API
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Receive scheduled anointed words, breakthrough alerts, and live sanctuary decrees directly on your device.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleTogglePush}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              enabled
                ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/20'
                : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
            }`}
          >
            {enabled ? <Check className="w-3.5 h-3.5" /> : null}
            {enabled ? 'Notifications Active' : 'Enable Notifications'}
          </button>
          
          {enabled && (
            <button
              onClick={handleTestNotification}
              className="px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-400 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Test Alert
            </button>
          )}
        </div>
      </div>

      {statusMsg && (
        <div className="mt-3 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          <span>{statusMsg}</span>
        </div>
      )}
    </div>
  );
};
