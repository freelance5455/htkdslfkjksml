import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Move, Maximize2, Check, Grid2X2, LayoutTemplate, SlidersHorizontal } from 'lucide-react';
import type { GridArrangement, KitPreset, PadConfig, PadLayoutRect, PadLayoutType } from '../types/octapad';

interface PadSurfaceProps {
  kit: KitPreset;
  pads: PadConfig[];
  editZonesMode: boolean;
  selectedPadIndex: number;
  selectedZoneId: 'primary' | 'secondary';
  activeHits: Record<string, number>;
  loopingZones: Record<string, boolean>;
  onTriggerZone: (padIndex: number, zoneId: 'primary' | 'secondary', velocity: number) => void;
  onReleaseZone: (padIndex: number, zoneId: 'primary' | 'secondary') => void;
  onSelectZone: (padIndex: number, zoneId: 'primary' | 'secondary', openEditor?: boolean) => void;
  onUpdatePad: (padIndex: number, updater: (pad: PadConfig) => PadConfig) => void;
  onUpdateKitMeta: (updater: (kit: KitPreset) => KitPreset) => void;
  onExitEditMode: () => void;
}

type DragAction =
  | {
      type: 'split';
      padIndex: number;
      mode: 'split-v' | 'split-h';
      rect: DOMRect;
    }
  | {
      type: 'move';
      padIndex: number;
      startClientX: number;
      startClientY: number;
      startRect: PadLayoutRect;
      deckRect: DOMRect;
    }
  | {
      type: 'resize';
      padIndex: number;
      startClientX: number;
      startClientY: number;
      startRect: PadLayoutRect;
      deckRect: DOMRect;
    };

export const PadSurface: React.FC<PadSurfaceProps> = ({
  kit,
  pads,
  editZonesMode,
  selectedPadIndex,
  selectedZoneId,
  activeHits,
  loopingZones,
  onTriggerZone,
  onReleaseZone,
  onSelectZone,
  onUpdatePad,
  onUpdateKitMeta,
  onExitEditMode,
}) => {
  const deckRef = useRef<HTMLDivElement>(null);
  const pointerMapRef = useRef<Map<number, { padIndex: number; zoneId: 'primary' | 'secondary' }>>(
    new Map()
  );
  const [dragAction, setDragAction] = useState<DragAction | null>(null);
  const [snapToGrid, setSnapToGrid] = useState(true);

  const computeHitZone = useCallback(
    (
      pad: PadConfig,
      clientX: number,
      clientY: number,
      rect: DOMRect
    ): { zoneId: 'primary' | 'secondary'; velocity: number } | null => {
      const pxFromLeft = clientX - rect.left;
      const pxFromTop = clientY - rect.top;

      // Respect customizable hitbox inset (deadzone border around pad edge)
      if (pad.hitboxInset > 0) {
        if (
          pxFromLeft < pad.hitboxInset ||
          pxFromLeft > rect.width - pad.hitboxInset ||
          pxFromTop < pad.hitboxInset ||
          pxFromTop > rect.height - pad.hitboxInset
        ) {
          return null;
        }
      }

      const relX = Math.max(0, Math.min(1, pxFromLeft / rect.width));
      const relY = Math.max(0, Math.min(1, pxFromTop / rect.height));

      let zoneId: 'primary' | 'secondary' = 'primary';
      if (pad.splitMode === 'split-v') {
        zoneId = relX < pad.splitRatio ? 'primary' : 'secondary';
      } else if (pad.splitMode === 'split-h') {
        zoneId = relY < pad.splitRatio ? 'primary' : 'secondary';
      } else if (pad.splitMode === 'center-rim') {
        const dx = Math.abs(relX - 0.5) * 2;
        const dy = Math.abs(relY - 0.5) * 2;
        const edgeDist = Math.max(dx, dy);
        zoneId = edgeDist >= 1 - pad.rimThickness ? 'secondary' : 'primary';
      }

      let velocity = 1.0;
      if (pad.velocityMode === 'radial') {
        const dx = (relX - 0.5) * 2;
        const dy = (relY - 0.5) * 2;
        const dist = Math.min(1, Math.sqrt(dx * dx + dy * dy));
        velocity = Math.max(0.45, 1.0 - dist * 0.45);
      } else if (pad.velocityMode === 'vertical') {
        velocity = Math.max(0.45, 0.5 + relY * 0.5);
      }

      return { zoneId, velocity };
    },
    []
  );

  const handlePadPointerDown = (
    e: React.PointerEvent<HTMLDivElement>,
    pad: PadConfig
  ) => {
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    const hit = computeHitZone(pad, e.clientX, e.clientY, rect);

    if (editZonesMode) {
      const targetZone = hit?.zoneId ?? 'primary';
      onSelectZone(pad.index, targetZone, false);
      // Audition the zone lightly on tap in edit mode too
      onTriggerZone(pad.index, targetZone, hit?.velocity ?? 0.9);
      return;
    }

    if (!hit) return;

    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore if capture unavailable
    }

    pointerMapRef.current.set(e.pointerId, {
      padIndex: pad.index,
      zoneId: hit.zoneId,
    });
    onTriggerZone(pad.index, hit.zoneId, hit.velocity);
  };

  const handlePadPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const active = pointerMapRef.current.get(e.pointerId);
    if (!active) return;
    pointerMapRef.current.delete(e.pointerId);
    onReleaseZone(active.padIndex, active.zoneId);
  };

  // Global drag handling for split dividers and freeform pad move/resize
  useEffect(() => {
    if (!dragAction) return;

    const handleMove = (e: PointerEvent) => {
      e.preventDefault();
      if (dragAction.type === 'split') {
        const { rect, mode, padIndex } = dragAction;
        const raw =
          mode === 'split-v'
            ? (e.clientX - rect.left) / rect.width
            : (e.clientY - rect.top) / rect.height;
        const clamped = Math.max(0.22, Math.min(0.78, Math.round(raw * 100) / 100));
        onUpdatePad(padIndex, (p) => ({ ...p, splitRatio: clamped }));
      } else if (dragAction.type === 'move') {
        const { startClientX, startClientY, startRect, deckRect, padIndex } = dragAction;
        const dxPct = ((e.clientX - startClientX) / deckRect.width) * 100;
        const dyPct = ((e.clientY - startClientY) / deckRect.height) * 100;
        let nextX = Math.max(0, Math.min(100 - startRect.w, startRect.x + dxPct));
        let nextY = Math.max(0, Math.min(100 - startRect.h, startRect.y + dyPct));
        if (snapToGrid) {
          nextX = Math.round(nextX / 2.5) * 2.5;
          nextY = Math.round(nextY / 2.5) * 2.5;
        }
        onUpdatePad(padIndex, (p) => ({
          ...p,
          layoutRect: { ...p.layoutRect, x: nextX, y: nextY },
        }));
      } else if (dragAction.type === 'resize') {
        const { startClientX, startClientY, startRect, deckRect, padIndex } = dragAction;
        const dxPct = ((e.clientX - startClientX) / deckRect.width) * 100;
        const dyPct = ((e.clientY - startClientY) / deckRect.height) * 100;
        let nextW = Math.max(12, Math.min(100 - startRect.x, startRect.w + dxPct));
        let nextH = Math.max(14, Math.min(100 - startRect.y, startRect.h + dyPct));
        if (snapToGrid) {
          nextW = Math.round(nextW / 2.5) * 2.5;
          nextH = Math.round(nextH / 2.5) * 2.5;
        }
        onUpdatePad(padIndex, (p) => ({
          ...p,
          layoutRect: { ...p.layoutRect, w: nextW, h: nextH },
        }));
      }
    };

    const handleUp = () => setDragAction(null);
    window.addEventListener('pointermove', handleMove, { passive: false });
    window.addEventListener('pointerup', handleUp);
    window.addEventListener('pointercancel', handleUp);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      window.removeEventListener('pointercancel', handleUp);
    };
  }, [dragAction, onUpdatePad, snapToGrid]);

  const setLayoutType = (layoutType: PadLayoutType) => {
    onUpdateKitMeta((k) => ({ ...k, layoutType }));
  };

  const renderPad = (pad: PadConfig) => {
    const primaryKey = `${pad.index}-primary`;
    const secondaryKey = `${pad.index}-secondary`;
    const isPrimaryHit = Boolean(activeHits[primaryKey]);
    const isSecondaryHit = Boolean(activeHits[secondaryKey]);
    const isAnyHit = isPrimaryHit || isSecondaryHit;
    const isPadSelected = editZonesMode && selectedPadIndex === pad.index;
    const isPrimaryLooping = Boolean(loopingZones[primaryKey]);
    const isSecondaryLooping = Boolean(loopingZones[secondaryKey]);

    const primaryZone = pad.zones[0];
    const secondaryZone = pad.zones[1];

    const freeformStyle: React.CSSProperties =
      kit.layoutType === 'freeform'
        ? {
            position: 'absolute',
            left: `${pad.layoutRect.x}%`,
            top: `${pad.layoutRect.y}%`,
            width: `${pad.layoutRect.w}%`,
            height: `${pad.layoutRect.h}%`,
          }
        : {};

    return (
      <div
        key={pad.index}
        onPointerDown={(e) => handlePadPointerDown(e, pad)}
        onPointerUp={handlePadPointerUp}
        onPointerCancel={handlePadPointerUp}
        style={{
          ...freeformStyle,
          borderRadius: `${kit.padRadius}px`,
          transform: isAnyHit ? 'scale(0.985)' : 'scale(1)',
        }}
        className={`touch-pad-surface relative overflow-hidden transition-transform duration-75 cursor-pointer select-none ${
          isAnyHit ? 'octapad-rubber-active' : 'octapad-rubber'
        } ${
          isPadSelected
            ? 'ring-2 ring-cyan-400 ring-offset-2 ring-offset-[#E4E6EB]'
            : ''
        }`}
      >
        {/* Hitbox Inset Deadzone Visualizer (visible in Edit Zones mode) */}
        {editZonesMode && pad.hitboxInset > 0 && (
          <div
            className="pointer-events-none absolute border border-dashed border-amber-400/70 bg-amber-400/5"
            style={{
              inset: `${pad.hitboxInset}px`,
              borderRadius: `${Math.max(4, kit.padRadius - 4)}px`,
            }}
          />
        )}

        {/* SPLIT VERTICAL (Left / Right Zones) */}
        {pad.splitMode === 'split-v' && (
          <>
            <div
              className="pointer-events-none absolute inset-y-0 left-0 transition-opacity duration-100"
              style={{
                width: `${pad.splitRatio * 100}%`,
                backgroundColor: isPrimaryHit ? `${primaryZone.accentColor}2E` : 'transparent',
                boxShadow:
                  isPadSelected && selectedZoneId === 'primary'
                    ? 'inset 0 0 0 2px rgba(34, 211, 238, 0.75)'
                    : undefined,
              }}
            />
            <div
              className="pointer-events-none absolute inset-y-0 right-0 transition-opacity duration-100"
              style={{
                width: `${(1 - pad.splitRatio) * 100}%`,
                backgroundColor: isSecondaryHit ? `${secondaryZone.accentColor}2E` : 'transparent',
                boxShadow:
                  isPadSelected && selectedZoneId === 'secondary'
                    ? 'inset 0 0 0 2px rgba(34, 211, 238, 0.75)'
                    : undefined,
              }}
            />
            {/* Split groove / interactive divider */}
            <div
              className={`absolute inset-y-0 z-10 ${
                editZonesMode
                  ? 'w-5 -ml-2.5 cursor-ew-resize flex items-center justify-center'
                  : 'pointer-events-none w-[1.5px] bg-white/10'
              }`}
              style={{ left: `${pad.splitRatio * 100}%` }}
              onPointerDown={(e) => {
                if (!editZonesMode) return;
                e.stopPropagation();
                const parentRect = e.currentTarget.parentElement?.getBoundingClientRect();
                if (!parentRect) return;
                setDragAction({
                  type: 'split',
                  padIndex: pad.index,
                  mode: 'split-v',
                  rect: parentRect,
                });
              }}
            >
              {editZonesMode && (
                <div className="h-9 w-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
              )}
            </div>
          </>
        )}

        {/* SPLIT HORIZONTAL (Top / Bottom Zones) */}
        {pad.splitMode === 'split-h' && (
          <>
            <div
              className="pointer-events-none absolute inset-x-0 top-0 transition-opacity duration-100"
              style={{
                height: `${pad.splitRatio * 100}%`,
                backgroundColor: isPrimaryHit ? `${primaryZone.accentColor}2E` : 'transparent',
                boxShadow:
                  isPadSelected && selectedZoneId === 'primary'
                    ? 'inset 0 0 0 2px rgba(34, 211, 238, 0.75)'
                    : undefined,
              }}
            />
            <div
              className="pointer-events-none absolute inset-x-0 bottom-0 transition-opacity duration-100"
              style={{
                height: `${(1 - pad.splitRatio) * 100}%`,
                backgroundColor: isSecondaryHit ? `${secondaryZone.accentColor}2E` : 'transparent',
                boxShadow:
                  isPadSelected && selectedZoneId === 'secondary'
                    ? 'inset 0 0 0 2px rgba(34, 211, 238, 0.75)'
                    : undefined,
              }}
            />
            <div
              className={`absolute inset-x-0 z-10 ${
                editZonesMode
                  ? 'h-5 -mt-2.5 cursor-ns-resize flex items-center justify-center'
                  : 'pointer-events-none h-[1.5px] bg-white/10'
              }`}
              style={{ top: `${pad.splitRatio * 100}%` }}
              onPointerDown={(e) => {
                if (!editZonesMode) return;
                e.stopPropagation();
                const parentRect = e.currentTarget.parentElement?.getBoundingClientRect();
                if (!parentRect) return;
                setDragAction({
                  type: 'split',
                  padIndex: pad.index,
                  mode: 'split-h',
                  rect: parentRect,
                });
              }}
            >
              {editZonesMode && (
                <div className="w-9 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
              )}
            </div>
          </>
        )}

        {/* CONCENTRIC CENTER + RIM SHOT ZONE */}
        {pad.splitMode === 'center-rim' && (
          <>
            <div
              className="pointer-events-none absolute inset-0 transition-opacity duration-100"
              style={{
                backgroundColor: isSecondaryHit ? `${secondaryZone.accentColor}30` : 'transparent',
                boxShadow:
                  isPadSelected && selectedZoneId === 'secondary'
                    ? 'inset 0 0 0 3px rgba(34, 211, 238, 0.75)'
                    : undefined,
              }}
            />
            <div
              className="pointer-events-none absolute border transition-colors duration-100"
              style={{
                inset: `${pad.rimThickness * 50}%`,
                borderRadius: `${Math.max(4, kit.padRadius - 4)}px`,
                borderColor:
                  isPadSelected && selectedZoneId === 'primary'
                    ? 'rgba(34, 211, 238, 0.85)'
                    : isPrimaryHit
                      ? primaryZone.accentColor
                      : 'rgba(255, 255, 255, 0.12)',
                backgroundColor: isPrimaryHit ? `${primaryZone.accentColor}2A` : 'rgba(255,255,255,0.015)',
              }}
            />
          </>
        )}

        {/* SINGLE ZONE FLASH OVERLAY */}
        {pad.splitMode === 'single' && isPrimaryHit && (
          <div
            className="pointer-events-none absolute inset-0 transition-opacity duration-100"
            style={{
              background: `radial-gradient(circle at center, ${primaryZone.accentColor}38 0%, ${primaryZone.accentColor}12 70%, transparent 100%)`,
            }}
          />
        )}

        {/* PAD LABELS & METADATA */}
        {(kit.showLabels || kit.showKeyHints || editZonesMode) && (
          <div className="pointer-events-none absolute inset-0 p-2.5 sm:p-3 flex flex-col justify-between">
            <div className="flex items-start justify-between gap-1.5">
              <div className="min-w-0">
                {(kit.showLabels || editZonesMode) && (
                  <p className="text-[11px] sm:text-xs font-semibold text-slate-200 truncate tracking-wide">
                    {primaryZone.label || primaryZone.soundName}
                    {primaryZone.muted && (
                      <span className="ml-1.5 text-[10px] text-rose-400">Muted</span>
                    )}
                  </p>
                )}
                {pad.splitMode !== 'single' && (kit.showLabels || editZonesMode) && (
                  <p className="text-[10px] text-cyan-300/85 truncate mt-0.5">
                    {pad.splitMode === 'center-rim' ? 'Rim: ' : 'Zone B: '}
                    {secondaryZone.label || secondaryZone.soundName}
                  </p>
                )}
              </div>

              {(kit.showKeyHints || editZonesMode) && (
                <span className="font-mono-tabular text-[10px] font-semibold text-slate-400 shrink-0">
                  {editZonesMode ? `P${pad.index + 1}` : pad.keyHint}
                </span>
              )}
            </div>

            <div className="flex items-end justify-between gap-1">
              {editZonesMode ? (
                <span className="text-[10px] font-medium text-slate-400">
                  {pad.splitMode === 'single'
                    ? 'Single Zone'
                    : pad.splitMode === 'split-v'
                      ? `Split ${Math.round(pad.splitRatio * 100)}/${Math.round((1 - pad.splitRatio) * 100)}`
                      : pad.splitMode === 'split-h'
                        ? `Row ${Math.round(pad.splitRatio * 100)}/${Math.round((1 - pad.splitRatio) * 100)}`
                        : `Center + Rim (${Math.round(pad.rimThickness * 100)}%)`}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400/80">
                  {(isPrimaryLooping || isSecondaryLooping) ? 'Loop Active' : ''}
                </span>
              )}

              {editZonesMode && (
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onSelectZone(pad.index, selectedZoneId, true);
                  }}
                  className="pointer-events-auto inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-800/90 hover:bg-cyan-500 hover:text-slate-950 text-[10px] font-semibold text-cyan-300 border border-slate-700 transition-colors"
                >
                  <SlidersHorizontal className="w-3 h-3" />
                  <span>Edit</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* FREEFORM MOVE & RESIZE HANDLES */}
        {editZonesMode && kit.layoutType === 'freeform' && (
          <>
            <button
              type="button"
              title="Drag to move touch zone"
              onPointerDown={(e) => {
                e.stopPropagation();
                const deckRect = deckRef.current?.getBoundingClientRect();
                if (!deckRect) return;
                setDragAction({
                  type: 'move',
                  padIndex: pad.index,
                  startClientX: e.clientX,
                  startClientY: e.clientY,
                  startRect: { ...pad.layoutRect },
                  deckRect,
                });
              }}
              className="absolute top-1.5 right-8 z-20 p-1.5 rounded bg-slate-900/85 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 cursor-grab active:cursor-grabbing border border-slate-700"
            >
              <Move className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              title="Drag to resize touch zone"
              onPointerDown={(e) => {
                e.stopPropagation();
                const deckRect = deckRef.current?.getBoundingClientRect();
                if (!deckRect) return;
                setDragAction({
                  type: 'resize',
                  padIndex: pad.index,
                  startClientX: e.clientX,
                  startClientY: e.clientY,
                  startRect: { ...pad.layoutRect },
                  deckRect,
                });
              }}
              className="absolute bottom-1.5 right-1.5 z-20 p-1.5 rounded bg-slate-900/85 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 cursor-nwse-resize border border-slate-700"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </>
        )}
      </div>
    );
  };

  const gridArrangement: GridArrangement = kit.gridArrangement ?? 'auto';
  const gridTemplateClass =
    gridArrangement === '2x4'
      ? 'grid-cols-2 grid-rows-4'
      : gridArrangement === '4x2'
        ? 'grid-cols-4 grid-rows-2'
        : 'grid-cols-2 grid-rows-4 md:grid-cols-4 md:grid-rows-2';

  const cycleGridArrangement = () => {
    const next: GridArrangement =
      gridArrangement === 'auto' ? '2x4' : gridArrangement === '2x4' ? '4x2' : 'auto';
    onUpdateKitMeta((k) => ({ ...k, gridArrangement: next }));
  };

  return (
    <div className="octapad-chassis relative flex-1 h-full flex flex-col overflow-hidden p-1.5 sm:p-2">
      {/* Zone Editor Top Bar (only shown when Edit Zones Mode is active) */}
      {editZonesMode && (
        <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-lg bg-[#131720] text-slate-100 border border-slate-800 shadow-sm shrink-0">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-display font-bold text-cyan-400 tracking-wide">
              TOUCH ZONE EDITOR
            </span>
            <span className="text-slate-500 hidden sm:inline">·</span>
            <span className="text-slate-300 hidden sm:inline">
              Tap a pad zone to customize split, hitbox, or sound
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center bg-[#0B0E14] rounded-md p-0.5 border border-slate-800">
              <button
                type="button"
                onClick={() => setLayoutType('grid')}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
                  kit.layoutType === 'grid'
                    ? 'bg-cyan-400 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Grid2X2 className="w-3.5 h-3.5" />
                <span>Grid</span>
              </button>
              <button
                type="button"
                onClick={() => setLayoutType('freeform')}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
                  kit.layoutType === 'freeform'
                    ? 'bg-cyan-400 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LayoutTemplate className="w-3.5 h-3.5" />
                <span>Freeform</span>
              </button>
            </div>

            {kit.layoutType === 'grid' && (
              <button
                type="button"
                onClick={cycleGridArrangement}
                className="px-2.5 py-1.5 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition-colors cursor-pointer"
              >
                {gridArrangement === 'auto'
                  ? 'Grid: Auto'
                  : gridArrangement === '2x4'
                    ? 'Grid: 2×4'
                    : 'Grid: 4×2'}
              </button>
            )}

            {kit.layoutType === 'freeform' && (
              <button
                type="button"
                onClick={() => setSnapToGrid((s) => !s)}
                className={`px-2.5 py-1.5 rounded text-xs font-medium border transition-colors ${
                  snapToGrid
                    ? 'bg-slate-800 text-cyan-300 border-cyan-500/50'
                    : 'bg-slate-900 text-slate-400 border-slate-700'
                }`}
              >
                Snap {snapToGrid ? 'On' : 'Off'}
              </button>
            )}

            <button
              type="button"
              onClick={() => onSelectZone(selectedPadIndex, selectedZoneId, true)}
              className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors"
            >
              Pad {selectedPadIndex + 1} Settings
            </button>

            <button
              type="button"
              onClick={onExitEditMode}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-bold transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Done</span>
            </button>
          </div>
        </div>
      )}

      {/* Main 8-Pad Playing Area */}
      <div
        ref={deckRef}
        className={
          kit.layoutType === 'freeform'
            ? 'relative flex-1 w-full h-full min-h-0'
            : `flex-1 w-full h-full min-h-0 grid ${gridTemplateClass}`
        }
        style={
          kit.layoutType === 'grid'
            ? { gap: `${kit.padGap}px` }
            : undefined
        }
      >
        {pads.map((pad) => renderPad(pad))}
      </div>
    </div>
  );
};
