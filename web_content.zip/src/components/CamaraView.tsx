import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  Zap,
  ZapOff,
  RefreshCw,
  Camera,
  Grid,
  Upload,
  AlertCircle,
} from 'lucide-react';
import { ModoFlash } from '../types';

interface CamaraViewProps {
  onAtras: () => void;
  onFotoCapturada: (tempFoto: {
    dataUrl: string;
    tamanoBytes: number;
    ancho: number;
    alto: number;
  }) => void;
}

export const CamaraView: React.FC<CamaraViewProps> = ({
  onAtras,
  onFotoCapturada,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [camaraFrontal, setCamaraFrontal] = useState(false);
  const [flash, setFlash] = useState<ModoFlash>('off');
  const [mostrarGuia, setMostrarGuia] = useState(true);
  const [disparando, setDisparando] = useState(false);
  const [errorCamara, setErrorCamara] = useState<string | null>(null);
  const [efectoFlash, setEfectoFlash] = useState(false);

  // Reproducir sonido sutil de obturador usando Web Audio API
  const reproducirSonidoObturador = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.09);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.1);
    } catch {
      // Ignorar si el audio está bloqueado
    }
  };

  // Iniciar cámara con MediaStream
  const iniciarCamara = useCallback(async () => {
    setErrorCamara(null);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Navegador no soporta acceso a cámara directa.');
      }

      const facingMode = camaraFrontal ? 'user' : { ideal: 'environment' };
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        await videoRef.current.play();
      }

      // Intentar aplicar flash a través de torch si está disponible y flash === 'on'
      const track = mediaStream.getVideoTracks()[0];
      const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as { torch?: boolean };
      if (capabilities.torch && flash === 'on') {
        try {
          await (track as MediaStreamTrack & { applyConstraints: (c: unknown) => Promise<void> }).applyConstraints({
            advanced: [{ torch: true }],
          });
        } catch {
          // Ignorar si torch falla
        }
      }
    } catch (err: unknown) {
      console.error('Error al iniciar cámara:', err);
      setErrorCamara(
        err instanceof Error
          ? err.message
          : 'No se pudo acceder a la cámara. Revisa permisos o sube una foto desde tu galería.'
      );
    }
  }, [camaraFrontal, flash]);

  useEffect(() => {
    iniciarCamara();
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [camaraFrontal]);

  // Manejar captura de foto
  const capturarFoto = () => {
    if (!videoRef.current || disparando) return;

    setDisparando(true);
    reproducirSonidoObturador();

    // Simular destello de flash en pantalla si flash está encendido o en auto
    if (flash === 'on' || flash === 'auto') {
      setEfectoFlash(true);
      setTimeout(() => setEfectoFlash(false), 200);
    }

    setTimeout(() => {
      try {
        const video = videoRef.current;
        if (!video) return;

        const canvas = canvasRef.current || document.createElement('canvas');
        const width = video.videoWidth || 1280;
        const height = video.videoHeight || 720;
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Si es cámara frontal, voltear horizontalmente como espejo
        if (camaraFrontal) {
          ctx.translate(width, 0);
          ctx.scale(-1, 1);
        }

        ctx.drawImage(video, 0, 0, width, height);

        // Convertir a JPEG de alta calidad
        const dataUrl = canvas.toDataURL('image/jpeg', 0.92);

        // Estimar tamaño en bytes a partir del base64
        const head = 'data:image/jpeg;base64,';
        const tamanoBytes = Math.round(((dataUrl.length - head.length) * 3) / 4);

        // Detener cámara temporalmente para liberar recursos
        if (stream) {
          stream.getTracks().forEach((track) => track.stop());
        }

        onFotoCapturada({
          dataUrl,
          tamanoBytes,
          ancho: width,
          alto: height,
        });
      } catch (err) {
        console.error('Error al capturar:', err);
      } finally {
        setDisparando(false);
      }
    }, flash === 'on' ? 120 : 50);
  };

  // Alternar Flash Requerimiento 17
  const toggleFlash = () => {
    setFlash((actual) => {
      if (actual === 'off') return 'on';
      if (actual === 'on') return 'auto';
      return 'off';
    });
  };

  // Subir foto desde archivos si la cámara no funciona o se prefiere
  const handleCargarArchivo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const img = new Image();
        img.onload = () => {
          if (stream) {
            stream.getTracks().forEach((track) => track.stop());
          }
          onFotoCapturada({
            dataUrl,
            tamanoBytes: file.size,
            ancho: img.width,
            alto: img.height,
          });
        };
        img.src = dataUrl;
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between select-none overflow-hidden">
      {/* Efecto destello flash */}
      {efectoFlash && (
        <div className="absolute inset-0 z-40 bg-white opacity-95 transition-opacity duration-150 pointer-events-none" />
      )}

      {/* Barra de Controles Superiores Requerimiento 14, 16, 17 */}
      <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-between p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        <button
          onClick={onAtras}
          className="p-2.5 rounded-full bg-black/40 text-white hover:bg-black/60 backdrop-blur-md active:scale-95 transition"
          aria-label="Cerrar cámara"
        >
          <X size={22} />
        </button>

        <div className="flex items-center gap-2">
          {/* Botón Flash */}
          <button
            onClick={toggleFlash}
            className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 backdrop-blur-md transition ${
              flash === 'on'
                ? 'bg-amber-500 text-slate-950'
                : flash === 'auto'
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                : 'bg-black/40 text-white/80'
            }`}
          >
            {flash === 'off' ? <ZapOff size={16} /> : <Zap size={16} />}
            <span>
              ⚡{' '}
              {flash === 'on' ? 'Encendido' : flash === 'auto' ? 'Auto' : 'Apagado'}
            </span>
          </button>

          {/* Toggle Guía / Rejilla para alinear el auto */}
          <button
            onClick={() => setMostrarGuia(!mostrarGuia)}
            title="Guía de alineación para vehículo"
            className={`p-2.5 rounded-full backdrop-blur-md transition ${
              mostrarGuia ? 'bg-amber-500/30 text-amber-400' : 'bg-black/40 text-white/70'
            }`}
          >
            <Grid size={18} />
          </button>
        </div>
      </div>

      {/* Contenedor del Video en Vivo */}
      <div className="relative flex-1 flex items-center justify-center bg-black overflow-hidden">
        {errorCamara ? (
          <div className="p-6 text-center max-w-sm mx-auto space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-red-500/20 text-red-400 flex items-center justify-center">
              <AlertCircle size={32} />
            </div>
            <h3 className="text-lg font-bold text-white">Cámara no disponible</h3>
            <p className="text-xs text-slate-400 leading-relaxed">{errorCamara}</p>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm flex items-center justify-center gap-2"
              >
                <Upload size={18} />
                Seleccionar foto desde archivo
              </button>
              <button
                onClick={onAtras}
                className="py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Volver a la carpeta
              </button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${camaraFrontal ? 'scale-x-[-1]' : ''}`}
            />

            {/* Rejilla de alineación para vehículos */}
            {mostrarGuia && (
              <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 border border-white/20">
                <div className="border-r border-b border-white/15" />
                <div className="border-r border-b border-white/15" />
                <div className="border-b border-white/15" />
                <div className="border-r border-b border-white/15 flex items-center justify-center">
                  {/* Marcador central para placa o detalle */}
                </div>
                <div className="border-r border-b border-white/15 flex items-center justify-center">
                  <div className="w-32 h-16 border-2 border-dashed border-amber-400/60 rounded-lg flex items-center justify-center">
                    <span className="text-[10px] text-amber-300 font-mono tracking-wider font-bold uppercase">
                      Placa / Falla
                    </span>
                  </div>
                </div>
                <div className="border-b border-white/15" />
                <div className="border-r border-white/15" />
                <div className="border-r border-white/15" />
                <div />
              </div>
            )}
          </>
        )}
      </div>

      {/* Barra de Controles Inferiores Requerimiento 15 & 16 */}
      <div className="absolute bottom-0 inset-x-0 z-30 p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-around">
        {/* Selector de archivo / galería alternativa */}
        <input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          onChange={handleCargarArchivo}
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          aria-label="Cargar desde galería"
          className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center backdrop-blur-md transition active:scale-95"
        >
          <Upload size={20} />
        </button>

        {/* Botón Disparador Principal Requerimiento 15 */}
        <button
          onClick={capturarFoto}
          disabled={!!errorCamara || disparando}
          aria-label="Tomar foto"
          className="w-20 h-20 rounded-full bg-white/20 p-1 flex items-center justify-center active:scale-90 transition-transform cursor-pointer disabled:opacity-50"
        >
          <div className="w-full h-full rounded-full bg-white border-4 border-slate-900 shadow-xl flex items-center justify-center group">
            <div className="w-4 h-4 rounded-full bg-amber-500 opacity-0 group-active:opacity-100 transition-opacity" />
          </div>
        </button>

        {/* Cambio de cámara frontal / trasera Requerimiento 16 */}
        <button
          onClick={() => setCamaraFrontal((actual) => !actual)}
          aria-label="Cambiar cámara frontal o trasera"
          className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center backdrop-blur-md transition active:scale-95"
        >
          <RefreshCw size={22} className={camaraFrontal ? 'rotate-180 transition-transform' : ''} />
        </button>
      </div>

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};
