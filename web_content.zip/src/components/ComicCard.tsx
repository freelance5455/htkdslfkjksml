import React, { useEffect, useState } from 'react';
import { BookOpen, CheckCheck, HardDriveDownload, Info, MoreVertical, RotateCcw, Trash2 } from 'lucide-react';
import type { ComicEntry, ReadStatus } from '../types/comic';

interface ComicCardProps {
  comic: ComicEntry;
  compact?: boolean;
  onOpen: (comic: ComicEntry) => void;
  onShowInfo: (comic: ComicEntry) => void;
  onToggleOffline: (comic: ComicEntry) => void;
  onSetReadStatus: (comic: ComicEntry, status: ReadStatus) => void;
  onDelete: (comic: ComicEntry) => void;
}

export const ComicCard: React.FC<ComicCardProps> = ({
  comic,
  compact = false,
  onOpen,
  onShowInfo,
  onToggleOffline,
  onSetReadStatus,
  onDelete,
}) => {
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!comic.coverBlob) {
      setCoverUrl(null);
      return;
    }
    const url = URL.createObjectURL(comic.coverBlob);
    setCoverUrl(url);
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [comic.coverBlob]);

  const progressPct =
    comic.readStatus === 'completed'
      ? 100
      : comic.pageCount > 1
        ? Math.min(100, Math.round(Math.max(((comic.currentPage + 1) / comic.pageCount) * 100, (comic.scrollProgress || 0) * 100)))
        : comic.scrollProgress > 0
          ? Math.round(comic.scrollProgress * 100)
          : 0;

  const hasStarted =
    comic.readStatus === 'completed' ||
    comic.readStatus === 'reading' ||
    comic.currentPage > 0 ||
    comic.scrollProgress > 0.02 ||
    Boolean(comic.lastReadAt);

  const metaParts: string[] = [];
  if (comic.comicInfo?.number) {
    metaParts.push(`#${comic.comicInfo.number}`);
  }
  metaParts.push(`${comic.pageCount}p`);
  metaParts.push(comic.format.toUpperCase());
  if (comic.readStatus === 'completed') {
    metaParts.push('Read');
  } else if (hasStarted) {
    metaParts.push(`${progressPct}%`);
  }
  if (comic.isOfflineCached) {
    metaParts.push('Offline');
  }

  return (
    <article className="group relative flex flex-col">
      <div className="relative aspect-[3/4] w-full overflow-hidden rounded-xl bg-zinc-200 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 transition-transform duration-150 ease-out group-hover:-translate-y-0.5">
        <button
          type="button"
          onClick={() => onOpen(comic)}
          className="w-full h-full block text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2"
          style={{ ['--tw-ring-color' as string]: 'var(--app-accent)' }}
          aria-label={`Open ${comic.displayTitle}`}
        >
          {coverUrl ? (
            <img
              src={coverUrl}
              alt={`${comic.displayTitle} cover`}
              referrerPolicy="no-referrer"
              loading="lazy"
              decoding="async"
              className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.02]"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-zinc-200 to-zinc-300 dark:from-zinc-800 dark:to-zinc-900">
              <BookOpen className="w-8 h-8 text-zinc-500 dark:text-zinc-400 mb-2" />
              <span className="text-xs font-medium text-zinc-600 dark:text-zinc-300 line-clamp-2">
                {comic.displayTitle}
              </span>
            </div>
          )}
        </button>

        {/* Subtle bottom reading progress bar */}
        {hasStarted && (
          <div className="absolute inset-x-0 bottom-0 h-1 bg-black/40 pointer-events-none">
            <div
              className="h-full transition-all duration-200"
              style={{
                width: `${Math.max(6, progressPct)}%`,
                backgroundColor: 'var(--app-accent)',
              }}
            />
          </div>
        )}

        {/* Overflow menu button in corner with 44x44 touch target */}
        <div className="absolute top-1 right-1">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen((v) => !v);
            }}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-white/90 bg-black/35 hover:bg-black/60 backdrop-blur-sm opacity-90 sm:opacity-0 sm:group-hover:opacity-100 focus:opacity-100 transition-opacity"
            aria-label={`More options for ${comic.displayTitle}`}
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {menuOpen && (
            <>
              <div
                className="fixed inset-0 z-20"
                onClick={() => setMenuOpen(false)}
              />
              <div className="absolute right-0 mt-1 w-48 z-30 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-lg py-1 text-sm">
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onShowInfo(comic);
                  }}
                  className="w-full min-h-[44px] px-3 flex items-center gap-2.5 text-left text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  <Info className="w-4 h-4 shrink-0 text-zinc-500" />
                  <span>Details &amp; TOC</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onToggleOffline(comic);
                  }}
                  className="w-full min-h-[44px] px-3 flex items-center gap-2.5 text-left text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  <HardDriveDownload className="w-4 h-4 shrink-0 text-zinc-500" />
                  <span>{comic.isOfflineCached ? 'Remove Offline Copy' : 'Cache for Offline'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onSetReadStatus(
                      comic,
                      comic.readStatus === 'completed' ? 'unread' : 'completed',
                    );
                  }}
                  className="w-full min-h-[44px] px-3 flex items-center gap-2.5 text-left text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  {comic.readStatus === 'completed' ? (
                    <>
                      <RotateCcw className="w-4 h-4 shrink-0 text-zinc-500" />
                      <span>Mark as Unread</span>
                    </>
                  ) : (
                    <>
                      <CheckCheck className="w-4 h-4 shrink-0 text-zinc-500" />
                      <span>Mark as Read</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onDelete(comic);
                  }}
                  className="w-full min-h-[44px] px-3 flex items-center gap-2.5 text-left text-rose-600 dark:text-rose-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  <Trash2 className="w-4 h-4 shrink-0" />
                  <span>Remove from Library</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className={compact ? 'mt-1.5 px-0.5' : 'mt-2.5 px-0.5'}>
        <button
          type="button"
          onClick={() => onOpen(comic)}
          className="block w-full text-left"
        >
          <h3 className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate leading-snug">
            {comic.displayTitle}
          </h3>
        </button>
        <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400 truncate font-mono-nums">
          {metaParts.join(' · ')}
        </p>
      </div>
    </article>
  );
};
