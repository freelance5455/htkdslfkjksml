import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bell,
  BellRing,
  Plus,
  Trash2,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Zap,
  CheckCircle2,
  X,
  Volume2,
  Sliders,
  Radio,
  ArrowUpRight,
  ArrowDownRight,
  Star,
  Search,
  ShieldCheck,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import {
  assetWatchlistService,
  TrackedCryptoAsset,
  AssetPriceAlert,
  AlertTargetType
} from '../lib/assetWatchlistService';

interface AssetWatchlistAlertSystemProps {
  onShowToast?: (msg: string) => void;
}

export const AssetWatchlistAlertSystem: React.FC<AssetWatchlistAlertSystemProps> = ({ onShowToast }) => {
  const [assets, setAssets] = useState<TrackedCryptoAsset[]>(() => assetWatchlistService.getAssets());
  const [alerts, setAlerts] = useState<AssetPriceAlert[]>(() => assetWatchlistService.getAlerts());
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [selectedAssetForAlert, setSelectedAssetForAlert] = useState<string>('BTC');
  const [targetType, setTargetType] = useState<AlertTargetType>('SELL_PROFIT_TARGET');
  const [targetPrice, setTargetPrice] = useState<string>('98000');
  const [alertNote, setAlertNote] = useState<string>('Prophetic Take-Profit Target');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [pushEnabled, setPushEnabled] = useState<boolean>(
    typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted'
  );

  useEffect(() => {
    const unsub = assetWatchlistService.subscribe(() => {
      setAssets(assetWatchlistService.getAssets());
      setAlerts(assetWatchlistService.getAlerts());
    });
    return () => unsub();
  }, []);

  const handleRequestPush = async () => {
    const granted = await assetWatchlistService.requestPushPermission();
    setPushEnabled(granted);
    if (granted) {
      onShowToast?.('✓ Browser Push Notifications enabled for Asset Watchlist!');
    } else {
      onShowToast?.('⚠️ Push permissions were not granted by browser.');
    }
  };

  const handleOpenAddModal = (symbol: string = 'BTC') => {
    const asset = assetWatchlistService.getAsset(symbol);
    setSelectedAssetForAlert(symbol);
    if (asset) {
      setTargetPrice(Math.round(asset.priceUsd * 1.05).toString());
    }
    setShowAddModal(true);
  };

  const handleApplyPresetPct = (pct: number) => {
    const asset = assetWatchlistService.getAsset(selectedAssetForAlert);
    if (!asset) return;
    const computed = +(asset.priceUsd * (1 + pct / 100)).toFixed(
      selectedAssetForAlert === 'ADA' || selectedAssetForAlert === 'DOGE' ? 4 : 2
    );
    setTargetPrice(computed.toString());
    if (pct > 0) {
      setTargetType('SELL_PROFIT_TARGET');
      setAlertNote(`Take-Profit Target (+${pct}%)`);
    } else {
      setTargetType('BUY_DIP_TARGET');
      setAlertNote(`Accumulation Dip Target (${pct}%)`);
    }
  };

  const handleSaveAlert = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = Number(targetPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      onShowToast?.('⚠️ Please enter a valid target price.');
      return;
    }

    assetWatchlistService.addAlert({
      assetSymbol: selectedAssetForAlert,
      targetPriceUsd: priceNum,
      targetType,
      note: alertNote.trim() || `${selectedAssetForAlert} Price Alert`,
      enabled: true
    });

    onShowToast?.(`✓ Added ${selectedAssetForAlert} alert at $${priceNum.toLocaleString()}!`);
    setShowAddModal(false);
  };

  const handleSimulateSurge = (symbol: string, pct: number) => {
    assetWatchlistService.simulatePriceMovement(symbol, pct);
    onShowToast?.(`⚡ Simulated ${pct > 0 ? `+${pct}% Surge` : `${pct}% Dip`} on ${symbol}! Checking triggers...`);
  };

  const handleTestAudioPush = () => {
    assetWatchlistService.playSynthesizedAlertChime(true);
    onShowToast?.('🔔 Synthesized Audio Chime & Push Trigger Tested!');
  };

  const filteredAssets = assets.filter(
    (a) =>
      a.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <BellRing className="w-4 h-4 text-amber-400" />
            <span>ASSET WATCHLIST & BUY/SELL TARGET ALERT ENGINE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Real-Time Push Notifications & Price Triggers
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Track live crypto assets, set custom buy/sell target thresholds, and receive instant push notifications with synthesized harmonic chimes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {!pushEnabled && (
            <button
              onClick={handleRequestPush}
              className="px-3.5 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span>ENABLE PUSH</span>
            </button>
          )}

          <button
            onClick={handleTestAudioPush}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
            title="Test Synthesized Harmonic Chime"
          >
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>TEST SOUND</span>
          </button>

          <button
            onClick={() => handleOpenAddModal('BTC')}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 hover:scale-105 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>SET NEW ALERT</span>
          </button>
        </div>
      </div>

      {/* Live Tracked Assets Matrix */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Tracked Cryptocurrencies ({assets.length})</span>
          </span>

          {/* Quick Search */}
          <div className="relative w-48 sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search ticker or name..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {filteredAssets.map((asset) => {
            const isPositive = asset.change24hPercent >= 0;
            const assetAlertsCount = alerts.filter((a) => a.assetSymbol === asset.symbol && a.enabled).length;

            return (
              <div
                key={asset.symbol}
                className="bg-slate-900/80 border border-amber-500/20 hover:border-amber-400/60 rounded-2xl p-4 transition-all hover:scale-101 space-y-3 group relative overflow-hidden"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-2xl">{asset.icon}</span>
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="text-sm font-black text-amber-100">{asset.symbol}</span>
                        <span className="text-[10px] text-slate-400 font-medium">({asset.name})</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">Vol: {asset.volume24h}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => assetWatchlistService.toggleFavoriteAsset(asset.symbol)}
                    className="text-slate-600 hover:text-amber-400 transition-colors"
                  >
                    <Star
                      className={`w-4 h-4 ${asset.isCustomFavorite ? 'fill-amber-400 text-amber-400' : ''}`}
                    />
                  </button>
                </div>

                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-lg font-black text-amber-200 font-mono">
                      ${asset.priceUsd.toLocaleString(undefined, {
                        minimumFractionDigits: asset.priceUsd < 1 ? 4 : 2,
                        maximumFractionDigits: asset.priceUsd < 1 ? 4 : 2
                      })}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      H: ${asset.high24h.toLocaleString()} • L: ${asset.low24h.toLocaleString()}
                    </div>
                  </div>

                  <div className={`px-2 py-0.5 rounded-lg text-xs font-bold font-mono flex items-center space-x-1 ${
                    isPositive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    <span>{isPositive ? '+' : ''}{asset.change24hPercent.toFixed(2)}%</span>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                    <Bell className="w-3 h-3 text-amber-400" />
                    <span>{assetAlertsCount} {assetAlertsCount === 1 ? 'alert' : 'alerts'}</span>
                  </span>

                  <button
                    onClick={() => handleOpenAddModal(asset.symbol)}
                    className="px-2 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-[10px] font-bold transition-colors"
                  >
                    + Add Target
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Price Alerts & Thresholds Section */}
      <div className="space-y-3 pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center space-x-1.5">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Active Price Target Alerts ({alerts.length})</span>
          </span>

          {/* Instant Simulation Buttons */}
          <div className="flex items-center space-x-2">
            <span className="text-[10px] text-slate-400 font-bold hidden sm:inline">Simulate:</span>
            <button
              onClick={() => handleSimulateSurge('BTC', 3.5)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/30"
            >
              BTC +3.5%
            </button>
            <button
              onClick={() => handleSimulateSurge('BTC', -3.5)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-rose-300 text-[10px] font-mono font-bold border border-rose-500/30"
            >
              BTC -3.5%
            </button>
            <button
              onClick={() => handleSimulateSurge('SOL', 5.0)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-teal-300 text-[10px] font-mono font-bold border border-teal-500/30"
            >
              SOL +5%
            </button>
          </div>
        </div>

        {alerts.length === 0 ? (
          <div className="p-8 bg-slate-950/60 border border-slate-800 rounded-3xl text-center space-y-2">
            <Bell className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-slate-400">No active price target alerts.</p>
            <p className="text-xs text-slate-500">Click 'Set New Alert' to create a buy dip or sell profit trigger.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {alerts.map((alert) => {
              const asset = assetWatchlistService.getAsset(alert.assetSymbol);
              const currentPrice = asset ? asset.priceUsd : 0;
              const diffPct = currentPrice > 0 ? ((alert.targetPriceUsd - currentPrice) / currentPrice) * 100 : 0;
              const isSell = alert.targetType === 'SELL_PROFIT_TARGET';

              return (
                <div
                  key={alert.id}
                  className={`p-4 rounded-2xl border transition-all relative overflow-hidden flex flex-col justify-between space-y-3 ${
                    alert.enabled
                      ? 'bg-slate-900/90 border-amber-500/30 shadow-lg'
                      : 'bg-slate-950/60 border-slate-800/80 opacity-60'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-2">
                      <span className="text-xl">{asset?.icon || '⚡'}</span>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-black text-amber-100">{alert.assetSymbol}</span>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                              isSell
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            }`}
                          >
                            {isSell ? '📈 Take-Profit Target (≥)' : '📉 Buy Dip Target (≤)'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 font-medium">{alert.note}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <button
                        onClick={() => assetWatchlistService.toggleAlert(alert.id)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                          alert.enabled
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {alert.enabled ? 'ACTIVE' : 'PAUSED'}
                      </button>

                      <button
                        onClick={() => assetWatchlistService.deleteAlert(alert.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase block">Target Price</span>
                      <span className="text-base font-black text-amber-300 font-mono">
                        ${alert.targetPriceUsd.toLocaleString()}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 uppercase block">Current Live Price</span>
                      <span className="text-xs font-bold text-slate-200 font-mono">
                        ${currentPrice.toLocaleString()} ({diffPct > 0 ? `+${diffPct.toFixed(2)}%` : `${diffPct.toFixed(2)}%`})
                      </span>
                    </div>
                  </div>

                  {/* Triggered Log Information */}
                  <div className="flex justify-between items-center text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                    <span>Triggers: <strong className="text-amber-200">{alert.triggerCount || 0}</strong></span>
                    <span>
                      {alert.triggeredAt ? (
                        <span className="text-emerald-400 font-bold">
                          Last Triggered: {alert.triggeredAt} (${alert.lastTriggeredPrice?.toLocaleString()})
                        </span>
                      ) : (
                        <span>Created: {alert.createdAt}</span>
                      )}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Alert Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 border-2 border-amber-500/60 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl text-slate-100">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-3">
              <div className="space-y-0.5">
                <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
                  <BellRing className="w-5 h-5 text-amber-400" />
                  <span>Configure Price Target Alert</span>
                </h3>
                <p className="text-xs text-slate-400">Push notification and sound chime will fire when hit.</p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-amber-200 text-lg font-bold p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAlert} className="space-y-4">
              {/* Asset Selector */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Select Cryptocurrency:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {assets.slice(0, 8).map((a) => (
                    <button
                      key={a.symbol}
                      type="button"
                      onClick={() => {
                        setSelectedAssetForAlert(a.symbol);
                        setTargetPrice(Math.round(a.priceUsd * 1.05).toString());
                      }}
                      className={`p-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 border transition-all ${
                        selectedAssetForAlert === a.symbol
                          ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-md'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <span>{a.icon}</span>
                      <span>{a.symbol}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Type Selector */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Target Condition:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTargetType('SELL_PROFIT_TARGET');
                      setAlertNote('Take-Profit Target (+5%)');
                    }}
                    className={`p-3 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                      targetType === 'SELL_PROFIT_TARGET'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md font-black'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                    <span>Price ≥ Target (Sell / Profit)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTargetType('BUY_DIP_TARGET');
                      setAlertNote('Accumulation Dip Target (-5%)');
                    }}
                    className={`p-3 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                      targetType === 'BUY_DIP_TARGET'
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-md font-black'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <ArrowDownRight className="w-4 h-4 text-cyan-400" />
                    <span>Price ≤ Target (Buy / Dip)</span>
                  </button>
                </div>
              </div>

              {/* Target Price & Percentage Presets */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    Target Trigger Price ($ USD):
                  </label>
                  <span className="text-[10px] text-amber-300 font-mono">
                    Current: ${assetWatchlistService.getAsset(selectedAssetForAlert)?.priceUsd.toLocaleString()}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={targetPrice}
                    onChange={(e) => setTargetPrice(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-amber-500/40 focus:border-amber-400 rounded-xl px-4 py-2.5 text-base font-bold text-amber-100 focus:outline-none font-mono"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-500 font-bold">USD</span>
                </div>

                {/* Quick Percentage Presets */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  <span className="text-[10px] font-bold text-slate-400 self-center">Presets:</span>
                  {[+5, +10, +20, -5, -10, -20].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => handleApplyPresetPct(pct)}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold transition-all ${
                        pct > 0
                          ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30'
                      }`}
                    >
                      {pct > 0 ? `+${pct}%` : `${pct}%`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Note / Memo */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Alert Strategy Note:
                </label>
                <input
                  type="text"
                  value={alertNote}
                  onChange={(e) => setAlertNote(e.target.value)}
                  placeholder="e.g. Trigger Kingdom Vault Take-Profit"
                  className="w-full bg-slate-950 border border-amber-500/30 focus:border-amber-400 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none"
                />
              </div>

              {/* Submit */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-102 cursor-pointer"
                >
                  <BellRing className="w-4 h-4 text-slate-950" />
                  <span>ARM PRICE TARGET ALERT</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
