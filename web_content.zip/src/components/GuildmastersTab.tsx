import { useGame } from '../context/GameContext';
import { formatNumber } from '../utils/formatters';
import { Check, ShieldCheck, Users } from 'lucide-react';
import { GuildmasterAvatar } from './GuildmasterAvatar';
import { VentureIcon } from './VentureIcon';

export function GuildmastersTab() {
  const { ventures, ventureStates, gold, hireManager, numberFormat } = useGame();

  const hiredCount = Object.values(ventureStates).filter((v) => v.managerHired).length;

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="rounded-2xl border border-amber-900/30 bg-slate-900/80 p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Users className="w-4 h-4" />
            <span>Kingdom Guildmasters & Overseers</span>
          </div>
          <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-slate-100">
            Automate Your Royal Enterprise
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Guildmasters run your workshops automatically so profits accumulate continuously, even when you are away from the realm.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0 flex-wrap sm:flex-nowrap">
          <div className="px-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-center shrink-0">
            <div className="text-xs text-slate-400">Employed Overseers</div>
            <div className="font-cinzel text-xl font-bold text-amber-300">
              {hiredCount} / {ventures.length}
            </div>
          </div>
        </div>
      </div>

      {/* Managers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {ventures.map((venture) => {
          const state = ventureStates[venture.id];
          const isHired = state?.managerHired ?? false;
          const canAfford = gold >= venture.manager.cost;
          const isVentureOwned = (state?.count || 0) > 0;

          return (
            <div
              key={venture.id}
              className={`rounded-2xl border p-4 sm:p-5 transition-all flex flex-col justify-between ${
                isHired
                  ? 'border-emerald-500/40 bg-emerald-950/15'
                  : 'border-slate-800 bg-slate-900/80 hover:bg-slate-900'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="relative shrink-0">
                      <GuildmasterAvatar
                        ventureId={venture.id}
                        size="md"
                        className="w-12 h-12 ring-2 ring-amber-500/30"
                      />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-md bg-slate-950/90 border border-slate-700/80 p-0.5 shadow-sm">
                        <VentureIcon ventureId={venture.id} size="sm" className="w-full h-full" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-cinzel text-base font-bold text-slate-100 leading-tight">
                        {venture.manager.name}
                      </h3>
                      <div className="text-xs text-amber-400/90 font-medium">
                        {venture.manager.title}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Oversees {venture.name}
                      </div>
                    </div>
                  </div>

                  {isHired && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/30">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Hired</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-400 italic mt-3 border-l-2 border-slate-700/80 pl-2.5 py-0.5">
                  "{venture.manager.quote}"
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <div className="text-xs">
                  <div className="text-slate-500">Signing Bounty</div>
                  <div className="font-semibold text-amber-300 tabular-nums">
                    {formatNumber(venture.manager.cost, numberFormat)} Gold
                  </div>
                </div>

                {isHired ? (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <Check className="w-4 h-4" />
                    <span>Actively Supervised</span>
                  </div>
                ) : (
                  <button
                    onClick={() => hireManager(venture.id)}
                    disabled={!canAfford || !isVentureOwned}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      canAfford && isVentureOwned
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-950/40 active:scale-95'
                        : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-75'
                    }`}
                  >
                    {!isVentureOwned
                      ? 'Establish Venture First'
                      : canAfford
                      ? 'Hire Guildmaster'
                      : 'Insufficient Gold'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
