import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  GraduationCap,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ThumbsUp,
  Award,
  Wallet,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  BookOpen,
  X,
  Share2,
  Bookmark,
  Sprout,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { Language, UserProfile, SeasonType, ExpertTip } from '../types';
import { EXPERT_ADVICE_TIPS } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface ExpertAdviceCarouselProps {
  language: Language;
  user: UserProfile;
  onNavigateToWallet?: () => void;
  onSelectInputToBuy?: (inputId: string) => void;
}

export default function ExpertAdviceCarousel({
  language,
  user,
  onNavigateToWallet,
  onSelectInputToBuy,
}: ExpertAdviceCarouselProps) {
  const isSw = language === 'sw';

  // Default season based on current real-world month (September is onset of Vuli / transition)
  const [selectedSeason, setSelectedSeason] = useState<SeasonType>('vuli');
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Community interaction states (persisted locally during session)
  const [endorsedTips, setEndorsedTips] = useState<Record<string, boolean>>({});
  const [bookmarkedTips, setBookmarkedTips] = useState<Record<string, boolean>>({});
  const [selectedModalTip, setSelectedModalTip] = useState<ExpertTip | null>(null);
  const [actionSuccessNotice, setActionSuccessNotice] = useState<string | null>(null);

  // Dynamic filter for tips
  const filteredTips = useMemo(() => {
    return EXPERT_ADVICE_TIPS.filter((tip) => {
      const seasonMatch = tip.season === selectedSeason;
      const cropMatch =
        selectedCrop === 'all' || tip.cropId === selectedCrop || tip.cropId === 'all';
      return seasonMatch && cropMatch;
    });
  }, [selectedSeason, selectedCrop]);

  // Handle carousel boundaries
  const activeIndex =
    filteredTips.length === 0 ? 0 : Math.min(currentIndex, filteredTips.length - 1);
  const currentTip = filteredTips[activeIndex];

  const handleNext = () => {
    playKeyTap();
    if (filteredTips.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % filteredTips.length);
  };

  const handlePrev = () => {
    playKeyTap();
    if (filteredTips.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + filteredTips.length) % filteredTips.length);
  };

  const handleEndorse = (tipId: string) => {
    playSuccessChime();
    setEndorsedTips((prev) => {
      const newState = !prev[tipId];
      if (newState) {
        setActionSuccessNotice(
          isSw
            ? 'Asante! Ushuhuda wako umerekodiwa kusaidia wakulima wengine.'
            : 'Thank you! Your endorsement has been verified to help fellow farmers.'
        );
        setTimeout(() => setActionSuccessNotice(null), 3500);
      }
      return { ...prev, [tipId]: newState };
    });
  };

  const handleBookmark = (tipId: string) => {
    playKeyTap();
    setBookmarkedTips((prev) => ({
      ...prev,
      [tipId]: !prev[tipId],
    }));
  };

  const handleGrowthWalletAction = (tip: ExpertTip) => {
    playKeyTap();
    if (onSelectInputToBuy && tip.growthWalletLink?.inputId) {
      onSelectInputToBuy(tip.growthWalletLink.inputId);
    } else if (onNavigateToWallet) {
      onNavigateToWallet();
    }
  };

  return (
    <div
      id="expert-advice-carousel-section"
      className="space-y-3 p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-sm text-[var(--ink)]"
    >
      {/* Header with Title and Growth Wallet Pill */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-amber-500/15 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-display font-bold text-sm sm:text-base text-[var(--ink)]">
                {isSw ? 'Ushauri wa Wataalamu wa Kilimo' : 'Expert Agronomy Advice'}
              </h3>
              <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold tracking-wider uppercase flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>{isSw ? 'Imethibitishwa' : 'Verified'}</span>
              </span>
            </div>
            <p className="text-[11px] text-[var(--ink-soft)]">
              {isSw
                ? 'Mbinu za kisasa za msimu zilizothibitishwa na watafiti na jamii ya wakulima'
                : 'Seasonal yield-boosting techniques verified by researchers & local farmers'}
            </p>
          </div>
        </div>

        {/* Farm Growth Wallet Quick Tag */}
        {onNavigateToWallet && (
          <button
            type="button"
            onClick={onNavigateToWallet}
            className="self-start sm:self-center px-2.5 py-1 rounded-xl bg-gradient-to-r from-emerald-600/15 via-amber-500/15 to-emerald-600/15 border border-emerald-500/30 text-[11px] font-semibold text-emerald-800 dark:text-emerald-200 flex items-center gap-1.5 hover:opacity-90 cursor-pointer shadow-xs"
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>{isSw ? 'Pochi ya Kukuza Shamba' : 'Farm Growth Wallet'}</span>
            <ArrowRight className="w-3 h-3 text-emerald-600" />
          </button>
        )}
      </div>

      {/* Season Selector Bar */}
      <div className="flex items-center justify-between gap-1 pt-1 pb-1">
        <div className="flex items-center gap-1 text-xs text-[var(--ink-soft)] font-medium">
          <Calendar className="w-3.5 h-3.5 text-[var(--forest)]" />
          <span>{isSw ? 'Msimu:' : 'Season:'}</span>
        </div>

        <div className="flex bg-[var(--bg)] p-0.5 rounded-xl border border-[var(--line)] text-xs">
          {[
            { id: 'vuli', sw: 'Vuli (Mvua Fupi)', en: 'Vuli (Short Rains)' },
            { id: 'masika', sw: 'Masika (Mvua Kuu)', en: 'Masika (Main Rains)' },
            { id: 'kiangazi', sw: 'Kiangazi & Mavuno', en: 'Dry & Harvest' },
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => {
                playKeyTap();
                setSelectedSeason(s.id as SeasonType);
                setCurrentIndex(0);
              }}
              className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] transition-all cursor-pointer ${
                selectedSeason === s.id
                  ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-xs'
                  : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
              }`}
            >
              {isSw ? s.sw : s.en}
            </button>
          ))}
        </div>
      </div>

      {/* Crop Filter Horizontal Tabs */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {[
          { id: 'all', sw: 'Mazao Yote', en: 'All Crops' },
          { id: 'maize', sw: '🌽 Mahindi', en: '🌽 Maize' },
          { id: 'rice', sw: '🌾 Mpunga', en: '🌾 Rice' },
          { id: 'beans', sw: '🫘 Maharage', en: '🫘 Beans' },
          { id: 'coffee', sw: '☕ Kahawa', en: '☕ Coffee' },
        ].map((crop) => (
          <button
            key={crop.id}
            onClick={() => {
              playKeyTap();
              setSelectedCrop(crop.id);
              setCurrentIndex(0);
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-medium flex-shrink-0 transition-all cursor-pointer border ${
              selectedCrop === crop.id
                ? 'bg-[var(--forest-dark)] text-amber-200 border-[var(--forest-dark)] shadow-xs'
                : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
            }`}
          >
            {isSw ? crop.sw : crop.en}
          </button>
        ))}
      </div>

      {/* Success Notification Alert */}
      {actionSuccessNotice && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>{actionSuccessNotice}</span>
        </motion.div>
      )}

      {/* Carousel Main Card Area */}
      {currentTip ? (
        <div className="relative rounded-2xl bg-[var(--bg)] border border-[var(--line)] p-4 shadow-xs overflow-hidden transition-all">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

          {/* Card Top Row: Crop Tag & Yield Metric */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2 py-0.5 rounded-lg bg-[var(--forest)]/10 text-[var(--forest)] font-bold text-[10px] uppercase tracking-wider">
                {isSw ? currentTip.cropNameSw : currentTip.cropNameEn}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold text-[10px] flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>{isSw ? currentTip.yieldImpactSw : currentTip.yieldImpactEn}</span>
              </span>
            </div>

            {/* Bookmark Button */}
            <button
              type="button"
              onClick={() => handleBookmark(currentTip.id)}
              className={`p-1.5 rounded-lg transition-all ${
                bookmarkedTips[currentTip.id]
                  ? 'text-amber-500 bg-amber-500/15'
                  : 'text-[var(--ink-soft)] hover:text-[var(--ink)] hover:bg-[var(--line)]/50'
              }`}
              title={isSw ? 'Hifadhi Kidokezo' : 'Bookmark Tip'}
            >
              <Bookmark
                className={`w-4 h-4 ${bookmarkedTips[currentTip.id] ? 'fill-amber-500' : ''}`}
              />
            </button>
          </div>

          {/* Tip Title */}
          <h4 className="font-display font-bold text-sm sm:text-base text-[var(--ink)] leading-snug">
            {isSw ? currentTip.titleSw : currentTip.titleEn}
          </h4>

          {/* Tip Summary */}
          <p className="text-xs text-[var(--ink-soft)] leading-relaxed mt-1.5">
            {isSw ? currentTip.summarySw : currentTip.summaryEn}
          </p>

          {/* Agronomist Attribution & Community Endorsement */}
          <div className="pt-3 mt-3 border-t border-[var(--line)] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[var(--forest-dark)] text-amber-200 font-bold text-xs flex items-center justify-center shadow-xs">
                {currentTip.verifiedExpert.avatar}
              </div>
              <div>
                <div className="font-bold text-xs text-[var(--ink)] flex items-center gap-1">
                  <span>{currentTip.verifiedExpert.name}</span>
                  <Award className="w-3 h-3 text-amber-500" />
                </div>
                <div className="text-[10px] text-[var(--ink-soft)]">
                  {currentTip.verifiedExpert.organization}
                </div>
              </div>
            </div>

            {/* Community Upvote / Endorsement Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleEndorse(currentTip.id)}
                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  endorsedTips[currentTip.id]
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-[var(--paper)] text-[var(--ink)] border border-[var(--line)] hover:border-emerald-500'
                }`}
              >
                <ThumbsUp
                  className={`w-3.5 h-3.5 ${endorsedTips[currentTip.id] ? 'fill-white' : ''}`}
                />
                <span>
                  {currentTip.communityEndorsements + (endorsedTips[currentTip.id] ? 1 : 0)}{' '}
                  {isSw ? 'Wamethibitisha' : 'Confirmed'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playKeyTap();
                  setSelectedModalTip(currentTip);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-[var(--paper)] hover:bg-[var(--forest)]/10 text-[var(--forest)] border border-[var(--line)] text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-all"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>{isSw ? 'Hatua Kamili' : 'Full Steps'}</span>
              </button>
            </div>
          </div>

          {/* Farm Growth Wallet Input Reinvestment Banner */}
          {currentTip.growthWalletLink && (
            <div className="mt-3 p-2.5 rounded-xl bg-gradient-to-r from-emerald-600/10 via-amber-500/10 to-emerald-600/10 border border-emerald-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                  <Sprout className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-[11px] text-[var(--ink)]">
                    {isSw ? currentTip.growthWalletLink.recommendedInputSw : currentTip.growthWalletLink.recommendedInputEn}
                  </div>
                  <div className="text-[10px] text-[var(--ink-soft)]">
                    {isSw ? 'Gharama ya hatua hii:' : 'Estimated cost:'}{' '}
                    <span className="font-bold text-[var(--forest)]">
                      Tsh {currentTip.growthWalletLink.estimatedCostTsh.toLocaleString()}
                    </span>{' '}
                    • {isSw ? 'Mfuko wa Kukuza Shamba unatoa 5% bonasi' : 'Farm Growth Wallet gives 5% bonus'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleGrowthWalletAction(currentTip)}
                className="self-end sm:self-center px-3 py-1.5 rounded-lg bg-[var(--forest)] text-[#F7F4E9] text-[11px] font-bold flex items-center gap-1 hover:opacity-95 cursor-pointer shadow-xs active:scale-95"
              >
                <Wallet className="w-3 h-3 text-amber-300" />
                <span>
                  {isSw
                    ? currentTip.growthWalletLink.actionSw
                    : currentTip.growthWalletLink.actionEn}
                </span>
              </button>
            </div>
          )}

          {/* Carousel Footer Controls (Slide numbers, arrows) */}
          <div className="mt-3 pt-2 flex items-center justify-between text-xs text-[var(--ink-soft)]">
            <div className="flex items-center gap-1.5">
              {filteredTips.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    playKeyTap();
                    setCurrentIndex(idx);
                  }}
                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                    activeIndex === idx ? 'w-5 bg-[var(--forest)]' : 'w-1.5 bg-[var(--line)]'
                  }`}
                  aria-label={`Slide ${idx + 1}`}
                />
              ))}
              <span className="text-[10px] ml-1 font-mono">
                {activeIndex + 1} / {filteredTips.length}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handlePrev}
                disabled={filteredTips.length <= 1}
                className="p-1.5 rounded-lg bg-[var(--paper)] border border-[var(--line)] hover:bg-[var(--line)]/50 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition-all"
                aria-label="Previous tip"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleNext}
                disabled={filteredTips.length <= 1}
                className="p-1.5 rounded-lg bg-[var(--paper)] border border-[var(--line)] hover:bg-[var(--line)]/50 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition-all"
                aria-label="Next tip"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-6 text-center rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink-soft)] space-y-1">
          <p className="font-semibold text-[var(--ink)]">
            {isSw ? 'Hakuna dokezo la msimu huu bado' : 'No tips found for this season'}
          </p>
          <p>
            {isSw
              ? 'Tafadhali chagua zao au msimu mwingine kuona ushauri wa wataalamu.'
              : 'Please switch the crop or season tab to view available agronomic tips.'}
          </p>
        </div>
      )}

      {/* FULL DETAILED STEPS MODAL */}
      <AnimatePresence>
        {selectedModalTip && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-lg rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-2xl p-5 max-h-[90vh] overflow-y-auto space-y-4 text-[var(--ink)]"
            >
              {/* Modal Header */}
              <div className="flex items-start justify-between gap-3 border-b border-[var(--line)] pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[var(--forest)]/10 text-[var(--forest)] font-bold text-[10px] uppercase">
                      {isSw ? selectedModalTip.cropNameSw : selectedModalTip.cropNameEn}
                    </span>
                    <span className="text-xs text-amber-600 font-bold">
                      {isSw ? selectedModalTip.yieldImpactSw : selectedModalTip.yieldImpactEn}
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-base sm:text-lg text-[var(--ink)] mt-1">
                    {isSw ? selectedModalTip.titleSw : selectedModalTip.titleEn}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedModalTip(null)}
                  className="p-1.5 rounded-full hover:bg-[var(--line)] text-[var(--ink-soft)] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Expert Profile Banner in Modal */}
              <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-[var(--forest-dark)] text-amber-200 font-bold text-xs flex items-center justify-center">
                    {selectedModalTip.verifiedExpert.avatar}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-[var(--ink)] flex items-center gap-1">
                      <span>{selectedModalTip.verifiedExpert.name}</span>
                      <Award className="w-3.5 h-3.5 text-amber-500" />
                    </div>
                    <div className="text-[10px] text-[var(--ink-soft)]">
                      {isSw
                        ? selectedModalTip.verifiedExpert.titleSw
                        : selectedModalTip.verifiedExpert.titleEn}{' '}
                      • {selectedModalTip.verifiedExpert.organization}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-bold text-emerald-600">
                    ★ {selectedModalTip.ratingPercent}% {isSw ? 'Uaminifu' : 'Trust Score'}
                  </div>
                  <div className="text-[10px] text-[var(--ink-soft)]">
                    {selectedModalTip.communityEndorsements} {isSw ? 'wakulima' : 'farmers'}
                  </div>
                </div>
              </div>

              {/* Numbered Step-by-Step Instructions */}
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-[var(--ink-soft)] mb-2 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[var(--forest)]" />
                  <span>{isSw ? 'Hatua kwa Hatua za Utekelezaji' : 'Implementation Steps'}</span>
                </h4>

                <div className="space-y-2">
                  {(isSw
                    ? selectedModalTip.detailedStepsSw
                    : selectedModalTip.detailedStepsEn
                  ).map((step, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs flex items-start gap-2.5"
                    >
                      <span className="w-5 h-5 rounded-full bg-[var(--forest)] text-[#F7F4E9] font-bold text-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed text-[var(--ink)]">{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Farm Growth Wallet Purchase Action */}
              {selectedModalTip.growthWalletLink && (
                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-600/15 to-amber-500/15 border border-emerald-500/30 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[var(--forest)] flex items-center gap-1">
                      <Wallet className="w-4 h-4 text-emerald-600" />
                      <span>{isSw ? 'Pochi ya Kukuza Shamba (Reinvestment)' : 'Farm Growth Wallet'}</span>
                    </span>
                    <span className="font-mono font-bold text-amber-700 dark:text-amber-300">
                      Tsh {selectedModalTip.growthWalletLink.estimatedCostTsh.toLocaleString()}
                    </span>
                  </div>

                  <p className="text-[11px] text-[var(--ink-soft)]">
                    {isSw
                      ? `Tumia salio la pochi ya shamba kupata pembejeo hii (${selectedModalTip.growthWalletLink.recommendedInputSw}) na punguzo la 5%.`
                      : `Fund this input recommendation (${selectedModalTip.growthWalletLink.recommendedInputEn}) directly with your Farm Growth Wallet.`}
                  </p>

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedModalTip(null);
                        handleGrowthWalletAction(selectedModalTip);
                      }}
                      className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm hover:opacity-95 cursor-pointer"
                    >
                      <Sprout className="w-4 h-4 text-amber-300" />
                      <span>
                        {isSw
                          ? selectedModalTip.growthWalletLink.actionSw
                          : selectedModalTip.growthWalletLink.actionEn}
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* Close Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setSelectedModalTip(null)}
                  className="px-4 py-2 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] hover:bg-[var(--line)]/50 cursor-pointer"
                >
                  {isSw ? 'Funga Dirisha' : 'Close'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
