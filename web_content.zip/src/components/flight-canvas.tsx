import { useEffect, useRef } from "react";
import { useGame } from "@/lib/store";

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  hue: number;
};

type Trail = { x: number; y: number };

export function FlightCanvas() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let running = true;
    let w = 0;
    let h = 0;
    let dpr = 1;
    const points: Trail[] = [];
    const trail: Trail[] = [];
    const particles: Particle[] = [];
    let lastPhase = useGame.getState().phase;
    let lastRound = useGame.getState().round;
    let flyOff = 0;
    const stars = Array.from({ length: 48 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: Math.random() * 1.2 + 0.3,
      a: Math.random() * 0.5 + 0.15,
      s: Math.random() * 0.08 + 0.02,
    }));

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      w = Math.max(1, Math.floor(rect.width));
      h = Math.max(1, Math.floor(rect.height));
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    resize();

    const origin = () => ({ x: 56, y: h - 36 });

    const plot = (elapsed: number, multiplier: number) => {
      const o = origin();
      const plotW = w - o.x - 28;
      const plotH = h - 56 - 20;
      const maxT = Math.max(elapsed, 8);
      const maxM = Math.max(multiplier, 2.2);
      const x = o.x + (elapsed / maxT) * plotW;
      const y = o.y - ((multiplier - 1) / (maxM - 1)) * plotH;
      return { x, y, plotW, plotH, maxT, maxM, o };
    };

    const burst = (x: number, y: number, n: number) => {
      for (let i = 0; i < n; i++) {
        const a = -Math.PI * 0.15 - Math.random() * Math.PI * 0.55;
        const sp = 40 + Math.random() * 220;
        particles.push({
          x,
          y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp,
          life: 0,
          max: 0.45 + Math.random() * 0.55,
          size: 1 + Math.random() * 2.4,
          hue: Math.random() < 0.7 ? 0 : 25,
        });
      }
    };

    let last = performance.now();
    const loop = (now: number) => {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const g = useGame.getState();

      if (g.round !== lastRound) {
        points.length = 0;
        trail.length = 0;
        particles.length = 0;
        flyOff = 0;
        lastRound = g.round;
      }
      if (g.phase !== lastPhase) {
        if (g.phase === "crashed") {
          const p = plot(g.elapsed, g.multiplier);
          burst(p.x, p.y, 36);
        }
        if (g.phase === "waiting") {
          points.length = 0;
          trail.length = 0;
          flyOff = 0;
        }
        lastPhase = g.phase;
      }

      if (g.phase === "flying") {
        const p = plot(g.elapsed, g.multiplier);
        const lastP = points[points.length - 1];
        if (!lastP || Math.hypot(p.x - lastP.x, p.y - lastP.y) > 1.2) {
          points.push({ x: p.x, y: p.y });
          if (points.length > 420) points.shift();
        }
        trail.push({ x: p.x, y: p.y });
        if (trail.length > 28) trail.shift();
        if (Math.random() < 0.55) {
          particles.push({
            x: p.x - 8,
            y: p.y + 2,
            vx: -20 - Math.random() * 40,
            vy: (Math.random() - 0.5) * 24,
            life: 0,
            max: 0.35,
            size: 1.2,
            hue: 0,
          });
        }
      } else if (g.phase === "crashed") {
        flyOff += dt;
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        if (!p) continue;
        p.life += dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += 80 * dt;
        if (p.life >= p.max) particles.splice(i, 1);
      }

      const trauma = g.shakeOff ? 0 : g.trauma;
      const shake = trauma * trauma;
      const ox = shake ? (Math.random() * 2 - 1) * 10 * shake : 0;
      const oy = shake ? (Math.random() * 2 - 1) * 8 * shake : 0;

      ctx.clearRect(0, 0, w, h);
      ctx.save();
      ctx.translate(ox, oy);

      const sky = ctx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, "#0b1220");
      sky.addColorStop(0.55, "#0a0e16");
      sky.addColorStop(1, "#07080c");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, h);

      for (const st of stars) {
        st.x += st.s * dt * 0.015;
        if (st.x > 1) st.x -= 1;
        ctx.globalAlpha = st.a * (g.phase === "flying" ? 1 : 0.7);
        ctx.fillStyle = "#d9e4f7";
        ctx.beginPath();
        ctx.arc(st.x * w, st.y * h, st.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      const pnow = plot(Math.max(g.elapsed, 0.01), Math.max(g.multiplier, 1.01));
      ctx.strokeStyle = "rgba(238,241,246,0.06)";
      ctx.lineWidth = 1;
      const rows = 4;
      for (let i = 0; i <= rows; i++) {
        const y = pnow.o.y - (i / rows) * pnow.plotH;
        ctx.beginPath();
        ctx.moveTo(pnow.o.x, y);
        ctx.lineTo(w - 16, y);
        ctx.stroke();
        const m = 1 + ((pnow.maxM - 1) * i) / rows;
        ctx.fillStyle = "rgba(139,147,167,0.7)";
        ctx.font = "11px Rajdhani, sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(`${m.toFixed(1)}x`, 10, y + 4);
      }
      const cols = 6;
      for (let i = 0; i <= cols; i++) {
        const x = pnow.o.x + (i / cols) * pnow.plotW;
        ctx.beginPath();
        ctx.moveTo(x, 16);
        ctx.lineTo(x, pnow.o.y);
        ctx.stroke();
      }

      ctx.strokeStyle = "rgba(238,241,246,0.16)";
      ctx.beginPath();
      ctx.moveTo(pnow.o.x, 16);
      ctx.lineTo(pnow.o.x, pnow.o.y);
      ctx.lineTo(w - 16, pnow.o.y);
      ctx.stroke();

      if (points.length > 1) {
        ctx.beginPath();
        ctx.moveTo(pnow.o.x, pnow.o.y);
        ctx.lineTo(points[0]!.x, points[0]!.y);
        for (const pt of points) ctx.lineTo(pt.x, pt.y);
        ctx.lineTo(points[points.length - 1]!.x, pnow.o.y);
        ctx.closePath();
        const fill = ctx.createLinearGradient(0, points[points.length - 1]!.y, 0, pnow.o.y);
        fill.addColorStop(0, "rgba(255,59,59,0.42)");
        fill.addColorStop(1, "rgba(255,59,59,0.02)");
        ctx.fillStyle = fill;
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(points[0]!.x, points[0]!.y);
        for (const pt of points) ctx.lineTo(pt.x, pt.y);
        ctx.strokeStyle = "#ff3b3b";
        ctx.lineWidth = 3;
        ctx.shadowColor = "#ff3b3b";
        ctx.shadowBlur = 12;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      for (const p of particles) {
        const t = 1 - p.life / p.max;
        ctx.globalAlpha = t;
        ctx.fillStyle = p.hue === 0 ? "#ff6b6b" : "#ffd0c0";
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * t, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      let planeX = pnow.o.x;
      let planeY = pnow.o.y;
      let angle = -0.45;
      if (g.phase === "flying" && points.length) {
        const a = points[points.length - 1]!;
        const b = points[Math.max(0, points.length - 4)]!;
        planeX = a.x;
        planeY = a.y;
        angle = Math.atan2(a.y - b.y, a.x - b.x);
      } else if (g.phase === "crashed" && points.length) {
        const a = points[points.length - 1]!;
        const b = points[Math.max(0, points.length - 4)]!;
        angle = Math.atan2(a.y - b.y, a.x - b.x);
        const speed = 180 + flyOff * 240;
        planeX = a.x + Math.cos(angle) * speed * flyOff;
        planeY = a.y + Math.sin(angle) * speed * flyOff;
      }

      drawPlane(ctx, planeX, planeY, angle, g.phase === "crashed" ? Math.max(0, 1 - flyOff * 0.7) : 1);

      ctx.restore();
      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <div ref={wrapRef} className="absolute inset-0">
      <canvas ref={canvasRef} className="h-full w-full" />
    </div>
  );
}

function drawPlane(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  alpha: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.globalAlpha = alpha;

  ctx.shadowColor = "#ff3b3b";
  ctx.shadowBlur = 18;

  ctx.strokeStyle = "#fff5f5";
  ctx.lineWidth = 1.4;
  ctx.lineJoin = "round";
  ctx.fillStyle = "#ff2d2d";
  ctx.beginPath();
  ctx.moveTo(22, 0);
  ctx.quadraticCurveTo(10, -6, -16, -5);
  ctx.lineTo(-20, -11);
  ctx.lineTo(-22, -5);
  ctx.lineTo(-18, -1);
  ctx.lineTo(-22, 5);
  ctx.lineTo(-20, 10);
  ctx.lineTo(-16, 4);
  ctx.quadraticCurveTo(10, 5, 22, 0);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.stroke();

  ctx.fillStyle = "#b81818";
  ctx.beginPath();
  ctx.moveTo(-1, 1);
  ctx.lineTo(-9, 12);
  ctx.lineTo(4, 2);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#ffe4e4";
  ctx.beginPath();
  ctx.ellipse(8, -1, 3.6, 1.6, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.moveTo(22, 0);
  ctx.lineTo(14, -2.2);
  ctx.lineTo(14, 2.2);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}
