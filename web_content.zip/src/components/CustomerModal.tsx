import React, { useState, useEffect } from 'react';
import { X, User, Phone, MapPin, Calendar, Folder as FolderIcon, AlertCircle, Clock } from 'lucide-react';
import { Customer, Folder } from '../types';
import { toInputDateFormat, getReminderDate, formatHindiDate } from '../utils/dateUtils';

interface CustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customerData: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>, editId?: string) => void;
  folders: Folder[];
  currentFolderId: string | 'all';
  customerToEdit?: Customer | null;
}

export const CustomerModal: React.FC<CustomerModalProps> = ({
  isOpen,
  onClose,
  onSave,
  folders,
  currentFolderId,
  customerToEdit,
}) => {
  const isEditing = !!customerToEdit;

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [folderId, setFolderId] = useState('');
  const [dealDate, setDealDate] = useState(toInputDateFormat(new Date()));
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (customerToEdit) {
      setName(customerToEdit.name);
      setPhone(customerToEdit.phone || '');
      setAddress(customerToEdit.address || '');
      setFolderId(customerToEdit.folderId || (folders[0]?.id ?? ''));
      setDealDate(customerToEdit.dealDate || toInputDateFormat(new Date()));
      setNotes(customerToEdit.notes || '');
      setError('');
    } else {
      setName('');
      setPhone('');
      setAddress('');
      // Default to selected folder if not 'all'
      const defaultFolder = (currentFolderId !== 'all' ? currentFolderId : folders[0]?.id) || '';
      setFolderId(defaultFolder);
      setDealDate(toInputDateFormat(new Date()));
      setNotes('');
      setError('');
    }
  }, [customerToEdit, isOpen, currentFolderId, folders]);

  if (!isOpen) return null;

  // Calculate prospective 26th-day reminder date for preview
  const previewReminderDate = dealDate ? getReminderDate(dealDate) : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('कृपया ग्राहक का नाम दर्ज करें।');
      return;
    }
    if (!folderId) {
      setError('कृपया एक इलाका / फोल्डर चुनें।');
      return;
    }
    if (!dealDate) {
      setError('कृपया डील / डिलीवरी की तारीख चुनें।');
      return;
    }

    onSave(
      {
        name: name.trim(),
        phone: phone.trim(),
        address: address.trim(),
        folderId,
        dealDate,
        notes: notes.trim(),
      },
      customerToEdit?.id
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden my-6 border border-orange-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-5 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-yellow-300" />
            <h2 className="text-base sm:text-lg font-bold">
              {isEditing ? 'ग्राहक का रिकॉर्ड बदलें' : 'नया गैस ग्राहक जोड़ें'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-orange-100 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Customer Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ग्राहक का नाम <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <User className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="उदा. रमेश कुमार"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium"
              />
            </div>
          </div>

          {/* Mobile Number & Folder in 2 columns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Mobile Number */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                मोबाइल नंबर (कॉल व WhatsApp हेतु)
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="उदा. 9876543210"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium"
                />
              </div>
            </div>

            {/* Folder selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                इलाका / फोल्डर <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <FolderIcon className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <select
                  required
                  value={folderId}
                  onChange={(e) => setFolderId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium bg-white"
                >
                  <option value="" disabled>
                    इलाका चुनें
                  </option>
                  {folders.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Deal Date & 26th-Day Auto Calculation Preview */}
          <div className="bg-orange-50/70 p-3.5 rounded-xl border border-orange-200">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-orange-600" />
                <span>सिलेंडर डील / पुष्टि तारीख:</span>
              </label>
              <button
                type="button"
                onClick={() => setDealDate(toInputDateFormat(new Date()))}
                className="text-[11px] font-bold text-orange-700 hover:text-orange-900 underline cursor-pointer"
              >
                आज की तारीख भरें
              </button>
            </div>

            <input
              type="date"
              required
              value={dealDate}
              onChange={(e) => setDealDate(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-orange-300 bg-white text-sm font-bold text-slate-800 focus:ring-2 focus:ring-orange-500"
            />

            {/* Live calculation banner */}
            {previewReminderDate && (
              <div className="mt-2.5 p-2 bg-white rounded-lg border border-orange-200/80 text-xs flex items-center gap-2 text-slate-700">
                <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                <div>
                  <span className="font-semibold text-slate-800">
                    अगला 26वां दिन रिमाइंडर:{' '}
                  </span>
                  <span className="font-extrabold text-orange-800">
                    {formatHindiDate(previewReminderDate)}
                  </span>
                  <span className="text-[11px] text-slate-500 ml-1">
                    (सुबह 9:00 बजे अलार्म)
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Full Address */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              पूरा पता (Address)
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="उदा. मकान नं. 12, गली नं. 4, मंदिर के पास..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium resize-none"
              />
            </div>
          </div>

          {/* Extra Notes (strictly non-financial) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              अतिरिक्त टिप्पणी (वैकल्पिक)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="उदा. 14.2 किग्रा घरेलू या कनेक्शन नंबर (कोई पैसे का हिसाब नहीं)"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium"
            />
          </div>

          {/* Modal Action Buttons */}
          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-sm hover:bg-slate-50 transition cursor-pointer"
            >
              रद्द करें
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-sm transition active:scale-95 cursor-pointer"
            >
              {isEditing ? 'बदलाव सुरक्षित करें' : 'नया ग्राहक जोड़ें'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
