import React, { useState, useEffect, useRef } from 'react';
import {
  Scissors,
  Download,
  X,
  Check,
  Camera,
  Upload,
  RefreshCw,
  Monitor,
  Smartphone,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import html2canvas from 'html2canvas';

interface ScreenshotModalProps {
  onClose: () => void;
  onUseAsSource: (imageDataUrl: string) => void;
}

export const ScreenshotModal: React.FC<ScreenshotModalProps> = ({ onClose, onUseAsSource }) => {
  const [screenshotData, setScreenshotData] = useState<string | null>(null);
  const [capturing, setCapturing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeMode, setActiveMode] = useState<'app' | 'display' | 'upload'>('app');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check if browser supports getDisplayMedia
  const hasDisplayMedia =
    typeof navigator !== 'undefined' &&
    navigator.mediaDevices &&
    typeof navigator.mediaDevices.getDisplayMedia === 'function';

  // 1. Instant App Viewport Screenshot via HTML2Canvas (works on mobile, desktop, iframes)
  const captureAppView = async () => {
    setCapturing(true);
    setErrorMsg(null);
    try {
      // Find the main app root container
      const targetElement = document.getElementById('root') || document.body;

      // Temporarily hide the modal itself from the screenshot
      const modalEl = document.getElementById('screenshot-modal-overlay');
      if (modalEl) modalEl.style.visibility = 'hidden';

      const canvas = await html2canvas(targetElement, {
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#070b14',
        scale: window.devicePixelRatio || 1,
      });

      if (modalEl) modalEl.style.visibility = 'visible';

      const dataUrl = canvas.toDataURL('image/png');
      setScreenshotData(dataUrl);
    } catch (err: any) {
      console.error('App screenshot error:', err);
      // Fallback: procedural canvas snapshot
      try {
        const fallbackCanvas = document.createElement('canvas');
        fallbackCanvas.width = 1200;
        fallbackCanvas.height = 700;
        const ctx = fallbackCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#070b14';
          ctx.fillRect(0, 0, 1200, 700);
          ctx.fillStyle = '#6366f1';
          ctx.font = 'bold 36px sans-serif';
          ctx.fillText('BrandMorph & Hey Julli App Screen Snapshot', 60, 100);
          ctx.fillStyle = '#94a3b8';
          ctx.font = '20px sans-serif';
          ctx.fillText('Captured at: ' + new Date().toLocaleString(), 60, 150);
          setScreenshotData(fallbackCanvas.toDataURL('image/png'));
        }
      } catch {
        setErrorMsg('Screenshot capture ho nahi paaya. Kripya image upload option use karein.');
      }
    } finally {
      const modalEl = document.getElementById('screenshot-modal-overlay');
      if (modalEl) modalEl.style.visibility = 'visible';
      setCapturing(false);
    }
  };

  // 2. OS Display / Window Media Capture (Safe Check)
  const captureScreenMedia = async () => {
    if (!hasDisplayMedia) {
      setErrorMsg(
        'Aapka browser ya device "Display Media" allow nahi karta (mobile ya sandboxed iframe). Kripya "Instant App Snapshot" use karein!'
      );
      setActiveMode('app');
      return;
    }

    setCapturing(true);
    setErrorMsg(null);
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { displaySurface: 'browser' } as any,
      });

      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/png');
        setScreenshotData(dataUrl);
      }

      stream.getTracks().forEach((track) => track.stop());
    } catch (err: any) {
      setErrorMsg(err.message || 'Screen capture permission cancel ho gaya.');
    } finally {
      setCapturing(false);
    }
  };

  // 3. File Upload / Gallery select
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setScreenshotData(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Auto trigger capture when opening
  useEffect(() => {
    captureAppView();
  }, []);

  return (
    <div
      id="screenshot-modal-overlay"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
    >
      <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-500/30">
              <Scissors className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">Screenshot & Screen Grab Tool</h3>
              <p className="text-[10px] text-slate-400">Mobile, Tablet, and Desktop Compatible</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Source Mode Selectors */}
        <div className="px-6 pt-4 flex gap-2 border-b border-slate-800/80 bg-slate-900/30">
          <button
            onClick={() => {
              setActiveMode('app');
              captureAppView();
            }}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all ${
              activeMode === 'app'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            App Screen (Direct)
          </button>
          <button
            onClick={() => {
              setActiveMode('display');
              captureScreenMedia();
            }}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all ${
              activeMode === 'display'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Display Sharing {hasDisplayMedia ? '' : '(Desktop Only)'}
          </button>
          <button
            onClick={() => {
              setActiveMode('upload');
              fileInputRef.current?.click();
            }}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all ${
              activeMode === 'upload'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            Upload Photo
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        {/* Modal Body */}
        <div className="p-6 flex flex-col items-center justify-center text-center space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-950/70 border border-rose-500/40 rounded-xl text-rose-200 text-xs w-full flex items-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {capturing && (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
              <p className="text-sm font-semibold text-white">Screen Capture in progress...</p>
              <p className="text-xs text-slate-400">Rendering high-resolution viewport pixels</p>
            </div>
          )}

          {!capturing && screenshotData && (
            <div className="w-full space-y-4">
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-inner">
                <img
                  src={screenshotData}
                  alt="Captured Screenshot"
                  className="w-full h-full object-contain"
                />
                <div className="absolute bottom-2 left-2 px-2.5 py-1 bg-black/70 backdrop-blur-md rounded-lg text-[10px] text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-mono">
                  <Check className="w-3 h-3 text-emerald-400" />
                  Captured Successfully
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-2.5">
                <button
                  onClick={activeMode === 'display' ? captureScreenMedia : captureAppView}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Retake
                </button>
                <a
                  href={screenshotData}
                  download={`screenshot_${Date.now()}.png`}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" /> Download PNG
                </a>
                <button
                  onClick={() => {
                    onUseAsSource(screenshotData);
                    onClose();
                  }}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02]"
                >
                  <Sparkles className="w-4 h-4 text-pink-300" /> Use in Logo / Video Studio
                </button>
              </div>
            </div>
          )}

          {!capturing && !screenshotData && (
            <div className="py-8 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-950 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mx-auto">
                <Scissors className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Capture Device Screen</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  Click below to capture the app window or select a screen. Works seamlessly across phone and desktop.
                </p>
              </div>
              <button
                onClick={captureAppView}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 mx-auto"
              >
                <Scissors className="w-4 h-4" />
                Capture App Screen Now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
