import { useMemo, useState } from 'react';
import {
  ArrowRight,
  BookOpenCheck,
  CheckCircle2,
  Gamepad2,
  GitCompare,
  Layers,
  Link2,
  Puzzle,
  RotateCcw,
  Sparkles,
  TextCursorInput,
  Volume2,
  XCircle,
} from 'lucide-react';
import type {
  VocabEntry,
  WordHubData,
  WordHubGameId,
  WordMasteryRecord,
} from '../types';
import type { SfxType } from '../utils/audio';
import {
  buildWordHubGames,
  type WordHubGameSpec,
} from '../utils/wordHubLogic';

interface WordHubGamesArenaProps {
  word: VocabEntry;
  hub: WordHubData;
  distractorPool: VocabEntry[];
  masteryRecord?: WordMasteryRecord;
  onSpeak: (text: string) => void;
  onSfx: (type: SfxType) => void;
  onEarnXp: (xpDelta: number) => void;
  onGameOutcome: (params: {
    gameId: WordHubGameId;
    completed: boolean;
    correctDelta: number;
    wrongDelta: number;
  }) => void;
}

function getGameIcon(id: WordHubGameId) {
  switch (id) {
    case 'synonym_match':
      return <GitCompare className="h-4 w-4" aria-hidden="true" />;
    case 'antonym_challenge':
      return <RotateCcw className="h-4 w-4" aria-hidden="true" />;
    case 'definition_quiz':
      return <BookOpenCheck className="h-4 w-4" aria-hidden="true" />;
    case 'word_family':
      return <Layers className="h-4 w-4" aria-hidden="true" />;
    case 'collocation_challenge':
      return <Link2 className="h-4 w-4" aria-hidden="true" />;
    case 'context_challenge':
      return <Sparkles className="h-4 w-4" aria-hidden="true" />;
    case 'memory_match':
      return <Puzzle className="h-4 w-4" aria-hidden="true" />;
    case 'sentence_completion':
      return <TextCursorInput className="h-4 w-4" aria-hidden="true" />;
  }
}

export function WordHubGamesArena({
  word,
  hub,
  distractorPool,
  masteryRecord,
  onSpeak,
  onSfx,
  onEarnXp,
  onGameOutcome,
}: WordHubGamesArenaProps) {
  const games = useMemo(
    () => buildWordHubGames(hub, word, distractorPool),
    [hub, word, distractorPool]
  );

  const [activeGameId, setActiveGameId] = useState<WordHubGameId | null>(null);

  // Quiz state
  const [qIdx, setQIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [finished, setFinished] = useState(false);

  // Memory Match state
  const [selectedLeftId, setSelectedLeftId] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [memoryFeedback, setMemoryFeedback] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  const activeGame: WordHubGameSpec | null = useMemo(
    () => games.find((g) => g.id === activeGameId) || null,
    [games, activeGameId]
  );

  const completedSet = useMemo(
    () => new Set<WordHubGameId>(masteryRecord?.completedGames || []),
    [masteryRecord]
  );

  const availableGames = useMemo(() => games.filter((g) => g.available), [games]);
  const unavailableGames = useMemo(() => games.filter((g) => !g.available), [games]);

  const shuffledRightPairs = useMemo(() => {
    if (!activeGame?.memoryPairs) return [];
    // Deterministic reorder so right column isn't identically aligned with left
    const arr = [...activeGame.memoryPairs];
    if (arr.length > 1) {
      const first = arr.shift()!;
      arr.push(first);
    }
    return arr.reverse();
  }, [activeGame]);

  const openGame = (gameId: WordHubGameId) => {
    setActiveGameId(gameId);
    setQIdx(0);
    setSelectedOpt(null);
    setCorrectCount(0);
    setWrongCount(0);
    setFinished(false);
    setSelectedLeftId(null);
    setMatchedIds([]);
    setMemoryFeedback(null);
    onSfx('tap');
  };

  const exitGame = () => {
    setActiveGameId(null);
    setFinished(false);
  };

  // Quiz answer handler
  const handleSelectOption = (optIdx: number) => {
    if (!activeGame || activeGame.kind !== 'quiz' || selectedOpt !== null) return;
    const q = activeGame.questions[qIdx];
    if (!q) return;

    setSelectedOpt(optIdx);
    const isCorrect = optIdx === q.correctIndex;
    if (isCorrect) {
      setCorrectCount((c) => c + 1);
      onSfx('ok');
      onEarnXp(8);
      onGameOutcome({
        gameId: activeGame.id,
        completed: false,
        correctDelta: 1,
        wrongDelta: 0,
      });
    } else {
      setWrongCount((w) => w + 1);
      onSfx('err');
      onGameOutcome({
        gameId: activeGame.id,
        completed: false,
        correctDelta: 0,
        wrongDelta: 1,
      });
    }
  };

  const handleNextQuestion = () => {
    if (!activeGame || activeGame.kind !== 'quiz') return;
    if (qIdx + 1 < activeGame.questions.length) {
      setQIdx((i) => i + 1);
      setSelectedOpt(null);
    } else {
      setFinished(true);
      const passed = correctCount >= Math.ceil(activeGame.questions.length * 0.6);
      if (passed) {
        onSfx('win');
        onEarnXp(15);
        onGameOutcome({
          gameId: activeGame.id,
          completed: true,
          correctDelta: 0,
          wrongDelta: 0,
        });
      }
    }
  };

  // Memory Match handler
  const handlePickRightCard = (rightPairId: string) => {
    if (!activeGame?.memoryPairs || !selectedLeftId) return;
    if (matchedIds.includes(rightPairId)) return;

    const leftPair = activeGame.memoryPairs.find((p) => p.id === selectedLeftId);
    const rightPair = activeGame.memoryPairs.find((p) => p.id === rightPairId);
    if (!leftPair || !rightPair) return;

    if (selectedLeftId === rightPairId) {
      const nextMatched = [...matchedIds, rightPairId];
      setMatchedIds(nextMatched);
      setSelectedLeftId(null);
      setCorrectCount((c) => c + 1);
      setMemoryFeedback({
        ok: true,
        message: `مطابقة صحيحة! «${leftPair.leftText}» = ${leftPair.rightText} (${leftPair.hintAr}).`,
      });
      onSfx('ok');
      onEarnXp(6);
      const done = nextMatched.length === activeGame.memoryPairs.length;
      onGameOutcome({
        gameId: activeGame.id,
        completed: done,
        correctDelta: 1,
        wrongDelta: 0,
      });
      if (done) {
        setFinished(true);
        onSfx('win');
        onEarnXp(15);
      }
    } else {
      setWrongCount((w) => w + 1);
      setMemoryFeedback({
        ok: false,
        message: `غير متطابق — «${leftPair.leftText}» لا تعني «${rightPair.rightText}». جرّب بطاقة أخرى.`,
      });
      onSfx('err');
      onGameOutcome({
        gameId: activeGame.id,
        completed: false,
        correctDelta: 0,
        wrongDelta: 1,
      });
    }
  };

  // Active Game Play View
  if (activeGame) {
    const currentQ = activeGame.kind === 'quiz' ? activeGame.questions[qIdx] : null;
    const totalSteps =
      activeGame.kind === 'memory'
        ? activeGame.memoryPairs?.length || 0
        : activeGame.questions.length;

    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e] sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={exitGame}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              <span>كل الألعاب</span>
            </button>
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                {activeGame.titleAr}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                الكلمة:{' '}
                <span dir="ltr" className="font-en font-bold text-slate-800 dark:text-slate-200">
                  {word.en}
                </span>
              </p>
            </div>
          </div>

          <div className="text-xs font-bold tabular-nums text-slate-500 dark:text-slate-400">
            {activeGame.kind === 'memory'
              ? `${matchedIds.length} / ${totalSteps} أزواج`
              : `سؤال ${Math.min(qIdx + 1, totalSteps)} / ${totalSteps}`}
          </div>
        </div>

        {/* Finished Summary */}
        {finished ? (
          <div className="py-6 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
            </div>
            <h4 className="mt-3 text-lg font-extrabold text-slate-900 dark:text-slate-100">
              أحسنت! أنهيت «{activeGame.titleAr}»
            </h4>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300 tabular-nums">
              إجابات صحيحة: {correctCount} · أخطاء: {wrongCount}
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => openGame(activeGame.id)}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>إعادة التحدي</span>
              </button>
              <button
                type="button"
                onClick={exitGame}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-bold text-white hover:bg-indigo-700"
              >
                <span>اختر لعبة أخرى</span>
              </button>
            </div>
          </div>
        ) : activeGame.kind === 'memory' && activeGame.memoryPairs ? (
          /* Memory Match Interactive Board */
          <div className="mt-5 space-y-4">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              اختر بطاقة إنجليزية من اليمين ثم اختر معناها المطابق من اليسار:
            </p>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2.5">
                {activeGame.memoryPairs.map((pair) => {
                  const isMatched = matchedIds.includes(pair.id);
                  const isSelected = selectedLeftId === pair.id;
                  return (
                    <button
                      key={`L-${pair.id}`}
                      type="button"
                      disabled={isMatched}
                      onClick={() => {
                        setSelectedLeftId(pair.id);
                        setMemoryFeedback(null);
                        onSpeak(pair.leftText);
                      }}
                      className={`flex w-full items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left transition-colors ${
                        isMatched
                          ? 'border-emerald-300 bg-emerald-50/70 text-emerald-700 dark:border-emerald-700/60 dark:bg-emerald-950/30 dark:text-emerald-300'
                          : isSelected
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-800 dark:border-indigo-400 dark:bg-indigo-950/40 dark:text-indigo-200'
                            : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-indigo-300 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100'
                      }`}
                    >
                      <span dir="ltr" className="font-en text-sm font-bold">
                        {pair.leftText}
                      </span>
                      {isMatched ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                      ) : (
                        <Volume2 className="h-3.5 w-3.5 shrink-0 opacity-60" aria-hidden="true" />
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="space-y-2.5">
                {shuffledRightPairs.map((pair) => {
                  const isMatched = matchedIds.includes(pair.id);
                  return (
                    <button
                      key={`R-${pair.id}`}
                      type="button"
                      disabled={isMatched || !selectedLeftId}
                      onClick={() => handlePickRightCard(pair.id)}
                      className={`flex w-full items-center justify-between gap-2 rounded-xl border px-4 py-3 text-right transition-colors disabled:cursor-not-allowed ${
                        isMatched
                          ? 'border-emerald-300 bg-emerald-50/70 text-emerald-700 dark:border-emerald-700/60 dark:bg-emerald-950/30 dark:text-emerald-300'
                          : selectedLeftId
                            ? 'border-slate-200 bg-white text-slate-900 hover:border-indigo-400 hover:bg-indigo-50/40 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100'
                            : 'border-slate-200 bg-slate-50/60 text-slate-500 opacity-75 dark:border-slate-800 dark:bg-slate-900/40 dark:text-slate-400'
                      }`}
                    >
                      <span className="text-sm font-bold">{pair.rightText}</span>
                      {isMatched && (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {memoryFeedback && (
              <div
                className={`flex items-start gap-2 rounded-xl border p-3.5 text-xs font-bold ${
                  memoryFeedback.ok
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-700/60 dark:bg-emerald-950/30 dark:text-emerald-300'
                    : 'border-rose-300 bg-rose-50 text-rose-800 dark:border-rose-700/60 dark:bg-rose-950/30 dark:text-rose-300'
                }`}
              >
                {memoryFeedback.ok ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                ) : (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                )}
                <span>{memoryFeedback.message}</span>
              </div>
            )}
          </div>
        ) : currentQ ? (
          /* Standard Interactive Quiz View */
          <div className="mt-5 space-y-4">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/60">
              <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {currentQ.promptAr}
              </p>
              {currentQ.promptEn && (
                <p
                  dir="ltr"
                  className="mt-2.5 text-left font-en text-base leading-relaxed font-semibold text-indigo-700 dark:text-cyan-300"
                >
                  {currentQ.promptEn}
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {currentQ.options.map((opt, idx) => {
                const answered = selectedOpt !== null;
                const isPicked = selectedOpt === idx;
                const isRight = idx === currentQ.correctIndex;
                let cls =
                  'border-slate-200 bg-white text-slate-800 hover:border-indigo-400 hover:bg-indigo-50/40 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100 dark:hover:border-indigo-500';
                if (answered) {
                  if (isRight) {
                    cls =
                      'border-emerald-500 bg-emerald-50 text-emerald-800 dark:border-emerald-500 dark:bg-emerald-950/40 dark:text-emerald-200';
                  } else if (isPicked && !isRight) {
                    cls =
                      'border-rose-500 bg-rose-50 text-rose-800 dark:border-rose-500 dark:bg-rose-950/40 dark:text-rose-200';
                  } else {
                    cls =
                      'border-slate-200 bg-slate-50 text-slate-400 opacity-70 dark:border-slate-800 dark:bg-slate-900/40 dark:text-slate-500';
                  }
                }
                const isEnglishOpt = /^[A-Za-z0-9\s'".,!?-]+$/.test(opt);

                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={answered}
                    onClick={() => handleSelectOption(idx)}
                    className={`flex min-h-12 items-center justify-between gap-2 rounded-xl border px-4 py-3 text-sm font-bold transition-colors ${cls}`}
                  >
                    <span
                      dir={isEnglishOpt ? 'ltr' : 'rtl'}
                      className={isEnglishOpt ? 'font-en text-left' : 'text-right'}
                    >
                      {opt}
                    </span>
                    {answered && isRight && (
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                    )}
                    {answered && isPicked && !isRight && (
                      <XCircle className="h-4 w-4 shrink-0 text-rose-600 dark:text-rose-400" aria-hidden="true" />
                    )}
                  </button>
                );
              })}
            </div>

            {selectedOpt !== null && (
              <div
                className={`space-y-3 rounded-xl border p-4 ${
                  selectedOpt === currentQ.correctIndex
                    ? 'border-emerald-300 bg-emerald-50/70 dark:border-emerald-700/60 dark:bg-emerald-950/25'
                    : 'border-rose-300 bg-rose-50/60 dark:border-rose-700/60 dark:bg-rose-950/25'
                }`}
              >
                <div className="flex items-center gap-2 text-xs font-extrabold sm:text-sm">
                  {selectedOpt === currentQ.correctIndex ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                      <span className="text-emerald-800 dark:text-emerald-300">
                        إجابة صحيحة (+8 XP)
                      </span>
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4 w-4 text-rose-600 dark:text-rose-400" aria-hidden="true" />
                      <span className="text-rose-800 dark:text-rose-300">
                        إجابة غير صحيحة — الإجابة الصحيحة:{' '}
                        <span className="font-en underline">{currentQ.correctLabel}</span>
                      </span>
                    </>
                  )}
                </div>

                <p className="text-xs leading-relaxed font-medium text-slate-700 dark:text-slate-200">
                  {currentQ.explanationAr}
                </p>

                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={handleNextQuestion}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-bold text-white hover:bg-indigo-700"
                  >
                    <span>
                      {qIdx + 1 < activeGame.questions.length ? 'السؤال التالي' : 'عرض النتيجة'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </section>
    );
  }

  // Selector Grid of Word-Specific Games
  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
              <Gamepad2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                ألعاب وتحديات مخصصة لكلمة «{word.en}»
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                الإتقان الحقيقي يُكتسب بحل التحديات العملية وإثبات الفهم وليس بمجرد القراءة.
              </p>
            </div>
          </div>

          <span className="text-xs font-bold tabular-nums text-slate-500 dark:text-slate-400">
            مكتمل: {completedSet.size} / {availableGames.length}
          </span>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {availableGames.map((game) => {
            const isDone = completedSet.has(game.id);
            return (
              <button
                key={game.id}
                type="button"
                onClick={() => openGame(game.id)}
                className={`group flex items-start justify-between gap-3 rounded-xl border p-4 text-right transition-colors ${
                  isDone
                    ? 'border-emerald-200 bg-emerald-50/40 hover:border-emerald-300 dark:border-emerald-800/60 dark:bg-emerald-950/20'
                    : 'border-slate-200 bg-slate-50/60 hover:border-indigo-400 hover:bg-indigo-50/30 dark:border-slate-800 dark:bg-slate-900/50 dark:hover:border-indigo-500'
                }`}
              >
                <div className="flex min-w-0 items-start gap-3">
                  <span
                    className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                      isDone
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300'
                        : 'bg-white text-indigo-600 shadow-2xs dark:bg-slate-800 dark:text-indigo-400'
                    }`}
                  >
                    {getGameIcon(game.id)}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-sm font-extrabold text-slate-900 dark:text-slate-100">
                      <span>{game.titleAr}</span>
                      {isDone && (
                        <CheckCircle2
                          className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400"
                          aria-hidden="true"
                        />
                      )}
                    </div>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                      {game.subtitleAr}
                    </p>
                  </div>
                </div>
                <span className="shrink-0 self-center text-xs font-bold text-indigo-600 group-hover:underline dark:text-indigo-400">
                  {isDone ? 'إعادة' : 'ابدأ'}
                </span>
              </button>
            );
          })}
        </div>

        {unavailableGames.length > 0 && (
          <div className="mt-4 border-t border-slate-100 pt-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
            تحديات غير منطبقة لغوياً على هذه الكلمة (لا نختلق بيانات غير دقيقة):{' '}
            {unavailableGames.map((g) => g.titleAr).join(' · ')}
          </div>
        )}
      </section>
    </div>
  );
}
