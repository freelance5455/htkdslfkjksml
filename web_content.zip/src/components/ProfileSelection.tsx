import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, Check, Ghost, Plus, User } from 'lucide-react';
import { AVATAR_OPTIONS, Profile, WALLPAPER_OPTIONS } from '../types/system';
import { soundEngine } from '../audio/soundEngine';
import { screenReader } from '../audio/screenReader';
import { useSwipeNavigation } from '../hooks/useSwipeNavigation';
import { StarfieldBackdrop } from './StarfieldBackdrop';

interface ProfileSelectionProps {
  profiles: Profile[];
  activeProfileId: string;
  onSelectProfile: (profile: Profile) => void;
  onAddProfile: (name: string, avatarUrl: string) => Profile;
  onUnlockAudio: () => void;
  isRotatedPortrait?: boolean;
  fromBoot?: boolean;
}

const ADD_TILE_ID = '__add_profile__';

export const ProfileSelection: React.FC<ProfileSelectionProps> = ({
  profiles,
  activeProfileId,
  onSelectProfile,
  onAddProfile,
  onUnlockAudio,
  isRotatedPortrait = false,
  fromBoot = false,
}) => {
  const [highlightedId, setHighlightedId] = useState<string | null>(
    activeProfileId || profiles[0]?.id || ADD_TILE_ID
  );
  const highlightedIdRef = useRef<string | null>(highlightedId);
  highlightedIdRef.current = highlightedId;
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});
  const [entering, setEntering] = useState(false);

  // Add Profile Modal state
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState(AVATAR_OPTIONS[0].url);
  const [nameError, setNameError] = useState('');
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const lastWheelStepRef = useRef(0);

  const tileOrder = useMemo(
    () => [ADD_TILE_ID, ...profiles.map((p) => p.id)],
    [profiles]
  );

  const describeTile = useCallback(
    (id: string | null): string => {
      if (!id) return "No tile highlighted. Swipe or tap any square to select a player.";
      if (id === ADD_TILE_ID) {
        return 'Add Profile. Create a new player slot with custom avatar, saved wallpaper, and personal progression. Double-tap to open.';
      }
      const target = profiles.find((p) => p.id === id);
      if (!target) return '';
      const wp =
        WALLPAPER_OPTIONS.find((w) => w.id === target.settings.wallpaperId) ??
        WALLPAPER_OPTIONS[0];
      return `${target.name}. Level ${target.progression.level}, using ${wp.name} wallpaper. Double-tap to launch into dashboard.`;
    },
    [profiles]
  );

  // Start space ambience + starfield clash sound after boot, and announce screen cleanly
  useEffect(() => {
    soundEngine.startMusic('profile');
    if (fromBoot) {
      soundEngine.playStarfieldClash();
    }
    const timer = window.setTimeout(() => {
      screenReader.speak(
        `Who's playing today? ${describeTile(highlightedIdRef.current)}`,
        { immediate: true }
      );
    }, fromBoot ? 820 : 60);
    return () => window.clearTimeout(timer);
    // Intentionally run on mount of Profile Selection
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (isCreating) {
      window.setTimeout(() => nameInputRef.current?.focus(), 60);
    }
  }, [isCreating]);

  const activateProfile = useCallback(
    (profile: Profile) => {
      if (entering) return;
      onUnlockAudio();
      soundEngine.playSelect();
      screenReader.stop();
      setEntering(true);
      window.setTimeout(() => {
        onSelectProfile(profile);
      }, 240);
    },
    [entering, onSelectProfile, onUnlockAudio]
  );

  const openAddModal = useCallback(() => {
    onUnlockAudio();
    soundEngine.playSelect();
    setNewName('');
    setNameError('');
    setSelectedAvatarUrl(AVATAR_OPTIONS[0].url);
    setIsCreating(true);
    screenReader.speak(
      'Add Profile. Enter a player name and choose an avatar, then select Create Profile.',
      { immediate: true }
    );
  }, [onUnlockAudio]);

  const highlightTile = useCallback(
    (nextId: string | null) => {
      highlightedIdRef.current = nextId;
      setHighlightedId(nextId);
      const speech = describeTile(nextId);
      if (speech) screenReader.speak(speech, { immediate: true });
    },
    [describeTile]
  );

  const stepTile = useCallback(
    (direction: 'left' | 'right') => {
      if (isCreating || tileOrder.length === 0) return;
      onUnlockAudio();
      const prev = highlightedIdRef.current;
      const nextId =
        !prev || !tileOrder.includes(prev)
          ? direction === 'left'
            ? tileOrder[0]
            : tileOrder[tileOrder.length - 1]
          : tileOrder[
              direction === 'right'
                ? (tileOrder.indexOf(prev) + 1) % tileOrder.length
                : (tileOrder.indexOf(prev) - 1 + tileOrder.length) % tileOrder.length
            ];

      highlightedIdRef.current = nextId;
      setHighlightedId(nextId);

      if (direction === 'left') soundEngine.playScrollLeft();
      else soundEngine.playScrollRight();
      const speech = describeTile(nextId);
      if (speech) screenReader.speak(speech, { immediate: true });
    },
    [describeTile, isCreating, onUnlockAudio, tileOrder]
  );

  const { swipeHandlers, shouldSuppressClick } = useSwipeNavigation({
    onSwipeLeft: () => stepTile('left'),
    onSwipeRight: () => stepTile('right'),
    isRotatedPortrait,
    stepPx: 54,
    disabled: isCreating,
  });

  const handleTileTap = (id: string) => {
    if (shouldSuppressClick()) return;
    onUnlockAudio();

    if (highlightedId === id) {
      if (id === ADD_TILE_ID) {
        openAddModal();
      } else {
        const target = profiles.find((p) => p.id === id);
        if (target) activateProfile(target);
      }
      return;
    }

    if (highlightedId && tileOrder.includes(highlightedId)) {
      const prevIdx = tileOrder.indexOf(highlightedId);
      const nextIdx = tileOrder.indexOf(id);
      if (nextIdx > prevIdx) soundEngine.playScrollRight();
      else if (nextIdx < prevIdx) soundEngine.playScrollLeft();
      else soundEngine.playHighlight();
    } else {
      soundEngine.playHighlight();
    }
    highlightTile(id);
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (isCreating) return;
    const dominantX = Math.abs(e.deltaX) >= Math.abs(e.deltaY) ? e.deltaX : 0;
    const delta = dominantX !== 0 ? dominantX : e.shiftKey ? e.deltaY : 0;
    if (Math.abs(delta) < 14) return;

    const now = performance.now();
    if (now - lastWheelStepRef.current < 160) return;
    lastWheelStepRef.current = now;

    if (delta > 0) stepTile('right');
    else stepTile('left');
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isCreating) {
        if (e.key === 'Escape') {
          e.preventDefault();
          soundEngine.playBack();
          setIsCreating(false);
          screenReader.speak('Cancelled Add Profile.');
        }
        return;
      }

      onUnlockAudio();

      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        stepTile('right');
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        e.preventDefault();
        stepTile('left');
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        if (highlightedId === ADD_TILE_ID) {
          openAddModal();
        } else {
          const active = profiles.find((p) => p.id === highlightedId);
          if (active) {
            activateProfile(active);
          } else {
            const fallbackId = profiles[0]?.id ?? ADD_TILE_ID;
            highlightTile(fallbackId);
            soundEngine.playHighlight();
          }
        }
      } else if (e.key === 'Escape' && highlightedId) {
        e.preventDefault();
        highlightTile(null);
        soundEngine.playBack();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isCreating,
    profiles,
    highlightedId,
    activateProfile,
    openAddModal,
    onUnlockAudio,
    stepTile,
    highlightTile,
  ]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newName.trim();
    if (!trimmed) {
      setNameError('Please enter a profile name.');
      soundEngine.playBack();
      screenReader.speak('Please enter a profile name before creating.', { immediate: true });
      nameInputRef.current?.focus();
      return;
    }

    soundEngine.playSelect();
    const created = onAddProfile(trimmed, selectedAvatarUrl);
    setIsCreating(false);
    highlightedIdRef.current = created.id;
    setHighlightedId(created.id);
    screenReader.speak(
      `Profile ${created.name} created and highlighted. Double-tap to launch into dashboard.`,
      { immediate: true }
    );
  };

  return (
    <motion.div
      initial={
        fromBoot
          ? { opacity: 0, scale: 1.15, rotate: -40 }
          : { opacity: 0, scale: 1.03, rotate: 0 }
      }
      animate={
        entering
          ? { opacity: 0, scale: 1.04, rotate: 0 }
          : { opacity: 1, x: 0, scale: 1, rotate: 0 }
      }
      transition={{ duration: fromBoot ? 0.52 : 0.24, ease: [0.16, 1, 0.3, 1] }}
      {...swipeHandlers}
      onWheel={handleWheel}
      className="relative w-full h-full flex flex-col justify-between overflow-hidden bg-[#020308] touch-none"
    >
      {/* Dark Cosmos Backdrop with Floating Stars */}
      <StarfieldBackdrop />

      {/* Top Header */}
      <header className="relative z-10 w-full px-10 pt-8 flex items-center justify-between">
        <span className="font-display text-sm font-semibold tracking-wider text-sky-300 uppercase whitespace-nowrap">
          Retro Game System
        </span>
        <span className="text-xs text-slate-300 whitespace-nowrap">
          Swipe or tap to highlight · Double-tap to enter
        </span>
      </header>

      {/* Center Square-Based Profile Grid */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-8">
        <h1
          className="font-display text-3xl md:text-5xl font-semibold tracking-tight text-white mb-10 text-center"
          style={{ textWrap: 'balance' }}
        >
          Who&apos;s playing today?
        </h1>

        <div className="flex items-start justify-center gap-7 md:gap-9 flex-wrap max-w-5xl">
          {/* LEFT: Add Profile Square with Plus Icon */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => handleTileTap(ADD_TILE_ID)}
              aria-pressed={highlightedId === ADD_TILE_ID}
              aria-label="Add Profile"
              className={`group relative w-40 h-40 md:w-48 md:h-48 aspect-square rounded-none flex items-center justify-center transition-all duration-150 focus:outline-none cursor-pointer ${
                highlightedId === ADD_TILE_ID
                  ? 'border-2 border-sky-400 shadow-[0_0_28px_rgba(56,189,248,0.34)] scale-[1.03] bg-[#0b1528] text-sky-300'
                  : 'border border-white/22 hover:border-sky-300/60 bg-[#070b14]/90 text-sky-200'
              }`}
            >
              <Plus className="w-14 h-14 stroke-[1.75] transition-transform duration-150 group-hover:scale-105" />

              {highlightedId === ADD_TILE_ID && (
                <>
                  <span className="pointer-events-none absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-sky-200" />
                  <span className="pointer-events-none absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-sky-200" />
                  <span className="pointer-events-none absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-sky-200" />
                  <span className="pointer-events-none absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-sky-200" />
                </>
              )}
            </button>

            <div className="mt-4 flex flex-col items-center">
              <span
                className={`font-display text-lg font-semibold tracking-tight transition-colors ${
                  highlightedId === ADD_TILE_ID ? 'text-sky-300' : 'text-slate-100'
                }`}
              >
                Add Profile
              </span>
              <span className="mt-1 text-xs text-slate-400 h-4">
                {highlightedId === ADD_TILE_ID ? 'Double-tap to create' : 'New player'}
              </span>
            </div>
          </div>

          {/* PLAYER PROFILES */}
          {profiles.map((profile) => {
            const isHighlighted = highlightedId === profile.id;
            const hasImgError = imgErrors[profile.id];
            const profileWp =
              WALLPAPER_OPTIONS.find((w) => w.id === profile.settings.wallpaperId) ??
              WALLPAPER_OPTIONS[0];

            return (
              <div key={profile.id} className="flex flex-col items-center">
                <button
                  type="button"
                  onClick={() => handleTileTap(profile.id)}
                  aria-pressed={isHighlighted}
                  aria-label={`${profile.name} profile`}
                  className={`group relative w-40 h-40 md:w-48 md:h-48 aspect-square rounded-none overflow-hidden transition-all duration-150 focus:outline-none cursor-pointer ${
                    isHighlighted
                      ? 'border-2 border-sky-400 shadow-[0_0_28px_rgba(56,189,248,0.34)] scale-[1.03] bg-[#0b1528]'
                      : 'border border-white/22 hover:border-sky-300/60 bg-[#070b14]'
                  }`}
                >
                  {!hasImgError ? (
                    <img
                      src={profile.avatarUrl}
                      alt={profile.name}
                      referrerPolicy="no-referrer"
                      draggable={false}
                      onError={() =>
                        setImgErrors((prev) => ({ ...prev, [profile.id]: true }))
                      }
                      className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#0e1729] to-[#070b14]">
                      {profile.id === 'ghost-games' ? (
                        <Ghost className="w-20 h-20 text-sky-300" />
                      ) : (
                        <User className="w-20 h-20 text-sky-300" />
                      )}
                    </div>
                  )}

                  {/* Per-profile saved theme & level indicator */}
                  <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between px-2 py-1 bg-black/75 border border-white/15">
                    <span className="flex items-center gap-1.5 text-[10px] font-medium text-slate-200 truncate">
                      <span
                        className="w-2 h-2 shrink-0"
                        style={{ backgroundColor: profileWp.accentHex }}
                      />
                      <span className="truncate">{profileWp.name}</span>
                    </span>
                    <span className="text-[10px] font-mono-tabular text-sky-300 ml-2 shrink-0">
                      Lv.{profile.progression.level}
                    </span>
                  </div>

                  {isHighlighted && (
                    <>
                      <span className="pointer-events-none absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-sky-200" />
                      <span className="pointer-events-none absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-sky-200" />
                      <span className="pointer-events-none absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-sky-200" />
                      <span className="pointer-events-none absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-sky-200" />
                    </>
                  )}
                </button>

                <div className="mt-4 flex flex-col items-center">
                  <span
                    className={`font-display text-lg font-semibold tracking-tight transition-colors ${
                      isHighlighted ? 'text-sky-300' : 'text-slate-100'
                    }`}
                  >
                    {profile.name}
                  </span>
                  <span className="mt-1 text-xs text-slate-400 h-4">
                    {isHighlighted
                      ? 'Double-tap to launch'
                      : `${profile.progression.sessionsCount} ${
                          profile.progression.sessionsCount === 1 ? 'session' : 'sessions'
                        }`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <footer className="relative z-10 w-full px-10 pb-6 flex items-center justify-between text-xs text-slate-400">
        <span>Active System · Starfield Mode</span>
        <span>Swipe, Press Enter, or Double-Tap Square</span>
      </footer>

      {/* ADD PROFILE MODAL */}
      <AnimatePresence>
        {isCreating && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 z-30 flex flex-col bg-[#040710]/96 p-8 md:p-10"
          >
            <div className="flex items-center justify-between border-b border-white/12 pb-5">
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onFocus={() =>
                    screenReader.speak('Back button. Returns to profile selection.')
                  }
                  onClick={() => {
                    soundEngine.playBack();
                    setIsCreating(false);
                    screenReader.speak('Returned to profile selection.');
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
                >
                  <ArrowLeft className="w-4 h-4 text-sky-300" />
                  <span>Back</span>
                </button>
                <h2 className="font-display text-2xl font-semibold tracking-tight text-white">
                  Add Profile
                </h2>
              </div>

              <span className="text-xs text-slate-400">New Player Setup</span>
            </div>

            <form
              onSubmit={handleCreateSubmit}
              className="flex-1 overflow-y-auto console-scroll flex flex-col justify-center max-w-3xl w-full mx-auto gap-6 py-4"
            >
              <div>
                <label
                  htmlFor="new-profile-name"
                  className="block font-display text-sm font-semibold text-slate-200 mb-2"
                >
                  Profile Name
                </label>
                <input
                  id="new-profile-name"
                  ref={nameInputRef}
                  type="text"
                  maxLength={24}
                  value={newName}
                  onFocus={() =>
                    screenReader.speak('Profile Name text box. Type a player name.')
                  }
                  onChange={(e) => {
                    setNewName(e.target.value);
                    if (nameError) setNameError('');
                    soundEngine.playScroll();
                  }}
                  placeholder="Enter player name..."
                  className="w-full bg-[#0a101d] border border-white/20 focus:border-sky-400 px-4 py-3.5 text-base text-white placeholder:text-slate-500 focus:outline-none transition-colors"
                />
                {nameError && (
                  <p className="mt-2 text-xs text-sky-300">{nameError}</p>
                )}
              </div>

              <div>
                <div className="font-display text-sm font-semibold text-slate-200 mb-3">
                  Choose an Avatar
                </div>
                <div className="grid grid-cols-5 gap-4">
                  {AVATAR_OPTIONS.map((av) => {
                    const isSelected = selectedAvatarUrl === av.url;
                    const hasErr = imgErrors[av.id];

                    return (
                      <button
                        key={av.id}
                        type="button"
                        onClick={() => {
                          soundEngine.playHighlight();
                          setSelectedAvatarUrl(av.url);
                          screenReader.speak(`${av.label} avatar selected.`);
                        }}
                        className={`group relative aspect-square overflow-hidden transition-all cursor-pointer focus:outline-none ${
                          isSelected
                            ? 'border-2 border-sky-400 shadow-[0_0_22px_rgba(56,189,248,0.3)] scale-[1.03]'
                            : 'border border-white/20 hover:border-sky-300/60 opacity-80 hover:opacity-100'
                        }`}
                      >
                        {!hasErr ? (
                          <img
                            src={av.url}
                            alt={av.label}
                            referrerPolicy="no-referrer"
                            draggable={false}
                            onError={() =>
                              setImgErrors((prev) => ({ ...prev, [av.id]: true }))
                            }
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-[#0d1322]">
                            <User className="w-8 h-8 text-sky-300" />
                          </div>
                        )}

                        {isSelected && (
                          <span className="absolute top-1.5 right-1.5 w-6 h-6 bg-sky-400 text-slate-950 flex items-center justify-center">
                            <Check className="w-4 h-4 stroke-[2.5]" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onFocus={() => screenReader.speak('Cancel button.')}
                  onClick={() => {
                    soundEngine.playBack();
                    setIsCreating(false);
                    screenReader.speak('Cancelled Add Profile.');
                  }}
                  className="px-5 py-2.5 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-slate-200 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  onFocus={() =>
                    screenReader.speak('Create Profile button. Press Enter or tap to save new profile.')
                  }
                  className="px-6 py-2.5 bg-sky-400 hover:bg-sky-300 text-slate-950 text-sm font-semibold transition-colors cursor-pointer"
                >
                  Create Profile
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
