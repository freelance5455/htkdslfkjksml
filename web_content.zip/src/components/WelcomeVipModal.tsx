import React from 'react';
import { Send, ExternalLink, X } from 'lucide-react';
import { cyberAudio } from '../audio';

interface WelcomeVipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WelcomeVipModal: React.FC<WelcomeVipModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in">
      <div className="relative w-full max-w-sm rounded-3xl bg-[#04140d] border border-emerald-500/60 overflow-hidden shadow-[0_0_40px_rgba(34,197,94,0.4)] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            cyberAudio.playClick();
            onClose();
          }}
          className="absolute top-3 right-3 z-30 w-8 h-8 rounded-full bg-black/70 hover:bg-emerald-950 border border-emerald-400/60 flex items-center justify-center text-emerald-300 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Banner */}
        <div className="relative w-full h-[140px] overflow-hidden z-10 bg-black">
          <img
            src="/assets/gx_popup_banner_1787560871524-CpGH9w08.jpg"
            alt="GX TEAM VIP Banner"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
            onError={(e) => {
              // fallback if not available
              (e.target as HTMLImageElement).src = 'https://i.ibb.co.com/vxGQ7hV9/IMG-20260823-131044-063.jpg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#04140d] via-[#04140d]/40 to-transparent" />
        </div>

        {/* Content Body */}
        <div className="w-full px-5 pb-5 pt-0 flex flex-col items-center relative z-20">
          {/* Crown badge */}
          <div className="-mt-8 w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500/30 via-yellow-400/20 to-emerald-500/30 border-2 border-amber-400 flex items-center justify-center mb-2 shadow-[0_4px_20px_rgba(245,158,11,0.5)] backdrop-blur-md">
            <span className="text-2xl drop-shadow">👑</span>
          </div>

          <h2 className="text-base font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-yellow-300 to-emerald-300 uppercase font-mono text-center mb-2">
            WELCOME GXTEAM
          </h2>

          {/* Bengali Message Box */}
          <div className="w-full p-3 rounded-xl bg-black/50 border border-emerald-500/30 mb-4 shadow-inner">
            <p className="text-[12px] text-slate-100 font-medium leading-relaxed text-center font-sans">
              এই হ্যাক টা ব্যবহার করার জন্য অবশ্যই এডমিনে কাছে পাসওয়ার্ড নিতে হবে এবং তাদের অফিসিয়াল লিংক থেকে একাউন্ট খুলতে হবে ✅
            </p>
          </div>

          {/* Action Buttons */}
          <div className="w-full flex flex-col gap-2.5">
            <a
              href="http://t.me/GX_OWNER_ARIF_SUPPORT"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-700 hover:from-sky-500 hover:to-blue-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(2,132,199,0.45)] active:scale-98 transition text-center cursor-pointer decoration-transparent border border-sky-300/50"
            >
              <Send className="w-3.5 h-3.5 shrink-0" />
              <span>CONTACT ADMIN</span>
            </a>

            <a
              href="https://dkwin9.com/#/register?invitationCode=33378743953"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(234,88,12,0.45)] active:scale-98 transition text-center cursor-pointer decoration-transparent border border-amber-300/50"
            >
              <ExternalLink className="w-3.5 h-3.5 shrink-0" />
              <span>OFFICIAL LINK</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
export default WelcomeVipModal;
