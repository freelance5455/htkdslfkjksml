import { format } from "date-fns";
import { categoryMeta, reportDate } from "@/lib/reportStats";

const statusColor = {
  reported: "#d99a2b",
  in_progress: "#2f7d95",
  resolved: "#16653f",
};

export default function ReportTimeline({ report, updates }) {
  const entries = [
    {
      id: "origin",
      status: "reported",
      note: "Report sent by a resident.",
      author_name: "Resident",
      created_date: reportDate(report),
    },
    ...updates,
  ];

  return (
    <ol className="relative space-y-5 border-l border-border pl-5">
      {entries.map((entry) => (
        <li key={entry.id} className="relative">
          <span
            className="absolute -left-[26px] top-1 h-2.5 w-2.5 rounded-full ring-4 ring-card"
            style={{ backgroundColor: statusColor[entry.status] || categoryMeta().color }}
          />
          <p className="text-[13px] font-medium text-foreground">
            {entry.note || "Status updated"}
          </p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {entry.author_name || "City team"}
            {entry.created_date
              ? ` · ${format(new Date(entry.created_date), "d MMM yyyy, h:mm a")}`
              : ""}
          </p>
        </li>
      ))}
    </ol>
  );
}