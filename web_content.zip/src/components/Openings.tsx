import { useEffect, useMemo, useState } from "react";
import { Chess } from "chess.js";
import Board from "./Board";
import { OPENINGS } from "../data/content";
import { cn } from "../utils/cn";

export default function Openings() {
  const [index, setIndex] = useState(0);
  const [ply, setPly] = useState(0);
  const [playing, setPlaying] = useState(false);
  const opening = OPENINGS[index];

  useEffect(() => {
    setPly(0);
    setPlaying(false);
  }, [index]);

  useEffect(() => {
    if (!playing) return;
    if (ply >= opening.moves.length) {
      setPlaying(false);
      return;
    }
    const t = window.setTimeout(() => setPly((p) => p + 1), 800);
    return () => window.clearTimeout(t);
  }, [playing, ply, opening.moves.length]);

  const { fen, lastMove } = useMemo(() => {
    const g = new Chess();
    let last: { from: string; to: string } | null = null;
    for (let i = 0; i < ply; i += 1) {
      try {
        const mv = g.move(opening.moves[i]);
        if (mv) last = { from: mv.from, to: mv.to };
      } catch {
        break;
      }
    }
    return { fen: g.fen(), lastMove: last };
  }, [opening, ply]);

  const note = opening.notes[ply - 1];

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div>
        <Board fen={fen} lastMove={lastMove} />
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            onClick={() => setPly(0)}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 hover:bg-white/10"
          >
            ⏮ Start
          </button>
          <button
            onClick={() => setPly((p) => Math.max(0, p - 1))}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 hover:bg-white/10"
          >
            ← Back
          </button>
          <button
            onClick={() => setPlaying((p) => !p)}
            className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
          >
            {playing ? "❚❚ Pause" : "▶ Auto-play"}
          </button>
          <button
            onClick={() => setPly((p) => Math.min(opening.moves.length, p + 1))}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 hover:bg-white/10"
          >
            Next →
          </button>
          <span className="ml-auto text-xs text-neutral-500">
            move {Math.ceil(ply / 2) || 0} of {Math.ceil(opening.moves.length / 2)}
          </span>
        </div>
      </div>

      <aside className="flex flex-col gap-4">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-lg font-semibold text-neutral-50">{opening.name}</h3>
            <span className="rounded-lg bg-black/40 px-2 py-1 text-xs font-semibold text-amber-300">
              {opening.eco}
            </span>
          </div>
          <p className="text-xs uppercase tracking-wider text-emerald-400">{opening.style}</p>
          <p className="mt-3 text-sm text-neutral-300">{opening.idea}</p>
          {note && (
            <p className="mt-3 rounded-xl bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
              {note}
            </p>
          )}
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Main line
          </p>
          <div className="flex flex-wrap gap-1 font-mono text-sm">
            {opening.moves.map((m, i) => (
              <button
                key={`${m}-${i}`}
                onClick={() => setPly(i + 1)}
                className={cn(
                  "rounded-md px-2 py-1 transition",
                  i < ply ? "bg-white/10 text-neutral-100" : "text-neutral-400 hover:bg-white/5",
                  i === ply - 1 && "bg-emerald-500/30 text-emerald-100",
                )}
              >
                {i % 2 === 0 && <span className="mr-1 text-neutral-500">{i / 2 + 1}.</span>}
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Repertoire
          </p>
          <div className="grid gap-1">
            {OPENINGS.map((o, i) => (
              <button
                key={o.id}
                onClick={() => setIndex(i)}
                className={cn(
                  "flex items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition",
                  i === index
                    ? "bg-emerald-500/15 text-emerald-200"
                    : "text-neutral-300 hover:bg-white/5",
                )}
              >
                <span>{o.name}</span>
                <span className="font-mono text-xs text-neutral-500">{o.eco}</span>
              </button>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
