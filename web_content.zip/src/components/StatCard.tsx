export default function StatCard({ label, value, pct, sub }: { label: string; value: string; pct?: number; sub?: string }) {
  return (
    <div className="card">
      <div className="k">{label}</div>
      <div className="big">{value}</div>
      {pct !== undefined && <div className="meter"><i style={{ width: pct + "%" }} /></div>}
      {sub && <div className="sub">{sub}</div>}
    </div>
  );
}
