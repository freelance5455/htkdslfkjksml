import React from 'react';
import {
  X,
  Plus,
  MessageSquare,
  Search,
  Trash2,
  Mic,
  Smartphone,
  Eye,
  Volume2,
  VolumeX,
  Radio,
  HardDrive,
  Download,
  Sparkles,
  LogOut,
  Camera,
  Play,
  Share2,
  SlidersHorizontal,
  ChevronRight,
  Flame,
  HelpCircle,
  ShieldCheck,
  Edit2
} from 'lucide-react';
import { ChatSession, UserProfile, PersonaType, ToneType } from '../types';

interface HamburgerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  // User Profile & Login
  userProfile: UserProfile;
  onOpenLoginModal: () => void;
  // Chat Sessions & History
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (sessionId: string) => void;
  onNewChat: () => void;
  onDeleteSession: (sessionId: string) => void;
  onRenameSession: (sessionId: string, newTitle: string) => void;
  // Modals & Tools
  onOpenSearchModal: () => void;
  onOpenAmbientVoiceModal: () => void;
  onOpenVoiceTriggersModal: () => void;
  onOpenPhoneToolsModal: () => void;
  onOpenScreenReaderModal: () => void;
  onOpenStorageModal: () => void;
  // Direct Voice & Controls
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  continuousListening: boolean;
  onToggleContinuousListening: () => void;
  // Persona & Tone
  currentPersona: PersonaType;
  onChangePersona: (p: PersonaType) => void;
  currentTone: ToneType;
  onChangeTone: (t: ToneType) => void;
  // Chat actions
  onClearCurrentChat: () => void;
  onExportChat: () => void;
  // Storage Stats
  storageUsed: string;
}

export const HamburgerMenu: React.FC<HamburgerMenuProps> = ({
  isOpen,
  onClose,
  userProfile,
  onOpenLoginModal,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onOpenSearchModal,
  onOpenAmbientVoiceModal,
  onOpenVoiceTriggersModal,
  onOpenPhoneToolsModal,
  onOpenScreenReaderModal,
  onOpenStorageModal,
  autoSpeak,
  onToggleAutoSpeak,
  continuousListening,
  onToggleContinuousListening,
  currentPersona,
  onChangePersona,
  currentTone,
  onChangeTone,
  onClearCurrentChat,
  onExportChat,
  storageUsed,
}) => {
  const [editingSessionId, setEditingSessionId] = React.useState<string | null>(null);
  const [editTitle, setEditTitle] = React.useState('');

  if (!isOpen) return null;

  const handleStartRename = (id: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(id);
    setEditTitle(currentTitle);
  };

  const handleSaveRename = (id: string, e: React.FormEvent) => {
    e.preventDefault();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingSessionId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative w-full max-w-sm sm:max-w-md bg-slate-950/95 border-r border-cyan-500/30 flex flex-col h-full shadow-2xl shadow-cyan-950/50 z-10 overflow-hidden gpu-accelerated animate-slide-in">
        
        {/* Drawer Header & User Profile Bar */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onOpenLoginModal();
            }}
            className="flex items-center gap-3 text-left hover:opacity-90 transition group cursor-pointer"
            title="User Profile & Login Settings"
          >
            <div className="relative">
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 flex items-center justify-center text-lg text-white font-bold shadow-md shadow-cyan-500/20 group-hover:scale-105 transition">
                {userProfile.avatar || '👤'}
              </div>
              <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-900 ${userProfile.isLoggedIn ? 'bg-emerald-400' : 'bg-amber-400'}`} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition">
                  {userProfile.name}
                </span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-semibold ${
                  userProfile.isLoggedIn
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {userProfile.isLoggedIn ? 'Account Active' : 'Guest'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate max-w-[170px]">
                {userProfile.isLoggedIn ? userProfile.email : 'Tap to Login / Setup Profile'}
              </p>
            </div>
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Close Menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat & Search Shortcut */}
        <div className="p-3 border-b border-slate-800/80 grid grid-cols-2 gap-2 bg-slate-900/30">
          <button
            onClick={() => {
              onNewChat();
              onClose();
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-500/20 hover:scale-[1.02] active:scale-95 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenSearchModal();
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-cyan-300 font-semibold text-xs border border-cyan-500/30 hover:border-cyan-400/50 transition cursor-pointer"
          >
            <Search className="w-4 h-4 text-cyan-400" />
            <span>Search Chats</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar text-sm">
          
          {/* SPECIAL SECTION: Always-On Voice Assistant / "Hey Nova" Screen-Off Mode */}
          <div className="rounded-2xl p-3.5 bg-gradient-to-br from-violet-950/60 via-slate-900/80 to-cyan-950/60 border border-violet-500/40 shadow-lg shadow-violet-950/40 relative overflow-hidden group">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-violet-600/30 border border-violet-400/40 flex items-center justify-center text-violet-300">
                  <Mic className="w-4 h-4 animate-pulse" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-white tracking-wide flex items-center gap-1.5">
                    Ambient Voice Assistant
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-violet-500/30 text-violet-200 border border-violet-400/40 uppercase font-mono">
                      Background
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-300">
                    Bolo: &quot;Hey Nova, open YouTube&quot;
                  </p>
                </div>
              </div>
            </div>
            
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Screen stay-awake &amp; wake-word listener. Phone desk par rakho aur hands-free commands chalao!
            </p>

            <button
              onClick={() => {
                onClose();
                onOpenAmbientVoiceModal();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-500 hover:opacity-95 text-white font-bold text-xs shadow-md transition cursor-pointer hover:scale-[1.01] active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Launch Voice Standby Mode</span>
            </button>
          </div>

          {/* CHAT HISTORY & SESSIONS */}
          <div>
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                Chat History ({sessions.length})
              </span>
              {sessions.length > 1 && (
                <span className="text-[10px] text-slate-500 font-mono">
                  Auto-saved
                </span>
              )}
            </div>

            <div className="space-y-1 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
              {sessions.map((sess) => {
                const isActive = sess.id === activeSessionId;
                const isEditing = editingSessionId === sess.id;

                return (
                  <div
                    key={sess.id}
                    onClick={() => {
                      if (!isEditing) {
                        onSelectSession(sess.id);
                        onClose();
                      }
                    }}
                    className={`group flex items-center justify-between p-2.5 rounded-xl text-xs transition cursor-pointer border ${
                      isActive
                        ? 'bg-cyan-950/50 border-cyan-500/40 text-cyan-200 font-semibold shadow-xs'
                        : 'bg-slate-900/40 border-slate-800/80 text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    {isEditing ? (
                      <form
                        onSubmit={(e) => handleSaveRename(sess.id, e)}
                        className="flex-1 flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="flex-1 bg-slate-950 border border-cyan-500/50 rounded px-2 py-1 text-xs text-white focus:outline-none"
                          autoFocus
                          onBlur={() => setEditingSessionId(null)}
                        />
                        <button
                          type="submit"
                          className="px-2 py-1 bg-cyan-600 text-white rounded text-[10px] font-bold"
                        >
                          Save
                        </button>
                      </form>
                    ) : (
                      <>
                        <div className="flex items-center gap-2 truncate flex-1 mr-2">
                          <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                          <span className="truncate">{sess.title}</span>
                        </div>

                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                          <button
                            type="button"
                            onClick={(e) => handleStartRename(sess.id, sess.title, e)}
                            className="p-1 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-700/60"
                            title="Rename Conversation"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          {sessions.length > 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteSession(sess.id);
                              }}
                              className="p-1 text-slate-400 hover:text-red-400 rounded hover:bg-red-500/10"
                              title="Delete Conversation"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* AI TOOLKIT & CAPABILITIES */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              All Features &amp; Tools
            </span>

            <div className="grid grid-cols-1 gap-2">
              {/* Phone Tools */}
              <button
                onClick={() => {
                  onClose();
                  onOpenPhoneToolsModal();
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-cyan-950/40 border border-slate-800 hover:border-cyan-500/40 text-left transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 group-hover:scale-105 transition">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200 group-hover:text-cyan-300 text-xs">
                      Phone Tools &amp; Device Assistant
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Battery, reminders, shortcuts &amp; quick apps
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition" />
              </button>

              {/* Screen Reader & OCR */}
              <button
                onClick={() => {
                  onClose();
                  onOpenScreenReaderModal();
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-emerald-950/40 border border-slate-800 hover:border-emerald-500/40 text-left transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:scale-105 transition">
                    <Eye className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200 group-hover:text-emerald-300 text-xs">
                      Screen Reader &amp; OCR Assistant
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Vision analysis, screen explanation &amp; accessibility
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition" />
              </button>

              {/* Custom Voice Triggers */}
              <button
                onClick={() => {
                  onClose();
                  onOpenVoiceTriggersModal();
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-violet-950/40 border border-slate-800 hover:border-violet-500/40 text-left transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-violet-500/10 text-violet-400 border border-violet-500/20 group-hover:scale-105 transition">
                    <Mic className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200 group-hover:text-violet-300 text-xs">
                      Custom Voice Triggers &amp; Macros
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Configure wake-phrases &amp; instant actions
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-violet-400 group-hover:translate-x-0.5 transition" />
              </button>

              {/* Zero-Bloat Storage & Data Manager */}
              <button
                onClick={() => {
                  onClose();
                  onOpenStorageModal();
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-emerald-950/40 border border-slate-800 hover:border-emerald-500/40 text-left transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:scale-105 transition">
                    <HardDrive className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200 group-hover:text-emerald-300 text-xs">
                      Zero-Bloat Storage &amp; Cache
                    </div>
                    <div className="text-[10px] text-emerald-400 font-mono">
                      {storageUsed} used • 100% Zero-Bloat
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition" />
              </button>
            </div>
          </div>

          {/* VOICE & AUDIO TOGGLES */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
              Voice &amp; Audio Settings
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onToggleAutoSpeak}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  autoSpeak
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {autoSpeak ? <Volume2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <VolumeX className="w-4 h-4 shrink-0" />}
                <div className="leading-tight">
                  <div className="font-bold text-xs">AI Voice Reply</div>
                  <div className="text-[10px]">{autoSpeak ? 'Speaking ON' : 'Muted'}</div>
                </div>
              </button>

              <button
                onClick={onToggleContinuousListening}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  continuousListening
                    ? 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                    : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Radio className={`w-4 h-4 shrink-0 ${continuousListening ? 'text-rose-400 animate-pulse' : ''}`} />
                <div className="leading-tight">
                  <div className="font-bold text-xs">Continuous Mic</div>
                  <div className="text-[10px]">{continuousListening ? 'Listening' : 'Tap to talk'}</div>
                </div>
              </button>
            </div>
          </div>

          {/* PERSONA & TONE SELECTORS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Persona &amp; Style
              </span>
              <span className="text-[10px] text-cyan-400 font-mono uppercase">
                {currentPersona.replace('_', ' ')}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-1.5 text-xs">
              {(
                [
                  { id: 'mast_friend', label: 'Mast Friend 😎' },
                  { id: 'phone_assistant', label: 'Phone Pro 📱' },
                  { id: 'coder', label: 'Coder 💻' },
                  { id: 'screen_accessibility', label: 'OCR Eye 👁️' },
                  { id: 'tutor', label: 'Tutor 📚' },
                  { id: 'creative', label: 'Creative 🎨' },
                ] as const
              ).map((p) => (
                <button
                  key={p.id}
                  onClick={() => onChangePersona(p.id)}
                  className={`py-1.5 px-2 rounded-lg border text-center transition cursor-pointer text-[11px] truncate ${
                    currentPersona === p.id
                      ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200 font-bold shadow-xs'
                      : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Tone Selector */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
              {(
                [
                  { id: 'chatpata', label: 'Chatpata Desi' },
                  { id: 'concise', label: 'Concise' },
                  { id: 'detailed', label: 'Detailed' },
                  { id: 'shuddh_hindi', label: 'Shuddh Hindi' },
                  { id: 'english', label: 'English' },
                ] as const
              ).map((t) => (
                <button
                  key={t.id}
                  onClick={() => onChangeTone(t.id)}
                  className={`px-2.5 py-1 rounded-full text-[10px] shrink-0 border transition cursor-pointer ${
                    currentTone === t.id
                      ? 'bg-violet-500/20 border-violet-500/50 text-violet-200 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* DANGER / EXPORT ACTIONS */}
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <button
              onClick={() => {
                onExportChat();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export Chat</span>
            </button>

            <button
              onClick={() => {
                if (window.confirm('Kya aap is chat ko clear karna chahte hain?')) {
                  onClearCurrentChat();
                  onClose();
                }
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-red-400 hover:bg-red-500/10 transition cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Current Chat</span>
            </button>
          </div>

        </div>

        {/* Drawer Footer Branding */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/60 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero-Bloat • Lag-Free Engine</span>
          </div>
          <span className="font-mono text-cyan-400">Nova v3.8</span>
        </div>

      </div>
    </div>
  );
};
