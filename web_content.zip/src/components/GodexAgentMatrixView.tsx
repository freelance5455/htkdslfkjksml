import React, { useState } from 'react';
import { 
  Users, 
  Cpu, 
  Code2, 
  ShieldCheck, 
  Zap, 
  Bug, 
  Eye, 
  Activity, 
  FileCode, 
  Terminal, 
  CheckCircle2, 
  Play, 
  Search,
  Sparkles,
  Lock,
  ArrowRight
} from 'lucide-react';
import { TaskState } from '../types';
import { OperationAgentItem } from '../godex/operationState';

interface GodexAgentMatrixViewProps {
  onPromptAgent?: (prompt: string) => void;
  taskState?: TaskState;
  agents?: OperationAgentItem[];
  currentAgentId?: string;
}

export const GodexAgentMatrixView: React.FC<GodexAgentMatrixViewProps> = ({
  onPromptAgent,
  taskState
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('ALL');

  const agents = [
    {
      id: 'ag-architect',
      name: 'Architect',
      domain: 'CORE',
      role: 'System Topology & DAG Planner',
      capabilities: ['Module graph analysis', 'API boundary design', 'Architectural invariants'],
      status: 'ONLINE',
      activeTask: 'Synchronizing module dependency graph',
      icon: Cpu,
      color: 'text-indigo-400',
      border: 'border-indigo-500/30'
    },
    {
      id: 'ag-coder',
      name: 'Coder',
      domain: 'ENGINEERING',
      role: 'TypeScript & Component Architect',
      capabilities: ['Strict AST syntax', 'React 19 hooks', 'Tailwind v4 tokens'],
      status: 'ONLINE',
      activeTask: 'Monitoring live source workspace',
      icon: Code2,
      color: 'text-cyan-400',
      border: 'border-cyan-500/30'
    },
    {
      id: 'ag-reviewer',
      name: 'Reviewer',
      domain: 'SECURITY',
      role: 'Security & Type Safety Gate',
      capabilities: ['Zero any types', 'Mutation firewall checks', 'Security vulnerability audit'],
      status: 'ONLINE',
      activeTask: 'Authoritative audit active',
      icon: ShieldCheck,
      color: 'text-emerald-400',
      border: 'border-emerald-500/30'
    },
    {
      id: 'ag-tester',
      name: 'Tester',
      domain: 'VERIFICATION',
      role: 'Chaos Fuzzer & Spec Evaluator',
      capabilities: ['Boundary injection', 'Null assertion test', 'Fuzz event generation'],
      status: 'ONLINE',
      activeTask: 'Chaos test suite standing by',
      icon: Zap,
      color: 'text-blue-400',
      border: 'border-blue-500/30'
    },
    {
      id: 'ag-debugger',
      name: 'Debugger',
      domain: 'SELF-HEALING',
      role: 'Self-Healing Runtime Diagnostic',
      capabilities: ['Stacktrace demangling', 'DOM snapshot diffing', 'Atomic repair patches'],
      status: 'ONLINE',
      activeTask: 'Listening for runtime exceptions',
      icon: Bug,
      color: 'text-rose-400',
      border: 'border-rose-500/30'
    },
    {
      id: 'ag-designer',
      name: 'Designer',
      domain: 'UI/UX',
      role: 'Visual Engine & Design Inspector',
      capabilities: ['WCAG AA contrast', 'Responsive presets', 'Perceptual regression'],
      status: 'ONLINE',
      activeTask: 'Visual-to-AST bridge linked',
      icon: Eye,
      color: 'text-violet-400',
      border: 'border-violet-500/30'
    },
    {
      id: 'ag-optimizer',
      name: 'Optimizer',
      domain: 'PERFORMANCE',
      role: 'V8 Engine & Memory Profiler',
      capabilities: ['Render cycle audit', 'Bundle size reduction', 'Memory leak detection'],
      status: 'ONLINE',
      activeTask: 'Performance baseline 60 FPS',
      icon: Activity,
      color: 'text-amber-400',
      border: 'border-amber-500/30'
    },
    {
      id: 'ag-docs',
      name: 'Docs',
      domain: 'INTELLIGENCE',
      role: 'Context Pack & Blueprint Sync',
      capabilities: ['Project memory vault', 'Semantic symbol index', 'Living markdown docs'],
      status: 'ONLINE',
      activeTask: 'Context pack updated',
      icon: FileCode,
      color: 'text-teal-400',
      border: 'border-teal-500/30'
    }
  ];

  const filteredAgents = agents.filter(ag => {
    const matchesSearch = ag.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          ag.role.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDomain = selectedDomain === 'ALL' || ag.domain === selectedDomain;
    return matchesSearch && matchesDomain;
  });

  return (
    <div className="flex-1 h-full flex flex-col bg-[#0A0F1C] overflow-y-auto font-sans p-6 space-y-6 select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#18233C]">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-violet-400" />
            <h1 className="text-xl font-bold text-white font-mono">AGENT MATRIX</h1>
            <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-mono">
              24 Agents Active
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Specialized autonomous sub-agents collaborating on architecture, code, testing, and self-healing.
          </p>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0F1629] border border-[#1F2C4A]">
            <Search className="w-3.5 h-3.5 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Filter agents..."
              className="bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none w-36"
            />
          </div>
        </div>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredAgents.map(ag => {
          const Icon = ag.icon;
          return (
            <div
              key={ag.id}
              className={`p-4 rounded-2xl bg-[#0F1629] border ${ag.border} hover:bg-[#121B33] transition-all duration-200 shadow-lg flex flex-col justify-between space-y-4`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-lg bg-[#141D33] flex items-center justify-center ${ag.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white font-mono">{ag.name}</div>
                      <div className="text-[10px] font-mono text-neutral-400">{ag.domain}</div>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    ONLINE
                  </span>
                </div>

                <div className="text-xs text-slate-300 font-medium">{ag.role}</div>

                {/* Capabilities */}
                <div className="space-y-1">
                  <div className="text-[10px] font-mono text-neutral-400 uppercase">Capabilities:</div>
                  <div className="flex flex-wrap gap-1">
                    {ag.capabilities.map((cap, i) => (
                      <span 
                        key={i} 
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0A0F1C] border border-[#1C2844] text-neutral-300"
                      >
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Status footer & Direct Prompt button */}
              <div className="pt-3 border-t border-[#1A243B] flex items-center justify-between">
                <span className="text-[10px] font-mono text-neutral-400 truncate max-w-[150px]">
                  {ag.activeTask}
                </span>
                <button
                  onClick={() => onPromptAgent(`@${ag.name}: Analyze and optimize the project.`)}
                  className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-300 text-xs font-mono flex items-center gap-1 transition-colors"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Engage</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
