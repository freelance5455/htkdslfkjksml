import React, { useState, useRef, useEffect } from 'react';
import { 
  Monitor, 
  Scan, 
  Sparkles, 
  Eye, 
  Volume2, 
  Copy, 
  Check, 
  StopCircle, 
  Play, 
  RefreshCw, 
  Maximize2, 
  ShieldAlert, 
  FileSearch,
  Code2,
  Cpu
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface ScreenVisionHUDProps {
  language: SupportedLanguage;
  onAnalyzeScreen: (prompt: string, screenBase64: string) => Promise<string>;
  onSpeak: (text: string) => void;
  autoScanInterval?: number;
}

export const ScreenVisionHUD: React.FC<ScreenVisionHUDProps> = ({
  language,
  onAnalyzeScreen,
  onSpeak,
}) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [capturedFrame, setCapturedFrame] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [autoWatchActive, setAutoWatchActive] = useState<boolean>(false);
  const [screenReport, setScreenReport] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [lastScanTime, setLastScanTime] = useState<string>('');
  const [screenDirective, setScreenDirective] = useState<string>(
    language === 'bn'
      ? 'আমার বর্তমান স্ক্রিনের সবকিছু স্ক্যান করে বিস্তারিত বিশ্লেষণ করো। স্ক্রিনে কী কাজ চলছে, কোনো ত্রুটি বা টেক্সট আছে কি না তা পরিষ্কার বাংলায় বলো।'
      : 'Scan everything visible on my current screen in detail. Explain what is happening, identify any errors or text, and summarize key elements.'
  );

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const intervalRef = useRef<any>(null);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopScreenCapture();
    };
  }, []);

  // Handle continuous auto-watch
  useEffect(() => {
    if (autoWatchActive && isCapturing) {
      intervalRef.current = setInterval(() => {
        captureAndAnalyze(true);
      }, 15000); // Auto scan every 15s
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [autoWatchActive, isCapturing, screenDirective]);

  const startScreenCapture = async () => {
    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        alert(
          language === 'bn'
            ? 'আপনার ব্রাউজারে স্ক্রিন শেয়ারিং সাপোর্ট করছে না। অনুগ্রহ করে ক্রোম অথবা এজ ব্যবহার করুন।'
            : 'Screen sharing is not supported in this browser. Please use Chrome or Edge.'
        );
        return;
      }

      const mediaStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
        },
        audio: false,
      });

      setStream(mediaStream);
      setIsCapturing(true);

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        await videoRef.current.play();
      }

      // Track stop event
      mediaStream.getVideoTracks()[0].onended = () => {
        stopScreenCapture();
      };

      // Take first frame after 600ms
      setTimeout(() => {
        grabCurrentFrame();
      }, 600);
    } catch (err: any) {
      console.warn('Screen capture error:', err);
    }
  };

  const stopScreenCapture = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setIsCapturing(false);
    setAutoWatchActive(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const grabCurrentFrame = (): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;

    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedFrame(dataUrl);
    return dataUrl;
  };

  const captureAndAnalyze = async (isAuto: boolean = false) => {
    let frame = grabCurrentFrame();
    if (!frame && capturedFrame) frame = capturedFrame;
    if (!frame) return;

    setIsAnalyzing(true);
    setLastScanTime(new Date().toLocaleTimeString());

    try {
      const prompt = screenDirective || 'Analyze everything on my screen in detail.';
      const result = await onAnalyzeScreen(prompt, frame);
      setScreenReport(result);
      if (!isAuto) {
        onSpeak(result);
      }
    } catch (error: any) {
      setScreenReport(`Error scanning screen: ${error?.message || 'Please retry'}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCopy = () => {
    if (screenReport) {
      navigator.clipboard.writeText(screenReport);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Hidden processing canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Futuristic Holographic Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0a1428] to-[#1a0f2e] border border-cyan-500/40 p-5 md:p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/50 text-cyan-300 text-xs font-mono-tech">
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              <span>LIVE SCREEN TELEMETRY & VISION OVERVIEW</span>
            </div>
            <h2 className="text-2xl font-orbitron font-extrabold tracking-wider bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
              SCREEN OVERVIEW & VISION HUD
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              হোলোগ্রাফিক ওভারভিউয়ের মাধ্যমে আপনার স্ক্রিনের সব কিছু সরাসরি পর্যবেক্ষণ ও বিশ্লেষণ করে রুবেল বস এআই।
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!isCapturing ? (
              <button
                onClick={startScreenCapture}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-fuchsia-500 hover:from-cyan-400 text-slate-950 font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/30"
              >
                <Monitor className="w-4 h-4" />
                <span>START SCREEN LINK</span>
              </button>
            ) : (
              <button
                onClick={stopScreenCapture}
                className="px-5 py-2.5 rounded-2xl bg-red-950 border border-red-500 text-red-300 font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-red-950/50"
              >
                <StopCircle className="w-4 h-4" />
                <span>DISCONNECT LINK</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Hologram-style Screen Display Box (Styled like the top logo HUD) */}
      <div className="relative rounded-3xl bg-[#060b17] border-2 border-cyan-500/40 p-4 md:p-6 shadow-2xl overflow-hidden">
        {/* Futuristic glowing corners */}
        <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-cyan-400 pointer-events-none" />
        <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-fuchsia-400 pointer-events-none" />
        <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-cyan-400 pointer-events-none" />
        <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-fuchsia-400 pointer-events-none" />

        {/* Live Video Feed or Placeholder */}
        <div className="relative w-full rounded-2xl overflow-hidden bg-black/90 min-h-[300px] md:min-h-[380px] flex items-center justify-center border border-cyan-900/60 scanlines">
          {isCapturing ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full max-h-[460px] object-contain mx-auto"
              />

              {/* Cyan overlay HUD and grid */}
              <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-transparent to-fuchsia-500/10 pointer-events-none" />

              {/* HUD Reticle Watermark */}
              <div className="absolute top-4 left-4 bg-slate-950/80 border border-cyan-400 px-3 py-1 rounded-full text-[11px] font-mono-tech text-cyan-300 flex items-center gap-2 shadow-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>LIVE SCREEN STREAM ACTIVE</span>
              </div>

              {lastScanTime && (
                <div className="absolute top-4 right-4 bg-slate-950/80 border border-fuchsia-500/50 px-3 py-1 rounded-full text-[10px] font-mono-tech text-fuchsia-300">
                  LAST SCAN: {lastScanTime}
                </div>
              )}

              {/* Target Scan Grid Crosshair */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-30">
                <div className="w-48 h-48 rounded-full border border-dashed border-cyan-400" />
                <div className="w-32 h-32 rounded-full border border-fuchsia-400 absolute" />
              </div>
            </>
          ) : (
            <div className="text-center p-8 space-y-4">
              <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border border-dashed border-cyan-400/50 animate-spin-slow" />
                <div className="w-16 h-16 rounded-full bg-cyan-950/80 border border-cyan-400 flex items-center justify-center text-cyan-300">
                  <Monitor className="w-8 h-8" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-orbitron font-bold text-white">
                  SCREEN OVERVIEW DISCONNECTED
                </h3>
                <p className="text-slate-400 text-xs sm:text-sm max-w-md mx-auto mt-1">
                  &quot;START SCREEN LINK&quot; বাটনে ক্লিক করে আপনার সম্পূর্ণ স্ক্রিন, কোনো অ্যাপ বা উইন্ডো যুক্ত করুন। রুবেল বস এআই সবকিছু নিজে দেখতে পারবে।
                </p>
              </div>

              <button
                onClick={startScreenCapture}
                className="px-6 py-2.5 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-xs tracking-wider shadow-lg shadow-cyan-500/30"
              >
                CONNECT SCREEN OVERVIEW
              </button>
            </div>
          )}
        </div>

        {/* Live Controls Strip */}
        {isCapturing && (
          <div className="mt-4 pt-3 border-t border-cyan-900/40 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => captureAndAnalyze(false)}
                disabled={isAnalyzing}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-xs tracking-wider flex items-center gap-2 shadow-md shadow-cyan-500/30"
              >
                {isAnalyzing ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Scan className="w-4 h-4" />
                )}
                <span>{isAnalyzing ? 'SCANNING SCREEN...' : 'INSPECT SCREEN NOW'}</span>
              </button>

              <button
                onClick={() => setAutoWatchActive(!autoWatchActive)}
                className={`px-3.5 py-2 rounded-xl text-xs font-mono-tech border flex items-center gap-1.5 transition-all ${
                  autoWatchActive
                    ? 'bg-fuchsia-950 border-fuchsia-400 text-fuchsia-300 font-bold shadow-md shadow-fuchsia-500/30'
                    : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>{autoWatchActive ? 'Auto-Watch: ACTIVE (15s)' : 'Auto-Watch: OFF'}</span>
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono-tech text-cyan-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI VISION EYE ACTIVE</span>
            </div>
          </div>
        )}
      </div>

      {/* Preset Screen Inspection Prompts */}
      <div className="space-y-2">
        <label className="text-xs font-mono-tech font-bold text-cyan-400 tracking-wider">
          QUICK SCREEN DIRECTIVES
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={() => {
              setScreenDirective('আমার স্ক্রিনের সমস্ত বিষয়বস্তু পরিষ্কার বাংলায় বিস্তারিত বর্ণনা করো। কী কাজ চলছে এবং কী কী উইন্ডো খোলা আছে তা বলো।');
              if (isCapturing) captureAndAnalyze(false);
            }}
            className="p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2"
          >
            <FileSearch className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>স্ক্রিনের সম্পূর্ণ বিবরণ</span>
          </button>

          <button
            onClick={() => {
              setScreenDirective('আমার স্ক্রিনে কোনো কোড বা এরর মেসেজ থাকলে তা চিহ্নিত করো, ভুল বুঝিয়ে দাও এবং সঠিক সমাধান দাও।');
              if (isCapturing) captureAndAnalyze(false);
            }}
            className="p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-fuchsia-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2"
          >
            <Code2 className="w-4 h-4 text-fuchsia-400 shrink-0" />
            <span>কোড ও এরর ফিক্স করো</span>
          </button>

          <button
            onClick={() => {
              setScreenDirective('স্ক্রিনের দৃশ্যমান সমস্ত টেক্সট, নম্বর ও গুরুত্বপূর্ণ ডাটা সঠিকভাবে এক্সট্রাক্ট করে পয়েন্ট আকারে তুলে ধরো।');
              if (isCapturing) captureAndAnalyze(false);
            }}
            className="p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-emerald-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2"
          >
            <Scan className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>টেক্সট ও ডাটা এক্সট্র্যাক্ট</span>
          </button>
        </div>
      </div>

      {/* Directive Textarea */}
      <div className="space-y-2">
        <label className="text-xs font-mono-tech font-bold text-slate-400 tracking-wider">
          CUSTOM SCREEN DIRECTIVE
        </label>
        <textarea
          rows={2}
          value={screenDirective}
          onChange={(e) => setScreenDirective(e.target.value)}
          placeholder="What should the AI check on your screen?"
          className="w-full bg-slate-950 text-slate-100 placeholder:text-slate-500 text-sm p-3.5 rounded-2xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400 font-sans resize-none"
        />
      </div>

      {/* Screen AI Intel Report */}
      {screenReport && (
        <div className="rounded-3xl bg-[#090f1e] border border-cyan-500/50 p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
            <div className="flex items-center gap-2">
              <Scan className="w-5 h-5 text-cyan-400" />
              <h3 className="font-orbitron font-bold text-sm text-cyan-300 tracking-wide">
                SCREEN INTEL REPORT (রুবেল বস এআই)
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onSpeak(screenReport)}
                title="Speak Out Loud"
                className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 transition-colors"
              >
                <Volume2 className="w-4 h-4" />
              </button>
              <button
                onClick={handleCopy}
                title="Copy Text"
                className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="text-slate-100 text-sm whitespace-pre-wrap leading-relaxed font-sans">
            {screenReport}
          </div>
        </div>
      )}
    </div>
  );
};
