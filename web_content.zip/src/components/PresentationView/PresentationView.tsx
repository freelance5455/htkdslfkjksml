import React, { useState, useEffect } from 'react';
import { Tv, Sparkles, Church, Heart, Maximize2, Users } from 'lucide-react';
import { useChurch } from '../../context/ChurchContext';

const BIBLE_VERSES = [
  {
    text: 'Alegrei-me quando me disseram: Vamos à casa do SENHOR.',
    ref: 'Salmos 122:1',
  },
  {
    text: 'Oh! Quão bom e quão suave é que os irmãos vivam em união.',
    ref: 'Salmos 133:1',
  },
  {
    text: 'Porque onde estiverem dois ou três reunidos em meu nome, aí estou eu no meio deles.',
    ref: 'Mateus 18:20',
  },
  {
    text: 'Entrai pelas portas dele com louvor, e em seus átrios com hinos; louvai-o, e bendizei o seu nome.',
    ref: 'Salmos 100:4',
  },
];

export const PresentationView: React.FC = () => {
  const { visitors, service } = useChurch();
  const [verseIndex, setVerseIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setVerseIndex((prev) => (prev + 1) % BIBLE_VERSES.length);
    }, 12000);
    return () => clearInterval(timer);
  }, []);

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const currentVerse = BIBLE_VERSES[verseIndex];

  return (
    <div className="relative min-h-[calc(100vh-105px)] bg-gradient-to-b from-neutral-950 via-neutral-900 to-black text-white flex flex-col justify-between p-6 sm:p-12 overflow-hidden select-none">
      {/* Background ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Banner */}
      <div className="relative z-10 flex items-center justify-between border-b border-neutral-800/80 pb-6">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-lg shadow-amber-500/10">
            <Church className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {service.churchName || 'Nossa Igreja'}
            </h1>
            <p className="text-sm font-semibold text-amber-400">{service.title}</p>
          </div>
        </div>

        <button
          onClick={handleFullscreen}
          className="flex items-center gap-2 rounded-2xl bg-neutral-900/80 border border-neutral-700/80 px-4 py-2.5 text-xs font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 transition"
        >
          <Maximize2 className="h-4 w-4" />
          <span>Tela Cheia Telão</span>
        </button>
      </div>

      {/* Center Welcome & Bible Verse Display */}
      <div className="relative z-10 my-auto text-center max-w-4xl mx-auto space-y-6 sm:space-y-8 py-8">
        <div className="inline-flex items-center gap-2 rounded-full bg-amber-500/15 border border-amber-500/30 px-5 py-2 text-sm font-black text-amber-400 tracking-widest uppercase">
          <Sparkles className="h-4 w-4" /> Boas-Vindas aos Visitantes
        </div>

        <h2 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white leading-tight">
          Você é Muito Especial Para Deus e Para Nossa Família!
        </h2>

        {/* Rotating Scripture Card */}
        <div className="rounded-3xl bg-neutral-900/60 border border-neutral-800/90 p-8 sm:p-10 backdrop-blur-md shadow-2xl transition-all duration-700">
          <p className="text-2xl sm:text-3xl font-serif italic text-neutral-200 leading-relaxed">
            &ldquo;{currentVerse.text}&rdquo;
          </p>
          <p className="mt-4 text-base font-bold text-amber-400 tracking-wider">
            {currentVerse.ref}
          </p>
        </div>
      </div>

      {/* Bottom Live Visitors Welcome Ticker */}
      <div className="relative z-10 border-t border-neutral-800/80 pt-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-amber-400" />
            <span className="text-sm font-bold text-neutral-300">
              Hoje temos a honra de receber:{' '}
              <strong className="text-white">
                {visitors.length} {visitors.length === 1 ? 'visitante' : 'visitantes'}
              </strong>
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar max-w-2xl py-1">
            {visitors.slice(0, 6).map((v) => (
              <span
                key={v.id}
                className="shrink-0 rounded-xl bg-neutral-900 border border-neutral-700/80 px-3 py-1.5 text-xs font-semibold text-neutral-200"
              >
                {v.name}
                {v.companionCount > 0 ? ` (+${v.companionCount})` : ''}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
