import React, { useState, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, RefreshCw, CheckCircle2, Terminal, Cpu, Database, Wifi } from 'lucide-react';

export const SystemDiagnostics: React.FC = () => {
  const [diagnostics, setDiagnostics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [repairing, setRepairing] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const fetchDiagnostics = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/system/diagnostics');
      const data = await res.json();
      setDiagnostics(data);
    } catch (err) {
      console.error('Error fetching diagnostics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDiagnostics();
  }, []);

  const handleRepair = async () => {
    setRepairing(true);
    setSuccessMsg('');
    try {
      const res = await fetch('/api/system/repair', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg(data.message);
        await fetchDiagnostics();
      }
    } catch (err) {
      console.error('Error repairing system:', err);
    } finally {
      setRepairing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#12071f]/90 backdrop-blur-xl border border-[#9d00ff]/40 rounded-2xl p-6 shadow-[0_0_30px_rgba(157,0,255,0.2)]">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#9d00ff]/20 rounded-xl border border-[#9d00ff]/50 text-[#9d00ff]">
              <ShieldCheck className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wider">CORRECCIÓN DE ERRORES DEL SISTEMA</h2>
              <p className="text-xs text-gray-400">Diagnóstico en tiempo real, auto-reparación de sockets y verificación de API Keys</p>
            </div>
          </div>
          <button
            onClick={handleRepair}
            disabled={repairing}
            className="px-5 py-2.5 bg-gradient-to-r from-[#9d00ff] to-[#ff0055] text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-[0_0_20px_rgba(157,0,255,0.4)] hover:opacity-90 transition flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${repairing ? 'animate-spin' : ''}`} />
            {repairing ? 'Reparando...' : 'Ejecutar Auto-Reparación'}
          </button>
        </div>

        {successMsg && (
          <div className="mb-6 p-4 bg-[#00ff88]/10 border border-[#00ff88]/40 rounded-xl text-[#00ff88] text-xs font-mono flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            {successMsg}
          </div>
        )}

        {/* Status Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-black/50 border border-[#9d00ff]/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400 mb-1">
              <Cpu className="w-4 h-4 text-[#9d00ff]" /> Estado del Sistema
            </div>
            <div className="text-lg font-black text-[#00ff88] uppercase">{diagnostics?.status || 'OPTIMAL'}</div>
          </div>
          <div className="bg-black/50 border border-[#9d00ff]/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400 mb-1">
              <Database className="w-4 h-4 text-[#00d4ff]" /> Errores Activos
            </div>
            <div className="text-lg font-black text-[#ff0055] font-mono">{diagnostics?.activeErrors || 0} Registrados</div>
          </div>
          <div className="bg-black/50 border border-[#9d00ff]/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400 mb-1">
              <Wifi className="w-4 h-4 text-yellow-400" /> Sockets Activos
            </div>
            <div className="text-lg font-black text-white font-mono">Estables (100%)</div>
          </div>
          <div className="bg-black/50 border border-[#9d00ff]/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400 mb-1">
              <Terminal className="w-4 h-4 text-[#ff0055]" /> Uptime Servidor
            </div>
            <div className="text-lg font-black text-[#ff0055] font-mono">{Math.round(diagnostics?.uptime || 0)}s</div>
          </div>
        </div>

        {/* API Key Status Checker */}
        <div className="bg-black/40 border border-[#9d00ff]/30 rounded-xl p-5 mb-6">
          <h4 className="text-xs font-mono text-gray-400 uppercase tracking-widest mb-4">Estado de Credenciales y APIs del Sistema</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {diagnostics?.apiKeyStatus && Object.entries(diagnostics.apiKeyStatus).map(([key, active]: [string, any]) => (
              <div key={key} className="flex items-center justify-between p-3 bg-black/60 border border-[#9d00ff]/20 rounded-lg">
                <span className="text-xs font-mono text-white">{key}</span>
                <span className={`px-2.5 py-1 rounded-md text-[10px] font-mono font-bold ${active ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'}`}>
                  {active ? 'CONECTADA & ACTIVA' : 'INACTIVA'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Error Logs Table */}
        <h4 className="text-xs font-mono text-gray-400 uppercase tracking-widest mb-3">Historial de Errores y Diagnóstico de Red</h4>
        <div className="space-y-2">
          {diagnostics?.logs?.map((log: any) => (
            <div key={log.id} className="p-4 bg-black/50 border border-[#9d00ff]/20 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                {log.fixed ? <CheckCircle2 className="w-5 h-5 text-[#00ff88]" /> : <AlertTriangle className="w-5 h-5 text-yellow-400" />}
                <div>
                  <div className="text-white font-bold text-xs font-mono">{log.type}</div>
                  <div className="text-gray-300 text-xs">{log.message}</div>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold ${log.fixed ? 'bg-[#00ff88]/20 text-[#00ff88]' : 'bg-yellow-400/20 text-yellow-400'}`}>
                {log.fixed ? 'CORREGIDO' : 'REQUIERE ATENCIÓN'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
