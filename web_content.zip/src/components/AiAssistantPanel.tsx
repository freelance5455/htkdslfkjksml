import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Wand2,
  Bug,
  Zap,
  HelpCircle,
  FileCode,
  Check,
  ArrowRight,
  Loader2,
  X,
  Code2,
  Cpu,
  RefreshCw,
  FolderPlus
} from 'lucide-react';
import { Project, ProjectFile, AIProposal } from '../types';

interface AiAssistantPanelProps {
  isOpen: boolean;
  onClose: () => void;
  activeFile: ProjectFile;
  project: Project;
  onProposeCodeChange: (proposal: Omit<AIProposal, 'id' | 'createdAt' | 'status'>) => void;
  onLoadGeneratedProject: (project: Project) => void;
  aiAvailable: boolean;
  diagnoseQuery?: { error: string; stack?: string } | null;
  onClearDiagnoseQuery?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  codeBlock?: { code: string; language: string };
  timestamp: string;
}

export const AiAssistantPanel: React.FC<AiAssistantPanelProps> = ({
  isOpen,
  onClose,
  activeFile,
  project,
  onProposeCodeChange,
  onLoadGeneratedProject,
  aiAvailable,
  diagnoseQuery,
  onClearDiagnoseQuery,
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'generator'>('chat');

  // Chat State
  const [inputPrompt, setInputPrompt] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Hello! I am CODEVERSE AI. I can generate complete multi-file projects, debug canvas & web errors, refactor code, and optimize algorithms.\n\nWhat would you like to build or improve?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  // 1-Click Generator State
  const [genPrompt, setGenPrompt] = useState('');
  const [genType, setGenType] = useState<'game' | 'web' | 'react' | 'python'>('game');
  const [isGeneratingProject, setIsGeneratingProject] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<string[] | null>(null);
  const [generatedResult, setGeneratedResult] = useState<any | null>(null);

  // Auto-fill diagnose query if triggered from debugger console
  React.useEffect(() => {
    if (diagnoseQuery) {
      setActiveTab('chat');
      const queryText = `Fix this runtime error: "${diagnoseQuery.error}"\nStack trace: ${diagnoseQuery.stack || 'none'}`;
      handleSendPrompt(queryText);
      if (onClearDiagnoseQuery) onClearDiagnoseQuery();
    }
  }, [diagnoseQuery]);

  const handleSendPrompt = async (promptToSend?: string) => {
    const text = promptToSend || inputPrompt;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!promptToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text.trim(),
          currentFile: {
            name: activeFile.name,
            language: activeFile.language,
            content: activeFile.content,
          },
          allFiles: project.files.map(f => ({ name: f.name, path: f.path })),
        }),
      });

      const data = await response.json();
      const reply = data.reply || 'No response returned.';

      // Extract code block if present
      const codeMatch = reply.match(/```([a-zA-Z0-9_\-+]*)\n([\s\S]*?)```/);
      let codeBlock;
      if (codeMatch) {
        codeBlock = {
          language: codeMatch[1] || activeFile.language,
          code: codeMatch[2].trim(),
        };
      }

      const aiMsg: ChatMessage = {
        id: 'ai_' + Date.now(),
        sender: 'ai',
        text: reply.replace(/```[a-zA-Z0-9_\-+]*\n[\s\S]*?```/g, '').trim() || 'Here is the proposed code:',
        codeBlock,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: 'err_' + Date.now(),
          sender: 'ai',
          text: `Error connecting to AI service: ${err.message}. Using offline intelligence.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Action Handler (Explain, Debug, Optimize, Refactor)
  const handleQuickAction = async (action: 'explain' | 'debug' | 'optimize' | 'refactor' | 'tests') => {
    setIsLoading(true);
    const actionPrompts = {
      explain: `Explain this code and its architecture in simple terms.`,
      debug: `Find any bugs or potential edge cases in this code and provide the fix.`,
      optimize: `Optimize this code for execution speed and render performance.`,
      refactor: `Refactor this code to be cleaner, modern, and modular.`,
      tests: `Write unit test assertions for this code.`,
    };

    setMessages(prev => [
      ...prev,
      {
        id: 'act_' + Date.now(),
        sender: 'user',
        text: `[Quick Action: ${action.toUpperCase()}] on ${activeFile.name}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    try {
      const response = await fetch('/api/ai/code-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          code: activeFile.content,
          language: activeFile.language,
          filename: activeFile.name,
          instruction: actionPrompts[action],
        }),
      });

      const data = await response.json();
      const aiMsg: ChatMessage = {
        id: 'ai_' + Date.now(),
        sender: 'ai',
        text: data.result || 'Action completed.',
        codeBlock: data.proposedCode ? { code: data.proposedCode, language: activeFile.language } : undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, aiMsg]);

      // Automatically offer diff proposal if code was generated
      if (data.proposedCode && data.proposedCode !== activeFile.content) {
        onProposeCodeChange({
          fileId: activeFile.id,
          filename: activeFile.name,
          originalCode: activeFile.content,
          proposedCode: data.proposedCode,
          explanation: `AI ${action} suggestions for ${activeFile.name}`,
          action,
        });
      }
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: 'err_' + Date.now(),
          sender: 'ai',
          text: `Action failed: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // 1-Click Project Generator
  const handleGenerateProject = async () => {
    if (!genPrompt.trim() || isGeneratingProject) return;
    setIsGeneratingProject(true);
    setGeneratedPlan(null);
    setGeneratedResult(null);

    try {
      const response = await fetch('/api/ai/generate-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: genPrompt.trim(),
          type: genType,
        }),
      });

      const data = await response.json();
      if (data.project) {
        setGeneratedPlan(data.project.plan || ['Architecture analyzed', 'Files compiled']);
        setGeneratedResult(data.project);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsGeneratingProject(false);
    }
  };

  const handleApplyGeneratedProject = () => {
    if (!generatedResult) return;
    const newProj: Project = {
      id: 'proj_' + Date.now(),
      name: generatedResult.title || 'Generated Project',
      description: generatedResult.description || 'AI Synthesized Project',
      category: (generatedResult.projectType as any) || genType,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      activeFileId: '',
      files: generatedResult.files.map((f: any, idx: number) => ({
        id: 'f_' + Date.now() + '_' + idx,
        name: f.name || `file_${idx}.js`,
        path: f.path || f.name || `file_${idx}.js`,
        language: f.language || 'javascript',
        content: f.content || '',
      })),
    };
    newProj.activeFileId = newProj.files[0]?.id || '';
    onLoadGeneratedProject(newProj);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <aside className="w-80 md:w-96 bg-[#090d18] border-l border-slate-800 flex flex-col shrink-0 select-none z-20 h-full shadow-2xl">
      {/* Top Header */}
      <div className="h-12 bg-[#070a14] px-4 flex items-center justify-between border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded-md bg-cyan-500/20 text-cyan-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-xs text-white">AI CODING ASSISTANT</span>
            <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${aiAvailable ? 'bg-cyan-400' : 'bg-amber-400'}`} />
              <span>{aiAvailable ? 'Gemini 3.8 Flash' : 'Offline Engine'}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          aria-label="Close AI panel"
          className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-[#090d18] px-2 pt-1.5 gap-1 shrink-0">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-t-lg transition-colors flex items-center justify-center gap-1.5 ${
            activeTab === 'chat'
              ? 'bg-[#0f172a] text-cyan-300 border-t-2 border-cyan-400'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>Assistant Chat</span>
        </button>
        <button
          onClick={() => setActiveTab('generator')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-t-lg transition-colors flex items-center justify-center gap-1.5 ${
            activeTab === 'generator'
              ? 'bg-[#0f172a] text-purple-300 border-t-2 border-purple-400'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>1-Click Project Gen</span>
        </button>
      </div>

      {/* TAB 1: ASSISTANT CHAT */}
      {activeTab === 'chat' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Quick Action Badges */}
          <div className="p-2 border-b border-slate-800 bg-[#050811] flex flex-wrap gap-1.5 shrink-0">
            <button
              onClick={() => handleQuickAction('explain')}
              disabled={isLoading}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
            >
              <HelpCircle className="w-3 h-3 text-cyan-400" />
              <span>Explain</span>
            </button>
            <button
              onClick={() => handleQuickAction('debug')}
              disabled={isLoading}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
            >
              <Bug className="w-3 h-3 text-rose-400" />
              <span>Debug</span>
            </button>
            <button
              onClick={() => handleQuickAction('optimize')}
              disabled={isLoading}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
            >
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Optimize</span>
            </button>
            <button
              onClick={() => handleQuickAction('refactor')}
              disabled={isLoading}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
            >
              <Cpu className="w-3 h-3 text-purple-400" />
              <span>Refactor</span>
            </button>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col text-xs ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`p-2.5 rounded-xl max-w-[90%] leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-cyan-600 text-slate-950 font-medium rounded-tr-none'
                      : 'bg-[#111827] text-slate-200 border border-slate-700/80 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Render Code Block if present */}
                  {msg.codeBlock && (
                    <div className="mt-2.5 bg-[#050811] rounded-lg border border-slate-800 p-2 font-mono text-[11px] overflow-hidden">
                      <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-slate-800 text-slate-400">
                        <span>{msg.codeBlock.language}</span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              onProposeCodeChange({
                                fileId: activeFile.id,
                                filename: activeFile.name,
                                originalCode: activeFile.content,
                                proposedCode: msg.codeBlock!.code,
                                explanation: 'AI generated code block',
                                action: 'apply',
                              });
                            }}
                            className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-semibold text-[10px] hover:bg-cyan-500/30 transition-colors"
                          >
                            Compare Diff & Apply
                          </button>
                        </div>
                      </div>
                      <pre className="overflow-x-auto text-emerald-300 max-h-40 leading-normal">
                        {msg.codeBlock.code}
                      </pre>
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5 px-1">{msg.timestamp}</span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2 p-2 bg-[#111827] rounded-xl text-xs text-cyan-300 border border-cyan-500/20 w-fit">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Synthesizing code solution...</span>
              </div>
            )}
          </div>

          {/* Active file context chip */}
          <div className="px-3 py-1 bg-[#050811] border-t border-slate-800/80 text-[10px] text-slate-400 flex items-center justify-between shrink-0 font-mono">
            <span>Context: {activeFile.name}</span>
            <span className="text-cyan-400 capitalize">{activeFile.language}</span>
          </div>

          {/* Input Box */}
          <div className="p-2.5 bg-[#070a14] border-t border-slate-800 flex items-center gap-2 shrink-0">
            <input
              type="text"
              placeholder="Ask AI: generate, debug, explain..."
              value={inputPrompt}
              onChange={e => setInputPrompt(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') handleSendPrompt();
              }}
              disabled={isLoading}
              className="flex-1 bg-[#0d1322] text-white text-xs px-3 py-2 rounded-lg border border-slate-700/80 outline-hidden font-mono focus:border-cyan-500/60"
            />
            <button
              onClick={() => handleSendPrompt()}
              disabled={isLoading || !inputPrompt.trim()}
              aria-label="Send prompt"
              className="p-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 font-bold transition-all shadow-md shadow-cyan-500/25 active:scale-95 shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: 1-CLICK PROJECT GENERATOR */}
      {activeTab === 'generator' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          <div>
            <div className="font-bold text-slate-200 text-sm mb-1">Synthesize Whole Project</div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Describe any 2D game, website, or algorithmic tool. AI will architect the files, generate working code, and connect preview components.
            </p>
          </div>

          {/* Project Type Picker */}
          <div>
            <label className="text-slate-300 font-semibold block mb-1.5">Project Type</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { type: 'game', label: '🎮 2D Canvas Game' },
                { type: 'web', label: '🌐 Modern Web App' },
                { type: 'react', label: '⚛️ React Component' },
                { type: 'python', label: '🐍 Python Lab' },
              ].map(opt => (
                <button
                  key={opt.type}
                  onClick={() => setGenType(opt.type as any)}
                  className={`p-2 rounded-lg text-xs font-semibold text-left transition-colors border ${
                    genType === opt.type
                      ? 'bg-purple-500/20 text-purple-200 border-purple-500/50'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Description */}
          <div>
            <label className="text-slate-300 font-semibold block mb-1.5">Describe Your Idea</label>
            <textarea
              rows={4}
              value={genPrompt}
              onChange={e => setGenPrompt(e.target.value)}
              placeholder="e.g. Neon Cyber Space Invader with 3 enemy tiers, score progression, shield powerups, and Web Audio synth sound effects..."
              className="w-full bg-[#0d1322] text-white p-2.5 rounded-lg border border-slate-700/80 outline-hidden font-mono resize-none focus:border-purple-500/60 leading-relaxed text-xs"
            />
          </div>

          {/* Quick Idea Presets */}
          <div className="flex flex-wrap gap-1.5">
            {[
              'Cyberpunk Pong 2088',
              'Tower Defense Blitz',
              'Crypto Stock Simulator',
              'Roguelike Dungeon Maze',
            ].map((idea, idx) => (
              <button
                key={idx}
                onClick={() => setGenPrompt(idea)}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-cyan-300 text-[10px] font-mono transition-colors"
              >
                + {idea}
              </button>
            ))}
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerateProject}
            disabled={isGeneratingProject || !genPrompt.trim()}
            className="w-full py-2.5 px-4 rounded-lg bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 disabled:opacity-40 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-purple-950/50 transition-all active:scale-95 text-xs"
          >
            {isGeneratingProject ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Generating Plan & Code...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>1-Click Generate Project</span>
              </>
            )}
          </button>

          {/* Generated Result & Plan Card */}
          {generatedResult && (
            <div className="p-3 bg-[#0d1322] border border-cyan-500/40 rounded-xl space-y-2.5 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{generatedResult.title}</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px]">
                  Ready
                </span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                {generatedResult.description}
              </p>

              {/* Plan list */}
              {generatedPlan && (
                <div className="p-2 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Architecture Plan:
                  </div>
                  {generatedPlan.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-[11px] text-slate-300">
                      <span className="text-cyan-400 font-bold shrink-0">{idx + 1}.</span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Files overview */}
              <div className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                <FolderPlus className="w-3.5 h-3.5 text-cyan-400" />
                <span>{generatedResult.files?.length || 0} files generated</span>
              </div>

              {/* Load Button */}
              <button
                onClick={handleApplyGeneratedProject}
                className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/25 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>Load Project into Workspace</span>
              </button>
            </div>
          )}
        </div>
      )}
    </aside>
  );
};
