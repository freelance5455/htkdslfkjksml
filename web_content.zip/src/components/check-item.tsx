import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export function CheckItem({
  checked,
  label,
  hint,
  onToggle,
  className,
}: {
  checked: boolean;
  label: string;
  hint?: string;
  onToggle: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl px-1 py-2.5 text-left transition-colors hover:bg-accent/50",
        className,
      )}
    >
      <span
        className={cn(
          "flex size-6 shrink-0 items-center justify-center rounded-md border transition-[background-color,border-color,box-shadow]",
          checked
            ? "animate-check-pop border-primary bg-primary text-primary-foreground"
            : "border-border bg-transparent text-transparent",
        )}
      >
        <Check className="size-3.5" strokeWidth={3} />
      </span>
      <span className="min-w-0 flex-1">
        <span
          className={cn(
            "block text-sm font-medium",
            checked ? "text-muted-foreground line-through" : "text-foreground",
          )}
        >
          {label}
        </span>
        {hint ? (
          <span className="block text-xs text-muted-foreground">{hint}</span>
        ) : null}
      </span>
    </button>
  );
}
