import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Hash,
  Search,
  Send,
  Paperclip,
  Image as ImageIcon,
  Mic,
  Square,
  Smile,
  File,
  Download,
  Play,
  Pause,
  X,
  Volume2,
} from 'lucide-react';
import { ChatAttachment } from '../../types';

export const MessagingView: React.FC = () => {
  const {
    channels,
    activeChannelId,
    setActiveChannelId,
    messages,
    sendMessage,
    addReaction,
    currentUser,
  } = useApp();

  const [messageInput, setMessageInput] = useState('');
  const [searchFilter, setSearchFilter] = useState('');
  const [showEmojiPickerFor, setShowEmojiPickerFor] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Voice note recording states
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<any>(null);

  // File upload simulation / input
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-scroll chat feed to bottom
  const feedEndRef = useRef<HTMLDivElement | null>(null);

  const activeChannel = channels.find((c) => c.id === activeChannelId) || channels[0];

  const channelMessages = messages.filter((m) => {
    const matchesChannel = m.channelId === activeChannelId;
    if (!matchesChannel) return false;
    if (!searchFilter.trim()) return true;
    return (
      m.text.toLowerCase().includes(searchFilter.toLowerCase()) ||
      m.senderName.toLowerCase().includes(searchFilter.toLowerCase())
    );
  });

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMessages.length]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;
    sendMessage(messageInput.trim());
    setMessageInput('');
  };

  // Start real audio recording
  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        const durationSec = recordingSeconds > 0 ? recordingSeconds : 4;

        // Auto send voice note
        sendMessage('Voice Memo', [
          {
            type: 'audio',
            name: `Voice_Note_${new Date().toISOString().slice(11, 19)}.webm`,
            url: audioUrl,
            duration: durationSec,
          },
        ]);

        // Stop all tracks to release mic
        stream.getTracks().forEach((track) => track.stop());
        setIsRecordingVoice(false);
        setRecordingSeconds(0);
        clearInterval(recordTimerRef.current);
      };

      mediaRecorder.start();
      setIsRecordingVoice(true);
      setRecordingSeconds(0);
      recordTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.warn('Microphone recording error:', err);
      // Fallback: send a sample audio note
      sendMessage('Voice Memo (Simulated)', [
        {
          type: 'audio',
          name: 'Faculty_Briefing.ogg',
          url: 'https://actions.google.com/sounds/v1/science_fiction/teleport_in.ogg',
          duration: 12,
        },
      ]);
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    } else {
      setIsRecordingVoice(false);
      setRecordingSeconds(0);
      clearInterval(recordTimerRef.current);
    }
  };

  // Image upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        sendMessage(messageInput.trim() || `Uploaded image: ${file.name}`, [
          {
            type: 'image',
            name: file.name,
            url,
          },
        ]);
        setMessageInput('');
      };
      reader.readAsDataURL(file);
    }
  };

  // Document file upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      sendMessage(messageInput.trim() || `Shared document: ${file.name}`, [
        {
          type: 'file',
          name: file.name,
          url: '#',
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
        },
      ]);
      setMessageInput('');
    }
  };

  return (
    <div className="h-[calc(100vh-140px)] flex bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      {/* Left Sidebar: Channels & Direct Messages */}
      <div className="w-64 border-r border-slate-200 flex flex-col bg-slate-50/60 shrink-0">
        <div className="p-3 border-b border-slate-200">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
            Campus & Office Chat
          </div>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Filter messages..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Channels List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-4">
          <div>
            <div className="px-2 mb-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Channels
            </div>
            <div className="space-y-0.5">
              {channels
                .filter((c) => !c.isDirect)
                .map((channel) => {
                  const isActive = activeChannelId === channel.id;
                  return (
                    <button
                      key={channel.id}
                      onClick={() => setActiveChannelId(channel.id)}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors text-left ${
                        isActive
                          ? 'bg-indigo-50 text-indigo-700 font-semibold'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <Hash className="w-3.5 h-3.5 text-slate-400" />
                      <span className="truncate">{channel.name}</span>
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Direct Messages */}
          <div>
            <div className="px-2 mb-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Direct Messages
            </div>
            <div className="space-y-0.5">
              {channels
                .filter((c) => c.isDirect)
                .map((channel) => {
                  const isActive = activeChannelId === channel.id;
                  return (
                    <button
                      key={channel.id}
                      onClick={() => setActiveChannelId(channel.id)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors text-left ${
                        isActive
                          ? 'bg-indigo-50 text-indigo-700 font-semibold'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <img
                          src={channel.recipientAvatar}
                          alt={channel.name}
                          referrerPolicy="no-referrer"
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="truncate">{channel.name}</span>
                      </div>
                      {channel.unreadCount && (
                        <span className="bg-indigo-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                          {channel.unreadCount}
                        </span>
                      )}
                    </button>
                  );
                })}
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white overflow-hidden">
        {/* Channel Header */}
        <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            {!activeChannel.isDirect ? (
              <Hash className="w-4 h-4 text-slate-400" />
            ) : (
              <img
                src={activeChannel.recipientAvatar}
                alt={activeChannel.name}
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-cover"
              />
            )}
            <h2 className="text-sm font-bold text-slate-900">{activeChannel.name}</h2>
            {activeChannel.topic && (
              <>
                <span className="text-slate-300">|</span>
                <span className="text-xs text-slate-500 truncate max-w-md">
                  {activeChannel.topic}
                </span>
              </>
            )}
          </div>
          <div className="text-xs text-slate-400">
            {channelMessages.length} messages
          </div>
        </div>

        {/* Message Feed */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {channelMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <p className="text-sm font-semibold text-slate-600">No messages in this view</p>
              <p className="text-xs mt-1">Start the discussion by typing a message below or sending a voice note.</p>
            </div>
          ) : (
            channelMessages.map((msg) => {
              const isSelf = msg.senderId === currentUser.id;
              return (
                <div key={msg.id} className="flex items-start gap-3 group">
                  <img
                    src={msg.senderAvatar}
                    alt={msg.senderName}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5 border border-slate-200"
                  />
                  <div className="flex-1 max-w-2xl">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-xs font-bold text-slate-900">{msg.senderName}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{msg.timestamp}</span>
                    </div>

                    <div className="text-xs text-slate-800 leading-relaxed bg-slate-50/70 p-3 rounded-xl border border-slate-200/80">
                      {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}

                      {/* Attachments */}
                      {msg.attachments && msg.attachments.length > 0 && (
                        <div className="mt-2 space-y-2">
                          {msg.attachments.map((att, idx) => {
                            if (att.type === 'image') {
                              return (
                                <div key={idx} className="relative group/img max-w-sm rounded-lg overflow-hidden border border-slate-200">
                                  <img
                                    src={att.url}
                                    alt={att.name}
                                    referrerPolicy="no-referrer"
                                    className="w-full max-h-56 object-cover cursor-pointer hover:opacity-95 transition-opacity"
                                    onClick={() => setPreviewImage(att.url)}
                                  />
                                  <div className="text-[11px] text-slate-500 p-1.5 bg-white border-t border-slate-100 flex items-center justify-between">
                                    <span className="truncate">{att.name}</span>
                                    <button
                                      onClick={() => setPreviewImage(att.url)}
                                      className="text-indigo-600 font-medium hover:underline text-[10px]"
                                    >
                                      Enlarge
                                    </button>
                                  </div>
                                </div>
                              );
                            }

                            if (att.type === 'file') {
                              return (
                                <div
                                  key={idx}
                                  className="flex items-center justify-between p-2.5 bg-white rounded-lg border border-slate-200 max-w-sm"
                                >
                                  <div className="flex items-center gap-2 truncate">
                                    <File className="w-4 h-4 text-indigo-600 shrink-0" />
                                    <div className="truncate">
                                      <div className="font-semibold text-slate-900 text-xs truncate">
                                        {att.name}
                                      </div>
                                      <div className="text-[10px] text-slate-400 font-mono">
                                        {att.size || '1.2 MB'} · PDF Document
                                      </div>
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => alert(`Downloading attachment: ${att.name}`)}
                                    className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
                                    title="Download file"
                                  >
                                    <Download className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              );
                            }

                            if (att.type === 'audio') {
                              return (
                                <div
                                  key={idx}
                                  className="flex flex-col gap-1.5 p-3 bg-white rounded-lg border border-slate-200 max-w-sm"
                                >
                                  <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                                    <span className="flex items-center gap-1.5">
                                      <Volume2 className="w-3.5 h-3.5 text-indigo-600" />
                                      Voice Note
                                    </span>
                                    <span className="text-[11px] text-slate-400 font-mono">
                                      00:{String(att.duration || 15).padStart(2, '0')}
                                    </span>
                                  </div>
                                  <audio
                                    controls
                                    src={att.url}
                                    className="w-full h-8 mt-1"
                                  />
                                </div>
                              );
                            }

                            return null;
                          })}
                        </div>
                      )}

                      {/* Reactions bar */}
                      {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2 pt-2 border-t border-slate-100">
                          {Object.entries(msg.reactions).map(([emoji, users]) => (
                            <button
                              key={emoji}
                              onClick={() => addReaction(msg.id, emoji)}
                              className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] border transition-colors ${
                                users.includes(currentUser.name)
                                  ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold'
                                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              <span>{emoji}</span>
                              <span className="font-mono text-[10px]">{users.length}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Quick Reaction Bar on Hover */}
                    <div className="relative mt-1 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      {['👍', '❤️', '🚀', '💡', '👏'].map((emoji) => (
                        <button
                          key={emoji}
                          onClick={() => addReaction(msg.id, emoji)}
                          className="px-1.5 py-0.5 text-xs hover:bg-slate-100 rounded transition-colors"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={feedEndRef} />
        </div>

        {/* Voice Note Recording Live Overlay */}
        {isRecordingVoice && (
          <div className="px-6 py-3 bg-red-50 border-t border-red-200 flex items-center justify-between text-xs text-red-700">
            <div className="flex items-center gap-2 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
              Recording Voice Memo:
              <span className="font-mono font-bold text-red-900">
                00:{String(recordingSeconds).padStart(2, '0')}
              </span>
            </div>
            <button
              onClick={stopVoiceRecording}
              className="px-3 py-1 bg-red-600 text-white rounded-md font-semibold text-xs hover:bg-red-700 flex items-center gap-1.5 shadow-xs"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              Stop & Send Memo
            </button>
          </div>
        )}

        {/* Input Bar */}
        <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 bg-white">
          <div className="flex items-center gap-2">
            {/* Hidden File Inputs */}
            <input
              type="file"
              ref={imageInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx,.xls,.xlsx"
              className="hidden"
            />

            {/* Media Upload Buttons */}
            <button
              type="button"
              onClick={() => imageInputRef.current?.click()}
              className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="Attach Photo"
            >
              <ImageIcon className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="Attach Document"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={startVoiceRecording}
              className={`p-2 rounded-lg transition-colors ${
                isRecordingVoice
                  ? 'bg-red-600 text-white'
                  : 'text-slate-500 hover:text-indigo-600 hover:bg-slate-100'
              }`}
              title="Record Voice Note"
            >
              <Mic className="w-4 h-4" />
            </button>

            {/* Text Input */}
            <input
              type="text"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              placeholder={`Message ${activeChannel.name}...`}
              className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all"
            />

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!messageInput.trim()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </div>
        </form>
      </div>

      {/* Lightbox Modal for Photo Attachments */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={previewImage}
              alt="Attachment Preview"
              referrerPolicy="no-referrer"
              className="max-w-full max-h-[85vh] rounded-lg object-contain shadow-2xl"
            />
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute -top-3 -right-3 bg-white text-slate-900 p-1.5 rounded-full shadow-lg hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
