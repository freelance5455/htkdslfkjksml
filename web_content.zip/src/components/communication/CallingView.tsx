import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  PhoneOff,
  Monitor,
  Hand,
  MessageSquare,
  FileText,
  Users,
  Copy,
  Check,
  Plus,
  Radio,
  Settings,
  Share2,
} from 'lucide-react';

export const CallingView: React.FC = () => {
  const { calls, currentCallId, joinCall, leaveCall, currentUser } = useApp();
  const [selectedCallId, setSelectedCallId] = useState<string>(calls[0].id);

  // In-call local states
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [activeSidePanel, setActiveSidePanel] = useState<'chat' | 'notes' | 'participants' | null>('chat');
  const [meetingNotes, setMeetingNotes] = useState<string>(
    '# All-Hands Meeting Agenda\n1. Science Lab robotics kit allocation.\n2. Final exam schedule approvals.\n3. Staff leave coverage arrangements.\n\nActions agreed:\n- Marcus to route 8 kits to Lab B-12 by Monday.\n- Report cards ready for Dean sign-off.'
  );
  const [inCallMessages, setInCallMessages] = useState<
    { sender: string; text: string; time: string }[]
  >([
    { sender: 'Prof. Arthur Pendelton', text: 'Good morning everyone. Audio is coming through crystal clear.', time: '10:02 AM' },
    { sender: 'Marcus Holloway', text: 'I am ready to present the inventory shipment report.', time: '10:03 AM' },
  ]);
  const [inCallChatInput, setInCallChatInput] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [mediaError, setMediaError] = useState<string | null>(null);

  // Video refs
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenShareVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);

  const activeCall = calls.find((c) => c.id === currentCallId) || calls.find((c) => c.id === selectedCallId);

  // Handle local camera stream
  useEffect(() => {
    if (currentCallId) {
      const startMedia = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true,
          });
          localStreamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setMediaError(null);
        } catch (err: any) {
          console.warn('Webcam/Mic not accessible, enabling high-fidelity simulated peer stream:', err);
          setMediaError('Camera permission not granted or device lacks camera. Using simulated interactive video stream.');
        }
      };

      startMedia();

      return () => {
        if (localStreamRef.current) {
          localStreamRef.current.getTracks().forEach((track) => track.stop());
          localStreamRef.current = null;
        }
        if (screenStreamRef.current) {
          screenStreamRef.current.getTracks().forEach((track) => track.stop());
          screenStreamRef.current = null;
        }
      };
    }
  }, [currentCallId]);

  // Toggle Mute Audio
  const handleToggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      if (localStreamRef.current) {
        localStreamRef.current.getAudioTracks().forEach((track) => {
          track.enabled = !next;
        });
      }
      return next;
    });
  };

  // Toggle Video Camera
  const handleToggleVideo = () => {
    setIsVideoOff((prev) => {
      const next = !prev;
      if (localStreamRef.current) {
        localStreamRef.current.getVideoTracks().forEach((track) => {
          track.enabled = !next;
        });
      }
      return next;
    });
  };

  // Toggle Screen Share
  const handleToggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        screenStreamRef.current = stream;
        if (screenShareVideoRef.current) {
          screenShareVideoRef.current.srcObject = stream;
        }
        setIsScreenSharing(true);
        stream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
          screenStreamRef.current = null;
        };
      } catch (err) {
        console.warn('Screen share canceled or unpermitted', err);
        // Fallback to simulated screen share demo
        setIsScreenSharing(true);
      }
    } else {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((track) => track.stop());
        screenStreamRef.current = null;
      }
      setIsScreenSharing(false);
    }
  };

  const handleSendInCallChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inCallChatInput.trim()) return;
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setInCallMessages((prev) => [
      ...prev,
      { sender: `${currentUser.name} (You)`, text: inCallChatInput.trim(), time: now },
    ]);
    setInCallChatInput('');
  };

  const copyRoomLink = () => {
    navigator.clipboard?.writeText(`https://synapse.edu/meet/room-${activeCall?.id || 'main'}`);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // If NOT currently inside a call room, display call schedule & room lobby
  if (!currentCallId) {
    return (
      <div className="space-y-6">
        {/* Header Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              Voice & Video Conference Hub
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              High-definition peer-to-peer audio and video calling for executive staff meetings and interactive classroom tutorials.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => joinCall('call_weekly_ops')}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Video className="w-4 h-4" />
              Start Instant Meeting
            </button>
          </div>
        </div>

        {/* Meeting Directory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {calls.map((call) => (
            <div
              key={call.id}
              className="border border-slate-200 bg-white rounded-xl p-5 hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3 text-xs text-slate-500">
                  <span className="font-semibold uppercase tracking-wider text-indigo-600">
                    {call.category === 'office' ? 'Office Operations' : 'Academic Lecture'}
                  </span>
                  <span>Started at {call.startedAt}</span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">{call.title}</h3>
                <p className="text-xs text-slate-600 mb-4 line-clamp-2 leading-relaxed">
                  {call.description}
                </p>

                {/* Active Participants Avatars */}
                <div className="mb-4">
                  <div className="text-[11px] font-medium text-slate-400 mb-2">
                    Active Participants ({call.participants.length})
                  </div>
                  <div className="flex items-center gap-2">
                    {call.participants.map((p) => (
                      <div key={p.id} className="relative group">
                        <img
                          src={p.avatar}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-full object-cover border-2 border-white shadow-xs"
                        />
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block px-2 py-1 bg-slate-900 text-white text-[10px] rounded shadow whitespace-nowrap z-20">
                          {p.name}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                <span className="text-xs text-slate-500 flex items-center gap-1.5 font-medium">
                  <Radio className="w-3.5 h-3.5 text-emerald-600" />
                  Live Room Active
                </span>
                <button
                  onClick={() => joinCall(call.id)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  Join Conference
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-200">
          <div className="p-4 bg-white border border-slate-200 rounded-xl">
            <div className="font-semibold text-slate-900 text-sm mb-1">Hardware Acceleration</div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Native browser WebRTC media pipeline with active noise suppression, echo cancellation, and resolution scaling.
            </p>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-xl">
            <div className="font-semibold text-slate-900 text-sm mb-1">Live Screen & Whiteboard</div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Share display monitors, window spreadsheets, or collaborate on shared meeting agendas and lecture problem sets.
            </p>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-xl">
            <div className="font-semibold text-slate-900 text-sm mb-1">Privacy & Role Security</div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Faculty and administrative host controls with participant mute, hand raising alerts, and session lock.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ACTIVE IN-CALL CONFERENCE ROOM VIEW
  return (
    <div className="h-[calc(100vh-140px)] flex flex-col bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 text-white">
      {/* Top Bar inside Call */}
      <div className="px-5 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <div>
            <h2 className="text-sm font-semibold text-white truncate max-w-md">
              {activeCall?.title}
            </h2>
            <div className="text-[11px] text-slate-400">
              Room ID: <span className="font-mono text-slate-300">{activeCall?.id}</span> · Encrypted Peer Stream
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isRecording && (
            <div className="flex items-center gap-1.5 text-xs text-red-400 font-mono px-2.5 py-1 rounded bg-red-950/60 border border-red-800">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              REC 00:14:22
            </div>
          )}

          <button
            onClick={copyRoomLink}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors border border-slate-700"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedCode ? 'Link Copied' : 'Invite Link'}
          </button>
        </div>
      </div>

      {/* Main Conference Content: Video Grid & Side Drawer */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video Tiles Grid */}
        <div className="flex-1 p-4 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto">
          {/* Tile 1: LOCAL USER */}
          <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-slate-800 aspect-video flex items-center justify-center group shadow-md">
            {/* Live Video Element */}
            {!isVideoOff ? (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform -scale-x-100"
              />
            ) : (
              <div className="flex flex-col items-center gap-2">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-full object-cover border-2 border-slate-700"
                />
                <span className="text-xs text-slate-400">Camera Paused</span>
              </div>
            )}

            {/* Local Badge */}
            <div className="absolute bottom-3 left-3 bg-slate-950/80 px-2.5 py-1 rounded-md text-xs font-medium text-slate-200 backdrop-blur-xs flex items-center gap-2 border border-slate-800">
              <span>{currentUser.name} (You)</span>
              {isMuted && <MicOff className="w-3 h-3 text-red-400" />}
              {isHandRaised && <Hand className="w-3 h-3 text-amber-400 animate-bounce" />}
            </div>

            {mediaError && (
              <div className="absolute top-3 left-3 right-3 text-[11px] bg-slate-900/90 text-amber-300 p-2 rounded border border-amber-800/60 leading-tight">
                {mediaError}
              </div>
            )}
          </div>

          {/* Tile 2: SCREEN SHARE or Remote Speaker 1 */}
          {isScreenSharing ? (
            <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-indigo-500 aspect-video flex flex-col justify-between p-4">
              <div className="text-xs text-indigo-300 font-semibold flex items-center gap-1.5">
                <Monitor className="w-4 h-4 text-indigo-400" />
                Live Screen Broadcast
              </div>
              <div className="flex-1 flex items-center justify-center p-4">
                <video
                  ref={screenShareVideoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain"
                />
                {!screenStreamRef.current && (
                  <div className="text-center p-6 bg-slate-950/60 rounded-xl border border-slate-800">
                    <p className="text-sm font-semibold text-slate-200">
                      Broadcasting Campus Physics Lab Simulator
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Sharing presentation viewport to 4 participants with low latency.
                    </p>
                  </div>
                )}
              </div>
              <div className="text-[11px] text-slate-400">Sharing Primary Display</div>
            </div>
          ) : (
            <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-slate-800 aspect-video flex items-center justify-center shadow-md">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=600"
                alt="Prof. Arthur Pendelton"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-3 bg-slate-950/80 px-2.5 py-1 rounded-md text-xs font-medium text-slate-200 backdrop-blur-xs flex items-center gap-2 border border-slate-800">
                <span>Prof. Arthur Pendelton</span>
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
            </div>
          )}

          {/* Tile 3: Remote Participant 2 */}
          <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-slate-800 aspect-video flex items-center justify-center shadow-md">
            <img
              src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=600"
              alt="Marcus Holloway"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-3 left-3 bg-slate-950/80 px-2.5 py-1 rounded-md text-xs font-medium text-slate-200 backdrop-blur-xs flex items-center gap-2 border border-slate-800">
              <span>Marcus Holloway</span>
              <MicOff className="w-3 h-3 text-red-400" />
            </div>
          </div>

          {/* Tile 4: Remote Participant 3 */}
          <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-slate-800 aspect-video flex items-center justify-center shadow-md">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600"
              alt="Sophia Thorne"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-3 left-3 bg-slate-950/80 px-2.5 py-1 rounded-md text-xs font-medium text-slate-200 backdrop-blur-xs flex items-center gap-2 border border-slate-800">
              <span>Sophia Thorne</span>
              <div className="w-2 h-2 rounded-full bg-emerald-400" />
            </div>
          </div>
        </div>

        {/* In-Call Side Panel (Chat, Notes, Roster) */}
        {activeSidePanel && (
          <div className="w-80 bg-slate-900 border-l border-slate-800 flex flex-col text-slate-200">
            {/* Side Panel Tabs */}
            <div className="flex border-b border-slate-800 text-xs font-medium">
              <button
                onClick={() => setActiveSidePanel('chat')}
                className={`flex-1 py-3 text-center border-b-2 transition-colors ${
                  activeSidePanel === 'chat'
                    ? 'border-indigo-500 text-indigo-400 font-semibold'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                In-Call Chat
              </button>
              <button
                onClick={() => setActiveSidePanel('notes')}
                className={`flex-1 py-3 text-center border-b-2 transition-colors ${
                  activeSidePanel === 'notes'
                    ? 'border-indigo-500 text-indigo-400 font-semibold'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Meeting Notes
              </button>
              <button
                onClick={() => setActiveSidePanel('participants')}
                className={`flex-1 py-3 text-center border-b-2 transition-colors ${
                  activeSidePanel === 'participants'
                    ? 'border-indigo-500 text-indigo-400 font-semibold'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Roster ({activeCall?.participants.length})
              </button>
            </div>

            {/* In-Call Chat Feed */}
            {activeSidePanel === 'chat' && (
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="flex-1 p-3 overflow-y-auto space-y-3 text-xs">
                  {inCallMessages.map((msg, i) => (
                    <div key={i} className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                      <div className="flex justify-between items-baseline mb-1">
                        <span className="font-semibold text-slate-300">{msg.sender}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{msg.time}</span>
                      </div>
                      <p className="text-slate-300 leading-relaxed">{msg.text}</p>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSendInCallChat} className="p-3 border-t border-slate-800 flex gap-2">
                  <input
                    type="text"
                    value={inCallChatInput}
                    onChange={(e) => setInCallChatInput(e.target.value)}
                    placeholder="Send a message to everyone..."
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold"
                  >
                    Send
                  </button>
                </form>
              </div>
            )}

            {/* In-Call Shared Notes */}
            {activeSidePanel === 'notes' && (
              <div className="flex-1 flex flex-col p-3">
                <div className="text-[11px] text-slate-400 mb-2">
                  Collaborative markdown notes saved to meeting record.
                </div>
                <textarea
                  value={meetingNotes}
                  onChange={(e) => setMeetingNotes(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-300 focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>
            )}

            {/* Participants Roster */}
            {activeSidePanel === 'participants' && (
              <div className="flex-1 p-3 overflow-y-auto space-y-2 text-xs">
                {activeCall?.participants.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-950/40 border border-slate-800/80"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={p.avatar}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div>
                        <div className="font-semibold text-slate-200">{p.name}</div>
                        <div className="text-[10px] text-slate-400">{p.role}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      {p.isMuted ? <MicOff className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
                      {p.isVideoOff && <VideoOff className="w-3.5 h-3.5 text-slate-500" />}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Conference Control Bar */}
      <div className="px-6 py-3 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-4">
        {/* Left: Meeting duration / status */}
        <div className="text-xs text-slate-400 font-medium hidden sm:block">
          Duration: <span className="font-mono text-slate-200">24:18</span> · 720p HD
        </div>

        {/* Center: Main Media Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mic */}
          <button
            onClick={handleToggleMute}
            className={`p-3 rounded-xl transition-all ${
              isMuted
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Camera */}
          <button
            onClick={handleToggleVideo}
            className={`p-3 rounded-xl transition-all ${
              isVideoOff
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title={isVideoOff ? 'Start camera' : 'Stop camera'}
          >
            {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
          </button>

          {/* Screen Share */}
          <button
            onClick={handleToggleScreenShare}
            className={`p-3 rounded-xl transition-all ${
              isScreenSharing
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title="Toggle Screen Share"
          >
            <Monitor className="w-4 h-4" />
          </button>

          {/* Hand Raise */}
          <button
            onClick={() => setIsHandRaised(!isHandRaised)}
            className={`p-3 rounded-xl transition-all ${
              isHandRaised
                ? 'bg-amber-600 text-white'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title="Raise hand"
          >
            <Hand className="w-4 h-4" />
          </button>

          {/* End Call Button */}
          <button
            onClick={leaveCall}
            className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold text-xs flex items-center gap-2 transition-all ml-2 shadow-xs"
          >
            <PhoneOff className="w-4 h-4" />
            <span className="hidden sm:inline">Leave Conference</span>
          </button>
        </div>

        {/* Right: Drawer toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'chat' ? null : 'chat')}
            className={`p-2.5 rounded-lg border text-xs transition-colors ${
              activeSidePanel === 'chat'
                ? 'bg-indigo-600 border-indigo-500 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Toggle In-Call Chat"
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'notes' ? null : 'notes')}
            className={`p-2.5 rounded-lg border text-xs transition-colors ${
              activeSidePanel === 'notes'
                ? 'bg-indigo-600 border-indigo-500 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Toggle Meeting Notes"
          >
            <FileText className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'participants' ? null : 'participants')}
            className={`p-2.5 rounded-lg border text-xs transition-colors ${
              activeSidePanel === 'participants'
                ? 'bg-indigo-600 border-indigo-500 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Toggle Participant Roster"
          >
            <Users className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
