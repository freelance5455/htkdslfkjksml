import React from 'react';
import { AlertCircle, Clock, ShieldCheck, Sun, Moon } from 'lucide-react';

const KILL_ZONES = [
  {
    name: 'Asian Kill Zone',
    nyTime: '7:00 PM – 10:00 PM',
    summerIst: '4:30 AM – 7:30 AM (next day)',
    winterIst: '5:30 AM – 8:30 AM (next day)',
  },
  {
    name: 'London Kill Zone',
    nyTime: '2:00 AM – 5:00 AM',
    summerIst: '11:30 AM – 2:30 PM',
    winterIst: '12:30 PM – 3:30 PM',
  },
  {
    name: 'New York AM Kill Zone',
    nyTime: '7:00 AM – 10:00 AM',
    summerIst: '4:30 PM – 7:30 PM',
    winterIst: '5:30 PM – 8:30 PM',
  },
  {
    name: 'London Close Kill Zone',
    nyTime: '10:00 AM – 12:00 PM',
    summerIst: '7:30 PM – 9:30 PM',
    winterIst: '8:30 PM – 10:30 PM',
  },
];

export const AboutView: React.FC = () => {
  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Introduction Card */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
            <Clock size={20} />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">About Jaswanth Time Converter</h2>
            <p className="text-xs text-slate-400">New York (Eastern) ↔ India Standard Time (IST)</p>
          </div>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed mt-2">
          <strong>Jaswanth Time Converter</strong> provides synchronized real-time clocks and accurate conversion between New York local time and India Standard Time (IST). Precision market sessions and key kill zones are strictly anchored to <strong>New York Local Time</strong>.
        </p>
      </div>

      {/* The Daylight Saving Difference Explained */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <div className="flex items-center gap-2 mb-3 text-amber-600">
          <AlertCircle size={18} />
          <h3 className="font-bold text-sm text-slate-900">The Daylight Saving (DST) Difference</h3>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed mb-3">
          New York time is often described casually as <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800 font-mono">UTC-4</code>. However, <strong>New York changes its timezone twice every year</strong> between Daylight Saving Time (EDT) and Standard Time (EST), while India (IST) remains constant at <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800 font-mono">UTC+5:30</code> year-round.
        </p>

        <div className="grid grid-cols-1 gap-2.5">
          {/* Summer / EDT */}
          <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/60">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <Sun size={14} className="text-amber-600" />
                <span>Summer (EDT — Eastern Daylight Time)</span>
              </span>
              <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-200/70 px-1.5 py-0.5 rounded">
                UTC-4
              </span>
            </div>
            <p className="text-[11px] text-amber-800 leading-normal">
              Occurs from 2nd Sunday in March to 1st Sunday in November.
              <br />
              <strong>India IST is 9 hours and 30 minutes ahead of New York.</strong>
            </p>
          </div>

          {/* Winter / EST */}
          <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200/60">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                <Moon size={14} className="text-sky-600" />
                <span>Winter (EST — Eastern Standard Time)</span>
              </span>
              <span className="text-[11px] font-mono font-bold text-sky-800 bg-sky-200/70 px-1.5 py-0.5 rounded">
                UTC-5
              </span>
            </div>
            <p className="text-[11px] text-sky-800 leading-normal">
              Occurs from 1st Sunday in November to 2nd Sunday in March.
              <br />
              <strong>India IST is 10 hours and 30 minutes ahead of New York.</strong>
            </p>
          </div>
        </div>

        <div className="mt-3 p-2.5 bg-slate-50 rounded-xl border border-slate-200/70 flex items-start gap-2">
          <ShieldCheck size={16} className="text-emerald-600 shrink-0 mt-0.5" />
          <p className="text-[11px] text-slate-600 leading-normal">
            <strong>Automatic Accuracy:</strong> This app uses the official IANA database (<code className="font-mono text-slate-800">America/New_York</code> and <code className="font-mono text-slate-800">Asia/Kolkata</code>). Whatever date you choose, DST transitions and offsets are automatically calculated without manual toggling.
          </p>
        </div>
      </div>

      {/* Jaswanth Kill Zones Table */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-100">
        <h3 className="font-bold text-sm text-slate-900 mb-2">Jaswanth Kill Zones</h3>
        <p className="text-xs text-slate-500 mb-3">
          Corresponding India (IST) timings during Summer (EDT) and Winter (EST):
        </p>

        {/* Mobile Responsive Layout (Screens under 640px) */}
        <div className="sm:hidden space-y-2.5">
          {KILL_ZONES.map((zone) => (
            <div
              key={zone.name}
              className="p-3 rounded-xl bg-slate-50/70 border border-slate-200/70 space-y-2"
            >
              <div className="flex flex-wrap items-center justify-between gap-1.5 pb-1.5 border-b border-slate-200/60">
                <span className="font-bold text-xs text-slate-900">{zone.name}</span>
                <span className="font-mono text-[11px] font-medium text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200/80">
                  {zone.nyTime} NY
                </span>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5">
                  <span className="text-[11px] font-medium text-amber-700">Summer IST (EDT):</span>
                  <span className="font-mono text-[11px] font-semibold text-amber-900 break-words text-right">
                    {zone.summerIst}
                  </span>
                </div>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5">
                  <span className="text-[11px] font-medium text-sky-700">Winter IST (EST):</span>
                  <span className="font-mono text-[11px] font-semibold text-sky-900 break-words text-right">
                    {zone.winterIst}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop / Tablet Table View (640px and up) */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-semibold">
                <th className="pb-2">Kill Zone</th>
                <th className="pb-2">New York Time</th>
                <th className="pb-2 text-amber-700">Summer IST (EDT)</th>
                <th className="pb-2 text-sky-700">Winter IST (EST)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {KILL_ZONES.map((zone) => (
                <tr key={zone.name}>
                  <td className="py-2.5 font-semibold text-slate-800">{zone.name}</td>
                  <td className="py-2.5 text-slate-600 font-mono">{zone.nyTime}</td>
                  <td className="py-2.5 text-amber-800 font-mono">{zone.summerIst}</td>
                  <td className="py-2.5 text-sky-800 font-mono">{zone.winterIst}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* App details */}
      <div className="p-4 text-center text-xs text-slate-400">
        <p>Jaswanth Time Converter</p>
        <p className="mt-1">Works 100% client-side & offline with IANA timezones.</p>
      </div>
    </div>
  );
};
