import React, { useState, useRef } from "react";
import {
  PenTool,
  Sliders,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  Sparkles,
  Check,
  Pipette,
  Layers,
  Circle,
  Eye,
  Minimize2,
  Maximize2
} from "lucide-react";
import {
  PEN_TYPES,
  PALETTE_INK_COLORS,
  STROKE_WIDTH_PRESETS,
  PenTypeConfig,
  triggerPenHapticFeedback
} from "../constants/PenStyles";

interface RealisticPenPaletteProps {
  activePenId?: PenTypeConfig["id"];
  activeColor?: string;
  strokeWidth?: number;
  opacity?: number;
  onChangePen?: (penId: PenTypeConfig["id"]) => void;
  onChangeColor?: (colorHex: string) => void;
  onChangeStrokeWidth?: (width: number) => void;
  onChangeOpacity?: (opacity: number) => void;
  onClearCanvas?: () => void;
  isDocked?: boolean;
  position?: "bottom" | "top" | "floating";
}

export const RealisticPenPalette: React.FC<RealisticPenPaletteProps> = ({
  activePenId = "pencil",
  activeColor = "#0F172A",
  strokeWidth = 2.0,
  opacity = 0.9,
  onChangePen,
  onChangeColor,
  onChangeStrokeWidth,
  onChangeOpacity,
  onClearCanvas,
  isDocked = true,
  position = "bottom",
}) => {
  const [selectedPen, setSelectedPen] = useState<PenTypeConfig["id"]>(activePenId);
  const [currentColor, setCurrentColor] = useState<string>(activeColor);
  const [currentWidth, setCurrentWidth] = useState<number>(strokeWidth);
  const [currentOpacity, setCurrentOpacity] = useState<number>(opacity);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [showColorPicker, setShowColorPicker] = useState<boolean>(false);
  const colorInputRef = useRef<HTMLInputElement>(null);

  const handlePenSelect = (penId: PenTypeConfig["id"]) => {
    triggerPenHapticFeedback("medium");
    setSelectedPen(penId);
    if (onChangePen) onChangePen(penId);

    // Auto set default width/opacity if switching pen type
    const penConfig = PEN_TYPES.find((p) => p.id === penId);
    if (penConfig) {
      setCurrentWidth(penConfig.defaultWidth);
      if (onChangeStrokeWidth) onChangeStrokeWidth(penConfig.defaultWidth);
      setCurrentOpacity(penConfig.defaultOpacity);
      if (onChangeOpacity) onChangeOpacity(penConfig.defaultOpacity);
    }
  };

  const handleColorSelect = (hex: string) => {
    triggerPenHapticFeedback("light");
    setCurrentColor(hex);
    if (onChangeColor) onChangeColor(hex);
  };

  const handleWidthChange = (w: number) => {
    setCurrentWidth(w);
    if (onChangeStrokeWidth) onChangeStrokeWidth(w);
  };

  const handleOpacityChange = (op: number) => {
    setCurrentOpacity(op);
    if (onChangeOpacity) onChangeOpacity(op);
  };

  // Helper renderer for realistic 3D Pen SVGBodies
  const renderPhysicalPenBody = (pen: PenTypeConfig) => {
    const isSelected = selectedPen === pen.id;
    const inkToUse = pen.id === "highlighter" ? (currentColor === "#0F172A" ? "#10B981" : currentColor) : currentColor;

    return (
      <div className="relative flex flex-col items-center group">
        {/* 3D Physical Pen Instrument Body */}
        <div
          className={`relative w-8 sm:w-10 h-32 sm:h-36 flex flex-col items-center cursor-pointer transition-all duration-350 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${
            isSelected
              ? "-translate-y-3.5 sm:-translate-y-4 scale-105 sm:scale-110 z-20"
              : "opacity-85 hover:opacity-100 hover:-translate-y-1.5 z-10"
          }`}
          onClick={() => handlePenSelect(pen.id)}
        >
          {/* 1. KURŞUN KALEM (Pencil) */}
          {pen.id === "pencil" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Pink Eraser Top */}
              <div className="w-5 h-3.5 bg-pink-400 rounded-t-sm shadow-inner border-b border-pink-500" />
              {/* Metallic Eraser Connector Band */}
              <div className="w-5.5 h-2 bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 border-y border-amber-400 shadow-xs" />
              {/* Hexagonal Wooden Shaft */}
              <div className="w-5 flex-1 bg-gradient-to-r from-amber-600 via-amber-400 to-amber-700 relative shadow-md flex items-center justify-center overflow-hidden">
                {/* Hexagonal Facet Lines */}
                <div className="absolute inset-y-0 left-1 w-px bg-amber-300/40" />
                <div className="absolute inset-y-0 right-1 w-px bg-amber-800/40" />
                <span className="text-[7px] font-mono font-bold text-amber-900/60 uppercase tracking-widest -rotate-90 select-none">
                  NOTEFLOW 2B
                </span>
              </div>
              {/* Sharpened Wooden Tip Cone */}
              <div className="w-5 h-5 relative">
                <svg viewBox="0 0 20 20" className="w-full h-full drop-shadow-xs">
                  <polygon points="0,0 20,0 10,20" fill="#FDE68A" />
                  {/* Graphite Lead Tip */}
                  <polygon points="6,12 14,12 10,20" fill={inkToUse} />
                </svg>
              </div>
            </div>
          )}

          {/* 2. DOLMA KALEM (Fountain Pen) */}
          {pen.id === "fountain" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Top Crown Accent */}
              <div className="w-5 h-2 bg-gradient-to-r from-yellow-300 via-amber-100 to-yellow-500 rounded-t-md shadow-xs" />
              {/* Brushed Dark Chrome Barrel */}
              <div className="w-5.5 flex-1 bg-gradient-to-r from-slate-800 via-slate-600 to-slate-900 relative shadow-lg flex items-center justify-center overflow-hidden border-x border-slate-700">
                {/* Specular Highlight Sheen */}
                <div className="absolute inset-y-0 left-1 w-1 bg-white/20 blur-[0.5px]" />
                {/* Gold Accent Ring */}
                <div className="w-full h-1.5 bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500 border-y border-amber-600 my-auto" />
              </div>
              {/* Steel / Gold Fountain Nib */}
              <div className="w-6 h-6 relative">
                <svg viewBox="0 0 24 24" className="w-full h-full drop-shadow-sm">
                  <path
                    d="M6,0 L18,0 L16,14 L12,24 L8,14 Z"
                    fill="url(#fountainNibGrad)"
                    stroke="#D97706"
                    strokeWidth="0.5"
                  />
                  {/* Nib Breather Hole & Slit */}
                  <circle cx="12" cy="10" r="1.2" fill={inkToUse} />
                  <line x1="12" y1="10" x2="12" y2="24" stroke={inkToUse} strokeWidth="0.8" />
                </svg>
                <svg className="hidden">
                  <defs>
                    <linearGradient id="fountainNibGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#CBD5E1" />
                      <stop offset="30%" stopColor="#F59E0B" />
                      <stop offset="70%" stopColor="#FEF08A" />
                      <stop offset="100%" stopColor="#94A3B8" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>
          )}

          {/* 3. TÜKENMEZ / JEL KALEM (Ballpoint) */}
          {pen.id === "ballpoint" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Metallic Push Button */}
              <div className="w-4 h-2.5 bg-gradient-to-r from-slate-300 via-white to-slate-400 rounded-t-sm shadow-xs" />
              {/* Plastic Barrel with Ink Level Window */}
              <div className="w-5 flex-1 bg-gradient-to-r from-blue-700 via-blue-500 to-blue-800 relative shadow-md flex flex-col items-center justify-between p-0.5 overflow-hidden border-x border-blue-900">
                {/* Metallic Pocket Clip */}
                <div className="w-1.5 h-10 bg-gradient-to-b from-slate-200 via-slate-400 to-slate-200 rounded-b-sm shadow-md absolute left-0.5 top-0 z-10" />
                {/* Transparent Ink Level Window */}
                <div className="w-2.5 h-12 bg-slate-900/60 rounded-full border border-white/20 relative my-auto overflow-hidden">
                  {/* Dynamic Ink Level */}
                  <div
                    className="absolute bottom-0 inset-x-0 transition-all duration-300"
                    style={{ height: "70%", backgroundColor: inkToUse }}
                  />
                </div>
              </div>
              {/* Metal Rollerball Cone */}
              <div className="w-4 h-4 relative">
                <svg viewBox="0 0 16 16" className="w-full h-full">
                  <polygon points="1,0 15,0 9,14 7,14" fill="#94A3B8" />
                  <circle cx="8" cy="15" r="1.5" fill={inkToUse} />
                </svg>
              </div>
            </div>
          )}

          {/* 4. FOSFORLU KALEM (Highlighter) */}
          {pen.id === "highlighter" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Glassmorphism Frosted Flat Body */}
              <div className="w-7 flex-1 rounded-t-lg bg-white/30 dark:bg-slate-800/40 backdrop-blur-md border border-white/50 shadow-md relative flex flex-col items-center justify-between p-1 overflow-hidden">
                <div
                  className="w-4 h-full rounded-md opacity-80 border border-white/30 transition-colors duration-300"
                  style={{ backgroundColor: inkToUse }}
                />
                <span className="text-[7px] font-extrabold text-slate-800/70 dark:text-white/70 uppercase tracking-widest my-auto -rotate-90 select-none">
                  TEXTMARKER
                </span>
              </div>
              {/* Chisel Felt Nib */}
              <div className="w-6 h-4 relative">
                <svg viewBox="0 0 24 16" className="w-full h-full">
                  <polygon points="2,0 22,0 18,16 6,16" fill={inkToUse} opacity="0.85" />
                  <line x1="2" y1="0" x2="18" y2="16" stroke="#FFFFFF" strokeWidth="1" opacity="0.4" />
                </svg>
              </div>
            </div>
          )}

          {/* 5. FIRÇA KALEM (Brush Pen) */}
          {pen.id === "brush" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Calligraphy Grip Handle */}
              <div className="w-5 flex-1 bg-gradient-to-r from-purple-900 via-purple-700 to-purple-950 rounded-t-xl shadow-lg relative flex flex-col items-center justify-between overflow-hidden border-x border-purple-800">
                <div className="w-full h-2 bg-gradient-to-r from-amber-400 to-amber-200 mt-2" />
                {/* Ergonomic Finger Grip Ribs */}
                <div className="space-y-1 my-auto">
                  <div className="w-4 h-0.5 bg-purple-950/80 rounded-full" />
                  <div className="w-4 h-0.5 bg-purple-950/80 rounded-full" />
                  <div className="w-4 h-0.5 bg-purple-950/80 rounded-full" />
                </div>
              </div>
              {/* Flexible Individual Bristles Tip */}
              <div className="w-5 h-6 relative">
                <svg viewBox="0 0 20 24" className="w-full h-full drop-shadow-xs">
                  <path d="M2,0 L18,0 C18,0 16,12 10,24 C4,12 2,0 2,0 Z" fill={inkToUse} />
                  {/* Bristle Highlight Lines */}
                  <path d="M6,2 C6,2 8,10 10,22" stroke="#FFFFFF" strokeWidth="0.5" opacity="0.3" fill="none" />
                  <path d="M14,2 C14,2 12,10 10,22" stroke="#FFFFFF" strokeWidth="0.5" opacity="0.3" fill="none" />
                </svg>
              </div>
            </div>
          )}

          {/* 6. HASSAS SİLGİ (Eraser) */}
          {pen.id === "eraser" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* White Rubber Top */}
              <div className="w-6 h-5 bg-slate-100 rounded-t-md shadow-inner border border-slate-300" />
              {/* Blue Protective Sleeve */}
              <div className="w-6.5 flex-1 bg-gradient-to-r from-blue-600 via-sky-500 to-blue-700 shadow-md flex items-center justify-center overflow-hidden border-x border-blue-800">
                <span className="text-[7px] font-black text-white uppercase tracking-widest -rotate-90 select-none">
                  MONO ERASER
                </span>
              </div>
            </div>
          )}

          {/* 7. KEMENT (Lasso Tool) */}
          {pen.id === "lasso" && (
            <div className="w-full h-full flex flex-col items-center relative">
              {/* Lasso Wand Handle */}
              <div className="w-5 flex-1 bg-gradient-to-r from-sky-600 via-cyan-500 to-sky-700 rounded-t-lg shadow-md flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white animate-ping opacity-75" />
              </div>
              {/* Lasso Loop Head */}
              <div className="w-6 h-6 flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-full h-full text-sky-400 animate-spin-slow">
                  <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" strokeDasharray="3 3" fill="none" />
                </svg>
              </div>
            </div>
          )}

          {/* Dynamic Specular Specular Highlight Sheen Overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none rounded-t-lg" />

          {/* Physical Contact Drop Shadow beneath active pen */}
          {isSelected && (
            <div
              className="absolute -bottom-2 w-7 sm:w-9 h-2.5 rounded-full blur-xs transition-all duration-300"
              style={{ backgroundColor: pen.shadowColor || "rgba(0, 0, 0, 0.3)" }}
            />
          )}
        </div>

        {/* Selected Indicator Pill */}
        {isSelected && (
          <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-md border border-slate-200 dark:border-slate-700 mt-1 animate-in fade-in zoom-in duration-150 whitespace-nowrap">
            {pen.name.split(" ")[0]}
          </span>
        )}
      </div>
    );
  };

  return (
    <div
      className={`w-full max-w-4xl mx-auto space-y-3 sm:space-y-4 select-none ${
        isDocked ? "p-2 sm:p-3" : "p-4"
      }`}
    >
      {/* ========================================================================= */}
      {/* ULTRA-REALISTIC STUDIO DOCK TRAY (GLASSMORPHISM & BRUSHED BORDER)         */}
      {/* ========================================================================= */}
      <div className="relative rounded-3xl sm:rounded-[2.5rem] bg-white/80 dark:bg-slate-900/85 backdrop-blur-2xl border border-white/60 dark:border-slate-700/80 shadow-[0_16px_40px_rgba(0,0,0,0.15),inset_0_2px_4px_rgba(255,255,255,0.6)] p-3 sm:p-5 flex flex-col gap-4 transition-all duration-300">
        
        {/* Top Header & Fine-tuning Bar */}
        <div className="flex items-center justify-between gap-2 px-1 sm:px-2 pb-2 border-b border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-indigo-600 text-white flex items-center justify-center shadow-md">
              <PenTool className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                <span>Realistic Studio Pen Palette</span>
                <span className="text-[9px] font-extrabold px-2 py-0.2 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  Notein & GoodNotes Standard
                </span>
              </h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Fiziksel dokular, dinamik mürekkep yansıması ve mekanik haptik geri bildirim
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Fine-tuning Drawer */}
            <button
              type="button"
              onClick={() => {
                triggerPenHapticFeedback("light");
                setIsDrawerOpen(!isDrawerOpen);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isDrawerOpen
                  ? "bg-teal-600 text-white shadow-md"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Uç & Akış Ayarları</span>
              {isDrawerOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {onClearCanvas && (
              <button
                type="button"
                onClick={() => {
                  triggerPenHapticFeedback("heavy");
                  onClearCanvas();
                }}
                className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/80 transition-colors cursor-pointer"
                title="Tuvali Temizle"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* MAIN PHYSICAL PEN RACK (3D ELEVATION RACK)                                 */}
        {/* ========================================================================= */}
        <div className="pt-4 pb-2 px-2 sm:px-6 flex items-end justify-around gap-1 sm:gap-4 overflow-x-auto scrollbar-none min-h-[160px] border-b border-slate-100 dark:border-slate-800/80">
          {PEN_TYPES.map((pen) => (
            <div key={pen.id} className="shrink-0">
              {renderPhysicalPenBody(pen)}
            </div>
          ))}
        </div>

        {/* ========================================================================= */}
        {/* INK COLOR SWATCH PALETTE WITH RADIAL SPECULAR HIGHLIGHT REFLECTION         */}
        {/* ========================================================================= */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-1 sm:px-2 pt-1">
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none w-full sm:w-auto pb-1 sm:pb-0">
            <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider shrink-0 mr-1">
              Mürekkep:
            </span>

            {PALETTE_INK_COLORS.map((swatch) => {
              const isSelected = currentColor.toLowerCase() === swatch.hex.toLowerCase();
              return (
                <button
                  key={swatch.hex}
                  type="button"
                  title={`${swatch.name} (${swatch.hex})`}
                  onClick={() => handleColorSelect(swatch.hex)}
                  className={`group relative w-7 h-7 sm:w-8 sm:h-8 rounded-full transition-all cursor-pointer shrink-0 flex items-center justify-center shadow-sm ${
                    isSelected
                      ? "ring-3 ring-teal-500 dark:ring-teal-400 scale-110 z-10"
                      : "hover:scale-105"
                  }`}
                  style={{ backgroundColor: swatch.hex }}
                >
                  {/* Radial Specular Highlight Reflection Sheen */}
                  <div className="absolute inset-0 rounded-full bg-radial from-white/40 via-transparent to-transparent pointer-events-none" />
                  {isSelected && (
                    <Check
                      className={`w-4 h-4 stroke-[3] ${
                        swatch.hex === "#FFFFFF" ? "text-slate-900" : "text-white"
                      }`}
                    />
                  )}
                </button>
              );
            })}

            {/* Custom HTML Hex Color Picker Button */}
            <div className="relative shrink-0 ml-1">
              <button
                type="button"
                onClick={() => {
                  triggerPenHapticFeedback("light");
                  if (colorInputRef.current) colorInputRef.current.click();
                }}
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gradient-to-tr from-indigo-500 via-rose-500 to-amber-400 p-0.5 shadow-md hover:scale-105 transition-transform cursor-pointer flex items-center justify-center"
                title="Özel Renk Seçici"
              >
                <div className="w-full h-full rounded-full bg-white dark:bg-slate-900 flex items-center justify-center text-slate-700 dark:text-slate-200">
                  <Pipette className="w-3.5 h-3.5" />
                </div>
              </button>
              <input
                ref={colorInputRef}
                type="color"
                value={currentColor}
                onChange={(e) => handleColorSelect(e.target.value)}
                className="opacity-0 absolute inset-0 w-full h-full cursor-pointer pointer-events-none"
              />
            </div>
          </div>

          {/* Quick Stroke Thickness Indicator Badge */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
            <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              Kalınlık: <strong className="text-slate-900 dark:text-white font-black">{currentWidth}mm</strong>
            </span>
            <div
              className="rounded-full bg-slate-900 dark:bg-white shadow-xs transition-all duration-200"
              style={{
                width: Math.max(6, Math.min(24, currentWidth * 2.5)),
                height: Math.max(6, Math.min(24, currentWidth * 2.5)),
                backgroundColor: currentColor,
              }}
            />
          </div>
        </div>

        {/* ========================================================================= */}
        {/* EXPANDABLE FINE-TUNING DRAWER (STROKE WIDTH & OPACITY SLIDERS)           */}
        {/* ========================================================================= */}
        {isDrawerOpen && (
          <div className="p-4 rounded-2xl bg-slate-100/90 dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700 space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
            {/* Stroke Width Slider & Presets */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Kalem Uç Kalınlığı (mm)</span>
                <span className="font-mono text-teal-600 dark:text-teal-400 font-extrabold">
                  {currentWidth} mm
                </span>
              </div>
              <input
                type="range"
                min="0.2"
                max="20.0"
                step="0.1"
                value={currentWidth}
                onChange={(e) => handleWidthChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-600"
              />
              <div className="flex items-center justify-between gap-1 pt-1 overflow-x-auto scrollbar-none">
                {STROKE_WIDTH_PRESETS.map((p) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => handleWidthChange(p.val)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                      currentWidth === p.val
                        ? "bg-teal-600 text-white shadow-xs"
                        : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Ink Opacity Slider */}
            <div className="space-y-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Mürekkep Saydamlığı (Opacity)</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400 font-extrabold">
                  %{Math.round(currentOpacity * 100)}
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={currentOpacity}
                onChange={(e) => handleOpacityChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
