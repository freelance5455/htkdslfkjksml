import { useCallback, useEffect, useRef, useState } from 'react';
import { Headphones, Play, Square, Volume2 } from 'lucide-react';
import { VideoPlayer } from '../player/VideoPlayer';

export interface StudyRecitation {
  id: string;
  videoId: string;
  title: string;
  reciter: string;
  sourceChannel: string;
  duration: string;
  note?: string;
}

type NoiseNodes = {
  context: AudioContext;
  source: AudioBufferSourceNode;
  gain: GainNode;
};

export function StudySoundPanel({ recitations }: { recitations: StudyRecitation[] }) {
  const [mode, setMode] = useState<'off' | 'brown-noise' | 'recitation'>('off');
  const [volume, setVolume] = useState(18);
  const [selectedId, setSelectedId] = useState(() => recitations.find((item) => item.id === 'baqarah-luhaidan')?.id ?? recitations[0]?.id ?? '');
  const [notice, setNotice] = useState('');
  const noise = useRef<NoiseNodes | null>(null);
  const selected = recitations.find((item) => item.id === selectedId) ?? recitations[0];

  const stopNoise = useCallback(() => {
    const active = noise.current;
    if (!active) return;
    noise.current = null;
    try { active.source.stop(); } catch { /* قد يكون المصدر قد توقف بالفعل */ }
    active.source.disconnect();
    active.gain.disconnect();
    void active.context.close();
  }, []);

  useEffect(() => () => stopNoise(), [stopNoise]);

  const startBrownNoise = async () => {
    stopNoise();
    setNotice('');
    setMode('off');
    try {
      const context = new AudioContext();
      await context.resume();
      const length = context.sampleRate * 10;
      const buffer = context.createBuffer(1, length, context.sampleRate);
      const channel = buffer.getChannelData(0);
      let last = 0;
      for (let index = 0; index < length; index += 1) {
        const white = Math.random() * 2 - 1;
        last = (last + 0.02 * white) / 1.02;
        channel[index] = last * 3.5;
      }
      // مزج طرفي العينة يجعل تكرارها أكثر نعومة ويقلل النقرات الصوتية.
      const fade = Math.min(Math.floor(context.sampleRate * 0.15), Math.floor(length / 4));
      for (let index = 0; index < fade; index += 1) {
        const blend = index / Math.max(1, fade - 1);
        const leftSample = channel[index] ?? 0;
        const rightSample = channel[length - fade + index] ?? 0;
        const mixed = leftSample * (1 - blend) + rightSample * blend;
        channel[index] = mixed;
        channel[length - fade + index] = mixed;
      }
      const source = context.createBufferSource();
      const gain = context.createGain();
      source.buffer = buffer;
      source.loop = true;
      gain.gain.value = (volume / 100) * 0.2;
      source.connect(gain);
      gain.connect(context.destination);
      source.start();
      noise.current = { context, source, gain };
      setMode('brown-noise');
    } catch {
      stopNoise();
      setMode('off');
      setNotice('تعذّر تشغيل صوت التركيز على هذا المتصفح. يمكنك متابعة الدراسة بلا صوت.');
    }
  };

  const chooseRecitation = () => {
    stopNoise();
    setNotice('');
    setMode('recitation');
  };

  const stopAll = () => {
    stopNoise();
    setMode('off');
  };

  const changeVolume = (next: number) => {
    setVolume(next);
    const active = noise.current;
    if (active) active.gain.gain.setTargetAtTime((next / 100) * 0.2, active.context.currentTime, 0.08);
  };

  return (
    <section id="study-audio" className="card scroll-mt-5 space-y-3 p-4" aria-label="أصوات الدراسة الاختيارية">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[var(--brand-soft)] text-[var(--brand)]"><Headphones size={19} /></span>
        <div>
          <h2 className="text-sm font-semibold text-[var(--ink)]">أصوات أثناء الدراسة</h2>
          <p className="mt-1 text-xs leading-relaxed text-[var(--ink-soft)]">اختيارية وتبدأ بضغطك فقط. الصوت وحده لا يسجل وقت دراسة ولا يمنح نقاطاً، والتلاوات تُعرض داخل المشغّل دون تنزيل.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => void startBrownNoise()} aria-pressed={mode === 'brown-noise'} className={`focus-ring flex min-h-11 items-center justify-center gap-2 rounded-2xl border px-3 text-xs font-medium ${mode === 'brown-noise' ? 'border-[var(--brand)] bg-[var(--brand)] text-[var(--brand-ink)]' : 'border-[var(--line)] text-[var(--ink)]'}`}>
          <Volume2 size={16} /> ضجيج تركيز هادئ
        </button>
        {recitations.length > 0 ? (
          <button type="button" onClick={chooseRecitation} aria-pressed={mode === 'recitation'} className={`focus-ring flex min-h-11 items-center justify-center gap-2 rounded-2xl border px-3 text-xs font-medium ${mode === 'recitation' ? 'border-[var(--brand)] bg-[var(--brand)] text-[var(--brand-ink)]' : 'border-[var(--line)] text-[var(--ink)]'}`}>
            <Play size={15} /> تلاوات قرآنية
          </button>
        ) : null}
      </div>

      {mode === 'brown-noise' ? (
        <div className="rounded-2xl bg-[var(--surface-2)] p-3">
          <label htmlFor="study-noise-volume" className="flex items-center justify-between gap-3 text-xs text-[var(--ink-soft)]">
            <span>مستوى صوت التركيز</span><span>{volume}%</span>
          </label>
          <input id="study-noise-volume" type="range" min="0" max="60" step="1" value={volume} onChange={(event) => changeVolume(Number(event.target.value))} className="mt-2 min-h-11 w-full accent-[var(--gold)]" />
        </div>
      ) : null}

      {mode === 'recitation' && selected ? (
        <div className="space-y-2">
          <label htmlFor="study-recitation" className="block text-xs font-medium text-[var(--ink)]">اختر التلاوة
            <select id="study-recitation" value={selected.id} onChange={(event) => setSelectedId(event.target.value)} className="focus-ring mt-1 min-h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]">
              {recitations.map((item) => <option key={item.id} value={item.id}>{item.title} · {item.duration}</option>)}
            </select>
          </label>
          <p className="text-xs leading-relaxed text-[var(--ink-soft)]">{selected.title} · القارئ: {selected.reciter} · المصدر: {selected.sourceChannel} · المدة: {selected.duration}{selected.note ? ` · ${selected.note}` : ''}</p>
          <VideoPlayer key={selected.videoId} videoId={selected.videoId} title={selected.title} autoPlayNext={false} />
        </div>
      ) : null}

      {notice ? <p role="status" className="rounded-xl bg-[var(--surface-2)] px-3 py-2 text-xs text-[var(--ink-soft)]">{notice}</p> : null}
      {mode !== 'off' ? (
        <button type="button" onClick={stopAll} className="focus-ring flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl border border-[var(--line)] text-xs font-medium text-[var(--ink)]">
          <Square size={14} /> إيقاف الصوت
        </button>
      ) : null}
      <span className="sr-only" aria-live="polite">{mode === 'brown-noise' ? 'صوت التركيز يعمل' : mode === 'recitation' ? 'اختر تلاوة واضغط تشغيل داخل المشغل' : 'الأصوات متوقفة'}</span>
    </section>
  );
}
