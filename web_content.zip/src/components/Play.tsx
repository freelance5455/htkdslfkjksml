import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess } from "chess.js";
import Board from "./Board";
import {
  capturedPieces,
  findBestMove,
  findKingSquare,
  GLYPH,
  materialBalance,
  type Difficulty,
  type PieceColor,
  type PieceType,
} from "../lib/chess";
import { cn } from "../utils/cn";

const DIFFICULTIES: { id: Difficulty; label: string; blurb: string }[] = [
  { id: "easy", label: "Pawn", blurb: "Beginner · plays loose moves" },
  { id: "medium", label: "Knight", blurb: "Club level · 2-ply search" },
  { id: "hard", label: "Queen", blurb: "Coach · 3-ply search" },
];

export default function Play() {
  const gameRef = useRef(new Chess());
  const [fen, setFen] = useState(gameRef.current.fen());
  const [history, setHistory] = useState<string[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [targets, setTargets] = useState<string[]>([]);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [playerColor, setPlayerColor] = useState<PieceColor>("w");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [thinking, setThinking] = useState(false);
  const [promotion, setPromotion] = useState<{ from: string; to: string } | null>(null);

  const game = gameRef.current;

  const sync = useCallback(() => {
    setFen(gameRef.current.fen());
    setHistory(gameRef.current.history());
    setSelected(null);
    setTargets([]);
  }, []);

  const newGame = useCallback(
    (color: PieceColor = playerColor) => {
      gameRef.current = new Chess();
      setPlayerColor(color);
      setLastMove(null);
      setPromotion(null);
      setThinking(false);
      sync();
    },
    [playerColor, sync],
  );

  /* Engine reply */
  useEffect(() => {
    const g = gameRef.current;
    if (g.isGameOver() || g.turn() === playerColor) return;
    let cancelled = false;
    setThinking(true);
    const snapshot = g.fen();
    const timer = window.setTimeout(() => {
      if (cancelled) return;
      const san = findBestMove(snapshot, difficulty);
      if (!cancelled && san && gameRef.current.fen() === snapshot) {
        const mv = gameRef.current.move(san);
        if (mv) setLastMove({ from: mv.from, to: mv.to });
        sync();
      }
      setThinking(false);
    }, 420);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [fen, playerColor, difficulty, sync]);

  const applyMove = useCallback(
    (from: string, to: string, promo?: string) => {
      try {
        const mv = gameRef.current.move({ from, to, promotion: promo ?? "q" });
        if (!mv) return;
        setLastMove({ from: mv.from, to: mv.to });
        sync();
      } catch {
        setSelected(null);
        setTargets([]);
      }
    },
    [sync],
  );

  const onSquareClick = useCallback(
    (square: string) => {
      if (promotion) return;
      const g = gameRef.current;
      if (g.isGameOver() || g.turn() !== playerColor) return;

      if (selected) {
        const legal = g.moves({ square: selected as never, verbose: true }) as Array<{
          to: string;
          piece: string;
          promotion?: string;
        }>;
        const match = legal.find((m) => m.to === square);
        if (match) {
          if (match.piece === "p" && (square[1] === "8" || square[1] === "1")) {
            setPromotion({ from: selected, to: square });
            setSelected(null);
            setTargets([]);
            return;
          }
          applyMove(selected, square);
          return;
        }
      }

      const piece = g.get(square as never);
      if (piece && piece.color === playerColor) {
        const legal = g.moves({ square: square as never, verbose: true }) as Array<{ to: string }>;
        setSelected(square);
        setTargets(legal.map((m) => m.to));
      } else {
        setSelected(null);
        setTargets([]);
      }
    },
    [applyMove, playerColor, promotion, selected],
  );

  const undo = () => {
    const g = gameRef.current;
    if (g.history().length === 0) return;
    g.undo();
    if (g.history().length > 0 && g.turn() !== playerColor) g.undo();
    setLastMove(null);
    sync();
  };

  const status = useMemo(() => {
    const g = gameRef.current;
    if (g.isCheckmate())
      return {
        tone: g.turn() === playerColor ? "bad" : "good",
        text: g.turn() === playerColor ? "Checkmate — the engine wins" : "Checkmate — you win! 🎉",
      };
    if (g.isStalemate()) return { tone: "flat", text: "Stalemate — draw" };
    if (g.isInsufficientMaterial()) return { tone: "flat", text: "Draw — insufficient material" };
    if (g.isDraw()) return { tone: "flat", text: "Draw" };
    if (g.inCheck())
      return { tone: "bad", text: g.turn() === playerColor ? "You are in check!" : "Engine in check" };
    if (thinking) return { tone: "flat", text: "Engine is thinking…" };
    return {
      tone: "flat",
      text: g.turn() === playerColor ? "Your move" : "Engine to move",
    };
  }, [fen, playerColor, thinking]);

  const captured = capturedPieces(fen);
  const balance = materialBalance(fen);
  const checkSquare = game.inCheck() ? findKingSquare(game, game.turn()) : null;

  const pairs: { n: number; w?: string; b?: string }[] = [];
  history.forEach((san, i) => {
    const idx = Math.floor(i / 2);
    if (!pairs[idx]) pairs[idx] = { n: idx + 1 };
    if (i % 2 === 0) pairs[idx].w = san;
    else pairs[idx].b = san;
  });

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="relative">
        <CapturedRow
          pieces={playerColor === "w" ? captured.w : captured.b}
          diff={playerColor === "w" ? balance : -balance}
          label={playerColor === "w" ? "You captured" : "You captured"}
        />
        <Board
          fen={fen}
          orientation={playerColor}
          selected={selected}
          targets={targets}
          lastMove={lastMove}
          checkSquare={checkSquare}
          onSquareClick={onSquareClick}
        />
        <CapturedRow
          pieces={playerColor === "w" ? captured.b : captured.w}
          diff={playerColor === "w" ? -balance : balance}
          label="Engine captured"
        />

        {promotion && (
          <div className="absolute inset-0 z-20 flex items-center justify-center rounded-xl bg-black/70 backdrop-blur-sm">
            <div className="rounded-2xl border border-white/10 bg-neutral-900 p-5 text-center shadow-xl">
              <p className="mb-3 text-sm font-medium text-neutral-300">Promote your pawn to:</p>
              <div className="flex gap-2">
                {(["q", "r", "b", "n"] as PieceType[]).map((t) => (
                  <button
                    key={t}
                    onClick={() => {
                      applyMove(promotion.from, promotion.to, t);
                      setPromotion(null);
                    }}
                    className="flex h-14 w-14 items-center justify-center rounded-xl bg-neutral-800 text-3xl text-white transition hover:bg-emerald-600"
                  >
                    {GLYPH[t]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <aside className="flex flex-col gap-4">
        <div
          className={cn(
            "rounded-2xl border p-4 text-sm font-medium",
            status.tone === "good" && "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
            status.tone === "bad" && "border-rose-500/40 bg-rose-500/10 text-rose-300",
            status.tone === "flat" && "border-white/10 bg-white/5 text-neutral-300",
          )}
        >
          {status.text}
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Opponent strength
          </p>
          <div className="grid gap-2">
            {DIFFICULTIES.map((d) => (
              <button
                key={d.id}
                onClick={() => setDifficulty(d.id)}
                className={cn(
                  "rounded-xl border px-3 py-2 text-left transition",
                  difficulty === d.id
                    ? "border-emerald-500/60 bg-emerald-500/15"
                    : "border-white/10 bg-black/20 hover:border-white/25",
                )}
              >
                <span className="block text-sm font-semibold text-neutral-100">{d.label}</span>
                <span className="block text-xs text-neutral-400">{d.blurb}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => newGame("w")}
            className="rounded-xl bg-emerald-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-emerald-500"
          >
            New game as White
          </button>
          <button
            onClick={() => newGame("b")}
            className="rounded-xl bg-neutral-800 px-3 py-2 text-sm font-semibold text-neutral-100 ring-1 ring-white/10 transition hover:bg-neutral-700"
          >
            New game as Black
          </button>
          <button
            onClick={undo}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10"
          >
            ↶ Take back
          </button>
          <button
            onClick={() => setPlayerColor((c) => (c === "w" ? "b" : "w"))}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10"
          >
            ⇵ Flip board
          </button>
        </div>

        <div className="flex-1 rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Moves
          </p>
          <div className="max-h-64 overflow-y-auto pr-1 font-mono text-sm">
            {pairs.length === 0 && <p className="text-neutral-500">No moves yet.</p>}
            {pairs.map((p) => (
              <div key={p.n} className="flex gap-3 py-0.5 text-neutral-200">
                <span className="w-6 text-neutral-500">{p.n}.</span>
                <span className="w-16">{p.w}</span>
                <span className="w-16">{p.b ?? ""}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

function CapturedRow({
  pieces,
  diff,
  label,
}: {
  pieces: PieceType[];
  diff: number;
  label: string;
}) {
  return (
    <div className="flex h-8 items-center gap-1 text-neutral-400">
      <span className="mr-1 text-[0.65rem] uppercase tracking-wider">{label}</span>
      <span className="text-lg leading-none">
        {pieces.map((p, i) => (
          <span key={`${p}${i}`}>{GLYPH[p]}</span>
        ))}
      </span>
      {diff > 0 && <span className="text-xs font-semibold text-emerald-400">+{diff}</span>}
    </div>
  );
}
