import React, { useState, useRef } from 'react';
import { useVideo } from '../context/VideoContext';
import {
  X,
  Upload,
  Film,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Play,
} from 'lucide-react';

export const UploadModal: React.FC = () => {
  const {
    isUploadModalOpen,
    setIsUploadModalOpen,
    refreshVideos,
    setActiveTab,
    setActiveVideo,
    language,
  } = useVideo();

  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [autoThumbnailDataUrl, setAutoThumbnailDataUrl] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('uploaded');
  const [rating, setRating] = useState<'All' | '13+' | '16+' | '18+'>('13+');
  const [tags, setTags] = useState('4K, Trending, New Release');
  const [cast, setCast] = useState('');
  const [director, setDirector] = useState('');
  const [duration, setDuration] = useState(0);

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successVideo, setSuccessVideo] = useState<any | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const hiddenVideoRef = useRef<HTMLVideoElement>(null);

  if (!isUploadModalOpen) return null;

  // Handle selecting the video file
  const handleVideoSelect = (file: File) => {
    if (!file.type.startsWith('video/')) {
      setErrorMsg('Please select a valid video file (MP4, WebM, MOV, MKV).');
      return;
    }

    setErrorMsg(null);
    setVideoFile(file);
    const preview = URL.createObjectURL(file);
    setVideoPreviewUrl(preview);

    // Auto-set title from clean file name
    const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
    if (!title) {
      setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }

    // Auto-capture thumbnail from video via hidden video + canvas
    const tempVid = document.createElement('video');
    tempVid.src = preview;
    tempVid.muted = true;
    tempVid.currentTime = 1.0;
    tempVid.onloadeddata = () => {
      setDuration(Math.round(tempVid.duration || 120));
      setTimeout(() => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = tempVid.videoWidth || 640;
          canvas.height = tempVid.videoHeight || 360;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(tempVid, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            setAutoThumbnailDataUrl(dataUrl);
          }
        } catch (e) {
          console.warn('Canvas thumbnail capture error:', e);
        }
      }, 300);
    };
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleVideoSelect(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const addTag = (tagToAdd: string) => {
    const list = tags.split(',').map((t) => t.trim()).filter(Boolean);
    if (!list.includes(tagToAdd)) {
      setTags([...list, tagToAdd].join(', '));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoFile) {
      setErrorMsg('Please select a video file to upload.');
      return;
    }
    if (!title.trim()) {
      setErrorMsg('Please provide a title for the video.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(15);
    setErrorMsg(null);

    try {
      const formData = new FormData();
      formData.append('video', videoFile);
      if (thumbFile) {
        formData.append('thumbnail', thumbFile);
      } else if (autoThumbnailDataUrl) {
        formData.append('thumbnailDataUrl', autoThumbnailDataUrl);
      }

      formData.append('title', title.trim());
      formData.append('description', description.trim());
      formData.append('category', category);
      formData.append('rating', rating);
      formData.append('tags', tags);
      formData.append('cast', cast.trim());
      formData.append('director', director.trim());
      formData.append('duration', duration.toString());
      formData.append('uploaderName', 'You');

      // Emulate progress increments
      const progressTimer = setInterval(() => {
        setUploadProgress((prev) => (prev < 90 ? prev + 12 : prev));
      }, 250);

      const res = await fetch('/api/videos/upload', {
        method: 'POST',
        body: formData,
      });

      clearInterval(progressTimer);
      setUploadProgress(100);

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Upload failed');
      }

      const result = await res.json();
      setSuccessVideo(result.video);
      await refreshVideos();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error uploading video');
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    setIsUploadModalOpen(false);
    setVideoFile(null);
    setThumbFile(null);
    setVideoPreviewUrl(null);
    setAutoThumbnailDataUrl(null);
    setSuccessVideo(null);
    setErrorMsg(null);
    setUploadProgress(0);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6"
      onClick={handleClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#181818] rounded-lg shadow-2xl border border-white/10 text-white overflow-hidden my-6"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-white/10 bg-zinc-900/60">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-[#E50914] flex items-center justify-center">
              <Upload className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                {language === 'ur' ? 'CineStream پر ویڈیو اپلوڈ کریں' : 'Upload Video to CineStream'}
              </h3>
              <p className="text-zinc-400 text-xs">
                {language === 'ur'
                  ? 'ویڈیو خودکار طور پر ڈیٹا بیس میں محفوظ ہوگی اور نیٹ فلکس پلیئر پر چلے گی'
                  : 'Video will be saved to the database and streamed via HTTP 206 range protocol'}
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content: Success State OR Form */}
        {successVideo ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h4 className="text-xl font-bold text-white">
                {language === 'ur' ? 'ویڈیو کامیابی سے اپلوڈ ہو گئی!' : 'Video Uploaded Successfully!'}
              </h4>
              <p className="text-zinc-400 text-xs sm:text-sm">
                "{successVideo.title}" has been saved to the library and is ready for streaming.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  handleClose();
                  setActiveVideo(successVideo);
                }}
                className="px-6 py-2.5 rounded bg-[#E50914] hover:bg-red-700 text-white font-bold text-sm flex items-center space-x-2 shadow-lg cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{language === 'ur' ? 'ابھی چلائیں' : 'Watch Now'}</span>
              </button>

              <button
                onClick={() => {
                  handleClose();
                  setActiveTab('uploaded');
                }}
                className="px-5 py-2.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold text-sm cursor-pointer"
              >
                {language === 'ur' ? 'اپلوڈز میں دیکھیں' : 'View in Uploads'}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
            {errorMsg && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-md text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Drag & Drop File Zone */}
            {!videoFile ? (
              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-700 hover:border-red-500 rounded-lg p-6 sm:p-8 text-center bg-zinc-900/40 hover:bg-zinc-900/80 transition-all cursor-pointer group"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleVideoSelect(e.target.files[0])}
                />
                <div className="w-12 h-12 rounded-full bg-zinc-800 group-hover:bg-[#E50914] flex items-center justify-center mx-auto text-zinc-300 group-hover:text-white transition-all mb-3">
                  <Film className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-white">
                  {language === 'ur' ? 'ویڈیو فائل یہاں ڈراپ کریں یا منتخب کریں' : 'Drag & drop video file here, or click to browse'}
                </p>
                <p className="text-zinc-500 text-xs mt-1">
                  Supports MP4, WebM, MOV, MKV (Up to 500 MB)
                </p>
              </div>
            ) : (
              <div className="relative rounded-lg overflow-hidden border border-zinc-700 bg-black flex flex-col sm:flex-row items-center">
                {/* Video Preview */}
                <div className="w-full sm:w-48 aspect-video bg-zinc-900 flex-shrink-0 relative">
                  <video
                    src={videoPreviewUrl || ''}
                    className="w-full h-full object-cover"
                    controls={false}
                  />
                  <div className="absolute top-1 left-1 bg-black/70 px-1 text-[10px] rounded text-emerald-400">
                    Preview
                  </div>
                </div>

                <div className="p-3 sm:p-4 flex-1 w-full flex items-center justify-between">
                  <div className="truncate mr-2">
                    <p className="text-white text-xs sm:text-sm font-bold truncate">
                      {videoFile.name}
                    </p>
                    <p className="text-zinc-400 text-xs">
                      {(videoFile.size / (1024 * 1024)).toFixed(1)} MB • {duration}s
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setVideoFile(null);
                      setVideoPreviewUrl(null);
                      setAutoThumbnailDataUrl(null);
                    }}
                    className="text-xs text-red-400 hover:text-red-300 underline cursor-pointer"
                  >
                    Change
                  </button>
                </div>
              </div>
            )}

            {/* Metadata Fields */}
            <div className="space-y-4">
              {/* Title & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">
                    {language === 'ur' ? 'ویڈیو کا نام / عنوان *' : 'Video Title *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Cyber City 2099 Trailer"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="uploaded">Community Upload</option>
                    <option value="movies">Movie</option>
                    <option value="series">Series / Show</option>
                    <option value="action">Action</option>
                    <option value="scifi">Sci-Fi</option>
                    <option value="comedy">Comedy</option>
                    <option value="documentary">Documentary</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-zinc-300">
                  {language === 'ur' ? 'تفصیل / Synopsis' : 'Description / Synopsis'}
                </label>
                <textarea
                  rows={2}
                  placeholder="Tell viewers what this video is about..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Maturity Rating & Tags */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Age Rating</label>
                  <select
                    value={rating}
                    onChange={(e) => setRating(e.target.value as any)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="All">All Audiences (G)</option>
                    <option value="13+">13+ Teen</option>
                    <option value="16+">16+ Mature</option>
                    <option value="18+">18+ Adults</option>
                  </select>
                </div>

                <div className="sm:col-span-2 space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="Action, Sci-Fi, HD"
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500"
                  />
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {['Action', 'Sci-Fi', 'Trailer', 'Original', 'Urdu', 'Hindi', 'Music'].map((t) => (
                      <button
                        type="button"
                        key={t}
                        onClick={() => addTag(t)}
                        className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                      >
                        +{t}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Cast & Director */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Creator / Cast</label>
                  <input
                    type="text"
                    placeholder="e.g. Salman, Alex"
                    value={cast}
                    onChange={(e) => setCast(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Director</label>
                  <input
                    type="text"
                    placeholder="e.g. Salman Kamboh"
                    value={director}
                    onChange={(e) => setDirector(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Custom Thumbnail Upload (Optional) */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-300 flex items-center justify-between">
                  <span>Custom Poster Thumbnail (Optional)</span>
                  {autoThumbnailDataUrl && !thumbFile && (
                    <span className="text-emerald-400 text-[10px]">
                      ✓ Auto-captured frame ready
                    </span>
                  )}
                </label>
                <div className="flex items-center space-x-3">
                  <input
                    ref={thumbInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => setThumbFile(e.target.files?.[0] || null)}
                  />
                  <button
                    type="button"
                    onClick={() => thumbInputRef.current?.click()}
                    className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold flex items-center space-x-1.5 cursor-pointer border border-zinc-700"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-zinc-400" />
                    <span>{thumbFile ? thumbFile.name : 'Upload Custom Image'}</span>
                  </button>

                  {autoThumbnailDataUrl && !thumbFile && (
                    <img
                      src={autoThumbnailDataUrl}
                      alt="Captured snapshot"
                      className="w-12 h-7 object-cover rounded border border-white/20"
                    />
                  )}
                </div>
              </div>
            </div>

            {/* Progress Bar (when uploading) */}
            {isUploading && (
              <div className="space-y-1.5 pt-2">
                <div className="flex items-center justify-between text-xs text-zinc-300 font-semibold">
                  <span>Uploading video to database...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#E50914] transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Footer Buttons */}
            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={handleClose}
                disabled={isUploading}
                className="px-4 py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isUploading || !videoFile}
                className="px-6 py-2 rounded bg-[#E50914] hover:bg-red-700 disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center space-x-2 transition-all shadow-lg cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>
                  {isUploading
                    ? 'Uploading...'
                    : language === 'ur'
                    ? 'ویڈیو محفوظ کریں'
                    : 'Publish & Upload'}
                </span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
