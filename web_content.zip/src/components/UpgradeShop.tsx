import React, { useState } from 'react';
import { WeaponConfig, WeaponType, GameResources, BaseState, PlayerState } from '../types';
import {
  Crosshair,
  Shield,
  Zap,
  Flame,
  Radio,
  ArrowRight,
  Sparkles,
  Lock,
  Plus,
  Coins,
  Package,
  Wrench,
  Hammer,
} from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface UpgradeShopProps {
  isOpen: boolean;
  wave: number;
  resources: GameResources;
  weapons: Record<string, WeaponConfig>;
  base: BaseState;
  player: PlayerState;
  onUpgradeWeapon: (weaponId: WeaponType, stat: 'damage' | 'fireRate' | 'mag' | 'reload') => void;
  onUnlockWeapon: (weaponId: WeaponType) => void;
  onUpgradeBase: (type: 'walls' | 'baseCore' | 'repairEfficiency') => void;
  onBuySupply: (type: 'ammo' | 'grenade' | 'heal') => void;
  onStartNextWave: () => void;
}

export const UpgradeShop: React.FC<UpgradeShopProps> = ({
  isOpen,
  wave,
  resources,
  weapons,
  base,
  player,
  onUpgradeWeapon,
  onUnlockWeapon,
  onUpgradeBase,
  onBuySupply,
  onStartNextWave,
}) => {
  const [activeTab, setActiveTab] = useState<'weapons' | 'base' | 'supplies'>('weapons');
  const [selectedWeaponId, setSelectedWeaponId] = useState<WeaponType>('pistol');

  if (!isOpen) return null;

  const selectedWeapon = weapons[selectedWeaponId];

  // Weapon Upgrade Costs
  const getUpgradeCost = (level: number) => {
    return {
      coins: 40 + level * 35,
      metal: 10 + level * 8,
      wood: 8 + level * 5,
    };
  };

  const damageCost = getUpgradeCost(selectedWeapon?.damageLevel || 1);
  const fireRateCost = getUpgradeCost(selectedWeapon?.fireRateLevel || 1);
  const magCost = getUpgradeCost(selectedWeapon?.magLevel || 1);
  const reloadCost = getUpgradeCost(selectedWeapon?.reloadLevel || 1);

  const canAfford = (cost: { coins: number; metal: number; wood: number }) => {
    return (
      resources.coins >= cost.coins &&
      resources.metal >= cost.metal &&
      resources.wood >= cost.wood
    );
  };

  return (
    <div
      id="upgrade-shop-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-300 select-none"
    >
      <div
        id="upgrade-shop-modal"
        className="relative w-full max-w-4xl h-[92vh] max-h-[700px] flex flex-col bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden text-zinc-100"
      >
        {/* Header Bar with Resources */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-zinc-800 bg-zinc-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-display uppercase tracking-wider text-white">
                Arsenal va Bazani Yaxshilash
              </div>
              <p className="text-xs text-zinc-400">
                {wave}-toʻlqin yakunlandi! Keyingi bosqich uchun qurol va bazangizni kuchaytiring.
              </p>
            </div>
          </div>

          {/* Current Resource Balances */}
          <div className="flex items-center gap-3 bg-zinc-950/80 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-bold">
            <div className="flex items-center gap-1.5 text-yellow-400">
              <Coins className="w-4 h-4" />
              <span>{resources.coins}</span>
            </div>
            <div className="w-px h-4 bg-zinc-800" />
            <div className="flex items-center gap-1.5 text-slate-300">
              <Package className="w-4 h-4 text-slate-400" />
              <span>{resources.metal} Metall</span>
            </div>
            <div className="w-px h-4 bg-zinc-800" />
            <div className="flex items-center gap-1.5 text-amber-500">
              <Wrench className="w-4 h-4" />
              <span>{resources.wood} Yogʻoch</span>
            </div>
            <div className="w-px h-4 bg-zinc-800" />
            <div className="flex items-center gap-1.5 text-orange-400">
              <Zap className="w-4 h-4" />
              <span>{resources.ammo} Oʻq</span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-900/90 px-6">
          <button
            id="tab-weapons-btn"
            onClick={() => setActiveTab('weapons')}
            className={`py-3 px-5 font-display text-base font-bold uppercase tracking-wider border-b-2 transition ${
              activeTab === 'weapons'
                ? 'border-red-500 text-red-400 bg-zinc-800/40'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Qurollar Arsenali
          </button>
          <button
            id="tab-base-btn"
            onClick={() => setActiveTab('base')}
            className={`py-3 px-5 font-display text-base font-bold uppercase tracking-wider border-b-2 transition ${
              activeTab === 'base'
                ? 'border-sky-500 text-sky-400 bg-zinc-800/40'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Baza va Mudofaa
          </button>
          <button
            id="tab-supplies-btn"
            onClick={() => setActiveTab('supplies')}
            className={`py-3 px-5 font-display text-base font-bold uppercase tracking-wider border-b-2 transition ${
              activeTab === 'supplies'
                ? 'border-amber-500 text-amber-400 bg-zinc-800/40'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Oʻq-Dori va Zaxiralar
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* TAB 1: WEAPONS */}
          {activeTab === 'weapons' && (
            <div className="grid grid-cols-12 gap-5 h-full">
              {/* Left Column: Weapon List */}
              <div className="col-span-5 space-y-2 overflow-y-auto pr-1">
                {(Object.values(weapons) as WeaponConfig[]).map((w) => {
                  const isSelected = selectedWeaponId === w.id;
                  return (
                    <div
                      key={w.id}
                      id={`select-weapon-${w.id}`}
                      onClick={() => setSelectedWeaponId(w.id)}
                      className={`p-3.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-red-500/15 border-red-500 text-white shadow-md'
                          : 'bg-zinc-950/40 hover:bg-zinc-800/60 border-zinc-800 text-zinc-300'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-sm flex items-center gap-2">
                          {w.name}
                          {!w.unlocked && <Lock className="w-3.5 h-3.5 text-zinc-500" />}
                        </div>
                        <div className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5">
                          {w.description}
                        </div>
                      </div>

                      <div className="text-right">
                        {w.unlocked ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            OCHIQ
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                            {w.unlockCostCoins} Tanga
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Right Column: Weapon Inspector & Upgrade Buttons */}
              <div className="col-span-7 bg-zinc-950/50 border border-zinc-800 rounded-xl p-5 flex flex-col justify-between">
                {selectedWeapon ? (
                  <>
                    <div>
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-bold font-display uppercase tracking-wide text-white">
                            {selectedWeapon.name}
                          </h3>
                          <p className="text-xs text-zinc-400 mt-0.5">
                            {selectedWeapon.description}
                          </p>
                        </div>
                        {selectedWeapon.unlocked ? (
                          <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-lg border border-emerald-500/30">
                            Foydalanishda
                          </span>
                        ) : (
                          <button
                            id="unlock-weapon-btn"
                            disabled={resources.coins < selectedWeapon.unlockCostCoins}
                            onClick={() => onUnlockWeapon(selectedWeapon.id)}
                            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 ${
                              resources.coins >= selectedWeapon.unlockCostCoins
                                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-950/60 active:scale-95'
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                          >
                            <Lock className="w-4 h-4" />
                            Qulfdan Ochish ({selectedWeapon.unlockCostCoins} Tanga)
                          </button>
                        )}
                      </div>

                      {/* Upgrade Stats Grid */}
                      <div className="grid grid-cols-2 gap-3 mt-4">
                        {/* 1. Damage Upgrade */}
                        <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-zinc-400">Zarar (Damage)</span>
                              <span className="font-bold text-red-400">
                                Lvl {selectedWeapon.damageLevel}
                              </span>
                            </div>
                            <div className="text-lg font-bold text-white mt-1">
                              {selectedWeapon.damage} HP
                            </div>
                          </div>
                          <button
                            id="upgrade-damage-btn"
                            disabled={!selectedWeapon.unlocked || !canAfford(damageCost)}
                            onClick={() => onUpgradeWeapon(selectedWeapon.id, 'damage')}
                            className={`mt-2.5 w-full py-1.5 rounded-lg text-[11px] font-bold uppercase transition flex items-center justify-center gap-1 ${
                              selectedWeapon.unlocked && canAfford(damageCost)
                                ? 'bg-red-600 hover:bg-red-500 text-white shadow'
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            +25% Zarar ({damageCost.coins}T / {damageCost.metal}M)
                          </button>
                        </div>

                        {/* 2. Fire Rate Upgrade */}
                        <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-zinc-400">Otish Tezligi</span>
                              <span className="font-bold text-amber-400">
                                Lvl {selectedWeapon.fireRateLevel}
                              </span>
                            </div>
                            <div className="text-lg font-bold text-white mt-1">
                              {selectedWeapon.fireRate.toFixed(1)} oʻq/sek
                            </div>
                          </div>
                          <button
                            id="upgrade-firerate-btn"
                            disabled={!selectedWeapon.unlocked || !canAfford(fireRateCost)}
                            onClick={() => onUpgradeWeapon(selectedWeapon.id, 'fireRate')}
                            className={`mt-2.5 w-full py-1.5 rounded-lg text-[11px] font-bold uppercase transition flex items-center justify-center gap-1 ${
                              selectedWeapon.unlocked && canAfford(fireRateCost)
                                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow'
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            +20% Tezlik ({fireRateCost.coins}T / {fireRateCost.metal}M)
                          </button>
                        </div>

                        {/* 3. Magazine Capacity */}
                        <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-zinc-400">Oʻqdon Hajmi</span>
                              <span className="font-bold text-cyan-400">
                                Lvl {selectedWeapon.magLevel}
                              </span>
                            </div>
                            <div className="text-lg font-bold text-white mt-1">
                              {selectedWeapon.magazineSize} dona
                            </div>
                          </div>
                          <button
                            id="upgrade-mag-btn"
                            disabled={!selectedWeapon.unlocked || !canAfford(magCost)}
                            onClick={() => onUpgradeWeapon(selectedWeapon.id, 'mag')}
                            className={`mt-2.5 w-full py-1.5 rounded-lg text-[11px] font-bold uppercase transition flex items-center justify-center gap-1 ${
                              selectedWeapon.unlocked && canAfford(magCost)
                                ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow'
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            +Kattaroq Oʻqdon ({magCost.coins}T / {magCost.wood}Y)
                          </button>
                        </div>

                        {/* 4. Reload Speed */}
                        <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-zinc-400">Qayta Oʻqlash</span>
                              <span className="font-bold text-purple-400">
                                Lvl {selectedWeapon.reloadLevel}
                              </span>
                            </div>
                            <div className="text-lg font-bold text-white mt-1">
                              {selectedWeapon.reloadTime.toFixed(1)} sek
                            </div>
                          </div>
                          <button
                            id="upgrade-reload-btn"
                            disabled={!selectedWeapon.unlocked || !canAfford(reloadCost)}
                            onClick={() => onUpgradeWeapon(selectedWeapon.id, 'reload')}
                            className={`mt-2.5 w-full py-1.5 rounded-lg text-[11px] font-bold uppercase transition flex items-center justify-center gap-1 ${
                              selectedWeapon.unlocked && canAfford(reloadCost)
                                ? 'bg-purple-600 hover:bg-purple-500 text-white shadow'
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            -15% Vaqt ({reloadCost.coins}T / {reloadCost.metal}M)
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                ) : null}
              </div>
            </div>
          )}

          {/* TAB 2: BASE UPGRADES */}
          {activeTab === 'base' && (
            <div className="grid grid-cols-3 gap-5">
              {/* Fortified Walls */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30 mb-3">
                    <Shield className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">Devorlar Mustahkamligi</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Baza atrofidagi beton va poʻlat devorlarning maksimal sogʻligʻini +200 HP ga
                    oshiradi va zarbaga chidamliligini kuchaytiradi.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">
                    Narxi: 80 Tanga, 25 Metall, 35 Yogʻoch
                  </div>
                  <button
                    id="upgrade-walls-btn"
                    disabled={resources.coins < 80 || resources.metal < 25 || resources.wood < 35}
                    onClick={() => onUpgradeBase('walls')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 80 && resources.metal >= 25 && resources.wood >= 35
                        ? 'bg-sky-600 hover:bg-sky-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Devorlarni Kuchaytirish
                  </button>
                </div>
              </div>

              {/* Base Generator Core */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mb-3">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">Baza Generatori Qalqoni</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Markaziy baza generatorining maksimal sogʻligʻini oshiradi (+300 HP) va unga
                    qoʻshimcha energiya toʻsigʻi beradi.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">
                    Narxi: 120 Tanga, 40 Metall, 20 Yogʻoch
                  </div>
                  <button
                    id="upgrade-generator-btn"
                    disabled={resources.coins < 120 || resources.metal < 40 || resources.wood < 20}
                    onClick={() => onUpgradeBase('baseCore')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 120 && resources.metal >= 40 && resources.wood >= 20
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Generatorni Kuchaytirish
                  </button>
                </div>
              </div>

              {/* Repair Efficiency */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 mb-3">
                    <Hammer className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">Taʼmirlash Samaradorligi</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Baza yoki devorlarni taʼmirlaganda har bir bosishda 2 barobar koʻproq HP
                    tiklanadi va kamroq resurs sarflanadi.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">
                    Narxi: 70 Tanga, 20 Metall, 30 Yogʻoch
                  </div>
                  <button
                    id="upgrade-repair-btn"
                    disabled={resources.coins < 70 || resources.metal < 20 || resources.wood < 30}
                    onClick={() => onUpgradeBase('repairEfficiency')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 70 && resources.metal >= 20 && resources.wood >= 30
                        ? 'bg-amber-600 hover:bg-amber-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Taʼmirlashni Kuchaytirish
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SUPPLIES / AMMO MARKET */}
          {activeTab === 'supplies' && (
            <div className="grid grid-cols-3 gap-5">
              {/* Ammo Pack */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 mb-3">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">+60 Dona Oʻq-Dori</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Avtomat, snayper va boshqa barcha qurollar uchun universal oʻqlar zahirasi.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">Narxi: 35 Tanga</div>
                  <button
                    id="buy-ammo-btn"
                    disabled={resources.coins < 35}
                    onClick={() => onBuySupply('ammo')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 35
                        ? 'bg-orange-600 hover:bg-orange-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Sotib Olish (+60 Oʻq)
                  </button>
                </div>
              </div>

              {/* Grenade Pack */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-red-500/20 text-red-400 border border-red-500/30 mb-3">
                    <Flame className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">+2 Dona Portlovchi Granata</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Toʻplanib kelayotgan oʻnlab zoʻmbilarni bir zumda yoʻq qiluvchi kuchli granata.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">Narxi: 45 Tanga</div>
                  <button
                    id="buy-grenade-btn"
                    disabled={resources.coins < 45}
                    onClick={() => onBuySupply('grenade')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 45
                        ? 'bg-red-600 hover:bg-red-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Sotib Olish (+2 Granata)
                  </button>
                </div>
              </div>

              {/* Medkit Pack */}
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col justify-between">
                <div>
                  <div className="p-2.5 w-fit rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mb-3">
                    <Shield className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-base text-white">Harbiy Aptechka (Toʻliq Davolash)</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Qahramon sogʻligʻini bir zumda 100% toʻliq tiklaydi.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800">
                  <div className="text-xs text-zinc-400 mb-2">Narxi: 50 Tanga</div>
                  <button
                    id="buy-medkit-btn"
                    disabled={resources.coins < 50}
                    onClick={() => onBuySupply('heal')}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase transition ${
                      resources.coins >= 50
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    Davolanish (+100 HP)
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer: Start Next Wave */}
        <div className="px-6 py-3.5 border-t border-zinc-800 bg-zinc-950/90 flex items-center justify-between">
          <div className="text-xs text-zinc-400">
            Resurslarni tejab ishlating, keyingi toʻlqinda zoʻmbilar soni va kuchi oshadi!
          </div>

          <button
            id="start-next-wave-btn"
            onClick={onStartNextWave}
            className="flex items-center gap-2 px-8 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold font-display text-lg uppercase tracking-wider shadow-lg shadow-red-950/60 transition active:scale-95"
          >
            <span>{wave + 1}-Toʻlqinni Boshlash</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
