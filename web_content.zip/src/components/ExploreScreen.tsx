import React, { useState, useEffect } from 'react';
import { Search, Flame, X, Check, Users, Sparkles } from 'lucide-react';
import { Post, UserProfile } from '../types';
import { getAllUsers, toggleFollowUser } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface ExploreScreenProps {
  posts: Post[];
  onSelectPost: (post: Post) => void;
  onSelectCreator: (username: string) => void;
}

const CATEGORIES = [
  'Para você',
  'Trends',
  'Música',
  'Games',
  'Memes',
  'Tecnologia',
  'Arte',
];

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  posts,
  onSelectPost,
  onSelectCreator,
}) => {
  const { userProfile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Para você');
  const [suggestedUsers, setSuggestedUsers] = useState<UserProfile[]>([]);
  const [followedMap, setFollowedMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    async function loadCommunity() {
      const users = await getAllUsers();
      setSuggestedUsers(users.filter((u) => u.id !== userProfile?.id && u.username !== userProfile?.username));
    }
    loadCommunity();
  }, [userProfile?.id, userProfile?.username]);

  const handleFollowToggle = async (targetUser: UserProfile) => {
    if (!userProfile) return;
    const isCurrentlyFollowed = followedMap[targetUser.id] || false;
    const newStatus = !isCurrentlyFollowed;

    setFollowedMap((prev) => ({ ...prev, [targetUser.id]: newStatus }));

    try {
      await toggleFollowUser(userProfile.id, userProfile, targetUser.id, isCurrentlyFollowed);
    } catch {
      // ignore
    }
  };

  const handleDismissSuggestion = (id: string) => {
    setSuggestedUsers((prev) => prev.filter((u) => u.id !== id));
  };

  // Filter posts based on search query or category
  const filteredPosts = posts.filter((p) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        p.caption.toLowerCase().includes(q) ||
        p.username.toLowerCase().includes(q) ||
        p.hashtags.some((h) => h.toLowerCase().includes(q))
      );
    }
    if (selectedCategory !== 'Para você') {
      return (
        p.category.toLowerCase() === selectedCategory.toLowerCase() ||
        p.hashtags.some((h) => h.toLowerCase() === selectedCategory.toLowerCase())
      );
    }
    return true;
  });

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen bg-[#050505] text-white px-5 pt-4 pb-24 md:pb-12 animate-fade-in">
      {/* Header matching reference image Screen 5: Explorar */}
      <div className="mb-3">
        <h1 className="text-xl font-extrabold text-white">Explorar</h1>
      </div>

      {/* Dark Search Input matching reference image: "Buscar" */}
      <div className="relative mb-4">
        <Search
          size={18}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A1A1AA]"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar criadores, vídeos ou #tags"
          className="w-full bg-[#101014] border border-[#19191F] rounded-2xl pl-11 pr-4 py-3 text-xs md:text-sm text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#FF008C] transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A1A1AA] hover:text-white"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Categories Horizontal Carousel */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-6">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-clipshare-gradient glow-clipshare-sm text-white'
                : 'bg-[#101014] text-[#A1A1AA] hover:text-white border border-[#19191F]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Section: Tendências 🔥 with "Ver tudo" */}
      {!searchQuery && posts.length > 0 && (
        <div className="mb-7">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>Tendências</span>
              <span>🔥</span>
            </h2>
            <button className="text-xs font-semibold text-[#FF008C] hover:underline cursor-pointer">
              Ver tudo
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {posts.slice(0, 3).map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectPost(item)}
                className="relative aspect-[3/4] rounded-2xl overflow-hidden group cursor-pointer border border-[#19191F]"
              >
                <img
                  src={item.coverUrl || item.mediaUrl}
                  alt={item.caption}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                <div className="absolute bottom-2.5 left-2.5 right-2.5 text-left">
                  <span className="text-xs font-black text-white block truncate">
                    #{item.hashtags?.[0] || 'clipshare'}
                  </span>
                  <span className="text-[10px] text-[#A1A1AA] block truncate">
                    {item.viewsCount || 1} views
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section: Sugestões para você matching reference image */}
      {!searchQuery && suggestedUsers.length > 0 && (
        <div className="mb-6">
          <h2 className="text-sm font-bold text-white mb-3 text-left">
            Sugestões para você
          </h2>

          <div className="space-y-2.5">
            {suggestedUsers.map((user) => {
              const isFollowed = followedMap[user.id] || false;
              return (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-[#101014] border border-[#19191F] transition-colors"
                >
                  <div
                    onClick={() => onSelectCreator(user.username)}
                    className="flex items-center gap-3 cursor-pointer overflow-hidden"
                  >
                    <div className="w-11 h-11 rounded-full p-[1.5px] bg-clipshare-gradient shrink-0">
                      <img
                        src={user.photoURL}
                        alt={user.displayName}
                        className="w-full h-full rounded-full object-cover"
                      />
                    </div>
                    <div className="text-left truncate">
                      <span className="text-xs font-bold text-white block truncate">
                        @{user.username}
                      </span>
                      <span className="text-[11px] text-[#A1A1AA] block truncate">
                        {user.displayName}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleFollowToggle(user)}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                        isFollowed
                          ? 'bg-[#19191F] text-white border border-[#272730]'
                          : 'bg-clipshare-gradient text-white glow-clipshare-sm hover:opacity-95'
                      }`}
                    >
                      {isFollowed ? 'Seguindo' : 'Seguir'}
                    </button>
                    <button
                      onClick={() => handleDismissSuggestion(user.id)}
                      className="p-1 text-[#A1A1AA] hover:text-white"
                      title="Dispensar sugestão"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filtered Posts Grid */}
      <div>
        <h2 className="text-sm font-bold text-white mb-3 text-left">
          {searchQuery ? `Resultados para "${searchQuery}"` : 'Em alta no ClipShare'}
        </h2>

        {filteredPosts.length === 0 ? (
          <div className="py-12 text-center text-xs text-[#A1A1AA]">
            Nenhum clipe encontrado. Tente outra busca!
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {filteredPosts.map((post) => (
              <div
                key={post.id}
                onClick={() => onSelectPost(post)}
                className="relative aspect-[3/4] bg-[#101014] rounded-2xl overflow-hidden group cursor-pointer border border-[#19191F]"
              >
                <img
                  src={post.coverUrl || post.mediaUrl}
                  alt={post.caption}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-2.5 left-2.5 right-2.5 text-left">
                  <p className="text-xs font-bold text-white line-clamp-1">
                    {post.caption}
                  </p>
                  <span className="text-[10px] text-[#A1A1AA]">@{post.username}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
