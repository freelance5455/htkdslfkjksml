import { useCallback, useEffect, useRef, useState } from "react";
import { ClipboardPaste, Copy, History, RotateCcw, Settings, X } from "lucide-react";
import { playTone, audioSupported } from "@/lib/calc/audio";
import {
  createState,
  reduce,
  view,
  type Action,
  type AngleMode,
  type CalcState,
} from "@/lib/calc/engine";
import { formatResult, type Places } from "@/lib/calc/format";

type ThemeId = "midnight" | "cyan" | "pink" | "minimal" | "light";
type Mode = "std" | "sci" | "pct";
type Panel = "history" | "settings" | null;
type Tone = "num" | "op" | "fn" | "eq" | "danger" | "ghost";

type Prefs = {
  theme: ThemeId;
  sound: boolean;
  haptic: boolean;
  group: boolean;
  places: Places;
};

type HistoryItem = { id: string; expr: string; result: string; value: number };

type KeyDef = {
  id: string;
  label: string;
  aria?: string;
  tone: Tone;
  action: Action;
  wide?: boolean;
};

const PREFS_KEY = "neon-calc-prefs-v1";
const HISTORY_KEY = "neon-calc-history-v1";

const DEFAULT_PREFS: Prefs = {
  theme: "midnight",
  sound: true,
  haptic: false,
  group: true,
  places: "auto",
};

const THEMES: { id: ThemeId; name: string }[] = [
  { id: "midnight", name: "Midnight Purple" },
  { id: "cyan", name: "Neon Cyan" },
  { id: "pink", name: "Pink Eclipse" },
  { id: "minimal", name: "Minimal Dark" },
  { id: "light", name: "Clean Light" },
];

const PLACES: { id: Places; label: string }[] = [
  { id: "auto", label: "Auto" },
  { id: 0, label: "0" },
  { id: 2, label: "2" },
  { id: 4, label: "4" },
  { id: 6, label: "6" },
];

const STD_KEYS: KeyDef[] = [
  { id: "ac", label: "AC", aria: "All clear", tone: "danger", action: { type: "ac" } },
  { id: "c", label: "C", aria: "Clear entry", tone: "ghost", action: { type: "c" } },
  { id: "bs", label: "⌫", aria: "Backspace", tone: "ghost", action: { type: "bs" } },
  { id: "pct", label: "%", aria: "Percent", tone: "op", action: { type: "percent" } },
  { id: "7", label: "7", tone: "num", action: { type: "digit", d: "7" } },
  { id: "8", label: "8", tone: "num", action: { type: "digit", d: "8" } },
  { id: "9", label: "9", tone: "num", action: { type: "digit", d: "9" } },
  { id: "div", label: "÷", aria: "Divide", tone: "op", action: { type: "op", op: "/" } },
  { id: "4", label: "4", tone: "num", action: { type: "digit", d: "4" } },
  { id: "5", label: "5", tone: "num", action: { type: "digit", d: "5" } },
  { id: "6", label: "6", tone: "num", action: { type: "digit", d: "6" } },
  { id: "mul", label: "×", aria: "Multiply", tone: "op", action: { type: "op", op: "*" } },
  { id: "1", label: "1", tone: "num", action: { type: "digit", d: "1" } },
  { id: "2", label: "2", tone: "num", action: { type: "digit", d: "2" } },
  { id: "3", label: "3", tone: "num", action: { type: "digit", d: "3" } },
  { id: "sub", label: "−", aria: "Subtract", tone: "op", action: { type: "op", op: "-" } },
  { id: "sign", label: "+/−", aria: "Change sign", tone: "ghost", action: { type: "sign" } },
  { id: "0", label: "0", tone: "num", action: { type: "digit", d: "0" } },
  { id: "dot", label: ".", aria: "Decimal point", tone: "num", action: { type: "dot" } },
  { id: "add", label: "+", aria: "Add", tone: "op", action: { type: "op", op: "+" } },
  { id: "eq", label: "=", aria: "Equals", tone: "eq", action: { type: "eq" }, wide: true },
];

const SCI_KEYS: KeyDef[] = [
  { id: "sin", label: "sin", tone: "fn", action: { type: "fn", fn: "sin" } },
  { id: "cos", label: "cos", tone: "fn", action: { type: "fn", fn: "cos" } },
  { id: "tan", label: "tan", tone: "fn", action: { type: "fn", fn: "tan" } },
  { id: "asin", label: "sin⁻¹", aria: "Inverse sine", tone: "fn", action: { type: "fn", fn: "asin" } },
  { id: "acos", label: "cos⁻¹", aria: "Inverse cosine", tone: "fn", action: { type: "fn", fn: "acos" } },
  { id: "atan", label: "tan⁻¹", aria: "Inverse tangent", tone: "fn", action: { type: "fn", fn: "atan" } },
  { id: "ln", label: "ln", aria: "Natural log", tone: "fn", action: { type: "fn", fn: "ln" } },
  { id: "log", label: "log", aria: "Log base 10", tone: "fn", action: { type: "fn", fn: "log" } },
  { id: "sqrt", label: "√", aria: "Square root", tone: "fn", action: { type: "fn", fn: "sqrt" } },
  { id: "cbrt", label: "∛", aria: "Cube root", tone: "fn", action: { type: "fn", fn: "cbrt" } },
  { id: "sq", label: "x²", aria: "Square", tone: "fn", action: { type: "fn", fn: "square" } },
  { id: "cube", label: "x³", aria: "Cube", tone: "fn", action: { type: "fn", fn: "cube" } },
  { id: "pow", label: "xʸ", aria: "Power", tone: "fn", action: { type: "op", op: "^" } },
  { id: "recip", label: "1/x", aria: "Reciprocal", tone: "fn", action: { type: "fn", fn: "recip" } },
  { id: "fact", label: "n!", aria: "Factorial", tone: "fn", action: { type: "fn", fn: "fact" } },
  { id: "exp", label: "eˣ", aria: "Exponential", tone: "fn", action: { type: "fn", fn: "exp" } },
  { id: "lp", label: "(", aria: "Open parenthesis", tone: "fn", action: { type: "lp" } },
  { id: "rp", label: ")", aria: "Close parenthesis", tone: "fn", action: { type: "rp" } },
  { id: "pi", label: "π", aria: "Pi", tone: "fn", action: { type: "const", name: "pi" } },
  { id: "e", label: "e", aria: "Euler number", tone: "fn", action: { type: "const", name: "e" } },
];

function worthHistory(expr: string): boolean {
  return /[+\×÷^%√∛!()]|sin\(|cos\(|tan\(|asin\(|acos\(|atan\(|log\(|ln\(|e\^| − /.test(expr);
}

function mainClass(text: string, isError: boolean): string {
  if (isError) return "is-error";
  const len = text.replace(/,/g, "").length;
  if (len > 18) return "is-xs";
  if (len > 14) return "is-sm";
  if (len > 10) return "is-md";
  return "is-lg";
}

function parseLoose(text: string): number | null {
  const cleaned = text.trim().replace(/,/g, "").replace(/\s+/g, "");
  if (!/^-?\d+(\.\d+)?$/.test(cleaned)) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

function readField(text: string): number | null {
  return parseLoose(text);
}

function isTheme(value: unknown): value is ThemeId {
  return value === "midnight" || value === "cyan" || value === "pink" || value === "minimal" || value === "light";
}

function isPlaces(value: unknown): value is Places {
  return value === "auto" || value === 0 || value === 2 || value === 4 || value === 6;
}

export function NeonCalc() {
  const [state, setState] = useState<CalcState>(() => createState());
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [mode, setMode] = useState<Mode>("std");
  const [panel, setPanel] = useState<Panel>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [canAudio, setCanAudio] = useState(true);
  const [canVibrate, setCanVibrate] = useState(true);
  const stateRef = useRef(state);
  const prefsRef = useRef(prefs);
  const modeRef = useRef(mode);
  const panelRef = useRef(panel);
  const idRef = useRef(0);
  stateRef.current = state;
  prefsRef.current = prefs;
  modeRef.current = mode;
  panelRef.current = panel;

  const formatOpts = { group: prefs.group, places: prefs.places };
  const display = view(state, formatOpts);

  const flash = useCallback((message: string) => {
    setToast(message);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 1600);
    return () => window.clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    setCanAudio(audioSupported());
    setCanVibrate(typeof navigator.vibrate === "function");
    try {
      const savedPrefs = localStorage.getItem(PREFS_KEY);
      if (savedPrefs) {
        const parsed = JSON.parse(savedPrefs) as Partial<Prefs> & { angle?: AngleMode; memory?: number };
        setPrefs({
          theme: isTheme(parsed.theme) ? parsed.theme : DEFAULT_PREFS.theme,
          sound: typeof parsed.sound === "boolean" ? parsed.sound : DEFAULT_PREFS.sound,
          haptic: typeof parsed.haptic === "boolean" ? parsed.haptic : DEFAULT_PREFS.haptic,
          group: typeof parsed.group === "boolean" ? parsed.group : DEFAULT_PREFS.group,
          places: isPlaces(parsed.places) ? parsed.places : DEFAULT_PREFS.places,
        });
        setState((current) => ({
          ...current,
          angle: parsed.angle === "rad" ? "rad" : "deg",
          memory: typeof parsed.memory === "number" && Number.isFinite(parsed.memory) ? parsed.memory : 0,
        }));
      }
      const savedHistory = localStorage.getItem(HISTORY_KEY);
      if (savedHistory) {
        const parsed = JSON.parse(savedHistory) as HistoryItem[];
        if (Array.isArray(parsed)) {
          setHistory(
            parsed
              .filter((item) => item && typeof item.expr === "string" && typeof item.result === "string" && typeof item.value === "number")
              .slice(0, 40),
          );
        }
      }
    } catch {
      /* storage blocked: keep the in-memory session */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = prefs.theme;
  }, [prefs.theme]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(
        PREFS_KEY,
        JSON.stringify({ ...prefs, angle: state.angle, memory: state.memory }),
      );
    } catch {
      /* ignore */
    }
  }, [prefs, state.angle, state.memory, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch {
      /* ignore */
    }
  }, [history, hydrated]);

  const copyText = useCallback(
    async (text: string) => {
      if (!text) {
        flash("Nothing to copy");
        return;
      }
      try {
        await navigator.clipboard.writeText(text);
        flash("Copied");
      } catch {
        flash("Couldn't copy that");
      }
    },
    [flash],
  );

  const pasteValue = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      const n = parseLoose(text);
      if (n == null) {
        flash("Couldn't paste that");
        return;
      }
      setState((prev) => reduce(prev, { type: "load", value: n }));
      flash("Pasted");
    } catch {
      flash("Paste isn't available here");
    }
  }, [flash]);

  const act = useCallback((action: Action) => {
    const prev = stateRef.current;
    const next = reduce(prev, action);
    stateRef.current = next;
    setState(next);
    if (action.type === "eq" && next.evaluated && !next.error && next.ans != null && worthHistory(next.exprSnapshot)) {
      const formatted = formatResult(next.ans, prefsRef.current);
      const item: HistoryItem = {
        id: `${Date.now()}-${idRef.current++}`,
        expr: next.exprSnapshot,
        result: formatted,
        value: next.ans,
      };
      setHistory((items) => {
        if (items[0] && items[0].expr === item.expr && items[0].result === item.result) return items;
        return [item, ...items].slice(0, 40);
      });
    }
    const currentPrefs = prefsRef.current;
    if (currentPrefs.haptic) {
      try {
        navigator.vibrate?.(10);
      } catch {
        /* unsupported */
      }
    }
    if (next.error && !prev.error) playTone("err", currentPrefs.sound);
    else if (action.type === "eq" && !next.error) playTone("eq", currentPrefs.sound);
    else playTone("tap", currentPrefs.sound);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      if (event.metaKey || event.ctrlKey || event.altKey) {
        const key = event.key.toLowerCase();
        if ((event.metaKey || event.ctrlKey) && key === "c") {
          event.preventDefault();
          const shown = view(stateRef.current, prefsRef.current);
          void copyText(shown.copyText);
        }
        if ((event.metaKey || event.ctrlKey) && key === "v") {
          event.preventDefault();
          void pasteValue();
        }
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        if (panelRef.current) {
          setPanel(null);
          return;
        }
        act({ type: "ac" });
        return;
      }
      if (panelRef.current || modeRef.current === "pct") return;
      let action: Action | null = null;
      if (/^\d$/.test(event.key)) action = { type: "digit", d: event.key };
      else if (event.key === "." || event.key === ",") action = { type: "dot" };
      else if (event.key === "+") action = { type: "op", op: "+" };
      else if (event.key === "-") action = { type: "op", op: "-" };
      else if (event.key === "*") action = { type: "op", op: "*" };
      else if (event.key === "/") action = { type: "op", op: "/" };
      else if (event.key === "^") action = { type: "op", op: "^" };
      else if (event.key === "Enter" || event.key === "=") action = { type: "eq" };
      else if (event.key === "Backspace") action = { type: "bs" };
      else if (event.key === "Delete") action = { type: "c" };
      else if (event.key === "%") action = { type: "percent" };
      else if (event.key === "(") action = { type: "lp" };
      else if (event.key === ")") action = { type: "rp" };
      else return;
      event.preventDefault();
      event.stopPropagation();
      act(action);
    };
    const onPaste = (event: ClipboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      const text = event.clipboardData?.getData("text") ?? "";
      const n = parseLoose(text);
      if (n == null) {
        flash("Couldn't paste that");
        return;
      }
      event.preventDefault();
      act({ type: "load", value: n });
      flash("Pasted");
    };
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("paste", onPaste);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      window.removeEventListener("paste", onPaste);
    };
  }, [act, copyText, flash, pasteValue]);

  const useValue = (value: number) => {
    act({ type: "load", value });
    setMode("std");
    setPanel(null);
  };

  return (
    <div className="nc-bg">
      <div className={`nc-frame ${mode === "sci" ? "is-sci" : ""} ${mode === "pct" ? "is-pct" : ""}`}>
        <header className="nc-top">
          <div>
            <p className="nc-mark">Neon Calc</p>
            <p className="nc-sub">Gen Z Edition</p>
          </div>
          <div className="nc-top-actions">
            <button type="button" className="nc-icon-btn" aria-label="History" onClick={() => setPanel("history")}>
              <History />
            </button>
            <button type="button" className="nc-icon-btn" aria-label="Settings" onClick={() => setPanel("settings")}>
              <Settings />
            </button>
          </div>
        </header>

        <div className="nc-modes" role="tablist" aria-label="Calculator mode">
          {(
            [
              ["std", "Standard"],
              ["sci", "Scientific"],
              ["pct", "Percent"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className="nc-tab"
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
            >
              {label}
            </button>
          ))}
        </div>

        <section className="nc-screen" aria-live="polite">
          <div className="nc-screen-tools">
            {display.memoryOn ? <span className="nc-pill">M</span> : null}
            {mode === "sci" ? (
              <div className="nc-angle" role="group" aria-label="Angle unit">
                {(["deg", "rad"] as const).map((unit) => (
                  <button
                    key={unit}
                    type="button"
                    aria-pressed={state.angle === unit}
                    onClick={() => act({ type: "angle", mode: unit })}
                  >
                    {unit === "deg" ? "DEG" : "RAD"}
                  </button>
                ))}
              </div>
            ) : null}
            <button type="button" className="nc-icon-btn nc-mini" aria-label="Copy result" onClick={() => void copyText(display.copyText)}>
              <Copy />
            </button>
            <button type="button" className="nc-icon-btn nc-mini" aria-label="Paste number" onClick={() => void pasteValue()}>
              <ClipboardPaste />
            </button>
          </div>
          <p className="nc-expr">{display.expression || "\u00a0"}</p>
          <p className={`nc-main ${mainClass(display.main, display.isError)}`}>{display.main}</p>
        </section>

        {mode === "pct" ? (
          <PercentBoard
            onUse={useValue}
            onCopy={(text) => void copyText(text)}
          />
        ) : (
          <div className="nc-board">
            {mode === "sci" ? <KeyGrid keys={SCI_KEYS} className="nc-sci" onPress={act} /> : null}
            <div className="nc-std">
              <div className="nc-mem">
                <button type="button" aria-label="Memory clear" onClick={() => act({ type: "mem", m: "mc" })}>MC</button>
                <button type="button" aria-label="Memory recall" onClick={() => act({ type: "mem", m: "mr" })}>MR</button>
                <button type="button" aria-label="Memory add" onClick={() => act({ type: "mem", m: "mp" })}>M+</button>
                <button type="button" aria-label="Memory subtract" onClick={() => act({ type: "mem", m: "mm" })}>M−</button>
              </div>
              <KeyGrid keys={STD_KEYS} onPress={act} />
            </div>
          </div>
        )}
      </div>

      {panel ? (
        <div className="nc-shade" onClick={() => setPanel(null)}>
          <div
            className="nc-panel"
            role="dialog"
            aria-modal="true"
            aria-label={panel === "history" ? "History" : "Settings"}
            onClick={(event) => event.stopPropagation()}
          >
            {panel === "history" ? (
              <HistoryPanel
                items={history}
                onClose={() => setPanel(null)}
                onUse={useValue}
                onCopy={(text) => void copyText(text)}
                onClear={() => {
                  setHistory([]);
                  flash("History cleared");
                }}
              />
            ) : (
              <SettingsPanel
                prefs={prefs}
                canAudio={canAudio}
                canVibrate={canVibrate}
                onClose={() => setPanel(null)}
                onChange={setPrefs}
                onReset={() => {
                  setPrefs(DEFAULT_PREFS);
                  flash("Settings reset");
                }}
              />
            )}
          </div>
        </div>
      ) : null}
      {toast ? <div className="nc-toast" role="status">{toast}</div> : null}
    </div>
  );
}

function KeyGrid({ keys, onPress, className }: { keys: KeyDef[]; onPress: (action: Action) => void; className?: string }) {
  return (
    <div className={`nc-grid ${className ?? ""}`}>
      {keys.map((key) => (
        <button
          key={key.id}
          type="button"
          className={`nc-key nc-key-${key.tone} ${key.wide ? "nc-key-wide" : ""}`}
          aria-label={key.aria ?? key.label}
          onClick={() => onPress(key.action)}
        >
          {key.label}
        </button>
      ))}
    </div>
  );
}

function HistoryPanel({
  items,
  onClose,
  onUse,
  onCopy,
  onClear,
}: {
  items: HistoryItem[];
  onClose: () => void;
  onUse: (value: number) => void;
  onCopy: (text: string) => void;
  onClear: () => void;
}) {
  return (
    <>
      <div className="nc-panel-head">
        <h2>History</h2>
        <button type="button" className="nc-icon-btn" aria-label="Close history" onClick={onClose}>
          <X />
        </button>
      </div>
      {items.length === 0 ? (
        <p className="nc-empty">No calculations yet. Finished results will show up here.</p>
      ) : (
        <div className="nc-history-list">
          {items.map((item) => (
            <div key={item.id} className="nc-history-card">
              <button type="button" className="nc-history-item" onClick={() => onUse(item.value)} aria-label={`Use result ${item.result}`}>
                <span>{item.expr}</span>
                <strong>{item.result}</strong>
              </button>
              <div className="nc-row-actions">
                <button type="button" className="nc-text-btn" onClick={() => onCopy(item.result)}>
                  Copy
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <button type="button" className="nc-text-btn" onClick={onClear} disabled={items.length === 0}>
        Clear history
      </button>
    </>
  );
}

function SettingsPanel({
  prefs,
  canAudio,
  canVibrate,
  onClose,
  onChange,
  onReset,
}: {
  prefs: Prefs;
  canAudio: boolean;
  canVibrate: boolean;
  onClose: () => void;
  onChange: (prefs: Prefs) => void;
  onReset: () => void;
}) {
  return (
    <>
      <div className="nc-panel-head">
        <h2>Settings</h2>
        <button type="button" className="nc-icon-btn" aria-label="Close settings" onClick={onClose}>
          <X />
        </button>
      </div>
      <div>
        <p className="nc-note">Theme</p>
        <div className="nc-swatches">
          {THEMES.map((theme) => (
            <button
              key={theme.id}
              type="button"
              className={`nc-swatch is-${theme.id}`}
              aria-pressed={prefs.theme === theme.id}
              onClick={() => onChange({ ...prefs, theme: theme.id })}
            >
              <span className="nc-swatch-dot" />
              {theme.name}
            </button>
          ))}
        </div>
      </div>
      <div className="nc-setting">
        <b>Button sounds</b>
        <button
          type="button"
          className={`nc-switch ${prefs.sound ? "is-on" : ""}`}
          role="switch"
          aria-checked={prefs.sound}
          aria-label="Button sounds"
          disabled={!canAudio}
          onClick={() => onChange({ ...prefs, sound: !prefs.sound })}
        >
          <span />
        </button>
      </div>
      {!canAudio ? <p className="nc-note">Sound isn't supported in this browser.</p> : null}
      <div className="nc-setting">
        <b>Haptic feedback</b>
        <button
          type="button"
          className={`nc-switch ${prefs.haptic ? "is-on" : ""}`}
          role="switch"
          aria-checked={prefs.haptic}
          aria-label="Haptic feedback"
          disabled={!canVibrate}
          onClick={() => onChange({ ...prefs, haptic: !prefs.haptic })}
        >
          <span />
        </button>
      </div>
      {!canVibrate ? <p className="nc-note">Haptics aren't supported on this device.</p> : null}
      <div>
        <p className="nc-note">Decimal places</p>
        <div className="nc-choices">
          {PLACES.map((place) => (
            <button
              key={String(place.id)}
              type="button"
              className="nc-choice"
              aria-pressed={prefs.places === place.id}
              onClick={() => onChange({ ...prefs, places: place.id })}
            >
              {place.label}
            </button>
          ))}
        </div>
      </div>
      <div className="nc-setting">
        <b>Thousands separators</b>
        <button
          type="button"
          className={`nc-switch ${prefs.group ? "is-on" : ""}`}
          role="switch"
          aria-checked={prefs.group}
          aria-label="Thousands separators"
          onClick={() => onChange({ ...prefs, group: !prefs.group })}
        >
          <span />
        </button>
      </div>
      <p className="nc-note">
        The % key, after + or −, takes that percent of the left side. After × or ÷, 15% becomes 0.15. On its own, it divides by 100.
      </p>
      <div className="nc-inline">
        <a className="nc-text-btn nc-link" href="/neon_calc.html" download="neon_calc.html">
          Save offline copy
        </a>
        <button type="button" className="nc-text-btn" onClick={onReset}>
          <RotateCcw size={16} /> Reset settings
        </button>
      </div>
      <p className="nc-note">The offline copy is one HTML file. Save it, then open it in Chrome on a tablet with no internet.</p>
    </>
  );
}

function PercentBoard({ onUse, onCopy }: { onUse: (value: number) => void; onCopy: (text: string) => void }) {
  const [ofPct, setOfPct] = useState("15");
  const [ofBase, setOfBase] = useState("200");
  const [upBase, setUpBase] = useState("200");
  const [upPct, setUpPct] = useState("15");
  const [downBase, setDownBase] = useState("200");
  const [downPct, setDownPct] = useState("15");
  const [from, setFrom] = useState("80");
  const [to, setTo] = useState("100");
  const [diffA, setDiffA] = useState("80");
  const [diffB, setDiffB] = useState("100");

  const ofValue = pair((a, b) => (b * a) / 100, ofPct, ofBase);
  const upValue = pair((base, pct) => base * (1 + pct / 100), upBase, upPct);
  const downValue = pair((base, pct) => base * (1 - pct / 100), downBase, downPct);
  const change = changeOf(from, to);
  const diff = diffOf(diffA, diffB);

  return (
    <div className="nc-board">
      <div className="nc-cards">
        <CalcCard
          title="Percent of a number"
          text="What is X% of Y?"
          fields={[
            ["Percent", ofPct, setOfPct],
            ["Of", ofBase, setOfBase],
          ]}
          value={ofValue}
          suffix=""
          onUse={onUse}
          onCopy={onCopy}
        />
        <CalcCard
          title="Increase"
          text="Raise a number by a percent."
          fields={[
            ["Start", upBase, setUpBase],
            ["Percent", upPct, setUpPct],
          ]}
          value={upValue}
          suffix=""
          onUse={onUse}
          onCopy={onCopy}
        />
        <CalcCard
          title="Decrease"
          text="Lower a number by a percent."
          fields={[
            ["Start", downBase, setDownBase],
            ["Percent", downPct, setDownPct],
          ]}
          value={downValue}
          suffix=""
          onUse={onUse}
          onCopy={onCopy}
        />
        <CalcCard
          title="Percent change"
          text="From A to B, compared with A."
          fields={[
            ["From", from, setFrom],
            ["To", to, setTo],
          ]}
          value={change}
          suffix="%"
          onUse={onUse}
          onCopy={onCopy}
        />
        <CalcCard
          title="Percent difference"
          text="How far apart two numbers are, compared with their average."
          fields={[
            ["First", diffA, setDiffA],
            ["Second", diffB, setDiffB],
          ]}
          value={diff}
          suffix="%"
          onUse={onUse}
          onCopy={onCopy}
        />
      </div>
    </div>
  );
}

function pair(fn: (a: number, b: number) => number, a: string, b: string): number | null {
  const left = readField(a);
  const right = readField(b);
  if (left == null || right == null) return null;
  const value = fn(left, right);
  return Number.isFinite(value) ? value : null;
}

function changeOf(from: string, to: string): number | null {
  const a = readField(from);
  const b = readField(to);
  if (a == null || b == null || a === 0) return null;
  const value = ((b - a) / Math.abs(a)) * 100;
  return Number.isFinite(value) ? value : null;
}

function diffOf(aText: string, bText: string): number | null {
  const a = readField(aText);
  const b = readField(bText);
  if (a == null || b == null) return null;
  const den = (Math.abs(a) + Math.abs(b)) / 2;
  if (den === 0) return null;
  const value = (Math.abs(a - b) / den) * 100;
  return Number.isFinite(value) ? value : null;
}

function CalcCard({
  title,
  text,
  fields,
  value,
  suffix,
  onUse,
  onCopy,
}: {
  title: string;
  text: string;
  fields: [string, string, (value: string) => void][];
  value: number | null;
  suffix: string;
  onUse: (value: number) => void;
  onCopy: (text: string) => void;
}) {
  const shown = value == null ? "—" : `${formatResult(value, { group: true, places: "auto" })}${suffix}`;
  return (
    <article className="nc-card">
      <h2>{title}</h2>
      <p>{text}</p>
      <div className="nc-fields">
        {fields.map(([label, field, setField]) => (
          <label key={label} className="nc-field">
            {label}
            <input
              inputMode="decimal"
              value={field}
              aria-label={label}
              onChange={(event) => {
                const next = event.target.value;
                if (next === "" || /^-?\d*\.?\d*$/.test(next)) setField(next);
              }}
            />
          </label>
        ))}
      </div>
      <div className="nc-result-row">
        <strong className="nc-result">{shown}</strong>
        <div className="nc-inline">
          <button type="button" className="nc-text-btn" disabled={value == null} onClick={() => value != null && onCopy(shown)}>
            Copy
          </button>
          <button type="button" className="nc-text-btn" disabled={value == null} onClick={() => value != null && onUse(value)}>
            Use
          </button>
        </div>
      </div>
    </article>
  );
}
