import React, { useState, useRef } from 'react';
import { Plus, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { Story } from '../types';
import { processGalleryUpload } from '../utils/media';
import { SafeVideo } from './SafeVideo';

export const StoryTray: React.FC = () => {
  const { user } = useAuth();
  const { stories, createStory } = useSocial();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);

  const handleStoryFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const processed = await processGalleryUpload(file);
      createStory(processed.mediaUrl, processed.mediaType);
      // Reset input
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err) {
      console.error('Failed to create story from gallery:', err);
    }
  };

  const currentStory = activeStoryIndex !== null ? stories[activeStoryIndex] : null;

  return (
    <div className="relative mb-4">
      {/* Hidden Gallery Input for Stories */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleStoryFileSelected}
      />

      {/* Horizontal Story Scroll Container */}
      <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory">
        
        {/* Create Story Card */}
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="relative shrink-0 w-28 sm:w-32 h-44 sm:h-52 rounded-2xl overflow-hidden cursor-pointer bg-white border border-slate-200 shadow-xs hover:shadow-md transition-all group snap-start flex flex-col justify-between"
        >
          <div className="h-2/3 overflow-hidden bg-slate-100">
            <img
              src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
              alt="Me"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="relative h-1/3 bg-white flex flex-col items-center justify-end pb-2 pt-3 px-1">
            <div className="absolute -top-4 w-8 h-8 rounded-full bg-[#1877F2] text-white flex items-center justify-center border-4 border-white shadow-sm group-hover:scale-110 transition-transform">
              <Plus className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="font-semibold text-slate-900 text-xs text-center leading-tight">
              Create story
            </span>
          </div>
        </div>

        {/* Existing Stories */}
        {stories.map((story, idx) => (
          <div
            key={story.id}
            onClick={() => setActiveStoryIndex(idx)}
            className="relative shrink-0 w-28 sm:w-32 h-44 sm:h-52 rounded-2xl overflow-hidden cursor-pointer shadow-xs hover:shadow-md transition-all group snap-start"
          >
            {story.mediaType === 'video' ? (
              <SafeVideo
                src={story.mediaUrl}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                muted
                playsInline
              />
            ) : (
              <img
                src={story.mediaUrl}
                alt={story.authorName}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            )}
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-linear-to-b from-black/40 via-transparent to-black/75"></div>

            {/* Author Avatar with blue ring */}
            <div className="absolute top-2.5 left-2.5">
              <img
                src={story.authorPhotoURL}
                alt={story.authorName}
                className="w-9 h-9 rounded-full object-cover ring-3 ring-[#1877F2] p-0.5 bg-white shadow-md"
              />
            </div>

            {/* Author Name */}
            <div className="absolute bottom-2.5 inset-x-2.5">
              <p className="font-bold text-white text-xs drop-shadow-md truncate">
                {story.authorName}
              </p>
            </div>
          </div>
        ))}

      </div>

      {/* Fullscreen Story Viewer Modal */}
      {currentStory && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-2 sm:p-4 backdrop-blur-md animate-in fade-in duration-150">
          <div className="relative w-full max-w-sm sm:max-w-md h-[88vh] bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
            
            {/* Top progress bar and Author info */}
            <div className="absolute top-0 inset-x-0 z-20 p-4 bg-linear-to-b from-black/70 to-transparent">
              {/* Progress bar */}
              <div className="w-full h-1 bg-white/30 rounded-full overflow-hidden mb-3">
                <div className="h-full bg-white animate-[pulse_3s_ease-in-out_infinite] w-full"></div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={currentStory.authorPhotoURL}
                    alt={currentStory.authorName}
                    className="w-9 h-9 rounded-full object-cover ring-2 ring-white"
                  />
                  <div>
                    <p className="font-bold text-white text-sm leading-tight">{currentStory.authorName}</p>
                    <p className="text-[10px] text-white/70">Story</p>
                  </div>
                </div>

                <button
                  onClick={() => setActiveStoryIndex(null)}
                  className="w-8 h-8 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Main Media */}
            <div className="w-full h-full flex items-center justify-center bg-black">
              {currentStory.mediaType === 'video' ? (
                <SafeVideo
                  src={currentStory.mediaUrl}
                  className="w-full h-full object-contain"
                  autoPlay
                  playsInline
                  loop
                />
              ) : (
                <img
                  src={currentStory.mediaUrl}
                  alt={currentStory.authorName}
                  className="w-full h-full object-contain"
                />
              )}
            </div>

            {/* Navigation Arrows */}
            {activeStoryIndex! > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveStoryIndex(activeStoryIndex! - 1);
                }}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/70 cursor-pointer"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}

            {activeStoryIndex! < stories.length - 1 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveStoryIndex(activeStoryIndex! + 1);
                }}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/70 cursor-pointer"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
