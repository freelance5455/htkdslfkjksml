import React, { useState, useEffect } from "react";
import {
  StickyNote,
  CheckSquare,
  Network,
  User,
  Plus,
  Table,
  FileText,
  Sparkles,
  Shield,
  Layers,
  Search,
  BookOpen,
  Mic,
  Sliders,
  PenTool,
} from "lucide-react";
import { ActiveTab, ThemeAccent, UserProfile, NavBarConfig } from "../types";
import { THEME_ACCENTS } from "../utils/theme";
import { useGlobalState } from "../context/GlobalContext";
import {
  getStoredPlusButtonConfig,
  PlusButtonConfig,
} from "../utils/storage";

interface DynamicNavigationBarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenCreateMenu: () => void;
  onOpenAIChat: () => void;
  onOpenSideGallery: () => void;
  onOpenCommandPalette: () => void;
  onOpenVault?: () => void;
  totalNotesCount?: number;
  vaultNotesCount?: number;
  isVaultUnlocked?: boolean;
  themeAccent?: ThemeAccent;
  profile?: UserProfile;
  menuOrder?: ActiveTab[];
  plusButtonConfig?: PlusButtonConfig;
  onQuickNoteCreate?: () => void;
}

export const DynamicNavigationBar: React.FC<DynamicNavigationBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenCreateMenu,
  onOpenAIChat,
  onOpenSideGallery,
  onOpenCommandPalette,
  onOpenVault,
  totalNotesCount = 0,
  vaultNotesCount = 0,
  isVaultUnlocked = false,
  themeAccent = "teal",
  profile,
  menuOrder: propMenuOrder,
  plusButtonConfig,
  onQuickNoteCreate,
}) => {
  const { state } = useGlobalState();
  const navConfig = state.navBarConfig;
  const scaleMultiplier = state.scaleConfig.uiScale;
  const menuOrder = propMenuOrder || state.menuOrder;

  const themeDef = THEME_ACCENTS[themeAccent || state.themeAccent] || THEME_ACCENTS.teal;
  const isAiActive = profile?.isLoggedIn && profile?.aiModeEnabled;

  const [effectivePlusConfig, setEffectivePlusConfig] = useState<PlusButtonConfig>(
    plusButtonConfig || getStoredPlusButtonConfig()
  );

  useEffect(() => {
    if (plusButtonConfig) {
      setEffectivePlusConfig(plusButtonConfig);
    } else {
      setEffectivePlusConfig(getStoredPlusButtonConfig());
    }
  }, [plusButtonConfig, menuOrder]);

  const handlePlusClick = () => {
    switch (effectivePlusConfig.action) {
      case "quick_note":
        if (onQuickNoteCreate) {
          onQuickNoteCreate();
        } else {
          onOpenCreateMenu();
        }
        break;
      case "mindmap":
        setActiveTab("mindmap");
        break;
      case "vault":
        setActiveTab("vault");
        if (onOpenVault) onOpenVault();
        break;
      case "create_menu":
      default:
        onOpenCreateMenu();
        break;
    }
  };

  // Base calculated sizes
  const rawHeight = navConfig.height || 64;
  const scaledHeight = Math.round(rawHeight * scaleMultiplier);
  const iconScale = (navConfig.iconLabelScale || 1.0) * scaleMultiplier;
  const baseIconSize = Math.round(18 * iconScale);

  const isVertical = navConfig.position === "sidebar_left" || navConfig.position === "sidebar_right";

  // Compute container position classes and inline styles
  const getContainerStyles = (): { className: string; style: React.CSSProperties } => {
    const opacityVal = (navConfig.opacity ?? 95) / 100;
    const blurVal = navConfig.blur ?? 16;
    const radiusVal = navConfig.borderRadius ?? 24;

    const baseStyle: React.CSSProperties = {
      backgroundColor: state.darkMode
        ? `rgba(15, 23, 42, ${opacityVal})`
        : `rgba(255, 255, 255, ${opacityVal})`,
      backdropFilter: navConfig.glassmorphism ? `blur(${blurVal}px)` : undefined,
      WebkitBackdropFilter: navConfig.glassmorphism ? `blur(${blurVal}px)` : undefined,
      borderRadius: isVertical ? `${Math.min(radiusVal, 24)}px` : `${radiusVal}px`,
      borderColor: state.darkMode ? "rgba(51, 65, 85, 0.7)" : "rgba(226, 232, 240, 0.9)",
    };

    switch (navConfig.position) {
      case "bottom_fixed":
        return {
          className: "fixed bottom-0 left-0 right-0 z-40 flex items-center justify-center p-2 border-t shadow-2xl transition-all duration-300",
          style: {
            ...baseStyle,
            height: `${scaledHeight}px`,
            borderRadius: "0px",
            paddingBottom: "max(8px, env(safe-area-inset-bottom, 8px))",
          },
        };

      case "floating_dock":
        return {
          className: "fixed bottom-3 sm:bottom-4 left-1/2 -translate-x-1/2 z-40 flex items-center justify-center border shadow-2xl transition-all duration-300",
          style: {
            ...baseStyle,
            height: `${scaledHeight}px`,
            width: `${navConfig.widthPercent || 94}%`,
            maxWidth: "760px",
          },
        };

      case "top_bar":
        return {
          className: "fixed top-0 left-0 right-0 z-40 flex items-center justify-center p-2 border-b shadow-md transition-all duration-300",
          style: {
            ...baseStyle,
            height: `${scaledHeight}px`,
            borderRadius: "0px",
            paddingTop: "max(6px, env(safe-area-inset-top, 6px))",
          },
        };

      case "sidebar_left":
        return {
          className: "fixed left-2 top-2 bottom-2 z-40 flex flex-col items-center justify-between py-4 px-2 border shadow-2xl transition-all duration-300",
          style: {
            ...baseStyle,
            width: `${Math.max(68, scaledHeight)}px`,
            maxWidth: "88px",
          },
        };

      case "sidebar_right":
        return {
          className: "fixed right-2 top-2 bottom-2 z-40 flex flex-col items-center justify-between py-4 px-2 border shadow-2xl transition-all duration-300",
          style: {
            ...baseStyle,
            width: `${Math.max(68, scaledHeight)}px`,
            maxWidth: "88px",
          },
        };

      default:
        return {
          className: "fixed bottom-3 left-1/2 -translate-x-1/2 z-40 flex items-center justify-center border shadow-xl",
          style: baseStyle,
        };
    }
  };

  const containerInfo = getContainerStyles();

  // Navigation Items Map
  const NAV_ITEMS: Record<
    ActiveTab,
    {
      label: string;
      icon: (isActive: boolean) => React.ReactNode;
      onClick: () => void;
      badge?: React.ReactNode;
    }
  > = {
    home: {
      label: "Notlar",
      icon: (isActive) => (
        <StickyNote
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("home"),
      badge: navConfig.showBadges && totalNotesCount > 0 ? (
        <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-300">
          {totalNotesCount}
        </span>
      ) : null,
    },
    docs: {
      label: "Belgeler",
      icon: (isActive) => (
        <FileText
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("docs"),
    },
    mindmap: {
      label: "Zihin",
      icon: (isActive) => (
        <Network
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("mindmap"),
    },
    plus_action: {
      label: "Ekle",
      icon: () => (
        <div
          onClick={(e) => {
            e.stopPropagation();
            handlePlusClick();
          }}
          className="rounded-full bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white flex items-center justify-center shadow-lg shadow-teal-600/30 transition-all cursor-pointer active:scale-90 hover:scale-105"
          style={{
            width: `${Math.round(baseIconSize * 1.7)}px`,
            height: `${Math.round(baseIconSize * 1.7)}px`,
          }}
          title="Hızlı Ekleme Menüsü"
        >
          <Plus style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }} className="stroke-[3]" />
        </div>
      ),
      onClick: handlePlusClick,
    },
    vault: {
      label: "Kasa",
      icon: (isActive) => (
        <Shield
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => {
        setActiveTab("vault");
        if (onOpenVault) onOpenVault();
      },
      badge: navConfig.showBadges && isVaultUnlocked ? (
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
      ) : null,
    },
    study: {
      label: "Çalışma",
      icon: (isActive) => (
        <BookOpen
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("study"),
    },
    profile: {
      label: "Profil",
      icon: (isActive) => (
        <User
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("profile"),
      badge: navConfig.showBadges && isAiActive ? (
        <Sparkles className="w-2.5 h-2.5 text-amber-400 fill-amber-400" />
      ) : null,
    },
    tips: {
      label: "İpuçları",
      icon: (isActive) => (
        <Sparkles
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("tips"),
    },
    settings: {
      label: "Ayarlar",
      icon: (isActive) => (
        <Sliders
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className={`transition-transform duration-200 ${
            isActive && navConfig.activeIndicatorStyle === "scale_icon" ? "scale-125 stroke-[2.5]" : ""
          }`}
        />
      ),
      onClick: () => setActiveTab("settings"),
    },
    ai_chat: {
      label: "AI Chat",
      icon: () => (
        <Sparkles
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className="text-teal-400"
        />
      ),
      onClick: onOpenAIChat,
    },
    quick_search: {
      label: "Arama",
      icon: () => (
        <Search
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className="text-blue-400"
        />
      ),
      onClick: onOpenCommandPalette,
    },
    voice_memo: {
      label: "Sesli",
      icon: () => (
        <Mic
          style={{ width: `${baseIconSize}px`, height: `${baseIconSize}px` }}
          className="text-rose-400"
        />
      ),
      onClick: () => {
        if (onQuickNoteCreate) onQuickNoteCreate();
      },
    },
  };

  return (
    <nav className={containerInfo.className} style={containerInfo.style}>
      <div
        className={`w-full h-full flex items-center justify-around px-2 ${
          isVertical ? "flex-col justify-between py-2 gap-2" : "flex-row gap-1 sm:gap-2"
        }`}
      >
        {menuOrder.filter((key) => key !== "mindmap").map((tabKey) => {
          const item = NAV_ITEMS[tabKey];
          if (!item) return null;

          const isActive = activeTab === tabKey;
          const isPlus = tabKey === "plus_action";

          if (isPlus) {
            return (
              <div key={tabKey} className="shrink-0 flex items-center justify-center">
                {item.icon(false)}
              </div>
            );
          }

          // Calculate label display mode
          const shouldShowLabel =
            navConfig.labelMode === "always" ||
            (navConfig.labelMode === "active_only" && isActive);

          // Active indicator styles
          let activeClasses = "";
          let activeInlineStyle: React.CSSProperties = {};

          if (isActive) {
            switch (navConfig.activeIndicatorStyle) {
              case "pill":
                activeClasses = "bg-teal-500/15 text-teal-600 dark:text-teal-300 font-black shadow-2xs";
                break;
              case "underline":
                activeClasses = "text-teal-600 dark:text-teal-300 font-black border-b-2 border-teal-500 rounded-none pb-0.5";
                break;
              case "glow":
                activeClasses = "text-teal-600 dark:text-teal-300 font-black ring-2 ring-teal-400/50 shadow-md shadow-teal-500/20";
                break;
              case "scale_icon":
                activeClasses = "text-teal-600 dark:text-teal-300 font-black";
                break;
            }
          } else {
            activeClasses = "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100/50 dark:hover:bg-slate-800/40";
          }

          return (
            <button
              key={tabKey}
              type="button"
              onClick={item.onClick}
              className={`relative flex flex-col items-center justify-center px-2 py-1.5 rounded-2xl transition-all duration-200 cursor-pointer select-none group min-w-[42px] ${activeClasses}`}
              style={{
                fontSize: `${Math.round(10 * iconScale)}px`,
                ...activeInlineStyle,
              }}
              title={item.label}
            >
              {/* Icon Container */}
              <div className="relative flex items-center justify-center">
                {item.icon(isActive)}

                {/* Badge if available */}
                {item.badge && (
                  <div className="absolute -top-1 -right-2 shrink-0">
                    {item.badge}
                  </div>
                )}
              </div>

              {/* Text Label */}
              {shouldShowLabel && (
                <span className="truncate mt-0.5 font-bold tracking-tight max-w-[60px] text-center leading-none">
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
