import React from 'react';
import { CircleDot, Award, ChevronDown, ChevronUp } from 'lucide-react';
import { MatchSettings, Player } from '../types';
import { calculateRemainingPoints, calculateSnookersNeeded, toPersianDigits } from '../utils/snooker';

interface TableOverviewProps {
  settings: MatchSettings;
  players: Player[];
  activePlayer: Player | undefined;
  onUpdateReds: (delta: number) => void;
}

export const TableOverview: React.FC<TableOverviewProps> = ({
  settings,
  players,
  activePlayer,
  onUpdateReds,
}) => {
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const leader = sortedPlayers[0];
  const trailer = sortedPlayers[1];

  const scoreDiff = leader && trailer ? leader.score - trailer.score : 0;
  const remainingPoints = calculateRemainingPoints(settings.remainingReds, settings.redValue);
  const snookersNeeded = trailer
    ? calculateSnookersNeeded(leader?.score || 0, trailer.score, remainingPoints)
    : 0;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900/90 to-slate-950/95 border border-emerald-800/40 p-3 sm:p-4 text-xs shadow-lg mb-3">
      {/* Felt cloth subtle texture accent */}
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />

      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3">
        {/* Frame Info & Remaining Reds */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-emerald-900/60 border border-emerald-600/40 px-2.5 py-1 rounded-xl">
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold text-emerald-200">
              فریم {toPersianDigits(settings.currentFrame)} از {toPersianDigits(settings.bestOfFrames)}
            </span>
          </div>

          {/* Remaining Reds Counter with quick adjust */}
          <div className="flex items-center gap-1 bg-slate-900/80 border border-slate-700/60 px-2 py-0.5 rounded-xl">
            <span className="text-slate-300 flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm shadow-red-500/50 inline-block" />
              قرمز باقی‌مانده:
              <strong className="text-white font-black text-sm ml-1">
                {toPersianDigits(settings.remainingReds)}
              </strong>
            </span>
            <div className="flex flex-col ml-1">
              <button
                type="button"
                onClick={() => onUpdateReds(1)}
                disabled={settings.remainingReds >= settings.totalReds}
                aria-label="افزایش توپ قرمز"
                className="text-slate-400 hover:text-white disabled:opacity-30 leading-none p-0.5"
              >
                <ChevronUp className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() => onUpdateReds(-1)}
                disabled={settings.remainingReds <= 0}
                aria-label="کاهش توپ قرمز"
                className="text-slate-400 hover:text-white disabled:opacity-30 leading-none p-0.5"
              >
                <ChevronDown className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Remaining points on table & Score gap */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-slate-300">
            <CircleDot className="w-3.5 h-3.5 text-teal-400" />
            <span>امتیاز روی میز:</span>
            <span className="font-black text-teal-300 text-sm">
              {toPersianDigits(remainingPoints)}
            </span>
          </div>

          {leader && trailer && leader.score !== trailer.score && (
            <div className="flex items-center gap-1 text-slate-300 border-r border-slate-700/60 pr-3">
              <span>اختلاف:</span>
              <span className="font-black text-amber-400 text-sm">
                {toPersianDigits(scoreDiff)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Snooker notice if active */}
      {snookersNeeded > 0 && trailer && (
        <div className="mt-2.5 pt-2 border-t border-emerald-800/30 flex items-center justify-between text-[11px] text-amber-300 bg-amber-950/30 px-2.5 py-1 rounded-lg">
          <span>
            ⚠️ اختلاف بیشتر از امتیاز روی میز است! {trailer.name} نیاز به{' '}
            <strong className="text-amber-200">{toPersianDigits(snookersNeeded)} خطا / اسنوکر</strong>{' '}
            دارد.
          </span>
        </div>
      )}
    </div>
  );
};
