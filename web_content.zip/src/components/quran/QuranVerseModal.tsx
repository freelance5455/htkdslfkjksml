import React, { useState } from 'react';
import { QuranVerse } from '../../types';
import { QURAN_VERSES, getDailyVerse } from '../../data/quranVerses';
import { BookOpen, Sparkles, X, RefreshCw, Copy, Check, Heart, Share2 } from 'lucide-react';
import { playNotificationChime } from '../../utils/notifications';

interface QuranVerseModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialVerse?: QuranVerse;
}

export const QuranVerseModal: React.FC<QuranVerseModalProps> = ({
  isOpen,
  onClose,
  initialVerse,
}) => {
  const [verse, setVerse] = useState<QuranVerse>(() => initialVerse || getDailyVerse());
  const [copied, setCopied] = useState(false);
  const [savedFavorite, setSavedFavorite] = useState(false);

  if (!isOpen) return null;

  const handleNextVerse = () => {
    const currentIndex = QURAN_VERSES.findIndex((v) => v.id === verse.id);
    const nextIndex = (currentIndex + 1) % QURAN_VERSES.length;
    setVerse(QURAN_VERSES[nextIndex]);
    setCopied(false);
    playNotificationChime('click');
  };

  const handleCopy = () => {
    const textToCopy = `﴿ ${verse.arabicText} ﴾ [${verse.surahName}: آية ${verse.ayahNumber}]\nالتفسير: ${verse.tafseer}`;
    navigator.clipboard?.writeText(textToCopy);
    setCopied(true);
    playNotificationChime('success');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white dark:bg-[#180d15] rounded-3xl border border-rose-200/80 dark:border-rose-900/60 shadow-2xl overflow-hidden transition-all text-right">
        {/* Top Decorative Floral Header */}
        <div className="relative p-6 pb-5 bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white overflow-hidden">
          {/* Subtle rose backdrop */}
          <div
            className="absolute inset-0 opacity-15 bg-cover bg-center pointer-events-none mix-blend-overlay"
            style={{ backgroundImage: `url('/public/assets/aistudio/images_5d51feea.jpg')` }}
          />

          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-xs">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-rose-100 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-pink-200" />
                  نفحات قرآنية مباركة
                </span>
                <h3 className="text-lg font-bold">آية اليوم وتفسيرها الميسر</h3>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition-colors"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {/* Surah & Ayah Badge */}
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950/60 border border-rose-200/60 dark:border-rose-900/40 text-xs font-bold text-rose-800 dark:text-rose-200">
              <span>{verse.surahName}</span>
              <span>·</span>
              <span>الآية {verse.ayahNumber}</span>
            </div>

            <span className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-pink-50 dark:bg-pink-950/40 px-2.5 py-0.5 rounded-md">
              {verse.theme}
            </span>
          </div>

          {/* Ayah Calligraphy Box */}
          <div className="relative p-6 rounded-2xl bg-gradient-to-b from-rose-50/40 via-white to-pink-50/30 dark:from-rose-950/20 dark:via-[#1a0f18] dark:to-rose-950/30 border border-rose-200/60 dark:border-rose-900/50 shadow-inner">
            <div className="text-center font-serif text-xl sm:text-2xl font-bold leading-loose text-slate-900 dark:text-rose-50 px-2">
              ﴿ {verse.arabicText} ﴾
            </div>
          </div>

          {/* Tafseer Section */}
          <div className="p-4 rounded-2xl bg-rose-50/30 dark:bg-[#1f0f1c]/50 border border-rose-100 dark:border-rose-950/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
              <Sparkles className="w-3.5 h-3.5 text-rose-500" />
              <span>التفسير الميسر ودلالة الآية:</span>
            </div>
            <p className="text-sm leading-relaxed text-slate-700 dark:text-rose-100/90 font-normal">
              {verse.tafseer}
            </p>
          </div>

          {/* Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-rose-100 dark:border-rose-950/60">
            <div className="flex items-center gap-2">
              <button
                onClick={handleNextVerse}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-slate-700 dark:text-rose-200 flex items-center gap-1.5 transition-colors"
                title="عرض آية أخرى"
              >
                <RefreshCw className="w-3.5 h-3.5 text-rose-600" />
                <span>آية أخرى</span>
              </button>

              <button
                onClick={handleCopy}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-slate-700 dark:text-rose-200 flex items-center gap-1.5 transition-colors"
                title="نسخ الآية وتفسيرها"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-bold">تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-rose-600" />
                    <span>نسخ الآية</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setSavedFavorite(!savedFavorite)}
                className={`p-2 rounded-xl border transition-colors ${
                  savedFavorite
                    ? 'border-rose-500 bg-rose-50 dark:bg-rose-950 text-rose-600'
                    : 'border-rose-200 dark:border-rose-900/60 text-slate-400 hover:text-rose-600'
                }`}
                title="حفظ في المفضلة"
              >
                <Heart className={`w-3.5 h-3.5 ${savedFavorite ? 'fill-rose-500' : ''}`} />
              </button>
            </div>

            <button
              onClick={onClose}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition-colors"
            >
              متابعة إلى يومي المنظم
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
