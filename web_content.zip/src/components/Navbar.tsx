import React, { useState, useEffect } from 'react';
import { TabType } from '../types';
import { Radio, Music2, BookOpen, Sparkles, HeartHandshake, ShieldCheck, Flame, Sun, User, Search, Download, Upload, Globe, MessageSquare, UserPlus, RefreshCw, Coins, Wallet, TrendingUp, MessageCircle, HardDrive } from 'lucide-react';
import { checkIsOwnerSecretUnlocked } from '../lib/ownerSecurity';
import { offlineCache } from '../lib/offlineCache';
import { membersRegistryService } from '../lib/membersRegistryService';

interface NavbarProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  onOpenProphetBio: () => void;
  onOpenPrayerModal: () => void;
  onOpenUserProfile: () => void;
  onOpenBackupProfile?: () => void;
  onOpenSearch: () => void;
  onOpenDownloadModal: () => void;
  onOpenUploadModal: () => void;
  onOpenWebPublishModal?: () => void;
  onOpenSignup?: () => void;
  onOpenLogoAuthModal?: () => void;
  isLiveNow?: boolean;
  userEmail?: string;
  isOwnerSecretUnlocked?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  onOpenProphetBio,
  onOpenPrayerModal,
  onOpenUserProfile,
  onOpenBackupProfile,
  onOpenSearch,
  onOpenDownloadModal,
  onOpenUploadModal,
  onOpenWebPublishModal,
  onOpenSignup,
  onOpenLogoAuthModal,
  isLiveNow = true,
  userEmail = 'juhnkrix.musika@gmail.com',
  isOwnerSecretUnlocked,
}) => {
  const isUnlocked = isOwnerSecretUnlocked !== undefined ? isOwnerSecretUnlocked : checkIsOwnerSecretUnlocked();
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(() => offlineCache.getCustomAppLogo());
  const [syncStatus, setSyncStatus] = useState<'SYNCED' | 'SYNCING' | 'PENDING'>('SYNCED');

  const handleForceManualSync = () => {
    setSyncStatus('SYNCING');
    setTimeout(() => {
      setSyncStatus('SYNCED');
      alert('✓ Force Manual Sync Successful! All local JMC earnings, mining data, and prayer activities have been cryptographically uploaded to cloud storage.');
    }, 1200);
  };

  useEffect(() => {
    const handleLogoUpdate = () => {
      setAppLogoUrl(offlineCache.getCustomAppLogo());
    };
    const unsubscribe = offlineCache.subscribe(handleLogoUpdate);
    window.addEventListener('juhnkrix_logo_updated', handleLogoUpdate);
    return () => {
      unsubscribe();
      window.removeEventListener('juhnkrix_logo_updated', handleLogoUpdate);
    };
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleMemberRestrictedTab = (targetTab: TabType) => {
    const isMember = membersRegistryService.isCurrentUserRegistered();
    if (isMember) {
      onTabChange(targetTab);
    } else {
      alert("You are not a registered member of JUHNKRIX MUSIKA, please click on the signups icon button below and get into the registration page to register as a member");
      if (onOpenSignup) onOpenSignup();
    }
  };

  const handleTextMessagesClick = () => {
    handleMemberRestrictedTab('textmessages');
  };

  const navItems: { id: TabType | 'textmessages_custom' | 'download_custom' | 'search_custom'; label: string; icon: React.FC<{ className?: string }>; onClick?: () => void }[] = [
    { id: 'worship', label: 'Anointed Worship', icon: Music2 },
    { id: 'jm-crypto', label: '💎 JM-CRYPTO', icon: Coins, onClick: () => handleMemberRestrictedTab('jm-crypto') },
    { id: 'jm-wallet', label: '💼 JM-WALLET', icon: Wallet, onClick: () => handleMemberRestrictedTab('jm-wallet') },
    { id: 'jm-global-trade', label: '📈 JM-GLOBAL-TRADE', icon: TrendingUp, onClick: () => handleMemberRestrictedTab('jm-global-trade') },
    { id: 'jm-chat', label: '💬 JM CHAT', icon: MessageCircle, onClick: () => onTabChange('jm-chat') },
    { id: 'profile', label: '👤 Profile', icon: User },
    {
      id: 'backup-profile',
      label: '💾 Backup Profile',
      icon: HardDrive,
      onClick: () => {
        if (onOpenBackupProfile) {
          onOpenBackupProfile();
        } else {
          onTabChange('backup-profile');
        }
      }
    },
    { id: 'textmessages_custom', label: 'Text Messages', icon: MessageSquare, onClick: handleTextMessagesClick },
    { id: 'audio', label: '🎵 Audio', icon: Music2 },
    { id: 'video', label: '🎬 Video', icon: Radio },
    { id: 'image', label: '🖼️ Image', icon: Sparkles },
    { id: 'sermons', label: 'Prophetic Sermons', icon: Radio },
    { id: 'devotionals', label: 'Daily Word', icon: BookOpen },
    { id: 'support', label: 'Support Offerings', icon: HeartHandshake },
    { id: 'soaking', label: 'Soaking Room', icon: Sparkles },
    { id: 'broadcast', label: 'Live Broadcast', icon: Flame },
    { id: 'journal', label: 'Prayer Journal', icon: HeartHandshake },
    { id: 'search_custom', label: '🔍 Search', icon: Search, onClick: onOpenSearch },
    { id: 'download_custom', label: '⬇️ Get App', icon: Download, onClick: onOpenDownloadModal },
  ];

  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl bg-slate-950/80 border-b border-amber-500/20 shadow-2xl">
      {/* Top Divine Banner */}
      <div className="bg-gradient-to-r from-amber-900/60 via-purple-900/40 to-slate-950 text-amber-200/90 text-xs py-1.5 px-4 border-b border-amber-500/10 flex items-center justify-between">
        <div className="flex items-center space-x-2 max-w-4xl truncate">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-400/30 animate-pulse">
            <Flame className="w-3 h-3 mr-1 text-amber-400" /> PROPHETIC ANOINTING
          </span>
          <span className="hidden sm:inline text-amber-100/80">
            Welcome to JUHNKRIX MUSIKA — World&apos;s Powerful Spiritual Gospel Experience
          </span>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3 text-[11px] flex-wrap justify-end">
          {/* Persistent Top Right Connection, Cloud Sync Status Indicator & Force Manual Sync Button */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-900/90 border border-amber-500/40 shadow-inner font-mono">
              <span className={`w-2.5 h-2.5 rounded-full ${syncStatus === 'SYNCING' ? 'bg-amber-400 animate-ping' : isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span className={isOnline ? 'text-emerald-300 font-bold' : 'text-amber-300 font-bold'}>
                {syncStatus === 'SYNCING' ? '☁️ Syncing to Cloud...' : isOnline ? '☁️ Cloud Sync: 100% Synced' : '☁️ Pending Offline Cache'}
              </span>
            </div>
            <button
              onClick={handleForceManualSync}
              disabled={syncStatus === 'SYNCING'}
              className="px-2.5 py-1 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-mono text-[10px] flex items-center space-x-1 shadow-md cursor-pointer transition-transform hover:scale-105"
              title="Force manual synchronization of local cache & JMC earnings to cloud"
            >
              <RefreshCw className={`w-3 h-3 ${syncStatus === 'SYNCING' ? 'animate-spin' : ''}`} />
              <span>{syncStatus === 'SYNCING' ? 'Syncing...' : 'Force Manual Sync'}</span>
            </button>
          </div>

          {isUnlocked && (
            <button
              onClick={onOpenWebPublishModal}
              className="flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500/30 to-amber-600/30 hover:from-amber-500/50 hover:to-amber-600/50 text-amber-200 border border-amber-400/40 text-[10px] font-bold transition-all shadow-sm"
              title="Publish to Domain URL & Web-Base App Hub"
            >
              <Globe className="w-3 h-3 text-amber-400 animate-spin-slow" />
              <span>Publish to Domain</span>
            </button>
          )}
          <button
            onClick={onOpenProphetBio}
            className="hover:text-amber-300 transition-colors hidden sm:flex items-center space-x-1 underline decoration-amber-500/40"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Prophet JUHNKRIX SYNVAGORD</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo & Brand (Hidden Owner Access Gate behind Logo) */}
          <div className="flex items-center space-x-3 group">
            <div 
              onClick={() => {
                if (onOpenLogoAuthModal) onOpenLogoAuthModal();
              }}
              className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 p-0.5 shadow-lg shadow-amber-500/30 cursor-pointer hover:scale-105 transition-transform"
              title="JUHNKRIX MUSIKA APP (Click logo for owner sanctuary authentication)"
            >
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/20 to-transparent opacity-60" />
                {appLogoUrl ? (
                  <img
                    src={appLogoUrl}
                    alt="JUHNKRIX MUSIKA Logo"
                    className="w-full h-full object-cover rounded-[14px] relative z-10"
                  />
                ) : (
                  <Sun className="w-6 h-6 text-amber-400 relative z-10 animate-spin-slow" />
                )}
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-100 bg-clip-text text-transparent font-serif">
                  JUHNKRIX MUSIKA
                </h1>
                
                {/* Search Engine Icon Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenSearch();
                  }}
                  className="px-2 sm:px-2.5 py-1 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-[10px] sm:text-xs font-bold flex items-center space-x-1 shadow-sm transition-all hover:scale-105 z-20"
                  title="Search JUHNKRIX MUSIKA (Songs, Messages, Sermons)"
                >
                  <Search className="w-3.5 h-3.5 text-amber-400" />
                  <span>Search</span>
                </button>
              </div>
              <div>
                <p className="text-[10px] tracking-widest text-amber-300/70 uppercase font-medium">
                  Prophetic Gospel & Soaking Sanctuary
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-900/60 p-1 rounded-2xl border border-amber-500/10 overflow-x-auto max-w-[50vw] lg:max-w-[60vw]">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <React.Fragment key={item.id}>
                  <button
                    onClick={() => {
                      if (item.onClick) {
                        item.onClick();
                      } else {
                        onTabChange(item.id as TabType);
                      }
                    }}
                    className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all duration-300 shrink-0 relative ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 text-amber-200 border border-amber-400/30 shadow-md shadow-amber-500/10'
                        : 'text-slate-400 hover:text-amber-200 hover:bg-slate-800/40'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                    {item.id === 'sermons' && isLiveNow && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    )}
                  </button>
                </React.Fragment>
              );
            })}
          </nav>

          {/* Quick Actions */}
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {/* Dedicated JM CHAT Quick Button */}
            <button
              onClick={() => onTabChange('jm-chat')}
              className={`flex items-center space-x-1.5 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer hover:scale-105 ${
                currentTab === 'jm-chat'
                  ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-slate-950 font-black ring-2 ring-amber-300 shadow-amber-500/30'
                  : 'bg-slate-900/90 hover:bg-slate-800 text-amber-300 border border-amber-500/40 hover:border-amber-400'
              }`}
              title="Open JM CHAT - Sovereign E2EE Messenger & Believer Partner Network"
            >
              <MessageCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="hidden sm:inline font-mono">JM CHAT</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            </button>

            <button
              onClick={onOpenPrayerModal}
              className="flex items-center space-x-1.5 px-3 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold shadow-lg shadow-amber-500/30 animate-pulse hover:shadow-[0_0_20px_rgba(251,191,36,0.7)] hover:scale-105 transition-all duration-200"
            >
              <HeartHandshake className="w-4 h-4 text-slate-950" />
              <span className="hidden sm:inline">Prayer Request</span>
              <span className="sm:hidden">Pray</span>
            </button>

            {/* SIGN-UP icon button placed in the first header */}
            <button
              onClick={onOpenSignup}
              className="flex items-center space-x-1.5 px-3 sm:px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 text-amber-300 hover:text-amber-100 border border-amber-500/40 text-xs font-bold shadow-md hover:scale-105 transition-all"
              title="Sign Up / Register Member"
            >
              <UserPlus className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Sign Up</span>
              <span className="sm:hidden">Join</span>
            </button>

            {/* User Profile Icon Button */}
            <button
              onClick={onOpenUserProfile}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl transition-all flex items-center space-x-1.5 shadow-md border cursor-pointer hover:scale-105 ${
                currentTab === 'profile'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 border-amber-300 ring-2 ring-amber-400 font-bold'
                  : 'bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 hover:border-amber-400'
              }`}
              title="Sanctuary User Profile & Saved Content"
            >
              <User className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="hidden lg:inline text-xs font-mono font-bold text-amber-300">Profile</span>
            </button>

            {/* BACKUP PROFILE Icon Button - Placed in the Header next to the User Profile Icon Button */}
            <button
              onClick={() => {
                if (onOpenBackupProfile) {
                  onOpenBackupProfile();
                } else {
                  onTabChange('backup-profile');
                }
              }}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl transition-all flex items-center space-x-1.5 shadow-md border cursor-pointer hover:scale-105 ${
                currentTab === 'backup-profile'
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 text-slate-950 border-emerald-300 ring-2 ring-emerald-400 shadow-emerald-500/30 font-bold'
                  : 'bg-slate-900 hover:bg-slate-800 text-emerald-400 border-emerald-500/40 hover:border-emerald-300'
              }`}
              title="BACKUP PROFILE - Decentralized Self-Custodial Data Vault (SD Card / Flashdrive / Hard Drive)"
            >
              <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="hidden sm:inline text-xs font-mono font-bold text-emerald-300">BACKUP PROFILE</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Tab Bar Header */}
      <div className="md:hidden flex items-center justify-around bg-slate-950/95 border-t border-amber-500/10 py-2 px-2 overflow-x-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.onClick) {
                  item.onClick();
                } else {
                  onTabChange(item.id as TabType);
                }
              }}
              className={`flex flex-col items-center px-2 py-1 rounded-lg text-[10px] font-medium transition-colors ${
                isActive ? 'text-amber-300 font-bold' : 'text-slate-400'
              }`}
            >
              <Icon className={`w-4 h-4 mb-0.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
              <span className="whitespace-nowrap">{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
