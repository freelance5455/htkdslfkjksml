import React from 'react';
import { Sparkles, Video, Plus, Wand2, Globe } from 'lucide-react';

interface NavbarProps {
  onNewProject: () => void;
  onLoadSample: () => void;
  onOpenAICommand: () => void;
  isLoadingSample: boolean;
  lang: 'ar' | 'en';
  onToggleLang: () => void;
  currentProjectName?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNewProject,
  onLoadSample,
  onOpenAICommand,
  isLoadingSample,
  lang,
  onToggleLang,
  currentProjectName
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-900/40 bg-[#0c0d1a]/90 backdrop-blur-md px-4 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand & Tagline */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 shadow-lg shadow-purple-900/30">
            <Video className="w-5 h-5 text-white" />
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 absolute -top-1 -right-1 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-purple-300 via-indigo-200 to-pink-300 bg-clip-text text-transparent">
                Designo
              </span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-700/50">
                AI Studio
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium hidden sm:block">
              {lang === 'ar' ? 'اصنع فيديوك بطريقتك.' : 'Create your video your way.'}
            </p>
          </div>
        </div>

        {/* Current Project Name (Desktop) */}
        {currentProjectName && (
          <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-lg bg-purple-950/40 border border-purple-800/30 text-xs text-purple-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="truncate max-w-[200px]">{currentProjectName}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {/* AI Command Button */}
          <button
            onClick={onOpenAICommand}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-purple-900/30 transition active:scale-95 cursor-pointer"
            title={lang === 'ar' ? 'أمر بالذكاء الاصطناعي' : 'AI Command'}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{lang === 'ar' ? 'أمر بالذكاء الاصطناعي' : 'AI Command'}</span>
          </button>

          {/* Sample Video Loader */}
          <button
            onClick={onLoadSample}
            disabled={isLoadingSample}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-800/50 text-purple-200 text-xs font-medium transition cursor-pointer disabled:opacity-50"
            title={lang === 'ar' ? 'تجربة فيديو افتراضي' : 'Try Demo Video'}
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span className="hidden xs:inline">
              {isLoadingSample
                ? (lang === 'ar' ? 'جاري التحميل...' : 'Loading...')
                : (lang === 'ar' ? 'فيديو تجريبي' : 'Demo Video')}
            </span>
          </button>

          {/* New Project */}
          <button
            onClick={onNewProject}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition cursor-pointer"
            title={lang === 'ar' ? 'مشروع جديد' : 'New Project'}
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{lang === 'ar' ? 'جديد' : 'New'}</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium transition cursor-pointer"
            title="تبديل اللغة / Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span>{lang === 'ar' ? 'EN' : 'عربي'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
