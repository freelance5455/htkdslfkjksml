import React, { useState } from 'react';
import { 
  Home, 
  Film, 
  Bell, 
  Search, 
  ShieldAlert, 
  Smartphone, 
  Settings, 
  LogOut, 
  UserCheck, 
  PlusCircle,
  Database,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';

interface NavbarProps {
  activeTab: 'feed' | 'reels' | 'profile' | 'admin';
  setActiveTab: (tab: 'feed' | 'reels' | 'profile' | 'admin') => void;
  onOpenCreatePost: () => void;
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onOpenApkGuide: () => void;
  onOpenFirebaseSettings: () => void;
  onSelectUserForProfile?: (userId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenCreatePost,
  onOpenSearch,
  onOpenNotifications,
  onOpenApkGuide,
  onOpenFirebaseSettings,
  onSelectUserForProfile,
}) => {
  const { user, isAdmin, logout, toggleAdminRole } = useAuth();
  const { unreadNotifsCount } = useSocial();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 h-14 flex items-center justify-between">
        
        {/* Left: Brand & Search */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button 
            onClick={() => setActiveTab('feed')}
            className="flex items-center gap-2 cursor-pointer focus:outline-hidden"
          >
            <div className="w-10 h-10 rounded-full bg-linear-to-tr from-[#1877F2] to-[#0D65D9] flex items-center justify-center text-white font-black text-2xl shadow-sm tracking-tighter hover:opacity-95 transition-opacity">
              <span className="translate-y-[-1px]">f</span>
              <span className="w-2 h-2 rounded-full bg-cyan-300 ml-[-2px] mb-2"></span>
            </div>
            <span className="hidden sm:inline font-black text-2xl text-[#1877F2] tracking-tight">
              FaceLook
            </span>
          </button>

          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full px-3.5 py-2 text-sm transition-colors cursor-pointer w-32 sm:w-60"
            title="Search users or hashtags"
          >
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="truncate text-left text-xs sm:text-sm">Search FaceLook...</span>
          </button>
        </div>

        {/* Center: Desktop Navigation Tabs */}
        <nav className="hidden md:flex items-center justify-center gap-1 lg:gap-2 h-full">
          <button
            onClick={() => setActiveTab('feed')}
            className={`h-full px-7 flex items-center border-b-[3px] transition-colors cursor-pointer ${
              activeTab === 'feed'
                ? 'border-[#1877F2] text-[#1877F2]'
                : 'border-transparent text-slate-500 hover:bg-slate-100 hover:text-slate-800'
            }`}
            title="Home Feed"
          >
            <Home className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab('reels')}
            className={`h-full px-7 flex items-center border-b-[3px] transition-colors cursor-pointer relative ${
              activeTab === 'reels'
                ? 'border-[#1877F2] text-[#1877F2]'
                : 'border-transparent text-slate-500 hover:bg-slate-100 hover:text-slate-800'
            }`}
            title="Reels & Short Videos"
          >
            <Film className="w-6 h-6" />
            <span className="absolute top-2.5 right-4 w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`h-full px-7 flex items-center border-b-[3px] transition-colors cursor-pointer ${
                activeTab === 'admin'
                  ? 'border-[#1877F2] text-[#1877F2]'
                  : 'border-transparent text-amber-600 hover:bg-amber-50 hover:text-amber-700'
              }`}
              title="Admin & Owner Dashboard"
            >
              <ShieldAlert className="w-6 h-6" />
            </button>
          )}
        </nav>

        {/* Right: Actions, Notifications & Profile Avatar */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Create Button */}
          <button
            onClick={onOpenCreatePost}
            className="hidden sm:flex items-center gap-1.5 bg-blue-50 hover:bg-blue-100 text-[#1877F2] font-semibold text-xs px-3 py-1.5 rounded-full transition-colors cursor-pointer"
            title="Create Post or Upload Media"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create</span>
          </button>

          {/* Android APK Packaging Free Workflow Button */}
          <button
            onClick={onOpenApkGuide}
            className="flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs px-2.5 py-1.5 rounded-full transition-colors cursor-pointer border border-emerald-200"
            title="Free Android APK Build & Packaging Guide"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span className="hidden xs:inline">Android APK</span>
          </button>

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center border-2 border-white">
                {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
              </span>
            )}
          </button>

          {/* User Profile Avatar & Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="flex items-center focus:outline-hidden cursor-pointer"
              title={user?.displayName || 'User Profile'}
            >
              <img
                src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
                alt={user?.displayName || 'Avatar'}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover ring-2 ring-slate-200 hover:ring-[#1877F2] transition-all"
              />
            </button>

            {menuOpen && (
              <div 
                className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setMenuOpen(false)}
              >
                {/* Header info */}
                <div 
                  onClick={() => {
                    if (onSelectUserForProfile && user?.id) onSelectUserForProfile(user.id);
                    setActiveTab('profile');
                  }}
                  className="px-4 py-2.5 flex items-center gap-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100"
                >
                  <img
                    src={user?.photoURL}
                    alt={user?.displayName}
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-300"
                  />
                  <div className="truncate">
                    <p className="font-bold text-sm text-slate-900 truncate flex items-center gap-1">
                      {user?.displayName}
                      {user?.isVerified && (
                        <span className="text-blue-500 text-xs">✓</span>
                      )}
                    </p>
                    <p className="text-xs text-slate-500 truncate">@{user?.username}</p>
                    <span className="inline-block text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full mt-0.5">
                      {user?.role === 'admin' ? 'Owner / Admin' : 'Member'}
                    </span>
                  </div>
                </div>

                {/* Profile Link */}
                <button
                  onClick={() => {
                    if (onSelectUserForProfile && user?.id) onSelectUserForProfile(user.id);
                    setActiveTab('profile');
                  }}
                  className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  <span>View Profile</span>
                </button>

                {/* Admin Dashboard */}
                <button
                  onClick={() => setActiveTab('admin')}
                  className="w-full text-left px-4 py-2 text-sm text-amber-700 hover:bg-amber-50 flex items-center gap-2.5 cursor-pointer font-medium"
                >
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  <span>Owner & Admin Dashboard</span>
                </button>

                {/* Free Android APK packaging modal */}
                <button
                  onClick={onOpenApkGuide}
                  className="w-full text-left px-4 py-2 text-sm text-emerald-700 hover:bg-emerald-50 flex items-center gap-2.5 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  <span>Export Android APK (Free)</span>
                </button>

                {/* Firebase Settings */}
                <button
                  onClick={onOpenFirebaseSettings}
                  className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
                >
                  <Database className="w-4 h-4 text-orange-500" />
                  <span>Firebase Setup & Status</span>
                </button>

                {/* Toggle Admin role for testing */}
                <button
                  onClick={toggleAdminRole}
                  className="w-full text-left px-4 py-2 text-xs text-slate-500 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Switch Role: {user?.role === 'admin' ? 'Demote to User' : 'Elevate to Admin'}</span>
                </button>

                <div className="border-t border-slate-100 my-1"></div>

                {/* Logout */}
                <button
                  onClick={logout}
                  className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 cursor-pointer"
                >
                  <LogOut className="w-4 h-4 text-rose-600" />
                  <span>Log Out</span>
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
