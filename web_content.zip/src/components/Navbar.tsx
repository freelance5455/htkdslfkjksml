import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Language } from '../types';
import {
  BookOpen,
  Layers,
  Network,
  RotateCcw,
  Sparkles,
  BookmarkCheck,
  Languages,
  LogIn,
  LogOut,
  Menu,
  X,
  Columns
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { language, setLanguage, showAllLanguages, setShowAllLanguages, isRtl } = useLanguage();
  const { user, signInWithGoogle, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    {
      id: 'sarf',
      labelPs: 'علم الصرف',
      labelUr: 'علم الصرف',
      labelEn: 'Ilm-e-Sarf',
      icon: Layers
    },
    {
      id: 'nahw',
      labelPs: 'علم النحو',
      labelUr: 'علم النحو',
      labelEn: 'Ilm-e-Nahw',
      icon: Network
    },
    {
      id: 'conjugator',
      labelPs: 'تصریف او ګردان',
      labelUr: 'گردان و تصریف',
      labelEn: 'Conjugator',
      icon: RotateCcw
    },
    {
      id: 'analyzer',
      labelPs: 'اعراب او ترکیب',
      labelUr: 'اعراب و ترکیب',
      labelEn: 'I\'rab Analyzer',
      icon: BookOpen
    },
    {
      id: 'quiz',
      labelPs: 'ازموینه (کویز)',
      labelUr: 'کویز و آزمائش',
      labelEn: 'Quiz & Test',
      icon: Sparkles
    },
    {
      id: 'dashboard',
      labelPs: 'زما یادښتونه',
      labelUr: 'میرے نوٹس و ذخیرہ',
      labelEn: 'My Study Hub',
      icon: BookmarkCheck
    }
  ];

  const getNavLabel = (item: typeof navItems[0]) => {
    if (language === 'pashto') return item.labelPs;
    if (language === 'urdu') return item.labelUr;
    return item.labelEn;
  };

  return (
    <header className="sticky top-0 z-40 bg-stone-900/95 text-stone-100 backdrop-blur-md border-b border-amber-600/30 shadow-lg">
      {/* Top Banner / Scholar Seal */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-amber-950 px-4 py-1.5 text-xs border-b border-amber-500/20 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-amber-300 font-medium">
          <span className="font-arabic text-base text-amber-400">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ</span>
          <span className="hidden sm:inline text-stone-400">•</span>
          <span className="hidden sm:inline text-stone-300">
            {language === 'pashto'
              ? 'د عربي ګرامر جامع لارښود (صرف او نحو)'
              : language === 'urdu'
              ? 'عربی گرامر کی جامع اکیڈمی (صرف و نحو)'
              : 'The Comprehensive Portal for Arabic Morphology & Syntax'}
          </span>
        </div>

        {/* Multi-view and Language selector */}
        <div className="flex items-center gap-2">
          {/* Trilingual toggle */}
          <button
            onClick={() => setShowAllLanguages(!showAllLanguages)}
            title={showAllLanguages ? 'Disable 3-Language View' : 'Enable 3-Language View (پښتو / اردو / English)'}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${
              showAllLanguages
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-stone-800 text-amber-300 hover:bg-stone-700'
            }`}
          >
            <Columns className="w-3.5 h-3.5" />
            <span>
              {language === 'pashto' ? '۳ ژبیزه لیدنه' : language === 'urdu' ? 'سہ لسانی منظر' : '3-Language View'}
            </span>
          </button>

          {/* Language Switcher Buttons */}
          <div className="flex items-center bg-stone-800 rounded-lg p-0.5 border border-stone-700">
            <button
              onClick={() => setLanguage('pashto')}
              className={`px-2.5 py-0.5 rounded text-xs transition-colors font-medium ${
                language === 'pashto'
                  ? 'bg-emerald-700 text-white font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              پښتو
            </button>
            <button
              onClick={() => setLanguage('urdu')}
              className={`px-2.5 py-0.5 rounded text-xs transition-colors font-medium ${
                language === 'urdu'
                  ? 'bg-emerald-700 text-white font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              اردو
            </button>
            <button
              onClick={() => setLanguage('english')}
              className={`px-2.5 py-0.5 rounded text-xs transition-colors font-medium ${
                language === 'english'
                  ? 'bg-emerald-700 text-white font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div
            onClick={() => setActiveTab('sarf')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 via-teal-700 to-amber-600 flex items-center justify-center shadow-md ring-2 ring-amber-400/40 group-hover:scale-105 transition-transform">
              <span className="font-arabic text-xl font-bold text-amber-100">صـ</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-arabic text-xl sm:text-2xl font-bold text-amber-200 tracking-wide">
                  مِرْآةُ الصَّرْفِ وَالنَّحْوِ
                </span>
              </div>
              <p className="text-[11px] text-stone-400 font-sans tracking-wide">
                {language === 'pashto'
                  ? 'د صرف او نحو لارښود'
                  : language === 'urdu'
                  ? 'قواعد الصرف والنحو اکیڈمی'
                  : 'Arabic Morphology & Syntax Academy'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-800/80 text-amber-200 border border-emerald-600/40 shadow-sm'
                      : 'text-stone-300 hover:text-white hover:bg-stone-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-stone-400'}`} />
                  <span className={language === 'urdu' ? 'font-urdu' : language === 'pashto' ? 'font-pashto' : ''}>
                    {getNavLabel(item)}
                  </span>
                </button>
              );
            })}
          </nav>

          {/* User Sign In / Profile */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex flex-col text-right rtl:text-left text-xs">
                  <span className="font-semibold text-stone-200 truncate max-w-[120px]">
                    {user.displayName || 'طالب علم'}
                  </span>
                  <span className="text-amber-400/80 text-[10px]">
                    {language === 'pashto' ? 'محصل' : language === 'urdu' ? 'طالب علم' : 'Student'}
                  </span>
                </div>
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'Profile'}
                    className="w-8 h-8 rounded-full ring-2 ring-emerald-500"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-white text-xs">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <button
                  onClick={signOut}
                  title="Sign Out"
                  className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-stone-800 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow-md border border-emerald-400/30 transition-all hover:scale-102"
              >
                <LogIn className="w-3.5 h-3.5 text-amber-300" />
                <span>
                  {language === 'pashto'
                    ? 'ګوګل سره داخل شئ'
                    : language === 'urdu'
                    ? 'گوگل سائن ان'
                    : 'Google Sign In'}
                </span>
              </button>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-stone-300 hover:text-white hover:bg-stone-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-stone-900 border-b border-stone-800 px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-emerald-800 text-amber-200'
                    : 'text-stone-300 hover:bg-stone-800 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 text-amber-400" />
                <span>{getNavLabel(item)}</span>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
