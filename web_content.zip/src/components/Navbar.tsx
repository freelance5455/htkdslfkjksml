import React from 'react';
import { BookOpen, Sparkles, HelpCircle, Layers, Globe } from 'lucide-react';

interface NavbarProps {
  currentTab: 'notes' | 'quiz' | 'flashcards' | 'ai' | 'saved';
  onSelectTab: (tab: 'notes' | 'quiz' | 'flashcards' | 'ai' | 'saved') => void;
  language: 'om' | 'en';
  onToggleLanguage: () => void;
  onOpenAiGenerator: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  language,
  onToggleLanguage,
  onOpenAiGenerator,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Brand wordmark (single line) */}
        <button
          onClick={() => onSelectTab('notes')}
          className="text-left group cursor-pointer shrink-0"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-base shadow-xs">
              B9
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 group-hover:text-amber-600 transition-colors whitespace-nowrap">
                  Barattoota <span className="text-amber-600 text-sm sm:text-base font-semibold">Kutaa 9</span>
                </span>
                <span className="text-[10px] font-extrabold text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  v3.0
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 leading-none mt-0.5">
                Ethiopian Grade 9 Learning Hub
              </p>
            </div>
          </div>
        </button>

        {/* Zone 2: Concise navigation links (single line) */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            onClick={() => onSelectTab('notes')}
            className={`flex items-center gap-2 hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
              currentTab === 'notes' ? 'text-amber-600 font-semibold' : ''
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{language === 'om' ? 'Qabxii Qorannoo' : 'Study Notes'}</span>
          </button>

          <button
            onClick={() => onSelectTab('quiz')}
            className={`flex items-center gap-2 hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
              currentTab === 'quiz' ? 'text-amber-600 font-semibold' : ''
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>{language === 'om' ? 'Qormaata (5 MCQs)' : 'Review Quizzes'}</span>
          </button>

          <button
            onClick={() => onSelectTab('flashcards')}
            className={`flex items-center gap-2 hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
              currentTab === 'flashcards' ? 'text-amber-600 font-semibold' : ''
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{language === 'om' ? 'Kaardii Jechootaa' : 'Flashcards'}</span>
          </button>

          <button
            onClick={onOpenAiGenerator}
            className="flex items-center gap-1.5 text-slate-700 hover:text-amber-700 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer font-medium"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>{language === 'om' ? 'AI Maddisiisi' : 'AI Topic Generator'}</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action (Language switcher button) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleLanguage}
            title="Afaan jijjiiri / Switch Language"
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer border border-slate-200"
          >
            <Globe className="w-3.5 h-3.5 text-amber-600" />
            <span>{language === 'om' ? 'Afaan: Oromoo' : 'Lang: English'}</span>
          </button>

          <button
            onClick={onOpenAiGenerator}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{language === 'om' ? 'Qabxii Haaraa' : 'Generate Notes'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
