import React from 'react';
import { Shield, Globe, Moon, Sun, ShieldCheck, ShieldAlert } from 'lucide-react';
import { Language, TRANSLATIONS } from '../translations';
import { ConnectionStatus } from '../types/vpn';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  status: ConnectionStatus;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenApkModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  isDark,
  onToggleTheme,
  status,
  activeTab,
  onSelectTab,
  onOpenApkModal,
}) => {
  const t = TRANSLATIONS[language];
  const isConnected = status === 'connected';

  return (
    <header className="w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
        
        {/* Zone 1: Single Brand Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors shadow-sm ${
            isConnected
              ? 'bg-emerald-500 text-white shadow-emerald-500/20'
              : 'bg-indigo-600 text-white shadow-indigo-600/20'
          }`}>
            <Shield className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
            {t.appTitle}
          </span>
        </div>

        {/* Zone 2: Navigation Links (Clean single-line prose) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`whitespace-nowrap transition-colors py-1 border-b-2 ${
              activeTab === 'dashboard'
                ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard'}
          </button>
          
          <button
            onClick={() => onSelectTab('servers')}
            className={`whitespace-nowrap transition-colors py-1 border-b-2 ${
              activeTab === 'servers'
                ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {t.changeLocation}
          </button>

          <button
            onClick={() => onSelectTab('speedtest')}
            className={`whitespace-nowrap transition-colors py-1 border-b-2 ${
              activeTab === 'speedtest'
                ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {t.speedTest}
          </button>

          <button
            onClick={() => onSelectTab('audit')}
            className={`whitespace-nowrap transition-colors py-1 border-b-2 ${
              activeTab === 'audit'
                ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {t.securityAudit}
          </button>

          <button
            onClick={() => onSelectTab('settings')}
            className={`whitespace-nowrap transition-colors py-1 border-b-2 ${
              activeTab === 'settings'
                ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {t.settings}
          </button>

          <button
            onClick={onOpenApkModal}
            className="whitespace-nowrap transition-colors py-1 border-b-2 border-transparent text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 font-semibold flex items-center gap-1.5"
          >
            <span>📱</span>
            <span>{language === 'bn' ? 'Android APK' : 'Android App'}</span>
          </button>
        </nav>

        {/* Zone 3: Controls (Status Pill, Language & Theme toggles) */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Android App Button for Mobile view */}
          <button
            onClick={onOpenApkModal}
            className="md:hidden flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-bold"
            title="Android APK / App"
          >
            <span>📱</span>
            <span>APK</span>
          </button>

          {/* Status Chip */}
          <div className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
            isConnected
              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
          }`}>
            {isConnected ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span className="whitespace-nowrap">
              {isConnected ? t.connected : t.disconnected}
            </span>
          </div>

          {/* Language Switcher */}
          <button
            onClick={() => onLanguageChange(language === 'bn' ? 'en' : 'bn')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors border border-slate-200 dark:border-slate-700"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {/* Theme Switcher */}
          <button
            onClick={onToggleTheme}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors border border-slate-200 dark:border-slate-700"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>

      </div>
    </header>
  );
};
