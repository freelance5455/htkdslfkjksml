import React from 'react';
import { 
  LayoutDashboard, 
  Receipt, 
  ShoppingBag, 
  PieChart, 
  Target, 
  Sparkles, 
  Settings as SettingsIcon,
  Lock,
  WifiOff,
  ShieldCheck,
  Moon,
  Sun,
  Palette
} from 'lucide-react';
import { AppSettings, SecuritySettings, ThemeMode } from '../types';
import { getDualAccentInfo } from '../utils/theme';
import { AppLogo } from './AppLogo';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  appSettings: AppSettings;
  setAppSettings: (settings: AppSettings) => void;
  securitySettings: SecuritySettings;
  onLockApp: () => void;
  isOffline: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  appSettings,
  setAppSettings,
  securitySettings,
  onLockApp,
  isOffline,
}) => {
  const tabs = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
    { id: 'transactions', label: 'লেনদেন', icon: Receipt },
    { id: 'shopping', label: 'বাজার তালিকা', icon: ShoppingBag },
    { id: 'budget', label: 'মাসিক বাজেট', icon: Target },
    { id: 'reports', label: 'Reports & Charts', icon: PieChart },
    { id: 'advisor', label: 'এআই সহকারী', icon: Sparkles },
    { id: 'settings', label: 'সেটিংস', icon: SettingsIcon },
  ];

  const toggleTheme = () => {
    const nextTheme: ThemeMode = appSettings.themeMode === 'dark' ? 'light' : 'dark';
    setAppSettings({ ...appSettings, themeMode: nextTheme });
  };

  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  return (
    <header className="sticky top-0 z-30 backdrop-blur-md bg-slate-900/90 dark:bg-slate-950/90 border-b border-slate-800 text-slate-100 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & App Brand */}
          <div className="flex items-center gap-3">
            <AppLogo
              size="lg"
              gradient={dualAccent.gradient}
              glowColor={dualAccent.primary.hex}
            />
            <div>
              <div className="flex items-center gap-2">
                <h1
                  className="font-bold text-lg tracking-tight"
                  style={{
                    background: dualAccent.gradientHorizontal,
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Onu Finance
                </h1>
                <span
                  className="hidden sm:inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full"
                  style={dualAccent.badgeStyle}
                >
                  <ShieldCheck className="w-3 h-3" /> সুরক্ষিত
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden xs:block">
                ব্যক্তিগত হিসাব কিতাব ও বাজেট
              </p>
            </div>
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-2">
            {/* Offline indicator */}
            <div
              className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition"
              style={{
                backgroundColor: `${dualAccent.secondary.hex}18`,
                borderColor: `${dualAccent.secondary.hex}40`,
                color: dualAccent.secondary.hex,
              }}
            >
              {isOffline ? (
                <>
                  <WifiOff className="w-3.5 h-3.5 animate-pulse" />
                  <span className="hidden sm:inline">অফলাইন</span>
                </>
              ) : (
                <>
                  <span
                    className="w-2 h-2 rounded-full animate-ping"
                    style={{ backgroundColor: dualAccent.secondary.hex }}
                  />
                  <span className="hidden sm:inline">লাইভ</span>
                </>
              )}
            </div>

            {/* Quick theme toggle */}
            <button
              onClick={toggleTheme}
              title="থিম পরিবর্তন করুন"
              className="p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition"
            >
              {appSettings.themeMode === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-400" />}
            </button>

            {/* Lock App Button */}
            {securitySettings.isPinEnabled && (
              <button
                onClick={onLockApp}
                title="অ্যাপ লক করুন"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">লক</span>
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Navigation Bar */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 no-scrollbar border-t border-slate-800/60">
          {tabs.map((tab) => {
            const IconComponent = tab.icon;
            const isActive = activeTab === tab.id;
            const tabActiveStyle = tab.id === 'dashboard'
              ? dualAccent.activeTabSecondaryStyle
              : dualAccent.activeTabPrimaryStyle;
            const tabIconColor = tab.id === 'dashboard'
              ? dualAccent.secondary.hex
              : dualAccent.primary.hex;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'shadow-sm font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
                style={isActive ? tabActiveStyle : undefined}
              >
                <IconComponent
                  className="w-4 h-4"
                  style={isActive ? { color: tabIconColor } : undefined}
                />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
