import React from 'react';
import { Wand2, Fingerprint, History, Radio, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenCloneModal: () => void;
  onOpenHistory: () => void;
  historyCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenCloneModal,
  onOpenHistory,
  historyCount,
}) => {
  return (
    <header className="glass-panel sticky top-0 z-40 px-4 md:px-8 py-3.5 flex justify-between items-center border-b border-gray-800/80">
      <div className="flex items-center space-x-3.5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20">
          <Wand2 className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-100 to-gray-400">
              SonicVoice
            </h1>
            <span className="text-[11px] font-mono font-semibold text-indigo-300 px-2 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-800/60 shadow-inner flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-indigo-400" /> PRO AI
            </span>
          </div>
          <p className="text-xs text-gray-400 hidden sm:block">
            ElevenLabs &amp; Cartesia AI Multilingual Voice Studio • Hindi, English &amp; Global Neural TTS
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-2.5 sm:space-x-4">
        {/* Model Status Pill */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Free Unlimited Engine Active</span>
        </div>

        {/* Clone Voice Studio Button */}
        <button
          onClick={onOpenCloneModal}
          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 border border-indigo-400/30 transition flex items-center gap-1.5 cursor-pointer active:scale-95"
        >
          <Fingerprint className="w-3.5 h-3.5" />
          <span>Clone Voice</span>
        </button>

        {/* History Drawer Trigger */}
        <button
          onClick={onOpenHistory}
          className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-gray-900/80 hover:bg-gray-800 border border-gray-700/80 text-gray-300 hover:text-white text-xs font-medium transition flex items-center gap-1.5 cursor-pointer relative"
          title="Generated Audio History"
        >
          <History className="w-4 h-4 text-indigo-400" />
          <span className="hidden sm:inline">History</span>
          {historyCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-indigo-600 text-[10px] font-bold text-white">
              {historyCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
