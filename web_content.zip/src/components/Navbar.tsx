import React from 'react';
import { 
  FolderArchive, 
  Terminal, 
  Layers, 
  Code2, 
  Cpu,
  KeyRound,
  ShieldCheck, 
  AlertCircle,
  Power,
  Cloud
} from 'lucide-react';
import { AdbStatus, HudSettings } from '../types';
import { User } from 'firebase/auth';

export type NavTabType = 'files' | 'drive' | 'hud' | 'monitor' | 'terminal' | 'adb' | 'code';

interface NavbarProps {
  activeTab: NavTabType;
  setActiveTab: (tab: NavTabType) => void;
  adbStatus: AdbStatus;
  hudSettings: HudSettings;
  setHudSettings: React.Dispatch<React.SetStateAction<HudSettings>>;
  driveUser: User | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  adbStatus,
  hudSettings,
  setHudSettings,
  driveUser,
}) => {
  return (
    <header className="h-14 border-b border-neutral-800 px-3 md:px-5 flex items-center justify-between bg-neutral-950/95 backdrop-blur z-30 shrink-0">
      {/* Brand */}
      <div className="flex items-center space-x-2.5">
        <div className="w-8 h-8 rounded bg-neutral-900 border border-neutral-800 flex items-center justify-center text-white shadow-inner shrink-0">
          <FolderArchive className="w-4 h-4 text-white" />
        </div>
        <div className="flex flex-col">
          <div className="flex items-center space-x-1.5">
            <span className="font-bold tracking-wider text-xs md:text-sm text-white whitespace-nowrap">MEUS ARQUIVOS PAT</span>
            <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-neutral-800 text-neutral-300">v2.5</span>
          </div>
          <span className="text-[10px] text-neutral-400 hidden xl:inline">Power User Suite · Drive & ADB Rootless</span>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav className="flex items-center space-x-1 overflow-x-auto py-1 max-w-[55vw] lg:max-w-none no-scrollbar">
        {/* 1. Files */}
        <button
          onClick={() => setActiveTab('files')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'files'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <FolderArchive className="w-3.5 h-3.5" />
          <span>Ficheiros</span>
        </button>

        {/* 2. Google Drive (New!) */}
        <button
          onClick={() => setActiveTab('drive')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'drive'
              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <Cloud className={`w-3.5 h-3.5 ${driveUser ? 'text-emerald-400' : 'text-blue-400'}`} />
          <span>Google Drive</span>
          {driveUser && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
        </button>

        {/* 3. Floating Menu (HUD) */}
        <button
          onClick={() => setActiveTab('hud')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'hud'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Menu Flutuante</span>
          <span className="sm:hidden">HUD</span>
          <span className={`w-1.5 h-1.5 rounded-full ${hudSettings.visible ? 'bg-emerald-400' : 'bg-neutral-600'}`} />
        </button>

        {/* 4. Hardware Monitor (CPU & GPU) */}
        <button
          onClick={() => setActiveTab('monitor')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'monitor'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          <span>CPU & GPU</span>
        </button>

        {/* 5. Dedicated Terminal */}
        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'terminal'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-amber-400" />
          <span>Terminal</span>
        </button>

        {/* 6. ADB Activation */}
        <button
          onClick={() => setActiveTab('adb')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'adb'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Ativação ADB</span>
          <span className="sm:hidden">Ativação</span>
        </button>

        {/* 7. Android Studio Code */}
        <button
          onClick={() => setActiveTab('code')}
          className={`px-2.5 py-1.5 text-xs font-medium rounded transition flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'code'
              ? 'bg-neutral-800 text-white font-semibold'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
          }`}
        >
          <Code2 className="w-3.5 h-3.5 text-purple-400" />
          <span className="hidden sm:inline">Código Android</span>
          <span className="sm:hidden">Código</span>
        </button>
      </nav>

      {/* Right Controls */}
      <div className="flex items-center space-x-2 shrink-0">
        {/* Dedicated Menu Flutuante On/Off Button */}
        <button
          onClick={() => setHudSettings(prev => ({ ...prev, visible: !prev.visible }))}
          className={`px-2.5 py-1 rounded text-xs border font-medium flex items-center space-x-1.5 transition ${
            hudSettings.visible
              ? 'bg-emerald-950/70 border-emerald-700/80 text-emerald-300 hover:bg-emerald-900/70'
              : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
          }`}
          title="Ativar ou desativar o Menu Flutuante na tela"
        >
          <Power className={`w-3 h-3 ${hudSettings.visible ? 'text-emerald-400' : 'text-neutral-500'}`} />
          <span className="hidden md:inline font-mono text-[11px]">
            HUD: {hudSettings.visible ? 'ATIVO' : 'DESLIGADO'}
          </span>
          <span className="md:hidden font-mono text-[11px]">
            {hudSettings.visible ? 'ON' : 'OFF'}
          </span>
        </button>

        {/* ADB Status Badge */}
        <button
          onClick={() => setActiveTab('adb')}
          className={`px-2.5 py-1 rounded text-[11px] font-mono flex items-center space-x-1.5 border transition ${
            adbStatus.connected
              ? 'bg-emerald-950/80 border-emerald-700/60 text-emerald-300'
              : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700'
          }`}
          title="Status do ADB sem root. Clique para abrir."
        >
          {adbStatus.connected ? (
            <>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="hidden lg:inline font-bold">ADB ATIVO</span>
            </>
          ) : (
            <>
              <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="hidden lg:inline">SEM ADB</span>
            </>
          )}
          <div className={`w-1.5 h-1.5 rounded-full ${adbStatus.connected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        </button>
      </div>
    </header>
  );
};
