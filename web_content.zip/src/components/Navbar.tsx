import React, { useState } from 'react';
import { MessageCircle, Radio, Menu, X, Phone, Disc, Smartphone, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  onBookClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onBookClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'DJ Booking', href: '#services' },
    { label: 'DJ Apps & Drops', href: '#shop' },
    { label: 'Phones Business', href: '#phones' },
    { label: 'Soundboard', href: '#soundboard' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Book Now', href: '#booking' },
  ];

  const defaultWaUrl =
    'https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20want%20to%20book%20you%20in%20Kyebando%20Kampala';

  return (
    <header className="sticky top-0 z-40 bg-black/90 backdrop-blur-md border-b border-zinc-800">
      <div className="max-w-6xl mx-auto px-4 h-16 sm:h-20 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-pink-600 to-cyan-500 p-0.5 shadow-lg group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#0d0818] rounded-[10px] flex items-center justify-center font-black text-white text-xs">
              👑
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-base sm:text-lg tracking-tight text-white uppercase font-['Outfit']">
                DJ EVAN PRO UG
              </span>
              <span className="text-[10px] bg-yellow-400 text-black font-extrabold px-1.5 py-0.2 rounded uppercase">
                👑 CUE KING
              </span>
            </div>
            <div className="text-[11px] font-mono text-cyan-400 font-bold tracking-wider -mt-1">
              KYEBANDO, KAWEMPE · KAMPALA
            </div>
          </div>
        </a>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-bold text-slate-300">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="hover:text-cyan-400 transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right CTA Actions */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href="https://tiktok.com/@djevanproug"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs font-bold text-white hover:text-pink-300 bg-zinc-900 border border-zinc-700 px-3 py-2 rounded-full transition-colors"
          >
            <Radio className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
            <span>TikTok @djevanproug</span>
          </a>

          <a
            href={defaultWaUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition-all"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>0742094651</span>
          </a>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex sm:hidden items-center gap-2">
          <a
            href={defaultWaUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full bg-emerald-500 text-white shadow-md"
            title="Chat on WhatsApp"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
          </a>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-slate-300 hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-zinc-950 border-b border-zinc-800 px-4 py-5 space-y-4 shadow-2xl">
          <nav className="flex flex-col gap-2.5 text-sm font-bold text-slate-200">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 px-3 rounded-lg hover:bg-zinc-900 hover:text-cyan-400 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-zinc-800 flex flex-col gap-2">
            <a
              href={defaultWaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 rounded-full bg-emerald-500 text-white font-black text-xs uppercase tracking-wider text-center flex items-center justify-center gap-2 shadow-lg"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp 0742094651</span>
            </a>

            <a
              href="https://tiktok.com/@djevanproug"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 rounded-full bg-black border border-white/40 text-white font-bold text-xs uppercase tracking-wider text-center flex items-center justify-center gap-2"
            >
              <Radio className="w-4 h-4 text-rose-500" />
              <span>TikTok LIVE 8PM @djevanproug</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
