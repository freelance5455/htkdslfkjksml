import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import { Menu, X, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';

type NavView =
  | 'home'
  | 'founders'
  | 'projects'
  | 'what-we-do'
  | 'start-project'
  | 'vouches'
  | 'ai-assistant'
  | 'admin';

interface NavbarProps {
  currentView: NavView;
  onNavigate?: (view: NavView, options?: { scrollId?: string; category?: string; tab?: string }) => void;
  setCurrentView?: (view: NavView) => void;
  setCategoryFilter?: (cat: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  setCurrentView,
  setCategoryFilter
}) => {
  const { data, syncing } = useData();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigateTo = (view: NavView, hash?: string) => {
    setMobileMenuOpen(false);
    if (onNavigate) {
      onNavigate(view, { scrollId: hash });
    } else if (setCurrentView) {
      setCurrentView(view);
      if (hash) {
        setTimeout(() => {
          const el = document.getElementById(hash);
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  return (
    <>
      <header className="sticky top-3.5 z-40 w-[min(1160px,calc(100%-28px))] mx-auto rounded-[30px] border border-white/15 bg-white/[0.05] backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.2)] transition-all">
        <nav className="flex justify-between items-center px-4 py-2.5 sm:px-6 sm:py-3">
          {/* Custom Cubix C Icon + Text Logo */}
          <button
            onClick={() => navigateTo('home')}
            className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer"
          >
            {/* Cubix Studio Emblem */}
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-black/50 border border-white/20 overflow-hidden p-0.5 shadow-sm">
              <img
                src={data?.settings?.logoUrl || '/cubix-logo.jpg'}
                alt="Cubix Studio"
                className="w-full h-full rounded-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/cubix-logo.jpg';
                }}
              />
              {/* Circular syncing indicator on emblem */}
              {syncing && (
                <div
                  className="absolute inset-0 bg-black/75 backdrop-blur-[1px] rounded-full flex items-center justify-center transition-all animate-fadeIn"
                  title="Cloud Firestore Synchronizing..."
                  aria-label="Cloud Firestore Synchronizing"
                >
                  <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                </div>
              )}
            </div>

            {/* Text Logo: Cubix Studio with subtle cyan accent */}
            <div className="flex flex-col">
              <div className="text-white font-extrabold text-lg sm:text-xl tracking-tight flex items-center gap-1.5 font-['Plus_Jakarta_Sans']">
                <span>Cubix</span>
                <span className="text-cyan-400 font-semibold">Studio</span>
                {/* Circular spinning indicator near brand text */}
                {syncing && (
                  <span
                    className="inline-flex items-center gap-1 text-[10px] font-mono text-cyan-400 ml-1 px-1.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 animate-fadeIn"
                    title="Cloud Firestore Synchronizing..."
                  >
                    <RefreshCw className="w-2.5 h-2.5 animate-spin text-cyan-400" />
                    <span className="hidden sm:inline">Syncing</span>
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* Right Hamburger / Menu Trigger matching design */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] text-slate-200 hover:text-white border border-white/15 transition-all cursor-pointer"
              aria-label="Open Navigation Menu"
            >
              <Menu className="w-5 h-5 text-slate-200" />
            </button>
          </div>
        </nav>
      </header>

      {/* Hamburger Menu Overlay - EXACT SPECIFIED ORDER:
          1. Home
          2. About
          3. Services
          4. Founders
          5. FAQ
          6. Contact
          7. Get in Touch
          8. Admin
      */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end transition-opacity duration-200"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="w-full max-w-sm sm:max-w-md h-full bg-[#061021]/95 border-l border-white/10 p-6 sm:p-7 flex flex-col justify-between shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              {/* Header inside Menu */}
              <div className="flex items-center justify-between pb-6 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-black/50 border border-white/20 p-0.5 flex items-center justify-center">
                    <img
                      src={data?.settings?.logoUrl || '/cubix-logo.jpg'}
                      alt="Cubix"
                      className="w-full h-full rounded-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-extrabold text-white text-lg">
                      Cubix <span className="text-cyan-400 font-semibold">Studio</span>
                    </div>
                    <div className="text-xs text-slate-400">Digital Development &amp; Creative Studio</div>
                  </div>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Links in EXACT ORDER REQUIRED (NO NUMBER PREFIXES, NO MEET TEAM) */}
              <nav className="my-8">
                <ul className="flex flex-col gap-2 text-base font-semibold">
                  {/* Home */}
                  <li>
                    <button
                      onClick={() => navigateTo('home')}
                      className={`w-full flex items-center justify-between py-2.5 px-4 rounded-xl transition-all text-left cursor-pointer ${
                        currentView === 'home'
                          ? 'bg-white/10 text-cyan-300 border border-white/15'
                          : 'text-slate-200 hover:text-cyan-300 hover:bg-white/5'
                      }`}
                    >
                      <span>Home</span>
                    </button>
                  </li>

                  {/* About */}
                  <li>
                    <button
                      onClick={() => navigateTo('home', 'about')}
                      className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl text-slate-200 hover:text-cyan-300 hover:bg-white/5 transition-all text-left cursor-pointer"
                    >
                      <span>About</span>
                    </button>
                  </li>

                  {/* Services */}
                  <li>
                    <button
                      onClick={() => navigateTo('home', 'services')}
                      className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl text-slate-200 hover:text-cyan-300 hover:bg-white/5 transition-all text-left cursor-pointer"
                    >
                      <span>Services</span>
                    </button>
                  </li>

                  {/* Founders (Renamed from Founder, no "Meet Team" label) */}
                  <li>
                    <button
                      onClick={() => navigateTo('founders')}
                      className={`w-full flex items-center justify-between py-2.5 px-4 rounded-xl transition-all text-left cursor-pointer ${
                        currentView === 'founders'
                          ? 'bg-white/10 text-cyan-300 border border-white/15'
                          : 'text-slate-200 hover:text-cyan-300 hover:bg-white/5'
                      }`}
                    >
                      <span>Founders</span>
                    </button>
                  </li>

                  {/* Vouches */}
                  <li>
                    <button
                      onClick={() => navigateTo('vouches')}
                      className={`w-full flex items-center justify-between py-2.5 px-4 rounded-xl transition-all text-left cursor-pointer ${
                        currentView === 'vouches'
                          ? 'bg-white/10 text-cyan-300 border border-white/15'
                          : 'text-slate-200 hover:text-cyan-300 hover:bg-white/5'
                      }`}
                    >
                      <span>Vouches</span>
                    </button>
                  </li>

                  {/* FAQ */}
                  <li>
                    <button
                      onClick={() => navigateTo('home', 'faq')}
                      className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl text-slate-200 hover:text-cyan-300 hover:bg-white/5 transition-all text-left cursor-pointer"
                    >
                      <span>FAQ</span>
                    </button>
                  </li>

                  {/* Contact */}
                  <li>
                    <button
                      onClick={() => navigateTo('home', 'contact')}
                      className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl text-slate-200 hover:text-cyan-300 hover:bg-white/5 transition-all text-left cursor-pointer"
                    >
                      <span>Contact</span>
                    </button>
                  </li>

                  {/* Get in Touch */}
                  <li>
                    <button
                      onClick={() => navigateTo('home', 'contact')}
                      className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl text-cyan-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-all text-left cursor-pointer"
                    >
                      <span>Get in Touch</span>
                      <ArrowRight className="w-4 h-4 text-cyan-400" />
                    </button>
                  </li>

                  {/* Admin */}
                  <li className="pt-2 border-t border-white/10 mt-2">
                    <button
                      onClick={() => navigateTo('admin')}
                      className={`w-full flex items-center justify-between py-2.5 px-4 rounded-xl transition-all text-left cursor-pointer ${
                        currentView === 'admin'
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'text-slate-300 hover:text-cyan-300 hover:bg-white/5'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-cyan-400" />
                        Admin
                      </span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>

            {/* Bottom info */}
            <div className="pt-4 border-t border-white/10 text-xs text-slate-400 text-center">
              <div>Cubix Studio • Gurgaon, Haryana, India</div>
              <div className="text-[11px] text-slate-500 mt-1">Direct: {data.settings.contactEmail}</div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
