import React, { useState, useEffect, useRef } from 'react';
import { useVideo } from '../context/VideoContext';
import {
  Search,
  Upload,
  Bell,
  ChevronDown,
  X,
  Film,
  Bookmark,
  User,
  Globe,
  PlusCircle,
  HardDrive,
  Sparkles,
  Play,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    searchQuery,
    setSearchQuery,
    activeTab,
    setActiveTab,
    setIsUploadModalOpen,
    myList,
    stats,
    language,
    setLanguage,
    currentProfile,
    profiles,
    selectProfile,
    setIsSelectingProfile,
    isAuthModalOpen,
    setIsAuthModalOpen,
    currentUser,
    logOut,
    filteredVideos,
    setYoutubeVideo,
  } = useVideo();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearchToggle = () => {
    setIsSearchOpen(!isSearchOpen);
    if (!isSearchOpen) {
      setTimeout(() => searchInputRef.current?.focus(), 150);
    }
  };

  const navLinks = [
    { id: 'home', labelEn: 'Home', labelUr: 'ہوم' },
    { id: 'movies', labelEn: 'Movies', labelUr: 'فلمیں' },
    { id: 'series', labelEn: 'Series', labelUr: 'سیریز' },
    {
      id: 'uploaded',
      labelEn: 'Community Uploads',
      labelUr: 'اپلوڈ شدہ ویڈیوز',
      badge: stats.uploadedVideos > 0 ? stats.uploadedVideos : undefined,
    },
    {
      id: 'my-list',
      labelEn: 'My List',
      labelUr: 'میری لسٹ',
      badge: myList.length > 0 ? myList.length : undefined,
    },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#141414]/95 backdrop-blur-md shadow-2xl py-3 border-b border-white/5'
          : 'bg-gradient-to-b from-black/90 via-black/40 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Left Side: Brand Logo & Navigation */}
        <div className="flex items-center space-x-6 lg:space-x-8">
          {/* Netflix-style Brand Logo */}
          <div
            onClick={() => {
              setActiveTab('home');
              setSearchQuery('');
            }}
            className="flex items-center space-x-2 cursor-pointer group select-none"
          >
            <div className="w-8 h-8 rounded-sm bg-[#E50914] flex items-center justify-center shadow-lg shadow-red-900/40 transform group-hover:scale-105 transition-transform">
              <Film className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold tracking-widest text-2xl lg:text-3xl text-[#E50914] font-['Plus_Jakarta_Sans',sans-serif] leading-none uppercase drop-shadow-md group-hover:brightness-110 transition-all">
                CINESTREAM
              </span>
              <span className="text-[10px] tracking-widest text-zinc-400 uppercase font-semibold">
                {language === 'ur' ? 'نیٹ فلکس انداز' : 'NETFLIX STYLE'}
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-5 text-sm font-medium">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id && !searchQuery;
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveTab(link.id);
                    setSearchQuery('');
                  }}
                  className={`transition-colors duration-200 relative py-1 flex items-center space-x-1.5 ${
                    isActive
                      ? 'text-white font-bold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  <span>{language === 'ur' ? link.labelUr : link.labelEn}</span>
                  {link.badge !== undefined && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-[#E50914] text-white">
                      {link.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#E50914] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Right Side: Upload, Search, Language, Profile */}
        <div className="flex items-center space-x-3 lg:space-x-5">
          {/* Upload Video Button */}
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center space-x-2 px-3 py-1.5 sm:px-4 sm:py-2 rounded-md bg-gradient-to-r from-[#E50914] to-[#b80710] hover:from-[#ff1b27] hover:to-[#E50914] text-white font-semibold text-xs sm:text-sm shadow-lg shadow-red-900/40 hover:shadow-red-800/60 transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
            title="Upload a new video to the platform"
          >
            <Upload className="w-4 h-4" />
            <span className="hidden sm:inline">
              {language === 'ur' ? 'ویڈیو اپلوڈ کریں' : 'Upload Video'}
            </span>
          </button>

          {/* Expandable Search Input */}
          <div className="relative flex items-center">
            {isSearchOpen ? (
              <div className="flex items-center bg-black/80 border border-white/30 rounded-md px-2.5 py-1 text-sm text-white w-48 sm:w-64 transition-all duration-300">
                <Search className="w-4 h-4 text-zinc-400 mr-2 flex-shrink-0" />
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder={language === 'ur' ? 'عنوان، اداکار، کیٹیگری...' : 'Titles, people, genres...'}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent border-none outline-none text-white text-xs sm:text-sm w-full placeholder-zinc-500"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-zinc-400 hover:text-white ml-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  onClick={handleSearchToggle}
                  className="text-zinc-400 hover:text-white ml-2 text-xs"
                >
                  ✕
                </button>
              </div>
            ) : (
              <button
                onClick={handleSearchToggle}
                className="p-2 text-zinc-300 hover:text-white transition-colors"
                title="Search"
              >
                <Search className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* YouTube Watch Mode Switcher */}
          <button
            onClick={() => {
              if (filteredVideos.length > 0) {
                setYoutubeVideo(filteredVideos[0]);
              }
            }}
            className="hidden sm:flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-red-600/20 hover:bg-red-600/30 text-xs font-bold text-red-400 border border-red-600/30 transition-colors cursor-pointer"
            title="Open in YouTube Watch View"
          >
            <div className="w-3.5 h-3.5 rounded-xs bg-[#E50914] flex items-center justify-center">
              <Play className="w-2 h-2 fill-white text-white ml-0.5" />
            </div>
            <span>{language === 'ur' ? 'یوٹیوب موڈ' : 'YouTube View'}</span>
          </button>

          {/* Language Toggle (EN / UR) */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
            className="flex items-center space-x-1 px-2.5 py-1 rounded bg-zinc-800/70 hover:bg-zinc-700/80 text-xs font-semibold text-zinc-200 transition-colors border border-zinc-700/50 cursor-pointer"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-zinc-400" />
            <span>{language === 'en' ? 'اردو' : 'EN'}</span>
          </button>

          {/* Sign In Button (if not authenticated) */}
          {!currentUser && (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center space-x-1.5 px-3 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white border border-white/20 transition-colors cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-red-500" />
              <span>{language === 'ur' ? 'سائن ان' : 'Sign In'}</span>
            </button>
          )}

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center space-x-1.5 focus:outline-none group cursor-pointer"
            >
              <img
                src={currentProfile?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                alt={currentProfile?.name || 'Profile'}
                className="w-8 h-8 rounded-sm object-cover ring-2 ring-transparent group-hover:ring-red-500 transition-all"
              />
              <ChevronDown
                className={`w-3.5 h-3.5 text-zinc-300 group-hover:text-white transition-transform ${
                  isProfileMenuOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Profile Dropdown Menu */}
            {isProfileMenuOpen && (
              <div
                className="absolute right-0 mt-3 w-60 rounded-md bg-[#191919] border border-white/10 shadow-2xl py-2 z-50 text-xs text-zinc-300"
                onMouseLeave={() => setIsProfileMenuOpen(false)}
              >
                <div className="px-3 py-2 border-b border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-zinc-400 text-[11px] uppercase tracking-wider font-semibold">
                      {language === 'ur' ? 'پروفائلز' : 'Profiles'}
                    </p>
                    <button
                      onClick={() => {
                        setIsSelectingProfile(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="text-[11px] text-red-500 hover:text-red-400 font-semibold cursor-pointer underline"
                    >
                      {language === 'ur' ? 'پروفائل اسکرین' : 'Switch Screen'}
                    </button>
                  </div>

                  <div className="space-y-1.5">
                    {profiles.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          selectProfile(p);
                          setIsProfileMenuOpen(false);
                        }}
                        className={`w-full flex items-center space-x-2.5 px-2 py-1.5 rounded text-left hover:bg-zinc-800 transition-colors ${
                          currentProfile?.id === p.id ? 'bg-zinc-800/80 font-bold text-white' : ''
                        }`}
                      >
                        <img src={p.avatar} alt={p.name} className="w-6 h-6 rounded-sm object-cover" />
                        <span className="truncate flex-1">{p.name}</span>
                        {p.isKids && (
                          <span className="text-[9px] px-1 bg-amber-500/20 text-amber-400 rounded">
                            Kids
                          </span>
                        )}
                        {currentProfile?.id === p.id && (
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                        )}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      setIsSelectingProfile(true);
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full mt-2 py-1.5 px-2 rounded border border-zinc-700 hover:border-zinc-500 text-center text-[11px] text-zinc-300 hover:text-white font-medium bg-zinc-800/40 cursor-pointer block"
                  >
                    ⚙ {language === 'ur' ? 'پروفائل تبدیل کریں / انتظام' : 'Manage / Switch Profiles'}
                  </button>
                </div>

                <div className="py-1 border-b border-white/10">
                  <button
                    onClick={() => {
                      setActiveTab('uploaded');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-2 px-3 py-2 hover:bg-zinc-800 text-left transition-colors"
                  >
                    <HardDrive className="w-4 h-4 text-red-500" />
                    <span>
                      {language === 'ur' ? 'میرے اپلوڈز' : 'Uploaded Content'} ({stats.uploadedVideos})
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('my-list');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-2 px-3 py-2 hover:bg-zinc-800 text-left transition-colors"
                  >
                    <Bookmark className="w-4 h-4 text-emerald-400" />
                    <span>
                      {language === 'ur' ? 'میری پسندیدہ لسٹ' : 'My Watchlist'} ({myList.length})
                    </span>
                  </button>
                </div>

                {/* Account Authentication section */}
                <div className="py-1 border-b border-white/10 px-3">
                  {currentUser ? (
                    <div>
                      <p className="text-[11px] text-zinc-400 truncate">
                        Account: <span className="text-white font-medium">{currentUser.displayName || currentUser.email}</span>
                      </p>
                      <button
                        onClick={() => {
                          logOut();
                          setIsProfileMenuOpen(false);
                        }}
                        className="text-red-400 hover:text-red-300 text-[11px] font-bold mt-1 underline cursor-pointer"
                      >
                        {language === 'ur' ? 'لاگ آؤٹ کریں' : 'Sign Out'}
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setIsAuthModalOpen(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="text-red-400 hover:text-red-300 text-xs font-semibold py-1 flex items-center space-x-1.5 cursor-pointer"
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>{language === 'ur' ? 'سائن ان / لاگ ان' : 'Sign In / Sign Up'}</span>
                    </button>
                  )}
                </div>

                <div className="px-3 pt-2 pb-1 text-[11px] text-zinc-500 flex items-center justify-between">
                  <span>CineStream v2.0</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Database Connected
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation Sub-bar */}
      <div className="md:hidden flex items-center justify-around px-4 pt-2.5 pb-1 text-xs border-t border-white/5 bg-[#141414]/90">
        {navLinks.map((link) => {
          const isActive = activeTab === link.id && !searchQuery;
          return (
            <button
              key={link.id}
              onClick={() => {
                setActiveTab(link.id);
                setSearchQuery('');
              }}
              className={`py-1 px-2 rounded ${
                isActive ? 'text-white font-bold bg-white/10' : 'text-zinc-400'
              }`}
            >
              {language === 'ur' ? link.labelUr : link.labelEn}
              {link.badge !== undefined && ` (${link.badge})`}
            </button>
          );
        })}
      </div>
    </header>
  );
};
