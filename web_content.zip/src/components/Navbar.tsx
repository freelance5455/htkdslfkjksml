"use client";

import {
  BrainCircuit, CandlestickChart, Flame, LayoutGrid, Receipt, Settings,
  TrendingUp, Users,
} from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { TabId } from "@/types";

const TABS: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: "ai", label: "AI Trader & בוט", icon: <BrainCircuit className="h-4 w-4" /> },
  { id: "active", label: "עסקאות פעילות", icon: <TrendingUp className="h-4 w-4" /> },
  { id: "copy", label: "Copy Trading", icon: <Users className="h-4 w-4" /> },
  { id: "paper", label: "מסחר דמו", icon: <CandlestickChart className="h-4 w-4" /> },
  { id: "terminal", label: "טרמינל לייב", icon: <LayoutGrid className="h-4 w-4" /> },
  { id: "heatmap", label: "מפת חום", icon: <Flame className="h-4 w-4" /> },
  { id: "tax", label: "יומן ומס", icon: <Receipt className="h-4 w-4" /> },
  { id: "settings", label: "הגדרות", icon: <Settings className="h-4 w-4" /> },
];

export default function Navbar() {
  const active = useTradingStore((s) => s.activeTab);
  const setActive = useTradingStore((s) => s.setActiveTab);
  const positionsCount = useTradingStore((s) => s.positions.length);

  return (
    <nav className="sticky top-[57px] z-30 border-b border-slate-800 bg-[#0f172a]/95 backdrop-blur lg:top-[61px]">
      <div className="mx-auto flex max-w-[1500px] gap-1 overflow-x-auto px-3 py-1.5 lg:px-5">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setActive(t.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition ${
              active === t.id
                ? "bg-emerald-500/15 text-emerald-400"
                : "text-slate-400 hover:bg-slate-800/70 hover:text-slate-200"
            }`}
          >
            {t.icon}
            {t.label}
            {t.id === "active" && positionsCount > 0 && (
              <span className="num flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-500 px-1 text-[9px] font-black text-slate-950">
                {positionsCount}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
}
