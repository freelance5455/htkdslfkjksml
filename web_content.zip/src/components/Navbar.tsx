import React, { useState } from 'react';
import { useApp, ViewType } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Building2, 
  HeartPulse, 
  Palmtree, 
  Plane, 
  Activity, 
  Globe2, 
  LayoutDashboard, 
  Menu, 
  X, 
  Send, 
  Search, 
  UserCheck, 
  Crown,
  Sparkles
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    language, 
    currentView, 
    setCurrentView, 
    openRequestModalForService, 
    setTrackingCode,
    lookupTracking,
    showToast
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [trackingInput, setTrackingInput] = useState('');
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const t = translations[language];
  const isAr = language === 'ar';

  const navLinks: { label: string; view: ViewType; icon: React.ReactNode }[] = [
    { label: t.navHome, view: 'home', icon: null },
    { label: t.navMedical, view: 'medical', icon: <HeartPulse className="w-4 h-4 text-[#D4AF37]" /> },
    { label: t.navRehab, view: 'rehab', icon: <Building2 className="w-4 h-4 text-[#D4AF37]" /> },
    { label: t.navTourism, view: 'tourism', icon: <Palmtree className="w-4 h-4 text-[#D4AF37]" /> },
    { label: t.navReception, view: 'reception', icon: <Plane className="w-4 h-4 text-[#D4AF37]" /> },
    { label: t.navTracking, view: 'tracking', icon: <Activity className="w-4 h-4 text-[#D4AF37]" /> },
    { label: t.navInternational, view: 'international', icon: <Globe2 className="w-4 h-4 text-[#D4AF37]" /> },
  ];

  const handleQuickTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingInput.trim()) return;
    const ok = lookupTracking(trackingInput.trim());
    if (ok) {
      setCurrentView('tracking');
      setShowSearchModal(false);
      setTrackingInput('');
    } else {
      showToast(
        isAr 
          ? `لم يتم العثور على الطلب (${trackingInput}). يرجى تجربة الرمز الافتراضي ALM-REQ-7924`
          : `Code (${trackingInput}) not found. Try default demo code ALM-REQ-7924`
      );
    }
  };

  return (
    <>
      <header className="bg-black/95 backdrop-blur-md border-b border-[#D4AF37]/30 sticky top-9 z-40 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* Logo & Brand Identity with Transparent Background Logo */}
            <div 
              onClick={() => { setCurrentView('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <div className="relative h-14 w-auto flex items-center justify-center group-hover:scale-105 transition-transform duration-300">
                <img 
                  src="/assets/aistudio/logo_transparent.png" 
                  alt="شعار المواساة الرسمي" 
                  className="h-14 sm:h-16 w-auto object-contain drop-shadow-[0_4px_12px_rgba(212,175,55,0.35)]"
                />
              </div>

              {/* Title & Slogan */}
              <div className="hidden sm:flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-xl font-black bg-gradient-to-r from-amber-200 via-amber-400 to-[#D4AF37] bg-clip-text text-transparent tracking-tight">
                    {t.brandName}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-[#D4AF37]/15 text-amber-300 rounded-md border border-[#D4AF37]/40">
                    MEDICAL & TOURISM
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 font-medium">
                  {isAr ? 'منظومة الرعاية الصحية والسياحة العلاجية بمصر' : 'Egypt Integrated Healthcare & Medical Tourism'}
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden xl:flex items-center gap-1 text-sm font-medium text-zinc-300">
              {navLinks.map(link => {
                const active = currentView === link.view;
                return (
                  <button
                    key={link.view}
                    onClick={() => {
                      setCurrentView(link.view);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
                      active 
                        ? 'text-amber-300 bg-zinc-900 border border-[#D4AF37]/50 font-bold shadow-[0_0_10px_rgba(212,175,55,0.15)]' 
                        : 'hover:text-amber-300 hover:bg-zinc-900/60'
                    }`}
                  >
                    {link.label}
                  </button>
                );
              })}
            </nav>

            {/* Actions: Track, Login/Register, Request CTA */}
            <div className="hidden lg:flex items-center gap-3">
              {/* Quick Track Button */}
              <button
                onClick={() => setShowSearchModal(true)}
                className="p-2.5 text-zinc-400 hover:text-amber-300 hover:bg-zinc-900 rounded-xl transition-colors border border-transparent hover:border-[#D4AF37]/30"
                title={t.navTrackingSearch}
              >
                <Search className="w-4 h-4 text-amber-400" />
              </button>

              {/* Auth / Patient Account Demo */}
              <button
                onClick={() => setShowAuthModal(true)}
                className="text-xs font-semibold text-zinc-300 hover:text-amber-300 px-3 py-2.5 rounded-xl hover:bg-zinc-900 transition-colors flex items-center gap-1.5 border border-zinc-800 hover:border-[#D4AF37]/30"
              >
                <UserCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{t.login}</span>
              </button>

              {/* Primary CTA */}
              <button
                onClick={() => openRequestModalForService('medical_sector')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black text-xs sm:text-sm font-extrabold px-4.5 py-2.5 rounded-xl shadow-lg shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 flex items-center gap-2 border border-amber-300"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{t.navRequestBtn}</span>
              </button>

              {/* Direct Admin Access Pill */}
              <button
                onClick={() => {
                  setCurrentView('admin');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="p-2.5 text-amber-300 bg-zinc-950 hover:bg-zinc-900 border border-[#D4AF37]/50 rounded-xl transition-colors shadow-sm"
                title={isAr ? 'لوحة تحكم الإدارة (عرض خاص للمستثمر)' : 'Admin Dashboard (Investor View)'}
              >
                <LayoutDashboard className="w-4 h-4 text-[#D4AF37]" />
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 xl:hidden">
              <button
                onClick={() => openRequestModalForService('medical_sector')}
                className="bg-gradient-to-r from-amber-400 to-amber-500 text-black text-xs font-bold px-3 py-2 rounded-lg"
              >
                {isAr ? 'اطلب خدمة' : 'Request'}
              </button>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-amber-400 hover:bg-zinc-900 transition-colors"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-zinc-950 border-b border-[#D4AF37]/30 px-4 pt-3 pb-6 shadow-2xl animate-in slide-in-from-top duration-200">
            <div className="flex flex-col space-y-2 mb-4">
              {navLinks.map(link => (
                <button
                  key={link.view}
                  onClick={() => {
                    setCurrentView(link.view);
                    setMobileMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                    currentView === link.view
                      ? 'bg-zinc-900 text-amber-300 font-bold border border-[#D4AF37]/40'
                      : 'text-zinc-300 hover:bg-zinc-900/60'
                  }`}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </button>
              ))}
            </div>

            {/* Quick Track Input in mobile menu */}
            <form onSubmit={handleQuickTrack} className="mb-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder={t.heroTrackInputPlaceholder}
                  value={trackingInput}
                  onChange={(e) => setTrackingInput(e.target.value)}
                  className="w-full text-xs px-3 py-2.5 rounded-xl bg-black border border-zinc-700 focus:outline-hidden focus:border-[#D4AF37] pr-9 text-white placeholder-zinc-500 font-mono"
                />
                <button type="submit" className="absolute right-2 top-2.5 text-amber-400">
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </form>

            <div className="flex flex-col gap-2 pt-2 border-t border-zinc-900">
              <button
                onClick={() => {
                  setCurrentView('admin');
                  setMobileMenuOpen(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full py-2.5 bg-black text-amber-300 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-[#D4AF37]/50"
              >
                <LayoutDashboard className="w-4 h-4 text-[#D4AF37]" />
                <span>{t.navAdmin} (عرض للمستثمر)</span>
              </button>

              <button
                onClick={() => {
                  setShowAuthModal(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 bg-zinc-900 text-zinc-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border border-zinc-800"
              >
                <UserCheck className="w-4 h-4 text-[#D4AF37]" />
                <span>{t.login} / {t.createAccount}</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Quick Search Modal */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-zinc-950 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#D4AF37]/40 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="font-bold text-white">
                  {isAr ? 'متابعة حالة طلب خدمة' : 'Track Your Request'}
                </h3>
              </div>
              <button onClick={() => setShowSearchModal(false)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400 mb-4">
              {isAr
                ? 'أدخل رقم الطلب التجريبي للتحقق من مرحلة التنسيق الطبي، المستشفى المعين، وجدول المواعيد.'
                : 'Enter your demo request code to track clinical matching, assigned hospital, and appointments.'}
            </p>
            <form onSubmit={handleQuickTrack} className="space-y-4">
              <div>
                <input
                  type="text"
                  value={trackingInput}
                  onChange={(e) => setTrackingInput(e.target.value)}
                  placeholder="ALM-REQ-7924"
                  className="w-full px-4 py-3 rounded-xl bg-black border border-zinc-700 text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] font-mono text-sm"
                  autoFocus
                />
                <div className="flex items-center justify-between mt-2 text-[11px] text-zinc-400">
                  <span>{isAr ? 'أرقام تجريبية جاهزة:' : 'Sample demo codes:'}</span>
                  <div className="space-x-1 rtl:space-x-reverse font-mono text-amber-400">
                    <button type="button" onClick={() => setTrackingInput('ALM-REQ-7924')} className="hover:underline">7924</button>
                    <span>•</span>
                    <button type="button" onClick={() => setTrackingInput('ALM-REQ-7925')} className="hover:underline">7925</button>
                    <span>•</span>
                    <button type="button" onClick={() => setTrackingInput('ALM-REQ-7926')} className="hover:underline">7926</button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold py-2.5 rounded-xl transition-colors text-sm"
                >
                  {isAr ? 'عرض بيانات الطلب' : 'View Request'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowSearchModal(false)}
                  className="px-4 py-2.5 border border-zinc-800 text-zinc-300 rounded-xl hover:bg-zinc-900 text-sm"
                >
                  {t.close}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Auth Demo Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-zinc-950 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#D4AF37]/40 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="font-bold text-white text-lg">
                  {isAr ? 'بوابة المرضى والمشرفين (محاكاة)' : 'Patient & Coordinator Portal'}
                </h3>
              </div>
              <button onClick={() => setShowAuthModal(false)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-3 bg-zinc-900/90 border border-[#D4AF37]/30 rounded-xl text-xs text-amber-200 mb-4">
              {isAr
                ? 'ملاحظة: هذا نموذج أولي تجريبي للعرض. يمكنك تسجيل الدخول المباشر كـ "مريض تجريبي" أو كـ "مشرف إدارة" دون الحاجة لكلمة مرور.'
                : 'Note: This is an interactive demo prototype. You can instantly sign in as a demo patient or administrator without passwords.'}
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setTrackingCode('ALM-REQ-7924');
                  setCurrentView('tracking');
                  setShowAuthModal(false);
                  showToast(isAr ? 'مرحباً بك في بوابة متابعة المريض' : 'Welcome to the patient follow-up portal');
                }}
                className="w-full py-3 px-4 bg-black hover:bg-zinc-900 border border-zinc-800 hover:border-[#D4AF37]/50 rounded-xl text-start transition-all group"
              >
                <div className="font-bold text-zinc-100 group-hover:text-amber-300 text-sm">
                  {isAr ? 'الدخول كـ "مريض" ومتابعة ملف الحالة' : 'Sign in as "Patient" (Demo Profile)'}
                </div>
                <div className="text-xs text-zinc-400 mt-0.5">
                  {isAr ? 'استعراض مواعيد الفحوصات، تقارير الأطباء، والمرافق' : 'Access appointments, coordinator updates & reports'}
                </div>
              </button>

              <button
                onClick={() => {
                  setCurrentView('admin');
                  setShowAuthModal(false);
                  showToast(isAr ? 'تم فتح لوحة تحكم الإدارة' : 'Admin dashboard opened');
                }}
                className="w-full py-3 px-4 bg-zinc-900 hover:bg-zinc-800 border border-[#D4AF37]/40 rounded-xl text-start transition-all group"
              >
                <div className="font-bold text-amber-300 text-sm flex items-center justify-between">
                  <span>{isAr ? 'الدخول كـ "مشرف تنسيق طبي" (لوحة الإدارة)' : 'Sign in as "Medical Coordinator / Admin"'}</span>
                  <span className="text-[10px] bg-[#D4AF37]/20 text-amber-300 px-2 py-0.5 rounded-full font-mono">VIP Demo</span>
                </div>
                <div className="text-xs text-zinc-400 mt-0.5">
                  {isAr ? 'إدارة الطلبات، الأطباء، المستشفيات، اللوجستيات، والمحاسبة' : 'Full system dashboard, requests, hospitals, compliance'}
                </div>
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-zinc-900 flex justify-end">
              <button
                onClick={() => setShowAuthModal(false)}
                className="px-4 py-2 text-xs font-semibold text-zinc-400 hover:text-white"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
