import React, { useState, useRef, useEffect } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Radio, 
  Sun, 
  Moon, 
  BarChart3, 
  LineChart, 
  Sparkles, 
  Mic, 
  Star, 
  Briefcase,
  ShieldCheck,
  Smartphone,
  Globe,
  ChevronDown,
  Check
} from 'lucide-react';
import { AudioSettings, AppTab, ThemeMode, AppLanguage } from '../types/market';
import { SUPPORTED_LANGUAGES, getTranslation } from '../i18n/translations';

interface NavbarProps {
  currentTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  audioSettings: AudioSettings;
  onUpdateAudioSettings: (settings: AudioSettings) => void;
  activeAlertsCount: number;
  watchlistCount: number;
  theme: ThemeMode;
  onToggleTheme: () => void;
  language: AppLanguage;
  onChangeLanguage: (lang: AppLanguage) => void;
  onOpenComplianceModal?: () => void;
  onOpenAndroidModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  audioSettings,
  onUpdateAudioSettings,
  activeAlertsCount,
  watchlistCount,
  theme,
  onToggleTheme,
  language,
  onChangeLanguage,
  onOpenComplianceModal,
  onOpenAndroidModal,
}) => {
  const isLight = theme === 'light';
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const langMenuRef = useRef<HTMLDivElement>(null);

  // Close language dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (langMenuRef.current && !langMenuRef.current.contains(event.target as Node)) {
        setIsLangMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLangMeta = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  const tabs: Array<{ id: AppTab; labelKey: string; icon: React.ComponentType<{ className?: string }>; badge?: number }> = [
    { id: 'marche', labelKey: 'tab_marche', icon: BarChart3 },
    { id: 'graph', labelKey: 'tab_graph', icon: LineChart },
    { id: 'iasignals', labelKey: 'tab_iasignals', icon: Sparkles },
    { id: 'alerte', labelKey: 'tab_alerte', icon: Mic, badge: activeAlertsCount },
    { id: 'watchlist', labelKey: 'tab_watchlist', icon: Star, badge: watchlistCount },
    { id: 'portfolio', labelKey: 'tab_portfolio', icon: Briefcase },
  ];

  const europeLanguages = SUPPORTED_LANGUAGES.filter((l) => l.region === 'europe');
  const arabLanguages = SUPPORTED_LANGUAGES.filter((l) => l.region === 'arab');

  return (
    <header className={`sticky top-0 z-40 border-b backdrop-blur-xl transition-colors duration-200 ${
      isLight 
        ? 'bg-white/90 border-slate-200 shadow-sm' 
        : 'bg-slate-950/85 border-slate-800/80 shadow-md shadow-black/20'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Live Status */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-emerald-400 p-[1px] shadow-lg shadow-amber-500/10">
              <div className={`w-full h-full rounded-[11px] flex items-center justify-center ${
                isLight ? 'bg-white' : 'bg-slate-950'
              }`}>
                <Radio className="w-5 h-5 text-amber-500 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`font-extrabold text-base tracking-tight font-['Chakra_Petch'] flex items-center gap-1.5 ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}>
                  TRADING FLOW <span className="text-amber-500">ALERTS</span>
                  <span className={`text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded border ${
                    isLight 
                      ? 'bg-amber-100 border-amber-300 text-amber-800' 
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  }`}>
                    {getTranslation(language, 'app_pro_tag', 'PRO NATIVE')}
                  </span>
                </span>
              </div>
              <div className={`flex items-center gap-1.5 text-[11px] font-mono ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                <span dangerouslySetInnerHTML={{ __html: getTranslation(language, 'live_feed', 'FLUX DIRECT &bull; TICK RÉEL') }} />
              </div>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <div className="hidden lg:flex items-center gap-1 p-1 rounded-2xl border bg-opacity-60 transition-colors">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.id;
              const label = getTranslation(language, tab.labelKey);
              return (
                <button
                  key={tab.id}
                  onClick={() => onSelectTab(tab.id)}
                  className={`relative flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? isLight
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                      : isLight
                      ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-emerald-500 text-slate-950">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Utility Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            
            {/* Android Native App Button */}
            {onOpenAndroidModal && (
              <button
                onClick={onOpenAndroidModal}
                className={`p-2 sm:px-2.5 sm:py-1.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold ${
                  isLight
                    ? 'bg-teal-50 border-teal-300 text-teal-800 hover:bg-teal-100 shadow-sm'
                    : 'bg-teal-500/10 border-teal-500/30 text-teal-400 hover:bg-teal-500/20 shadow-sm'
                }`}
                title={getTranslation(language, 'btn_android', 'Application Android')}
              >
                <Smartphone className="w-4 h-4 text-teal-500" />
                <span className="hidden md:inline font-mono text-[11px] font-bold">
                  {getTranslation(language, 'btn_android', 'App Android')}
                </span>
              </button>
            )}

            {/* Store Compliance & Legal Audit Button */}
            {onOpenComplianceModal && (
              <button
                onClick={onOpenComplianceModal}
                className={`p-2 sm:px-2.5 sm:py-1.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold ${
                  isLight
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100 shadow-sm'
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 shadow-sm'
                }`}
                title={getTranslation(language, 'btn_stores', 'Audit Stores')}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span className="hidden md:inline font-mono text-[11px] font-bold">
                  {getTranslation(language, 'btn_stores', 'Audit Stores')}
                </span>
              </button>
            )}

            {/* Day / Night Light Mode Toggle */}
            <button
              onClick={onToggleTheme}
              className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold ${
                isLight
                  ? 'bg-slate-100 border-slate-300 text-amber-700 hover:bg-slate-200'
                  : 'bg-slate-900 border-slate-800 text-amber-300 hover:border-slate-700'
              }`}
              title={isLight ? getTranslation(language, 'mode_night', 'Nuit') : getTranslation(language, 'mode_day', 'Jour')}
            >
              {isLight ? (
                <>
                  <Sun className="w-4 h-4 text-amber-500" />
                  <span className="hidden sm:inline text-slate-700 text-[11px]">{getTranslation(language, 'mode_day', 'Jour')}</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-400" />
                  <span className="hidden sm:inline text-slate-300 text-[11px]">{getTranslation(language, 'mode_night', 'Nuit')}</span>
                </>
              )}
            </button>

            {/* Master Sound Mute/Unmute */}
            <button
              onClick={() => {
                onUpdateAudioSettings({
                  ...audioSettings,
                  masterSoundEnabled: !audioSettings.masterSoundEnabled,
                });
              }}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                audioSettings.masterSoundEnabled
                  ? isLight
                    ? 'bg-emerald-100 border-emerald-300 text-emerald-800'
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                  : isLight
                  ? 'bg-rose-100 border-rose-300 text-rose-800'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20'
              }`}
              title={audioSettings.masterSoundEnabled ? getTranslation(language, 'sound_active', 'Son actif') : getTranslation(language, 'sound_muted', 'Son muet')}
            >
              {audioSettings.masterSoundEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            {/* Multilingual Selector Dropdown (Europe & Arab) */}
            <div className="relative" ref={langMenuRef}>
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className={`px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                  isLight
                    ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 shadow-sm'
                }`}
                title={getTranslation(language, 'choose_language', 'Changer la langue')}
                aria-expanded={isLangMenuOpen}
              >
                <span className="text-sm leading-none">{currentLangMeta.flag}</span>
                <span className="font-mono text-xs font-bold uppercase">{currentLangMeta.code}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 opacity-60 ${isLangMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {isLangMenuOpen && (
                <div className={`absolute right-0 mt-2 w-56 rounded-2xl border shadow-2xl p-2 z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 ${
                  isLight 
                    ? 'bg-white/95 border-slate-200 text-slate-900' 
                    : 'bg-slate-900/95 border-slate-800 text-slate-100'
                }`}>
                  {/* European Languages Section */}
                  <div className="px-2 py-1.5 text-[10px] font-bold tracking-wider uppercase text-slate-400 flex items-center gap-1.5 border-b border-slate-700/20 pb-1 mb-1">
                    <span>🇪🇺</span>
                    <span>{getTranslation(language, 'european_languages', 'Langues Européennes')}</span>
                  </div>
                  <div className="space-y-0.5">
                    {europeLanguages.map((item) => {
                      const isSelected = item.code === language;
                      return (
                        <button
                          key={item.code}
                          onClick={() => {
                            onChangeLanguage(item.code);
                            setIsLangMenuOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer text-left ${
                            isSelected
                              ? isLight 
                                ? 'bg-amber-100 text-amber-900 font-bold' 
                                : 'bg-amber-500/20 text-amber-300 font-bold'
                              : isLight 
                                ? 'hover:bg-slate-100 text-slate-700' 
                                : 'hover:bg-slate-800 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">{item.flag}</span>
                            <span>{item.nativeName}</span>
                            <span className="text-[10px] opacity-60 font-mono">({item.code.toUpperCase()})</span>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-500" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Arab Languages Section */}
                  <div className="px-2 py-1.5 text-[10px] font-bold tracking-wider uppercase text-slate-400 flex items-center gap-1.5 border-b border-slate-700/20 pb-1 mt-2 mb-1">
                    <span>🌍</span>
                    <span>{getTranslation(language, 'arab_languages', 'Langues Arabes')}</span>
                  </div>
                  <div className="space-y-0.5">
                    {arabLanguages.map((item) => {
                      const isSelected = item.code === language;
                      return (
                        <button
                          key={item.code}
                          onClick={() => {
                            onChangeLanguage(item.code);
                            setIsLangMenuOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer text-left ${
                            isSelected
                              ? isLight 
                                ? 'bg-amber-100 text-amber-900 font-bold' 
                                : 'bg-amber-500/20 text-amber-300 font-bold'
                              : isLight 
                                ? 'hover:bg-slate-100 text-slate-700' 
                                : 'hover:bg-slate-800 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">{item.flag}</span>
                            <span className="font-semibold">{item.nativeName}</span>
                            <span className="text-[10px] opacity-60 font-mono">({item.name})</span>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-500" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </header>
  );
};
