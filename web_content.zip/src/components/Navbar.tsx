import React, { useState } from "react";
import {
  ChevronDown,
  Menu as MenuIcon,
  X,
  Sparkles,
  MessageSquare,
  Clock,
  MapPin,
  Phone,
  Compass,
} from "lucide-react";
import { MenuCategory } from "../types";
import { MenuMegaPanel } from "./MenuMegaPanel";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

interface NavbarProps {
  categories: MenuCategory[];
  onOpenMenu: (categorySlug?: string) => void;
  onOpenImport: () => void;
  onOpenConcierge: () => void;
  onOpenStudio: () => void;
  onOrderOnline: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  categories,
  onOpenMenu,
  onOpenImport,
  onOpenConcierge,
  onOpenStudio,
  onOrderOnline,
}) => {
  const [isMegaPanelOpen, setIsMegaPanelOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    setIsMegaPanelOpen(false);
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-40 bg-[#F4F0E7]/90 backdrop-blur-md border-b border-[#D8D0C2]/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 sm:h-20 flex items-center justify-between">
        {/* Left / Brand Logo */}
        <a
          href="#"
          className="group flex flex-col cursor-pointer select-none"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <span className="font-serif text-lg sm:text-2xl md:text-3xl tracking-[0.14em] sm:tracking-[0.18em] text-[#17201C] font-normal leading-none">
            KAL O R E E Z
          </span>
          <span className="text-[7.5px] sm:text-[9px] font-sans tracking-[0.25em] sm:tracking-[0.3em] uppercase text-[#17201C]/60 mt-1">
            THE WHOLESOME EATERY · VIZAG
          </span>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8">
          {/* PRIMARY MENU INTERACTIVE CONTROL */}
          <div
            className="relative"
            onMouseEnter={() => setIsMegaPanelOpen(true)}
          >
            <button
              type="button"
              onClick={() => onOpenMenu("all")}
              className="inline-flex items-center gap-1.5 text-xs font-medium tracking-[0.2em] uppercase text-[#17201C] hover:text-[#9BAF82] transition-colors py-2 cursor-pointer"
            >
              <span>MENU</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  isMegaPanelOpen ? "rotate-180 text-[#9BAF82]" : "text-[#17201C]/50"
                }`}
              />
            </button>
          </div>

          <button
            type="button"
            onClick={() => scrollToSection("philosophy")}
            className="text-xs font-medium tracking-[0.2em] uppercase text-[#17201C]/80 hover:text-[#17201C] transition-colors cursor-pointer"
          >
            OUR STORY
          </button>

          <button
            type="button"
            onClick={() => scrollToSection("space")}
            className="text-xs font-medium tracking-[0.2em] uppercase text-[#17201C]/80 hover:text-[#17201C] transition-colors cursor-pointer"
          >
            THE SPACE
          </button>

          <button
            type="button"
            onClick={() => scrollToSection("journal")}
            className="text-xs font-medium tracking-[0.2em] uppercase text-[#17201C]/80 hover:text-[#17201C] transition-colors cursor-pointer"
          >
            JOURNAL
          </button>

          <button
            type="button"
            onClick={() => scrollToSection("visit")}
            className="text-xs font-medium tracking-[0.2em] uppercase text-[#17201C]/80 hover:text-[#17201C] transition-colors cursor-pointer"
          >
            VISIT & MAP
          </button>
        </nav>

        {/* Right CTA Actions (Desktop) */}
        <div className="hidden lg:flex items-center gap-3">
          {/* Direct Call Symbol Button (Immediately places call) */}
          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            title={`Direct Call: ${RESTAURANT_INFO.phoneDisplay}`}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2] text-xs font-sans text-[#17201C] hover:border-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-all cursor-pointer group"
          >
            <Phone className="w-3.5 h-3.5 text-[#9BAF82] group-hover:text-[#9BAF82]" />
            <span className="font-mono text-[11px]">{RESTAURANT_INFO.phoneDisplay}</span>
          </a>

          <button
            type="button"
            onClick={onOpenConcierge}
            title="Ask Table Concierge & Nutrition Sommelier"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2] text-xs font-sans text-[#17201C]/80 hover:border-[#17201C] hover:bg-white transition-all cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5 text-[#9BAF82]" />
            <span>Concierge</span>
          </button>

          {/* Primary CTA */}
          <button
            type="button"
            onClick={onOrderOnline}
            className="px-5 py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium tracking-[0.18em] uppercase hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors cursor-pointer"
          >
            ORDER ONLINE
          </button>
        </div>

        {/* Mobile Header Quick Actions */}
        <div className="flex items-center gap-2 lg:hidden">
          {/* Direct Call Icon on Mobile (Immediately triggers phone dialer) */}
          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            title="Direct Call"
            aria-label="Direct Phone Call"
            className="w-9 h-9 rounded-full bg-[#FDFBF7] border border-[#D8D0C2] flex items-center justify-center text-[#17201C] active:scale-95 transition-transform"
          >
            <Phone className="w-4 h-4 text-[#9BAF82]" />
          </a>

          <button
            type="button"
            onClick={() => onOpenMenu("all")}
            className="px-3 py-1.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-[11px] font-medium tracking-wider uppercase active:scale-95 transition-transform"
          >
            VIEW MENU
          </button>

          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle Navigation"
            className="p-2 rounded-md text-[#17201C] hover:bg-[#D8D0C2]/30 transition-colors cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Desktop Mega-Panel */}
      <MenuMegaPanel
        categories={categories}
        isOpen={isMegaPanelOpen}
        onClose={() => setIsMegaPanelOpen(false)}
        onSelectCategory={(slug) => {
          setIsMegaPanelOpen(false);
          onOpenMenu(slug);
        }}
        onOpenImport={() => {
          setIsMegaPanelOpen(false);
          onOpenImport();
        }}
      />

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#FDFBF7] border-b border-[#D8D0C2] px-5 py-6 space-y-5 shadow-2xl animate-in slide-in-from-top-4 duration-200 max-h-[85vh] overflow-y-auto">
          {/* Direct Call Mobile Highlight */}
          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            className="flex items-center justify-between p-3.5 rounded-xs bg-[#17201C] text-[#F4F0E7] active:scale-98 transition-transform shadow-xs"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">
                <Phone className="w-4 h-4 text-[#9BAF82]" />
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-white/70">
                  Call Restaurant Directly
                </div>
                <div className="text-sm font-serif font-bold">
                  {RESTAURANT_INFO.phoneDisplay}
                </div>
              </div>
            </div>
            <span className="text-[11px] text-[#9BAF82] font-semibold uppercase tracking-wider">
              Dial Now 📞
            </span>
          </a>

          {/* Quick Restaurant Status Pill */}
          <div className="p-3 bg-[#F4F0E7] rounded-xs border border-[#D8D0C2]/70 flex items-center justify-between text-xs font-sans text-[#17201C]/80">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#9BAF82]" />
              <span>Dine-in: 7:30 AM – 10:00 PM</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-[#9BAF82] font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
              <span>Open Now</span>
            </div>
          </div>

          {/* Primary Action: View Menu */}
          <div>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenMenu("all");
              }}
              className="w-full text-left font-serif text-2xl text-[#17201C] border-b border-[#D8D0C2]/60 pb-2 flex items-center justify-between group"
            >
              <span>Explore Entire Menu</span>
              <span className="text-xs uppercase font-sans tracking-widest text-[#9BAF82] group-hover:translate-x-1 transition-transform">
                Open ({categories.length} Sections) →
              </span>
            </button>

            {/* Quick Category Chips for Fast Mobile Navigation */}
            <div className="mt-3">
              <div className="text-[10px] tracking-widest uppercase text-[#17201C]/50 font-semibold mb-2">
                Quick Category Jump
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-sans">
                {categories.slice(0, 8).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onOpenMenu(cat.id);
                    }}
                    className="p-2 text-left rounded-xs bg-[#F4F0E7]/60 hover:bg-[#EAE4D7] border border-[#D8D0C2]/50 text-[#17201C] flex items-center justify-between"
                  >
                    <span className="truncate pr-1">{cat.name}</span>
                    <span className="text-[10px] text-[#17201C]/40 font-mono">({cat.dishes.length})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Website Navigation Links */}
          <div className="pt-2 border-t border-[#D8D0C2]/50 space-y-2.5">
            <button
              onClick={() => scrollToSection("visit")}
              className="w-full text-left font-sans text-xs tracking-wider uppercase text-[#17201C]/80 hover:text-[#17201C] py-1 flex items-center justify-between font-semibold text-[#B96D52]"
            >
              <span>📍 Real-Time Google Maps & Directions</span>
              <span className="text-xs text-[#9BAF82]">→</span>
            </button>
            <button
              onClick={() => scrollToSection("philosophy")}
              className="w-full text-left font-sans text-xs tracking-wider uppercase text-[#17201C]/80 hover:text-[#17201C] py-1 flex items-center justify-between"
            >
              <span>Our Story & Philosophy</span>
              <span className="text-xs text-[#9BAF82]">→</span>
            </button>
            <button
              onClick={() => scrollToSection("space")}
              className="w-full text-left font-sans text-xs tracking-wider uppercase text-[#17201C]/80 hover:text-[#17201C] py-1 flex items-center justify-between"
            >
              <span>The Space & Atmosphere</span>
              <span className="text-xs text-[#9BAF82]">→</span>
            </button>
            <button
              onClick={() => scrollToSection("nutrition")}
              className="w-full text-left font-sans text-xs tracking-wider uppercase text-[#17201C]/80 hover:text-[#17201C] py-1 flex items-center justify-between"
            >
              <span>Transparent Nutrition Ledger</span>
              <span className="text-xs text-[#9BAF82]">→</span>
            </button>
          </div>

          {/* Concierge & Order CTA */}
          <div className="pt-3 border-t border-[#D8D0C2]/70 space-y-2">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenConcierge();
              }}
              className="w-full p-2.5 rounded-xs border border-[#D8D0C2] text-xs font-sans text-center flex items-center justify-center gap-2 bg-[#FDFBF7]"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#9BAF82]" />
              <span>Ask Table Concierge & Nutrition Sommelier</span>
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOrderOnline();
              }}
              className="w-full py-3 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-semibold tracking-widest uppercase text-center active:scale-98 transition-transform"
            >
              Order Online / Table Reservation
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
