import React from 'react';
import { ActiveTab, StudentProfile } from '../types';
import {
  Camera,
  FileText,
  BookMarked,
  SpellCheck,
  LayoutDashboard,
  Clock,
  Flame,
  UserCheck,
  History,
  GraduationCap
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  profile: StudentProfile;
  onOpenProfile: () => void;
  onOpenTimer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  profile,
  onOpenProfile,
  onOpenTimer,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'snap-solve', label: 'Snap & Solve', icon: <Camera className="w-4 h-4" />, badge: 'AI Vision' },
    { id: 'paragraph', label: 'Paragraphs', icon: <FileText className="w-4 h-4" /> },
    { id: 'essay', label: 'Essays', icon: <BookMarked className="w-4 h-4" /> },
    { id: 'grammar', label: 'Grammar Checker', icon: <SpellCheck className="w-4 h-4" />, badge: 'Live' },
    { id: 'history', label: 'Notebook', icon: <History className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('dashboard')}
              className="flex items-center gap-2.5 text-left group transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-slate-900 tracking-tight text-lg flex items-center gap-1.5">
                  StudySnap <span className="text-xs px-1.5 py-0.5 rounded-md bg-blue-100 text-blue-700 font-bold uppercase tracking-wider">AI</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium block truncate max-w-[140px] sm:max-w-xs">
                  {profile.schoolName}
                </span>
              </div>
            </button>
          </div>

          {/* Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/80 p-1 rounded-2xl border border-slate-200/60">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    isActive
                      ? 'bg-white text-blue-700 shadow-xs border border-slate-200/40'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1 py-0.2 rounded font-extrabold tracking-tight uppercase ${
                        isActive ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Pomodoro Timer button */}
            <button
              onClick={onOpenTimer}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition cursor-pointer"
              title="Open Focus Timer"
            >
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">Focus Timer</span>
            </button>

            {/* Streak Counter */}
            <div
              className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-50 border border-amber-200/60 text-amber-700 rounded-xl text-xs font-bold shadow-2xs"
              title="Daily Study Streak"
            >
              <Flame className="w-4 h-4 fill-amber-500 text-amber-500 animate-pulse" />
              <span>{profile.studyStreakDays}d</span>
            </div>

            {/* Student Profile Quick View & Edit */}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 pl-2 pr-3 py-1 bg-white hover:bg-blue-50/50 border border-slate-200 rounded-2xl shadow-2xs transition group text-left cursor-pointer"
              title="Click to change grade, name, or school"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-100 border border-blue-200 flex items-center justify-center text-lg shadow-2xs group-hover:scale-105 transition">
                {profile.avatar}
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1 leading-tight">
                  <span className="truncate max-w-[90px]">{profile.name}</span>
                  <UserCheck className="w-3 h-3 text-emerald-500" />
                </div>
                <div className="text-[10px] text-blue-600 font-semibold truncate max-w-[100px]">
                  {profile.grade}
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
