import React, { useState } from 'react';
import { Brain, Sparkles, HeartHandshake, ShieldCheck, LogOut, Menu, X, CheckCircle2, User } from 'lucide-react';

interface NavbarProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  currentUserEmail: string | null;
  isAdmin: boolean;
  onLogout: () => void;
  onOpenAdminAuth: () => void;
  onOpenSupport: () => void;
  onOpenDownloadModal: () => void;
  apiConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  currentUserEmail,
  isAdmin,
  onLogout,
  onOpenAdminAuth,
  onOpenSupport,
  onOpenDownloadModal,
  apiConnected,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white shadow-lg sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex justify-between items-center h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <Brain className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white">ProQuiz</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-400 text-blue-950">
                  AI Test
                </span>
              </div>
              <p className="text-[11px] text-blue-100 hidden sm:block">विषयानुसार मॉक टेस्ट एवं प्रतियोगी परीक्षा तैयारी</p>
            </div>
          </div>

          {/* Center Status Badge - Highlights API Connection */}
          <div className="hidden md:flex items-center">
            <div
              className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border backdrop-blur-sm ${
                apiConnected
                  ? 'bg-emerald-500/20 text-emerald-200 border-emerald-400/40 shadow-sm'
                  : 'bg-amber-500/20 text-amber-200 border-amber-400/40'
              }`}
              title="Google Gemini AI API automatically configured on the server"
            >
              <span className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${apiConnected ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${apiConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
              </span>
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{apiConnected ? 'Gemini AI API सक्रिय (Active)' : 'AI Connecting...'}</span>
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={() => onNavigate('home')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentScreen === 'home'
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-blue-100 hover:bg-white/10 hover:text-white'
              }`}
            >
              सभी विषय (Subjects)
            </button>

            <button
              onClick={onOpenDownloadModal}
              className="px-3 py-1.5 rounded-lg text-sm font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 transition flex items-center gap-1.5 shadow-xs"
              title="टेस्ट पेपर्स, PDF व डेटा फाइल डाउनलोड करें"
            >
              <span className="text-sm">📥</span>
              <span>फाइल डाउनलोड</span>
            </button>

            <button
              onClick={onOpenDownloadModal}
              className="px-3 py-1.5 rounded-lg text-sm font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 transition flex items-center gap-1.5 shadow-xs"
              title="टेस्ट पेपर्स, PDF व डेटा फाइल डाउनलोड करें"
            >
              <span className="text-sm">📥</span>
              <span>फाइल डाउनलोड</span>
            </button>

            <button
              onClick={onOpenSupport}
              className="px-3 py-1.5 rounded-lg text-sm font-medium text-blue-100 hover:bg-white/10 hover:text-white transition flex items-center gap-1.5"
            >
              <HeartHandshake className="w-4 h-4 text-pink-300" />
              <span>Support (UPI)</span>
            </button>

            {isAdmin ? (
              <button
                onClick={() => onNavigate('admin')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-1.5 ${
                  currentScreen === 'admin'
                    ? 'bg-white text-blue-900 shadow-md font-semibold'
                    : 'bg-amber-400/90 text-blue-950 hover:bg-amber-400 font-semibold'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-blue-800" />
                <span>Admin Dashboard</span>
              </button>
            ) : (
              <button
                onClick={onOpenAdminAuth}
                className="px-3 py-1.5 rounded-lg text-xs text-blue-200 hover:text-white hover:bg-white/10 transition flex items-center gap-1"
                title="प्रशासक लॉगिन"
              >
                <ShieldCheck className="w-3.5 h-3.5 opacity-80" />
                <span>Admin</span>
              </button>
            )}

            {currentUserEmail ? (
              <div className="flex items-center gap-2 pl-2 border-l border-white/20">
                <span className="text-xs text-blue-100 font-mono bg-blue-900/40 px-2 py-1 rounded max-w-[130px] truncate" title={currentUserEmail}>
                  {currentUserEmail}
                </span>
                <button
                  onClick={onLogout}
                  className="p-1.5 rounded-lg text-blue-200 hover:text-red-300 hover:bg-white/10 transition"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => onNavigate('login')}
                className="px-3 py-1.5 rounded-lg text-sm font-medium bg-white text-blue-700 hover:bg-blue-50 transition shadow-sm"
              >
                Login
              </button>
            )}
          </div>

          {/* Mobile menu trigger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-blue-100 hover:bg-white/10 hover:text-white focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-blue-900/95 border-t border-blue-800 px-4 pt-3 pb-5 space-y-3 backdrop-blur-md">
          {/* API Status badge in mobile */}
          <div className="flex items-center justify-between p-2.5 rounded-lg bg-blue-950/60 border border-blue-800 text-xs">
            <span className="text-blue-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> AI Engine
            </span>
            <span className="text-emerald-300 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> API Connected
            </span>
          </div>

          <div className="grid grid-cols-1 gap-1">
            <button
              onClick={() => {
                onNavigate('home');
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-white hover:bg-white/10"
            >
              सभी विषय (Subjects)
            </button>
            <button
              onClick={() => {
                onOpenDownloadModal();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold text-emerald-300 hover:bg-white/10 flex items-center gap-2"
            >
              <span>📥</span> फाइल डाउनलोड (PDF, JSON, App)
            </button>
            <button
              onClick={() => {
                onOpenSupport();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-white hover:bg-white/10 flex items-center gap-2"
            >
              <HeartHandshake className="w-4 h-4 text-pink-300" /> Support via UPI
            </button>
            <button
              onClick={() => {
                if (isAdmin) {
                  onNavigate('admin');
                } else {
                  onOpenAdminAuth();
                }
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-amber-300 hover:bg-white/10 flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" /> Admin Panel
            </button>
          </div>

          {currentUserEmail ? (
            <div className="pt-2 border-t border-blue-800 flex items-center justify-between text-xs text-blue-200">
              <div className="flex items-center gap-2 truncate">
                <User className="w-4 h-4 text-blue-300" />
                <span className="truncate">{currentUserEmail}</span>
              </div>
              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="text-red-300 hover:text-red-200 font-semibold flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" /> Logout
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                onNavigate('login');
                setMobileMenuOpen(false);
              }}
              className="w-full py-2 bg-white text-blue-900 font-semibold rounded-lg text-sm text-center shadow"
            >
              Login / Register
            </button>
          )}
        </div>
      )}
    </nav>
  );
};
