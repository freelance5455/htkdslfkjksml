import React from 'react';
import { 
  Bot, 
  Scan, 
  NotebookPen, 
  AlarmClock, 
  Wrench, 
  Settings, 
  Volume2, 
  VolumeX, 
  Globe,
  Share2
} from 'lucide-react';
import { ActiveTab, SupportedLanguage } from '../types/assistant';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  language: SupportedLanguage;
  onToggleLanguage: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  language,
  onToggleLanguage,
  soundEnabled,
  onToggleSound,
}) => {
  const navTabs: Array<{ id: ActiveTab; labelBn: string; labelEn: string; icon: React.ReactNode }> = [
    { id: 'assistant', labelBn: 'অ্যাসিস্ট্যান্ট', labelEn: 'Assistant', icon: <Bot className="w-4 h-4" /> },
    { id: 'vision', labelBn: 'ভিশন এআই', labelEn: 'Vision AI', icon: <Scan className="w-4 h-4" /> },
    { id: 'social', labelBn: 'সোশ্যাল অটোমেশন', labelEn: 'App Automation', icon: <Share2 className="w-4 h-4 text-fuchsia-400" /> },
    { id: 'notes', labelBn: 'নোটস', labelEn: 'Notes', icon: <NotebookPen className="w-4 h-4" /> },
    { id: 'reminders', labelBn: 'রিমাইন্ডার', labelEn: 'Reminders', icon: <AlarmClock className="w-4 h-4" /> },
    { id: 'tools', labelBn: 'টুলস', labelEn: 'Tools', icon: <Wrench className="w-4 h-4" /> },
    { id: 'settings', labelBn: 'সেটিংস', labelEn: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#050811]/90 backdrop-blur-md border-b border-cyan-900/30">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Brand identity */}
        <div 
          onClick={() => onTabChange('assistant')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-fuchsia-600 p-0.5 shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] overflow-hidden flex items-center justify-center">
              <img
                src="/assets/ic_launcher_brand.png"
                alt="Rubel Boss AI"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-orbitron font-extrabold text-sm sm:text-base tracking-wider bg-gradient-to-r from-cyan-300 via-white to-fuchsia-400 bg-clip-text text-transparent">
                RUBEL BOSS AI
              </span>
              <span className="hidden sm:inline-block text-[9px] font-mono-tech px-1.5 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-500/30 rounded">
                v2.5
              </span>
            </div>
            <p className="text-[10px] text-slate-400 tracking-tight hidden sm:block">
              Holographic Personal Intelligence
            </p>
          </div>
        </div>

        {/* Center Navigation Tabs (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-950/80 p-1 rounded-2xl border border-slate-800">
          {navTabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-600/30 to-fuchsia-600/30 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                {tab.icon}
                <span>{language === 'bn' ? tab.labelBn : tab.labelEn}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Action Controls: Language, Sound, Settings */}
        <div className="flex items-center gap-2">
          {/* Sound FX Switch */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute Sound FX' : 'Enable Sound FX'}
            className={`p-2 rounded-xl border text-xs font-mono-tech transition-all flex items-center justify-center ${
              soundEnabled
                ? 'bg-slate-900/90 border-cyan-500/40 text-cyan-400 hover:bg-slate-800'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLanguage}
            title="Toggle Language"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 border border-fuchsia-500/40 text-fuchsia-300 hover:bg-slate-800 text-xs font-mono-tech transition-all shadow-sm"
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="font-semibold">{language === 'bn' ? 'বাংলা' : 'EN'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Subnav scrollable tabs */}
      <div className="lg:hidden flex items-center gap-1.5 px-3 py-2 overflow-x-auto no-scrollbar border-t border-slate-900 bg-slate-950/60">
        {navTabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800/80'
              }`}
            >
              {tab.icon}
              <span>{language === 'bn' ? tab.labelBn : tab.labelEn}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
