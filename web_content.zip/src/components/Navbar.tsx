import React, { useState } from 'react';
import { Volume2, VolumeX, Star, Sparkles, MessageCircle, Video, Award, User, Check, Edit2, Download } from 'lucide-react';
import { sound } from '../utils/sound';
import { LearningCategory } from '../types/curriculum';

interface NavbarProps {
  childName: string;
  onUpdateChildName: (newName: string) => void;
  starsCount: number;
  activeTab: LearningCategory;
  onSelectTab: (tab: LearningCategory) => void;
  onOpenChat: () => void;
  onOpenVideo: () => void;
  onOpenCertificate: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  childName,
  onUpdateChildName,
  starsCount,
  activeTab,
  onSelectTab,
  onOpenChat,
  onOpenVideo,
  onOpenCertificate,
}) => {
  const [isMuted, setIsMuted] = useState(sound.getMuted());
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(childName);

  const toggleMute = () => {
    const nextMuted = !isMuted;
    sound.setMuted(nextMuted);
    setIsMuted(nextMuted);
    if (!nextMuted) {
      sound.playPopSound();
    }
  };

  const handleSaveName = () => {
    if (tempName.trim()) {
      onUpdateChildName(tempName.trim());
      sound.playSuccessSound();
    }
    setIsEditingName(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-amber-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-2.5 sm:py-3">
        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Logo & Child Name Badge */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-xl shadow-md text-white">
              🧸
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-urdu text-lg sm:text-xl font-black text-amber-950 leading-tight">
                  ارہان کی جادوئی کلاس
                </h1>

                {/* Child Name Switcher */}
                {isEditingName ? (
                  <div className="flex items-center gap-1 bg-amber-50 p-0.5 rounded-lg border border-amber-300">
                    <input
                      type="text"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
                      className="font-urdu text-xs font-bold text-amber-950 px-2 py-0.5 w-24 bg-white rounded border border-amber-200 outline-none"
                      autoFocus
                    />
                    <button
                      onClick={handleSaveName}
                      className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700 cursor-pointer"
                    >
                      <Check className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setTempName(childName);
                      setIsEditingName(true);
                    }}
                    className="inline-flex items-center gap-1 bg-amber-100 hover:bg-amber-200 text-amber-900 px-2.5 py-0.5 rounded-full text-xs font-bold transition-all cursor-pointer border border-amber-200"
                    title="نام تبدیل کریں"
                  >
                    <User className="w-3 h-3 text-amber-700" />
                    <span>پیارے {childName}</span>
                    <Edit2 className="w-2.5 h-2.5 opacity-60" />
                  </button>
                )}
              </div>
              <p className="text-[11px] text-amber-700 font-sans">
                Arhan's AI Learning Companion
              </p>
            </div>
          </div>

          {/* Right Tools: Stars, Sound, Chat, Video */}
          <div className="flex items-center gap-2">
            {/* Stars Counter */}
            <div className="flex items-center gap-1 bg-gradient-to-r from-amber-100 to-yellow-100 border border-amber-300 px-3 py-1.5 rounded-2xl shadow-xs">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500 animate-pulse-gentle" />
              <span className="font-extrabold text-amber-900 text-sm">{starsCount}</span>
              <span className="font-urdu text-xs text-amber-800 font-bold hidden sm:inline">ستارے</span>
            </div>

            {/* Mute Sound Button */}
            <button
              onClick={toggleMute}
              className={`p-2 rounded-2xl border transition-all cursor-pointer ${
                isMuted
                  ? 'bg-rose-50 border-rose-200 text-rose-600'
                  : 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800'
              }`}
              title={isMuted ? 'آواز کھولیں (Unmute)' : 'آواز بند کریں (Mute)'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* AI Chat trigger */}
            <button
              onClick={onOpenChat}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white rounded-2xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">میاں بھالو چیٹ</span>
              <span className="sm:hidden">چیٹ</span>
            </button>

            {/* Video Studio trigger */}
            <button
              onClick={onOpenVideo}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 hover:bg-purple-700 active:scale-95 text-white rounded-2xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <Video className="w-3.5 h-3.5 text-pink-200" />
              <span className="hidden sm:inline">ویڈیو اسٹوڈیو</span>
              <span className="sm:hidden">ویڈیو</span>
            </button>

            {/* Download Project ZIP button */}
            <a
              href="/api/download-zip"
              download="arhan-ai-learning-app.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 active:scale-95 text-white rounded-2xl text-xs font-bold transition-all shadow-sm cursor-pointer"
              title="مکمل پروجیکٹ کوڈ زپ ڈاؤنلوڈ کریں"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">ZIP ڈاؤنلوڈ</span>
              <span className="sm:hidden">ZIP</span>
            </a>
          </div>
        </div>

        {/* Tab Navigation: Urdu, English, Math */}
        <div className="mt-3 pt-2 border-t border-amber-100 flex items-center justify-center sm:justify-start gap-2 overflow-x-auto">
          <button
            onClick={() => {
              sound.playPopSound();
              onSelectTab('urdu');
            }}
            className={`font-urdu px-4 py-1.5 rounded-2xl text-sm font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'urdu'
                ? 'bg-rose-500 text-white shadow-md ring-2 ring-rose-300'
                : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200'
            }`}
          >
            <span>الف بے تے (Urdu)</span>
            <span className="text-base">🦋</span>
          </button>

          <button
            onClick={() => {
              sound.playPopSound();
              onSelectTab('english');
            }}
            className={`font-fun px-4 py-1.5 rounded-2xl text-sm font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'english'
                ? 'bg-sky-500 text-white shadow-md ring-2 ring-sky-300'
                : 'bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200'
            }`}
          >
            <span>ABC Phonics (English)</span>
            <span className="text-base">🍎</span>
          </button>

          <button
            onClick={() => {
              sound.playPopSound();
              onSelectTab('math');
            }}
            className={`font-urdu px-4 py-1.5 rounded-2xl text-sm font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'math'
                ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-300'
                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
            }`}
          >
            <span>گنتی 123 (Counting)</span>
            <span className="text-base">🔢</span>
          </button>
        </div>
      </div>
    </header>
  );
};
