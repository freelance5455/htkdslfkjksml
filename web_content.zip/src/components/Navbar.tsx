import React, { useState, useEffect } from 'react';
import { Tv, Radio, Flame, Search, Clock, Shield, Sparkles, Link2, Download, Smartphone } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

interface NavbarProps {
  activeTab: 'matches' | 'channels' | 'highlights';
  setActiveTab: (tab: 'matches' | 'channels' | 'highlights') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenCustomStream: () => void;
  onOpenApkModal?: () => void;
  liveMatchesCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  onOpenCustomStream,
  onOpenApkModal,
  liveMatchesCount,
}) => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('ar-SA', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#0c101a]/95 backdrop-blur-md border-b border-slate-200 dark:border-rose-950/40 shadow-sm dark:shadow-xl dark:shadow-black/40 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 gap-4">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="relative group cursor-pointer" onClick={() => setActiveTab('matches')}>
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-600 via-red-600 to-rose-800 flex items-center justify-center shadow-lg shadow-rose-600/30 border border-rose-400/30">
                <Tv className="w-6 h-6 text-white transform group-hover:scale-110 transition-transform" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-500 border-2 border-white dark:border-[#0c101a]"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white font-['Changa',sans-serif]">
                  IRAQI <span className="text-rose-600 dark:text-rose-500">LIVE</span>
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 text-[11px] font-bold bg-rose-600/10 dark:bg-rose-600/20 text-rose-600 dark:text-rose-400 border border-rose-500/20 dark:border-rose-500/30 rounded-full">
                  LIVE V4.2
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium hidden md:block">
                البث المباشر لمباريات اليوم بدون تقطيع وبجودة متعددة
              </p>
            </div>
          </div>

          {/* Search bar */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <input
                id="search-input"
                type="text"
                placeholder="ابحث عن فريق، دوري، أو معلق (مثال: ريال مدريد، الشوالي)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-100 dark:bg-[#141a29] border border-slate-200 dark:border-slate-700/60 rounded-xl py-2 pr-10 pl-4 text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 dark:hover:text-white"
                >
                  مسح
                </button>
              )}
            </div>
          </div>

          {/* Action buttons & Clock */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Theme Toggle (Automatic based on device time / Manual) */}
            <ThemeToggle />

            {/* Download / APK Button */}
            {onOpenApkModal && (
              <button
                id="apk-download-btn"
                onClick={onOpenApkModal}
                title="تنزيل التطبيق APK أو تثبيته على الهاتف"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md shadow-emerald-950/20 transition-all active:scale-95 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">تثبيت APK</span>
              </button>
            )}

            {/* Custom M3U8 Tester Button */}
            <button
              id="custom-stream-btn"
              onClick={onOpenCustomStream}
              title="تشغيل رابط بث خاص M3U8"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700/70 transition-all hover:border-rose-500/40 cursor-pointer"
            >
              <Link2 className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400" />
              <span className="hidden lg:inline">بث مخصص</span>
            </button>

            {/* Mecca Clock */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-[#141a29] border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300">
              <Clock className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
              <span className="font-mono text-[11px] text-amber-600 dark:text-amber-300/90 font-bold">{time || '00:00:00'}</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">مكة</span>
            </div>

            {/* Live Matches Indicator */}
            {liveMatchesCount > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-600/15 dark:bg-rose-600/20 border border-rose-500/30 dark:border-rose-500/40 text-rose-600 dark:text-rose-400 text-xs font-bold animate-pulse">
                <Radio className="w-3.5 h-3.5" />
                <span>{liveMatchesCount} مباشر</span>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Search input */}
        <div className="pb-3 md:hidden">
          <div className="relative">
            <input
              id="mobile-search-input"
              type="text"
              placeholder="ابحث عن مباراة أو قناة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 dark:bg-[#141a29] border border-slate-200 dark:border-slate-700/60 rounded-xl py-2 pr-9 pl-3 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-400 focus:outline-none focus:border-rose-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* Primary Tabs */}
        <nav className="flex items-center gap-2 border-t border-slate-200 dark:border-slate-800/80 pt-2 pb-2.5 overflow-x-auto no-scrollbar">
          <button
            id="tab-matches"
            onClick={() => setActiveTab('matches')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'matches'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Tv className="w-4 h-4" />
            <span>جدول المباريات</span>
            {liveMatchesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white text-rose-600 font-extrabold">
                {liveMatchesCount}
              </span>
            )}
          </button>

          <button
            id="tab-channels"
            onClick={() => setActiveTab('channels')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'channels'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>قنوات IRAQI LIVE (beIN & SSC)</span>
          </button>

          <button
            id="tab-highlights"
            onClick={() => setActiveTab('highlights')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'highlights'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Flame className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>أهداف وملخصات</span>
          </button>

          <div className="mr-auto hidden sm:flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Shield className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
            <span>سيرفرات فائقة السرعة بدون تقطيع</span>
          </div>
        </nav>
      </div>
    </header>
  );
};

