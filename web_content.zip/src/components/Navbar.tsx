import React from 'react';
import { 
  Trophy, 
  Crosshair, 
  Smartphone, 
  ShieldAlert, 
  Users, 
  Zap, 
  Volume2, 
  VolumeX, 
  Flame,
  Award,
  Layers
} from 'lucide-react';
import { sounds } from '../utils/soundEffects';

export type TabType = 'scrims' | 'sensitivity' | 'hud' | 'armory' | 'combos' | 'roster' | 'trainer';

interface NavbarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  isMuted: boolean;
  setIsMuted: (muted: boolean) => void;
  roomId: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isMuted,
  setIsMuted,
  roomId
}) => {
  const tabs = [
    { id: 'scrims', label: 'Match Ops & Scrims', icon: Trophy, badge: 'Live FFWS' },
    { id: 'sensitivity', label: 'Sensitivity & DPI', icon: Crosshair, badge: '1-Tap' },
    { id: 'hud', label: 'Custom HUD Lab', icon: Smartphone, badge: 'Claw' },
    { id: 'armory', label: 'Weapon Armory & TTK', icon: ShieldAlert, badge: 'Meta' },
    { id: 'combos', label: 'Character Synergies', icon: Layers, badge: 'Combos' },
    { id: 'roster', label: 'Guild & Squad', icon: Users, badge: '5/5' },
    { id: 'trainer', label: 'Aim Reflex Trainer', icon: Zap, badge: 'Mini-Game' },
  ] as const;

  const handleTabClick = (tabId: TabType) => {
    sounds.playClick();
    setActiveTab(tabId);
  };

  const toggleSound = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sounds.setMuted(nextMuted);
    if (!nextMuted) {
      sounds.playHeadshot();
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#0d0f18]/95 backdrop-blur-md border-b border-orange-500/20">
      {/* Top Banner with Game Status */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Emblem */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-orange-600 via-amber-600 to-red-700 rounded-xl tactical-cut-sm shadow-lg shadow-orange-600/30">
            <Flame className="w-6 h-6 text-yellow-200 animate-pulse" />
            <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-black text-[9px] font-bold px-1.5 py-0.2 rounded font-rajdhani">
              PRO
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-heading text-lg sm:text-xl font-bold bg-gradient-to-r from-orange-400 via-amber-300 to-yellow-400 bg-clip-text text-transparent">
                FREE FIRE COMMAND PANEL
              </span>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 text-[10px] font-semibold bg-red-950/80 text-red-400 border border-red-500/30 rounded-full font-rajdhani">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping mr-1.5"></span>
                ESPORTS SERVER ACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Tournament Manager • Pro Drag Sensitivity • Custom HUD • Damage Lab
            </p>
          </div>
        </div>

        {/* Right utility indicators */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Room quick-view chip */}
          <div className="hidden lg:flex items-center gap-2 bg-[#141824] border border-orange-500/30 rounded-lg px-3 py-1.5 text-xs">
            <span className="text-slate-400">ROOM ID:</span>
            <span className="font-mono font-bold text-orange-400 tracking-wider">#{roomId}</span>
          </div>

          {/* Grandmaster Badge */}
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500/10 to-red-500/10 border border-amber-500/30 px-2.5 py-1 rounded-lg">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold font-rajdhani text-amber-300">GRANDMASTER</span>
          </div>

          {/* Sound FX Toggle */}
          <button
            onClick={toggleSound}
            title={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
            className="p-2 rounded-lg bg-[#141824] hover:bg-[#1f2537] text-slate-300 hover:text-orange-400 border border-slate-700/60 transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-orange-400" />}
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-none py-1.5 border-t border-slate-800/80">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id as TabType)}
                className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap rounded-lg transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-600/30 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#141824]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isActive
                        ? 'bg-black/30 text-yellow-200'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
