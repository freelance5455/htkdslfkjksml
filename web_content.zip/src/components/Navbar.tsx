import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Compass,
  Ticket,
  User,
  Home,
  Plus,
  Bell,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { PageType } from '../types';
import { motion } from 'motion/react';
import { EventraLogo } from './ui/EventraLogo';
import { triggerHaptic } from '../utils/haptics';

export const Navbar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    tickets,
    notifications,
    user,
  } = useApp();

  const activeTicketsCount = tickets.filter((t) => t.status === 'active').length;
  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;

  const navItems: { id: PageType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: 'Discover', icon: Home },
    { id: 'events', label: 'Events', icon: Compass },
    { id: 'dashboard', label: 'Host', icon: TrendingUp },
    { id: 'tickets', label: 'Passes', icon: Ticket },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <>
      {/* Sleek Glassmorphism Top Header (Pure Dark Mode) */}
      <div className="fixed top-3 left-0 right-0 z-40 flex justify-center px-4 pointer-events-none">
        <header className="pointer-events-auto h-12.5 px-3.5 sm:px-5 py-1.5 rounded-full bg-[#111317]/90 backdrop-blur-xl border border-[#1f2229] shadow-xl shadow-black/50 flex items-center justify-between gap-3 sm:gap-6 transition-all max-w-4xl w-full">
          {/* Brand Logo */}
          <button
            onClick={() => {
              triggerHaptic('selection');
              setCurrentPage('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 py-1 text-sm font-bold tracking-tight text-[#f4f4f6] hover:opacity-85 transition-opacity cursor-pointer shrink-0"
            aria-label="Eventra Home"
          >
            <EventraLogo size="sm" />
          </button>

          <div className="h-4 w-px bg-[#1f2229] hidden sm:block shrink-0" />

          {/* Desktop Navigation Segmented Pill */}
          <nav className="hidden md:flex items-center gap-1 p-0.5 bg-[#17191f] rounded-full border border-[#1f2229]">
            {navItems.map((item) => {
              const isActive = currentPage === item.id || (item.id === 'dashboard' && currentPage === 'create');
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    triggerHaptic('selection');
                    setCurrentPage(item.id);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={`relative px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer z-10 ${
                    isActive
                      ? 'text-white font-bold'
                      : 'text-[#9496a1] hover:text-[#f4f4f6]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="desktopNavActivePill"
                      className="absolute inset-0 bg-emerald-500 rounded-full shadow-sm -z-10"
                      transition={{ type: 'spring', stiffness: 500, damping: 38 }}
                    />
                  )}
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>

                  {item.id === 'tickets' && activeTicketsCount > 0 && (
                    <span className="w-4 h-4 rounded-full bg-white text-neutral-950 text-[10px] font-bold flex items-center justify-center font-mono ml-0.5">
                      {activeTicketsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Tools: Dedicated Notification Bell & User Avatar */}
          <div className="flex items-center gap-2">
            {/* Dedicated Notification Button in Top Header */}
            <button
              onClick={() => {
                triggerHaptic('selection');
                setCurrentPage('notifications');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`relative w-8.5 h-8.5 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                currentPage === 'notifications'
                  ? 'bg-emerald-500 text-white shadow-sm'
                  : 'bg-[#17191f] text-[#9496a1] hover:text-[#f4f4f6] border border-[#1f2229]'
              }`}
              title="Open Notifications"
              aria-label="Notification Center"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifsCount > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#111317]" />
              )}
            </button>

            {/* Profile Avatar Quick Link */}
            {user && (
              <button
                onClick={() => {
                  triggerHaptic('selection');
                  setCurrentPage('profile');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`w-8.5 h-8.5 rounded-full overflow-hidden border transition-all cursor-pointer ${
                  currentPage === 'profile'
                    ? 'border-emerald-500 ring-2 ring-emerald-500/30'
                    : 'border-[#1f2229] hover:border-emerald-500/50'
                }`}
                title={user.name}
              >
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-full h-full object-cover"
                />
              </button>
            )}
          </div>
        </header>
      </div>

      {/* Mobile Floating Bottom Bar - Strictly 5 Primary Tabs */}
      <div className="md:hidden fixed bottom-4 inset-x-4 z-40 flex justify-center pointer-events-none">
        <nav className="pointer-events-auto h-14 px-3 py-1.5 rounded-full bg-[#111317]/95 backdrop-blur-xl border border-[#1f2229] shadow-2xl shadow-black/70 flex items-center justify-around w-full max-w-sm">
          {navItems.map((item) => {
            const isActive = currentPage === item.id || (item.id === 'dashboard' && currentPage === 'create');
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  triggerHaptic('selection');
                  setCurrentPage(item.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`relative flex flex-col items-center justify-center w-12 h-11 rounded-full transition-all cursor-pointer ${
                  isActive
                    ? 'text-emerald-400 font-bold'
                    : 'text-[#9496a1] hover:text-[#f4f4f6]'
                }`}
                aria-label={item.label}
              >
                {isActive && (
                  <motion.div
                    layoutId="mobileNavActivePill"
                    className="absolute inset-0 bg-[#17191f] border border-[#1f2229] rounded-full -z-10"
                    transition={{ type: 'spring', stiffness: 500, damping: 38 }}
                  />
                )}
                <Icon className="w-4 h-4" />
                <span className="text-[10px] font-medium mt-0.5 tracking-tight">
                  {item.label}
                </span>

                {item.id === 'tickets' && activeTicketsCount > 0 && (
                  <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-emerald-500" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </>
  );
};
