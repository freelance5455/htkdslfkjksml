import React from 'react';
import { 
  Tv, 
  Wifi, 
  Download, 
  Lock, 
  Unlock, 
  Globe, 
  Calendar, 
  FileSpreadsheet, 
  Users, 
  Receipt, 
  CreditCard, 
  LayoutDashboard,
  Smartphone,
  Database
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  activeMonth: string;
  setActiveMonth: (month: string) => void;
  isLocked: boolean;
  setIsLocked: (locked: boolean) => void;
  onOpenUnlockModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  activeMonth,
  setActiveMonth,
  isLocked,
  setIsLocked,
  onOpenUnlockModal,
}) => {
  const t = translations[language];
  const { isInstallable, install, isInstalled } = usePWAInstall();

  // Generate selectable months for billing cycle
  const availableMonths = [
    { value: '2026-11', label: 'November 2026' },
    { value: '2026-10', label: 'October 2026' },
    { value: '2026-09', label: 'September 2026' },
    { value: '2026-08', label: 'August 2026' },
    { value: '2026-12', label: 'December 2026' },
  ];

  const navItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'customers', label: t.customers, icon: Users },
    { id: 'billing', label: t.billing, icon: Receipt },
    { id: 'payments', label: t.payments, icon: CreditCard },
    { id: 'sheets', label: t.googleSheets, icon: FileSpreadsheet },
    { id: 'apk', label: t.apkDownload, icon: Smartphone, highlight: true },
    { id: 'settings', label: t.settings, icon: Database },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 shadow-xl">
      {/* Top Bar: Brand, Language, Month, Install & Lock */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2">
          
          {/* Logo & Brand Name */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 p-0.5 shadow-lg shadow-cyan-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <div className="flex items-center justify-center text-cyan-400">
                  <Tv className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-xl tracking-tight text-white flex items-center gap-1.5">
                  <span>CCTV NETWORK</span>
                  <span className="text-cyan-400 font-black">CHAMPESWAR</span>
                </h1>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
                  ODISHA
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Right Controls: Month Selector, Language, PWA Install, Admin Lock */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Active Billing Month Picker */}
            <div className="relative flex items-center bg-slate-800/80 border border-slate-700 rounded-lg px-2 py-1 sm:px-3 sm:py-1.5 text-xs text-slate-200">
              <Calendar className="w-3.5 h-3.5 text-cyan-400 mr-1.5 hidden sm:inline" />
              <select
                value={activeMonth}
                onChange={(e) => setActiveMonth(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-100 outline-none cursor-pointer"
                title="Active Billing Month"
              >
                {availableMonths.map((m) => (
                  <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Language Selector (Trilingual: EN / ଓଡ଼ିଆ / हिंदी) */}
            <div className="flex items-center bg-slate-800/80 border border-slate-700 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded font-medium transition ${
                  language === 'en'
                    ? 'bg-cyan-600 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="English"
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('or')}
                className={`px-2 py-1 rounded font-medium transition lang-odia ${
                  language === 'or'
                    ? 'bg-cyan-600 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Odia (ଓଡ଼ିଆ)"
              >
                ଓଡ଼ିଆ
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2 py-1 rounded font-medium transition lang-hindi ${
                  language === 'hi'
                    ? 'bg-cyan-600 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Hindi (हिन्दी)"
              >
                हिंदी
              </button>
            </div>

            {/* PWA / WebAPK In-App Install Prompt */}
            {!isInstalled && isInstallable && (
              <button
                onClick={install}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-900/30 transition animate-pulse"
                title="Install CCTV Network Champeswar APK on Android Phone"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Install APK</span>
              </button>
            )}

            {/* Android Shortcut Icon on Mobile */}
            <button
              onClick={() => setActiveTab('apk')}
              className="sm:hidden p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 hover:bg-emerald-900"
              title="Android APK Center"
            >
              <Smartphone className="w-4 h-4" />
            </button>

            {/* Admin PIN Lock / Unlock Indicator */}
            {isLocked ? (
              <button
                onClick={onOpenUnlockModal}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 hover:bg-amber-500/30 text-xs font-bold transition"
                title="Click to Unlock Full Owner Controls"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Locked</span>
              </button>
            ) : (
              <button
                onClick={() => setIsLocked(true)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 text-xs font-medium transition"
                title="Lock Application"
              >
                <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}

          </div>
        </div>

        {/* Tab Navigation Menu */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 scrollbar-none border-t border-slate-800/80">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-900/30'
                    : item.highlight
                    ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60 hover:bg-emerald-900/60'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
