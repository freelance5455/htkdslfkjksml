import React from 'react';
import { Crown, Bookmark, Smartphone, Download } from 'lucide-react';

interface NavbarProps {
  savedCount: number;
  onOpenSaved: () => void;
  onOpenInstall: () => void;
  isFramed: boolean;
  onToggleFrame: () => void;
  backendOnline: boolean;
  isInstallable?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  savedCount,
  onOpenSaved,
  onOpenInstall,
  isFramed,
  onToggleFrame,
  backendOnline,
}) => {
  return (
    <header className="shrink-0 bg-[#140628]/95 backdrop-blur-md border-b border-[#d4af37]/25 px-4 py-3 sticky top-0 z-40">
      <div className="flex items-center justify-between">
        {/* Brand Crest & Title */}
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#fae48c] via-[#d4af37] to-[#8d6f1a] flex items-center justify-center shadow-[0_2px_12px_rgba(212,175,55,0.35)] text-[#16062c] font-black text-xl tracking-wider select-none transform transition-transform group-hover:scale-105">
              H
            </div>
            <Crown className="w-3.5 h-3.5 text-[#fae48c] absolute -top-1.5 -right-1 drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)] animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="royal-heading text-lg font-bold tracking-wider gold-gradient-text leading-tight">
                Handsome AI
              </h1>
              {backendOnline && (
                <span
                  title="Backend connected"
                  className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]"
                />
              )}
            </div>
            <p className="text-[10px] text-[#bda8d9] tracking-widest uppercase font-medium flex items-center gap-1">
              <span>Luxury Creative Intelligence</span>
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Frame Toggle (Desktop only) */}
          <button
            onClick={onToggleFrame}
            className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#200b3d] border border-[#d4af37]/30 text-xs text-[#fae48c] hover:bg-[#2c1054] transition-colors"
            title={isFramed ? 'Switch to Full Width' : 'Preview Android Mobile Frame'}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="text-[11px]">{isFramed ? 'Full Width' : 'Phone View'}</span>
          </button>

          {/* App Download / Install Action */}
          <button
            onClick={onOpenInstall}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#fae48c] via-[#d4af37] to-[#96761f] text-[#120422] hover:brightness-110 transition-all active:scale-95 shadow-[0_2px_10px_rgba(212,175,55,0.25)] font-bold text-xs"
            title="Download or Install Handsome AI"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="text-[11px] font-bold">App Download</span>
          </button>

          {/* Saved Vault */}
          <button
            onClick={onOpenSaved}
            className="relative flex items-center justify-center p-2 rounded-lg bg-[#200b3d] border border-[#d4af37]/30 text-[#fae48c] hover:bg-[#2c1054] transition-colors active:scale-95"
            title="Saved Vault"
          >
            <Bookmark className="w-4 h-4" />
            {savedCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#d4af37] text-[#120422] font-extrabold text-[10px] flex items-center justify-center shadow-md">
                {savedCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
