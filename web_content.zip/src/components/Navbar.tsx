import React from 'react';
import { ViewMode } from '../types';
import { useAuth } from '../context/AuthContext';
import { BookOpen, UploadCloud, Bookmark, LogIn, Users, User, Shield, Mail } from 'lucide-react';
import { SmartImage } from './SmartImage';

interface NavbarProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  onOpenBookmarks: () => void;
  onOpenAuthModal: () => void;
  onOpenProfileModal: () => void;
  onOpenInvitations?: () => void;
  bookmarksCount: number;
  pendingInvitationsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSelectView,
  onOpenBookmarks,
  onOpenAuthModal,
  onOpenProfileModal,
  onOpenInvitations,
  bookmarksCount,
  pendingInvitationsCount = 0
}) => {
  const { user, profile, isPublisher, isOwner, loading } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-[#0d121f]/95 backdrop-blur-md border-b border-purple-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo with HT Emblem */}
        <div 
          onClick={() => onSelectView('reader')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-700 via-violet-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-600/30 group-hover:scale-105 transition-transform">
            <span className="text-xl font-black text-white tracking-tighter">HT</span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg text-white tracking-tight">MANHWA HART</span>
              <span className="px-1.5 py-0.2 text-[9px] font-bold bg-pink-500/20 text-pink-400 rounded border border-pink-500/30">
                هارت
              </span>
            </div>
            <span className="text-[10px] text-gray-400 font-medium">المنصة الشاملة للمانهوا والمانجا والروايات</span>
          </div>
        </div>

        {/* View Switcher: قارئ / الفرق / ناشر */}
        <nav className="flex items-center bg-[#151b2d] p-1 rounded-xl border border-white/5">
          <button
            onClick={() => onSelectView('reader')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
              currentView === 'reader' || currentView === 'chapter-view'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-md shadow-purple-600/30'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>قارئ</span>
          </button>

          <button
            onClick={() => onSelectView('teams')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
              currentView === 'teams'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-md shadow-purple-600/30'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>الفرق</span>
          </button>

          <button
            onClick={() => onSelectView('publisher')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
              currentView === 'publisher'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-md shadow-purple-600/30'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <UploadCloud className="w-4 h-4" />
            <span>ناشر</span>
            {isPublisher && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            )}
          </button>
        </nav>

        {/* Action Controls & Auth */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Team Invitations Bell / Mail */}
          {user && (
            <button
              onClick={onOpenInvitations}
              className="relative p-2 text-gray-400 hover:text-purple-300 hover:bg-white/5 rounded-xl transition-colors"
              title="دعوات الانضمام للفرق"
            >
              <Mail className="w-5 h-5" />
              {pendingInvitationsCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 text-white text-[10px] font-black flex items-center justify-center shadow-lg shadow-pink-900/50 animate-pulse">
                  {pendingInvitationsCount}
                </span>
              )}
            </button>
          )}

          {/* Bookmarks */}
          <button
            onClick={onOpenBookmarks}
            className="relative p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-colors"
            title="المفضلة"
          >
            <Bookmark className="w-5 h-5" />
            {bookmarksCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-pink-600 text-white text-[10px] font-bold flex items-center justify-center">
                {bookmarksCount}
              </span>
            )}
          </button>

          {/* User Account / Profile */}
          {loading ? (
            <div className="w-8 h-8 rounded-full bg-gray-800 animate-pulse"></div>
          ) : user ? (
            <button
              onClick={onOpenProfileModal}
              className="flex items-center gap-2 bg-[#171f33] hover:bg-[#202b46] py-1.5 px-2.5 rounded-xl border border-white/10 transition-colors"
              title="الملف الشخصي"
            >
              {profile?.photoUrl || user.photoURL ? (
                <SmartImage
                  src={profile?.photoUrl || user.photoURL || ''}
                  alt={profile?.displayName || user.displayName || 'المستخدم'}
                  fallbackText={(profile?.displayName || user.displayName || 'U')[0].toUpperCase()}
                  showFallbackText={false}
                  className="w-full h-full object-cover"
                  containerClassName="w-7 h-7 rounded-full border border-purple-500/40 shrink-0"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-purple-600 text-white font-bold text-xs flex items-center justify-center">
                  {(profile?.displayName || user.displayName || user.email || 'U')[0].toUpperCase()}
                </div>
              )}
              <span className="text-xs font-semibold text-gray-200 hidden md:inline max-w-[90px] truncate">
                {profile?.displayName || user.displayName || user.email?.split('@')[0]}
              </span>
              {isOwner && (
                <span className="text-[10px] px-1 py-0.2 rounded bg-pink-500/20 text-pink-400 font-bold border border-pink-500/30 hidden lg:inline">
                  مالك
                </span>
              )}
            </button>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-purple-900/40 transition-all"
            >
              <LogIn className="w-4 h-4" />
              <span>دخول / تسجيل</span>
            </button>
          )}

        </div>

      </div>
    </header>
  );
};
