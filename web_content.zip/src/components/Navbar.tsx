import { useEffect, useState } from "react";
import { brand, navLinks } from "../data/content";
import { useSmoothScroll } from "../hooks/useSmoothScroll";
import { cn } from "../utils/cn";
import { LogoIcon, MenuIcon, XIcon, ArrowRightIcon } from "./icons";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const scrollTo = useSmoothScroll();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const handleNav = (id: string) => {
    setOpen(false);
    scrollTo(id);
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled || open
          ? "border-b border-white/10 bg-ink-950/80 backdrop-blur-2xl"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <nav
        className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:h-[4.5rem] lg:px-8"
        aria-label="Primary"
      >
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            handleNav("hero");
          }}
          className="group flex items-center gap-2.5"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-700 text-white shadow-lg shadow-brand-600/30 transition-transform duration-300 group-hover:scale-105">
            <LogoIcon size={20} />
          </span>
          <span className="text-lg font-semibold tracking-tight text-white">
            {brand.name}
          </span>
        </a>

        <ul className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <button
                type="button"
                onClick={() => handleNav(link.href)}
                className="rounded-full px-3.5 py-2 text-sm font-medium text-ink-300 transition-colors duration-200 hover:bg-white/5 hover:text-white"
              >
                {link.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 md:flex">
          <button
            type="button"
            className="rounded-full px-3.5 py-2 text-sm font-medium text-ink-300 transition-colors hover:text-white"
          >
            Sign in
          </button>
          <button type="button" className="btn-primary !px-5 !py-2.5">
            Start free trial
            <ArrowRightIcon size={16} />
          </button>
        </div>

        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <XIcon size={20} /> : <MenuIcon size={20} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        className={cn(
          "fixed inset-x-0 top-16 bottom-0 z-40 bg-ink-950/95 backdrop-blur-2xl transition-all duration-400 md:hidden",
          open
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0"
        )}
      >
        <div className="flex h-full flex-col px-6 py-8">
          <ul className="flex flex-col gap-1">
            {navLinks.map((link, i) => (
              <li
                key={link.href}
                style={{
                  transitionDelay: open ? `${i * 50 + 50}ms` : "0ms",
                }}
                className={cn(
                  "transition-all duration-400",
                  open
                    ? "translate-y-0 opacity-100"
                    : "translate-y-3 opacity-0"
                )}
              >
                <button
                  type="button"
                  onClick={() => handleNav(link.href)}
                  className="w-full rounded-xl px-4 py-3.5 text-left text-lg font-medium text-white transition-colors hover:bg-white/5"
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-auto flex flex-col gap-3 border-t border-white/10 pt-6">
            <button
              type="button"
              className="btn-secondary w-full justify-center"
            >
              Sign in
            </button>
            <button type="button" className="btn-primary w-full justify-center">
              Start free trial
              <ArrowRightIcon size={16} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
