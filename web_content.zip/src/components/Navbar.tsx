import React from 'react';
import { ActiveTab } from '../types';
import { LayoutTemplate, ShieldAlert, Download } from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenBillboard: () => void;
  onOpenInstallModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenBillboard, onOpenInstallModal }) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6 px-4 sm:px-6 h-16">
        {/* Zone 1: Brand Wordmark (ScreenSound Fixer in English) */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2.5 text-right cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-xs shadow-md group-hover:scale-105 transition-transform">
              SF
            </div>
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-black tracking-tight text-white whitespace-nowrap group-hover:text-red-400 transition-colors">
                ScreenSound Fixer
              </span>
              <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap">
                العجردي لصيانة وبرمجة الجوال
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-5 text-xs font-bold text-slate-300">
          <button
            onClick={() => setActiveTab('home')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              activeTab === 'home' ? 'text-red-500 border-b-2 border-red-500' : 'hover:text-white'
            }`}
          >
            الرئيسية
          </button>

          <button
            onClick={() => setActiveTab('screen')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              activeTab === 'screen' ? 'text-red-500 border-b-2 border-red-500' : 'hover:text-white'
            }`}
          >
            إبقاء الشاشة أثناء المكالمة
          </button>

          <button
            onClick={() => setActiveTab('audio')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              activeTab === 'audio' ? 'text-red-500 border-b-2 border-red-500' : 'hover:text-white'
            }`}
          >
            إصلاح صوت الوسائط
          </button>

          <button
            onClick={() => setActiveTab('services')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              activeTab === 'services' ? 'text-red-500 border-b-2 border-red-500' : 'hover:text-white'
            }`}
          >
            خدمات المحل
          </button>

          <button
            onClick={() => setActiveTab('diagnostics')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              activeTab === 'diagnostics' ? 'text-red-500 border-b-2 border-red-500' : 'hover:text-white'
            }`}
          >
            فحص الحساسات
          </button>
        </nav>

        {/* Zone 3: Primary Action CTAs */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenInstallModal}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl transition-all whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">تنزيل التطبيق</span>
            <span className="sm:hidden">تنزيل</span>
          </button>

          <button
            onClick={onOpenBillboard}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 active:scale-95 rounded-xl shadow-md transition-all whitespace-nowrap cursor-pointer"
          >
            <LayoutTemplate className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">لوحة إعلان المحل</span>
            <span className="sm:hidden">الإعلان</span>
          </button>
        </div>
      </div>
    </header>
  );
};
