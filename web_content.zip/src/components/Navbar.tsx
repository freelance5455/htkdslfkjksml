import React, { useState } from 'react';
import {
  Search,
  ShoppingBag,
  User,
  X,
  Home,
  LayoutGrid,
  ShieldCheck,
} from 'lucide-react';
import { AppView } from '../types/store';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useStoreData } from '../context/StoreDataContext';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onFocusCatalog: () => void;
}

const NAV_LINKS: { id: AppView; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'men', label: 'Men' },
  { id: 'women', label: 'Women' },
  { id: 'new-arrivals', label: 'New Arrivals' },
  { id: 'best-sellers', label: 'Best Sellers' },
];

export function Navbar({
  currentView,
  onNavigate,
  searchQuery,
  onSearchChange,
  onFocusCatalog,
}: NavbarProps) {
  const { user, isAdmin } = useAuth();
  const { totalItems, openCart } = useCart();
  const { settings } = useStoreData();
  const [searchOpen, setSearchOpen] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);

  const handleNavClick = (view: AppView) => {
    onNavigate(view);
    if (view !== 'account' && view !== 'admin-login' && view !== 'admin-dashboard') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSearchInput = (val: string) => {
    onSearchChange(val);
    if (
      currentView === 'account' ||
      currentView === 'admin-login' ||
      currentView === 'admin-dashboard'
    ) {
      onNavigate('home');
    }
    onFocusCatalog();
  };

  return (
    <>
      {!bannerDismissed && settings.announcementText && currentView !== 'admin-dashboard' && (
        <div className="bg-[#0A0A0A] text-white h-8 px-4 flex items-center justify-center relative text-[11px] tracking-wide w-full">
          <span className="truncate max-w-[90vw]">{settings.announcementText}</span>
          <button
            type="button"
            onClick={() => setBannerDismissed(true)}
            aria-label="Dismiss announcement"
            className="absolute right-3 p-1 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-neutral-200">
        <div className="w-full px-4 sm:px-8 lg:px-12 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className="font-display text-2xl sm:text-[26px] font-semibold tracking-[0.14em] text-[#0A0A0A] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0A0A0A]"
          >
            {settings.storeName || 'Fashion Hub'}
          </button>

          {/* Zone 2: Primary Navigation Links (All 5 working) */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-600"
          >
            {NAV_LINKS.map((link) => {
              const active = currentView === link.id;
              return (
                <button
                  key={link.id}
                  type="button"
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0A0A0A] ${
                    active ? 'text-[#0A0A0A] font-semibold' : 'hover:text-[#0A0A0A]'
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute left-0 right-0 -bottom-0.5 h-[1.5px] bg-[#0A0A0A]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Action Controls */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSearchOpen((prev) => !prev)}
              aria-label="Toggle product search"
              className="w-10 h-10 flex items-center justify-center rounded-full text-[#0A0A0A] hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              {searchOpen ? <X className="w-[18px] h-[18px]" /> : <Search className="w-[18px] h-[18px]" />}
            </button>

            <button
              type="button"
              onClick={() => onNavigate('account')}
              aria-label="Customer account"
              className={`w-10 h-10 flex items-center justify-center rounded-full transition-colors cursor-pointer relative ${
                currentView === 'account'
                  ? 'bg-[#0A0A0A] text-white'
                  : 'text-[#0A0A0A] hover:bg-neutral-100'
              }`}
            >
              <User className="w-[18px] h-[18px]" />
              {user && (
                <span className="sr-only">Signed in as {user.email}</span>
              )}
            </button>

            <button
              type="button"
              onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'admin-login')}
              aria-label="Admin Panel"
              title="Admin Panel"
              className={`hidden sm:inline-flex items-center gap-1.5 h-9 px-3.5 rounded-full border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentView === 'admin-dashboard' || currentView === 'admin-login'
                  ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                  : 'border-neutral-300 text-[#0A0A0A] hover:border-[#0A0A0A] hover:bg-neutral-50'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>

            <button
              type="button"
              onClick={openCart}
              aria-label="Open shopping bag"
              className="relative h-10 px-3 flex items-center gap-2 rounded-full text-[#0A0A0A] hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-[18px] h-[18px]" />
              <span className="text-xs font-semibold tabular-nums">{totalItems}</span>
            </button>
          </div>
        </div>

        {/* Mobile Secondary Horizontal Nav Strip so all 5 links work on phones too */}
        <div className="md:hidden border-t border-neutral-100 px-4 py-2 flex items-center gap-4 overflow-x-auto no-scrollbar">
          {NAV_LINKS.map((link) => {
            const active = currentView === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => handleNavClick(link.id)}
                className={`text-xs whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                  active ? 'text-[#0A0A0A] font-semibold underline underline-offset-4' : 'text-neutral-600'
                }`}
              >
                {link.label}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'admin-login')}
            className="text-xs whitespace-nowrap shrink-0 py-1 font-medium text-[#0A0A0A] cursor-pointer"
          >
            Admin
          </button>
        </div>

        {/* Instant Search Drawer Bar */}
        {searchOpen && (
          <div className="border-t border-neutral-200 bg-white px-4 sm:px-8 lg:px-12 py-3 w-full">
            <div className="w-full flex items-center gap-3">
              <Search className="w-4 h-4 text-neutral-400 shrink-0" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => handleSearchInput(e.target.value)}
                placeholder="Search by product name, category, price (e.g. 999), or style..."
                className="w-full text-sm text-[#0A0A0A] placeholder:text-neutral-400 bg-transparent focus:outline-none py-1.5"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="text-xs font-medium text-neutral-500 hover:text-[#0A0A0A] whitespace-nowrap cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Mobile Bottom Navigation Bar */}
      {currentView !== 'admin-dashboard' && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 h-14 px-2 flex items-center justify-around"
        >
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className={`flex flex-col items-center justify-center min-w-[52px] h-11 text-[10px] font-medium cursor-pointer ${
              currentView === 'home' ? 'text-[#0A0A0A]' : 'text-neutral-500'
            }`}
          >
            <Home className="w-4 h-4 mb-0.5" />
            <span>Home</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onNavigate('home');
              setTimeout(() => onFocusCatalog(), 50);
            }}
            className={`flex flex-col items-center justify-center min-w-[52px] h-11 text-[10px] font-medium cursor-pointer ${
              currentView === 'men' || currentView === 'women' ? 'text-[#0A0A0A]' : 'text-neutral-500'
            }`}
          >
            <LayoutGrid className="w-4 h-4 mb-0.5" />
            <span>Shop</span>
          </button>

          <button
            type="button"
            onClick={() => setSearchOpen((prev) => !prev)}
            className={`flex flex-col items-center justify-center min-w-[52px] h-11 text-[10px] font-medium cursor-pointer ${
              searchOpen ? 'text-[#0A0A0A]' : 'text-neutral-500'
            }`}
          >
            <Search className="w-4 h-4 mb-0.5" />
            <span>Search</span>
          </button>

          <button
            type="button"
            onClick={openCart}
            className="relative flex flex-col items-center justify-center min-w-[52px] h-11 text-[10px] font-medium text-neutral-600 cursor-pointer"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4 mb-0.5" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-2 min-w-[15px] h-[15px] px-1 rounded-full bg-[#0A0A0A] text-white text-[9px] flex items-center justify-center tabular-nums">
                  {totalItems}
                </span>
              )}
            </div>
            <span>Bag</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('account')}
            className={`flex flex-col items-center justify-center min-w-[52px] h-11 text-[10px] font-medium cursor-pointer ${
              currentView === 'account' ? 'text-[#0A0A0A]' : 'text-neutral-500'
            }`}
          >
            <User className="w-4 h-4 mb-0.5" />
            <span>Account</span>
          </button>
        </nav>
      )}
    </>
  );
}
