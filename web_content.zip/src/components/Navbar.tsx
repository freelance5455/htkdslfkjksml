import React from 'react';
import { ActiveTab, StoreSettings } from '../types';
import { 
  ShoppingCart, 
  Barcode, 
  Boxes, 
  Receipt, 
  Settings as SettingsIcon, 
  LayoutDashboard
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  cartCount: number;
  lowStockCount: number;
  settings: StoreSettings;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  lowStockCount,
  settings
}) => {
  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-40 glass-header px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          {/* Logo & App Title */}
          <div 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center space-x-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-black text-xl text-white shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition transform">
              T
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                  TALLY
                </h1>
                <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  POS PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-medium">
                {settings.storeName || 'Sales & Inventory'}
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-900/60 p-1 rounded-xl border border-slate-800/80">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('sale')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition relative cursor-pointer ${
                activeTab === 'sale'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              Sale Terminal
              {cartCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[10px] bg-cyan-500 text-slate-950 rounded-full font-bold">
                  {cartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('register')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Barcode className="w-3.5 h-3.5" />
              Register Item
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition relative cursor-pointer ${
                activeTab === 'inventory'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Boxes className="w-3.5 h-3.5" />
              Inventory
              {lowStockCount > 0 && (
                <span className="ml-1 w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              Sales Log
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <SettingsIcon className="w-3.5 h-3.5" />
              Settings
            </button>
          </nav>
        </div>
      </header>

      {/* Bottom Nav on Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 glass-header px-2 py-2 flex justify-around items-center z-40 border-t border-slate-800">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition ${
            activeTab === 'dashboard' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          Home
        </button>
        <button
          onClick={() => setActiveTab('sale')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition relative ${
            activeTab === 'sale' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <ShoppingCart className="w-5 h-5 mb-0.5" />
          Sale
          {cartCount > 0 && (
            <span className="absolute top-0 right-1 px-1 text-[9px] bg-cyan-500 text-slate-950 font-bold rounded-full">
              {cartCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('register')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition ${
            activeTab === 'register' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Barcode className="w-5 h-5 mb-0.5" />
          Register
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition relative ${
            activeTab === 'inventory' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Boxes className="w-5 h-5 mb-0.5" />
          Stock
          {lowStockCount > 0 && (
            <span className="absolute top-0.5 right-2 w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition ${
            activeTab === 'history' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Receipt className="w-5 h-5 mb-0.5" />
          Receipts
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center text-[10px] py-1 px-2 rounded-lg transition ${
            activeTab === 'settings' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <SettingsIcon className="w-5 h-5 mb-0.5" />
          Settings
        </button>
      </nav>
    </>
  );
};
