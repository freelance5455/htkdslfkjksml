import React from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import {
  GraduationCap,
  Calendar,
  Users,
  CheckCircle2,
  DollarSign,
  BookOpen,
  FileText,
  Award,
  Video,
  Cloud,
  Globe,
  MapPin,
  Phone
} from 'lucide-react';
import { User } from 'firebase/auth';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  googleUser: User | null;
  onGoogleSignIn: () => void;
  onGoogleSignOut: () => void;
  centerLogoUrl: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  lang,
  setLang,
  googleUser,
  onGoogleSignIn,
  onGoogleSignOut,
  centerLogoUrl,
}) => {
  const t = translations[lang];

  const navItems = [
    { id: 'home', label: t.navHome, icon: GraduationCap },
    { id: 'classes', label: t.navClasses, icon: Calendar },
    { id: 'students', label: t.navStudents, icon: Users },
    { id: 'attendance', label: t.navAttendance, icon: CheckCircle2 },
    { id: 'fees', label: t.navFees, icon: DollarSign },
    { id: 'syllabus', label: t.navSyllabus, icon: BookOpen },
    { id: 'parchi', label: t.navParchi, icon: FileText },
    { id: 'graduates', label: t.navGraduates, icon: Award },
    { id: 'media', label: t.navMedia, icon: Video },
    { id: 'drive', label: t.navGoogleDrive, icon: Cloud },
  ];

  return (
    <header className="no-print bg-slate-900 text-white shadow-xl sticky top-0 z-40 border-b border-emerald-800/40">
      {/* Top Notification / Address Bar */}
      <div className="bg-emerald-900/90 text-emerald-100 px-4 py-1.5 text-xs font-medium border-b border-emerald-700/50">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="font-semibold text-white tracking-wide">{t.address}</span>
            <span className="hidden sm:inline text-emerald-300">|</span>
            <span className="hidden sm:inline text-emerald-200">Elementary A to Advanced (4-Month Diploma)</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-emerald-200">
              <Phone className="w-3 h-3 text-amber-400" />
              <span>{t.phone}</span>
            </div>

            {/* Language Switcher */}
            <div className="flex items-center gap-1 bg-slate-950/60 p-0.5 rounded-lg border border-emerald-700/60">
              <Globe className="w-3 h-3 text-amber-400 ml-1.5" />
              <button
                onClick={() => setLang('en')}
                className={`px-2 py-0.5 text-xs rounded font-medium transition-all ${
                  lang === 'en'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLang('ps')}
                className={`px-2 py-0.5 text-xs rounded font-bold transition-all ${
                  lang === 'ps'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                پښتو
              </button>
              <button
                onClick={() => setLang('ur')}
                className={`px-2 py-0.5 text-xs rounded font-bold transition-all ${
                  lang === 'ur'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                اردو
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 py-3.5 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Brand Logo & Name */}
        <div
          onClick={() => setCurrentTab('home')}
          className="flex items-center gap-3.5 cursor-pointer group select-none"
        >
          <div className="relative">
            <img
              src={centerLogoUrl}
              alt="Rahbar English Center Logo"
              className="w-12 h-12 rounded-xl object-cover ring-2 ring-emerald-500/80 shadow-md group-hover:scale-105 transition-transform"
            />
            <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 font-black text-[9px] px-1.5 py-0.2 rounded-full border border-slate-900 shadow">
              TRAT
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                {t.centerName}
              </h1>
              <span className="hidden md:inline bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] px-2 py-0.5 rounded-full font-bold">
                Pishin
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              {t.centerTagline}
            </p>
          </div>
        </div>

        {/* User / Google Drive Status */}
        <div className="flex items-center gap-3">
          {googleUser ? (
            <div className="flex items-center gap-2 bg-slate-800/80 border border-emerald-500/30 rounded-xl p-1.5 px-3">
              <img
                src={googleUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                alt={googleUser.displayName || 'User'}
                className="w-7 h-7 rounded-full border border-emerald-400"
              />
              <div className="text-left text-xs leading-tight">
                <span className="text-slate-300 block font-medium truncate max-w-[120px]">
                  {googleUser.displayName || googleUser.email}
                </span>
                <span className="text-emerald-400 font-semibold text-[10px] flex items-center gap-1">
                  <Cloud className="w-2.5 h-2.5" /> Drive Active
                </span>
              </div>
              <button
                onClick={onGoogleSignOut}
                className="ml-1 text-[11px] text-rose-300 hover:text-rose-100 underline hover:no-underline"
              >
                {t.signOut}
              </button>
            </div>
          ) : (
            <button
              onClick={onGoogleSignIn}
              className="flex items-center gap-2 bg-white text-slate-800 hover:bg-slate-100 px-3 py-1.5 rounded-xl font-semibold text-xs transition shadow-sm border border-slate-200"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{t.signInWithGoogle}</span>
            </button>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav className="bg-slate-950/80 px-2 sm:px-4 overflow-x-auto scrollbar-none border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center gap-1 py-1.5 min-w-max">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/50'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-300' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
};
