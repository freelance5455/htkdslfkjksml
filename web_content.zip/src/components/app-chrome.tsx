"use client";

import { usePathname } from "next/navigation";
import { SiteFooter } from "./site-footer";

/**
 * Routes that are an active match workspace. A scorer (or a live viewer)
 * needs a focused console, so the large platform footer is suppressed there
 * while remaining on Home, History and other informational pages.
 */
function isMatchWorkspace(pathname: string | null): boolean {
  if (!pathname) return false;
  // The same route can arrive as "/scorer", "/scorer.html" or — when the
  // static package is opened from file:// inside a WebView — as a full
  // filesystem path. Compare only the final segment so the prerendered and
  // hydrated markup always agree.
  const segment = (pathname.split("/").pop() ?? "").replace(/\.html$/, "");
  return segment === "scorer" || segment === "match" || segment === "league";
}

/** Renders the platform footer only outside live match screens. */
export function ConditionalFooter() {
  const pathname = usePathname();
  if (isMatchWorkspace(pathname)) return null;
  return <SiteFooter />;
}
