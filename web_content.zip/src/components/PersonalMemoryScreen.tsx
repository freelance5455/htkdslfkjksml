import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MemoryCategory, MemoryItem } from '../types';
import {
  Brain,
  Search,
  Plus,
  Trash2,
  ShieldCheck,
  Tag,
  Sparkles,
  Lock,
  CheckCircle,
  Eye,
  Sliders,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const PersonalMemoryScreen: React.FC = () => {
  const { memories, addMemory, deleteMemory, clearAllMemories } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [useMemoryForAI, setUseMemoryForAI] = useState(true);

  // New Memory Form
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCat, setNewCat] = useState<MemoryCategory>('Preferences');
  const [newTagsStr, setNewTagsStr] = useState('');

  const categories = [
    'All',
    'Preferences',
    'Important Notes',
    'Interests & Goals',
    'Health & Wellness',
  ];

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const tags = newTagsStr
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    addMemory({
      title: newTitle.trim(),
      content: newContent.trim(),
      category: newCat,
      userApproved: true,
      tags: tags.length > 0 ? tags : ['personal', 'preference'],
    });

    setNewTitle('');
    setNewContent('');
    setNewTagsStr('');
    setIsAdding(false);
  };

  const filteredMemories = memories.filter((m) => {
    if (selectedCategory !== 'All' && m.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = m.title.toLowerCase().includes(q);
      const matchContent = m.content.toLowerCase().includes(q);
      const matchTag = m.tags.some((t) => t.toLowerCase().includes(q));
      return matchTitle || matchContent || matchTag;
    }
    return true;
  });

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-4">
      {/* 1. Header with Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Personal Memory
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            User-approved knowledge bank for personalized intelligence
          </p>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            setIsAdding(true);
          }}
          className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Remember</span>
        </button>
      </div>

      {/* 2. Privacy & Control Banner */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Memory Privacy Shield
            </span>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={useMemoryForAI}
              onChange={(e) => setUseMemoryForAI(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
          HiBuddy only recalls memories explicitly authorized by you. Stored locally with zero third-party telemetry.
        </p>
      </div>

      {/* 3. Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search memories, coffee, birthdays, habits..."
          className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* 4. Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              sound.playClick();
              setSelectedCategory(cat);
            }}
            className={`px-3 py-1 rounded-full font-medium whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-700'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 5. Add Memory Form Modal */}
      {isAdding && (
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Remember New Note or Preference
            </h4>
            <button
              onClick={() => setIsAdding(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleCreateMemory} className="space-y-3">
            <input
              type="text"
              required
              placeholder="Memory title (e.g. Flight preference, Allergies)"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none"
            />

            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">
                Category
              </label>
              <select
                value={newCat}
                onChange={(e) => setNewCat(e.target.value as MemoryCategory)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              >
                <option value="Preferences">Preferences</option>
                <option value="Important Notes">Important Notes</option>
                <option value="Interests & Goals">Interests & Goals</option>
                <option value="Health & Wellness">Health & Wellness</option>
              </select>
            </div>

            <textarea
              required
              rows={3}
              placeholder="Details HiBuddy should remember..."
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none"
            />

            <input
              type="text"
              placeholder="Tags (comma separated: travel, work, diet)"
              value={newTagsStr}
              onChange={(e) => setNewTagsStr(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            />

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
            >
              Save to Memory Bank
            </button>
          </form>
        </div>
      )}

      {/* 6. Memories List */}
      <div className="space-y-3">
        {filteredMemories.length === 0 ? (
          <div className="py-12 text-center bg-white dark:bg-slate-800/80 rounded-3xl border border-slate-200 dark:border-slate-700 p-6">
            <Brain className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              No matching memories found
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Add a new personal note or ask Buddy to remember during chat.
            </p>
          </div>
        ) : (
          filteredMemories.map((m) => (
            <div
              key={m.id}
              className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-2.5 group transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded-md">
                    {m.category}
                  </span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Approved
                  </span>
                </div>

                <button
                  onClick={() => deleteMemory(m.id)}
                  title="Forget this memory"
                  className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-500 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {m.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {m.content}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {m.tags.map((t, idx) => (
                    <span key={idx} className="text-slate-500 dark:text-slate-400">
                      #{t}
                    </span>
                  ))}
                </div>
                <span className="font-mono text-[10px] shrink-0">{m.dateAdded}</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 7. Clear All Footer */}
      {memories.length > 0 && (
        <div className="pt-2 text-center">
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear all personal memories?')) {
                clearAllMemories();
              }
            }}
            className="text-xs text-slate-400 hover:text-rose-500 transition-colors"
          >
            Clear All Memories ({memories.length})
          </button>
        </div>
      )}
    </div>
  );
};
