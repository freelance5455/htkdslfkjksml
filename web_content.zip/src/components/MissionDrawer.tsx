import React from 'react';
import {CheckCircle2, Lock, Play, UserPlus, X} from 'lucide-react';
import {STORY_MISSIONS} from '../game/storyMissions';
import {PROTAGONISTS} from '../game/types';

interface MissionDrawerProps {
  open: boolean;
  activeMissionId: string | null;
  completedMissions: string[];
  onStartMission: (id: string) => void;
  onClose: () => void;
}

export const MissionDrawer: React.FC<MissionDrawerProps> = ({
  open,
  activeMissionId,
  completedMissions,
  onStartMission,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-4">
      <div className="flex max-h-[86vh] w-full max-w-2xl flex-col rounded-xl border border-white/15 bg-[#0b0f16] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div>
            <h2 className="font-display text-xl font-bold tracking-wider text-white uppercase">
              Los Santos Story Campaign
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              {completedMissions.length} of {STORY_MISSIONS.length} GTA V story missions completed
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 bg-slate-900 text-slate-300 hover:text-white"
            aria-label="Close Mission List"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-5">
          {STORY_MISSIONS.map((m) => {
            const done = completedMissions.includes(m.id);
            const active = activeMissionId === m.id;
            const prof = PROTAGONISTS[m.protagonist];
            const reqMission = m.requiredMissionId
              ? STORY_MISSIONS.find((item) => item.id === m.requiredMissionId)
              : null;
            const locked = Boolean(m.requiredMissionId && !completedMissions.includes(m.requiredMissionId));
            const unlockProf = m.unlocksCharacter ? PROTAGONISTS[m.unlocksCharacter] : null;

            return (
              <div
                key={m.id}
                className={`flex flex-col justify-between gap-3 rounded-xl border p-4 sm:flex-row sm:items-center ${
                  active
                    ? 'border-amber-400/70 bg-slate-900'
                    : locked
                      ? 'border-white/5 bg-slate-950/70 opacity-75'
                      : 'border-white/10 bg-slate-900/70'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                    <span>{m.number === 0 ? 'Prologue' : `Mission 0${m.number}`}</span>
                    <span aria-hidden="true">·</span>
                    <span>{m.act}</span>
                    <span aria-hidden="true">·</span>
                    <span style={{color: prof.accentColor}}>{prof.name}</span>
                  </div>

                  <div className="mt-1 flex items-center gap-2">
                    <h3 className="font-display text-base font-bold text-white">
                      {m.title}
                    </h3>
                    {done && <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />}
                    {locked && <Lock className="h-4 w-4 shrink-0 text-slate-500" />}
                  </div>

                  <p className="mt-1 text-xs leading-relaxed text-slate-300">
                    {m.summary}
                  </p>

                  <div className="mt-2 flex flex-wrap items-center gap-4 text-xs">
                    {m.rewardCash > 0 && (
                      <span className="font-mono-num font-semibold text-emerald-400">
                        Payout: ${m.rewardCash.toLocaleString()}
                      </span>
                    )}
                    {unlockProf && (
                      <span
                        className="inline-flex items-center gap-1 font-semibold"
                        style={{color: unlockProf.accentColor}}
                      >
                        <UserPlus className="h-3.5 w-3.5" />
                        Unlocks {unlockProf.name}
                      </span>
                    )}
                    {locked && reqMission && (
                      <span className="text-amber-400/90">
                        Requires {reqMission.number === 0 ? 'Prologue' : `Mission 0${reqMission.number}`}: {reqMission.title}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={locked}
                  onClick={() => {
                    onStartMission(m.id);
                    onClose();
                  }}
                  className={`inline-flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-lg px-4 py-2 text-xs font-bold whitespace-nowrap ${
                    locked
                      ? 'cursor-not-allowed border border-white/10 bg-slate-900 text-slate-500'
                      : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                  }`}
                >
                  {locked ? <Lock className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  {locked ? 'Locked' : active ? 'Restart' : done ? 'Replay' : 'Launch'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
