import React from 'react';
import { Sparkles, Leaf, Compass, Feather } from 'lucide-react';

export const HeritageSection: React.FC = () => {
  return (
    <section id="heritage-section" className="py-20 bg-[#F4F0E8] border-t border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs uppercase tracking-[0.25em] text-stone-500 font-semibold">
            Philosophy & Origin
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif text-stone-900 mt-2 text-balance">
            Bait ul Ukasha: The Art of Intentional Dwelling
          </h2>
          <p className="text-stone-600 text-base mt-4 leading-relaxed">
            In classical heritage, a home is more than physical shelter; it is a sanctuary of peace, hospitality, and grounding. We craft everyday home essentials that celebrate slow craftsmanship over disposable consumerism.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/80 backdrop-blur-xs p-8 rounded-2xl border border-stone-200/80 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-stone-800">
              <Leaf className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-lg font-semibold text-stone-900">
              Earth-Rooted Materials
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              We exclusively use single-origin Normandy flax linen, non-toxic lead-free pottery clays, sustainable American walnut, and pure botanical essential oils.
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-xs p-8 rounded-2xl border border-stone-200/80 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-stone-800">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-lg font-semibold text-stone-900">
              Heirloom Longevity
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Every curve, hem, and glaze is tested for daily rituals. Our stonewashed linens soften with age, and our end-grain wooden boards heal under sharp chef knives.
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-xs p-8 rounded-2xl border border-stone-200/80 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-stone-800">
              <Feather className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-lg font-semibold text-stone-900">
              Aromatic Serenity
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Our incense censers and Cambodian oud wood diffusers transform room atmospheres into calming spaces for contemplation, family gatherings, and rest.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
