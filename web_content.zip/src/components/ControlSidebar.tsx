import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize,
  Minimize,
  Sliders,
  Upload,
  Save,
  Grid,
  Check,
  RotateCw,
} from 'lucide-react';
import type { BankId, KitPreset, SidebarPosition, SidebarRotation } from '../types/octapad';

interface ControlSidebarProps {
  kit: KitPreset;
  activeBank: BankId;
  sidebarPosition: SidebarPosition;
  sidebarRotation: SidebarRotation;
  isFullscreen: boolean;
  editZonesMode: boolean;
  justSaved: boolean;
  hasUnsavedChanges: boolean;
  onToggleFullscreen: () => void;
  onRotateSidebar: () => void;
  onOpenImportSound: () => void;
  onSaveKit: () => void;
  onToggleEditZones: () => void;
  onOpenProMix: () => void;
  onSelectBank: (bank: BankId) => void;
  onPrevKit: () => void;
  onNextKit: () => void;
}

export const ControlSidebar: React.FC<ControlSidebarProps> = ({
  kit,
  activeBank,
  sidebarPosition,
  sidebarRotation,
  isFullscreen,
  editZonesMode,
  justSaved,
  hasUnsavedChanges,
  onToggleFullscreen,
  onRotateSidebar,
  onOpenImportSound,
  onSaveKit,
  onToggleEditZones,
  onOpenProMix,
  onSelectBank,
  onPrevKit,
  onNextKit,
}) => {
  const containerRef = useRef<HTMLElement>(null);
  const [size, setSize] = useState<{ w: number; h: number }>({ w: 0, h: 0 });

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setSize({ w: rect.width, h: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [sidebarPosition, sidebarRotation]);

  const isHorizontalDock = sidebarPosition === 'bottom' || sidebarPosition === 'top';
  const isSidewaysRotated = sidebarRotation === 90 || sidebarRotation === -90;

  const borderClass =
    sidebarPosition === 'right'
      ? 'border-t md:border-t-0 md:border-l'
      : sidebarPosition === 'left'
        ? 'border-t md:border-t-0 md:border-r'
        : sidebarPosition === 'top'
          ? 'border-b'
          : 'border-t';

  // Size classes for the <aside> container (compact so the 2x4 pad side stays large)
  const asideSizeClass = isSidewaysRotated
    ? isHorizontalDock
      ? 'w-full h-[168px] md:h-[180px]'
      : 'w-full h-[168px] md:h-full md:w-[214px] lg:w-[234px]'
    : isHorizontalDock
      ? 'w-full md:h-auto'
      : 'w-full md:h-full md:w-[214px] lg:w-[234px]';

  // Vertical Hardware Rack Content (used in Right/Left docks, and inside 90/-90 rotated mobile/desktop modes)
  const renderVerticalRack = (compact = false) => (
    <div
      className={`flex flex-col h-full justify-between ${
        compact ? 'gap-1 p-2' : 'gap-2.5 p-3.5 md:py-4 md:px-3.5'
      }`}
    >
      {/* Top Section: Brand + Rotate + Fullscreen + Kit Info */}
      <div className={`flex flex-col ${compact ? 'gap-1' : 'gap-2'}`}>
        <div className="flex items-center justify-between gap-1.5">
          <h1
            className={`font-display font-extrabold tracking-wide text-[#10D2F2] truncate ${
              compact ? 'text-xs' : 'text-base lg:text-lg'
            }`}
          >
            OCTAPAD PRO
          </h1>
          <button
            type="button"
            onClick={onRotateSidebar}
            title="Rotate control sidebar"
            aria-label="Rotate control sidebar"
            className={`shrink-0 rounded-lg bg-[#222630] hover:bg-[#2B303C] border border-white/5 text-cyan-400 flex items-center justify-center transition-colors cursor-pointer ${
              compact ? 'w-6 h-6' : 'w-8 h-8'
            }`}
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          type="button"
          onClick={onToggleFullscreen}
          className={`w-full rounded-xl bg-[#222630] hover:bg-[#2B303C] active:scale-[0.99] border border-white/5 font-bold tracking-wider text-slate-100 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            compact ? 'min-h-[26px] px-2 py-0.5 text-[9px]' : 'min-h-[42px] px-3 py-2 text-xs'
          }`}
        >
          {isFullscreen ? (
            <Minimize className="w-3 h-3 text-cyan-400" />
          ) : (
            <Maximize className="w-3 h-3 text-cyan-400" />
          )}
          <span className="whitespace-nowrap">
            {isFullscreen ? 'EXIT FULL' : 'FULL SCREEN'}
          </span>
        </button>

        <div className={compact ? '' : 'pt-0.5'}>
          <p className="text-[9px] font-medium text-slate-400 tracking-wider">KIT</p>
          <p
            className={`font-display font-bold text-white tracking-wide truncate ${
              compact ? 'text-[11px]' : 'text-sm lg:text-base'
            }`}
          >
            {kit.name}
          </p>
        </div>
      </div>

      {/* Middle Section: Import Sound, Save Kit, Edit Zones, ProMix */}
      <div className={`flex flex-col ${compact ? 'gap-1' : 'gap-2'}`}>
        <button
          type="button"
          onClick={onOpenImportSound}
          className={`w-full rounded-xl bg-[#222630] hover:bg-[#2B303C] active:scale-[0.99] border border-white/5 font-bold tracking-wider text-slate-100 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            compact ? 'min-h-[28px] px-2 py-0.5 text-[9px]' : 'min-h-[42px] px-3 py-2 text-xs'
          }`}
        >
          <Upload className="w-3 h-3 text-cyan-400" />
          <span className="whitespace-nowrap">IMPORT SOUND</span>
        </button>

        <button
          type="button"
          onClick={onSaveKit}
          className={`w-full rounded-xl active:scale-[0.99] border font-bold tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            compact ? 'min-h-[28px] px-2 py-0.5 text-[9px]' : 'min-h-[42px] px-3 py-2 text-xs'
          } ${
            justSaved
              ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
              : hasUnsavedChanges
                ? 'bg-[#252B37] hover:bg-[#2F3645] border-cyan-400/40 text-cyan-200'
                : 'bg-[#222630] hover:bg-[#2B303C] border-white/5 text-slate-100'
          }`}
        >
          {justSaved ? (
            <Check className="w-3 h-3 text-emerald-400" />
          ) : (
            <Save className="w-3 h-3 text-cyan-400" />
          )}
          <span className="whitespace-nowrap">
            {justSaved ? 'KIT SAVED' : 'SAVE KIT'}
          </span>
        </button>

        <div className="text-center">
          <p
            className={`font-semibold tracking-wider text-[#10D2F2] truncate ${
              compact ? 'text-[8px]' : 'text-[10px]'
            }`}
          >
            BANK {activeBank} — KIT {kit.name}
          </p>
        </div>

        <button
          type="button"
          onClick={onToggleEditZones}
          className={`w-full rounded-xl active:scale-[0.99] border font-bold tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            compact ? 'min-h-[26px] px-2 py-0.5 text-[9px]' : 'min-h-[40px] px-3 py-2 text-xs'
          } ${
            editZonesMode
              ? 'bg-[#10D2F2] text-[#091117] border-[#10D2F2]'
              : 'bg-[#1A1E27] hover:bg-[#242936] border-white/10 text-slate-200'
          }`}
        >
          <Grid className="w-3 h-3" />
          <span className="whitespace-nowrap">
            {editZonesMode ? 'DONE ZONES' : 'EDIT ZONES'}
          </span>
        </button>

        <button
          type="button"
          onClick={onOpenProMix}
          className={`w-full rounded-xl bg-transparent hover:bg-[#191D26] border border-white/5 font-medium text-slate-300 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            compact ? 'min-h-[24px] px-1.5 py-0.5 text-[9px]' : 'min-h-[38px] px-2.5 py-1.5 text-[11px]'
          }`}
        >
          <Sliders className="w-3 h-3 text-slate-400" />
          <span className="truncate">MultiTrack ProMix</span>
        </button>
      </div>

      {/* Bottom Section: BANK A / B + < KIT / KIT > */}
      <div className={`flex flex-col ${compact ? 'gap-1' : 'gap-2'}`}>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => onSelectBank('A')}
            className={`rounded-xl font-bold tracking-wider transition-all cursor-pointer whitespace-nowrap ${
              compact ? 'min-h-[28px] px-1.5 py-0.5 text-[9px]' : 'min-h-[44px] px-2 py-2 text-xs'
            } ${
              activeBank === 'A'
                ? 'bg-[#10D2F2] text-[#091117] shadow-[0_0_16px_rgba(16,210,242,0.3)]'
                : 'bg-[#222630] text-slate-200 hover:bg-[#2B303C]'
            }`}
          >
            BANK A
          </button>
          <button
            type="button"
            onClick={() => onSelectBank('B')}
            className={`rounded-xl font-bold tracking-wider transition-all cursor-pointer whitespace-nowrap ${
              compact ? 'min-h-[28px] px-1.5 py-0.5 text-[9px]' : 'min-h-[44px] px-2 py-2 text-xs'
            } ${
              activeBank === 'B'
                ? 'bg-[#10D2F2] text-[#091117] shadow-[0_0_16px_rgba(16,210,242,0.3)]'
                : 'bg-[#222630] text-slate-200 hover:bg-[#2B303C]'
            }`}
          >
            BANK B
          </button>
        </div>

        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={onPrevKit}
            className={`rounded-xl bg-[#222630] hover:bg-[#2B303C] active:scale-[0.98] font-bold tracking-wider text-slate-100 flex items-center justify-center gap-0.5 transition-all cursor-pointer whitespace-nowrap ${
              compact ? 'min-h-[26px] px-1.5 py-0.5 text-[9px]' : 'min-h-[42px] px-2 py-2 text-xs'
            }`}
          >
            <ChevronLeft className="w-3 h-3" />
            <span>KIT</span>
          </button>
          <button
            type="button"
            onClick={onNextKit}
            className={`rounded-xl bg-[#222630] hover:bg-[#2B303C] active:scale-[0.98] font-bold tracking-wider text-slate-100 flex items-center justify-center gap-0.5 transition-all cursor-pointer whitespace-nowrap ${
              compact ? 'min-h-[26px] px-1.5 py-0.5 text-[9px]' : 'min-h-[42px] px-2 py-2 text-xs'
            }`}
          >
            <span>KIT</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );

  // Horizontal Dock Strip (used when sidebarPosition is 'bottom' or 'top' on desktop with 0/180 rotation)
  const renderHorizontalRack = () => (
    <div className="hidden md:flex items-center justify-between gap-3 px-4 py-2.5 w-full">
      {/* Left: Brand + Kit Stepper */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="min-w-0">
          <h1 className="font-display text-sm font-extrabold tracking-wide text-[#10D2F2] whitespace-nowrap">
            OCTAPAD PRO
          </h1>
          <p className="text-[11px] font-bold text-white truncate max-w-[140px]">
            KIT {kit.name}
          </p>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onPrevKit}
            className="min-h-[40px] px-2.5 rounded-lg bg-[#222630] hover:bg-[#2B303C] text-xs font-bold text-slate-100 flex items-center gap-0.5 cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>KIT</span>
          </button>
          <button
            type="button"
            onClick={onNextKit}
            className="min-h-[40px] px-2.5 rounded-lg bg-[#222630] hover:bg-[#2B303C] text-xs font-bold text-slate-100 flex items-center gap-0.5 cursor-pointer"
          >
            <span>KIT</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center: Bank A / B */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={() => onSelectBank('A')}
          className={`min-h-[40px] px-3.5 rounded-lg text-xs font-bold tracking-wider cursor-pointer ${
            activeBank === 'A'
              ? 'bg-[#10D2F2] text-[#091117]'
              : 'bg-[#222630] text-slate-200 hover:bg-[#2B303C]'
          }`}
        >
          BANK A
        </button>
        <button
          type="button"
          onClick={() => onSelectBank('B')}
          className={`min-h-[40px] px-3.5 rounded-lg text-xs font-bold tracking-wider cursor-pointer ${
            activeBank === 'B'
              ? 'bg-[#10D2F2] text-[#091117]'
              : 'bg-[#222630] text-slate-200 hover:bg-[#2B303C]'
          }`}
        >
          BANK B
        </button>
      </div>

      {/* Right: Actions + Rotate + Fullscreen */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onOpenImportSound}
          className="min-h-[40px] px-3 rounded-lg bg-[#222630] hover:bg-[#2B303C] text-xs font-bold text-slate-100 flex items-center gap-1.5 cursor-pointer"
        >
          <Upload className="w-3.5 h-3.5 text-cyan-400" />
          <span>IMPORT</span>
        </button>

        <button
          type="button"
          onClick={onSaveKit}
          className={`min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
            justSaved
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/50'
              : 'bg-[#222630] hover:bg-[#2B303C] text-slate-100'
          }`}
        >
          {justSaved ? (
            <Check className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Save className="w-3.5 h-3.5 text-cyan-400" />
          )}
          <span>{justSaved ? 'SAVED' : 'SAVE'}</span>
        </button>

        <button
          type="button"
          onClick={onToggleEditZones}
          className={`min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
            editZonesMode
              ? 'bg-[#10D2F2] text-[#091117]'
              : 'bg-[#1A1E27] hover:bg-[#242936] text-slate-200 border border-white/10'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>{editZonesMode ? 'DONE' : 'ZONES'}</span>
        </button>

        <button
          type="button"
          onClick={onOpenProMix}
          className="min-h-[40px] px-3 rounded-lg bg-[#222630] hover:bg-[#2B303C] text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer"
        >
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          <span>MIX</span>
        </button>

        <button
          type="button"
          onClick={onRotateSidebar}
          title="Rotate control sidebar"
          aria-label="Rotate control sidebar"
          className="min-h-[40px] min-w-[40px] rounded-lg bg-[#222630] hover:bg-[#2B303C] text-cyan-400 flex items-center justify-center cursor-pointer"
        >
          <RotateCw className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onToggleFullscreen}
          aria-label="Toggle fullscreen"
          className="min-h-[40px] min-w-[40px] rounded-lg bg-[#222630] hover:bg-[#2B303C] text-cyan-400 flex items-center justify-center cursor-pointer"
        >
          {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );

  // If 90° or -90° rotation is active, render the exact hardware rack rotated inside the measured container
  if (isSidewaysRotated) {
    const innerWidth = size.h > 0 ? size.h : 215;
    const innerHeight = size.w > 0 ? size.w : 380;

    return (
      <aside
        ref={containerRef}
        className={`relative overflow-hidden bg-[#0E1116] text-slate-100 border-slate-800/90 ${borderClass} shrink-0 select-none ${asideSizeClass}`}
      >
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            width: `${innerWidth}px`,
            height: `${innerHeight}px`,
            transform: `translate(-50%, -50%) rotate(${sidebarRotation}deg)`,
          }}
        >
          {renderVerticalRack(true)}
        </div>
      </aside>
    );
  }

  return (
    <aside
      ref={containerRef}
      style={sidebarRotation === 180 ? { transform: 'rotate(180deg)' } : undefined}
      className={`bg-[#0E1116] text-slate-100 border-slate-800/90 ${borderClass} shrink-0 select-none ${asideSizeClass}`}
    >
      {/* Desktop / Landscape view */}
      {isHorizontalDock ? (
        renderHorizontalRack()
      ) : (
        <div className="hidden md:block h-full">{renderVerticalRack(false)}</div>
      )}

      {/* Mobile Portrait Bottom Control Dock (0° / 180° upright mode) */}
      <div className="flex md:hidden flex-col gap-1.5 p-2">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <span className="font-display text-xs font-extrabold text-[#10D2F2] tracking-wide">
              OCTAPAD PRO
            </span>
            <span className="mx-1.5 text-slate-600">·</span>
            <span className="text-xs font-bold text-white truncate">
              {kit.name} ({activeBank})
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onPrevKit}
              aria-label="Previous kit"
              className="min-h-[38px] min-w-[38px] px-2 rounded-lg bg-[#222630] text-slate-200 flex items-center justify-center"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onNextKit}
              aria-label="Next kit"
              className="min-h-[38px] min-w-[38px] px-2 rounded-lg bg-[#222630] text-slate-200 flex items-center justify-center"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onRotateSidebar}
              title="Rotate control sidebar 90°"
              aria-label="Rotate control sidebar"
              className="min-h-[38px] min-w-[38px] px-2 rounded-lg bg-[#222630] text-cyan-400 flex items-center justify-center"
            >
              <RotateCw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onToggleFullscreen}
              aria-label="Toggle fullscreen"
              className="min-h-[38px] min-w-[38px] px-2 rounded-lg bg-[#222630] text-cyan-400 flex items-center justify-center"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          <button
            type="button"
            onClick={() => onSelectBank('A')}
            className={`min-h-[44px] rounded-lg text-[11px] font-bold tracking-wide ${
              activeBank === 'A'
                ? 'bg-[#10D2F2] text-[#091117]'
                : 'bg-[#222630] text-slate-200'
            }`}
          >
            BANK A
          </button>
          <button
            type="button"
            onClick={() => onSelectBank('B')}
            className={`min-h-[44px] rounded-lg text-[11px] font-bold tracking-wide ${
              activeBank === 'B'
                ? 'bg-[#10D2F2] text-[#091117]'
                : 'bg-[#222630] text-slate-200'
            }`}
          >
            BANK B
          </button>
          <button
            type="button"
            onClick={onOpenImportSound}
            className="min-h-[44px] rounded-lg bg-[#222630] text-slate-100 text-[11px] font-semibold flex items-center justify-center gap-1"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Import</span>
          </button>
          <button
            type="button"
            onClick={onToggleEditZones}
            className={`min-h-[44px] rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 ${
              editZonesMode
                ? 'bg-[#10D2F2] text-[#091117]'
                : 'bg-[#222630] text-slate-100'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Zones</span>
          </button>
          <button
            type="button"
            onClick={onOpenProMix}
            className="min-h-[44px] rounded-lg bg-[#222630] text-slate-100 text-[11px] font-semibold flex items-center justify-center gap-1"
          >
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            <span>Mix</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
