import PoliceIcon from './PoliceIcon';

const territorialForces = [
  ['Metropolitan Police Service', 'England', 'Very large', 'Greater London, excluding the City of London police area'],
  ['Police Scotland', 'Scotland', 'Very large', 'National force for Scotland'],
  ['Greater Manchester Police', 'England', 'Large', 'Greater Manchester'],
  ['West Midlands Police', 'England', 'Large', 'West Midlands metropolitan county'],
  ['West Yorkshire Police', 'England', 'Large', 'West Yorkshire'],
  ['Thames Valley Police', 'England', 'Large', 'Berkshire, Buckinghamshire and Oxfordshire'],
  ['Police Service of Northern Ireland', 'Northern Ireland', 'Large', 'National service for Northern Ireland'],
  ['Kent Police', 'England', 'Large', 'Kent and Medway'],
  ['Hampshire and Isle of Wight Constabulary', 'England', 'Large', 'Hampshire and Isle of Wight'],
  ['Essex Police', 'England', 'Large', 'Essex, Southend and Thurrock'],
  ['Devon and Cornwall Police', 'England', 'Large', 'Devon, Cornwall and Isles of Scilly'],
  ['Avon and Somerset Police', 'England', 'Large', 'Avon and Somerset force area'],
  ['South Wales Police', 'Wales', 'Large', 'Cardiff, Swansea and surrounding South Wales area'],
  ['Sussex Police', 'England', 'Medium', 'East Sussex, West Sussex and Brighton and Hove'],
  ['Lancashire Constabulary', 'England', 'Medium', 'Lancashire, Blackburn with Darwen and Blackpool'],
  ['South Yorkshire Police', 'England', 'Medium', 'South Yorkshire'],
  ['Northumbria Police', 'England', 'Medium', 'Tyne and Wear and Northumberland'],
  ['Nottinghamshire Police', 'England', 'Medium', 'Nottinghamshire and Nottingham'],
  ['Leicestershire Police', 'England', 'Medium', 'Leicester, Leicestershire and Rutland'],
  ['Hertfordshire Constabulary', 'England', 'Medium', 'Hertfordshire'],
  ['Surrey Police', 'England', 'Medium', 'Surrey'],
  ['Merseyside Police', 'England', 'Medium', 'Merseyside'],
  ['Cheshire Constabulary', 'England', 'Medium', 'Cheshire'],
  ['Staffordshire Police', 'England', 'Medium', 'Staffordshire and Stoke-on-Trent'],
  ['West Mercia Police', 'England', 'Medium', 'Herefordshire, Shropshire and Worcestershire'],
  ['Derbyshire Constabulary', 'England', 'Medium', 'Derbyshire and Derby'],
  ['Humberside Police', 'England', 'Medium', 'East Riding, Hull, North and North East Lincolnshire'],
  ['Cambridgeshire Constabulary', 'England', 'Medium', 'Cambridgeshire and Peterborough'],
  ['North Wales Police', 'Wales', 'Medium', 'Six local authority areas of North Wales'],
  ['Norfolk Constabulary', 'England', 'Medium', 'Norfolk'],
  ['Suffolk Constabulary', 'England', 'Medium', 'Suffolk'],
  ['Gloucestershire Constabulary', 'England', 'Medium', 'Gloucestershire'],
  ['Northamptonshire Police', 'England', 'Medium', 'Northamptonshire'],
  ['Gwent Police', 'Wales', 'Medium', 'South-east Wales force area'],
  ['Wiltshire Police', 'England', 'Medium', 'Wiltshire and Swindon'],
  ['Dorset Police', 'England', 'Medium', 'Dorset, Bournemouth, Christchurch and Poole'],
  ['North Yorkshire Police', 'England', 'Medium', 'North Yorkshire and City of York'],
  ['Bedfordshire Police', 'England', 'Smaller', 'Bedfordshire, Luton and Bedford'],
  ['Durham Constabulary', 'England', 'Smaller', 'County Durham and Darlington'],
  ['Lincolnshire Police', 'England', 'Smaller', 'Lincolnshire'],
  ['Dyfed-Powys Police', 'Wales', 'Smaller', 'Carmarthenshire, Ceredigion, Pembrokeshire and Powys'],
  ['Warwickshire Police', 'England', 'Smaller', 'Warwickshire'],
  ['Cleveland Police', 'England', 'Smaller', 'Middlesbrough, Stockton, Hartlepool and Redcar and Cleveland'],
  ['Cumbria Constabulary', 'England', 'Smaller', 'Cumbria'],
  ['City of London Police', 'England', 'Smaller', 'The City of London; national lead roles include fraud'],
];

const specialistForces = [
  ['British Transport Police', 'Polices railways across Great Britain.'],
  ['Civil Nuclear Constabulary', 'Protects civil nuclear sites and nuclear material in transit.'],
  ['Ministry of Defence Police', 'Civilian police force protecting defence people, sites and assets.'],
];

const otherBodies = [
  ['National Crime Agency', 'National law-enforcement agency with officers who may hold constable, customs and immigration powers; not a territorial police force.'],
  ['Royal Military Police', 'Service Police for the British Army; not a Home Office territorial force.'],
  ['Royal Navy Police', 'Service Police for the Royal Navy and Royal Marines.'],
  ['Royal Air Force Police', 'Service Police for the Royal Air Force.'],
];

const ForceDirectory = () => (
  <article className="police-document force-directory">
    <header className="document-hero">
      <div className="document-kicker">NATIONAL REFERENCE</div>
      <h1>UK Police Force Directory</h1>
      <p>All territorial police forces in the United Kingdom, plus the three national special police forces.</p>
      <div className="document-meta"><span>45 territorial forces</span><span>3 special police forces</span><span>UK wide</span></div>
    </header>

    <div className="document-notice">
      <PoliceIcon name="info" className="h-5 w-5" />
      <p>Forces are ordered broadly by workforce scale, not as a definitive league table. Staffing changes each year; consult official Home Office, Scottish Government and PSNI statistics for current numbers.</p>
    </div>

    <section className="document-section">
      <div className="section-number">01</div>
      <div className="section-content">
        <h2>Territorial police forces</h2><div className="section-rule" />
        <div className="doc-table-wrap">
          <table className="doc-table force-table">
            <thead><tr><th>#</th><th>Force</th><th>Nation</th><th>Scale</th><th>Police area</th></tr></thead>
            <tbody>{territorialForces.map((force, index) => <tr key={force[0]}><td>{index + 1}</td><td><strong>{force[0]}</strong></td><td>{force[1]}</td><td>{force[2]}</td><td>{force[3]}</td></tr>)}</tbody>
          </table>
        </div>
      </div>
    </section>

    <section className="document-section">
      <div className="section-number">02</div>
      <div className="section-content">
        <h2>National special police forces</h2><div className="section-rule" />
        <div className="directory-cards">
          {specialistForces.map(([name, description]) => <div key={name}><PoliceIcon name="shield" className="h-7 w-7" /><h3>{name}</h3><p>{description}</p></div>)}
        </div>
      </div>
    </section>

    <section className="document-section">
      <div className="section-number">03</div>
      <div className="section-content">
        <h2>Other UK law-enforcement bodies</h2><div className="section-rule" />
        <div className="doc-table-wrap"><table className="doc-table"><thead><tr><th>Body</th><th>Status</th></tr></thead><tbody>{otherBodies.map((body) => <tr key={body[0]}><td><strong>{body[0]}</strong></td><td>{body[1]}</td></tr>)}</tbody></table></div>
        <aside className="doc-callout border-amber-500 bg-amber-50 text-amber-950"><div className="doc-callout-title text-amber-900"><PoliceIcon name="warning" className="h-5 w-5" />Crown Dependencies</div><p>Jersey, Guernsey and the Isle of Man have their own police services but are Crown Dependencies, not part of the United Kingdom, so they are not included in the UK territorial total.</p></aside>
      </div>
    </section>
  </article>
);

export default ForceDirectory;