/**
 * GODEX Phase 7 - Engineering Memory & Knowledge Vault
 * Comprehensive engineering memory inspector: Decisions, Changes, Failures,
 * Repairs, Verifications, Epistemic Status (KNOWN, LIKELY, UNKNOWN),
 * Status (ACTIVE, STALE, SUPERSEDED), and Unified Engineering Timeline.
 */

import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Search, 
  Plus, 
  ShieldCheck, 
  AlertTriangle, 
  Wrench, 
  CheckCircle2, 
  Layers, 
  Clock, 
  HelpCircle,
  Play,
  RotateCcw,
  Tag,
  FileCode,
  GitCommit,
  GitBranch,
  Shield,
  Activity,
  History,
  FileText
} from 'lucide-react';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { 
  EngineeringMemoryEntry, 
  EngineeringMemoryType, 
  EpistemicStatus, 
  MemoryStatus 
} from '../memory/memoryTypes';
import { SimulationMemoryTest, SimulationSuiteReport } from '../memory/simulationMemoryTest';

export const GodexProjectMemoryView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [epistemicFilter, setEpistemicFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [memories, setMemories] = useState<EngineeringMemoryEntry[]>([]);
  const [selectedMemory, setSelectedMemory] = useState<EngineeringMemoryEntry | null>(null);
  
  // Add Decision Form
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newReason, setNewReason] = useState('');
  const [newDecision, setNewDecision] = useState('');
  const [newEvidence, setNewEvidence] = useState('');
  const [newFiles, setNewFiles] = useState('');

  // Simulation test state
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testReport, setTestReport] = useState<SimulationSuiteReport | null>(null);

  const memoryEngine = EngineeringMemoryEngine.getInstance();
  const store = memoryEngine.getStore();

  const refreshMemories = () => {
    setMemories(store.getAllEntries());
  };

  useEffect(() => {
    refreshMemories();
    const unsubscribe = store.subscribe(() => {
      refreshMemories();
    });
    return unsubscribe;
  }, []);

  const stats = memoryEngine.getStats();

  const handleAddDecision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDecision.trim()) return;

    memoryEngine.recordDecision({
      title: newTitle.trim(),
      reason: newReason.trim() || 'User engineering choice',
      decision: newDecision.trim(),
      evidence: newEvidence.trim() ? newEvidence.split(',').map(s => s.trim()) : ['User defined constraint'],
      relatedFiles: newFiles.trim() ? newFiles.split(',').map(s => s.trim()) : [],
      source: 'USER_DECISION',
      epistemicStatus: 'KNOWN',
      confidence: 1.0
    });

    setIsAdding(false);
    setNewTitle('');
    setNewReason('');
    setNewDecision('');
    setNewEvidence('');
    setNewFiles('');
    refreshMemories();
  };

  const handleRunSimulation = async () => {
    setIsRunningTests(true);
    try {
      const rep = await SimulationMemoryTest.runAllTests();
      setTestReport(rep);
      refreshMemories();
    } finally {
      setIsRunningTests(false);
    }
  };

  // Filter memories
  const filteredMemories = memories.filter(m => {
    // Type tab filter
    if (activeTab === 'decisions' && m.type !== 'DECISION') return false;
    if (activeTab === 'failures' && m.type !== 'FAILURE') return false;
    if (activeTab === 'repairs' && m.type !== 'REPAIR') return false;
    if (activeTab === 'verifications' && m.type !== 'VERIFICATION') return false;
    if (activeTab === 'architecture' && m.type !== 'ARCHITECTURE' && m.type !== 'DECISION') return false;

    // Epistemic filter
    if (epistemicFilter !== 'ALL' && m.epistemicStatus !== epistemicFilter) return false;

    // Status filter
    if (statusFilter !== 'ALL' && m.status !== statusFilter) return false;

    // Query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchText = [
        m.content,
        m.reason || '',
        m.type,
        m.failureDetails?.errorCode || '',
        m.failureDetails?.errorMessage || '',
        m.repairDetails?.strategy || '',
        m.relatedFiles.join(' '),
        m.relatedSymbols.join(' ')
      ].join(' ').toLowerCase();

      if (!matchText.includes(q)) return false;
    }

    return true;
  });

  const timelineEvents = memoryEngine.getEngineeringTimeline();

  return (
    <div className="flex-1 h-full flex flex-col bg-[#08090D] overflow-y-auto select-none font-sans p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1C2230] pb-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#141A26] border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-md">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-wide">GODEX Engineering Memory</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                PHASE 7
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono">
              Verified Decisions • Failure & Repair History • Epistemic Grounding • Grounded Context
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Decision</span>
          </button>

          <button
            onClick={handleRunSimulation}
            disabled={isRunningTests}
            className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{isRunningTests ? 'Running Suite...' : 'Run Phase 7 Suite'}</span>
          </button>
        </div>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 font-sans">
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Total Memories</span>
          <span className="text-xl font-bold text-white font-mono mt-1">{stats.totalMemories}</span>
          <span className="text-[10px] text-cyan-400/80 font-mono">{stats.activeMemories} Active</span>
        </div>
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Verified Decisions</span>
          <span className="text-xl font-bold text-emerald-400 font-mono mt-1">{stats.verifiedDecisions}</span>
          <span className="text-[10px] text-emerald-400/80 font-mono">KNOWN Epistemic</span>
        </div>
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Historical Failures</span>
          <span className="text-xl font-bold text-amber-400 font-mono mt-1">{stats.historicalFailures}</span>
          <span className="text-[10px] text-neutral-400 font-mono">Phase 5 Root Cause</span>
        </div>
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Successful Repairs</span>
          <span className="text-xl font-bold text-blue-400 font-mono mt-1">{stats.successfulRepairs}</span>
          <span className="text-[10px] text-blue-400/80 font-mono">{stats.failedRepairs} Regressed/Failed</span>
        </div>
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Verifications</span>
          <span className="text-xl font-bold text-purple-400 font-mono mt-1">{stats.verificationsCount}</span>
          <span className="text-[10px] text-purple-400/80 font-mono">Evidence-Backed</span>
        </div>
        <div className="p-3 rounded-xl bg-[#0D111A] border border-[#1C2436] flex flex-col justify-between">
          <span className="text-[11px] text-neutral-400 font-medium">Stale / Superseded</span>
          <span className="text-xl font-bold text-neutral-400 font-mono mt-1">{stats.staleMemories + stats.supersededMemories}</span>
          <span className="text-[10px] text-neutral-500 font-mono">Historical Trace</span>
        </div>
      </div>

      {/* Add Decision Modal / Form */}
      {isAdding && (
        <form onSubmit={handleAddDecision} className="p-4 rounded-xl bg-[#0D111A] border border-cyan-500/40 space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
              <Shield className="w-4 h-4" />
              <span>Record Durable Engineering Decision</span>
            </div>
            <span className="text-[10px] text-neutral-400 font-mono">Source: USER_DECISION (KNOWN)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 font-mono block mb-1">Decision Title *</label>
              <input
                type="text"
                autoFocus
                placeholder="e.g. Keep Payment Handlers in Service Layer"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-[10px] text-neutral-400 font-mono block mb-1">Related Files (comma separated)</label>
              <input
                type="text"
                placeholder="e.g. src/services/payment.ts, src/types.ts"
                value={newFiles}
                onChange={e => setNewFiles(e.target.value)}
                className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 font-mono block mb-1">Architectural Reason (Why?) *</label>
              <input
                type="text"
                placeholder="e.g. Isolates stripe gateway interactions from UI components"
                value={newReason}
                onChange={e => setNewReason(e.target.value)}
                className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-[10px] text-neutral-400 font-mono block mb-1">Concrete Decision / Rule *</label>
              <input
                type="text"
                placeholder="e.g. UI components must call paymentService.charge() without direct SDK imports"
                value={newDecision}
                onChange={e => setNewDecision(e.target.value)}
                className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-neutral-400 font-mono block mb-1">Evidence / Artifact Reference</label>
            <input
              type="text"
              placeholder="e.g. AST export analysis, compliance requirements"
              value={newEvidence}
              onChange={e => setNewEvidence(e.target.value)}
              className="w-full bg-[#131824] border border-[#222E46] text-xs text-white px-3 py-1.5 rounded-lg outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 rounded-lg bg-[#171E2C] text-neutral-300 text-xs hover:bg-[#202A3D]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded-lg bg-cyan-600 text-white font-semibold text-xs hover:bg-cyan-500"
            >
              Commit to Engineering Memory
            </button>
          </div>
        </form>
      )}

      {/* Simulation Report Section (if run) */}
      {testReport && (
        <div className="p-4 rounded-xl bg-[#0B111D] border border-purple-500/40 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-[#1E283E] pb-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-white">Phase 7 Deterministic Simulation Report</span>
            </div>
            <div className="text-[11px] text-neutral-400">
              Passed: <span className="text-emerald-400 font-bold">{testReport.passedCount}</span> / {testReport.totalTests} ({testReport.durationMs}ms)
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-60 overflow-y-auto">
            {testReport.results.map(r => (
              <div
                key={r.testId}
                className={`p-2.5 rounded-lg border text-[11px] ${
                  r.passed ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200' : 'bg-rose-950/20 border-rose-500/30 text-rose-200'
                }`}
              >
                <div className="flex items-center justify-between font-bold">
                  <span>{r.testId}. {r.name}</span>
                  <span>{r.passed ? '✓ PASS' : '✗ FAIL'}</span>
                </div>
                <p className="text-[10px] text-neutral-400 mt-1">{r.message}</p>
                {r.evidence && (
                  <p className="text-[9px] text-neutral-500 mt-0.5 truncate">{r.evidence}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Tab Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-[#1C2436] pb-3">
        {/* Main Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
          {[
            { id: 'all', label: 'All Memories', icon: Database },
            { id: 'decisions', label: 'Decisions', icon: Shield },
            { id: 'failures', label: 'Failures', icon: AlertTriangle },
            { id: 'repairs', label: 'Repairs', icon: Wrench },
            { id: 'verifications', label: 'Verifications', icon: CheckCircle2 },
            { id: 'timeline', label: 'Timeline', icon: History }
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  active
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/40'
                    : 'text-neutral-400 hover:text-white hover:bg-[#121722]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search file, symbol, error..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-[#0F1420] border border-[#1E283E] text-xs text-white pl-8 pr-3 py-1 rounded-lg w-48 outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          <select
            value={epistemicFilter}
            onChange={e => setEpistemicFilter(e.target.value)}
            className="bg-[#0F1420] border border-[#1E283E] text-xs text-neutral-300 px-2 py-1 rounded-lg outline-none font-mono"
          >
            <option value="ALL">Epistemic: All</option>
            <option value="KNOWN">KNOWN (Verified)</option>
            <option value="LIKELY">LIKELY (Inferred)</option>
            <option value="UNKNOWN">UNKNOWN</option>
          </select>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-[#0F1420] border border-[#1E283E] text-xs text-neutral-300 px-2 py-1 rounded-lg outline-none font-mono"
          >
            <option value="ALL">Status: All</option>
            <option value="ACTIVE">ACTIVE</option>
            <option value="STALE">STALE</option>
            <option value="SUPERSEDED">SUPERSEDED</option>
          </select>
        </div>
      </div>

      {/* Main Content View */}
      {activeTab === 'timeline' ? (
        /* Unified Timeline View */
        <div className="space-y-3 font-sans">
          <div className="text-xs font-bold text-neutral-300 flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <span>Unified Engineering History Timeline</span>
            <span className="text-[10px] text-neutral-500 font-mono">({timelineEvents.length} events logged)</span>
          </div>

          <div className="relative border-l-2 border-[#1C263A] ml-3 pl-4 space-y-4">
            {timelineEvents.map((evt, idx) => {
              let badgeColor = 'bg-cyan-950 text-cyan-300 border-cyan-500/40';
              if (evt.category === 'FAILURE') badgeColor = 'bg-rose-950 text-rose-300 border-rose-500/40';
              else if (evt.category === 'REPAIR') badgeColor = 'bg-blue-950 text-blue-300 border-blue-500/40';
              else if (evt.category === 'VERIFICATION') badgeColor = 'bg-emerald-950 text-emerald-300 border-emerald-500/40';
              else if (evt.category === 'GIT') badgeColor = 'bg-purple-950 text-purple-300 border-purple-500/40';

              return (
                <div key={evt.id} className="relative group">
                  <div className="absolute -left-[23px] top-1.5 w-2.5 h-2.5 rounded-full bg-cyan-500 ring-4 ring-[#08090D]" />
                  <div className="p-3 rounded-xl bg-[#0D121D] border border-[#1C2436] hover:border-cyan-500/40 transition-colors">
                    <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold border ${badgeColor}`}>
                          {evt.category}
                        </span>
                        <span className="text-xs font-bold text-white">{evt.title}</span>
                      </div>
                      <span className="text-[10px] text-neutral-500 font-mono">
                        {new Date(evt.timestamp).toLocaleTimeString()}
                      </span>
                    </div>

                    <p className="text-xs text-neutral-400 mt-1">{evt.description}</p>

                    {evt.relatedFiles.length > 0 && (
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        {evt.relatedFiles.map(f => (
                          <span key={f} className="text-[10px] font-mono text-cyan-400 bg-cyan-950/40 px-1.5 py-0.5 rounded">
                            {f}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Memory Grid View */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredMemories.length === 0 ? (
            <div className="col-span-2 p-12 text-center rounded-xl bg-[#0D111A] border border-[#1C2230]">
              <Database className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
              <p className="text-xs text-neutral-400 font-mono">No engineering memories match the selected filters.</p>
            </div>
          ) : (
            filteredMemories.map(mem => {
              const isSelected = selectedMemory?.id === mem.id;
              
              // Badge colors
              let typeColor = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30';
              if (mem.type === 'FAILURE') typeColor = 'text-rose-400 bg-rose-950/60 border-rose-500/30';
              else if (mem.type === 'REPAIR') typeColor = 'text-blue-400 bg-blue-950/60 border-blue-500/30';
              else if (mem.type === 'VERIFICATION') typeColor = 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30';

              let epistemicColor = 'text-emerald-400 bg-emerald-950/50 border-emerald-500/30';
              if (mem.epistemicStatus === 'LIKELY') epistemicColor = 'text-amber-400 bg-amber-950/50 border-amber-500/30';
              else if (mem.epistemicStatus === 'UNKNOWN') epistemicColor = 'text-neutral-400 bg-neutral-900 border-neutral-700';

              let statusBadge = null;
              if (mem.status === 'STALE') {
                statusBadge = <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/30">STALE</span>;
              } else if (mem.status === 'SUPERSEDED') {
                statusBadge = <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">SUPERSEDED (v{mem.version})</span>;
              }

              return (
                <div
                  key={mem.id}
                  onClick={() => setSelectedMemory(mem)}
                  className={`p-4 rounded-xl bg-[#0D111A] border transition-all cursor-pointer space-y-3 ${
                    isSelected ? 'border-cyan-500 shadow-md ring-1 ring-cyan-500/30' : 'border-[#1C2436] hover:border-[#2A3752]'
                  }`}
                >
                  {/* Top Bar */}
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${typeColor}`}>
                        {mem.type}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${epistemicColor}`}>
                        {mem.epistemicStatus}
                      </span>
                      {statusBadge}
                    </div>
                    <span className="text-[10px] text-neutral-500 font-mono">
                      {new Date(mem.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  {/* Title / Content */}
                  <div>
                    <h3 className="text-sm font-bold text-white leading-snug">{mem.content}</h3>
                    {mem.reason && (
                      <p className="text-xs text-neutral-400 mt-1 font-sans">{mem.reason}</p>
                    )}
                  </div>

                  {/* Typed details */}
                  {mem.decisionDetails && (
                    <div className="p-2.5 rounded-lg bg-[#111724] border border-[#1D273B] text-[11px] space-y-1 font-sans">
                      {mem.decisionDetails.fact && (
                        <div><strong className="text-neutral-300 font-mono">Fact:</strong> <span className="text-neutral-400">{mem.decisionDetails.fact}</span></div>
                      )}
                      <div><strong className="text-neutral-300 font-mono">Reason:</strong> <span className="text-neutral-400">{mem.decisionDetails.reason}</span></div>
                      <div><strong className="text-cyan-300 font-mono">Decision:</strong> <span className="text-white">{mem.decisionDetails.decision}</span></div>
                    </div>
                  )}

                  {mem.failureDetails && (
                    <div className="p-2.5 rounded-lg bg-[#181014] border border-rose-500/30 text-[11px] space-y-1 font-mono">
                      <div className="text-rose-300 font-bold">Error {mem.failureDetails.errorCode}</div>
                      <div className="text-neutral-400">{mem.failureDetails.errorMessage}</div>
                      {mem.failureDetails.rootCause && (
                        <div className="text-neutral-300"><span className="text-neutral-500">Root Cause:</span> {mem.failureDetails.rootCause}</div>
                      )}
                    </div>
                  )}

                  {mem.repairDetails && (
                    <div className="p-2.5 rounded-lg bg-[#101524] border border-blue-500/30 text-[11px] space-y-1 font-mono">
                      <div className="text-blue-300 font-bold">Outcome: {mem.repairDetails.outcome}</div>
                      <div className="text-neutral-300">{mem.repairDetails.strategy}</div>
                      {mem.repairDetails.proposedFix && (
                        <div className="text-emerald-300 bg-[#090D18] p-1.5 rounded border border-[#162038] text-[10px] truncate">
                          {mem.repairDetails.proposedFix}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Related Files & Evidence */}
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-[#182030] text-[10px] font-mono text-neutral-400">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <FileCode className="w-3 h-3 text-neutral-500" />
                      {mem.relatedFiles.slice(0, 2).map(f => (
                        <span key={f} className="text-neutral-300">{f}</span>
                      ))}
                      {mem.relatedFiles.length > 2 && <span>+{mem.relatedFiles.length - 2} more</span>}
                    </div>

                    <div className="text-neutral-500">
                      Source: {mem.source}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
