import { Pause, Volume2, VolumeX } from 'lucide-react';
import { HudSnapshot } from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
}

export function GameHud({ hud, isMuted, onToggleMute, onPause }: GameHudProps) {
  const mapLabel = hud.mapTheme === 'TWELVE_CITY' ? 'CITY TWEENS' : '36 AREA';

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-3 sm:p-4">
      {/* Top-left: Score, Best, and MARAU count */}
      <div className="bg-[#122419]/92 border-2 border-[#3c6047] px-3 py-2 shadow-[0_3px_0_0_rgba(9,19,12,0.75)]">
        <div className="flex items-baseline gap-3.5 sm:gap-5">
          <div>
            <div className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#9ec2a5]">Score</div>
            <div className="font-pixel-display text-base sm:text-xl leading-tight text-[#f4f7ec] tabular-nums">
              {hud.score.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#9ec2a5]">Best</div>
            <div className="font-pixel-display text-sm sm:text-base leading-tight text-[#facc15] tabular-nums">
              {hud.bestScore.toLocaleString()}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <svg
              width="18"
              height="18"
              viewBox="0 0 12 12"
              className="pixelated shrink-0"
              aria-hidden="true"
            >
              <rect x="4" y="1" width="4" height="4" fill="#14532d" />
              <rect x="1" y="4" width="4" height="4" fill="#14532d" />
              <rect x="7" y="4" width="4" height="4" fill="#14532d" />
              <rect x="5" y="8" width="2" height="3" fill="#14532d" />
              <rect x="5" y="2" width="2" height="2" fill="#22c55e" />
              <rect x="2" y="5" width="2" height="2" fill="#22c55e" />
              <rect x="8" y="5" width="2" height="2" fill="#22c55e" />
              <rect x="5" y="8" width="1" height="2" fill="#4ade80" />
            </svg>
            <div>
              <div className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#9ec2a5]">MARAU</div>
              <div className="font-pixel-display text-sm sm:text-base leading-tight text-[#86efac] tabular-nums">
                {hud.clovers}
                {hud.streak >= 2 && (
                  <span className="ml-1 text-xs text-[#facc15]">x{hud.streak}</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Top-right corner: Current map name (36 AREA / CITY TWEENS) + audio & pause buttons */}
      <div className="flex flex-col items-end gap-2">
        <div className="flex items-center gap-2">
          <div className="bg-[#122419]/92 border-2 border-[#3c6047] px-2.5 py-1.5 text-right shadow-[0_3px_0_0_rgba(9,19,12,0.75)]">
            <div className="flex items-center gap-1.5 text-xs sm:text-sm whitespace-nowrap">
              <span className={`font-pixel-display font-bold ${hud.mapTheme === 'TWELVE_CITY' ? 'text-[#facc15]' : 'text-[#86efac]'}`}>
                {mapLabel}
              </span>
              <span aria-hidden="true" className="text-[#9ec2a5]">·</span>
              <span className="font-pixel-display text-[#f4f7ec] tabular-nums">
                {hud.mapTimeRemaining}s
              </span>
            </div>
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={isMuted ? 'Unmute sound' : 'Mute sound'}
              className="pixel-btn flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center bg-[#172b1e] text-[#f4f7ec] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
            >
              {isMuted ? (
                <VolumeX className="h-5 w-5 text-[#9ec2a5]" />
              ) : (
                <Volume2 className="h-5 w-5 text-[#facc15]" />
              )}
            </button>

            <button
              type="button"
              onClick={onPause}
              aria-label="Pause game"
              className="pixel-btn flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center bg-[#172b1e] text-[#f4f7ec] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
            >
              <Pause className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
