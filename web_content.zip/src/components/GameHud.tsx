import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  RotateCcw, 
  Lightbulb, 
  Coins, 
  Flame,
  Volume2, 
  VolumeX, 
  Timer, 
  Plus 
} from 'lucide-react';
import { Language } from '../types';
import { getTranslations } from '../services/i18n';

interface GameHudProps {
  levelName: string;
  worldName: string;
  moves: number;
  targetMoves?: number;
  remainingArrows: number;
  coins: number;
  hintsRemaining: number;
  undosRemaining: number;
  comboCount: number;
  comboReactionText: string | null;
  tutorialText?: string;
  soundEnabled: boolean;
  isTimedMode?: boolean;
  timeRemaining?: number;
  language?: Language;
  onToggleSound: () => void;
  onBack: () => void;
  onUndo: () => void;
  onHint: () => void;
  onReset: () => void;
  onFreeHintAd?: () => void;
  onFreeUndoAd?: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  levelName,
  worldName,
  moves,
  targetMoves,
  remainingArrows,
  coins,
  hintsRemaining,
  undosRemaining,
  comboCount,
  comboReactionText,
  tutorialText,
  soundEnabled,
  isTimedMode,
  timeRemaining,
  language = 'en',
  onToggleSound,
  onBack,
  onUndo,
  onHint,
  onReset,
  onFreeHintAd,
  onFreeUndoAd,
}) => {
  const t = getTranslations(language);
  const isTimeLow = isTimedMode && typeof timeRemaining === 'number' && timeRemaining <= 10;

  return (
    <div className="w-full flex flex-col items-center select-none z-20 shrink-0">
      {/* Top Status Bar with Android Safe-Area Inset Handling */}
      <div 
        className="w-full px-4 pb-1.5 flex items-center justify-between"
        style={{ paddingTop: 'max(0.75rem, env(safe-area-inset-top, 0px))' }}
      >
        <button
          id="btn-hud-back"
          type="button"
          onClick={onBack}
          aria-label="Back to menu"
          className="w-10 h-10 rounded-2xl bg-white/80 dark:bg-slate-800/80 backdrop-blur shadow-sm border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-200 active:scale-95 transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        {/* Level Title & World Pill */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-400">
            {worldName}
          </span>
          <h2 className="text-base font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 leading-tight">
            {levelName}
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
              {remainingArrows} {t.arrowsLeft}
            </span>
          </h2>
        </div>

        {/* Coins Pill & Sound Toggle */}
        <div className="flex items-center gap-1.5">
          <div className="h-9 px-2.5 rounded-2xl bg-amber-100/90 dark:bg-amber-950/60 border border-amber-300/60 dark:border-amber-700/60 flex items-center gap-1.5 shadow-sm">
            <Coins className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-xs font-black text-amber-900 dark:text-amber-200">
              {coins}
            </span>
          </div>
          <button
            id="btn-hud-sound"
            type="button"
            onClick={onToggleSound}
            aria-label="Toggle Sound"
            className="w-9 h-9 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 active:scale-95 transition"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>

      {/* Secondary Row: Moves, Timed Countdown, & Dynamic Combo */}
      <div className="w-full px-4 py-1 flex items-center justify-between gap-2">
        {/* Moves Counter */}
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-white/70 dark:bg-slate-800/70 px-3 py-1 rounded-full border border-slate-200/60 dark:border-slate-700/60 shadow-sm">
          <span>{t.movesLabel} <strong className="text-slate-900 dark:text-white font-black">{moves}</strong></span>
          {targetMoves && (
            <span className="text-slate-400 font-normal">/ 3★ {targetMoves}</span>
          )}
        </div>

        {/* Timed Challenge Countdown Timer */}
        {isTimedMode && typeof timeRemaining === 'number' && (
          <div
            id="hud-timed-countdown"
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black shadow-md transition-all ${
              isTimeLow
                ? 'bg-rose-500 text-white animate-bounce'
                : 'bg-amber-500 text-slate-950 animate-pulse'
            }`}
          >
            <Timer className="w-3.5 h-3.5" />
            <span>{t.timeLabel} {timeRemaining}s</span>
          </div>
        )}

        {/* Dynamic Floating Combo Badge */}
        <AnimatePresence>
          {comboCount >= 2 && (
            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-md"
            >
              <Flame className="w-3.5 h-3.5 fill-current animate-pulse" />
              <span className="text-xs font-black tracking-wide">
                x{comboCount}
              </span>
              {comboReactionText && (
                <span className="text-[10px] font-bold ml-1 bg-white/25 px-1.5 py-0.2 rounded-full">
                  {comboReactionText}
                </span>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Tutorial Instruction Banner if provided */}
      {tutorialText && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-4 mt-1 px-3 py-1 rounded-xl bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800 text-sky-800 dark:text-sky-200 text-xs font-medium flex items-center gap-2 shadow-sm"
        >
          <span>💡 {tutorialText}</span>
        </motion.div>
      )}

      {/* Bottom Control Bar (Reset, Undo, Hint) */}
      <div className="w-full px-6 pt-2 pb-1 flex items-center justify-around gap-4 shrink-0">
        {/* Reset Button */}
        <button
          id="btn-hud-reset"
          type="button"
          onClick={onReset}
          className="flex flex-col items-center gap-1 text-slate-600 dark:text-slate-400 active:scale-95 transition"
        >
          <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-center text-slate-600 dark:text-slate-300 hover:border-sky-400 transition">
            <RotateCcw className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold">{t.reset}</span>
        </button>

        {/* Undo Button with badge and optional Rewarded Ad trigger */}
        <div className="flex flex-col items-center gap-1 relative">
          <div className="relative">
            <button
              id="btn-hud-undo"
              type="button"
              onClick={undosRemaining > 0 ? onUndo : (onFreeUndoAd || onUndo)}
              className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-center text-slate-600 dark:text-slate-300 hover:border-sky-400 transition active:scale-95"
            >
              <RotateCcw className="w-5 h-5 scale-x-[-1]" />
            </button>
            {undosRemaining > 0 ? (
              <span className="pointer-events-none absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-black flex items-center justify-center shadow">
                {undosRemaining}
              </span>
            ) : onFreeUndoAd ? (
              <button
                type="button"
                onClick={onFreeUndoAd}
                title="Watch Ad for +3 Undos"
                className="absolute -top-1.5 -right-2 px-1.5 py-0.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white text-[9px] font-black flex items-center gap-0.5 shadow transition active:scale-95"
              >
                <Plus className="w-2.5 h-2.5" />
                <span>{t.adBadge}</span>
              </button>
            ) : null}
          </div>
          <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
            {t.undo}
          </span>
        </div>

        {/* Hint Button with badge and optional Rewarded Ad trigger */}
        <div className="flex flex-col items-center gap-1 relative">
          <div className="relative">
            <button
              id="btn-hud-hint"
              type="button"
              onClick={hintsRemaining > 0 ? onHint : (onFreeHintAd || onHint)}
              className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700/60 shadow-sm flex items-center justify-center text-amber-500 hover:border-amber-400 transition active:scale-95"
            >
              <Lightbulb className="w-5 h-5" />
            </button>
            {hintsRemaining > 0 ? (
              <span className="pointer-events-none absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center shadow">
                {hintsRemaining}
              </span>
            ) : onFreeHintAd ? (
              <button
                type="button"
                onClick={onFreeHintAd}
                title="Watch Ad for +2 Hints"
                className="absolute -top-1.5 -right-2 px-1.5 py-0.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white text-[9px] font-black flex items-center gap-0.5 shadow transition active:scale-95"
              >
                <Plus className="w-2.5 h-2.5" />
                <span>{t.adBadge}</span>
              </button>
            ) : null}
          </div>
          <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
            {t.hint}
          </span>
        </div>
      </div>
    </div>
  );
};
