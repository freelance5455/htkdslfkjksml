import { Droplet, Flame, Heart, Landmark, Moon, Pause, Sparkles } from "lucide-react";
import type { BannerEvent, HudSnapshot } from "@/game/types";
import { formatScore, formatTime } from "@/lib/scores";

function Hearts({ hp, maxHp }: { hp: number; maxHp: number }) {
  return (
    <div className="flex items-center gap-[3px]" aria-label={`الصحة ${hp} من ${maxHp}`}>
      {Array.from({ length: maxHp }).map((_, i) => {
        const alive = i < hp;
        return (
          <Heart
            key={i}
            className={[
              "h-[13px] w-[13px] transition-all duration-200 sm:h-[15px] sm:w-[15px]",
              alive ? "text-[#eb9277]" : "text-[#e8dcc4]/20",
              alive && i === hp - 1 && hp === 1 ? "animate-heart" : "",
            ].join(" ")}
            fill={alive ? "currentColor" : "none"}
            strokeWidth={2}
          />
        );
      })}
    </div>
  );
}

function StatBar({
  value,
  max,
  className,
  icon,
  label,
}: {
  value: number;
  max: number;
  className: string;
  icon: React.ReactNode;
  label: string;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const low = pct < 26;
  return (
    <div className="flex items-center gap-1.5" aria-label={`${label} ${Math.round(value)} من ${max}`}>
      <span className={low ? "animate-pulse text-[#ef9981]" : "text-[#94d5c6]"}>{icon}</span>
      <div className="h-[5px] w-[52px] overflow-hidden rounded-full bg-[#e8dcc4]/15 sm:w-[68px]">
        <div
          className={`h-full rounded-full transition-[width] duration-200 ${className} ${low ? "animate-pulse" : ""}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className={`nums text-[9px] font-medium sm:text-[10px] ${low ? "text-[#f2a88f]" : "text-[#d8c9aa]/80"}`}>
        {Math.round(value)}
      </span>
    </div>
  );
}

export function GameHud({
  hud,
  onPause,
  banner,
  onInteract,
}: {
  hud: HudSnapshot;
  onPause: () => void;
  banner: BannerEvent | null;
  onInteract: () => void;
}) {
  const lit = hud.shrines.filter(Boolean).length;
  const nightPct = Math.round(hud.night * 100);

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-1.5 p-2 sm:p-4">
        {/* Status — right in RTL */}
        <div className="flex min-w-0 items-center gap-1.5 rounded-2xl border border-[#f0d9a8]/15 bg-[#102620]/85 p-1.5 text-[#f6ecd8] shadow-[0_10px_30px_-12px_rgba(0,0,0,0.7)] backdrop-blur-md sm:gap-2.5 sm:px-3 sm:py-2">
          <div className="relative hidden h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#e3b974]/50 bg-gradient-to-br from-[#2b4f45] to-[#17352e] sm:flex sm:h-10 sm:w-10">
            <Flame className="h-4 w-4 text-[#f0cd8b] sm:h-[18px] sm:w-[18px]" />
            <span className="absolute -bottom-0.5 -left-0.5 h-2 w-2 rounded-full border border-[#102620] bg-[#79c5b4]" />
          </div>
          <div className="min-w-0">
            <div className="mb-0.5 flex items-center gap-1.5 sm:mb-1 sm:gap-2">
              <span className="hidden text-[11px] font-medium text-[#d8c9aa] sm:inline">المسافر</span>
              <Hearts hp={hud.hp} maxHp={hud.maxHp} />
            </div>
            <StatBar
              value={hud.water}
              max={hud.maxWater}
              label="الماء"
              icon={<Droplet className="h-2.5 w-2.5 sm:h-3 sm:w-3" fill="currentColor" strokeWidth={1.5} />}
              className="bg-gradient-to-l from-[#74c8b7] to-[#3d8b7f]"
            />
          </div>
        </div>

        <div className="flex shrink-0 items-start gap-1 sm:gap-2">
          <div className="pointer-events-auto relative overflow-hidden rounded-2xl border border-[#e3b974]/25 bg-[#102620]/85 px-2 py-1 text-center text-[#f6ecd8] shadow-[0_10px_30px_-12px_rgba(0,0,0,0.7)] backdrop-blur-md sm:px-4 sm:py-2">
            <div className="flex items-center justify-center gap-1 text-[7px] font-medium tracking-[0.18em] text-[#d8c9aa]/85 sm:text-[9px]">
              <Sparkles className="h-2.5 w-2.5 text-[#e3b974]" />
              النقاط
            </div>
            <div className="nums text-base font-semibold leading-tight text-[#f5dba4] sm:text-2xl">
              {formatScore(hud.score)}
            </div>
            {hud.combo > 1 && (
              <div className="mt-0.5">
                <div className="flex items-center justify-between gap-2 text-[8px] font-semibold text-[#f0cd8b] sm:text-[9px]">
                  <span>سلسلة ×{hud.combo}</span>
                  <span className="nums opacity-70">{Math.ceil(hud.comboProgress * 5)}ث</span>
                </div>
                <div className="mt-0.5 h-[2px] w-full overflow-hidden rounded-full bg-white/15">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-[#f5dba4] to-[#e3b974]"
                    style={{ width: `${hud.comboProgress * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>
          <button
            onClick={onPause}
            aria-label="إيقاف اللعبة مؤقتًا"
            className="group flex h-9 w-9 items-center justify-center rounded-full border border-[#f0d9a8]/20 bg-[#102620]/85 text-[#f1e4cb] shadow-lg backdrop-blur-md transition hover:border-[#e3b974]/60 hover:bg-[#1c3d34] active:scale-95 sm:h-10 sm:w-10"
          >
            <Pause className="h-3.5 w-3.5 sm:h-4 sm:w-4" fill="currentColor" />
          </button>
        </div>
      </div>

      {/* Mission strip */}
      <div className="pointer-events-none absolute inset-x-0 top-[52px] z-20 flex justify-center px-2 sm:top-[76px]">
        <div className="flex max-w-full items-center gap-1.5 rounded-full border border-[#f0d9a8]/15 bg-[#102620]/80 px-2 py-1 text-[#f0e5cf] shadow-lg backdrop-blur-md sm:gap-3 sm:px-3.5 sm:py-1.5">
          <div className="flex items-center gap-1">
            <Landmark className="h-3 w-3 text-[#e3b974]" />
            <span className="text-[9px] font-medium text-[#d8c9aa] sm:text-[10px]">الأضرحة</span>
            <div className="flex items-center gap-1">
              {hud.shrines.map((s, i) => (
                <span
                  key={i}
                  className={[
                    "inline-block h-[7px] w-[7px] rotate-45 rounded-[1px] border transition-all sm:h-2 sm:w-2",
                    s
                      ? "border-[#f7dfa8] bg-[#f0cd8b] shadow-[0_0_8px_rgba(240,205,139,0.85)]"
                      : "border-[#d8c9aa]/40 bg-transparent",
                  ].join(" ")}
                />
              ))}
            </div>
            <span className="nums text-[9px] text-[#e3b974] sm:text-[10px]">{lit}/3</span>
          </div>
          <span className="h-3 w-px bg-[#e8dcc4]/15" />
          <div className="flex items-center gap-1 text-[9px] text-[#d8c9aa] sm:text-[10px]">
            <Flame className="h-2.5 w-2.5 text-[#e79a6c]" />
            <span className="nums">دورة {hud.cycles}</span>
          </div>
          <span className="h-3 w-px bg-[#e8dcc4]/15" />
          <div className="flex items-center gap-1 text-[9px] text-[#d8c9aa] sm:text-[10px]">
            <Moon className={`h-2.5 w-2.5 ${nightPct > 0 ? "text-[#b9c7e8]" : "text-[#d8c9aa]/50"}`} />
            <div className="h-[3px] w-8 overflow-hidden rounded-full bg-[#e8dcc4]/15 sm:w-12">
              <div
                className="h-full rounded-full bg-gradient-to-l from-[#aebfe4] to-[#7087b9] transition-[width] duration-500"
                style={{ width: `${Math.max(3, nightPct)}%` }}
              />
            </div>
            <span className="nums tabular-nums opacity-70">{formatTime(hud.time)}</span>
          </div>
        </div>
      </div>

      {banner && (
        <div className="pointer-events-none absolute inset-x-0 top-[82px] z-30 flex justify-center px-3 sm:top-[112px]">
          <div
            key={banner.id}
            className="animate-toast flex max-w-[92%] items-center gap-2.5 rounded-2xl border border-[#f5dba4]/30 bg-[#0f241f]/92 px-3 py-2 text-[#f7eedb] shadow-[0_18px_40px_-18px_rgba(0,0,0,0.85)] backdrop-blur-md sm:px-4 sm:py-2.5"
          >
            <div
              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border ${
                banner.tone === "teal"
                  ? "border-[#74c8b7]/40 bg-[#3d8b7f]/25 text-[#a9e7d5]"
                  : banner.tone === "clay"
                    ? "border-[#e79a6c]/40 bg-[#c66b46]/20 text-[#f0b28d]"
                    : "border-[#e3b974]/40 bg-[#e3b974]/15 text-[#f5dba4]"
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
            </div>
            <div className="min-w-0 text-right">
              <p className="text-[11px] font-semibold leading-tight sm:text-xs">{banner.title}</p>
              {banner.sub && <p className="mt-0.5 text-[9px] leading-snug text-[#d8c9aa]/85 sm:text-[10px]">{banner.sub}</p>}
            </div>
          </div>
        </div>
      )}

      {hud.prompt && (
        <div className="pointer-events-none absolute inset-x-0 bottom-[132px] z-20 flex justify-center px-3 sm:bottom-6">
          <button
            onClick={onInteract}
            className="pointer-events-auto animate-pop flex items-center gap-2 rounded-full border border-[#f5dba4]/40 bg-[#102620]/92 px-3 py-2 text-[#f7eedb] shadow-[0_12px_30px_-12px_rgba(0,0,0,0.8)] backdrop-blur-md transition hover:bg-[#1c3d34] active:scale-95 sm:gap-3 sm:px-4"
          >
            <span className="hidden h-6 min-w-6 items-center justify-center rounded-md border border-[#e3b974]/50 bg-[#e3b974]/15 px-1 text-[10px] font-semibold text-[#f5dba4] sm:flex">
              E
            </span>
            <Sparkles className="h-3.5 w-3.5 text-[#f0cd8b]" />
            <span className="text-[11px] font-medium sm:text-xs">{hud.promptLabel}</span>
            <span className="rounded-md bg-[#e3b974] px-1.5 py-0.5 text-[9px] font-semibold text-[#142e28] sm:hidden">تفاعل</span>
          </button>
        </div>
      )}
    </>
  );
}
