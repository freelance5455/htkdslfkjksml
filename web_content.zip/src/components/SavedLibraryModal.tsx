import React, { useState } from 'react';
import { X, Bookmark, Music, Film, Camera, Copy, Check, Trash2 } from 'lucide-react';
import { SavedItem } from '../types.ts';

interface SavedLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: SavedItem[];
  onDeleteItem: (id: string) => void;
  showToast: (msg: string) => void;
}

export const SavedLibraryModal: React.FC<SavedLibraryModalProps> = ({
  isOpen,
  onClose,
  items,
  onDeleteItem,
  showToast,
}) => {
  const [filter, setFilter] = useState<'all' | 'music' | 'video' | 'photo'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeItem, setActiveItem] = useState<SavedItem | null>(null);

  if (!isOpen) return null;

  const filteredItems = items.filter((item) => filter === 'all' || item.type === filter);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('Copied to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'music':
        return <Music className="w-4 h-4 text-[#fae48c]" />;
      case 'video':
        return <Film className="w-4 h-4 text-[#fae48c]" />;
      case 'photo':
        return <Camera className="w-4 h-4 text-[#fae48c]" />;
      default:
        return <Bookmark className="w-4 h-4 text-[#fae48c]" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#17072d] border border-[#d4af37]/40 w-full max-w-lg rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 border-b border-[#d4af37]/25 flex items-center justify-between bg-[#1f0b3c]">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-[#fae48c]" />
            <h3 className="royal-heading font-bold gold-gradient-text text-base">
              Saved Creative Vault
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#140626] border border-[#d4af37]/30 text-[#bda8d9] hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="px-3.5 py-2.5 bg-[#120524] border-b border-[#d4af37]/15 flex gap-1.5 overflow-x-auto no-scrollbar">
          {(['all', 'music', 'video', 'photo'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1 rounded-full text-xs font-semibold capitalize transition-all ${
                filter === tab
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#fae48c] text-[#120422] shadow-sm'
                  : 'bg-[#220c3f] text-[#a893c2] hover:text-[#fae48c]'
              }`}
            >
              {tab === 'all' ? 'All Creations' : tab}
            </button>
          ))}
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 text-xs text-[#a28cb8]">
              <Bookmark className="w-8 h-8 text-[#d4af37]/40 mx-auto mb-2" />
              <p className="font-semibold text-sm text-[#eee3f8]">No saved creations yet</p>
              <p className="mt-1">Generated songs, video treatments, and photo prompts will appear here.</p>
            </div>
          ) : (
            filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-[#200b3d] border border-[#d4af37]/25 hover:border-[#fae48c]/50 rounded-xl p-3 transition-colors shadow-md space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-[#140626] border border-[#d4af37]/30">
                      {getIcon(item.type)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#f5edfa] line-clamp-1">{item.title}</h4>
                      <p className="text-[10px] text-[#bda8d9] line-clamp-1">{item.subtitle}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleCopy(item.id, item.content)}
                      className="p-1.5 rounded-lg bg-[#140626] border border-[#d4af37]/30 text-[#fae48c] hover:bg-[#280e4d] transition-colors"
                      title="Copy"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-1.5 rounded-lg bg-[#140626] border border-rose-500/30 text-rose-400 hover:bg-rose-950/40 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Preview Trigger */}
                <button
                  onClick={() => setActiveItem(activeItem?.id === item.id ? null : item)}
                  className="w-full text-left text-[11px] text-[#d4af37] font-semibold hover:underline"
                >
                  {activeItem?.id === item.id ? 'Hide Details ▲' : 'View Full Creation ▼'}
                </button>

                {activeItem?.id === item.id && (
                  <div className="mt-2 p-2.5 rounded-lg bg-[#120524] border border-[#d4af37]/20 text-[11.5px] leading-relaxed text-[#f3e8f8] whitespace-pre-wrap max-h-56 overflow-y-auto">
                    {item.content}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
