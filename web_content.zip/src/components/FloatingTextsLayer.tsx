import { useGame } from '../context/GameContext';

export function FloatingTextsLayer() {
  const { floatingTexts } = useGame();

  if (floatingTexts.length === 0) return null;

  return (
    <div
      className="fixed inset-0 pointer-events-none z-40 overflow-hidden"
      style={{ contain: 'strict' }}
    >
      {floatingTexts.map((item) => (
        <div
          key={item.id}
          className={`absolute font-cinzel font-bold text-sm sm:text-base [text-shadow:0_2px_4px_rgba(0,0,0,0.85)] select-none animate-float-spark will-change-transform ${
            item.color || 'text-amber-300'
          }`}
          style={{
            left: `${item.x}px`,
            top: `${item.y}px`,
            willChange: 'transform, opacity',
          }}
        >
          {item.text}
        </div>
      ))}
    </div>
  );
}
