import React, { useMemo, useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, Edit2, Plus, Search, Trash2, UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateOverallLoanTotals,
  calculatePersonLoanSummary,
  formatDisplayDate,
  formatMoney,
} from '../engine/calculations';
import type { LoanPerson, LoanTransaction } from '../types/app';
import { ConfirmDialog } from './ConfirmDialog';

export const LoanView: React.FC = () => {
  const {
    snapshot,
    saveLoanPerson,
    deleteLoanPerson,
    saveLoanTransaction,
    deleteLoanTransaction,
    notify,
  } = useApp();
  const { loanPersons, loanTransactions, settings } = snapshot;

  const [activeTab, setActiveTab] = useState<'ledger' | 'add-loan' | 'repayment' | 'history'>('ledger');
  const [filterPersonId, setFilterPersonId] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Person modal / inline form state
  const [showPersonModal, setShowPersonModal] = useState(false);
  const [editingPerson, setEditingPerson] = useState<LoanPerson | null>(null);
  const [personName, setPersonName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [openingBalance, setOpeningBalance] = useState('0');
  const [personRemarks, setPersonRemarks] = useState('');

  // Loan Received form state
  const [editingTx, setEditingTx] = useState<LoanTransaction | null>(null);
  const [loanPersonId, setLoanPersonId] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanDate, setLoanDate] = useState(new Date().toISOString().slice(0, 10));
  const [loanDescription, setLoanDescription] = useState('');
  const [loanRemarks, setLoanRemarks] = useState('');

  // Repayment form state
  const [repayPersonId, setRepayPersonId] = useState('');
  const [repayAmount, setRepayAmount] = useState('');
  const [repayDate, setRepayDate] = useState(new Date().toISOString().slice(0, 10));
  const [repayMethod, setRepayMethod] = useState('Cash');
  const [repayRef, setRepayRef] = useState('');
  const [repayRemarks, setRepayRemarks] = useState('');
  const [allowOverpayment, setAllowOverpayment] = useState(false);

  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({ open: false, title: '', message: '', onConfirm: () => {} });

  const activePersons = useMemo(
    () => loanPersons.filter((p) => !p.archived).sort((a, b) => a.name.localeCompare(b.name)),
    [loanPersons]
  );

  const totals = useMemo(
    () => calculateOverallLoanTotals(loanPersons, loanTransactions),
    [loanPersons, loanTransactions]
  );

  const personSummaries = useMemo(() => {
    return activePersons
      .map((p) => calculatePersonLoanSummary(p, loanTransactions))
      .filter((s) => {
        if (filterPersonId !== 'all' && s.person.id !== filterPersonId) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return (
            s.person.name.toLowerCase().includes(q) ||
            s.person.contactNumber.toLowerCase().includes(q) ||
            s.person.remarks.toLowerCase().includes(q)
          );
        }
        return true;
      });
  }, [activePersons, loanTransactions, filterPersonId, searchQuery]);

  const filteredTransactions = useMemo(() => {
    const personMap = new Map(loanPersons.map((p) => [p.id, p.name]));
    return loanTransactions
      .filter((tx) => {
        if (filterPersonId !== 'all' && tx.personId !== filterPersonId) return false;
        if (dateFrom && tx.date < dateFrom) return false;
        if (dateTo && tx.date > dateTo) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const pName = (personMap.get(tx.personId) || '').toLowerCase();
          return (
            pName.includes(q) ||
            tx.description.toLowerCase().includes(q) ||
            (tx.transactionRef || '').toLowerCase().includes(q) ||
            tx.remarks.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => (b.date !== a.date ? b.date.localeCompare(a.date) : b.createdAt.localeCompare(a.createdAt)));
  }, [loanTransactions, loanPersons, filterPersonId, dateFrom, dateTo, searchQuery]);

  const openNewPerson = () => {
    setEditingPerson(null);
    setPersonName('');
    setContactNumber('');
    setOpeningBalance('0');
    setPersonRemarks('');
    setShowPersonModal(true);
  };

  const openEditPerson = (p: LoanPerson) => {
    setEditingPerson(p);
    setPersonName(p.name);
    setContactNumber(p.contactNumber);
    setOpeningBalance(String(p.openingBalance));
    setPersonRemarks(p.remarks);
    setShowPersonModal(true);
  };

  const handleSavePerson = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveLoanPerson({
      id: editingPerson?.id,
      name: personName,
      contactNumber,
      openingBalance: Number(openingBalance) || 0,
      remarks: personRemarks,
    });
    if (!res.ok) {
      notify(res.error || 'Failed to save person', 'error');
      return;
    }
    notify(editingPerson ? 'Person updated' : 'Person added to Loan Ledger');
    if (res.data && !loanPersonId) setLoanPersonId(res.data.id);
    if (res.data && !repayPersonId) setRepayPersonId(res.data.id);
    setShowPersonModal(false);
  };

  const handleSaveLoanReceived = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveLoanTransaction({
      id: editingTx?.type === 'received' ? editingTx.id : undefined,
      personId: loanPersonId,
      type: 'received',
      amount: Number(loanAmount),
      date: loanDate,
      description: loanDescription,
      remarks: loanRemarks,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save loan transaction', 'error');
      return;
    }
    notify(editingTx ? 'Loan transaction updated' : 'Loan received recorded');
    setEditingTx(null);
    setLoanAmount('');
    setLoanDescription('');
    setLoanRemarks('');
    setActiveTab('ledger');
  };

  const handleSaveRepayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveLoanTransaction(
      {
        id: editingTx?.type === 'repayment' ? editingTx.id : undefined,
        personId: repayPersonId,
        type: 'repayment',
        amount: Number(repayAmount),
        date: repayDate,
        description: 'Loan Repayment',
        paymentMethod: repayMethod,
        transactionRef: repayRef,
        remarks: repayRemarks,
      },
      { allowOverpayment }
    );
    if (!res.ok) {
      notify(res.error || 'Could not save repayment', 'error');
      return;
    }
    notify(editingTx ? 'Repayment updated' : 'Repayment recorded & balance updated');
    setEditingTx(null);
    setRepayAmount('');
    setRepayRef('');
    setRepayRemarks('');
    setAllowOverpayment(false);
    setActiveTab('ledger');
  };

  const startEditTransaction = (tx: LoanTransaction) => {
    setEditingTx(tx);
    if (tx.type === 'received') {
      setLoanPersonId(tx.personId);
      setLoanAmount(String(tx.amount));
      setLoanDate(tx.date);
      setLoanDescription(tx.description);
      setLoanRemarks(tx.remarks);
      setActiveTab('add-loan');
    } else {
      setRepayPersonId(tx.personId);
      setRepayAmount(String(tx.amount));
      setRepayDate(tx.date);
      setRepayMethod(tx.paymentMethod || 'Cash');
      setRepayRef(tx.transactionRef || '');
      setRepayRemarks(tx.remarks);
      setActiveTab('repayment');
    }
  };

  const selectedRepaySummary = useMemo(() => {
    const p = activePersons.find((x) => x.id === repayPersonId);
    return p ? calculatePersonLoanSummary(p, loanTransactions) : null;
  }, [activePersons, repayPersonId, loanTransactions]);

  return (
    <div className="space-y-6">
      {/* Loan KPI Strip (Strictly isolated from Committee) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Total People</div>
          <div className="mt-1 font-mono-num text-xl font-bold text-slate-900">{totals.activePeople}</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Total Loan Received</div>
          <div className="mt-1 font-mono-num text-xl font-bold text-blue-700">
            {formatMoney(totals.totalReceived, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Total Loan Repaid</div>
          <div className="mt-1 font-mono-num text-xl font-bold text-emerald-700">
            {formatMoney(totals.totalRepaid, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Remaining Payable</div>
          <div className="mt-1 font-mono-num text-xl font-bold text-amber-700">
            {formatMoney(totals.remainingPayable, settings)}
          </div>
        </div>
      </div>

      {/* Action Bar & Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg" role="tablist">
          {[
            { id: 'ledger', label: 'Person Ledger' },
            { id: 'add-loan', label: 'Loan Received' },
            { id: 'repayment', label: 'Repayment Entry' },
            { id: 'history', label: 'Transaction History' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => {
                setActiveTab(tab.id as typeof activeTab);
                if (tab.id !== 'add-loan' && tab.id !== 'repayment') setEditingTx(null);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={openNewPerson}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <UserPlus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Person</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingTx(null);
              setActiveTab('add-loan');
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 cursor-pointer whitespace-nowrap"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Record Loan</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingTx(null);
              setActiveTab('repayment');
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer whitespace-nowrap"
          >
            <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Record Repayment</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      {(activeTab === 'ledger' || activeTab === 'history') && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label htmlFor="loan-search" className="block text-xs font-medium text-slate-600 mb-1">
              Search Person or Notes
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" aria-hidden="true" />
              <input
                id="loan-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, ref..."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
          <div>
            <label htmlFor="loan-person-filter" className="block text-xs font-medium text-slate-600 mb-1">
              Filter by Person
            </label>
            <select
              id="loan-person-filter"
              value={filterPersonId}
              onChange={(e) => setFilterPersonId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All People</option>
              {activePersons.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="loan-date-from" className="block text-xs font-medium text-slate-600 mb-1">
              From Date
            </label>
            <input
              id="loan-date-from"
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label htmlFor="loan-date-to" className="block text-xs font-medium text-slate-600 mb-1">
              To Date
            </label>
            <input
              id="loan-date-to"
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>
      )}

      {/* TAB 1: Person-wise Outstanding Ledger */}
      {activeTab === 'ledger' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900">Person-wise Loan Ledger</h2>
            <span className="text-xs text-slate-500">
              Closing Payable = Opening + Received − Repaid
            </span>
          </div>
          {personSummaries.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-sm text-slate-600">No loan accounts found.</p>
              <button
                type="button"
                onClick={openNewPerson}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Add First Person</span>
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Person</th>
                    <th className="py-3 px-4 text-right">Opening</th>
                    <th className="py-3 px-4 text-right">Loan Received</th>
                    <th className="py-3 px-4 text-right">Repaid</th>
                    <th className="py-3 px-4 text-right">Remaining Payable</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {personSummaries.map((s) => (
                    <tr key={s.person.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{s.person.name}</div>
                        <div className="text-xs text-slate-500">
                          {s.person.contactNumber || 'No contact'} · {s.transactionCount} tx
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-slate-700">
                        {formatMoney(s.openingBalance, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-blue-700 font-medium">
                        {formatMoney(s.totalReceived, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-emerald-700 font-medium">
                        {formatMoney(s.totalRepaid, settings)}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-mono-num font-bold ${
                          s.closingPayable > 0
                            ? 'text-amber-700 bg-amber-50/50'
                            : s.closingPayable < 0
                              ? 'text-red-700 bg-red-50/50'
                              : 'text-emerald-700'
                        }`}
                      >
                        {formatMoney(s.closingPayable, settings)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setRepayPersonId(s.person.id);
                              setActiveTab('repayment');
                            }}
                            className="px-2.5 py-1 rounded text-xs font-medium text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                          >
                            Pay
                          </button>
                          <button
                            type="button"
                            aria-label={`Edit ${s.person.name}`}
                            onClick={() => openEditPerson(s.person)}
                            className="p-1.5 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            aria-label={`Delete ${s.person.name}`}
                            onClick={() =>
                              setConfirmState({
                                open: true,
                                title: `Delete ${s.person.name}?`,
                                message: `This moves ${s.person.name} and their ${s.transactionCount} loan transaction(s) to the Recycle Bin.`,
                                onConfirm: async () => {
                                  await deleteLoanPerson(s.person.id);
                                  notify(`Moved ${s.person.name} to Recycle Bin`);
                                  setConfirmState((prev) => ({ ...prev, open: false }));
                                },
                              })
                            }
                            className="p-1.5 rounded text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Loan Received Entry Form */}
      {activeTab === 'add-loan' && (
        <form
          onSubmit={handleSaveLoanReceived}
          className="rounded-xl border border-slate-200 bg-white p-6 max-w-2xl space-y-4"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="font-display text-base font-bold text-slate-900">
              {editingTx ? 'Edit Loan Received' : 'Record Loan Received'}
            </h2>
            <button
              type="button"
              onClick={openNewPerson}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              + New Person
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="loan-person-select" className="block text-xs font-semibold text-slate-700 mb-1">
                Person Name *
              </label>
              <select
                id="loan-person-select"
                required
                value={loanPersonId}
                onChange={(e) => setLoanPersonId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select Person...</option>
                {activePersons.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="loan-amount-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Loan Received ({settings.currency}) *
              </label>
              <input
                id="loan-amount-input"
                type="number"
                step="0.01"
                min="0.01"
                required
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label htmlFor="loan-date-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Loan Date *
              </label>
              <input
                id="loan-date-input"
                type="date"
                required
                value={loanDate}
                onChange={(e) => setLoanDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="loan-desc-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Description
              </label>
              <input
                id="loan-desc-input"
                type="text"
                value={loanDescription}
                onChange={(e) => setLoanDescription(e.target.value)}
                placeholder="Purpose or terms"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div>
            <label htmlFor="loan-remarks-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Remarks
            </label>
            <textarea
              id="loan-remarks-input"
              rows={2}
              value={loanRemarks}
              onChange={(e) => setLoanRemarks(e.target.value)}
              placeholder="Optional notes"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div className="flex items-center justify-end gap-2 pt-2">
            {editingTx && (
              <button
                type="button"
                onClick={() => {
                  setEditingTx(null);
                  setActiveTab('history');
                }}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 cursor-pointer"
            >
              {editingTx ? 'Update Loan' : 'Save Loan Received'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 3: Separate Loan Repayment Entry Form */}
      {activeTab === 'repayment' && (
        <form
          onSubmit={handleSaveRepayment}
          className="rounded-xl border border-slate-200 bg-white p-6 max-w-2xl space-y-4"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="font-display text-base font-bold text-slate-900">
              {editingTx ? 'Edit Loan Repayment' : 'Record Loan Repayment'}
            </h2>
            {selectedRepaySummary && (
              <span className="text-xs font-semibold text-amber-700 font-mono-num">
                Current Payable: {formatMoney(selectedRepaySummary.closingPayable, settings)}
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="repay-person-select" className="block text-xs font-semibold text-slate-700 mb-1">
                Person Name *
              </label>
              <select
                id="repay-person-select"
                required
                value={repayPersonId}
                onChange={(e) => setRepayPersonId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select Person...</option>
                {activePersons.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="repay-date-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Date *
              </label>
              <input
                id="repay-date-input"
                type="date"
                required
                value={repayDate}
                onChange={(e) => setRepayDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="repay-amount-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Amount ({settings.currency}) *
              </label>
              <input
                id="repay-amount-input"
                type="number"
                step="0.01"
                min="0.01"
                required
                value={repayAmount}
                onChange={(e) => setRepayAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label htmlFor="repay-method-select" className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Method
              </label>
              <select
                id="repay-method-select"
                value={repayMethod}
                onChange={(e) => setRepayMethod(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Cheque">Cheque</option>
                <option value="Easypaisa / JazzCash">Easypaisa / JazzCash</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label htmlFor="repay-ref-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Transaction Reference
              </label>
              <input
                id="repay-ref-input"
                type="text"
                value={repayRef}
                onChange={(e) => setRepayRef(e.target.value)}
                placeholder="Slip / Reference #"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="repay-remarks-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks
              </label>
              <input
                id="repay-remarks-input"
                type="text"
                value={repayRemarks}
                onChange={(e) => setRepayRemarks(e.target.value)}
                placeholder="Optional note"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
            <input
              type="checkbox"
              checked={allowOverpayment}
              onChange={(e) => setAllowOverpayment(e.target.checked)}
              className="rounded border-slate-300 text-emerald-600"
            />
            <span>Allow overpayment above current remaining payable</span>
          </label>

          <div className="flex items-center justify-end gap-2 pt-2">
            {editingTx && (
              <button
                type="button"
                onClick={() => {
                  setEditingTx(null);
                  setActiveTab('history');
                }}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
            >
              {editingTx ? 'Update Repayment' : 'Save Repayment'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 4: Date-wise Transaction & Payment History */}
      {activeTab === 'history' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900">
              Loan &amp; Repayment History
            </h2>
            <span className="text-xs text-slate-500">{filteredTransactions.length} record(s)</span>
          </div>
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              No loan transactions match your filters.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Person</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Method / Ref</th>
                    <th className="py-3 px-4">Remarks</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredTransactions.map((tx) => {
                    const person = loanPersons.find((p) => p.id === tx.personId);
                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num text-xs text-slate-600 whitespace-nowrap">
                          {formatDisplayDate(tx.date, settings.dateFormat)}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-900">
                          {person?.name || 'Unknown'}
                        </td>
                        <td className="py-3 px-4 text-xs">
                          <span
                            className={`font-semibold ${
                              tx.type === 'received' ? 'text-blue-700' : 'text-emerald-700'
                            }`}
                          >
                            {tx.type === 'received' ? 'Loan Received' : 'Repayment'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-500">
                          {tx.paymentMethod || tx.description || '-'}
                          {tx.transactionRef ? ` · ${tx.transactionRef}` : ''}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-500">{tx.remarks || '-'}</td>
                        <td
                          className={`py-3 px-4 text-right font-mono-num font-semibold ${
                            tx.type === 'received' ? 'text-blue-700' : 'text-emerald-700'
                          }`}
                        >
                          {formatMoney(tx.amount, settings)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              aria-label={`Edit transaction ${tx.id}`}
                              onClick={() => startEditTransaction(tx)}
                              className="p-1.5 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              aria-label={`Delete transaction ${tx.id}`}
                              onClick={() =>
                                setConfirmState({
                                  open: true,
                                  title: 'Delete Loan Transaction?',
                                  message: `Delete ${tx.type === 'received' ? 'Loan Received' : 'Repayment'} of ${formatMoney(tx.amount, settings)} for ${person?.name || 'Unknown'}? Balances will recalculate automatically.`,
                                  onConfirm: async () => {
                                    await deleteLoanTransaction(tx.id);
                                    notify('Transaction moved to Recycle Bin');
                                    setConfirmState((prev) => ({ ...prev, open: false }));
                                  },
                                })
                              }
                              className="p-1.5 rounded text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add/Edit Person Modal */}
      {showPersonModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="person-modal-title"
        >
          <form
            onSubmit={handleSavePerson}
            className="w-full max-w-md rounded-xl bg-white border border-slate-200 shadow-2xl p-6 space-y-4"
          >
            <h3 id="person-modal-title" className="font-display text-base font-bold text-slate-900">
              {editingPerson ? 'Edit Loan Person' : 'Add Loan Person'}
            </h3>
            <div>
              <label htmlFor="modal-person-name" className="block text-xs font-semibold text-slate-700 mb-1">
                Person Name *
              </label>
              <input
                id="modal-person-name"
                type="text"
                required
                value={personName}
                onChange={(e) => setPersonName(e.target.value)}
                placeholder="e.g. Tariq Mahmood"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="modal-person-phone" className="block text-xs font-semibold text-slate-700 mb-1">
                Contact Number
              </label>
              <input
                id="modal-person-phone"
                type="text"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="0300-0000000"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="modal-person-opening" className="block text-xs font-semibold text-slate-700 mb-1">
                Opening Balance ({settings.currency})
              </label>
              <input
                id="modal-person-opening"
                type="number"
                step="0.01"
                value={openingBalance}
                onChange={(e) => setOpeningBalance(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label htmlFor="modal-person-remarks" className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks
              </label>
              <input
                id="modal-person-remarks"
                type="text"
                value={personRemarks}
                onChange={(e) => setPersonRemarks(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPersonModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
              >
                Save Person
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={confirmState.open}
        title={confirmState.title}
        message={confirmState.message}
        destructive
        confirmLabel="Delete"
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState((prev) => ({ ...prev, open: false }))}
      />
    </div>
  );
};
