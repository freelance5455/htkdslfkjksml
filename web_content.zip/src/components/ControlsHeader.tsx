import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Palette,
  Volume2,
  Info,
  Radio,
  Sparkles,
  Download,
} from 'lucide-react';
import { SessionState, MoodTheme } from '../types';

interface ControlsHeaderProps {
  state: SessionState;
  theme: MoodTheme;
  voice: string;
  isMuted: boolean;
  onThemeSelect: (theme: MoodTheme) => void;
  onVoiceSelect: (voice: string) => void;
  onToggleMute: () => void;
}

const themeOptions: { id: MoodTheme; name: string; color: string }[] = [
  { id: 'cyber-rose', name: 'Cyber Rose', color: 'bg-pink-500' },
  { id: 'electric-violet', name: 'Electric Violet', color: 'bg-purple-500' },
  { id: 'midnight-emerald', name: 'Midnight Emerald', color: 'bg-emerald-500' },
  { id: 'solar-amber', name: 'Solar Amber', color: 'bg-amber-500' },
  { id: 'hyper-cyan', name: 'Hyper Cyan', color: 'bg-cyan-500' },
];

export const ControlsHeader: React.FC<ControlsHeaderProps> = ({
  state,
  theme,
  voice,
  isMuted,
  onThemeSelect,
  onVoiceSelect,
  onToggleMute,
}) => {
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  const getStatusBadge = () => {
    switch (state) {
      case 'speaking':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40 text-xs font-semibold animate-pulse shadow-md">
            <Radio className="w-3.5 h-3.5 animate-spin" />
            ROXY SPEAKING
          </span>
        );
      case 'listening':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold shadow-md">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            LISTENING
          </span>
        );
      case 'connecting':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-semibold animate-pulse">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            CONNECTING...
          </span>
        );
      case 'error':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-semibold">
            ERROR
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-800/80 text-zinc-400 border border-zinc-700/60 text-xs font-medium">
            STANDBY
          </span>
        );
    }
  };

  return (
    <>
      <header className="w-full max-w-5xl mx-auto px-4 py-3 flex items-center justify-between z-30 select-none">
        {/* Brand identity */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/30 font-black text-sm">
            RX
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base tracking-wider text-white">
                ROXY
              </h1>
              <span className="text-[10px] tracking-widest uppercase font-semibold px-1.5 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30">
                LIVE VOICE
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 font-medium hidden sm:block">
              Sassy • Witty • Audio-to-Audio Only
            </p>
          </div>
        </div>

        {/* Center Status Badge */}
        <div className="hidden md:flex items-center">
          {getStatusBadge()}
        </div>

        {/* Controls Toolbar */}
        <div className="flex items-center gap-2">
          {/* Mute toggle button (only when active) */}
          {(state === 'listening' || state === 'speaking') && (
            <button
              onClick={onToggleMute}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                isMuted
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-lg'
                  : 'bg-zinc-800/60 text-zinc-300 border-zinc-700/60 hover:text-white'
              }`}
              title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
              aria-label="Toggle mute"
            >
              {isMuted ? <MicOff className="w-4 h-4 text-amber-400" /> : <Mic className="w-4 h-4" />}
            </button>
          )}

          {/* Voice Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                setShowVoiceMenu(!showVoiceMenu);
                setShowThemeMenu(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 text-xs text-zinc-200 transition-all cursor-pointer"
              title="Change Voice Persona"
            >
              <Volume2 className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden sm:inline font-medium">{voice}</span>
            </button>

            {showVoiceMenu && (
              <div className="absolute right-0 mt-2 w-48 rounded-xl bg-zinc-900 border border-zinc-700 p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <div className="text-[10px] uppercase font-bold text-zinc-400 px-2 py-1">
                  Gemini Live Voice
                </div>
                {[
                  { id: 'Aoede', name: 'Aoede', desc: 'Chic, bright & expressive' },
                  { id: 'Kore', name: 'Kore', desc: 'Crisp, sassy & confident' },
                ].map((v) => (
                  <button
                    key={v.id}
                    onClick={() => {
                      onVoiceSelect(v.id);
                      setShowVoiceMenu(false);
                    }}
                    className={`w-full text-left p-2 rounded-lg text-xs transition-colors flex flex-col cursor-pointer ${
                      voice === v.id
                        ? 'bg-pink-500/20 text-pink-300 font-semibold'
                        : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    <span>{v.name}</span>
                    <span className="text-[10px] text-zinc-500">{v.desc}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Theme Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                setShowThemeMenu(!showThemeMenu);
                setShowVoiceMenu(false);
              }}
              className="p-2 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 text-zinc-200 transition-all cursor-pointer"
              title="Change Mood Theme"
            >
              <Palette className="w-4 h-4 text-purple-400" />
            </button>

            {showThemeMenu && (
              <div className="absolute right-0 mt-2 w-44 rounded-xl bg-zinc-900 border border-zinc-700 p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <div className="text-[10px] uppercase font-bold text-zinc-400 px-2 py-1">
                  Ambient Vibe
                </div>
                {themeOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      onThemeSelect(opt.id);
                      setShowThemeMenu(false);
                    }}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg text-xs transition-colors cursor-pointer ${
                      theme === opt.id
                        ? 'bg-zinc-800 text-white font-semibold'
                        : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    <span className={`w-2.5 h-2.5 rounded-full ${opt.color}`} />
                    <span>{opt.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Download Project ZIP Button */}
          <a
            href="/api/download-zip"
            download="roxy-voice-assistant.zip"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/40 text-xs text-pink-300 hover:text-white transition-all cursor-pointer font-semibold shadow-sm"
            title="Download Full Project Source Code (.ZIP)"
          >
            <Download className="w-3.5 h-3.5 text-pink-400" />
            <span className="hidden sm:inline">ZIP File</span>
          </a>

          {/* Info Modal Button */}
          <button
            onClick={() => setShowInfo(true)}
            className="p-2 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 text-zinc-400 hover:text-white transition-all cursor-pointer"
            title="App Architecture & Features"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-zinc-900 border border-zinc-700 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-pink-400" />
                <h3 className="font-bold text-lg text-white">About Roxy AI</h3>
              </div>
              <button
                onClick={() => setShowInfo(false)}
                className="text-zinc-400 hover:text-white text-sm px-2 py-1 rounded-lg hover:bg-zinc-800"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
              <div className="p-3 rounded-xl bg-pink-500/10 border border-pink-500/20">
                <strong className="text-pink-300 block mb-1">Pure Audio-to-Audio (Gemini Live)</strong>
                No text generation or typing. Streams your microphone at 16kHz PCM and plays Roxy’s witty spoken voice at 24kHz PCM with gapless Web Audio scheduling and instant interruption handling.
              </div>

              <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20">
                <strong className="text-purple-300 block mb-1">Live Function Calling</strong>
                Ask Roxy to open any website (e.g., <em>"Open YouTube"</em>, <em>"Check Wikipedia"</em>). She executes the action in your browser and responds in real time.
              </div>

              <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                <strong className="text-cyan-300 block mb-1">Personality & Tone</strong>
                Confident, playful, and sassy like a close friend. Expressive reactions, sharp comebacks, and zero robotic corporate speak.
              </div>
            </div>

            <button
              onClick={() => setShowInfo(false)}
              className="w-full py-2.5 rounded-xl bg-pink-500 hover:bg-pink-600 text-white font-semibold text-xs transition-colors"
            >
              Got it, let's talk!
            </button>
          </div>
        </div>
      )}
    </>
  );
};
