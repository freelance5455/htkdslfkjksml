import React, { useState } from 'react';
import {
  Settings,
  Monitor,
  Palette,
  Sparkles,
  HardDrive,
  Info,
  Volume2,
  Bell,
  Sun,
  Moon,
  Upload,
  ArrowRight
} from 'lucide-react';
import { useDesktop, DEFAULT_WALLPAPERS } from '../../context/DesktopContext';
import { ANDROID_PACKAGE_NAME } from '../../data/androidProjectFiles';

export const SystemSettings: React.FC = () => {
  const {
    theme,
    setTheme,
    wallpaper,
    setWallpaper,
    taskbarAlignment,
    setTaskbarAlignment,
    volume,
    setVolume,
    brightness,
    setBrightness,
    customIcon,
    openApp,
    addNotification
  } = useDesktop();

  const [activeSection, setActiveSection] = useState<'personalization' | 'appicon' | 'system' | 'storage' | 'about'>('personalization');

  const handleCustomWallpaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = ev => {
      if (ev.target?.result) {
        setWallpaper(ev.target.result as string);
        addNotification({ title: 'Wallpaper Updated', message: 'Applied custom background image.', type: 'info' });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="h-full flex bg-slate-900 text-slate-100 select-none overflow-hidden">
      {/* Left Sidebar */}
      <div className="w-56 bg-slate-950/70 border-r border-white/10 p-3 space-y-1 text-xs">
        <div className="px-3 py-2 flex items-center gap-2 mb-2">
          <Settings size={18} className="text-sky-400" />
          <span className="font-bold text-white text-sm">Settings</span>
        </div>

        <button
          onClick={() => setActiveSection('personalization')}
          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 transition-colors ${
            activeSection === 'personalization'
              ? 'bg-sky-500/20 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Palette size={16} /> Personalization
        </button>

        <button
          onClick={() => setActiveSection('appicon')}
          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 transition-colors ${
            activeSection === 'appicon'
              ? 'bg-sky-500/20 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles size={16} /> App Icon Studio
        </button>

        <button
          onClick={() => setActiveSection('system')}
          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 transition-colors ${
            activeSection === 'system'
              ? 'bg-sky-500/20 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Monitor size={16} /> System & Display
        </button>

        <button
          onClick={() => setActiveSection('storage')}
          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 transition-colors ${
            activeSection === 'storage'
              ? 'bg-sky-500/20 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <HardDrive size={16} /> Storage
        </button>

        <button
          onClick={() => setActiveSection('about')}
          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 transition-colors ${
            activeSection === 'about'
              ? 'bg-sky-500/20 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Info size={16} /> About Bird PC
        </button>
      </div>

      {/* Main Settings Content */}
      <div className="flex-1 p-6 overflow-y-auto custom-scrollbar space-y-6">
        {/* Personalization */}
        {activeSection === 'personalization' && (
          <div className="space-y-6">
            <h2 className="text-lg font-bold text-white">Personalization</h2>

            {/* Taskbar Alignment */}
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-3">
              <span className="text-xs font-semibold text-white block">Taskbar Alignment</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setTaskbarAlignment('center')}
                  className={`px-4 py-2 rounded-xl text-xs font-medium border transition-colors ${
                    taskbarAlignment === 'center'
                      ? 'bg-sky-500/20 text-sky-400 border-sky-500/50'
                      : 'bg-slate-800 text-slate-400 border-white/5'
                  }`}
                >
                  Windows 11 Centered
                </button>
                <button
                  onClick={() => setTaskbarAlignment('left')}
                  className={`px-4 py-2 rounded-xl text-xs font-medium border transition-colors ${
                    taskbarAlignment === 'left'
                      ? 'bg-sky-500/20 text-sky-400 border-sky-500/50'
                      : 'bg-slate-800 text-slate-400 border-white/5'
                  }`}
                >
                  Classic Left Aligned
                </button>
              </div>
            </div>

            {/* Wallpaper Gallery */}
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Desktop Background Gallery</span>
                <label className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 cursor-pointer">
                  <Upload size={13} /> Custom Wallpaper
                  <input type="file" accept="image/*" onChange={handleCustomWallpaperUpload} className="hidden" />
                </label>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {DEFAULT_WALLPAPERS.map(wp => (
                  <button
                    key={wp.id}
                    onClick={() => setWallpaper(wp.url)}
                    className={`h-24 rounded-xl overflow-hidden border-2 relative group transition-all ${
                      wallpaper === wp.url ? 'border-sky-400 ring-2 ring-sky-400/30' : 'border-white/10 hover:border-white/30'
                    }`}
                  >
                    <img src={wp.url} alt={wp.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <span className="absolute bottom-1 left-2 text-[10px] bg-black/60 px-1.5 py-0.5 rounded text-white font-medium truncate max-w-[90%]">
                      {wp.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* App Icon Studio Link */}
        {activeSection === 'appicon' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white">App Icon Management</h2>
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-white/10 overflow-hidden flex items-center justify-center p-1">
                  {customIcon?.dataUrl && (
                    <img src={customIcon.dataUrl} alt="Active Icon" className="w-full h-full object-contain" />
                  )}
                </div>
                <div>
                  <span className="text-sm font-semibold text-white block">Current Launcher Icon</span>
                  <span className="text-xs text-slate-400 font-mono">com.birdbase.app · res/mipmap-*/ic_launcher.png</span>
                  <span className="text-[11px] text-emerald-400 block mt-0.5">5 density buckets generated</span>
                </div>
              </div>

              <button
                onClick={() => openApp('app-icon-studio')}
                className="px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition-colors"
              >
                Open Studio <ArrowRight size={14} />
              </button>
            </div>
          </div>
        )}

        {/* System & Display */}
        {activeSection === 'system' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white">System & Display</h2>
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-4 text-xs">
              <div>
                <span className="text-slate-300 block mb-1">Display Brightness: {brightness}%</span>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={brightness}
                  onChange={e => setBrightness(Number(e.target.value))}
                  className="w-full accent-sky-400"
                />
              </div>

              <div>
                <span className="text-slate-300 block mb-1">Master Volume: {volume}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={volume}
                  onChange={e => setVolume(Number(e.target.value))}
                  className="w-full accent-sky-400"
                />
              </div>
            </div>
          </div>
        )}

        {/* Storage */}
        {activeSection === 'storage' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white">Internal Storage</h2>
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/5 space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">32.4 GB used of 128 GB</span>
                <span className="text-slate-400">95.6 GB free</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden flex">
                <div className="bg-sky-500 h-full w-[15%]" title="Apps" />
                <div className="bg-emerald-500 h-full w-[6%]" title="System" />
                <div className="bg-purple-500 h-full w-[4%]" title="Android Gradle Cache" />
              </div>
            </div>
          </div>
        )}

        {/* About Bird PC */}
        {activeSection === 'about' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white">About Bird PC</h2>
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <span className="text-slate-400">Application ID:</span>
                <span className="font-mono text-emerald-400 font-bold">{ANDROID_PACKAGE_NAME}</span>

                <span className="text-slate-400">OS Edition:</span>
                <span className="text-white">Bird PC for Android 15</span>

                <span className="text-slate-400">Target SDK:</span>
                <span className="text-white">API 35 (Android 15)</span>

                <span className="text-slate-400">Build Toolchain:</span>
                <span className="text-white">Android Gradle 8.7.2 · Kotlin 2.0.21</span>

                <span className="text-slate-400">Processor:</span>
                <span className="text-white">ARMv8/v9 Octa-core</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
