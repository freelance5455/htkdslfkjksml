import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Star,
  ExternalLink,
  Plus,
  X,
  Compass,
  Shield,
  Search
} from 'lucide-react';

interface BrowserTab {
  id: string;
  title: string;
  url: string;
  contentKey: 'docs' | 'github' | 'gradle' | 'google';
}

export const BirdBrowser: React.FC = () => {
  const [tabs, setTabs] = useState<BrowserTab[]>([
    {
      id: 'tab-1',
      title: 'Android Developers — Jetpack Compose',
      url: 'https://developer.android.com/compose',
      contentKey: 'docs'
    },
    {
      id: 'tab-2',
      title: 'GitHub — com.birdbase.app CI',
      url: 'https://github.com/birdbase/birdpc-android',
      contentKey: 'github'
    }
  ]);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [urlInput, setUrlInput] = useState('https://developer.android.com/compose');

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const handleTabSelect = (tab: BrowserTab) => {
    setActiveTabId(tab.id);
    setUrlInput(tab.url);
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    const remaining = tabs.filter(t => t.id !== id);
    setTabs(remaining);
    if (activeTabId === id) {
      setActiveTabId(remaining[0].id);
      setUrlInput(remaining[0].url);
    }
  };

  const handleNewTab = () => {
    const newTab: BrowserTab = {
      id: `tab-${Date.now()}`,
      title: 'New Tab',
      url: 'https://www.google.com',
      contentKey: 'google'
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setUrlInput(newTab.url);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-hidden">
      {/* Browser Tab Strip */}
      <div className="flex items-center bg-slate-950 px-2 pt-2 gap-1 border-b border-white/10 overflow-x-auto custom-scrollbar">
        {tabs.map(tab => (
          <div
            key={tab.id}
            onClick={() => handleTabSelect(tab)}
            className={`group max-w-[220px] min-w-[120px] px-3 py-1.5 rounded-t-xl text-xs flex items-center justify-between gap-2 cursor-pointer transition-colors ${
              tab.id === activeTabId
                ? 'bg-slate-900 text-white font-medium border-t border-x border-white/10'
                : 'text-slate-400 hover:bg-slate-900/50 hover:text-slate-200'
            }`}
          >
            <span className="truncate">{tab.title}</span>
            {tabs.length > 1 && (
              <button
                onClick={e => handleCloseTab(tab.id, e)}
                className="opacity-0 group-hover:opacity-100 hover:text-white p-0.5 rounded"
              >
                <X size={12} />
              </button>
            )}
          </div>
        ))}

        <button
          onClick={handleNewTab}
          className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-900 hover:text-white"
          title="New Tab"
        >
          <Plus size={15} />
        </button>
      </div>

      {/* Navigation & Address Bar */}
      <div className="px-3 py-2 bg-slate-900 border-b border-white/10 flex items-center gap-2 text-xs">
        <button className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/10">
          <ArrowLeft size={16} />
        </button>
        <button className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/10">
          <ArrowRight size={16} />
        </button>
        <button className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/10">
          <RotateCw size={15} />
        </button>

        {/* Address Input */}
        <div className="flex-1 bg-slate-950 rounded-full border border-white/10 px-4 py-1.5 flex items-center gap-2 focus-within:border-sky-500">
          <Shield size={13} className="text-emerald-400 shrink-0" />
          <input
            type="text"
            value={urlInput}
            onChange={e => setUrlInput(e.target.value)}
            className="w-full bg-transparent border-none outline-none text-xs text-white"
          />
          <Star size={14} className="text-slate-400 hover:text-amber-400 cursor-pointer" />
        </div>
      </div>

      {/* Web Page Viewport */}
      <div className="flex-1 p-6 bg-slate-950 overflow-y-auto custom-scrollbar select-text">
        {activeTab.contentKey === 'docs' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="p-4 bg-slate-900 rounded-2xl border border-white/10 space-y-2">
              <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold">Android Developers Documentation</span>
              <h1 className="text-xl font-bold text-white">Jetpack Compose in Bird PC (API 35)</h1>
              <p className="text-xs text-slate-300 leading-relaxed">
                Bird PC is designed using Android’s modern declarative UI toolkit, Jetpack Compose. All desktop components—including the draggable WindowFrame, centered Taskbar, StartMenu, and live system meters—are rendered using native Compose states.
              </p>
            </div>

            <div className="p-4 bg-slate-900/60 rounded-xl border border-white/5 space-y-2">
              <h3 className="text-sm font-semibold text-white">Key Compose Dependencies</h3>
              <pre className="p-3 bg-slate-950 rounded-lg text-xs font-mono text-sky-300 overflow-x-auto">
                implementation("androidx.compose.ui:ui:1.7.5")
                implementation("androidx.compose.material3:material3:1.3.1")
                implementation("androidx.activity:activity-compose:1.9.3")
              </pre>
            </div>
          </div>
        )}

        {activeTab.contentKey === 'github' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="p-4 bg-slate-900 rounded-2xl border border-white/10 space-y-2">
              <span className="text-xs uppercase tracking-wider text-purple-400 font-bold">GitHub Repository</span>
              <h1 className="text-xl font-bold text-white">birdbase/birdpc-android</h1>
              <p className="text-xs text-slate-300 leading-relaxed">
                Automated continuous integration pipeline via GitHub Actions. Push your downloaded project to compile the installable APK without needing Android Studio or a high-end PC.
              </p>
            </div>
          </div>
        )}

        {activeTab.contentKey === 'google' && (
          <div className="max-w-xl mx-auto text-center py-16 space-y-4">
            <Compass size={48} className="mx-auto text-sky-400" />
            <h2 className="text-lg font-bold text-white">Bird PC Web Reader</h2>
            <p className="text-xs text-slate-400">
              Enter any URL or documentation link in the address bar above.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
