import React, { useState } from 'react';
import {
  Save,
  FolderOpen,
  FileText,
  Copy,
  Check,
  Code
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

export const Notepad: React.FC = () => {
  const { addNotification } = useDesktop();
  const [content, setContent] = useState<string>(
`package com.birdbase.app

import androidx.compose.runtime.Composable
import androidx.compose.material3.Text

/**
 * Bird PC Kotlin Component
 */
@Composable
fun HelloBirdPC() {
    Text("Welcome to Bird PC Native Android Desktop!")
}
`
  );
  const [fileName, setFileName] = useState('MainActivity.kt');
  const [copied, setCopied] = useState(false);

  const lines = content.split('\n');
  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;

  const handleSave = () => {
    addNotification({
      title: 'File Saved',
      message: `Saved "${fileName}" (${content.length} characters) to virtual disk.`,
      type: 'success'
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Menu / Action Bar */}
      <div className="px-4 py-2 bg-slate-900 border-b border-white/10 flex items-center justify-between text-xs">
        <div className="flex items-center gap-3">
          <FileText size={16} className="text-sky-400" />
          <input
            type="text"
            value={fileName}
            onChange={e => setFileName(e.target.value)}
            className="bg-transparent font-medium text-white border-b border-transparent hover:border-white/20 focus:border-sky-500 outline-none px-1"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            className="px-2.5 py-1 bg-sky-500/20 text-sky-400 hover:bg-sky-500/30 rounded-lg flex items-center gap-1 transition-colors"
          >
            <Save size={14} /> Save
          </button>
          <button
            onClick={handleCopy}
            className="px-2.5 py-1 bg-slate-800 text-slate-300 hover:text-white rounded-lg flex items-center gap-1 transition-colors"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />} Copy
          </button>
        </div>
      </div>

      {/* Editor Canvas with line numbers */}
      <div className="flex-1 flex overflow-hidden">
        {/* Line Numbers */}
        <div className="w-12 py-3 bg-slate-900/50 text-slate-600 font-mono text-xs text-right pr-3 select-none overflow-hidden">
          {lines.map((_, i) => (
            <div key={i} className="leading-6">{i + 1}</div>
          ))}
        </div>

        {/* Textarea */}
        <textarea
          value={content}
          onChange={e => setContent(e.target.value)}
          className="flex-1 p-3 bg-transparent text-slate-200 font-mono text-xs leading-6 outline-none resize-none custom-scrollbar select-text"
          spellCheck={false}
        />
      </div>

      {/* Footer Status Bar */}
      <div className="px-4 py-1.5 bg-slate-900/90 border-t border-white/10 flex justify-between text-[11px] text-slate-400">
        <span>Lines: {lines.length} · Words: {wordCount} · Characters: {content.length}</span>
        <span>UTF-8 · Kotlin / Plain Text</span>
      </div>
    </div>
  );
};
