import React, { useState, useEffect } from 'react';
import {
  Download,
  Package,
  FileCode,
  Terminal,
  Smartphone,
  Cloud,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  FolderTree,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  Cpu,
  ShieldCheck
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { downloadAndroidProjectZip, ExportResult } from '../../services/zipExporter';
import { ANDROID_PROJECT_FILES, ANDROID_PACKAGE_NAME } from '../../data/androidProjectFiles';
import { BuildDiagnosticInfo } from '../../types/desktop';

export const ProjectExporter: React.FC = () => {
  const { customIcon, addNotification, openApp } = useDesktop();

  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportStatusText, setExportStatusText] = useState('');
  const [lastExport, setLastExport] = useState<ExportResult | null>(null);

  const [activeTab, setActiveTab] = useState<'export' | 'guide' | 'files' | 'diagnostics'>('export');
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copiedCode, setCopiedCode] = useState(false);

  // Diagnostics info from server
  const [diagnostics, setDiagnostics] = useState<BuildDiagnosticInfo | null>(null);
  const [checkingDiag, setCheckingDiag] = useState(false);

  useEffect(() => {
    checkBuildDiagnostics();
  }, []);

  const checkBuildDiagnostics = async () => {
    setCheckingDiag(true);
    try {
      const res = await fetch('/api/build/diagnostics');
      if (res.ok) {
        const data = await res.json();
        setDiagnostics(data);
      }
    } catch {
      setDiagnostics({
        hasJava: false,
        javaVersion: null,
        hasGradle: false,
        gradleVersion: null,
        hasAndroidSdk: false,
        androidHome: null,
        platform: 'linux',
        cloudBuildAvailable: false,
        message: 'Host environment lacks Java 17+ and Android SDK. Local device or cloud build (GitHub Actions / Termux) is required to compile APK.'
      });
    } finally {
      setCheckingDiag(false);
    }
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    setExportProgress(10);
    setExportStatusText('Preparing Android project files...');

    try {
      const result = await downloadAndroidProjectZip(
        customIcon,
        (percent, status) => {
          setExportProgress(percent);
          setExportStatusText(status);
        }
      );
      setLastExport(result);
      addNotification({
        title: 'Project ZIP Downloaded',
        message: `Successfully generated ${result.fileName} (${(result.fileSizeBytes / 1024).toFixed(1)} KB, ${result.fileCount} files).`,
        type: 'success'
      });
    } catch (err: any) {
      addNotification({
        title: 'Export Failed',
        message: err.message || 'Error creating ZIP file',
        type: 'error'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const selectedFile = ANDROID_PROJECT_FILES[selectedFileIndex] || ANDROID_PROJECT_FILES[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-y-auto custom-scrollbar">
      {/* Top Warning Banner: ZIP vs APK distinction */}
      <div className="bg-sky-950/40 border-b border-sky-500/30 px-6 py-3 flex items-start gap-3">
        <HelpCircle size={18} className="text-sky-400 shrink-0 mt-0.5" />
        <div className="text-xs text-sky-200/90 leading-relaxed">
          <span className="font-semibold text-sky-300">Crucial: Do Not Rename .zip to .apk</span> —
          Renaming <code className="bg-sky-900/60 px-1 py-0.5 rounded text-sky-100">BirdPC-Android-Project.zip</code> to <code className="bg-sky-900/60 px-1 py-0.5 rounded text-sky-100">BirdPC.apk</code> does NOT compile bytecode or binary resources and will fail on Android. Follow the Build APK Guide below to generate the genuine APK.
        </div>
      </div>

      {/* Main Header */}
      <div className="p-6 border-b border-white/10 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Package className="text-emerald-400" size={22} /> APK Builder & Project Exporter
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Application ID: <span className="font-mono text-emerald-400 font-medium">{ANDROID_PACKAGE_NAME}</span> · Native Android Gradle Architecture
          </p>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={handleDownloadZip}
          disabled={isExporting}
          className={`px-5 py-2.5 rounded-xl font-semibold text-xs flex items-center gap-2 shadow-lg transition-all ${
            isExporting
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/25 active:scale-95'
          }`}
        >
          {isExporting ? (
            <>
              <RefreshCw size={16} className="animate-spin" />
              Packaging ({exportProgress}%)...
            </>
          ) : (
            <>
              <Download size={16} /> Download Project ZIP
            </>
          )}
        </button>
      </div>

      {/* Export Progress Bar */}
      {isExporting && (
        <div className="px-6 py-3 bg-slate-800/60 border-b border-white/5 space-y-1.5 animate-in fade-in">
          <div className="flex justify-between text-xs text-slate-300">
            <span>{exportStatusText}</span>
            <span className="font-mono text-emerald-400">{exportProgress}%</span>
          </div>
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-200"
              style={{ width: `${exportProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Last Export Card */}
      {lastExport && !isExporting && (
        <div className="mx-6 mt-4 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <CheckCircle2 size={22} />
            </div>
            <div>
              <span className="text-xs font-semibold text-white block">Archive Generated Successfully</span>
              <span className="text-[11px] text-emerald-300 font-mono">
                {lastExport.fileName} · {(lastExport.fileSizeBytes / 1024).toFixed(1)} KB · {lastExport.fileCount} items
              </span>
            </div>
          </div>
          <button
            onClick={handleDownloadZip}
            className="px-3 py-1.5 bg-emerald-600/60 hover:bg-emerald-600 text-white rounded-lg text-xs font-medium transition-colors"
          >
            Re-Download
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 px-6 pt-4 border-b border-white/10">
        <button
          onClick={() => setActiveTab('export')}
          className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'export'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Package size={15} /> Project Package Details
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'guide'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Smartphone size={15} /> Build APK Guide (Mobile & PC)
        </button>
        <button
          onClick={() => setActiveTab('files')}
          className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'files'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileCode size={15} /> Source Code Viewer ({ANDROID_PROJECT_FILES.length})
        </button>
        <button
          onClick={() => setActiveTab('diagnostics')}
          className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'diagnostics'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Cpu size={15} /> Build Environment Diagnostics
        </button>
      </div>

      {/* Tab 1: Export Overview */}
      {activeTab === 'export' && (
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-slate-400">Application ID</span>
              <div className="text-sm font-bold text-white font-mono">{ANDROID_PACKAGE_NAME}</div>
              <span className="text-[11px] text-slate-400">Strictly preserved in manifest & gradle</span>
            </div>

            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-slate-400">Target Framework</span>
              <div className="text-sm font-bold text-white">Kotlin 2.0 + Jetpack Compose</div>
              <span className="text-[11px] text-slate-400">Compile SDK 35 (Android 15)</span>
            </div>

            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-slate-400">Included Custom Icon</span>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                {customIcon?.dataUrl ? (
                  <>
                    <img src={customIcon.dataUrl} alt="Icon" className="w-5 h-5 rounded object-cover" />
                    <span>Injected (mdpi - xxxhdpi)</span>
                  </>
                ) : (
                  <span>Default Penguin Mascot</span>
                )}
              </div>
              <button
                onClick={() => openApp('app-icon-studio')}
                className="text-[11px] text-sky-400 hover:underline inline-block mt-0.5"
              >
                Change in App Icon Studio →
              </button>
            </div>
          </div>

          {/* Project Structure Highlights */}
          <div className="p-5 bg-slate-800/30 rounded-2xl border border-white/10 space-y-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <FolderTree size={16} className="text-emerald-400" /> What's Included in the ZIP Archive
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
              <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 space-y-1">
                <span className="font-semibold text-white">⚙️ Build Scripts & Toolchain</span>
                <p className="text-slate-400 leading-relaxed">
                  settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, gradle.properties, gradlew, gradlew.bat, and wrapper properties.
                </p>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 space-y-1">
                <span className="font-semibold text-white">📱 Kotlin Source Code</span>
                <p className="text-slate-400 leading-relaxed">
                  MainActivity.kt, BirdPCApplication.kt, DesktopScreen.kt, Taskbar.kt, StartMenu.kt, WindowFrame.kt, AppIconManager.kt.
                </p>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 space-y-1">
                <span className="font-semibold text-white">🎨 Android XML Resources</span>
                <p className="text-slate-400 leading-relaxed">
                  strings.xml, colors.xml, themes.xml, adaptive vector drawables, backup_rules.xml, and data_extraction_rules.xml.
                </p>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 space-y-1">
                <span className="font-semibold text-white">🚀 Automated Build Helpers</span>
                <p className="text-slate-400 leading-relaxed">
                  GitHub Actions CI workflow (.github/workflows/build-apk.yml) for 1-click cloud APK build, and build-apk-termux.sh for Android phones.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Build APK Guide */}
      {activeTab === 'guide' && (
        <div className="p-6 space-y-6">
          {/* Method Selector */}
          <div className="space-y-4">
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                <Smartphone size={18} /> Method 1: Build Directly on Android Phone (No PC Required!)
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                If you only have an Android phone, you can compile the real native APK directly in Termux using our bundled automation script:
              </p>
              <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 font-normal pl-2">
                <li>
                  Download <strong>BirdPC-Android-Project.zip</strong> using the download button above.
                </li>
                <li>
                  Install <strong>ZArchiver</strong> and <strong>Termux</strong> from F-Droid or GitHub.
                </li>
                <li>
                  In ZArchiver, extract <code className="text-emerald-300">BirdPC-Android-Project.zip</code> to your internal storage (e.g. into <code className="text-emerald-300">/sdcard/Download/BirdPC</code>).
                </li>
                <li>
                  Open Termux and run the automated build command:
                  <div className="my-2 p-3 bg-slate-950 rounded-xl font-mono text-[11px] text-emerald-300 border border-white/10 select-text">
                    cd /sdcard/Download/BirdPC<br />
                    bash build-apk-termux.sh
                  </div>
                </li>
                <li>
                  The script will automatically install OpenJDK 17, execute <code className="text-emerald-300">./gradlew assembleDebug</code>, and place your installable APK at:
                  <div className="mt-1 font-mono text-emerald-400">/sdcard/Download/BirdPC-debug.apk</div>
                </li>
                <li>
                  Open ZArchiver or your phone's File Manager and tap the APK to install!
                </li>
              </ol>
            </div>

            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-sky-400 font-semibold text-sm">
                <Cloud size={18} /> Method 2: Free 1-Click Cloud Build with GitHub Actions
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                The exported project includes a pre-configured GitHub Actions workflow (<code className="text-sky-300">.github/workflows/build-apk.yml</code>):
              </p>
              <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 pl-2">
                <li>Extract the downloaded project ZIP into a folder.</li>
                <li>Create a free repository on GitHub and push the code:
                  <div className="my-2 p-3 bg-slate-950 rounded-xl font-mono text-[11px] text-sky-300 border border-white/10 select-text">
                    git init<br />
                    git add .<br />
                    git commit -m "Initial Bird PC release"<br />
                    git branch -M main<br />
                    git remote add origin https://github.com/YOUR_USERNAME/BirdPC.git<br />
                    git push -u origin main
                  </div>
                </li>
                <li>GitHub Actions will build the project automatically in ~2 minutes.</li>
                <li>Go to the <strong>Actions</strong> tab on your GitHub repository, click the latest workflow run, and download the compiled <strong>BirdPC-Debug-APK</strong>!</li>
              </ol>
            </div>

            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-purple-400 font-semibold text-sm">
                <Terminal size={18} /> Method 3: Android Studio on PC / Mac
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300 pl-2">
                <li>Extract the ZIP and open Android Studio (Iguana, Jellyfish, Koala or newer).</li>
                <li>Select <strong>File &gt; Open</strong> and pick the extracted folder.</li>
                <li>Allow Gradle to sync automatically.</li>
                <li>Click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</li>
                <li>Your APK will be located under: <code className="text-purple-300">app/build/outputs/apk/debug/app-debug.apk</code>.</li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Source Code Viewer */}
      {activeTab === 'files' && (
        <div className="flex-1 flex overflow-hidden p-6 gap-4 min-h-[420px]">
          {/* File List Sidebar */}
          <div className="w-64 bg-slate-800/40 rounded-2xl border border-white/10 overflow-y-auto custom-scrollbar p-2 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 px-3 py-2 block">
              Project Files ({ANDROID_PROJECT_FILES.length})
            </span>
            {ANDROID_PROJECT_FILES.map((file, idx) => (
              <button
                key={file.path}
                onClick={() => setSelectedFileIndex(idx)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-colors flex items-center gap-2 truncate ${
                  selectedFileIndex === idx
                    ? 'bg-emerald-500/20 text-emerald-400 font-medium border border-emerald-500/30'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                <FileCode size={14} className="shrink-0" />
                <span className="truncate">{file.path}</span>
              </button>
            ))}
          </div>

          {/* File Content Preview */}
          <div className="flex-1 bg-slate-950 rounded-2xl border border-white/10 flex flex-col overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400">{selectedFile.path}</span>
                <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded">
                  {selectedFile.category}
                </span>
              </div>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] flex items-center gap-1.5 transition-colors"
              >
                {copiedCode ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                {copiedCode ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="p-4 flex-1 overflow-auto font-mono text-xs text-slate-300 leading-relaxed custom-scrollbar select-text">
              {selectedFile.content}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 4: Diagnostics */}
      {activeTab === 'diagnostics' && (
        <div className="p-6 space-y-4">
          <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <ShieldCheck size={18} className="text-emerald-400" /> Host Build Diagnostics Report
              </h3>
              <button
                onClick={checkBuildDiagnostics}
                disabled={checkingDiag}
                className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1"
              >
                <RefreshCw size={12} className={checkingDiag ? 'animate-spin' : ''} /> Refresh
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              In adherence to our strict transparency guidelines: Bird PC reports the exact toolchain status of the host container and never pretends compilation succeeded when SDK tools are absent.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5 space-y-1">
                <span className="text-[11px] text-slate-400">JDK / Java 17+</span>
                <div className="text-xs font-semibold flex items-center gap-1.5">
                  {diagnostics?.hasJava ? (
                    <span className="text-emerald-400">✓ Detected ({diagnostics.javaVersion})</span>
                  ) : (
                    <span className="text-amber-400">✗ Not installed on host</span>
                  )}
                </div>
              </div>

              <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5 space-y-1">
                <span className="text-[11px] text-slate-400">Gradle Daemon</span>
                <div className="text-xs font-semibold flex items-center gap-1.5">
                  {diagnostics?.hasGradle ? (
                    <span className="text-emerald-400">✓ Detected ({diagnostics.gradleVersion})</span>
                  ) : (
                    <span className="text-amber-400">✗ Not installed on host</span>
                  )}
                </div>
              </div>

              <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5 space-y-1">
                <span className="text-[11px] text-slate-400">Android SDK (API 35)</span>
                <div className="text-xs font-semibold flex items-center gap-1.5">
                  {diagnostics?.hasAndroidSdk ? (
                    <span className="text-emerald-400">✓ Configured</span>
                  ) : (
                    <span className="text-amber-400">✗ Not installed on host</span>
                  )}
                </div>
              </div>
            </div>

            <div className="p-4 bg-sky-950/40 rounded-xl border border-sky-500/20 text-xs text-sky-200 space-y-1">
              <span className="font-semibold text-white block">Recommended Build Action:</span>
              <span>
                Download the complete project ZIP via <strong>Download Project ZIP</strong> and compile it with Termux on your Android phone or with GitHub Actions cloud build for free in 2 minutes.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
