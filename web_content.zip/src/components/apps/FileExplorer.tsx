import React, { useState } from 'react';
import {
  Folder,
  FileText,
  FileCode,
  Image as ImageIcon,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  RefreshCw,
  Search,
  Plus,
  Trash2,
  Download,
  FolderPlus
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { ANDROID_PROJECT_FILES } from '../../data/androidProjectFiles';

interface VirtualItem {
  id: string;
  name: string;
  type: 'folder' | 'file';
  size?: string;
  updated: string;
  category?: string;
  content?: string;
}

export const FileExplorer: React.FC = () => {
  const { openApp, addNotification } = useDesktop();

  const [currentPath, setCurrentPath] = useState<string>('Android Project/app/src/main');
  const [history, setHistory] = useState<string[]>(['Android Project/app/src/main']);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  // Initial virtual files
  const [customFiles, setCustomFiles] = useState<VirtualItem[]>([
    { id: 'f-1', name: 'README.md', type: 'file', size: '2.4 KB', updated: 'Today', content: '# Bird PC Documentation\nNative Android desktop environment for com.birdbase.app.' },
    { id: 'f-2', name: 'Notes.txt', type: 'file', size: '1.1 KB', updated: 'Today', content: 'Remember to rebuild the APK after uploading a custom launcher icon!' }
  ]);

  const navigateTo = (path: string) => {
    const newHist = history.slice(0, historyIndex + 1);
    newHist.push(path);
    setHistory(newHist);
    setHistoryIndex(newHist.length - 1);
    setCurrentPath(path);
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setCurrentPath(history[historyIndex - 1]);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setCurrentPath(history[historyIndex + 1]);
    }
  };

  const handleUp = () => {
    const parts = currentPath.split('/');
    if (parts.length > 1) {
      parts.pop();
      navigateTo(parts.join('/'));
    }
  };

  // Build items list according to current directory
  const getItemsForCurrentPath = (): VirtualItem[] => {
    if (currentPath === 'Android Project') {
      return [
        { id: 'dir-app', name: 'app', type: 'folder', updated: 'Today' },
        { id: 'dir-gradle', name: 'gradle', type: 'folder', updated: 'Today' },
        { id: 'f-settings', name: 'settings.gradle.kts', type: 'file', size: '1.2 KB', updated: 'Today' },
        { id: 'f-build', name: 'build.gradle.kts', type: 'file', size: '820 B', updated: 'Today' },
        { id: 'f-props', name: 'gradle.properties', type: 'file', size: '340 B', updated: 'Today' }
      ];
    }

    if (currentPath === 'Android Project/app') {
      return [
        { id: 'dir-src', name: 'src', type: 'folder', updated: 'Today' },
        { id: 'f-app-build', name: 'build.gradle.kts', type: 'file', size: '3.4 KB', updated: 'Today' },
        { id: 'f-proguard', name: 'proguard-rules.pro', type: 'file', size: '640 B', updated: 'Today' }
      ];
    }

    if (currentPath === 'Android Project/app/src/main') {
      return [
        { id: 'dir-kotlin', name: 'kotlin (com.birdbase.app)', type: 'folder', updated: 'Today' },
        { id: 'dir-res', name: 'res (values & mipmap)', type: 'folder', updated: 'Today' },
        { id: 'f-manifest', name: 'AndroidManifest.xml', type: 'file', size: '1.9 KB', updated: 'Today' }
      ];
    }

    if (currentPath === 'Documents') {
      return customFiles;
    }

    if (currentPath === 'Downloads') {
      return [
        { id: 'dl-1', name: 'BirdPC-Android-Project.zip', type: 'file', size: '142.8 KB', updated: 'Today' },
        { id: 'dl-2', name: 'build-apk-termux.sh', type: 'file', size: '1.2 KB', updated: 'Today' }
      ];
    }

    // Default: Root
    return [
      { id: 'nav-android', name: 'Android Project', type: 'folder', updated: 'Today' },
      { id: 'nav-docs', name: 'Documents', type: 'folder', updated: 'Today' },
      { id: 'nav-dl', name: 'Downloads', type: 'folder', updated: 'Today' }
    ];
  };

  const handleCreateFile = () => {
    const name = prompt('Enter new filename (e.g. MyConfig.txt):');
    if (!name) return;
    const newF: VirtualItem = {
      id: `f-${Date.now()}`,
      name,
      type: 'file',
      size: '0 B',
      updated: 'Just now',
      content: ''
    };
    setCustomFiles(prev => [...prev, newF]);
    addNotification({ title: 'File Created', message: `Created "${name}" in ${currentPath}.`, type: 'info' });
  };

  const handleItemClick = (item: VirtualItem) => {
    if (item.type === 'folder') {
      navigateTo(`${currentPath}/${item.name}`);
    } else {
      openApp('notepad');
    }
  };

  const items = getItemsForCurrentPath().filter(i =>
    i.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-hidden">
      {/* Top Toolbar */}
      <div className="px-4 py-2 bg-slate-950 border-b border-white/10 flex items-center justify-between gap-3 text-xs">
        {/* Navigation Arrows */}
        <div className="flex items-center gap-1 text-slate-400">
          <button
            onClick={handleBack}
            disabled={historyIndex <= 0}
            className="p-1 rounded hover:bg-white/10 disabled:opacity-30"
          >
            <ArrowLeft size={16} />
          </button>
          <button
            onClick={handleForward}
            disabled={historyIndex >= history.length - 1}
            className="p-1 rounded hover:bg-white/10 disabled:opacity-30"
          >
            <ArrowRight size={16} />
          </button>
          <button onClick={handleUp} className="p-1 rounded hover:bg-white/10">
            <ArrowUp size={16} />
          </button>
        </div>

        {/* Breadcrumb Path Bar */}
        <div className="flex-1 bg-slate-800/80 rounded-lg px-3 py-1.5 border border-white/10 font-mono text-xs text-slate-200 truncate flex items-center gap-1.5">
          <Folder size={14} className="text-yellow-400 shrink-0" />
          <span>{currentPath}</span>
        </div>

        {/* Search */}
        <div className="relative w-48">
          <Search size={14} className="absolute left-2.5 top-2 text-slate-400" />
          <input
            type="text"
            placeholder="Search folder..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-800 border border-white/10 rounded-lg pl-8 pr-3 py-1 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>

        {/* New File / Action */}
        <button
          onClick={handleCreateFile}
          className="px-2.5 py-1 bg-sky-500 hover:bg-sky-400 text-white rounded-lg flex items-center gap-1 transition-colors"
        >
          <Plus size={14} /> New File
        </button>
      </div>

      {/* Main View (Sidebar + Content) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Quick Navigation Tree */}
        <div className="w-52 bg-slate-950/60 border-r border-white/10 p-3 space-y-1 text-xs">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 block mb-1">
            Quick Access
          </span>
          <button
            onClick={() => navigateTo('Android Project')}
            className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 transition-colors ${
              currentPath.startsWith('Android Project')
                ? 'bg-sky-500/20 text-sky-400 font-medium'
                : 'text-slate-300 hover:bg-white/5'
            }`}
          >
            <Folder size={15} className="text-emerald-400 shrink-0" />
            <span className="truncate">Android Project</span>
          </button>
          <button
            onClick={() => navigateTo('Documents')}
            className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 transition-colors ${
              currentPath === 'Documents'
                ? 'bg-sky-500/20 text-sky-400 font-medium'
                : 'text-slate-300 hover:bg-white/5'
            }`}
          >
            <Folder size={15} className="text-yellow-400 shrink-0" />
            <span className="truncate">Documents</span>
          </button>
          <button
            onClick={() => navigateTo('Downloads')}
            className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 transition-colors ${
              currentPath === 'Downloads'
                ? 'bg-sky-500/20 text-sky-400 font-medium'
                : 'text-slate-300 hover:bg-white/5'
            }`}
          >
            <Folder size={15} className="text-sky-400 shrink-0" />
            <span className="truncate">Downloads</span>
          </button>

          <div className="pt-4 border-t border-white/10">
            <button
              onClick={() => openApp('project-exporter')}
              className="w-full text-left px-2.5 py-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded-lg flex items-center gap-2"
            >
              <Download size={14} /> Export All as ZIP
            </button>
          </div>
        </div>

        {/* Right Content Items Grid */}
        <div className="flex-1 p-5 overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
            {items.map(item => (
              <button
                key={item.id}
                onDoubleClick={() => handleItemClick(item)}
                onClick={() => handleItemClick(item)}
                className="p-3 rounded-xl bg-slate-800/40 hover:bg-white/10 border border-white/5 flex flex-col items-center text-center gap-2 transition-all active:scale-95 group"
              >
                <div className="w-12 h-12 flex items-center justify-center text-3xl">
                  {item.type === 'folder' ? (
                    <Folder size={36} className="text-yellow-400 group-hover:scale-105 transition-transform" />
                  ) : item.name.endsWith('.kt') || item.name.endsWith('.gradle.kts') ? (
                    <FileCode size={34} className="text-purple-400" />
                  ) : (
                    <FileText size={34} className="text-sky-400" />
                  )}
                </div>
                <div className="w-full">
                  <span className="text-xs font-medium text-slate-100 truncate block w-full">
                    {item.name}
                  </span>
                  {item.size && (
                    <span className="text-[10px] text-slate-400 block">{item.size}</span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {items.length === 0 && (
            <div className="text-center py-12 text-slate-500 text-xs">
              Folder is empty
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
