import React, { useState, useEffect } from 'react';
import {
  Activity,
  Cpu,
  HardDrive,
  Wifi,
  Trash2,
  RefreshCw,
  Layers
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { DESKTOP_APPS } from '../../data/appsList';

export const TaskManager: React.FC = () => {
  const { openWindows, closeWindow, addNotification } = useDesktop();

  const [activeTab, setActiveTab] = useState<'processes' | 'performance'>('processes');
  const [cpuHistory, setCpuHistory] = useState<number[]>([12, 18, 25, 20, 15, 30, 22, 19, 14, 28, 16, 22]);
  const [currentCpu, setCurrentCpu] = useState(22);
  const [currentRamMB, setCurrentRamMB] = useState(3420);

  // Live simulation of performance graphs
  useEffect(() => {
    const interval = setInterval(() => {
      const nextCpu = Math.floor(12 + Math.random() * 26);
      setCurrentCpu(nextCpu);
      setCpuHistory(prev => [...prev.slice(1), nextCpu]);

      setCurrentRamMB(prev => {
        const delta = Math.floor((Math.random() - 0.5) * 40);
        return Math.min(6144, Math.max(2800, prev + delta));
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  const handleEndTask = (windowId: string, title: string) => {
    closeWindow(windowId);
    addNotification({
      title: 'Task Ended',
      message: `Terminated process "${title}".`,
      type: 'info'
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-hidden">
      {/* Top Tabs */}
      <div className="px-5 py-2.5 bg-slate-950 border-b border-white/10 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <Activity size={18} className="text-sky-400" />
          <span className="font-bold text-white">Task Manager</span>
        </div>

        <div className="flex bg-slate-800 p-0.5 rounded-lg border border-white/5">
          <button
            onClick={() => setActiveTab('processes')}
            className={`px-3 py-1 rounded-md transition-colors ${
              activeTab === 'processes' ? 'bg-sky-500 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Processes ({openWindows.length})
          </button>
          <button
            onClick={() => setActiveTab('performance')}
            className={`px-3 py-1 rounded-md transition-colors ${
              activeTab === 'performance' ? 'bg-sky-500 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Performance
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-5 overflow-y-auto custom-scrollbar">
        {activeTab === 'processes' ? (
          <div className="space-y-4">
            {/* Header Metrics Summary */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-semibold">Total CPU</span>
                  <span className="text-base font-bold text-sky-400">{currentCpu}%</span>
                </div>
                <Cpu size={20} className="text-sky-400/60" />
              </div>

              <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-semibold">Total RAM</span>
                  <span className="text-base font-bold text-purple-400">{(currentRamMB / 1024).toFixed(1)} / 8.0 GB</span>
                </div>
                <Layers size={20} className="text-purple-400/60" />
              </div>

              <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-semibold">Network</span>
                  <span className="text-base font-bold text-emerald-400">1.4 MB/s</span>
                </div>
                <Wifi size={20} className="text-emerald-400/60" />
              </div>
            </div>

            {/* Processes Table */}
            <div className="bg-slate-800/30 rounded-2xl border border-white/10 overflow-hidden">
              <div className="grid grid-cols-12 px-4 py-2 bg-slate-950/60 text-[11px] font-semibold text-slate-400 border-b border-white/5">
                <span className="col-span-6">Application / Task</span>
                <span className="col-span-2 text-right">CPU</span>
                <span className="col-span-2 text-right">Memory</span>
                <span className="col-span-2 text-right">Action</span>
              </div>

              <div className="divide-y divide-white/5 text-xs">
                {openWindows.map((win, idx) => {
                  const simulatedCpu = ((idx % 3) * 3 + 2).toFixed(1);
                  const simulatedMem = (110 + (idx * 45)).toFixed(0);

                  return (
                    <div
                      key={win.id}
                      className="grid grid-cols-12 px-4 py-2.5 items-center hover:bg-white/5 transition-colors"
                    >
                      <div className="col-span-6 flex items-center gap-2.5 truncate">
                        <div className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="font-medium text-slate-200 truncate">{win.title}</span>
                      </div>
                      <span className="col-span-2 text-right font-mono text-slate-400">{simulatedCpu}%</span>
                      <span className="col-span-2 text-right font-mono text-slate-400">{simulatedMem} MB</span>
                      <div className="col-span-2 text-right">
                        <button
                          onClick={() => handleEndTask(win.id, win.title)}
                          className="px-2 py-0.5 bg-rose-950 hover:bg-rose-900 border border-rose-500/30 text-rose-300 rounded text-[11px] transition-colors"
                        >
                          End Task
                        </button>
                      </div>
                    </div>
                  );
                })}

                {openWindows.length === 0 && (
                  <div className="py-8 text-center text-slate-500 text-xs">
                    No active user window processes
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          /* Performance Tab with Live SVG Charts */
          <div className="space-y-6">
            {/* CPU Waveform Graph */}
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/10 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <Cpu size={15} className="text-sky-400" /> CPU Utilization ({currentCpu}%)
                </span>
                <span className="text-[11px] text-slate-400">Octa-Core ARM64 (Snapdragon 8 Gen 3)</span>
              </div>

              <div className="h-28 bg-slate-950 rounded-xl p-2 border border-white/5 flex items-end">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 120 40" preserveAspectRatio="none">
                  {/* Grid lines */}
                  <line x1="0" y1="10" x2="120" y2="10" stroke="#334155" strokeWidth="0.5" strokeDasharray="2,2" />
                  <line x1="0" y1="20" x2="120" y2="20" stroke="#334155" strokeWidth="0.5" strokeDasharray="2,2" />
                  <line x1="0" y1="30" x2="120" y2="30" stroke="#334155" strokeWidth="0.5" strokeDasharray="2,2" />

                  {/* CPU Area / Line */}
                  <polyline
                    fill="none"
                    stroke="#38BDF8"
                    strokeWidth="2"
                    points={cpuHistory
                      .map((val, idx) => `${(idx / (cpuHistory.length - 1)) * 120},${40 - (val / 100) * 40}`)
                      .join(' ')}
                  />
                </svg>
              </div>
            </div>

            {/* Memory Waveform Graph */}
            <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/10 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <Layers size={15} className="text-purple-400" /> Memory Usage ({(currentRamMB / 1024).toFixed(1)} GB / 8.0 GB)
                </span>
                <span className="text-[11px] text-slate-400">LPDDR5X RAM</span>
              </div>

              <div className="h-10 bg-slate-950 rounded-xl overflow-hidden border border-white/5 flex items-center px-1">
                <div
                  className="h-6 bg-purple-500 rounded-lg transition-all duration-300 flex items-center justify-end pr-2 text-[10px] font-bold text-white shadow-md shadow-purple-500/30"
                  style={{ width: `${(currentRamMB / 8192) * 100}%` }}
                >
                  {Math.round((currentRamMB / 8192) * 100)}%
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
