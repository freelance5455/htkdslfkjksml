import React, { useState, useRef } from 'react';
import {
  Upload,
  RotateCcw,
  Check,
  X,
  AlertTriangle,
  Layers,
  Image as ImageIcon,
  Sparkles,
  Info,
  Download,
  FolderOpen
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { processUploadedIconFile, generateDefaultBirdIcon } from '../../services/iconGenerator';
import { CustomAppIconData } from '../../types/desktop';

export const AppIconStudio: React.FC = () => {
  const { customIcon, setCustomIcon, addNotification, openApp } = useDesktop();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [stagedIcon, setStagedIcon] = useState<CustomAppIconData | null>(null);
  const [cropOffset, setCropOffset] = useState({ x: 0, y: 0 });
  const [cropZoom, setCropZoom] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'preview' | 'densities' | 'manifest'>('preview');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate format
    const validTypes = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'];
    if (!validTypes.includes(file.type) && !file.name.match(/\.(png|jpe?g|webp|svg)$/i)) {
      setErrorMessage('Please upload a valid image file (PNG, JPEG, WebP, or SVG).');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const processed = await processUploadedIconFile(file);
      setStagedIcon(processed);
      addNotification({
        title: 'Icon Uploaded',
        message: `Uploaded "${file.name}" (${Math.round(file.size / 1024)} KB). Preview and click Apply.`,
        type: 'info'
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to process image file.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApply = () => {
    if (!stagedIcon) return;
    setCustomIcon(stagedIcon);
    setStagedIcon(null);
    addNotification({
      title: 'Launcher Icon Updated',
      message: 'App icon applied to Bird PC and Android project resources. Rebuild APK to reflect on device.',
      type: 'success'
    });
  };

  const handleCancel = () => {
    setStagedIcon(null);
    setErrorMessage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleResetToDefault = () => {
    const defIcon = generateDefaultBirdIcon();
    setCustomIcon(defIcon);
    setStagedIcon(null);
    addNotification({
      title: 'Icon Reset',
      message: 'Restored default Cowboy Penguin mascot launcher icon.',
      type: 'info'
    });
  };

  const activeDisplayIcon = stagedIcon || customIcon;

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 overflow-y-auto custom-scrollbar select-none">
      {/* Top Banner / Education */}
      <div className="bg-amber-950/40 border-b border-amber-600/30 px-5 py-3 flex items-start gap-3">
        <AlertTriangle size={20} className="text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-200/90 leading-relaxed">
          <strong className="text-amber-300 font-semibold block">Important Android Packaging Notice:</strong>
          Updating the launcher icon modifies resource mipmaps in <code className="bg-amber-900/60 px-1 py-0.5 rounded text-amber-200">app/src/main/res/mipmap-*/</code>.
          On standard Android OS, changes to launcher icons require rebuilding and reinstalling the APK, or using component-alias switching.
        </div>
      </div>

      {/* Main Studio Toolbar */}
      <div className="p-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="text-sky-400" size={22} /> App Icon Studio
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Target Package: <span className="font-mono text-sky-400">com.birdbase.app</span> · App Name: Bird PC
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="px-4 py-2 bg-sky-500 hover:bg-sky-400 active:scale-95 text-white font-medium text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-sky-500/20 transition-all"
            >
              <Upload size={16} /> Upload App Icon
            </button>

            <button
              onClick={handleResetToDefault}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 text-xs rounded-xl flex items-center gap-1.5 transition-all border border-white/10"
              title="Reset to default cowboy penguin mascot"
            >
              <RotateCcw size={15} /> Reset Default
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
            <AlertTriangle size={16} className="text-rose-400 shrink-0" />
            {errorMessage}
          </div>
        )}

        {/* Action Bar for Staged Icon */}
        {stagedIcon && (
          <div className="p-4 rounded-2xl bg-sky-950/40 border border-sky-500/30 flex flex-wrap items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-sky-400/50 bg-slate-900">
                <img src={stagedIcon.dataUrl} alt="Staged" className="w-full h-full object-cover" />
              </div>
              <div>
                <span className="text-xs font-semibold text-white block">Unapplied Custom Icon</span>
                <span className="text-[11px] text-sky-300">{stagedIcon.fileName} ({Math.round(stagedIcon.sizeBytes / 1024)} KB)</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleApply}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-600/30 transition-all"
              >
                <Check size={16} /> Apply to Project
              </button>
              <button
                onClick={handleCancel}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl flex items-center gap-1.5 transition-all border border-white/10"
              >
                <X size={15} /> Cancel
              </button>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-white/10 pb-1">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'preview'
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ImageIcon size={15} /> Preview & Square Crop
          </button>
          <button
            onClick={() => setActiveTab('densities')}
            className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'densities'
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers size={15} /> Density Mipmaps (mdpi to xxxhdpi)
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'manifest'
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Info size={15} /> Manifest & Rebuild Guide
          </button>
        </div>

        {/* Tab 1: Preview & Crop */}
        {activeTab === 'preview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Square Crop & Center Preview Box */}
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                  Square Icon Canvas (192 x 192 px)
                </span>
                <span className="text-[11px] text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800">
                  1:1 Ratio Guaranteed
                </span>
              </div>

              <div className="relative w-48 h-48 mx-auto bg-slate-950 rounded-2xl border-2 border-dashed border-sky-500/40 flex items-center justify-center overflow-hidden shadow-inner group">
                {activeDisplayIcon?.dataUrl ? (
                  <img
                    src={activeDisplayIcon.dataUrl}
                    alt="Active Icon"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-4 text-slate-500 text-xs">
                    No icon loaded
                  </div>
                )}

                {/* Cropping Grid Overlay */}
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-20">
                  <div className="border-r border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-b border-white" />
                  <div className="border-r border-white" />
                  <div className="border-r border-white" />
                  <div />
                </div>
              </div>

              <div className="text-[11px] text-slate-400 text-center leading-normal">
                Non-square images are automatically centered and cropped to an exact square canvas to prevent distortion on Android devices.
              </div>
            </div>

            {/* Android Device Mockups (Standard vs Adaptive Round) */}
            <div className="p-5 bg-slate-800/40 rounded-2xl border border-white/10 space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 block">
                Android Launcher Rendering Previews
              </span>

              <div className="grid grid-cols-2 gap-4">
                {/* Standard Squircle / Rounded Rect */}
                <div className="p-4 bg-slate-900/80 rounded-xl border border-white/5 flex flex-col items-center gap-3 text-center">
                  <div className="w-20 h-20 rounded-2xl bg-slate-800 shadow-xl overflow-hidden border border-white/10 p-1 flex items-center justify-center">
                    {activeDisplayIcon?.dataUrl && (
                      <img
                        src={activeDisplayIcon.dataUrl}
                        alt="Square"
                        className="w-full h-full object-cover rounded-xl"
                      />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-white block">Standard Launcher</span>
                    <span className="text-[10px] text-slate-400">@mipmap/ic_launcher</span>
                  </div>
                </div>

                {/* Adaptive Round Circle (Pixel / OneUI) */}
                <div className="p-4 bg-slate-900/80 rounded-xl border border-white/5 flex flex-col items-center gap-3 text-center">
                  <div className="w-20 h-20 rounded-full bg-slate-800 shadow-xl overflow-hidden border border-white/10 p-1 flex items-center justify-center">
                    {activeDisplayIcon?.adaptiveRoundDataUrl ? (
                      <img
                        src={activeDisplayIcon.adaptiveRoundDataUrl}
                        alt="Round"
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : activeDisplayIcon?.dataUrl ? (
                      <img
                        src={activeDisplayIcon.dataUrl}
                        alt="Round"
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : null}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-white block">Adaptive Circle</span>
                    <span className="text-[10px] text-slate-400">@mipmap/ic_launcher_round</span>
                  </div>
                </div>
              </div>

              {/* Status & Export Button */}
              <div className="pt-2">
                <button
                  onClick={() => openApp('project-exporter')}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-sky-400 hover:text-sky-300 text-xs font-medium rounded-xl border border-sky-500/30 flex items-center justify-center gap-2 transition-colors"
                >
                  <Download size={15} /> Export Project ZIP with this Icon
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Density Mipmaps Breakdown */}
        {activeTab === 'densities' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-800/40 rounded-xl border border-white/10">
              <h3 className="text-sm font-semibold text-white mb-1">Generated Android Density Buckets</h3>
              <p className="text-xs text-slate-400">
                Bird PC automatically generates PNG assets for all 5 official Android display densities to ensure crisp scaling on budget phones, tablets, and flagship AMOLED displays.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {[
                { label: 'mdpi', size: '48 x 48', key: 'mdpi', scale: '1.0x', desc: 'Older & budget devices' },
                { label: 'hdpi', size: '72 x 72', key: 'hdpi', scale: '1.5x', desc: 'Standard 720p screens' },
                { label: 'xhdpi', size: '96 x 96', key: 'xhdpi', scale: '2.0x', desc: '1080p FHD phones' },
                { label: 'xxhdpi', size: '144 x 144', key: 'xxhdpi', scale: '3.0x', desc: 'QHD & high-res screens' },
                { label: 'xxxhdpi', size: '192 x 192', key: 'xxxhdpi', scale: '4.0x', desc: 'Flagship 4K & Ultra DPI' }
              ].map(item => {
                const imgData = activeDisplayIcon?.densityDrawables?.[item.key as keyof CustomAppIconData['densityDrawables']];
                return (
                  <div
                    key={item.key}
                    className="p-3.5 bg-slate-800/60 rounded-xl border border-white/5 flex flex-col items-center text-center gap-2"
                  >
                    <div className="w-16 h-16 bg-slate-900 rounded-lg flex items-center justify-center border border-white/10 overflow-hidden p-1">
                      {imgData ? (
                        <img src={imgData} alt={item.label} className="max-w-full max-h-full object-contain" />
                      ) : (
                        <span className="text-[10px] text-slate-600">None</span>
                      )}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-sky-400 block">{item.label}</span>
                      <span className="text-[11px] font-mono text-slate-300 block">{item.size}</span>
                      <span className="text-[10px] text-slate-500 block">{item.scale}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 3: Manifest Configuration & Rebuild Guide */}
        {activeTab === 'manifest' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-800/40 rounded-xl border border-white/10 space-y-3">
              <h3 className="text-sm font-semibold text-white">AndroidManifest.xml Configuration</h3>
              <pre className="p-3 bg-slate-950 rounded-lg font-mono text-xs text-sky-300 overflow-x-auto leading-relaxed border border-white/10">
{`<application
    android:name=".BirdPCApplication"
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"
    android:label="@string/app_name"
    android:theme="@style/Theme.BirdPC">

    <activity
        android:name=".MainActivity"
        android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
    </activity>

    <!-- Supported Component-Alias for Runtime Switching -->
    <activity-alias
        android:name=".MainActivityCustomIcon"
        android:enabled="false"
        android:exported="true"
        android:icon="@mipmap/ic_launcher"
        android:targetActivity=".MainActivity">
        <intent-filter>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
    </activity-alias>
</application>`}
              </pre>
            </div>

            <div className="p-4 bg-slate-800/40 rounded-xl border border-white/10 space-y-2 text-xs text-slate-300">
              <h4 className="font-semibold text-white">Why Must the APK Be Rebuilt?</h4>
              <p>
                In the Android operating system architecture, launcher icons are parsed directly from the APK's binary resources (<code className="text-sky-300">resources.arsc</code>) by the Android System Launcher daemon during APK installation.
              </p>
              <p>
                When you download the project ZIP, your uploaded icon is already injected into the <code className="text-sky-300">res/mipmap/</code> folders. Once you run <code className="text-sky-300">./gradlew assembleDebug</code>, your new icon is baked into the compiled APK!
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
