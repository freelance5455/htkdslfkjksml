import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Search,
  Brain,
  Zap,
  Code,
  Smartphone,
  RefreshCw,
  Copy,
  Check,
  ExternalLink
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  modelUsed?: string;
  searchChunks?: Array<{ web?: { title?: string; uri?: string } }>;
  isError?: boolean;
}

export const BirdAIAssistant: React.FC = () => {
  const { openApp } = useDesktop();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'assistant',
      text: 'Hello! I am Bird AI Copilot, your native Android engineer and packaging specialist for Bird PC (`com.birdbase.app`).\n\nI can help you build Android Jetpack Compose interfaces, debug Gradle build scripts, optimize launcher icons, or guide you through compiling the APK on your Android device with Termux or GitHub Actions.',
      timestamp: 'Just now',
      modelUsed: 'gemini-3.5-flash'
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState<'gemini-3.5-flash' | 'gemini-3.1-pro-preview' | 'gemini-3.1-flash-lite'>('gemini-3.5-flash');
  const [thinkingMode, setThinkingMode] = useState(false);
  const [searchGrounding, setSearchGrounding] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const presetQueries = [
    'How do I build the APK on an Android phone without a PC?',
    'Explain the dynamic component-alias launcher icon in AndroidManifest.xml',
    'How do I setup GitHub Actions to compile Bird PC for free?',
    'What is the difference between a project ZIP and a compiled APK?'
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          model: thinkingMode ? 'gemini-3.1-pro-preview' : selectedModel,
          thinking: thinkingMode,
          searchGrounding,
          systemInstruction: 'You are Bird AI Copilot, a senior Android engineer and Gradle build specialist for the native Android application "Bird PC" (com.birdbase.app). Help users with Kotlin 2.0, Jetpack Compose, Android 15 API 35, Gradle build scripts, Termux mobile builds, custom launcher icons, and GitHub Actions CI.'
        })
      });

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.text || 'No response returned.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed || (thinkingMode ? 'gemini-3.1-pro-preview' : selectedModel),
        searchChunks: data.searchChunks,
        isError: !response.ok
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          sender: 'assistant',
          text: `Error connecting to Gemini API: ${err.message}. You can continue exploring Bird PC offline modules.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isError: true
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-hidden">
      {/* Top Configuration Bar */}
      <div className="px-5 py-3 bg-slate-950 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Bot size={18} className="text-sky-400" />
          <span className="font-bold text-white">Bird AI Copilot</span>
          <span className="text-[10px] text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800">
            @google/genai
          </span>
        </div>

        {/* Model and Mode Toggles */}
        <div className="flex items-center gap-2">
          {/* Model Switcher */}
          <select
            value={selectedModel}
            onChange={e => setSelectedModel(e.target.value as any)}
            disabled={thinkingMode}
            className="bg-slate-800 border border-white/10 text-slate-200 text-xs rounded-lg px-2.5 py-1 outline-none cursor-pointer"
          >
            <option value="gemini-3.5-flash">Gemini 3.5 Flash (General)</option>
            <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Complex)</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Fast)</option>
          </select>

          {/* High Thinking Mode Toggle */}
          <button
            onClick={() => setThinkingMode(!thinkingMode)}
            className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-all ${
              thinkingMode
                ? 'bg-purple-600 text-white font-medium shadow-md shadow-purple-600/30'
                : 'bg-slate-800 text-slate-400 hover:text-white border border-white/5'
            }`}
            title="High Thinking Mode with gemini-3.1-pro-preview"
          >
            <Brain size={14} />
            <span>Thinking {thinkingMode ? 'HIGH' : 'Off'}</span>
          </button>

          {/* Search Grounding Toggle */}
          <button
            onClick={() => setSearchGrounding(!searchGrounding)}
            className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-all ${
              searchGrounding
                ? 'bg-emerald-600 text-white font-medium shadow-md shadow-emerald-600/30'
                : 'bg-slate-800 text-slate-400 hover:text-white border border-white/5'
            }`}
            title="Search Grounding with Google Search Data"
          >
            <Search size={14} />
            <span>Search {searchGrounding ? 'On' : 'Off'}</span>
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4 custom-scrollbar">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-sky-600 text-white'
                  : msg.isError
                  ? 'bg-rose-950/60 border border-rose-500/40 text-rose-200'
                  : 'bg-slate-800/90 border border-white/10 text-slate-100 select-text'
              }`}
            >
              <div className="whitespace-pre-wrap font-sans">{msg.text}</div>

              {/* Grounding metadata sources */}
              {msg.searchChunks && msg.searchChunks.length > 0 && (
                <div className="mt-3 pt-2 border-t border-white/10 space-y-1">
                  <span className="text-[10px] text-slate-400 font-semibold block">Google Search Sources:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.searchChunks.map((chunk, idx) => (
                      <a
                        key={idx}
                        href={chunk.web?.uri || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] bg-slate-900/80 px-2 py-0.5 rounded text-sky-400 hover:underline flex items-center gap-1"
                      >
                        {chunk.web?.title || 'Search source'} <ExternalLink size={10} />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Message Meta Info */}
            <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-slate-400">
              <span>{msg.timestamp}</span>
              {msg.modelUsed && <span>· {msg.modelUsed}</span>}
              <button
                onClick={() => handleCopy(msg.id, msg.text)}
                className="hover:text-white"
              >
                {copiedId === msg.id ? <Check size={11} className="text-emerald-400 inline" /> : 'Copy'}
              </button>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-slate-400 p-2">
            <RefreshCw size={14} className="animate-spin text-sky-400" />
            <span>Bird AI is thinking and formulating response...</span>
          </div>
        )}
      </div>

      {/* Preset Prompts Pill Bar */}
      <div className="px-5 py-2 border-t border-white/5 bg-slate-950/60 flex items-center gap-2 overflow-x-auto custom-scrollbar">
        {presetQueries.map((pq, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(pq)}
            className="text-[11px] whitespace-nowrap bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-1 rounded-full border border-white/5 transition-colors shrink-0"
          >
            {pq}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <div className="p-4 bg-slate-950 border-t border-white/10">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="Ask about Android architecture, Gradle builds, Termux mobile commands..."
            value={inputPrompt}
            onChange={e => setInputPrompt(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-sky-500"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white rounded-xl transition-all shadow-md shadow-sky-500/20"
          >
            <Send size={16} />
          </button>
        </form>
      </div>
    </div>
  );
};
