import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Video,
  Sparkles,
  Download,
  Check,
  RefreshCw,
  Crop,
  Layers,
  Film
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { processUploadedIconFile } from '../../services/iconGenerator';

export const ImageVideoStudio: React.FC = () => {
  const { setCustomIcon, addNotification, openApp } = useDesktop();

  const [prompt, setPrompt] = useState('Futuristic Windows 11 style penguin astronaut cyber icon with glowing neon visor, 3d render');
  const [modelChoice, setModelChoice] = useState<'gemini-3-pro-image-preview' | 'gemini-3.1-flash-image-preview'>('gemini-3-pro-image-preview');
  const [aspectRatio, setAspectRatio] = useState<string>('1:1');
  const [imageSize, setImageSize] = useState<string>('2K');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);

  // Video generation state
  const [videoMode, setVideoMode] = useState(false);
  const [videoAspectRatio, setVideoAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [videoStatus, setVideoStatus] = useState<string | null>(null);
  const [isRenderingVideo, setIsRenderingVideo] = useState(false);

  const aspectRatios = ['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'];
  const imageSizes = ['1K', '2K', '4K'];

  const handleGenerateImage = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setVideoStatus(null);

    try {
      const res = await fetch('/api/ai/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          aspectRatio,
          imageSize,
          model: modelChoice
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate image');
      }

      setGeneratedImageUrl(data.imageUrl);
      addNotification({
        title: 'Image Generated',
        message: `Generated ${aspectRatio} (${imageSize}) using ${modelChoice}.`,
        type: 'success'
      });
    } catch (err: any) {
      addNotification({
        title: 'Generation Failed',
        message: err.message || 'Error creating image with Gemini',
        type: 'error'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApplyAsAppIcon = async () => {
    if (!generatedImageUrl) return;

    try {
      // Convert base64 data url into File
      const res = await fetch(generatedImageUrl);
      const blob = await res.blob();
      const file = new File([blob], 'ai-generated-icon.png', { type: 'image/png' });

      const processed = await processUploadedIconFile(file);
      setCustomIcon(processed);

      addNotification({
        title: 'New Launcher Icon Set',
        message: 'AI generated image set as custom Android app icon for com.birdbase.app!',
        type: 'success'
      });

      openApp('app-icon-studio');
    } catch (e: any) {
      addNotification({
        title: 'Icon Conversion Error',
        message: e.message || 'Failed to set as app icon',
        type: 'error'
      });
    }
  };

  const handleGenerateVideo = async () => {
    if (!prompt.trim() || isRenderingVideo) return;
    setIsRenderingVideo(true);
    setVideoStatus('Connecting to veo-3.1-fast-generate-preview with aspect ratio ' + videoAspectRatio + '...');

    try {
      const res = await fetch('/api/ai/animate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          aspectRatio: videoAspectRatio,
          imageBase64: generatedImageUrl || undefined
        })
      });

      const data = await res.json();
      setVideoStatus(data.message || 'Veo video processing job initialized.');
      addNotification({
        title: 'Veo Video Initialized',
        message: `Veo video rendering job scheduled for aspect ratio ${videoAspectRatio}.`,
        type: 'info'
      });
    } catch (e: any) {
      setVideoStatus(`Veo request: ${e.message}`);
    } finally {
      setIsRenderingVideo(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-y-auto custom-scrollbar p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="text-amber-400" size={22} /> Creative Studio & Gemini Media
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Generate 1K-4K images with <span className="text-amber-400 font-mono">gemini-3-pro-image-preview</span> & animate with <span className="text-sky-400 font-mono">veo-3.1-fast-generate-preview</span>.
          </p>
        </div>

        {/* Media Mode Toggle (Image vs Veo Video) */}
        <div className="flex bg-slate-800 p-1 rounded-xl border border-white/10 text-xs">
          <button
            onClick={() => setVideoMode(false)}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
              !videoMode ? 'bg-amber-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ImageIcon size={14} /> Image Gen
          </button>
          <button
            onClick={() => setVideoMode(true)}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
              videoMode ? 'bg-sky-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Video size={14} /> Veo Video
          </button>
        </div>
      </div>

      {/* Main Studio Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Config Column */}
        <div className="space-y-4 md:col-span-1">
          {/* Prompt */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              Creative Text Prompt
            </label>
            <textarea
              rows={4}
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Describe the image or video motion..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-slate-500 outline-none focus:border-amber-400 custom-scrollbar resize-none"
            />
          </div>

          {!videoMode ? (
            <>
              {/* Model Choice */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  AI Model
                </label>
                <select
                  value={modelChoice}
                  onChange={e => setModelChoice(e.target.value as any)}
                  className="w-full bg-slate-800 border border-white/10 text-xs text-white rounded-xl p-2.5 outline-none cursor-pointer"
                >
                  <option value="gemini-3-pro-image-preview">gemini-3-pro-image-preview (High-Quality)</option>
                  <option value="gemini-3.1-flash-image-preview">gemini-3.1-flash-image-preview (Fast)</option>
                </select>
              </div>

              {/* Aspect Ratio Affordance */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Aspect Ratio
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {aspectRatios.map(ar => (
                    <button
                      key={ar}
                      onClick={() => setAspectRatio(ar)}
                      className={`py-1.5 text-xs rounded-lg border font-mono transition-colors ${
                        aspectRatio === ar
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 font-bold'
                          : 'bg-slate-800/60 text-slate-400 border-white/5 hover:text-white'
                      }`}
                    >
                      {ar}
                    </button>
                  ))}
                </div>
              </div>

              {/* Image Size Affordance (1K, 2K, 4K) */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Resolution / Image Size
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {imageSizes.map(sz => (
                    <button
                      key={sz}
                      onClick={() => setImageSize(sz)}
                      className={`py-1.5 text-xs rounded-lg border font-medium transition-colors ${
                        imageSize === sz
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 font-bold'
                          : 'bg-slate-800/60 text-slate-400 border-white/5 hover:text-white'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate Image Button */}
              <button
                onClick={handleGenerateImage}
                disabled={isGenerating || !prompt.trim()}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all active:scale-95"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw size={15} className="animate-spin" /> Rendering Image...
                  </>
                ) : (
                  <>
                    <Sparkles size={15} /> Generate Image
                  </>
                )}
              </button>
            </>
          ) : (
            /* Veo Video Options */
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Veo Video Aspect Ratio (16:9 Landscape or 9:16 Portrait)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['16:9', '9:16'] as const).map(ar => (
                    <button
                      key={ar}
                      onClick={() => setVideoAspectRatio(ar)}
                      className={`py-2 text-xs rounded-xl border font-bold font-mono transition-colors ${
                        videoAspectRatio === ar
                          ? 'bg-sky-500/20 text-sky-400 border-sky-500/50'
                          : 'bg-slate-800/60 text-slate-400 border-white/5 hover:text-white'
                      }`}
                    >
                      {ar} {ar === '16:9' ? '(Landscape)' : '(Portrait)'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-white/5 text-[11px] text-slate-300 space-y-1">
                <span className="font-semibold text-sky-400 block">Model: veo-3.1-fast-generate-preview</span>
                <span>Animates photo or prompt into video motion at specified aspect ratio.</span>
              </div>

              <button
                onClick={handleGenerateVideo}
                disabled={isRenderingVideo || !prompt.trim()}
                className="w-full py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 transition-all active:scale-95"
              >
                {isRenderingVideo ? (
                  <>
                    <RefreshCw size={15} className="animate-spin" /> Animating Video...
                  </>
                ) : (
                  <>
                    <Film size={15} /> Animate with Veo
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Right Preview Column */}
        <div className="md:col-span-2 bg-slate-800/40 rounded-2xl border border-white/10 p-5 flex flex-col items-center justify-center min-h-[380px]">
          {isGenerating ? (
            <div className="text-center space-y-3">
              <RefreshCw size={32} className="animate-spin text-amber-400 mx-auto" />
              <div className="text-sm font-semibold text-white">Gemini is synthesizing image...</div>
              <div className="text-xs text-slate-400">Model: {modelChoice} · Ratio: {aspectRatio} · Size: {imageSize}</div>
            </div>
          ) : generatedImageUrl ? (
            <div className="w-full flex flex-col items-center gap-4">
              <div className="max-h-[340px] max-w-full rounded-xl overflow-hidden shadow-2xl border border-white/10 bg-slate-950">
                <img
                  src={generatedImageUrl}
                  alt="Generated"
                  className="max-h-[340px] w-auto object-contain"
                />
              </div>

              {/* Action Buttons for generated image */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={handleApplyAsAppIcon}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-600/30 transition-all"
                >
                  <Crop size={15} /> Set as Bird PC App Icon
                </button>

                <a
                  href={generatedImageUrl}
                  download="bird-pc-generated.png"
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl flex items-center gap-1.5 border border-white/10 transition-colors"
                >
                  <Download size={15} /> Download PNG
                </a>
              </div>
            </div>
          ) : (
            <div className="text-center p-8 space-y-2 text-slate-400">
              <ImageIcon size={48} className="mx-auto text-slate-600" />
              <div className="text-sm font-medium text-slate-300">Ready to Generate</div>
              <div className="text-xs max-w-sm mx-auto">
                Enter a text prompt, select aspect ratio (1:1 to 21:9) and resolution (1K-4K), and click Generate Image.
              </div>
            </div>
          )}

          {videoStatus && (
            <div className="mt-4 w-full p-3 bg-sky-950/40 rounded-xl border border-sky-500/20 text-xs text-sky-200">
              {videoStatus}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
