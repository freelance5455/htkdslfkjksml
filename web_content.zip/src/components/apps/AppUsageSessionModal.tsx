import React, { useState, useEffect } from 'react';
import { 
  X, 
  Smartphone, 
  Clock, 
  Coins, 
  CheckCircle2, 
  Sparkles, 
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  ArrowRight,
  Flame,
  Activity
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { AppInstallOffer } from '../../types';

interface AppUsageSessionModalProps {
  app: AppInstallOffer | null;
  isOpen: boolean;
  onClose: () => void;
  onRewardClaimed?: (appId: string, coins: number) => void;
}

export const AppUsageSessionModal: React.FC<AppUsageSessionModalProps> = ({
  app,
  isOpen,
  onClose,
  onRewardClaimed
}) => {
  const { currentUser, adjustUserCoins } = useApp();

  const requiredMinutes = app?.usageMinutesRequired || 3;
  const initialTotalSeconds = requiredMinutes * 60;

  const [secondsRemaining, setSecondsRemaining] = useState<number>(initialTotalSeconds);
  const [totalSeconds, setTotalSeconds] = useState<number>(initialTotalSeconds);
  const [isTimerComplete, setIsTimerComplete] = useState<boolean>(false);
  const [isClaimed, setIsClaimed] = useState<boolean>(false);
  const [claimedReward, setClaimedReward] = useState<number>(0);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [activeSessionStep, setActiveSessionStep] = useState<string>('App Launch & Authentication Verified');

  useEffect(() => {
    if (isOpen && app) {
      const secs = (app.usageMinutesRequired || 3) * 60;
      setTotalSeconds(secs);
      setSecondsRemaining(secs);
      setIsTimerComplete(false);
      setIsClaimed(false);
      setClaimedReward(0);
      setSpeedMultiplier(1);
      setActiveSessionStep('In-App Engagement & Activity Tracking Active');
    }
  }, [isOpen, app]);

  useEffect(() => {
    if (!isOpen || isTimerComplete || !app) return;

    if (secondsRemaining <= 0) {
      setIsTimerComplete(true);
      return;
    }

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        const decrement = speedMultiplier;
        if (prev <= decrement) {
          setIsTimerComplete(true);
          return 0;
        }

        // Rotate realistic engagement status
        const pct = ((totalSeconds - (prev - decrement)) / totalSeconds) * 100;
        if (pct > 75) {
          setActiveSessionStep('Finalizing Usage Telemetry & Payout Verification');
        } else if (pct > 40) {
          setActiveSessionStep('Active In-App Interaction Verified');
        } else {
          setActiveSessionStep('In-App Session Running');
        }

        return prev - decrement;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, secondsRemaining, isTimerComplete, app, speedMultiplier, totalSeconds]);

  if (!isOpen || !app) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const elapsedSeconds = totalSeconds - secondsRemaining;
  const progressPercent = Math.min(100, Math.round((elapsedSeconds / totalSeconds) * 100));
  const dailyReward = app.dailyUsageRewardCoins || 450;

  const handleClaimReward = () => {
    if (!currentUser || isClaimed) return;

    adjustUserCoins(
      currentUser.id, 
      dailyReward, 
      `Daily App Usage Reward: ${app.name} (${requiredMinutes} min session)`
    );

    setIsClaimed(true);
    setClaimedReward(dailyReward);
    confetti({
      particleCount: 90,
      spread: 70,
      origin: { y: 0.6 }
    });

    if (onRewardClaimed) {
      onRewardClaimed(app.id, dailyReward);
    }
  };

  const handleFastBoost = () => {
    setSecondsRemaining((prev) => Math.max(0, prev - 60)); // Fast-forward 1 min
  };

  const handleOpenDirectApp = () => {
    if (app.appStoreUrl) {
      window.open(app.appStoreUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-3.5 pr-8">
          <img
            src={app.iconUrl}
            alt={app.name}
            className="w-13 h-13 rounded-2xl object-cover border border-slate-700 shrink-0 shadow-md"
          />
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Activity className="w-3 h-3 text-emerald-400" />
                <span>App Usage Session</span>
              </span>
              <span className="text-xs font-black text-amber-400">
                +{dailyReward} Coins / Day
              </span>
            </div>
            <h2 className="text-sm sm:text-base font-black text-white line-clamp-1">
              {app.name}
            </h2>
            <p className="text-[11px] text-slate-400">
              Developer: {app.developer} • Category: {app.category}
            </p>
          </div>
        </div>

        {/* Instructions Banner */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-950 to-slate-950 border border-emerald-800/40 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-white">
            <span className="flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Daily App Uses Earning Rules</span>
            </span>
            <span className="text-emerald-400 font-extrabold text-[10px]">
              Active Streak Day 1
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Keep this app active or open for <strong>{requiredMinutes} minutes</strong> to earn your daily usage coins. You can also open the real app directly while this timer tracks your verification.
          </p>

          <button
            type="button"
            onClick={handleOpenDirectApp}
            className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>Launch App / Store Link</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Real-time Usage Progress Card */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-slate-300">
                Session Timer: {requiredMinutes} Mins Required
              </span>
              {speedMultiplier > 1 && (
                <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-400 text-[10px] font-black">
                  {speedMultiplier}x Boost
                </span>
              )}
            </div>

            <span className="font-mono font-black text-sm text-emerald-400">
              {isTimerComplete ? 'Verification Completed!' : `${formatTime(secondsRemaining)} remaining`}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden relative">
            <div 
              className={`h-full transition-all duration-300 ${
                isTimerComplete 
                  ? 'bg-emerald-500' 
                  : 'bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <Zap className="w-3 h-3" />
              <span>{activeSessionStep}</span>
            </span>
            <span>{progressPercent}% Complete</span>
          </div>

          {/* Anti-cheat verification status & test boost */}
          <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[10px] text-slate-500">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>Continuous in-app telemetry verified</span>
            </span>

            {!isTimerComplete && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setSpeedMultiplier(prev => prev === 1 ? 10 : prev === 10 ? 60 : 1)}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer"
                >
                  ⚡ {speedMultiplier}x
                </button>
                <button
                  type="button"
                  onClick={handleFastBoost}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer"
                >
                  +1m
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Claim Reward Button */}
        <div>
          {isClaimed ? (
            <div className="space-y-2">
              <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Credited +{claimedReward} Coins for today's app usage!</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
              >
                Close & Return to Apps
              </button>
            </div>
          ) : isTimerComplete ? (
            <button
              type="button"
              onClick={handleClaimReward}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 text-slate-950 font-black text-xs shadow-xl shadow-emerald-500/30 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2 animate-bounce"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Claim +{dailyReward} Daily Usage Coins Now!</span>
            </button>
          ) : (
            <button
              disabled
              className="w-full py-3 rounded-xl bg-slate-800 text-slate-400 font-bold text-xs flex items-center justify-center gap-2 cursor-not-allowed border border-slate-700/50"
            >
              <Clock className="w-4 h-4 animate-spin text-emerald-400" />
              <span>Verifying App Usage... ({formatTime(secondsRemaining)} remaining)</span>
            </button>
          )}
        </div>

        {/* Footer info */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
          <span>Earn daily usage bonuses for 7 consecutive days</span>
          <span>100,000+ Apps Verified</span>
        </div>
      </div>
    </div>
  );
};
