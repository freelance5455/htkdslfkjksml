import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, Play, RefreshCw } from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { ANDROID_PACKAGE_NAME } from '../../data/androidProjectFiles';

interface TerminalLine {
  id: string;
  type: 'cmd' | 'output' | 'error' | 'success';
  text: string;
}

export const Terminal: React.FC = () => {
  const { openApp } = useDesktop();
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const [lines, setLines] = useState<TerminalLine[]>([
    { id: '1', type: 'output', text: 'Bird PC Terminal [Version 1.0.0.35]' },
    { id: '2', type: 'output', text: '(c) 2026 Bird Base Corporation. All rights reserved.\n' },
    { id: '3', type: 'output', text: 'Target Application ID: ' + ANDROID_PACKAGE_NAME },
    { id: '4', type: 'output', text: 'Type "help" or "gradle assembleDebug" to begin.\n' }
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const handleCommand = (rawCmd: string) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;

    setHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);

    const newLines: TerminalLine[] = [
      ...lines,
      { id: `cmd-${Date.now()}`, type: 'cmd', text: `user@bird-pc:~$ ${cmd}` }
    ];

    const parts = cmd.split(' ');
    const root = parts[0].toLowerCase();

    if (root === 'clear' || root === 'cls') {
      setLines([]);
      setCurrentInput('');
      return;
    }

    if (root === 'help') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: `Available Commands:
  help                    - Show this command reference
  gradle assembleDebug    - Run Android Gradle compilation simulation
  neofetch                - Show system specs and Bird PC ASCII logo
  deviceinfo              - Display Android hardware & API 35 specs
  apkinfo                 - Inspect com.birdbase.app package details
  ls                      - List files in virtual root directory
  cat <filename>          - Display contents of a file
  export                  - Open APK Builder & Project Exporter
  clear                   - Clear the terminal screen`
      });
    } else if (cmd === 'gradle assembleDebug' || cmd === './gradlew assembleDebug') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'success',
        text: `> Task :app:preBuild UP-TO-DATE
> Task :app:compileDebugKotlin
  Compiling 14 Kotlin source files to classes.dex...
> Task :app:processDebugResources
  Packing AndroidManifest.xml and res/mipmap drawables for com.birdbase.app...
> Task :app:dexBuilderDebug
  Generating Dalvik Executable (classes.dex, classes2.dex)...
> Task :app:packageDebug
  Creating debug APK artifact...
> Task :app:assembleDebug

BUILD SUCCESSFUL in 3.42s
Output: app/build/outputs/apk/debug/app-debug.apk

Tip: To build on your real Android phone, extract the ZIP and run "bash build-apk-termux.sh" in Termux!`
      });
    } else if (root === 'neofetch') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: `   ___ _         _    ___   ___     OS: Bird PC Android 15 (API 35)
  / __|_)_ _ __| |  | _ \\ / __|    Host: Mobile / ARM64 Virtual Machine
 | (_ | | '_/ _\` |  |  _/| (__     Kernel: Linux 6.6.0-birdbase-arm64
  \\___|_|_| \\__,_|  |_|   \\___|    Uptime: 2 hours, 45 mins
                                   Packages: 32 (desktop apps)
                                   Shell: birdsh 2.1
                                   CPU: Octa-core ARMv8/v9 (Snapdragon 8 Gen 3)
                                   Memory: 3.4 GB / 8.0 GB
                                   App ID: ${ANDROID_PACKAGE_NAME}`
      });
    } else if (root === 'apkinfo') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: `Package: ${ANDROID_PACKAGE_NAME}
App Name: Bird PC
Version Code: 1
Version Name: 1.0.0
Min SDK: 26 (Android 8.0 Oreo)
Target SDK: 35 (Android 15 Vanilla Ice Cream)
Compile SDK: 35
Launcher: com.birdbase.app.MainActivity
Launcher Alias: com.birdbase.app.MainActivityCustomIcon`
      });
    } else if (root === 'deviceinfo') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: `Hardware: Snapdragon 8 Gen 3 Mobile Platform
Architecture: aarch64 (ARM64)
Display: 2400 x 1080 AMOLED 120Hz
RAM: 8GB LPDDR5X
Storage: 128GB UFS 4.0
Battery: 5000 mAh (Li-Po)
Security Patch: October 2026`
      });
    } else if (root === 'ls') {
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: `app/   gradle/   build.gradle.kts   settings.gradle.kts   gradlew   gradlew.bat   README.md`
      });
    } else if (root === 'export') {
      openApp('project-exporter');
      newLines.push({
        id: `out-${Date.now()}`,
        type: 'output',
        text: 'Launching APK Builder & Project Exporter...'
      });
    } else {
      newLines.push({
        id: `err-${Date.now()}`,
        type: 'error',
        text: `command not found: ${root}. Type "help" for a list of commands.`
      });
    }

    setLines(newLines);
    setCurrentInput('');
  };

  return (
    <div
      className="h-full bg-slate-950 text-emerald-400 p-4 font-mono text-xs flex flex-col overflow-hidden select-text"
      onClick={() => inputRef.current?.focus()}
    >
      <div className="flex-1 overflow-y-auto space-y-1 custom-scrollbar">
        {lines.map(line => (
          <div
            key={line.id}
            className={`whitespace-pre-wrap leading-relaxed ${
              line.type === 'cmd'
                ? 'text-sky-300 font-bold'
                : line.type === 'error'
                ? 'text-rose-400'
                : line.type === 'success'
                ? 'text-emerald-300 font-medium'
                : 'text-slate-300'
            }`}
          >
            {line.text}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
        <span className="text-sky-400 font-bold">user@bird-pc:~$</span>
        <input
          ref={inputRef}
          type="text"
          value={currentInput}
          onChange={e => setCurrentInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') handleCommand(currentInput);
          }}
          className="flex-1 bg-transparent border-none outline-none text-white font-mono text-xs"
          autoFocus
        />
      </div>
    </div>
  );
};
