import React, { useState, useEffect } from 'react';
import { 
  X, 
  Star, 
  Download, 
  Smartphone, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  MessageSquareText, 
  ExternalLink,
  Layers,
  ThumbsUp,
  Clock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { AppTaskItem } from '../../types';

interface AppSurveyFeedbackModalProps {
  app: AppTaskItem | null;
  isOpen: boolean;
  onClose: () => void;
  onSurveyCompleted?: (appId: string, coins: number) => void;
  onNextApp?: () => void;
}

export const AppSurveyFeedbackModal: React.FC<AppSurveyFeedbackModalProps> = ({
  app,
  isOpen,
  onClose,
  onSurveyCompleted,
  onNextApp
}) => {
  const { currentUser, adjustUserCoins } = useApp();

  const [step, setStep] = useState<'install' | 'survey' | 'success'>('install');
  const [installProgress, setInstallProgress] = useState(0);
  const [isInstalling, setIsInstalling] = useState(false);
  const [rating, setRating] = useState<number>(5);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [feedbackText, setFeedbackText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && app) {
      setStep('install');
      setInstallProgress(0);
      setIsInstalling(false);
      setRating(5);
      setAnswers({});
      setFeedbackText('');
      setIsSubmitting(false);
    }
  }, [isOpen, app]);

  if (!isOpen || !app) return null;

  const handleStartSimulatedInstall = () => {
    setIsInstalling(true);
    setInstallProgress(10);

    const interval = setInterval(() => {
      setInstallProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsInstalling(false);
          setStep('survey');
          return 100;
        }
        return prev + 25;
      });
    }, 400);
  };

  const handleSelectOption = (questionIndex: number, option: string) => {
    setAnswers((prev) => ({ ...prev, [questionIndex]: option }));
  };

  const handleSubmitSurvey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setIsSubmitting(true);
    const reward = app.rewardCoins;

    adjustUserCoins(
      currentUser.id,
      reward,
      `App Feedback & Survey: ${app.name}`
    );

    confetti({
      particleCount: 85,
      spread: 60,
      origin: { y: 0.65 }
    });

    if (onSurveyCompleted) {
      onSurveyCompleted(app.id, reward);
    }

    setStep('success');
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* App Header Card */}
        <div className="flex items-center gap-3 pr-6">
          <img
            src={app.iconUrl}
            alt={app.name}
            className="w-14 h-14 rounded-2xl object-cover border border-slate-700 shadow-md shrink-0"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {app.category}
              </span>
              <span className="text-[10px] text-amber-400 font-bold flex items-center gap-0.5">
                <Star className="w-3 h-3 fill-current" />
                {app.rating}
              </span>
            </div>
            <h2 className="text-sm font-black text-white truncate mt-0.5">
              {app.name}
            </h2>
            <p className="text-[11px] text-slate-400 truncate">
              {app.developer} • {app.sizeMb} MB
            </p>
          </div>

          <div className="text-right shrink-0">
            <span className="text-xs font-black text-amber-400 block">
              +{app.rewardCoins} Coins
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold block">
              ₹{(app.rewardCoins / 100).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Step Indicator */}
        <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold pt-1">
          <div className={`p-2 rounded-xl border transition-all ${
            step === 'install' 
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' 
              : 'bg-slate-950 text-slate-400 border-slate-800'
          }`}>
            <span>1. Test & Launch App</span>
          </div>
          <div className={`p-2 rounded-xl border transition-all ${
            step === 'survey' || step === 'success'
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' 
              : 'bg-slate-950 text-slate-400 border-slate-800'
          }`}>
            <span>2. Feature Survey & Rating</span>
          </div>
        </div>

        {/* STEP 1: Launch / Install */}
        {step === 'install' && (
          <div className="space-y-4 pt-1">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-200 block">App Overview:</span>
              <p className="text-xs text-slate-400 leading-relaxed">
                {app.description}
              </p>
              <div className="flex items-center gap-4 text-[11px] text-slate-500 pt-1">
                <span>Downloads: <strong>{app.downloadsCount}</strong></span>
                <span>Version: <strong>Latest 2026</strong></span>
                <span>Security: <strong>Verified</strong></span>
              </div>
            </div>

            {isInstalling ? (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs text-slate-300 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
                    <span>Launching & Verifying App Environment...</span>
                  </span>
                  <span>{installProgress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                    style={{ width: `${installProgress}%` }}
                  />
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleStartSimulatedInstall}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Launch & Test App (+{app.rewardCoins} Coins)</span>
              </button>
            )}

            <p className="text-[10px] text-slate-500 text-center">
              Testing takes ~10 seconds. You will answer 2 quick feedback questions to claim your coins.
            </p>
          </div>
        )}

        {/* STEP 2: Interactive Feature Survey */}
        {step === 'survey' && (
          <form onSubmit={handleSubmitSurvey} className="space-y-4 pt-1">
            {/* Star Rating */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-center">
              <span className="text-xs font-bold text-slate-300 block">
                How would you rate your overall experience with {app.name}?
              </span>
              <div className="flex items-center justify-center gap-2 py-1">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setRating(s)}
                    className="p-1 cursor-pointer transition-transform hover:scale-110"
                  >
                    <Star 
                      className={`w-6 h-6 ${s <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'}`} 
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Questions */}
            {app.surveyQuestions.map((sq, qIdx) => (
              <div key={qIdx} className="space-y-2 p-3 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-xs font-bold text-slate-200 block">
                  {qIdx + 1}. {sq.question}
                </span>
                <div className="space-y-1.5">
                  {sq.options.map((opt, oIdx) => (
                    <button
                      key={oIdx}
                      type="button"
                      onClick={() => handleSelectOption(qIdx, opt)}
                      className={`w-full p-2 rounded-xl text-left text-xs font-medium transition-all cursor-pointer flex items-center justify-between ${
                        answers[qIdx] === opt
                          ? 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-300'
                          : 'bg-slate-900 border border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span>{opt}</span>
                      {answers[qIdx] === opt && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            {/* Feedback input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 block">
                Feature Suggestions & Bug Feedback (Optional)
              </label>
              <textarea
                rows={2}
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
                placeholder="Suggest new features, improvements or UI thoughts..."
                className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Submit Survey & Claim +{app.rewardCoins} Coins</span>
            </button>
          </form>
        )}

        {/* STEP 3: Success */}
        {step === 'success' && (
          <div className="text-center space-y-3 py-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Verified & Credited
              </span>
              <h3 className="text-base font-black text-white pt-1">
                Survey Submitted!
              </h3>
              <p className="text-xs text-slate-400">
                Your feedback for <strong>{app.name}</strong> was submitted and <strong>+{app.rewardCoins} Coins (₹{(app.rewardCoins / 100).toFixed(2)})</strong> have been added to your balance.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              {onNextApp && (
                <button
                  type="button"
                  onClick={onNextApp}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs hover:opacity-90 cursor-pointer shadow-md flex items-center justify-center gap-1.5"
                >
                  <span>Test Next App</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl border border-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
