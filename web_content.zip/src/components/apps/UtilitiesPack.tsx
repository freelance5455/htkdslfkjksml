import React, { useState, useEffect, useRef } from 'react';
import {
  Calculator as CalcIcon,
  Calendar as CalIcon,
  ShoppingBag,
  Download,
  Eye,
  Music,
  Palette,
  CloudSun,
  Archive,
  Cpu,
  Crop,
  Clipboard,
  Smartphone,
  Battery,
  Wifi,
  Gamepad2,
  StickyNote,
  ShieldCheck,
  Mic,
  GitBranch,
  Play,
  Pause,
  RotateCw,
  Plus,
  Trash2,
  Check,
  Copy,
  ExternalLink,
  Volume2
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { processUploadedIconFile } from '../../services/iconGenerator';

// ==========================================
// 1. Bird App Store
// ==========================================
export const BirdAppStore: React.FC = () => {
  const { openApp, addNotification } = useDesktop();
  const [installingId, setInstallingId] = useState<string | null>(null);

  const storeApps = [
    { id: 'app-icon-studio', name: 'App Icon Studio', cat: 'Developer Tools', rating: '5.0', desc: 'Custom launcher icon studio & mipmap generator' },
    { id: 'project-exporter', name: 'APK Exporter', cat: 'Developer Tools', rating: '4.9', desc: 'Complete Android Gradle packaging suite' },
    { id: 'bird-ai', name: 'Bird AI Copilot', cat: 'AI & Intelligence', rating: '4.9', desc: 'Gemini reasoning assistant with thinking mode' },
    { id: 'image-studio', name: 'Creative Studio', cat: 'Media & Design', rating: '4.8', desc: 'Gemini 3 Pro text-to-image & Veo animation' },
    { id: 'game-center', name: 'Retro Game Center', cat: 'Entertainment', rating: '4.7', desc: 'Playable Minesweeper and arcade Snake' },
    { id: 'paint-canvas', name: 'Paint & Drawing', cat: 'Creativity', rating: '4.8', desc: 'Freehand canvas with instant app icon set' },
    { id: 'terminal', name: 'Terminal CLI', cat: 'Developer Tools', rating: '4.9', desc: 'Gradle assemble simulation & diagnostics' },
    { id: 'task-manager', name: 'Task Manager', cat: 'System', rating: '4.8', desc: 'Process monitor and animated CPU/RAM charts' }
  ];

  const handleInstall = (app: typeof storeApps[0]) => {
    setInstallingId(app.id);
    setTimeout(() => {
      setInstallingId(null);
      addNotification({
        title: 'App Ready',
        message: `${app.name} is installed and ready to launch.`,
        type: 'success'
      });
      openApp(app.id);
    }, 1200);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-y-auto custom-scrollbar p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShoppingBag className="text-sky-400" size={22} /> Bird App Store
          </h2>
          <p className="text-xs text-slate-400 mt-1">Curated applications for Android desktop environment</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {storeApps.map(app => (
          <div key={app.id} className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 flex flex-col justify-between gap-3 hover:bg-slate-800/70 transition-colors">
            <div>
              <span className="text-[10px] text-sky-400 font-semibold uppercase">{app.cat}</span>
              <h3 className="text-sm font-bold text-white mt-0.5">{app.name}</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{app.desc}</p>
              <div className="text-[11px] text-amber-400 mt-2">★ {app.rating}</div>
            </div>
            <button
              onClick={() => handleInstall(app)}
              disabled={installingId === app.id}
              className="w-full py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              {installingId === app.id ? (
                <>
                  <RotateCw size={13} className="animate-spin" /> Installing...
                </>
              ) : (
                'Open / Install'
              )}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// ==========================================
// 2. Calculator (Standard & Scientific)
// ==========================================
export const Calculator: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [scientific, setScientific] = useState(false);

  const handleNum = (n: string) => {
    setDisplay(prev => prev === '0' ? n : prev + n);
  };

  const handleOp = (op: string) => {
    setEquation(display + ' ' + op + ' ');
    setDisplay('0');
  };

  const handleEqual = () => {
    try {
      // Safe arithmetic evaluation
      const full = equation + display;
      const sanitized = full.replace(/×/g, '*').replace(/÷/g, '/');
      // eslint-disable-next-line no-eval
      const result = Function(`'use strict'; return (${sanitized})`)();
      setDisplay(String(result));
      setEquation('');
    } catch {
      setDisplay('Error');
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const handleSci = (fn: string) => {
    const val = parseFloat(display);
    if (fn === 'sqrt') setDisplay(String(Math.sqrt(val)));
    if (fn === 'sin') setDisplay(String(Math.sin(val).toFixed(4)));
    if (fn === 'cos') setDisplay(String(Math.cos(val).toFixed(4)));
    if (fn === 'sq') setDisplay(String(val * val));
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-white select-none p-4 justify-between font-mono">
      <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
        <span className="font-bold flex items-center gap-1">
          <CalcIcon size={14} /> {scientific ? 'Scientific' : 'Standard'}
        </span>
        <button
          onClick={() => setScientific(!scientific)}
          className="text-sky-400 hover:underline"
        >
          {scientific ? 'Standard' : 'Scientific'}
        </button>
      </div>

      <div className="p-3 bg-slate-900 rounded-xl text-right mb-3 border border-white/5">
        <div className="text-xs text-slate-400 h-4">{equation}</div>
        <div className="text-3xl font-bold text-white truncate">{display}</div>
      </div>

      {scientific && (
        <div className="grid grid-cols-4 gap-1.5 mb-2">
          {['sin', 'cos', 'sqrt', 'sq'].map(fn => (
            <button
              key={fn}
              onClick={() => handleSci(fn)}
              className="py-1.5 bg-slate-800 text-sky-400 rounded-lg text-xs font-semibold hover:bg-slate-700"
            >
              {fn}
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-4 gap-2 text-sm font-semibold">
        <button onClick={handleClear} className="p-3 bg-slate-800 text-rose-400 rounded-xl hover:bg-slate-700">C</button>
        <button onClick={() => setDisplay(prev => prev.slice(0, -1) || '0')} className="p-3 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700">⌫</button>
        <button onClick={() => handleOp('%')} className="p-3 bg-slate-800 text-sky-400 rounded-xl hover:bg-slate-700">%</button>
        <button onClick={() => handleOp('÷')} className="p-3 bg-sky-600 text-white rounded-xl hover:bg-sky-500">÷</button>

        {['7', '8', '9'].map(n => <button key={n} onClick={() => handleNum(n)} className="p-3 bg-slate-900 rounded-xl hover:bg-slate-800">{n}</button>)}
        <button onClick={() => handleOp('×')} className="p-3 bg-sky-600 text-white rounded-xl hover:bg-sky-500">×</button>

        {['4', '5', '6'].map(n => <button key={n} onClick={() => handleNum(n)} className="p-3 bg-slate-900 rounded-xl hover:bg-slate-800">{n}</button>)}
        <button onClick={() => handleOp('-')} className="p-3 bg-sky-600 text-white rounded-xl hover:bg-sky-500">-</button>

        {['1', '2', '3'].map(n => <button key={n} onClick={() => handleNum(n)} className="p-3 bg-slate-900 rounded-xl hover:bg-slate-800">{n}</button>)}
        <button onClick={() => handleOp('+')} className="p-3 bg-sky-600 text-white rounded-xl hover:bg-sky-500">+</button>

        <button onClick={() => handleNum('0')} className="p-3 bg-slate-900 rounded-xl hover:bg-slate-800 col-span-2">0</button>
        <button onClick={() => handleNum('.')} className="p-3 bg-slate-900 rounded-xl hover:bg-slate-800">.</button>
        <button onClick={handleEqual} className="p-3 bg-emerald-500 text-slate-950 font-bold rounded-xl hover:bg-emerald-400">=</button>
      </div>
    </div>
  );
};

// ==========================================
// 3. Calendar & Clock
// ==========================================
export const CalendarClock: React.FC = () => {
  const [date] = useState(new Date());

  const daysInMonth = 31;
  const currentDay = date.getDate();

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none p-5 space-y-4 overflow-y-auto custom-scrollbar">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <CalIcon className="text-sky-400" size={18} /> October 2026
        </h2>
        <span className="text-xs text-slate-400 font-mono">{date.toLocaleTimeString()}</span>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center text-xs">
        {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => (
          <span key={d} className="font-bold text-slate-500 py-1">{d}</span>
        ))}
        {Array.from({ length: 3 }).map((_, i) => <div key={`empty-${i}`} />)}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          const isToday = day === currentDay;
          return (
            <div
              key={day}
              className={`py-2 rounded-lg font-medium transition-colors ${
                isToday ? 'bg-sky-500 text-white font-bold shadow-md shadow-sky-500/30' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              {day}
            </div>
          );
        })}
      </div>

      <div className="pt-3 border-t border-white/10 space-y-2">
        <span className="text-xs font-semibold text-slate-300">Upcoming Schedule</span>
        <div className="p-2.5 bg-slate-800/40 rounded-xl border border-white/5 text-xs flex justify-between items-center">
          <div>
            <div className="font-semibold text-white">Compile com.birdbase.app Release APK</div>
            <div className="text-[11px] text-slate-400">Target Android 15 (API 35)</div>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Today</span>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 4. Paint & Canvas Drawing
// ==========================================
export const PaintApp: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { setCustomIcon, addNotification, openApp } = useDesktop();
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#38BDF8');
  const [brushSize, setBrushSize] = useState(6);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDraw = () => setIsDrawing(false);

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.strokeStyle = color;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const handleApplyAsAppIcon = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.toBlob(async blob => {
      if (!blob) return;
      const file = new File([blob], 'paint-custom-icon.png', { type: 'image/png' });
      const processed = await processUploadedIconFile(file);
      setCustomIcon(processed);
      addNotification({
        title: 'Canvas Icon Set',
        message: 'Your painting was set as the custom launcher icon for com.birdbase.app!',
        type: 'success'
      });
      openApp('app-icon-studio');
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-hidden p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-950 p-2.5 rounded-xl border border-white/10">
        <div className="flex items-center gap-3">
          <input
            type="color"
            value={color}
            onChange={e => setColor(e.target.value)}
            className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-none"
          />
          <div className="flex items-center gap-1">
            <span className="text-slate-400">Size:</span>
            <input
              type="range"
              min={2}
              max={24}
              value={brushSize}
              onChange={e => setBrushSize(Number(e.target.value))}
              className="w-20 accent-sky-400"
            />
          </div>
          <button onClick={handleClear} className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg">
            Clear
          </button>
        </div>

        <button
          onClick={handleApplyAsAppIcon}
          className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg flex items-center gap-1.5 transition-colors"
        >
          <Crop size={14} /> Set as App Icon
        </button>
      </div>

      <div className="flex-1 bg-slate-950 rounded-2xl border border-white/10 flex items-center justify-center p-2 overflow-hidden">
        <canvas
          ref={canvasRef}
          width={500}
          height={380}
          onMouseDown={startDraw}
          onMouseUp={stopDraw}
          onMouseMove={draw}
          className="cursor-crosshair rounded-xl shadow-lg border border-white/5"
        />
      </div>
    </div>
  );
};

// ==========================================
// 5. Game Center (Minesweeper & Snake)
// ==========================================
export const GameCenter: React.FC = () => {
  const [game, setGame] = useState<'minesweeper' | 'snake'>('minesweeper');
  const [board, setBoard] = useState<{ isMine: boolean; revealed: boolean; count: number }[][]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);

  // Initialize Minesweeper (8x8)
  const initMinesweeper = () => {
    const size = 8;
    const numMines = 8;
    const newBoard = Array.from({ length: size }, () =>
      Array.from({ length: size }, () => ({ isMine: false, revealed: false, count: 0 }))
    );

    // Place mines
    let placed = 0;
    while (placed < numMines) {
      const r = Math.floor(Math.random() * size);
      const c = Math.floor(Math.random() * size);
      if (!newBoard[r][c].isMine) {
        newBoard[r][c].isMine = true;
        placed++;
      }
    }

    // Calculate neighbor counts
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (!newBoard[r][c].isMine) {
          let cnt = 0;
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              if (r + dr >= 0 && r + dr < size && c + dc >= 0 && c + dc < size) {
                if (newBoard[r + dr][c + dc].isMine) cnt++;
              }
            }
          }
          newBoard[r][c].count = cnt;
        }
      }
    }

    setBoard(newBoard);
    setGameOver(false);
    setWon(false);
  };

  useEffect(() => {
    initMinesweeper();
  }, []);

  const revealCell = (r: number, c: number) => {
    if (gameOver || board[r][c].revealed) return;

    if (board[r][c].isMine) {
      setGameOver(true);
      // Reveal all mines
      setBoard(prev => prev.map(row => row.map(cell => cell.isMine ? { ...cell, revealed: true } : cell)));
      return;
    }

    const next = board.map(row => row.map(cell => ({ ...cell })));
    next[r][c].revealed = true;
    setBoard(next);

    // Check win
    const unrevealedSafe = next.flat().filter(cell => !cell.isMine && !cell.revealed).length;
    if (unrevealedSafe === 0) {
      setWon(true);
      setGameOver(true);
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none p-5 space-y-4 overflow-y-auto custom-scrollbar">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Gamepad2 className="text-sky-400" size={18} /> Classic Minesweeper
        </h2>
        <button
          onClick={initMinesweeper}
          className="px-3 py-1 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-lg text-xs"
        >
          New Game
        </button>
      </div>

      <div className="flex flex-col items-center justify-center p-4">
        {gameOver && (
          <div className={`mb-3 text-sm font-bold ${won ? 'text-emerald-400' : 'text-rose-400'}`}>
            {won ? '🎉 You Won! Field cleared!' : '💥 BOOM! Hit a mine.'}
          </div>
        )}

        <div className="grid grid-cols-8 gap-1.5 p-3 bg-slate-950 rounded-2xl border border-white/10">
          {board.map((row, r) =>
            row.map((cell, c) => (
              <button
                key={`${r}-${c}`}
                onClick={() => revealCell(r, c)}
                className={`w-9 h-9 rounded-lg font-bold text-xs flex items-center justify-center transition-all ${
                  cell.revealed
                    ? cell.isMine
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-800 text-sky-300'
                    : 'bg-slate-700 hover:bg-slate-600 active:scale-95 text-transparent'
                }`}
              >
                {cell.revealed ? (cell.isMine ? '💣' : cell.count || '') : ''}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 6. Device Hardware & Specs
// ==========================================
export const DeviceInformation: React.FC = () => {
  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none p-6 space-y-4 overflow-y-auto custom-scrollbar text-xs">
      <h2 className="text-base font-bold text-white flex items-center gap-2">
        <Smartphone className="text-sky-400" size={18} /> Device & Hardware Information
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-4 bg-slate-800/40 rounded-xl border border-white/5 space-y-2">
          <span className="font-semibold text-sky-400 block">System Architecture</span>
          <div className="text-slate-300">Target OS: Android 15 (Vanilla Ice Cream)</div>
          <div className="text-slate-300">API Level: 35 (Compile & Target)</div>
          <div className="text-slate-300">Min SDK: API 26 (Android 8.0)</div>
          <div className="text-slate-300">Package: com.birdbase.app</div>
        </div>

        <div className="p-4 bg-slate-800/40 rounded-xl border border-white/5 space-y-2">
          <span className="font-semibold text-emerald-400 block">Hardware Telemetry</span>
          <div className="text-slate-300">CPU: Qualcomm Snapdragon 8 Gen 3 (Octa-core)</div>
          <div className="text-slate-300">GPU: Adreno 750 (Vulkan 1.3)</div>
          <div className="text-slate-300">Memory: 8 GB LPDDR5X</div>
          <div className="text-slate-300">Display: 2400 x 1080 (xxxhdpi density bucket)</div>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 7. Virtual Machine Manager (Honest Status)
// ==========================================
export const VirtualMachineManager: React.FC = () => {
  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none p-6 space-y-4 overflow-y-auto custom-scrollbar text-xs">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Cpu className="text-sky-400" size={18} /> Virtual Machine Hypervisor Console
        </h2>
        <span className="text-[10px] bg-sky-950 text-sky-400 px-2 py-0.5 rounded border border-sky-800">
          Diagnostic Audit
        </span>
      </div>

      <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/10 space-y-2 text-slate-300">
        <span className="font-semibold text-white block">Honest Host Virtualization Status:</span>
        <p className="leading-relaxed">
          The container host environment operates under restricted user namespace privileges without hardware KVM acceleration (<code className="text-sky-300">/dev/kvm</code>). Full hardware virtualization is disabled to ensure sandboxed stability.
        </p>
        <p className="text-slate-400">
          All 32 applications in Bird PC execute natively in the browser runtime and export to Android Gradle bytecode for direct on-device execution.
        </p>
      </div>
    </div>
  );
};

// ==========================================
// 8. GitHub Actions CI Workflow Helper
// ==========================================
export const GitHubActionsCiApp: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const workflowYaml = `name: Build Bird PC Native APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant Execute Permission
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: BirdPC-Debug-APK
          path: app/build/outputs/apk/debug/app-debug.apk
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(workflowYaml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none p-6 space-y-4 overflow-y-auto custom-scrollbar text-xs">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <GitBranch className="text-purple-400" size={18} /> GitHub Actions 1-Click APK CI Builder
        </h2>
        <button
          onClick={handleCopy}
          className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg flex items-center gap-1.5 transition-colors font-medium"
        >
          {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? 'Copied' : 'Copy Workflow'}
        </button>
      </div>

      <p className="text-slate-300 leading-relaxed">
        This file is already included at <code className="text-purple-300">.github/workflows/build-apk.yml</code> inside your exported ZIP. Push your project to GitHub to automatically receive a compiled APK in your Actions artifacts!
      </p>

      <pre className="p-4 bg-slate-950 rounded-xl font-mono text-[11px] text-purple-300 border border-white/10 overflow-x-auto select-text">
        {workflowYaml}
      </pre>
    </div>
  );
};
