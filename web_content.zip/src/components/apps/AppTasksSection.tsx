import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Star, 
  Download, 
  Search, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw, 
  ArrowRight,
  ShieldCheck,
  MessageSquare
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AppTaskItem } from '../../types';
import { getAppCatalog, APP_CATEGORIES, TOTAL_APP_CATALOG_COUNT } from '../../services/appLibrary';
import { AppSurveyFeedbackModal } from './AppSurveyFeedbackModal';

export const AppTasksSection: React.FC = () => {
  const { currentUser } = useApp();

  const [category, setCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [appsList, setAppsList] = useState<AppTaskItem[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);

  // Active testing modal
  const [activeApp, setActiveApp] = useState<AppTaskItem | null>(null);

  // Completed app IDs (persisted locally)
  const [completedIds, setCompletedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_completed_app_tasks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const { apps, hasMore: more } = getAppCatalog(1, 10, category, searchQuery);
    setAppsList(apps);
    setPage(1);
    setHasMore(more);
  }, [category, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { apps: newBatch, hasMore: more } = getAppCatalog(nextPage, 10, category, searchQuery);
    setAppsList((prev) => [...prev, ...newBatch]);
    setPage(nextPage);
    setHasMore(more);
  };

  const handleSurveyCompleted = (appId: string, coins: number) => {
    setCompletedIds((prev) => {
      const updated = Array.from(new Set([...prev, appId]));
      localStorage.setItem('taskearn_completed_app_tasks', JSON.stringify(updated));
      return updated;
    });
  };

  const handleNextApp = () => {
    if (!activeApp) return;
    const currentIndex = appsList.findIndex((a) => a.id === activeApp.id);
    if (currentIndex >= 0 && currentIndex + 1 < appsList.length) {
      setActiveApp(appsList[currentIndex + 1]);
    } else {
      setActiveApp(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* 10,000+ Apps Header Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-800/60 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/30">
                <Smartphone className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                App Testing & Feature Surveys
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100,000+ Apps
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Test newly released verified apps, submit quick feature feedback, and earn +50 to +250 Coins instantly!
            </p>
          </div>

          <div className="p-2.5 rounded-2xl bg-black/40 border border-slate-800 flex items-center gap-3 shrink-0">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Catalog Apps</span>
              <span className="text-sm font-black text-amber-400">100,000+</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Tested Today</span>
              <span className="text-sm font-black text-emerald-400">{completedIds.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Categories Horizontal Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {APP_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              category === cat
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search 100,000+ apps across Crypto, AI, Gaming, Social..."
          className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/70 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
        />
      </div>

      {/* Apps List */}
      <div className="space-y-3">
        {appsList.map((app) => {
          const isDone = completedIds.includes(app.id);

          return (
            <div
              key={app.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs ${
                isDone
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-80'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* App Info Left */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                <img
                  src={app.iconUrl}
                  alt={app.name}
                  className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shadow-sm shrink-0"
                  loading="lazy"
                />
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {app.category}
                    </span>
                    <span className="text-[11px] text-amber-400 font-bold flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-current" />
                      {app.rating}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {app.sizeMb} MB • {app.downloadsCount}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white truncate">
                    {app.name}
                  </h3>
                  <p className="text-[11px] text-slate-400 line-clamp-1">
                    {app.description}
                  </p>
                </div>
              </div>

              {/* Reward & Action Right */}
              <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                <div className="text-left sm:text-right">
                  <span className="text-xs font-black text-amber-400 block">
                    +{app.rewardCoins} Coins
                  </span>
                  <span className="text-[10px] text-emerald-400 font-semibold block">
                    ₹{(app.rewardCoins / 100).toFixed(2)}
                  </span>
                </div>

                {isDone ? (
                  <button
                    onClick={() => setActiveApp(app)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-emerald-400 text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Completed</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setActiveApp(app)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Test & Survey</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-xs shadow-xs active:scale-95 transition-all cursor-pointer inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            <span>Load More from 10,000+ App Library</span>
          </button>
        </div>
      )}

      {/* App Testing & Survey Modal */}
      <AppSurveyFeedbackModal
        app={activeApp}
        isOpen={!!activeApp}
        onClose={() => setActiveApp(null)}
        onSurveyCompleted={handleSurveyCompleted}
        onNextApp={handleNextApp}
      />
    </div>
  );
};
