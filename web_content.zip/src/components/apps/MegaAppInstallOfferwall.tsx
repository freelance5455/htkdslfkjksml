import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  Coins, 
  Star, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  Flame, 
  Clock, 
  ExternalLink,
  MessageSquareHeart,
  ChevronDown,
  ChevronUp,
  Search,
  Zap,
  Globe,
  Bot,
  Gamepad2,
  Share2,
  Wallet,
  RefreshCw,
  Activity
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  MEGA_APP_INSTALL_OFFERS, 
  TOTAL_INSTALL_POOL_COINS, 
  TOTAL_APP_INSTALL_CATALOG_COUNT,
  INSTALL_OFFER_CATEGORIES,
  get100kAppInstallOffers 
} from '../../services/appInstallOffers';
import { AppInstallOffer } from '../../types';
import { AppUsageSessionModal } from './AppUsageSessionModal';

interface MegaAppInstallOfferwallProps {
  onOpenFeedbackSurvey?: () => void;
}

export const MegaAppInstallOfferwall: React.FC<MegaAppInstallOfferwallProps> = ({
  onOpenFeedbackSurvey
}) => {
  const { currentUser, adjustUserCoins, systemSettings } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [offersList, setOffersList] = useState<AppInstallOffer[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);

  const [activeInstallingId, setActiveInstallingId] = useState<string | null>(null);
  const [installProgress, setInstallProgress] = useState<number>(0);
  const [expandedOfferId, setExpandedOfferId] = useState<string | null>('install-binance-crypto-v1');

  // Active app usage modal
  const [activeUsageApp, setActiveUsageApp] = useState<AppInstallOffer | null>(null);

  // Track completed installs and completed usages
  const [completedOfferIds, setCompletedOfferIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_completed_install_offers');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [usedAppIdsToday, setUsedAppIdsToday] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_used_apps_today');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const currencySymbol = systemSettings?.currencySymbol || '₹';

  // Fetch initial/updated batch
  useEffect(() => {
    const { offers, hasMore: more } = get100kAppInstallOffers(1, 10, selectedCategory, searchQuery);
    setOffersList(offers);
    setPage(1);
    setHasMore(more);
  }, [selectedCategory, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { offers: newBatch, hasMore: more } = get100kAppInstallOffers(nextPage, 10, selectedCategory, searchQuery);
    setOffersList((prev) => [...prev, ...newBatch]);
    setPage(nextPage);
    setHasMore(more);
  };

  const totalEarnedCoins = completedOfferIds.length * 2800 + usedAppIdsToday.length * 450;

  const handleStartInstall = (offer: AppInstallOffer) => {
    if (completedOfferIds.includes(offer.id)) return;

    setActiveInstallingId(offer.id);
    setInstallProgress(15);

    const interval = setInterval(() => {
      setInstallProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          handleFinishInstall(offer);
          return 100;
        }
        return prev + 25;
      });
    }, 550);
  };

  const handleFinishInstall = (offer: AppInstallOffer) => {
    setActiveInstallingId(null);
    setInstallProgress(0);

    if (!completedOfferIds.includes(offer.id)) {
      const updated = [...completedOfferIds, offer.id];
      setCompletedOfferIds(updated);
      try {
        localStorage.setItem('taskearn_completed_install_offers', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }

      if (currentUser) {
        adjustUserCoins(
          currentUser.id, 
          offer.rewardCoins, 
          `App Install Reward: ${offer.name}`
        );
      }

      confetti({
        particleCount: 95,
        spread: 80,
        origin: { y: 0.6 }
      });
    }
  };

  const handleUsageRewardClaimed = (appId: string, coins: number) => {
    setUsedAppIdsToday((prev) => {
      const updated = Array.from(new Set([...prev, appId]));
      try {
        localStorage.setItem('taskearn_used_apps_today', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'Crypto & Web3': return <Globe className="w-3.5 h-3.5 text-amber-400" />;
      case 'AI & Productivity': return <Bot className="w-3.5 h-3.5 text-purple-400" />;
      case 'Gaming & Esports': return <Gamepad2 className="w-3.5 h-3.5 text-rose-400" />;
      case 'Social & Media': return <Share2 className="w-3.5 h-3.5 text-sky-400" />;
      case 'Fintech & Pay': return <Wallet className="w-3.5 h-3.5 text-emerald-400" />;
      default: return <Sparkles className="w-3.5 h-3.5 text-teal-400" />;
    }
  };

  const getCategoryBadgeClass = (cat: string) => {
    switch (cat) {
      case 'Crypto & Web3': return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'AI & Productivity': return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      case 'Gaming & Esports': return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'Social & Media': return 'bg-sky-500/20 text-sky-300 border-sky-500/30';
      case 'Fintech & Pay': return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      default: return 'bg-teal-500/20 text-teal-300 border-teal-500/30';
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* 100,000+ Apps & Install / Usage Mega Banner */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-950/90 via-slate-900 to-indigo-950/90 border border-purple-800/60 text-white shadow-xl relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-48 h-48 rounded-full bg-purple-500/10 blur-2xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md">
                ⚡ 100,000+ Apps Pool
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Install & Daily Uses Earning
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Crypto • AI • Gaming • Social • Fintech
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              100,000+ Apps: Install & Use to Earn Money
            </h2>

            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Earn money two ways: <strong>Install verified apps</strong> for huge one-time bonuses, plus <strong>Open & Use apps daily for 3-5 mins</strong> to collect continuous recurring cash rewards!
            </p>
          </div>

          {/* Earning Progress Pill & Survey CTA */}
          <div className="p-4 rounded-2xl bg-black/40 border border-slate-800 space-y-2.5 shrink-0 min-w-[220px]">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Earned Progress</span>
              <span className="font-bold text-amber-400">
                🪙 {totalEarnedCoins.toLocaleString()} Coins
              </span>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Installs: {completedOfferIds.length}</span>
              <span>Daily Uses: {usedAppIdsToday.length}</span>
            </div>

            {onOpenFeedbackSurvey && (
              <button
                type="button"
                onClick={onOpenFeedbackSurvey}
                className="w-full py-2 px-3 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <MessageSquareHeart className="w-3.5 h-3.5 text-pink-400" />
                <span>Feature Survey (+500)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Category Filter Chips & Search Bar */}
      <div className="space-y-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          {INSTALL_OFFER_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl whitespace-nowrap font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/20 border border-purple-400'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {getCategoryIcon(cat)}
              <span>{cat}</span>
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search across 100,000+ Crypto, AI, Gaming, Social, or Fintech apps..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Offers List */}
      <div className="space-y-3">
        {offersList.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs rounded-3xl bg-slate-900/60 border border-slate-800">
            No apps found matching "{searchQuery}".
          </div>
        ) : (
          offersList.map((offer) => {
            const isInstalled = completedOfferIds.includes(offer.id);
            const isInstalling = activeInstallingId === offer.id;
            const isExpanded = expandedOfferId === offer.id;
            const isUsedToday = usedAppIdsToday.includes(offer.id);
            const dailyCoins = offer.dailyUsageRewardCoins || 450;

            return (
              <div 
                key={offer.id}
                className={`rounded-3xl border transition-all duration-200 overflow-hidden ${
                  isInstalled 
                    ? 'bg-slate-900/90 border-slate-800 hover:border-slate-750 text-slate-300' 
                    : 'bg-slate-900 border-slate-800 hover:border-purple-800/80 shadow-lg text-white'
                }`}
              >
                {/* Main Card Header */}
                <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3.5 min-w-0">
                    <img 
                      src={offer.iconUrl} 
                      alt={offer.name} 
                      className="w-13 h-13 rounded-2xl object-cover border border-slate-700/80 shrink-0 shadow-md"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-sm sm:text-base text-white truncate">
                          {offer.name}
                        </h3>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${getCategoryBadgeClass(offer.category)}`}>
                          {offer.payoutBadge}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-300">
                          {offer.category}
                        </span>
                      </div>

                      <div className="flex items-center gap-2.5 text-xs text-slate-400 mt-1 flex-wrap">
                        <span>{offer.developer}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-amber-400 font-semibold">
                          <Star className="w-3 h-3 fill-amber-400" />
                          <span>{offer.rating}</span>
                        </span>
                        <span>•</span>
                        <span>{offer.downloadsCount} installs</span>
                        <span>•</span>
                        <span>{offer.sizeMb} MB</span>
                      </div>

                      {/* Twin Rewards Pill (Install + Daily Use) */}
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          <span>Install: +{offer.rewardCoins.toLocaleString()} C ({currencySymbol}{offer.rewardRupees})</span>
                        </span>
                        <span className="px-2 py-0.5 rounded-lg bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[10px] font-bold flex items-center gap-1">
                          <Activity className="w-3 h-3" />
                          <span>Daily Use ({offer.usageMinutesRequired || 3}m): +{dailyCoins} C/day</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Actions: Install & Use App */}
                  <div className="flex items-center gap-2.5 sm:self-center self-end shrink-0">
                    {/* Action 1: Install App */}
                    {isInstalled ? (
                      <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Installed</span>
                      </span>
                    ) : isInstalling ? (
                      <div className="px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-500/50 text-purple-200 text-xs font-bold flex items-center gap-1.5">
                        <div className="w-3 h-3 rounded-full border-2 border-purple-400 border-t-transparent animate-spin" />
                        <span>{installProgress}%</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleStartInstall(offer)}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Install</span>
                      </button>
                    )}

                    {/* Action 2: Daily App Usage Earning */}
                    {isUsedToday ? (
                      <span className="px-3 py-1.5 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Used Today</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setActiveUsageApp(offer)}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-95 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer"
                        title="Open & use app for 3 mins to claim daily coins"
                      >
                        <Activity className="w-3.5 h-3.5" />
                        <span>Use & Earn</span>
                      </button>
                    )}

                    {/* Expand Details button */}
                    <button
                      type="button"
                      onClick={() => setExpandedOfferId(isExpanded ? null : offer.id)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                      title="View Instructions"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Progress bar during simulated install */}
                {isInstalling && (
                  <div className="w-full bg-slate-800 h-1.5">
                    <div 
                      className="bg-gradient-to-r from-purple-500 via-amber-400 to-emerald-400 h-full transition-all duration-300"
                      style={{ width: `${installProgress}%` }}
                    />
                  </div>
                )}

                {/* Collapsible Step-by-Step Instructions */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-2 border-t border-slate-800/80 bg-slate-950/40 space-y-3">
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                      How to Complete & Maximize Earning:
                    </span>
                    
                    <div className="space-y-1.5">
                      {offer.instructions.map((step, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                          <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center justify-center shrink-0 font-bold text-[10px]">
                            {idx + 1}
                          </span>
                          <p className="pt-0.5">{step}</p>
                        </div>
                      ))}
                      <div className="flex items-start gap-2.5 text-xs text-emerald-300">
                        <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center shrink-0 font-bold text-[10px]">
                          ★
                        </span>
                        <p className="pt-0.5">
                          Daily Usage Earning: Open and use {offer.name} for {offer.usageMinutesRequired || 3} mins daily to earn +{dailyCoins} Coins every day!
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center gap-1 text-[11px]">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Play Protect & Malware Scanned Verified</span>
                      </span>

                      <button
                        type="button"
                        onClick={() => setActiveUsageApp(offer)}
                        className="text-purple-400 hover:underline font-bold text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <span>Start Usage Session Now (+{dailyCoins} C)</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Load More Button for 100,000+ Catalog */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            <span>Load More from 100,000+ Apps Pool</span>
          </button>
        </div>
      )}

      {/* App Usage Session Modal */}
      <AppUsageSessionModal
        app={activeUsageApp}
        isOpen={Boolean(activeUsageApp)}
        onClose={() => setActiveUsageApp(null)}
        onRewardClaimed={handleUsageRewardClaimed}
      />

    </div>
  );
};
