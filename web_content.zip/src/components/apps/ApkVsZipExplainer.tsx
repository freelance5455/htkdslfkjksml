import React from 'react';
import {
  HelpCircle,
  AlertTriangle,
  FileArchive,
  Smartphone,
  Cpu,
  Layers,
  CheckCircle,
  XCircle,
  ArrowRight
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

export const ApkVsZipExplainer: React.FC = () => {
  const { openApp } = useDesktop();

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-100 select-none overflow-y-auto custom-scrollbar p-6 space-y-6">
      {/* Title */}
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <HelpCircle className="text-sky-400" size={22} /> Why Renaming .ZIP to .APK Fails
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          A fundamental engineering explanation of Android package binary structures and compilation requirements.
        </p>
      </div>

      {/* Side-by-Side Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left: Project ZIP */}
        <div className="p-5 bg-slate-800/40 rounded-2xl border border-rose-500/30 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-rose-300 flex items-center gap-2">
              <FileArchive size={18} /> BirdPC-Project.zip
            </span>
            <span className="text-[10px] bg-rose-950 px-2 py-0.5 rounded text-rose-300 border border-rose-800">
              Raw Source Code
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            A Project ZIP contains human-readable plain text files designed for developers and build systems:
          </p>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✗</span> Plaintext <code className="text-rose-200">.kt</code> source files (Android cannot execute raw Kotlin source)
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✗</span> Plaintext XML resources (Android requires compiled binary XML)
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✗</span> No <code className="text-rose-200">classes.dex</code> bytecode
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✗</span> No Android cryptographic signature (<code className="text-rose-200">META-INF/*.RSA</code>)
            </li>
          </ul>

          <div className="p-3 bg-rose-950/60 rounded-xl border border-rose-500/30 text-[11px] text-rose-200">
            <strong>Android OS Error:</strong> If you rename <code className="text-white">BirdPC.zip</code> to <code className="text-white">BirdPC.apk</code>, Android will immediately fail with <em>"There was a problem parsing the package" (Parse Error)</em> because the OS package parser cannot find <code className="text-white">classes.dex</code> or binary headers.
          </div>
        </div>

        {/* Right: Compiled APK */}
        <div className="p-5 bg-slate-800/40 rounded-2xl border border-emerald-500/30 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-emerald-300 flex items-center gap-2">
              <Smartphone size={18} /> app-debug.apk
            </span>
            <span className="text-[10px] bg-emerald-950 px-2 py-0.5 rounded text-emerald-300 border border-emerald-800">
              Compiled Executable
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            A genuine Android APK is produced by running <code className="text-emerald-300">gradle assembleDebug</code>:
          </p>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span> <code className="text-emerald-200">classes.dex</code>: Dalvik/ART virtual machine bytecode compiled by D8/R8
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span> <code className="text-emerald-200">resources.arsc</code>: Pre-indexed binary resource table
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span> Binary compiled <code className="text-emerald-200">AndroidManifest.xml</code>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span> APK Signature Scheme v2/v3 embedded signature block
            </li>
          </ul>

          <div className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-500/30 text-[11px] text-emerald-200">
            <strong>Installable:</strong> Recognized immediately by Android PackageInstaller and launches as a full native application.
          </div>
        </div>
      </div>

      {/* Action / Next steps */}
      <div className="p-5 bg-slate-800/50 rounded-2xl border border-white/10 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-sm font-semibold text-white block">Ready to compile the APK?</span>
          <span className="text-xs text-slate-400">Download the ZIP and follow the Termux or GitHub Actions workflow.</span>
        </div>

        <button
          onClick={() => openApp('project-exporter')}
          className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg transition-colors"
        >
          Open APK Builder & Guide <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
};
