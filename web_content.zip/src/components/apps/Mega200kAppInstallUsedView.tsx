import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  Coins, 
  Star, 
  CheckCircle2, 
  Sparkles, 
  Search, 
  Filter, 
  RefreshCw, 
  ExternalLink, 
  ShieldCheck, 
  Check, 
  Clock, 
  ArrowRight,
  Play,
  Zap,
  Activity
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  MEGA_APP_INSTALL_OFFERS, 
  TOTAL_APP_INSTALL_CATALOG_COUNT, 
  INSTALL_OFFER_CATEGORIES 
} from '../../services/appInstallOffers';
import { AppInstallOffer } from '../../types';

export const Mega200kAppInstallUsedView: React.FC = () => {
  const { currentUser, adjustUserCoins, language } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Track app installation state
  const [installedApps, setInstalledApps] = useState<Record<string, 'not_installed' | 'installing' | 'installed' | 'used' | 'collected'>>(() => {
    try {
      const saved = localStorage.getItem('taskearn_200k_app_status');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [installProgress, setInstallProgress] = useState<Record<string, number>>({});
  const [usageSeconds, setUsageSeconds] = useState<Record<string, number>>({});
  const [activeUsingAppId, setActiveUsingAppId] = useState<string | null>(null);

  const saveStatus = (newStatus: Record<string, any>) => {
    setInstalledApps(newStatus);
    try {
      localStorage.setItem('taskearn_200k_app_status', JSON.stringify(newStatus));
    } catch {
      // ignore
    }
  };

  const handleInstallApp = (offer: AppInstallOffer) => {
    // Open app store URL if present
    if (offer.appStoreUrl) {
      window.open(offer.appStoreUrl, '_blank', 'noopener,noreferrer');
    }

    // Set status to installing
    const current = { ...installedApps, [offer.id]: 'installing' as const };
    saveStatus(current);

    // Simulate progress
    let pct = 0;
    const interval = setInterval(() => {
      pct += 25;
      setInstallProgress(prev => ({ ...prev, [offer.id]: pct }));
      if (pct >= 100) {
        clearInterval(interval);
        const done = { ...installedApps, [offer.id]: 'installed' as const };
        saveStatus(done);
      }
    }, 400);
  };

  const handleUseApp = (offer: AppInstallOffer) => {
    setActiveUsingAppId(offer.id);
    // Simulate active app usage for 5 seconds (or fast verify)
    let secs = 0;
    const interval = setInterval(() => {
      secs += 1;
      setUsageSeconds(prev => ({ ...prev, [offer.id]: secs }));
      if (secs >= 3) {
        clearInterval(interval);
        setActiveUsingAppId(null);
        const used = { ...installedApps, [offer.id]: 'used' as const };
        saveStatus(used);
      }
    }, 800);
  };

  const handleCollectCoins = (offer: AppInstallOffer) => {
    if (!currentUser) return;
    adjustUserCoins(
      currentUser.id,
      offer.rewardCoins, 
      `200,000+ App Installed & Used: ${offer.name}`
    );
    const collected = { ...installedApps, [offer.id]: 'collected' as const };
    saveStatus(collected);

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const filteredOffers = MEGA_APP_INSTALL_OFFERS.filter(offer => {
    const matchesCategory = selectedCategory === 'All' || offer.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      offer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (offer.nameBn && offer.nameBn.toLowerCase().includes(searchQuery.toLowerCase())) ||
      offer.developer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-teal-950 via-slate-900 to-emerald-950 border border-teal-500/30 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <Smartphone className="w-3 h-3 text-teal-400" />
                200,000+ Apps Catalog
              </span>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center gap-1">
                <Coins className="w-3 h-3 text-amber-400" />
                Install & Used App Coins
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <span>{language === 'bn' ? '২০০,০০০+ অ্যাপ ইন্সটল ও ব্যবহার করে কয়েন সংগ্রহ' : '200,000+ App Install & Used Earning Hub'}</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'bn'
                ? '১. অ্যাপ ইন্সটল করুন ➔ ২. কিছুক্ষণ ব্যবহার করুন ➔ ৩. সাথে সাথে শত শত কয়েন নিজের ওয়ালেটে সংগ্রহ করুন!'
                : '1. Install App ➔ 2. Open & Use App ➔ 3. Collect Instant Coins directly to your wallet!'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-teal-500/20 self-start sm:self-auto">
            <Coins className="w-5 h-5 text-amber-400" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-bold">Reward per App</span>
              <span className="text-xs font-black text-amber-300">200 - 3,500 Coins</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Steps Guide Pill */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[10px] font-black flex items-center justify-center">1</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? 'অ্যাপ ইন্সটল' : 'Install App'}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center justify-center">2</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? 'ব্যবহার করুন' : 'Used App'}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black flex items-center justify-center">3</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? 'কয়েন সংগ্রহ' : 'Collect Coins'}</span>
        </div>
      </div>

      {/* Categories */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {INSTALL_OFFER_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-teal-600 text-white border border-teal-400 shadow-md shadow-teal-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={language === 'bn' ? '২০০,০০০+ অ্যাপস খুঁজুন...' : 'Search 200,000+ install offers...'}
          className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
        />
      </div>

      {/* Apps Cards List */}
      <div className="space-y-3">
        {filteredOffers.map((offer) => {
          const status = installedApps[offer.id] || 'not_installed';
          const title = language === 'bn' && offer.nameBn ? offer.nameBn : offer.name;
          const isCurrentlyUsing = activeUsingAppId === offer.id;

          return (
            <div
              key={offer.id}
              className={`p-4 rounded-2xl border transition-all space-y-3 ${
                status === 'collected'
                  ? 'bg-slate-900/40 border-slate-800 opacity-80'
                  : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800 hover:border-teal-500/40 shadow-md'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <img
                    src={offer.iconUrl}
                    alt={offer.name}
                    className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shrink-0 shadow-md"
                  />
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-teal-500/10 text-teal-300 border border-teal-500/20">
                        {offer.category}
                      </span>
                      <div className="flex items-center gap-1 text-[11px] text-amber-400 font-bold">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{offer.rating}</span>
                      </div>
                    </div>
                    <h3 className="text-sm font-bold text-white truncate">
                      {title}
                    </h3>
                    <p className="text-[11px] text-slate-400 truncate">
                      {offer.developer} • {offer.sizeMb} MB
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-sm font-black text-amber-400 block">
                    +{offer.rewardCoins} Coins
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold block">
                    ₹{(offer.rewardCoins / 100).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Status progress / actions */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2 text-xs">
                  {status === 'not_installed' && (
                    <span className="text-slate-400 flex items-center gap-1">
                      <Download className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'ইন্সটল অপেক্ষমাণ' : 'Ready to Install'}</span>
                    </span>
                  )}
                  {status === 'installing' && (
                    <span className="text-teal-400 flex items-center gap-1 font-bold animate-pulse">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{language === 'bn' ? 'ইন্সটল হচ্ছে...' : 'Installing...'} {installProgress[offer.id] || 0}%</span>
                    </span>
                  )}
                  {status === 'installed' && (
                    <span className="text-amber-400 flex items-center gap-1 font-bold">
                      <Activity className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'ইন্সটল সম্পন্ন — অ্যাপটি ব্যবহার করুন' : 'Installed — Open & Use App'}</span>
                    </span>
                  )}
                  {status === 'used' && (
                    <span className="text-emerald-400 flex items-center gap-1 font-black">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'bn' ? 'অ্যাপ ব্যবহার যাচাইকৃত — কয়েন সংগ্রহ করুন' : 'App Used — Ready to Collect'}</span>
                    </span>
                  )}
                  {status === 'collected' && (
                    <span className="text-slate-400 flex items-center gap-1 font-bold">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'bn' ? 'কয়েন সংগৃহীত ✅' : 'Coins Collected ✅'}</span>
                    </span>
                  )}
                </div>

                {/* Dynamic Action Button */}
                <div>
                  {status === 'not_installed' && (
                    <button
                      onClick={() => handleInstallApp(offer)}
                      className="px-4 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-teal-600/20 active:scale-95 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'ইন্সটল করুন' : 'Install App'}</span>
                    </button>
                  )}

                  {status === 'installed' && (
                    <button
                      disabled={isCurrentlyUsing}
                      onClick={() => handleUseApp(offer)}
                      className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20 active:scale-95 transition-all"
                    >
                      {isCurrentlyUsing ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>{language === 'bn' ? 'ব্যবহার যাচাই...' : 'Verifying Usage...'}</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>{language === 'bn' ? 'অ্যাপ ব্যবহার করুন' : 'Open & Use App'}</span>
                        </>
                      )}
                    </button>
                  )}

                  {status === 'used' && (
                    <button
                      onClick={() => handleCollectCoins(offer)}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/30 animate-pulse hover:scale-105 transition-all"
                    >
                      <Coins className="w-3.5 h-3.5 text-slate-950" />
                      <span>{language === 'bn' ? `+${offer.rewardCoins} কয়েন সংগ্রহ করুন` : `Collect +${offer.rewardCoins} Coins`}</span>
                    </button>
                  )}

                  {status === 'collected' && (
                    <span className="px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      <span>{language === 'bn' ? 'সংগৃহীত' : 'Collected'}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
