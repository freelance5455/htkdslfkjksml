import { useEffect, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";

export function WeekChart({ data }: { data: { label: string; minutes: number }[] }) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) {
    return (
      <div className="flex h-48 items-end gap-2">
        {data.map((row) => (
          <div key={row.label} className="flex flex-1 flex-col items-center gap-2">
            <div className="w-full rounded-t-md bg-primary" style={{ height: `${Math.max(8, row.minutes)}px` }} />
            <span className="text-xs text-muted">{row.label}</span>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="h-48 w-full text-primary">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 12, right: 4, left: 4, bottom: 0 }}>
          <XAxis
            dataKey="label"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted)", fontSize: 12 }}
          />
          <Tooltip
            cursor={{ fill: "var(--color-surface-2)" }}
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: 12,
              color: "var(--color-fg)",
            }}
            formatter={(value) => [`${Number(value) || 0}`, "min"]}
          />
          <Bar dataKey="minutes" fill="currentColor" radius={[8, 8, 0, 0]} maxBarSize={32} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
