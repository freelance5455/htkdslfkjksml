import React, { useState } from 'react';
import {
  Camera,
  Check,
  Coins,
  Edit3,
  Eye,
  Film,
  Play,
  Square,
  ThumbsUp,
  Upload,
  Users,
  Video,
} from 'lucide-react';
import { RecordedClipDraft, YouTubeChannel, YouTubeVideo } from '../types/game';

interface YouTubeAppProps {
  channel: YouTubeChannel;
  isRecording: boolean;
  recordingSeconds: number;
  pendingDraft: RecordedClipDraft | null;
  onUpdateChannel: (patch: Partial<YouTubeChannel>) => void;
  onCaptureProfilePhoto: () => string;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onPublishVideo: (
    title: string,
    category: YouTubeVideo['category'],
    draft: RecordedClipDraft
  ) => void;
  onDiscardDraft: () => void;
  onClaimRevenue: () => void;
}

const AVATAR_COLORS = ['#ef4444', '#f59e0b', '#10b981', '#0ea5e9', '#8b5cf6', '#ec4899'];
const CATEGORIES: YouTubeVideo['category'][] = [
  'Vlog',
  'Car Review',
  'Street Race',
  'Police Chase',
  'Sea View',
];

export const YouTubeApp: React.FC<YouTubeAppProps> = ({
  channel,
  isRecording,
  recordingSeconds,
  pendingDraft,
  onUpdateChannel,
  onCaptureProfilePhoto,
  onStartRecording,
  onStopRecording,
  onPublishVideo,
  onDiscardDraft,
  onClaimRevenue,
}) => {
  const [editingProfile, setEditingProfile] = useState(!channel.created);
  const [nameInput, setNameInput] = useState(channel.channelName);
  const [idInput, setIdInput] = useState(channel.customerId);
  const [bioInput, setBioInput] = useState(channel.bio);
  const [colorInput, setColorInput] = useState(channel.avatarColor);

  const [videoTitle, setVideoTitle] = useState('');
  const [videoCategory, setVideoCategory] = useState<YouTubeVideo['category']>('Vlog');
  const [playingVideo, setPlayingVideo] = useState<YouTubeVideo | null>(null);

  const totalUnclaimed = channel.videos.reduce((sum, v) => sum + v.unclaimedCash, 0);

  const handleSaveChannel = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateChannel({
      created: true,
      channelName: nameInput.trim() || 'Karachi Creator',
      customerId: idInput.trim() || 'KHI-001',
      bio: bioInput.trim() || 'Exploring Grand Karachi City 1',
      avatarColor: colorInput,
    });
    setEditingProfile(false);
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="px-2 py-0.5 rounded bg-red-600 text-white font-black text-xs tracking-tight">
            YouTube
          </div>
          <span className="text-xs font-bold text-slate-300">Karachi Studio</span>
        </div>
        {channel.created && !editingProfile && (
          <button
            type="button"
            onClick={() => {
              setNameInput(channel.channelName);
              setIdInput(channel.customerId);
              setBioInput(channel.bio);
              setColorInput(channel.avatarColor);
              setEditingProfile(true);
            }}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-slate-200 cursor-pointer"
          >
            <Edit3 className="w-3 h-3" /> Customize
          </button>
        )}
      </div>

      {/* Create / Customize Channel Form */}
      {editingProfile && (
        <form
          onSubmit={handleSaveChannel}
          className="p-3.5 rounded-xl bg-slate-900 border border-slate-700 space-y-2.5"
        >
          <div className="text-xs font-black uppercase tracking-wider text-rose-400">
            {channel.created ? 'Customize Your Channel' : 'Create Your YouTube Channel'}
          </div>

          {/* Channel Photo / Live 3D Camera Selfie */}
          <div className="flex items-center gap-3">
            <div
              style={{ backgroundColor: colorInput }}
              className="w-14 h-14 rounded-full border-2 border-white overflow-hidden flex items-center justify-center shrink-0 font-black text-lg text-white"
            >
              {channel.avatarDataUrl ? (
                <img
                  src={channel.avatarDataUrl}
                  alt="Channel Avatar"
                  className="w-full h-full object-cover"
                />
              ) : (
                (nameInput || 'K').slice(0, 2).toUpperCase()
              )}
            </div>
            <div className="space-y-1.5 flex-1">
              <button
                type="button"
                onClick={() => {
                  const snap = onCaptureProfilePhoto();
                  if (snap) onUpdateChannel({ avatarDataUrl: snap });
                }}
                className="w-full py-1.5 px-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" /> Snap Live Game Photo
              </button>
              <div className="flex gap-1.5">
                {AVATAR_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColorInput(c)}
                    style={{ backgroundColor: c }}
                    className={`w-5 h-5 rounded-full border cursor-pointer ${
                      colorInput === c ? 'border-white scale-110' : 'border-slate-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
              Channel Name
            </label>
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              placeholder="e.g. Karachi Supercars"
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-rose-400"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
              Customer ID / Handle
            </label>
            <input
              type="text"
              value={idInput}
              onChange={(e) => setIdInput(e.target.value)}
              placeholder="e.g. KHI-AQ-101"
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-rose-400"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
              Channel Bio
            </label>
            <input
              type="text"
              value={bioInput}
              onChange={(e) => setBioInput(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-rose-400"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Check className="w-4 h-4" /> Save Channel Profile
          </button>
        </form>
      )}

      {/* Channel Banner & Stats Card */}
      {!editingProfile && (
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center gap-3">
            <div
              style={{ backgroundColor: channel.avatarColor }}
              className="w-12 h-12 rounded-full border-2 border-rose-500 overflow-hidden flex items-center justify-center shrink-0 font-black text-white"
            >
              {channel.avatarDataUrl ? (
                <img
                  src={channel.avatarDataUrl}
                  alt={channel.channelName}
                  className="w-full h-full object-cover"
                />
              ) : (
                channel.channelName.slice(0, 2).toUpperCase()
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-black text-white truncate">{channel.channelName}</div>
              <div className="text-[11px] font-bold text-rose-400 truncate">
                ID: {channel.customerId}
              </div>
              <div className="text-[10px] text-slate-400 truncate">{channel.bio}</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-center">
            <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-xs font-black text-white tabular-nums flex items-center justify-center gap-1">
                <Users className="w-3 h-3 text-rose-400" />
                {channel.subscribers.toLocaleString()}
              </div>
              <div className="text-[9px] text-slate-400">Subscribers</div>
            </div>
            <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-xs font-black text-white tabular-nums flex items-center justify-center gap-1">
                <Eye className="w-3 h-3 text-sky-400" />
                {channel.totalViews.toLocaleString()}
              </div>
              <div className="text-[9px] text-slate-400">Total Views</div>
            </div>
            <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-xs font-black text-emerald-400 tabular-nums">
                Rs. {channel.totalEarned.toLocaleString()}
              </div>
              <div className="text-[9px] text-slate-400">Earned</div>
            </div>
          </div>

          {totalUnclaimed > 0 && (
            <button
              type="button"
              onClick={onClaimRevenue}
              className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Coins className="w-4 h-4" /> Collect Ad Revenue (+Rs. {totalUnclaimed.toLocaleString()})
            </button>
          )}
        </div>
      )}

      {/* Record / Publish Gameplay Video Section */}
      {!editingProfile && !pendingDraft && (
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          {isRecording ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-rose-400">
                <span className="flex items-center gap-1.5">
                  <Video className="w-4 h-4" /> Recording Gameplay...
                </span>
                <span className="tabular-nums">{recordingSeconds}s</span>
              </div>
              <button
                type="button"
                onClick={onStopRecording}
                className="w-full py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-white" /> Stop Recording & Preview
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onStartRecording}
              className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Film className="w-4 h-4" /> Record Real Karachi Video
            </button>
          )}
        </div>
      )}

      {/* Draft Video Ready to Publish */}
      {pendingDraft && (
        <div className="p-3 rounded-xl bg-slate-900 border border-amber-400/70 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-amber-400 uppercase">
              Recorded Clip Ready ({pendingDraft.durationSec}s)
            </span>
            <button
              type="button"
              onClick={onDiscardDraft}
              className="text-[11px] font-bold text-slate-400 hover:text-rose-400 cursor-pointer"
            >
              Discard
            </button>
          </div>

          <div className="rounded-lg overflow-hidden bg-black border border-slate-700">
            {pendingDraft.videoUrl ? (
              <video
                src={pendingDraft.videoUrl}
                poster={pendingDraft.thumbnailDataUrl}
                controls
                playsInline
                className="w-full h-32 object-cover"
              />
            ) : (
              <img
                src={pendingDraft.thumbnailDataUrl}
                alt="Recorded gameplay preview"
                className="w-full h-32 object-cover"
              />
            )}
          </div>

          <input
            type="text"
            value={videoTitle}
            onChange={(e) => setVideoTitle(e.target.value)}
            placeholder={`Driving in ${pendingDraft.district} | GKC 1`}
            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
          />

          <div className="flex flex-wrap gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setVideoCategory(cat)}
                className={`px-2 py-1 rounded text-[10px] font-bold cursor-pointer ${
                  videoCategory === cat
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              const title =
                videoTitle.trim() || `${videoCategory} in ${pendingDraft.district} | GKC 1`;
              onPublishVideo(title, videoCategory, pendingDraft);
              setVideoTitle('');
            }}
            className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Upload className="w-4 h-4" /> Publish to YouTube & Earn
          </button>
        </div>
      )}

      {/* Built-In Video Player Modal for Watching Published Videos */}
      {playingVideo && (
        <div className="p-3 rounded-xl bg-slate-900 border border-sky-500/60 space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs font-black text-white truncate pr-2">{playingVideo.title}</div>
            <button
              type="button"
              onClick={() => setPlayingVideo(null)}
              className="text-[11px] font-bold text-slate-400 hover:text-white cursor-pointer"
            >
              Close
            </button>
          </div>
          <div className="rounded-lg overflow-hidden bg-black border border-slate-800">
            {playingVideo.videoUrl ? (
              <video
                src={playingVideo.videoUrl}
                poster={playingVideo.thumbnailDataUrl}
                controls
                autoPlay
                playsInline
                className="w-full h-36 object-cover"
              />
            ) : (
              <img
                src={playingVideo.thumbnailDataUrl}
                alt={playingVideo.title}
                className="w-full h-36 object-cover"
              />
            )}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>{playingVideo.views.toLocaleString()} views · {playingVideo.district}</span>
            <span className="text-emerald-400 font-bold">
              Earned Rs. {playingVideo.earnedCash.toLocaleString()}
            </span>
          </div>
        </div>
      )}

      {/* Published Videos Feed */}
      <div className="space-y-2">
        <div className="text-xs font-black uppercase tracking-wider text-slate-400">
          Your Published Videos ({channel.videos.length})
        </div>
        {channel.videos.length === 0 ? (
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 text-center text-xs text-slate-400">
            No videos yet! Tap "Record Real Karachi Video", drive around Karachi, and publish to earn YouTube money.
          </div>
        ) : (
          channel.videos.map((v) => (
            <button
              key={v.id}
              type="button"
              onClick={() => setPlayingVideo(v)}
              className="w-full p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center gap-2.5 text-left cursor-pointer"
            >
              <div className="relative w-24 h-14 rounded-lg overflow-hidden bg-slate-950 shrink-0">
                {v.thumbnailDataUrl ? (
                  <img
                    src={v.thumbnailDataUrl}
                    alt={v.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-800">
                    <Play className="w-4 h-4 text-white" />
                  </div>
                )}
                <span className="absolute bottom-1 right-1 px-1 rounded bg-black/85 text-[9px] font-bold text-white tabular-nums">
                  {v.durationSec}s
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-white truncate">{v.title}</div>
                <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-2 tabular-nums">
                  <span>{v.views.toLocaleString()} views</span>
                  <span className="inline-flex items-center gap-0.5">
                    <ThumbsUp className="w-2.5 h-2.5" /> {v.likes.toLocaleString()}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-emerald-400 mt-0.5 tabular-nums">
                  +Rs. {v.earnedCash.toLocaleString()} earned
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
};
