import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  ShieldCheck,
  ShieldAlert,
  Bell,
  CheckCircle2,
  Sliders,
  ExternalLink,
  MessageSquare,
  Mail,
  Calendar,
  Video,
  Layers,
  Sparkles,
  PhoneCall,
} from 'lucide-react';
import { JarvisSettings } from '../types';
import { generateNotificationBriefing, BriefingReport } from '../utils/notificationBriefing';
import { speakJarvis, stopSpeaking } from '../utils/audioSynthesizer';

interface NotificationBriefingModalProps {
  isOpen: boolean;
  settings: JarvisSettings;
  onClose: () => void;
  onGrantAccess: () => void;
  onStartMorningCall?: () => void;
}

export const NotificationBriefingModal: React.FC<NotificationBriefingModalProps> = ({
  isOpen,
  settings,
  onClose,
  onGrantAccess,
  onStartMorningCall,
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  if (!isOpen) return null;

  const briefing: BriefingReport = generateNotificationBriefing(
    settings.capturedNotifications,
    settings
  );

  const handleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    setIsSpeaking(true);
    speakJarvis(
      briefing.speechScript,
      settings.voicePitch,
      settings.voiceSpeed,
      settings.voicePersonality,
      () => {
        setIsSpeaking(false);
      }
    );
  };

  const handleClose = () => {
    stopSpeaking();
    setIsSpeaking(false);
    onClose();
  };

  const getAppIcon = (app: string) => {
    const lower = app.toLowerCase();
    if (lower.includes('whatsapp') || lower.includes('message') || lower.includes('slack')) {
      return <MessageSquare className="w-3.5 h-3.5 text-[#00E5FF]" />;
    }
    if (lower.includes('gmail') || lower.includes('email') || lower.includes('mail')) {
      return <Mail className="w-3.5 h-3.5 text-[#FF5252]" />;
    }
    if (lower.includes('calendar')) {
      return <Calendar className="w-3.5 h-3.5 text-[#FFB300]" />;
    }
    if (lower.includes('youtube') || lower.includes('video')) {
      return <Video className="w-3.5 h-3.5 text-[#FF1744]" />;
    }
    return <Bell className="w-3.5 h-3.5 text-[#00E5FF]" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="notification-briefing-modal"
        className="w-full max-w-lg max-h-[90vh] bg-[#0E1525] border border-cyan-500/30 rounded-2xl flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="px-4 py-3.5 bg-[#131B2E] border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-[#00E5FF]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-mono font-bold tracking-wider text-white">
                NOTIFICATION BRIEFING PREVIEW
              </h3>
              <p className="text-[10px] text-slate-400 font-mono">
                Local On-Device Synthesis Engine
              </p>
            </div>
          </div>
          <button
            id="btn-close-briefing-modal"
            onClick={handleClose}
            className="w-7 h-7 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-slate-200 text-xs">
          {/* Notification Access Status Alert */}
          {!settings.isNotificationAccessGranted ? (
            <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-semibold">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>Notification Access Not Enabled</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Android security policy strictly forbids reading notifications until you explicitly grant
                Notification Access in Android Settings. JARVIS has zero access to notifications currently.
              </p>
              <button
                id="btn-modal-grant-access"
                type="button"
                onClick={onGrantAccess}
                className="w-full py-2 px-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                ENABLE NOTIFICATION ACCESS IN SETTINGS
              </button>
            </div>
          ) : (
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span className="font-mono text-[11px] font-semibold">ACCESS GRANTED • ON-DEVICE ONLY</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400/80">0% Cloud Upload</span>
            </div>
          )}

          {/* SCRIPT PREVIEW BOX */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] tracking-widest text-[#00E5FF] font-semibold flex items-center gap-1">
                <Volume2 className="w-3 h-3" />
                WHAT JARVIS WILL SPEAK
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Voice: {settings.voicePersonality}
              </span>
            </div>

            <div className="p-3.5 bg-[#090D16] border border-slate-800 rounded-xl font-mono text-[12px] text-slate-100 whitespace-pre-wrap leading-relaxed shadow-inner">
              {briefing.displayPreview}
            </div>
          </div>

          {/* Grouped App Summary Chips */}
          {briefing.groups.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] tracking-wider text-slate-400 font-semibold flex items-center gap-1">
                  <Layers className="w-3 h-3 text-[#00E5FF]" />
                  GROUPED BY APPLICATION ({briefing.totalFilteredCount} TOTAL)
                </span>
                {briefing.ignoredCount > 0 && (
                  <span className="text-[10px] text-slate-400">
                    {briefing.ignoredCount} noise item(s) filtered
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                {briefing.groups.map(g => (
                  <div
                    key={g.app}
                    className="p-2 bg-[#131B2E] border border-slate-800 rounded-lg flex items-center justify-between"
                  >
                    <div className="flex items-center gap-1.5">
                      {getAppIcon(g.app)}
                      <span className="font-medium text-white text-[11px]">{g.app}</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 text-[#00E5FF] font-mono text-[10px] font-bold">
                      {g.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Captured Notification Details List */}
          {settings.isNotificationAccessGranted && (
            <div className="space-y-2">
              <span className="font-mono text-[10px] tracking-wider text-slate-400 font-semibold flex items-center gap-1">
                <Bell className="w-3 h-3 text-[#00E5FF]" />
                CAPTURED NOTIFICATION DETAILS (MINIMUM DATA STORED)
              </span>

              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {settings.capturedNotifications.map(item => {
                  const isFilteredOut = !briefing.groups.some(g =>
                    g.items.some(i => i.id === item.id)
                  );

                  return (
                    <div
                      key={item.id}
                      className={`p-2.5 rounded-lg border text-[11px] transition-all ${
                        isFilteredOut
                          ? 'bg-slate-900/40 border-slate-800/50 opacity-40'
                          : 'bg-[#131B2E] border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          {getAppIcon(item.app)}
                          <span className="font-semibold text-white">{item.app}</span>
                          <span className="text-slate-400 font-mono text-[10px]">
                            • {item.timeReceived}
                          </span>
                        </div>
                        <span
                          className={`text-[9px] font-mono px-1.5 py-0.2 rounded ${
                            item.importance === 'high'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                              : item.importance === 'normal'
                              ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {item.importance.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-slate-200 font-medium">{item.title}</div>
                      <div className="text-slate-400 text-[10.5px] truncate">{item.text}</div>
                      {isFilteredOut && (
                        <div className="text-amber-400/80 font-mono text-[9px] mt-1">
                          [Ignored by current filter: {item.isOngoing ? 'Ongoing system noise' : 'Low priority'}]
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Privacy Guarantee Footer Note */}
          <div className="p-2.5 bg-slate-900/60 border border-slate-800/80 rounded-lg text-[10px] text-slate-400 font-mono flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-[#00E5FF] shrink-0 mt-0.5" />
            <div>
              <p className="text-slate-300 font-medium">Privacy Architecture Guarantee</p>
              <p>
                All notification contents remain strictly local in Android memory/DataStore. Zero network
                payloads are transmitted to external servers.
              </p>
            </div>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="p-3 bg-[#131B2E] border-t border-slate-800 flex items-center gap-2 shrink-0">
          <button
            id="btn-modal-speak"
            type="button"
            onClick={handleSpeak}
            className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
              isSpeaking
                ? 'bg-red-500/20 border border-red-500/50 text-red-400'
                : 'bg-[#1C2640] hover:bg-[#253354] border border-[#00E5FF]/40 text-[#00E5FF]'
            }`}
          >
            {isSpeaking ? (
              <>
                <VolumeX className="w-4 h-4 animate-pulse" />
                STOP SPEAKING
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                SPEAK PREVIEW WITH JARVIS
              </>
            )}
          </button>

          {onStartMorningCall && (
            <button
              id="btn-modal-start-call"
              type="button"
              onClick={() => {
                handleClose();
                onStartMorningCall();
              }}
              className="py-2.5 px-3.5 rounded-lg bg-[#00E5FF] hover:bg-[#00c4db] text-[#0A0E17] text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-transform active:scale-[0.98] shadow-md shadow-[#00E5FF]/20"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              TEST CALL
            </button>
          )}

          <button
            id="btn-modal-done"
            type="button"
            onClick={handleClose}
            className="py-2.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
