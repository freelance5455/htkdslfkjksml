import {
  Bell,
  Globe,
  MessageSquare,
  Settings,
  Target,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Toaster } from "sonner";
import { AddWatchDialog } from "@/components/add-watch-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { WatchCard } from "@/components/watch-card";
import { useEngine } from "@/hooks/use-engine";
import { copy } from "@/lib/i18n";
import { useLaksha, type Watch } from "@/lib/store";
import { cn, formatIstClock, formatRelative, smsHref } from "@/lib/utils";

type Tab = "hub" | "alerts" | "sms" | "settings";

export function LakshaApp() {
  const [tab, setTab] = useState<Tab>("hub");
  const [now, setNow] = useState(() => new Date());
  const [note, setNote] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [notifyState, setNotifyState] = useState<NotificationPermission | "unsupported">("default");

  const lang = useLaksha((s) => s.lang);
  const watches = useLaksha((s) => s.watches);
  const alerts = useLaksha((s) => s.alerts);
  const sms = useLaksha((s) => s.sms);
  const primaryId = useLaksha((s) => s.primaryId);
  const startedAt = useLaksha((s) => s.startedAt);
  const markAlertsRead = useLaksha((s) => s.markAlertsRead);

  useEngine();

  useEffect(() => {
    void useLaksha.persist.rehydrate();
  }, []);

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (typeof Notification === "undefined") {
      setNotifyState("unsupported");
      return;
    }
    setNotifyState(Notification.permission);
  }, []);

  useEffect(() => {
    if (tab === "alerts") markAlertsRead();
  }, [tab, markAlertsRead]);

  const t = copy[lang];
  const unread = alerts.filter((a) => !a.read).length;
  const todayKey = useMemo(() => {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(now);
  }, [now]);
  const alertsToday = alerts.filter((a) => {
    const k = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date(a.createdAt));
    return k === todayKey;
  }).length;
  const hoursOn = Math.max(1, Math.round((Date.now() - startedAt) / 3600000));
  const primary = watches.find((w) => w.id === primaryId) ?? watches[0];
  const rest = watches.filter((w) => w.id !== primary?.id);
  const liveCount = watches.filter((w) => w.enabled).length;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          classNames: {
            toast: "bg-surface text-fg border-border",
            title: "text-fg",
            description: "text-muted",
          },
        }}
      />
      <div className="mx-auto flex min-h-dvh max-w-6xl md:grid md:grid-cols-[220px_1fr]">
        <aside className="hidden border-r border-border md:flex md:flex-col md:gap-6 md:p-6">
          <Brand hoursOn={hoursOn} live={liveCount > 0} />
          <nav className="flex flex-col gap-1">
            <NavBtn id="hub" tab={tab} setTab={setTab} label={t.hub} icon={Target} />
            <NavBtn id="alerts" tab={tab} setTab={setTab} label={t.alerts} icon={Bell} badge={unread} />
            <NavBtn id="sms" tab={tab} setTab={setTab} label={t.sms} icon={MessageSquare} badge={sms.length} />
            <NavBtn id="settings" tab={tab} setTab={setTab} label={t.settings} icon={Settings} />
          </nav>
          <p className="mt-auto text-xs leading-normal text-subtle">{t.footer}</p>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col pb-24 md:pb-0">
          <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/95 px-4 py-3 md:px-8">
            <div className="flex min-w-0 items-center gap-3 md:hidden">
              <Iris live={liveCount > 0} />
              <div className="min-w-0">
                <p className="font-display text-xl leading-tight">{t.app}</p>
                <p className="truncate text-xs text-muted">{t.tagline}</p>
              </div>
            </div>
            <p className="hidden font-mono text-sm tabular-nums text-muted md:block">
              {formatIstClock(lang, now)}
            </p>
            <div className="ml-auto flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-signal/30 bg-signal/10 px-2.5 py-1 text-xs font-medium text-signal">
                <span className="size-1.5 rounded-full bg-signal" />
                {t.live}
              </span>
            </div>
          </header>

          <main className="flex-1 px-4 py-5 md:px-8 md:py-8">
            {tab === "hub" && (
              <Hub
                note={note}
                setNote={setNote}
                onAdd={() => setDialogOpen(true)}
                primary={primary}
                rest={rest}
                liveCount={liveCount}
                alertsToday={alertsToday}
                smsCount={sms.length}
                hoursOn={hoursOn}
              />
            )}
            {tab === "alerts" && <AlertsView />}
            {tab === "sms" && <SmsView />}
            {tab === "settings" && (
              <SettingsView notifyState={notifyState} setNotifyState={setNotifyState} />
            )}
          </main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] md:hidden">
        <div className="grid grid-cols-4">
          <TabBtn id="hub" tab={tab} setTab={setTab} label={t.hub} icon={Target} />
          <TabBtn id="alerts" tab={tab} setTab={setTab} label={t.alerts} icon={Bell} badge={unread} />
          <TabBtn id="sms" tab={tab} setTab={setTab} label={t.sms} icon={MessageSquare} />
          <TabBtn id="settings" tab={tab} setTab={setTab} label={t.settings} icon={Settings} />
        </div>
      </nav>

      <AddWatchDialog open={dialogOpen} note={note} onOpenChange={(o) => {
        setDialogOpen(o);
        if (!o) setNote("");
      }} />
    </div>
  );
}

function Brand({ hoursOn, live }: { hoursOn: number; live: boolean }) {
  const lang = useLaksha((s) => s.lang);
  const t = copy[lang];
  return (
    <div className="flex items-center gap-3">
      <Iris live={live} />
      <div>
        <p className="font-display text-2xl leading-tight">{t.app}</p>
        <p className="text-xs text-muted">
          {hoursOn} {t.hoursWatch}
        </p>
      </div>
    </div>
  );
}

function Iris({ live }: { live?: boolean }) {
  return (
    <div className="iris" aria-hidden="true">
      {live ? <span className="iris-sweep" /> : null}
      <span className="iris-ring" />
      <span className="iris-ring-mid" />
      {live ? <span className="iris-pulse" /> : null}
      <span className="iris-pip" />
    </div>
  );
}

function NavBtn({
  id,
  tab,
  setTab,
  label,
  icon: Icon,
  badge,
}: {
  id: Tab;
  tab: Tab;
  setTab: (t: Tab) => void;
  label: string;
  icon: typeof Bell;
  badge?: number;
}) {
  const active = tab === id;
  return (
    <button
      type="button"
      onClick={() => setTab(id)}
      className={cn(
        "flex h-11 items-center gap-3 rounded-md px-3 text-sm",
        active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
      )}
    >
      <Icon className="size-4" />
      <span className="flex-1 text-left">{label}</span>
      {badge ? (
        <span className="rounded-full bg-alert/20 px-1.5 font-mono text-xs tabular-nums text-alert">
          {badge}
        </span>
      ) : null}
    </button>
  );
}

function TabBtn({
  id,
  tab,
  setTab,
  label,
  icon: Icon,
  badge,
}: {
  id: Tab;
  tab: Tab;
  setTab: (t: Tab) => void;
  label: string;
  icon: typeof Bell;
  badge?: number;
}) {
  const active = tab === id;
  return (
    <button
      type="button"
      onClick={() => setTab(id)}
      className={cn(
        "relative flex min-h-14 flex-col items-center justify-center gap-1 text-xs",
        active ? "text-fg" : "text-muted",
      )}
    >
      <Icon className="size-5" />
      {label}
      {badge ? (
        <span className="absolute top-1.5 right-1/4 size-1.5 rounded-full bg-alert" />
      ) : null}
    </button>
  );
}

function Hub({
  note,
  setNote,
  onAdd,
  primary,
  rest,
  liveCount,
  alertsToday,
  smsCount,
  hoursOn,
}: {
  note: string;
  setNote: (v: string) => void;
  onAdd: () => void;
  primary?: Watch;
  rest: Watch[];
  liveCount: number;
  alertsToday: number;
  smsCount: number;
  hoursOn: number;
}) {
  const lang = useLaksha((s) => s.lang);
  const t = copy[lang];

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-3 gap-2 md:gap-3">
        <Stat label={t.watchingFor} value={String(liveCount)} />
        <Stat label={t.alertsToday} value={String(alertsToday)} />
        <Stat label={t.smsOut} value={String(smsCount)} />
      </div>

      <section className="rounded-xl border border-border bg-surface p-4 md:p-5">
        <Label htmlFor="composer" className="text-sm text-fg">
          {t.ask}
        </Label>
        <p className="mt-1 text-xs text-muted">{t.composerHint}</p>
        <Textarea
          id="composer"
          className="mt-3 min-h-28 rounded-lg"
          placeholder={t.placeholder}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-subtle">
            {hoursOn} {t.hoursWatch}
          </p>
          <Button onClick={onAdd} disabled={!note.trim()}>
            {t.watchIt}
          </Button>
        </div>
      </section>

      {primary ? (
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-medium tracking-wide text-muted uppercase">{t.primary}</h2>
          <WatchCard watch={primary} featured />
        </section>
      ) : (
        <p className="rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-muted">
          {t.empty}
        </p>
      )}

      {rest.length > 0 && (
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-medium tracking-wide text-muted uppercase">{t.watching}</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {rest.map((w) => (
              <WatchCard key={w.id} watch={w} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-3">
      <p className="font-mono text-2xl tabular-nums leading-none text-fg">{value}</p>
      <p className="mt-2 text-xs text-muted">{label}</p>
    </div>
  );
}

function AlertsView() {
  const lang = useLaksha((s) => s.lang);
  const alerts = useLaksha((s) => s.alerts);
  const t = copy[lang];
  if (alerts.length === 0) {
    return <p className="py-16 text-center text-sm text-muted">{t.emptyAlerts}</p>;
  }
  return (
    <ol className="flex flex-col gap-3">
      {alerts.map((a) => (
        <li key={a.id} className="rounded-lg border border-border bg-surface p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-medium text-fg">{a.title}</p>
              <p className="mt-1 text-sm leading-normal text-muted">{a.body}</p>
            </div>
            <time className="shrink-0 font-mono text-xs tabular-nums text-subtle">
              {formatRelative(a.createdAt, lang)}
            </time>
          </div>
          <p className="mt-2 text-xs text-subtle">
            {a.notification && a.sms ? t.channelBoth : a.sms ? t.sms : t.notif}
          </p>
        </li>
      ))}
    </ol>
  );
}

function SmsView() {
  const lang = useLaksha((s) => s.lang);
  const phone = useLaksha((s) => s.phone);
  const sms = useLaksha((s) => s.sms);
  const t = copy[lang];
  const latest = sms[0];

  if (sms.length === 0) {
    return <p className="py-16 text-center text-sm text-muted">{t.emptySms}</p>;
  }

  return (
    <div className="mx-auto flex max-w-md flex-col gap-4">
      <div className="overflow-hidden rounded-xl border border-border bg-surface">
        <div className="flex items-center gap-3 border-b border-border px-4 py-3">
          <span className="flex size-9 items-center justify-center rounded-full bg-surface-2">
            <Globe className="size-4 text-muted" />
          </span>
          <div>
            <p className="text-sm font-medium">{t.fromLaksha}</p>
            <p className="font-mono text-xs text-muted">{phone || "—"}</p>
          </div>
        </div>
        <div className="flex max-h-[60dvh] flex-col gap-3 overflow-y-auto bg-bg px-4 py-4">
          {[...sms].reverse().map((m) => (
            <div key={m.id} className="max-w-[85%] rounded-lg rounded-tl-xs bg-surface-2 px-3 py-2">
              <p className="text-sm leading-normal text-fg">{m.body}</p>
              <p className="mt-1 font-mono text-xs tabular-nums text-subtle">
                {formatRelative(m.createdAt, lang)} · {t.delivered}
              </p>
            </div>
          ))}
        </div>
      </div>
      {latest ? (
        <Button
          variant="secondary"
          disabled={!phone}
          onClick={() => {
            if (!phone) return;
            window.location.href = smsHref(phone, latest.body);
          }}
        >
          {phone ? t.openSms : t.addPhone}
        </Button>
      ) : null}
    </div>
  );
}

function SettingsView({
  notifyState,
  setNotifyState,
}: {
  notifyState: NotificationPermission | "unsupported";
  setNotifyState: (v: NotificationPermission | "unsupported") => void;
}) {
  const lang = useLaksha((s) => s.lang);
  const phone = useLaksha((s) => s.phone);
  const sound = useLaksha((s) => s.sound);
  const quietOn = useLaksha((s) => s.quietOn);
  const quietFrom = useLaksha((s) => s.quietFrom);
  const quietTo = useLaksha((s) => s.quietTo);
  const setLang = useLaksha((s) => s.setLang);
  const setPhone = useLaksha((s) => s.setPhone);
  const setSound = useLaksha((s) => s.setSound);
  const setQuiet = useLaksha((s) => s.setQuiet);
  const wipe = useLaksha((s) => s.wipe);
  const t = copy[lang];

  async function enableNotify() {
    if (typeof Notification === "undefined") {
      setNotifyState("unsupported");
      return;
    }
    const perm = await Notification.requestPermission();
    setNotifyState(perm);
  }

  return (
    <div className="mx-auto flex max-w-lg flex-col gap-5">
      <section className="rounded-lg border border-border bg-surface p-4">
        <Label>{t.language}</Label>
        <div className="mt-3 flex gap-2">
          <Button variant={lang === "mr" ? "default" : "secondary"} onClick={() => setLang("mr")}>
            {t.marathi}
          </Button>
          <Button variant={lang === "en" ? "default" : "secondary"} onClick={() => setLang("en")}>
            {t.english}
          </Button>
        </div>
      </section>

      <section className="flex flex-col gap-2 rounded-lg border border-border bg-surface p-4">
        <Label htmlFor="phone">{t.phone}</Label>
        <p className="text-xs text-muted">{t.phoneHint}</p>
        <Input
          id="phone"
          inputMode="tel"
          placeholder="+91 98765 43210"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
      </section>

      <section className="flex items-center justify-between gap-3 rounded-lg border border-border bg-surface p-4">
        <div>
          <p className="text-sm font-medium">{t.notifyPerm}</p>
          <p className="text-xs text-muted">
            {notifyState === "granted"
              ? t.notifyOn
              : notifyState === "denied"
                ? t.notifyDenied
                : t.enableNotify}
          </p>
        </div>
        {notifyState !== "granted" && notifyState !== "unsupported" ? (
          <Button size="sm" onClick={() => void enableNotify()}>
            {t.enableNotify}
          </Button>
        ) : null}
      </section>

      <section className="flex items-center justify-between rounded-lg border border-border bg-surface p-4">
        <p className="text-sm font-medium">{t.sound}</p>
        <Switch checked={sound} onCheckedChange={setSound} />
      </section>

      <section className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">{t.quiet}</p>
            <p className="text-xs text-muted">{t.quietHint}</p>
          </div>
          <Switch checked={quietOn} onCheckedChange={(v) => setQuiet(v)} />
        </div>
        {quietOn ? (
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="qf">{t.quietFrom}</Label>
              <Input
                id="qf"
                type="time"
                value={quietFrom}
                onChange={(e) => setQuiet(true, e.target.value, quietTo)}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="qt">{t.quietTo}</Label>
              <Input
                id="qt"
                type="time"
                value={quietTo}
                onChange={(e) => setQuiet(true, quietFrom, e.target.value)}
              />
            </div>
          </div>
        ) : null}
      </section>

      <Button
        variant="outline"
        onClick={() => {
          if (window.confirm(t.wipeConfirm)) wipe();
        }}
      >
        {t.wipe}
      </Button>
    </div>
  );
}

