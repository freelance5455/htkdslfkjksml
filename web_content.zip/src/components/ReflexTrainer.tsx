import React, { useState, useEffect, useRef } from 'react';
import { 
  Zap, 
  Crosshair, 
  RotateCcw, 
  Trophy, 
  Award, 
  Flame, 
  Target, 
  Play, 
  Square,
  Volume2
} from 'lucide-react';
import { sounds } from '../utils/soundEffects';

interface DamagePopup {
  id: number;
  x: number;
  y: number;
  damage: number;
  isHeadshot: boolean;
}

export const ReflexTrainer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [difficulty, setDifficulty] = useState<'normal' | 'pro' | 'grandmaster'>('pro');
  const [score, setScore] = useState(0);
  const [headshots, setHeadshots] = useState(0);
  const [totalShots, setTotalShots] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [reactionTimes, setReactionTimes] = useState<number[]>([]);
  const [targetPos, setTargetPos] = useState<{ x: number; y: number } | null>(null);
  const [damagePopups, setDamagePopups] = useState<DamagePopup[]>([]);
  const [spawnTimestamp, setSpawnTimestamp] = useState<number>(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Speed settings based on difficulty
  const timeoutMs = difficulty === 'normal' ? 1800 : difficulty === 'pro' ? 1100 : 750;

  const spawnTarget = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const paddingX = 80;
    const paddingY = 80;
    const x = Math.floor(Math.random() * (rect.width - paddingX * 2)) + paddingX;
    const y = Math.floor(Math.random() * (rect.height - paddingY * 2)) + paddingY;

    setTargetPos({ x, y });
    setSpawnTimestamp(Date.now());

    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(() => {
      // Missed target timeout
      setStreak(0);
      spawnTarget();
    }, timeoutMs);
  };

  const startGame = () => {
    sounds.playClick();
    setIsPlaying(true);
    setScore(0);
    setHeadshots(0);
    setTotalShots(0);
    setStreak(0);
    setMaxStreak(0);
    setReactionTimes([]);
    setDamagePopups([]);
    setTimeout(() => spawnTarget(), 300);
  };

  const stopGame = () => {
    sounds.playClick();
    setIsPlaying(false);
    if (timerRef.current) clearTimeout(timerRef.current);
    setTargetPos(null);
  };

  const addDamagePopup = (x: number, y: number, damage: number, isHeadshot: boolean) => {
    const newPopup: DamagePopup = {
      id: Date.now() + Math.random(),
      x,
      y,
      damage,
      isHeadshot
    };
    setDamagePopups(prev => [...prev.slice(-6), newPopup]);

    setTimeout(() => {
      setDamagePopups(prev => prev.filter(p => p.id !== newPopup.id));
    }, 800);
  };

  const handleHeadshot = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isPlaying || !targetPos) return;

    const reaction = Date.now() - spawnTimestamp;
    setReactionTimes(prev => [...prev, reaction]);

    sounds.playHeadshot();
    const damage = Math.floor(Math.random() * 80) + 360; // 360 - 440 red damage
    addDamagePopup(targetPos.x, targetPos.y - 30, damage, true);

    setScore(s => s + 150);
    setHeadshots(h => h + 1);
    setTotalShots(t => t + 1);
    setStreak(s => {
      const next = s + 1;
      if (next > maxStreak) setMaxStreak(next);
      return next;
    });

    spawnTarget();
  };

  const handleBodyHit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isPlaying || !targetPos) return;

    const reaction = Date.now() - spawnTimestamp;
    setReactionTimes(prev => [...prev, reaction]);

    sounds.playBodyHit();
    const damage = Math.floor(Math.random() * 15) + 35; // 35 - 50 yellow damage
    addDamagePopup(targetPos.x, targetPos.y + 10, damage, false);

    setScore(s => s + 40);
    setTotalShots(t => t + 1);
    setStreak(0);

    spawnTarget();
  };

  const handleContainerMiss = () => {
    if (!isPlaying) return;
    setTotalShots(t => t + 1);
    setStreak(0);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const hsPercentage = totalShots > 0 ? Math.round((headshots / totalShots) * 100) : 0;
  const avgReactionTime = reactionTimes.length > 0 
    ? Math.round(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length) 
    : 0;

  const getRankAssessment = () => {
    if (totalShots < 5) return 'Calibrating Reflexes...';
    if (hsPercentage >= 80 && avgReactionTime < 400) return '👑 GRANDMASTER 1-TAP DRAG KING';
    if (hsPercentage >= 65 && avgReactionTime < 600) return '🔥 HEROIC ESPORTS RUSHER';
    if (hsPercentage >= 45) return '🎯 MASTER RANK MARKS-MAN';
    return '⚡ RECOIL STABILIZATION IN PROGRESS';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/30 font-rajdhani">
                AIM & REFLEX TRAINING LAB
              </span>
              <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
                <Target className="w-3.5 h-3.5" /> Red-Number Drag Simulation
              </span>
            </div>
            <h2 className="text-2xl font-bold font-heading text-white">
              One-Tap Drag & Hitbox Reflex Simulator
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Sharpen your reaction latency and precision flick. Click or upward-flick onto the RED head hitbox for authentic 400+ damage red numbers.
            </p>
          </div>

          {/* Controls & Difficulty */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-[#090b14] p-1 rounded-xl border border-slate-700 text-xs">
              <button
                onClick={() => setDifficulty('normal')}
                disabled={isPlaying}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  difficulty === 'normal' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                }`}
              >
                Normal
              </button>
              <button
                onClick={() => setDifficulty('pro')}
                disabled={isPlaying}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  difficulty === 'pro' ? 'bg-orange-600 text-white' : 'text-slate-400'
                }`}
              >
                Pro (1.1s)
              </button>
              <button
                onClick={() => setDifficulty('grandmaster')}
                disabled={isPlaying}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  difficulty === 'grandmaster' ? 'bg-red-600 text-white' : 'text-slate-400'
                }`}
              >
                GM (0.75s)
              </button>
            </div>

            {!isPlaying ? (
              <button
                onClick={startGame}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl shadow-lg shadow-orange-600/30 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Start Training</span>
              </button>
            ) : (
              <button
                onClick={stopGame}
                className="flex items-center gap-2 px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>Stop</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Scorebar */}
        <div className="mt-5 pt-4 border-t border-slate-700/60 grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
          <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">TOTAL SCORE</span>
            <span className="text-xl font-bold font-mono text-orange-400">{score}</span>
          </div>
          <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">HEADSHOT %</span>
            <span className="text-xl font-bold font-mono text-red-500">{hsPercentage}%</span>
          </div>
          <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">AVG REACTION</span>
            <span className="text-xl font-bold font-mono text-cyan-400">{avgReactionTime} ms</span>
          </div>
          <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">CURRENT STREAK</span>
            <span className="text-xl font-bold font-mono text-yellow-400">⚡ {streak}</span>
          </div>
          <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">MAX STREAK</span>
            <span className="text-xl font-bold font-mono text-amber-300">{maxStreak}</span>
          </div>
        </div>
      </div>

      {/* Interactive Combat Canvas Box */}
      <div
        ref={containerRef}
        onClick={handleContainerMiss}
        className="relative w-full h-[420px] sm:h-[480px] bg-[#090b14] border-2 border-slate-700/80 rounded-3xl overflow-hidden cursor-crosshair select-none shadow-2xl flex flex-col justify-between"
      >
        {/* Tactical Crosshair Grid */}
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <div className="w-full h-full bg-[radial-gradient(#f97316_1px,transparent_1px)] [background-size:32px_32px]"></div>
        </div>

        {/* Center Target Indicator */}
        <div className="absolute top-3 left-4 text-xs font-mono text-slate-500 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
          <span>BATTLE COMBAT RANGE • TARGET ACQUISITION</span>
        </div>

        {/* Evaluation Banner */}
        <div className="absolute top-3 right-4 text-xs font-bold font-rajdhani text-amber-300 bg-[#121626]/80 px-3 py-1 rounded-lg border border-amber-500/30">
          {getRankAssessment()}
        </div>

        {/* Target Entity */}
        {isPlaying && targetPos && (
          <div
            style={{
              left: `${targetPos.x}px`,
              top: `${targetPos.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
            className="absolute z-20 flex flex-col items-center group cursor-crosshair animate-in fade-in zoom-in duration-100"
          >
            {/* RED Head Hitbox */}
            <div
              onClick={handleHeadshot}
              className="w-10 h-10 rounded-full border-2 border-red-500 bg-red-600/40 hover:bg-red-500 flex items-center justify-center shadow-lg shadow-red-500/50 cursor-crosshair transition-transform active:scale-90"
              title="Click Head for One-Tap Red Damage!"
            >
              <div className="w-3.5 h-3.5 rounded-full bg-red-500 animate-pulse"></div>
              <span className="absolute -top-4 text-[9px] font-black text-red-400 font-mono tracking-wider">
                HEAD
              </span>
            </div>

            {/* YELLOW Body Hitbox */}
            <div
              onClick={handleBodyHit}
              className="w-16 h-20 bg-amber-600/30 hover:bg-amber-600/50 border-2 border-amber-500 rounded-t-xl rounded-b-md mt-0.5 flex items-center justify-center cursor-crosshair transition-transform active:scale-95"
              title="Body Hit (Yellow Damage)"
            >
              <span className="text-[10px] font-bold text-amber-300 font-mono">
                BODY
              </span>
            </div>
          </div>
        )}

        {/* Damage Popup Floaters */}
        {damagePopups.map((popup) => (
          <div
            key={popup.id}
            style={{
              left: `${popup.x}px`,
              top: `${popup.y}px`,
              transform: 'translate(-50%, -100%)',
            }}
            className={`absolute pointer-events-none font-heading font-extrabold text-2xl sm:text-3xl tracking-wider animate-bounce ${
              popup.isHeadshot
                ? 'text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.9)]'
                : 'text-yellow-400 drop-shadow-[0_0_10px_rgba(234,179,8,0.7)]'
            }`}
          >
            {popup.isHeadshot ? `⚡ ${popup.damage}` : popup.damage}
          </div>
        ))}

        {/* Start Overlay if not playing */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-30">
            <div className="w-16 h-16 rounded-2xl bg-orange-600/20 border-2 border-orange-500 flex items-center justify-center text-orange-400 mb-4 shadow-lg shadow-orange-500/20">
              <Crosshair className="w-8 h-8 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <h3 className="text-2xl font-bold font-heading text-white">
              Free Fire Headshot Reflex Lab
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mt-1 mb-5">
              Target appears dynamically in combat space. Flick directly to the <span className="text-red-400 font-bold">RED head circle</span> to test your reaction time and headshot percentage!
            </p>
            <button
              onClick={startGame}
              className="px-6 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl shadow-xl shadow-orange-600/30 transition-all cursor-pointer text-sm"
            >
              Enter Combat Range
            </button>
          </div>
        )}

        {/* Bottom instructions */}
        <div className="p-3 text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-800/80">
          <span>Target Color: <strong className="text-red-400">Red Circle = One-Tap Headshot</strong> • <strong className="text-yellow-400">Body = Standard Hit</strong></span>
          <span className="hidden sm:inline">Tip: Practice upward snap flick with your mouse or finger</span>
        </div>
      </div>
    </div>
  );
};
