import React, { useState } from 'react';
import { RecoveryCheckIn } from '../types';
import { StorageService } from '../services/storage';
import {
  ShieldAlert,
  AlertTriangle,
  HeartPulse,
  CheckCircle,
  X,
  PhoneCall,
  Activity,
} from 'lucide-react';

interface SafetyCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveRecovery: (recovery: RecoveryCheckIn) => void;
  onAdviceEmergencyStop?: () => void;
}

export const SafetyCheckInModal: React.FC<SafetyCheckInModalProps> = ({
  isOpen,
  onClose,
  onSaveRecovery,
  onAdviceEmergencyStop,
}) => {
  const [sleepHours, setSleepHours] = useState(7.5);
  const [sleepQuality, setSleepQuality] = useState(4);
  const [energyLevel, setEnergyLevel] = useState(4);
  const [sorenessScore, setSorenessScore] = useState(2);
  const [painAreas, setPainAreas] = useState<string[]>([]);
  const [hasSharpPain, setHasSharpPain] = useState(false);
  const [hasChestPainOrDizziness, setHasChestPainOrDizziness] = useState(false);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const painAreaOptions = [
    'Shin / Shin Splints',
    'Knee (Patella/IT Band)',
    'Calf / Achilles',
    'Hamstring',
    'Hip Flexor / Groin',
    'Lower Back',
    'Foot / Plantar',
  ];

  const toggleArea = (area: string) => {
    setPainAreas((prev) =>
      prev.includes(area) ? prev.filter((a) => a !== area) : [...prev, area]
    );
  };

  const isEmergency = hasChestPainOrDizziness || (hasSharpPain && sorenessScore >= 8);
  const isHighRisk = sorenessScore >= 6 || hasSharpPain || sleepHours < 5 || energyLevel <= 2;

  const handleSave = () => {
    const recoveryLog: RecoveryCheckIn = {
      id: 'rec-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      sleepHours,
      sleepQuality,
      energyLevel,
      sorenessScore,
      painAreas,
      hasSharpPain,
      readyForHardWorkout: !isHighRisk && !isEmergency,
      notes,
    };

    StorageService.saveRecoveryLog(recoveryLog);
    onSaveRecovery(recoveryLog);

    if (isEmergency && onAdviceEmergencyStop) {
      onAdviceEmergencyStop();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-2xl p-5 shadow-2xl relative my-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-2.5 mb-3 border-b border-zinc-800 pb-3">
          <HeartPulse className="w-6 h-6 text-[#00FF66]" />
          <div>
            <h2 className="font-athletic text-base font-extrabold uppercase text-white">
              Daily Recovery & Injury Screen
            </h2>
            <p className="text-[11px] text-zinc-400">
              Discipline means listening to your body before hard efforts
            </p>
          </div>
        </div>

        {/* Red Flag Warning If Emergency Symptoms Checked */}
        {hasChestPainOrDizziness ? (
          <div className="p-3.5 bg-rose-500/20 border-2 border-rose-500 rounded-xl space-y-2 mb-4 animate-pulse">
            <div className="flex items-center gap-2 text-rose-300 font-bold text-xs uppercase">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              <span>CRITICAL MEDICAL SAFETY ADVISORY</span>
            </div>
            <p className="text-xs text-rose-100 leading-relaxed">
              If you are experiencing chest pain, dizziness, fainting, or severe abnormal shortness of breath: <strong>STOP RUNNING IMMEDIATELY</strong>, sit down in a shaded area, loosen tight clothing, and seek urgent medical evaluation.
            </p>
          </div>
        ) : isHighRisk ? (
          <div className="p-3 bg-amber-500/15 border border-amber-500/40 rounded-xl flex items-start gap-2.5 text-xs text-amber-300 mb-4">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Coach Jaat Recovery Guidance:</p>
              <p className="mt-0.5 text-zinc-300">
                Elevated soreness or acute pain reported. High-intensity 400m intervals are downgraded today to active recovery walk or full rest. Do not run through pain.
              </p>
            </div>
          </div>
        ) : null}

        {/* Form Inputs */}
        <div className="space-y-3.5 text-xs">
          {/* Critical Symptoms Checkboxes */}
          <div className="p-3 bg-black/60 border border-zinc-800 rounded-xl space-y-2">
            <label className="flex items-start gap-2 text-zinc-200 cursor-pointer">
              <input
                type="checkbox"
                checked={hasChestPainOrDizziness}
                onChange={(e) => setHasChestPainOrDizziness(e.target.checked)}
                className="w-4 h-4 mt-0.5 accent-rose-500 rounded"
              />
              <span className="font-semibold text-rose-300">
                Chest tightness, dizziness, fainting, or abnormal breathing distress
              </span>
            </label>

            <label className="flex items-start gap-2 text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={hasSharpPain}
                onChange={(e) => setHasSharpPain(e.target.checked)}
                className="w-4 h-4 mt-0.5 accent-amber-500 rounded"
              />
              <span>Sharp or stabbing pain in a joint or bone (not just mild muscular fatigue)</span>
            </label>
          </div>

          {/* Sleep Hours & Quality */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-zinc-300 block mb-1">
                Sleep Duration: <span className="text-[#00FF66] font-mono-numbers">{sleepHours}h</span>
              </label>
              <input
                type="range"
                min="4"
                max="10"
                step="0.5"
                value={sleepHours}
                onChange={(e) => setSleepHours(parseFloat(e.target.value))}
                className="w-full accent-[#00FF66] bg-zinc-800 h-2 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <label className="font-semibold text-zinc-300 block mb-1">
                Energy Level: <span className="text-white font-mono-numbers">{energyLevel}/5</span>
              </label>
              <input
                type="range"
                min="1"
                max="5"
                value={energyLevel}
                onChange={(e) => setEnergyLevel(parseInt(e.target.value))}
                className="w-full accent-cyan-400 bg-zinc-800 h-2 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Muscle Soreness Score */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-semibold text-zinc-300">Muscle Soreness Score:</span>
              <span className="font-bold text-amber-400 font-mono-numbers">{sorenessScore} / 10</span>
            </div>
            <input
              type="range"
              min="0"
              max="10"
              value={sorenessScore}
              onChange={(e) => setSorenessScore(parseInt(e.target.value))}
              className="w-full accent-amber-400 bg-zinc-800 h-2 rounded-lg cursor-pointer"
            />
          </div>

          {/* Soreness Location Chips */}
          <div>
            <label className="font-semibold text-zinc-400 block mb-1.5 uppercase tracking-wider text-[10px]">
              Identify Sore or Tight Muscle Groups
            </label>
            <div className="flex flex-wrap gap-1.5">
              {painAreaOptions.map((area) => (
                <button
                  type="button"
                  key={area}
                  onClick={() => toggleArea(area)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition ${
                    painAreas.includes(area)
                      ? 'bg-amber-400 text-black border-amber-400 font-bold'
                      : 'bg-black text-zinc-400 border-zinc-800 hover:text-white'
                  }`}
                >
                  {area}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="font-semibold text-zinc-400 block mb-1">
              Recovery Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. slight calf tightness after Wednesday intervals"
              className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleSave}
          className="mt-5 w-full py-3 rounded-xl bg-[#00FF66] text-black font-athletic font-black text-sm uppercase tracking-wide flex items-center justify-center gap-1.5 hover:bg-[#10B981] transition shadow-md glow-neon-sm"
        >
          <CheckCircle className="w-4 h-4" />
          <span>Save Recovery Check-in</span>
        </button>
      </div>
    </div>
  );
};
