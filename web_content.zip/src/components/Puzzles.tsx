import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess } from "chess.js";
import Board from "./Board";
import { PUZZLES } from "../data/content";
import { findKingSquare, type PieceColor } from "../lib/chess";
import { cn } from "../utils/cn";

const norm = (san: string) => san.replace(/[+#!?]/g, "");

export default function Puzzles() {
  const [index, setIndex] = useState(0);
  const puzzle = PUZZLES[index];
  const gameRef = useRef(new Chess(puzzle.fen));
  const [fen, setFen] = useState(puzzle.fen);
  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [targets, setTargets] = useState<string[]>([]);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [feedback, setFeedback] = useState<{ tone: "idle" | "good" | "bad" | "done"; text: string }>(
    { tone: "idle", text: "Find the best move." },
  );
  const [showHint, setShowHint] = useState(false);
  const [solved, setSolved] = useState<Record<string, boolean>>({});

  const sideToMove = (puzzle.fen.split(" ")[1] as PieceColor) ?? "w";

  const reset = useCallback(
    (i: number) => {
      const p = PUZZLES[i];
      gameRef.current = new Chess(p.fen);
      setFen(p.fen);
      setStep(0);
      setSelected(null);
      setTargets([]);
      setLastMove(null);
      setShowHint(false);
      setFeedback({ tone: "idle", text: "Find the best move." });
    },
    [],
  );

  useEffect(() => {
    reset(index);
  }, [index, reset]);

  const playOpponent = useCallback(
    (nextStep: number) => {
      const p = PUZZLES[index];
      if (nextStep >= p.solution.length) return;
      window.setTimeout(() => {
        const mv = gameRef.current.move(p.solution[nextStep]);
        if (mv) setLastMove({ from: mv.from, to: mv.to });
        setFen(gameRef.current.fen());
        setStep(nextStep + 1);
      }, 450);
    },
    [index],
  );

  const onSquareClick = (square: string) => {
    const g = gameRef.current;
    if (feedback.tone === "done" || step >= puzzle.solution.length) return;

    if (selected) {
      const legal = g.moves({ square: selected as never, verbose: true }) as Array<{
        to: string;
        san: string;
      }>;
      const match = legal.find((m) => m.to === square);
      if (match) {
        const expected = puzzle.solution[step];
        if (norm(match.san) === norm(expected)) {
          const mv = g.move(match.san);
          if (mv) setLastMove({ from: mv.from, to: mv.to });
          setFen(g.fen());
          setSelected(null);
          setTargets([]);
          const nextStep = step + 1;
          setStep(nextStep);
          if (nextStep >= puzzle.solution.length) {
            setFeedback({ tone: "done", text: "Solved! Brilliant. ✨" });
            setSolved((s) => ({ ...s, [puzzle.id]: true }));
          } else {
            setFeedback({ tone: "good", text: "Correct — keep going!" });
            playOpponent(nextStep);
          }
        } else {
          setSelected(null);
          setTargets([]);
          setFeedback({ tone: "bad", text: "Not the move. There is something stronger…" });
        }
        return;
      }
    }

    const piece = g.get(square as never);
    if (piece && piece.color === g.turn()) {
      setSelected(square);
      setTargets((g.moves({ square: square as never, verbose: true }) as Array<{ to: string }>).map(
        (m) => m.to,
      ));
    } else {
      setSelected(null);
      setTargets([]);
    }
  };

  const showSolution = () => {
    const g = new Chess(puzzle.fen);
    puzzle.solution.forEach((san) => {
      try {
        g.move(san);
      } catch {
        /* ignore */
      }
    });
    gameRef.current = g;
    setFen(g.fen());
    setStep(puzzle.solution.length);
    setSelected(null);
    setTargets([]);
    const hist = g.history({ verbose: true }) as Array<{ from: string; to: string }>;
    const last = hist[hist.length - 1];
    if (last) setLastMove({ from: last.from, to: last.to });
    setFeedback({ tone: "idle", text: `Solution: ${puzzle.solution.join(" ")}` });
  };

  const checkSquare = useMemo(() => {
    const g = gameRef.current;
    return g.inCheck() ? findKingSquare(g, g.turn()) : null;
  }, [fen]);

  const hintSquares = useMemo(() => {
    if (!showHint || step >= puzzle.solution.length) return [];
    try {
      const probe = new Chess(gameRef.current.fen());
      const mv = probe.move(puzzle.solution[step]);
      return mv ? [mv.from] : [];
    } catch {
      return [];
    }
  }, [showHint, step, fen, puzzle]);

  const solvedCount = Object.keys(solved).length;

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div>
        <div className="mb-2 flex items-center justify-between text-sm text-neutral-400">
          <span className="font-semibold text-neutral-200">
            {sideToMove === "w" ? "White" : "Black"} to play
          </span>
          <span>
            Puzzle {index + 1} / {PUZZLES.length} · solved {solvedCount}
          </span>
        </div>
        <Board
          fen={fen}
          orientation={sideToMove}
          selected={selected}
          targets={targets}
          lastMove={lastMove}
          checkSquare={checkSquare}
          hintSquares={hintSquares}
          onSquareClick={onSquareClick}
        />
      </div>

      <aside className="flex flex-col gap-4">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold text-neutral-50">{puzzle.name}</h3>
              <p className="text-xs uppercase tracking-wider text-emerald-400">{puzzle.theme}</p>
            </div>
            <span className="rounded-lg bg-black/40 px-2 py-1 text-xs font-semibold text-neutral-300">
              {puzzle.rating}
            </span>
          </div>
          <p
            className={cn(
              "mt-3 rounded-xl px-3 py-2 text-sm",
              feedback.tone === "good" && "bg-emerald-500/15 text-emerald-300",
              feedback.tone === "done" && "bg-emerald-500/20 text-emerald-200",
              feedback.tone === "bad" && "bg-rose-500/15 text-rose-300",
              feedback.tone === "idle" && "bg-black/30 text-neutral-300",
            )}
          >
            {feedback.text}
          </p>
          {showHint && <p className="mt-2 text-sm text-amber-300/90">💡 {puzzle.hint}</p>}
          {(feedback.tone === "done" || step >= puzzle.solution.length) && (
            <p className="mt-3 border-t border-white/10 pt-3 text-sm text-neutral-300">
              {puzzle.lesson}
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setShowHint(true)}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10"
          >
            💡 Hint
          </button>
          <button
            onClick={() => reset(index)}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10"
          >
            ↺ Retry
          </button>
          <button
            onClick={showSolution}
            className="rounded-xl bg-white/5 px-3 py-2 text-sm font-semibold text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10"
          >
            👁 Solution
          </button>
          <button
            onClick={() => setIndex((i) => (i + 1) % PUZZLES.length)}
            className="rounded-xl bg-emerald-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-emerald-500"
          >
            Next →
          </button>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Puzzle set
          </p>
          <div className="grid gap-1">
            {PUZZLES.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setIndex(i)}
                className={cn(
                  "flex items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition",
                  i === index ? "bg-emerald-500/15 text-emerald-200" : "text-neutral-300 hover:bg-white/5",
                )}
              >
                <span>
                  {solved[p.id] ? "✓ " : ""}
                  {p.name}
                </span>
                <span className="text-xs text-neutral-500">{p.rating}</span>
              </button>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
