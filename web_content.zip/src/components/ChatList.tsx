import React, { useState, useEffect } from 'react';
import { Search, MessageSquare, Plus, Check, CheckCheck, Users, Bot } from 'lucide-react';
import type { User, Chat } from '../types/index.ts';
import { api, wsClient } from '../services/api.ts';
import { BlueTick } from './BlueTick.tsx';

interface ChatListProps {
  currentUser: User;
  onSelectChat: (chat: Chat) => void;
  activeChatId?: string;
  onStartNewChat: () => void;
  onOpenAIChat?: () => void;
}

export const ChatList: React.FC<ChatListProps> = ({
  currentUser,
  onSelectChat,
  activeChatId,
  onStartNewChat,
  onOpenAIChat,
}) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [allUsers, setAllUsers] = useState<Record<string, User>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  const loadChatsAndUsers = async () => {
    try {
      const [chatsData, usersData] = await Promise.all([
        api.getChats(currentUser.id),
        api.getUsers(),
      ]);

      const userMap: Record<string, User> = {};
      usersData.forEach(u => {
        userMap[u.id] = u;
      });
      setAllUsers(userMap);
      setChats(chatsData || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadChatsAndUsers();

    const unsubMsg = wsClient.on('message:new', (data) => {
      setChats(prev => {
        const existingIdx = prev.findIndex(c => c.id === data.chatId);
        if (existingIdx !== -1) {
          const updated = [...prev];
          updated[existingIdx] = data.chat;
          // Bring to top
          const [moved] = updated.splice(existingIdx, 1);
          return [moved, ...updated];
        } else {
          return [data.chat, ...prev];
        }
      });
    });

    const unsubPresence = wsClient.on('user:presence', (data) => {
      setAllUsers(prev => {
        if (!prev[data.userId]) return prev;
        return {
          ...prev,
          [data.userId]: {
            ...prev[data.userId],
            online: data.online,
          }
        };
      });
    });

    return () => {
      unsubMsg();
      unsubPresence();
    };
  }, [currentUser.id]);

  const filteredChats = chats.filter(chat => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    if (chat.type === 'group') {
      return chat.name?.toLowerCase().includes(q) || chat.lastMessage?.text.toLowerCase().includes(q);
    }
    const otherId = chat.participants.find(p => p !== currentUser.id);
    const other = otherId ? allUsers[otherId] : null;
    return other?.fullName.toLowerCase().includes(q) ||
           other?.username.toLowerCase().includes(q) ||
           chat.lastMessage?.text.toLowerCase().includes(q);
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080a0f] overflow-hidden text-slate-100 relative">
      {/* Search Bar */}
      <div className="p-3.5 bg-[#0a0f18] border-b border-slate-800/80 shrink-0">
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search messages or clan squads..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#0c121e] border border-slate-700/80 text-white placeholder-slate-500 text-xs focus:border-cyan-400 outline-none"
          />
        </div>

        {/* AI Support Direct Chat Button */}
        {onOpenAIChat && (
          <button
            onClick={onOpenAIChat}
            className="mt-2.5 w-full p-2.5 rounded-xl bg-gradient-to-r from-cyan-950/70 via-blue-950/50 to-[#0c121e] border border-cyan-500/30 hover:border-cyan-400 flex items-center justify-between text-left transition-all group cursor-pointer shadow-sm hover:shadow-[0_0_12px_rgba(0,210,255,0.2)]"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform shadow-[0_0_8px_rgba(0,210,255,0.3)]">
                <Bot size={16} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span className="truncate">Unknown Gamer AI Support</span>
                  <span className="px-1.5 py-0.5 rounded-full text-[9px] font-mono bg-cyan-400/15 text-cyan-300 border border-cyan-400/30 shrink-0">
                    24/7 AI
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  Ask about rules, bans, reports & gameplay issues
                </div>
              </div>
            </div>
            <span className="text-[11px] font-bold text-cyan-400 shrink-0 pl-1 group-hover:translate-x-0.5 transition-transform">
              Chat &rarr;
            </span>
          </button>
        )}
      </div>

      {/* Chats Feed */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40">
        {filteredChats.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <MessageSquare size={36} className="mx-auto mb-2 text-slate-600" />
            <p className="text-xs font-semibold text-slate-300">No conversations yet</p>
            <p className="text-[11px] text-slate-500 mt-1">Start chatting with permitted gamers</p>
            <button
              onClick={onStartNewChat}
              className="mt-4 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
            >
              Start New Chat
            </button>
          </div>
        ) : (
          filteredChats.map((chat) => {
            const isGroup = chat.type === 'group';
            const otherId = !isGroup ? chat.participants.find(p => p !== currentUser.id) : null;
            const otherUser = otherId ? allUsers[otherId] : null;

            const title = isGroup ? chat.name : (otherUser?.fullName || 'Gamer');
            const avatar = isGroup ? chat.avatar : (otherUser?.avatarUrl || 'https://api.dicebear.com/7.x/bottts/svg?seed=user');
            const isVerified = !isGroup && otherUser?.verifiedBlueTick;
            const isOnline = !isGroup && otherUser?.online;
            const unreadCount = chat.unreadCounts?.[currentUser.id] || 0;
            const isActive = activeChatId === chat.id;

            return (
              <div
                key={chat.id}
                onClick={() => onSelectChat(chat)}
                className={`p-3.5 flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-cyan-950/40 border-l-2 border-cyan-400'
                    : 'hover:bg-[#0c121e]'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={avatar}
                      alt={title}
                      className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-700 object-cover"
                    />
                    {isOnline && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-[#080a0f]" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 font-bold text-white text-sm truncate">
                      <span className="truncate">{title}</span>
                      {isVerified && <BlueTick size="sm" />}
                    </div>

                    <div className="text-xs text-slate-400 truncate max-w-[200px] sm:max-w-xs mt-0.5 flex items-center gap-1">
                      {chat.lastMessage ? (
                        <>
                          {chat.lastMessage.senderId === currentUser.id && (
                            <CheckCheck size={14} className="text-cyan-400 shrink-0" />
                          )}
                          <span className="truncate">{chat.lastMessage.text}</span>
                        </>
                      ) : (
                        <span className="italic text-slate-500">Tap to start conversation</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1 shrink-0 text-right">
                  {chat.lastMessage && (
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(chat.lastMessage.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500 text-slate-950 shadow-[0_0_8px_rgba(0,210,255,0.6)]">
                      {unreadCount}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating Action Button for New Chat */}
      <button
        onClick={onStartNewChat}
        className="absolute bottom-4 right-4 w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 flex items-center justify-center shadow-lg shadow-cyan-500/30 active:scale-95 transition-all cursor-pointer z-10"
        title="Start Chat"
      >
        <Plus size={24} />
      </button>
    </div>
  );
};
