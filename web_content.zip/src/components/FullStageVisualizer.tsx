/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Minimize2,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Waves,
  BarChart3,
  CircleDot,
  Radio,
  Grid3X3,
  Sparkles,
} from 'lucide-react';
import { LiveWaveformCanvas } from './LiveWaveformCanvas';
import { Track, VisualizerMode } from '../types';

interface FullStageVisualizerProps {
  currentTrack: Track;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
  visualizerMode: VisualizerMode;
  onVisualizerModeChange: (mode: VisualizerMode) => void;
  onClose: () => void;
  backdropUrl: string | null;
  onOpenAIStudio: () => void;
}

export const FullStageVisualizer: React.FC<FullStageVisualizerProps> = ({
  currentTrack,
  isPlaying,
  onPlayPause,
  onNext,
  onPrev,
  visualizerMode,
  onVisualizerModeChange,
  onClose,
  backdropUrl,
  onOpenAIStudio,
}) => {
  const modes: { id: VisualizerMode; label: string; icon: React.ReactNode }[] = [
    { id: 'waveform', label: 'Waveform', icon: <Waves className="w-4 h-4" /> },
    { id: 'spectrum', label: 'Spectrum', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'circular', label: 'Circular Ring', icon: <CircleDot className="w-4 h-4" /> },
    { id: 'lasers', label: '3D Lasers', icon: <Radio className="w-4 h-4" /> },
    { id: 'matrix', label: 'LED Matrix', icon: <Grid3X3 className="w-4 h-4" /> },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#050508] flex flex-col justify-between overflow-hidden select-none animate-fade-in">
      
      {/* Background Stage Image (if customized via AI Art Studio) */}
      {backdropUrl && (
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30 pointer-events-none mix-blend-screen scale-105 transition-all duration-700"
          style={{ backgroundImage: `url(${backdropUrl})` }}
        />
      )}

      {/* Top Floating Stage Bar */}
      <div className="relative z-20 flex items-center justify-between p-4 sm:p-6 bg-gradient-to-b from-black/90 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          <h2 className="text-lg sm:text-2xl font-black font-dj text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-500 uppercase tracking-widest">
            DJ SUNNY MUSIC • LIVE STAGE SHOW
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAIStudio}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/80 hover:bg-purple-600 text-white text-xs font-bold font-dj uppercase shadow-[0_0_15px_#b026ff] transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">AI STAGE BACKDROP</span>
          </button>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-zinc-900/90 border border-zinc-700 hover:border-cyan-400 text-zinc-300 hover:text-white transition-all shadow-[0_0_15px_rgba(0,0,0,0.8)]"
            title="Exit Full Stage Mode"
          >
            <Minimize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Giant Central Visualizer Canvas */}
      <div className="relative flex-1 w-full h-full flex items-center justify-center p-4 sm:p-8">
        <LiveWaveformCanvas
          mode={visualizerMode}
          isPlaying={isPlaying}
          className="w-full h-full border-none shadow-[0_0_50px_rgba(0,240,255,0.15)]"
        />
      </div>

      {/* Bottom Floating HUD */}
      <div className="relative z-20 p-4 sm:p-6 bg-gradient-to-t from-black/95 via-black/80 to-transparent flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Track Title */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.5)]">
            <img
              src={currentTrack.coverUrl}
              alt={currentTrack.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white font-dj tracking-wide">
              {currentTrack.title}
            </h3>
            <p className="text-xs text-cyan-300 font-medium">
              {currentTrack.artist} • <span className="text-purple-300">{currentTrack.bpm} BPM</span>
            </p>
          </div>
        </div>

        {/* Transport Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={onPrev}
            className="p-3 rounded-full bg-zinc-800 text-zinc-300 hover:text-white active:scale-95 transition-all"
          >
            <SkipBack className="w-5 h-5" />
          </button>

          <button
            onClick={onPlayPause}
            className="p-5 rounded-full bg-gradient-to-r from-cyan-400 to-purple-600 text-black shadow-[0_0_30px_#00f0ff] hover:scale-105 active:scale-95 transition-all"
          >
            {isPlaying ? <Pause className="w-7 h-7 fill-black" /> : <Play className="w-7 h-7 fill-black ml-0.5" />}
          </button>

          <button
            onClick={onNext}
            className="p-3 rounded-full bg-zinc-800 text-zinc-300 hover:text-white active:scale-95 transition-all"
          >
            <SkipForward className="w-5 h-5" />
          </button>
        </div>

        {/* Visualizer Mode Switcher */}
        <div className="flex items-center gap-1.5 flex-wrap justify-center sm:justify-end">
          {modes.map((m) => (
            <button
              key={m.id}
              onClick={() => onVisualizerModeChange(m.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold font-dj uppercase transition-all ${
                visualizerMode === m.id
                  ? 'bg-cyan-500 text-black shadow-[0_0_15px_#00f0ff]'
                  : 'bg-zinc-900/90 text-zinc-400 hover:text-white'
              }`}
            >
              {m.icon}
              <span className="hidden sm:inline">{m.label}</span>
            </button>
          ))}
        </div>

      </div>

    </div>
  );
};
