import React, { useState } from "react";
import { ContactInfo } from "../types";
import { X, Save, Phone, MessageCircle, Building2, User, Clock, Check } from "lucide-react";

interface ContactModalProps {
  contact: ContactInfo;
  isOpen: boolean;
  onClose: () => void;
  onSaveContact: (newContact: ContactInfo) => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  contact,
  isOpen,
  onClose,
  onSaveContact,
}) => {
  const [formData, setFormData] = useState<ContactInfo>({ ...contact });
  const [isEditing, setIsEditing] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveContact(formData);
    setSavedSuccess(true);
    setIsEditing(false);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const cleanPhone = contact.phone.replace(/[^0-9+]/g, "");
  const cleanWhatsapp = contact.whatsapp.replace(/[^0-9]/g, "");

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
        {/* Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/30 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Building2 className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Contractor Contact & Enquiry
              </h3>
              <p className="text-[11px] text-slate-400">
                Site visits, measurement & work bookings
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {!isEditing ? (
            <div className="space-y-4">
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2.5">
                <span className="text-[10px] uppercase tracking-wider font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">
                  For Enquiry & Work Contact
                </span>
                <h4 className="font-extrabold text-base text-slate-900">
                  {contact.businessName}
                </h4>
                <div className="text-xl font-black text-slate-900 font-mono flex items-center gap-2">
                  <span>📞 {contact.phone}</span>
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-600" />
                  <span>{contact.personName}</span>
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span>{contact.availableHours}</span>
                </div>
              </div>

              {/* Direct Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <a
                  href={`tel:${cleanPhone}`}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-3 rounded-xl flex items-center justify-center gap-2 text-xs shadow transition-all active:scale-95 text-center uppercase tracking-wide"
                >
                  <Phone className="w-4 h-4 fill-white shrink-0" />
                  <span>CALL NOW</span>
                </a>

                <a
                  href={`https://wa.me/${cleanWhatsapp}?text=${encodeURIComponent(
                    "Hello! I am contacting from the Ceiling Calculation App for an interior estimate and site booking."
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3.5 px-3 rounded-xl flex items-center justify-center gap-2 text-xs shadow transition-all active:scale-95 text-center uppercase tracking-wide"
                >
                  <MessageCircle className="w-4 h-4 fill-white shrink-0" />
                  <span>WHATSAPP</span>
                </a>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-xs">
                <span className="text-slate-400">Need to change contractor info?</span>
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="font-bold text-indigo-600 hover:text-indigo-700 underline"
                >
                  Edit Details
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Business / Company Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.businessName}
                  onChange={(e) =>
                    setFormData({ ...formData, businessName: e.target.value })
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Contact Person Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.personName}
                  onChange={(e) =>
                    setFormData({ ...formData, personName: e.target.value })
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    WhatsApp Number
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.whatsapp}
                    onChange={(e) =>
                      setFormData({ ...formData, whatsapp: e.target.value })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Working Hours / Days
                </label>
                <input
                  type="text"
                  value={formData.availableHours}
                  onChange={(e) =>
                    setFormData({ ...formData, availableHours: e.target.value })
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3.5 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-md shadow-indigo-600/20"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Contact</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
