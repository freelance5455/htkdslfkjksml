import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  CheckCircle2,
  User,
  Users,
  Smartphone,
  CreditCard,
  Lock,
  ArrowRight,
  ArrowLeft,
  AlertCircle,
  Loader2,
  Sparkles,
  ExternalLink,
  Mail,
  Send,
  ShieldCheck,
} from 'lucide-react';
import { PaymentProvider, TicketType, PurchasedTicket, EventTicketTier } from '../types';
import { mpesaService } from '../services/mpesaService';
import { emailTicketService } from '../services/emailTicketService';
import { isValidPhoneNumber, formatPhoneForDisplay } from '../utils/phoneUtils';
import { triggerHaptic } from '../utils/haptics';
import { QRCodeSVG } from 'qrcode.react';

export const TicketPurchaseModal: React.FC = () => {
  const {
    selectedEventForPurchase,
    closePurchaseModal,
    purchaseTickets,
    user,
    formatKsh,
    showToast,
    setActiveVirtualTicket,
  } = useApp();

  const event = selectedEventForPurchase;
  if (!event) return null;

  // Step state: 1 = Tier Selection, 2 = Payment & Contact, 3 = Instant Pass Generated
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // Dynamic Tiers from Event or defaults with customized capacities
  const basePrice = event.personalPrice || event.price || 2500;
  const tiers: EventTicketTier[] = event.tiers && event.tiers.length > 0 ? event.tiers : [
    {
      id: 'early_bird',
      name: 'Early Bird Pass',
      price: Math.round(basePrice * 0.85),
      capacity: 200,
      description: 'Exclusive early admission with expedited gate entry',
      perks: 'Early access, priority lane',
    },
    {
      id: 'regular',
      name: 'Regular Admission',
      price: basePrice,
      capacity: 800,
      description: 'Standard festival entry to all main stages and grounds',
      perks: 'General admission, all stages',
    },
    {
      id: 'vip',
      name: 'VIP Raised Lounge',
      price: Math.round(basePrice * 1.8),
      capacity: 150,
      description: 'Priority lounge access, private bar, and elevated view',
      perks: 'VIP lounge, express bar',
    },
    {
      id: 'vvip',
      name: 'VVIP Diamond Experience',
      price: Math.round(basePrice * 3.5),
      capacity: 50,
      description: 'All-inclusive backstage hospitality & private lounge',
      perks: 'All-access backstage & private lounge',
    },
  ];

  const [selectedTierId, setSelectedTierId] = useState<string>(tiers[0]?.id || 'regular');
  const [ticketType, setTicketType] = useState<TicketType>('personal');
  const [selectedGroupTierId, setSelectedGroupTierId] = useState<string>(() => {
    return event.groupTiers && event.groupTiers.length > 0 ? event.groupTiers[0].id : '';
  });

  const [quantity, setQuantity] = useState<number>(1);
  const [paymentChoice, setPaymentChoice] = useState<PaymentProvider>('mpesa');
  const [mpesaNumber, setMpesaNumber] = useState<string>(
    user?.mpesaNumber || user?.phone || '0712 345 678'
  );
  const [buyerEmail, setBuyerEmail] = useState<string>(
    user?.email || 'attendee@eventra.live'
  );
  const [buyerName, setBuyerName] = useState<string>(
    user?.name || 'Festival Guest'
  );

  // STK Push awaiting prompt state & PIN
  const [isAwaitingStk, setIsAwaitingStk] = useState<boolean>(false);
  const [isQueryingStatus, setIsQueryingStatus] = useState<boolean>(false);
  const [stkPin, setStkPin] = useState<string>('');
  const [checkoutRequestId, setCheckoutRequestId] = useState<string>('');
  const [issuedPass, setIssuedPass] = useState<PurchasedTicket | null>(null);
  const [phoneError, setPhoneError] = useState<string | null>(null);

  const selectedTier = tiers.find((t) => t.id === selectedTierId) || tiers[0];
  const activeGroupTier = (event.groupTiers && event.groupTiers.find((g) => g.id === selectedGroupTierId)) || {
    id: 'grp_default',
    name: 'Squad Group Pass',
    size: 4,
    price: Math.round(basePrice * 4 * 0.85),
    perks: '4 wristbands, 15% group discount, priority turnstile lane',
  };

  const unitPrice = ticketType === 'personal' ? selectedTier.price : activeGroupTier.price;
  const total = ticketType === 'personal' ? unitPrice * quantity : activeGroupTier.price;

  const handleProceedToPayment = () => {
    triggerHaptic('medium');
    setCurrentStep(2);
  };

  const handleStartPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError(null);

    if (paymentChoice === 'mpesa') {
      if (!isValidPhoneNumber(mpesaNumber)) {
        triggerHaptic('error');
        setPhoneError('Please enter a valid Kenyan phone number (e.g. 0712 345 678 or +254 712 345 678)');
        return;
      }

      triggerHaptic('medium');
      setIsAwaitingStk(true);
      setIsQueryingStatus(false);
      setStkPin('');

      const res = await mpesaService.initiateStkPush({
        phone: mpesaNumber,
        amount: total,
        accountReference: 'EventraPass',
        transactionDesc: event.title.slice(0, 15),
        orderId: `ORD-${Date.now()}`,
      });

      if (res.checkoutRequestId) {
        setCheckoutRequestId(res.checkoutRequestId);
      }
    } else {
      // Direct Instant PayPal / Card flow
      triggerHaptic('medium');
      setIsQueryingStatus(true);
      try {
        const pass = await purchaseTickets(
          event.id,
          quantity,
          'paypal',
          buyerEmail,
          ticketType,
          ticketType === 'group' ? activeGroupTier.id : undefined,
          {
            tierId: selectedTier.id,
            tierName: selectedTier.name,
            tierPrice: selectedTier.price,
            buyerName,
            buyerEmail,
          }
        );
        setIsQueryingStatus(false);
        if (pass) {
          triggerHaptic('success');
          setIssuedPass(pass);
          setCurrentStep(3);
        }
      } catch (err) {
        triggerHaptic('error');
        setIsQueryingStatus(false);
        showToast('Booking failed. Please try again.');
      }
    }
  };

  const handleConfirmMpesaPayment = async () => {
    triggerHaptic('medium');
    setIsQueryingStatus(true);
    // Simulate real Daraja PIN verification handshake
    await new Promise((resolve) => setTimeout(resolve, 1400));
    const queryRes = await mpesaService.queryPaymentStatus(checkoutRequestId || `CO_${Date.now()}`);

    if (queryRes.status === 'COMPLETED' || queryRes.success) {
      try {
        const pass = await purchaseTickets(
          event.id,
          quantity,
          'mpesa',
          mpesaNumber,
          ticketType,
          ticketType === 'group' ? activeGroupTier.id : undefined,
          {
            tierId: selectedTier.id,
            tierName: selectedTier.name,
            tierPrice: selectedTier.price,
            buyerName,
            buyerEmail,
          }
        );

        setIsQueryingStatus(false);
        setIsAwaitingStk(false);

        if (pass) {
          triggerHaptic('success');
          setIssuedPass(pass);
          setCurrentStep(3);
        }
      } catch (err) {
        triggerHaptic('error');
        setIsQueryingStatus(false);
        showToast('Could not finalize booking. Please check connection.');
      }
    } else {
      triggerHaptic('warning');
      setIsQueryingStatus(false);
      showToast('Payment verification pending. Please verify your PIN on your phone.');
    }
  };

  const handleOpenFullPass = () => {
    triggerHaptic('light');
    if (issuedPass) {
      closePurchaseModal();
      setActiveVirtualTicket(issuedPass);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
        onClick={closePurchaseModal}
      >
        <div
          className="relative w-full max-w-xl my-6 bg-[#111317] rounded-[32px] shadow-2xl border border-[#1f2229] overflow-hidden text-[#f4f4f6] transition-all"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header with Step Tracker */}
          <div className="p-6 pb-4 border-b border-[#1f2229] bg-[#16181f]/80">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase tracking-wider border border-emerald-500/20">
                <Sparkles className="w-3 h-3" />
                <span>Instant Digital Pass Booking</span>
              </div>

              <button
                onClick={closePurchaseModal}
                className="w-8 h-8 rounded-full hover:bg-[#1f2229] flex items-center justify-center text-[#9496a1] hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-2 flex items-baseline justify-between">
              <div>
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  {event.title}
                </h2>
                <p className="text-xs text-[#9496a1] mt-0.5">
                  {event.venue} · {event.city} · {event.date}
                </p>
              </div>

              {/* Step indicator */}
              <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                  currentStep === 1
                    ? 'bg-emerald-500 text-white font-bold'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}>
                  1
                </span>
                <span className="w-4 h-0.5 bg-[#262934]" />
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                  currentStep === 2
                    ? 'bg-emerald-500 text-white font-bold'
                    : currentStep > 2
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-[#1f2229] text-[#646875]'
                }`}>
                  2
                </span>
                <span className="w-4 h-0.5 bg-[#262934]" />
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                  currentStep === 3
                    ? 'bg-emerald-500 text-white font-bold'
                    : 'bg-[#1f2229] text-[#646875]'
                }`}>
                  3
                </span>
              </div>
            </div>
          </div>

          {/* STEP 1: DYNAMIC TIER SELECTION & SEAT SELECTOR */}
          {currentStep === 1 && (
            <div className="p-6 space-y-5 animate-in fade-in duration-150">
              {/* Category Switcher: Individual vs Group */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-[#16181f] rounded-2xl border border-[#232733]">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('selection');
                    setTicketType('personal');
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    ticketType === 'personal'
                      ? 'bg-[#252834] text-white shadow-xs border border-[#353a4b]'
                      : 'text-[#9496a1] hover:text-white'
                  }`}
                >
                  <User className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Standard / Individual Tiers</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('selection');
                    setTicketType('group');
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    ticketType === 'group'
                      ? 'bg-[#252834] text-white shadow-xs border border-[#353a4b]'
                      : 'text-[#9496a1] hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Custom Group Pass</span>
                </button>
              </div>

              {/* Dynamic Tier Cards (Personal) */}
              {ticketType === 'personal' ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#9496a1] block">
                      Choose Admission Tier
                    </label>
                    <span className="text-[10px] text-[#646875] font-semibold">
                      {tiers.length} tier option{tiers.length > 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="space-y-2.5">
                    {tiers.map((tier) => {
                      const isSelected = selectedTierId === tier.id;
                      return (
                        <div
                          key={tier.id}
                          onClick={() => {
                            triggerHaptic('selection');
                            setSelectedTierId(tier.id);
                          }}
                          className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                            isSelected
                              ? 'border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/30'
                              : 'border-[#232733] bg-[#16181f] hover:border-[#353a4b]'
                          }`}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold text-white">
                                {tier.name}
                              </span>
                              {tier.capacity && (
                                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-mono">
                                  {tier.capacity} passes
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#9496a1] truncate mt-0.5">
                              {tier.description || tier.perks || 'Admission ticket to this event'}
                            </p>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="text-sm font-black text-white block font-mono">
                              {formatKsh(tier.price)}
                            </span>
                            <span className="text-[10px] text-[#646875]">per pass</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* Custom Group Tiers */
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9496a1] block">
                    Choose Group Tier Package
                  </label>
                  <div className="space-y-2.5">
                    {(event.groupTiers && event.groupTiers.length > 0 ? event.groupTiers : [activeGroupTier]).map((gt) => {
                      const isSelected = selectedGroupTierId === gt.id;
                      return (
                        <div
                          key={gt.id}
                          onClick={() => {
                            triggerHaptic('selection');
                            setSelectedGroupTierId(gt.id);
                          }}
                          className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                            isSelected
                              ? 'border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/30'
                              : 'border-[#232733] bg-[#16181f] hover:border-[#353a4b]'
                          }`}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold text-white">
                                {gt.name}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                                {gt.size} Guests
                              </span>
                            </div>
                            <p className="text-[11px] text-[#9496a1] truncate mt-0.5">
                              {gt.perks || 'Group express access'}
                            </p>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="text-sm font-black text-white block font-mono">
                              {formatKsh(gt.price)}
                            </span>
                            <span className="text-[10px] text-[#646875]">Total bundle</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Quantity Selector for Personal Passes */}
              {ticketType === 'personal' && (
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#16181f] border border-[#232733]">
                  <div>
                    <span className="text-xs font-bold text-white block">Number of Guests</span>
                    <span className="text-[11px] text-[#646875]">Personal pass count</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setQuantity(Math.max(1, quantity - 1));
                      }}
                      className="w-8 h-8 rounded-full border border-[#262934] bg-[#1a1d26] text-white flex items-center justify-center font-bold text-sm hover:border-emerald-500 cursor-pointer active:scale-95"
                    >
                      -
                    </button>
                    <span className="font-mono text-sm font-bold text-white w-4 text-center">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setQuantity(Math.min(20, quantity + 1));
                      }}
                      className="w-8 h-8 rounded-full border border-[#262934] bg-[#1a1d26] text-white flex items-center justify-center font-bold text-sm hover:border-emerald-500 cursor-pointer active:scale-95"
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              {/* Bottom Next Bar */}
              <div className="pt-2 flex items-center justify-between border-t border-[#1f2229]">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#646875] block">
                    Subtotal
                  </span>
                  <span className="text-xl font-black text-white font-mono">
                    {formatKsh(total)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleProceedToPayment}
                  className="py-3 px-6 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md active:scale-95"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: PAYMENT METHOD & BUYER CONTACT */}
          {currentStep === 2 && (
            <form onSubmit={handleStartPayment} className="p-6 space-y-5 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('light');
                    setCurrentStep(1);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#9496a1] hover:text-white cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Tier Selection</span>
                </button>

                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                  {formatKsh(total)} Due
                </span>
              </div>

              {/* Direct Host Payout Notice */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-2xl flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div className="text-xs">
                  <span className="font-bold text-emerald-400 block">Direct Host M-Pesa Settlement</span>
                  <span className="text-[#9496a1] text-[11px]">
                    Your payment of <strong className="text-white font-mono">{formatKsh(total)}</strong> is credited directly to host <strong className="text-white">{event.hostName || event.organizer}</strong> (<span className="text-emerald-300 font-mono">{event.hostMpesa || '0712 345 678'}</span>).
                  </span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-wider text-[#9496a1] block">
                  Select Payment Method
                </label>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('selection');
                      setPaymentChoice('mpesa');
                    }}
                    className={`py-3 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                      paymentChoice === 'mpesa'
                        ? 'border-emerald-500 bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30'
                        : 'border-[#232733] bg-[#16181f] text-[#9496a1] hover:text-white'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span>Safaricom M-Pesa</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('selection');
                      setPaymentChoice('paypal');
                    }}
                    className={`py-3 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                      paymentChoice === 'paypal'
                        ? 'border-emerald-500 bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30'
                        : 'border-[#232733] bg-[#16181f] text-[#9496a1] hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span>PayPal / Apple Pay</span>
                  </button>
                </div>
              </div>

              {/* Form inputs with explicit high-contrast labels and spacious padding */}
              <div className="space-y-3.5">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#b8b9c2] block">
                    Passholder Full Name (Printed on Digital Pass)
                  </label>
                  <input
                    type="text"
                    value={buyerName}
                    onChange={(e) => setBuyerName(e.target.value)}
                    placeholder="Maya Lin"
                    className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#b8b9c2] block">
                    Passholder Email (Instant Voucher & Calendar Invite)
                  </label>
                  <input
                    type="email"
                    value={buyerEmail}
                    onChange={(e) => setBuyerEmail(e.target.value)}
                    placeholder="maya.lin@gmail.com"
                    className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none transition-all"
                    required
                  />
                </div>

                {paymentChoice === 'mpesa' && (
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#b8b9c2] block">
                      M-Pesa Phone Number (Receives STK PIN Prompt)
                    </label>
                    <input
                      type="tel"
                      value={mpesaNumber}
                      onChange={(e) => setMpesaNumber(e.target.value)}
                      placeholder="0712 345 678"
                      className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] font-mono font-medium text-white placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none transition-all"
                      required
                    />
                    {phoneError && (
                      <div className="flex items-center gap-1.5 text-xs text-rose-400 font-medium">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{phoneError}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Order Breakdown Box */}
              <div className="p-4 rounded-2xl bg-[#16181f] border border-[#232733] space-y-2 text-xs">
                <div className="flex justify-between text-[#9496a1]">
                  <span>Pass Tier:</span>
                  <span className="font-semibold text-white">
                    {ticketType === 'personal' ? selectedTier.name : activeGroupTier.name} (x{quantity})
                  </span>
                </div>
                <div className="flex justify-between text-[#9496a1]">
                  <span>Ticket Delivery:</span>
                  <span className="font-semibold text-emerald-400">Automated Instant Email & SMS</span>
                </div>
                <div className="flex justify-between text-[#9496a1]">
                  <span>Booking Fees:</span>
                  <span className="font-semibold text-emerald-400">KSh 0 (Zero-Fee Guarantee)</span>
                </div>
                <div className="pt-2 border-t border-[#232733] flex justify-between font-bold text-sm text-white">
                  <span>Total Due:</span>
                  <span className="text-emerald-400">{formatKsh(total)}</span>
                </div>
              </div>

              {/* Checkout Trigger */}
              <button
                type="submit"
                disabled={isQueryingStatus}
                className="w-full h-12 rounded-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98"
              >
                {isQueryingStatus ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Secure Payment...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Pay {formatKsh(total)} & Issue Instant Pass</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* STEP 3: INSTANT DIGITAL PASS GENERATION CONFIRMATION */}
          {currentStep === 3 && issuedPass && (
            <div className="p-6 space-y-5 text-center animate-in zoom-in-95 duration-200">
              <div className="w-14 h-14 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
              </div>

              <div className="space-y-1">
                <h3 className="text-xl font-extrabold text-white">
                  Digital Pass Generated!
                </h3>
                <p className="text-xs text-[#9496a1]">
                  Synchronized live to all your signed-in devices and emailed to your inbox.
                </p>
              </div>

              {/* Automated Email & Phone SMS Confirmation Banners */}
              <div className="space-y-2">
                <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-xs text-left flex items-start gap-3">
                  <Mail className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-emerald-400 block">Pass Voucher Dispatched to Email</span>
                    <span className="text-[11px] text-[#9496a1] block mt-0.5 truncate">
                      Sent to <strong className="text-white">{issuedPass.holderEmail || buyerEmail}</strong> · Host alerted
                    </span>
                  </div>
                </div>

                {/* Actual Phone SMS Receipt */}
                <div className="p-3.5 bg-[#16181f] border border-emerald-500/30 rounded-2xl text-xs text-left space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>{issuedPass.paymentMethod === 'mpesa' ? 'Safaricom M-Pesa SMS Sent to Phone' : 'Payment SMS Receipt Sent'}</span>
                    </div>
                    <span className="text-[10px] text-[#646875] font-mono">{issuedPass.holderPhone || mpesaNumber}</span>
                  </div>
                  <p className="font-mono text-[11px] text-[#c7cad4] bg-[#0d0e12] p-2.5 rounded-xl border border-[#232733] leading-relaxed select-all">
                    {issuedPass.mpesaSmsText || issuedPass.mpesaReceiptSms || `${issuedPass.transactionRef} Confirmed. KSh ${issuedPass.totalPaid.toLocaleString()} paid to ${event.title}. Code: ${issuedPass.ticketCode}`}
                  </p>
                  <div className="flex items-center justify-end pt-1">
                    <a
                      href={`sms:${(issuedPass.holderPhone || mpesaNumber).replace(/\s+/g, '')}?body=${encodeURIComponent(issuedPass.mpesaSmsText || '')}`}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300"
                    >
                      <span>Open SMS in Messages App</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Digital Pass Preview Card with QR */}
              <div className="max-w-xs mx-auto p-4 rounded-3xl bg-[#16181f] border border-[#232733] space-y-3 shadow-md">
                <div className="p-3 bg-white rounded-2xl shadow-xs border border-white inline-block">
                  <QRCodeSVG
                    value={`EVENTRA:PASS:${issuedPass.ticketCode}:${issuedPass.ticketId}`}
                    size={140}
                    level="H"
                  />
                </div>

                <div>
                  <span className="text-[10px] uppercase font-bold text-[#646875] block">
                    Distinct Pass Serial Code
                  </span>
                  <span className="font-mono text-base font-black text-emerald-400">
                    {issuedPass.ticketCode}
                  </span>
                </div>

                <div className="text-left text-xs bg-[#111317] p-2.5 rounded-xl border border-[#1f2229] space-y-1">
                  <div className="flex justify-between">
                    <span className="text-[#646875]">Tier:</span>
                    <span className="font-semibold text-white">
                      {issuedPass.groupTierName || (issuedPass.ticketType === 'group' ? 'Group Pass' : 'Individual Pass')} ({issuedPass.quantity}x)
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#646875]">Payment:</span>
                    <span className="font-semibold text-emerald-400">{issuedPass.paymentMethod.toUpperCase()} (Ref: {issuedPass.transactionRef})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#646875]">Order Ref:</span>
                    <span className="font-mono text-[10px] text-[#9496a1]">{issuedPass.orderNumber}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={handleOpenFullPass}
                  className="w-full py-3 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm active:scale-98"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Digital Passbook</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => emailTicketService.openMailClientVoucher(issuedPass, event)}
                    className="py-2.5 px-3 rounded-full border border-[#232733] bg-[#16181f] text-xs font-semibold text-[#f4f4f6] hover:bg-[#1f2229] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5 text-emerald-400" />
                    <span>View / Send Email</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => emailTicketService.downloadCalendarInvite(issuedPass, event)}
                    className="py-2.5 px-3 rounded-full border border-[#232733] bg-[#16181f] text-xs font-semibold text-[#f4f4f6] hover:bg-[#1f2229] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Apple / Google .ics</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={closePurchaseModal}
                  className="w-full py-2.5 rounded-full border border-[#232733] text-xs font-semibold text-[#9496a1] hover:text-white hover:bg-[#16181f] transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Realistic Safaricom STK Push Prompt Modal (Simulated Live Daraja Interface) */}
      {isAwaitingStk && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-[#111317] border border-[#1f2229] rounded-[32px] p-6 text-[#f4f4f6] shadow-2xl space-y-5">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                <Smartphone className="w-6 h-6 animate-pulse" />
              </div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
                <span>Safaricom Lipa Na M-Pesa Online</span>
              </div>
              <h3 className="text-base font-bold tracking-tight text-white">
                STK Push Dispatched to Phone
              </h3>
              <p className="text-xs text-[#9496a1] leading-relaxed">
                Prompt sent to <strong className="text-white font-mono">{formatPhoneForDisplay(mpesaNumber)}</strong>. Check your handset screen.
              </p>
            </div>

            {/* Simulated Safaricom SIM Prompt Box */}
            <div className="p-4 rounded-2xl bg-[#090a0d] border border-emerald-500/30 space-y-2 text-xs">
              <div className="text-[11px] font-mono font-bold text-emerald-400 text-center pb-1 border-b border-[#1f2229]">
                Safaricom M-Pesa (Shortcode 174379)
              </div>
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Direct Host Payee:</span>
                <span className="text-white font-medium truncate max-w-[170px]">{event.hostName || event.organizer}</span>
              </div>
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Host M-Pesa:</span>
                <span className="text-emerald-400 font-mono">{event.hostMpesa || '0712 345 678'}</span>
              </div>
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Amount:</span>
                <strong className="text-emerald-400 font-mono text-sm">{formatKsh(total)}</strong>
              </div>
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Pass Tier:</span>
                <span className="text-white font-medium">{ticketType === 'personal' ? selectedTier.name : activeGroupTier.name} (x{quantity})</span>
              </div>

              {/* PIN simulation input */}
              <div className="pt-2">
                <label className="text-[10px] text-[#646875] uppercase font-bold block mb-1">
                  Enter 4-Digit M-Pesa PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={stkPin}
                  onChange={(e) => {
                    triggerHaptic('light');
                    setStkPin(e.target.value.replace(/\D/g, ''));
                  }}
                  placeholder="••••"
                  className="w-full h-11 text-center font-mono text-lg tracking-widest bg-[#16181f] border border-[#262934] focus:border-emerald-500 rounded-xl text-white focus:outline-none"
                />
              </div>
            </div>

            <p className="text-[11px] text-[#9496a1] text-center leading-normal">
              Enter your PIN above or directly authorize on your handset, then tap below to instantly confirm.
            </p>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleConfirmMpesaPayment}
                disabled={isQueryingStatus}
                className="w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold text-xs transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 active:scale-98"
              >
                {isQueryingStatus ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Verifying with Safaricom Daraja...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm M-Pesa PIN & Issue Ticket</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setIsAwaitingStk(false)}
                className="w-full py-2.5 rounded-2xl border border-[#232733] hover:bg-[#16181f] text-[#9496a1] text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel or Change Number
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
