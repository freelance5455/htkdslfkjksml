import { Bell, CheckCircle2, Plane, Sparkles, FileText, ShieldAlert } from 'lucide-react';
import { NotificationItem, Language } from '../../types';
import { translations } from '../../i18n/translations';

interface NotificationsScreenProps {
  notifications: NotificationItem[];
  language: Language;
  onSelectAction?: (route: string) => void;
}

export function NotificationsScreen({ notifications, language, onSelectAction }: NotificationsScreenProps) {
  const t = translations[language];

  const getIconForCategory = (cat: NotificationItem['category']) => {
    switch (cat) {
      case 'flight_alert':
        return <Plane className="w-4 h-4 text-cyan-400" />;
      case 'booking':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'document':
        return <FileText className="w-4 h-4 text-blue-400" />;
      case 'promo':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      default:
        return <Bell className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white">
            {language === 'ar' ? 'مركز الإشعارات والتنبيهات' : 'Notification Center'}
          </h1>
          <p className="text-xs text-cyan-400 font-mono mt-0.5">
            Tourism By Taki Live Broadcasts
          </p>
        </div>
        <span className="text-xs font-mono text-cyan-400 bg-cyan-950/70 border border-cyan-800/80 px-2.5 py-0.5 rounded-full">
          {notifications.length} {language === 'ar' ? 'تنبيهات' : 'alerts'}
        </span>
      </div>

      {/* Notifications List */}
      <div className="space-y-2.5">
        {notifications.map(item => (
          <div
            key={item.id}
            onClick={() => item.actionRoute && onSelectAction && onSelectAction(item.actionRoute)}
            className={`glass-panel p-4 rounded-3xl border transition-all text-white flex items-start gap-3 cursor-pointer ${
              !item.isRead ? 'border-cyan-400/40 bg-[#0a1432]' : 'border-slate-800'
            }`}
          >
            <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 mt-0.5">
              {getIconForCategory(item.category)}
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white">{item.title}</h3>
                <span className="text-[10px] text-slate-400 font-mono">{item.timestamp}</span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{item.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
