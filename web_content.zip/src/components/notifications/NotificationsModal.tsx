import React, { useState, useEffect } from 'react';
import { NotificationItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import {
  Bell, X, Heart, MessageCircle, UserPlus,
  Check, CheckCheck, RefreshCw, Phone
} from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTo: (targetType: string, targetId?: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onNavigateTo
}) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadNotifications = async () => {
    if (!currentUser) return;
    try {
      setIsLoading(true);
      const res = await api.getNotifications(currentUser.id);
      setNotifications(res.notifications || []);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadNotifications();
    }
  }, [isOpen, currentUser?.id]);

  if (!isOpen) return null;

  const handleMarkAllRead = async () => {
    if (!currentUser) return;
    try {
      await api.markNotificationsAsRead(currentUser.id);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (err) {
      console.error(err);
    }
  };

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500/20" />;
      case 'comment':
        return <MessageCircle className="w-3.5 h-3.5 text-blue-400" />;
      case 'friend_request':
      case 'friend_accepted':
      case 'follow':
        return <UserPlus className="w-3.5 h-3.5 text-emerald-400" />;
      case 'call':
        return <Phone className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <Bell className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 max-h-[85vh] flex flex-col animate-in zoom-in-95">

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-white font-display">Notificações</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllRead}
              className="text-xs text-amber-400 hover:underline font-medium flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Marcar lidas</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 my-2">
          {isLoading ? (
            <div className="p-8 text-center text-xs text-slate-500">A carregar notificações...</div>
          ) : notifications.length === 0 ? (
            <div className="p-10 text-center text-slate-400 text-xs">
              <Bell className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="font-semibold text-white">Sem notificações no momento</p>
              <p className="text-slate-500 mt-1">Interaja com a comunidade angolana para receber novidades.</p>
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                className={`p-3.5 flex items-start gap-3 rounded-xl transition-colors ${notif.read ? 'opacity-80' : 'bg-slate-950/40 border-l-2 border-amber-400'}`}
              >
                <div className="relative shrink-0">
                  <img
                    src={notif.fromUser?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
                    alt="Remetente"
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-700"
                  />
                  <span className="absolute -bottom-1 -right-1 p-1 bg-slate-950 rounded-full border border-slate-800 shadow">
                    {getIcon(notif.type)}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-200 leading-snug">
                    <strong className="text-white font-semibold">{notif.fromUser?.name || 'Alguém'}</strong>{' '}
                    {notif.text}
                  </p>
                  <span className="text-[10px] text-slate-500 mt-1 block font-mono">
                    {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
