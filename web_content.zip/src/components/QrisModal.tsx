import React, { useState } from 'react';
import {
  QrCode,
  ScanLine,
  X,
  Store,
  Wallet,
  CheckCircle2,
  Share2,
  Download,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  UtensilsCrossed,
  BookOpen,
  Coins,
  Shirt,
  CupSoda,
  Printer,
  Camera,
} from 'lucide-react';
import { QRIS_MERCHANTS } from '../data/mockData';
import { QrisMerchantPreset, StudentProfile, Transaction } from '../types';
import { formatNumber, formatRupiah, generateRefCode, getCurrentWibTime } from '../utils/formatters';

interface QrisModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentProfile: StudentProfile;
  walletBalance: number;
  onRequestPin: (amount: number, onAuthorize: () => void) => void;
  onSuccessPayment: (transaction: Transaction) => void;
  onSuccessReceive: (transaction: Transaction) => void;
}

export const QrisModal: React.FC<QrisModalProps> = ({
  isOpen,
  onClose,
  studentProfile,
  walletBalance,
  onRequestPin,
  onSuccessPayment,
  onSuccessReceive,
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'my_qris'>('scan');

  // Scanner state
  const [selectedMerchant, setSelectedMerchant] = useState<QrisMerchantPreset | null>(null);
  const [customMerchantName, setCustomMerchantName] = useState<string>('');
  const [paymentAmount, setPaymentAmount] = useState<number>(15000);
  const [paymentNote, setPaymentNote] = useState<string>('');
  const [scanStage, setScanStage] = useState<'scanning' | 'confirm'>('scanning');
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Receive state
  const [receiveAmount, setReceiveAmount] = useState<number>(50000);
  const [customReceiveInput, setCustomReceiveInput] = useState<string>('50000');
  const [senderName, setSenderName] = useState<string>('Ibu / Ayah');

  if (!isOpen) return null;

  const handleSelectPresetMerchant = (merchant: QrisMerchantPreset) => {
    setSelectedMerchant(merchant);
    setCustomMerchantName(merchant.name);
    setPaymentAmount(merchant.defaultAmount);
    setPaymentNote(`Bayar di ${merchant.name}`);
    setScanStage('confirm');
    setErrorMessage('');
  };

  const handleSimulateCustomScan = () => {
    if (!customMerchantName.trim()) {
      setCustomMerchantName('Kantin Pujasera Siswa');
    }
    setSelectedMerchant(null);
    setScanStage('confirm');
    setErrorMessage('');
  };

  const handleExecutePayment = () => {
    if (paymentAmount <= 0) {
      setErrorMessage('Nominal pembayaran harus lebih dari Rp 0');
      return;
    }

    if (walletBalance < paymentAmount) {
      setErrorMessage(`Saldo Dompet Saku tidak cukup (Saldo: ${formatRupiah(walletBalance)}). Silakan Top Up terlebih dahulu.`);
      return;
    }

    // Authorize with PIN
    onRequestPin(paymentAmount, () => {
      const merchantName = selectedMerchant ? selectedMerchant.name : (customMerchantName || 'Merchant QRIS Sekolah');
      const newTx: Transaction = {
        id: `TXN-${Date.now().toString().slice(-7)}`,
        type: 'qris_payment',
        title: `QRIS ${merchantName}`,
        category: selectedMerchant ? 'canteen' : 'other',
        amount: paymentAmount,
        sourceAccount: 'Dompet Saku',
        paymentMethodName: 'QRIS SakuSiswa',
        timestamp: getCurrentWibTime(),
        status: 'success',
        referenceCode: generateRefCode('QRIS-PAY'),
        destination: 'wallet',
        merchantName: merchantName,
        note: paymentNote.trim() || `Pembayaran QRIS di ${merchantName}`,
      };

      onSuccessPayment(newTx);
      onClose();
    });
  };

  const handleSimulateReceiveMoney = () => {
    if (receiveAmount <= 0) return;

    const newTx: Transaction = {
      id: `TXN-${Date.now().toString().slice(-7)}`,
      type: 'qris_receive',
      title: `Terima QRIS dari ${senderName}`,
      category: 'transfer',
      amount: receiveAmount,
      sourceAccount: `${senderName} (QRIS Pay)`,
      paymentMethodName: 'QRIS Terima',
      timestamp: getCurrentWibTime(),
      status: 'success',
      referenceCode: generateRefCode('QRIS-RCV'),
      destination: 'wallet',
      note: `Terima dana QRIS dari ${senderName}`,
    };

    onSuccessReceive(newTx);
    onClose();
  };

  const renderMerchantIcon = (iconName: string) => {
    switch (iconName) {
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5 text-amber-600" />;
      case 'BookOpen':
        return <BookOpen className="w-5 h-5 text-indigo-600" />;
      case 'Coins':
        return <Coins className="w-5 h-5 text-emerald-600" />;
      case 'Shirt':
        return <Shirt className="w-5 h-5 text-sky-600" />;
      case 'CupSoda':
        return <CupSoda className="w-5 h-5 text-rose-600" />;
      case 'Printer':
        return <Printer className="w-5 h-5 text-purple-600" />;
      default:
        return <Store className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header with Navigation Tabs */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 px-6 pt-6 pb-4 text-white">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <QrCode className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-bold">QRIS Nasional Indonesia</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Segmented Control */}
          <div className="flex items-center gap-1 p-1 bg-white/15 backdrop-blur-md rounded-2xl">
            <button
              type="button"
              onClick={() => {
                setActiveTab('scan');
                setScanStage('scanning');
                setErrorMessage('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'scan' ? 'bg-white text-rose-600 shadow-sm' : 'text-white/90 hover:text-white'
              }`}
            >
              <ScanLine className="w-4 h-4" />
              <span>Pindai QRIS (Bayar)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('my_qris');
                setErrorMessage('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'my_qris' ? 'bg-white text-rose-600 shadow-sm' : 'text-white/90 hover:text-white'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>QRIS Saya (Terima Dana)</span>
            </button>
          </div>
        </div>

        {/* TAB 1: PINDAI QRIS (SCAN) */}
        {activeTab === 'scan' && (
          <div className="p-6 max-h-[75vh] overflow-y-auto space-y-5">
            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{errorMessage}</span>
              </div>
            )}

            {scanStage === 'scanning' ? (
              <div className="space-y-4">
                {/* Simulated Camera Viewport */}
                <div className="relative w-full h-56 bg-slate-950 rounded-2xl overflow-hidden flex flex-col items-center justify-center border-2 border-slate-800 shadow-inner">
                  {/* Subtle Grid / Camera simulation */}
                  <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />

                  {/* QR Aim Frame */}
                  <div className="relative w-44 h-44 border-2 border-rose-500/80 rounded-2xl flex items-center justify-center overflow-hidden">
                    {/* Laser Scanner animation */}
                    <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-rose-500 to-transparent shadow-lg shadow-rose-500/80 animate-bounce" />

                    <div className="text-center p-3">
                      <Camera className="w-8 h-8 text-rose-400/80 mx-auto mb-2 animate-pulse" />
                      <span className="text-[11px] font-medium text-slate-300 block">
                        Arahkan kamera ke QRIS
                      </span>
                    </div>

                    {/* Corner Reticles */}
                    <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-rose-400" />
                    <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-rose-400" />
                    <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-rose-400" />
                    <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-rose-400" />
                  </div>

                  <div className="absolute bottom-3 flex items-center gap-2 bg-slate-900/80 px-3 py-1 rounded-full text-[10px] text-slate-300">
                    <Sparkles className="w-3 h-3 text-rose-400" />
                    <span>Mendukung semua standar QRIS BI & FinTech</span>
                  </div>
                </div>

                {/* Saldo Dompet Info */}
                <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Wallet className="w-4 h-4 text-emerald-600" />
                    <span>Saldo Dompet Saku Anda:</span>
                  </div>
                  <span className="font-bold text-slate-900 font-mono">
                    {formatRupiah(walletBalance)}
                  </span>
                </div>

                {/* Preset Cepat Merchant Sekolah */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-800">
                      Pilih Merchant QRIS Sekolah
                    </label>
                    <span className="text-[11px] text-slate-500">Klik untuk bayar instan</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {QRIS_MERCHANTS.map((merchant) => (
                      <button
                        key={merchant.id}
                        type="button"
                        onClick={() => handleSelectPresetMerchant(merchant)}
                        className="p-3 bg-white border border-slate-200 hover:border-rose-400 hover:bg-rose-50/30 rounded-2xl text-left transition-all flex items-start gap-3 group shadow-xs"
                      >
                        <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                          {renderMerchantIcon(merchant.iconName)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-slate-900 truncate">
                            {merchant.name}
                          </p>
                          <p className="text-[10px] text-slate-500 truncate">{merchant.location}</p>
                          <p className="text-xs font-bold text-rose-600 font-mono mt-0.5">
                            {formatRupiah(merchant.defaultAmount)}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Atau scan merchant kustom */}
                <div className="pt-2">
                  <div className="flex items-center gap-2 mb-2">
                    <input
                      type="text"
                      value={customMerchantName}
                      onChange={(e) => setCustomMerchantName(e.target.value)}
                      placeholder="Atau ketik nama toko / merchant lain..."
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                    />
                    <button
                      type="button"
                      onClick={handleSimulateCustomScan}
                      className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors shrink-0"
                    >
                      Lanjut
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Confirmation Stage */
              <div className="space-y-4">
                <div className="text-center p-4 bg-rose-50/50 border border-rose-100 rounded-2xl">
                  <div className="w-12 h-12 mx-auto bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mb-2">
                    <Store className="w-6 h-6" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {selectedMerchant ? selectedMerchant.name : (customMerchantName || 'Merchant QRIS')}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    NMID: {selectedMerchant ? selectedMerchant.nmid : 'ID102938481920'}
                  </p>
                </div>

                {/* Input / Atur Nominal Bayar */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Nominal Pembayaran
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold text-sm">
                      Rp
                    </div>
                    <input
                      type="text"
                      value={formatNumber(paymentAmount)}
                      onChange={(e) => {
                        const val = Number(e.target.value.replace(/\D/g, ''));
                        setPaymentAmount(val);
                        setErrorMessage('');
                      }}
                      className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-lg font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                    />
                  </div>
                </div>

                {/* Catatan Pembayaran */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Catatan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={paymentNote}
                    onChange={(e) => setPaymentNote(e.target.value)}
                    placeholder="Contoh: Beli Makan Siang & Es Teh"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                  />
                </div>

                {/* Saldo Warning if insufficient */}
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex items-center justify-between">
                  <span className="text-slate-600">Sisa Saldo Setelah Bayar:</span>
                  <span
                    className={`font-mono font-bold ${
                      walletBalance - paymentAmount < 0 ? 'text-rose-600' : 'text-slate-900'
                    }`}
                  >
                    {formatRupiah(walletBalance - paymentAmount)}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setScanStage('scanning')}
                    className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
                  >
                    Kembali Pindai
                  </button>

                  <button
                    type="button"
                    onClick={handleExecutePayment}
                    className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white text-xs font-bold rounded-xl shadow-md shadow-rose-600/20 transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>Konfirmasi PIN & Bayar</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: QRIS SAYA (RECEIVE MONEY) */}
        {activeTab === 'my_qris' && (
          <div className="p-6 max-h-[75vh] overflow-y-auto space-y-5">
            {/* Indonesian QRIS Style Card */}
            <div className="bg-white border-2 border-slate-900 rounded-2xl p-4 shadow-lg text-center max-w-[320px] mx-auto relative overflow-hidden">
              {/* QRIS Header Flag */}
              <div className="flex items-center justify-between border-b-2 border-slate-900 pb-2 mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="bg-red-600 text-white font-extrabold text-[11px] px-1.5 py-0.5 rounded-xs tracking-wider">
                    QRIS
                  </div>
                  <span className="text-[10px] font-bold text-slate-800">
                    Pembayaran Digital
                  </span>
                </div>
                <span className="text-[9px] font-mono text-slate-500">ASPI / BI</span>
              </div>

              {/* Merchant / Student Info */}
              <p className="text-sm font-extrabold text-slate-900 truncate">
                {studentProfile.name}
              </p>
              <p className="text-[10px] text-slate-500 font-mono mb-2">
                NMID: ID2026SAKUSISWA{studentProfile.nisn.slice(-4) || '9901'}
              </p>

              {/* QR Code SVG Display */}
              <div className="relative p-2 bg-white border border-slate-200 rounded-xl inline-block mb-3 shadow-inner">
                <svg
                  className="w-44 h-44 mx-auto"
                  viewBox="0 0 100 100"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {/* Outer Frame & Finder patterns */}
                  <rect width="100" height="100" fill="white" />
                  {/* Top-left pattern */}
                  <rect x="8" y="8" width="26" height="26" fill="black" rx="3" />
                  <rect x="12" y="12" width="18" height="18" fill="white" rx="2" />
                  <rect x="16" y="16" width="10" height="10" fill="black" rx="1" />
                  {/* Top-right pattern */}
                  <rect x="66" y="8" width="26" height="26" fill="black" rx="3" />
                  <rect x="70" y="12" width="18" height="18" fill="white" rx="2" />
                  <rect x="74" y="16" width="10" height="10" fill="black" rx="1" />
                  {/* Bottom-left pattern */}
                  <rect x="8" y="66" width="26" height="26" fill="black" rx="3" />
                  <rect x="12" y="70" width="18" height="18" fill="white" rx="2" />
                  <rect x="16" y="74" width="10" height="10" fill="black" rx="1" />
                  {/* QR Data Matrix Bits */}
                  <rect x="38" y="10" width="6" height="6" fill="black" />
                  <rect x="48" y="10" width="6" height="6" fill="black" />
                  <rect x="42" y="20" width="6" height="6" fill="black" />
                  <rect x="52" y="20" width="6" height="6" fill="black" />
                  <rect x="10" y="38" width="6" height="6" fill="black" />
                  <rect x="20" y="42" width="6" height="6" fill="black" />
                  <rect x="38" y="38" width="6" height="6" fill="black" />
                  <rect x="46" y="46" width="8" height="8" fill="#DC2626" rx="2" />
                  <rect x="58" y="38" width="6" height="6" fill="black" />
                  <rect x="70" y="42" width="6" height="6" fill="black" />
                  <rect x="84" y="38" width="6" height="6" fill="black" />
                  <rect x="38" y="58" width="6" height="6" fill="black" />
                  <rect x="50" y="58" width="6" height="6" fill="black" />
                  <rect x="62" y="54" width="6" height="6" fill="black" />
                  <rect x="74" y="62" width="6" height="6" fill="black" />
                  <rect x="86" y="70" width="6" height="6" fill="black" />
                  <rect x="70" y="84" width="6" height="6" fill="black" />
                  <rect x="84" y="84" width="6" height="6" fill="black" />
                  <rect x="40" y="74" width="6" height="6" fill="black" />
                  <rect x="52" y="80" width="6" height="6" fill="black" />
                </svg>
              </div>

              {/* Set Amount Display */}
              <div className="py-1 px-2 bg-slate-100 rounded-lg text-xs font-mono font-bold text-slate-800">
                Nominal: {formatRupiah(receiveAmount)}
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Dicetak oleh SakuSiswa • Terhubung GPN
              </p>
            </div>

            {/* Atur Nominal Terima */}
            <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <label className="block text-xs font-bold text-slate-800">
                Atur Jumlah Yang Ingin Diterima
              </label>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold text-xs">
                  Rp
                </div>
                <input
                  type="text"
                  value={formatNumber(receiveAmount)}
                  onChange={(e) => {
                    const raw = Number(e.target.value.replace(/\D/g, ''));
                    setReceiveAmount(raw);
                    setCustomReceiveInput(raw.toString());
                  }}
                  className="w-full pl-10 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex gap-2">
                {[20000, 50000, 100000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      setReceiveAmount(amt);
                      setCustomReceiveInput(amt.toString());
                    }}
                    className={`flex-1 py-1 text-[11px] font-mono font-semibold rounded-lg border transition-colors ${
                      receiveAmount === amt
                        ? 'bg-rose-50 border-rose-300 text-rose-700'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Rp {formatNumber(amt)}
                  </button>
                ))}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Nama Pengirim (Orang Tua / Teman)
                </label>
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="Contoh: Ibu / Ayah / Budi"
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            {/* Test Simulation Button: Parents sending money via QRIS */}
            <div className="pt-1">
              <button
                type="button"
                onClick={handleSimulateReceiveMoney}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-2xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Simulasikan Terima Transfer Rp {formatNumber(receiveAmount)}</span>
              </button>
              <p className="text-[10px] text-center text-slate-400 mt-1">
                Fitur demo: Klik untuk langsung menambahkan dana ke saldo dompet saku Anda.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
