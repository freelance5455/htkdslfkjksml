import React, { useState } from 'react';
import { 
  FolderDown, 
  X, 
  Trash2, 
  Upload, 
  Download, 
  Save, 
  Calendar, 
  Check, 
  Plus
} from 'lucide-react';
import { SavedGasProject, GasAppliance, GasParameters } from '../../types/gas';
import { saveProjectsList } from '../../utils/gasStorage';

interface SavedProjectsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedProjects: SavedGasProject[];
  onLoadProject: (project: SavedGasProject) => void;
  onSaveCurrentProject: () => void;
  onDeleteProject: (id: string) => void;
  currentTitle: string;
  currentClient: string;
}

export const SavedProjectsModal: React.FC<SavedProjectsModalProps> = ({
  isOpen,
  onClose,
  savedProjects,
  onLoadProject,
  onSaveCurrentProject,
  onDeleteProject,
  currentTitle,
  currentClient,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden my-4">
        
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center">
              <FolderDown className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">
                إدارة المشاريع المحفوظة
              </h2>
              <p className="text-[11px] text-slate-400">
                حفظ واسترجاع حسابات شبكات الغاز السابقة
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Project Quick Save Bar */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-semibold text-slate-200">
              حفظ المشروع الحالي: <span className="text-amber-400">{currentTitle || 'مشروع جديد'}</span>
            </div>
            <div className="text-[11px] text-slate-400">
              العميل: {currentClient || 'غير محدد'}
            </div>
          </div>

          <button
            onClick={onSaveCurrentProject}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors shadow-sm"
          >
            <Save className="w-3.5 h-3.5" />
            <span>حفظ نسخة جديدة الآن</span>
          </button>
        </div>

        {/* Saved List */}
        <div className="p-4 overflow-y-auto space-y-2.5 max-h-96">
          {savedProjects.map((project) => (
            <div
              key={project.id}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <span>{project.title}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 font-normal">
                    {project.buildingType === 'residential' ? 'منزلي' : 'تجاري'}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1 flex items-center gap-3 font-mono">
                  <span>العميل: {project.clientName || 'بدون اسم'}</span>
                  <span>التاريخ: {project.date}</span>
                  <span>({project.appliances?.length || 0} أجهزة)</span>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  onClick={() => {
                    onLoadProject(project);
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-amber-600 hover:text-white text-slate-200 text-xs font-semibold transition-colors"
                >
                  فتح المشروع
                </button>
                <button
                  onClick={() => onDeleteProject(project.id)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}

          {savedProjects.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
              لا توجد مشاريع محفوظة حاليًا. اضغط على &quot;حفظ نسخة جديدة الآن&quot; لحفظ عملك.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
