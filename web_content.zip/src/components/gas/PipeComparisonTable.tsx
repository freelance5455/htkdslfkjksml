import React from 'react';
import { 
  Table, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles,
  Info,
  ArrowUpDown
} from 'lucide-react';
import { PipeCalculationResult, GasParameters } from '../../types/gas';

interface PipeComparisonTableProps {
  pipeResults: PipeCalculationResult[];
  params: GasParameters;
}

export const PipeComparisonTable: React.FC<PipeComparisonTableProps> = ({
  pipeResults,
  params,
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0">
            <Table className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>جدول المقارنة الهيدروليكية لجميع أقطار النحاس (EN 1057)</span>
            </h2>
            <p className="text-xs text-slate-400">
              مقارنة هبوط الضغط وسرعة الغاز عبر مختلف الأقطار التجارية لاختيار القطر الاقتصادي والفني الأنسب
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-400 flex items-center gap-2">
          <span>الحد الأقصى لهبوط الضغط:</span>
          <span className="font-mono font-bold text-amber-400">
            {params.maxAllowablePressureDropMbar} م.بار
          </span>
        </div>
      </div>

      {/* Table responsive container */}
      <div className="overflow-x-auto mt-4">
        <table className="w-full text-right border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
              <th className="py-3 px-3">القطر التجاري (خارجي/داخلي)</th>
              <th className="py-3 px-3">القطر الداخلي (D)</th>
              <th className="py-3 px-3">مكافئ الأكواع</th>
              <th className="py-3 px-3">الطول الكلي (Leq)</th>
              <th className="py-3 px-3">هبوط الضغط (ΔP)</th>
              <th className="py-3 px-3">نسبة الاستهلاك</th>
              <th className="py-3 px-3">سرعة الغاز (V)</th>
              <th className="py-3 px-3 text-center">التقييم الفني</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {pipeResults.map((result) => {
              const isOptimal = result.isOptimal;
              const isRejected = !result.isPressureDropValid;
              const hasVelocityWarning = !result.isVelocityValid;

              return (
                <tr
                  key={result.pipe.nominal}
                  className={`transition-colors font-medium ${
                    isOptimal
                      ? 'bg-cyan-950/40 text-cyan-200 font-bold border-l-4 border-l-cyan-400'
                      : isRejected
                      ? 'bg-slate-950/30 text-slate-400 hover:bg-slate-800/30'
                      : 'hover:bg-slate-800/40 text-slate-300'
                  }`}
                >
                  {/* Nominal size */}
                  <td className="py-3 px-3 font-mono text-sm">
                    <div className="flex items-center gap-2">
                      {isOptimal && (
                        <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      )}
                      <span>{result.pipe.nominal} مم</span>
                      {isOptimal && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-sans">
                          الموصى به
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Internal diameter */}
                  <td className="py-3 px-3 font-mono text-slate-400">
                    {result.pipe.internalDiameterMm} مم
                  </td>

                  {/* Fittings Leq */}
                  <td className="py-3 px-3 font-mono text-amber-400/90">
                    +{result.fittingsEqLengthM} م
                  </td>

                  {/* Total Leq */}
                  <td className="py-3 px-3 font-mono text-slate-200">
                    {result.totalEqLengthM} م
                  </td>

                  {/* Delta P */}
                  <td className="py-3 px-3 font-mono">
                    <span
                      className={`font-bold ${
                        result.isPressureDropValid
                          ? isOptimal
                            ? 'text-cyan-400'
                            : 'text-emerald-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {result.pressureDropMbar} م.بار
                    </span>
                  </td>

                  {/* Pressure Drop Bar & Percentage */}
                  <td className="py-3 px-3">
                    <div className="w-24 flex items-center gap-1.5 font-mono text-[11px]">
                      <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            result.pressureDropRatioPercent > 100
                              ? 'bg-rose-500'
                              : result.pressureDropRatioPercent > 80
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{
                            width: `${Math.min(100, result.pressureDropRatioPercent)}%`,
                          }}
                        />
                      </div>
                      <span
                        className={
                          result.pressureDropRatioPercent > 100
                            ? 'text-rose-400 font-bold'
                            : 'text-slate-400'
                        }
                      >
                        {result.pressureDropRatioPercent}%
                      </span>
                    </div>
                  </td>

                  {/* Velocity */}
                  <td className="py-3 px-3 font-mono">
                    <span
                      className={
                        result.isVelocityValid
                          ? 'text-slate-200'
                          : 'text-amber-400 font-bold'
                      }
                    >
                      {result.velocityMps} م/ث
                    </span>
                  </td>

                  {/* Status Badge */}
                  <td className="py-3 px-3 text-center">
                    {isOptimal ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        <Sparkles className="w-3 h-3 text-cyan-400" />
                        الخيار الأمثل
                      </span>
                    ) : isRejected ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                        <XCircle className="w-3 h-3" />
                        مرفوض (ΔP زائد)
                      </span>
                    ) : hasVelocityWarning ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        <AlertTriangle className="w-3 h-3" />
                        سرعة عالية
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3" />
                        صالح ومطابق
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <span>* تم حساب هبوط الضغط بدقة وفق صيغة رينوار للضغط المنخفض (Renouard Basse Pression P &lt; 50 mbar).</span>
        <span>* الخيار الأمثل هو أصغر قطر نحاسي يحقق شروط الأمان لتوفير تكلفة المواد.</span>
      </div>

    </div>
  );
};
