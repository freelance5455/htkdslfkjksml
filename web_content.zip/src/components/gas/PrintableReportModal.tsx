import React from 'react';
import { 
  Printer, 
  X, 
  Flame, 
  CheckCircle2, 
  FileText, 
  ShieldCheck, 
  Calendar, 
  User, 
  Building2,
  Gauge
} from 'lucide-react';
import { CalculationSummary, GasParameters, GasAppliance, BuildingType } from '../../types/gas';

interface PrintableReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: CalculationSummary;
  params: GasParameters;
  appliances: GasAppliance[];
  projectTitle: string;
  clientName: string;
}

export const PrintableReportModal: React.FC<PrintableReportModalProps> = ({
  isOpen,
  onClose,
  summary,
  params,
  appliances,
  projectTitle,
  clientName,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      
      {/* Container */}
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-4">
        
        {/* Modal Top Bar (Hidden on print) */}
        <div className="no-print p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-slate-100 text-sm">
              معاينة التقرير الهندسي للاعتماد والطباعة
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-semibold text-xs shadow-md transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة التقرير / حفظ PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Sheet Content */}
        <div className="p-6 sm:p-8 overflow-y-auto bg-slate-950 text-slate-200 print:p-0 print:bg-white print:text-black" id="printable-report">
          
          {/* Header of the Official Report */}
          <div className="border-b-2 border-orange-500/80 pb-6 mb-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <div className="flex items-center gap-2 text-orange-500 font-extrabold text-xl tracking-tight">
                  <Flame className="w-7 h-7 text-orange-500" />
                  <span>مذكرة الحسابات الفنية لشبكة الغاز الطبيعي</span>
                </div>
                <div className="text-xs text-slate-400 print:text-gray-600 mt-1 font-medium">
                  حساب أقطار أنابيب النحاس وتحديد نوع العداد وفق المواصفات القياسية (NF DTU 61.1 / EN 1057 / EN 1359)
                </div>
              </div>
              
              <div className="text-left font-mono text-xs text-slate-400 print:text-gray-600">
                <div>التاريخ: <strong className="text-slate-200 print:text-black">{currentDate}</strong></div>
                <div>المرجع: <strong className="text-orange-400 font-mono">GN-CALC-{Date.now().toString().slice(-6)}</strong></div>
              </div>
            </div>

            {/* Project & Client Card */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 p-3 bg-slate-900 print:bg-gray-100 rounded-xl border border-slate-800 print:border-gray-300 text-xs">
              <div>
                <span className="text-slate-400 print:text-gray-500 block">اسم المشروع:</span>
                <strong className="text-slate-100 print:text-black font-semibold text-sm">
                  {projectTitle || 'مشروع تمديد شبكة غاز طبيعي'}
                </strong>
              </div>
              <div>
                <span className="text-slate-400 print:text-gray-500 block">المالك / العميل:</span>
                <strong className="text-slate-100 print:text-black font-semibold">
                  {clientName || 'غير محدد'}
                </strong>
              </div>
              <div>
                <span className="text-slate-400 print:text-gray-500 block">طبيعة المنشأة:</span>
                <strong className="text-amber-400 print:text-orange-700 font-semibold">
                  {params.buildingType === 'residential' ? 'استعمال منزلي (شقق / فلل)' : 'استعمال تجاري (مطاعم / محلات / مخابز)'}
                </strong>
              </div>
            </div>
          </div>

          {/* Standards & Hypotheses */}
          <div className="mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 print:text-gray-700 mb-2">
              1. الفرضيات والمعايير الهندسية المعتمدة (Hypothèses de Calcul):
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-900/60 print:bg-gray-50 p-3 rounded-lg border border-slate-800 print:border-gray-200 font-mono">
              <div>نوع الغاز: <strong className="text-slate-200 print:text-black">غاز طبيعي H (20 mbar)</strong></div>
              <div>الكثافة النسبية (d): <strong className="text-slate-200 print:text-black">0.60</strong></div>
              <div>القيمة الحرارية (PCS): <strong className="text-slate-200 print:text-black">{params.calorificValueKwh} kWh/m³</strong></div>
              <div>أقصى هبوط ضغط: <strong className="text-amber-400 print:text-orange-600">{params.maxAllowablePressureDropMbar} mbar</strong></div>
            </div>
          </div>

          {/* Installed Appliances Table */}
          <div className="mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 print:text-gray-700 mb-2">
              2. قائمة معدات وأجهزة الغاز المحسوبة (Inventaire des Appareils):
            </h3>
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-700 print:border-gray-300 text-slate-400 print:text-gray-600 bg-slate-900 print:bg-gray-100">
                  <th className="py-2 px-3">الجهاز</th>
                  <th className="py-2 px-3">العدد</th>
                  <th className="py-2 px-3">القدرة الحرارية (kW)</th>
                  <th className="py-2 px-3">التدفق الاسمي (m³/h)</th>
                  <th className="py-2 px-3">ملاحظات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 print:divide-gray-200">
                {appliances.filter(a => a.enabled).map((app) => (
                  <tr key={app.id}>
                    <td className="py-2 px-3 font-semibold text-slate-200 print:text-black">{app.name}</td>
                    <td className="py-2 px-3 font-mono">{app.quantity}</td>
                    <td className="py-2 px-3 font-mono">{app.powerKw * app.quantity} kW</td>
                    <td className="py-2 px-3 font-mono">{(app.flowRateM3h * app.quantity).toFixed(2)} m³/h</td>
                    <td className="py-2 px-3 text-slate-400 print:text-gray-500">{app.notes || '-'}</td>
                  </tr>
                ))}
                <tr className="bg-slate-900/80 print:bg-gray-100 font-bold border-t-2 border-slate-700 print:border-gray-400">
                  <td className="py-2.5 px-3">الإجمالي الاسمي:</td>
                  <td className="py-2.5 px-3 font-mono">{appliances.filter(a => a.enabled).reduce((s, a) => s + a.quantity, 0)}</td>
                  <td className="py-2.5 px-3 font-mono text-amber-400 print:text-black">{summary.totalInstalledPowerKw} kW</td>
                  <td className="py-2.5 px-3 font-mono text-cyan-400 print:text-black">{summary.totalNominalFlowM3h} m³/h</td>
                  <td className="py-2.5 px-3 text-[11px] text-slate-400 print:text-gray-600 font-normal">
                    معامل التزامن: {Math.round(summary.diversityFactor * 100)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Network Geometry & Fittings */}
          <div className="mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 print:text-gray-700 mb-2">
              3. أطوال الأنبوب ومكافئ الأكواع والتجهيزات (Longueurs et Coudes):
            </h3>
            <div className="p-3 bg-slate-900/60 print:bg-gray-50 rounded-lg border border-slate-800 print:border-gray-200 text-xs grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
              <div>الطول المستقيم: <strong className="text-slate-200 print:text-black">{params.pipeLengthM} م</strong></div>
              <div>عدد الأكواع 90°: <strong className="text-amber-400 print:text-black">{params.fittings.elbows90} كوع</strong></div>
              <div>عدد الأكواع 45°: <strong className="text-amber-400 print:text-black">{params.fittings.elbows45} كوع</strong></div>
              <div>تفرعات T ومحابس: <strong className="text-slate-200 print:text-black">{params.fittings.tees} T / {params.fittings.valves} محبس</strong></div>
              <div className="col-span-2 text-cyan-400 print:text-blue-700 font-bold">
                مكافئ مقاومة الأكواع: +{summary.fittingsEquivalentLengthM} م
              </div>
              <div className="col-span-2 text-cyan-400 print:text-blue-700 font-bold">
                الطول الهيدروليكي الإجمالي (Leq): {summary.totalEquivalentLengthM} م
              </div>
            </div>
          </div>

          {/* Final Results Approved Box */}
          <div className="mb-8 p-5 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-amber-950/40 print:bg-gray-100 rounded-xl border-2 border-orange-500/60 print:border-gray-400">
            <h3 className="text-sm font-bold text-orange-400 print:text-orange-700 flex items-center gap-2 mb-4">
              <ShieldCheck className="w-5 h-5" />
              <span>4. القرارات الفنية المعتمدة (Résultats et Spécifications Approuvées):</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Pipe Result */}
              <div className="p-4 rounded-xl bg-slate-950 print:bg-white border border-slate-800 print:border-gray-300">
                <div className="text-xs text-slate-400 print:text-gray-600 mb-1">
                  قطر أنبوب النحاس المعتمد (Tube Cuivre EN 1057):
                </div>
                <div className="text-3xl font-extrabold font-mono text-cyan-400 print:text-blue-700">
                  {summary.recommendedPipe?.nominal} مم
                </div>
                <div className="text-xs text-slate-300 print:text-gray-700 mt-2 space-y-1 font-mono">
                  <div>القطر الداخلي: {summary.recommendedPipe?.internalDiameterMm} مم | الخارجي: {summary.recommendedPipe?.externalDiameterMm} مم</div>
                  <div>هبوط الضغط الفعلي: <strong className="text-cyan-400 print:text-black">{summary.optimalResult?.pressureDropMbar} mbar</strong> (مقبول &lt; {params.maxAllowablePressureDropMbar} mbar)</div>
                  <div>سرعة تدفق الغاز: <strong className="text-emerald-400 print:text-black">{summary.optimalResult?.velocityMps} m/s</strong> (آمن وهادئ)</div>
                </div>
              </div>

              {/* Meter Result */}
              <div className="p-4 rounded-xl bg-slate-950 print:bg-white border border-slate-800 print:border-gray-300">
                <div className="text-xs text-slate-400 print:text-gray-600 mb-1">
                  نوع عداد الغاز الطبيعي المعتمد (Compteur Gaz EN 1359):
                </div>
                <div className="text-3xl font-extrabold font-mono text-amber-400 print:text-orange-600">
                  {summary.recommendedMeter?.code}
                </div>
                <div className="text-xs text-slate-300 print:text-gray-700 mt-2 space-y-1 font-mono">
                  <div>التدفق الاسمي: {summary.recommendedMeter?.qNom} m³/h | الأقصى Qmax: {summary.recommendedMeter?.qMax} m³/h</div>
                  <div>وصلة العداد (Raccord): {summary.recommendedMeter?.connectionSize}</div>
                  <div>نسبة تحميل العداد: <strong className="text-amber-400 print:text-black">{summary.recommendedMeter?.loadPercentage}%</strong> من السعة القصوى</div>
                </div>
              </div>

            </div>
          </div>

          {/* Signatures block */}
          <div className="mt-8 pt-6 border-t border-slate-800 print:border-gray-300 grid grid-cols-3 gap-4 text-center text-xs">
            <div>
              <span className="text-slate-400 print:text-gray-500 block mb-12">مهندس الشبكات / المصمم:</span>
              <div className="border-t border-dashed border-slate-700 print:border-gray-400 pt-1 font-semibold">
                التوقيع والختم
              </div>
            </div>
            <div>
              <span className="text-slate-400 print:text-gray-500 block mb-12">المقاول المنفذ (السباك المعتمد):</span>
              <div className="border-t border-dashed border-slate-700 print:border-gray-400 pt-1 font-semibold">
                التوقيع والختم
              </div>
            </div>
            <div>
              <span className="text-slate-400 print:text-gray-500 block mb-12">مصادقة مصلحة الغاز / الرقابة:</span>
              <div className="border-t border-dashed border-slate-700 print:border-gray-400 pt-1 font-semibold">
                الموافقة الفنية
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
