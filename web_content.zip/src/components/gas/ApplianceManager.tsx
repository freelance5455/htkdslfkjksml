import React, { useState } from 'react';
import { 
  Flame, 
  Plus, 
  Trash2, 
  Zap, 
  Gauge, 
  Sliders, 
  Layers, 
  HelpCircle,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { GasAppliance, GasParameters } from '../../types/gas';
import { STANDARD_APPLIANCE_CATALOG } from '../../data/gasPresets';

interface ApplianceManagerProps {
  appliances: GasAppliance[];
  params: GasParameters;
  onUpdateAppliances: (appliances: GasAppliance[]) => void;
  onUpdateParams: (params: Partial<GasParameters>) => void;
  totalInstalledPowerKw: number;
  totalNominalFlowM3h: number;
  simultaneousFlowM3h: number;
  diversityFactor: number;
}

export const ApplianceManager: React.FC<ApplianceManagerProps> = ({
  appliances,
  params,
  onUpdateAppliances,
  onUpdateParams,
  totalInstalledPowerKw,
  totalNominalFlowM3h,
  simultaneousFlowM3h,
  diversityFactor,
}) => {
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [newCustomName, setNewCustomName] = useState('');
  const [newCustomPower, setNewCustomPower] = useState(15);
  const [isAddingCustom, setIsAddingCustom] = useState(false);

  // Toggle appliance enabled state
  const handleToggle = (id: string) => {
    onUpdateAppliances(
      appliances.map((app) =>
        app.id === id ? { ...app, enabled: !app.enabled } : app
      )
    );
  };

  // Change quantity
  const handleQuantityChange = (id: string, delta: number) => {
    onUpdateAppliances(
      appliances.map((app) => {
        if (app.id === id) {
          const newQty = Math.max(1, app.quantity + delta);
          return { ...app, quantity: newQty };
        }
        return app;
      })
    );
  };

  // Change power
  const handlePowerChange = (id: string, power: number) => {
    const validPower = Math.max(0.1, power);
    const flow = Math.round((validPower / params.calorificValueKwh) * 100) / 100;
    onUpdateAppliances(
      appliances.map((app) =>
        app.id === id ? { ...app, powerKw: validPower, flowRateM3h: flow } : app
      )
    );
  };

  // Delete appliance
  const handleDelete = (id: string) => {
    onUpdateAppliances(appliances.filter((app) => app.id !== id));
  };

  // Add from catalog
  const handleAddFromCatalog = (item: (typeof STANDARD_APPLIANCE_CATALOG)[0]) => {
    const newApp: GasAppliance = {
      ...item,
      id: `app-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    };
    onUpdateAppliances([...appliances, newApp]);
    setIsCatalogOpen(false);
  };

  // Add custom appliance
  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomName.trim()) return;
    const flow = Math.round((newCustomPower / params.calorificValueKwh) * 100) / 100;
    const newApp: GasAppliance = {
      id: `app-custom-${Date.now()}`,
      name: newCustomName.trim(),
      category: 'other',
      powerKw: newCustomPower,
      flowRateM3h: flow,
      quantity: 1,
      enabled: true,
      notes: 'جهاز مخصص',
    };
    onUpdateAppliances([...appliances, newApp]);
    setNewCustomName('');
    setIsAddingCustom(false);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
      
      {/* Header & Metric Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-orange-400 border border-orange-500/20 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>معدات وأجهزة الغاز واستهلاكها</span>
              <span className="text-xs font-normal text-slate-400">
                ({appliances.filter(a => a.enabled).length} أجهزة نشطة)
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              أدخل قدرة الأجهزة بالكيلوواط (kW) لحساب معدل التدفق الاسمي والمتزامن
            </p>
          </div>
        </div>

        {/* Live Counters */}
        <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800/80">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">إجمالي القدرة</div>
            <div className="text-sm font-bold text-amber-400 font-mono">
              {totalInstalledPowerKw} <span className="text-xs text-slate-400 font-normal">kW</span>
            </div>
          </div>
          <div className="h-7 w-[1px] bg-slate-800" />
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">التدفق الاسمي</div>
            <div className="text-sm font-bold text-cyan-400 font-mono">
              {totalNominalFlowM3h} <span className="text-xs text-slate-400 font-normal">m³/h</span>
            </div>
          </div>
          <div className="h-7 w-[1px] bg-slate-800" />
          <div className="text-right">
            <div className="text-[10px] text-orange-400 font-semibold uppercase tracking-wider">التدفق المتزامن</div>
            <div className="text-sm font-bold text-orange-400 font-mono">
              {simultaneousFlowM3h} <span className="text-xs text-slate-400 font-normal">m³/h</span>
            </div>
          </div>
        </div>
      </div>

      {/* Diversity / Simultaneity Settings */}
      <div className="my-4 p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <span>نسبة التزامن والاستهلاك الفعلي (Diversity Factor)</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 font-bold">
                {Math.round(diversityFactor * 100)}%
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {params.diversityFactorMode === 'auto'
                ? params.buildingType === 'residential'
                  ? 'حساب تلقائي قياسي (DTU 61.1): مراعاة عدم تشغيل جميع الأجهزة بطاقتها القصوى معًا'
                  : 'حساب تلقائي قياسي تجاري: ذروة استخدام متزامنة للمطابخ والمطاعم والمخابز'
                : 'تحديد يدوي مباشر لنسبة تشغيل الأجهزة المتزامنة'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Auto vs Manual Toggle */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => onUpdateParams({ diversityFactorMode: 'auto' })}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                params.diversityFactorMode === 'auto'
                  ? 'bg-amber-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تلقائي قياسي
            </button>
            <button
              type="button"
              onClick={() => onUpdateParams({ diversityFactorMode: 'manual' })}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                params.diversityFactorMode === 'manual'
                  ? 'bg-amber-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              يدوي مخصص
            </button>
          </div>

          {/* Manual Slider if active */}
          {params.diversityFactorMode === 'manual' && (
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="40"
                max="100"
                step="5"
                value={params.manualDiversityPercent}
                onChange={(e) =>
                  onUpdateParams({ manualDiversityPercent: Number(e.target.value) })
                }
                className="w-28 accent-amber-500"
              />
              <span className="text-xs font-mono font-bold text-amber-400 w-10 text-left">
                {params.manualDiversityPercent}%
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Appliances Table / List */}
      <div className="space-y-2.5">
        {appliances.map((app) => (
          <div
            key={app.id}
            className={`p-3 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              app.enabled
                ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                : 'bg-slate-950/20 border-slate-800/40 opacity-50'
            }`}
          >
            {/* Right: Info & Enable toggle */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleToggle(app.id)}
                className="text-slate-400 hover:text-amber-400 transition-colors"
                title={app.enabled ? 'تعطيل الجهاز من الحساب' : 'تفعيل الجهاز في الحساب'}
              >
                {app.enabled ? (
                  <ToggleRight className="w-6 h-6 text-amber-500" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-slate-600" />
                )}
              </button>
              <div>
                <div className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                  <span>{app.name}</span>
                  {app.notes && (
                    <span className="text-[10px] text-slate-500 font-normal hidden sm:inline">
                      ({app.notes})
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  التدفق الفردي: <span className="text-cyan-400">{app.flowRateM3h} m³/h</span>
                </div>
              </div>
            </div>

            {/* Left: Power input, Quantity controls, Delete */}
            <div className="flex items-center justify-between sm:justify-end gap-3">
              
              {/* Power in kW */}
              <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800">
                <span className="text-[11px] text-slate-400">القدرة:</span>
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={app.powerKw}
                  onChange={(e) => handlePowerChange(app.id, Number(e.target.value))}
                  className="w-16 bg-transparent text-xs font-mono font-bold text-amber-400 focus:outline-none text-center"
                />
                <span className="text-[10px] text-slate-400 font-mono">kW</span>
              </div>

              {/* Quantity */}
              <div className="flex items-center bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
                <button
                  type="button"
                  onClick={() => handleQuantityChange(app.id, -1)}
                  className="px-2 py-1 text-slate-400 hover:text-slate-100 hover:bg-slate-800 text-xs font-bold"
                >
                  -
                </button>
                <span className="px-2.5 text-xs font-mono font-bold text-slate-200">
                  {app.quantity}
                </span>
                <button
                  type="button"
                  onClick={() => handleQuantityChange(app.id, 1)}
                  className="px-2 py-1 text-slate-400 hover:text-slate-100 hover:bg-slate-800 text-xs font-bold"
                >
                  +
                </button>
              </div>

              {/* Delete */}
              <button
                type="button"
                onClick={() => handleDelete(app.id)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                title="حذف الجهاز"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {appliances.length === 0 && (
          <div className="p-8 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
            لم يتم إضافة أجهزة بعد. اختر جهازًا من الكتالوج أو أضف جهازًا مخصصًا.
          </div>
        )}
      </div>

      {/* Action Buttons: Add from Catalog or Custom */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setIsCatalogOpen(!isCatalogOpen)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
        >
          <Layers className="w-3.5 h-3.5 text-amber-400" />
          <span>إضافة جهاز من الكتالوج القياسي</span>
        </button>

        <button
          type="button"
          onClick={() => setIsAddingCustom(!isAddingCustom)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
        >
          <Plus className="w-3.5 h-3.5 text-cyan-400" />
          <span>إضافة جهاز مخصص</span>
        </button>
      </div>

      {/* Catalog Selector Panel */}
      {isCatalogOpen && (
        <div className="mt-3 p-3 bg-slate-950 border border-slate-800 rounded-xl">
          <div className="text-xs font-bold text-slate-300 mb-2 flex items-center justify-between">
            <span>كتالوج الأجهزة المنزلية والتجارية القياسية:</span>
            <button
              onClick={() => setIsCatalogOpen(false)}
              className="text-slate-500 hover:text-slate-300 text-xs"
            >
              إغلاق ✕
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 max-h-60 overflow-y-auto pr-1">
            {STANDARD_APPLIANCE_CATALOG.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleAddFromCatalog(item)}
                className="text-right p-2 rounded-lg bg-slate-900 hover:bg-amber-950/40 hover:border-amber-500/40 border border-slate-800/80 transition-all text-xs flex flex-col justify-between"
              >
                <span className="font-semibold text-slate-200">{item.name}</span>
                <span className="text-[11px] text-amber-400 font-mono mt-1">
                  {item.powerKw} kW ≈ {item.flowRateM3h} m³/h
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Add Custom Form */}
      {isAddingCustom && (
        <form onSubmit={handleAddCustom} className="mt-3 p-3 bg-slate-950 border border-slate-800 rounded-xl flex flex-wrap items-center gap-2.5">
          <input
            type="text"
            placeholder="اسم الجهاز الجديد (مثال: موقد ووك، فرن خزفي...)"
            value={newCustomName}
            onChange={(e) => setNewCustomName(e.target.value)}
            className="flex-1 min-w-[200px] px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            autoFocus
          />
          <div className="flex items-center gap-1.5 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400">القدرة:</span>
            <input
              type="number"
              min="0.5"
              step="0.5"
              value={newCustomPower}
              onChange={(e) => setNewCustomPower(Number(e.target.value))}
              className="w-16 bg-transparent text-xs font-mono font-bold text-amber-400 focus:outline-none text-center"
            />
            <span className="text-xs text-slate-400 font-mono">kW</span>
          </div>
          <button
            type="submit"
            className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs shadow-sm transition-colors"
          >
            إضافة للجرد
          </button>
          <button
            type="button"
            onClick={() => setIsAddingCustom(false)}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
          >
            إلغاء
          </button>
        </form>
      )}

    </div>
  );
};
