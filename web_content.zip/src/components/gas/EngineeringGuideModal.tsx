import React, { useState } from 'react';
import { 
  BookOpen, 
  X, 
  Flame, 
  Gauge, 
  Ruler, 
  ShieldAlert, 
  FileCode, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { GAS_METERS_SPECS } from '../../utils/gasCalculations';

interface EngineeringGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EngineeringGuideModal: React.FC<EngineeringGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [activeSection, setActiveSection] = useState<'renouard' | 'meters' | 'fittings' | 'safety'>('renouard');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-4">
        
        {/* Modal Top */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">
                دليل القوانين والمعايير الهندسية لشبكات الغاز الطبيعي
              </h2>
              <p className="text-[11px] text-slate-400">
                صيغة رينوار، مواصفات العدادات EN 1359، وأصول تركيب أنابيب النحاس
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex items-center gap-1 p-2 bg-slate-950/80 border-b border-slate-800 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveSection('renouard')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors ${
              activeSection === 'renouard'
                ? 'bg-amber-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            صيغة رينوار (Renouard)
          </button>
          <button
            onClick={() => setActiveSection('meters')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors ${
              activeSection === 'meters'
                ? 'bg-amber-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            جدول العدادات (G4 إلى G65)
          </button>
          <button
            onClick={() => setActiveSection('fittings')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors ${
              activeSection === 'fittings'
                ? 'bg-amber-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            مقاومة الأكواع والتجهيزات
          </button>
          <button
            onClick={() => setActiveSection('safety')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors ${
              activeSection === 'safety'
                ? 'bg-amber-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            قواعد السلامة واللحام
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto text-xs text-slate-300 leading-relaxed space-y-4">
          
          {/* Section 1: Renouard Formula */}
          {activeSection === 'renouard' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-amber-400 font-bold text-sm mb-1">
                  صيغة رينوار للضغط المنخفض (Formule de Renouard Basse Pression)
                </div>
                <p className="text-slate-400 mb-3">
                  تُستخدم هذه الصيغة الهيدروليكية لحساب هبوط الضغط في شبكات الغاز الطبيعي عندما يكون الضغط الاسمي أقل من 50 ميلي بار (P &lt; 50 mbar):
                </p>
                
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-center font-mono text-cyan-300 text-base font-bold my-2 direction-ltr">
                  ΔP = 23.2 × d × L × Q^1.82 / D^4.82
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 text-slate-300 font-mono text-[11px]">
                  <div>• <strong>ΔP</strong>: هبوط الضغط بالميلي بار (mbar).</div>
                  <div>• <strong>d</strong>: الكثافة النسبية للغاز (0.60 للغاز الطبيعي).</div>
                  <div>• <strong>L</strong>: الطول الهيدروليكي المكافئ الكلي بالأمتار (m).</div>
                  <div>• <strong>Q</strong>: معدل التدفق المتزامن بـ (m³/h).</div>
                  <div>• <strong>D</strong>: القطر الداخلي للأنبوب بالميليمتر (mm).</div>
                  <div>• <strong>23.2</strong>: الثابت الرياضي لتحويل الوحدات.</div>
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-bold text-slate-200 mb-1">شروط القبول وفق المواصفة DTU 61.1:</div>
                <ul className="list-disc list-inside space-y-1 text-slate-400">
                  <li>أقصى هبوط ضغط مسموح به بين عداد الغاز وأبعد جهاز هو <strong className="text-amber-400">1.0 م.بار</strong> (أو 1.5 م.بار لبعض الشبكات التجارية).</li>
                  <li>سرعة تدفق الغاز داخل الأنابيب المنزلية يجب ألا تتجاوز <strong className="text-emerald-400">5 م/ث</strong> لمنع الصفير والاهتزاز.</li>
                  <li>في المحلات التجارية والمطابخ المركزية يمكن قبول سرعة تصل إلى <strong className="text-emerald-400">10 م/ث</strong> في الخطوط الرئيسية.</li>
                </ul>
              </div>
            </div>
          )}

          {/* Section 2: Gas Meters Table */}
          {activeSection === 'meters' && (
            <div className="space-y-3">
              <p className="text-slate-400">
                تصنيف عدادات الغاز الطبيعي وفق المواصفة الأوروبية القياسية <strong className="text-amber-400">EN 1359</strong>:
              </p>
              
              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                      <th className="p-2">طراز العداد</th>
                      <th className="p-2">التدفق الاسمي (Qnom)</th>
                      <th className="p-2">التدفق الأقصى (Qmax)</th>
                      <th className="p-2">أقصى قدرة حرارية تقريبية</th>
                      <th className="p-2">قطر الوصلة</th>
                      <th className="p-2">الاستعمال النموذجي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {GAS_METERS_SPECS.map((m) => (
                      <tr key={m.code} className="hover:bg-slate-800/40">
                        <td className="p-2 font-mono font-bold text-amber-400">{m.code}</td>
                        <td className="p-2 font-mono">{m.qNom} m³/h</td>
                        <td className="p-2 font-mono font-bold text-cyan-400">{m.qMax} m³/h</td>
                        <td className="p-2 font-mono text-slate-300">~ {m.maxPowerKwApprox} kW</td>
                        <td className="p-2 font-mono text-slate-400">{m.connectionSize}</td>
                        <td className="p-2 text-slate-400 text-[11px]">{m.typicalApplicationAr}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 3: Fittings Equivalent Lengths */}
          {activeSection === 'fittings' && (
            <div className="space-y-4">
              <p className="text-slate-400">
                كل تغيير في اتجاه الأنبوب أو صمام يتسبب في فقدان طاقة موضعي (Perte de charge singulière). وفق دليل ATG B 105، يتم تحويلها إلى أطوال مكافئة بدلالة القطر الداخلي (D):
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-amber-400 font-bold mb-1">كوع 90 درجة (Coude 90°):</div>
                  <div className="font-mono text-cyan-400 text-sm font-bold">Leq = 30 × D</div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    مثال لقطر داخلي 20 مم (20/22): يضيف الكوع الواحد 0.60 متر مكافئ.
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-amber-400 font-bold mb-1">كوع 45 درجة (Coude 45°):</div>
                  <div className="font-mono text-cyan-400 text-sm font-bold">Leq = 15 × D</div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    مثال لقطر داخلي 20 مم: يضيف الكوع الواحد 0.30 متر مكافئ فقط.
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-indigo-400 font-bold mb-1">تفرع تي 90° (Té de dérivation):</div>
                  <div className="font-mono text-cyan-400 text-sm font-bold">Leq = 60 × D</div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    المسار المنعطف يسبب اضطرابًا هيدروليكيًا مضاعفًا مقارنة بالكوع.
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-emerald-400 font-bold mb-1">صمام غاز ربع دورة (Robinet):</div>
                  <div className="font-mono text-cyan-400 text-sm font-bold">Leq = 20 × D</div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    للصمامات الكروية كاملة المقطع المعتمدة للغاز (Passage intégral).
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 4: Safety Regulations & Brazing */}
          {activeSection === 'safety' && (
            <div className="space-y-3">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  قواعد اللحام والتوصيل لأنابيب النحاس الخاصة بالغاز الطبيعي:
                </div>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300">
                  <li><strong>اللحام الصلب فقط (Brasage fort):</strong> يُمنع تمامًا اللحام بالقصدير الضعيف (Brasage tendre). يجب استخدام سبائك الفضة/النحاس-فوسفور التي تنصهر عند درجات حرارة أعلى من 450°C.</li>
                  <li><strong>نوع النحاس:</strong> نحاس سحب نقي نصف صلب أو صلب مطابقة للمواصفة EN 1057 موسوم بعلامة الغاز.</li>
                  <li><strong>المسافات الفاصلة عن الشبكات الكهربائية:</strong> يجب الحفاظ على مسافة لا تقل عن 3 سم في المسار الموازي و1 سم عند التقاطع.</li>
                  <li><strong>محابس الأمان:</strong> يجب تزويد كل جهاز غاز بمحبس ربع دورة مخصص يسهل الوصول إليه بسرعة في الحالات الطارئة.</li>
                  <li><strong>اختبار الضغط والسلامة:</strong> يجب إجراء فحص إحكام (Test d'étanchéité) عند ضغط 150 إلى 200 م.بار لمدة 10 دقائق على الأقل قبل إطلاق الغاز للتأكد من عدم وجود أي تسريب.</li>
                </ul>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
