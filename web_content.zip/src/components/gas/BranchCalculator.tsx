import React, { useState } from 'react';
import { 
  GitFork, 
  Plus, 
  Trash2, 
  Flame, 
  Ruler, 
  CornerDownLeft, 
  CheckCircle2, 
  ArrowRight
} from 'lucide-react';
import { GasAppliance, GasParameters } from '../../types/gas';
import { 
  calculateRenouardPressureDrop, 
  calculateGasVelocity, 
  calculateFittingsEquivalentLength, 
  COPPER_PIPES 
} from '../../utils/gasCalculations';

interface BranchCalculatorProps {
  appliances: GasAppliance[];
  params: GasParameters;
}

interface LocalBranch {
  id: string;
  name: string;
  applianceId: string;
  lengthM: number;
  elbows90: number;
}

export const BranchCalculator: React.FC<BranchCalculatorProps> = ({ appliances, params }) => {
  const [branches, setBranches] = useState<LocalBranch[]>([
    {
      id: 'br-1',
      name: 'فرع المرجل / الشوفاج',
      applianceId: appliances[0]?.id || '',
      lengthM: 6,
      elbows90: 3,
    },
    {
      id: 'br-2',
      name: 'فرع طباخ المطبخ',
      applianceId: appliances[1]?.id || '',
      lengthM: 8,
      elbows90: 4,
    },
  ]);

  const addBranch = () => {
    const newBr: LocalBranch = {
      id: `br-${Date.now()}`,
      name: `فرع جهاز إضافي`,
      applianceId: appliances[0]?.id || '',
      lengthM: 5,
      elbows90: 2,
    };
    setBranches([...branches, newBr]);
  };

  const removeBranch = (id: string) => {
    setBranches(branches.filter((b) => b.id !== id));
  };

  const updateBranch = (id: string, updates: Partial<LocalBranch>) => {
    setBranches(branches.map((b) => (b.id === id ? { ...b, ...updates } : b)));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center shrink-0">
            <GitFork className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>حاسبة الفروع الفردية (من مجمع التوزيع إلى كل جهاز)</span>
            </h2>
            <p className="text-xs text-slate-400">
              تحديد القطر النحاسي المستقل لكل جهاز انطلاقًا من مجمع الغاز الرئيسي (Nourrice)
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={addBranch}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white shadow-sm transition-colors self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>إضافة فرع جهاز</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        {branches.map((branch) => {
          const matchedApp = appliances.find((a) => a.id === branch.applianceId);
          const flowM3h = matchedApp ? matchedApp.flowRateM3h : 1.5;
          const powerKw = matchedApp ? matchedApp.powerKw : 15;

          // Find optimal copper pipe for this specific branch
          // Allowed branch ΔP is typically 0.5 mbar
          const branchMaxDp = 0.5;

          let recommendedPipe = COPPER_PIPES[0];
          let bestDp = 999;
          let bestVelocity = 0;

          for (const pipe of COPPER_PIPES) {
            const fittingsEq = calculateFittingsEquivalentLength(
              {
                elbows90: branch.elbows90,
                elbows45: 0,
                tees: 1,
                valves: 1,
                customEquivalentLength: 0,
              },
              pipe.internalDiameterMm
            );
            const totalL = branch.lengthM + fittingsEq;
            const dp = calculateRenouardPressureDrop(
              flowM3h,
              totalL,
              pipe.internalDiameterMm,
              params.relativeDensity
            );
            const vel = calculateGasVelocity(flowM3h, pipe.internalDiameterMm);

            if (dp <= branchMaxDp && vel <= params.maxVelocityMps) {
              recommendedPipe = pipe;
              bestDp = dp;
              bestVelocity = vel;
              break;
            }
          }

          return (
            <div
              key={branch.id}
              className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <input
                    type="text"
                    value={branch.name}
                    onChange={(e) => updateBranch(branch.id, { name: e.target.value })}
                    className="font-bold text-slate-200 bg-transparent border-b border-transparent hover:border-slate-700 focus:border-purple-500 focus:outline-none text-sm px-1"
                  />
                  <button
                    type="button"
                    onClick={() => removeBranch(branch.id)}
                    className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/30"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Select appliance */}
                <div className="mb-3">
                  <label className="text-[11px] text-slate-400 block mb-1">
                    الجهاز المغذى بالفرع:
                  </label>
                  <select
                    value={branch.applianceId}
                    onChange={(e) => updateBranch(branch.id, { applianceId: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-purple-500 font-medium"
                  >
                    {appliances.map((app) => (
                      <option key={app.id} value={app.id}>
                        {app.name} ({app.powerKw} kW ≈ {app.flowRateM3h} m³/h)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Length and elbows */}
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">
                      طول الفرع (متر):
                    </label>
                    <input
                      type="number"
                      min="0.5"
                      step="0.5"
                      value={branch.lengthM}
                      onChange={(e) =>
                        updateBranch(branch.id, { lengthM: Math.max(0.1, Number(e.target.value)) })
                      }
                      className="w-full px-2 py-1 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-slate-200 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">
                      عدد الأكواع 90°:
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={branch.elbows90}
                      onChange={(e) =>
                        updateBranch(branch.id, { elbows90: Math.max(0, Number(e.target.value)) })
                      }
                      className="w-full px-2 py-1 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-amber-400 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Branch Recommendation Box */}
              <div className="pt-3 border-t border-slate-800/80 bg-purple-950/20 p-3 rounded-xl border border-purple-500/20 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-purple-300 font-medium uppercase">
                    قطر أنبوب النحاس للفرع:
                  </div>
                  <div className="text-xl font-mono font-extrabold text-purple-400">
                    {recommendedPipe.nominal} مم
                  </div>
                  <div className="text-[10px] text-slate-400">
                    داخلي: {recommendedPipe.internalDiameterMm} مم
                  </div>
                </div>

                <div className="text-left text-xs font-mono">
                  <div className="text-slate-300">
                    ΔP: <span className="text-purple-300 font-bold">{bestDp}</span> mbar
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    V: <span className="text-emerald-400 font-bold">{bestVelocity}</span> m/s
                  </div>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
