import React from 'react';
import { 
  Flame, 
  Building2, 
  Home, 
  Printer, 
  BookOpen, 
  FolderDown, 
  RotateCcw,
  Sparkles,
  Gauge,
  Smartphone,
  Download
} from 'lucide-react';
import { BuildingType } from '../../types/gas';
import { GAS_PRESETS, GasPreset } from '../../data/gasPresets';

interface GasHeaderProps {
  buildingType: BuildingType;
  onBuildingTypeChange: (type: BuildingType) => void;
  projectTitle: string;
  onProjectTitleChange: (title: string) => void;
  clientName: string;
  onClientNameChange: (name: string) => void;
  onSelectPreset: (preset: GasPreset) => void;
  onOpenReport: () => void;
  onOpenGuide: () => void;
  onOpenSavedProjects: () => void;
  onOpenMobileInstall: () => void;
  onResetToDefaults: () => void;
}

export const GasHeader: React.FC<GasHeaderProps> = ({
  buildingType,
  onBuildingTypeChange,
  projectTitle,
  onProjectTitleChange,
  clientName,
  onClientNameChange,
  onSelectPreset,
  onOpenReport,
  onOpenGuide,
  onOpenSavedProjects,
  onOpenMobileInstall,
  onResetToDefaults,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand & Main Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-md shadow-orange-500/20 text-white shrink-0">
              <Flame className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-100 tracking-tight">
                  حاسبة أقطار أنابيب الغاز الطبيعي وعدادات الغاز
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-orange-500/10 text-orange-400 border border-orange-500/20">
                  صيغة رينوار | EN 1057 | EN 1359
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                حساب الأنابيب النحاسية للمنازل والمحلات التجارية، هبوط الضغط، الأكواع واختيار العداد (G4, G6, G10...)
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Quick Presets Dropdown */}
            <div className="relative group">
              <button 
                type="button"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>نماذج جاهزة</span>
              </button>
              <div className="absolute left-0 top-full mt-1.5 w-64 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl p-2 hidden group-hover:block z-50">
                <div className="text-[11px] font-bold text-slate-400 px-2 py-1 uppercase tracking-wider">
                  اختر نموذجًا سريعًا:
                </div>
                {GAS_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => onSelectPreset(preset)}
                    className="w-full text-right px-2.5 py-2 rounded-lg text-xs text-slate-200 hover:bg-slate-700 hover:text-amber-400 transition-colors flex flex-col gap-0.5"
                  >
                    <span className="font-semibold flex items-center justify-between">
                      <span>{preset.name}</span>
                      <span className="text-[10px] text-slate-400">
                        {preset.buildingType === 'residential' ? 'منزلي' : 'تجاري'}
                      </span>
                    </span>
                    <span className="text-[10px] text-slate-400 line-clamp-1">
                      {preset.description}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Guide Button */}
            <button
              onClick={onOpenGuide}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm"
              title="دليل القوانين والمعايير الهندسية"
            >
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">دليل المعايير</span>
            </button>

            {/* Saved Projects Button */}
            <button
              onClick={onOpenSavedProjects}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm"
              title="المشاريع المحفوظة"
            >
              <FolderDown className="w-4 h-4 text-indigo-400" />
              <span className="hidden sm:inline">المشاريع</span>
            </button>

            {/* Android / Mobile Download Button */}
            <button
              onClick={onOpenMobileInstall}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/40 transition-all shadow-sm active:scale-95 cursor-pointer"
              title="تحميل وتثبيت البرنامج على أندرويد (Android)"
            >
              <Smartphone className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>تحميل أندرويد (Android)</span>
            </button>

            {/* Direct Offline HTML Download */}
            <a
              href="/gas-calc-mobile.html"
              download="GasCalc_Offline_Android.html"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/40 transition-all shadow-sm active:scale-95 cursor-pointer"
              title="تنزيل ملف البرنامج المستقل للهاتف (يعمل بدون نت)"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span className="hidden md:inline">تنزيل نسخة الهاتف (ملف HTML)</span>
              <span className="md:hidden">ملف الهاتف</span>
            </a>

            {/* Print Technical Report */}
            <button
              onClick={onOpenReport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white shadow-md shadow-orange-600/20 transition-all active:scale-95"
              title="تصدير وطباعة تقرير الحسابات الهندسية"
            >
              <Printer className="w-4 h-4" />
              <span>تقرير فني (طباعة / PDF)</span>
            </button>

            {/* Reset */}
            <button
              onClick={onResetToDefaults}
              className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
              title="إعادة ضبط الحسابات"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sub-bar: Project metadata & Mode Switcher */}
        <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          {/* Mode Switch: Residential vs Commercial */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 w-fit">
            <button
              type="button"
              onClick={() => onBuildingTypeChange('residential')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                buildingType === 'residential'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>استعمال منزلي (شقق وفلل)</span>
            </button>
            <button
              type="button"
              onClick={() => onBuildingTypeChange('commercial')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                buildingType === 'commercial'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>استعمال تجاري (مطاعم ومحلات ومخابز)</span>
            </button>
          </div>

          {/* Project & Client Quick Inputs */}
          <div className="flex flex-1 sm:justify-end items-center gap-2">
            <input
              type="text"
              value={projectTitle}
              onChange={(e) => onProjectTitleChange(e.target.value)}
              placeholder="اسم المشروع / المنشأة..."
              className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs w-48 sm:w-56"
            />
            <input
              type="text"
              value={clientName}
              onChange={(e) => onClientNameChange(e.target.value)}
              placeholder="اسم العميل / المالك..."
              className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs w-36 sm:w-44"
            />
          </div>
        </div>

      </div>
    </header>
  );
};
