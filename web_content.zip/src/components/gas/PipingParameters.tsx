import React from 'react';
import { 
  Ruler, 
  CornerDownLeft, 
  GitBranch, 
  CircleDot, 
  Settings2, 
  Info,
  SlidersHorizontal,
  ShieldCheck
} from 'lucide-react';
import { GasParameters, GasFittings } from '../../types/gas';

interface PipingParametersProps {
  params: GasParameters;
  onUpdateParams: (params: Partial<GasParameters>) => void;
  fittingsEquivalentLengthM: number;
  totalEquivalentLengthM: number;
}

export const PipingParameters: React.FC<PipingParametersProps> = ({
  params,
  onUpdateParams,
  fittingsEquivalentLengthM,
  totalEquivalentLengthM,
}) => {
  const updateFittings = (key: keyof GasFittings, value: number) => {
    onUpdateParams({
      fittings: {
        ...params.fittings,
        [key]: Math.max(0, value),
      },
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center justify-center shrink-0">
            <Ruler className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>متغيرات الأنبوب النحاسي والأكواع والتوصيلات</span>
            </h2>
            <p className="text-xs text-slate-400">
              حساب الطول المستقيم ومقاومة الأكواع المكافئة (Fittings Equivalent Length)
            </p>
          </div>
        </div>

        {/* Dynamic Length Breakdown Badge */}
        <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800/80">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">الطول المستقيم</div>
            <div className="text-sm font-bold text-slate-200 font-mono">
              {params.pipeLengthM} <span className="text-xs text-slate-400 font-normal">متر</span>
            </div>
          </div>
          <div className="h-7 w-[1px] bg-slate-800" />
          <div className="text-right">
            <div className="text-[10px] text-amber-400 uppercase tracking-wider">مكافئ الأكواع</div>
            <div className="text-sm font-bold text-amber-400 font-mono">
              +{fittingsEquivalentLengthM} <span className="text-xs text-slate-400 font-normal">متر</span>
            </div>
          </div>
          <div className="h-7 w-[1px] bg-slate-800" />
          <div className="text-right">
            <div className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider">الطول الإجمالي (Leq)</div>
            <div className="text-sm font-bold text-cyan-400 font-mono">
              {totalEquivalentLengthM} <span className="text-xs text-slate-400 font-normal">متر</span>
            </div>
          </div>
        </div>
      </div>

      {/* Inputs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 my-4">
        
        {/* 1. Pipe Length */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-200">طول الأنبوب المستقيم</span>
            <Ruler className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="0.5"
              step="0.5"
              value={params.pipeLengthM}
              onChange={(e) =>
                onUpdateParams({ pipeLengthM: Math.max(0.1, Number(e.target.value)) })
              }
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm font-mono font-bold text-cyan-400 focus:outline-none focus:border-cyan-500"
            />
            <span className="text-xs font-semibold text-slate-400">متر (m)</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1.5">
            المسافة الهندسية من عداد الغاز إلى مجمع التوزيع/الجهاز
          </span>
        </div>

        {/* 2. 90° Elbows */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-200">عدد الأكواع 90° (Coude 90°)</span>
            <CornerDownLeft className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="0"
              step="1"
              value={params.fittings.elbows90}
              onChange={(e) => updateFittings('elbows90', Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-500"
            />
            <span className="text-xs font-semibold text-slate-400">كوع</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1.5">
            كل كوع 90° يضيف مقاومة مكافئة ≈ 30 × القطر الداخلي
          </span>
        </div>

        {/* 3. 45° Elbows */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-200">عدد الأكواع 45° (Coude 45°)</span>
            <CornerDownLeft className="w-4 h-4 text-amber-400 rotate-45" />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="0"
              step="1"
              value={params.fittings.elbows45}
              onChange={(e) => updateFittings('elbows45', Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-500"
            />
            <span className="text-xs font-semibold text-slate-400">كوع</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1.5">
            كل كوع 45° يضيف مقاومة مكافئة ≈ 15 × القطر الداخلي
          </span>
        </div>

        {/* 4. Tees & Valves */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-200">تفرعات تي (T) ومحابس غاز</span>
            <GitBranch className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">تفرع تي (T):</label>
              <input
                type="number"
                min="0"
                step="1"
                value={params.fittings.tees}
                onChange={(e) => updateFittings('tees', Number(e.target.value))}
                className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-indigo-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">محابس الغاز:</label>
              <input
                type="number"
                min="0"
                step="1"
                value={params.fittings.valves}
                onChange={(e) => updateFittings('valves', Number(e.target.value))}
                className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-emerald-400 focus:outline-none"
              />
            </div>
          </div>
          <span className="text-[10px] text-slate-500 mt-1.5">
            تفرع التي: 60 × D، محبس ربع دورة: 20 × D
          </span>
        </div>

      </div>

      {/* Advanced Technical Settings Accordion / Strip */}
      <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Max Allowable Pressure Drop Selector */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium">الحد الأقصى لهبوط الضغط المسموح (ΔP max):</span>
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            {[
              { val: 0.5, label: '0.5 mbar (صيانة مشددة)' },
              { val: 1.0, label: '1.0 mbar (معياري DTU 61.1)' },
              { val: 1.5, label: '1.5 mbar (تجاري)' },
              { val: 2.0, label: '2.0 mbar (شبكة أطول)' },
            ].map((item) => (
              <button
                key={item.val}
                type="button"
                onClick={() => onUpdateParams({ maxAllowablePressureDropMbar: item.val })}
                className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-colors ${
                  params.maxAllowablePressureDropMbar === item.val
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Gas Velocity Limit & Gas Standard Info */}
        <div className="flex items-center gap-2 text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>حد السرعة الآمن:</span>
          <span className="font-mono font-bold text-emerald-400">
            ≤ {params.maxVelocityMps} م/ث
          </span>
          <span className="text-[11px] text-slate-500">
            (لمنع الصفير والتآكل الميكانيكي)
          </span>
        </div>

      </div>

    </div>
  );
};
