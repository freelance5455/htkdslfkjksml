import React from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Gauge, 
  Disc3, 
  ArrowRight, 
  Activity, 
  Check, 
  Layers, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { CalculationSummary, GasParameters } from '../../types/gas';

interface ResultsOverviewProps {
  summary: CalculationSummary;
  params: GasParameters;
}

export const ResultsOverview: React.FC<ResultsOverviewProps> = ({ summary, params }) => {
  const {
    recommendedPipe,
    recommendedMeter,
    optimalResult,
    simultaneousFlowM3h,
    totalInstalledPowerKw,
    allMeterModels,
  } = summary;

  return (
    <div className="space-y-4">
      
      {/* Top Banner Status */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-cyan-950/60 border border-emerald-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>النتيجة الهندسية المعتمدة وفق صيغة رينوار (Renouard)</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                DTU 61.1 | EN 1057
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              تم حساب القطر الداخلي للنحاس ونوع العداد لمعدل تدفق متزامن:
              <strong className="text-emerald-400 font-mono mx-1">
                {simultaneousFlowM3h} m³/h
              </strong>
              (إجمالي قدرة مركبة: {totalInstalledPowerKw} kW)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold self-end sm:self-auto">
          <span className="text-slate-400">حالة الشبكة:</span>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            مطابقة للشروط الفنية
          </span>
        </div>
      </div>

      {/* Two Hero Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* Card 1: Recommended Copper Pipe Diameter */}
        <div className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 transition-all rounded-2xl p-5 shadow-md relative overflow-hidden flex flex-col justify-between">
          
          {/* Subtle glow background */}
          <div className="absolute -top-20 -left-20 w-44 h-44 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            {/* Badge & Title */}
            <div className="flex items-center justify-between mb-3">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Disc3 className="w-3.5 h-3.5" />
                أنبوب النحاس التجاري الموصى به
              </span>
              <span className="text-xs font-mono text-slate-400">
                المواصفة EN 1057
              </span>
            </div>

            {/* Giant Metric Display */}
            <div className="my-3 flex items-baseline gap-3">
              <div className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 font-mono tracking-tight">
                {recommendedPipe ? `${recommendedPipe.nominal} مم` : 'غير محدد'}
              </div>
              <div className="text-xs text-slate-400">
                <div>(خارجي {recommendedPipe?.externalDiameterMm} مم / داخلي {recommendedPipe?.internalDiameterMm} مم)</div>
                <div className="text-[11px] text-cyan-400/80">سمك الجدار: {recommendedPipe?.thicknessMm} مم</div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              أصغر قطر نحاسي يحقق هبوط ضغط آمن أقل من الحد المسموح به 
              ({params.maxAllowablePressureDropMbar} م.بار) مع سرعة تدفق منخفضة لمنع الضجيج.
            </p>

            {/* Technical Parameters Breakdown */}
            <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
              
              {/* Pressure Drop */}
              <div>
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="text-slate-400">هبوط الضغط الفعلي (ΔP):</span>
                  <span className="font-mono font-bold text-cyan-400">
                    {optimalResult ? optimalResult.pressureDropMbar : 0} م.بار 
                    <span className="text-slate-500 font-normal"> / {params.maxAllowablePressureDropMbar} م.بار مسموح</span>
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all rounded-full ${
                      (optimalResult?.pressureDropRatioPercent || 0) > 85
                        ? 'bg-amber-500'
                        : 'bg-cyan-500'
                    }`}
                    style={{
                      width: `${Math.min(100, optimalResult?.pressureDropRatioPercent || 0)}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 mt-0.5 font-mono">
                  <span>0 م.بار</span>
                  <span>مستهلك: {optimalResult?.pressureDropRatioPercent}% من السعة</span>
                  <span>{params.maxAllowablePressureDropMbar} م.بار</span>
                </div>
              </div>

              {/* Gas Velocity */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-emerald-400" />
                  سرعة تدفق الغاز (V):
                </span>
                <span className="font-mono font-bold text-emerald-400">
                  {optimalResult ? optimalResult.velocityMps : 0} م/ث
                  <span className="text-[10px] text-slate-500 font-normal mr-1">
                    (الحد الأقصى {params.maxVelocityMps} م/ث)
                  </span>
                </span>
              </div>

              {/* Total Equivalent Length */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">الطول الهيدروليكي المكافئ (Leq):</span>
                <span className="font-mono font-semibold text-slate-200">
                  {optimalResult ? optimalResult.totalEqLengthM : 0} متر
                  <span className="text-[10px] text-amber-400 font-normal mr-1">
                    (مستقيم: {params.pipeLengthM}م + أكواع: {optimalResult ? optimalResult.fittingsEqLengthM : 0}م)
                  </span>
                </span>
              </div>

            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>نوع النحاس: نحاس سحب صلب نصف قاسي (Cu-DHP)</span>
            <span className="text-emerald-400 font-medium">✓ آمن وهادئ</span>
          </div>

        </div>

        {/* Card 2: Recommended Gas Meter Type */}
        <div className="bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all rounded-2xl p-5 shadow-md relative overflow-hidden flex flex-col justify-between">
          
          {/* Subtle glow background */}
          <div className="absolute -top-20 -left-20 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            {/* Badge & Title */}
            <div className="flex items-center justify-between mb-3">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Gauge className="w-3.5 h-3.5" />
                نوع عداد الغاز الطبيعي المناسب
              </span>
              <span className="text-xs font-mono text-slate-400">
                المواصفة EN 1359
              </span>
            </div>

            {/* Giant Metric Display */}
            <div className="my-3 flex items-baseline gap-3">
              <div className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400 font-mono tracking-tight">
                {recommendedMeter ? recommendedMeter.code : 'G4'}
              </div>
              <div className="text-xs text-slate-400">
                <div>التدفق الاسمي: <strong className="text-slate-200 font-mono">{recommendedMeter?.qNom} m³/h</strong></div>
                <div>التدفق الأقصى (Qmax): <strong className="text-amber-400 font-mono">{recommendedMeter?.qMax} m³/h</strong></div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              {recommendedMeter?.typicalApplicationAr}
            </p>

            {/* Technical Specifications Breakdown */}
            <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
              
              {/* Meter Load percentage */}
              <div>
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="text-slate-400">نسبة تحميل العداد (Q_sim / Qmax):</span>
                  <span className="font-mono font-bold text-amber-400">
                    {recommendedMeter?.loadPercentage}% من سعة العداد
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all rounded-full ${
                      (recommendedMeter?.loadPercentage || 0) > 85
                        ? 'bg-rose-500'
                        : (recommendedMeter?.loadPercentage || 0) > 70
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{
                      width: `${Math.min(100, recommendedMeter?.loadPercentage || 0)}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 mt-0.5 font-mono">
                  <span>التدفق المتزامن: {simultaneousFlowM3h} m³/h</span>
                  <span>الحد الأقصى للعداد: {recommendedMeter?.qMax} m³/h</span>
                </div>
              </div>

              {/* Thread Connection Size */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">قطر وصلة العداد (Raccordement):</span>
                <span className="font-mono font-bold text-slate-200">
                  {recommendedMeter?.connectionSize}
                </span>
              </div>

              {/* Center distance */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">المسافة بين محور الوصلتين (Entre-axe):</span>
                <span className="font-mono font-semibold text-slate-200">
                  {recommendedMeter?.centerDistanceMm} مم
                </span>
              </div>

            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>نوع العداد: غشائي حجمي (Diaphragm Gas Meter)</span>
            <span className="text-amber-400 font-medium">✓ معتمد من شركة الغاز</span>
          </div>

        </div>

      </div>

      {/* Meter Comparison Mini-Ribbon */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5">
        <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center justify-between">
          <span>مقارنة العداد مع بقية فئات عدادات الغاز الطبيعي (EN 1359):</span>
          <span className="text-[11px] text-slate-500">
            التدفق الحالي المطلوب: {simultaneousFlowM3h} m³/h
          </span>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-1.5">
          {allMeterModels.map((meter) => {
            const isChosen = recommendedMeter?.code === meter.code;
            return (
              <div
                key={meter.code}
                className={`p-2 rounded-lg border text-center transition-all ${
                  isChosen
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/30 font-bold'
                    : meter.isSuitable
                    ? 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    : 'bg-slate-950/40 border-slate-800/40 text-slate-600'
                }`}
              >
                <div className="text-xs font-mono font-bold flex items-center justify-center gap-1">
                  <span>{meter.code}</span>
                  {isChosen && <Check className="w-3 h-3 text-amber-400" />}
                </div>
                <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                  ≤ {meter.qMax} m³/h
                </div>
                <div className="text-[9px] mt-0.5">
                  {meter.isSuitable ? (
                    isChosen ? (
                      <span className="text-amber-400 font-semibold">الموصى به</span>
                    ) : (
                      <span className="text-emerald-500">مناسب</span>
                    )
                  ) : (
                    <span className="text-rose-500/80">صغير جدًا</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
