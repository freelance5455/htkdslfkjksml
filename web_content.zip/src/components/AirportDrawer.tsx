import React, { useState } from 'react';
import {
  Building2,
  Lock,
  CheckCircle2,
  X,
  MapPin,
  TrendingUp,
  Globe2,
  ChevronRight
} from 'lucide-react';
import {
  AirportCity,
  INITIAL_CITIES,
  getAirportUpgradeCost
} from '../game/flightLogic';
import { sound } from '../game/sound';

interface AirportDrawerProps {
  unlockedCityIds: string[];
  airportLevels: Record<string, number>;
  cash: number;
  onUnlockCity: (city: AirportCity) => void;
  onUpgradeTerminal: (cityId: string) => void;
  onSelectCityOnMap: (city: AirportCity) => void;
  onClose: () => void;
}

export const AirportDrawer: React.FC<AirportDrawerProps> = ({
  unlockedCityIds,
  airportLevels,
  cash,
  onUnlockCity,
  onUpgradeTerminal,
  onSelectCityOnMap,
  onClose
}) => {
  type RegionFilter = 'all' | 'north-america' | 'europe' | 'asia' | 'south-america' | 'middle-east' | 'oceania' | 'africa';
  const [regionFilter, setRegionFilter] = useState<RegionFilter>('north-america');

  const filteredCities = INITIAL_CITIES.filter(city => {
    if (regionFilter === 'north-america') return city.continent === 'North America';
    if (regionFilter === 'south-america') return city.continent === 'South America';
    if (regionFilter === 'europe') return city.continent === 'Europe';
    if (regionFilter === 'middle-east') return city.continent === 'Middle East';
    if (regionFilter === 'asia') return city.continent === 'Asia';
    if (regionFilter === 'oceania') return city.continent === 'Oceania';
    if (regionFilter === 'africa') return city.continent === 'Africa';
    return true;
  });

  const totalUnlocked = unlockedCityIds.length;
  const filterUnlocked = filteredCities.filter(c => unlockedCityIds.includes(c.id)).length;

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#0a0b10] border-l border-[#27272a] shadow-2xl flex flex-col text-white animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-5 border-b border-[#27272a]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-mono text-base font-bold tracking-tight">GLOBAL AIRPORT NETWORK</h2>
            <div className="flex items-center gap-2 text-xs text-[#71717a] font-mono mt-0.5">
              <span>{totalUnlocked}/{INITIAL_CITIES.length} Airports Unlocked</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#a1a1aa]">View: {filterUnlocked}/{filteredCities.length}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Airports Panel"
            className="p-1.5 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-lg transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Region Filter Segmented Tabs */}
        <div className="flex items-center gap-1 mt-4 p-1 bg-[#12131a] rounded-lg border border-[#27272a] overflow-x-auto scrollbar-thin">
          <button
            onClick={() => setRegionFilter('north-america')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'north-america' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            N. America
          </button>
          <button
            onClick={() => setRegionFilter('europe')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'europe' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Europe
          </button>
          <button
            onClick={() => setRegionFilter('asia')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'asia' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Asia
          </button>
          <button
            onClick={() => setRegionFilter('south-america')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'south-america' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            S. America
          </button>
          <button
            onClick={() => setRegionFilter('middle-east')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'middle-east' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Mid East
          </button>
          <button
            onClick={() => setRegionFilter('africa')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'africa' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Africa
          </button>
          <button
            onClick={() => setRegionFilter('oceania')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'oceania' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Oceania
          </button>
          <button
            onClick={() => setRegionFilter('all')}
            className={`px-2.5 py-1 text-xs font-mono rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              regionFilter === 'all' ? 'bg-white text-black font-semibold' : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            All ({INITIAL_CITIES.length})
          </button>
        </div>
      </div>

      {/* Cities list */}
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-3">
        {filteredCities.map(city => {
          const isUnlocked = unlockedCityIds.includes(city.id);
          const terminalLevel = airportLevels[city.id] || 1;
          const terminalUpgradeCost = getAirportUpgradeCost(terminalLevel, city.tier);
          const canAffordUnlock = cash >= city.unlockCost;
          const canAffordTerminal = cash >= terminalUpgradeCost;

          return (
            <div
              key={city.id}
              className={`p-4 rounded-xl border transition-all ${
                isUnlocked
                  ? 'bg-[#111218] border-[#27272a]'
                  : 'bg-[#0d0e12] border-[#1e1f26] opacity-90'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                      isUnlocked ? 'bg-white text-black' : 'bg-[#181922] text-[#71717a]'
                    }`}
                  >
                    {city.code}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-sm text-white">{city.name}</h3>
                      {city.stateOrRegion && (
                        <span className="text-xs text-[#71717a]">({city.stateOrRegion})</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mt-0.5 font-mono">
                      <span>{city.country}</span>
                      <span aria-hidden="true">·</span>
                      <span>Tier {city.tier}</span>
                    </div>
                  </div>
                </div>

                {isUnlocked ? (
                  <button
                    onClick={() => {
                      onSelectCityOnMap(city);
                      sound.playRadarPing();
                    }}
                    className="p-1.5 text-[#71717a] hover:text-white hover:bg-[#18181b] rounded transition-colors"
                    title="Focus on Map"
                  >
                    <MapPin size={16} />
                  </button>
                ) : (
                  <div className="p-1 text-[#52525b]">
                    <Lock size={16} />
                  </div>
                )}
              </div>

              <p className="text-xs text-[#71717a] mt-2 leading-relaxed">
                {city.description}
              </p>

              {/* Action buttons */}
              <div className="mt-3 pt-3 border-t border-[#1e1f28] flex items-center justify-between">
                {isUnlocked ? (
                  <>
                    <div className="text-xs font-mono text-[#a1a1aa]">
                      <span>Terminal Lvl {terminalLevel}</span>
                      <span className="text-[#71717a] ml-1.5">(+{(terminalLevel - 1) * 15}% pay)</span>
                    </div>
                    <button
                      onClick={() => {
                        if (canAffordTerminal) {
                          onUpgradeTerminal(city.id);
                          sound.playUpgrade();
                        }
                      }}
                      disabled={!canAffordTerminal}
                      className={`px-3 py-1.5 rounded font-mono text-xs font-semibold transition-all ${
                        canAffordTerminal
                          ? 'bg-[#1e202b] hover:bg-[#282a3a] text-white border border-[#3f3f46]'
                          : 'bg-[#121318] text-[#52525b] border border-[#27272a] cursor-not-allowed'
                      }`}
                    >
                      Upgrade (${terminalUpgradeCost.toLocaleString()})
                    </button>
                  </>
                ) : (
                  <>
                    <span className="font-mono text-xs text-white font-semibold">
                      ${city.unlockCost.toLocaleString()}
                    </span>
                    <button
                      onClick={() => {
                        if (canAffordUnlock) {
                          onUnlockCity(city);
                          sound.playUnlockCity();
                        }
                      }}
                      disabled={!canAffordUnlock}
                      className={`px-3.5 py-1.5 rounded-lg font-mono text-xs font-semibold transition-all ${
                        canAffordUnlock
                          ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                          : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
                      }`}
                    >
                      UNLOCK AIRPORT
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
