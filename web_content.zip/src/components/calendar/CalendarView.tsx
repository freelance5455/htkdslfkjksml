import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  CheckCircle2,
  BookOpen,
  Pill,
  GraduationCap,
  Sparkles,
  Compass,
  Sun,
  X,
  Filter,
} from 'lucide-react';
import { formatTime24to12 } from '../../utils/prayerCalculator';
import { ScheduleItem } from '../../types';

const DAYS_NAMES = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export const CalendarView: React.FC = () => {
  const {
    scheduleItems,
    subjects,
    medications,
    prayersToday,
    toggleScheduleItemCompleted,
    addScheduleItem,
  } = useApp();

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [filterType, setFilterType] = useState<'all' | 'academic' | 'study' | 'meds' | 'exams'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // New item form state for selected date
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<ScheduleItem['type']>('personal');
  const [newStartTime, setNewStartTime] = useState('10:00');
  const [newDuration, setNewDuration] = useState(60);
  const [newSubjectId, setNewSubjectId] = useState('');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Helper for month navigation
  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(today.toISOString().split('T')[0]);
  };

  // Generate calendar grid days
  const calendarDays = useMemo(() => {
    const firstDayIndex = new Date(year, month, 1).getDay(); // 0 for Sunday
    const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const days: Array<{
      dateStr: string;
      dayNumber: number;
      isCurrentMonth: boolean;
      dayOfWeek: number;
    }> = [];

    // Preceding month days
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const d = prevMonthDays - i;
      const prevMonth = month === 0 ? 11 : month - 1;
      const prevYear = month === 0 ? year - 1 : year;
      const dateStr = `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({
        dateStr,
        dayNumber: d,
        isCurrentMonth: false,
        dayOfWeek: new Date(prevYear, prevMonth, d).getDay(),
      });
    }

    // Current month days
    for (let d = 1; d <= totalDaysInMonth; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({
        dateStr,
        dayNumber: d,
        isCurrentMonth: true,
        dayOfWeek: new Date(year, month, d).getDay(),
      });
    }

    // Trailing next month days to complete 6 weeks grid
    const remainingDays = 42 - days.length;
    for (let d = 1; d <= remainingDays; d++) {
      const nextMonth = month === 11 ? 0 : month + 1;
      const nextYear = month === 11 ? year + 1 : year;
      const dateStr = `${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({
        dateStr,
        dayNumber: d,
        isCurrentMonth: false,
        dayOfWeek: new Date(nextYear, nextMonth, d).getDay(),
      });
    }

    return days;
  }, [year, month]);

  // Map activities for each date
  const activitiesByDate = useMemo(() => {
    const map: Record<string, {
      items: ScheduleItem[];
      exams: typeof subjects;
      hasMeds: boolean;
    }> = {};

    calendarDays.forEach(({ dateStr, dayOfWeek }) => {
      // 1. Schedule items: recurring by dayOfWeek OR specific date
      const items = scheduleItems.filter((i) => {
        if (i.date) return i.date === dateStr;
        return i.dayOfWeek === dayOfWeek;
      });

      // 2. Exams
      const exams = subjects.filter((s) => s.examDate === dateStr);

      // 3. Meds active
      const hasMeds = medications.some((m) => m.active && m.startDate <= dateStr && m.endDate >= dateStr);

      map[dateStr] = { items, exams, hasMeds };
    });

    return map;
  }, [calendarDays, scheduleItems, subjects, medications]);

  // Selected date data
  const selectedDayData = useMemo(() => {
    const dateObj = new Date(selectedDateStr);
    const dayOfWeek = dateObj.getDay();
    const data = activitiesByDate[selectedDateStr] || { items: [], exams: [], hasMeds: false };

    // Filter items based on active filter
    let filteredItems = data.items;
    if (filterType === 'academic') {
      filteredItems = data.items.filter((i) => i.type === 'lecture' || i.type === 'section');
    } else if (filterType === 'study') {
      filteredItems = data.items.filter((i) => i.type === 'study');
    }

    return {
      dateStr: selectedDateStr,
      dateObj,
      dayOfWeek,
      items: filteredItems,
      allDayItems: data.items,
      exams: data.exams,
      hasMeds: data.hasMeds,
    };
  }, [selectedDateStr, activitiesByDate, filterType]);

  const handleAddCustomTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const [h, m] = newStartTime.split(':').map(Number);
    const endMinutes = h * 60 + m + newDuration;
    const endH = Math.floor(endMinutes / 60) % 24;
    const endM = endMinutes % 60;
    const endTime = `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`;

    const dateObj = new Date(selectedDateStr);

    addScheduleItem({
      title: newTitle.trim(),
      type: newType,
      dayOfWeek: dateObj.getDay(),
      date: selectedDateStr,
      startTime: newStartTime,
      endTime,
      durationMinutes: newDuration,
      subjectId: newSubjectId || undefined,
      isCompleted: false,
    });

    setNewTitle('');
    setShowAddModal(false);
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-700 via-pink-700 to-rose-600 p-6 text-white shadow-sm border border-rose-400/30">
        <div
          className="absolute inset-0 opacity-15 bg-cover bg-center pointer-events-none mix-blend-overlay"
          style={{ backgroundImage: `url('/public/assets/aistudio/images_5d51feea.jpg')` }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-200 text-xs font-semibold mb-1">
              <CalendarIcon className="w-4 h-4 text-pink-300" />
              <span>التقويم الشهري الذكي وتوزيع المهام</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight">تقويم المهام والمذاكرة</h2>
            <p className="text-xs text-rose-100/90 mt-1 max-w-xl">
              عرض شامل لكافة أيام الشهر، توزيع المحاضرات والسكاشن، مواعيد الامتحانات، ومتابعة ما تم إنجازه
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={handleToday}
              className="px-3.5 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold backdrop-blur-md border border-white/30 transition-all shadow-xs"
            >
              اليوم الحالي
            </button>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-3.5 py-2 rounded-xl bg-white text-rose-800 hover:bg-rose-50 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مهمة لتاريخ محدد</span>
            </button>
          </div>
        </div>
      </div>

      {/* Month Navigator & Filters Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-[#180d15] p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
        {/* Month Selector */}
        <div className="flex items-center gap-3">
          <button
            onClick={handlePrevMonth}
            className="p-2 rounded-xl border border-rose-200/60 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-rose-200"
            title="الشهر السابق"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-rose-50 min-w-[140px] text-center">
            {currentDate.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' })}
          </h3>

          <button
            onClick={handleNextMonth}
            className="p-2 rounded-xl border border-rose-200/60 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-rose-200"
            title="الشهر القادم"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center flex-wrap gap-1.5 text-xs">
          <span className="text-slate-400 text-[11px] ml-1 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            فلترة:
          </span>
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
              filterType === 'all'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/60 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60'
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setFilterType('academic')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
              filterType === 'academic'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/60 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60'
            }`}
          >
            المحاضرات والسكاشن
          </button>
          <button
            onClick={() => setFilterType('study')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
              filterType === 'study'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/60 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60'
            }`}
          >
            جلسات المذاكرة
          </button>
        </div>
      </div>

      {/* Main Grid + Selected Day Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Left: Monthly Calendar Grid (2 Cols) */}
        <div className="lg:col-span-2 bg-white dark:bg-[#180d15] rounded-3xl border border-rose-100 dark:border-rose-950/60 p-4 sm:p-5 shadow-xs overflow-hidden">
          {/* Day of week headers */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2 text-center text-xs font-bold text-rose-700 dark:text-rose-300 pb-2 mb-2 border-b border-rose-50 dark:border-rose-950/50">
            {DAYS_NAMES.map((name) => (
              <div key={name} className="py-1">
                {name}
              </div>
            ))}
          </div>

          {/* Calendar Day Cells */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2">
            {calendarDays.map((day) => {
              const data = activitiesByDate[day.dateStr] || { items: [], exams: [], hasMeds: false };
              const isSelected = selectedDateStr === day.dateStr;
              const isToday = day.dateStr === todayStr;

              const lecturesCount = data.items.filter((i) => i.type === 'lecture').length;
              const sectionsCount = data.items.filter((i) => i.type === 'section').length;
              const studyCount = data.items.filter((i) => i.type === 'study').length;
              const examsCount = data.exams.length;

              return (
                <button
                  key={day.dateStr}
                  onClick={() => setSelectedDateStr(day.dateStr)}
                  className={`min-h-[75px] sm:min-h-[92px] p-1.5 sm:p-2 rounded-2xl border text-right transition-all flex flex-col justify-between group relative ${
                    isSelected
                      ? 'border-rose-500 bg-rose-50/80 dark:bg-rose-950/60 ring-2 ring-rose-500/30 shadow-xs'
                      : isToday
                      ? 'border-rose-300 dark:border-rose-800 bg-rose-50/30 dark:bg-rose-950/20'
                      : day.isCurrentMonth
                      ? 'border-slate-100 dark:border-rose-950/40 bg-white dark:bg-[#1a0f18] hover:border-rose-200 dark:hover:border-rose-900'
                      : 'border-transparent bg-slate-50/40 dark:bg-rose-950/10 opacity-40'
                  }`}
                >
                  {/* Day Number and Today Badge */}
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-xs sm:text-sm font-bold font-mono ${
                        isToday
                          ? 'w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center'
                          : day.isCurrentMonth
                          ? 'text-slate-900 dark:text-rose-100'
                          : 'text-slate-400 dark:text-rose-400/50'
                      }`}
                    >
                      {day.dayNumber}
                    </span>

                    {examsCount > 0 && (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-rose-600 text-white" title="موعد امتحان!">
                        امتحان
                      </span>
                    )}
                  </div>

                  {/* Badges / Dots of Scheduled activities */}
                  <div className="space-y-1 w-full my-1">
                    {/* Academic Badges */}
                    {lecturesCount > 0 && (
                      <div className="text-[10px] truncate px-1 py-0.5 rounded bg-rose-100/80 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 font-semibold leading-none">
                        {lecturesCount} مح
                      </div>
                    )}
                    {sectionsCount > 0 && (
                      <div className="text-[10px] truncate px-1 py-0.5 rounded bg-pink-100/80 dark:bg-pink-900/60 text-pink-800 dark:text-pink-200 font-semibold leading-none">
                        {sectionsCount} سك
                      </div>
                    )}
                    {studyCount > 0 && (
                      <div className="text-[10px] truncate px-1 py-0.5 rounded bg-fuchsia-100/80 dark:bg-fuchsia-900/60 text-fuchsia-800 dark:text-fuchsia-200 font-semibold leading-none">
                        {studyCount} مذاكرة
                      </div>
                    )}
                  </div>

                  {/* Bottom indicators */}
                  <div className="flex items-center justify-between w-full text-[9px] text-slate-400">
                    {data.hasMeds && (
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500" title="أدوية مجدولة" />
                    )}
                    {data.items.length > 0 && (
                      <span className="font-mono text-slate-400 mr-auto">
                        {data.items.filter((i) => i.isCompleted).length}/{data.items.length}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Day Inspector & Task Manager (1 Col) */}
        <div className="bg-white dark:bg-[#180d15] rounded-3xl border border-rose-100 dark:border-rose-950/60 p-5 shadow-xs space-y-5">
          {/* Header */}
          <div className="pb-3 border-b border-rose-100/60 dark:border-rose-950/60 flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold text-rose-600 dark:text-rose-400">
                تفاصيل اليوم المختار
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-rose-50">
                {new Date(selectedDateStr).toLocaleDateString('ar-EG', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </h4>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="p-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-xs"
              title="إضافة نشاط لهذا اليوم"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Exam Alert if any */}
          {selectedDayData.exams.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-rose-600 text-white text-xs font-semibold space-y-1 shadow-xs animate-in fade-in">
              <div className="flex items-center gap-1.5 font-bold">
                <Sparkles className="w-4 h-4" />
                <span>موعد امتحان مجدول اليوم!</span>
              </div>
              {selectedDayData.exams.map((sub) => (
                <div key={sub.id} className="text-rose-100">
                  • امتحان مادة: {sub.name} ({sub.code})
                </div>
              ))}
            </div>
          )}

          {/* Day Items List */}
          <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-0.5">
            {selectedDayData.items.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                لا توجد مهام أو محاضرات مجدولة لهذا التاريخ.
                <button
                  onClick={() => setShowAddModal(true)}
                  className="block mx-auto mt-2 text-rose-600 dark:text-rose-400 hover:underline font-bold"
                >
                  + أضف مهمة جديدة الآن
                </button>
              </div>
            ) : (
              selectedDayData.items.map((item) => {
                const sub = subjects.find((s) => s.id === item.subjectId);

                return (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl border transition-all ${
                      item.isCompleted
                        ? 'bg-rose-50/30 dark:bg-rose-950/20 border-rose-200/50 dark:border-rose-900/40 opacity-75'
                        : 'bg-white dark:bg-[#1a0f18] border-rose-100 dark:border-rose-950/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5">
                        <button
                          onClick={() => toggleScheduleItemCompleted(item.id)}
                          className={`w-5 h-5 rounded-lg border mt-0.5 flex items-center justify-center shrink-0 transition-colors ${
                            item.isCompleted
                              ? 'bg-rose-600 border-rose-600 text-white'
                              : 'border-slate-300 dark:border-rose-900/60'
                          }`}
                        >
                          {item.isCompleted && <CheckCircle2 className="w-3.5 h-3.5" />}
                        </button>

                        <div>
                          <div
                            className={`text-xs font-bold leading-tight ${
                              item.isCompleted
                                ? 'line-through text-slate-400'
                                : 'text-slate-900 dark:text-rose-100'
                            }`}
                          >
                            {item.title}
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-rose-200/70 mt-1">
                            <span className="font-mono tabular-nums font-semibold text-rose-600 dark:text-rose-400">
                              {formatTime24to12(item.startTime)}
                            </span>
                            <span>·</span>
                            <span>{item.durationMinutes} دقيقة</span>
                            {sub && (
                              <>
                                <span>·</span>
                                <span style={{ color: sub.color }} className="font-medium">
                                  {sub.code}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Item Type Badge */}
                      <span className="text-[10px] px-2 py-0.5 rounded font-semibold shrink-0 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300">
                        {item.type === 'lecture'
                          ? 'محاضرة'
                          : item.type === 'section'
                          ? 'سكشن'
                          : item.type === 'study'
                          ? 'مذاكرة'
                          : 'التزام'}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Add Task for Date Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-[#180d15] rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-100 dark:border-rose-950/80">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100 dark:border-rose-950/60 mb-4">
              <h3 className="font-bold text-base text-slate-900 dark:text-rose-50">
                إضافة مهمة لتاريخ ({selectedDateStr})
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-rose-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCustomTask} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  عنوان المهمة أو المحاضرة *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: مراجعة الباب الثالث / تسليم التكليف"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    النوع
                  </label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as ScheduleItem['type'])}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  >
                    <option value="study">جلسة مذاكرة</option>
                    <option value="lecture">محاضرة</option>
                    <option value="section">سكشن</option>
                    <option value="personal">التزام شخصي</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    المادة المرتبطة (اختياري)
                  </label>
                  <select
                    value={newSubjectId}
                    onChange={(e) => setNewSubjectId(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  >
                    <option value="">عام / غير محدد</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    وقت البدء
                  </label>
                  <input
                    type="time"
                    required
                    value={newStartTime}
                    onChange={(e) => setNewStartTime(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    المدة (بالدقائق)
                  </label>
                  <input
                    type="number"
                    min={15}
                    max={360}
                    step={15}
                    value={newDuration}
                    onChange={(e) => setNewDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-rose-100 dark:border-rose-950/60">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-600 dark:text-rose-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
                >
                  حفظ المهمة في التقويم
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
