import React, { useState, useMemo } from 'react';
import { ReadingSession, Book } from '../../types';
import { CoverImage } from '../common/CoverImage';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  BookOpen,
  Sparkles,
  ChevronRight as ChevronRightIcon,
  X,
  Flame,
  Award,
} from 'lucide-react';

interface CalendarViewProps {
  sessions: ReadingSession[];
  books: Book[];
  onOpenBookDetail: (book: Book) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  sessions,
  books,
  onOpenBookDetail,
}) => {
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [selectedDayString, setSelectedDayString] = useState<string>(() => {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(
      today.getDate()
    ).padStart(2, '0')}`;
  });

  // Modal: "Detalle de actividad del día / libro" (Requirement 8)
  const [activeDayDetail, setActiveDayDetail] = useState<{
    book: Book;
    date: string;
    daySessions: ReadingSession[];
  } | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0 to 11

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  // Build calendar matrix
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = (new Date(year, month, 1).getDay() + 6) % 7; // Monday = 0

  // Sessions map by YYYY-MM-DD
  const sessionsByDate = useMemo(() => {
    const map = new Map<string, ReadingSession[]>();
    sessions.forEach((s) => {
      const dateKey = s.date.slice(0, 10);
      const list = map.get(dateKey) || [];
      list.push(s);
      map.set(dateKey, list);
    });
    return map;
  }, [sessions]);

  // Selected day sessions and statistics
  const selectedDaySessions = useMemo(() => {
    return sessionsByDate.get(selectedDayString) || [];
  }, [sessionsByDate, selectedDayString]);

  // Read books list for current month (Large tactile cards carousel like Screen 3 in reference)
  const monthReadBooks = useMemo(() => {
    const map = new Map<string, { book: Book; lastDate: string; totalMins: number; totalPages: number; sessions: ReadingSession[] }>();
    sessions.forEach((s) => {
      const d = new Date(s.date);
      if (d.getFullYear() === year && d.getMonth() === month) {
        const b = books.find((bk) => bk.id === s.bookId);
        if (b) {
          const entry = map.get(b.id) || {
            book: b,
            lastDate: s.date.slice(0, 10),
            totalMins: 0,
            totalPages: 0,
            sessions: [],
          };
          entry.totalMins += s.durationMinutes || 0;
          entry.totalPages += s.pagesRead || 0;
          entry.sessions.push(s);
          if (s.date > entry.lastDate) entry.lastDate = s.date.slice(0, 10);
          map.set(b.id, entry);
        }
      }
    });

    return Array.from(map.values()).sort(
      (a, b) => new Date(b.lastDate).getTime() - new Date(a.lastDate).getTime()
    );
  }, [sessions, books, year, month]);

  const monthName = new Intl.DateTimeFormat('es-ES', { month: 'long', year: 'numeric' }).format(currentDate);
  const dayNames = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];

  // Helper to open day activity detail
  const handleOpenActivityDetail = (book: Book, date: string, daySessions: ReadingSession[]) => {
    setActiveDayDetail({
      book,
      date,
      daySessions,
    });
  };

  return (
    <div className="space-y-7 pb-16 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
            Calendario
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Monitorea tus días de lectura y consulta la actividad detallada
          </p>
        </div>

        {/* Month Navigation (< Junio 2026 >) */}
        <div className="flex items-center gap-2 self-end sm:self-auto glass-panel rounded-xl px-3 py-1.5 border border-white/10">
          <button
            onClick={handlePrevMonth}
            className="p-1 rounded-lg hover:bg-white/10 text-zinc-300 hover:text-white"
            aria-label="Mes anterior"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-semibold text-white capitalize min-w-[130px] text-center">
            {monthName}
          </span>
          <button
            onClick={handleNextMonth}
            className="p-1 rounded-lg hover:bg-white/10 text-zinc-300 hover:text-white"
            aria-label="Mes siguiente"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 1. CALENDARIO MENSUAL (Screen 3 in reference) */}
      <div className="glass-panel rounded-3xl p-4 sm:p-6 border border-white/10 shadow-2xl">
        {/* Days of Week Header */}
        <div className="grid grid-cols-7 gap-1 text-center mb-2.5">
          {dayNames.map((d, idx) => (
            <span key={idx} className="text-xs font-bold text-zinc-400 uppercase py-1">
              {d}
            </span>
          ))}
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5">
          {/* Blank offset for first day */}
          {Array.from({ length: firstDayOfWeek }).map((_, i) => (
            <div key={`blank-${i}`} className="aspect-square opacity-0" />
          ))}

          {/* Days of Month */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const daySessions = sessionsByDate.get(dateKey) || [];
            const hasActivity = daySessions.length > 0;
            const isSelected = selectedDayString === dateKey;
            const firstBook = hasActivity ? books.find((b) => b.id === daySessions[0].bookId) : null;

            return (
              <button
                key={dayNum}
                onClick={() => {
                  setSelectedDayString(dateKey);
                  if (firstBook) {
                    handleOpenActivityDetail(firstBook, dateKey, daySessions);
                  }
                }}
                className={`aspect-square rounded-2xl p-1.5 sm:p-2 flex flex-col justify-between transition-all relative overflow-hidden group cursor-pointer ${
                  isSelected
                    ? 'bg-white/20 border-2 border-white/60 shadow-[0_0_15px_rgba(255,255,255,0.25)]'
                    : hasActivity
                    ? 'bg-white/[0.06] hover:bg-white/[0.12] border border-white/20'
                    : 'bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.04]'
                }`}
              >
                {/* Day number */}
                <span
                  className={`text-xs font-semibold tabular-nums self-start ${
                    isSelected
                      ? 'text-white font-bold'
                      : hasActivity
                      ? 'text-white'
                      : 'text-zinc-500'
                  }`}
                >
                  {dayNum}
                </span>

                {/* Cover thumbnail / activity indicator (Tactile & visible!) */}
                {hasActivity && (
                  <div className="w-full flex items-end justify-between mt-auto">
                    {firstBook?.coverUrl ? (
                      <div className="w-6 h-8 sm:w-7 sm:h-9 rounded-md overflow-hidden shrink-0 shadow-md border border-white/20 group-hover:scale-110 transition-transform">
                        <img
                          src={firstBook.coverUrl}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <span className="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.5)]" />
                    )}
                    <span className="text-[10px] font-mono text-zinc-300 font-semibold hidden sm:inline tabular-nums">
                      {daySessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0)}p
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. LIBROS LEÍDOS: CAROUSEL HORIZONTAL DE PORTADAS GRANDES Y TÁCTILES (Screen 3 in reference) */}
      <section aria-labelledby="heading-libros-leidos" className="space-y-3">
        <h2 id="heading-libros-leidos" className="text-xs font-bold tracking-wider uppercase text-zinc-400 px-1">
          Libros leídos en {monthName} ({monthReadBooks.length})
        </h2>

        {monthReadBooks.length === 0 ? (
          <div className="glass-panel-subtle rounded-2xl p-6 text-center text-zinc-400 text-xs">
            No se han registrado sesiones de lectura en este mes aún.
          </div>
        ) : (
          <div className="flex items-stretch gap-4 overflow-x-auto pb-3 pt-1 px-1 no-scrollbar select-none">
            {monthReadBooks.map(({ book, lastDate, totalMins, totalPages, sessions: bookDaySessions }) => (
              <div
                key={book.id}
                onClick={() => handleOpenActivityDetail(book, lastDate, bookDaySessions)}
                className="w-32 sm:w-36 shrink-0 glass-panel-interactive rounded-2xl p-2.5 border border-white/10 shadow-xl cursor-pointer group flex flex-col justify-between"
                title={`Ver actividad de ${book.title}`}
              >
                {/* Large Tactile Cover */}
                <div className="w-full aspect-[2/3] relative rounded-xl overflow-hidden shadow-lg group-hover:scale-[1.03] transition-transform duration-300">
                  <CoverImage
                    url={book.coverUrl}
                    title={book.title}
                    author={book.author}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Information below cover */}
                <div className="mt-2.5 space-y-1">
                  <p className="text-[11px] text-zinc-400 font-medium truncate">
                    {new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' }).format(
                      new Date(lastDate + 'T00:00:00')
                    )}
                  </p>
                  <p className="text-[11px] font-mono text-zinc-300 font-semibold truncate tabular-nums">
                    {totalMins} min • {totalPages} pág.
                  </p>

                  {/* Mini Progress Bar */}
                  <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden mt-1.5">
                    <div
                      className="h-full bg-white rounded-full"
                      style={{ width: `${book.progress || 0}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono block text-right">
                    {book.progress || 0}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 3. ACTIVIDAD DEL DÍA (Screen 3 in reference) */}
      <section aria-labelledby="heading-actividad-dia" className="space-y-3">
        <h2 id="heading-actividad-dia" className="text-xs font-bold tracking-wider uppercase text-zinc-400 px-1">
          Actividad del día (
          {new Intl.DateTimeFormat('es-ES', {
            day: 'numeric',
            month: 'long',
          }).format(new Date(selectedDayString + 'T00:00:00'))}
          )
        </h2>

        {selectedDaySessions.length === 0 ? (
          <div className="glass-panel-subtle rounded-2xl p-6 text-center text-zinc-400 text-xs">
            No hay sesiones registradas en este día. Selecciona un día con actividad para inspeccionarlo.
          </div>
        ) : (
          <div className="space-y-3">
            {selectedDaySessions.map((s) => {
              const b = books.find((bk) => bk.id === s.bookId);
              if (!b) return null;

              return (
                <div
                  key={s.id}
                  onClick={() => handleOpenActivityDetail(b, selectedDayString, [s])}
                  className="glass-panel-interactive rounded-2xl p-3.5 sm:p-4 border border-white/10 shadow-lg cursor-pointer flex items-center gap-4 group"
                >
                  {/* Large tactile cover on left */}
                  <div className="w-14 sm:w-16 aspect-[2/3] shrink-0 rounded-xl overflow-hidden shadow-md group-hover:scale-105 transition-transform">
                    <CoverImage
                      url={b.coverUrl}
                      title={b.title}
                      author={b.author}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-sm font-bold text-white group-hover:text-zinc-200 transition-colors truncate">
                      {b.title}
                    </h3>
                    <p className="text-xs text-zinc-400 truncate">{b.author}</p>

                    <div className="flex items-center gap-3 text-xs text-zinc-300 pt-1">
                      <span className="flex items-center gap-1 font-mono text-zinc-300">
                        <Clock className="w-3.5 h-3.5 text-zinc-300" />
                        {s.durationMinutes} min
                      </span>
                      <span>·</span>
                      <span className="font-mono text-zinc-300">{s.pagesRead} páginas</span>
                    </div>

                    <p className="text-[11px] text-zinc-500 font-mono">
                      {new Intl.DateTimeFormat('es-ES', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      }).format(new Date(selectedDayString + 'T00:00:00'))}{' '}
                      • {s.startTime || '19:00'}
                    </p>
                  </div>

                  <ChevronRightIcon className="w-5 h-5 text-zinc-500 group-hover:text-white transition-colors shrink-0" />
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 4. MODAL: DETALLE DE ACTIVIDAD DEL DÍA / LIBRO (Requirement 8) */}
      {activeDayDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
          <div className="w-full max-w-lg glass-panel rounded-3xl p-5 sm:p-7 border border-white/15 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                <span>Detalle de actividad de lectura</span>
              </span>
              <button
                onClick={() => setActiveDayDetail(null)}
                className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/15 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Large Hero Book Cover & Info */}
            <div className="flex flex-col items-center text-center space-y-3">
              <div
                onClick={() => {
                  onOpenBookDetail(activeDayDetail.book);
                  setActiveDayDetail(null);
                }}
                className="w-36 sm:w-44 aspect-[2/3] rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.9)] ring-1 ring-white/20 cursor-pointer hover:scale-105 transition-transform"
                title="Tocar para abrir ficha completa del libro"
              >
                <CoverImage
                  url={activeDayDetail.book.coverUrl}
                  title={activeDayDetail.book.title}
                  author={activeDayDetail.book.author}
                  className="w-full h-full object-cover"
                />
              </div>

              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">
                  {activeDayDetail.book.title}
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">{activeDayDetail.book.author}</p>
                <p className="text-xs font-semibold text-zinc-300 mt-1 capitalize">
                  {new Intl.DateTimeFormat('es-ES', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  }).format(new Date(activeDayDetail.date + 'T00:00:00'))}
                </p>
              </div>
            </div>

            {/* Statistics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
              <div className="glass-panel-subtle rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-zinc-400 block font-medium">Tiempo leído</span>
                <span className="text-base font-bold text-white font-mono tabular-nums">
                  {activeDayDetail.daySessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0)} min
                </span>
              </div>

              <div className="glass-panel-subtle rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-zinc-400 block font-medium">Páginas leídas</span>
                <span className="text-base font-bold text-white font-mono tabular-nums">
                  {activeDayDetail.daySessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0)}
                </span>
              </div>

              <div className="glass-panel-subtle rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-zinc-400 block font-medium">Progreso</span>
                <span className="text-base font-bold text-white font-mono tabular-nums">
                  {activeDayDetail.book.progress || 0}%
                </span>
              </div>

              <div className="glass-panel-subtle rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-zinc-400 block font-medium">Sesiones</span>
                <span className="text-base font-bold text-white font-mono tabular-nums">
                  {activeDayDetail.daySessions.length}
                </span>
              </div>
            </div>

            {/* Sessions Detail Breakdown */}
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-300 block">
                Desglose de sesiones
              </span>

              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {activeDayDetail.daySessions.map((session, sIdx) => {
                  const startTime = session.startTime || '19:00';
                  // Calculate estimated finish time if not explicitly stored
                  const duration = session.durationMinutes || 30;
                  const [startH, startM] = startTime.split(':').map(Number);
                  const totalStartMin = (startH || 19) * 60 + (startM || 0);
                  const endMin = totalStartMin + duration;
                  const endH = Math.floor(endMin / 60) % 24;
                  const endM = endMin % 60;
                  const endTime = `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`;

                  return (
                    <div
                      key={session.id || sIdx}
                      className="p-3 rounded-2xl bg-white/[0.04] border border-white/5 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="text-white">Sesión #{sIdx + 1}</span>
                        <span className="text-white font-mono">
                          {startTime} → {endTime}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-zinc-400">
                        <span>
                          Páginas: {session.startPage} a {session.endPage} ({session.pagesRead} pág.)
                        </span>
                        <span>{session.durationMinutes} minutos</span>
                      </div>

                      {session.notes && (
                        <p className="text-[11px] text-zinc-400 bg-white/[0.02] p-2 rounded-xl italic">
                          "{session.notes}"
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  onOpenBookDetail(activeDayDetail.book);
                  setActiveDayDetail(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg transition-all"
              >
                Abrir ficha del libro
              </button>
              <button
                onClick={() => setActiveDayDetail(null)}
                className="px-5 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/10 text-zinc-300 text-xs font-semibold transition-all"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
