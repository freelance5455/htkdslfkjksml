import React from 'react';
import { Code, Lightbulb, PenTool, Sparkles, Compass, Rocket } from 'lucide-react';

interface SuggestionsProps {
  onSelectSuggestion: (text: string) => void;
}

export const Suggestions: React.FC<SuggestionsProps> = ({ onSelectSuggestion }) => {
  const suggestions = [
    {
      icon: Code,
      title: 'البرمجة والأكواد',
      prompt: 'اكتب لي كود دالة بلغة JavaScript لحساب الفروق بين تاريخين مع توثيق وشرح الخطوات.',
      accent: 'from-blue-600/20 to-cyan-500/10 border-blue-600/30 text-cyan-300',
    },
    {
      icon: Lightbulb,
      title: 'شرح وتبسيط المفاهيم',
      prompt: 'اشرح لي كيف تعمل نماذج الذكاء الاصطناعي التوليدي LLM بأسلوب مبسط ومفهوم مع أمثلة عملية.',
      accent: 'from-amber-600/20 to-yellow-500/10 border-amber-500/30 text-amber-300',
    },
    {
      icon: PenTool,
      title: 'كتابة إبداعية واحترافية',
      prompt: 'ساعدني في صياغة بريد إلكتروني رسمي باللغة العربية للتقديم على وظيفة مطور برمجيات.',
      accent: 'from-emerald-600/20 to-teal-500/10 border-emerald-500/30 text-emerald-300',
    },
    {
      icon: Rocket,
      title: 'نصائح وتطوير التطبيقات',
      prompt: 'ما هي أفضل الممارسات لتصميم واجهات مستخدم متوافقة مع هواتف أندرويد وتدعم اللغة العربية RTL؟',
      accent: 'from-purple-600/20 to-blue-500/10 border-purple-500/30 text-purple-300',
    },
  ];

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 sm:py-8 text-center animate-fade-in">
      {/* Brand Hero Greeting */}
      <div className="mb-6 sm:mb-8">
        <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-blue-700 via-blue-600 to-cyan-400 shadow-xl shadow-blue-600/30 mb-4 ring-2 ring-blue-400/30">
          <Sparkles className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
          مرحباً بك في <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">Mostafa AI</span>
        </h2>
        <p className="text-sm sm:text-base text-slate-300/80 max-w-md mx-auto leading-relaxed">
          مساعدك الذكي العربي المدعوم بتقنية Google Gemini. اسألني في البرمجة، الكتابة، الشرح، أو أي فكرة تدور ببالك!
        </p>
      </div>

      {/* Grid of Starter Prompts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 text-right">
        {suggestions.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={() => onSelectSuggestion(item.prompt)}
              className={`p-3.5 rounded-2xl bg-gradient-to-br ${item.accent} bg-[#0D1630] border hover:border-blue-400/60 hover:bg-[#121F45] transition-all duration-200 active:scale-[0.98] group flex flex-col justify-between text-right`}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 rounded-lg bg-blue-950/70 border border-blue-800/40">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-slate-200 group-hover:text-blue-200">
                  {item.title}
                </span>
              </div>
              <p className="text-xs text-slate-400 group-hover:text-slate-300 line-clamp-2 leading-relaxed">
                {item.prompt}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
