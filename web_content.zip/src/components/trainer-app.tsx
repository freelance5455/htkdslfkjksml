import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { Square } from "chess.js";
import {
  ArrowDownUp,
  ChevronLeft,
  Flame,
  RotateCcw,
  Undo2,
} from "lucide-react";
import { ChessBoard, squareFromPoint, type SquareMark } from "@/components/chess-board";
import { PieceGlyph, pieceSrc } from "@/components/piece-glyph";
import { generatePosition, SHOWCASE_FEN, type GeneratedPosition } from "@/lib/chess/generate";
import {
  formatClock,
  pieceName,
  piecesFromFen,
  samePiece,
  scorePosition,
  type BoardMap,
  type BoardPiece,
  type Score,
} from "@/lib/chess/position";
import {
  DEFAULT_DURATION,
  DURATIONS,
  type Difficulty,
  type DurationSec,
} from "@/lib/chess/types";
import { cn } from "@/lib/cn";
import {
  applySession,
  averageAccuracy,
  defaultSave,
  loadSave,
  visibleStreak,
  writeSave,
  type Save,
  type SessionRecord,
} from "@/lib/progress";

type Phase = "home" | "study" | "recall" | "result";
type Review = "compare" | "solution" | "yours";
type Arm = { piece: BoardPiece; from: Square | null };

const DIFFICULTIES: { id: Difficulty; label: string; hint: string }[] = [
  { id: "beginner", label: "Beginner", hint: "Fewer pieces, and a longer look." },
  { id: "intermediate", label: "Intermediate", hint: "A middlegame you might actually reach." },
  { id: "advanced", label: "Advanced", hint: "A crowded board. A short glance." },
];

const PALETTE: BoardPiece[] = [
  { color: "w", type: "k" },
  { color: "w", type: "q" },
  { color: "w", type: "r" },
  { color: "w", type: "b" },
  { color: "w", type: "n" },
  { color: "w", type: "p" },
  { color: "b", type: "k" },
  { color: "b", type: "q" },
  { color: "b", type: "r" },
  { color: "b", type: "b" },
  { color: "b", type: "n" },
  { color: "b", type: "p" },
];

export function TrainerApp() {
  const showcase = useMemo(() => piecesFromFen(SHOWCASE_FEN), []);
  const [save, setSave] = useState<Save>(defaultSave);
  const [hydrated, setHydrated] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>("intermediate");
  const [duration, setDuration] = useState<DurationSec>(5);
  const [phase, setPhase] = useState<Phase>("home");
  const [puzzle, setPuzzle] = useState<GeneratedPosition | null>(null);
  const [puzzlePieces, setPuzzlePieces] = useState<BoardMap>(showcase);
  const [userPieces, setUserPieces] = useState<BoardMap>({});
  const [flipped, setFlipped] = useState(false);
  const [remaining, setRemaining] = useState(duration * 1000);
  const [fading, setFading] = useState(false);
  const [studiedMs, setStudiedMs] = useState(0);
  const [recallElapsed, setRecallElapsed] = useState(0);
  const [score, setScore] = useState<Score | null>(null);
  const [review, setReview] = useState<Review>("compare");
  const [newBest, setNewBest] = useState(false);
  const [armed, setArmed] = useState<Arm | null>(null);
  const [lifted, setLifted] = useState<Square | null>(null);
  const [undoCount, setUndoCount] = useState(0);
  const [confirmReset, setConfirmReset] = useState(false);

  const boardRef = useRef<BoardMap>({});
  const undoStack = useRef<BoardMap[]>([]);
  const recallStartRef = useRef(0);
  const remainingRef = useRef(duration * 1000);
  const fadeTimer = useRef<number | null>(null);
  const studyTimer = useRef<number | null>(null);
  const gesture = useRef(false);
  const ghostRef = useRef<HTMLDivElement>(null);
  const ghostImgRef = useRef<HTMLImageElement>(null);
  const ghostPos = useRef({ x: -200, y: -200, visible: false, src: pieceSrc({ color: "w", type: "k" }) });
  const [round, setRound] = useState(0);

  useEffect(() => {
    const loaded = loadSave();
    setSave(loaded);
    setDifficulty(loaded.difficulty);
    setDuration(loaded.duration);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    setSave((current) => {
      if (current.difficulty === difficulty && current.duration === duration) return current;
      const next = { ...current, difficulty, duration };
      writeSave(next);
      return next;
    });
  }, [difficulty, duration, hydrated]);

  useEffect(() => {
    if (phase !== "study") return;
    const endsAt = performance.now() + duration * 1000;
    remainingRef.current = duration * 1000;
    setRemaining(duration * 1000);
    studyTimer.current = window.setInterval(() => {
      const left = Math.max(0, endsAt - performance.now());
      remainingRef.current = left;
      setRemaining(left);
      if (left <= 0) {
        if (studyTimer.current != null) {
          window.clearInterval(studyTimer.current);
          studyTimer.current = null;
        }
        beginRecall(duration * 1000);
      }
    }, 80);
    return () => {
      if (studyTimer.current != null) {
        window.clearInterval(studyTimer.current);
        studyTimer.current = null;
      }
    };
  }, [phase, round, duration]);

  useEffect(() => {
    if (phase !== "recall") return;
    const id = window.setInterval(() => {
      setRecallElapsed(performance.now() - recallStartRef.current);
    }, 200);
    return () => window.clearInterval(id);
  }, [phase, puzzle?.fen]);

  useLayoutEffect(() => {
    const shell = ghostRef.current;
    const image = ghostImgRef.current;
    if (!shell || !image) return;
    image.src = ghostPos.current.src;
    shell.style.opacity = ghostPos.current.visible ? "1" : "0";
    shell.style.transform = `translate3d(${ghostPos.current.x}px, ${ghostPos.current.y}px, 0)`;
  });

  useEffect(() => {
    return () => {
      if (fadeTimer.current != null) window.clearTimeout(fadeTimer.current);
    };
  }, []);

  function placeGhost(piece: BoardPiece, x: number, y: number, visible: boolean) {
    ghostPos.current = { x: x - 32, y: y - 58, visible, src: pieceSrc(piece) };
    const shell = ghostRef.current;
    const image = ghostImgRef.current;
    if (!shell || !image) return;
    if (image.src !== ghostPos.current.src) image.src = ghostPos.current.src;
    shell.style.opacity = visible ? "1" : "0";
    shell.style.transform = `translate3d(${ghostPos.current.x}px, ${ghostPos.current.y}px, 0)`;
  }

  function hideGhost() {
    ghostPos.current.visible = false;
    const shell = ghostRef.current;
    if (shell) shell.style.opacity = "0";
  }

  function resetBoard() {
    boardRef.current = {};
    undoStack.current = [];
    setUserPieces({});
    setUndoCount(0);
    setArmed(null);
    setLifted(null);
  }

  function setBoard(next: BoardMap, recordUndo: boolean) {
    if (recordUndo) undoStack.current.push(boardRef.current);
    boardRef.current = next;
    setUserPieces(next);
    setUndoCount(undoStack.current.length);
  }

  function place(square: Square, piece: BoardPiece, from: Square | null) {
    const next: BoardMap = { ...boardRef.current };
    if (from && from !== square) delete next[from];
    next[square] = piece;
    setBoard(next, true);
    setArmed(null);
    setLifted(null);
  }

  function removeSquare(square: Square) {
    if (!boardRef.current[square]) {
      setArmed(null);
      return;
    }
    const next: BoardMap = { ...boardRef.current };
    delete next[square];
    setBoard(next, true);
    setArmed(null);
  }

  function undo() {
    const previous = undoStack.current.pop();
    if (!previous) return;
    boardRef.current = previous;
    setUserPieces(previous);
    setUndoCount(undoStack.current.length);
    setArmed(null);
  }

  function clearBoard() {
    if (Object.keys(boardRef.current).length === 0) return;
    setBoard({}, true);
    setArmed(null);
  }

  function tapSquare(square: Square) {
    const occupant = boardRef.current[square];
    if (armed) {
      if (armed.from === square) {
        removeSquare(square);
        return;
      }
      place(square, armed.piece, armed.from);
      return;
    }
    if (occupant) setArmed({ piece: occupant, from: square });
  }

  function armPalette(piece: BoardPiece) {
    setArmed((current) =>
      current && current.from == null && samePiece(current.piece, piece) ? null : { piece, from: null },
    );
  }

  function onSquarePointerDown(square: Square, event: React.PointerEvent) {
    if (phase !== "recall" || gesture.current) return;
    const piece = boardRef.current[square];
    gesture.current = true;
    const startX = event.clientX;
    const startY = event.clientY;
    let dragging = false;
    if (piece) placeGhost(piece, startX, startY, false);
    const move = (ev: PointerEvent) => {
      if (Math.hypot(ev.clientX - startX, ev.clientY - startY) <= 8) return;
      if (!dragging) {
        dragging = true;
        if (piece) setLifted(square);
      }
      if (piece) {
        ev.preventDefault();
        placeGhost(piece, ev.clientX, ev.clientY, true);
      }
    };
    const up = (ev: PointerEvent) => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      gesture.current = false;
      hideGhost();
      setLifted(null);
      if (!dragging) {
        tapSquare(square);
        return;
      }
      if (!piece) return;
      const target = squareFromPoint(ev.clientX, ev.clientY);
      if (!target) {
        removeSquare(square);
        return;
      }
      if (target !== square) place(target, piece, square);
    };
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
  }

  function onPalettePointerDown(piece: BoardPiece, event: React.PointerEvent) {
    if (phase !== "recall" || gesture.current) return;
    event.preventDefault();
    gesture.current = true;
    const startX = event.clientX;
    const startY = event.clientY;
    let dragging = false;
    placeGhost(piece, startX, startY, false);
    const move = (ev: PointerEvent) => {
      if (Math.hypot(ev.clientX - startX, ev.clientY - startY) <= 8) return;
      dragging = true;
      ev.preventDefault();
      placeGhost(piece, ev.clientX, ev.clientY, true);
    };
    const up = (ev: PointerEvent) => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      gesture.current = false;
      hideGhost();
      if (!dragging) {
        armPalette(piece);
        return;
      }
      const target = squareFromPoint(ev.clientX, ev.clientY);
      if (target) place(target, piece, null);
    };
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
  }

  function beginRecall(studied: number) {
    if (studyTimer.current != null) {
      window.clearInterval(studyTimer.current);
      studyTimer.current = null;
    }
    if (fadeTimer.current != null) return;
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const finish = () => {
      fadeTimer.current = null;
      setFading(false);
      resetBoard();
      setStudiedMs(studied);
      recallStartRef.current = performance.now();
      setRecallElapsed(0);
      setScore(null);
      setReview("compare");
      setPhase("recall");
    };
    if (reduced) {
      finish();
      return;
    }
    setFading(true);
    fadeTimer.current = window.setTimeout(finish, 240);
  }

  function hideNow() {
    if (phase !== "study" || fadeTimer.current != null) return;
    beginRecall(Math.max(0, duration * 1000 - remainingRef.current));
  }

  function startPuzzle(next?: GeneratedPosition) {
    if (fadeTimer.current != null) {
      window.clearTimeout(fadeTimer.current);
      fadeTimer.current = null;
    }
    const position = next ?? generatePosition(difficulty);
    setPuzzle(position);
    setPuzzlePieces(piecesFromFen(position.fen));
    resetBoard();
    setFading(false);
    setScore(null);
    setNewBest(false);
    setReview("compare");
    setRemaining(duration * 1000);
    remainingRef.current = duration * 1000;
    setRound((value) => value + 1);
    setPhase("study");
  }

  function goHome() {
    if (fadeTimer.current != null) {
      window.clearTimeout(fadeTimer.current);
      fadeTimer.current = null;
    }
    setFading(false);
    setPhase("home");
    setArmed(null);
    setLifted(null);
  }

  function submit() {
    if (!puzzle || phase !== "recall") return;
    const recallMs = Math.max(0, performance.now() - recallStartRef.current);
    const nextScore = scorePosition(puzzlePieces, boardRef.current);
    const previousBest = save.bestAccuracy;
    const hadSessions = save.sessions > 0;
    const session: SessionRecord = {
      at: Date.now(),
      difficulty,
      duration,
      accuracy: nextScore.accuracy,
      correct: nextScore.correct,
      total: nextScore.total,
      missing: nextScore.missing,
      incorrect: nextScore.incorrect,
      recallMs,
      studiedMs,
    };
    const nextSave = applySession(save, session);
    writeSave(nextSave);
    setSave(nextSave);
    setScore(nextScore);
    setRecallElapsed(recallMs);
    setNewBest(hadSessions && nextScore.accuracy > previousBest);
    setReview("compare");
    setArmed(null);
    setPhase("result");
  }

  function chooseDifficulty(next: Difficulty) {
    setDifficulty(next);
    setDuration(DEFAULT_DURATION[next]);
    setConfirmReset(false);
  }

  function resetProgress() {
    const next = {
      ...defaultSave(),
      difficulty,
      duration,
    };
    writeSave(next);
    setSave(next);
    setConfirmReset(false);
  }

  const streak = visibleStreak(save);
  const average = averageAccuracy(save);
  const placed = Object.keys(userPieces).length;
  const activeMeta = DIFFICULTIES.find((item) => item.id === difficulty) ?? DIFFICULTIES[1]!;
  const turnLabel = puzzle?.turn === "b" ? "Black to move" : "White to move";

  const marks: Partial<Record<Square, SquareMark>> = {};
  const ghosts: BoardMap = {};
  const badges: BoardMap = {};
  if (phase === "result" && score && review === "compare") {
    for (const square of score.correctSquares) marks[square] = "correct";
    for (const mistake of score.mistakes) {
      marks[mistake.square] = mistake.kind;
      if (mistake.kind === "missing" && mistake.expected) ghosts[mistake.square] = mistake.expected;
      if (mistake.kind === "wrong" && mistake.expected) badges[mistake.square] = mistake.expected;
    }
  }

  const displayPieces =
    phase === "home"
      ? showcase
      : phase === "study"
        ? puzzlePieces
        : phase === "result" && review === "solution"
          ? puzzlePieces
          : userPieces;

  const boardLabel =
    phase === "study"
      ? "Position to memorize"
      : phase === "recall"
        ? "Blank board. Rebuild the position"
        : phase === "result"
          ? "Reviewed position"
          : "Sample middlegame";

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-4 pt-4 pb-28 lg:px-8 lg:pt-8 lg:pb-10">
      <header className="mb-4 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2">
          {phase !== "home" && (
            <button
              type="button"
              aria-label="Back to setup"
              onClick={goHome}
              className="grid size-11 shrink-0 place-items-center rounded-full border border-line bg-surface text-fg"
            >
              <ChevronLeft className="size-5" />
            </button>
          )}
          <div className="min-w-0">
            <p className="text-xs tracking-widest text-brass uppercase">Board memory</p>
            <h1 className="font-display text-2xl leading-none text-balance text-fg sm:text-4xl">
              Chess <span className="text-brass italic">Memory</span>
            </h1>
          </div>
        </div>
        <div
          className="flex shrink-0 items-center gap-2 rounded-full border border-line bg-surface px-3 py-2"
          aria-label={streak > 0 ? `${streak} day streak` : "No streak yet"}
        >
          <Flame className={cn("size-4", streak > 0 ? "text-brass" : "text-muted")} />
          <span className="text-sm font-medium text-fg tabular-nums">{streak}</span>
          <span className="hidden text-sm text-muted lg:inline">day streak</span>
        </div>
      </header>

      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,36rem)_minmax(18rem,1fr)] lg:gap-10">
        <section className="min-w-0 lg:sticky lg:top-6">
          <ChessBoard
            pieces={displayPieces}
            ghosts={ghosts}
            badges={badges}
            marks={marks}
            flipped={flipped}
            interactive={phase === "recall"}
            armedSquare={armed?.from ?? null}
            liftedSquare={lifted}
            dimPieces={fading}
            label={boardLabel}
            onSquarePointerDown={onSquarePointerDown}
          />
          <div className="mt-3 flex items-center justify-between gap-3">
            <p className="text-sm text-muted">
              {phase === "home" && "A quiet sample. Your drill starts blank after the timer."}
              {phase === "study" && `${activeMeta.label} · ${turnLabel}`}
              {phase === "recall" && `${placed} placed · ${formatClock(recallElapsed)}`}
              {phase === "result" &&
                (score ? `${score.correct} of ${score.total} pieces on the right squares` : "")}
            </p>
            <button
              type="button"
              onClick={() => setFlipped((value) => !value)}
              className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 text-sm text-fg"
            >
              <ArrowDownUp className="size-4" />
              Flip
            </button>
          </div>
        </section>

        <section className="flex min-w-0 flex-col gap-5">
          {phase === "home" && (
            <HomePanel
              difficulty={difficulty}
              duration={duration}
              save={save}
              average={average}
              confirmReset={confirmReset}
              onDifficulty={chooseDifficulty}
              onDuration={(value) => {
                setDuration(value);
                setConfirmReset(false);
              }}
              onResetAsk={() => setConfirmReset(true)}
              onResetCancel={() => setConfirmReset(false)}
              onResetConfirm={resetProgress}
            />
          )}

          {phase === "study" && (
            <StudyPanel
              remaining={remaining}
              duration={duration}
              hint={activeMeta.hint}
            />
          )}

          {phase === "recall" && (
            <RecallPanel
              armed={armed}
              undoCount={undoCount}
              onPalettePointerDown={onPalettePointerDown}
              onUndo={undo}
              onClear={clearBoard}
            />
          )}

          {phase === "result" && score && (
            <ResultPanel
              score={score}
              recallElapsed={recallElapsed}
              studiedMs={studiedMs}
              review={review}
              newBest={newBest}
              onReview={setReview}
            />
          )}

          <div className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur lg:static lg:z-auto lg:border-0 lg:bg-transparent lg:p-0">
            <div className="mx-auto flex w-full max-w-6xl gap-2 px-4 py-3 lg:max-w-none lg:px-0">
              {phase === "home" && (
                <button
                  type="button"
                  data-testid="start"
                  onClick={() => startPuzzle()}
                  className="min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink"
                >
                  Start practice
                </button>
              )}
              {phase === "study" && (
                <button
                  type="button"
                  data-testid="hide-now"
                  onClick={hideNow}
                  className="min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink"
                >
                  Hide pieces now
                </button>
              )}
              {phase === "recall" && (
                <button
                  type="button"
                  data-testid="check"
                  onClick={submit}
                  className="min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink"
                >
                  Check memory
                </button>
              )}
              {phase === "result" && (
                <>
                  <button
                    type="button"
                    onClick={() => puzzle && startPuzzle(puzzle)}
                    className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-semibold text-fg"
                  >
                    <RotateCcw className="size-4" />
                    Retry
                  </button>
                  <button
                    type="button"
                    onClick={() => startPuzzle()}
                    className="min-h-12 flex-1 rounded-xl bg-brass px-3 text-sm font-semibold text-brass-ink"
                  >
                    New position
                  </button>
                </>
              )}
            </div>
          </div>
        </section>
      </div>

      <div
        ref={ghostRef}
        className="pointer-events-none fixed top-0 left-0 z-50 size-16 opacity-0"
        aria-hidden="true"
      >
        <img
          ref={ghostImgRef}
          src={pieceSrc({ color: "w", type: "k" })}
          alt=""
          draggable={false}
          className="piece-shadow size-full"
        />
      </div>
    </main>
  );
}

function HomePanel({
  difficulty,
  duration,
  save,
  average,
  confirmReset,
  onDifficulty,
  onDuration,
  onResetAsk,
  onResetCancel,
  onResetConfirm,
}: {
  difficulty: Difficulty;
  duration: DurationSec;
  save: Save;
  average: number | null;
  confirmReset: boolean;
  onDifficulty: (value: Difficulty) => void;
  onDuration: (value: DurationSec) => void;
  onResetAsk: () => void;
  onResetCancel: () => void;
  onResetConfirm: () => void;
}) {
  const meta = DIFFICULTIES.find((item) => item.id === difficulty);
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="font-display text-xl text-balance text-fg">Hold the position, then rebuild it.</h2>
        <p className="mt-2 text-sm leading-relaxed text-pretty text-muted">
          A legal position appears for a few seconds. When it vanishes, drag the pieces back
          onto the same squares.
        </p>
      </div>

      <fieldset className="flex flex-col gap-2">
        <legend className="text-sm font-medium text-fg">Difficulty</legend>
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-surface p-1" role="radiogroup" aria-label="Difficulty">
          {DIFFICULTIES.map((item) => {
            const selected = item.id === difficulty;
            return (
              <button
                key={item.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => onDifficulty(item.id)}
                className={cn(
                  "min-h-11 rounded-lg px-1 text-center text-sm leading-tight font-medium",
                  selected ? "bg-brass text-brass-ink" : "text-muted",
                )}
              >
                {item.label}
              </button>
            );
          })}
        </div>
        <p className="text-sm text-muted">{meta?.hint}</p>
      </fieldset>

      <fieldset className="flex flex-col gap-2">
        <legend className="text-sm font-medium text-fg">Display time</legend>
        <div className="grid grid-cols-4 gap-1 rounded-xl bg-surface p-1" role="radiogroup" aria-label="Display time">
          {DURATIONS.map((value) => {
            const selected = value === duration;
            return (
              <button
                key={value}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => onDuration(value)}
                className={cn(
                  "min-h-11 rounded-lg text-sm font-medium tabular-nums",
                  selected ? "bg-brass text-brass-ink" : "text-muted",
                )}
              >
                {value}s
              </button>
            );
          })}
        </div>
      </fieldset>

      <dl className="grid grid-cols-3 gap-2">
        <Stat label="Best" value={save.sessions > 0 ? `${save.bestAccuracy}%` : "—"} />
        <Stat label="Average" value={average == null ? "—" : `${average}%`} />
        <Stat label="Sessions" value={String(save.sessions)} />
      </dl>

      <div>
        <h3 className="text-sm font-medium text-fg">Recent</h3>
        {save.history.length === 0 ? (
          <p className="mt-2 text-sm text-muted">Finish a board and it will land here.</p>
        ) : (
          <ul className="mt-2 flex flex-col gap-2">
            {save.history.slice(0, 5).map((session) => (
              <li
                key={session.at}
                className="flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-2 text-sm"
              >
                <span className="text-fg capitalize">{session.difficulty}</span>
                <span className="text-muted tabular-nums">{formatClock(session.recallMs)}</span>
                <span className="font-medium text-brass tabular-nums">{session.accuracy}%</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {confirmReset ? (
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <span className="text-muted">Erase saved stats on this device?</span>
          <button type="button" onClick={onResetConfirm} className="min-h-11 rounded-lg px-3 text-bad">
            Erase
          </button>
          <button type="button" onClick={onResetCancel} className="min-h-11 rounded-lg px-3 text-fg">
            Cancel
          </button>
        </div>
      ) : (
        <button type="button" onClick={onResetAsk} className="self-start text-sm text-muted">
          Reset progress
        </button>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-3">
      <dt className="text-xs tracking-wide text-muted uppercase">{label}</dt>
      <dd className="mt-1 font-display text-2xl text-fg tabular-nums">{value}</dd>
    </div>
  );
}

function StudyPanel({
  remaining,
  duration,
  hint,
}: {
  remaining: number;
  duration: number;
  hint: string;
}) {
  const progress = duration === 0 ? 0 : remaining / (duration * 1000);
  const seconds = Math.max(0, Math.ceil(remaining / 1000));
  const radius = 18;
  const circumference = 2 * Math.PI * radius;
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-xl text-fg">Memorize</h2>
        <p className="mt-2 text-sm leading-relaxed text-pretty text-muted">{hint} The board clears when the clock ends.</p>
      </div>
      <div className="flex items-center gap-4">
        <svg viewBox="0 0 44 44" className="size-16 shrink-0" aria-hidden="true">
          <circle cx="22" cy="22" r={radius} fill="none" className="stroke-line" strokeWidth="3" />
          <circle
            cx="22"
            cy="22"
            r={radius}
            fill="none"
            className="stroke-brass"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - progress)}
            transform="rotate(-90 22 22)"
          />
        </svg>
        <div>
          <p className="font-display text-5xl text-fg tabular-nums" data-testid="timer">
            {seconds}
          </p>
          <p className="text-sm text-muted">seconds left</p>
        </div>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-line">
        <div className="h-full bg-brass" style={{ width: `${Math.max(0, Math.min(100, progress * 100))}%` }} />
      </div>
    </div>
  );
}

function RecallPanel({
  armed,
  undoCount,
  onPalettePointerDown,
  onUndo,
  onClear,
}: {
  armed: Arm | null;
  undoCount: number;
  onPalettePointerDown: (piece: BoardPiece, event: React.PointerEvent) => void;
  onUndo: () => void;
  onClear: () => void;
}) {
  const hint = armed
    ? armed.from
      ? `Tap a square to move the ${pieceName(armed.piece).toLowerCase()}, or tap it again to remove it.`
      : `Tap a square to place the ${pieceName(armed.piece).toLowerCase()}. Tap the piece again to cancel.`
    : "Drag a piece onto a square, or tap a piece and then a square.";
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-xl text-fg">Rebuild</h2>
        <p className="mt-2 text-sm leading-relaxed text-pretty text-muted">{hint}</p>
      </div>
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-medium text-fg">Piece tray</h3>
        <div className="flex gap-1">
          <button
            type="button"
            onClick={onUndo}
            disabled={undoCount === 0}
            className="inline-flex min-h-11 items-center gap-1 rounded-lg px-3 text-sm text-fg disabled:opacity-40"
          >
            <Undo2 className="size-4" />
            Undo
          </button>
          <button type="button" onClick={onClear} className="min-h-11 rounded-lg px-3 text-sm text-fg">
            Clear
          </button>
        </div>
      </div>
      <div className="touch-none rounded-2xl border border-line bg-surface p-3">
        <PaletteRow color="w" label="White" armed={armed} onPointerDown={onPalettePointerDown} />
        <div className="my-3 h-px bg-line" />
        <PaletteRow color="b" label="Black" armed={armed} onPointerDown={onPalettePointerDown} />
      </div>
    </div>
  );
}

function PaletteRow({
  color,
  label,
  armed,
  onPointerDown,
}: {
  color: "w" | "b";
  label: string;
  armed: Arm | null;
  onPointerDown: (piece: BoardPiece, event: React.PointerEvent) => void;
}) {
  const pieces = PALETTE.filter((piece) => piece.color === color);
  return (
    <div className="flex flex-col gap-2">
      <p className="text-xs tracking-wide text-muted uppercase">{label}</p>
      <div className="grid grid-cols-6 gap-1">
        {pieces.map((piece) => {
          const selected =
            armed?.from == null && armed != null && samePiece(armed.piece, piece);
          return (
            <button
              key={`${piece.color}${piece.type}`}
              type="button"
              aria-label={pieceName(piece)}
              aria-pressed={selected}
              data-testid={`palette-${piece.color}${piece.type}`}
              onPointerDown={(event) => onPointerDown(piece, event)}
              onContextMenu={(event) => event.preventDefault()}
              className={cn(
                "grid aspect-square min-h-11 place-items-center rounded-lg bg-raised p-1",
                selected && "ring-2 ring-brass",
              )}
            >
              <PieceGlyph piece={piece} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ResultPanel({
  score,
  recallElapsed,
  studiedMs,
  review,
  newBest,
  onReview,
}: {
  score: Score;
  recallElapsed: number;
  studiedMs: number;
  review: Review;
  newBest: boolean;
  onReview: (review: Review) => void;
}) {
  const tone =
    score.accuracy >= 90 ? "text-good" : score.accuracy >= 60 ? "text-brass" : "text-bad";
  const headline =
    score.accuracy === 100 ? "You rebuilt it." : score.accuracy >= 80 ? "Close." : "Not quite.";
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-xl text-fg">{headline}</h2>
        {newBest && <p className="mt-1 text-sm text-brass">New best accuracy.</p>}
      </div>
      <p className={cn("font-display text-6xl leading-none tabular-nums", tone)} data-testid="accuracy">
        {score.accuracy}
        <span className="text-3xl">%</span>
      </p>
      <p className="text-sm text-muted">
        Studied {formatClock(studiedMs)} · rebuilt in {formatClock(recallElapsed)}
      </p>
      <dl className="grid grid-cols-3 gap-2">
        <Stat label="Correct" value={String(score.correct)} />
        <Stat label="Missing" value={String(score.missing)} />
        <Stat label="Incorrect" value={String(score.incorrect)} />
      </dl>
      <p className="text-sm text-pretty text-muted">
        Accuracy is pieces on the right squares, divided by the original pieces plus any extras.
      </p>
      <div className="grid grid-cols-3 gap-1 rounded-xl bg-surface p-1" role="radiogroup" aria-label="Board review">
        {(
          [
            ["compare", "Review"],
            ["solution", "Solution"],
            ["yours", "Yours"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={review === id}
            onClick={() => onReview(id)}
            className={cn(
              "min-h-11 rounded-lg text-sm font-medium",
              review === id ? "bg-brass text-brass-ink" : "text-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>
      <ul className="flex flex-wrap gap-3 text-xs text-muted">
        <li className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-good" /> Correct
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-brass" /> Missing
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-bad" /> Incorrect
        </li>
      </ul>
      {score.mistakes.length === 0 ? (
        <p className="text-sm text-fg">Every piece landed on its square.</p>
      ) : (
        <ul className="flex max-h-56 flex-col gap-2 overflow-auto pr-1">
          {score.mistakes.map((mistake) => (
            <li key={`${mistake.kind}-${mistake.square}`} className="text-sm leading-snug text-fg">
              <span className="font-medium text-brass tabular-nums">{mistake.square}</span>{" "}
              <span className="text-muted">{mistakeCopy(mistake)}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function mistakeCopy(mistake: Score["mistakes"][number]) {
  if (mistake.kind === "missing" && mistake.expected) {
    return `missing ${pieceName(mistake.expected).toLowerCase()}`;
  }
  if (mistake.kind === "extra" && mistake.actual) {
    return `extra ${pieceName(mistake.actual).toLowerCase()}`;
  }
  if (mistake.expected && mistake.actual) {
    return `placed ${pieceName(mistake.actual).toLowerCase()}, expected ${pieceName(mistake.expected).toLowerCase()}`;
  }
  return "incorrect";
}
