import React from 'react';
import { GameStats } from '../types';
import { Play, Trophy, Sparkles, Volume2, VolumeX, Smartphone, SmartphoneNfc, Zap } from 'lucide-react';

interface StartScreenProps {
  stats: GameStats;
  isSoundMuted: boolean;
  isHapticsEnabled: boolean;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  stats,
  isSoundMuted,
  isHapticsEnabled,
  onToggleSound,
  onToggleHaptics,
  onStart,
}) => {
  return (
    <div className="flex h-full w-full max-w-md flex-col items-center justify-between px-6 py-8 text-center select-none pt-safe pb-safe z-10">
      {/* Top Setting Quick Toggles */}
      <div className="flex w-full items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <span>ARCADE READY</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggleSound}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-800/80 text-slate-300 hover:text-white transition-all active:scale-95"
            aria-label={isSoundMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isSoundMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
          <button
            onClick={onToggleHaptics}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-800/80 text-slate-300 hover:text-white transition-all active:scale-95"
            aria-label={isHapticsEnabled ? 'Disable Haptics' : 'Enable Haptics'}
          >
            {isHapticsEnabled ? (
              <SmartphoneNfc className="h-5 w-5 text-emerald-400" />
            ) : (
              <Smartphone className="h-5 w-5 text-slate-500" />
            )}
          </button>
        </div>
      </div>

      {/* Hero Brand Title & Visual Teaser */}
      <div className="flex flex-col items-center my-auto">
        {/* Animated Color Orb Trio */}
        <div className="relative mb-4 flex items-center justify-center">
          <div className="absolute -left-6 h-12 w-12 rounded-full bg-blue-500 blur-md opacity-80 animate-pulse" />
          <div className="absolute -right-6 h-12 w-12 rounded-full bg-rose-500 blur-md opacity-80 animate-pulse delay-150" />
          <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-blue-500 p-1 shadow-[0_0_40px_rgba(239,68,68,0.5)]">
            <div className="flex h-full w-full items-center justify-center rounded-full bg-slate-950">
              <Zap className="h-10 w-10 text-amber-400 fill-amber-400 animate-bounce" />
            </div>
          </div>
        </div>

        {/* Game Title */}
        <h1 className="text-5xl font-black tracking-tight drop-shadow-md">
          <span className="text-white">COLOR </span>
          <span className="bg-gradient-to-r from-amber-400 via-rose-500 to-blue-500 bg-clip-text text-transparent">
            RUSH
          </span>
        </h1>
        <p className="mt-2 text-sm font-medium text-slate-400 max-w-xs">
          Match the target color before the clock runs out. One mistake and it’s game over!
        </p>

        {/* Feature badges */}
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <div className="flex items-center gap-1.5 rounded-lg bg-slate-900/80 px-3 py-1.5 text-xs text-slate-300 border border-slate-800">
            <Sparkles className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />
            <span>Golden Bonuses (+5)</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-lg bg-slate-900/80 px-3 py-1.5 text-xs text-slate-300 border border-slate-800">
            <span className="text-emerald-400 font-bold">5x</span>
            <span>Combo Multiplier</span>
          </div>
        </div>

        {/* High Score Card */}
        {stats.highScore > 0 && (
          <div className="mt-6 flex items-center gap-3 rounded-2xl bg-slate-900/90 px-6 py-3 border border-amber-500/30 shadow-[0_0_20px_rgba(245,158,11,0.15)]">
            <Trophy className="h-6 w-6 text-amber-400 fill-amber-400" />
            <div className="flex flex-col text-left">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                BEST SCORE
              </span>
              <span className="font-mono text-2xl font-black text-amber-300 tabular-nums leading-none">
                {stats.highScore}
              </span>
            </div>
            <div className="ml-4 border-l border-slate-800 pl-4 text-left">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                MAX COMBO
              </span>
              <span className="font-mono text-sm font-bold text-slate-200 tabular-nums block">
                {stats.maxCombo}x streak
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Start Action Button */}
      <div className="w-full flex flex-col items-center gap-3">
        <button
          onClick={onStart}
          className="group relative flex h-16 w-full max-w-xs cursor-pointer items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 font-black text-lg text-white shadow-[0_8px_30px_rgba(16,185,129,0.45)] transition-all duration-150 active:scale-95 hover:brightness-110 active:brightness-95"
        >
          <Play className="h-6 w-6 fill-white transition-transform group-hover:scale-110" />
          <span className="tracking-wide">PLAY NOW</span>
        </button>

        <span className="text-[11px] text-slate-500">
          Fast · Offline · No Account Required
        </span>
      </div>
    </div>
  );
};
