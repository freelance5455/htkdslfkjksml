import { useState } from "react";
import type { GameMode, HighScore, Settings } from "@/game/types";
import { cn } from "@/utils/cn";
import { FoxMark, Icon, IconButton, KeyCap, Logo, Panel, SectionTitle, StarBurst } from "./ui";

const NICKNAMES = ["Толок", "Песок", "Бублик", "Вихрь", "Сырник", "Кусь", "Шпрот", "Мармелад"];

interface StartScreenProps {
  mode: GameMode;
  onModeChange: (mode: GameMode) => void;
  nickname: string;
  onNicknameChange: (name: string) => void;
  onStart: () => void;
  highScores: HighScore[];
  settings: Settings;
  onSettingsChange: (patch: Partial<Settings>) => void;
  onOpenSettings: () => void;
  onOpenBriefing: () => void;
  onOpenServers: () => void;
  soundOn: boolean;
  onToggleSound: () => void;
}

export function StartScreen({
  mode,
  onModeChange,
  nickname,
  onNicknameChange,
  onStart,
  highScores,
  settings,
  onSettingsChange,
  onOpenSettings,
  onOpenBriefing,
  onOpenServers,
  soundOn,
  onToggleSound,
}: StartScreenProps) {
  const [nameFocused, setNameFocused] = useState(false);
  const best = highScores[0];

  return (
    <div className="pointer-events-none fixed inset-0 z-20 overflow-y-auto">
      <div className="pointer-events-auto relative flex min-h-full flex-col">
        {/* backdrop */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-deep/95 via-ink-deep/75 to-ink-deep/10" />
        <div className="absolute inset-x-0 bottom-0 -z-10 h-1/2 bg-gradient-to-t from-ink-deep via-ink-deep/60 to-transparent" />
        <div className="absolute inset-0 -z-10 bg-dots opacity-40" />
        <div className="pointer-events-none absolute -left-24 top-1/3 -z-10 h-[420px] w-[420px] text-teal/10">
          <StarBurst className="animate-spin-slow" />
        </div>
        <div className="pointer-events-none absolute right-[18%] top-10 -z-10 h-24 w-24 text-sun/20 animate-floaty">
          <StarBurst />
        </div>
        <div className="pointer-events-none absolute right-[8%] top-[38%] -z-10 hidden h-14 w-14 text-coral/30 animate-floaty lg:block" style={{ animationDelay: "1.2s" }}>
          <StarBurst />
        </div>

        {/* header */}
        <header className="start-header safe-top flex items-center justify-between gap-3 px-4 pb-2 sm:px-7 lg:px-10">
          <div className="flex items-center gap-3">
            <Logo />
            <div className="start-season hidden items-center gap-2 rounded-full border-2 border-cream/15 bg-ink/50 px-3 py-1.5 sm:flex">
              <span className="h-2 w-2 animate-pulse rounded-full bg-lime" />
              <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-cream/70">Сезон 01 · Песчаный форт</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-xl border-2 border-cream/10 bg-ink/50 px-3 py-2 md:flex">
              <Icon name="trophy" className="h-4 w-4 text-sun" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-cream/50">Рекорд</span>
              <span className="font-display text-sm font-black text-cream">{best ? best.score.toLocaleString("ru-RU") : "—"}</span>
            </div>
            <IconButton icon="server" label="Онлайн-серверы" onClick={onOpenServers} />
            <IconButton icon={soundOn ? "sound" : "mute"} label={soundOn ? "Выключить звук" : "Включить звук"} onClick={onToggleSound} active={soundOn} />
            <IconButton icon="settings" label="Настройки" onClick={onOpenSettings} />
            <button
              type="button"
              onClick={onOpenBriefing}
              className="hidden items-center gap-2 rounded-xl border-[3px] border-ink bg-grape px-3 py-2 font-display text-[10px] font-extrabold uppercase tracking-wider text-ink shadow-[0_3px_0_0_#241a35] transition-transform active:translate-y-[2px] sm:flex"
            >
              <Icon name="info" className="h-4 w-4" />
              Брифинг
            </button>
          </div>
        </header>

        {/* main */}
        <main className="start-main mx-auto flex w-full max-w-[1440px] flex-1 items-center gap-10 px-4 py-3 sm:px-7 lg:px-10">
          <section className="w-full max-w-[660px] animate-fade-up">
            <div className="start-badges mb-3 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-coral px-2.5 py-1 text-[9px] font-black uppercase tracking-[0.16em] text-white shadow-[0_2px_0_0_#241a35]">
                <Icon name="bolt" className="h-3 w-3" />
                Мультяшный 3D-шутер
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-cream/15 bg-ink/50 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.16em] text-cream/60">
                <Icon name="users" className="h-3 w-3" />
                10 ботов · 6 стволов · 3 машины
              </span>
            </div>

            <div className="start-title-wrap relative">
              <div className="pointer-events-none absolute -left-6 -top-10 h-32 w-32 text-sun/25 animate-spin-slow">
                <StarBurst />
              </div>
              <h1 className="start-title relative font-display text-[clamp(3.6rem,11vw,7.6rem)] font-black leading-[0.78] tracking-[-0.07em] text-sun text-outline">
                ТОЛОК
              </h1>
              <div className="start-subtitle mt-2 flex flex-wrap items-center gap-2">
                <span className="inline-flex -rotate-2 items-center rounded-lg border-[3px] border-ink bg-teal px-3 py-1 font-display text-sm font-black uppercase tracking-[0.2em] text-ink shadow-[0_3px_0_0_#241a35] sm:text-base">
                  Арена
                </span>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-cream/45">Sand Fort · Web Prototype</span>
              </div>
            </div>

            <p className="start-tagline mt-3 max-w-lg text-sm font-medium leading-relaxed text-cream/70 sm:text-base">
              Схвати пушку, заберись в багги и разнеси Песчаный форт. Быстрые матчи, сочные взрывы и ни одного шанса заскучать.
            </p>

            {/* mode */}
            <div className="start-modes mt-4 grid grid-cols-2 gap-2.5">
              <ModeCard
                active={mode === "dm"}
                onClick={() => onModeChange("dm")}
                icon="skull"
                title="Deathmatch"
                tag="Каждый сам за себя"
                desc="8 бойцов. 25 убийств или 3 минуты."
                accent="coral"
              />
              <ModeCard
                active={mode === "tdm"}
                onClick={() => onModeChange("tdm")}
                icon="users"
                title="Team Deathmatch"
                tag="4 на 4"
                desc="SUN против TIDE. Командный счёт до 30."
                accent="teal"
              />
            </div>

            {/* nickname + play */}
            <div className="start-play-row mt-3 flex flex-col gap-2.5 sm:flex-row sm:items-stretch">
              <label
                className={cn(
                  "flex min-w-0 flex-1 items-center gap-2 rounded-2xl border-[3px] bg-panel/90 px-3 py-2 transition-colors",
                  nameFocused ? "border-teal" : "border-ink"
                )}
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border-2 border-ink bg-sun text-ink">
                  <FoxMark className="h-6 w-6" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[8px] font-black uppercase tracking-[0.2em] text-cream/40">Твой никнейм</span>
                  <input
                    value={nickname}
                    onChange={(e) => onNicknameChange(e.target.value.slice(0, 14))}
                    onFocus={() => setNameFocused(true)}
                    onBlur={() => setNameFocused(false)}
                    maxLength={14}
                    placeholder="Игрок"
                    className="w-full bg-transparent font-display text-sm font-extrabold text-cream outline-none placeholder:text-cream/25"
                  />
                </span>
                <button
                  type="button"
                  aria-label="Случайный никнейм"
                  onClick={() => onNicknameChange(NICKNAMES[Math.floor(Math.random() * NICKNAMES.length)])}
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border-2 border-ink bg-cream text-ink transition-transform active:rotate-12"
                >
                  <Icon name="swap" className="h-4 w-4" />
                </button>
              </label>
              <button
                type="button"
                onClick={onStart}
                className="group relative flex shrink-0 items-center justify-center gap-3 overflow-hidden rounded-2xl border-[3px] border-ink bg-sun px-6 py-3 font-display text-lg font-black uppercase tracking-[0.08em] text-ink shadow-[0_6px_0_0_#241a35] transition-all hover:bg-[#ffc65c] active:translate-y-[4px] active:shadow-[0_2px_0_0_#241a35] sm:min-w-[210px]"
              >
                <span className="absolute inset-0 shimmer opacity-40" />
                <span className="relative grid h-9 w-9 place-items-center rounded-full border-[3px] border-ink bg-cream">
                  <Icon name="play" className="ml-0.5 h-5 w-5" />
                </span>
                <span className="relative">В бой</span>
                <span className="relative hidden rounded-md border-2 border-ink/30 bg-ink/10 px-1.5 py-0.5 font-mono text-[9px] font-bold sm:inline">ENTER</span>
              </button>
            </div>

            <div className="start-stats mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <MiniStat icon="clock" label="Матч" value="4:00" />
              <MiniStat icon="skull" label="Лимит" value={mode === "dm" ? "25 убийств" : "30 очков"} />
              <MiniStat icon="car" label="Техника" value="Багги · Танк" />
              <MiniStat icon="target" label="Оружие" value="6 стволов" />
            </div>

            <div className="start-hints mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-[10px] font-bold uppercase tracking-wider text-cream/45">
              <span className="flex items-center gap-1.5">
                <Icon name="keyboard" className="h-3.5 w-3.5" /> WASD
              </span>
              <span className="flex items-center gap-1.5">
                <Icon name="crosshair" className="h-3.5 w-3.5" /> ЛКМ — огонь
              </span>
              <span className="flex items-center gap-1.5">
                <Icon name="use" className="h-3.5 w-3.5" /> E — машина
              </span>
              <span className="flex items-center gap-1.5">
                <Icon name="touch" className="h-3.5 w-3.5" /> Тач-джойстик
              </span>
              <button type="button" onClick={onOpenBriefing} className="ml-auto flex items-center gap-1 text-teal hover:text-cream">
                Все управление <Icon name="chevron" className="h-3 w-3" />
              </button>
            </div>
          </section>

          {/* right rail */}
          <aside className="hidden w-[350px] shrink-0 flex-col gap-3 lg:flex">
            <Panel className="overflow-hidden p-4">
              <SectionTitle icon="trophy" right={<span className="rounded-md bg-ink/60 px-1.5 py-0.5 font-mono text-[9px] font-bold text-cream/50">ТОП-8</span>}>
                Доска почёта
              </SectionTitle>
              {highScores.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-cream/15 bg-ink/30 px-4 py-7 text-center">
                  <div className="relative mb-2 grid h-14 w-14 place-items-center rounded-2xl border-[3px] border-ink bg-sun text-ink shadow-[0_4px_0_0_#241a35]">
                    <Icon name="trophy" className="h-7 w-7" />
                    <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full border-2 border-ink bg-coral" />
                  </div>
                  <p className="font-display text-xs font-extrabold uppercase tracking-wider text-cream">Рекордов пока нет</p>
                  <p className="mt-1 text-[11px] leading-snug text-cream/50">Первый забег — твой. Разнеси форт и впиши себя в историю.</p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  {highScores.slice(0, 5).map((entry, i) => (
                    <div
                      key={entry.id}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border-2 px-2 py-1.5",
                        i === 0 ? "border-sun/60 bg-sun/15" : "border-cream/10 bg-white/5"
                      )}
                    >
                      <span
                        className={cn(
                          "grid h-6 w-6 shrink-0 place-items-center rounded-md border-2 border-ink font-display text-[10px] font-black",
                          i === 0 ? "bg-sun text-ink" : i === 1 ? "bg-cream text-ink" : i === 2 ? "bg-coral text-white" : "bg-white/10 text-cream/70"
                        )}
                      >
                        {i + 1}
                      </span>
                      <span className="min-w-0 flex-1 truncate font-display text-[11px] font-extrabold text-cream">{entry.name}</span>
                      <span className="hidden font-mono text-[9px] font-bold text-cream/40 sm:block">{entry.kills} K</span>
                      <span className="font-mono text-[11px] font-black text-sun">{entry.score.toLocaleString("ru-RU")}</span>
                    </div>
                  ))}
                </div>
              )}
            </Panel>

            <Panel className="p-4">
              <SectionTitle icon="bolt">Как играть</SectionTitle>
              <div className="space-y-2">
                <ControlRow keys={["W", "A", "S", "D"]} label="Движение" icon="keyboard" />
                <ControlRow keys={["ЛКМ"]} label="Огонь · автострельба" icon="crosshair" />
                <ControlRow keys={["ПКМ"]} label="Прицел / зум" icon="target" />
                <ControlRow keys={["SPACE"]} label="Прыжок" icon="jump" />
                <ControlRow keys={["E"]} label="Сесть / выйти из машины" icon="car" />
                <ControlRow keys={["G"]} label="Граната" icon="grenade" />
              </div>
              <button
                type="button"
                onClick={onOpenBriefing}
                className="mt-3 flex w-full items-center justify-between rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2 text-left transition-colors hover:bg-white/10"
              >
                <span className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-cream/60">
                  <Icon name="info" className="h-4 w-4 text-grape" /> Брифинг и Godot-план
                </span>
                <Icon name="chevron" className="h-4 w-4 text-cream/40" />
              </button>
            </Panel>

            <button
              type="button"
              onClick={onOpenServers}
              className="flex items-center justify-between rounded-2xl border-2 border-teal/30 bg-teal/10 px-3 py-2 text-left transition-colors hover:bg-teal/20"
            >
              <span className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg border-2 border-ink bg-teal text-ink">
                  <Icon name="server" className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[9px] font-black uppercase tracking-wider text-teal/70">Онлайн</span>
                  <span className="block text-[11px] font-bold text-cream">Найти сервер</span>
                </span>
              </span>
              <Icon name="chevron" className="h-4 w-4 text-teal/60" />
            </button>

            <div className="flex items-center justify-between rounded-2xl border-2 border-cream/10 bg-ink/40 px-3 py-2">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg border-2 border-ink bg-teal text-ink">
                  <Icon name="touch" className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-[9px] font-black uppercase tracking-wider text-cream/40">Тач-контроль</p>
                  <p className="text-[11px] font-bold text-cream">{settings.touch ? "Включён" : "Выключен"}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onSettingsChange({ touch: !settings.touch })}
                className={cn(
                  "relative h-6 w-11 rounded-full border-2 border-ink transition-colors",
                  settings.touch ? "bg-teal" : "bg-white/15"
                )}
                aria-label="Переключить тач-контроль"
              >
                <span className={cn("absolute top-0.5 h-4 w-4 rounded-full border-2 border-ink bg-cream transition-all", settings.touch ? "left-[22px]" : "left-0.5")} />
              </button>
            </div>
          </aside>
        </main>

        {/* footer */}
        <footer className="start-footer safe-bottom mt-auto flex flex-wrap items-center justify-between gap-2 px-4 pb-3 pt-1 sm:px-7 lg:px-10">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onOpenSettings}
              className="flex items-center gap-2 rounded-xl border-2 border-cream/10 bg-ink/50 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-cream/60 transition-colors hover:bg-ink/80 hover:text-cream"
            >
              <Icon name="settings" className="h-3.5 w-3.5" /> Настройки
            </button>
            <div className="hidden items-center gap-2 rounded-xl border-2 border-cream/10 bg-ink/50 px-3 py-1.5 sm:flex">
              <span className="text-[9px] font-bold uppercase tracking-wider text-cream/40">Чувствительность</span>
              <input
                type="range"
                min={0.4}
                max={2}
                step={0.05}
                value={settings.sensitivity}
                onChange={(e) => onSettingsChange({ sensitivity: Number(e.target.value) })}
                className="tolok-range w-24"
                aria-label="Чувствительность"
              />
              <span className="w-8 font-mono text-[10px] font-bold text-sun">{settings.sensitivity.toFixed(2)}</span>
            </div>
            <div className="hidden items-center gap-1 rounded-xl border-2 border-cream/10 bg-ink/50 p-1 md:flex">
              {(["low", "medium", "high"] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => onSettingsChange({ quality: q })}
                  className={cn(
                    "rounded-lg px-2 py-1 text-[9px] font-extrabold uppercase tracking-wider transition-colors",
                    settings.quality === q ? "bg-sun text-ink" : "text-cream/40 hover:text-cream"
                  )}
                >
                  {q === "low" ? "Низк" : q === "medium" ? "Сред" : "Высок"}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[0.16em] text-cream/30">
            <span className="h-1.5 w-1.5 rounded-full bg-lime" />
            Web-прототип · v0.9
            <button type="button" onClick={onOpenBriefing} className="text-teal/70 hover:text-teal">
              Godot-план
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}

function ModeCard({
  active,
  onClick,
  icon,
  title,
  tag,
  desc,
  accent,
}: {
  active: boolean;
  onClick: () => void;
  icon: "skull" | "users";
  title: string;
  tag: string;
  desc: string;
  accent: "coral" | "teal";
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "start-mode-card group relative overflow-hidden rounded-2xl border-[3px] p-2.5 text-left transition-all sm:p-3",
        active
          ? "border-ink bg-cream text-ink shadow-[0_5px_0_0_#241a35]"
          : "border-cream/15 bg-panel/80 text-cream shadow-[0_4px_0_0_rgba(36,26,53,0.6)] hover:border-cream/30 hover:bg-panel"
      )}
    >
      <div className="flex items-start gap-2">
        <span
          className={cn(
            "grid h-8 w-8 shrink-0 place-items-center rounded-lg border-2 border-ink shadow-[0_2px_0_0_#241a35]",
            accent === "coral" ? "bg-coral text-white" : "bg-teal text-ink"
          )}
        >
          <Icon name={icon} className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-1">
            <span className="truncate font-display text-[11px] font-black uppercase tracking-wide sm:text-xs">{title}</span>
            {active && (
              <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full border-2 border-ink bg-teal">
                <Icon name="check" className="h-2.5 w-2.5 text-ink" />
              </span>
            )}
          </div>
          <div className={cn("mt-0.5 text-[9px] font-extrabold uppercase tracking-wider", active ? "text-coral" : "text-sun/80")}>{tag}</div>
          <p className={cn("start-mode-desc mt-1 hidden text-[10px] leading-snug sm:block", active ? "text-ink/60" : "text-cream/45")}>{desc}</p>
        </div>
      </div>
    </button>
  );
}

function MiniStat({ icon, label, value }: { icon: "clock" | "skull" | "car" | "target"; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl border-2 border-cream/10 bg-ink/40 px-2 py-1.5">
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md border-2 border-ink bg-white/10 text-sun">
        <Icon name={icon} className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0">
        <p className="text-[8px] font-black uppercase tracking-wider text-cream/35">{label}</p>
        <p className="truncate font-display text-[10px] font-extrabold text-cream">{value}</p>
      </div>
    </div>
  );
}

function ControlRow({ keys, label, icon }: { keys: string[]; label: string; icon: "keyboard" | "crosshair" | "target" | "jump" | "car" | "grenade" }) {
  return (
    <div className="flex items-center gap-2">
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md border-2 border-ink bg-white/10 text-cream/70">
        <Icon name={icon} className="h-3.5 w-3.5" />
      </span>
      <div className="flex min-w-0 flex-1 items-center gap-1">
        {keys.map((k) => (
          <KeyCap key={k}>{k}</KeyCap>
        ))}
      </div>
      <span className="truncate text-[10px] font-bold text-cream/55">{label}</span>
    </div>
  );
}
