import { useEffect, useRef } from "react";
import { buildProceduralSprites } from "../game/sprites";

export function StartScreen({ onStart, loading }: { onStart: () => void; loading: boolean }) {
  const front = useRef<HTMLCanvasElement>(null);
  const back = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const set = buildProceduralSprites();
    let f = 0;
    const draw = () => {
      const fc = front.current, bc = back.current;
      if (fc) {
        const c = fc.getContext("2d")!;
        c.imageSmoothingEnabled = false;
        c.clearRect(0, 0, fc.width, fc.height);
        c.drawImage(set.idle.front[Math.floor(f / 2) % 2].tex.image as HTMLCanvasElement, 0, 0, fc.width, fc.height);
      }
      if (bc) {
        const c = bc.getContext("2d")!;
        c.imageSmoothingEnabled = false;
        c.clearRect(0, 0, bc.width, bc.height);
        c.drawImage(set.walk.back[f % 4].tex.image as HTMLCanvasElement, 0, 0, bc.width, bc.height);
      }
      f++;
    };
    draw();
    const id = setInterval(draw, 220);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center overflow-hidden bg-black">
      <img src="images/menu-bg.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-80" style={{ imageRendering: "pixelated" }} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/50" />
      <div className="relative flex w-full max-w-4xl flex-col items-center gap-4 px-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col items-center gap-3 text-center sm:items-start sm:text-left">
          <div className="text-[11px] uppercase tracking-[0.4em] text-fuchsia-300">Aventura · Exploração</div>
          <h1 className="title-glow text-4xl leading-tight text-white sm:text-6xl">Terras de<br />Ametista</h1>
          <p className="max-w-md text-sm text-white/80">
            Explore florestas densas, montanhas, cavernas cheias de cristais, rios, lagoas e a grande Cachoeira do Véu.
            Descubra ruínas, templos antigos e mirantes escondidos.
          </p>
          <button
            onClick={onStart}
            disabled={loading}
            className="pixel-btn mt-2 bg-fuchsia-600 px-8 py-3 text-lg text-white hover:bg-fuchsia-500 disabled:opacity-70"
          >
            {loading ? "Gerando o mundo..." : "▶ Explorar"}
          </button>
          <div className="text-[11px] text-white/60">📱 Melhor jogado com o celular na horizontal · ⌨️ WASD + mouse no PC</div>
        </div>
        <div className="flex items-end gap-2">
          <canvas ref={front} width={32} height={48} className="h-40 w-[107px] drop-shadow-[0_0_18px_rgba(200,90,255,0.6)] sm:h-56 sm:w-[150px]" style={{ imageRendering: "pixelated" }} />
          <canvas ref={back} width={32} height={48} className="h-32 w-[85px] opacity-90 sm:h-44 sm:w-[117px]" style={{ imageRendering: "pixelated" }} />
        </div>
      </div>
      {loading && (
        <div className="absolute bottom-6 left-1/2 w-64 -translate-x-1/2">
          <div className="h-2 overflow-hidden bg-white/10">
            <div className="loading-bar h-2 bg-fuchsia-500" />
          </div>
        </div>
      )}
    </div>
  );
}
