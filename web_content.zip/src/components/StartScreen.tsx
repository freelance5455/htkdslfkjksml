import { useMemo } from "react";
import { LESSONS, REVIEW_LESSON } from "@/game/words";
import type { Mode, Difficulty } from "@/game/engine";
import type { Prefs, ProgressMap, ScoreEntry } from "@/lib/storage";

interface Props {
  lessonId: string;
  setLessonId: (id: string) => void;
  mode: Mode;
  setMode: (m: Mode) => void;
  difficulty: Difficulty;
  setDifficulty: (d: Difficulty) => void;
  prefs: Prefs;
  setPrefs: (p: Prefs) => void;
  progress: ProgressMap;
  scores: ScoreEntry[];
  onStart: () => void;
  onClearScores: () => void;
}

const MODES: { id: Mode; label: string; sub: string; emoji: string; color: string }[] = [
  {
    id: "tap",
    label: "انتخاب کن",
    sub: "کلمهٔ درست را لمس کن",
    emoji: "👆",
    color: "#22d3ee",
  },
  {
    id: "type",
    label: "تایپ کن",
    sub: "کلمه را از حفظ بنویس",
    emoji: "⌨️",
    color: "#a78bfa",
  },
  {
    id: "meaning",
    label: "معنی",
    sub: "معنی درست را پیدا کن",
    emoji: "💡",
    color: "#f472b6",
  },
];

const MODE_HELP: Record<Mode, string> = {
  tap: "کلمهٔ فارسی بالای صفحه را می‌بینی؛ کافی است کارت انگلیسی که همان معنی را دارد لمس کنی.",
  type: "کلمهٔ فارسی بالای صفحه را می‌بینی؛ کلمهٔ انگلیسی‌اش را از حفظ تایپ کن (با صفحه‌کلید گوشی یا کیبورد کامپیوتر).",
  meaning: "کلمهٔ انگلیسی بالای صفحه را می‌بینی؛ کارتی را لمس کن که معنی فارسیِ درست را نشان می‌دهد.",
};

const DIFFS: { id: Difficulty; label: string; emoji: string }[] = [
  { id: "easy", label: "آرام", emoji: "🐢" },
  { id: "normal", label: "عادی", emoji: "🚶" },
  { id: "hard", label: "سریع", emoji: "🚀" },
];

const FLOAT_WORDS = [
  "name",
  "family",
  "school",
  "kebab",
  "hello",
  "address",
  "apple",
  "teacher",
  "favourite",
  "classmate",
  "breakfast",
  "student",
];

function FloatingWords() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {FLOAT_WORDS.map((w, i) => (
        <span
          key={w}
          className="animate-drift absolute rounded-xl border border-white/10 bg-white/[0.04] px-3 py-1 font-display text-[13px] font-bold text-white/25 backdrop-blur-[2px]"
          style={{
            left: `${(i * 41) % 88}%`,
            top: `${(i * 37) % 88}%`,
            animationDelay: `${(i % 6) * 0.7}s`,
            animationDuration: `${6 + (i % 4)}s`,
          }}
        >
          {w}
        </span>
      ))}
    </div>
  );
}

export default function StartScreen({
  lessonId,
  setLessonId,
  mode,
  setMode,
  difficulty,
  setDifficulty,
  prefs,
  setPrefs,
  progress,
  scores,
  onStart,
  onClearScores,
}: Props) {
  const best = useMemo(() => scores[0]?.score ?? 0, [scores]);

  const lessons = [...LESSONS, REVIEW_LESSON];

  const mastery = (lessonIdValue: string, ids: string[]) =>
    ids.filter((id) => progress[`${lessonIdValue}:${id}`]?.mastered).length;

  return (
    <div className="h-full w-full overflow-y-auto overflow-x-hidden overscroll-contain">
      <div className="mx-auto flex min-h-full w-full max-w-4xl flex-col items-center gap-5 px-4 py-6">
        {/* title */}
        <div className="animate-pop-in relative flex flex-col items-center text-center">
          <div className="pointer-events-none absolute -inset-x-16 -inset-y-10">
            <FloatingWords />
          </div>
          <div className="relative mb-3">
            <div className="absolute inset-0 animate-pulse-ring rounded-3xl bg-cyan-400/30 blur-2xl" />
            <div className="relative grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-cyan-400 via-sky-500 to-violet-600 text-4xl shadow-2xl shadow-cyan-500/30">
              🎯
            </div>
          </div>
          <h1 className="shimmer-text font-display text-4xl font-black tracking-tight sm:text-5xl">
            واژه‌بار
          </h1>
          <p className="mt-1 text-sm text-slate-300 sm:text-base">
            بازی آموزش زبان انگلیسی پایهٔ هفتم متوسطه اول — درس‌های ۱ تا ۸
          </p>
        </div>

        {/* play button */}
        <button
          onClick={onStart}
          className="group relative w-full max-w-sm overflow-hidden rounded-2xl bg-gradient-to-l from-cyan-400 via-sky-500 to-violet-600 px-8 py-4 font-display text-xl font-black text-slate-950 shadow-2xl shadow-cyan-500/30 transition active:scale-95 sm:text-2xl"
        >
          <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          <span className="relative">شروع بازی ▶</span>
        </button>

        {best > 0 && (
          <div className="text-xs text-slate-400">
            رکورد شما:{" "}
            <span className="font-display font-bold text-amber-300">{best}</span> امتیاز
          </div>
        )}

        {/* lessons */}
        <section className="w-full">
          <h2 className="mb-2 flex items-center gap-2 text-sm font-bold text-slate-300">
            <span className="text-lg">📚</span> انتخاب درس
          </h2>
          <div className="no-select -mx-1 flex gap-2 overflow-x-auto px-1 pb-2">
            {lessons.map((l) => {
              const done = mastery(l.id, l.words.map((w) => w.id));
              const active = lessonId === l.id;
              const total = l.words.length;
              const pct = Math.round((done / total) * 100);
              return (
                <button
                  key={l.id}
                  onClick={() => setLessonId(l.id)}
                  className={`relative min-w-[118px] shrink-0 rounded-2xl border px-3 py-2.5 text-right transition active:scale-95 ${
                    active
                      ? "border-cyan-400/70 bg-cyan-400/15 shadow-lg shadow-cyan-500/20"
                      : "border-white/10 bg-white/5 hover:border-white/25 hover:bg-white/10"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xl">{l.emoji}</span>
                    <span className="rounded-lg bg-white/10 px-1.5 py-0.5 font-display text-[11px] font-bold text-slate-200">
                      {l.no === 0 ? "★" : l.no}
                    </span>
                  </div>
                  <div className="mt-1 text-[13px] font-bold leading-tight">{l.title}</div>
                  <div className="text-[11px] text-slate-400">{l.titleFa}</div>
                  <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, background: l.color }}
                    />
                  </div>
                  <div className="mt-1 text-[10px] text-slate-400">
                    {done}/{total} کلمه
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* modes */}
        <section className="w-full">
          <h2 className="mb-2 flex items-center gap-2 text-sm font-bold text-slate-300">
            <span className="text-lg">🎮</span> حالت بازی
          </h2>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {MODES.map((m) => {
              const active = mode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`flex items-center gap-3 rounded-2xl border px-3 py-3 text-right transition active:scale-95 ${
                    active ? "bg-white/12" : "bg-white/5 hover:bg-white/10"
                  }`}
                  style={{
                    borderColor: active ? m.color : "rgba(255,255,255,0.1)",
                    boxShadow: active ? `0 0 22px ${m.color}40` : undefined,
                  }}
                >
                  <span className="text-2xl">{m.emoji}</span>
                  <span>
                    <span className="block text-sm font-bold">{m.label}</span>
                    <span className="block text-[11px] text-slate-400">{m.sub}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* how to play */}
        <div className="w-full rounded-2xl border border-cyan-400/25 bg-cyan-400/[0.07] p-3">
          <h3 className="mb-1 text-sm font-bold text-cyan-200">🎯 چطور بازی کنم؟</h3>
          <p className="text-[13px] leading-6 text-slate-200">{MODE_HELP[mode]}</p>
          <p className="mt-1 text-[12px] leading-6 text-slate-400">
            کارت‌ها از بالا پایین می‌آیند؛ قبل از رسیدن کارتِ درست به پایین صفحه پاسخ بده! هر
            پاسخِ درست امتیاز و کمبو می‌سازد و هر ۴ پاسخ، مرحله بالا می‌رود. ⏱️
          </p>
        </div>

        {/* difficulty + options */}
        <section className="grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
            <h3 className="mb-2 text-sm font-bold text-slate-300">⏱️ سرعت بازی</h3>
            <div className="grid grid-cols-3 gap-2">
              {DIFFS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDifficulty(d.id)}
                  className={`rounded-xl border px-2 py-2 text-xs font-bold transition active:scale-95 ${
                    difficulty === d.id
                      ? "border-amber-400/70 bg-amber-400/15 text-amber-200"
                      : "border-white/10 bg-white/5 text-slate-300"
                  }`}
                >
                  <span className="block text-base">{d.emoji}</span>
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
            <h3 className="mb-2 text-sm font-bold text-slate-300">⚙️ تنظیمات</h3>
            <label className="mb-2 block">
              <span className="mb-1 block text-[11px] text-slate-400">نام شما</span>
              <input
                value={prefs.name}
                onChange={(e) => setPrefs({ ...prefs, name: e.target.value.slice(0, 16) })}
                placeholder="مثلاً: زهرا"
                className="w-full rounded-xl border border-white/10 bg-slate-900/60 px-3 py-2 text-sm outline-none transition focus:border-cyan-400/70"
              />
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setPrefs({ ...prefs, sound: !prefs.sound })}
                className={`flex-1 rounded-xl border px-2 py-2 text-xs font-bold transition active:scale-95 ${
                  prefs.sound
                    ? "border-emerald-400/60 bg-emerald-400/15 text-emerald-200"
                    : "border-white/10 bg-white/5 text-slate-400"
                }`}
              >
                {prefs.sound ? "🔊 صدا" : "🔇 صدا"}
              </button>
              <button
                onClick={() => setPrefs({ ...prefs, voice: !prefs.voice })}
                className={`flex-1 rounded-xl border px-2 py-2 text-xs font-bold transition active:scale-95 ${
                  prefs.voice
                    ? "border-violet-400/60 bg-violet-400/15 text-violet-200"
                    : "border-white/10 bg-white/5 text-slate-400"
                }`}
              >
                {prefs.voice ? "🗣️ تلفظ" : "🗣️ تلفظ"}
              </button>
            </div>
          </div>
        </section>

        {/* high scores */}
        <section className="w-full rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-300">🏆 جدول رکوردها</h3>
            {scores.length > 0 && (
              <button
                onClick={onClearScores}
                className="rounded-lg border border-rose-400/40 px-2 py-1 text-[11px] text-rose-300 transition active:scale-95"
              >
                پاک کردن
              </button>
            )}
          </div>
          {scores.length === 0 ? (
            <p className="py-3 text-center text-xs text-slate-500">
              هنوز رکوردی ثبت نشده — اولین نفر باش! 🚀
            </p>
          ) : (
            <ul className="divide-y divide-white/5">
              {scores.slice(0, 5).map((s, i) => (
                <li key={s.id} className="flex items-center gap-2 py-1.5 text-xs">
                  <span
                    className={`grid h-6 w-6 shrink-0 place-items-center rounded-lg font-display font-black ${
                      i === 0
                        ? "bg-amber-400/25 text-amber-200"
                        : i === 1
                          ? "bg-slate-300/20 text-slate-100"
                          : i === 2
                            ? "bg-orange-500/20 text-orange-200"
                            : "bg-white/5 text-slate-400"
                    }`}
                  >
                    {i + 1}
                  </span>
                  <span className="min-w-0 flex-1 truncate font-bold">{s.name || "بازیکن"}</span>
                  <span className="hidden shrink-0 text-[10px] text-slate-400 sm:block">
                    {s.lessonTitle}
                  </span>
                  <span className="shrink-0 font-display font-black text-cyan-300">
                    {s.score}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <p className="pb-4 text-center text-[11px] leading-5 text-slate-500">
          با کلیک روی کارت‌ها بازی کن • با صفحه‌کلید هم می‌شود تایپ کرد • کلید{" "}
          <span className="font-display font-bold text-slate-300">Esc</span> برای توقف
        </p>
      </div>
    </div>
  );
}
