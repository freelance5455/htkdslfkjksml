import React from 'react';
import { Play, Trophy, HelpCircle, ShieldAlert, Sparkles } from 'lucide-react';
import { GameDifficulty } from '../types/game';

interface StartScreenProps {
  onStart: (difficulty: GameDifficulty) => void;
  selectedDifficulty: GameDifficulty;
  onSelectDifficulty: (difficulty: GameDifficulty) => void;
  onOpenHowToPlay: () => void;
  onOpenHighScores: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStart,
  selectedDifficulty,
  onSelectDifficulty,
  onOpenHowToPlay,
  onOpenHighScores,
}) => {
  return (
    <div className="absolute inset-0 z-40 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-4 text-white overflow-y-auto">
      <div className="max-w-md w-full flex flex-col items-center text-center space-y-6">
        {/* Cartoon Header & Chicken Mascot */}
        <div className="relative">
          <div className="w-24 h-24 rounded-3xl bg-linear-to-tr from-amber-500 via-yellow-400 to-orange-500 flex items-center justify-center shadow-2xl shadow-amber-500/30 border-4 border-yellow-200 animate-pulse">
            <span className="text-5xl select-none">🐔</span>
          </div>
          <div className="absolute -top-2 -right-2 bg-red-600 text-white font-black text-xs px-2.5 py-0.5 rounded-full border border-white shadow-md">
            SURVIVAL!
          </div>
        </div>

        {/* Title & Subtitle */}
        <div>
          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white drop-shadow-md">
            CHASING <span className="text-amber-400">CHICKEN</span>
          </h1>
          <p className="mt-2 text-base sm:text-lg text-amber-200/90 font-medium tracking-wide">
            "Find the portal. Don't get caught!"
          </p>
        </div>

        {/* Key Game Insight Callout */}
        <div className="bg-slate-900/80 border border-slate-700/80 rounded-2xl p-3 text-xs sm:text-sm text-slate-300 shadow-inner flex items-center space-x-3 text-left">
          <Sparkles className="w-5 h-5 text-yellow-400 shrink-0" />
          <span>
            Collect the <strong>3 Crystals</strong> hidden in the maze corners to <strong>unlock the central portal</strong>! Use real bushes to survive the chickens.
          </span>
        </div>

        {/* Difficulty Selection */}
        <div className="w-full">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 block">
            Select Difficulty
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['easy', 'normal', 'hard'] as GameDifficulty[]).map((diff) => (
              <button
                key={diff}
                onClick={() => onSelectDifficulty(diff)}
                className={`py-2 px-3 rounded-xl font-black text-sm capitalize transition ${
                  selectedDifficulty === diff
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/40 border-2 border-white scale-105'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                {diff}
              </button>
            ))}
          </div>
        </div>

        {/* Big Start Button */}
        <button
          onClick={() => onStart(selectedDifficulty)}
          className="w-full py-4 px-8 rounded-2xl bg-linear-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-slate-950 font-black text-xl sm:text-2xl shadow-2xl shadow-emerald-500/50 border-3 border-emerald-200 transition flex items-center justify-center space-x-3 cursor-pointer"
        >
          <Play className="w-7 h-7 fill-slate-950" />
          <span>START ESCAPE</span>
        </button>

        {/* Secondary Buttons: How to Play & High Scores */}
        <div className="flex items-center space-x-3 w-full">
          <button
            onClick={onOpenHowToPlay}
            className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 text-slate-300 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition"
          >
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <span>How to Play</span>
          </button>
          <button
            onClick={onOpenHighScores}
            className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 text-slate-300 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>High Scores</span>
          </button>
        </div>

        {/* Controls Info Tip */}
        <div className="flex items-center space-x-2 text-[11px] text-slate-500 font-semibold">
          <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
          <span>Tap/Click to move or use WASD/Arrows.</span>
        </div>
      </div>
    </div>
  );
};
