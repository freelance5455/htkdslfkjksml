import { useState, type MouseEvent } from 'react';
import Logo from './Logo';
import ControlsHint, { useIsTouch } from './ControlsHint';
import HighScoreTable from './HighScoreTable';
import type { HighScoreEntry } from '@/game/types';

interface Props {
  onStart: () => void;
  scores: HighScoreEntry[];
  name: string;
  onNameChange: (n: string) => void;
  muted: boolean;
  onToggleMute: () => void;
}

export default function StartScreen({ onStart, scores, name, onNameChange, muted, onToggleMute }: Props) {
  const [showAll, setShowAll] = useState(false);
  const touch = useIsTouch();
  const best = scores.length ? scores[0].score : 0;

  const onBackdropClick = (e: MouseEvent<HTMLDivElement>) => {
    const t = e.target as HTMLElement;
    if (t.closest('button, input, a, label, table')) return;
    onStart();
  };

  return (
    <div
      className="absolute inset-0 z-20 flex flex-col overflow-y-auto bg-gradient-to-b from-night/70 via-night/40 to-night/85 animate-fade-in scrollbar-thin"
      onClick={onBackdropClick}
    >
      <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col items-center px-4 pb-8 pt-[max(1.5rem,env(safe-area-inset-top))]">
        <div className="animate-slide-up" style={{ animationDelay: '0.05s' }}>
          <Logo className="animate-float" />
        </div>
        <p className="mt-3 max-w-md text-center text-sm font-bold text-parchment/90 sm:text-base animate-slide-up" style={{ animationDelay: '0.15s' }}>
          Sprint down the ancient road, dodge the boulders, and run through the gate with the <span className="text-gold">right answer</span>.
          Chain correct answers to build your combo!
        </p>

        <div className="mt-6 flex w-full flex-col items-center animate-slide-up" style={{ animationDelay: '0.25s' }}>
          <button
            type="button"
            onClick={onStart}
            autoFocus
            className="btn-gold animate-pulse-glow w-full max-w-xs rounded-2xl px-8 py-4 font-display text-2xl font-black tracking-[0.15em] outline-none focus-visible:ring-4 focus-visible:ring-gold-light/70"
          >
            ▶ START RUN
          </button>
          <div className="mt-2 text-xs font-bold uppercase tracking-[0.25em] text-gold-light/70">
            {touch ? 'or tap anywhere to begin' : 'press Space or Enter'}
          </div>
        </div>

        <div className="mt-6 w-full animate-slide-up" style={{ animationDelay: '0.35s' }}>
          <ControlsHint />
        </div>

        <div className="mt-5 flex w-full flex-wrap items-center justify-between gap-3 animate-slide-up" style={{ animationDelay: '0.42s' }}>
          <label className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-gold-light/80">
            Runner
            <input
              value={name}
              onChange={(e) => onNameChange(e.target.value.toUpperCase().replace(/[^A-Z0-9 _-]/g, '').slice(0, 10))}
              maxLength={10}
              spellCheck={false}
              className="w-32 rounded-lg border border-gold-dark/60 bg-parchment px-2 py-1.5 font-body text-sm font-black tracking-widest text-ink outline-none focus:ring-2 focus:ring-gold"
              aria-label="Runner name"
            />
          </label>
          <div className="flex items-center gap-2">
            {best > 0 && (
              <div className="rounded-lg border border-gold/40 bg-ink/40 px-3 py-1.5 text-xs font-black uppercase tracking-wider text-gold-light">
                Best <span className="font-display text-gold">{best.toLocaleString('en-US')}</span>
              </div>
            )}
            <button
              type="button"
              onClick={onToggleMute}
              className="btn-ghost rounded-lg px-3 py-1.5 text-sm font-black"
              aria-label={muted ? 'Unmute sound' : 'Mute sound'}
              title={muted ? 'Unmute' : 'Mute'}
            >
              {muted ? '🔇' : '🔊'}
            </button>
          </div>
        </div>

        <div className="mt-4 w-full animate-slide-up" style={{ animationDelay: '0.5s' }}>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-display text-sm font-black tracking-[0.25em] text-gold">HALL OF RUNNERS</h2>
            {scores.length > 5 && (
              <button type="button" onClick={() => setShowAll((s) => !s)} className="text-xs font-black uppercase tracking-wider text-gold-light/80 hover:text-gold">
                {showAll ? 'Show top 5' : 'Show all'}
              </button>
            )}
          </div>
          <HighScoreTable scores={scores} limit={showAll ? 10 : 5} dark />
        </div>

        <p className="mt-6 text-center font-display text-[11px] tracking-widest text-parchment/50">
          "Your word is a lamp for my feet, a light on my path." — Psalm 119:105
        </p>
      </div>
    </div>
  );
}
