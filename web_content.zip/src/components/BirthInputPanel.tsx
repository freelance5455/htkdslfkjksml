import type { FormEvent } from 'react';
import { Calendar, Clock, Copy, RotateCcw } from 'lucide-react';

export interface PresetOption {
  label: string;
  dob: string;
  tob: string;
}

export const PRESET_OPTIONS: PresetOption[] = [
  { label: '1995', dob: '1995-08-14', tob: '06:30' },
  { label: '2000', dob: '2000-05-15', tob: '00:00' },
  { label: '2005', dob: '2005-11-15', tob: '09:15' },
  { label: 'Leap 2012', dob: '2012-02-29', tob: '12:00' },
];

interface BirthInputPanelProps {
  dob: string;
  tob: string;
  maxDate: string;
  mode: 'live' | 'custom';
  targetDate: string;
  targetTime: string;
  error: string | null;
  activePreset: string | null;
  onDobChange: (value: string) => void;
  onTobChange: (value: string) => void;
  onModeChange: (mode: 'live' | 'custom') => void;
  onTargetDateChange: (value: string) => void;
  onTargetTimeChange: (value: string) => void;
  onSelectPreset: (preset: PresetOption) => void;
  onSubmit: (e: FormEvent) => void;
  onCopy: () => void;
  onResetToday: () => void;
}

export function BirthInputPanel({
  dob,
  tob,
  maxDate,
  mode,
  targetDate,
  targetTime,
  error,
  activePreset,
  onDobChange,
  onTobChange,
  onModeChange,
  onTargetDateChange,
  onTargetTimeChange,
  onSelectPreset,
  onSubmit,
  onCopy,
  onResetToday,
}: BirthInputPanelProps) {
  return (
    <aside className="lg:sticky lg:top-20 space-y-5">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight grad-title leading-tight text-balance">
          Exact Age &amp; Life Analytics
        </h1>
        <p className="text-sm text-slate-400 leading-relaxed">
          Precision chronological counter with planetary orbits, milestones, and birth insights.
        </p>
      </div>

      <form
        onSubmit={onSubmit}
        noValidate
        className="rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold tracking-wide text-slate-300">
            Chronology Input
          </span>
          <div
            role="group"
            aria-label="Calculation mode"
            className="inline-flex rounded-lg border border-white/[0.08] bg-white/[0.03] p-0.5"
          >
            <button
              type="button"
              onClick={() => onModeChange('live')}
              className={`min-h-[32px] px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'live'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live Now
            </button>
            <button
              type="button"
              onClick={() => onModeChange('custom')}
              className={`min-h-[32px] px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'custom'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              As of Date
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-3.5">
          <div>
            <label
              htmlFor="dob-input"
              className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-slate-400"
            >
              <Calendar className="h-3.5 w-3.5 text-slate-500" aria-hidden="true" />
              <span>Date of Birth</span>
            </label>
            <input
              id="dob-input"
              type="date"
              min="1900-01-01"
              max={mode === 'live' ? maxDate : '2150-12-31'}
              value={dob}
              onChange={(e) => onDobChange(e.target.value)}
              className="min-h-[44px] w-full rounded-xl border border-white/[0.1] bg-white/[0.04] px-3.5 py-2.5 text-sm font-medium text-slate-100 outline-none transition-colors focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/25 font-mono-tabular"
            />
          </div>

          <div>
            <label
              htmlFor="tob-input"
              className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-slate-400"
            >
              <Clock className="h-3.5 w-3.5 text-slate-500" aria-hidden="true" />
              <span>Birth Time</span>
            </label>
            <input
              id="tob-input"
              type="time"
              value={tob}
              onChange={(e) => onTobChange(e.target.value)}
              className="min-h-[44px] w-full rounded-xl border border-white/[0.1] bg-white/[0.04] px-3.5 py-2.5 text-sm font-medium text-slate-100 outline-none transition-colors focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/25 font-mono-tabular"
            />
          </div>
        </div>

        {mode === 'custom' && (
          <div className="pt-3 border-t border-white/[0.07] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-300">Target Reference Date</span>
              <button
                type="button"
                onClick={onResetToday}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-400 hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="h-3 w-3" aria-hidden="true" />
                <span>Reset to today</span>
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-3.5">
              <div>
                <label htmlFor="target-date-input" className="mb-1.5 block text-xs font-medium text-slate-400">
                  Target Date
                </label>
                <input
                  id="target-date-input"
                  type="date"
                  min="1900-01-01"
                  max="2150-12-31"
                  value={targetDate}
                  onChange={(e) => onTargetDateChange(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-white/[0.1] bg-white/[0.04] px-3.5 py-2.5 text-sm font-medium text-slate-100 outline-none transition-colors focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/25 font-mono-tabular"
                />
              </div>
              <div>
                <label htmlFor="target-time-input" className="mb-1.5 block text-xs font-medium text-slate-400">
                  Target Time
                </label>
                <input
                  id="target-time-input"
                  type="time"
                  value={targetTime}
                  onChange={(e) => onTargetTimeChange(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-white/[0.1] bg-white/[0.04] px-3.5 py-2.5 text-sm font-medium text-slate-100 outline-none transition-colors focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/25 font-mono-tabular"
                />
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <span className="block text-xs font-medium text-slate-400">Quick Sample Presets</span>
          <div className="grid grid-cols-4 gap-1.5">
            {PRESET_OPTIONS.map((preset) => {
              const isSelected = activePreset === preset.dob;
              return (
                <button
                  key={preset.dob}
                  type="button"
                  onClick={() => onSelectPreset(preset)}
                  className={`min-h-[40px] rounded-lg border px-2 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'border-indigo-400/60 bg-indigo-500/20 text-indigo-200'
                      : 'border-white/[0.08] bg-white/[0.03] text-slate-300 hover:border-white/20 hover:text-white'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>

        {error && (
          <div
            role="alert"
            className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-xs font-medium text-rose-300"
          >
            {error}
          </div>
        )}

        <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 pt-1">
          <button
            type="submit"
            className="min-h-[46px] w-full rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-950/50 transition-transform hover:brightness-110 active:scale-[0.98] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          >
            Calculate Exact Age
          </button>

          <button
            type="button"
            onClick={onCopy}
            className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-white/[0.1] bg-white/[0.03] px-4 py-2.5 text-xs font-semibold text-slate-200 transition-colors hover:bg-white/[0.07] active:scale-[0.98] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            <Copy className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
            <span>Copy Summary</span>
          </button>
        </div>
      </form>
    </aside>
  );
}
