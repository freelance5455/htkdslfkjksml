import React, { useState, useEffect, useRef } from 'react';
import { 
  Cloud, 
  Folder, 
  FileText, 
  FileArchive, 
  FileCode, 
  FileSpreadsheet, 
  Image as ImageIcon, 
  Search, 
  Upload, 
  FolderPlus, 
  Trash2, 
  Download, 
  ExternalLink, 
  RefreshCw, 
  LogOut, 
  ShieldCheck, 
  AlertTriangle, 
  Check, 
  X, 
  ChevronRight, 
  Lock,
  HardDrive
} from 'lucide-react';
import { User } from 'firebase/auth';
import { signInWithGoogle, signOut, getAccessToken } from '../services/auth';
import { 
  listDriveFiles, 
  createDriveFolder, 
  uploadFileToDrive, 
  deleteDriveFile, 
  downloadDriveFile, 
  getDriveAbout,
  DriveFileItem, 
  DriveStorageQuota 
} from '../services/googleDrive';
import { exportEntireAppToDrive, ExportResult } from '../services/appExporter';

interface GoogleDriveManagerProps {
  user: User | null;
  token: string | null;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
}

export const GoogleDriveManager: React.FC<GoogleDriveManagerProps> = ({
  user,
  token,
  setUser,
  setToken,
}) => {
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Export App State
  const [isExportingApp, setIsExportingApp] = useState<boolean>(false);
  const [exportStep, setExportStep] = useState<string>('');
  const [exportResult, setExportResult] = useState<ExportResult | null>(null);
  
  // Navigation stack: [{ id: 'root', name: 'Meu Drive' }]
  const [folderStack, setFolderStack] = useState<{ id: string; name: string }[]>([
    { id: 'root', name: 'Meu Drive' }
  ]);
  const currentFolder = folderStack[folderStack.length - 1];

  const [storageQuota, setStorageQuota] = useState<DriveStorageQuota>({});
  
  // Modais
  const [showNewFolderModal, setShowNewFolderModal] = useState<boolean>(false);
  const [newFolderName, setNewFolderName] = useState<string>('');
  
  // Confirmation Modal for Destructive Delete (Mandatory requirement)
  const [deleteTargetFile, setDeleteTargetFile] = useState<DriveFileItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load files when token or folder changes
  const loadFiles = async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const driveFiles = await listDriveFiles(token, currentFolder.id, searchQuery);
      setFiles(driveFiles);

      // Load quota info
      const quota = await getDriveAbout(token);
      setStorageQuota(quota);
    } catch (err: any) {
      console.error('Failed to load drive files:', err);
      setError(err.message || 'Erro ao carregar arquivos do Google Drive.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      loadFiles();
    }
  }, [token, currentFolder.id]);

  // Handle Login
  const handleLogin = async () => {
    setIsLoggingIn(true);
    setError(null);
    try {
      const result = await signInWithGoogle();
      setUser(result.user);
      setToken(result.accessToken);
      showToast(`✓ Conectado ao Google Drive como ${result.user.displayName || result.user.email}`);
    } catch (err: any) {
      console.error('Login failed:', err);
      setError(err.message || 'Falha ao autenticar com o Google.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle Logout
  const handleLogout = async () => {
    await signOut();
    setUser(null);
    setToken(null);
    setFiles([]);
    showToast('Desconectado do Google Drive.');
  };

  // Navigate into folder
  const handleOpenFolder = (folder: DriveFileItem) => {
    setFolderStack(prev => [...prev, { id: folder.id, name: folder.name }]);
    setSearchQuery('');
  };

  // Navigate to breadcrumb level
  const handleBreadcrumbClick = (index: number) => {
    setFolderStack(prev => prev.slice(0, index + 1));
    setSearchQuery('');
  };

  // Create Folder
  const handleCreateFolder = async () => {
    if (!token || !newFolderName.trim()) return;
    try {
      const newFolder = await createDriveFolder(token, newFolderName.trim(), currentFolder.id);
      setFiles(prev => [newFolder, ...prev]);
      setShowNewFolderModal(false);
      setNewFolderName('');
      showToast(`✓ Pasta "${newFolder.name}" criada com sucesso no Google Drive.`);
    } catch (err: any) {
      alert(`Erro ao criar pasta: ${err.message}`);
    }
  };

  // Upload File
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!token || !uploaded || uploaded.length === 0) return;

    setLoading(true);
    try {
      for (let i = 0; i < uploaded.length; i++) {
        const file = uploaded[i];
        showToast(`Enviando "${file.name}" para o Google Drive...`);
        const item = await uploadFileToDrive(token, file, currentFolder.id);
        setFiles(prev => [item, ...prev]);
      }
      showToast(`✓ Arquivo(s) enviado(s) para o Google Drive com sucesso!`);
    } catch (err: any) {
      alert(`Erro no upload: ${err.message}`);
    } finally {
      setLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Confirm and Execute Delete (MANDATORY User Confirmation Dialog)
  const executeDelete = async () => {
    if (!token || !deleteTargetFile) return;
    setIsDeleting(true);
    try {
      await deleteDriveFile(token, deleteTargetFile.id);
      setFiles(prev => prev.filter(f => f.id !== deleteTargetFile.id));
      showToast(`✓ "${deleteTargetFile.name}" foi removido do Google Drive.`);
      setDeleteTargetFile(null);
    } catch (err: any) {
      alert(`Erro ao excluir: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Export Entire App to Google Drive
  const handleExportApp = async () => {
    if (!token) {
      alert("Faça login com o Google Drive primeiro para exportar o aplicativo.");
      return;
    }
    setIsExportingApp(true);
    setExportStep('Criando pasta e empacotando arquivos do projeto...');
    try {
      const res = await exportEntireAppToDrive(token, (msg) => {
        setExportStep(msg);
      });
      setExportResult(res);
      showToast(`✓ Aplicativo exportado com sucesso para "${res.folderName}" no Google Drive!`);
      await loadFiles();
    } catch (err: any) {
      console.error('Export error:', err);
      alert(`Erro ao exportar para o Google Drive: ${err.message}`);
    } finally {
      setIsExportingApp(false);
    }
  };

  // Download File
  const handleDownload = async (file: DriveFileItem) => {
    if (!token) return;
    try {
      showToast(`Baixando "${file.name}" do Google Drive...`);
      await downloadDriveFile(token, file.id, file.name);
      showToast(`✓ Download de "${file.name}" concluído.`);
    } catch (err: any) {
      alert(`Erro ao baixar: ${err.message}`);
    }
  };

  // Icon Helper
  const getFileIcon = (file: DriveFileItem) => {
    if (file.isFolder) {
      return <Folder className="w-5 h-5 text-amber-400 shrink-0" />;
    }
    const mime = file.mimeType.toLowerCase();
    if (mime.includes('image')) {
      return <ImageIcon className="w-5 h-5 text-emerald-400 shrink-0" />;
    }
    if (mime.includes('zip') || mime.includes('7z') || mime.includes('compressed') || mime.includes('tar')) {
      return <FileArchive className="w-5 h-5 text-purple-400 shrink-0" />;
    }
    if (mime.includes('spreadsheet') || mime.includes('sheet') || mime.includes('excel')) {
      return <FileSpreadsheet className="w-5 h-5 text-green-400 shrink-0" />;
    }
    if (mime.includes('script') || mime.includes('json') || mime.includes('javascript') || mime.includes('xml')) {
      return <FileCode className="w-5 h-5 text-cyan-400 shrink-0" />;
    }
    return <FileText className="w-5 h-5 text-neutral-400 shrink-0" />;
  };

  // Format bytes
  const formatBytes = (bytesStr?: string) => {
    if (!bytesStr) return '--';
    const bytes = parseInt(bytesStr, 10);
    if (isNaN(bytes)) return '--';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-black overflow-hidden relative">
      
      {/* Toast */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-neutral-700 text-white text-xs px-4 py-2 rounded-lg shadow-xl font-mono flex items-center space-x-2 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hidden file input for uploading to Drive */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        multiple
        className="hidden"
      />

      {/* STATE 1: NOT AUTHENTICATED */}
      {!token ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-6 max-w-lg mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center text-emerald-400 shadow-xl">
            <Cloud className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-lg font-bold text-white tracking-wide">
              Conectar Google Drive
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Integre sua conta do Google Drive ao <strong>Meus Arquivos PAT</strong> para salvar backups criptografados com AES-256 (.7z), sincronizar scripts e gerenciar seus arquivos na nuvem com permissão explícita.
            </p>
          </div>

          {/* Official Material Google Sign-In Button */}
          <button 
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="flex items-center space-x-3 px-5 py-3 rounded-lg bg-white hover:bg-neutral-100 text-neutral-800 font-medium text-xs shadow-md transition active:scale-98 disabled:opacity-70 cursor-pointer border border-neutral-300"
          >
            <svg className="w-4 h-4" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
            <span className="font-semibold text-neutral-800">
              {isLoggingIn ? "Conectando ao Google..." : "Fazer login com o Google"}
            </span>
          </button>

          {error && (
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs font-mono">
              {error}
            </div>
          )}

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-900 text-[11px] text-neutral-500 font-mono text-left space-y-1">
            <div className="flex items-center space-x-1.5 text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Privacidade & Segurança:</span>
            </div>
            <p>O aplicativo acessa apenas os arquivos que você selecionar com permissão. O token de acesso fica em memória durante a sessão e não é gravado em disco.</p>
          </div>
        </div>
      ) : (
        /* STATE 2: AUTHENTICATED DRIVE EXPLORER */
        <div className="flex-1 flex flex-col overflow-hidden">
          
          {/* User Profile & Drive Quota Strip */}
          <div className="h-12 px-4 border-b border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs shrink-0">
            <div className="flex items-center space-x-3">
              {user?.photoURL ? (
                <img 
                  src={user.photoURL} 
                  alt={user.displayName || 'User'} 
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full border border-neutral-700" 
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  {user?.displayName?.charAt(0) || user?.email?.charAt(0) || 'U'}
                </div>
              )}
              <div className="flex flex-col">
                <span className="font-bold text-white text-xs">{user?.displayName || 'Usuário Google'}</span>
                <span className="text-[10px] text-neutral-400 font-mono truncate max-w-[200px]">{user?.email}</span>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {storageQuota.usage && storageQuota.limit && (
                <div className="hidden md:flex items-center space-x-2 text-[11px] text-neutral-400 font-mono">
                  <HardDrive className="w-3.5 h-3.5 text-neutral-500" />
                  <span>{formatBytes(storageQuota.usage)} de {formatBytes(storageQuota.limit)}</span>
                </div>
              )}

              <button
                onClick={handleLogout}
                className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white flex items-center space-x-1.5 transition font-mono"
                title="Desconectar do Google Drive"
              >
                <LogOut className="w-3 h-3 text-neutral-400" />
                <span className="hidden sm:inline">Desconectar</span>
              </button>
            </div>
          </div>

          {/* Breadcrumbs Navigation */}
          <div className="h-10 px-4 border-b border-neutral-800/80 bg-neutral-950/70 flex items-center space-x-1 text-xs font-mono overflow-x-auto shrink-0">
            {folderStack.map((crumb, idx) => (
              <React.Fragment key={crumb.id}>
                {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-neutral-600 shrink-0" />}
                <button
                  onClick={() => handleBreadcrumbClick(idx)}
                  className={`hover:text-white transition whitespace-nowrap ${
                    idx === folderStack.length - 1 ? 'text-emerald-400 font-bold' : 'text-neutral-400'
                  }`}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Export Quick Banner */}
          <div className="p-3 bg-gradient-to-r from-emerald-950/60 to-black border-b border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 shrink-0">
                <Cloud className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-white block">Exportar Aplicativo para o Google Drive</span>
                <span className="text-[11px] text-neutral-400">
                  Cria uma pasta no seu Drive com o projeto Android Studio (.ZIP), código Kotlin, scripts e APK.
                </span>
              </div>
            </div>

            <button
              onClick={handleExportApp}
              disabled={isExportingApp}
              className="px-3.5 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs flex items-center space-x-1.5 transition shadow shrink-0 cursor-pointer disabled:opacity-50"
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>{isExportingApp ? "Exportando..." : "Exportar App Agora"}</span>
            </button>
          </div>

          {/* Toolbar */}
          <div className="p-3 border-b border-neutral-800 bg-neutral-950/80 flex flex-wrap gap-2 items-center justify-between shrink-0">
            <div className="flex items-center space-x-2">
              <button
                onClick={handleExportApp}
                disabled={isExportingApp}
                className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center space-x-1.5 transition shadow cursor-pointer disabled:opacity-50"
                title="Exportar projeto completo para o Google Drive"
              >
                <Cloud className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{isExportingApp ? "Exportando..." : "Exportar App (.ZIP)"}</span>
                <span className="sm:hidden">Exportar</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5 transition shadow"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload</span>
              </button>

              <button
                onClick={() => setShowNewFolderModal(true)}
                className="px-2.5 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white flex items-center space-x-1.5 transition"
              >
                <FolderPlus className="w-3.5 h-3.5" />
                <span>Nova Pasta</span>
              </button>

              <button
                onClick={loadFiles}
                disabled={loading}
                className="p-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-white transition"
                title="Recarregar arquivos"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Search */}
            <div className="relative flex-1 max-w-xs">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') loadFiles(); }}
                placeholder="Pesquisar no Drive..."
                className="w-full bg-black border border-neutral-800 pl-9 pr-3 py-1.5 text-xs text-white rounded-lg focus:outline-none focus:border-white transition font-mono"
              />
            </div>
          </div>

          {/* Files Grid / List */}
          <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
            {loading && files.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-neutral-400 space-y-2 text-xs font-mono">
                <RefreshCw className="w-6 h-6 animate-spin text-emerald-400" />
                <span>Carregando arquivos do Google Drive...</span>
              </div>
            ) : files.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-neutral-500 space-y-2 text-xs">
                <Cloud className="w-8 h-8 text-neutral-600" />
                <span>Nenhum arquivo encontrado nesta pasta do Google Drive.</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {files.map(file => (
                  <div
                    key={file.id}
                    onClick={() => {
                      if (file.isFolder) {
                        handleOpenFolder(file);
                      }
                    }}
                    className={`p-3 rounded-lg border transition flex flex-col justify-between group ${
                      file.isFolder 
                        ? 'bg-neutral-950/80 border-neutral-800 hover:border-amber-400/60 cursor-pointer' 
                        : 'bg-neutral-950 border-neutral-800/80 hover:border-neutral-600'
                    }`}
                  >
                    <div className="flex items-start space-x-3 truncate">
                      {getFileIcon(file)}
                      <div className="truncate flex-1">
                        <div className="text-xs font-bold text-white truncate group-hover:text-neutral-200">
                          {file.name}
                        </div>
                        <div className="text-[10px] text-neutral-500 font-mono mt-0.5">
                          {file.isFolder ? 'Pasta' : formatBytes(file.size)} · {file.modifiedTime}
                        </div>
                      </div>
                    </div>

                    {/* File Card Actions */}
                    <div className="flex items-center justify-end space-x-1 pt-3 mt-2 border-t border-neutral-900 text-neutral-400">
                      {file.webViewLink && (
                        <a
                          href={file.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={e => e.stopPropagation()}
                          className="p-1 rounded hover:bg-neutral-800 hover:text-white transition"
                          title="Abrir no Google Drive"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}

                      {!file.isFolder && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownload(file);
                          }}
                          className="p-1 rounded hover:bg-neutral-800 hover:text-white transition"
                          title="Baixar arquivo"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* Excluir (Dispara modal de confirmação explícita obrigatória) */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteTargetFile(file);
                        }}
                        className="p-1 rounded hover:bg-rose-950/60 hover:text-rose-400 transition"
                        title="Excluir do Drive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* MODAL: CRIAR NOVA PASTA NO DRIVE */}
      {showNewFolderModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl w-full max-w-sm p-4 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-neutral-800 pb-2">
              <h3 className="text-sm font-bold text-white">Nova Pasta no Google Drive</h3>
              <button onClick={() => setShowNewFolderModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-neutral-400 text-xs mb-1 font-mono">Nome da Pasta</label>
              <input
                type="text"
                value={newFolderName}
                onChange={e => setNewFolderName(e.target.value)}
                placeholder="Ex: Backups_PAT_Nuvem"
                autoFocus
                className="w-full bg-black border border-neutral-800 p-2 text-xs font-mono text-white rounded focus:border-white outline-none"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => setShowNewFolderModal(false)}
                className="px-3 py-1.5 border border-neutral-800 text-xs rounded text-neutral-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateFolder}
                className="px-4 py-1.5 bg-white text-black font-bold text-xs rounded hover:bg-neutral-200"
              >
                Criar Pasta
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANDATORY EXPLICIT CONFIRMATION DIALOG FOR DELETIONS */}
      {deleteTargetFile && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-rose-900/60 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400 border-b border-neutral-800 pb-3">
              <div className="p-2 rounded-lg bg-rose-950/80 border border-rose-800 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Confirmar Exclusão no Google Drive</h3>
                <span className="text-[11px] text-rose-400 font-mono">Operação destrutiva com permissão do usuário</span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-neutral-300">
              <p>
                Tem certeza de que deseja excluir permanentemente o item abaixo da sua conta do Google Drive?
              </p>
              <div className="p-2.5 rounded bg-black border border-neutral-800 font-mono font-bold text-white truncate">
                {deleteTargetFile.name}
              </div>
              <p className="text-[11px] text-neutral-400">
                Esta ação enviará o item para a lixeira do seu Google Drive e removerá o acesso a partir desta aplicação.
              </p>
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-neutral-800">
              <button
                disabled={isDeleting}
                onClick={() => setDeleteTargetFile(null)}
                className="px-4 py-1.5 border border-neutral-800 text-xs rounded text-neutral-300 hover:text-white"
              >
                Cancelar
              </button>
              <button
                disabled={isDeleting}
                onClick={executeDelete}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded transition flex items-center space-x-1.5"
              >
                {isDeleting ? "Excluindo..." : "Sim, Excluir do Drive"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EXPORTANDO APLICATIVO PARA O GOOGLE DRIVE */}
      {isExportingApp && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-emerald-800/80 rounded-xl w-full max-w-md p-6 space-y-4 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-400 mx-auto flex items-center justify-center animate-bounce">
              <Cloud className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white tracking-wide">
                Exportando para o Google Drive
              </h3>
              <p className="text-xs text-neutral-400">
                Criando o pacote completo do aplicativo e enviando para a sua nuvem...
              </p>
            </div>

            {/* Current Step */}
            <div className="p-3 rounded-lg bg-black border border-neutral-800 text-xs font-mono text-emerald-300">
              {exportStep}
            </div>

            <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
              <div className="bg-emerald-400 h-full w-3/4 animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RESULTADO DA EXPORTAÇÃO COM SUCESSO */}
      {exportResult && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-emerald-700/80 rounded-xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2 text-emerald-400">
                <Check className="w-5 h-5" />
                <h3 className="text-sm font-bold text-white">Aplicativo Exportado com Sucesso!</h3>
              </div>
              <button 
                onClick={() => setExportResult(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-neutral-300 leading-relaxed">
                O projeto completo do <strong>Meus Arquivos PAT</strong> foi empacotado e salvo com sucesso na sua conta do Google Drive dentro da pasta:
              </p>

              <div className="p-3 rounded-lg bg-black border border-neutral-800 font-mono text-xs text-emerald-400 font-bold truncate">
                📁 {exportResult.folderName}
              </div>

              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-mono text-neutral-400 block font-bold">Arquivos enviados para a nuvem:</span>
                <div className="max-h-36 overflow-y-auto space-y-1 p-2 rounded bg-neutral-900/60 border border-neutral-800 font-mono text-[11px] custom-scrollbar">
                  {exportResult.uploadedFiles.map(f => (
                    <div key={f.id} className="flex items-center justify-between text-neutral-300">
                      <span className="truncate">{f.name}</span>
                      <span className="text-neutral-500 text-[10px] ml-2">Enviado</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-neutral-800">
              <button
                onClick={() => setExportResult(null)}
                className="px-4 py-2 bg-white text-black font-bold text-xs rounded hover:bg-neutral-200 transition"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
