import React from 'react';
import { BookOpen, Sparkles } from 'lucide-react';

const VERSES = [
  { text: "The Lord is my strength and my shield; my heart trusts in him, and he helps me.", ref: "Psalm 28:7" },
  { text: "Be still, and know that I am God.", ref: "Psalm 46:10" },
  { text: "You will keep in perfect peace those whose minds are steadfast, because they trust in you.", ref: "Isaiah 26:3" },
  { text: "The Lord your God is with you wherever you go.", ref: "Joshua 1:9" },
  { text: "Cast all your anxiety on him because he cares for you.", ref: "1 Peter 5:7" },
  { text: "O Lord, you are my God; I will exalt you and praise your name.", ref: "Isaiah 25:1" }
];

export const VerseOfTheDayBanner: React.FC = () => {
  // Pick verse based on day of year
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  const currentVerse = VERSES[dayOfYear % VERSES.length];

  return (
    <div className="bg-gradient-to-r from-amber-950/70 via-slate-900 to-amber-950/70 p-4 sm:p-5 rounded-2xl border border-amber-500/30 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center shrink-0">
          <BookOpen className="w-5 h-5 text-amber-400" />
        </div>
        <div>
          <div className="flex items-center space-x-1.5 text-[10px] font-mono font-bold text-amber-400">
            <Sparkles className="w-3 h-3" />
            <span>VERSE OF THE DAY • {currentVerse.ref}</span>
          </div>
          <p className="text-xs sm:text-sm text-amber-100 font-serif italic mt-0.5">
            &ldquo;{currentVerse.text}&rdquo;
          </p>
        </div>
      </div>
      <div className="shrink-0">
        <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 px-3 py-1.5 rounded-xl border border-amber-500/30 block">
          Daily Grace & Truth 🙏
        </span>
      </div>
    </div>
  );
};
