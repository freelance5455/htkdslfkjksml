import React, { useState } from 'react';
import {
  X,
  Bell,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Cake,
  BookOpen,
  Send,
  Trash2,
  Clock,
  Sparkles,
} from 'lucide-react';
import { UserSettings, CalendarDay, LocationPreset } from '../types';
import {
  requestNotificationPermission,
  sendBrowserNotification,
  getStoredNotifications,
  clearAllNotifications,
  logInAppNotification,
  AppNotification,
} from '../services/notificationService';

interface HolidayAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  todayDay: CalendarDay;
  location: LocationPreset;
}

export const HolidayAlertsModal: React.FC<HolidayAlertsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  todayDay,
  location,
}) => {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>(() => {
    return 'Notification' in window ? Notification.permission : 'denied';
  });

  const [testSent, setTestSent] = useState(false);
  const [notificationsLog, setNotificationsLog] = useState<AppNotification[]>(() =>
    getStoredNotifications()
  );

  if (!isOpen) return null;

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setPermissionStatus(perm);
    if (perm === 'granted') {
      onUpdateSettings({
        notifications: {
          ...settings.notifications,
          enabled: true,
        },
      });
      sendBrowserNotification('✡️ Hebrew Calendar Notifications Enabled', {
        body: `You will receive Shabbat candle lighting alerts, fast day reminders, and holiday updates for ${location.name}.`,
      });
    }
  };

  const handleSendTestNotification = () => {
    const title = `🕯️ Shabbat Candle Lighting Test Alert`;
    const body = `Shabbat candle lighting is at ${todayDay.candleLighting || '18:42'} in ${location.name}. Shabbat Shalom!`;

    sendBrowserNotification(title, { body });
    const item = logInAppNotification({
      title,
      body,
      category: 'shabbat',
    });
    setNotificationsLog([item, ...notificationsLog]);

    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  };

  const handleClearHistory = () => {
    clearAllNotifications();
    setNotificationsLog([]);
  };

  const updateNotifSetting = (key: keyof UserSettings['notifications'], value: any) => {
    onUpdateSettings({
      notifications: {
        ...settings.notifications,
        [key]: value,
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-2xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#252525] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#EAEAEA]">
                Holiday Alerts & Zmanim Notifications
              </h3>
              <p className="text-xs text-[#888888]">
                Customizable reminders for Shabbat, Jewish holidays, fasts, and Yahrzeits
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* Permission Status Banner */}
          <div className="p-4 rounded-xl border border-[#2A2A2A] bg-[#161616] flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {permissionStatus === 'granted' ? (
                <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              ) : (
                <div className="w-8 h-8 rounded-lg bg-amber-950 border border-amber-800 text-amber-400 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-4 h-4" />
                </div>
              )}
              <div>
                <div className="text-xs font-bold text-[#EAEAEA]">
                  {permissionStatus === 'granted'
                    ? 'Browser Notifications Active'
                    : 'Browser Permissions Needed'}
                </div>
                <div className="text-[11px] text-[#888888]">
                  {permissionStatus === 'granted'
                    ? 'Alerts will appear on your device according to your preferences below'
                    : 'Allow notifications to receive timely candle lighting & holiday alerts'}
                </div>
              </div>
            </div>

            {permissionStatus !== 'granted' && (
              <button
                onClick={handleRequestPermission}
                className="px-4 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold shrink-0 transition-colors"
              >
                Enable Alerts
              </button>
            )}
          </div>

          {/* Alert Categories */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-[#555555] uppercase tracking-[0.2em] block">
              Notification Preferences
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Shabbat Candle Lighting */}
              <div className="p-3.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#EAEAEA] flex items-center gap-1.5">
                    <span>🕯️</span>
                    <span>Shabbat Candle Lighting</span>
                  </div>
                  <div className="text-[11px] text-[#888888]">
                    18 min before sunset on Fridays
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notifications.shabbatCandles}
                  onChange={(e) => updateNotifSetting('shabbatCandles', e.target.checked)}
                  className="w-4 h-4 accent-[#C5A267] rounded-sm cursor-pointer"
                />
              </div>

              {/* Major Holidays */}
              <div className="p-3.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#EAEAEA] flex items-center gap-1.5">
                    <span>✡️</span>
                    <span>Jewish Holidays</span>
                  </div>
                  <div className="text-[11px] text-[#888888]">
                    Eve of Yom Tov and major Chagim
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notifications.holidays}
                  onChange={(e) => updateNotifSetting('holidays', e.target.checked)}
                  className="w-4 h-4 accent-[#C5A267] rounded-sm cursor-pointer"
                />
              </div>

              {/* Fast Days & Zmanim */}
              <div className="p-3.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#EAEAEA] flex items-center gap-1.5">
                    <span>⏳</span>
                    <span>Fast Days & Zmanim</span>
                  </div>
                  <div className="text-[11px] text-[#888888]">
                    Fast start & prayer time reminders
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notifications.zmanimAlerts}
                  onChange={(e) => updateNotifSetting('zmanimAlerts', e.target.checked)}
                  className="w-4 h-4 accent-[#C5A267] rounded-sm cursor-pointer"
                />
              </div>

              {/* Personal Hebrew Events */}
              <div className="p-3.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#EAEAEA] flex items-center gap-1.5">
                    <span>⭐</span>
                    <span>Yahrzeits & Birthdays</span>
                  </div>
                  <div className="text-[11px] text-[#888888]">
                    Reminders for personal Hebrew dates
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notifications.personalEvents}
                  onChange={(e) => updateNotifSetting('personalEvents', e.target.checked)}
                  className="w-4 h-4 accent-[#C5A267] rounded-sm cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Test Alert Button */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#161616] border border-[#2A2A2A]">
            <div>
              <div className="text-xs font-bold text-[#EAEAEA]">Test Alert Dispatch</div>
              <div className="text-[11px] text-[#888888]">Send an immediate test alert to verify notification delivery</div>
            </div>
            <button
              onClick={handleSendTestNotification}
              className="px-3.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#C5A267] flex items-center gap-1.5 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{testSent ? 'Sent!' : 'Send Test'}</span>
            </button>
          </div>

          {/* Notification History Log */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#555555] uppercase tracking-[0.2em]">
                Recent Notification Log
              </span>
              {notificationsLog.length > 0 && (
                <button
                  onClick={handleClearHistory}
                  className="text-xs text-[#888888] hover:text-rose-400 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" /> Clear
                </button>
              )}
            </div>

            <div className="divide-y divide-[#2A2A2A] rounded-xl border border-[#2A2A2A] bg-[#161616] max-h-48 overflow-y-auto">
              {notificationsLog.length > 0 ? (
                notificationsLog.map((notif) => (
                  <div key={notif.id} className="p-3 text-xs flex justify-between items-start">
                    <div>
                      <div className="font-bold text-[#EAEAEA]">{notif.title}</div>
                      <div className="text-[#888888] text-[11px] mt-0.5">{notif.body}</div>
                    </div>
                    <span className="text-[10px] text-[#666666] font-mono shrink-0 ml-2">
                      {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-[#555555] text-xs">
                  No notifications recorded yet.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2A2A2A] bg-[#161616] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
