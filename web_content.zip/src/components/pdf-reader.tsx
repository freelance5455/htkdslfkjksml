import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Download, X } from "lucide-react";
import { base64ToBytes, downloadPdf } from "@/components/bits";

type PdfDoc = {
  numPages: number;
  getPage: (page: number) => Promise<{
    getViewport: (params: { scale: number }) => { width: number; height: number };
    render: (params: {
      canvasContext: CanvasRenderingContext2D;
      viewport: { width: number; height: number };
    }) => { promise: Promise<void>; cancel: () => void };
  }>;
  destroy: () => Promise<void>;
};

export function PdfReader({
  title,
  writer,
  pdfBase64,
  onClose,
}: {
  title: string;
  writer: string;
  pdfBase64: string;
  onClose: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const docRef = useRef<PdfDoc | null>(null);
  const [page, setPage] = useState(1);
  const [numPages, setNumPages] = useState(1);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [detail, setDetail] = useState("Opening the book…");

  useEffect(() => {
    let cancelled = false;
    let task: { destroy: () => Promise<void> } | null = null;
    (async () => {
      const pdfjs = await import("pdfjs-dist");
      const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
      pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
      const data = base64ToBytes(pdfBase64);
      const loadingTask = pdfjs.getDocument({ data });
      task = loadingTask;
      const doc = (await loadingTask.promise) as unknown as PdfDoc;
      if (cancelled) {
        await doc.destroy();
        return;
      }
      docRef.current = doc;
      setNumPages(doc.numPages);
      setPage(1);
      setStatus("ready");
    })().catch((err: unknown) => {
      if (cancelled) return;
      setStatus("error");
      setDetail(err instanceof Error ? err.message : "This PDF could not be opened.");
    });
    return () => {
      cancelled = true;
      void task?.destroy();
      void docRef.current?.destroy();
      docRef.current = null;
    };
  }, [pdfBase64]);

  useEffect(() => {
    if (status !== "ready") return;
    const doc = docRef.current;
    const canvas = canvasRef.current;
    if (!doc || !canvas) return;
    let cancelled = false;
    let renderTask: { promise: Promise<void>; cancel: () => void } | null = null;
    (async () => {
      const pageObj = await doc.getPage(page);
      if (cancelled) return;
      const parentWidth = canvas.parentElement?.clientWidth ?? 720;
      const base = pageObj.getViewport({ scale: 1 });
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssWidth = Math.max(240, Math.min(parentWidth - 8, 860));
      const viewport = pageObj.getViewport({ scale: (cssWidth / base.width) * dpr });
      const context = canvas.getContext("2d");
      if (!context) return;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      canvas.style.width = `${viewport.width / dpr}px`;
      canvas.style.height = `${viewport.height / dpr}px`;
      renderTask = pageObj.render({ canvasContext: context, viewport });
      await renderTask.promise;
    })().catch(() => {
      if (!cancelled) {
        setStatus("error");
        setDetail("A page failed to draw. You can still download the file.");
      }
    });
    return () => {
      cancelled = true;
      renderTask?.cancel();
    };
  }, [page, status]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowRight") setPage((current) => Math.min(numPages, current + 1));
      if (event.key === "ArrowLeft") setPage((current) => Math.max(1, current - 1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [numPages, onClose]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-ink text-on-ink">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b reader-rule px-4 py-3">
        <div className="min-w-0">
          <h2 className="truncate font-display text-xl text-on-ink">{title}</h2>
          <p className="truncate text-sm soft-on-ink">{writer}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="reader-chip rounded-full px-3 py-2 text-sm tabular-nums">
            Page {page} / {numPages}
          </span>
          <button
            type="button"
            className="btn reader-chip"
            onClick={() => setPage((current) => Math.max(1, current - 1))}
            disabled={page <= 1}
          >
            <ChevronLeft className="size-4" /> Prev
          </button>
          <button
            type="button"
            className="btn reader-chip"
            onClick={() => setPage((current) => Math.min(numPages, current + 1))}
            disabled={page >= numPages}
          >
            Next <ChevronRight className="size-4" />
          </button>
          <button type="button" className="btn btn-primary" onClick={() => downloadPdf(pdfBase64, title)}>
            <Download className="size-4" /> Download
          </button>
          <button type="button" className="btn reader-chip size-11 px-0" aria-label="Close reader" onClick={onClose}>
            <X className="size-4" />
          </button>
        </div>
      </div>
      <div className="flex flex-1 justify-center overflow-auto px-4 py-6">
        {status === "ready" ? (
          <canvas ref={canvasRef} className="h-auto max-w-full rounded-lg bg-surface shadow-2xl" />
        ) : (
          <p className="max-w-md pt-16 text-center text-on-ink">{detail}</p>
        )}
      </div>
    </div>
  );
}
