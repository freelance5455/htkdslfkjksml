import React, { useCallback, useEffect, useRef, useState } from 'react';
import { getCachedImage, preloadGameImage, useAssetSrc } from '../utils/gameAssets';
import { sound } from '../utils/sound';
const LOGICAL_W = 360;
const LOGICAL_H = 640;
const FLOOR_Y = LOGICAL_H - 6;
const BIRD_X = 96;
const BIRD_HIT_RADIUS = 15;
const BIRD_DRAW_SIZE = 78;
const SPRITE_FRAMES = 12;
const SPRITE_FRAME_SIZE = 144;
const BEST_SCORE_KEY = 'flapora_best_score_v1';
function readStoredNumber(key) {
    try {
        const val = Number(window.localStorage.getItem(key) ?? '0');
        return Number.isFinite(val) ? val : 0;
    }
    catch {
        return 0;
    }
}
export const FlaporaGame = ({ language, backgroundSrc, birdSkin, pipeSkin, onExitToMenu, }) => {
    const isAr = language === 'ar';
    const canvasRef = useRef(null);
    const bgImgRef = useRef(getCachedImage(backgroundSrc));
    const birdSheetRef = useRef(getCachedImage(birdSkin.gameSrc));
    const pipeImgRef = useRef(getCachedImage(pipeSkin.src));
    const birdSkinRef = useRef(birdSkin);
    useEffect(() => {
        birdSkinRef.current = birdSkin;
    }, [birdSkin]);
    const [status, setStatus] = useState('READY');
    const [score, setScore] = useState(0);
    const [bestScore, setBestScore] = useState(() => readStoredNumber(BEST_SCORE_KEY));
    const [isNewBest, setIsNewBest] = useState(false);
    const hudTrophySrc = useAssetSrc('assets/flapora/FLAPORA_trophy.webp');
    const homeBtnSrc = useAssetSrc('assets/flapora/FLAPORA_home.webp');
    const replayBtnSrc = useAssetSrc('assets/flapora/FLAPORA_replay.webp');
    const royalTrophySrc = useAssetSrc('assets/flapora/FLAPORA_trophy_royal.webp');
    const silverTrophySrc = useAssetSrc('assets/flapora/FLAPORA_trophy_silver.webp');
    const bronzeTrophySrc = useAssetSrc('assets/flapora/FLAPORA_trophy_bronze.webp');
    const statusRef = useRef('READY');
    useEffect(() => {
        statusRef.current = status;
    }, [status]);
    const gameRef = useRef({
        birdY: 268,
        birdVy: 0,
        birdTilt: 0,
        spriteFrame: 0,
        flapBoostTimer: 0,
        shakeTimer: 0,
        pillars: [],
        particles: [],
        score: 0,
        gameOverHandled: false,
    });
    // Load dynamic background whenever user changes it (instant if already cached)
    useEffect(() => {
        let active = true;
        const cached = getCachedImage(backgroundSrc);
        if (cached) {
            bgImgRef.current = cached;
        }
        void preloadGameImage(backgroundSrc).then((img) => {
            if (active && img)
                bgImgRef.current = img;
        });
        return () => {
            active = false;
        };
    }, [backgroundSrc]);
    // Ensure equipped bird skin and pipe skin are ready immediately
    useEffect(() => {
        let active = true;
        const cachedBird = getCachedImage(birdSkin.gameSrc);
        if (cachedBird)
            birdSheetRef.current = cachedBird;
        void preloadGameImage(birdSkin.gameSrc).then((img) => {
            if (active && img)
                birdSheetRef.current = img;
        });
        const cachedPipe = getCachedImage(pipeSkin.src);
        if (cachedPipe)
            pipeImgRef.current = cachedPipe;
        void preloadGameImage(pipeSkin.src).then((img) => {
            if (active && img)
                pipeImgRef.current = img;
        });
        return () => {
            active = false;
        };
    }, [birdSkin.gameSrc, pipeSkin.src]);
    const spawnPillar = useCallback((xPos, currentScore) => {
        const difficultyRatio = Math.min(1, currentScore / 80);
        const gapHeight = 214 - difficultyRatio * 68; // Smoothly narrows from 214px down to 146px
        const minCenter = 108 + gapHeight / 2;
        const maxCenter = LOGICAL_H - 92 - gapHeight / 2;
        const prevPillar = gameRef.current.pillars[gameRef.current.pillars.length - 1];
        let gapY;
        if (prevPillar) {
            const maxDelta = 110 + difficultyRatio * 80; // Gradually allows wider height changes
            const low = Math.max(minCenter, prevPillar.gapY - maxDelta);
            const high = Math.min(maxCenter, prevPillar.gapY + maxDelta);
            gapY = low + Math.random() * (high - low);
        }
        else {
            const mid = (minCenter + maxCenter) / 2;
            gapY = mid + (Math.random() - 0.5) * 90;
        }
        gameRef.current.pillars.push({
            x: xPos,
            width: 92,
            gapY,
            gapHeight,
            passed: false,
        });
    }, []);
    const resetRun = useCallback(() => {
        gameRef.current = {
            birdY: 268,
            birdVy: 0,
            birdTilt: 0,
            spriteFrame: 0,
            flapBoostTimer: 0,
            shakeTimer: 0,
            pillars: [],
            particles: [],
            score: 0,
            gameOverHandled: false,
        };
        setScore(0);
        setIsNewBest(false);
        setStatus('READY');
        statusRef.current = 'READY';
        sound.startMusic();
    }, []);
    const emitParticles = useCallback((x, y, count, color) => {
        for (let i = 0; i < count; i++) {
            gameRef.current.particles.push({
                x: x + (Math.random() * 8 - 4),
                y: y + (Math.random() * 8 - 4),
                vx: -45 - Math.random() * 75,
                vy: 15 + Math.random() * 80,
                radius: 2.4 + Math.random() * 2.8,
                alpha: 0.95,
                color,
            });
        }
    }, []);
    const flap = useCallback(() => {
        const current = statusRef.current;
        if (current === 'GAME_OVER')
            return;
        const g = gameRef.current;
        if (current === 'READY') {
            setStatus('PLAYING');
            statusRef.current = 'PLAYING';
            spawnPillar(LOGICAL_W + 90, 0);
            spawnPillar(LOGICAL_W + 342, 0);
        }
        g.birdVy = -315;
        g.flapBoostTimer = 0.28;
        emitParticles(BIRD_X - 16, g.birdY + 6, 5, birdSkinRef.current.trailColor);
        sound.playFlap();
    }, [emitParticles, spawnPillar]);
    // Keyboard shortcuts
    useEffect(() => {
        const onKeyDown = (e) => {
            if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
                if (statusRef.current === 'READY' || statusRef.current === 'PLAYING') {
                    e.preventDefault();
                    flap();
                }
            }
            else if (e.code === 'Escape') {
                sound.playClick();
                onExitToMenu();
            }
        };
        window.addEventListener('keydown', onKeyDown);
        return () => window.removeEventListener('keydown', onKeyDown);
    }, [flap, onExitToMenu]);
    // Main 60fps requestAnimationFrame loop
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas)
            return;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = LOGICAL_W * dpr;
        canvas.height = LOGICAL_H * dpr;
        let rafId = 0;
        let lastTime = performance.now();
        const triggerGameOver = () => {
            const g = gameRef.current;
            if (g.gameOverHandled)
                return;
            g.gameOverHandled = true;
            g.shakeTimer = 0.24;
            emitParticles(BIRD_X, g.birdY, 14, '#FDE047');
            sound.playCrash();
            const prevBest = readStoredNumber(BEST_SCORE_KEY);
            const nextBest = Math.max(prevBest, g.score);
            if (g.score > prevBest) {
                setIsNewBest(true);
            }
            setBestScore(nextBest);
            try {
                window.localStorage.setItem(BEST_SCORE_KEY, String(nextBest));
            }
            catch {
                // ignore storage restrictions
            }
            setStatus('GAME_OVER');
            statusRef.current = 'GAME_OVER';
        };
        const tick = (now) => {
            const dt = Math.min((now - lastTime) / 1000, 0.035);
            lastTime = now;
            const g = gameRef.current;
            const current = statusRef.current;
            const difficultyRatio = Math.min(1, g.score / 80);
            const speed = 145 + difficultyRatio * 80; // Smoothly ramps 145 -> 225
            const gravity = 880;
            const spawnGap = 252 - difficultyRatio * 46; // Smoothly tightens 252 -> 206
            if (current === 'READY') {
                g.birdY = 268 + Math.sin(now * 0.0045) * 9;
                g.birdTilt = 0;
                g.spriteFrame = (g.spriteFrame + 12 * dt) % SPRITE_FRAMES;
            }
            else if (current === 'PLAYING') {
                if (g.flapBoostTimer > 0) {
                    g.flapBoostTimer = Math.max(0, g.flapBoostTimer - dt);
                }
                const animFps = g.flapBoostTimer > 0 ? 24 : 11;
                g.spriteFrame = (g.spriteFrame + animFps * dt) % SPRITE_FRAMES;
                g.birdVy = Math.min(g.birdVy + gravity * dt, 420);
                g.birdY += g.birdVy * dt;
                // Subtle, gentle tilt (-9 deg up on flap, +12 deg gentle tilt down)
                const targetTilt = Math.max(-0.16, Math.min(0.22, g.birdVy / 1500));
                g.birdTilt += (targetTilt - g.birdTilt) * Math.min(1, dt * 10);
                if (g.birdY < BIRD_HIT_RADIUS + 6) {
                    g.birdY = BIRD_HIT_RADIUS + 6;
                    g.birdVy = 0;
                }
                if (g.birdY + BIRD_HIT_RADIUS >= FLOOR_Y) {
                    g.birdY = FLOOR_Y - BIRD_HIT_RADIUS;
                    triggerGameOver();
                }
                // Pillars update & collisions
                for (let i = g.pillars.length - 1; i >= 0; i--) {
                    const p = g.pillars[i];
                    p.x -= speed * dt;
                    if (!p.passed && p.x + p.width < BIRD_X) {
                        p.passed = true;
                        g.score += 1;
                        setScore(g.score);
                        sound.playScore();
                    }
                    const forgiveY = 6;
                    const shaftInsetX = 15;
                    const topEdge = p.gapY - p.gapHeight / 2;
                    const botEdge = p.gapY + p.gapHeight / 2;
                    const overlapX = BIRD_X + BIRD_HIT_RADIUS - forgiveY > p.x + shaftInsetX &&
                        BIRD_X - BIRD_HIT_RADIUS + forgiveY < p.x + p.width - shaftInsetX;
                    const hitsTop = g.birdY - BIRD_HIT_RADIUS + forgiveY < topEdge;
                    const hitsBot = g.birdY + BIRD_HIT_RADIUS - forgiveY > botEdge;
                    if (overlapX && (hitsTop || hitsBot)) {
                        triggerGameOver();
                    }
                    if (p.x + p.width < -24) {
                        g.pillars.splice(i, 1);
                    }
                }
                const lastPillar = g.pillars[g.pillars.length - 1];
                if (!lastPillar || LOGICAL_W - lastPillar.x >= spawnGap) {
                    spawnPillar(LOGICAL_W + 24, g.score);
                }
            }
            if (g.shakeTimer > 0) {
                g.shakeTimer = Math.max(0, g.shakeTimer - dt);
            }
            for (let i = g.particles.length - 1; i >= 0; i--) {
                const pt = g.particles[i];
                pt.x += pt.vx * dt;
                pt.y += pt.vy * dt;
                pt.alpha -= dt * 2.2;
                if (pt.alpha <= 0) {
                    g.particles.splice(i, 1);
                }
            }
            // === RENDER ===
            ctx.save();
            ctx.scale(dpr, dpr);
            if (g.shakeTimer > 0) {
                const mag = 5 * (g.shakeTimer / 0.24);
                ctx.translate((Math.random() - 0.5) * mag * 2, (Math.random() - 0.5) * mag * 2);
            }
            // 1. Background (center-cropped cover fit)
            if (bgImgRef.current && bgImgRef.current.naturalWidth > 0) {
                const img = bgImgRef.current;
                const imgRatio = img.naturalWidth / img.naturalHeight;
                const canvasRatio = LOGICAL_W / LOGICAL_H;
                let sx = 0;
                let sy = 0;
                let sw = img.naturalWidth;
                let sh = img.naturalHeight;
                if (imgRatio > canvasRatio) {
                    sw = img.naturalHeight * canvasRatio;
                    sx = (img.naturalWidth - sw) / 2;
                }
                else if (imgRatio < canvasRatio) {
                    sh = img.naturalWidth / canvasRatio;
                    sy = (img.naturalHeight - sh) / 2;
                }
                ctx.drawImage(img, sx, sy, sw, sh, 0, 0, LOGICAL_W, LOGICAL_H);
            }
            else {
                const grad = ctx.createLinearGradient(0, 0, 0, LOGICAL_H);
                grad.addColorStop(0, '#0284C7');
                grad.addColorStop(0.7, '#7DD3FC');
                grad.addColorStop(1, '#4ADE80');
                ctx.fillStyle = grad;
                ctx.fillRect(0, 0, LOGICAL_W, LOGICAL_H);
            }
            // 2. Emerald Sky-Kingdom Pipes (bottom pipe extends from bottom edge of screen)
            for (const p of g.pillars) {
                const topH = p.gapY - p.gapHeight / 2;
                const botY = p.gapY + p.gapHeight / 2;
                const botH = LOGICAL_H - botY;
                drawSkyTower(ctx, pipeImgRef.current, p.x, 0, p.width, topH, true);
                drawSkyTower(ctx, pipeImgRef.current, p.x, botY, p.width, botH, false);
            }
            // 3. Particles
            for (const pt of g.particles) {
                ctx.save();
                ctx.globalAlpha = Math.max(0, pt.alpha);
                ctx.fillStyle = pt.color;
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
            // 5. Animated Bird Sprite with subtle gentle tilt
            ctx.save();
            ctx.translate(BIRD_X, g.birdY);
            ctx.rotate(g.birdTilt);
            if (birdSheetRef.current) {
                if (birdSkinRef.current.isSpriteSheet) {
                    const frameIdx = Math.floor(g.spriteFrame) % SPRITE_FRAMES;
                    ctx.drawImage(birdSheetRef.current, frameIdx * SPRITE_FRAME_SIZE, 0, SPRITE_FRAME_SIZE, SPRITE_FRAME_SIZE, -BIRD_DRAW_SIZE / 2, -BIRD_DRAW_SIZE / 2, BIRD_DRAW_SIZE, BIRD_DRAW_SIZE);
                }
                else {
                    const beatFreq = g.flapBoostTimer > 0 ? 0.032 : 0.015;
                    const beat = Math.sin(now * beatFreq);
                    ctx.scale(1 + beat * 0.04, 1 - beat * 0.06);
                    ctx.drawImage(birdSheetRef.current, -BIRD_DRAW_SIZE / 2, -BIRD_DRAW_SIZE / 2, BIRD_DRAW_SIZE, BIRD_DRAW_SIZE);
                }
            }
            else {
                ctx.beginPath();
                ctx.arc(0, 0, BIRD_HIT_RADIUS, 0, Math.PI * 2);
                ctx.fillStyle = '#0EA5E9';
                ctx.fill();
            }
            ctx.restore();
            ctx.restore();
            rafId = requestAnimationFrame(tick);
        };
        rafId = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(rafId);
    }, [emitParticles, spawnPillar]);
    return (<div className="relative w-full h-full select-none overflow-hidden">
      <canvas ref={canvasRef} onPointerDown={flap} className="w-full h-full block cursor-pointer touch-none"/>

      {/* Top HUD */}
      <div className="pointer-events-none absolute top-0 inset-x-0 px-3.5 pt-3 flex items-center justify-between">
        {/* Best Score with Glossy Trophy Icon */}
        <div className="flex items-center gap-1.5 text-lg font-display font-bold tabular-nums text-white drop-shadow-[0_2px_4px_rgba(15,23,42,0.8)]">
          <img src={hudTrophySrc} alt="Best Score" referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-9 h-9 object-contain drop-shadow-[0_3px_5px_rgba(15,23,42,0.5)] select-none"/>
          <span>{Math.max(bestScore, score)}</span>
        </div>

        {/* Active Score */}
        <div className="font-display text-4xl font-bold text-white tabular-nums drop-shadow-[0_3px_0_rgba(30,27,75,0.85)]">
          {score}
        </div>

        {/* Home Button returning to main UI */}
        <div className="pointer-events-auto">
          <button type="button" onClick={() => {
            sound.playClick();
            onExitToMenu();
        }} aria-label="القائمة الرئيسية" className="w-11 h-11 flex items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-300 rounded-xl">
            <img src={homeBtnSrc} alt="القائمة الرئيسية" referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-full h-full object-contain drop-shadow-[0_4px_6px_rgba(15,23,42,0.5)] select-none"/>
          </button>
        </div>
      </div>

      {/* Ready prompt before first flap */}
      {status === 'READY' && (<div dir={isAr ? 'rtl' : 'ltr'} className="pointer-events-none absolute inset-x-0 bottom-[26%] flex justify-center px-6 text-center">
          <p className={`${isAr ? 'font-arabic' : 'font-display'} text-base font-bold text-white drop-shadow-[0_2px_6px_rgba(15,23,42,0.85)] animate-pulse`}>
            {isAr
                ? 'اضغط أو استخدم زر المسافة للتحليق'
                : 'Tap, Click, or Press Space to Flap'}
          </p>
        </div>)}

      {/* Game Over Board */}
      {status === 'GAME_OVER' && (<div dir={isAr ? 'rtl' : 'ltr'} className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs flex flex-col items-center justify-center p-5 z-20">
          <div className={`relative w-full max-w-[305px] pt-5 ${isAr ? 'font-arabic' : ''}`}>
            {/* Overlapping Top Ribbon Banner */}
            <div className="absolute top-0 inset-x-0 flex justify-center z-10">
              <div className="px-7 py-2 rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-600 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-bold text-xl tracking-wide drop-shadow-[0_2px_0_rgba(69,26,3,0.9)]">
                {isAr ? 'انتهت الجولة' : 'Game Over'}
              </div>
            </div>

            {/* Cartoon Wood & Cream Parchment Scoreboard */}
            <div className="rounded-[28px] bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 border-[3px] border-amber-950 p-2 shadow-[0_10px_0_#451A03,0_22px_45px_rgba(0,0,0,0.55)]">
              <div className="rounded-[20px] bg-gradient-to-b from-amber-50 to-amber-100 border-2 border-amber-800/30 px-4 pt-8 pb-5 text-amber-950">
                {isNewBest && (<div className="text-center mb-3">
                    <span className="inline-block px-3 py-0.5 rounded-lg bg-gradient-to-b from-yellow-300 to-amber-500 border-2 border-amber-950 text-amber-950 text-xs font-extrabold shadow-xs">
                      {isAr ? 'رقم قياسي جديد!' : 'New High Score!'}
                    </span>
                  </div>)}

                <div className="flex items-center justify-between gap-4">
                  {/* Trophy / Medal Showcase */}
                  <div className="flex flex-col items-center justify-center w-24 shrink-0 rounded-2xl bg-amber-200/65 border-2 border-amber-800/20 py-3 px-2">
                    <img src={score >= 25
                ? royalTrophySrc
                : score >= 12
                    ? hudTrophySrc
                    : score >= 5
                        ? silverTrophySrc
                        : bronzeTrophySrc} alt="Trophy" referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-16 h-16 object-contain drop-shadow-[0_4px_5px_rgba(69,26,3,0.35)] select-none"/>
                    <span className="mt-1.5 text-[11px] font-extrabold text-amber-900">
                      {score >= 25
                ? isAr
                    ? 'تاج المملكة'
                    : 'Royal Crown'
                : score >= 12
                    ? isAr
                        ? 'ذهبي'
                        : 'Gold'
                    : score >= 5
                        ? isAr
                            ? 'فضي'
                            : 'Silver'
                        : isAr
                            ? 'برونزي'
                            : 'Bronze'}
                    </span>
                  </div>

                  {/* Score & Best Readout */}
                  <div className="flex-1 space-y-2.5 text-center">
                    <div className="rounded-xl bg-white/80 border border-amber-900/15 py-1.5 px-3">
                      <div className="text-[11px] font-bold text-amber-800">
                        {isAr ? 'النقاط' : 'Score'}
                      </div>
                      <div className="font-display text-3xl font-bold tabular-nums text-amber-950 leading-tight">
                        {score}
                      </div>
                    </div>

                    <div className="rounded-xl bg-white/80 border border-amber-900/15 py-1.5 px-3">
                      <div className="text-[11px] font-bold text-amber-800">
                        {isAr ? 'الأعلى' : 'Best'}
                      </div>
                      <div className="font-display text-3xl font-bold tabular-nums text-orange-600 leading-tight">
                        {bestScore}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Glossy Replay & Home Action Buttons */}
          <div className={`flex items-center justify-center gap-6 mt-5 ${isAr ? 'font-arabic' : ''}`}>
            <button type="button" onClick={() => {
                sound.playClick();
                resetRun();
            }} aria-label={isAr ? 'العب مجدداً' : 'Play Again'} className="flex flex-col items-center gap-1.5 cursor-pointer group focus-visible:outline-2 focus-visible:outline-yellow-300 rounded-2xl">
              <img src={replayBtnSrc} alt={isAr ? 'العب مجدداً' : 'Play Again'} referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-[74px] h-[74px] object-contain drop-shadow-[0_7px_10px_rgba(15,23,42,0.6)] transition-transform duration-150 group-hover:scale-105 group-active:scale-95 select-none"/>
              <span className="text-xs font-bold text-white drop-shadow-[0_2px_3px_rgba(0,0,0,0.85)]">
                {isAr ? 'العب مجدداً' : 'Play Again'}
              </span>
            </button>

            <button type="button" onClick={() => {
                sound.playClick();
                onExitToMenu();
            }} aria-label={isAr ? 'القائمة الرئيسية' : 'Main Menu'} className="flex flex-col items-center gap-1.5 cursor-pointer group focus-visible:outline-2 focus-visible:outline-yellow-300 rounded-2xl">
              <img src={homeBtnSrc} alt={isAr ? 'القائمة الرئيسية' : 'Main Menu'} referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-[74px] h-[74px] object-contain drop-shadow-[0_7px_10px_rgba(15,23,42,0.6)] transition-transform duration-150 group-hover:scale-105 group-active:scale-95 select-none"/>
              <span className="text-xs font-bold text-white drop-shadow-[0_2px_3px_rgba(0,0,0,0.85)]">
                {isAr ? 'الرئيسية' : 'Home'}
              </span>
            </button>
          </div>
        </div>)}
    </div>);
};
function drawSkyTower(ctx, pipeImg, x, y, w, h, isTop) {
    if (h <= 0)
        return;
    if (pipeImg && pipeImg.naturalWidth > 0) {
        const srcW = pipeImg.naturalWidth; // 180
        const capSrcH = 82; // clean glossy top lip
        const shaftSrcY = 115; // clean emerald-lime vertical shaft
        const shaftSrcH = 110;
        const capDrawH = Math.min(h, Math.round(w * (capSrcH / srcW)));
        ctx.save();
        if (isTop) {
            ctx.translate(x, y + h);
            ctx.scale(1, -1);
        }
        else {
            ctx.translate(x, y);
        }
        // Draw seamless vertical green pipe shaft
        const shaftDrawH = h - capDrawH + 6;
        if (shaftDrawH > 0) {
            ctx.drawImage(pipeImg, 0, shaftSrcY, srcW, shaftSrcH, 0, capDrawH - 6, w, shaftDrawH);
        }
        // Draw glossy rounded pipe lip facing the gap
        ctx.drawImage(pipeImg, 0, 0, srcW, capSrcH, 0, 0, w, capDrawH);
        ctx.restore();
        return;
    }
    // Fallback vector pipe if image is still loading
    ctx.save();
    const grad = ctx.createLinearGradient(x, 0, x + w, 0);
    grad.addColorStop(0, '#059669');
    grad.addColorStop(0.38, '#34D399');
    grad.addColorStop(1, '#065F46');
    ctx.fillStyle = grad;
    ctx.fillRect(x + 7, y, w - 14, h);
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = '#022C22';
    ctx.strokeRect(x + 7, y, w - 14, h);
    const capH = 24;
    const capY = isTop ? y + h - capH : y;
    ctx.fillStyle = '#10B981';
    ctx.fillRect(x + 1, capY, w - 2, capH);
    ctx.strokeStyle = '#FACC15';
    ctx.lineWidth = 2.4;
    ctx.strokeRect(x + 1, capY, w - 2, capH);
    ctx.restore();
}
