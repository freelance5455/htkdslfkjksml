import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Trash2 } from "lucide-react";
import { listDriveFolder, searchDrive } from "@/lib/assistant/briefing";
import { useRefetchWhenConnectorReady } from "@/lib/app-data";
import { ConnectorState } from "@/components/connector-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import { formatBytes } from "@/lib/device";
import type { ConnectorPack } from "@/lib/assistant/types";

export function LibraryPane() {
  const deviceFiles = useAppStore((s) => s.deviceFiles);
  const removeDeviceFile = useAppStore((s) => s.removeDeviceFile);
  const setTab = useAppStore((s) => s.setTab);
  const setDraft = useAppStore((s) => s.setDraft);
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");

  const folder = useQuery({
    queryKey: ["drive-root"],
    queryFn: () => listDriveFolder({ data: {} }),
  });
  const search = useQuery({
    queryKey: ["drive-search", submitted],
    queryFn: () => searchDrive({ data: { query: submitted } }),
    enabled: submitted.length > 0,
  });

  const pack: ConnectorPack | undefined = submitted ? search.data : folder.data;
  const pending = Boolean(pack?.pending || folder.data?.pending);
  useRefetchWhenConnectorReady(pending, () => {
    void folder.refetch();
    if (submitted) void search.refetch();
  });

  const loading = submitted ? search.isLoading : folder.isLoading;

  return (
    <div className="mx-auto flex w-full max-w-lg flex-col gap-6 overflow-y-auto px-4 pb-8 pt-2">
      <header>
        <p className="text-sm font-medium text-muted">Library</p>
        <h2 className="font-display mt-1 text-3xl tracking-[-0.03em] text-fg">
          Files you can reach
        </h2>
        <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">
          Cloud files come from Google Drive through Grok. Phone files stay on
          this device until you attach them to a question.
        </p>
      </header>

      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          setSubmitted(query.trim());
        }}
      >
        <label className="flex h-11 flex-1 items-center gap-2 rounded-lg bg-raised px-3 shadow-[var(--shadow-border)]">
          <Search className="size-4 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Drive"
            className="h-full w-full bg-transparent text-sm text-fg outline-none placeholder:text-faint"
          />
        </label>
        <Button type="submit" size="md">
          Search
        </Button>
      </form>

      <section className="flex flex-col gap-3">
        <h3 className="text-sm font-medium text-fg">On this device</h3>
        {deviceFiles.length === 0 ? (
          <p className="text-sm text-muted">
            Nothing attached yet. Use Files or Camera in Ask to add something
            from this phone.
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {deviceFiles.map((file) => (
              <li
                key={file.id}
                className="flex items-center gap-3 rounded-xl bg-raised px-3 py-2.5 shadow-[var(--shadow-border)]"
              >
                <button
                  type="button"
                  className="min-w-0 flex-1 text-left"
                  onClick={() => {
                    setDraft(`Summarize or explain ${file.name}`);
                    setTab("ask");
                  }}
                >
                  <p className="truncate text-sm font-medium text-fg">{file.name}</p>
                  <p className="text-xs text-muted">{formatBytes(file.size)}</p>
                </button>
                <button
                  type="button"
                  aria-label={`Remove ${file.name}`}
                  className="flex size-10 items-center justify-center rounded-md text-muted hover:text-fg"
                  onClick={() => removeDeviceFile(file.id)}
                >
                  <Trash2 className="size-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="flex flex-col gap-3">
        <h3 className="text-sm font-medium text-fg">
          {submitted ? "Drive results" : "Drive"}
        </h3>
        {loading ? (
          <>
            <Skeleton className="h-16 w-full rounded-xl" />
            <Skeleton className="h-16 w-full rounded-xl" />
          </>
        ) : pack ? (
          <>
            <ConnectorState pack={pack} label="Google Drive" />
            {pack.ok && !pack.error && pack.items.length === 0 ? (
              <p className="text-sm text-muted">No files matched.</p>
            ) : null}
            <ul className="flex flex-col gap-2">
              {pack.items.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className="flex w-full flex-col gap-0.5 rounded-xl bg-raised px-4 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98]"
                    onClick={() => {
                      setDraft(`Read and summarize this Drive file: ${item.title}`);
                      setTab("ask");
                    }}
                  >
                    <span className="text-sm font-medium text-fg">{item.title}</span>
                    {item.subtitle ? (
                      <span className="text-xs text-muted">{item.subtitle}</span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <p className="text-sm text-muted">Open this tab from Grok to load Drive.</p>
        )}
      </section>
    </div>
  );
}
