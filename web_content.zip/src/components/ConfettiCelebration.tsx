import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
  type: 'rect' | 'circle' | 'streamer' | 'star';
  aspectRatio: number;
  wobble: number;
  wobbleSpeed: number;
  opacity: number;
  segments?: { x: number; y: number }[]; // for wavy streamers
}

const FESTIVE_COLORS = [
  '#EF4444', // Crimson Ruby
  '#F43F5E', // Rose
  '#3B82F6', // Sapphire Blue
  '#06B6D4', // Cyan
  '#10B981', // Emerald Green
  '#FACC15', // Gold Yellow
  '#F97316', // Orange
  '#A855F7', // Purple
  '#EC4899', // Hot Pink
  '#84CC16', // Lime
  '#FFFFFF', // Bright White Sparkle
];

export const ConfettiCelebration: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const particles: Particle[] = [];
    const particleTypes: ('rect' | 'circle' | 'streamer' | 'star')[] = [
      'rect',
      'rect',
      'rect',
      'circle',
      'streamer',
      'star',
    ];

    // Helper to spawn a particle
    const createParticle = (fromTop = false): Particle => {
      const type = particleTypes[Math.floor(Math.random() * particleTypes.length)];
      const color = FESTIVE_COLORS[Math.floor(Math.random() * FESTIVE_COLORS.length)];
      const size = type === 'streamer' ? 14 + Math.random() * 12 : type === 'star' ? 8 + Math.random() * 8 : 7 + Math.random() * 9;
      
      const x = fromTop ? Math.random() * width : Math.random() > 0.5 ? Math.random() * (width * 0.3) : width * 0.7 + Math.random() * (width * 0.3);
      const y = fromTop ? -20 - Math.random() * 80 : height * 0.2 + Math.random() * (height * 0.3);
      
      const angle = fromTop ? Math.PI / 2 + (Math.random() - 0.5) * 0.8 : Math.random() * Math.PI * 2;
      const speed = fromTop ? 2 + Math.random() * 5 : 6 + Math.random() * 10;

      const p: Particle = {
        x,
        y,
        vx: fromTop ? (Math.random() - 0.5) * 3 : Math.cos(angle) * speed,
        vy: fromTop ? speed : Math.sin(angle) * speed - 5,
        size,
        color,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.15,
        type,
        aspectRatio: 0.4 + Math.random() * 0.8,
        wobble: Math.random() * Math.PI * 2,
        wobbleSpeed: 0.04 + Math.random() * 0.08,
        opacity: 1,
      };

      if (type === 'streamer') {
        p.segments = [];
        for (let i = 0; i < 6; i++) {
          p.segments.push({ x: p.x, y: p.y - i * 6 });
        }
      }

      return p;
    };

    // Initial festive burst
    for (let i = 0; i < 90; i++) {
      particles.push(createParticle(false));
    }

    let frameCount = 0;
    const maxFrames = 380; // lasts ~6.3 seconds

    const render = () => {
      frameCount++;
      ctx.clearRect(0, 0, width, height);

      // Continuously rain confetti from top during first 3 seconds
      if (frameCount < 180 && frameCount % 2 === 0) {
        for (let k = 0; k < 3; k++) {
          particles.push(createParticle(true));
        }
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        // Physics update
        p.wobble += p.wobbleSpeed;
        p.x += p.vx + Math.sin(p.wobble) * 1.6;
        p.y += p.vy;
        p.vy += 0.12; // gravity
        p.vx *= 0.985; // air drag
        p.rotation += p.rotationSpeed;

        if (frameCount > maxFrames - 60) {
          p.opacity = Math.max(0, p.opacity - 0.02);
        }

        // Remove off-screen particles
        if (p.y > height + 50 || p.opacity <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.opacity;
        ctx.fillStyle = p.color;
        ctx.strokeStyle = p.color;

        if (p.type === 'rect') {
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          const flipScale = Math.cos(p.wobble);
          ctx.scale(1, flipScale);
          ctx.fillRect(-p.size / 2, (-p.size * p.aspectRatio) / 2, p.size, p.size * p.aspectRatio);
        } else if (p.type === 'circle') {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === 'star') {
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.beginPath();
          const spikes = 5;
          const outerRadius = p.size / 2;
          const innerRadius = outerRadius * 0.45;
          for (let s = 0; s < spikes * 2; s++) {
            const r = s % 2 === 0 ? outerRadius : innerRadius;
            const currAngle = (s * Math.PI) / spikes;
            const sx = Math.cos(currAngle) * r;
            const sy = Math.sin(currAngle) * r;
            if (s === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          }
          ctx.closePath();
          ctx.fill();
        } else if (p.type === 'streamer' && p.segments) {
          // Update ribbon segments
          p.segments.unshift({ x: p.x, y: p.y });
          p.segments.pop();

          ctx.lineWidth = 3.5;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.segments[0].x, p.segments[0].y);
          for (let s = 1; s < p.segments.length; s++) {
            const seg = p.segments[s];
            const waveX = seg.x + Math.sin(p.wobble + s * 0.6) * 4;
            ctx.lineTo(waveX, seg.y);
          }
          ctx.stroke();
        }

        ctx.restore();
      }

      if (particles.length > 0 || frameCount < maxFrames) {
        animId = requestAnimationFrame(render);
      }
    };

    animId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[60] w-full h-full"
      style={{ touchAction: 'none' }}
    />
  );
};
