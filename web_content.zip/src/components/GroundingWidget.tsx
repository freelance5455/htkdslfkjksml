import React, { useState } from 'react';
import { Eye, Hand, Volume2, Flower2, Coffee, Check, RotateCcw } from 'lucide-react';

export const GroundingWidget: React.FC = () => {
  const [checkedItems, setCheckedItems] = useState<{ [key: string]: boolean }>({});

  const sections = [
    {
      level: 5,
      sense: 'La Vue',
      icon: Eye,
      color: 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-950/30 dark:border-amber-900',
      instruction: '5 choses que vous voyez autour de vous (une ombre, une plante, un tableau, une texture...)',
      items: ['Objet 1', 'Objet 2', 'Objet 3', 'Objet 4', 'Objet 5'],
    },
    {
      level: 4,
      sense: 'Le Toucher',
      icon: Hand,
      color: 'text-teal-600 bg-teal-50 border-teal-200 dark:bg-teal-950/30 dark:border-teal-900',
      instruction: '4 sensations physiques (vos pieds sur le sol, vos mains sur les cuisses, le tissu, l’air...)',
      items: ['Sensation 1', 'Sensation 2', 'Sensation 3', 'Sensation 4'],
    },
    {
      level: 3,
      sense: 'L’Ouïe',
      icon: Volume2,
      color: 'text-indigo-600 bg-indigo-50 border-indigo-200 dark:bg-indigo-950/30 dark:border-indigo-900',
      instruction: '3 bruits distincts (le souffle d’une pièce, un bruit de moteur lointain, votre respiration...)',
      items: ['Son 1', 'Son 2', 'Son 3'],
    },
    {
      level: 2,
      sense: 'L’Odorat',
      icon: Flower2,
      color: 'text-rose-600 bg-rose-50 border-rose-200 dark:bg-rose-950/30 dark:border-rose-900',
      instruction: '2 odeurs subtiles (votre parfum, le café, le savon, l’air frais de la fenêtre...)',
      items: ['Odeur 1', 'Odeur 2'],
    },
    {
      level: 1,
      sense: 'Le Goût',
      icon: Coffee,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-900',
      instruction: '1 goût dans votre bouche ou buvez une gorgée d’eau avec pleine conscience',
      items: ['Goût ou gorgée d’eau'],
    },
  ];

  const toggleCheck = (id: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const totalItems = sections.reduce((acc, s) => acc + s.items.length, 0);
  const completedCount = Object.values(checkedItems).filter(Boolean).length;
  const isAllComplete = completedCount === totalItems;

  const resetAll = () => {
    setCheckedItems({});
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 shadow-sm max-w-xl mx-auto my-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h4 className="font-bold text-slate-900 dark:text-slate-100 text-base">
            Parcours Interactif 5-4-3-2-1
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Cochez chaque élément à mesure que vous le repérez dans votre environnement
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
            {completedCount} / {totalItems} ancrages
          </span>
          {completedCount > 0 && (
            <button
              onClick={resetAll}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              title="Réinitialiser"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mb-6 overflow-hidden">
        <div
          className="bg-gradient-to-r from-teal-500 to-rose-500 h-full transition-all duration-300"
          style={{ width: `${(completedCount / totalItems) * 100}%` }}
        />
      </div>

      {/* Sections */}
      <div className="space-y-4">
        {sections.map((sec) => {
          const Icon = sec.icon;
          return (
            <div
              key={sec.level}
              className={`p-4 rounded-2xl border transition-all ${sec.color}`}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-6 h-6 rounded-full bg-white dark:bg-slate-900 flex items-center justify-center font-bold text-xs shadow-2xs">
                  {sec.level}
                </div>
                <Icon className="w-4 h-4" />
                <span className="font-bold text-sm">{sec.sense}</span>
              </div>
              <p className="text-xs opacity-85 mb-3">{sec.instruction}</p>

              <div className="flex flex-wrap gap-2">
                {sec.items.map((label, idx) => {
                  const itemId = `${sec.level}-${idx}`;
                  const isChecked = Boolean(checkedItems[itemId]);
                  return (
                    <button
                      key={itemId}
                      onClick={() => toggleCheck(itemId)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all shadow-2xs ${
                        isChecked
                          ? 'bg-white text-slate-800 ring-2 ring-emerald-500 dark:bg-slate-900 dark:text-emerald-300 line-through opacity-90'
                          : 'bg-white/80 dark:bg-slate-900/80 hover:bg-white text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full flex items-center justify-center border ${
                          isChecked
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-slate-400'
                        }`}
                      >
                        {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                      <span>{label} repéré</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {isAllComplete && (
        <div className="mt-5 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center animate-fade-in">
          <p className="text-sm font-bold text-emerald-800 dark:text-emerald-200">
            🎉 Félicitations, vous avez réancré vos 5 sens dans le présent !
          </p>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
            Prenez une inspiration lente et profonde. Votre système nerveux sait que vous êtes en sécurité ici.
          </p>
        </div>
      )}
    </div>
  );
};
