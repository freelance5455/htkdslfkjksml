"use client";

import { useState } from "react";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtDateTime } from "@/lib/format";
import { requestBrowserPermission, sendTestNotification } from "@/lib/client/notificationsService";
import { useToast } from "@/components/Toast";

type Item = { id: number; title: string; body: string; kind: string; createdAt: string };

export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { data, refresh } = useApi<{ notifications?: Item[] }>("/api/notifications", { intervalMs: 45000 });
  const items = arr<Item>(data?.notifications);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-xl border border-slate-700 bg-slate-900 px-3 py-1 text-[11px] font-bold text-slate-200"
      >
        🔔 התראות
        {items.length > 0 && (
          <span className="absolute -top-1 -left-1 rounded-full bg-rose-500 px-1.5 text-[9px] text-white">
            {items.length > 99 ? "99+" : items.length}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute left-0 top-10 z-50 max-h-96 w-80 overflow-y-auto rounded-2xl border border-slate-700 bg-slate-950 p-3 shadow-2xl">
          <div className="mb-2 flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-200">מנוע התראות פוש</span>
            <div className="flex gap-1">
              <button
                onClick={async () => {
                  const ok = await requestBrowserPermission();
                  toast(ok ? "התראות הופעלו במכשיר" : "ההרשאה להתראות נדחתה", ok ? "success" : "error");
                }}
                className="rounded-lg bg-slate-800 px-2 py-1 text-[10px] text-slate-200"
              >
                הפעל
              </button>
              <button
                onClick={async () => {
                  const res = await sendTestNotification();
                  toast(res.message ?? "נשלחה התראת בדיקה", res.ok ? "success" : "error");
                  void refresh();
                }}
                className="rounded-lg bg-sky-600 px-2 py-1 text-[10px] text-white"
              >
                בדיקה
              </button>
            </div>
          </div>
          {items.length === 0 ? (
            <p className="py-6 text-center text-[11px] text-slate-500">אין התראות עדיין</p>
          ) : (
            <ul className="space-y-2">
              {items.map((n) => (
                <li key={n.id} className="rounded-xl border border-slate-800 bg-slate-900/70 p-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-slate-100">{n.title}</span>
                    <span className="text-[9px] text-slate-500">{fmtDateTime(n.createdAt)}</span>
                  </div>
                  <p className="mt-0.5 text-[10px] text-slate-400">{n.body}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
