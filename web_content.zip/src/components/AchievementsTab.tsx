import { useGame } from '../context/GameContext';
import { VentureIcon } from './VentureIcon';
import {
  Award,
  Leaf,
  FlaskConical,
  Hammer,
  Coins,
  Feather,
  Wand2,
  Flame,
  Users,
  Crown,
  Gem,
  Sparkles,
  Zap,
  Compass,
  Shield,
  Target,
  CheckCircle2,
  Lock,
} from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  Award,
  Leaf,
  FlaskConical,
  Hammer,
  Coins,
  Feather,
  Wand2,
  Flame,
  Users,
  Crown,
  Gem,
  Sparkles,
  Zap,
  Compass,
  Shield,
  Target,
};

export function AchievementsTab() {
  const { achievements } = useGame();

  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const progressPercent = Math.round((unlockedCount / achievements.length) * 100);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl border border-amber-900/30 bg-slate-900/80 p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Award className="w-4 h-4" />
            <span>Kingdom Feats & Lore</span>
          </div>
          <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-slate-100">
            Royal Chronicles & Milestones
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Chronicle your ascent from humble herbalist to cosmic sovereign of all planar trade.
          </p>
        </div>

        <div className="w-full sm:w-48 bg-slate-950 border border-slate-800 p-3 rounded-xl text-center shrink-0">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Progress</span>
            <span className="font-bold text-amber-300 tabular-nums">
              {unlockedCount} / {achievements.length}
            </span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {achievements.map((ach) => {
          const IconComponent = ICON_MAP[ach.icon] || Award;

          return (
            <div
              key={ach.id}
              className={`rounded-2xl border p-4 sm:p-5 transition-all flex items-start gap-4 ${
                ach.unlocked
                  ? 'border-amber-500/40 bg-gradient-to-br from-amber-950/20 to-slate-900/80'
                  : 'border-slate-800/80 bg-slate-950/60 opacity-65'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${
                  ach.unlocked
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-slate-900 border-slate-800 text-slate-600'
                }`}
              >
                {ach.unlocked ? (
                  ach.id === 'ach_potion_brew' ? (
                    <VentureIcon ventureId="potion_brewery" size="sm" className="w-8 h-8 rounded-lg" />
                  ) : ach.id === 'ach_first_seed' ? (
                    <VentureIcon ventureId="mana_herbs" size="sm" className="w-8 h-8 rounded-lg" />
                  ) : (
                    <IconComponent className="w-6 h-6" />
                  )
                ) : (
                  <Lock className="w-5 h-5 text-slate-600" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3
                    className={`font-cinzel text-base font-bold truncate ${
                      ach.unlocked ? 'text-slate-100' : 'text-slate-400'
                    }`}
                  >
                    {ach.title}
                  </h3>
                  {ach.unlocked && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Unlocked</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {ach.description}
                </p>

                <p className="text-[11px] text-amber-400/80 italic mt-2">
                  "{ach.rewardText}"
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
