import { useRef } from 'react';
import { Play, Upload } from 'lucide-react';
import type { ApkBuildConfig, SplashConfig } from '../types/apk';
import { convertImageFileToPngBase64 } from '../lib/iconCanvas';

interface SplashScreenSectionProps {
  config: ApkBuildConfig;
  previewIconUrl: string;
  onChange: (patch: Partial<ApkBuildConfig>) => void;
  onTriggerSplashPreview: () => void;
}

const SPLASH_BG_PRESETS = [
  '#0F172A',
  '#16A34A',
  '#FFFFFF',
  '#1E293B',
  '#1D4ED8',
  '#111827',
];

export function SplashScreenSection({
  config,
  previewIconUrl,
  onChange,
  onTriggerSplashPreview,
}: SplashScreenSectionProps) {
  const logoInputRef = useRef<HTMLInputElement | null>(null);
  const s = config.splash;

  const updateSplash = (patch: Partial<SplashConfig>) => {
    onChange({
      splash: { ...s, ...patch },
    });
  };

  const handleUploadSplashLogo = async (file: File | undefined) => {
    if (!file) return;
    try {
      const pngBase64 = await convertImageFileToPngBase64(file, 256);
      updateSplash({ customLogoBase64Png: pngBase64 });
    } catch {
      // Ignore invalid image
    }
  };

  const resolvedSplashLogo = s.customLogoBase64Png
    ? `data:image/png;base64,${s.customLogoBase64Png}`
    : previewIconUrl;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/70">
        <label className="flex items-start gap-3 cursor-pointer flex-1">
          <input
            type="checkbox"
            checked={s.enabled}
            onChange={(e) => updateSplash({ enabled: e.target.checked })}
            className="mt-0.5 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              Enable Custom Launch Splash Screen
            </div>
            <div className="text-xs text-slate-600 mt-0.5 leading-relaxed">
              Displays your branded launch screen before revealing the WebView. Compiled into HTML/Code APKs and wired natively via <code className="font-mono">FrameLayout</code> in the Gradle export.
            </div>
          </div>
        </label>

        <button
          type="button"
          onClick={onTriggerSplashPreview}
          disabled={!s.enabled}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
        >
          <Play className="w-3.5 h-3.5" />
          Preview Splash
        </button>
      </div>

      {s.enabled && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="splash-headline"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Splash Headline
              </label>
              <input
                id="splash-headline"
                type="text"
                maxLength={40}
                value={s.headline}
                onChange={(e) => updateSplash({ headline: e.target.value })}
                placeholder={config.appName}
                className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
              />
            </div>

            <div>
              <label
                htmlFor="splash-tagline"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Tagline / Subtitle (Optional)
              </label>
              <input
                id="splash-tagline"
                type="text"
                maxLength={60}
                value={s.tagline}
                onChange={(e) => updateSplash({ tagline: e.target.value })}
                placeholder="Loading workspace..."
                className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-2">
                Splash Background Color
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                {SPLASH_BG_PRESETS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    aria-label={`Splash background ${hex}`}
                    onClick={() =>
                      updateSplash({
                        backgroundColor: hex,
                        textColor: hex === '#FFFFFF' ? '#0F172A' : '#FFFFFF',
                      })
                    }
                    className={`w-7 h-7 rounded-lg border transition-transform ${
                      s.backgroundColor.toUpperCase() === hex
                        ? 'border-emerald-600 scale-110'
                        : 'border-slate-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
                <input
                  type="color"
                  aria-label="Custom splash background color"
                  value={s.backgroundColor}
                  onChange={(e) =>
                    updateSplash({ backgroundColor: e.target.value })
                  }
                  className="w-8 h-7 rounded border border-slate-200 bg-white cursor-pointer"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-2">
                Text & Spinner Contrast
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => updateSplash({ textColor: '#FFFFFF' })}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border ${
                    s.textColor.toUpperCase() === '#FFFFFF'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200'
                  }`}
                >
                  Light Text (#FFFFFF)
                </button>
                <button
                  type="button"
                  onClick={() => updateSplash({ textColor: '#0F172A' })}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border ${
                    s.textColor.toUpperCase() === '#0F172A'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200'
                  }`}
                >
                  Dark Text (#0F172A)
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div>
              <div className="flex items-center justify-between text-xs font-medium text-slate-700 mb-1.5">
                <label htmlFor="splash-duration">Display Duration</label>
                <span className="font-mono tabular-nums text-slate-500">
                  {(s.durationMs / 1000).toFixed(1)}s ({s.durationMs} ms)
                </span>
              </div>
              <input
                id="splash-duration"
                type="range"
                min={400}
                max={4000}
                step={200}
                value={s.durationMs}
                onChange={(e) =>
                  updateSplash({ durationMs: parseInt(e.target.value, 10) })
                }
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Logo Size & Loading Indicator
              </label>
              <div className="flex items-center gap-3">
                <select
                  value={s.logoScale}
                  onChange={(e) =>
                    updateSplash({
                      logoScale: e.target.value as SplashConfig['logoScale'],
                    })
                  }
                  className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900"
                >
                  <option value="sm">Small (56dp)</option>
                  <option value="md">Medium (76dp)</option>
                  <option value="lg">Large (96dp)</option>
                </select>
                <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={s.showSpinner}
                    onChange={(e) =>
                      updateSplash({ showSpinner: e.target.checked })
                    }
                    className="h-4 w-4 accent-emerald-600 rounded border-slate-300"
                  />
                  Show spinner
                </label>
              </div>
            </div>
          </div>

          {/* Custom Splash Artwork */}
          <div className="pt-4 border-t border-slate-200 flex items-center gap-4">
            {resolvedSplashLogo ? (
              <img
                src={resolvedSplashLogo}
                alt="Splash Logo"
                className="w-14 h-14 rounded-2xl border border-slate-200 object-cover shrink-0"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center font-display font-bold text-lg shrink-0"
                style={{
                  backgroundColor: s.backgroundColor,
                  color: s.textColor,
                }}
              >
                {(s.headline || config.appName).slice(0, 2).toUpperCase()}
              </div>
            )}

            <div>
              <div className="text-xs font-medium text-slate-900">
                Splash Centerpiece Logo
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Uses your App Icon by default, or upload a separate splash image.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  onChange={(e) =>
                    void handleUploadSplashLogo(e.target.files?.[0])
                  }
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Upload Splash Logo
                </button>
                {s.customLogoBase64Png && (
                  <button
                    type="button"
                    onClick={() =>
                      updateSplash({ customLogoBase64Png: undefined })
                    }
                    className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900"
                  >
                    Use App Icon
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
