import React, { useState, useMemo } from 'react';
import {
  Wheat,
  Plus,
  Search,
  Filter,
  Download,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
  Scale,
  Calendar,
  Building,
} from 'lucide-react';
import { AppSettings, AttaRecord } from '../types';
import { translations } from '../utils/translations';
import { calculateAttaAmount, summarizeAttaPurchases } from '../utils/calculations';
import { StorageService } from '../utils/storage';

interface AttaTrackerProps {
  records: AttaRecord[];
  onUpdateRecords: (records: AttaRecord[]) => void;
  settings: AppSettings;
}

export const AttaTracker: React.FC<AttaTrackerProps> = ({
  records,
  onUpdateRecords,
  settings,
}) => {
  const t = translations[settings.language];
  const [search, setSearch] = useState('');
  const [supplierFilter, setSupplierFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AttaRecord | null>(null);

  // Form State
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().slice(0, 10));
  const [quantityMaund, setQuantityMaund] = useState<number | ''>(10);
  const [rate, setRate] = useState<number | ''>(8000);
  const [rateUnit, setRateUnit] = useState<'Per Maund' | 'Per KG'>('Per Maund');
  const [supplier, setSupplier] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Partial' | 'Unpaid'>('Paid');
  const [remarks, setRemarks] = useState('');

  // Auto-calculated preview values
  const { totalAmount: calcAmount, equivalentKg: calcKg } = useMemo(() => {
    return calculateAttaAmount(Number(quantityMaund) || 0, Number(rate) || 0, rateUnit);
  }, [quantityMaund, rate, rateUnit]);

  // Filtered active records
  const activeRecords = useMemo(() => {
    return records
      .filter((r) => !r.isDeleted)
      .filter((r) => {
        const matchesSearch =
          search === '' ||
          r.supplier.toLowerCase().includes(search.toLowerCase()) ||
          (r.remarks && r.remarks.toLowerCase().includes(search.toLowerCase())) ||
          r.purchaseDate.includes(search);
        const matchesSupplier = supplierFilter === '' || r.supplier === supplierFilter;
        const matchesStatus = statusFilter === '' || r.paymentStatus === statusFilter;
        return matchesSearch && matchesSupplier && matchesStatus;
      })
      .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }, [records, search, supplierFilter, statusFilter]);

  // Overall calculations
  const summary = useMemo(() => {
    return summarizeAttaPurchases(records);
  }, [records]);

  // Unique suppliers for filter dropdown
  const uniqueSuppliers = useMemo(() => {
    const set = new Set<string>();
    records.filter((r) => !r.isDeleted).forEach((r) => set.add(r.supplier));
    return Array.from(set);
  }, [records]);

  // Open modal for new record
  const handleOpenAdd = () => {
    setEditingRecord(null);
    setPurchaseDate(new Date().toISOString().slice(0, 10));
    setQuantityMaund(10);
    setRate(8000);
    setRateUnit('Per Maund');
    setSupplier(uniqueSuppliers[0] || 'Al-Madina Flour Mills');
    setPaymentStatus('Paid');
    setRemarks('');
    setIsModalOpen(true);
  };

  // Open modal for editing
  const handleOpenEdit = (rec: AttaRecord) => {
    setEditingRecord(rec);
    setPurchaseDate(rec.purchaseDate);
    setQuantityMaund(rec.quantityMaund);
    setRate(rec.rate);
    setRateUnit(rec.rateUnit);
    setSupplier(rec.supplier);
    setPaymentStatus(rec.paymentStatus);
    setRemarks(rec.remarks || '');
    setIsModalOpen(true);
  };

  // Save record (Add or Edit)
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplier.trim()) {
      alert('Please enter a supplier name');
      return;
    }
    const qty = Number(quantityMaund);
    const r = Number(rate);
    if (qty <= 0 || r <= 0) {
      alert('Quantity and Rate must be greater than zero');
      return;
    }

    const { totalAmount, equivalentKg } = calculateAttaAmount(qty, r, rateUnit);

    if (editingRecord) {
      // Update
      const old = { ...editingRecord };
      const updated: AttaRecord = {
        ...editingRecord,
        purchaseDate,
        quantityMaund: qty,
        rate: r,
        rateUnit,
        totalAmount,
        equivalentKg,
        supplier: supplier.trim(),
        paymentStatus,
        remarks: remarks.trim(),
        updatedAt: new Date().toISOString(),
      };
      const newRecords = records.map((item) => (item.id === editingRecord.id ? updated : item));
      onUpdateRecords(newRecords);
      StorageService.saveAttaRecords(newRecords);
      StorageService.addAuditLog('UPDATE', 'Atta', `Updated purchase record for ${supplier}`, old, updated);
    } else {
      // Create new
      const newRecord: AttaRecord = {
        id: `atta_${Date.now()}`,
        purchaseDate,
        quantityMaund: qty,
        rate: r,
        rateUnit,
        totalAmount,
        equivalentKg,
        supplier: supplier.trim(),
        paymentStatus,
        remarks: remarks.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const newRecords = [newRecord, ...records];
      onUpdateRecords(newRecords);
      StorageService.saveAttaRecords(newRecords);
      StorageService.addAuditLog('CREATE', 'Atta', `Added purchase of ${qty} Maund from ${supplier}`, null, newRecord);
    }

    setIsModalOpen(false);
  };

  // Soft Delete record
  const handleDelete = (rec: AttaRecord) => {
    if (window.confirm(t.confirmDelete)) {
      const updatedList = records.map((item) =>
        item.id === rec.id ? { ...item, isDeleted: true } : item
      );
      onUpdateRecords(updatedList);
      StorageService.saveAttaRecords(updatedList);
      StorageService.moveToRecycleBin('Atta', rec.id, `${rec.quantityMaund} Maund from ${rec.supplier}`, rec);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const rows = activeRecords.map((r) => ({
      'Purchase Date': r.purchaseDate,
      'Quantity (Maund)': r.quantityMaund,
      'Equivalent (KG)': r.equivalentKg,
      Rate: r.rate,
      'Rate Unit': r.rateUnit,
      'Total Amount': r.totalAmount,
      Supplier: r.supplier,
      'Payment Status': r.paymentStatus,
      Remarks: r.remarks || '',
    }));
    StorageService.exportToCsv('Atta_Purchases_Export', rows);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 rounded-lg">
              <Wheat className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {t.attaTracker}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                1 Maund = 40 KG • Automatic Per Maund / Per KG Total Amount Calculation
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addPurchase}</span>
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalPurchases}</span>
            <Wheat className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {summary.totalPurchases}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Total recorded orders</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalMaund}</span>
            <Scale className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {summary.totalQuantityMaund.toLocaleString()}{' '}
            <span className="text-sm font-normal text-slate-500">Maund</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            = {summary.totalQuantityKg.toLocaleString()} KG (1 Mnd = 40 KG)
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalAmount}</span>
            <TrendingUp className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {settings.currencySymbol} {summary.totalAmount.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Cumulative flour expenditure</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.avgRate}</span>
            <Wheat className="w-4 h-4 text-purple-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-purple-600 dark:text-purple-400">
            {settings.currencySymbol} {Math.round(summary.averageRatePerMaund).toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Avg {settings.currencySymbol} {summary.averageRatePerKg.toFixed(1)} / KG
          </p>
        </div>
      </div>

      {/* Supplier Breakdown Summary Card */}
      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
        <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Building className="w-4 h-4 text-emerald-500" />
          Supplier-Wise Volume & Spend
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {Object.entries(summary.supplierSummary).map(([sup, data]) => (
            <div
              key={sup}
              className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1"
            >
              <div className="font-semibold text-slate-900 dark:text-white truncate">{sup}</div>
              <div className="flex justify-between text-slate-500">
                <span>Total Orders:</span>
                <span className="font-medium text-slate-700 dark:text-slate-300">{data.count}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Quantity:</span>
                <span className="font-medium text-emerald-600">
                  {data.maund} Mnd ({data.maund * 40} KG)
                </span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Total Paid:</span>
                <span className="font-medium text-slate-900 dark:text-white">
                  {settings.currencySymbol} {data.amount.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-auto rtl:right-3" />
          <input
            type="text"
            placeholder="Search supplier, remarks or date..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 border-0"
          />
        </div>

        <select
          value={supplierFilter}
          onChange={(e) => setSupplierFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Suppliers</option>
          {uniqueSuppliers.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Statuses</option>
          <option value="Paid">{t.paid}</option>
          <option value="Partial">{t.partial}</option>
          <option value="Unpaid">{t.unpaid}</option>
        </select>
      </div>

      {/* Data Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">{t.purchaseDate}</th>
                <th className="px-4 py-3">{t.supplier}</th>
                <th className="px-4 py-3">{t.quantityMaund}</th>
                <th className="px-4 py-3">{t.equivalentKg}</th>
                <th className="px-4 py-3">{t.rate}</th>
                <th className="px-4 py-3">{t.totalAmount}</th>
                <th className="px-4 py-3">{t.paymentStatus}</th>
                <th className="px-4 py-3">{t.remarks}</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                    No Atta purchase records found matching filters.
                  </td>
                </tr>
              ) : (
                activeRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                      {r.purchaseDate}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                      {r.supplier}
                    </td>
                    <td className="px-4 py-3 font-bold text-emerald-600 dark:text-emerald-400">
                      {r.quantityMaund} Mnd
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {r.equivalentKg} KG
                    </td>
                    <td className="px-4 py-3 text-slate-700 dark:text-slate-300">
                      {settings.currencySymbol} {r.rate.toLocaleString()}{' '}
                      <span className="text-[10px] text-slate-400">({r.rateUnit})</span>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                      {settings.currencySymbol} {r.totalAmount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          r.paymentStatus === 'Paid'
                            ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400'
                            : r.paymentStatus === 'Partial'
                            ? 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400'
                            : 'bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        {r.paymentStatus === 'Paid' ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                        {r.paymentStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                      {r.remarks || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(r)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit"
                          aria-label={`Edit purchase on ${r.purchaseDate}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(r)}
                          className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          title="Move to Recycle Bin"
                          aria-label={`Delete purchase from ${r.supplier}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Wheat className="w-5 h-5 text-amber-500" />
                {editingRecord ? 'Edit Atta Purchase' : t.addPurchase}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.purchaseDate} *
                  </label>
                  <input
                    type="date"
                    required
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.supplier} *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Al-Madina Flour Mills"
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Quantity in Maund (User entered) & Conversion preview */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-900 dark:text-slate-100 mb-1">
                    {t.quantityMaund} *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={quantityMaund}
                    onChange={(e) => setQuantityMaund(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-bold text-emerald-600 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">User enters Maund only</p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    {t.equivalentKg}
                  </label>
                  <div className="px-3 py-2 text-sm font-semibold bg-slate-100 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-between">
                    <span>{calcKg} KG</span>
                    <span className="text-[10px] text-slate-400">(40 × Mnd)</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">1 Maund = 40 KG</p>
                </div>
              </div>

              {/* Rate & Rate Unit selection */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.rate} ({settings.currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={rate}
                    onChange={(e) => setRate(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.rateUnit} *
                  </label>
                  <select
                    value={rateUnit}
                    onChange={(e) => setRateUnit(e.target.value as 'Per Maund' | 'Per KG')}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="Per Maund">{t.perMaund}</option>
                    <option value="Per KG">{t.perKg}</option>
                  </select>
                </div>
              </div>

              {/* Live Calculation formula callout */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-xs space-y-1">
                <div className="flex justify-between items-center text-amber-900 dark:text-amber-200 font-bold text-sm">
                  <span>Calculated Total Amount:</span>
                  <span className="text-base text-emerald-600 dark:text-emerald-400">
                    {settings.currencySymbol} {calcAmount.toLocaleString()}
                  </span>
                </div>
                <p className="text-[11px] text-amber-800 dark:text-amber-300">
                  {rateUnit === 'Per Maund'
                    ? `Formula: Rate (${rate}) × Maund (${quantityMaund}) = Rs. ${calcAmount}`
                    : `Formula: Rate (${rate}) × Maund (${quantityMaund}) × 40 = Rs. ${calcAmount}`}
                </p>
              </div>

              {/* Payment status & remarks */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.paymentStatus}
                  </label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as 'Paid' | 'Partial' | 'Unpaid')}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  >
                    <option value="Paid">{t.paid}</option>
                    <option value="Partial">{t.partial}</option>
                    <option value="Unpaid">{t.unpaid}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {t.remarks}
                  </label>
                  <input
                    type="text"
                    placeholder="Batch, vehicle no, etc."
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Form Buttons */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition"
                >
                  {editingRecord ? 'Update Record' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
