import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Clock, 
  Coins, 
  Search, 
  CheckCircle2, 
  Sparkles, 
  Flame, 
  RefreshCw, 
  Tv, 
  ArrowRight, 
  Filter,
  Zap,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { YouTubeVideo } from '../../types';
import { getYoutubeVideos, YOUTUBE_CATEGORIES, TOTAL_YOUTUBE_CATALOG_COUNT } from '../../services/youtubeLibrary';
import { YouTubeWatchPlayerModal } from './YouTubeWatchPlayerModal';

export const YouTubeWatchSection: React.FC = () => {
  const { currentUser } = useApp();

  const [category, setCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [videosList, setVideosList] = useState<YouTubeVideo[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);

  // Active playing video modal
  const [activeVideo, setActiveVideo] = useState<YouTubeVideo | null>(null);

  // Watched video IDs (persisted locally)
  const [watchedIds, setWatchedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_watched_yt_videos');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Fetch initial/updated videos
  useEffect(() => {
    const { videos, hasMore: more } = getYoutubeVideos(1, 12, category, searchQuery);
    setVideosList(videos);
    setPage(1);
    setHasMore(more);
  }, [category, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { videos: newBatch, hasMore: more } = getYoutubeVideos(nextPage, 12, category, searchQuery);
    setVideosList((prev) => [...prev, ...newBatch]);
    setPage(nextPage);
    setHasMore(more);
  };

  const handleRewardClaimed = (videoId: string, coins: number) => {
    setWatchedIds((prev) => {
      const updated = Array.from(new Set([...prev, videoId]));
      localStorage.setItem('taskearn_watched_yt_videos', JSON.stringify(updated));
      return updated;
    });
  };

  const handleWatchNext = () => {
    if (!activeVideo) return;
    const currentIndex = videosList.findIndex((v) => v.id === activeVideo.id);
    if (currentIndex >= 0 && currentIndex + 1 < videosList.length) {
      setActiveVideo(videosList[currentIndex + 1]);
    } else {
      setActiveVideo(null);
    }
  };

  const formatCardDuration = (seconds: number) => {
    if (seconds >= 7200) return '2 Hours Marathon';
    if (seconds >= 3600) return '1 Hour Stream';
    if (seconds >= 1800) return '30 Mins Watch';
    if (seconds >= 60) return `${Math.floor(seconds / 60)} Mins Watch`;
    return `${seconds}s Quick`;
  };

  return (
    <div className="space-y-4">
      {/* 100,000+ YouTube Catalog & 2-Hour Video Play Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-red-950/90 via-slate-900 to-indigo-950/90 border border-red-800/60 shadow-xl space-y-3 relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-600/30">
                <Tv className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                YouTube Watch & Earn
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-500/20 text-red-300 border border-red-500/40">
                ⚡ 100,000+ Videos Pool
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                2-Hour Play Active
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-xl">
              Watch directly on the <strong>Direct YouTube Player</strong> or official YouTube app. Earn up to <strong className="text-amber-400">10,000 Coins (₹100 Cash)</strong> per 2-hour marathon session!
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-black/50 border border-slate-800 flex items-center gap-3 shrink-0">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Video Pool</span>
              <span className="text-sm font-black text-amber-400">100,000+</span>
            </div>
            <div className="w-px h-7 bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">2-Hour Max Reward</span>
              <span className="text-sm font-black text-emerald-400">₹100 (10k C)</span>
            </div>
            <div className="w-px h-7 bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Watched Today</span>
              <span className="text-sm font-black text-white">{watchedIds.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {YOUTUBE_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              category === cat
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat === '2-Hour Marathons' ? '🔥 2-Hour Marathons (₹100)' : cat}
          </button>
        ))}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search 100,000+ YouTube titles, creators, or 2-hour long streams..."
          className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-500"
        />
      </div>

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {videosList.map((video) => {
          const isWatched = watchedIds.includes(video.id);
          const is2Hour = video.isMarathon2Hour || video.durationSeconds >= 7200;

          return (
            <div
              key={video.id}
              className={`p-3.5 rounded-3xl border transition-all flex flex-col justify-between gap-3 shadow-md ${
                is2Hour
                  ? 'bg-gradient-to-br from-red-950/40 via-slate-900 to-slate-950 border-red-800/60 hover:border-red-600/80'
                  : isWatched
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-80'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Thumbnail + Video Info */}
              <div className="space-y-2.5">
                <div 
                  onClick={() => setActiveVideo(video)}
                  className="relative aspect-video rounded-2xl overflow-hidden bg-slate-950 cursor-pointer group shadow-inner"
                >
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    loading="lazy"
                  />
                  {/* Play Overlay */}
                  <div className="absolute inset-0 bg-black/35 group-hover:bg-black/15 transition-colors flex items-center justify-center">
                    <div className="w-11 h-11 rounded-full bg-red-600 text-white flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </div>
                  </div>

                  {/* Duration Tag */}
                  <span className={`absolute bottom-2 right-2 px-2 py-0.5 rounded-lg backdrop-blur-md text-[10px] font-mono font-bold ${
                    is2Hour ? 'bg-red-600/90 text-white' : 'bg-black/80 text-white'
                  }`}>
                    {formatCardDuration(video.durationSeconds)}
                  </span>

                  {/* 2-Hour High Earning Badge */}
                  {is2Hour && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded-lg bg-amber-500/90 backdrop-blur-xs text-[9px] font-black uppercase text-slate-950 shadow-md">
                      ⭐ Up to ₹100
                    </span>
                  )}

                  {/* Category Pill */}
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-lg bg-black/70 backdrop-blur-xs text-[9px] uppercase font-bold text-slate-300">
                    {video.category}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 
                    onClick={() => setActiveVideo(video)}
                    className="text-xs font-bold text-white line-clamp-2 cursor-pointer hover:text-red-400 transition-colors"
                  >
                    {video.title}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {video.channelTitle} • {video.viewsCount}
                  </p>
                </div>
              </div>

              {/* Bottom Line: Reward & Action */}
              <div className="flex items-center justify-between pt-2.5 border-t border-slate-800/80">
                <div>
                  <span className="text-xs font-black text-amber-400 flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    <span>+{video.rewardCoins.toLocaleString()} Coins</span>
                  </span>
                  <span className="text-[10px] text-emerald-400 font-semibold block">
                    ≈ ₹{(video.rewardCoins / 100).toFixed(0)} Cash Payout
                  </span>
                </div>

                {isWatched ? (
                  <button
                    onClick={() => setActiveVideo(video)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-emerald-400 text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Watched</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setActiveVideo(video)}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs shadow-md shadow-red-600/20 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Play Direct</span>
                    <Play className="w-3 h-3 fill-current" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            <span>Load More from 100,000+ Library</span>
          </button>
        </div>
      )}

      {/* Active Video Player Modal with Direct YouTube & 2-Hour Watch Mode */}
      <YouTubeWatchPlayerModal
        video={activeVideo}
        isOpen={Boolean(activeVideo)}
        onClose={() => setActiveVideo(null)}
        onWatchNext={handleWatchNext}
        onRewardClaimed={handleRewardClaimed}
      />
    </div>
  );
};
