import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Clock, 
  Coins, 
  CheckCircle2, 
  Sparkles, 
  ExternalLink, 
  Play, 
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Tv,
  Zap,
  Flame,
  FastForward,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { YouTubeVideo } from '../../types';

interface YouTubeWatchPlayerModalProps {
  video: YouTubeVideo | null;
  isOpen: boolean;
  onClose: () => void;
  onWatchNext?: () => void;
  onRewardClaimed?: (videoId: string, coins: number) => void;
}

interface DurationTier {
  label: string;
  seconds: number;
  coins: number;
  badge: string;
  isPopular?: boolean;
}

const DURATION_TIERS: DurationTier[] = [
  { label: '2 Hours Marathon', seconds: 7200, coins: 10000, badge: '⭐ MAX ₹100', isPopular: true },
  { label: '1 Hour', seconds: 3600, coins: 4500, badge: '₹45 Cash' },
  { label: '30 Mins', seconds: 1800, coins: 2000, badge: '₹20 Cash' },
  { label: '15 Mins', seconds: 900, coins: 850, badge: '₹8.50' },
  { label: '5 Mins', seconds: 300, coins: 250, badge: '₹2.50' },
  { label: '15s Quick', seconds: 15, coins: 40, badge: 'Fast' },
];

export const YouTubeWatchPlayerModal: React.FC<YouTubeWatchPlayerModalProps> = ({
  video,
  isOpen,
  onClose,
  onWatchNext,
  onRewardClaimed
}) => {
  const { currentUser, adjustUserCoins, recordPlaySeen } = useApp();

  // Selected duration tier (default to 2 Hours if marathon or video >= 7200, else 2 Hours by default for maximum earnings)
  const [selectedTier, setSelectedTier] = useState<DurationTier>(DURATION_TIERS[0]);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(7200);
  const [totalSeconds, setTotalSeconds] = useState<number>(7200);
  const [isTimerComplete, setIsTimerComplete] = useState<boolean>(false);
  const [isClaimed, setIsClaimed] = useState<boolean>(false);
  const [claimedReward, setClaimedReward] = useState<number>(0);
  const [isWatchingOnExternalYouTube, setIsWatchingOnExternalYouTube] = useState<boolean>(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);

  // Initialize or reset when video opens
  useEffect(() => {
    if (isOpen && video) {
      // Default to 2 hours marathon for maximum user earning capability as requested
      const initialTier = video.isMarathon2Hour || video.durationSeconds >= 7200 
        ? DURATION_TIERS[0] 
        : (DURATION_TIERS.find(t => t.seconds === video.durationSeconds) || DURATION_TIERS[0]);

      setSelectedTier(initialTier);
      setTotalSeconds(initialTier.seconds);
      setSecondsRemaining(initialTier.seconds);
      setIsTimerComplete(false);
      setIsClaimed(false);
      setClaimedReward(0);
      setIsWatchingOnExternalYouTube(false);
      setSpeedMultiplier(1);
    }
  }, [isOpen, video]);

  // Handle switching duration tier
  const handleSelectTier = (tier: DurationTier) => {
    setSelectedTier(tier);
    setTotalSeconds(tier.seconds);
    setSecondsRemaining(tier.seconds);
    setIsTimerComplete(false);
    setIsClaimed(false);
    setClaimedReward(0);
  };

  // Active Countdown timer with support for speed multipliers & anti-idle simulation
  useEffect(() => {
    if (!isOpen || isTimerComplete || !video) return;

    if (secondsRemaining <= 0) {
      setIsTimerComplete(true);
      return;
    }

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        const decrement = speedMultiplier;
        if (prev <= decrement) {
          setIsTimerComplete(true);
          return 0;
        }
        return prev - decrement;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, secondsRemaining, isTimerComplete, video, speedMultiplier]);

  if (!isOpen || !video) return null;

  // Format seconds into HH:MM:SS
  const formatTime = (secs: number) => {
    const hours = Math.floor(secs / 3600);
    const minutes = Math.floor((secs % 3600) / 60);
    const seconds = secs % 60;

    const pad = (n: number) => n.toString().padStart(2, '0');
    if (hours > 0) {
      return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    }
    return `${pad(minutes)}:${pad(seconds)}`;
  };

  const elapsedSeconds = totalSeconds - secondsRemaining;
  const progressPercent = Math.min(
    100,
    Math.round((elapsedSeconds / totalSeconds) * 100)
  );

  // Live accumulated coins as watch progresses
  const accumulatedCoins = Math.min(
    selectedTier.coins,
    Math.floor((elapsedSeconds / totalSeconds) * selectedTier.coins)
  );

  const handleClaimReward = () => {
    if (!currentUser || isClaimed) return;

    const reward = selectedTier.coins;
    adjustUserCoins(
      currentUser.id, 
      reward, 
      `YouTube Watch & Earn (${selectedTier.label}): ${video.title.slice(0, 30)}...`
    );

    // Record Play Seen for Admin Ad Revenue & Monetization
    recordPlaySeen(elapsedSeconds);

    setIsClaimed(true);
    setClaimedReward(reward);
    confetti({
      particleCount: 120,
      spread: 75,
      origin: { y: 0.6 }
    });

    if (onRewardClaimed) {
      onRewardClaimed(video.id, reward);
    }
  };

  const handleOpenDirectYouTube = () => {
    const directWatchUrl = `https://www.youtube.com/watch?v=${video.youtubeId}`;
    setIsWatchingOnExternalYouTube(true);
    window.open(directWatchUrl, '_blank', 'noopener,noreferrer');
  };

  const handleFastTestBoost = () => {
    // Allows fast simulation for verification without waiting 2 full hours in testing
    setSecondsRemaining((prev) => Math.max(0, prev - 600)); // jump 10 minutes ahead
  };

  const youtubeEmbedUrl = `https://www.youtube-nocookie.com/embed/${video.youtubeId}?autoplay=1&rel=0&modestbranding=1&enablejsapi=1`;
  const directWatchUrl = `https://www.youtube.com/watch?v=${video.youtubeId}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl relative max-h-[94vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Video Header with 100,000+ Badge */}
        <div className="space-y-1.5 pr-8">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] uppercase font-black px-2.5 py-0.5 rounded-full bg-red-600 text-white flex items-center gap-1 shadow-sm">
              <Play className="w-2.5 h-2.5 fill-current" />
              <span>Direct YouTube Player</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              ⚡ 100,000+ Video Pool
            </span>
            <span className="text-xs font-black text-emerald-400">
              +{selectedTier.coins.toLocaleString()} Coins (₹{(selectedTier.coins / 100).toFixed(0)} Cash)
            </span>
          </div>

          <h2 className="text-sm sm:text-base font-black text-white line-clamp-2">
            {video.title}
          </h2>
          <p className="text-[11px] text-slate-400">
            Channel: <strong className="text-slate-200">{video.channelTitle}</strong> • Views: {video.viewsCount} • Category: {video.category}
          </p>
        </div>

        {/* DURATION SELECTOR TIERS: 2 HOURS MARATHON (MAX ₹100) vs 1 HOUR vs QUICK */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-bold text-slate-300 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Select Watch Time & Earn Tier:</span>
            </span>
            <span className="text-amber-400 font-extrabold text-[10px]">
              Earn up to 10,000 Coins / ₹100
            </span>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
            {DURATION_TIERS.map((tier) => {
              const isSelected = selectedTier.seconds === tier.seconds;
              return (
                <button
                  key={tier.seconds}
                  type="button"
                  onClick={() => handleSelectTier(tier)}
                  className={`p-2 rounded-xl text-center transition-all cursor-pointer border flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-b from-red-600 to-rose-700 text-white border-red-500 shadow-md shadow-red-600/30 font-black'
                      : 'bg-slate-950/80 hover:bg-slate-800 border-slate-800 text-slate-300'
                  }`}
                >
                  <span className="text-[10px] font-bold block truncate">
                    {tier.label}
                  </span>
                  <span className={`text-[9px] mt-0.5 font-bold block ${isSelected ? 'text-amber-200' : 'text-emerald-400'}`}>
                    +{tier.coins >= 1000 ? `${(tier.coins / 1000).toFixed(1)}k` : tier.coins} C
                  </span>
                  <span className={`text-[8px] mt-0.5 px-1 rounded-md block truncate ${
                    isSelected ? 'bg-black/30 text-white' : 'bg-slate-900 text-amber-400'
                  }`}>
                    {tier.badge}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* EMBEDDED DIRECT YOUTUBE PLAYER */}
        <div className="w-full aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 relative shadow-2xl">
          <iframe
            src={youtubeEmbedUrl}
            title={video.title}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>

        {/* DIRECT YOUTUBE PLAY BUTTON (OPENS OFFICIAL YOUTUBE APP/SITE) */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-red-950/60 via-slate-950 to-slate-950 border border-red-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-white">
              <Tv className="w-4 h-4 text-red-500" />
              <span>Watch Directly on YouTube App</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Open in full official YouTube player or background while this timer earns your coins!
            </p>
          </div>

          <button
            type="button"
            onClick={handleOpenDirectYouTube}
            className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-red-600/30 transition-all cursor-pointer active:scale-95 shrink-0"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Play on Direct YouTube</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        {/* LIVE TIME TRACKER & COINS ACCUMULATION CARD */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Session Duration: {selectedTier.label}</span>
              </span>
              {speedMultiplier > 1 && (
                <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-400 text-[10px] font-black">
                  {speedMultiplier}x Boost
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <span className="font-mono font-black text-sm text-emerald-400">
                {isTimerComplete ? 'Completed!' : formatTime(secondsRemaining)}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden relative">
            <div 
              className={`h-full transition-all duration-300 ${
                isTimerComplete 
                  ? 'bg-emerald-500' 
                  : 'bg-gradient-to-r from-red-500 via-amber-400 to-emerald-400'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Live Accumulated Coins Banner */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
            <span className="flex items-center gap-1 text-amber-300 font-bold">
              <Coins className="w-3.5 h-3.5" />
              <span>Accumulated: {accumulatedCoins.toLocaleString()} / {selectedTier.coins.toLocaleString()} Coins</span>
            </span>

            <span className="text-slate-400 font-medium">
              {progressPercent}% Complete
            </span>
          </div>

          {/* Testing Fast-Forward Controls */}
          <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[10px] text-slate-500">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>Anti-cheat active: continuous watch tracked</span>
            </span>

            {!isTimerComplete && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setSpeedMultiplier(prev => prev === 1 ? 10 : prev === 10 ? 60 : 1)}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer"
                  title="Toggle Test Simulation Speed"
                >
                  ⚡ Speed: {speedMultiplier}x
                </button>
                <button
                  type="button"
                  onClick={handleFastTestBoost}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer flex items-center gap-0.5"
                  title="Fast Forward 10 Minutes"
                >
                  <FastForward className="w-3 h-3" />
                  <span>+10m</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* CLAIM REWARD OR ACTIVE TIMER BUTTON */}
        <div>
          {isClaimed ? (
            <div className="space-y-2">
              <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Credited +{claimedReward.toLocaleString()} Coins (₹{(claimedReward / 100).toFixed(0)}) to your wallet!</span>
              </div>

              {onWatchNext && (
                <button
                  type="button"
                  onClick={onWatchNext}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs shadow-md shadow-red-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Watch Next 2-Hour Video (+Coins)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          ) : isTimerComplete ? (
            <button
              type="button"
              onClick={handleClaimReward}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 text-slate-950 font-black text-xs shadow-xl shadow-emerald-500/30 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2 animate-bounce"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Claim +{selectedTier.coins.toLocaleString()} Coins (₹{(selectedTier.coins / 100).toFixed(0)} Cash) Now!</span>
            </button>
          ) : (
            <button
              disabled
              className="w-full py-3 rounded-xl bg-slate-800 text-slate-400 font-bold text-xs flex items-center justify-center gap-2 cursor-not-allowed border border-slate-700/50"
            >
              <Clock className="w-4 h-4 animate-spin text-amber-400" />
              <span>Watching YouTube Stream... ({formatTime(secondsRemaining)} left to claim {selectedTier.coins.toLocaleString()} Coins)</span>
            </button>
          )}
        </div>

        {/* Footer info */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
          <a
            href={directWatchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 hover:text-slate-300 underline"
          >
            <span>Open in YouTube App</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <span>100,000+ YouTube Videos Catalog Active</span>
        </div>

      </div>
    </div>
  );
};
