import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Project, ProjectCategory, ProjectPriority, ProjectMilestone } from '../types';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectToEdit?: Project | null;
}

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({ isOpen, onClose, projectToEdit }) => {
  const { clients, users, createProject, updateProject, currentDateStr } = useApp();

  const nextRefNumber = 90 + Math.floor(Math.random() * 10);
  const defaultRef = `PHX-2026-${nextRefNumber.toString().padStart(3, '0')}`;

  const [reference, setReference] = useState(defaultRef);
  const [name, setName] = useState('');
  const [clientId, setClientId] = useState(clients[0]?.id || '');
  const [category, setCategory] = useState<ProjectCategory>('Fire Alarm System');
  const [priority, setPriority] = useState<ProjectPriority>('High');
  const [startDate, setStartDate] = useState(currentDateStr);
  const [expectedCompletionDate, setExpectedCompletionDate] = useState('2026-12-30');
  const [siteLocation, setSiteLocation] = useState('Chennai, Tamil Nadu');
  const [contractValueINR, setContractValueINR] = useState(1500000);
  const [description, setDescription] = useState('');
  const [assignedEmployeeIds, setAssignedEmployeeIds] = useState<string[]>([]);

  // Sync state whenever projectToEdit or isOpen changes
  React.useEffect(() => {
    if (projectToEdit) {
      setReference(projectToEdit.reference);
      setName(projectToEdit.name);
      setClientId(projectToEdit.clientId);
      setCategory(projectToEdit.category);
      setPriority(projectToEdit.priority);
      setStartDate(projectToEdit.startDate);
      setExpectedCompletionDate(projectToEdit.expectedCompletionDate);
      setSiteLocation(projectToEdit.siteLocation);
      setContractValueINR(projectToEdit.contractValueINR || 1000000);
      setDescription(projectToEdit.description);
      setAssignedEmployeeIds(projectToEdit.assignedEmployeeIds || []);
    } else {
      setReference(`PHX-2026-${(90 + Math.floor(Math.random() * 10)).toString().padStart(3, '0')}`);
      setName('');
      setClientId(clients[0]?.id || '');
      setCategory('Fire Alarm System');
      setPriority('High');
      setStartDate(currentDateStr);
      setExpectedCompletionDate('2026-12-30');
      setSiteLocation('Chennai, Tamil Nadu');
      setContractValueINR(1500000);
      setDescription('');
      setAssignedEmployeeIds([users.find(u => u.role === 'Employee')?.id || '']);
    }
  }, [projectToEdit, isOpen, clients, users, currentDateStr]);

  if (!isOpen) return null;

  const employees = users.filter(u => u.role === 'Employee');

  const toggleEmployee = (empId: string) => {
    setAssignedEmployeeIds(prev => 
      prev.includes(empId) ? prev.filter(id => id !== empId) : [...prev, empId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedClient = clients.find(c => c.id === clientId);
    if (!selectedClient || !name) return;

    if (projectToEdit) {
      updateProject(projectToEdit.id, {
        reference,
        name,
        clientId,
        clientCompanyName: selectedClient.companyName,
        category,
        priority,
        startDate,
        expectedCompletionDate,
        siteLocation,
        contractValueINR: Number(contractValueINR),
        description,
        assignedEmployeeIds
      });
    } else {
      // Default milestones
      const defaultMilestones: ProjectMilestone[] = [
        { id: `m-${Date.now()}-1`, title: 'Site Inspection & Engineering Survey', description: 'CAD ducting survey and loop planning', completed: true, dueDate: startDate, completedDate: startDate },
        { id: `m-${Date.now()}-2`, title: 'Equipment Dispatch & Piping Installation', description: 'Material delivery from factory', completed: false, dueDate: '2026-11-15' },
        { id: `m-${Date.now()}-3`, title: 'Commissioning, Pressure Testing & TNFRS NOC', description: 'Statutory compliance demonstration', completed: false, dueDate: expectedCompletionDate }
      ];

      createProject({
        reference,
        name,
        clientId,
        clientCompanyName: selectedClient.companyName,
        category,
        priority,
        startDate,
        expectedCompletionDate,
        siteLocation,
        contractValueINR: Number(contractValueINR),
        description,
        assignedEmployeeIds,
        isManualProgress: false,
        milestones: defaultMilestones
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[95vh] sm:max-h-[90vh]">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              {projectToEdit ? 'Edit Fire Protection Project' : 'Create New Fire Protection Project'}
            </h3>
            <p className="text-[11px] sm:text-xs text-slate-500">
              {projectToEdit ? `Updating ${projectToEdit.reference}` : 'Initiate a work order, assign project engineers, and configure milestones'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold shrink-0"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Project Reference *</label>
              <input
                type="text"
                required
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold text-red-600"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Project Title *</label>
              <input
                type="text"
                required
                placeholder="e.g. Addressable Fire Alarm Upgrade (Phase 2)"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Client Company *</label>
              <select
                required
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
              >
                {clients.map(c => (
                  <option key={c.id} value={c.id}>{c.companyName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">System Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
              >
                <option value="Fire Alarm System">Fire Alarm System</option>
                <option value="Hydrant & Sprinkler">Hydrant & Sprinkler</option>
                <option value="CO2 & Clean Agent Gas">CO2 & Clean Agent Gas</option>
                <option value="Extinguisher & AMC">Extinguisher & AMC</option>
                <option value="TNFRS NOC Compliance">TNFRS NOC Compliance</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Start Date *</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Expected Completion *</label>
              <input
                type="date"
                required
                value={expectedCompletionDate}
                onChange={(e) => setExpectedCompletionDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Site Location *</label>
              <input
                type="text"
                required
                placeholder="e.g. Block C, Guindy Industrial Estate, Chennai"
                value={siteLocation}
                onChange={(e) => setSiteLocation(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Contract Value (INR ₹)</label>
              <input
                type="number"
                step="50000"
                value={contractValueINR}
                onChange={(e) => setContractValueINR(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Assign Engineers / Technicians</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 bg-slate-50 border border-slate-200 rounded-lg">
              {employees.map(emp => (
                <label key={emp.id} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={assignedEmployeeIds.includes(emp.id)}
                    onChange={() => toggleEmployee(emp.id)}
                    className="rounded text-red-600"
                  />
                  <span className="text-slate-800 font-medium">{emp.name}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Scope of Work & Engineering Notes</label>
            <textarea
              rows={3}
              placeholder="Describe equipment specifications, loop counts, compliance standards (IS 3844, NBC 2016)..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs transition-colors"
            >
              {projectToEdit ? 'Save Project Changes' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
