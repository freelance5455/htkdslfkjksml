import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Filter, 
  Edit, 
  Trash2, 
  Phone, 
  MapPin, 
  Tv, 
  Wifi, 
  Sparkles, 
  CreditCard, 
  ExternalLink,
  ChevronRight,
  Receipt,
  FileSpreadsheet,
  CheckCircle,
  XCircle,
  AlertTriangle,
  History,
  MessageSquare,
  Share2
} from 'lucide-react';
import { Customer, ServiceType, CustomerStatus, Language, Bill, Payment, BusinessProfile } from '../types';
import { translations } from '../translations';
import { receiptService } from '../services/receiptService';
import { DEFAULT_AREAS } from '../services/storage';
import { WhatsAppDispatchPayload } from './WhatsAppDispatchModal';

interface CustomerListViewProps {
  customers: Customer[];
  bills: Bill[];
  payments: Payment[];
  language: Language;
  profile: BusinessProfile;
  onSaveCustomer: (cust: Customer) => void;
  onDeleteCustomer: (id: string) => void;
  onQuickCollect: (customer: Customer) => void;
  onExportExcel: () => void;
  onOpenWhatsAppModal: (payload: WhatsAppDispatchPayload) => void;
  isLocked: boolean;
  onRequireUnlock: () => void;
}

export const CustomerListView: React.FC<CustomerListViewProps> = ({
  customers,
  bills,
  payments,
  language,
  profile,
  onSaveCustomer,
  onDeleteCustomer,
  onQuickCollect,
  onExportExcel,
  onOpenWhatsAppModal,
  isLocked,
  onRequireUnlock,
}) => {
  const t = translations[language];

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedService, setSelectedService] = useState<string>('ALL');
  const [selectedArea, setSelectedArea] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [duesOnly, setDuesOnly] = useState<boolean>(false);

  // Edit / Add Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Partial<Customer> | null>(null);

  // Detail / Ledger Drawer
  const [selectedCustomerForHistory, setSelectedCustomerForHistory] = useState<Customer | null>(null);

  // Filter customers
  const filteredCustomers = customers.filter(c => {
    // Search query matches name, ID, or mobile
    const q = searchQuery.toLowerCase().trim();
    const matchQuery = 
      !q || 
      c.name.toLowerCase().includes(q) || 
      c.customerCode.toLowerCase().includes(q) || 
      c.mobile.includes(q) ||
      c.area.toLowerCase().includes(q);

    const matchService = selectedService === 'ALL' || c.serviceType === selectedService;
    const matchArea = selectedArea === 'ALL' || c.area === selectedArea;
    const matchStatus = selectedStatus === 'ALL' || c.status === selectedStatus;
    const matchDues = !duesOnly || (c.totalOutstanding > 0);

    return matchQuery && matchService && matchArea && matchStatus && matchDues;
  });

  const handleOpenAdd = () => {
    setEditingCustomer({
      customerCode: `CNC-${1001 + customers.length}`,
      name: '',
      mobile: '',
      address: '',
      area: 'Mandir Sahi',
      serviceType: 'COMBO',
      planName: 'Fiber 50Mbps + 350 Channels HD',
      monthlyAmount: 699,
      setupBoxNo: '',
      ipOrMacAddress: '',
      status: 'ACTIVE',
      connectionDate: new Date().toISOString().split('T')[0],
      previousDues: 0,
      currentDues: 699,
      totalOutstanding: 699,
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (customer: Customer) => {
    setEditingCustomer({ ...customer });
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer || !editingCustomer.name || !editingCustomer.mobile) return;

    const toSave: Customer = {
      id: editingCustomer.id || `cust-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      customerCode: editingCustomer.customerCode || `CNC-${1000 + customers.length}`,
      name: editingCustomer.name,
      mobile: editingCustomer.mobile.replace(/\D/g, ''),
      address: editingCustomer.address || 'Champeswar',
      area: editingCustomer.area || 'Champeswar Bazar',
      serviceType: editingCustomer.serviceType || 'CABLE',
      planName: editingCustomer.planName || 'Standard Plan',
      monthlyAmount: Number(editingCustomer.monthlyAmount) || 0,
      setupBoxNo: editingCustomer.setupBoxNo || '',
      ipOrMacAddress: editingCustomer.ipOrMacAddress || '',
      status: editingCustomer.status || 'ACTIVE',
      connectionDate: editingCustomer.connectionDate || new Date().toISOString().split('T')[0],
      previousDues: Number(editingCustomer.previousDues) || 0,
      currentDues: Number(editingCustomer.currentDues) || Number(editingCustomer.monthlyAmount) || 0,
      totalOutstanding: (Number(editingCustomer.previousDues) || 0) + (Number(editingCustomer.currentDues) || Number(editingCustomer.monthlyAmount) || 0),
      notes: editingCustomer.notes || '',
      createdAt: editingCustomer.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSaveCustomer(toSave);
    setIsModalOpen(false);
    setEditingCustomer(null);
  };

  const handleDelete = (id: string, name: string) => {
    if (isLocked) {
      onRequireUnlock();
      return;
    }
    if (window.confirm(`${t.confirmDelete}\n\nCustomer: ${name}`)) {
      onDeleteCustomer(id);
    }
  };

  // Unique areas from customer database
  const areasList = Array.from(new Set([...DEFAULT_AREAS, ...customers.map(c => c.area)]));

  return (
    <div className="space-y-6">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-cyan-400" />
            <span>{t.customerList}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
              {filteredCustomers.length} of {customers.length}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Search, filter, view ledger, edit, or collect payments for cable &amp; broadband subscribers.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={onExportExcel}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow-sm transition"
            title="Export all customers to Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Export Master (Excel)</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-cyan-950/40 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addCustomer}</span>
          </button>
        </div>
      </div>

      {/* Search & Multi-Filters Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          
          {/* Search Input */}
          <div className="relative w-full sm:flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 transition"
            />
          </div>

          {/* Dues Only Toggle */}
          <button
            onClick={() => setDuesOnly(!duesOnly)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              duesOnly
                ? 'bg-rose-500 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Overdue Only</span>
          </button>

        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800/70">
          
          {/* Service Filter */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              {t.serviceType}
            </label>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-cyan-500"
            >
              <option value="ALL">{t.allServices}</option>
              <option value="CABLE">{t.cableTV}</option>
              <option value="BROADBAND">{t.broadband}</option>
              <option value="COMBO">{t.combo}</option>
            </select>
          </div>

          {/* Area Filter */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              {t.area}
            </label>
            <select
              value={selectedArea}
              onChange={(e) => setSelectedArea(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-cyan-500"
            >
              <option value="ALL">{t.allAreas}</option>
              {areasList.map(a => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              {t.status}
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-cyan-500"
            >
              <option value="ALL">{t.allStatuses}</option>
              <option value="ACTIVE">{t.active}</option>
              <option value="INACTIVE">{t.inactive}</option>
              <option value="SUSPENDED">{t.suspended}</option>
            </select>
          </div>

        </div>
      </div>

      {/* Customer List Table / Mobile Cards */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        {filteredCustomers.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <Users className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-sm font-semibold">{t.noDataFound}</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedService('ALL');
                setSelectedArea('ALL');
                setSelectedStatus('ALL');
                setDuesOnly(false);
              }}
              className="mt-3 text-xs text-cyan-400 hover:underline"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-bold">{t.customerId} / {t.customerName}</th>
                  <th className="py-3.5 px-4 font-bold">{t.mobileNumber}</th>
                  <th className="py-3.5 px-4 font-bold">{t.area} &amp; {t.address}</th>
                  <th className="py-3.5 px-4 font-bold">{t.serviceType} / Plan</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.currentBalance}</th>
                  <th className="py-3.5 px-4 font-bold text-center">{t.status}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredCustomers.map(customer => {
                  const hasDues = customer.totalOutstanding > 0;
                  return (
                    <tr key={customer.id} className="hover:bg-slate-850/50 transition">
                      {/* Name & ID */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                            customer.serviceType === 'CABLE'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : customer.serviceType === 'BROADBAND'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                          }`}>
                            {customer.serviceType === 'CABLE' ? <Tv className="w-4 h-4" /> : customer.serviceType === 'BROADBAND' ? <Wifi className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                          </div>
                          <div>
                            <span 
                              onClick={() => setSelectedCustomerForHistory(customer)}
                              className="font-bold text-slate-100 hover:text-cyan-400 cursor-pointer text-sm block"
                            >
                              {customer.name}
                            </span>
                            <span className="text-[11px] font-mono text-cyan-400">
                              {customer.customerCode}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Mobile */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-slate-200">
                          <Phone className="w-3 h-3 text-slate-500" />
                          <a href={`tel:${customer.mobile}`} className="hover:text-cyan-400">
                            {customer.mobile}
                          </a>
                        </div>
                      </td>

                      {/* Area & Address */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-start gap-1 text-slate-300">
                          <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-semibold block">{customer.area}</span>
                            <span className="text-[11px] text-slate-400 block line-clamp-1">{customer.address}</span>
                          </div>
                        </div>
                      </td>

                      {/* Service & Plan */}
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-200 block">{customer.planName}</span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {receiptService.formatCurrency(customer.monthlyAmount)} / mo
                        </span>
                      </td>

                      {/* Balance / Outstanding */}
                      <td className="py-3.5 px-4 text-right">
                        <span className={`font-black text-sm font-mono-num block ${hasDues ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {receiptService.formatCurrency(customer.totalOutstanding)}
                        </span>
                        {customer.previousDues > 0 && (
                          <span className="text-[10px] text-slate-400 block font-mono">
                            Prev: {receiptService.formatCurrency(customer.previousDues)}
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          customer.status === 'ACTIVE'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : customer.status === 'INACTIVE'
                            ? 'bg-slate-800 text-slate-400 border border-slate-700'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {customer.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Send WhatsApp Dues Notice */}
                          <button
                            onClick={() => onOpenWhatsAppModal({
                              mode: 'DUES',
                              customer,
                            })}
                            className={`p-1.5 rounded-lg border transition ${
                              customer.totalOutstanding > 0 
                                ? 'bg-emerald-950 text-emerald-400 border-emerald-800 hover:bg-emerald-900 shadow-sm' 
                                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-emerald-400'
                            }`}
                            title={customer.totalOutstanding > 0 ? "Send Outstanding Dues on WhatsApp" : "Send Account Info on WhatsApp"}
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>

                          {/* Quick Collect Payment */}
                          <button
                            onClick={() => onQuickCollect(customer)}
                            className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition shadow-sm"
                            title={t.quickCollect}
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                          </button>

                          {/* View Ledger / History */}
                          <button
                            onClick={() => setSelectedCustomerForHistory(customer)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                            title="View Customer Ledger & History"
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit Customer */}
                          <button
                            onClick={() => handleOpenEdit(customer)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                            title={t.editCustomer}
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete Customer */}
                          <button
                            onClick={() => handleDelete(customer.id, customer.name)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-400 transition"
                            title={t.deleteCustomer}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Customer Add / Edit Modal */}
      {isModalOpen && editingCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-cyan-400" />
                <span>{editingCustomer.id ? t.editCustomer : t.addCustomer}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.customerId} *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingCustomer.customerCode || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, customerCode: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.customerName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingCustomer.name || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                    placeholder="e.g. Ramesh Chandra Das"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.mobileNumber} *
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={editingCustomer.mobile || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, mobile: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                    placeholder="10 digit mobile"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.area} *
                  </label>
                  <input
                    type="text"
                    required
                    list="areas-datalist"
                    value={editingCustomer.area || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, area: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                    placeholder="Select or enter area"
                  />
                  <datalist id="areas-datalist">
                    {areasList.map(a => <option key={a} value={a} />)}
                  </datalist>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.address}
                  </label>
                  <input
                    type="text"
                    value={editingCustomer.address || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, address: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                    placeholder="Street, Landmark, Plot number"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.serviceType}
                  </label>
                  <select
                    value={editingCustomer.serviceType || 'CABLE'}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, serviceType: e.target.value as ServiceType })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                  >
                    <option value="CABLE">{t.cableTV}</option>
                    <option value="BROADBAND">{t.broadband}</option>
                    <option value="COMBO">{t.combo}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.monthlySubscription} *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editingCustomer.monthlyAmount ?? ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, monthlyAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.previousDues}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingCustomer.previousDues ?? 0}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, previousDues: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.status}
                  </label>
                  <select
                    value={editingCustomer.status || 'ACTIVE'}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, status: e.target.value as CustomerStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                  >
                    <option value="ACTIVE">{t.active}</option>
                    <option value="INACTIVE">{t.inactive}</option>
                    <option value="SUSPENDED">{t.suspended}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.boxOrRouterNo}
                  </label>
                  <input
                    type="text"
                    value={editingCustomer.setupBoxNo || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, setupBoxNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                    placeholder="e.g. STB-998822 / MAC"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.ipAddress}
                  </label>
                  <input
                    type="text"
                    value={editingCustomer.ipOrMacAddress || ''}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, ipOrMacAddress: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                    placeholder="192.168.x.x / VLAN"
                  />
                </div>

              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-900/30"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Ledger & History Drawer / Modal */}
      {selectedCustomerForHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <span>{selectedCustomerForHistory.name}</span>
                  <span className="text-xs font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
                    {selectedCustomerForHistory.customerCode}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  {selectedCustomerForHistory.area} • {selectedCustomerForHistory.mobile}
                </p>
              </div>
              <button
                onClick={() => setSelectedCustomerForHistory(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            {/* Quick Balance Summary */}
            <div className="grid grid-cols-3 gap-3 p-3 rounded-xl bg-slate-850 border border-slate-800 text-center">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Monthly Plan</span>
                <span className="text-sm font-bold text-cyan-300 font-mono-num">
                  {receiptService.formatCurrency(selectedCustomerForHistory.monthlyAmount)}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Previous Dues</span>
                <span className="text-sm font-bold text-slate-300 font-mono-num">
                  {receiptService.formatCurrency(selectedCustomerForHistory.previousDues)}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Outstanding</span>
                <span className={`text-base font-extrabold font-mono-num ${selectedCustomerForHistory.totalOutstanding > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {receiptService.formatCurrency(selectedCustomerForHistory.totalOutstanding)}
                </span>
              </div>
            </div>

            {/* Billing History */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Bills Issued
              </h4>
              <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                {bills.filter(b => b.customerId === selectedCustomerForHistory.id).length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No bill records generated yet.</p>
                ) : (
                  bills
                    .filter(b => b.customerId === selectedCustomerForHistory.id)
                    .map(b => (
                      <div key={b.id} className="p-2.5 rounded-lg bg-slate-800/70 border border-slate-750 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-semibold text-slate-200 block">{b.billNumber} ({b.billingMonth})</span>
                          <span className="text-[11px] text-slate-400">Plan: {receiptService.formatCurrency(b.planAmount)} • Total: {receiptService.formatCurrency(b.totalAmount)}</span>
                        </div>
                        <div className="text-right">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            b.status === 'PAID' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'
                          }`}>
                            {b.status}
                          </span>
                          <span className="block font-mono text-[11px] text-slate-300 mt-0.5">
                            Due: {receiptService.formatCurrency(b.balanceDue)}
                          </span>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>

            {/* Payments History */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Payments Received
              </h4>
              <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                {payments.filter(p => p.customerId === selectedCustomerForHistory.id).length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No payment transactions recorded.</p>
                ) : (
                  payments
                    .filter(p => p.customerId === selectedCustomerForHistory.id)
                    .map(p => (
                      <div key={p.id} className="p-2.5 rounded-lg bg-slate-800/70 border border-slate-750 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-mono text-cyan-300 font-semibold block">{p.receiptNo}</span>
                          <span className="text-[11px] text-slate-400">{receiptService.formatDate(p.paymentDate)} • {p.paymentMethod}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-emerald-400 font-mono-num text-sm">
                            +{receiptService.formatCurrency(p.amount)}
                          </span>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>

            {/* Footer action */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  const cust = selectedCustomerForHistory;
                  setSelectedCustomerForHistory(null);
                  onOpenWhatsAppModal({
                    mode: 'DUES',
                    customer: cust,
                  });
                }}
                className="px-4 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 font-bold text-xs flex items-center gap-1.5 transition"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Send WhatsApp Notice</span>
              </button>

              <button
                onClick={() => {
                  const cust = selectedCustomerForHistory;
                  setSelectedCustomerForHistory(null);
                  onQuickCollect(cust);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Collect Payment</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
