import { cn } from "@/lib/utils";
import { POST_SORTS, type PostSort } from "@/lib/sort";
import { ChevronDown } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export function SortBar({
  value,
  onChange,
}: {
  value: PostSort;
  onChange: (sort: PostSort) => void;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const current = POST_SORTS.find((s) => s.id === value)?.label ?? "Sort";

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!root.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  return (
    <div ref={root} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex h-11 max-w-[11rem] items-center gap-1 rounded-xl bg-secondary px-3 text-xs font-medium"
        aria-expanded={open}
      >
        <span className="truncate">{current}</span>
        <ChevronDown className="size-4 shrink-0" />
      </button>
      {open ? (
        <ul className="absolute right-0 z-50 mt-1 w-72 overflow-hidden rounded-xl border border-border bg-card py-1 shadow-lg">
          {POST_SORTS.map((item) => {
            const active = item.id === value;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  className={cn(
                    "flex h-11 w-full items-center px-3 text-left text-xs font-medium",
                    active ? "bg-secondary text-foreground" : "text-muted-foreground",
                  )}
                  onClick={() => {
                    onChange(item.id);
                    setOpen(false);
                  }}
                >
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}
