import React, { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { BarcodeFormat, DecodeHintType } from '@zxing/library';
import { Camera, Flashlight, ImagePlus, RefreshCw, ScanBarcode, ZoomIn } from 'lucide-react';
import type { Product } from '../types';
import { Modal } from './SharedUI';

interface BarcodeDetectorResult {
  rawValue?: string;
}

interface BarcodeDetectorInstance {
  detect: (source: HTMLVideoElement | HTMLCanvasElement) => Promise<BarcodeDetectorResult[]>;
}

interface BarcodeDetectorConstructor {
  new (options?: { formats?: string[] }): BarcodeDetectorInstance;
  getSupportedFormats?: () => Promise<string[]>;
}

interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
  onDetected: (code: string) => void;
  title?: string;
  t: Record<string, string>;
  products?: Product[];
}

const TARGET_NATIVE_FORMATS = [
  'code_128',
  'code_39',
  'code_93',
  'ean_13',
  'ean_8',
  'upc_a',
  'upc_e',
  'itf',
  'codabar',
  'qr_code',
  'data_matrix',
];

const playBeep = () => {
  try {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(45);
    }
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = 960;
    gain.gain.value = 0.08;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.09);
  } catch {
    // Ignore audio context restrictions
  }
};

const createZxingReader = () => {
  const hints = new Map<DecodeHintType, unknown>();
  hints.set(DecodeHintType.TRY_HARDER, true);
  hints.set(DecodeHintType.POSSIBLE_FORMATS, [
    BarcodeFormat.EAN_13,
    BarcodeFormat.EAN_8,
    BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E,
    BarcodeFormat.CODE_128,
    BarcodeFormat.CODE_39,
    BarcodeFormat.CODE_93,
    BarcodeFormat.ITF,
    BarcodeFormat.CODABAR,
    BarcodeFormat.QR_CODE,
    BarcodeFormat.DATA_MATRIX,
  ]);
  return new BrowserMultiFormatReader(hints);
};

// Boosts contrast & normalizes luminance directly on ImageData for glossy/low-light 1D barcodes
const stretchContrast = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
  const imgData = ctx.getImageData(0, 0, w, h);
  const d = imgData.data;
  let min = 255;
  let max = 0;
  for (let i = 0; i < d.length; i += 16) {
    const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    if (lum < min) min = lum;
    if (lum > max) max = lum;
  }
  const range = Math.max(24, max - min);
  const scale = 255 / range;
  for (let i = 0; i < d.length; i += 4) {
    const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    let v = (lum - min) * scale;
    v = v < 0 ? 0 : v > 255 ? 255 : v;
    d[i] = v;
    d[i + 1] = v;
    d[i + 2] = v;
  }
  ctx.putImageData(imgData, 0, 0);
};

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  open,
  onClose,
  onDetected,
  title,
  t,
  products = [],
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const onDetectedRef = useRef(onDetected);
  const onCloseRef = useRef(onClose);
  const handledRef = useRef(false);

  const [manualCode, setManualCode] = useState('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraStatus, setCameraStatus] = useState<'initializing' | 'active' | 'denied'>('initializing');
  const [torchOn, setTorchOn] = useState(false);
  const [zoomSupported, setZoomSupported] = useState(false);
  const [zoom2x, setZoom2x] = useState(false);
  const [zoomRange, setZoomRange] = useState<{ min: number; max: number }>({ min: 1, max: 2 });
  const [detectedFlash, setDetectedFlash] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState('');

  useEffect(() => {
    onDetectedRef.current = onDetected;
  }, [onDetected]);

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  const emitCodeAndClose = (raw: string) => {
    const code = raw.trim();
    if (!code || handledRef.current) return;
    handledRef.current = true;
    playBeep();
    setDetectedFlash(code);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((tr) => tr.stop());
      streamRef.current = null;
    }
    window.setTimeout(() => {
      onDetectedRef.current(code);
      onCloseRef.current();
    }, 180);
  };

  useEffect(() => {
    if (!open) {
      handledRef.current = false;
      setTorchOn(false);
      setZoomSupported(false);
      setZoom2x(false);
      setDetectedFlash(null);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((tr) => tr.stop());
        streamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
      setManualCode('');
      setErrorDetail('');
      return;
    }

    let cancelled = false;
    let timerId: number | null = null;
    handledRef.current = false;
    setDetectedFlash(null);

    const stopCurrentStream = () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((tr) => tr.stop());
        streamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };

    const startScanner = async () => {
      setCameraStatus('initializing');
      setErrorDetail('');
      setTorchOn(false);
      setZoomSupported(false);
      setZoom2x(false);

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraStatus('denied');
        return;
      }

      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: facingMode },
              width: { ideal: 1920 },
              height: { ideal: 1080 },
            },
            audio: false,
          });
        } catch {
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              video: { facingMode: { ideal: facingMode } },
              audio: false,
            });
          } catch {
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          }
        }

        if (cancelled) {
          stream.getTracks().forEach((tr) => tr.stop());
          return;
        }

        streamRef.current = stream;
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack) {
          try {
            const caps = videoTrack.getCapabilities?.() as MediaTrackCapabilities & {
              focusMode?: string[];
              zoom?: { min?: number; max?: number };
            };
            if (caps?.focusMode?.includes('continuous')) {
              await videoTrack.applyConstraints({
                advanced: [{ focusMode: 'continuous' } as MediaTrackConstraintSet],
              });
            }
            if (caps?.zoom && typeof caps.zoom.max === 'number' && caps.zoom.max > 1.2) {
              setZoomSupported(true);
              setZoomRange({ min: caps.zoom.min ?? 1, max: Math.min(caps.zoom.max, 2.5) });
            }
          } catch {
            // Optional camera capabilities not supported
          }
        }

        const videoEl = videoRef.current;
        if (videoEl) {
          videoEl.srcObject = stream;
          videoEl.setAttribute('playsinline', 'true');
          await videoEl.play().catch(() => {});
        }

        if (cancelled) return;
        setCameraStatus('active');

        const win = window as unknown as { BarcodeDetector?: BarcodeDetectorConstructor };
        let nativeDetector: BarcodeDetectorInstance | null = null;
        if (win.BarcodeDetector) {
          try {
            if (typeof win.BarcodeDetector.getSupportedFormats === 'function') {
              const supported = await win.BarcodeDetector.getSupportedFormats();
              const allowed = TARGET_NATIVE_FORMATS.filter((f) => supported.includes(f));
              nativeDetector =
                allowed.length > 0 ? new win.BarcodeDetector({ formats: allowed }) : new win.BarcodeDetector();
            } else {
              nativeDetector = new win.BarcodeDetector();
            }
          } catch {
            try {
              nativeDetector = new win.BarcodeDetector();
            } catch {
              nativeDetector = null;
            }
          }
        }

        const zxingReader = createZxingReader();
        const roiCanvas = document.createElement('canvas');
        const roiCtx = roiCanvas.getContext('2d', { willReadFrequently: true });
        const fullCanvas = document.createElement('canvas');
        const fullCtx = fullCanvas.getContext('2d', { willReadFrequently: true });
        const rotCanvas = document.createElement('canvas');
        const rotCtx = rotCanvas.getContext('2d', { willReadFrequently: true });
        let frameCount = 0;

        const tryZxing = (canvas: HTMLCanvasElement): string | null => {
          try {
            const res = zxingReader.decodeFromCanvas(canvas);
            const txt = res?.getText?.();
            return txt && txt.trim().length > 0 ? txt.trim() : null;
          } catch {
            return null;
          }
        };

        const scanFrame = async () => {
          if (cancelled || handledRef.current) return;
          const v = videoRef.current;
          if (v && v.readyState >= 2 && v.videoWidth > 0 && v.videoHeight > 0) {
            frameCount += 1;
            const vw = v.videoWidth;
            const vh = v.videoHeight;

            // 1. Native hardware BarcodeDetector on live video element
            if (nativeDetector) {
              try {
                const results = await nativeDetector.detect(v);
                const found = results.find((r) => r.rawValue && r.rawValue.trim().length > 0);
                if (found?.rawValue) {
                  emitCodeAndClose(found.rawValue);
                  return;
                }
              } catch {
                // Fall through to canvas / ZXing
              }
            }

            // 2. Center-ROI crop (scaled cleanly so 1D bars stay crisp & fast)
            if (roiCtx) {
              const srcW = Math.max(240, Math.floor(vw * 0.82));
              const srcH = Math.max(140, Math.floor(vh * 0.54));
              const sx = Math.max(0, Math.floor((vw - srcW) / 2));
              const sy = Math.max(0, Math.floor((vh - srcH) / 2));
              const outScale = Math.min(1, 960 / srcW);
              const cw = Math.max(200, Math.floor(srcW * outScale));
              const ch = Math.max(120, Math.floor(srcH * outScale));

              if (roiCanvas.width !== cw || roiCanvas.height !== ch) {
                roiCanvas.width = cw;
                roiCanvas.height = ch;
              }
              roiCtx.drawImage(v, sx, sy, srcW, srcH, 0, 0, cw, ch);

              if (nativeDetector) {
                try {
                  const resRoi = await nativeDetector.detect(roiCanvas);
                  const foundRoi = resRoi.find((r) => r.rawValue && r.rawValue.trim().length > 0);
                  if (foundRoi?.rawValue) {
                    emitCodeAndClose(foundRoi.rawValue);
                    return;
                  }
                } catch {
                  // Ignore
                }
              }

              const directHit = tryZxing(roiCanvas);
              if (directHit) {
                emitCodeAndClose(directHit);
                return;
              }

              // Every 2nd frame: contrast-normalized grayscale pass for glossy or dim labels
              if (frameCount % 2 === 0) {
                stretchContrast(roiCtx, cw, ch);
                const contrastHit = tryZxing(roiCanvas);
                if (contrastHit) {
                  emitCodeAndClose(contrastHit);
                  return;
                }
              }

              // Every 4th frame: 90-degree rotated pass for vertical barcodes
              if (frameCount % 4 === 0 && rotCtx) {
                if (rotCanvas.width !== ch || rotCanvas.height !== cw) {
                  rotCanvas.width = ch;
                  rotCanvas.height = cw;
                }
                rotCtx.save();
                rotCtx.translate(ch / 2, cw / 2);
                rotCtx.rotate(Math.PI / 2);
                rotCtx.drawImage(v, sx, sy, srcW, srcH, -cw / 2, -ch / 2, cw, ch);
                rotCtx.restore();
                const rotHit = tryZxing(rotCanvas);
                if (rotHit) {
                  emitCodeAndClose(rotHit);
                  return;
                }
              }
            }

            // 3. Every 3rd frame: Full frame scan for off-center barcodes
            if (frameCount % 3 === 0 && fullCtx) {
              const scale = Math.min(1, 1080 / Math.max(vw, vh));
              const fw = Math.max(1, Math.floor(vw * scale));
              const fh = Math.max(1, Math.floor(vh * scale));
              if (fullCanvas.width !== fw || fullCanvas.height !== fh) {
                fullCanvas.width = fw;
                fullCanvas.height = fh;
              }
              fullCtx.drawImage(v, 0, 0, fw, fh);
              const fullHit = tryZxing(fullCanvas);
              if (fullHit) {
                emitCodeAndClose(fullHit);
                return;
              }
            }
          }

          if (!cancelled && !handledRef.current) {
            timerId = window.setTimeout(scanFrame, 150);
          }
        };

        timerId = window.setTimeout(scanFrame, 260);
      } catch (err) {
        if (!cancelled) {
          setCameraStatus('denied');
          if (err instanceof Error && err.message) {
            setErrorDetail(err.message);
          }
        }
      }
    };

    startScanner();

    return () => {
      cancelled = true;
      if (timerId !== null) window.clearTimeout(timerId);
      stopCurrentStream();
    };
  }, [open, facingMode]);

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    const next = !torchOn;
    try {
      await track.applyConstraints({
        advanced: [{ torch: next } as MediaTrackConstraintSet],
      });
      setTorchOn(next);
      setErrorDetail('');
    } catch {
      setErrorDetail('Flashlight is not supported by this browser or camera lens.');
    }
  };

  const toggleZoom = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track || !zoomSupported) return;
    const next = !zoom2x;
    try {
      await track.applyConstraints({
        advanced: [{ zoom: next ? zoomRange.max : zoomRange.min } as MediaTrackConstraintSet],
      });
      setZoom2x(next);
    } catch {
      // Ignore unsupported zoom transition
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const url = URL.createObjectURL(file);
    try {
      const img = new Image();
      img.onload = async () => {
        try {
          const c = document.createElement('canvas');
          const scale = Math.min(1, 1400 / Math.max(img.width, img.height));
          c.width = Math.max(1, Math.floor(img.width * scale));
          c.height = Math.max(1, Math.floor(img.height * scale));
          const ctx = c.getContext('2d', { willReadFrequently: true });
          if (ctx) {
            ctx.drawImage(img, 0, 0, c.width, c.height);

            const win = window as unknown as { BarcodeDetector?: BarcodeDetectorConstructor };
            if (win.BarcodeDetector) {
              try {
                const det = new win.BarcodeDetector();
                const res = await det.detect(c);
                const hit = res.find((r) => r.rawValue && r.rawValue.trim());
                if (hit?.rawValue) {
                  emitCodeAndClose(hit.rawValue);
                  return;
                }
              } catch {
                // Fall back to ZXing
              }
            }

            const reader = createZxingReader();
            try {
              const result = reader.decodeFromCanvas(c);
              const txt = result?.getText?.();
              if (txt && txt.trim()) {
                emitCodeAndClose(txt);
                return;
              }
            } catch {
              stretchContrast(ctx, c.width, c.height);
              const result2 = reader.decodeFromCanvas(c);
              const txt2 = result2?.getText?.();
              if (txt2 && txt2.trim()) {
                emitCodeAndClose(txt2);
                return;
              }
            }
          }
          setErrorDetail('Could not detect a barcode in that photo. Try clearer lighting or enter manually.');
        } catch {
          setErrorDetail('Could not detect a barcode in that photo. Try clearer lighting or enter manually.');
        } finally {
          URL.revokeObjectURL(url);
        }
      };
      img.src = url;
    } catch {
      URL.revokeObjectURL(url);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = manualCode.trim();
    if (!code) return;
    handledRef.current = true;
    onDetectedRef.current(code);
    setManualCode('');
    onCloseRef.current();
  };

  const quickProducts = products.filter((p) => p.barcode || p.sku).slice(0, 6);

  return (
    <Modal open={open} onClose={onClose} title={title || t.barcodeScannerTitle} maxWidth="max-w-md">
      <div className="space-y-4">
        {/* Camera Viewfinder */}
        <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 aspect-[4/3] flex items-center justify-center">
          <video ref={videoRef} muted playsInline autoPlay className="w-full h-full object-cover" />

          {cameraStatus === 'active' && (
            <>
              <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5">
                {zoomSupported && (
                  <button
                    type="button"
                    onClick={toggleZoom}
                    className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold border backdrop-blur-sm ${
                      zoom2x
                        ? 'bg-blue-500 text-white border-blue-400'
                        : 'bg-slate-900/85 hover:bg-slate-900 text-white border-white/15'
                    }`}
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>{zoom2x ? '2x' : '1x'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={toggleTorch}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold border backdrop-blur-sm ${
                    torchOn
                      ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.45)]'
                      : 'bg-slate-900/85 hover:bg-slate-900 text-white border-white/15'
                  }`}
                >
                  <Flashlight className="w-3.5 h-3.5" />
                  <span>{torchOn ? 'Flash On' : 'Flashlight'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/85 hover:bg-slate-900 text-white text-[11px] font-bold border border-white/15 backdrop-blur-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Switch</span>
                </button>
              </div>

              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-6">
                <div
                  className={`w-64 h-36 relative border-2 rounded-xl shadow-[0_0_0_9999px_rgba(2,6,23,0.42)] transition-colors ${
                    detectedFlash ? 'border-emerald-400 bg-emerald-500/15' : 'border-blue-400/90'
                  }`}
                >
                  <div className={`absolute inset-x-3 top-1/2 h-0.5 ${detectedFlash ? 'bg-emerald-400' : 'bg-rose-500/90'}`} />
                </div>
                <p className="mt-4 text-xs font-medium text-white bg-slate-900/85 px-3 py-1.5 rounded-lg text-center">
                  {detectedFlash ? `Detected: ${detectedFlash}` : t.cameraScanningActive}
                </p>
              </div>
            </>
          )}

          {cameraStatus === 'initializing' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-200 gap-2 p-4 text-center bg-slate-950/90">
              <Camera className="w-8 h-8 text-blue-400" />
              <p className="text-xs font-medium">Starting camera...</p>
            </div>
          )}

          {cameraStatus === 'denied' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-300 gap-2.5 p-6 text-center bg-slate-900/95">
              <ScanBarcode className="w-9 h-9 text-blue-400" />
              <p className="text-xs text-slate-200 leading-relaxed max-w-xs">{t.cameraUnavailableFallback}</p>
            </div>
          )}
        </div>

        {errorDetail && (
          <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 font-medium">
            {errorDetail}
          </p>
        )}

        {/* Photo Upload Scan Fallback + Manual / USB Barcode Input */}
        <form noValidate onSubmit={handleManualSubmit} className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <label className="block text-xs font-semibold text-slate-600">{t.manualBarcodeEntry}</label>
            <input ref={photoInputRef} type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
            <button
              type="button"
              onClick={() => photoInputRef.current?.click()}
              className="btn-secondary px-2.5 py-1 text-[11px]"
            >
              <ImagePlus className="w-3.5 h-3.5 text-blue-600" />
              <span>Scan Photo</span>
            </button>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="e.g. 8901001001 or EL-1001"
              className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
            <button type="submit" className="btn-primary px-4 py-2.5 text-xs">
              {t.applyBarcode}
            </button>
          </div>
        </form>

        {/* Quick Barcode Selectors */}
        {quickProducts.length > 0 && (
          <div className="pt-2.5 border-t border-slate-100">
            <p className="text-[11px] font-semibold text-slate-500 mb-2">Available Product Barcodes</p>
            <div className="flex flex-wrap gap-1.5">
              {quickProducts.map((p) => {
                const code = p.barcode || p.sku;
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => {
                      handledRef.current = true;
                      onDetectedRef.current(code);
                      onCloseRef.current();
                    }}
                    className="option-chip px-2.5 py-1.5 text-[11px]"
                  >
                    <span className="font-mono font-bold text-slate-900">{code}</span>
                    <span className="text-slate-500 truncate max-w-[140px]">{p.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
