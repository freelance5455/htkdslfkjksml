import React, { useEffect, useRef, useState } from 'react';
import { Camera, Flashlight, X, Search, Check, AlertCircle } from 'lucide-react';
import { sound } from '../utils/sound';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [hasCamera, setHasCamera] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [torchOn, setTorchOn] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const streamRef = useRef<MediaStream | null>(null);
  const isScanningRef = useRef(false);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    startCamera();
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setHasCamera(false);
        setCameraError('الكاميرا غير مدعومة في هذا المتصفح');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setHasCamera(true);

      // Check native BarcodeDetector API
      const BarcodeDetectorClass = (window as unknown as { BarcodeDetector?: any }).BarcodeDetector;
      if (BarcodeDetectorClass) {
        const detector = new BarcodeDetectorClass({
          formats: ['code_128', 'ean_13', 'ean_8', 'qr_code', 'upc_a'],
        });

        isScanningRef.current = true;
        const scanLoop = async () => {
          if (!isScanningRef.current || !videoRef.current) return;
          try {
            if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
              const barcodes = await detector.detect(videoRef.current);
              if (barcodes.length > 0) {
                const rawValue = barcodes[0].rawValue;
                if (rawValue) {
                  sound.playBarcodeBeep();
                  onScan(rawValue);
                  onClose();
                  return;
                }
              }
            }
          } catch {
            // Detector loop frame failure
          }
          requestAnimationFrame(scanLoop);
        };
        requestAnimationFrame(scanLoop);
      }
    } catch (err: unknown) {
      console.warn('Camera access denied or unavailable', err);
      setHasCamera(false);
      setCameraError('تعذر فتح الكاميرا (يرجى السماح بصلاحية الكاميرا أو استخدام الإدخال اليدوي أدناه)');
    }
  };

  const stopCamera = () => {
    isScanningRef.current = false;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setTorchOn(false);
  };

  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (track && 'applyConstraints' in track) {
      try {
        const nextState = !torchOn;
        await (track as any).applyConstraints({
          advanced: [{ torch: nextState }],
        });
        setTorchOn(nextState);
      } catch {
        // Torch not supported on device
      }
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      sound.playBarcodeBeep();
      onScan(manualCode.trim());
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 flex items-center justify-between border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">قارئ الباركود المتطور</h3>
              <p className="text-xs text-slate-400">وجه الكاميرا نحو باركود الصنف</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder Area */}
        <div className="relative bg-black h-64 sm:h-72 flex items-center justify-center overflow-hidden">
          {hasCamera ? (
            <video
              ref={videoRef}
              playsInline
              muted
              className="absolute inset-0 w-full h-full object-cover"
            />
          ) : (
            <div className="p-6 text-center text-slate-400 flex flex-col items-center gap-2">
              <AlertCircle className="w-10 h-10 text-amber-500/80" />
              <p className="text-sm font-medium">{cameraError || 'الكاميرا غير متاحة'}</p>
              <p className="text-xs text-slate-500">يمكنك استخدام البحث بالباركود المباشر أدناه</p>
            </div>
          )}

          {/* Scanner Overlay Frame */}
          <div className="relative w-56 h-36 border-2 border-amber-400/80 rounded-2xl pointer-events-none flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.2)]">
            {/* Animated Laser Line */}
            <div className="absolute left-2 right-2 h-0.5 bg-amber-400 shadow-[0_0_10px_#fbbf24] animate-pulse" />
            <div className="text-[11px] font-bold text-amber-400/90 bg-black/60 px-2 py-0.5 rounded-full absolute bottom-2">
              وجه الباركود داخل الإطار
            </div>
          </div>

          {/* Flashlight toggle */}
          {hasCamera && (
            <button
              onClick={toggleTorch}
              className={`absolute top-4 left-4 p-2.5 rounded-xl backdrop-blur-md transition ${
                torchOn ? 'bg-amber-500 text-slate-900' : 'bg-black/50 text-white'
              }`}
            >
              <Flashlight className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Manual Barcode Input Section */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 space-y-3">
          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="أو اكتب رقم الباركود / الكود يدوياً..."
                className="w-full h-11 pr-10 pl-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-amber-500"
                autoFocus
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
            </div>
            <button
              type="submit"
              className="px-4 h-11 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl flex items-center gap-1.5 active:scale-95 transition text-sm"
            >
              <Check className="w-4 h-4" />
              <span>تأكيد</span>
            </button>
          </form>

          {/* Preset quick test barcodes */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <span className="text-[11px] text-slate-400 shrink-0">باركود تجريبي:</span>
            {['622001', '622002', '622003', '622004'].map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => {
                  sound.playBarcodeBeep();
                  onScan(code);
                  onClose();
                }}
                className="text-xs bg-slate-800 hover:bg-slate-700 text-amber-400 font-mono px-2.5 py-1 rounded-lg border border-slate-700 shrink-0 active:scale-95 transition"
              >
                {code}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
