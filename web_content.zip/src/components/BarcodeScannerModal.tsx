import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  X,
  Flashlight,
  AlertCircle,
  RefreshCw,
  Barcode,
  ImagePlus,
  SwitchCamera,
  CheckCircle2,
} from 'lucide-react';
import {
  BrowserMultiFormatReader,
  BarcodeFormat,
  DecodeHintType,
} from '@zxing/library';
import { parseAndNormalizeBarcode } from '../utils/barcodeUtils.ts';
import type { MedicineItem } from '../types/pharmacy.ts';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string, extra?: { expiryDate?: string; batchNumber?: string }) => void;
  title?: string;
  medicines?: MedicineItem[];
}

// Type declaration for browser-native BarcodeDetector API (Chrome Android / Safari iOS 17+)
interface NativeDetectedBarcode {
  rawValue: string;
  format?: string;
}
interface NativeBarcodeDetector {
  detect(source: ImageBitmapSource): Promise<NativeDetectedBarcode[]>;
}
declare global {
  interface Window {
    BarcodeDetector?: {
      new (options?: { formats: string[] }): NativeBarcodeDetector;
      getSupportedFormats?: () => Promise<string[]>;
    };
  }
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title = 'مسح الباركود بالكاميرا',
  medicines = [],
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const codeReaderRef = useRef<BrowserMultiFormatReader | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nativeTimerRef = useRef<number | null>(null);
  const hasScannedRef = useRef<boolean>(false);

  const [error, setError] = useState<string | null>(null);
  const [photoStatus, setPhotoStatus] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isStreamActive, setIsStreamActive] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [torchOn, setTorchOn] = useState(false);
  const [hasTorch, setHasTorch] = useState(false);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceIndex, setSelectedDeviceIndex] = useState<number>(-1);

  const isFileProtocol =
    typeof window !== 'undefined' && window.location.protocol === 'file:';
  const isAndroidWebView =
    typeof navigator !== 'undefined' &&
    (/wv|Version\/\d+\.\d+.*Chrome\/\d+/.test(navigator.userAgent) || isFileProtocol);

  // Transparent 1x1 GIF prevents Android WebView from showing the huge grey "Play" triangle on <video>
  const TRANSPARENT_POSTER =
    'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

  // Play a pleasant beep sound using Web Audio API on scan success
  const playBeep = () => {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtx();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.18, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.14);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.14);
    } catch {
      // Audio not supported or blocked, ignore silently
    }
  };

  const createConfiguredZxingReader = () => {
    const hints = new Map();
    hints.set(DecodeHintType.TRY_HARDER, true);
    hints.set(DecodeHintType.POSSIBLE_FORMATS, [
      BarcodeFormat.EAN_13,
      BarcodeFormat.EAN_8,
      BarcodeFormat.UPC_A,
      BarcodeFormat.UPC_E,
      BarcodeFormat.CODE_128,
      BarcodeFormat.CODE_39,
      BarcodeFormat.ITF,
      BarcodeFormat.QR_CODE,
      BarcodeFormat.DATA_MATRIX,
    ]);
    return new BrowserMultiFormatReader(hints, 150);
  };

  const triggerScanSuccess = (rawCode: string) => {
    if (hasScannedRef.current) return;
    const parsed = parseAndNormalizeBarcode(rawCode);
    if (!parsed.normalizedBarcode) return;

    hasScannedRef.current = true;
    playBeep();
    stopScanner();
    onScan(parsed.normalizedBarcode, {
      expiryDate: parsed.expiryDate,
      batchNumber: parsed.batchNumber,
    });
    onClose();
  };

  useEffect(() => {
    if (!isOpen) {
      stopScanner();
      return;
    }

    hasScannedRef.current = false;
    setManualCode('');
    setError(null);
    setPhotoStatus(null);
    void startScanner(selectedDeviceIndex);

    return () => {
      stopScanner();
    };
  }, [isOpen]);

  // Multi-stage camera acquisition for maximum compatibility across Android WebViews, iOS, and Chrome
  const acquireCameraStream = async (deviceIdx: number): Promise<MediaStream> => {
    const candidateConstraints: MediaStreamConstraints[] = [];

    if (deviceIdx >= 0 && videoDevices[deviceIdx]?.deviceId) {
      candidateConstraints.push({
        video: {
          deviceId: { exact: videoDevices[deviceIdx].deviceId },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      candidateConstraints.push({
        video: { deviceId: { ideal: videoDevices[deviceIdx].deviceId } },
        audio: false,
      });
    }

    // Stage 1: HD Rear camera
    candidateConstraints.push({
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });

    // Stage 2: Simple rear camera without resolution constraints (fixes strict Android WebViews)
    candidateConstraints.push({
      video: { facingMode: 'environment' },
      audio: false,
    });

    // Stage 3: Basic video: true (fixes WebViews that reject facingMode object)
    candidateConstraints.push({
      video: true,
      audio: false,
    });

    let lastErr: unknown = null;

    if (navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {
      for (const constraints of candidateConstraints) {
        try {
          return await navigator.mediaDevices.getUserMedia(constraints);
        } catch (err) {
          lastErr = err;
        }
      }
    }

    // Stage 4: Legacy WebKit / Android WebView getUserMedia fallback
    const legacyGetUserMedia =
      (navigator as unknown as {
        getUserMedia?: (
          c: MediaStreamConstraints,
          s: (stream: MediaStream) => void,
          e: (err: unknown) => void
        ) => void;
        webkitGetUserMedia?: (
          c: MediaStreamConstraints,
          s: (stream: MediaStream) => void,
          e: (err: unknown) => void
        ) => void;
        mozGetUserMedia?: (
          c: MediaStreamConstraints,
          s: (stream: MediaStream) => void,
          e: (err: unknown) => void
        ) => void;
      }).getUserMedia ||
      (navigator as unknown as {
        webkitGetUserMedia?: (
          c: MediaStreamConstraints,
          s: (stream: MediaStream) => void,
          e: (err: unknown) => void
        ) => void;
      }).webkitGetUserMedia ||
      (navigator as unknown as {
        mozGetUserMedia?: (
          c: MediaStreamConstraints,
          s: (stream: MediaStream) => void,
          e: (err: unknown) => void
        ) => void;
      }).mozGetUserMedia;

    if (legacyGetUserMedia) {
      return await new Promise<MediaStream>((resolve, reject) => {
        legacyGetUserMedia.call(
          navigator,
          { video: true, audio: false },
          (stream) => resolve(stream),
          (err) => reject(err)
        );
      });
    }

    throw lastErr || new Error('Camera API not supported in this WebView');
  };

  const startScanner = async (deviceIdx: number = -1) => {
    stopScanner();
    hasScannedRef.current = false;
    setError(null);
    setPhotoStatus(null);
    setIsScanning(true);
    setIsStreamActive(false);

    try {
      const videoElement = videoRef.current;
      if (!videoElement) return;

      const stream = await acquireCameraStream(deviceIdx);

      streamRef.current = stream;
      videoElement.srcObject = stream;
      videoElement.setAttribute('playsinline', 'true');
      videoElement.setAttribute('webkit-playsinline', 'true');
      await videoElement.play();
      setIsStreamActive(true);

      // Enumerate video devices after permission is granted so labels are available
      if (navigator.mediaDevices?.enumerateDevices) {
        try {
          const allDevs = await navigator.mediaDevices.enumerateDevices();
          const cams = allDevs.filter((d) => d.kind === 'videoinput');
          setVideoDevices(cams);
        } catch {
          // ignore
        }
      }

      const track = stream.getVideoTracks()[0];
      if (track) {
        // Attempt continuous autofocus & macro focus if supported by the phone camera
        try {
          const capabilities = track.getCapabilities
            ? (track.getCapabilities() as {
                torch?: boolean;
                focusMode?: string[];
              })
            : {};

          if (capabilities?.torch) {
            setHasTorch(true);
          } else {
            setHasTorch(false);
          }

          if (capabilities?.focusMode && capabilities.focusMode.includes('continuous')) {
            await track.applyConstraints({
              advanced: [{ focusMode: 'continuous' } as unknown as MediaTrackConstraintSet],
            });
          }
        } catch {
          // Focus mode constraint not supported on this browser, ignore
        }
      }

      // Engine 1: Native Hardware BarcodeDetector Loop (Ultra-fast on Android Chrome & iOS 17+ Safari)
      if (typeof window.BarcodeDetector !== 'undefined') {
        try {
          const detector = new window.BarcodeDetector({
            formats: [
              'ean_13',
              'ean_8',
              'upc_a',
              'upc_e',
              'code_128',
              'code_39',
              'itf',
              'qr_code',
              'data_matrix',
            ],
          });

          const pollNativeDetector = async () => {
            if (hasScannedRef.current || !videoRef.current || !streamRef.current) return;
            try {
              if (videoRef.current.readyState >= 2) {
                const results = await detector.detect(videoRef.current);
                if (results && results.length > 0 && results[0].rawValue) {
                  triggerScanSuccess(results[0].rawValue);
                  return;
                }
              }
            } catch {
              // ignore frame error
            }
            if (!hasScannedRef.current && streamRef.current) {
              nativeTimerRef.current = window.setTimeout(pollNativeDetector, 120);
            }
          };

          nativeTimerRef.current = window.setTimeout(pollNativeDetector, 150);
        } catch {
          // Native detector init failed, ZXing below will handle decoding
        }
      }

      // Engine 2: ZXing Multi-Format Stream Decoder (Uses the SAME stream without re-opening getUserMedia!)
      const reader = createConfiguredZxingReader();
      codeReaderRef.current = reader;

      void reader.decodeFromStream(stream, videoElement, (result) => {
        if (result && !hasScannedRef.current) {
          const text = result.getText();
          if (text) {
            triggerScanSuccess(text);
          }
        }
      });
    } catch (err: unknown) {
      console.warn('Camera scan initialization failed or permission denied:', err);
      setIsStreamActive(false);
      setIsScanning(false);
      setError(
        'تعذر تشغيل البث المباشر للكاميرا داخل هذا الغلاف (WebView). يمكنك الضغط على زر "تصوير الباركود بالكاميرا" أدناه أو تفعيل وضع الكاميرا الآمن.'
      );
    }
  };

  const stopScanner = () => {
    if (nativeTimerRef.current) {
      clearTimeout(nativeTimerRef.current);
      nativeTimerRef.current = null;
    }

    if (codeReaderRef.current) {
      try {
        codeReaderRef.current.reset();
      } catch {
        // ignore
      }
      codeReaderRef.current = null;
    }

    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((t) => t.stop());
      } catch {
        // ignore
      }
      streamRef.current = null;
    }

    if (videoRef.current && videoRef.current.srcObject) {
      try {
        const s = videoRef.current.srcObject as MediaStream;
        s.getTracks().forEach((t) => t.stop());
      } catch {
        // ignore
      }
      videoRef.current.srcObject = null;
    }

    setIsScanning(false);
    setIsStreamActive(false);
    setTorchOn(false);
  };

  const handleSwitchCamera = () => {
    if (videoDevices.length <= 1) {
      void startScanner(-1);
      return;
    }
    const nextIdx = (selectedDeviceIndex + 1) % videoDevices.length;
    setSelectedDeviceIndex(nextIdx);
    void startScanner(nextIdx);
  };

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()?.[0];
    if (!track) return;
    try {
      const newStatus = !torchOn;
      await (track as unknown as { applyConstraints: (c: unknown) => Promise<void> }).applyConstraints({
        advanced: [{ torch: newStatus }],
      });
      setTorchOn(newStatus);
    } catch (err) {
      console.warn('Torch toggle failed:', err);
    }
  };

  // Helper to render an image onto a canvas with optional max dimension, rotation, or center crop
  const createCanvasPass = (
    img: HTMLImageElement,
    maxDim: number,
    rotate90: boolean = false,
    centerCrop: boolean = false
  ): HTMLCanvasElement => {
    const canvas = document.createElement('canvas');
    const srcX = centerCrop ? Math.floor(img.naturalWidth * 0.15) : 0;
    const srcY = centerCrop ? Math.floor(img.naturalHeight * 0.15) : 0;
    const srcW = centerCrop ? Math.floor(img.naturalWidth * 0.7) : img.naturalWidth;
    const srcH = centerCrop ? Math.floor(img.naturalHeight * 0.7) : img.naturalHeight;

    const scale = Math.min(1, maxDim / Math.max(srcW, srcH));
    const targetW = Math.max(1, Math.round(srcW * scale));
    const targetH = Math.max(1, Math.round(srcH * scale));

    if (rotate90) {
      canvas.width = targetH;
      canvas.height = targetW;
    } else {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    const ctx = canvas.getContext('2d');
    if (ctx) {
      if (rotate90) {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(Math.PI / 2);
        ctx.drawImage(img, srcX, srcY, srcW, srcH, -targetW / 2, -targetH / 2, targetW, targetH);
      } else {
        ctx.drawImage(img, srcX, srcY, srcW, srcH, 0, 0, targetW, targetH);
      }
    }
    return canvas;
  };

  // Multi-pass photo barcode decoder (handles 12MP-50MP phone photos, rotated photos, and close-up crops)
  const handlePhotoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setPhotoStatus('جاري تحليل وقراءة الباركود من الصورة بدقة عالية...');

    try {
      const imageUrl = URL.createObjectURL(file);
      const img = new Image();
      img.src = imageUrl;

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('Failed to load image'));
      });

      const cleanup = () => URL.revokeObjectURL(imageUrl);

      // Pass 1: Native BarcodeDetector on raw image and scaled canvas
      if (typeof window.BarcodeDetector !== 'undefined') {
        try {
          const detector = new window.BarcodeDetector({
            formats: [
              'ean_13',
              'ean_8',
              'upc_a',
              'upc_e',
              'code_128',
              'code_39',
              'itf',
              'qr_code',
              'data_matrix',
            ],
          });

          const rawDetected = await detector.detect(img);
          if (rawDetected && rawDetected.length > 0 && rawDetected[0].rawValue) {
            cleanup();
            setPhotoStatus(null);
            triggerScanSuccess(rawDetected[0].rawValue);
            return;
          }

          const scaledCanvas = createCanvasPass(img, 1400, false, false);
          const canvasDetected = await detector.detect(scaledCanvas);
          if (canvasDetected && canvasDetected.length > 0 && canvasDetected[0].rawValue) {
            cleanup();
            setPhotoStatus(null);
            triggerScanSuccess(canvasDetected[0].rawValue);
            return;
          }
        } catch {
          // continue to ZXing multi-pass fallback
        }
      }

      // Pass 2: Multi-scale & multi-orientation ZXing decoding on Canvas
      const passes: Array<{ maxDim: number; rotate: boolean; crop: boolean }> = [
        { maxDim: 1400, rotate: false, crop: false },
        { maxDim: 1000, rotate: false, crop: true },
        { maxDim: 1400, rotate: true, crop: false },
        { maxDim: 800, rotate: false, crop: false },
        { maxDim: 1000, rotate: true, crop: true },
      ];

      for (const pass of passes) {
        try {
          const canvas = createCanvasPass(img, pass.maxDim, pass.rotate, pass.crop);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          const reader = createConfiguredZxingReader();
          const result = await reader.decodeFromImage(undefined, dataUrl);
          if (result && result.getText()) {
            cleanup();
            setPhotoStatus(null);
            triggerScanSuccess(result.getText());
            return;
          }
        } catch {
          // try next pass
        }
      }

      cleanup();
      setPhotoStatus(null);
      setError('لم يتم العثور على باركود واضح في الصورة. يرجى تقريب الكاميرا من الباركود أو كتابة الرقم يدوياً.');
    } catch {
      setPhotoStatus(null);
      setError('لم يتم التعرف على الباركود من الصورة. حاول تصوير الباركود بشكل أوضح أو أدخل الرقم يدوياً.');
    } finally {
      e.target.value = '';
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      triggerScanSuccess(manualCode.trim());
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-md max-h-[94vh] overflow-y-auto rounded-3xl bg-white shadow-2xl ring-1 ring-slate-900/10 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-slate-900 text-white px-4 py-3 shrink-0">
          <div className="flex items-center gap-2 font-black">
            <Camera className="h-5 w-5 text-amber-400" />
            <h3 className="text-sm sm:text-base">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl bg-white/10 p-1.5 text-white hover:bg-white/20 transition"
            aria-label="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Camera Viewfinder */}
        <div className="relative aspect-4/3 w-full bg-slate-950 overflow-hidden flex items-center justify-center shrink-0">
          <video
            ref={videoRef}
            poster={TRANSPARENT_POSTER}
            className={`h-full w-full object-cover transition-opacity duration-200 ${
              isStreamActive ? 'opacity-100' : 'opacity-0'
            }`}
            playsInline
            muted
            autoPlay
          />

          {/* Clean Dark Backdrop when stream is starting or blocked (replaces ugly Android WebView Play icon) */}
          {!isStreamActive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/90 p-5 text-center">
              <div className="h-12 w-12 rounded-2xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center mb-2">
                <Camera className="h-6 w-6 text-amber-400" />
              </div>
              {isScanning ? (
                <p className="text-xs font-bold text-slate-300">
                  جاري تشغيل عدسة الكاميرا...
                </p>
              ) : (
                <div className="space-y-2 max-w-xs z-10">
                  <p className="text-xs font-black text-amber-300">
                    البث المباشر مقيد داخل غلاف الـ APK التقليدي
                  </p>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    برامج تحويل الـ APK المجانية تمنع البث الحي داخل (WebView) حتى بعد إعطاء الإذن. استخدم الزر الأخضر أدناه للتصوير الفوري أو افتح محرك الكاميرا الكامل:
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                    <a
                      href="intent://meshmesh-sync.surge.sh#Intent;scheme=https;package=com.android.chrome;end"
                      className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 px-3 py-2 text-[11px] font-black shadow-md transition"
                    >
                      <Camera className="h-3.5 w-3.5 shrink-0" />
                      <span>تشغيل الكاميرا المباشرة (محرك Chrome)</span>
                    </a>
                    {isFileProtocol && (
                      <a
                        href="https://meshmesh-sync.surge.sh"
                        className="inline-flex items-center justify-center gap-1 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/20 px-2.5 py-2 text-[11px] font-bold transition"
                      >
                        <span>وضع HTTPS الآمن</span>
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Aiming Reticle Overlay */}
          {isStreamActive && (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-6">
              <div className="relative h-40 w-64 max-w-[82%] rounded-2xl border-2 border-amber-400/90 shadow-[0_0_0_9999px_rgba(0,0,0,0.52)]">
                <div className="absolute -top-1 -left-1 h-5 w-5 border-t-4 border-l-4 border-amber-400 rounded-tl-md" />
                <div className="absolute -top-1 -right-1 h-5 w-5 border-t-4 border-r-4 border-amber-400 rounded-tr-md" />
                <div className="absolute -bottom-1 -left-1 h-5 w-5 border-b-4 border-l-4 border-amber-400 rounded-bl-md" />
                <div className="absolute -bottom-1 -right-1 h-5 w-5 border-b-4 border-r-4 border-amber-400 rounded-br-md" />

                {/* Animated Red Laser Scan Line */}
                <div className="absolute inset-x-3 top-1/2 h-0.5 bg-red-500 shadow-[0_0_10px_#ef4444] animate-pulse" />
              </div>
            </div>
          )}

          {/* Top Left Controls: Torch & Camera Switcher */}
          <div className="absolute top-3 left-3 flex items-center gap-2 z-20">
            {hasTorch && (
              <button
                type="button"
                onClick={toggleTorch}
                className={`rounded-xl px-2.5 py-2 text-xs font-bold flex items-center gap-1 transition ${
                  torchOn
                    ? 'bg-amber-400 text-slate-950 shadow-lg'
                    : 'bg-black/65 text-white hover:bg-black/80 border border-white/20'
                }`}
                title="إضاءة الفلاش"
              >
                <Flashlight className="h-4 w-4" />
                <span>فلاش</span>
              </button>
            )}

            {videoDevices.length > 1 && (
              <button
                type="button"
                onClick={handleSwitchCamera}
                className="rounded-xl bg-black/65 hover:bg-black/80 text-white border border-white/20 px-2.5 py-2 text-xs font-bold flex items-center gap-1 transition"
                title="تبديل العدسة أو الكاميرا"
              >
                <SwitchCamera className="h-4 w-4 text-amber-300" />
                <span>تبديل العدسة</span>
              </button>
            )}
          </div>

          {/* Restart Camera Button */}
          <button
            type="button"
            onClick={() => void startScanner(selectedDeviceIndex)}
            className="absolute top-3 right-3 z-20 rounded-xl bg-black/65 border border-white/20 px-2.5 py-2 text-xs font-bold text-white hover:bg-black/80 flex items-center gap-1 transition"
            title="إعادة تشغيل الكاميرا"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isScanning ? '' : 'animate-spin'}`} />
            <span>تحديث</span>
          </button>

          {/* Status / Error Banner */}
          {photoStatus && (
            <div className="absolute inset-x-3 bottom-3 z-20 rounded-xl bg-teal-900/95 p-2.5 text-xs font-bold text-white flex items-center justify-center gap-2 shadow-lg">
              <RefreshCw className="h-4 w-4 animate-spin text-amber-300" />
              <span>{photoStatus}</span>
            </div>
          )}

          {error && !photoStatus && (
            <div className="absolute inset-x-3 bottom-2 z-20 rounded-xl bg-amber-600/95 px-2.5 py-2 text-[11px] font-bold text-white flex items-center gap-2 shadow-lg">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span className="line-clamp-2">{error}</span>
            </div>
          )}
        </div>

        {/* Controls, Native Photo Capture & Manual Entry */}
        <div className="p-4 bg-white space-y-3.5">
          {/* Native Camera Photo Scan Buttons (Works 100% on iPhone WebClip, Android APK & all phones) */}
          <div className="space-y-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoFileChange}
              className="hidden"
            />
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoFileChange}
              className="hidden"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-teal-900 to-emerald-800 hover:from-teal-800 hover:to-emerald-700 text-white py-3 px-3.5 text-xs font-black shadow-sm transition active:scale-[0.99]"
              >
                <Camera className="h-4 w-4 text-amber-300 shrink-0" />
                <span>تصوير الباركود بالكاميرا مباشرة</span>
              </button>
              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 py-3 px-3.5 text-xs font-black transition active:scale-[0.99]"
              >
                <ImagePlus className="h-4 w-4 text-teal-700 shrink-0" />
                <span>قراءة باركود من صورة / الأستوديو</span>
              </button>
            </div>
          </div>

          {/* Manual Barcode Input (No autoFocus so keyboard doesn't cover the camera) */}
          <form onSubmit={handleManualSubmit} className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-600">
              أو اكتب رقم الباركود يدوياً / امسح بجهاز الليزر:
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="أدخل رقم الباركود (مثال: 6291100123456)"
                  dir="ltr"
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 py-2.5 pr-9 pl-3 text-xs sm:text-sm font-mono font-bold text-slate-900 focus:border-teal-600 focus:bg-white focus:outline-hidden"
                />
                <Barcode className="absolute right-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
              </div>
              <button
                type="submit"
                disabled={!manualCode.trim()}
                className="rounded-xl bg-slate-900 px-4 py-2.5 text-xs sm:text-sm font-black text-amber-300 hover:bg-slate-800 disabled:opacity-40 transition shrink-0"
              >
                تأكيد
              </button>
            </div>
          </form>

          {/* Quick Pick from Registered Medicines if available */}
          {medicines.length > 0 && (
            <div className="pt-2 border-t border-slate-100 space-y-1.5">
              <div className="text-[11px] font-bold text-slate-500">
                أو اختر سريعاً من المواد المعرّفة بالنظام:
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {medicines.slice(0, 12).map((m) => (
                  <button
                    key={m.barcode}
                    type="button"
                    onClick={() => triggerScanSuccess(m.barcode)}
                    className="inline-flex items-center gap-1 rounded-lg bg-slate-100 hover:bg-teal-50 hover:text-teal-900 border border-slate-200 px-2.5 py-1 text-[11px] font-bold text-slate-700 transition"
                  >
                    <CheckCircle2 className="h-3 w-3 text-teal-600 shrink-0" />
                    <span className="truncate max-w-[150px]">{m.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
