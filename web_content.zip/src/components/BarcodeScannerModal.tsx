import React, { useState, useEffect, useRef } from 'react';
import { Camera, X, Flashlight, Barcode, Search, ArrowUpRight, ArrowDownLeft, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';
import { feedback } from '../utils/haptics';

interface BarcodeScannerModalProps {
  products: Product[];
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product, action: 'S' | 'P' | 'view') => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  products,
  isOpen,
  onClose,
  onSelectProduct,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [manualCode, setManualCode] = useState('');
  const [torchOn, setTorchOn] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [detectedProduct, setDetectedProduct] = useState<Product | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setDetectedProduct(null);
      setManualCode('');
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera not supported by browser.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
      setCameraError(null);

      // Check for BarcodeDetector API in modern Android Chromium
      if ('BarcodeDetector' in window) {
        const barcodeDetector = new (window as any).BarcodeDetector({
          formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code'],
        });

        const scanLoop = async () => {
          if (!streamRef.current || !videoRef.current) return;
          try {
            if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
              const barcodes = await barcodeDetector.detect(videoRef.current);
              if (barcodes.length > 0) {
                const rawValue = barcodes[0].rawValue;
                handleCodeDetected(rawValue);
                return;
              }
            }
          } catch {
            // ignore frame error
          }
          if (isOpen) {
            requestAnimationFrame(scanLoop);
          }
        };
        requestAnimationFrame(scanLoop);
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('Camera preview unavailable. You can type or pick a barcode below.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
    setTorchOn(false);
  };

  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (track) {
      try {
        const capabilities = (track as any).getCapabilities?.() || {};
        if (capabilities.torch) {
          await (track as any).applyConstraints({
            advanced: [{ torch: !torchOn }],
          });
          setTorchOn(!torchOn);
          feedback.vibrateSoft(hapticsEnabled);
        }
      } catch {
        // torch not supported on this device
      }
    }
  };

  const handleCodeDetected = (code: string) => {
    const found = products.find(
      (p) =>
        (p.sku && p.sku.toLowerCase() === code.trim().toLowerCase()) ||
        p.id.toLowerCase() === code.trim().toLowerCase()
    );

    feedback.vibrateSuccess(hapticsEnabled);
    feedback.playSuccess(soundEnabled);

    if (found) {
      setDetectedProduct(found);
    } else {
      setManualCode(code);
    }
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    const found = products.find(
      (p) =>
        (p.sku && p.sku.toLowerCase() === manualCode.trim().toLowerCase()) ||
        p.name.toLowerCase().includes(manualCode.trim().toLowerCase())
    );

    if (found) {
      feedback.vibrateSuccess(hapticsEnabled);
      feedback.playSuccess(soundEnabled);
      setDetectedProduct(found);
    } else {
      feedback.vibrateWarning(hapticsEnabled);
      alert(`No product found with barcode or name: "${manualCode}"`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col animate-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Barcode className="w-5 h-5 text-red-500" />
            <h3 className="font-semibold text-sm">Android Barcode Scanner</h3>
          </div>
          <div className="flex items-center gap-2">
            {cameraActive && (
              <button
                type="button"
                onClick={toggleTorch}
                className={`p-1.5 rounded-full transition ${torchOn ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'}`}
                title="Toggle Torch / Flashlight"
              >
                <Flashlight className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Viewfinder Area */}
        <div className="relative bg-black h-56 flex items-center justify-center overflow-hidden">
          {cameraActive ? (
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-slate-400 p-4 text-center">
              <Camera className="w-10 h-10 mb-2 opacity-50" />
              <p className="text-xs max-w-xs">{cameraError || 'Initializing camera...'}</p>
            </div>
          )}

          {/* Scanner Reticle Overlay */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div className="w-64 h-36 border-2 border-red-500/80 rounded-xl relative shadow-[0_0_15px_rgba(239,68,68,0.4)]">
              {/* Corner accents */}
              <div className="absolute -top-1 -left-1 w-4 h-4 border-t-3 border-l-3 border-red-500" />
              <div className="absolute -top-1 -right-1 w-4 h-4 border-t-3 border-r-3 border-red-500" />
              <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-3 border-l-3 border-red-500" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-3 border-r-3 border-red-500" />

              {/* Animated Laser Line */}
              <div className="absolute left-1 right-1 h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] animate-scanline" />
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {detectedProduct ? (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
              <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-semibold text-xs mb-2">
                <CheckCircle2 className="w-4 h-4" />
                Product Recognized
              </div>
              <div className="font-bold text-base text-slate-900 dark:text-white">
                {detectedProduct.name}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                SKU: <span className="font-mono font-medium">{detectedProduct.sku || detectedProduct.id}</span> • {detectedProduct.cat}
              </div>

              <div className="grid grid-cols-2 gap-2 mt-4">
                <button
                  type="button"
                  onClick={() => {
                    onSelectProduct(detectedProduct, 'S');
                    onClose();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  Quick Sale
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSelectProduct(detectedProduct, 'P');
                    onClose();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <ArrowDownLeft className="w-3.5 h-3.5" />
                  Quick Restock
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Manual input */}
              <form onSubmit={handleManualSearch} className="flex gap-2">
                <div className="relative flex-1">
                  <Barcode className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={manualCode}
                    onChange={(e) => setManualCode(e.target.value)}
                    placeholder="Enter or paste Barcode / SKU"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl flex items-center gap-1"
                >
                  <Search className="w-3.5 h-3.5" />
                  Find
                </button>
              </form>

              {/* Quick simulation buttons for testing */}
              <div>
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Sample Barcodes (Tap to simulate scan):
                </div>
                <div className="grid grid-cols-1 gap-1.5 max-h-40 overflow-y-auto pr-1">
                  {products.slice(0, 6).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => handleCodeDetected(p.sku || p.id)}
                      className="p-2 rounded-xl text-left bg-slate-50 dark:bg-slate-800/60 hover:bg-red-50 dark:hover:bg-red-950/30 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs transition active:scale-98"
                    >
                      <div className="truncate mr-2">
                        <div className="font-medium text-slate-900 dark:text-slate-100 truncate">{p.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">Barcode: {p.sku || p.id}</div>
                      </div>
                      <span className="text-[10px] text-red-600 dark:text-red-400 font-semibold shrink-0">
                        Scan &rarr;
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
