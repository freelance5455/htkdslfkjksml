import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, Flashlight, AlertCircle, RefreshCw, Barcode } from 'lucide-react';
import { BrowserMultiFormatReader } from '@zxing/library';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
  title?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title = 'مسح الباركود بالكاميرا',
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const codeReaderRef = useRef<BrowserMultiFormatReader | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [torchOn, setTorchOn] = useState(false);
  const [hasTorch, setHasTorch] = useState(false);
  const [videoTrack, setVideoTrack] = useState<MediaStreamTrack | null>(null);

  // Play a pleasant beep sound using Web Audio API on scan success
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // 880Hz A5
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    } catch {
      // Audio not supported or blocked, ignore silently
    }
  };

  useEffect(() => {
    if (!isOpen) {
      stopScanner();
      return;
    }

    startScanner();

    return () => {
      stopScanner();
    };
  }, [isOpen]);

  const startScanner = async () => {
    setError(null);
    setIsScanning(true);

    try {
      const reader = new BrowserMultiFormatReader();
      codeReaderRef.current = reader;

      const videoElement = videoRef.current;
      if (!videoElement) return;

      // Ask for environment-facing camera (rear camera for barcodes)
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      videoElement.srcObject = stream;
      await videoElement.play();

      const track = stream.getVideoTracks()[0];
      setVideoTrack(track);

      // Check if torch/flashlight is supported
      const capabilities = track.getCapabilities ? (track.getCapabilities() as { torch?: boolean }) : {};
      if (capabilities && capabilities.torch) {
        setHasTorch(true);
      }

      // Start decoding loop
      reader.decodeFromVideoDevice(null, videoElement, (result) => {
        if (result) {
          const text = result.getText();
          if (text) {
            playBeep();
            stopScanner();
            onScan(text);
            onClose();
          }
        }
      });
    } catch (err: unknown) {
      console.warn('Camera scan initialization failed or permission denied:', err);
      setError('تعذر فتح الكاميرا أو لم يتم منح الإذن. يمكنك إدخال الباركود يدوياً أدناه.');
      setIsScanning(false);
    }
  };

  const stopScanner = () => {
    if (codeReaderRef.current) {
      try {
        codeReaderRef.current.reset();
      } catch {
        // ignore
      }
      codeReaderRef.current = null;
    }

    if (videoTrack) {
      try {
        videoTrack.stop();
      } catch {
        // ignore
      }
      setVideoTrack(null);
    }

    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
    setTorchOn(false);
  };

  const toggleTorch = async () => {
    if (!videoTrack) return;
    try {
      const newStatus = !torchOn;
      await (videoTrack as unknown as { applyConstraints: (c: unknown) => Promise<void> }).applyConstraints({
        advanced: [{ torch: newStatus }],
      });
      setTorchOn(newStatus);
    } catch (err) {
      console.warn('Torch toggle failed:', err);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      playBeep();
      onScan(manualCode.trim());
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl ring-1 ring-slate-900/10">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-3">
          <div className="flex items-center gap-2 text-teal-800 font-bold">
            <Camera className="h-5 w-5 text-teal-600" />
            <h3 className="text-base">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-500 hover:bg-slate-200 transition"
            aria-label="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Camera Viewfinder */}
        <div className="relative aspect-4/3 w-full bg-slate-950 overflow-hidden flex items-center justify-center">
          <video
            ref={videoRef}
            className="h-full w-full object-cover"
            playsInline
            muted
            autoPlay
          />

          {/* Aiming Reticle Overlay */}
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-8">
            <div className="relative h-44 w-64 rounded-xl border-2 border-teal-400/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]">
              {/* Corner markers */}
              <div className="absolute -top-1 -left-1 h-4 w-4 border-t-4 border-l-4 border-teal-400 rounded-tl-sm" />
              <div className="absolute -top-1 -right-1 h-4 w-4 border-t-4 border-r-4 border-teal-400 rounded-tr-sm" />
              <div className="absolute -bottom-1 -left-1 h-4 w-4 border-b-4 border-l-4 border-teal-400 rounded-bl-sm" />
              <div className="absolute -bottom-1 -right-1 h-4 w-4 border-b-4 border-r-4 border-teal-400 rounded-br-sm" />

              {/* Animated Red Laser Scan Line */}
              <div className="absolute inset-x-2 top-1/2 h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] animate-pulse" />
            </div>
          </div>

          {/* Torch Button if available */}
          {hasTorch && (
            <button
              onClick={toggleTorch}
              className={`absolute top-3 left-3 rounded-full p-2.5 transition ${
                torchOn ? 'bg-amber-400 text-slate-900 shadow-lg' : 'bg-black/60 text-white hover:bg-black/80'
              }`}
              title="إضاءة الفلاش"
            >
              <Flashlight className="h-5 w-5" />
            </button>
          )}

          {/* Restart Camera Button */}
          <button
            onClick={() => {
              stopScanner();
              startScanner();
            }}
            className="absolute top-3 right-3 rounded-full bg-black/60 p-2 text-white hover:bg-black/80 transition"
            title="إعادة تشغيل الكاميرا"
          >
            <RefreshCw className="h-4 w-4" />
          </button>

          {/* Error Banner */}
          {error && (
            <div className="absolute inset-x-4 bottom-4 rounded-xl bg-amber-500/90 p-3 text-xs text-white backdrop-blur-xs flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Guidance and Manual Barcode Fallback */}
        <div className="p-4 bg-white space-y-3">
          <p className="text-center text-xs text-slate-500">
            وجه الكاميرا نحو باركود علبة الدواء، أو أدخل الرقم يدوياً / عبر قارئ USB
          </p>

          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="أدخل رقم الباركود (مثال: 6291100123456)"
                dir="ltr"
                className="w-full rounded-xl border border-slate-300 bg-slate-50 py-2.5 pr-10 pl-3 text-sm font-mono text-slate-900 focus:border-teal-500 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-teal-500"
                autoFocus
              />
              <Barcode className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
            <button
              type="submit"
              disabled={!manualCode.trim()}
              className="rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-700 disabled:opacity-40 transition shadow-xs"
            >
              تأكيد
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
