import React, { useState } from 'react';
import { X, Tablet, QrCode, Copy, Check, ExternalLink, Wifi } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const QRCodeModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const currentUrl = typeof window !== 'undefined' ? window.location.origin : '';

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate QR Code via reliable SVG service
  const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(currentUrl)}&margin=10`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-neutral-900 border border-neutral-800 p-6 text-white shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white transition"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Tablet className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Conectar os Dois Tablets</h3>
            <p className="text-xs text-neutral-400">Escaneie com a câmera do outro tablet ou celular</p>
          </div>
        </div>

        <div className="my-5 flex flex-col items-center justify-center rounded-2xl bg-white p-6 shadow-inner text-neutral-900">
          <img
            src={qrApiUrl}
            alt="QR Code para conectar o tablet"
            className="h-52 w-52 rounded-lg"
          />
          <p className="mt-3 text-xs font-semibold text-neutral-600 text-center">
            Aponte a câmera do tablet da porta ou do púlpito para abrir
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-xl bg-neutral-800/80 p-3 border border-neutral-700/60">
            <div className="truncate text-xs font-mono text-neutral-300 pr-2">
              {currentUrl}
            </div>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-neutral-950 hover:bg-amber-400 transition shrink-0"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" /> Copiado!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" /> Copiar Link
                </>
              )}
            </button>
          </div>

          <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-3.5 text-xs text-amber-200/90 leading-relaxed space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-amber-300">
              <Wifi className="h-4 w-4" /> Dica de Conexão na Igreja:
            </div>
            <p>
              1. Conecte ambos os tablets no <strong>Wi-Fi da igreja</strong> ou dados móveis (4G/5G).
            </p>
            <p>
              2. No tablet da porta, escolha <strong>&quot;Tablet da Recepção&quot;</strong>.
            </p>
            <p>
              3. No tablet do pastor, escolha <strong>&quot;Tablet do Altar&quot;</strong>. Tudo o que for digitado na porta aparecerá na mesma hora no altar!
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="w-full rounded-xl bg-neutral-800 py-3 font-semibold text-neutral-200 hover:bg-neutral-700 transition"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
