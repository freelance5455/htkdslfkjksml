import React, { useState, useEffect, useRef } from 'react';
import { RefreshCw, ArrowDown } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PullToRefresh: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { triggerHardRefresh, isRefreshing } = useApp();
  const [pullDistance, setPullDistance] = useState(0);
  const [isPulling, setIsPulling] = useState(false);
  const startY = useRef(0);
  const threshold = 85;

  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      if (window.scrollY <= 0) {
        startY.current = e.touches[0].clientY;
        setIsPulling(true);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isPulling || isRefreshing) return;
      if (window.scrollY <= 0) {
        const currentY = e.touches[0].clientY;
        const diff = currentY - startY.current;
        if (diff > 0) {
          // Friction calculation
          const friction = Math.min(diff * 0.45, 120);
          setPullDistance(friction);
        }
      } else {
        setPullDistance(0);
      }
    };

    const handleTouchEnd = async () => {
      if (pullDistance >= threshold && !isRefreshing) {
        setPullDistance(threshold);
        await triggerHardRefresh();
      }
      setPullDistance(0);
      setIsPulling(false);
    };

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isPulling, pullDistance, isRefreshing, triggerHardRefresh]);

  return (
    <div className="relative w-full">
      {/* Pull down indicator pill */}
      {(pullDistance > 10 || isRefreshing) && (
        <div
          className="fixed top-18 left-0 right-0 z-50 flex justify-center pointer-events-none transition-transform duration-100"
          style={{ transform: `translateY(${Math.min(pullDistance, 90) * 0.8}px)` }}
        >
          <div className="px-4 py-2 rounded-full bg-[#13151d] border border-[#232733] shadow-xl text-xs font-semibold text-[#f4f4f6] flex items-center gap-2">
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isRefreshing || pullDistance >= threshold ? 'animate-spin' : ''}`} />
            <span>
              {isRefreshing
                ? 'Syncing Eventra data...'
                : pullDistance >= threshold
                ? 'Release to refresh'
                : 'Pull down to refresh'}
            </span>
          </div>
        </div>
      )}
      {children}
    </div>
  );
};
