import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RefreshCw, Sparkles, ChevronDown } from 'lucide-react';

interface PullToRefreshProps {
  children: React.ReactNode;
}

// Configuration for deliberate, long-gesture pull down
const PULL_THRESHOLD = 200;      // Visual pull distance threshold (px)
const MIN_PHYSICAL_DRAG = 320;   // Must drag finger at least 320px down ("all the way down")
const RESISTANCE = 0.6;          // Visual damping factor
const MAX_PULL = 240;            // Maximum visual pull clamp (px)
const MIN_SWIPE_DURATION = 260;  // Must be dragging continuously for at least 260ms (not a tap or rapid flick)
const MIN_MOVE_EVENTS = 6;       // Must produce at least 6 touchmove events along the drag path
const MAX_START_Y = 160;         // Swipe MUST originate from top edge/header (top 160px of screen)
const RAPID_TAP_WINDOW = 350;    // If consecutive touches arrive within 350ms, treated as alternate-finger tapping

export function PullToRefresh({ children }: PullToRefreshProps) {
  const [pullDistance, setPullDistance] = useState(0);
  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Gesture tracking refs
  const activeTouchIdRef = useRef<number | null>(null);
  const startYRef = useRef(0);
  const startXRef = useRef(0);
  const startTimeRef = useRef(0);
  const rawDeltaYRef = useRef(0);
  const moveCountRef = useRef(0);
  const isCandidateRef = useRef(false);
  const isPullingRef = useRef(false);
  const isRefreshingRef = useRef(false);
  const pullDistanceRef = useRef(0);

  // Anti-rapid-tap / multi-finger protection refs
  const lastTouchTimeRef = useRef(0);
  const lockoutUntilRef = useRef(0);

  // Keep refs immediately up to date
  isPullingRef.current = isPulling;
  isRefreshingRef.current = isRefreshing;
  pullDistanceRef.current = pullDistance;

  const cancelPull = useCallback(() => {
    isCandidateRef.current = false;
    isPullingRef.current = false;
    activeTouchIdRef.current = null;
    rawDeltaYRef.current = 0;
    moveCountRef.current = 0;
    pullDistanceRef.current = 0;
    setIsPulling(false);
    setPullDistance(0);
  }, []);

  const triggerRefresh = useCallback(() => {
    if (isRefreshingRef.current) return;
    setIsRefreshing(true);
    isRefreshingRef.current = true;
    setPullDistance(76);
    pullDistanceRef.current = 76;

    // Subtle haptic confirmation if supported
    try {
      if (typeof window !== 'undefined' && 'navigator' in window && window.navigator.vibrate) {
        window.navigator.vibrate([35, 45, 35]);
      }
    } catch {
      // Ignore vibration errors
    }

    // Force save game to localStorage before reloading
    try {
      window.dispatchEvent(new Event('beforeunload'));
    } catch {
      // Ignore save dispatch errors
    }

    // Allow user to see smooth confirmation animation, then reload
    setTimeout(() => {
      window.location.reload();
    }, 600);
  }, []);

  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      const now = Date.now();

      if (isRefreshingRef.current) return;

      // 1. MULTI-TOUCH DETECTED: 2+ simultaneous fingers instantly aborts and locks out
      if (e.touches.length > 1) {
        lockoutUntilRef.current = now + 600;
        cancelPull();
        return;
      }

      // 2. RAPID ALTERNATE TAP PROTECTION:
      // If the user is tapping rapidly (e.g. index/middle finger alternating spam),
      // touch intervals are tiny (< 350ms). Lock out pull to refresh during tap storm.
      const intervalSinceLastTouch = now - lastTouchTimeRef.current;
      lastTouchTimeRef.current = now;

      if (now < lockoutUntilRef.current || intervalSinceLastTouch < RAPID_TAP_WINDOW) {
        // Tapping fast with alternate fingers! Not a deliberate swipe down.
        // Lock out pull-to-refresh for an extra 450ms after the rapid taps stop.
        lockoutUntilRef.current = now + 450;
        cancelPull();
        return;
      }

      // 3. SCROLL CONTAINER POSITION:
      // Must be at the very top (scrollTop <= 0 and window.scrollY <= 0)
      const rootEl = document.getElementById('root');
      const scrollTop = rootEl ? rootEl.scrollTop : 0;
      const winScrollY = window.scrollY || window.pageYOffset || 0;
      if (scrollTop > 2 || winScrollY > 2) {
        cancelPull();
        return;
      }

      const touch = e.touches[0];

      // 4. ORIGIN ZONE REQUIREMENT:
      // A pull-to-refresh swipe down must start near the top of the viewport (top 160px: header/banner)
      // Tapping the Arcane Orb or middle/bottom of screen will NEVER initiate pull-to-refresh
      if (touch.clientY > MAX_START_Y) {
        cancelPull();
        return;
      }

      // 5. INTERACTIVE & ORB PROTECTION:
      const target = e.target as HTMLElement | null;
      if (
        target?.closest('[data-no-pull="true"]') ||
        target?.closest('[data-arcane-orb="true"]') ||
        target?.closest('.arcane-orb-container')
      ) {
        cancelPull();
        return;
      }

      // Record this specific touch identifier
      activeTouchIdRef.current = touch.identifier;
      startYRef.current = touch.clientY;
      startXRef.current = touch.clientX;
      startTimeRef.current = now;
      rawDeltaYRef.current = 0;
      moveCountRef.current = 0;
      isCandidateRef.current = true;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isRefreshingRef.current) return;

      // Multi-touch rule: Any second finger aborts immediately
      if (e.touches.length > 1) {
        lockoutUntilRef.current = Date.now() + 600;
        cancelPull();
        return;
      }

      if (!isCandidateRef.current || activeTouchIdRef.current === null) {
        return;
      }

      // Locate the exact touch that initiated the candidate gesture
      let matchingTouch: Touch | null = null;
      for (let i = 0; i < e.touches.length; i++) {
        if (e.touches[i].identifier === activeTouchIdRef.current) {
          matchingTouch = e.touches[i];
          break;
        }
      }

      // If the tracked finger was lost, immediately cancel (never adopt a second finger's position!)
      if (!matchingTouch) {
        cancelPull();
        return;
      }

      const currentY = matchingTouch.clientY;
      const currentX = matchingTouch.clientX;
      const deltaY = currentY - startYRef.current;
      const deltaX = currentX - startXRef.current;

      // Abort if moving upwards or predominantly horizontally
      if (deltaY <= 0 || (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 12)) {
        cancelPull();
        return;
      }

      // Ensure container is still at top
      const rootEl = document.getElementById('root');
      const scrollTop = rootEl ? rootEl.scrollTop : 0;
      if (scrollTop > 2) {
        cancelPull();
        return;
      }

      moveCountRef.current++;
      rawDeltaYRef.current = deltaY;

      // Apply resistance damping for visual pull
      const dampedDistance = Math.min(MAX_PULL, deltaY * RESISTANCE);

      if (dampedDistance > 6) {
        isPullingRef.current = true;
        pullDistanceRef.current = dampedDistance;
        setIsPulling(true);
        setPullDistance(dampedDistance);

        if (e.cancelable) {
          e.preventDefault();
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const now = Date.now();
      lastTouchTimeRef.current = now;

      if (isRefreshingRef.current) return;

      if (!isCandidateRef.current && !isPullingRef.current) {
        return;
      }

      const wasPulling = isPullingRef.current;
      const rawDistance = rawDeltaYRef.current;
      const currentPull = pullDistanceRef.current;
      const moves = moveCountRef.current;
      const duration = now - startTimeRef.current;

      // Reset candidate tracking flags synchronously
      isCandidateRef.current = false;
      activeTouchIdRef.current = null;

      // REQUIRE A DELIBERATE LONG GESTURE ALL THE WAY DOWN:
      // 1. Must have reached both visual pull threshold (200px) and physical drag threshold (320px)
      // 2. Must have moved for at least MIN_SWIPE_DURATION (260ms) - taps are <150ms
      // 3. Must have had at least MIN_MOVE_EVENTS (6) touchmove events
      const isValidLongGesture =
        wasPulling &&
        currentPull >= PULL_THRESHOLD &&
        rawDistance >= MIN_PHYSICAL_DRAG &&
        duration >= MIN_SWIPE_DURATION &&
        moves >= MIN_MOVE_EVENTS;

      if (isValidLongGesture) {
        triggerRefresh();
      } else {
        // Short gesture, rapid tap, or partial drag - smoothly snap back with NO refresh
        cancelPull();
      }
    };

    const handleTouchCancel = () => {
      if (!isRefreshingRef.current) {
        cancelPull();
      }
    };

    // Attach to window so drag tracking is smooth across all sections
    window.addEventListener('touchstart', handleTouchStart, { passive: true, capture: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: false, capture: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true, capture: true });
    window.addEventListener('touchcancel', handleTouchCancel, { passive: true, capture: true });

    return () => {
      window.removeEventListener('touchstart', handleTouchStart, { capture: true });
      window.removeEventListener('touchmove', handleTouchMove, { capture: true });
      window.removeEventListener('touchend', handleTouchEnd, { capture: true });
      window.removeEventListener('touchcancel', handleTouchCancel, { capture: true });
    };
  }, [cancelPull, triggerRefresh]);

  const progress = Math.min(1, pullDistance / PULL_THRESHOLD);
  const isReady = pullDistance >= PULL_THRESHOLD;
  const circumference = 2 * Math.PI * 18; // Radius 18
  const strokeDashoffset = circumference * (1 - progress);

  return (
    <div className="relative w-full min-h-screen overflow-x-hidden bg-slate-950">
      {/* Visual Pull Indicator Banner - Revealed when pulling down */}
      <div
        className="overflow-hidden bg-slate-950 border-b border-amber-900/30 select-none flex flex-col items-center justify-center transition-[height] duration-75"
        style={{
          height: isRefreshing ? '76px' : `${pullDistance}px`,
          opacity: pullDistance > 10 || isRefreshing ? 1 : 0,
          backgroundColor: '#020617',
        }}
        aria-hidden="true"
      >
        <div className="flex items-center justify-center gap-3 px-4 py-2 w-full max-w-md mx-auto">
          {/* Arcane Circular Runic Gauge */}
          <div className="relative w-11 h-11 flex items-center justify-center shrink-0">
            <svg className="w-11 h-11 -rotate-90 transform" viewBox="0 0 44 44">
              <circle
                cx="22"
                cy="22"
                r="18"
                className="stroke-slate-800"
                strokeWidth="3.5"
                fill="transparent"
              />
              <circle
                cx="22"
                cy="22"
                r="18"
                className={`transition-all duration-75 ${
                  isReady || isRefreshing
                    ? 'stroke-amber-400 [filter:drop-shadow(0_0_6px_rgba(245,158,11,0.8))]'
                    : 'stroke-cyan-500'
                }`}
                strokeWidth="3.5"
                strokeDasharray={circumference}
                strokeDashoffset={isRefreshing ? 0 : strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            {/* Centered Glyphic Icon */}
            <div
              className={`absolute inset-0 flex items-center justify-center transition-transform ${
                isRefreshing ? 'animate-spin' : ''
              }`}
              style={{
                transform: isRefreshing ? undefined : `rotate(${progress * 360}deg)`,
              }}
            >
              {isRefreshing ? (
                <RefreshCw className="w-5 h-5 text-amber-300" />
              ) : isReady ? (
                <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
              ) : (
                <RefreshCw className="w-4 h-4 text-cyan-400" />
              )}
            </div>
          </div>

          {/* Text Status & Percentage Guidance */}
          <div className="flex flex-col text-left">
            <span
              className={`font-cinzel text-xs sm:text-sm font-semibold tracking-wide transition-colors ${
                isReady || isRefreshing ? 'text-amber-300 font-bold' : 'text-slate-300'
              }`}
            >
              {isRefreshing
                ? 'Restoring Arcane Realm...'
                : isReady
                ? '✨ Release to Refresh Realm!'
                : 'Pull All The Way Down'}
            </span>

            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              {isRefreshing ? (
                <span className="text-amber-400/90 italic">Preserving mana archives...</span>
              ) : isReady ? (
                <span className="text-emerald-400 font-medium">Ready · Full gesture reached</span>
              ) : (
                <>
                  <ChevronDown className="w-3 h-3 text-cyan-400 animate-bounce" />
                  <span>
                    {Math.round(progress * 100)}% · Long pull required ({Math.round(pullDistance)}/{PULL_THRESHOLD}px)
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Delicate Golden Progress Line at Base */}
        <div className="w-full h-[2px] bg-slate-900 overflow-hidden">
          <div
            className={`h-full transition-all duration-75 ${
              isReady || isRefreshing
                ? 'bg-gradient-to-r from-amber-400 via-amber-200 to-cyan-400 shadow-[0_0_8px_rgba(245,158,11,0.8)]'
                : 'bg-gradient-to-r from-cyan-600 to-amber-500'
            }`}
            style={{ width: isRefreshing ? '100%' : `${progress * 100}%` }}
          />
        </div>
      </div>

      {/* Main App Container - Smooth translation physics */}
      <div
        className="w-full flex-1 flex flex-col will-change-transform"
        style={{
          transform: isRefreshing
            ? 'translateY(0px)'
            : pullDistance > 0
            ? `translateY(${pullDistance}px)`
            : 'translateY(0px)',
          transition: isPulling ? 'none' : 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {children}
      </div>
    </div>
  );
}
