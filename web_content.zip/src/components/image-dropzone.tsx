import { useRef } from "react";
import { ImagePlus, Trash2, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const MAX_FILES = 6;

type Props = {
  files: File[];
  previews: string[];
  onAdd: (files: File[]) => void;
  onRemove: (index: number) => void;
  onClear: () => void;
};

export function ImageDropzone({ files, previews, onAdd, onRemove, onClear }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const atCap = files.length >= MAX_FILES;

  function pick() {
    if (atCap) return;
    inputRef.current?.click();
  }

  function handleFiles(list: FileList | File[]) {
    const incoming = Array.from(list).filter((f) => f.type.startsWith("image/"));
    if (incoming.length === 0) return;
    const room = MAX_FILES - files.length;
    onAdd(incoming.slice(0, room));
  }

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted">
          Squad & Players စခရင်ရှော့
        </span>
        <span className="rounded-full bg-accent/10 px-2.5 py-0.5 font-display text-xs font-semibold tabular-nums text-accent">
          {files.length}/{MAX_FILES}
        </span>
      </div>

      <div
        className={cn(
          "rounded-[var(--radius-lg)] bg-bg p-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150",
          "focus-within:ring-2 focus-within:ring-ring",
        )}
        onDragOver={(e) => {
          e.preventDefault();
        }}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
        }}
      >
        {files.length === 0 ? (
          <button
            type="button"
            onClick={pick}
            className="flex w-full flex-col items-center justify-center rounded-[var(--radius-md)] px-3 py-6 text-center"
          >
            <span className="mb-2 flex size-11 items-center justify-center rounded-full bg-surface-2 text-accent">
              <Upload className="size-5" aria-hidden />
            </span>
            <span className="text-sm font-bold text-fg">စခရင်ရှော့ပုံများ တင်ရန်နှိပ်ပါ</span>
            <span className="mt-1 text-xs text-muted">
              Main Squad, Subs, Reserve & Epic ကတ်များ · အများဆုံး ၆ ပုံ
            </span>
          </button>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2">
              {previews.map((src, idx) => (
                <div
                  key={`${files[idx]?.name}-${idx}`}
                  className="relative aspect-video overflow-hidden rounded-[var(--radius-sm)] bg-surface-2"
                >
                  <img
                    src={src}
                    alt={`screenshot ${idx + 1}`}
                    className="size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                  />
                  <button
                    type="button"
                    onClick={() => onRemove(idx)}
                    className="absolute top-1 right-1 flex size-8 items-center justify-center rounded-full bg-danger text-fg"
                    aria-label="ပုံဖျက်ရန်"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between border-t border-border pt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={pick}
                disabled={atCap}
                className="text-accent hover:text-accent"
              >
                <ImagePlus className="size-3.5" />
                ပုံထပ်ထည့်မည်
              </Button>
              <Button variant="ghost" size="sm" onClick={onClear} className="text-danger hover:text-danger">
                <Trash2 className="size-3.5" />
                အားလုံးဖျက်မည်
              </Button>
            </div>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) handleFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>
    </div>
  );
}
