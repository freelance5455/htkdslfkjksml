import React, { useState } from 'react';
import { 
  X, 
  Send, 
  MessageSquare, 
  ShieldCheck, 
  Search, 
  CheckCheck 
} from 'lucide-react';
import { Message, User } from '../types';

interface MessagingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  allUsers: User[];
  messages: Message[];
  onSendMessage: (receiverId: string, content: string) => void;
}

export const MessagingDrawer: React.FC<MessagingDrawerProps> = ({
  isOpen,
  onClose,
  currentUser,
  allUsers,
  messages,
  onSendMessage
}) => {
  if (!isOpen) return null;

  const otherUsers = allUsers.filter((u) => u.id !== currentUser.id);
  const [selectedUserId, setSelectedUserId] = useState<string>(otherUsers[0]?.id || 'usr_1');
  const [inputText, setInputText] = useState('');

  const selectedUser = allUsers.find((u) => u.id === selectedUserId) || otherUsers[0];

  const conversationMessages = messages.filter(
    (m) =>
      (m.senderId === currentUser.id && m.receiverId === selectedUserId) ||
      (m.senderId === selectedUserId && m.receiverId === currentUser.id)
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(selectedUserId, inputText);
    setInputText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm">
      <div className="bg-slate-900 border-l border-slate-800 w-full max-w-2xl h-full flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-extrabold text-white">Private Study Messaging</h3>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-xl cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messaging Body Grid (Users list + Chat thread) */}
        <div className="grid grid-cols-1 md:grid-cols-3 flex-1 overflow-hidden">
          
          {/* Users List Sidebar */}
          <div className="border-r border-slate-800 p-3 bg-slate-950/60 overflow-y-auto space-y-2">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2">Contacts</p>
            {otherUsers.map((u) => {
              const isSelected = u.id === selectedUserId;
              return (
                <button
                  key={u.id}
                  onClick={() => setSelectedUserId(u.id)}
                  className={`w-full p-2.5 rounded-2xl flex items-center gap-2.5 transition-all cursor-pointer ${
                    isSelected ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="relative">
                    <img src={u.avatar} alt={u.name} className="w-8 h-8 rounded-full object-cover" />
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-slate-900"></span>
                  </div>
                  <div className="text-left line-clamp-1">
                    <p className="text-xs font-bold leading-none">{u.name}</p>
                    <p className={`text-[10px] ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>{u.role}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Chat Thread */}
          <div className="md:col-span-2 flex flex-col justify-between bg-slate-900 p-4 overflow-hidden">
            
            {/* Contact Header */}
            {selectedUser && (
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <img src={selectedUser.avatar} alt={selectedUser.name} className="w-9 h-9 rounded-full object-cover ring-2 ring-amber-500/40" />
                <div>
                  <p className="text-xs font-bold text-white flex items-center gap-1">
                    <span>{selectedUser.name}</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  </p>
                  <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                    <span>Online • {selectedUser.school}</span>
                  </p>
                </div>
              </div>
            )}

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {conversationMessages.map((msg) => {
                const isMe = msg.senderId === currentUser.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-xs p-3 rounded-2xl text-xs space-y-1 shadow-md ${
                        isMe
                          ? 'bg-amber-500 text-slate-950 font-medium rounded-br-none'
                          : 'bg-slate-800 text-slate-200 border border-slate-700/80 rounded-bl-none'
                      }`}
                    >
                      <p>{msg.content}</p>
                      <p className={`text-[9px] text-right ${isMe ? 'text-slate-900' : 'text-slate-400'}`}>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Message Input Box */}
            <form onSubmit={handleSend} className="flex gap-2 pt-2 border-t border-slate-800">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={`Message ${selectedUser?.name || 'user'}...`}
                className="flex-1 bg-slate-950 text-xs text-white p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-4 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

          </div>

        </div>

      </div>
    </div>
  );
};
