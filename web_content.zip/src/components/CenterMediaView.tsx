import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import {
  Video,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Upload,
  Camera,
  Sparkles,
  Maximize2,
  CheckCircle,
  Image as ImageIcon
} from 'lucide-react';

interface CenterMediaViewProps {
  lang: Language;
  centerVideoUrl: string;
  onUpdateVideoUrl: (url: string) => void;
  centerLogoUrl: string;
  onUpdateLogoUrl: (url: string) => void;
}

export const CenterMediaView: React.FC<CenterMediaViewProps> = ({
  lang,
  centerVideoUrl,
  onUpdateVideoUrl,
  centerLogoUrl,
  onUpdateLogoUrl,
}) => {
  const t = translations[lang];

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [videoInput, setVideoInput] = useState(centerVideoUrl);
  const [logoInput, setLogoInput] = useState(centerLogoUrl);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showLogoModal, setShowLogoModal] = useState(false);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          onUpdateLogoUrl(reader.result);
          setShowLogoModal(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveVideo = () => {
    if (videoInput.trim()) {
      onUpdateVideoUrl(videoInput.trim());
      setShowVideoModal(false);
    }
  };

  const sampleCampusImages = [
    {
      title: 'Main Speech & Debate Auditorium',
      location: 'Rahbar Center, Trat Campus',
      img: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=600&q=80'
    },
    {
      title: 'Modern English Language & Audio Lab',
      location: 'Balochistan Wing',
      img: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=600&q=80'
    },
    {
      title: 'Girls Wing Dedicated Study Hall',
      location: 'Fatima Jinnah Block',
      img: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=600&q=80'
    },
    {
      title: 'Elementary Phonetics & Grammar Room',
      location: 'Room 01 - Trat',
      img: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=600&q=80'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Interactive Campus Media & Center Branding</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t.centerVideoTitle}
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {t.centerVideoSubtitle}
          </p>
        </div>

        {/* Branding Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowLogoModal(true)}
            className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 font-bold px-4 py-2 rounded-2xl text-xs transition"
          >
            <Camera className="w-4 h-4 text-amber-400" />
            <span>Change Center Logo</span>
          </button>

          <button
            onClick={() => setShowVideoModal(true)}
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-2xl text-xs transition shadow-md"
          >
            <Video className="w-4 h-4" />
            <span>{t.changeVideoUrl}</span>
          </button>
        </div>
      </div>

      {/* Animated Center Video Showcase */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-950 border-4 border-emerald-600/60 shadow-2xl group">
        {/* Animated Glow Border Effect */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-transparent to-amber-500/10 pointer-events-none" />

        <div className="relative aspect-video w-full max-h-[540px] flex items-center justify-center bg-slate-950">
          {centerVideoUrl.includes('youtube.com') || centerVideoUrl.includes('youtu.be') ? (
            <iframe
              src={centerVideoUrl.replace('watch?v=', 'embed/')}
              title="Rahbar English Center Video"
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video
              src={centerVideoUrl}
              autoPlay={false}
              controls
              muted={isMuted}
              className="w-full h-full object-cover"
              poster="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80"
            />
          )}
        </div>

        {/* Video Overlay Title & Location */}
        <div className="p-4 sm:p-6 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src={centerLogoUrl}
              alt="Logo"
              className="w-12 h-12 rounded-xl object-cover ring-2 ring-emerald-500"
            />
            <div>
              <h3 className="text-base font-black text-white">
                {t.centerName} - Campus Tour & Speaking Drills
              </h3>
              <p className="text-xs text-emerald-400 font-semibold">
                Trat, Pishin, Balochistan • Established for Quality English Education
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowVideoModal(true)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-slate-800 text-slate-200 hover:text-white border border-slate-700 transition"
            >
              Upload / Replace Video
            </button>
          </div>
        </div>
      </div>

      {/* Campus Gallery */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-emerald-600" />
            <span>Rahbar English Center Campus & Activities</span>
          </h3>
          <span className="text-xs text-slate-500 font-medium">Trat, Pishin</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {sampleCampusImages.map((item, idx) => (
            <div
              key={idx}
              className="rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-sm hover:shadow-md transition group"
            >
              <div className="h-44 overflow-hidden relative">
                <img
                  src={item.img}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent" />
                <span className="absolute bottom-2 left-2 text-[11px] font-bold text-amber-300">
                  {item.location}
                </span>
              </div>
              <div className="p-3">
                <h4 className="text-xs font-bold text-slate-800 line-clamp-1">{item.title}</h4>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Video URL Modal */}
      {showVideoModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Video className="w-4 h-4 text-emerald-600" />
                {t.changeVideoUrl}
              </h3>
              <button
                onClick={() => setShowVideoModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Video URL (YouTube Embed or MP4 direct link):
                </label>
                <input
                  type="text"
                  value={videoInput}
                  onChange={(e) => setVideoInput(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=... or .mp4"
                  className="w-full px-3 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl text-slate-600 text-[11px] space-y-1">
                <p>💡 You can paste any YouTube presentation or direct video link of your center classes, speeches, or ceremonies.</p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setShowVideoModal(false)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleSaveVideo}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
              >
                {t.saveChanges}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Logo Modal */}
      {showLogoModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-600" />
                Customize Center Logo
              </h3>
              <button
                onClick={() => setShowLogoModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-center py-2">
                <img
                  src={centerLogoUrl}
                  alt="Current Logo"
                  className="w-24 h-24 rounded-2xl object-cover ring-4 ring-emerald-500 shadow"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Logo Image URL:
                </label>
                <input
                  type="text"
                  value={logoInput}
                  onChange={(e) => setLogoInput(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="cursor-pointer flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-4 bg-slate-50 transition">
                  <Upload className="w-6 h-6 text-slate-400 mb-1" />
                  <span className="font-bold text-slate-700">{t.uploadPhoto}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setShowLogoModal(false)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  if (logoInput.trim()) onUpdateLogoUrl(logoInput.trim());
                  setShowLogoModal(false);
                }}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
              >
                {t.saveChanges}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
