import React, { useEffect, useMemo, useState } from 'react';
import { Edit2, Plus, Search, SlidersHorizontal, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  addDaysToDate,
  calculateLeaveBalances,
  formatDate,
  formatNumber,
  getLeaveYearForDate,
} from '../utils/calculations';
import { getTodayIso } from '../utils/storage';
import type { LeaveEntryType, LeaveStatus, TaskPriority, TaskStatus } from '../types';
import { ConfirmModal } from './ConfirmModal';

const LEAVE_YEAR_OPTIONS = ['2024-2025', '2025-2026', '2026-2027', '2027-2028', '2028-2029'];
const TASK_PRIORITIES: TaskPriority[] = ['Low', 'Medium', 'High', 'Urgent'];
const TASK_STATUSES: TaskStatus[] = ['Pending', 'In Progress', 'Completed', 'Cancelled'];

export const FactoryModule: React.FC = () => {
  const {
    state,
    activeSubTab,
    focusedRecordId,
    clearFocusedRecord,
    tr,
    themeTokens,
    notify,
    updateSettings,
    upsertLeave,
    deleteLeave,
    upsertLeaveYearOpening,
    upsertTask,
    deleteTask,
  } = useApp();

  const [tab, setTab] = useState<'leave' | 'tasks'>(
    activeSubTab === 'tasks' ? 'tasks' : 'leave'
  );

  useEffect(() => {
    if (activeSubTab === 'leave' || activeSubTab === 'tasks') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const dateFmt = state.settings.dateFormat;

  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    type: 'leave' | 'task';
    id: string;
    label: string;
  }>({ open: false, type: 'leave', id: '', label: '' });

  // ==========================================
  // LEAVE MANAGEMENT STATE
  // ==========================================
  const selectedYear = state.settings.activeLeaveYear;
  const openingConfig = useMemo(
    () => state.leaveYearOpenings.find((o) => o.leaveYear === selectedYear),
    [state.leaveYearOpenings, selectedYear]
  );

  const leaveBalance = useMemo(
    () =>
      calculateLeaveBalances(
        state.leaves,
        selectedYear,
        openingConfig,
        state.settings.defaultCL,
        state.settings.defaultSL,
        state.settings.cplExpiryDays
      ),
    [
      state.leaves,
      selectedYear,
      openingConfig,
      state.settings.defaultCL,
      state.settings.defaultSL,
      state.settings.cplExpiryDays,
    ]
  );

  const [showOpeningEditor, setShowOpeningEditor] = useState(false);
  const [openCL, setOpenCL] = useState(String(leaveBalance.clEntitlement));
  const [openSL, setOpenSL] = useState(String(leaveBalance.slEntitlement));
  const [carryCL, setCarryCL] = useState(String(leaveBalance.clOpening));
  const [carrySL, setCarrySL] = useState(String(leaveBalance.slOpening));
  const [carryCPL, setCarryCPL] = useState(String(leaveBalance.cplOpening));

  useEffect(() => {
    setOpenCL(String(leaveBalance.clEntitlement));
    setOpenSL(String(leaveBalance.slEntitlement));
    setCarryCL(String(leaveBalance.clOpening));
    setCarrySL(String(leaveBalance.slOpening));
    setCarryCPL(String(leaveBalance.cplOpening));
  }, [selectedYear, openingConfig, state.settings.defaultCL, state.settings.defaultSL]);

  const [lEditId, setLEditId] = useState<string | null>(null);
  const [lDate, setLDate] = useState(getTodayIso());
  const [lEmployee, setLEmployee] = useState(state.settings.defaultEmployeeName || 'Saif Ullah');
  const [lType, setLType] = useState<LeaveEntryType>('CL');
  const [lDays, setLDays] = useState('1');
  const [lReason, setLReason] = useState('');
  const [lStatus, setLStatus] = useState<LeaveStatus>('Approved');
  const [lError, setLError] = useState('');

  // Leave filters
  const [lSearch, setLSearch] = useState('');
  const [lTypeFilter, setLTypeFilter] = useState('');
  const [lFrom, setLFrom] = useState('');
  const [lTo, setLTo] = useState('');

  const resetLeaveForm = () => {
    setLEditId(null);
    setLDate(getTodayIso());
    setLEmployee(state.settings.defaultEmployeeName || 'Saif Ullah');
    setLType('CL');
    setLDays('1');
    setLReason('');
    setLStatus('Approved');
    setLError('');
  };

  const handleSaveOpening = (e: React.FormEvent) => {
    e.preventDefault();
    upsertLeaveYearOpening({
      leaveYear: selectedYear,
      clEntitlement: Math.max(0, parseFloat(openCL) || 0),
      slEntitlement: Math.max(0, parseFloat(openSL) || 0),
      clOpening: parseFloat(carryCL) || 0,
      slOpening: parseFloat(carrySL) || 0,
      cplOpening: Math.max(0, parseFloat(carryCPL) || 0),
    });
    setShowOpeningEditor(false);
    notify(`Updated leave year ${selectedYear} balances.`);
  };

  const handleSaveLeave = (e: React.FormEvent) => {
    e.preventDefault();
    setLError('');
    const daysNum = parseFloat(lDays);
    if (!lDate) {
      setLError('Date is required.');
      return;
    }
    if (!Number.isFinite(daysNum) || daysNum <= 0) {
      setLError('Please enter a valid positive number.');
      return;
    }

    const entryYear = getLeaveYearForDate(lDate);
    // Compute balance excluding the currently edited record
    const otherLeaves = lEditId ? state.leaves.filter((x) => x.id !== lEditId) : state.leaves;
    const yearOpening = state.leaveYearOpenings.find((o) => o.leaveYear === entryYear);
    const bal = calculateLeaveBalances(
      otherLeaves,
      entryYear,
      yearOpening,
      state.settings.defaultCL,
      state.settings.defaultSL,
      state.settings.cplExpiryDays,
      lDate
    );

    if (lStatus !== 'Cancelled' && !state.settings.allowNegativeLeaveOverride) {
      if (lType === 'CL' && daysNum > bal.clRemaining) {
        setLError(
          `Insufficient Casual Leave balance. Available: ${formatNumber(bal.clRemaining)}, requested: ${formatNumber(daysNum)}.`
        );
        return;
      }
      if (lType === 'SL' && daysNum > bal.slRemaining) {
        setLError(
          `Insufficient Sick Leave balance. Available: ${formatNumber(bal.slRemaining)}, requested: ${formatNumber(daysNum)}.`
        );
        return;
      }
      if (lType === 'CPL_USED') {
        if (bal.cplAvail <= 0) {
          setLError('No CPL Avail balance is currently available. Post CPL Due first.');
          return;
        }
        if (daysNum > bal.cplAvail) {
          setLError(
            `Insufficient CPL Avail balance. Available: ${formatNumber(bal.cplAvail)}, requested: ${formatNumber(daysNum)}.`
          );
          return;
        }
      }
    }

    const expiryDate =
      lType === 'CPL_DUE' ? addDaysToDate(lDate, state.settings.cplExpiryDays || 40) : undefined;

    upsertLeave(
      {
        date: lDate,
        leaveYear: entryYear,
        employee: lEmployee.trim() || state.settings.defaultEmployeeName || 'Saif Ullah',
        type: lType,
        days: daysNum,
        expiryDate,
        reason: lReason.trim(),
        status: lStatus,
      },
      lEditId || undefined
    );

    if (entryYear !== selectedYear) {
      updateSettings({ activeLeaveYear: entryYear }, `Switched leave year to ${entryYear}`);
    }
    notify(lEditId ? 'Leave entry updated.' : 'Leave entry saved.');
    resetLeaveForm();
  };

  const startEditLeave = (id: string) => {
    const rec = state.leaves.find((l) => l.id === id);
    if (!rec) return;
    setLEditId(rec.id);
    setLDate(rec.date);
    setLEmployee(rec.employee);
    setLType(rec.type);
    setLDays(String(rec.days));
    setLReason(rec.reason);
    setLStatus(rec.status);
    setLError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredLeaves = useMemo(() => {
    const q = lSearch.trim().toLowerCase();
    return state.leaves
      .filter((l) => {
        if (l.leaveYear !== selectedYear) return false;
        if (lTypeFilter && l.type !== lTypeFilter) return false;
        if (lFrom && l.date < lFrom) return false;
        if (lTo && l.date > lTo) return false;
        if (q) {
          const hay = `${l.employee} ${l.reason} ${l.type} ${l.status}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [state.leaves, selectedYear, lTypeFilter, lFrom, lTo, lSearch]);

  // ==========================================
  // OFFICE TASKS STATE
  // ==========================================
  const [tEditId, setTEditId] = useState<string | null>(null);
  const [tTitle, setTTitle] = useState('');
  const [tDesc, setTDesc] = useState('');
  const [tAssigned, setTAssigned] = useState(state.settings.defaultEmployeeName || 'Saif Ullah');
  const [tCreated, setTCreated] = useState(getTodayIso());
  const [tDue, setTDue] = useState('');
  const [tPriority, setTPriority] = useState<TaskPriority>('Medium');
  const [tStatus, setTStatus] = useState<TaskStatus>('Pending');
  const [tRemarks, setTRemarks] = useState('');
  const [tError, setTError] = useState('');

  // Task filters
  const [tSearch, setTSearch] = useState('');
  const [tStatusFilter, setTStatusFilter] = useState('');
  const [tPriorityFilter, setTPriorityFilter] = useState('');
  const [tDueFilter, setTDueFilter] = useState('');

  useEffect(() => {
    if (focusedRecordId) {
      if (state.leaves.some((l) => l.id === focusedRecordId)) {
        setTab('leave');
        startEditLeave(focusedRecordId);
        clearFocusedRecord();
      } else if (state.tasks.some((tk) => tk.id === focusedRecordId)) {
        setTab('tasks');
        const tk = state.tasks.find((x) => x.id === focusedRecordId);
        if (tk) {
          setTEditId(tk.id);
          setTTitle(tk.title);
          setTDesc(tk.description);
          setTAssigned(tk.assignedPerson);
          setTCreated(tk.createdDate);
          setTDue(tk.dueDate);
          setTPriority(tk.priority);
          setTStatus(tk.status);
          setTRemarks(tk.remarks);
        }
        clearFocusedRecord();
      }
    }
  }, [focusedRecordId, state.leaves, state.tasks, clearFocusedRecord]);

  const resetTaskForm = () => {
    setTEditId(null);
    setTTitle('');
    setTDesc('');
    setTAssigned(state.settings.defaultEmployeeName || 'Saif Ullah');
    setTCreated(getTodayIso());
    setTDue('');
    setTPriority('Medium');
    setTStatus('Pending');
    setTRemarks('');
    setTError('');
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    setTError('');
    if (!tTitle.trim()) {
      setTError('Task title is required.');
      return;
    }
    upsertTask(
      {
        title: tTitle.trim(),
        description: tDesc.trim(),
        assignedPerson: tAssigned.trim(),
        createdDate: tCreated || getTodayIso(),
        dueDate: tDue,
        priority: tPriority,
        status: tStatus,
        remarks: tRemarks.trim(),
      },
      tEditId || undefined
    );
    notify(tEditId ? 'Task updated.' : 'Task added.');
    resetTaskForm();
  };

  const filteredTasks = useMemo(() => {
    const q = tSearch.trim().toLowerCase();
    return state.tasks
      .filter((tk) => {
        if (tStatusFilter && tk.status !== tStatusFilter) return false;
        if (tPriorityFilter && tk.priority !== tPriorityFilter) return false;
        if (tDueFilter && tk.dueDate > tDueFilter) return false;
        if (q) {
          const hay = `${tk.title} ${tk.description} ${tk.assignedPerson} ${tk.remarks}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => (a.dueDate || '9999-12-31').localeCompare(b.dueDate || '9999-12-31'));
  }, [state.tasks, tStatusFilter, tPriorityFilter, tDueFilter, tSearch]);

  const taskCounts = useMemo(
    () => ({
      pending: state.tasks.filter((t) => t.status === 'Pending').length,
      inProgress: state.tasks.filter((t) => t.status === 'In Progress').length,
      completed: state.tasks.filter((t) => t.status === 'Completed').length,
      cancelled: state.tasks.filter((t) => t.status === 'Cancelled').length,
    }),
    [state.tasks]
  );

  const triggerDelete = (type: 'leave' | 'task', id: string, label: string) => {
    if (!state.settings.confirmBeforeDelete) {
      if (type === 'leave') deleteLeave(id);
      else deleteTask(id);
      notify('Moved to Recycle Bin.');
      return;
    }
    setConfirmState({ open: true, type, id, label });
  };

  return (
    <div className="space-y-6">
      {/* Submodule Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg bg-slate-200/70 p-1" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'leave'}
            onClick={() => setTab('leave')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'leave'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('leave_management')}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'tasks'}
            onClick={() => setTab('tasks')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'tasks'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('office_tasks')}
          </button>
        </div>

        {tab === 'leave' && (
          <div className="flex items-center gap-2">
            <label htmlFor="leave-year-select" className="text-xs font-medium text-slate-600">
              {tr('leave_year')} (Jul–Jun):
            </label>
            <select
              id="leave-year-select"
              value={selectedYear}
              onChange={(e) =>
                updateSettings({ activeLeaveYear: e.target.value }, `Selected leave year ${e.target.value}`)
              }
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-900"
            >
              {LEAVE_YEAR_OPTIONS.map((yr) => (
                <option key={yr} value={yr}>
                  {yr}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setShowOpeningEditor((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Openings</span>
            </button>
          </div>
        )}
      </div>

      {/* ==========================================
          TAB A: LEAVE MANAGEMENT
         ========================================== */}
      {tab === 'leave' && (
        <div className="space-y-6">
          {/* Opening / Entitlement Editor */}
          {showOpeningEditor && (
            <form
              onSubmit={handleSaveOpening}
              className="bg-white border border-slate-200 rounded-xl p-5 space-y-4"
            >
              <h3 className="text-sm font-semibold text-slate-900">
                Leave Year {selectedYear} Entitlements &amp; Opening Balances
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Casual Leave Entitlement
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={openCL}
                    onChange={(e) => setOpenCL(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Sick Leave Entitlement
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={openSL}
                    onChange={(e) => setOpenSL(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    CL Opening
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={carryCL}
                    onChange={(e) => setCarryCL(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    SL Opening
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={carrySL}
                    onChange={(e) => setCarrySL(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    CPL Opening
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={carryCPL}
                    onChange={(e) => setCarryCPL(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm tabular-nums"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowOpeningEditor(false)}
                  className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-medium text-slate-700"
                >
                  {tr('cancel')}
                </button>
                <button
                  type="submit"
                  className={`rounded-lg px-4 py-1.5 text-xs font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  {tr('save')}
                </button>
              </div>
            </form>
          )}

          {/* Leave Balance Cards — Strictly numeric values, NO "days" suffix */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs font-medium text-slate-500">{tr('casual_leave')}</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatNumber(leaveBalance.clRemaining)}
              </div>
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                Ent {formatNumber(leaveBalance.clEntitlement + leaveBalance.clOpening)} · Used {formatNumber(leaveBalance.clUsed)}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs font-medium text-slate-500">{tr('sick_leave')}</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatNumber(leaveBalance.slRemaining)}
              </div>
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                Ent {formatNumber(leaveBalance.slEntitlement + leaveBalance.slOpening)} · Used {formatNumber(leaveBalance.slUsed)}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs font-medium text-slate-500">{tr('cpl_due')}</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatNumber(leaveBalance.cplDueTotal)}
              </div>
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                Used {formatNumber(leaveBalance.cplUsedTotal)} · Exp {formatNumber(leaveBalance.cplExpiredTotal)}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs font-medium text-slate-500">{tr('cpl_avail')}</div>
              <div className="mt-1 text-2xl font-bold text-emerald-700 tabular-nums">
                {formatNumber(leaveBalance.cplAvail)}
              </div>
              <div className="mt-1 text-xs text-slate-500">
                FIFO · {state.settings.cplExpiryDays}-day expiry
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 col-span-2 lg:col-span-1">
              <div className="text-xs font-medium text-slate-500">Total Leave Balance</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatNumber(leaveBalance.totalRemaining)}
              </div>
              <div className="mt-1 text-xs text-slate-500">CL + SL + CPL Avail</div>
            </div>
          </div>

          {/* Leave Entry Form */}
          <form onSubmit={handleSaveLeave} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {lEditId ? 'Edit Leave / CPL Entry' : tr('add_leave_entry')}
              </h3>
              {lEditId && (
                <button type="button" onClick={resetLeaveForm} className="text-xs text-slate-500">
                  {tr('cancel')}
                </button>
              )}
            </div>

            {lError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {lError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <div>
                <label htmlFor="l-date" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('date')} *
                </label>
                <input
                  id="l-date"
                  type="date"
                  value={lDate}
                  onChange={(e) => setLDate(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="l-type" className="block text-xs font-medium text-slate-700 mb-1">
                  Leave Type *
                </label>
                <select
                  id="l-type"
                  value={lType}
                  onChange={(e) => setLType(e.target.value as LeaveEntryType)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="CL">{tr('casual_leave')}</option>
                  <option value="SL">{tr('sick_leave')}</option>
                  <option value="CPL_DUE">{tr('cpl_due')} (Add to CPL Avail)</option>
                  {(leaveBalance.cplAvail > 0 || state.settings.allowNegativeLeaveOverride || lEditId) && (
                    <option value="CPL_USED">
                      Use CPL (Avail: {formatNumber(leaveBalance.cplAvail)})
                    </option>
                  )}
                </select>
              </div>

              <div>
                <label htmlFor="l-days" className="block text-xs font-medium text-slate-700 mb-1">
                  Count (e.g. 0.5, 1, 2) *
                </label>
                <input
                  id="l-days"
                  type="number"
                  step="0.5"
                  min="0.5"
                  value={lDays}
                  onChange={(e) => setLDays(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>

              <div>
                <label htmlFor="l-emp" className="block text-xs font-medium text-slate-700 mb-1">
                  Employee / Person
                </label>
                <input
                  id="l-emp"
                  type="text"
                  value={lEmployee}
                  onChange={(e) => setLEmployee(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="l-status" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('status')}
                </label>
                <select
                  id="l-status"
                  value={lStatus}
                  onChange={(e) => setLStatus(e.target.value as LeaveStatus)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="Approved">Approved</option>
                  <option value="Pending">Pending</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 items-end">
              <div className="flex-1 w-full">
                <label htmlFor="l-reason" className="block text-xs font-medium text-slate-700 mb-1">
                  Reason / Remarks
                </label>
                <input
                  id="l-reason"
                  type="text"
                  value={lReason}
                  onChange={(e) => setLReason(e.target.value)}
                  placeholder="Sunday duty, medical checkup, personal work..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <button
                type="submit"
                className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
              >
                <Plus className="h-4 w-4" />
                <span>{lEditId ? tr('update') : tr('save')}</span>
              </button>
            </div>
          </form>

          {/* CPL FIFO Expiry Lots Table */}
          {leaveBalance.cplLots.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-800">
                  CPL Lots (FIFO · {state.settings.cplExpiryDays}-Day Expiry)
                </h3>
                <span className="text-xs text-slate-500 tabular-nums">
                  CPL Avail: {formatNumber(leaveBalance.cplAvail)}
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <tr>
                      <th className="px-4 py-2.5 text-start">Due Date</th>
                      <th className="px-4 py-2.5 text-start">Expiry Date</th>
                      <th className="px-4 py-2.5 text-start">Reason</th>
                      <th className="px-4 py-2.5 text-end">CPL Due</th>
                      <th className="px-4 py-2.5 text-end">Used</th>
                      <th className="px-4 py-2.5 text-end">Expired</th>
                      <th className="px-4 py-2.5 text-end">CPL Avail</th>
                      <th className="px-4 py-2.5 text-start">State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {leaveBalance.cplLots.map((lot) => (
                      <tr key={lot.id} className={lot.isExpired ? 'bg-red-50/40 text-slate-500' : ''}>
                        <td className="px-4 py-2.5 tabular-nums whitespace-nowrap">
                          {formatDate(lot.dueDate, dateFmt)}
                        </td>
                        <td className="px-4 py-2.5 tabular-nums whitespace-nowrap">
                          {formatDate(lot.expiryDate, dateFmt)}
                        </td>
                        <td className="px-4 py-2.5">{lot.reason || '—'}</td>
                        <td className="px-4 py-2.5 text-end tabular-nums">{formatNumber(lot.originalDays)}</td>
                        <td className="px-4 py-2.5 text-end tabular-nums">{formatNumber(lot.usedDays)}</td>
                        <td className="px-4 py-2.5 text-end tabular-nums text-red-700">
                          {formatNumber(lot.expiredDays)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums font-semibold text-emerald-700">
                          {formatNumber(lot.remainingDays)}
                        </td>
                        <td className="px-4 py-2.5 whitespace-nowrap font-medium">
                          {lot.isExpired
                            ? 'Expired'
                            : lot.remainingDays === 0
                              ? 'Consumed'
                              : 'Active'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Leave Ledger Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              <div className="relative lg:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={lSearch}
                  onChange={(e) => setLSearch(e.target.value)}
                  placeholder="Search leave ledger..."
                  aria-label="Search leave ledger"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
                />
              </div>
              <select
                value={lTypeFilter}
                onChange={(e) => setLTypeFilter(e.target.value)}
                aria-label="Filter by leave type"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Types</option>
                <option value="CL">{tr('casual_leave')}</option>
                <option value="SL">{tr('sick_leave')}</option>
                <option value="CPL_DUE">{tr('cpl_due')}</option>
                <option value="CPL_USED">CPL Used</option>
              </select>
              <input
                type="date"
                value={lFrom}
                onChange={(e) => setLFrom(e.target.value)}
                aria-label="Filter leave from date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
              <input
                type="date"
                value={lTo}
                onChange={(e) => setLTo(e.target.value)}
                aria-label="Filter leave to date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
            </div>

            {filteredLeaves.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('date')}</th>
                      <th className="px-4 py-3 text-start">Type</th>
                      <th className="px-4 py-3 text-end">Count</th>
                      <th className="px-4 py-3 text-start">Employee</th>
                      <th className="px-4 py-3 text-start">Reason / Expiry</th>
                      <th className="px-4 py-3 text-start">{tr('status')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredLeaves.map((l) => {
                      const label =
                        l.type === 'CL'
                          ? tr('casual_leave')
                          : l.type === 'SL'
                            ? tr('sick_leave')
                            : l.type === 'CPL_DUE'
                              ? tr('cpl_due')
                              : 'CPL Used';
                      return (
                        <tr key={l.id} className="hover:bg-slate-50">
                          <td className="px-4 py-3 whitespace-nowrap tabular-nums">
                            {formatDate(l.date, dateFmt)}
                          </td>
                          <td className="px-4 py-3 font-medium whitespace-nowrap">
                            <span
                              className={
                                l.type === 'CPL_DUE' ? 'text-emerald-700' : 'text-slate-900'
                              }
                            >
                              {label}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-end tabular-nums font-semibold">
                            {l.type === 'CPL_DUE' ? `+${formatNumber(l.days)}` : formatNumber(l.days)}
                          </td>
                          <td className="px-4 py-3 text-slate-700">{l.employee}</td>
                          <td className="px-4 py-3 text-slate-600">
                            <div>{l.reason || '—'}</div>
                            {l.expiryDate && (
                              <div className="text-xs text-slate-500">
                                Expires {formatDate(l.expiryDate, dateFmt)}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-xs font-medium text-slate-700">
                            {l.status}
                          </td>
                          <td className="px-4 py-3 text-end whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => startEditLeave(l.id)}
                              aria-label={`Edit leave ${label} on ${l.date}`}
                              className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                            >
                              <Edit2 className="h-4 w-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => triggerDelete('leave', l.id, `${label} (${l.days})`)}
                              aria-label={`Delete leave ${label} on ${l.date}`}
                              className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================
          TAB B: OFFICE TASKS
         ========================================== */}
      {tab === 'tasks' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Pending</div>
              <div className="mt-1 text-2xl font-bold text-amber-700 tabular-nums">{taskCounts.pending}</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">In Progress</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">{taskCounts.inProgress}</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Completed</div>
              <div className="mt-1 text-2xl font-bold text-emerald-700 tabular-nums">{taskCounts.completed}</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Cancelled</div>
              <div className="mt-1 text-2xl font-bold text-slate-500 tabular-nums">{taskCounts.cancelled}</div>
            </div>
          </div>

          {/* Task Form */}
          <form onSubmit={handleSaveTask} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {tEditId ? 'Edit Office Task' : tr('add_task')}
              </h3>
              {tEditId && (
                <button type="button" onClick={resetTaskForm} className="text-xs text-slate-500">
                  {tr('cancel')}
                </button>
              )}
            </div>

            {tError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {tError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="t-title" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('task_title')} *
                </label>
                <input
                  id="t-title"
                  type="text"
                  value={tTitle}
                  onChange={(e) => setTTitle(e.target.value)}
                  placeholder="e.g. Submit monthly attendance sheet"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="t-assigned" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('assigned_person')}
                </label>
                <input
                  id="t-assigned"
                  type="text"
                  value={tAssigned}
                  onChange={(e) => setTAssigned(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="t-due" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('due_date')}
                </label>
                <input
                  id="t-due"
                  type="date"
                  value={tDue}
                  onChange={(e) => setTDue(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="t-priority" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('priority')}
                </label>
                <select
                  id="t-priority"
                  value={tPriority}
                  onChange={(e) => setTPriority(e.target.value as TaskPriority)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {TASK_PRIORITIES.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="t-status" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('status')}
                </label>
                <select
                  id="t-status"
                  value={tStatus}
                  onChange={(e) => setTStatus(e.target.value as TaskStatus)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {TASK_STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="t-desc" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('description')} / {tr('remarks')}
                </label>
                <div className="flex gap-2">
                  <input
                    id="t-desc"
                    type="text"
                    value={tDesc}
                    onChange={(e) => setTDesc(e.target.value)}
                    placeholder="Details or follow-up notes..."
                    className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <button
                    type="submit"
                    className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                  >
                    <Plus className="h-4 w-4" />
                    <span>{tEditId ? tr('update') : tr('save')}</span>
                  </button>
                </div>
              </div>
            </div>
          </form>

          {/* Tasks Filters & List */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              <div className="relative lg:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={tSearch}
                  onChange={(e) => setTSearch(e.target.value)}
                  placeholder="Search office tasks..."
                  aria-label="Search office tasks"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
                />
              </div>
              <select
                value={tStatusFilter}
                onChange={(e) => setTStatusFilter(e.target.value)}
                aria-label="Filter by task status"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Statuses</option>
                {TASK_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <select
                value={tPriorityFilter}
                onChange={(e) => setTPriorityFilter(e.target.value)}
                aria-label="Filter by task priority"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Priorities</option>
                {TASK_PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              <input
                type="date"
                value={tDueFilter}
                onChange={(e) => setTDueFilter(e.target.value)}
                aria-label="Filter tasks due on or before date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
            </div>

            {filteredTasks.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('task_title')}</th>
                      <th className="px-4 py-3 text-start">{tr('assigned_person')}</th>
                      <th className="px-4 py-3 text-start">{tr('due_date')}</th>
                      <th className="px-4 py-3 text-start">{tr('priority')}</th>
                      <th className="px-4 py-3 text-start">{tr('status')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredTasks.map((tk) => (
                      <tr key={tk.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-900">{tk.title}</div>
                          {tk.description && <div className="text-xs text-slate-500">{tk.description}</div>}
                        </td>
                        <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                          {tk.assignedPerson || '—'}
                        </td>
                        <td className="px-4 py-3 tabular-nums whitespace-nowrap text-slate-600">
                          {tk.dueDate ? formatDate(tk.dueDate, dateFmt) : '—'}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-xs font-medium">
                          <span
                            className={
                              tk.priority === 'Urgent'
                                ? 'text-red-700'
                                : tk.priority === 'High'
                                  ? 'text-amber-700'
                                  : 'text-slate-600'
                            }
                          >
                            {tk.priority}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <select
                            aria-label={`Change status for ${tk.title}`}
                            value={tk.status}
                            onChange={(e) => {
                              upsertTask(
                                {
                                  title: tk.title,
                                  description: tk.description,
                                  assignedPerson: tk.assignedPerson,
                                  createdDate: tk.createdDate,
                                  dueDate: tk.dueDate,
                                  priority: tk.priority,
                                  status: e.target.value as TaskStatus,
                                  remarks: tk.remarks,
                                },
                                tk.id
                              );
                              notify(`Task status updated to ${e.target.value}.`);
                            }}
                            className="rounded border border-slate-300 bg-white px-2 py-1 text-xs font-medium text-slate-800"
                          >
                            {TASK_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setTEditId(tk.id);
                              setTTitle(tk.title);
                              setTDesc(tk.description);
                              setTAssigned(tk.assignedPerson);
                              setTCreated(tk.createdDate);
                              setTDue(tk.dueDate);
                              setTPriority(tk.priority);
                              setTStatus(tk.status);
                              setTRemarks(tk.remarks);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            aria-label={`Edit task ${tk.title}`}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => triggerDelete('task', tk.id, tk.title)}
                            aria-label={`Delete task ${tk.title}`}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      <ConfirmModal
        open={confirmState.open}
        title={tr('confirm_delete_title')}
        message={`${tr('confirm_delete_msg')} (${confirmState.label})`}
        confirmLabel={tr('delete')}
        cancelLabel={tr('cancel')}
        onCancel={() => setConfirmState((s) => ({ ...s, open: false }))}
        onConfirm={() => {
          if (confirmState.type === 'leave') deleteLeave(confirmState.id);
          else deleteTask(confirmState.id);
          notify('Moved to Recycle Bin.');
          setConfirmState((s) => ({ ...s, open: false }));
        }}
      />
    </div>
  );
};
