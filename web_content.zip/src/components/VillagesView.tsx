import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Building2,
  Castle,
  Clock,
  Info,
  RefreshCw,
  Shield,
  Wrench,
} from 'lucide-react';
import {
  ClanDashboardState,
  JsonObjectSnapshotEntry,
  OfficialUnitEntry,
  PlayerProfile,
  VillageId,
} from '../shared/cocData';
import { formatDateTimeRu, formatRelativeTimeRu } from '../utils/formatters';
import { translateCocUnitNameRu } from '../utils/clanAnalytics';
import {
  CocUnitBadge,
  formatCountdownRu,
  getDataSourceLabel,
  getUpgradeCategoryShortLabel,
  isActualUpgradeEvent,
  resolveUpgradeDetailType,
  resolveUpgradeVillage,
} from './CocUnitBadge';

interface VillagesViewProps {
  state: ClanDashboardState;
  selectedVillage: VillageId;
  nowMs: number;
  isSyncing: boolean;
  onSelectVillage: (village: VillageId) => void;
  onSyncNow: () => void;
  onOpenJsonImport?: (playerTag?: string) => void;
  onSelectPlayer: (tag: string) => void;
}

const ApiUnitSubGrid: React.FC<{
  title: string;
  items: OfficialUnitEntry[];
  accent?: 'amber' | 'sky' | 'emerald';
}> = ({ title, items, accent = 'amber' }) => {
  if (items.length === 0) return null;
  const lvColor =
    accent === 'sky' ? 'text-sky-400' : accent === 'emerald' ? 'text-emerald-400' : 'text-amber-400';

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between text-xs">
        <span className="font-semibold text-slate-300">{title}</span>
        <span className="font-mono text-[11px] text-slate-500">{items.length} поз.</span>
      </div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((u, idx) => (
          <div
            key={`${u.name}-${u.village ?? 'home'}-${idx}`}
            className="flex items-center justify-between gap-2 rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs"
          >
            <div className="min-w-0">
              <div className="truncate font-medium text-slate-100">
                {u.name}
                {u.superTroopIsActive && (
                  <span className="ml-1.5 text-[10px] font-semibold text-amber-400">Супер</span>
                )}
              </div>
              <div className="truncate text-[10px] text-slate-500">
                {translateCocUnitNameRu(u.name)}
              </div>
            </div>
            <span
              className={`font-mono font-bold tabular-nums shrink-0 ${
                u.maxLevel > 0 && u.level >= u.maxLevel ? 'text-emerald-400' : lvColor
              }`}
            >
              {u.level}/{u.maxLevel || u.level}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

const JsonObjectsGrid: React.FC<{
  title: string;
  entries: JsonObjectSnapshotEntry[];
}> = ({ title, entries }) => {
  if (entries.length === 0) return null;

  return (
    <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
        <h3 className="font-display text-sm font-semibold text-slate-100">{title}</h3>
        <span className="font-mono text-[11px] text-sky-300">
          Источник: Доп. JSON Export · {entries.length} тип.
        </span>
      </div>
      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {entries.map((entry) => (
          <div
            key={`${entry.dataId}-${entry.name}`}
            className="rounded-md border border-slate-800 bg-[#0B0F17] p-3 space-y-2"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-100 truncate">{entry.name}</div>
                {entry.nameRu !== entry.name && (
                  <div className="text-[11px] text-slate-400 truncate">{entry.nameRu}</div>
                )}
              </div>
              <span className="font-mono text-[11px] text-slate-400 shrink-0">
                {entry.levels.length} шт.
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 font-mono text-xs tabular-nums">
              {entry.levels.map((lv, idx) => (
                <span
                  key={idx}
                  className="rounded border border-slate-700/80 bg-[#121824] px-2 py-0.5 text-amber-300"
                >
                  Ур. {lv}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const VillagesView: React.FC<VillagesViewProps> = ({
  state,
  selectedVillage,
  nowMs,
  isSyncing,
  onSelectVillage,
  onSyncNow,
  onSelectPlayer,
}) => {
  const [selectedMemberTag, setSelectedMemberTag] = useState<string>(
    state.players[0]?.tag ?? ''
  );

  useEffect(() => {
    if (
      state.players.length > 0 &&
      !state.players.some((p) => p.tag === selectedMemberTag)
    ) {
      setSelectedMemberTag(state.players[0].tag);
    }
  }, [state.players, selectedMemberTag]);

  const activeMember: PlayerProfile | null = useMemo(
    () =>
      state.players.find((p) => p.tag === selectedMemberTag) ??
      state.players[0] ??
      null,
    [state.players, selectedMemberTag]
  );

  const actualEvents = useMemo(
    () => state.events.filter(isActualUpgradeEvent),
    [state.events]
  );

  const villageStats = useMemo(() => {
    const activeByVillage: Record<VillageId, number> = {
      home: 0,
      builderBase: 0,
      clanCapital: 0,
    };
    for (const a of state.activeUpgrades ?? []) {
      if (a.status === 'in_progress') {
        activeByVillage[a.village] += 1;
      }
    }
    const eventsByVillage: Record<VillageId, number> = {
      home: 0,
      builderBase: 0,
      clanCapital: 0,
    };
    for (const ev of actualEvents) {
      eventsByVillage[resolveUpgradeVillage(ev)] += 1;
    }

    const avgTh =
      state.players.length > 0
        ? state.players.reduce((s, p) => s + p.townHallLevel, 0) / state.players.length
        : 0;
    const maxTh =
      state.players.length > 0
        ? Math.max(...state.players.map((p) => p.townHallLevel))
        : 0;
    const bhPlayers = state.players.filter((p) => p.builderHallLevel > 0);
    const avgBh =
      bhPlayers.length > 0
        ? bhPlayers.reduce((s, p) => s + p.builderHallLevel, 0) / bhPlayers.length
        : 0;
    const topBbTrophies =
      state.players.length > 0
        ? Math.max(...state.players.map((p) => p.builderBaseTrophies))
        : 0;

    return {
      activeByVillage,
      eventsByVillage,
      avgTh,
      maxTh,
      avgBh,
      topBbTrophies,
    };
  }, [state.activeUpgrades, state.players, actualEvents]);

  const villageActiveUpgrades = useMemo(
    () =>
      (state.activeUpgrades ?? [])
        .filter((a) => a.village === selectedVillage)
        .sort((a, b) => {
          if (a.status !== b.status) return a.status === 'in_progress' ? -1 : 1;
          return new Date(b.lastConfirmedAt).getTime() - new Date(a.lastConfirmedAt).getTime();
        }),
    [state.activeUpgrades, selectedVillage]
  );

  const villageHistoryEvents = useMemo(
    () =>
      actualEvents.filter((ev) => resolveUpgradeVillage(ev) === selectedVillage),
    [actualEvents, selectedVillage]
  );

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы просматривать данные по трём деревням (Home Village, Builder Base и Clan Capital).
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header + Sync CTA */}
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-5 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Три деревни клана (раздельный мониторинг)
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Home Village, Builder Base и Clan Capital строго разделены: собственная статистика из Supercell API, объекты и журнал улучшений
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onSyncNow}
            disabled={isSyncing}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-4 py-2.5 text-xs sm:text-sm font-bold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap"
          >
            <RefreshCw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'СИНХРОНИЗАЦИЯ...' : 'СИНХРОНИЗИРОВАТЬ ДАННЫЕ'}</span>
          </button>
        </div>
      </section>

      {/* THREE BIG VILLAGE SWITCHER CARDS */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {/* 1. HOME VILLAGE */}
        <button
          type="button"
          onClick={() => onSelectVillage('home')}
          className={`rounded-xl border p-5 text-left transition-all ${
            selectedVillage === 'home'
              ? 'border-amber-500 bg-amber-500/12 shadow-lg shadow-amber-500/10'
              : 'border-slate-800 bg-[#121824] hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-amber-400">
              <Building2 className="h-4 w-4" />
              HOME VILLAGE
            </span>
            <span className="font-mono text-xs text-slate-400">
              Средняя TH: <strong className="text-slate-100">{villageStats.avgTh.toFixed(1)}</strong>
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Родная деревня
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-slate-800/80 pt-3 font-mono text-xs tabular-nums">
            <span className="text-amber-300">
              Очки: <strong>{state.clan.clanPoints.toLocaleString('ru-RU')}</strong>
            </span>
            <span className="text-emerald-400">
              Улучшений (API): <strong>{villageStats.eventsByVillage.home}</strong>
            </span>
          </div>
        </button>

        {/* 2. BUILDER BASE */}
        <button
          type="button"
          onClick={() => onSelectVillage('builderBase')}
          className={`rounded-xl border p-5 text-left transition-all ${
            selectedVillage === 'builderBase'
              ? 'border-sky-500 bg-sky-500/12 shadow-lg shadow-sky-500/10'
              : 'border-slate-800 bg-[#121824] hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-sky-400">
              <Wrench className="h-4 w-4" />
              BUILDER BASE
            </span>
            <span className="font-mono text-xs text-slate-400">
              Средний BH: <strong className="text-slate-100">{villageStats.avgBh > 0 ? villageStats.avgBh.toFixed(1) : '—'}</strong>
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Деревня строителя
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-slate-800/80 pt-3 font-mono text-xs tabular-nums">
            <span className="text-sky-300">
              Очки ДС: <strong>{(state.clan.clanBuilderBasePoints ?? 0).toLocaleString('ru-RU')}</strong>
            </span>
            <span className="text-emerald-400">
              Улучшений (API): <strong>{villageStats.eventsByVillage.builderBase}</strong>
            </span>
          </div>
        </button>

        {/* 3. CLAN CAPITAL */}
        <button
          type="button"
          onClick={() => onSelectVillage('clanCapital')}
          className={`rounded-xl border p-5 text-left transition-all ${
            selectedVillage === 'clanCapital'
              ? 'border-emerald-500 bg-emerald-500/12 shadow-lg shadow-emerald-500/10'
              : 'border-slate-800 bg-[#121824] hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-emerald-400">
              <Castle className="h-4 w-4" />
              CLAN CAPITAL
            </span>
            <span className="font-mono text-xs text-slate-400">
              Capital Hall: <strong className="text-slate-100">{state.clan.capitalHallLevel ?? '—'}</strong>
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Столица клана
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-slate-800/80 pt-3 font-mono text-xs tabular-nums">
            <span className="text-emerald-300">
              Очки: <strong>{state.clan.clanCapitalPoints.toLocaleString('ru-RU')}</strong>
            </span>
            <span className="text-amber-300">
              Районов: <strong>{state.clan.capitalDistricts?.length ?? 0}</strong>
            </span>
          </div>
        </button>
      </section>

      {/* HOME VILLAGE */}
      {selectedVillage === 'home' && (
        <div className="space-y-6">
          <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Средняя Ратуша (TH)</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-amber-400">
                {villageStats.avgTh.toFixed(1)}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Макс. Ратуша в клане</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-slate-100">
                TH{villageStats.maxTh}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Очки клана (Home)</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-sky-400">
                {state.clan.clanPoints.toLocaleString('ru-RU')}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Зафиксировано улучшений</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-emerald-400">
                {villageStats.eventsByVillage.home}
              </div>
            </div>
          </section>

          <section className="flex items-start gap-3 rounded-lg border border-slate-800 bg-[#121824] px-4 py-3 text-xs text-slate-300 leading-relaxed">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            <div>
              <strong className="text-slate-100">Данные HOME VILLAGE из Supercell API:</strong> автоматически загружаются Ратуша (<span className="font-mono text-amber-300">townHallLevel</span> и <span className="font-mono text-amber-300">townHallWeaponLevel</span>), все герои, оборудование героев, войска (включая Супер-войска), заклинания, питомцы и осадные машины. Уровни отдельных защитных зданий, ловушек, стен и активные таймеры строителей не передаются официальным Supercell API.
            </div>
          </section>

          {villageActiveUpgrades.length > 0 && (
            <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <h2 className="font-display text-base font-semibold text-slate-100">
                  Активные строительные таймеры HOME VILLAGE ({villageActiveUpgrades.filter((a) => a.status === 'in_progress').length})
                </h2>
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {villageActiveUpgrades.map((item) => {
                  const isInProgress = item.status === 'in_progress';
                  const countdown = isInProgress ? formatCountdownRu(item.estimatedFinishesAt, nowMs) : null;
                  return (
                    <div
                      key={item.id}
                      className={`rounded-lg border p-4 space-y-2 ${
                        isInProgress ? 'border-amber-500/45 bg-[#0B0F17]' : 'border-emerald-500/35 bg-[#0B0F17]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <button
                          type="button"
                          onClick={() => onSelectPlayer(item.playerTag)}
                          className="font-semibold text-slate-100 hover:text-amber-400"
                        >
                          {item.playerName} <span className="font-mono text-slate-500">{item.playerTag}</span>
                        </button>
                        <span className={isInProgress ? 'font-mono font-bold text-amber-400' : 'font-mono font-bold text-emerald-400'}>
                          {isInProgress ? 'УЛУЧШАЕТСЯ' : 'ЗАВЕРШЕНО'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold text-slate-100">{item.objectName}</span>
                        <span className="font-mono text-sm font-bold text-amber-400 tabular-nums">
                          {item.fromLevel} → {item.toLevel}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 font-mono">
                        <span>Источник: {getDataSourceLabel(item.source)}</span>
                        <span>{countdown ? countdown.label : formatDateTimeRu(item.lastConfirmedAt)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* Home Village Member Object Inspector */}
          {activeMember && (
            <section className="space-y-4">
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-100">
                    HOME VILLAGE: {activeMember.name} · TH{activeMember.townHallLevel}
                    {activeMember.townHallWeaponLevel ? ` (Оружие ур. ${activeMember.townHallWeaponLevel})` : ''}
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400 font-mono">
                    Трофеи: {activeMember.trophies.toLocaleString('ru-RU')} (макс. {activeMember.bestTrophies.toLocaleString('ru-RU')}) · API обновлён: {formatDateTimeRu(activeMember.lastSyncedAt)}
                  </p>
                </div>

                <select
                  value={activeMember.tag}
                  onChange={(e) => setSelectedMemberTag(e.target.value)}
                  className="rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  {state.players.map((pl) => (
                    <option key={pl.tag} value={pl.tag}>
                      {pl.name} ({pl.tag} · TH{pl.townHallLevel})
                    </option>
                  ))}
                </select>
              </div>

              {/* Home API Units Grouped */}
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                  <h3 className="font-display text-sm font-semibold text-slate-100">
                    Герои, оборудование, войска, заклинания, питомцы и осадные машины
                  </h3>
                  <span className="font-mono text-[11px] text-emerald-400">Источник: Supercell API</span>
                </div>

                <ApiUnitSubGrid
                  title="Герои Home Village"
                  items={activeMember.apiHeroes.filter((h) => h.village !== 'builderBase')}
                />
                <ApiUnitSubGrid
                  title="Оборудование героев"
                  items={activeMember.apiHeroEquipment}
                />
                <ApiUnitSubGrid
                  title="Войска Home Village"
                  items={activeMember.apiTroops.filter((t) => t.village !== 'builderBase')}
                />
                <ApiUnitSubGrid title="Заклинания" items={activeMember.apiSpells} />
                <ApiUnitSubGrid title="Питомцы героев" items={activeMember.apiPets} />
                <ApiUnitSubGrid title="Осадные машины" items={activeMember.apiSiegeMachines} />
              </div>

              {/* Optional Home JSON Buildings (shown only if imported via Settings) */}
              {activeMember.jsonVillage && (
                <>
                  <JsonObjectsGrid
                    title="Здания и оборона HOME VILLAGE (доп. JSON Export)"
                    entries={activeMember.jsonVillage.homeBuildings}
                  />
                  <JsonObjectsGrid
                    title="Ловушки HOME VILLAGE (доп. JSON Export)"
                    entries={activeMember.jsonVillage.homeTraps}
                  />
                  {activeMember.jsonVillage.homeWallsTotal > 0 && (
                    <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <h3 className="font-display text-sm font-semibold text-slate-100">
                          Стены HOME VILLAGE ({activeMember.jsonVillage.homeWallsTotal} шт.)
                        </h3>
                        <span className="font-mono text-[11px] text-sky-300">Источник: Доп. JSON Export</span>
                      </div>
                      <div className="flex flex-wrap gap-3 font-mono text-xs">
                        {Object.entries(activeMember.jsonVillage.homeWallsByLevel)
                          .sort((a, b) => Number(b[0]) - Number(a[0]))
                          .map(([lv, cnt]) => (
                            <div key={lv} className="rounded border border-slate-800 bg-[#0B0F17] px-3 py-1.5">
                              Ур. {lv}: <strong className="text-amber-400">{cnt} шт.</strong>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </section>
          )}
        </div>
      )}

      {/* BUILDER BASE */}
      {selectedVillage === 'builderBase' && (
        <div className="space-y-6">
          <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Очки клана (Builder Base)</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-sky-400">
                {(state.clan.clanBuilderBasePoints ?? 0).toLocaleString('ru-RU')}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Средний Builder Hall</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-slate-100">
                {villageStats.avgBh > 0 ? villageStats.avgBh.toFixed(1) : '—'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Макс. трофеи ДС в клане</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-amber-300">
                {villageStats.topBbTrophies.toLocaleString('ru-RU')}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Зафиксировано улучшений (BB)</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-emerald-400">
                {villageStats.eventsByVillage.builderBase}
              </div>
            </div>
          </section>

          <section className="flex items-start gap-3 rounded-lg border border-slate-800 bg-[#121824] px-4 py-3 text-xs text-slate-300 leading-relaxed">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
            <div>
              <strong className="text-slate-100">Данные BUILDER BASE из Supercell API:</strong> автоматически загружаются <span className="font-mono text-sky-300">Builder Hall</span>, трофеи и рекорд ДС, лига <span className="font-mono text-sky-300">Builder Base League</span>, герои <span className="font-mono text-sky-300">Battle Machine</span> и <span className="font-mono text-sky-300">Battle Copter</span>, а также все войска Деревни строителя. Таймеры стройки и уровни отдельных пушек/стен ДС официальный Supercell API не передаёт.
            </div>
          </section>

          {villageActiveUpgrades.length > 0 && (
            <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <h2 className="font-display text-base font-semibold text-slate-100">
                  Активные строительные таймеры BUILDER BASE ({villageActiveUpgrades.filter((a) => a.status === 'in_progress').length})
                </h2>
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {villageActiveUpgrades.map((item) => {
                  const isInProgress = item.status === 'in_progress';
                  const countdown = isInProgress ? formatCountdownRu(item.estimatedFinishesAt, nowMs) : null;
                  return (
                    <div
                      key={item.id}
                      className={`rounded-lg border p-4 space-y-2 ${
                        isInProgress ? 'border-sky-500/50 bg-[#0B0F17]' : 'border-emerald-500/35 bg-[#0B0F17]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <button
                          type="button"
                          onClick={() => onSelectPlayer(item.playerTag)}
                          className="font-semibold text-slate-100 hover:text-amber-400"
                        >
                          {item.playerName} <span className="font-mono text-slate-500">{item.playerTag}</span>
                        </button>
                        <span className={isInProgress ? 'font-mono font-bold text-amber-400' : 'font-mono font-bold text-emerald-400'}>
                          {isInProgress ? 'УЛУЧШАЕТСЯ' : 'ЗАВЕРШЕНО'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold text-slate-100">{item.objectName}</span>
                        <span className="font-mono text-base font-bold text-sky-400 tabular-nums">
                          {item.fromLevel} → {item.toLevel}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 font-mono">
                        <span>Источник: {getDataSourceLabel(item.source)}</span>
                        <span>{countdown ? countdown.label : formatDateTimeRu(item.lastConfirmedAt)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* Builder Base Member Inspector */}
          {activeMember && (
            <section className="space-y-4">
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-100">
                    BUILDER BASE: {activeMember.name} · BH{activeMember.builderHallLevel || '—'}
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400 font-mono">
                    Трофеи ДС: {activeMember.builderBaseTrophies.toLocaleString('ru-RU')}
                    {activeMember.bestBuilderBaseTrophies > 0 ? ` (макс. ${activeMember.bestBuilderBaseTrophies.toLocaleString('ru-RU')})` : ''}
                    {activeMember.builderBaseLeague?.name ? ` · ${activeMember.builderBaseLeague.name}` : ''}
                    {' · '}API обновлён: {formatDateTimeRu(activeMember.lastSyncedAt)}
                  </p>
                </div>

                <select
                  value={activeMember.tag}
                  onChange={(e) => setSelectedMemberTag(e.target.value)}
                  className="rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  {state.players.map((pl) => (
                    <option key={pl.tag} value={pl.tag}>
                      {pl.name} ({pl.tag} · BH{pl.builderHallLevel || '—'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Builder Base API Heroes + Troops */}
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                  <h3 className="font-display text-sm font-semibold text-slate-100">
                    Герои и войска Деревни строителя (Battle Machine, Battle Copter, BB Troops)
                  </h3>
                  <span className="font-mono text-[11px] text-emerald-400">Источник: Supercell API</span>
                </div>
                {(() => {
                  const bbHeroes = activeMember.apiHeroes.filter((h) => h.village === 'builderBase');
                  const bbTroops = activeMember.apiTroops.filter((t) => t.village === 'builderBase');
                  if (bbHeroes.length === 0 && bbTroops.length === 0) {
                    return (
                      <p className="text-xs text-slate-500">
                        У этого игрока не обнаружены герои или войска Builder Base в ответе Supercell API.
                      </p>
                    );
                  }
                  return (
                    <div className="space-y-5">
                      <ApiUnitSubGrid title="Герои Деревни строителя" items={bbHeroes} accent="sky" />
                      <ApiUnitSubGrid title="Войска Деревни строителя" items={bbTroops} accent="sky" />
                    </div>
                  );
                })()}
              </div>

              {/* Optional Builder Base JSON Buildings (shown only if imported) */}
              {activeMember.jsonVillage && activeMember.jsonVillage.builderBuildings.length > 0 && (
                <>
                  <JsonObjectsGrid
                    title="Здания и оборона BUILDER BASE (доп. JSON Export)"
                    entries={activeMember.jsonVillage.builderBuildings}
                  />
                  <JsonObjectsGrid
                    title="Ловушки BUILDER BASE (доп. JSON Export)"
                    entries={activeMember.jsonVillage.builderTraps}
                  />
                  {activeMember.jsonVillage.builderWallsTotal > 0 && (
                    <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <h3 className="font-display text-sm font-semibold text-slate-100">
                          Стены BUILDER BASE ({activeMember.jsonVillage.builderWallsTotal} шт.)
                        </h3>
                        <span className="font-mono text-[11px] text-sky-300">Источник: Доп. JSON Export</span>
                      </div>
                      <div className="flex flex-wrap gap-3 font-mono text-xs">
                        {Object.entries(activeMember.jsonVillage.builderWallsByLevel)
                          .sort((a, b) => Number(b[0]) - Number(a[0]))
                          .map(([lv, cnt]) => (
                            <div key={lv} className="rounded border border-slate-800 bg-[#0B0F17] px-3 py-1.5">
                              Ур. {lv}: <strong className="text-sky-400">{cnt} шт.</strong>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </section>
          )}
        </div>
      )}

      {/* CLAN CAPITAL */}
      {selectedVillage === 'clanCapital' && (
        <div className="space-y-6">
          <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Capital Hall</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-emerald-400">
                Ур. {state.clan.capitalHallLevel ?? '—'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Очки столицы</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-amber-400">
                {state.clan.clanCapitalPoints.toLocaleString('ru-RU')}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Лига столицы</div>
              <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
                {state.clan.capitalLeague ?? 'Не определена'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
              <div className="text-xs text-slate-400">Районы столицы</div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-slate-100">
                {state.clan.capitalDistricts?.length ?? 0}
              </div>
            </div>
          </section>

          <section className="flex items-start gap-3 rounded-lg border border-slate-800 bg-[#121824] px-4 py-3 text-xs text-slate-300 leading-relaxed">
            <Shield className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
            <div>
              <strong className="text-slate-100">Данные CLAN CAPITAL из Supercell API:</strong> передаются уровень <span className="font-mono text-emerald-300">Capital Hall</span>, все открытые районы (<span className="font-mono">Districts</span>) и суммарный вклад каждого участника (<span className="font-mono">clanCapitalContributions</span>). Официальный API не передаёт таймеры улучшений и не указывает автора конкретного вложения в здание Столицы.
            </div>
          </section>

          <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Районы Столицы клана
              </h2>
              <span className="font-mono text-[11px] text-emerald-400">Источник: Supercell API</span>
            </div>

            {state.clan.capitalDistricts && state.clan.capitalDistricts.length > 0 ? (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {state.clan.capitalDistricts.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center justify-between rounded-lg border border-slate-800 bg-[#0B0F17] px-4 py-3"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-100">{d.name}</div>
                      <div className="font-mono text-[11px] text-slate-500">ID {d.id}</div>
                    </div>
                    <span className="font-mono text-base font-bold text-emerald-400 tabular-nums">
                      Ур. {d.districtHallLevel}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400">
                {state.clan.level < 2
                  ? `У клана сейчас ${state.clan.level}-й уровень (Столица клана в Clash of Clans открывается со 2-го уровня клана).`
                  : 'Районы Столицы ещё не открыты или не получены в ответе Supercell API.'}
              </p>
            )}
          </section>
        </div>
      )}

      {/* VILLAGE-SPECIFIC UPGRADE HISTORY */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-5 py-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              История улучшений — {selectedVillage === 'home' ? 'HOME VILLAGE' : selectedVillage === 'builderBase' ? 'BUILDER BASE' : 'CLAN CAPITAL'} ({villageHistoryEvents.length})
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Показываются только улучшения, относящиеся к выбранной деревне (данные других деревень не смешиваются)
            </p>
          </div>
          <span className="font-mono text-xs text-slate-400">
            Обновлено: {formatRelativeTimeRu(state.clan.lastSyncedAt, nowMs)}
          </span>
        </div>

        {villageHistoryEvents.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            В этой деревне пока не зафиксировано завершённых повышений уровня. После синхронизации Supercell API новые повышения появятся здесь.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70">
            {villageHistoryEvents.slice(0, 40).map((ev) => {
              const dt = resolveUpgradeDetailType(ev);
              const objName = ev.apiName || ev.itemNameRu;
              return (
                <div
                  key={ev.id}
                  className="flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <CocUnitBadge
                      detailType={dt}
                      apiName={objName}
                      isSuperTroop={ev.isSuperTroop}
                      size="md"
                    />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        {selectedVillage === 'clanCapital' ? (
                          <span className="font-semibold text-emerald-300">{ev.playerName}</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectPlayer(ev.playerTag)}
                            className="font-semibold text-slate-100 hover:text-amber-400"
                          >
                            {ev.playerName}
                          </button>
                        )}
                        <span className="font-mono text-slate-500">{ev.playerTag}</span>
                        <span className="text-slate-600">·</span>
                        <span className="text-sky-300 font-mono text-[11px]">
                          {getDataSourceLabel(ev.source)}
                        </span>
                      </div>
                      <div className="mt-0.5 text-sm font-bold text-amber-400">
                        {objName}
                        {ev.instanceNumber ? ` #${ev.instanceNumber}` : ''}
                      </div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                        <span>{getUpgradeCategoryShortLabel(dt)}</span>
                        <span>·</span>
                        <span className="inline-flex items-center gap-1 font-mono">
                          <Clock className="h-3 w-3 text-slate-500" />
                          {formatDateTimeRu(ev.detectedAt || ev.timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 font-mono text-sm font-bold tabular-nums shrink-0 pl-12 sm:pl-0">
                    <span className="text-slate-400">Ур. {ev.fromLevel}</span>
                    <ArrowRight className="h-4 w-4 text-emerald-400" />
                    <span className="text-lg text-emerald-400">{ev.toLevel}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
