import React, { useState } from 'react';
import {
  Plane as PlaneIcon,
  X,
  Plus,
  ArrowRightLeft,
  Navigation,
  MapPin,
  TrendingUp,
  Clock,
  Sparkles
} from 'lucide-react';
import {
  Plane,
  CITY_MAP,
  AirportCity,
  calculateDistance,
  calculateFlightDuration,
  calculateFlightRevenue,
  getNewPlaneCost,
  getAircraftTierName,
  LIVERY_MAP
} from '../game/flightLogic';
import { sound } from '../game/sound';

interface FleetDrawerProps {
  planes: Plane[];
  unlockedCities: AirportCity[];
  speedLevel: number;
  moneyMakerLevel: number;
  capacityLevel: number;
  cash: number;
  selectedPlaneId: string | null;
  onSelectPlane: (planeId: string) => void;
  onAssignRoute: (planeId: string, fromId: string, toId: string) => void;
  onBuyPlane: () => void;
  onOpenLiveries?: () => void;
  onClose: () => void;
}

export const FleetDrawer: React.FC<FleetDrawerProps> = ({
  planes,
  unlockedCities,
  speedLevel,
  moneyMakerLevel,
  capacityLevel,
  cash,
  selectedPlaneId,
  onSelectPlane,
  onAssignRoute,
  onBuyPlane,
  onOpenLiveries,
  onClose
}) => {
  const [editingPlaneId, setEditingPlaneId] = useState<string | null>(null);
  const [routeFromId, setRouteFromId] = useState<string>('sfo');
  const [routeToId, setRouteToId] = useState<string>('lax');

  const newPlaneCost = getNewPlaneCost(planes.length);
  const canAffordNewPlane = cash >= newPlaneCost;

  const startRouteEdit = (plane: Plane) => {
    setEditingPlaneId(plane.id);
    setRouteFromId(plane.fromCityId);
    setRouteToId(plane.toCityId);
  };

  const saveRouteEdit = (planeId: string) => {
    if (routeFromId && routeToId && routeFromId !== routeToId) {
      onAssignRoute(planeId, routeFromId, routeToId);
      setEditingPlaneId(null);
      sound.playClick();
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#0a0b10] border-l border-[#27272a] shadow-2xl flex flex-col text-white animate-in slide-in-from-right duration-200">
      {/* Drawer Header */}
      <div className="flex items-center justify-between p-5 border-b border-[#27272a]">
        <div>
          <h2 className="font-mono text-base font-bold tracking-tight">COMMERCIAL FLEET</h2>
          <p className="text-xs text-[#71717a] font-mono mt-0.5">
            {planes.length} Active Aircraft · {getAircraftTierName(capacityLevel)}
          </p>
        </div>
        <button
          onClick={onClose}
          aria-label="Close Fleet Panel"
          className="p-1.5 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-lg transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>
      </div>

      {/* Planes List */}
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-4">
        {/* Livery Hangar Quick Entry Banner */}
        {onOpenLiveries && (
          <div
            onClick={onOpenLiveries}
            className="p-3.5 rounded-xl bg-gradient-to-r from-red-950/40 via-[#181924] to-[#12131b] border border-red-900/50 hover:border-red-500/70 cursor-pointer transition-all flex items-center justify-between group shadow-sm"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-red-900/50 border border-red-700/60 flex items-center justify-center text-red-200">
                <Sparkles size={16} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-mono text-xs font-bold text-white group-hover:text-red-300 transition-colors">
                    FLIGHT LIVERY HANGAR
                  </h3>
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#20212e] border border-[#3f3f46] text-[#a1a1aa] font-bold">
                    SPECIAL SKINS
                  </span>
                </div>
                <p className="text-[11px] text-[#a1a1aa]">
                  Redeem secret codes & equip festive aircraft skins
                </p>
              </div>
            </div>
            <span className="text-xs font-mono text-white/80 group-hover:translate-x-0.5 transition-transform">
              →
            </span>
          </div>
        )}

        {planes.map(plane => {
          const fromCity = CITY_MAP.get(plane.fromCityId);
          const toCity = CITY_MAP.get(plane.toCityId);
          if (!fromCity || !toCity) return null;

          const distanceKm = calculateDistance(fromCity.lat, fromCity.lng, toCity.lat, toCity.lng);
          const flightDuration = calculateFlightDuration(distanceKm, speedLevel);
          const flightRev = calculateFlightRevenue(distanceKm, moneyMakerLevel, capacityLevel);
          const isSelected = selectedPlaneId === plane.id;
          const isEditing = editingPlaneId === plane.id;
          const livery = LIVERY_MAP.get(plane.liveryId || 'default');
          const isChristmas = livery?.id === 'christmas';

          return (
            <div
              key={plane.id}
              className={`p-4 rounded-xl border transition-all ${
                isSelected
                  ? 'bg-[#14151e] border-white'
                  : 'bg-[#111218] border-[#27272a] hover:border-[#3f3f46]'
              }`}
            >
              {/* Plane Header */}
              <div className="flex items-center justify-between">
                <div
                  className="flex items-center gap-2.5 cursor-pointer"
                  onClick={() => onSelectPlane(plane.id)}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden ${
                      isChristmas
                        ? 'bg-red-950/80 border border-red-700/80'
                        : 'bg-[#1e202b] text-white'
                    }`}
                  >
                    {isChristmas ? (
                      <img
                        src="/assets/aistudio/file_00000000eaf88211a0090db038da8bda_6d662669.png"
                        alt="Christmas Flight skin 2026"
                        className="w-7 h-7 object-contain"
                      />
                    ) : (
                      <PlaneIcon size={14} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-mono font-bold text-sm text-white">{plane.name}</h3>
                      {livery && (
                        <span
                          className={`text-[9px] font-mono px-1.5 py-0.2 rounded border ${
                            isChristmas
                              ? 'bg-red-950/80 border-red-700 text-red-200 font-bold'
                              : 'bg-[#181924] border-[#27272a] text-[#a1a1aa]'
                          }`}
                        >
                          {livery.name}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#a1a1aa]">
                      <span>{plane.totalFlightsCompleted} Flights</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">${plane.totalEarnings.toLocaleString()} earned</span>
                    </div>
                  </div>
                </div>

                {!isEditing && (
                  <div className="flex items-center gap-1.5">
                    {onOpenLiveries && (
                      <button
                        onClick={() => {
                          onSelectPlane(plane.id);
                          onOpenLiveries();
                        }}
                        title="Change Aircraft Livery / Skin"
                        className="p-1.5 bg-[#181922] hover:bg-[#232532] text-xs font-mono text-[#a1a1aa] hover:text-white rounded-lg border border-[#27272a] transition-colors cursor-pointer"
                      >
                        <Sparkles size={13} />
                      </button>
                    )}
                    <button
                      onClick={() => startRouteEdit(plane)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#181922] hover:bg-[#232532] text-xs font-mono text-white rounded-lg border border-[#27272a] transition-colors cursor-pointer"
                    >
                      <ArrowRightLeft size={12} />
                      <span>Route</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Editing Route Mode */}
              {isEditing ? (
                <div className="mt-3 p-3 bg-[#0a0a0e] rounded-lg border border-[#27272a] space-y-3">
                  <span className="text-xs font-mono text-[#a1a1aa] block">
                    ASSIGN ROUTE FOR {plane.name.toUpperCase()}:
                  </span>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-mono text-[#71717a] block mb-1">ORIGIN CITY</label>
                      <select
                        value={routeFromId}
                        onChange={e => setRouteFromId(e.target.value)}
                        className="w-full bg-[#181922] border border-[#27272a] rounded px-2.5 py-1.5 text-xs text-white font-mono focus:border-white focus:outline-none"
                      >
                        {unlockedCities.map(c => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.code})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-mono text-[#71717a] block mb-1">DESTINATION CITY</label>
                      <select
                        value={routeToId}
                        onChange={e => setRouteToId(e.target.value)}
                        className="w-full bg-[#181922] border border-[#27272a] rounded px-2.5 py-1.5 text-xs text-white font-mono focus:border-white focus:outline-none"
                      >
                        {unlockedCities.map(c => (
                          <option key={c.id} value={c.id} disabled={c.id === routeFromId}>
                            {c.name} ({c.code})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      onClick={() => setEditingPlaneId(null)}
                      className="px-3 py-1.5 text-xs text-[#a1a1aa] hover:text-white font-mono"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => saveRouteEdit(plane.id)}
                      disabled={routeFromId === routeToId}
                      className={`px-3 py-1.5 text-xs font-mono font-semibold rounded ${
                        routeFromId !== routeToId
                          ? 'bg-white text-black hover:bg-[#e4e4e7]'
                          : 'bg-[#18181b] text-[#52525b] cursor-not-allowed'
                      }`}
                    >
                      Confirm Route
                    </button>
                  </div>
                </div>
              ) : (
                /* Route Summary & Progress */
                <div className="mt-3 space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1.5 text-white">
                      <span className="font-bold">{fromCity.code}</span>
                      <span className="text-[#71717a]">⇄</span>
                      <span className="font-bold">{toCity.code}</span>
                      <span className="text-[#a1a1aa] text-[11px]">({fromCity.name} - {toCity.name})</span>
                    </div>
                    <span className="text-white font-semibold tabular-nums">+${flightRev}</span>
                  </div>

                  {/* Flight Progress Bar */}
                  <div className="w-full h-1.5 bg-[#1f2029] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
                      style={{ width: `${Math.round(plane.progress * 100)}%` }}
                    />
                  </div>

                  {/* Flight telemetry */}
                  <div className="flex items-center justify-between text-[11px] font-mono text-[#71717a]">
                    <span>{distanceKm.toLocaleString()} km</span>
                    <span>~{flightDuration.toFixed(1)}s est</span>
                    <span>{plane.isReturning ? 'Returning' : 'Outbound'}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Buy Plane Quick Action */}
        <div className="p-4 border border-dashed border-[#27272a] hover:border-white rounded-xl bg-[#0c0d12] flex flex-col items-center text-center gap-2 transition-colors">
          <PlaneIcon size={24} className="text-[#71717a]" />
          <div>
            <h4 className="font-semibold text-sm text-white">Add New Aircraft</h4>
            <p className="text-xs text-[#a1a1aa] mt-0.5">
              Cost: ${newPlaneCost.toLocaleString()} · Expand to {planes.length + 1} planes
            </p>
          </div>
          <button
            onClick={() => {
              if (canAffordNewPlane) {
                onBuyPlane();
                sound.playUpgrade();
              }
            }}
            disabled={!canAffordNewPlane}
            className={`mt-2 px-4 py-2 rounded-lg font-mono text-xs font-semibold transition-all ${
              canAffordNewPlane
                ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
            }`}
          >
            +1 PLANE (${newPlaneCost.toLocaleString()})
          </button>
        </div>
      </div>
    </div>
  );
};
