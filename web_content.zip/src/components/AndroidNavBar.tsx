import React from 'react';
import { Home, Package, Plus, BarChart3, Settings } from 'lucide-react';
import { feedback } from '../utils/haptics';

export type TabType = 'home' | 'items' | 'add' | 'rep' | 'set';

interface AndroidNavBarProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
  lowStockCount?: number;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({
  currentTab,
  onChangeTab,
  lowStockCount = 0,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const tabs = [
    { id: 'home' as TabType, label: 'Home', icon: Home },
    { id: 'items' as TabType, label: 'Inventory', icon: Package, badge: lowStockCount },
    { id: 'add' as TabType, label: 'Add', icon: Plus, isFab: true },
    { id: 'rep' as TabType, label: 'Reports', icon: BarChart3 },
    { id: 'set' as TabType, label: 'Settings', icon: Settings },
  ];

  const handleSelect = (tabId: TabType) => {
    feedback.vibrateSoft(hapticsEnabled);
    feedback.playTap(soundEnabled);
    onChangeTab(tabId);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-[max(env(safe-area-inset-bottom,0px),8px)] pt-1 select-none">
      <div className="max-w-md mx-auto flex items-end justify-around px-2">
        {tabs.map((t) => {
          const isActive = currentTab === t.id;
          const Icon = t.icon;

          if (t.isFab) {
            return (
              <button
                key={t.id}
                onClick={() => handleSelect(t.id)}
                className="group flex flex-col items-center -mt-5 relative focus:outline-hidden"
                aria-label="Add sale, purchase or item"
              >
                <div className={`w-13 h-13 rounded-full flex items-center justify-center text-white shadow-lg transition-transform duration-200 group-active:scale-90 ${
                  isActive
                    ? 'bg-rose-700 ring-4 ring-red-200 dark:ring-red-900/50'
                    : 'bg-[#d9262c] hover:bg-red-700 shadow-red-600/30'
                }`}>
                  <Plus className="w-7 h-7 stroke-[2.5]" />
                </div>
                <span className={`text-[10px] mt-1 font-semibold ${isActive ? 'text-[#d9262c]' : 'text-slate-500 dark:text-slate-400'}`}>
                  {t.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={t.id}
              onClick={() => handleSelect(t.id)}
              className="flex-1 py-1.5 flex flex-col items-center justify-center relative focus:outline-hidden text-center group"
            >
              <div
                className={`relative px-4 py-1 rounded-full transition-all duration-200 flex items-center justify-center ${
                  isActive
                    ? 'bg-red-100 dark:bg-red-950/60 text-[#d9262c] dark:text-red-400 scale-105'
                    : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.3]' : 'stroke-[1.8]'}`} />
                {Boolean(t.badge && t.badge > 0) && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.2 min-w-4 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                    {t.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] tracking-tight mt-0.5 transition-colors ${
                  isActive
                    ? 'font-bold text-[#d9262c] dark:text-red-400'
                    : 'font-medium text-slate-500 dark:text-slate-400'
                }`}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
