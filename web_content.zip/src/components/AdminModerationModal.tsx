import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { filterProfanity } from '../utils/security';
import { 
  X, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Trash2, 
  UserX, 
  Search, 
  Lock 
} from 'lucide-react';

export const AdminModerationModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { reportedPosts, confessions, deleteConfessionAsAdmin, user } = useApp();
  const [testText, setTestText] = useState('This is a test message to see how abusive words get censored.');

  if (!isOpen) return null;

  const testResult = filterProfanity(testText);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-2xl bg-[#0e111d] border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-cyan-950/40 relative max-h-[90vh] overflow-y-auto space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                Safety Engine & Moderation Console
              </h3>
              <p className="text-[11px] text-slate-400">
                Automated word filtering & anonymous shadowban logs
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Filter Sandbox */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Live AI Word Filter Simulator
          </h4>
          <input
            type="text"
            value={testText}
            onChange={(e) => setTestText(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
          />
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs">
            <span className="text-[10px] text-slate-500 block mb-0.5">Filter Result:</span>
            <p className="text-cyan-300 font-mono">{testResult.censoredText}</p>
            <div className="mt-2 flex items-center gap-2 text-[10px]">
              <span className={`px-2 py-0.5 rounded-full ${testResult.isClean ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                {testResult.isClean ? 'Status: Clean' : `Flagged: ${testResult.flaggedKeywords.join(', ')}`}
              </span>
            </div>
          </div>
        </div>

        {/* Reported Content Queue */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Community Report Queue ({reportedPosts.length})</span>
          </h4>

          {reportedPosts.length === 0 ? (
            <p className="p-6 text-center text-xs text-slate-500 bg-slate-900/40 rounded-xl border border-slate-800">
              Zero pending reports. The campus ecosystem is clean and peaceful.
            </p>
          ) : (
            <div className="space-y-2 max-h-52 overflow-y-auto">
              {reportedPosts.map(rep => (
                <div key={rep.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-rose-400">
                    <span className="font-semibold">{rep.reason}</span>
                    <span className="font-mono text-slate-500">{rep.authorHash}</span>
                  </div>
                  <p className="text-slate-300 italic">"{rep.content}"</p>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-emerald-400 font-semibold">Automated strike applied</span>
                    <button
                      onClick={() => deleteConfessionAsAdmin(rep.confessionId)}
                      className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[10px] font-bold flex items-center gap-1 transition-all"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove Post</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-3 rounded-2xl bg-indigo-950/30 border border-indigo-500/20 text-xs text-indigo-300">
          <p className="leading-relaxed">
            <strong>System-Level Ban Policy:</strong> Repeat offenders have their client cryptographic tokens silently restricted across college feeds without ever leaking their real identity or college records.
          </p>
        </div>

      </div>
    </div>
  );
};
