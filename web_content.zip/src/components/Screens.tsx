import { useState } from "react";
import { ENDINGS, type HighScore } from "../game/engine";
import type { Ending, GameState } from "../game/types";

export function StartScreen({
  onStart,
  onContinue,
  hasSave,
  scores,
  name,
  setName,
}: {
  onStart: () => void;
  onContinue: () => void;
  hasSave: boolean;
  scores: HighScore[];
  name: string;
  setName: (n: string) => void;
}) {
  return (
    <div className="scanlines vignette absolute inset-0 z-50 overflow-y-auto bg-[radial-gradient(ellipse_at_top,#241634_0%,#0b0812_60%)]">
      <div className="mx-auto flex min-h-full max-w-3xl flex-col items-center px-4 py-8">
        <div className="mb-1 text-center">
          <div className="mono text-[10px] uppercase tracking-[0.5em] text-[#9d8fb0]">
            Robert Greene &middot; Um RPG de intriga medieval
          </div>
          <h1
            className="gold glow-gold mt-2 text-4xl font-bold tracking-wide sm:text-6xl"
            style={{ textShadow: "0 4px 0 #3a2a12, 0 0 26px rgba(232,192,106,0.35)" }}
          >
            O CAMINHO DO PODER
          </h1>
          <div className="mono mt-2 text-[11px] uppercase tracking-[0.3em] text-[#c79ae8]">
            As 48 Leis do Poder
          </div>
        </div>

        <p className="mt-4 max-w-xl text-center text-[13px] leading-relaxed text-[#c9bcd8]">
          Você nasce na Vila de Cinzas, sem nome e sem cédula. Em quarenta e oito desafios vai
          atravessar vilas, tavernas, conselhos e o próprio Salão do Trono. Cada escolha cria
          aliados, ódios ou crises — e o reino nunca esquece.
        </p>

        <div className="panel mt-6 w-full max-w-md p-4">
          <label className="panel-title mb-1 block">Seu nome no reino</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 22))}
            placeholder="Sem Nome"
            className="w-full border-2 border-[#4a3a5e] bg-[#140e1e] px-3 py-2 text-[14px] text-[#f7e3a8] outline-none focus:border-[#e8c06a]"
          />
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <button className="btn btn-primary flex-1 py-2" onClick={onStart}>
              Novo Jogo
            </button>
            <button className="btn flex-1 py-2" disabled={!hasSave} onClick={onContinue}>
              Continuar
            </button>
          </div>
        </div>

        <div className="panel mt-4 w-full max-w-md p-4">
          <div className="panel-title mb-2">Melhores jornadas</div>
          {scores.length === 0 ? (
            <p className="text-[12px] italic text-[#6f6380]">
              Ninguém ainda marcou seu nome na história deste reino.
            </p>
          ) : (
            <table className="w-full text-[12px]">
              <tbody>
                {scores.map((s, i) => (
                  <tr key={i} className="border-b border-[#2c2139]">
                    <td className="py-1 pr-2 text-[#e8c06a]">{i + 1}.</td>
                    <td className="py-1 pr-2 text-[#ecdcb8]">{s.name}</td>
                    <td className="py-1 pr-2 text-[10px] text-[#9d8fb0]">{s.ending}</td>
                    <td className="mono py-1 text-right text-[#e8c06a]">{s.score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="mono mt-4 max-w-md text-center text-[10px] leading-relaxed text-[#7a6b8f]">
          WASD / SETAS: mover &middot; E ou ESPAÇO: conversar &middot; I: inventário &middot; R: relações
          <br /> J: diário das leis &middot; M: mapa &middot; ESC: pausa &middot; No celular, use o direcional
        </div>
      </div>
    </div>
  );
}

export function PauseOverlay({
  onResume,
  onSave,
  onLoad,
  onRestart,
  onTitle,
  muted,
  onToggleMute,
  state,
}: {
  onResume: () => void;
  onSave: () => void;
  onLoad: () => void;
  onRestart: () => void;
  onTitle: () => void;
  muted: boolean;
  onToggleMute: () => void;
  state: GameState;
}) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-[2px]">
      <div className="panel pop w-full max-w-sm p-5">
        <div className="panel-title text-center">Pausa</div>
        <h2 className="gold mt-1 text-center text-2xl font-bold">O tempo espera</h2>
        <div className="mono mt-3 space-y-1 text-center text-[11px] text-[#9d8fb0]">
          <div>Pontos de poder: <span className="text-[#e8c06a]">{state.score}</span></div>
          <div>Leis dominadas: {state.completedMissions.length}/48</div>
          <div>
            {state.stats.influence} influ &middot; {state.stats.reputation} rep &middot;{" "}
            {state.stats.power} poder
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn btn-primary col-span-2 py-2" onClick={onResume}>
            Continuar
          </button>
          <button className="btn py-2" onClick={onSave}>
            Salvar
          </button>
          <button className="btn py-2" onClick={onLoad}>
            Carregar
          </button>
          <button className="btn py-2" onClick={onToggleMute}>
            {muted ? "Som: desligado" : "Som: ligado"}
          </button>
          <button className="btn btn-danger py-2" onClick={onRestart}>
            Reiniciar
          </button>
          <button className="btn col-span-2 py-2" onClick={onTitle}>
            Voltar ao Título
          </button>
        </div>
      </div>
    </div>
  );
}

export function GameOverScreen({
  title,
  reason,
  score,
  onRestart,
  onTitle,
}: {
  title: string;
  reason: string;
  score: number;
  onRestart: () => void;
  onTitle: () => void;
}) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,#2a0f16_0%,#08060c_70%)] p-4">
      <div className="panel pop w-full max-w-md p-6 text-center">
        <div className="mono text-[10px] uppercase tracking-[0.4em] text-[#a8323f]">Fim de jogo</div>
        <h2 className="glow-crimson mt-2 text-3xl font-bold text-[#e07a6a]">{title}</h2>
        <p className="mt-3 text-[13px] leading-relaxed text-[#c9bcd8]">{reason}</p>
        <div className="mono mt-3 text-[12px] text-[#e8c06a]">Pontos de poder: {score}</div>
        <div className="mt-5 flex flex-col gap-2">
          <button className="btn btn-primary py-2" onClick={onRestart}>
            Tentar de novo [R]
          </button>
          <button className="btn py-2" onClick={onTitle}>
            Voltar ao Título
          </button>
        </div>
      </div>
    </div>
  );
}

export function EndScreen({
  ending,
  state,
  onRestart,
  onTitle,
  onSaveScore,
  saved,
}: {
  ending: Ending;
  state: GameState;
  onRestart: () => void;
  onTitle: () => void;
  onSaveScore: (name: string) => void;
  saved: boolean;
}) {
  const info = ENDINGS[ending];
  const [name, setName] = useState(state.playerName || "Sem Nome");
  return (
    <div className="scanlines absolute inset-0 z-50 overflow-y-auto bg-[radial-gradient(ellipse_at_top,#2a2038_0%,#08060c_65%)]">
      <div className="mx-auto flex min-h-full max-w-2xl flex-col items-center px-4 py-10 text-center">
        <div className="mono text-[10px] uppercase tracking-[0.45em] text-[#9d8fb0]">Fim da jornada</div>
        <h1
          className={`mt-2 text-3xl font-bold sm:text-5xl ${info.tone === "bad" ? "glow-crimson text-[#e07a6a]" : "gold glow-gold"}`}
        >
          {info.title}
        </h1>
        <p className="mt-4 max-w-xl text-[14px] leading-relaxed text-[#c9bcd8]">{info.text}</p>

        <div className="panel mt-6 grid w-full max-w-lg grid-cols-2 gap-2 p-4 sm:grid-cols-3">
          {[
            ["Pontos de poder", state.score],
            ["Leis dominadas", `${state.completedMissions.length}/48`],
            ["Influência", state.stats.influence],
            ["Reputação", state.stats.reputation],
            ["Inteligência", state.stats.intelligence],
            ["Riqueza", state.stats.wealth],
            ["Poder político", state.stats.power],
            ["Aliados jurados", Object.values(state.npcs).filter((n) => n.loyalty >= 60).length],
            ["Inimigos", Object.values(state.npcs).filter((n) => n.trust <= 10).length],
          ].map(([k, v]) => (
            <div key={String(k)} className="border border-[#3a2b4c] bg-[#1d1528] px-2 py-2">
              <div className="text-[9px] uppercase tracking-wider text-[#9d8fb0]">{k}</div>
              <div className="mono text-[16px] text-[#e8c06a]">{v}</div>
            </div>
          ))}
        </div>

        {!saved && (
          <div className="panel mt-4 w-full max-w-sm p-4">
            <div className="panel-title mb-1">Registre seu nome nos anais</div>
            <input
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 22))}
              className="w-full border-2 border-[#4a3a5e] bg-[#140e1e] px-3 py-2 text-[14px] text-[#f7e3a8] outline-none focus:border-[#e8c06a]"
            />
            <button className="btn btn-primary mt-2 w-full py-2" onClick={() => onSaveScore(name)}>
              Salvar no ranking
            </button>
          </div>
        )}

        <div className="mt-6 flex flex-col gap-2 sm:flex-row">
          <button className="btn btn-primary px-6 py-2" onClick={onRestart}>
            Jogar novamente
          </button>
          <button className="btn px-6 py-2" onClick={onTitle}>
            Voltar ao Título
          </button>
        </div>
      </div>
    </div>
  );
}
