import { CSSProperties, ReactNode, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Check,
  ChevronRight,
  Droplets,
  Grid3X3,
  Lock,
  Medal,
  Play,
  RotateCcw,
  Settings,
  Sparkles,
  Star,
  Trophy,
  Volume2,
  VolumeX,
  Waves,
  X,
} from "lucide-react";
import {
  formatTime,
  getDifficulty,
  getLevelColorCount,
  LIQUID_COLORS,
  SkinId,
  skinIsUnlocked,
  TOTAL_LEVELS,
  TUBE_SKINS,
} from "../game";
import {
  AudioSettings,
  Progress,
  totalScore,
  totalStars,
} from "../storage";
import { audio } from "../audio";
import TubeGraphic from "./Tube";

interface HomeProps {
  progress: Progress;
  onPlay: () => void;
  onLevels: () => void;
  onProgress: () => void;
  onScores: () => void;
  onSettings: () => void;
  onToggleSound: () => void;
}

export function HomeScreen({ progress, onPlay, onLevels, onProgress, onScores, onSettings, onToggleSound }: HomeProps) {
  const completed = Object.keys(progress.completed).length;
  const stars = totalStars(progress);
  const next = Math.min(progress.unlocked, TOTAL_LEVELS);
  return (
    <main className="home-screen screen">
      <div className="home-top-actions">
        <button className="icon-button glass-button" onClick={onToggleSound} aria-label={progress.settings.sound ? "Mute sound" : "Turn sound on"}>
          {progress.settings.sound ? <Volume2 size={20} /> : <VolumeX size={20} />}
        </button>
        <button className="icon-button glass-button" onClick={onSettings} aria-label="Open settings"><Settings size={20} /></button>
      </div>

      <section className="home-hero">
        <div className="brand-mark"><Droplets /><i /><i /></div>
        <div className="brand-copy">
          <span className="brand-kicker">A premium underwater puzzle</span>
          <h1><span>AQUA</span><strong>SORT</strong></h1>
          <p>Pour a little calm into your day.</p>
        </div>
        <div className="hero-tubes" aria-hidden="true">
          <div className="hero-tube hero-tube-one"><TubeGraphic tube={[0, 0, 2, 2]} skin={progress.selectedSkin} /></div>
          <div className="hero-tube hero-tube-two"><TubeGraphic tube={[2, 2, 0, 0]} skin={progress.selectedSkin} /></div>
          <div className="hero-tube hero-tube-three"><TubeGraphic tube={[]} skin={progress.selectedSkin} /></div>
          <svg className="hero-water-arc" viewBox="0 0 200 100"><path d="M48 16 Q98 75 153 55" /><path d="M48 16 Q98 75 153 55" /></svg>
        </div>
      </section>

      <section className="home-actions">
        <button className="primary-button dive-button" onClick={onPlay}>
          <span className="button-play-icon"><Play fill="currentColor" size={20} /></span>
          <span><strong>{completed ? "Continue Dive" : "Begin Dive"}</strong><small>Level {next} · {getDifficulty(next)}</small></span>
          <ArrowRight size={21} />
        </button>
        <div className="home-menu-grid">
          <button className="menu-button glass-panel" onClick={onLevels}><Grid3X3 /><span><strong>All Levels</strong><small>120 solvable puzzles</small></span><ChevronRight /></button>
          <button className="menu-button glass-panel" onClick={onProgress}><Medal /><span><strong>My Progress</strong><small>Stats & glass skins</small></span><ChevronRight /></button>
        </div>
        <button className="text-button home-score-link" onClick={onScores}><Trophy size={16} /> Local high scores</button>
      </section>

      <section className="home-stats glass-panel" aria-label="Saved progress summary">
        <div><strong>{completed}<small>/120</small></strong><span>Completed</span></div>
        <div><strong>{stars}<small>/360</small></strong><span>Stars</span></div>
        <div><strong>{totalScore(progress).toLocaleString()}</strong><span>Total score</span></div>
      </section>
      <p className="audio-disclosure"><Waves size={13} /> Procedural water audio · no downloads</p>
    </main>
  );
}

function ScreenHeader({ title, subtitle, onBack, action }: { title: string; subtitle: string; onBack: () => void; action?: ReactNode }) {
  return (
    <header className="screen-header">
      <button className="icon-button glass-button" onClick={onBack} aria-label="Go back"><ArrowLeft size={20} /></button>
      <div><span>{subtitle}</span><h2>{title}</h2></div>
      {action ?? <span className="header-spacer" />}
    </header>
  );
}

interface LevelSelectProps {
  progress: Progress;
  onBack: () => void;
  onPlay: (level: number) => void;
}

export function LevelSelectScreen({ progress, onBack, onPlay }: LevelSelectProps) {
  const [category, setCategory] = useState<"Easy" | "Medium" | "Hard">(getDifficulty(progress.unlocked));
  const ranges = { Easy: [1, 40], Medium: [41, 80], Hard: [81, 120] };
  const [start, end] = ranges[category];
  const levels = Array.from({ length: end - start + 1 }, (_, index) => start + index);
  const completedInCategory = levels.filter((level) => progress.completed[level]).length;
  return (
    <main className="levels-screen screen scroll-screen">
      <ScreenHeader title="Choose a Dive" subtitle={`${Object.keys(progress.completed).length} of 120 complete`} onBack={onBack} />
      <div className="difficulty-tabs glass-panel" role="tablist" aria-label="Difficulty">
        {(["Easy", "Medium", "Hard"] as const).map((item) => (
          <button key={item} role="tab" aria-selected={category === item} className={category === item ? "active" : ""} onClick={() => { setCategory(item); audio.clink(); }}>
            {item}<small>{item === "Easy" ? "1–40" : item === "Medium" ? "41–80" : "81–120"}</small>
          </button>
        ))}
      </div>
      <div className="category-summary">
        <div><span className={`difficulty-dot ${category.toLowerCase()}`} /><strong>{category} Currents</strong></div>
        <span>{completedInCategory}/40 completed</span>
      </div>
      <section className="level-grid" aria-label={`${category} levels`}>
        {levels.map((level) => {
          const record = progress.completed[level];
          const unlocked = level <= progress.unlocked;
          const current = unlocked && !record && level === progress.unlocked;
          return (
            <button
              key={level}
              className={`level-button ${record ? "completed" : ""} ${current ? "current" : ""} ${!unlocked ? "locked" : ""}`}
              disabled={!unlocked}
              onClick={() => onPlay(level)}
              aria-label={unlocked ? `Play level ${level}${record ? `, best ${record.bestMoves} moves, ${record.stars} stars` : ""}` : `Level ${level} locked`}
            >
              {!unlocked ? <Lock size={17} /> : record ? <Check className="level-check" size={14} /> : null}
              <strong>{level}</strong>
              {record ? (
                <span className="level-stars" aria-hidden="true">
                  {[0, 1, 2].map((star) => <Star key={star} size={9} fill={star < record.stars ? "currentColor" : "none"} className={star < record.stars ? "earned" : ""} />)}
                </span>
              ) : unlocked ? (
                <span className="color-dots" aria-hidden="true">
                  {(() => {
                    const count = getLevelColorCount(level);
                    const dots = Math.min(4, count);
                    // Spread sample across the palette so new colors preview too.
                    return Array.from({ length: dots }, (_, i) => {
                      const colorIndex = dots === 1 ? 0 : Math.round((i / (dots - 1)) * (count - 1));
                      return <i key={i} style={{ background: LIQUID_COLORS[colorIndex].base }} />;
                    });
                  })()}
                </span>
              ) : <small>Locked</small>}
            </button>
          );
        })}
      </section>
      <p className="level-footnote"><Sparkles size={14} /> Complete a level to unlock the next. Every puzzle has a guaranteed solution.</p>
    </main>
  );
}

interface ProgressProps {
  progress: Progress;
  onBack: () => void;
  onScores: () => void;
  onSelectSkin: (skin: SkinId) => void;
  onReset: () => void;
  onPlay: (level: number) => void;
}

export function ProgressScreen({ progress, onBack, onScores, onSelectSkin, onReset, onPlay }: ProgressProps) {
  const completed = Object.keys(progress.completed).length;
  const stars = totalStars(progress);
  const records = Object.entries(progress.completed)
    .map(([level, record]) => ({ level: Number(level), ...record }))
    .sort((a, b) => b.bestScore - a.bestScore)
    .slice(0, 6);
  return (
    <main className="progress-screen screen scroll-screen">
      <ScreenHeader title="Captain's Log" subtitle="Saved on this device" onBack={onBack} />
      <section className="progress-overview glass-panel">
        <div className="progress-ring" style={{ "--progress": `${(completed / TOTAL_LEVELS) * 360}deg` } as CSSProperties}>
          <div><strong>{completed}</strong><span>of 120</span></div>
        </div>
        <div className="progress-copy"><span className="eyebrow">Ocean explorer</span><h3>{completed === 120 ? "Master of the Deep" : completed >= 40 ? "Current Navigator" : completed >= 10 ? "Reef Explorer" : "New Diver"}</h3><p>{120 - completed} puzzles remain in your expedition.</p></div>
      </section>
      <section className="stat-card-grid">
        <div className="stat-card glass-panel"><Star /><strong>{stars}</strong><span>Total stars</span><small>out of 360</small></div>
        <div className="stat-card glass-panel"><Award /><strong>{progress.bestStreak}</strong><span>Best streak</span><small>3-star chain</small></div>
        <div className="stat-card glass-panel"><Droplets /><strong>{progress.totalMoves.toLocaleString()}</strong><span>Total moves</span><small>every real pour</small></div>
        <div className="stat-card glass-panel"><Trophy /><strong>{totalScore(progress).toLocaleString()}</strong><span>Best score</span><small>sum of records</small></div>
      </section>

      <div className="section-title"><div><span>Make it yours</span><h3>Glass Collection</h3></div><small>{TUBE_SKINS.filter((skin) => skinIsUnlocked(skin.id, completed, stars)).length}/{TUBE_SKINS.length} unlocked</small></div>
      <section className="skin-grid">
        {TUBE_SKINS.map((item) => {
          const unlocked = skinIsUnlocked(item.id, completed, stars);
          const selected = progress.selectedSkin === item.id;
          return (
            <button
              key={item.id}
              className={`skin-card glass-panel ${selected ? "selected" : ""} ${!unlocked ? "locked" : ""}`}
              disabled={!unlocked}
              onClick={() => { onSelectSkin(item.id); audio.clink(); }}
            >
              <div className="skin-preview"><TubeGraphic tube={[2, 2, 0, 0]} skin={item.id} />{!unlocked && <span><Lock size={18} /></span>}</div>
              <strong>{item.name}</strong>
              <p>{item.note}</p>
              <small>{selected ? <><Check size={12} /> Selected</> : unlocked ? "Tap to equip" : `${item.completed} levels or ${item.stars} stars`}</small>
            </button>
          );
        })}
      </section>

      <div className="section-title"><div><span>Your finest pours</span><h3>Best Records</h3></div><button className="text-button" onClick={onScores}>High scores <ChevronRight size={14} /></button></div>
      <section className="records-list glass-panel">
        {records.length ? records.map((record) => (
          <button key={record.level} onClick={() => onPlay(record.level)}>
            <span className="record-level">{record.level}</span>
            <span><strong>Level {record.level}</strong><small>{record.bestMoves} moves · {formatTime(record.bestTime)}</small></span>
            <span className="record-score"><strong>{record.bestScore.toLocaleString()}</strong><small>{record.stars} stars</small></span>
            <ChevronRight size={15} />
          </button>
        )) : <div className="empty-records"><Waves /><p>Complete your first puzzle to create a personal best.</p></div>}
      </section>
      <button className="danger-button" onClick={onReset}><RotateCcw size={16} /> Reset all progress</button>
    </main>
  );
}

export function HighScoresScreen({ progress, onBack, onPlay }: { progress: Progress; onBack: () => void; onPlay: (level: number) => void }) {
  return (
    <main className="scores-screen screen scroll-screen">
      <ScreenHeader title="Local High Scores" subtitle="Top 10 · this device only" onBack={onBack} />
      <section className="scores-hero glass-panel"><Trophy /><div><strong>{progress.highScores[0]?.score.toLocaleString() ?? "—"}</strong><span>{progress.highScores.length ? "Highest single-level score" : "Your trophy shelf is waiting"}</span></div></section>
      <section className="high-score-table glass-panel">
        <div className="score-row score-header"><span>Rank</span><span>Level</span><span>Performance</span><span>Score</span></div>
        {progress.highScores.length ? progress.highScores.map((entry, index) => (
          <button className="score-row" key={`${entry.level}-${entry.date}-${index}`} onClick={() => onPlay(entry.level)}>
            <span className={`rank rank-${index + 1}`}>{index + 1}</span>
            <span><strong>Level {entry.level}</strong><small>{getDifficulty(entry.level)}</small></span>
            <span><strong>{entry.moves} moves</strong><small>{entry.stars} stars · {formatTime(entry.seconds)}</small></span>
            <span><strong>{entry.score.toLocaleString()}</strong><small>{new Date(entry.date).toLocaleDateString()}</small></span>
          </button>
        )) : <div className="empty-scores"><Medal /><h3>No scores yet</h3><p>Finish a level and your score will appear here instantly.</p></div>}
      </section>
      <p className="level-footnote">Scores reward efficient pours, quick solutions, and fewer hints, undos, or bonus tubes.</p>
    </main>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`toggle ${checked ? "on" : ""}`} onClick={onChange}><i /></button>;
}

export function SettingsModal({ settings, onChange, onClose }: { settings: AudioSettings; onChange: (settings: AudioSettings) => void; onClose: () => void }) {
  const update = (patch: Partial<AudioSettings>) => onChange({ ...settings, ...patch });
  return (
    <div className="modal-backdrop settings-backdrop" role="dialog" aria-modal="true" aria-label="Sound and settings">
      <section className="modal-card settings-card">
        <button className="modal-close icon-button" onClick={onClose} aria-label="Close settings"><X size={19} /></button>
        <div className="modal-icon"><Settings /></div>
        <span className="eyebrow">Make the ocean yours</span>
        <h2>Sound & Settings</h2>
        <div className="settings-list">
          <div className="setting-row"><span className="setting-icon">{settings.sound ? <Volume2 /> : <VolumeX />}</span><span><strong>Sound</strong><small>Master sound on or off</small></span><Toggle label="Sound" checked={settings.sound} onChange={() => update({ sound: !settings.sound })} /></div>
          <div className="setting-row"><span className="setting-icon"><Droplets /></span><span><strong>Water & Glass</strong><small>Pours, splashes and clinks</small></span><Toggle label="Water and glass sounds" checked={settings.water} onChange={() => update({ water: !settings.water })} /></div>
          <div className="setting-row"><span className="setting-icon"><Waves /></span><span><strong>Underwater Ambience</strong><small>Deep current and soft bubbles</small></span><Toggle label="Underwater ambience" checked={settings.ambient} onChange={() => update({ ambient: !settings.ambient })} /></div>
          <label className="volume-control"><span><strong>Overall Volume</strong><small>{Math.round(settings.volume * 100)}%</small></span><input type="range" min="0" max="1" step="0.01" value={settings.volume} onChange={(event) => update({ volume: Number(event.target.value) })} /></label>
        </div>
        <p className="synth-note"><Sparkles size={15} /><span><strong>Synthesized, not recorded.</strong> Water and glass sounds are generated in real time with Web Audio—no speech, music, samples, or network requests. Audio unlocks only after you interact.</span></p>
        <button className="primary-button wide" onClick={onClose}>Done</button>
      </section>
    </div>
  );
}

export function ResetConfirmDialog({ onCancel, onConfirm }: { onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="modal-backdrop" role="alertdialog" aria-modal="true" aria-label="Confirm reset all progress">
      <section className="modal-card confirm-card">
        <div className="modal-icon warning"><RotateCcw /></div>
        <h2>Reset everything?</h2>
        <p>This permanently clears unlocked levels, stars, high scores, move records, and tube skins on this device. This cannot be undone.</p>
        <button className="danger-solid-button wide" onClick={onConfirm}>Yes, Reset Everything</button>
        <button className="secondary-button wide" onClick={onCancel}>Keep My Progress</button>
      </section>
    </div>
  );
}
