import type { ReactNode } from 'react';
import type { MatchResult } from '../game/types';
import type { Stats } from '../game/storage';

export const MENU_BG = 'https://images.pexels.com/photos/15717709/pexels-photo-15717709.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200';

const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

function FireButton({
  children,
  onClick,
  variant = 'primary',
  className = '',
}: {
  children: ReactNode;
  onClick: () => void;
  variant?: 'primary' | 'ghost' | 'secondary';
  className?: string;
}) {
  const styles = {
    primary:
      'btn-sheen anim-glow text-white bg-gradient-to-r from-amber-400 via-orange-500 to-red-600 px-10 py-4 text-2xl shadow-[0_10px_40px_-6px_rgba(249,115,22,0.7)] hover:brightness-110',
    secondary: 'text-amber-100 bg-white/10 ring-1 ring-white/20 px-6 py-3 text-base hover:bg-white/15',
    ghost: 'text-white/70 px-4 py-2 text-sm hover:text-white',
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative overflow-hidden rounded-xl font-display font-black uppercase tracking-[0.18em] transition duration-150 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg bg-white/[0.06] px-3 py-2 ring-1 ring-white/10">
      <div className="font-display text-[10px] tracking-[0.25em] text-white/55">{label}</div>
      <div className="font-display text-2xl font-bold tabular-nums text-white">{value}</div>
    </div>
  );
}

export function MenuScreen({
  name,
  onNameChange,
  onPlay,
  stats,
  muted,
  onToggleMute,
}: {
  name: string;
  onNameChange: (v: string) => void;
  onPlay: () => void;
  stats: Stats;
  muted: boolean;
  onToggleMute: () => void;
}) {
  return (
    <div className="anim-fade absolute inset-0 z-20 overflow-y-auto overflow-x-hidden bg-black font-body text-white touch-pan-y">
      <img src={MENU_BG} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-black/25" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/40" />

      <div className="relative flex min-h-full flex-col justify-between gap-8 px-6 py-6 sm:px-10 sm:py-8 lg:flex-row lg:items-center">
        {/* Left: logo + play */}
        <div className="anim-drop max-w-md">
          <div className="flex items-center gap-3">
            <svg viewBox="0 0 24 24" className="h-10 w-10 text-amber-400 drop-shadow-[0_0_12px_rgba(251,146,60,0.8)]" fill="currentColor" aria-hidden>
              <path d="M12 2c1 3.5 4 5 4 9a4 4 0 0 1-8 0c0-1.7.8-3 1.8-4C10 9.5 11 11 12 11c0-3 .5-6-0-9zM7 14c0 3 2.2 6 5 6s5-3 5-6c0 1.5-1 2.5-2 3 .3-1.6-.4-3-1.5-4-.3 1.2-1 2-2 2 .6-2.4-.5-4.5-2.5-5.5C8 11.5 7 12.5 7 14z" />
            </svg>
            <span className="font-display text-xs font-bold tracking-[0.5em] text-amber-300/90">BATTLE ROYALE</span>
          </div>
          <h1 className="mt-1 font-display text-[88px] font-black leading-[0.85] tracking-tight sm:text-[120px]">
            <span className="title-fire block">JYREX</span>
            <span className="title-fire-2 block">FIRE</span>
          </h1>
          <p className="mt-4 max-w-sm text-lg tracking-wide text-white/70">
            Drop in. Loot up. Outlast sixteen operators as the safe zone closes in.
          </p>

          <form
            className="mt-8 flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault();
              onPlay();
            }}
          >
            <label className="flex flex-col gap-1">
              <span className="font-display text-[11px] tracking-[0.3em] text-white/55">CALLSIGN</span>
              <input
                value={name}
                maxLength={14}
                onChange={(e) => onNameChange(e.target.value)}
                aria-label="Callsign"
                placeholder="Survivor"
                className="w-full max-w-xs rounded-lg border border-white/20 bg-black/55 px-4 py-2.5 font-display text-lg font-bold tracking-wider text-white outline-none placeholder:text-white/30 focus:border-amber-400"
              />
            </label>
            <div className="flex flex-wrap items-center gap-4">
              <FireButton onClick={onPlay}>▶ Play</FireButton>
              <FireButton variant="ghost" onClick={onToggleMute}>
                {muted ? 'Sound off' : 'Sound on'}
              </FireButton>
            </div>
            <p className="font-display text-[11px] tracking-[0.3em] text-white/45">SOLO · 16 PLAYERS · ENTER TO PLAY</p>
          </form>
        </div>

        {/* Right: stats + controls */}
        <div className="anim-drop flex w-full max-w-sm flex-col gap-4 self-end lg:self-center" style={{ animationDelay: '0.1s' }}>
          <div className="rounded-2xl bg-black/50 p-4 ring-1 ring-white/10 backdrop-blur-sm">
            <div className="mb-3 font-display text-[11px] font-bold tracking-[0.3em] text-amber-300">PILOT RECORD</div>
            <div className="grid grid-cols-2 gap-2">
              <Stat label="MATCHES" value={stats.matches} />
              <Stat label="WINS" value={stats.wins} />
              <Stat label="KILLS" value={stats.kills} />
              <Stat label="BEST KILLS" value={stats.bestKills} />
            </div>
          </div>
          <div className="rounded-2xl bg-black/50 p-4 text-sm ring-1 ring-white/10 backdrop-blur-sm">
            <div className="mb-2 font-display text-[11px] font-bold tracking-[0.3em] text-amber-300">CONTROLS</div>
            <div className="grid grid-cols-[110px_1fr] gap-x-3 gap-y-1.5 text-white/75">
              <span className="font-display text-xs tracking-wider text-white">WASD</span>
              <span>Move · Shift sprint · Space jump</span>
              <span className="font-display text-xs tracking-wider text-white">MOUSE</span>
              <span>Aim · Hold LMB fire · RMB aim</span>
              <span className="font-display text-xs tracking-wider text-white">E / F / R</span>
              <span>Pick up · Heal · Reload</span>
              <span className="font-display text-xs tracking-wider text-white">1 · 2 · Q</span>
              <span>Switch weapon slots</span>
              <span className="font-display text-xs tracking-wider text-white">TOUCH</span>
              <span>Left joystick · Right drag to look</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PauseScreen({
  muted,
  onResume,
  onRestart,
  onLobby,
  onToggleMute,
}: {
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onLobby: () => void;
  onToggleMute: () => void;
}) {
  return (
    <div className="anim-fade absolute inset-0 z-20 flex flex-col items-center justify-center gap-5 bg-black/75 font-body text-white">
      <div className="font-display text-xs font-bold tracking-[0.5em] text-amber-300">MATCH PAUSED</div>
      <h2 className="font-display text-6xl font-black tracking-wider">PAUSED</h2>
      <div className="flex w-full max-w-[280px] flex-col gap-3">
        <FireButton onClick={onResume} className="w-full">
          Resume
        </FireButton>
        <FireButton variant="secondary" onClick={onRestart} className="w-full">
          New match · R
        </FireButton>
        <FireButton variant="secondary" onClick={onToggleMute} className="w-full">
          {muted ? 'Sound off' : 'Sound on'}
        </FireButton>
        <FireButton variant="ghost" onClick={onLobby}>
          Quit to lobby
        </FireButton>
      </div>
      <p className="font-display text-[11px] tracking-[0.3em] text-white/45">ESC / P TO RESUME · CLICK SCREEN TO RE-AIM</p>
    </div>
  );
}

export function ResultScreen({
  result,
  stats,
  onAgain,
  onLobby,
}: {
  result: MatchResult;
  stats: Stats;
  onAgain: () => void;
  onLobby: () => void;
}) {
  const win = result.win;
  return (
    <div className="anim-fade absolute inset-0 z-20 flex flex-col items-center justify-center gap-6 overflow-y-auto bg-[radial-gradient(ellipse_at_center,rgba(30,20,10,0.85),rgba(0,0,0,0.96))] px-6 py-10 text-center font-body text-white">
      <div className="anim-drop">
        <div className="font-display text-xs font-bold tracking-[0.5em] text-amber-300/80">{win ? 'VICTORY ROYALE' : 'MATCH OVER'}</div>
        <h2 className={`font-display text-7xl font-black tracking-wider ${win ? 'title-gold' : 'text-rose-400 [text-shadow:0_0_24px_rgba(251,113,133,0.6)]'}`}>
          {win ? 'BOOYAH!' : 'ELIMINATED'}
        </h2>
        {!win && (
          <p className="mt-1 font-display text-2xl tracking-wider text-white/80">
            Placed <span className="text-amber-300">#{result.placement}</span> of 16
          </p>
        )}
      </div>

      <div className="grid w-full max-w-sm grid-cols-3 gap-2">
        <Stat label="PLACEMENT" value={`#${result.placement}`} />
        <Stat label="KILLS" value={result.kills} />
        <Stat label="SURVIVED" value={fmtTime(result.time)} />
      </div>
      <p className="font-display text-xs tracking-[0.3em] text-white/50">
        CAREER · {stats.wins} WINS · {stats.kills} KILLS · {stats.matches} MATCHES
      </p>

      <div className="flex w-full max-w-[280px] flex-col gap-3">
        <FireButton onClick={onAgain} className="w-full">
          Play again
        </FireButton>
        <FireButton variant="ghost" onClick={onLobby}>
          Lobby
        </FireButton>
      </div>
      <p className="font-display text-[10px] tracking-[0.3em] text-white/40">ENTER / R TO PLAY AGAIN</p>
    </div>
  );
}
