import { useMemo, useRef, useState } from "react";
import type { Game } from "../game/engine";
import { loadScores, type ScoreRow } from "../game/engine";
import {
  CAT_INFO,
  CUSTOMER_TYPES,
  DISHES,
  ING_MAP,
  LOCATIONS,
  UPGRADES,
  bn,
  DAY_TARGET,
  festForDay,
  locForDay,
  taka,
  type Cat,
} from "../game/data";
import { sfx } from "../game/audio";
import { CartView, LightsView, PersonView, SilhouetteView, TrafficView } from "./Sprites";

const upRefCache = new Map<string, (el: HTMLElement | null) => void>();
const reg = (g: Game, key: string) => {
  let fn = upRefCache.get(key);
  if (!fn) {
    fn = (el: HTMLElement | null) => {
      g.register(key, el);
    };
    upRefCache.set(key, fn);
  }
  return fn;
};

function MenuBackdrop({ fest }: { fest?: boolean }) {
  const loc = LOCATIONS[2];
  const [c1, c2, c3] = loc.sky;
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: `linear-gradient(180deg, ${c1}, ${c2} 55%, ${c3})` }}>
      <div className="absolute inset-x-0 top-0 h-1/2">
        {Array.from({ length: 30 }).map((_, i) => (
          <span
            key={i}
            className="anim-flicker absolute rounded-full bg-cream"
            style={{ left: `${(i * 41) % 100}%`, top: `${(i * 37) % 44}%`, width: i % 4 === 0 ? 3 : 2, height: i % 4 === 0 ? 3 : 2, animationDelay: `${(i % 6) * 0.8}s` }}
          />
        ))}
      </div>
      <div
        className="absolute rounded-full"
        style={{ right: "9%", top: "8%", width: 62, height: 62, background: "radial-gradient(circle at 35% 35%,#fff3dc,#ffb627 60%,#f2714a)", boxShadow: "0 0 70px #ffb627aa" }}
      />
      <SilhouetteView kind={loc.silo} tint="rgba(24,12,34,.85)" />
      <TrafficView night />
      <div className="absolute inset-x-0 bottom-0 h-[20%]" style={{ background: "linear-gradient(180deg,#3a2b45,#1b1029)" }}>
        <div className="absolute inset-x-0 top-1/2 flex -translate-y-1/2 justify-around opacity-40">
          {Array.from({ length: 12 }).map((_, i) => (
            <span key={i} className="h-[3px] w-[28px] rounded bg-marigold/70" />
          ))}
        </div>
      </div>
      <LightsView bulbs={18} color={fest ? "#e8384f" : "#ffb627"} />
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 80% at 50% 35%, transparent 35%, rgba(16,8,26,.78))" }} />
    </div>
  );
}

function Bulb({ i }: { i: number }) {
  return (
    <span
      className="anim-flicker absolute h-2 w-2 rounded-full"
      style={{
        background: ["#ffb627", "#ff4d8d", "#17b8a6"][i % 3],
        boxShadow: `0 0 10px ${["#ffb627", "#ff4d8d", "#17b8a6"][i % 3]}`,
        animationDelay: `${(i % 6) * 0.3}s`,
      }}
    />
  );
}

function SignBoard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative rounded-2xl border-4 border-ink/70 p-[3px] ${className}`} style={{ background: "linear-gradient(140deg,#ffb627,#e8384f 55%,#ff4d8d)", boxShadow: "0 18px 40px rgba(0,0,0,.5), inset 0 2px 0 rgba(255,255,255,.4)" }}>
      <div className="relative rounded-[12px] px-3 py-3 sm:px-5 sm:py-4" style={{ background: "linear-gradient(180deg,#3a1f47,#241232)" }}>
        <div className="pointer-events-none absolute inset-x-2 -top-[5px] flex justify-between">
          {Array.from({ length: 12 }).map((_, i) => (
            <Bulb key={i} i={i} />
          ))}
        </div>
        {children}
      </div>
    </div>
  );
}

function ScoreTable({ rows, compact }: { rows: ScoreRow[]; compact?: boolean }) {
  return (
    <div className="paper rounded-xl p-2 sm:p-3">
      <div className="mb-1.5 flex items-baseline justify-between">
        <h3 className="font-display text-[15px] font-extrabold sm:text-[17px]">🏆 সেরা স্কোর</h3>
        <span className="text-[9px] font-semibold opacity-60">LOCAL TOP {bn(8)}</span>
      </div>
      {rows.length === 0 ? (
        <p className="py-3 text-center text-[11px] font-semibold opacity-70">এখনও কেউ খেলেনি — প্রথম রেকর্ডটা আপনার হোক!</p>
      ) : (
        <ol className="flex flex-col gap-[3px]">
          {rows.slice(0, compact ? 5 : 8).map((r, i) => (
            <li
              key={i}
              className={`flex items-center gap-1.5 rounded-md px-1.5 py-[3px] text-[11px] font-semibold ${i === 0 ? "bg-marigold/45" : i < 3 ? "bg-[rgba(58,36,18,.12)]" : ""}`}
            >
              <span className="w-4 shrink-0 font-display text-[12px] font-extrabold">{["🥇", "🥈", "🥉"][i] ?? bn(i + 1)}</span>
              <span className="w-[74px] shrink-0 truncate sm:w-[110px]">{r.name}</span>
              <span className="hidden w-[86px] shrink-0 truncate opacity-70 sm:block">
                দিন {bn(r.day)} · {r.loc}
              </span>
              <span className="ml-auto font-display text-[13px] font-extrabold tabular-nums">{bn(r.score)}</span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

/* ------------------------------ START ------------------------------ */

export function StartScreen({ g }: { g: Game }) {
  const rows = useMemo(() => loadScores(), [g.version]);
  const steps = [
    { icon: "🗣️", bn: "অর্ডার নিন", en: "কাস্টমারের ব্যাজে কোন খাবার চায় দেখুন" },
    { icon: "👆", bn: "পরপর ট্যাপ করুন", en: "মেনু বোর্ডের ক্রম অনুযায়ী উপাদান ট্যাপ করুন" },
    { icon: "🍽️", bn: "পরিবেশন করুন", en: "কাস্টমারকে ট্যাপ করুন — দ্রুত দিলে টিপস বেশি" },
    { icon: "⚙️", bn: "আপগ্রেড কিনুন", en: "নতুন উপাদান, যন্ত্র আর কার্টের সাজসজ্জা" },
  ];
  return (
    <div className="absolute inset-0 overflow-hidden">
      <MenuBackdrop />
      <div className="scroll-y relative z-10 h-full">
        <div className="mx-auto flex min-h-full w-full max-w-[1180px] flex-col gap-3 p-3 sm:p-5 lg:flex-row lg:items-stretch">
          {/* left */}
          <div className="flex flex-[1.25] flex-col gap-3">
            <SignBoard className="anim-zoom">
              <div className="pt-1 text-center">
                <div className="mb-1 inline-flex items-center gap-1.5 rounded-full border border-marigold/40 bg-ink/60 px-2 py-[2px]">
                  <span className="text-[10px]">🛺</span>
                  <span className="font-display text-[10px] font-bold tracking-[0.18em] text-marigold uppercase">Street Food Tycoon</span>
                </div>
                <h1 className="sign text-[clamp(26px,6.4vw,52px)] leading-[1.06] text-marigold">রাস্তার ধারের<br className="sm:hidden" /> ফুডকার্ট</h1>
                <p className="mt-1 text-[11px] font-semibold text-cream/70 sm:text-[13px]">
                  ফুচকা · ঝালমুড়ি · চটপটি — স্কুল গেট থেকে গুলশান, ঢাকার সেরা কার্ট টাইকুন বনুন
                </p>
              </div>
            </SignBoard>

            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <button
                className="btn3d anim-glow group flex items-center justify-center gap-2 bg-gradient-to-b from-marigold to-[#f2900f] px-5 py-3 text-ink sm:flex-1"
                onPointerDown={(e) => {
                  e.preventDefault();
                  sfx.init();
                  sfx.click();
                  g.startRun();
                }}
              >
                <span className="text-[22px] transition-transform group-hover:-rotate-12">🍳</span>
                <span className="font-display text-[19px] font-extrabold sm:text-[23px]">খেলা শুরু করুন</span>
                <span className="rounded bg-ink/25 px-1.5 py-[1px] font-display text-[11px] font-bold">Enter</span>
              </button>
              <div className="panel flex items-center gap-2 rounded-xl px-2.5 py-2">
                <span className="text-[18px]">🎯</span>
                <div className="leading-tight">
                  <div className="font-display text-[12px] font-bold text-cream">দিনের লক্ষ্য পূরণ করুন</div>
                  <div className="text-[9.5px] text-cream/60">রেটিং শূন্য হলে দোকান বন্ধ!</div>
                </div>
              </div>
            </div>

            {/* how to play */}
            <div className="panel anim-slide-up rounded-xl p-2.5 sm:p-3" style={{ animationDelay: "120ms" }}>
              <h2 className="mb-2 font-display text-[14px] font-extrabold text-marigold sm:text-[16px]">কীভাবে খেলবেন</h2>
              <ol className="relative flex flex-col gap-2 pl-1">
                <span className="absolute top-2 bottom-2 left-[15px] w-[2px] border-l-2 border-dashed border-cream/20" />
                {steps.map((st, i) => (
                  <li key={i} className="relative flex items-center gap-2.5">
                    <span className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 border-ink/60 bg-marigold text-[15px] shadow">{st.icon}</span>
                    <span className="font-display text-[12.5px] leading-tight font-bold text-cream sm:text-[14px]">
                      {bn(i + 1)}. {st.bn}
                      <span className="ml-1.5 font-body text-[10px] font-medium text-cream/55">{st.en}</span>
                    </span>
                  </li>
                ))}
              </ol>
              <div className="mt-2.5 flex flex-wrap items-center gap-1 border-t border-cream/12 pt-2">
                {[
                  ["1–0", "উপাদান ট্যাপ"],
                  ["Space", "দ্রুত পরিবেশন"],
                  ["Q W E R T", "স্লট অনুযায়ী দিন"],
                  ["X", "ফেলে দিন"],
                  ["P", "বিরতি"],
                  ["R", "রিস্টার্ট"],
                ].map(([k, v]) => (
                  <span key={k} className="flex items-center gap-1 rounded-md border border-cream/15 bg-ink/60 px-1.5 py-[2px]">
                    <kbd className="font-display text-[10px] font-extrabold text-marigold">{k}</kbd>
                    <span className="text-[9.5px] text-cream/65">{v}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* customer types ticker */}
            <div className="panel anim-slide-up rounded-xl p-2.5" style={{ animationDelay: "210ms" }}>
              <h2 className="mb-1.5 font-display text-[13px] font-extrabold text-marigold sm:text-[15px]">👥 কাস্টমার চেনেন নিন</h2>
              <div className="scroll-y flex gap-2 overflow-x-auto pb-1">
                {CUSTOMER_TYPES.map((c) => (
                  <div key={c.id} className="flex w-[168px] shrink-0 items-start gap-2 rounded-lg border border-cream/12 bg-ink/50 p-1.5">
                    <div className="shrink-0">
                      <PersonView type={c} w={30} />
                    </div>
                    <div className="leading-tight">
                      <div className="font-display text-[11px] font-bold text-cream">{c.bn}</div>
                      <div className="mt-[1px] text-[9px] text-cream/55">{c.quirk}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* right */}
          <div className="flex flex-1 flex-col gap-3">
            <div className="panel anim-slide-up relative overflow-hidden rounded-xl p-2.5" style={{ animationDelay: "160ms" }}>
              <div className="absolute -top-8 -right-6 text-[110px] opacity-10">🥟</div>
              <h2 className="mb-2 font-display text-[14px] font-extrabold text-marigold sm:text-[16px]">🍽️ আজকের মেনু</h2>
              <div className="flex flex-col gap-1.5">
                {DISHES.map((d) => (
                  <div key={d.id} className="flex items-center gap-2 rounded-lg border border-cream/10 bg-ink/45 px-2 py-1">
                    <span className="text-[19px]">{d.icon}</span>
                    <div className="leading-tight">
                      <div className="font-display text-[12px] font-bold text-cream">{d.bn}</div>
                      <div className="text-[8.5px] text-cream/45">{d.en}</div>
                    </div>
                    <span className="ml-1 flex gap-[2px]">
                      {d.recipe.map((r, i) => (
                        <span key={i} className="text-[11px]">{ING_MAP[r].icon}</span>
                      ))}
                    </span>
                    <span className="ml-auto font-display text-[12px] font-extrabold text-marigold">{taka(d.price)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-2 flex items-center justify-center gap-2 rounded-lg border border-dashed border-cream/20 py-1.5">
                <CartView upgrades={{ light: 2, banner: 1, sound: 1, pot: 1 }} sign="ফুচকা ঘর" glow="#ffb627" />
              </div>
            </div>
            <div className="anim-slide-up" style={{ animationDelay: "250ms" }}>
              <ScoreTable rows={rows} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ READY ------------------------------ */

export function ReadyOverlay({ g }: { g: Game }) {
  const s = g.s;
  const n = Math.max(1, Math.ceil(s.readyT));
  const fest = s.fest;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-ink/70 px-3 backdrop-blur-[2px]" onPointerDown={() => g.skipReady()}>
      <div className="anim-zoom w-full max-w-[430px]">
        <SignBoard>
          <div className="pt-1.5 text-center">
            <div className="font-display text-[12px] font-bold tracking-[0.2em] text-cream/60 uppercase">Day {bn(s.day)}</div>
            <h2 className="sign text-[clamp(22px,5.4vw,34px)] leading-tight text-marigold">
              {s.loc.icon} {s.loc.bn}
            </h2>
            <p className="text-[11px] font-semibold text-cream/70">{s.loc.tagline}</p>
            {fest && (
              <div className="mt-2 rounded-lg border-2 border-rickshaw/60 bg-rickshaw/20 px-2 py-1">
                <div className="font-display text-[13px] font-extrabold text-rickshaw">
                  {fest.icon} {fest.bn}
                </div>
                <div className="text-[10px] text-cream/75">{fest.note}</div>
              </div>
            )}
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {[
                ["⏳", `${bn(s.dayLen)} সে.`, "সময়"],
                ["🎯", taka(s.target), "লক্ষ্য"],
                ["👥", `${bn(s.maxSlots)} জন`, "লাইন"],
              ].map(([i, v, l]) => (
                <div key={l} className="rounded-lg border border-cream/15 bg-ink/55 py-1">
                  <div className="text-[14px]">{i}</div>
                  <div className="font-display text-[13px] font-extrabold text-cream">{v}</div>
                  <div className="text-[8.5px] text-cream/50">{l}</div>
                </div>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-center gap-2">
              <span key={n} className="anim-pop font-display text-[40px] leading-none font-extrabold text-cream">
                {n === 1 ? "শুরু!" : bn(n)}
              </span>
              <span className="text-[10px] text-cream/55">ট্যাপ করে এখনই শুরু</span>
            </div>
          </div>
        </SignBoard>
      </div>
    </div>
  );
}

/* ------------------------------ PAUSE ------------------------------ */

export function PauseOverlay({ g }: { g: Game }) {
  const s = g.s;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-ink/78 px-3 backdrop-blur-[3px]">
      <div className="anim-zoom panel w-full max-w-[360px] rounded-2xl p-4 text-center">
        <div className="text-[34px]">⏸</div>
        <h2 className="font-display text-[24px] font-extrabold text-marigold">বিরতি</h2>
        <p className="text-[11px] text-cream/60">দিন {bn(s.day)} · {s.loc.bn}</p>
        <div className="my-3 grid grid-cols-3 gap-1.5">
          {[
            [taka(s.dayEarned), "আয়"],
            [bn(s.stats.served), "পরিবেশন"],
            [`⭐${bn(Math.round(s.rep))}`, "রেটিং"],
          ].map(([v, l]) => (
            <div key={l} className="rounded-lg border border-cream/12 bg-ink/60 py-1.5">
              <div className="font-display text-[15px] font-extrabold text-cream">{v}</div>
              <div className="text-[9px] text-cream/50">{l}</div>
            </div>
          ))}
        </div>
        <div className="flex flex-col gap-2">
          <button className="btn3d bg-gradient-to-b from-leaf to-[#2c8244] px-4 py-2.5 font-display text-[16px] font-extrabold text-cream" onPointerDown={(e) => { e.preventDefault(); g.togglePause(); }}>
            ▶ আবার খেলুন <span className="text-[11px] opacity-70">(P)</span>
          </button>
          <div className="flex gap-2">
            <button className="btn3d flex-1 bg-plum px-3 py-2 font-display text-[13px] font-bold text-cream" onPointerDown={(e) => { e.preventDefault(); sfx.click(); g.startRun(); }}>
              🔄 নতুন করে
            </button>
            <button className="btn3d flex-1 bg-ink px-3 py-2 font-display text-[13px] font-bold text-cream/80" onPointerDown={(e) => { e.preventDefault(); g.toMenu(); }}>
              🏠 মেনু
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ SHOP ------------------------------ */

function UpgradeCard({ g, id }: { g: Game; id: string }) {
  const u = UPGRADES.find((x) => x.id === id)!;
  const lvl = g.s.upgrades[id] ?? 0;
  const maxed = lvl >= u.costs.length;
  const cost = maxed ? 0 : u.costs[lvl];
  const afford = g.s.wallet >= cost;
  return (
    <div
      ref={reg(g, "up_" + id)}
      className={`flex items-center gap-2 rounded-xl border-2 p-2 transition-colors ${
        maxed ? "border-leaf/50 bg-leaf/12" : afford ? "border-marigold/50 bg-ink/60" : "border-cream/12 bg-ink/45 opacity-70"
      }`}
    >
      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border-2 border-ink/50 text-[20px] ${maxed ? "bg-leaf/30" : "bg-marigold/25"}`}>{u.icon}</span>
      <div className="min-w-0 flex-1 leading-tight">
        <div className="flex items-center gap-1">
          <span className="font-display text-[12.5px] font-extrabold text-cream">{u.bn}</span>
          <span className="flex gap-[2px]">
            {Array.from({ length: u.costs.length }).map((_, i) => (
              <span key={i} className={`h-[6px] w-[6px] rounded-full ${i < lvl ? "bg-leaf" : "bg-cream/25"}`} />
            ))}
          </span>
        </div>
        <div className="truncate text-[9.5px] text-cream/55">{u.en}</div>
        <div className="mt-[1px] text-[10px] font-semibold text-marigold/90">{u.effect}</div>
      </div>
      <button
        className="btn3d shrink-0 px-2 py-1.5 text-center"
        style={{ background: maxed ? "#3fae5a" : afford ? "linear-gradient(180deg,#ffb627,#f2900f)" : "#4a2352" }}
        disabled={maxed || !afford}
        onPointerDown={(e) => {
          e.preventDefault();
          g.buyUpgrade(id);
        }}
      >
        <span className="block font-display text-[12.5px] leading-none font-extrabold text-ink">{maxed ? "সর্বোচ্চ" : taka(cost)}</span>
        {!maxed && <span className="block text-[8px] leading-tight text-ink/70">লেভেল {bn(lvl + 1)}</span>}
      </button>
    </div>
  );
}

export function ShopScreen({ g }: { g: Game }) {
  const s = g.s;
  const nextDay = s.day + 1;
  const nextLoc = locForDay(nextDay);
  const nextFest = festForDay(nextDay);
  const bonus = Math.round(s.rep * 8 + s.stats.perfect * 25 + s.bestCombo * 15 + s.stats.tips * 0.5);
  const cats: Cat[] = ["ing", "app", "cart"];
  return (
    <div className="absolute inset-0 z-40 overflow-hidden bg-ink/85 backdrop-blur-[3px]">
      <div className="scroll-y h-full">
        <div className="mx-auto flex w-full max-w-[1080px] flex-col gap-2.5 p-3 sm:p-4">
          <div className="anim-slide-up panel flex flex-wrap items-center gap-2 rounded-2xl px-3 py-2">
            <span className="text-[28px]">🎉</span>
            <div className="leading-tight">
              <h2 className="font-display text-[19px] font-extrabold text-marigold sm:text-[23px]">দিন {bn(s.day)} সফল!</h2>
              <p className="text-[10.5px] text-cream/60">{s.loc.bn} — লক্ষ্য {taka(s.target)} পূরণ, বোনাস {taka(bonus)} যোগ হয়েছে</p>
            </div>
            <div className="ml-auto flex flex-wrap items-center gap-1.5">
              {[
                [taka(s.dayEarned), "আয়", "#17b8a6"],
                [bn(s.stats.served), "পরিবেশন", "#3fae5a"],
                [bn(s.stats.perfect), "পারফেক্ট", "#ffb627"],
                [bn(s.stats.missed), "মিস", "#e8384f"],
                [taka(s.totalTips), "টিপস", "#ff4d8d"],
              ].map(([v, l, c]) => (
                <div key={l} className="rounded-lg border-2 border-ink/50 px-2 py-1 text-center" style={{ background: `${c}22` }}>
                  <div className="font-display text-[14px] leading-none font-extrabold" style={{ color: c as string }}>{v}</div>
                  <div className="text-[8.5px] text-cream/55">{l}</div>
                </div>
              ))}
              <div className="rounded-lg border-2 border-marigold bg-marigold px-2.5 py-1 text-center">
                <div className="font-display text-[15px] leading-none font-extrabold text-ink tabular-nums">💰 {bn(s.wallet)}</div>
                <div className="text-[8.5px] text-ink/70">ওয়ালেট</div>
              </div>
            </div>
          </div>

          <div className="grid gap-2.5 md:grid-cols-3">
            {cats.map((cat, ci) => (
              <div key={cat} className="anim-slide-up panel rounded-2xl p-2.5" style={{ animationDelay: `${ci * 70}ms` }}>
                <div className="mb-2 flex items-center gap-1.5">
                  <span className="text-[17px]">{CAT_INFO[cat].icon}</span>
                  <h3 className="font-display text-[14px] font-extrabold text-cream">{CAT_INFO[cat].bn}</h3>
                  <span className="ml-auto text-[9px] tracking-wide text-cream/40 uppercase">{CAT_INFO[cat].en}</span>
                </div>
                <div className="flex flex-col gap-1.5">
                  {UPGRADES.filter((u) => u.cat === cat).map((u) => (
                    <UpgradeCard key={u.id} g={g} id={u.id} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="anim-slide-up panel sticky bottom-2 flex flex-wrap items-center gap-2 rounded-2xl px-3 py-2.5">
            <div className="leading-tight">
              <div className="font-display text-[11px] font-bold text-cream/60">পরবর্তী দিন</div>
              <div className="font-display text-[15px] font-extrabold text-marigold">
                দিন {bn(nextDay)} · {nextLoc.icon} {nextLoc.bn}
                {nextFest && <span className="ml-1 text-rickshaw">{nextFest.icon} {nextFest.bn}</span>}
              </div>
              <div className="text-[9.5px] text-cream/55">
                লক্ষ্য {taka(DAY_TARGET(nextDay))} · দাম ×{nextLoc.priceMul} · ভিড় ×{(nextLoc.spawnMul * (nextFest?.spawnMul ?? 1)).toFixed(1)}
              </div>
            </div>
            <button
              className="btn3d ml-auto bg-gradient-to-b from-leaf to-[#2c8244] px-4 py-2.5 font-display text-[16px] font-extrabold text-cream sm:text-[18px]"
              onPointerDown={(e) => {
                e.preventDefault();
                g.nextDay();
              }}
            >
              দোকান খুলুন → <span className="text-[11px] opacity-70">(Enter)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------- GAME OVER ---------------------------- */

export function GameOverScreen({ g }: { g: Game }) {
  const s = g.s;
  const [name, setName] = useState(() => {
    try {
      return localStorage.getItem("sft_name") ?? "";
    } catch {
      return "";
    }
  });
  const [rows, setRows] = useState<ScoreRow[]>(() => loadScores());
  const saved = useRef(false);
  const score = Math.round(s.score);

  const doSave = () => {
    if (saved.current) return;
    saved.current = true;
    try {
      localStorage.setItem("sft_name", name.trim().slice(0, 14) || "নামহীন");
    } catch {
      /* ignore */
    }
    setRows(g.submitScore(name));
    sfx.coin(true);
  };
  g.pendingSave = doSave;

  const rank = rows.findIndex((r) => r.score === score) + 1;
  const best = rows[0]?.score ?? score;

  return (
    <div className="absolute inset-0 z-50 overflow-hidden">
      <MenuBackdrop fest={s.overReason === "target"} />
      <div className="scroll-y relative z-10 h-full">
        <div className="mx-auto flex min-h-full w-full max-w-[860px] flex-col gap-2.5 p-3 sm:p-5">
          <div className="anim-zoom">
            <SignBoard>
              <div className="pt-1.5 text-center">
                <div className="text-[34px]">{s.overReason === "rep" ? "😡" : "🌙"}</div>
                <h2 className="sign text-[clamp(22px,5.6vw,38px)] leading-tight text-chili">
                  {s.overReason === "rep" ? "দোকান বন্ধ!" : "লক্ষ্য পূরণ হয়নি"}
                </h2>
                <p className="text-[11.5px] font-semibold text-cream/70">
                  {s.overReason === "rep"
                    ? "রেটিং শূন্য — কাস্টমাররা আর আসছে না। আবার চেষ্টা করুন!"
                    : `দিন ${bn(s.day)} শেষে ${taka(s.dayEarned)} আয় হলো, লক্ষ্য ছিল ${taka(s.target)}।`}
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <div>
                    <div className="text-[9.5px] tracking-widest text-cream/50 uppercase">Final Score</div>
                    <div key={score} className="anim-pop font-display text-[clamp(38px,10vw,64px)] leading-none font-extrabold text-marigold tabular-nums">{bn(score)}</div>
                  </div>
                  <div className="mb-1 text-left text-[10px] leading-tight text-cream/60">
                    <div>দিন পৌঁছেছেন: <b className="text-cream">{bn(s.day)}</b></div>
                    <div>সেরা কম্বো: <b className="text-cream">×{bn(s.bestCombo)}</b></div>
                    <div>মোট আয়: <b className="text-cream">{taka(s.totalEarned)}</b></div>
                  </div>
                </div>
              </div>
            </SignBoard>
          </div>

          <div className="grid gap-2 sm:grid-cols-[1.1fr_1fr]">
            <div className="panel anim-slide-up rounded-xl p-2.5">
              <h3 className="mb-2 font-display text-[14px] font-extrabold text-marigold">📊 এই রানের হিসাব</h3>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  ["🍽️", bn(s.runServed), "পরিবেশন"],
                  ["✨", bn(s.runPerfect), "পারফেক্ট"],
                  ["😡", bn(s.runMissed), "মিস"],
                  ["💸", taka(s.totalTips), "টিপস"],
                  ["⭐", bn(Math.round(s.rep)), "রেটিং"],
                  ["🏆", bn(best), "সেরা স্কোর"],
                ].map(([i, v, l]) => (
                  <div key={l} className="flex items-center gap-1.5 rounded-lg border border-cream/12 bg-ink/50 px-2 py-1.5">
                    <span className="text-[16px]">{i}</span>
                    <div className="leading-tight">
                      <div className="font-display text-[14px] font-extrabold text-cream tabular-nums">{v}</div>
                      <div className="text-[8.5px] text-cream/50">{l}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-2.5 flex items-center gap-1.5">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      doSave();
                    }
                    e.stopPropagation();
                  }}
                  maxLength={14}
                  placeholder="আপনার নাম লিখুন"
                  className="min-w-0 flex-1 rounded-lg border-2 border-cream/25 bg-ink/70 px-2.5 py-2 font-display text-[14px] font-bold text-cream outline-none placeholder:text-cream/35 focus:border-marigold"
                />
                <button
                  className="btn3d shrink-0 bg-gradient-to-b from-marigold to-[#f2900f] px-3 py-2 font-display text-[13px] font-extrabold text-ink"
                  onPointerDown={(e) => {
                    e.preventDefault();
                    doSave();
                  }}
                >
                  {saved.current ? "✓ সেভ হয়েছে" : "সেভ করুন"}
                </button>
              </div>
              {saved.current && rank > 0 && (
                <div className="mt-1.5 text-center font-display text-[12px] font-bold text-turq">
                  🎉 টেবিলে অবস্থান {bn(rank)} নম্বরে!
                </div>
              )}
              <div className="mt-2.5 flex gap-2">
                <button
                  className="btn3d anim-glow flex-1 bg-gradient-to-b from-chili to-[#b32237] px-3 py-2.5 font-display text-[15px] font-extrabold text-cream"
                  onPointerDown={(e) => {
                    e.preventDefault();
                    doSave();
                    sfx.click();
                    g.startRun();
                  }}
                >
                  🔄 আবার খেলুন <span className="text-[10px] opacity-70">(R)</span>
                </button>
                <button className="btn3d bg-plum px-3 py-2.5 font-display text-[14px] font-bold text-cream" onPointerDown={(e) => { e.preventDefault(); doSave(); g.toMenu(); }}>
                  🏠 মেনু
                </button>
              </div>
            </div>
            <ScoreTable rows={rows} />
          </div>
        </div>
      </div>
    </div>
  );
}
