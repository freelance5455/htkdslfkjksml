import { useEffect, useState } from "react";
import { AnswerButton, CenterScreen, PinkButton } from "./ui";
import { cn } from "../utils/cn";

// =====================================================
// START SCREEN
// =====================================================

export function StartScreen({ onStart }: { onStart: () => void }) {
  return (
    <CenterScreen>
      <div className="animate-heartbeat text-[85px] leading-none drop-shadow-[0_0_30px_rgba(255,62,165,0.6)]">
        💗
      </div>

      <h1 className="mt-3 text-[52px] leading-none font-black tracking-tight text-white drop-shadow-[0_0_24px_rgba(255,79,175,0.45)]">
        SADIYA
      </h1>

      <p className="mt-2 text-base text-[#FF7BCB]">has entered the app...</p>

      <p className="mt-10 text-[15px] font-bold text-[#FF4B9D]">⚠️ WARNING ⚠️</p>

      <h2 className="mt-2.5 text-[40px] leading-tight font-black text-white">DON'T TOUCH</h2>

      <p className="text-[15px] text-gray-500">Seriously.</p>

      <div className="mt-9 w-full">
        <PinkButton onClick={onStart}>DON'T TOUCH 😈</PinkButton>
      </div>
    </CenterScreen>
  );
}

// =====================================================
// DON'T TOUCH
// =====================================================

export function DontTouchScreen({ onTouch }: { onTouch: () => void }) {
  return (
    <CenterScreen>
      <div className="animate-bob text-[75px] leading-none">👁️</div>

      <h2 className="mt-4 text-[35px] leading-none font-black text-white">SADIYA...</h2>

      <p className="mt-2 text-xl font-bold text-[#FF3E91]">I'M SERIOUS.</p>

      <div className="mt-8 animate-breathe">
        <button
          type="button"
          onClick={onTouch}
          aria-label="Don't touch"
          className={cn(
            "flex h-[210px] w-[210px] cursor-pointer items-center justify-center rounded-full",
            "border border-[#FF65BC]/25 bg-[#1D071B] text-[27px] leading-tight font-black text-[#FF65BC]",
            "shadow-[0_0_60px_-6px_rgba(255,62,165,0.55),inset_0_0_40px_rgba(255,62,165,0.12)]",
            "transition duration-150 hover:border-[#FF65BC]/60 active:brightness-150",
          )}
        >
          DON'T
          <br />
          TOUCH
        </button>
      </div>

      <p className="mt-6 max-w-xs text-xs text-gray-500">
        Touch karogi to jo hoga uski responsibility meri nahi 😈
      </p>
    </CenterScreen>
  );
}

// =====================================================
// SCARE
// =====================================================

export function ScareScreen({ onDone }: { onDone: () => void }) {
  const [devil, setDevil] = useState(false);

  useEffect(() => {
    const swap = window.setTimeout(() => setDevil(true), 850);
    const done = window.setTimeout(onDone, 1700);
    return () => {
      window.clearTimeout(swap);
      window.clearTimeout(done);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <CenterScreen animate={false} className="relative">
      {/* red strobe */}
      <div className="pointer-events-none fixed inset-0 z-30 animate-flash bg-[#FF0050]" />

      <div className="animate-shake">
        <div className="animate-pop text-[100px] leading-none drop-shadow-[0_0_40px_rgba(255,0,80,0.8)]">
          {devil ? "😈" : "👁️"}
        </div>

        <p className="mt-4 text-3xl font-black text-white">I TOLD YOU...</p>

        <p className="mt-1 text-[22px] font-bold text-[#FF4FAF]">DON'T TOUCH 😭</p>
      </div>
    </CenterScreen>
  );
}

// =====================================================
// INTRO
// =====================================================

export function IntroScreen({ onNext }: { onNext: () => void }) {
  return (
    <CenterScreen>
      <div className="animate-bob text-[80px] leading-none">😌</div>

      <h2 className="mt-4 text-[32px] leading-tight font-bold text-white">Achha Sadiya...</h2>

      <p className="mt-1 text-base text-gray-300">Ab jab itni door aa hi gayi ho...</p>

      <p className="mt-6 text-[19px] font-bold text-[#FF8BD7]">
        Ek chhota sa game kheloge? 👀
      </p>

      <div className="mt-8 w-full">
        <PinkButton onClick={onNext}>CHALO 😈</PinkButton>
      </div>
    </CenterScreen>
  );
}

// =====================================================
// QUESTIONS
// =====================================================

const QUESTIONS: { q: string; options: string[] }[] = [
  {
    q: "Perfect evening tumhare liye kya hai? 🌙",
    options: ["🌆 Long drive", "☕ Chai + baatein", "🎬 Movie night", "🌃 Bas shanti"],
  },
  {
    q: "Agar tumhe ek surprise mile to? 🎁",
    options: ["🌹 Flowers", "🍫 Chocolate", "🧸 Cute teddy", "🤫 Secret surprise"],
  },
  {
    q: "Tumhara mood instantly kis cheez se achha hota hai? ✨",
    options: ["😂 Funny baatein", "🎵 Music", "🍕 Favourite food", "🫶 Someone special"],
  },
  {
    q: "Ek din ke liye superpower mile to? 🦸‍♀️",
    options: ["🪽 Fly karna", "⏳ Time travel", "🧠 Mind read", "✨ Magic"],
  },
];

export function QuizScreen({ onDone }: { onDone: (answers: string[]) => void }) {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [picked, setPicked] = useState<string | null>(null);

  const current = QUESTIONS[index];

  const choose = (answer: string) => {
    if (picked) return;
    setPicked(answer);

    window.setTimeout(() => {
      const next = [...answers, answer];
      setPicked(null);
      if (index < QUESTIONS.length - 1) {
        setAnswers(next);
        setIndex(index + 1);
      } else {
        onDone(next);
      }
    }, 320);
  };

  return (
    <CenterScreen>
      <p className="text-[13px] font-bold tracking-wide text-[#FF67C3]">SADIYA'S VIBE CHECK 💗</p>

      <p className="mt-4 text-sm text-gray-500">
        {index + 1} / {QUESTIONS.length}
      </p>

      <div className="mt-3 flex w-40 gap-1.5">
        {QUESTIONS.map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-1 flex-1 rounded-full transition-colors duration-300",
              i <= index ? "bg-[#FF3EA5]" : "bg-white/15",
            )}
          />
        ))}
      </div>

      <div key={index} className="flex w-full animate-fade-up flex-col items-center">
        <h2 className="mt-6 mb-6 text-[26px] leading-snug font-bold text-white">{current.q}</h2>

        <div className="flex w-full flex-col gap-2.5">
          {current.options.map((option) => (
            <AnswerButton
              key={option}
              text={option}
              selected={picked === option}
              disabled={picked !== null}
              onClick={() => choose(option)}
            />
          ))}
        </div>
      </div>

      <p className="mt-6 text-xs text-gray-500">Koi right ya wrong answer nahi hai 😌</p>
    </CenterScreen>
  );
}

// =====================================================
// REACTION
// =====================================================

export function ReactionScreen({
  answers,
  onNext,
}: {
  answers: string[];
  onNext: () => void;
}) {
  return (
    <CenterScreen>
      <div className="text-[56px] leading-none font-black text-white">HMMM... 👀</div>

      <h2 className="mt-4 text-[27px] leading-snug font-bold text-white">
        Interesting choices, Sadiya...
      </h2>

      {answers.length > 0 && (
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          {answers.map((a, i) => (
            <span
              key={`${a}-${i}`}
              className="animate-fade-up rounded-full border border-[#FF67C3]/30 bg-white/[0.07] px-3.5 py-1.5 text-sm text-white"
              style={{ animationDelay: `${i * 120 + 200}ms` }}
            >
              {a}
            </span>
          ))}
        </div>
      )}

      <p className="mt-5 text-[17px] text-[#FF8BD7]">Tumhari choices kaafi cute hain 😌💗</p>

      <div className="mt-8 w-full">
        <PinkButton onClick={onNext}>AB EK SECRET HAI 🔐</PinkButton>
      </div>
    </CenterScreen>
  );
}

// =====================================================
// SECRET
// =====================================================

export function SecretScreen({ onNext }: { onNext: () => void }) {
  return (
    <CenterScreen>
      <div className="animate-bob text-[80px] leading-none">🔐</div>

      <h2 className="mt-2.5 text-3xl font-black text-white">SECRET LEVEL</h2>

      <p className="mt-4 text-xl text-[#FF7CCB]">Sadiya, ek baat bataun?</p>

      <div className="mt-6 w-full rounded-[20px] border border-white/10 bg-white/[0.13] p-6 text-[17px] leading-relaxed text-white backdrop-blur-sm">
        <p>Tumhare liye ye app banana tha...</p>
        <p className="mt-5">kyunki simple message bhejna bahut normal hota. 😌</p>
        <p className="mt-5">Thoda effort to banta hai ❤️</p>
      </div>

      <div className="mt-8 w-full">
        <PinkButton onClick={onNext}>LAST SURPRISE 🎁</PinkButton>
      </div>
    </CenterScreen>
  );
}

// =====================================================
// FINAL
// =====================================================

export function FinalScreen({ onReplay }: { onReplay: () => void }) {
  return (
    <CenterScreen>
      <div className="animate-heartbeat text-[90px] leading-none">🎁</div>

      <h2 className="mt-2.5 text-[38px] leading-tight font-black text-[#FF65BE] drop-shadow-[0_0_24px_rgba(255,101,190,0.5)]">
        FOR SADIYA
      </h2>

      <p className="mt-5 text-xl leading-snug text-white">
        Kuch logon ke liye
        <br />
        app banaya nahi jaata...
      </p>

      <p className="mt-2.5 text-[21px] leading-snug font-bold text-[#FF9DDA]">
        app banane ka mann ho jaata hai. ❤️
      </p>

      <p className="mt-6 text-[15px] text-gray-300">Bas hamesha aise hi smile karti rehna. ✨</p>

      <div className="mt-9 w-full">
        <PinkButton onClick={onReplay}>REPLAY 😈</PinkButton>
      </div>
    </CenterScreen>
  );
}
