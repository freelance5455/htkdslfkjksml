import { resumeAudio, startEngine } from "../game/audio";
import { resetInput } from "../game/input";
import { useGame } from "../game/store";
import { startRun } from "../game/world";
import { faNumber } from "../utils/fa";

function Key({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-lg border border-white/15 bg-white/10 px-2.5 py-1 font-mono text-xs text-white shadow-[inset_0_-2px_0_rgba(0,0,0,0.35)]">
      {children}
    </span>
  );
}

export default function Screens() {
  const g = useGame();

  const begin = () => {
    resetInput();
    resumeAudio();
    startEngine();
    startRun();
  };

  if (g.phase === "menu") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-gradient-to-b from-slate-950/80 via-slate-950/60 to-slate-950/90 px-4 backdrop-blur-sm">
        <div className="animate-fade-up w-full max-w-lg text-center">
          <div className="mb-3 text-xs tracking-[0.4em] text-cyan-300/70">
            مسابقه‌ی سه‌بعدی
          </div>
          <h1 className="bg-gradient-to-b from-white via-cyan-100 to-cyan-400 bg-clip-text text-6xl font-black text-transparent drop-shadow-[0_0_28px_rgba(79,227,255,0.45)]">
            نئون درایو
          </h1>
          <p className="mx-auto mt-4 max-w-md text-sm leading-7 text-white/65">
            توی جاده‌ی شبانه شتاب بگیر، از ماشین‌های رو به رو جاخالی کن و
            سلول‌های انرژی رو جمع کن. هر چقدر دورتر بشی، سرعت بیشتر می‌شه!
          </p>

          <div className="mx-auto mt-6 grid max-w-md grid-cols-2 gap-3 text-right text-xs text-white/70">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="mb-2 text-[11px] text-cyan-300/80">فرمان دادن</div>
              <div className="flex items-center gap-2">
                <Key>←</Key>
                <Key>→</Key>
                <span className="text-white/55">یا</span>
                <Key>A</Key>
                <Key>D</Key>
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="mb-2 text-[11px] text-cyan-300/80">شتاب و ترمز</div>
              <div className="flex items-center gap-2">
                <Key>↑</Key>
                <Key>↓</Key>
                <span className="text-white/55">یا</span>
                <Key>W</Key>
                <Key>S</Key>
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="mb-2 text-[11px] text-cyan-300/80">نیترو</div>
              <div className="flex items-center gap-2">
                <Key>Shift</Key>
                <span className="text-white/55">یا</span>
                <Key>Space</Key>
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="mb-2 text-[11px] text-cyan-300/80">شروع / ادامه</div>
              <div className="flex items-center gap-2">
                <Key>Enter</Key>
                <span className="text-white/55">یا دکمه‌ی زیر</span>
              </div>
            </div>
          </div>

          <button
            onClick={begin}
            className="group mt-8 rounded-2xl bg-gradient-to-l from-cyan-400 to-fuchsia-500 px-10 py-4 text-lg font-bold text-slate-950 shadow-[0_0_36px_rgba(79,227,255,0.45)] transition hover:scale-105 hover:shadow-[0_0_50px_rgba(168,85,247,0.6)] active:scale-95"
          >
            شروع بازی
          </button>

          <div className="mt-5 text-xs text-white/45">
            رکورد شما:{" "}
            <span className="font-mono font-bold text-amber-300">
              {faNumber(g.best)}
            </span>
          </div>
        </div>
      </div>
    );
  }

  if (g.phase === "gameover") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-gradient-to-b from-rose-950/70 via-slate-950/70 to-slate-950/90 px-4 backdrop-blur-sm">
        <div className="animate-pop w-full max-w-md rounded-3xl border border-white/10 bg-slate-950/70 p-8 text-center shadow-[0_0_60px_rgba(255,77,109,0.25)]">
          <div className="text-5xl">💥</div>
          <h2 className="mt-3 text-4xl font-black text-rose-400 drop-shadow-[0_0_24px_rgba(255,77,109,0.6)]">
            تصادف!
          </h2>
          <p className="mt-2 text-sm text-white/55">
            ماشینت رفت روی جدول! امتیاز بازی بعدی رو بزن.
          </p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] text-white/50">امتیاز</div>
              <div className="font-mono text-2xl font-bold text-white tabular-nums">
                {faNumber(g.score)}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] text-white/50">بهترین رکورد</div>
              <div className="font-mono text-2xl font-bold text-amber-300 tabular-nums">
                {faNumber(Math.max(g.best, g.score))}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] text-white/50">مسافت</div>
              <div className="font-mono text-2xl font-bold text-cyan-300 tabular-nums">
                {faNumber(g.distance)}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] text-white/50">سلول انرژی</div>
              <div className="font-mono text-2xl font-bold text-fuchsia-300 tabular-nums">
                {faNumber(g.pickups)}
              </div>
            </div>
          </div>

          <button
            onClick={begin}
            className="mt-7 w-full rounded-2xl bg-gradient-to-l from-cyan-400 to-fuchsia-500 px-8 py-4 text-lg font-bold text-slate-950 shadow-[0_0_32px_rgba(79,227,255,0.4)] transition hover:scale-[1.02] active:scale-95"
          >
            شروع دوباره
          </button>
          <div className="mt-3 text-[11px] text-white/40">
            کلید Enter هم کار می‌کنه
          </div>
        </div>
      </div>
    );
  }

  if (g.phase === "crashed") {
    return (
      <div className="pointer-events-none absolute inset-0 z-20">
        <div className="absolute inset-0 bg-rose-900/20" />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-4xl font-black text-rose-300 drop-shadow-[0_0_30px_rgba(255,77,109,0.8)]">
          BOOM!
        </div>
      </div>
    );
  }

  return null;
}
