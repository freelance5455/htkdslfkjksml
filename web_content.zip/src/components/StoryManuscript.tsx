import React, { useState } from 'react';
import { Edit3, Check, BookOpen, Clock, FileText, Sparkles, Copy, Undo2 } from 'lucide-react';
import { AlternativeHook } from '../types';

interface StoryManuscriptProps {
  title: string;
  storyText: string;
  originalOpening: string;
  onUpdateStory: (text: string) => void;
  alternativeHooks: AlternativeHook[];
  onRequestContinuation: () => void;
  isContinuing: boolean;
}

export const StoryManuscript: React.FC<StoryManuscriptProps> = ({
  title,
  storyText,
  originalOpening,
  onUpdateStory,
  alternativeHooks,
  onRequestContinuation,
  isContinuing,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);

  const wordCount = storyText.trim() ? storyText.trim().split(/\s+/).length : 0;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  const handleCopy = () => {
    navigator.clipboard.writeText(storyText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSelectAlternativeHook = (hook: AlternativeHook) => {
    // Replace opening paragraph or append
    if (confirm(`Switch opening paragraph to the "${hook.style}"?`)) {
      onUpdateStory(hook.paragraph);
    }
  };

  const handleResetToOriginal = () => {
    if (confirm('Revert manuscript to the original ghostwritten opening?')) {
      onUpdateStory(originalOpening);
    }
  };

  return (
    <div className="rounded-2xl border border-stone-800 bg-stone-900/60 backdrop-blur-sm p-6 sm:p-8 shadow-xl space-y-6 relative">
      {/* Decorative top brass accent line */}
      <div className="w-16 h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto rounded-full" />

      {/* Header with Title and Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-800/80 pb-4">
        <div className="space-y-1">
          <span className="text-[10px] tracking-widest uppercase font-bold text-amber-500">
            Ghostwritten Manuscript
          </span>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-stone-100 tracking-wider">
            {title || 'Opening Scene'}
          </h2>
        </div>

        {/* Action badges */}
        <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className={`px-3 py-1.5 rounded-lg border font-medium flex items-center gap-1.5 transition-all ${
              isEditing
                ? 'bg-amber-500 text-stone-950 border-amber-400 font-semibold shadow-md shadow-amber-500/20'
                : 'bg-stone-950/80 text-stone-300 border-stone-800 hover:bg-stone-800'
            }`}
          >
            {isEditing ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Done Editing</span>
              </>
            ) : (
              <>
                <Edit3 className="w-3.5 h-3.5 text-stone-400" />
                <span>Edit Manuscript</span>
              </>
            )}
          </button>

          <button
            onClick={handleCopy}
            className="p-2 rounded-lg bg-stone-950/80 hover:bg-stone-800 text-stone-300 border border-stone-800 transition-colors"
            title="Copy text"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {storyText !== originalOpening && (
            <button
              onClick={handleResetToOriginal}
              className="p-2 rounded-lg bg-stone-950/80 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-800 transition-colors"
              title="Revert to initial opening"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Manuscript Text Body */}
      {isEditing ? (
        <div className="space-y-2">
          <textarea
            value={storyText}
            onChange={(e) => onUpdateStory(e.target.value)}
            rows={10}
            className="w-full p-4 rounded-xl bg-stone-950/90 border border-stone-700/80 font-serif-story text-stone-100 text-lg leading-relaxed focus:outline-none focus:border-amber-500 resize-y shadow-inner"
            placeholder="Write or edit your story here..."
          />
          <p className="text-[11px] text-stone-500 italic">
            You have full freedom to edit, polish, or append your own words to the ghostwriter's foundation.
          </p>
        </div>
      ) : (
        <div className="prose prose-invert max-w-none">
          {/* Split paragraphs */}
          <div className="space-y-4 text-stone-200 font-serif-story text-lg sm:text-xl leading-relaxed tracking-wide select-text">
            {storyText.split('\n\n').map((paragraph, index) => {
              if (!paragraph.trim()) return null;
              return (
                <p
                  key={index}
                  className={index === 0 ? 'story-drop-cap' : 'indent-6 sm:indent-8'}
                >
                  {paragraph}
                </p>
              );
            })}
          </div>
        </div>
      )}

      {/* Word Count & Stats Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-stone-800/80 text-xs text-stone-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-stone-500" />
            <strong className="text-stone-300 font-medium">{wordCount}</strong> words
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-stone-500" />
            ~{readingTime} min read
          </span>
        </div>

        {/* Continuation Button */}
        <button
          onClick={onRequestContinuation}
          disabled={isContinuing}
          className="px-3.5 py-1.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-200 text-xs font-medium border border-stone-700/60 transition-all hover:scale-105 active:scale-95 disabled:opacity-50 flex items-center gap-1.5"
        >
          {isContinuing ? (
            <>
              <div className="w-3.5 h-3.5 rounded-full border-2 border-stone-400 border-t-transparent animate-spin" />
              <span>Weaving Next Passage...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Continue Story With Ghostwriter</span>
            </>
          )}
        </button>
      </div>

      {/* Alternative Opening Variations */}
      {alternativeHooks && alternativeHooks.length > 0 && (
        <div className="pt-2 border-t border-stone-800/50 space-y-3">
          <div className="flex items-center gap-2 text-xs text-stone-400">
            <BookOpen className="w-3.5 h-3.5 text-amber-500" />
            <span className="font-medium text-stone-300">
              Alternative Opening Variations for this scene:
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {alternativeHooks.map((hook, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-stone-950/40 border border-stone-800/80 hover:border-amber-500/40 transition-colors space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-amber-400">
                    {hook.style}
                  </span>
                  <button
                    onClick={() => handleSelectAlternativeHook(hook)}
                    className="text-[11px] px-2 py-0.5 rounded bg-stone-800 hover:bg-amber-500 hover:text-stone-950 text-stone-300 font-medium transition-colors"
                  >
                    Use Hook
                  </button>
                </div>
                <p className="font-serif-story text-xs text-stone-300 line-clamp-3 leading-relaxed italic">
                  "{hook.paragraph}"
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
