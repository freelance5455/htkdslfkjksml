import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Transaction, ExpenseCategory } from '../types';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Plus,
  TrendingUp,
  PieChart,
  Coffee,
  ShoppingBag,
  Bus,
  Dumbbell,
  Zap,
  Home,
  Sparkles,
  ChevronRight,
  Receipt,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const MoneyManagerScreen: React.FC = () => {
  const {
    transactions,
    addTransaction,
    monthlyBudget,
    setMonthlyBudget,
    totalExpense,
    totalIncome,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'expense' | 'income'>('all');
  const [isAdding, setIsAdding] = useState(false);

  // New transaction form
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'expense' | 'income'>('expense');
  const [category, setCategory] = useState<ExpenseCategory>('Food & Dining');

  const netSavings = totalIncome - totalExpense;
  const remainingBudget = Math.max(0, monthlyBudget - totalExpense);
  const budgetRatio = Math.min(100, Math.round((totalExpense / monthlyBudget) * 100));

  const categoryIcons: Record<string, any> = {
    'Food & Dining': Coffee,
    Shopping: ShoppingBag,
    Transport: Bus,
    Wellness: Dumbbell,
    Utilities: Zap,
    Housing: Home,
    Income: ArrowDownLeft,
  };

  // Group expenses by category
  const categoryTotals: Record<string, number> = {};
  transactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    });

  const categories = Object.entries(categoryTotals).map(([cat, total]) => ({
    name: cat,
    total,
    percentage: totalExpense > 0 ? Math.round((total / totalExpense) * 100) : 0,
  }));

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!title.trim() || isNaN(val) || val <= 0) return;

    addTransaction({
      title: title.trim(),
      amount: val,
      type,
      category: type === 'income' ? 'Income' : category,
      date: 'Today, ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      iconName: type === 'income' ? 'ArrowDownLeft' : 'Receipt',
    });

    setTitle('');
    setAmount('');
    setIsAdding(false);
  };

  const filteredTransactions = transactions.filter((t) => {
    if (activeFilter === 'expense') return t.type === 'expense';
    if (activeFilter === 'income') return t.type === 'income';
    return true;
  });

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-4">
      {/* 1. Header & Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Money Manager
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Intelligent personal finance & budget tracking
          </p>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            setIsAdding(true);
          }}
          className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add</span>
        </button>
      </div>

      {/* 2. Total Balance & Cash Flow Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white shadow-xl shadow-slate-900/20 space-y-4">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-300">
            Net Monthly Savings
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl font-extrabold font-mono tabular-nums">
              ${netSavings.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-emerald-400 font-medium">
              +{Math.round((netSavings / (totalIncome || 1)) * 100)}% savings rate
            </span>
          </div>
        </div>

        {/* Income vs Expense strip */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider">Income</p>
              <p className="text-sm font-bold font-mono text-emerald-300 tabular-nums">
                +${totalIncome.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider">Expenses</p>
              <p className="text-sm font-bold font-mono text-rose-300 tabular-nums">
                -${totalExpense.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Monthly Budget Gauge */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <Wallet className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Budget Target
            </span>
          </div>
          <span className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300">
            ${totalExpense.toFixed(0)} / ${monthlyBudget}
          </span>
        </div>

        <div className="w-full bg-slate-100 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              budgetRatio > 85
                ? 'bg-rose-500'
                : budgetRatio > 70
                ? 'bg-amber-500'
                : 'bg-emerald-500'
            }`}
            style={{ width: `${budgetRatio}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>{budgetRatio}% consumed</span>
          <span className="font-semibold text-emerald-600 dark:text-emerald-400">
            ${remainingBudget.toFixed(2)} remaining this month
          </span>
        </div>
      </div>

      {/* 4. AI Financial Insight Coach */}
      <div className="p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200/70 dark:border-indigo-800/60 flex items-start gap-3">
        <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0 mt-0.5">
          <Sparkles className="w-3.5 h-3.5" />
        </div>
        <div className="text-xs">
          <p className="font-bold text-indigo-950 dark:text-indigo-200">
            HiBuddy Financial Recommendation
          </p>
          <p className="text-indigo-800/80 dark:text-indigo-300 mt-0.5 leading-relaxed">
            You're on track to save <span className="font-semibold">$450</span> this month! Dining out is 12% lower than last week. Reinvesting that into your Emergency Fund goal will advance milestone #4.
          </p>
        </div>
      </div>

      {/* 5. Spending by Category Breakdown */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Spending Analytics
          </h3>
          <span className="text-[11px] text-slate-400">This Month</span>
        </div>

        <div className="space-y-2.5">
          {categories.map((c) => (
            <div key={c.name} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700 dark:text-slate-300">
                  {c.name}
                </span>
                <span className="font-mono text-slate-500 dark:text-slate-400">
                  ${c.total.toFixed(2)} ({c.percentage}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-600 dark:bg-indigo-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${c.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Add Transaction Modal */}
      {isAdding && (
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Log Transaction
            </h4>
            <button
              onClick={() => setIsAdding(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleAdd} className="space-y-3">
            {/* Type selector */}
            <div className="flex rounded-xl bg-slate-100 dark:bg-slate-700 p-1">
              <button
                type="button"
                onClick={() => setType('expense')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  type === 'expense'
                    ? 'bg-white dark:bg-slate-800 text-rose-600 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                Expense
              </button>
              <button
                type="button"
                onClick={() => setType('income')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  type === 'income'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                Income
              </button>
            </div>

            <input
              type="text"
              required
              placeholder="What was this for? (e.g. Lunch with team)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Amount ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white font-mono"
                />
              </div>

              {type === 'expense' && (
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="Food & Dining">Food & Dining</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Transport">Transport</option>
                    <option value="Housing">Housing</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Wellness">Wellness</option>
                  </select>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
            >
              Save Transaction
            </button>
          </form>
        </div>
      )}

      {/* 7. Transactions List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight">
            Recent Activity
          </h3>

          <div className="flex items-center gap-1 text-xs">
            {(['all', 'expense', 'income'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => {
                  sound.playClick();
                  setActiveFilter(filter);
                }}
                className={`px-2.5 py-0.5 rounded-md capitalize transition-colors ${
                  activeFilter === filter
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          {filteredTransactions.map((tx) => {
            const IconComponent = categoryIcons[tx.category] || Receipt;
            const isExp = tx.type === 'expense';
            return (
              <div
                key={tx.id}
                className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      isExp
                        ? 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                        : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                      {tx.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {tx.category} · {tx.date}
                    </p>
                  </div>
                </div>

                <span
                  className={`text-sm font-bold font-mono shrink-0 tabular-nums ${
                    isExp ? 'text-slate-900 dark:text-white' : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {isExp ? '-' : '+'}${tx.amount.toFixed(2)}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
