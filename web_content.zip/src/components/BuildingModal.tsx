import React from 'react';
import { GameEngine } from '../game/engine';
import { BuildingType } from '../types/game';
import { HotbarItemIcon } from './HUD';
import { X, Check, Tent } from 'lucide-react';

interface BuildingModalProps {
  engine: GameEngine;
  onClose: () => void;
}

const BUILD_OPTIONS: { type: BuildingType; nameAr: string; descAr: string; itemId: string }[] = [
  {
    type: 'wood_floor',
    nameAr: 'أرضية خشبية',
    descAr: 'قاعدة المأوى، ويمكن مدها فوق المياه والبرك كجسور للمرور.',
    itemId: 'wood_floor',
  },
  {
    type: 'wood_wall',
    nameAr: 'جدار خشبي متين',
    descAr: 'حاجز صلب يحميك داخل المأوى ويمنع تقدم الوحوش والذئاب.',
    itemId: 'wood_wall',
  },
  {
    type: 'wood_door',
    nameAr: 'باب خشبي',
    descAr: 'باب قابل للفتح والإغلاق لمنع الوحوش من الدخول ليلاً.',
    itemId: 'wood_door',
  },
  {
    type: 'campfire',
    nameAr: 'موقد نار دافئ',
    descAr: 'مصدر ضوء ليلي، يطرد وحوش الظلام ويسمح بطهي اللحوم والفواكه.',
    itemId: 'campfire',
  },
  {
    type: 'chest',
    nameAr: 'صندوق تخزين خشب',
    descAr: 'يوفر 8 خانات تخزين إضافية لحفظ المواد والأدوات النادرة.',
    itemId: 'chest',
  },
];

export const BuildingModal: React.FC<BuildingModalProps> = ({ engine, onClose }) => {
  const getItemCount = (itemId: string) => {
    let count = 0;
    for (const slot of engine.inventory) {
      if (slot && slot.item === itemId) count += slot.count;
    }
    return count;
  };

  const handleSelectBuilding = (type: BuildingType) => {
    engine.activeBuildingGhost = type;
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-lg bg-neutral-900 border-2 border-emerald-600/80 rounded-2xl shadow-2xl p-4 sm:p-6 text-white flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-700 pb-3">
          <div className="flex items-center gap-2">
            <Tent className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base sm:text-lg font-bold text-emerald-300">نظام البناء وتشييد المأوى</h2>
          </div>
          <button
            id="btn-close-building"
            onClick={onClose}
            className="p-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-neutral-300 leading-relaxed">
          اختر نوع الهيكل لوضع المعاينة الشفافة (Ghost Mode). بعد الاختيار، انقر على الخريطة ضمن نطاق اللاعب للبناء على الشبكة (32×32).
        </p>

        {/* Building Structures List */}
        <div className="flex flex-col gap-2.5">
          {BUILD_OPTIONS.map((opt) => {
            const count = getItemCount(opt.itemId);
            const hasItem = count > 0;
            const isCurrentGhost = engine.activeBuildingGhost === opt.type;

            return (
              <div
                key={opt.type}
                className={`flex items-center justify-between p-3 rounded-xl border transition ${
                  isCurrentGhost
                    ? 'bg-emerald-950/60 border-emerald-400'
                    : hasItem
                    ? 'bg-neutral-950/80 border-neutral-700 hover:border-neutral-500'
                    : 'bg-neutral-950/40 border-neutral-800/80 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-neutral-800 rounded-lg border border-neutral-700 flex items-center justify-center shrink-0">
                    <HotbarItemIcon itemId={opt.itemId} />
                  </div>
                  <div className="flex flex-col text-right">
                    <span className="text-sm font-bold text-white">{opt.nameAr}</span>
                    <span className="text-xs text-neutral-400">{opt.descAr}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`text-xs font-mono font-bold px-2 py-1 rounded border ${
                      hasItem
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                        : 'bg-red-950 text-red-400 border-red-800'
                    }`}
                  >
                    متوفر: {count}
                  </span>

                  <button
                    id={`btn-select-build-${opt.type}`}
                    onClick={() => handleSelectBuilding(opt.type)}
                    disabled={!hasItem}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                      isCurrentGhost
                        ? 'bg-emerald-500 text-black font-black'
                        : hasItem
                        ? 'bg-emerald-700 hover:bg-emerald-600 text-white cursor-pointer active:scale-95'
                        : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                    }`}
                  >
                    {isCurrentGhost && <Check className="w-3.5 h-3.5" />}
                    <span>{isCurrentGhost ? 'محدد حالياً' : 'تحديد للبناء'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
