import React, { useState, useEffect } from 'react';
import {
  Search,
  Bookmark,
  ArrowRight,
  Globe,
  Pill,
  Thermometer,
  ShieldAlert,
  Activity,
  HeartPulse,
  Flame,
  Droplet,
  Wind,
  Bug,
  ShieldPlus,
  Sparkles,
  Share2,
  Check,
  UtensilsCrossed
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { MEDICINES_DATA } from '../data/medicineData';
import { MedicineItem, MedicineLanguage, MedicineCategory } from '../types/medicine';
import { MedicineDetailView } from './MedicineDetailView';

interface MedicineEducationViewProps {
  onBack: () => void;
}

export const MedicineEducationView: React.FC<MedicineEducationViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<MedicineLanguage>('English');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMedicine, setSelectedMedicine] = useState<MedicineItem | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // Load bookmarks
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_bookmarked_medicines');
      if (saved) {
        setBookmarkedIds(JSON.parse(saved));
      }
    } catch (err) {
      console.warn('Failed to load bookmarked medicines:', err);
    }
  }, []);

  // Toggle bookmark
  const toggleBookmark = (medicineId: string) => {
    setBookmarkedIds((prev) => {
      let updated: string[];
      if (prev.includes(medicineId)) {
        updated = prev.filter((id) => id !== medicineId);
      } else {
        updated = [...prev, medicineId];
      }
      try {
        localStorage.setItem('mediguide_bookmarked_medicines', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save bookmarked medicines:', err);
      }
      return updated;
    });
  };

  // Helper to render category icon
  const renderCategoryIcon = (category: string) => {
    switch (category) {
      case 'Antibiotics': return <span className="text-xl">💊</span>;
      case 'Pain Relievers': return <span className="text-xl">🤒</span>;
      case 'Fever Medicines': return <span className="text-xl">🌡</span>;
      case 'Cold & Cough Medicines': return <span className="text-xl">🤧</span>;
      case 'Blood Pressure Medicines': return <span className="text-xl">❤️</span>;
      case 'Diabetes Medicines': return <span className="text-xl">🩸</span>;
      case 'Vitamins & Supplements': return <span className="text-xl">🌿</span>;
      case 'Anti-Allergy Medicines': return <span className="text-xl">🤢</span>;
      case 'Digestive Medicines': return <span className="text-xl">🍽</span>;
      case 'Antifungal Medicines': return <span className="text-xl">🦠</span>;
      case 'Antibiotic Ointments': return <span className="text-xl">💉</span>;
      case 'Asthma Medicines': return <span className="text-xl">🫁</span>;
      default: return <Pill className="w-5 h-5 text-white" />;
    }
  };

  // Quick Share Card
  const handleQuickShare = async (e: React.MouseEvent, medicine: MedicineItem) => {
    e.stopPropagation();
    const content = medicine.content[selectedLanguage] || medicine.content.English;
    const text = `💊 ${content.name}\nGeneric: ${content.genericName}\nBrands: ${content.brandNames.join(', ')}\n\n${content.description}\n\nLearn more on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.name,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(medicine.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Failed to copy:', err);
    }
  };

  // 12 Requested Categories with Trilingual names
  const categoryCards: { id: MedicineCategory; emoji: string; nameEn: string; nameHi: string; nameMr: string }[] = [
    { id: 'Antibiotics', emoji: '💊', nameEn: 'Antibiotics', nameHi: 'एंटीबायोटिक्स', nameMr: 'अँटीबायोटिक्स' },
    { id: 'Pain Relievers', emoji: '🤒', nameEn: 'Pain Relievers', nameHi: 'दर्द निवारक', nameMr: 'वेदनाशामक' },
    { id: 'Fever Medicines', emoji: '🌡', nameEn: 'Fever Medicines', nameHi: 'बुखार की दवाएं', nameMr: 'तापाची औषधे' },
    { id: 'Cold & Cough Medicines', emoji: '🤧', nameEn: 'Cold & Cough Medicines', nameHi: 'सर्दी और खांसी', nameMr: 'सर्दी व खोकला' },
    { id: 'Blood Pressure Medicines', emoji: '❤️', nameEn: 'Blood Pressure Medicines', nameHi: 'बीपी की दवाएं', nameMr: 'रक्तदाबाची औषधे' },
    { id: 'Diabetes Medicines', emoji: '🩸', nameEn: 'Diabetes Medicines', nameHi: 'शुगर / डायबिटीज', nameMr: 'मधुमेहाची औषधे' },
    { id: 'Vitamins & Supplements', emoji: '🌿', nameEn: 'Vitamins & Supplements', nameHi: 'विटामिन और सप्लीमेंट्स', nameMr: 'व्हिटॅमिन्स व सप्लीमेंट्स' },
    { id: 'Anti-Allergy Medicines', emoji: '🤢', nameEn: 'Anti-Allergy Medicines', nameHi: 'एंटी-एलर्जी दवाएं', nameMr: 'ॲलर्जीवरील औषधे' },
    { id: 'Digestive Medicines', emoji: '🍽', nameEn: 'Digestive Medicines', nameHi: 'पाचन और एसिडिटी', nameMr: 'पचन व ॲसिडिटी' },
    { id: 'Antifungal Medicines', emoji: '🦠', nameEn: 'Antifungal Medicines', nameHi: 'एंटीफंगल (दाद/खाज)', nameMr: 'अँटीफंगल औषधे' },
    { id: 'Antibiotic Ointments', emoji: '💉', nameEn: 'Antibiotic Ointments', nameHi: 'घाव और मलहम', nameMr: 'मलम व फर्स्ट एड' },
    { id: 'Asthma Medicines', emoji: '🫁', nameEn: 'Asthma Medicines', nameHi: 'दमा और सांस की दवाएं', nameMr: 'दमा व श्वासाची औषधे' }
  ];

  // Filter medicines based on search query and category filter
  const filteredMedicines = MEDICINES_DATA.filter((item) => {
    const content = item.content[selectedLanguage] || item.content.English;
    const query = searchQuery.toLowerCase().trim();

    // Search across name, generic name, brand names, and category
    const matchesSearch =
      !query ||
      content.name.toLowerCase().includes(query) ||
      content.genericName.toLowerCase().includes(query) ||
      content.categoryName.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query) ||
      content.brandNames.some((brand) => brand.toLowerCase().includes(query));

    // Category filter
    let matchesCategory = true;
    if (selectedCategory === 'Bookmarked') {
      matchesCategory = bookmarkedIds.includes(item.id);
    } else if (selectedCategory !== 'All') {
      matchesCategory = item.category === selectedCategory;
    }

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Medicine Education"
        subtitle="Medicine Education Hub"
        onBack={onBack}
        badge="Verified Pharmacopeia"
        badgeColor="bg-blue-100 text-blue-800 border-blue-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Main Banner Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-700 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 text-white shadow-inner">
                <Pill className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Medicine Education</h1>
                <p className="text-xs text-blue-100 mt-0.5 font-medium">
                  Verified educational guides for dosages, uses, food interactions & precautions.
                </p>
              </div>
            </div>
          </div>

          {/* Language Selector Header Bar */}
          <div className="pt-3 border-t border-white/20 flex flex-wrap items-center justify-between gap-2 text-xs relative z-10">
            <div className="flex items-center gap-1.5 font-bold text-blue-100">
              <Globe className="w-4 h-4 text-blue-200" />
              <span>Language: English (हिन्दी / मराठी)</span>
            </div>

            {/* Language Switcher Tabs */}
            <div className="flex bg-black/25 p-1 rounded-2xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as MedicineLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-white text-blue-900 shadow-md'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Medicine..."
            className="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs text-slate-900"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold bg-slate-100 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Cards Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-500">
              {selectedLanguage === 'Hindi'
                ? 'दवा श्रेणियां (Medicine Categories)'
                : selectedLanguage === 'Marathi'
                ? 'औषध वर्गवारी (Categories)'
                : 'Medicine Categories'}
            </h2>
            {selectedCategory !== 'All' && (
              <button
                onClick={() => setSelectedCategory('All')}
                className="text-xs text-blue-600 font-bold hover:underline cursor-pointer"
              >
                Clear Filter ({selectedCategory})
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {categoryCards.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const title =
                selectedLanguage === 'Hindi'
                  ? cat.nameHi
                  : selectedLanguage === 'Marathi'
                  ? cat.nameMr
                  : cat.nameEn;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'All' : cat.id)}
                  className={`p-3 rounded-2xl border transition-all text-left flex items-center gap-2.5 cursor-pointer shadow-2xs hover:shadow-md ${
                    isSelected
                      ? 'bg-slate-900 text-white border-slate-900 ring-2 ring-slate-900/20'
                      : 'bg-white text-slate-800 border-slate-200/90 hover:border-blue-300 hover:bg-blue-50/40'
                  }`}
                >
                  <span className="text-xl shrink-0">{cat.emoji}</span>
                  <div className="overflow-hidden">
                    <p className="text-xs font-extrabold truncate leading-tight">{title}</p>
                    <p className={`text-[10px] truncate ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                      {cat.nameEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Results Counter & Bookmarks Chip */}
        <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1 pt-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'Bookmarked' ? 'All' : 'Bookmarked')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'Bookmarked'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${bookmarkedIds.length > 0 ? 'fill-amber-500 text-amber-600' : ''}`} />
              <span>Saved ({bookmarkedIds.length})</span>
            </button>
            <span>
              {selectedLanguage === 'Hindi'
                ? `कुल ${filteredMedicines.length} दवाएं उपलब्ध हैं`
                : selectedLanguage === 'Marathi'
                ? `एकूण ${filteredMedicines.length} औषधे उपलब्ध आहेत`
                : `Showing ${filteredMedicines.length} verified medicines`}
            </span>
          </div>

          <span className="text-[11px] text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200 font-semibold">
            {selectedLanguage === 'English' ? 'English' : selectedLanguage === 'Hindi' ? 'हिन्दी' : 'मराठी'}
          </span>
        </div>

        {/* Medicines Grid */}
        {filteredMedicines.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200/80 space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <Pill className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-sm">
              {selectedLanguage === 'Hindi'
                ? 'कोई दवा नहीं मिली'
                : selectedLanguage === 'Marathi'
                ? 'कोणतेही औषध आढळले नाही'
                : 'No Medicines Found'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {selectedCategory === 'Bookmarked'
                ? 'You have not bookmarked any medicine yet. Click the bookmark icon on any medicine card to save it here.'
                : 'Try searching by brand name (e.g., Dolo 650, Crocin, Pan 40, Asthalin, Electral) or generic name.'}
            </p>
            {(searchQuery || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredMedicines.map((medicine) => {
              const content = medicine.content[selectedLanguage] || medicine.content.English;
              const isBookmarked = bookmarkedIds.includes(medicine.id);

              return (
                <motion.div
                  key={medicine.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => setSelectedMedicine(medicine)}
                  className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between space-y-3 cursor-pointer group"
                >
                  <div className="space-y-2">
                    {/* Category & Action buttons */}
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-extrabold ${medicine.badgeBg} ${medicine.badgeText} px-2.5 py-0.5 rounded-lg border`}>
                        {medicine.category}
                      </span>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => toggleBookmark(medicine.id)}
                          className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                            isBookmarked
                              ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                              : 'bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Bookmark Medicine"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-600' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => handleQuickShare(e, medicine)}
                          className="p-1.5 bg-slate-100 text-slate-500 rounded-xl hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                          title="Share Medicine"
                        >
                          {copiedShareId === medicine.id ? (
                            <Check className="w-3.5 h-3.5 text-blue-600" />
                          ) : (
                            <Share2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Title & Brands */}
                    <div className="flex items-start gap-3 pt-1">
                      <div className={`p-3 bg-gradient-to-br ${medicine.bgGradient} rounded-2xl shrink-0 shadow-xs group-hover:scale-105 transition-transform text-white`}>
                        {renderCategoryIcon(medicine.category)}
                      </div>

                      <div className="space-y-1 overflow-hidden">
                        <h3 className="font-extrabold text-sm text-slate-900 leading-snug group-hover:text-blue-700 transition-colors">
                          {content.name}
                        </h3>
                        <p className="text-[11px] font-bold text-blue-600 truncate">
                          Generic: {content.genericName}
                        </p>
                        <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                          {content.description}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Brand Chips */}
                  <div className="flex flex-wrap gap-1">
                    {content.brandNames.slice(0, 3).map((brand, i) => (
                      <span key={i} className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                        {brand}
                      </span>
                    ))}
                    {content.brandNames.length > 3 && (
                      <span className="text-[10px] font-semibold bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-md">
                        +{content.brandNames.length - 3} more
                      </span>
                    )}
                  </div>

                  {/* Bottom bar */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-blue-700">
                    <span className="text-[10px] text-slate-400 font-medium">{content.foodRelation}</span>
                    <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      {selectedLanguage === 'Hindi'
                        ? 'विस्तार से पढ़ें'
                        : selectedLanguage === 'Marathi'
                        ? 'सविस्तर वाचा'
                        : 'View Full Details'}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Medicine Detail Modal */}
      <AnimatePresence>
        {selectedMedicine && (
          <MedicineDetailView
            medicine={selectedMedicine}
            currentLanguage={selectedLanguage}
            onLanguageChange={(lang) => setSelectedLanguage(lang)}
            isBookmarked={bookmarkedIds.includes(selectedMedicine.id)}
            onToggleBookmark={toggleBookmark}
            onClose={() => setSelectedMedicine(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
