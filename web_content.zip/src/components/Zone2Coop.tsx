import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { SPECIES_MAP } from '../data/species.ts';
import { getButlerPerks } from '../utils/gameLogic.ts';
import { Heart, Utensils, Sparkles, Hand, DollarSign, Bot, Clock } from 'lucide-react';

export const Zone2Coop: React.FC = () => {
  const {
    player,
    animalPens,
    feedAnimal,
    petAnimal,
    harvestAnimal,
    toggleAnimalButler,
    sellAnimal,
  } = useGame();

  const [sellModalSpecies, setSellModalSpecies] = useState<string | null>(null);
  const [sellCount, setSellCount] = useState<number>(1);
  const [feedModalSpecies, setFeedModalSpecies] = useState<string | null>(null);

  const pensList = Object.values(animalPens);
  const now = Date.now();

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🐔</span>
          <div>
            <h2 className="text-base font-bold text-amber-300">Khu 2: Trang Trại Chuồng Thú</h2>
            <p className="text-xs text-stone-400">
              Quy chuẩn: 1 Chuồng/Loài (Tối đa 10 con/chuồng) • Sản lượng & EXP nhân theo số cá thể
            </p>
          </div>
        </div>

        <div className="text-xs text-stone-300 bg-stone-800/80 px-3 py-1.5 rounded-lg border border-stone-700">
          <span>Tổng số loài đang nuôi: </span>
          <strong className="text-amber-400">{pensList.length}</strong>
        </div>
      </div>

      {pensList.length === 0 ? (
        <div className="text-center py-12 bg-stone-900/60 rounded-xl border border-stone-800 text-stone-400 text-sm">
          <p>Hiện chưa có chuồng thú nào!</p>
          <p className="mt-1 text-amber-400">Hãy đến Khu 7 (Thương Cảng) để mua giống gia súc, gia cầm.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {pensList.map((pen) => {
            const sp = SPECIES_MAP.get(pen.speciesId);
            if (!sp) return null;

            const isRipe = pen.readyAt && now >= pen.readyAt;
            const remainingSec = pen.readyAt ? Math.max(0, Math.ceil((pen.readyAt - now) / 1000)) : 0;
            const butlerPerk = getButlerPerks(sp.tier);

            return (
              <div
                key={pen.speciesId}
                className={`bg-stone-900/90 border-2 rounded-2xl p-3.5 shadow-md flex flex-col justify-between space-y-3 transition ${
                  isRipe ? 'border-amber-400 ring-2 ring-amber-400/40 bg-amber-950/20' : 'border-stone-800'
                }`}
              >
                {/* Header: Species Icon, Name, Count */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl p-1.5 bg-stone-800 rounded-xl border border-stone-700">
                      {sp.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-bold text-stone-100 text-sm sm:text-base">{sp.name}</h3>
                        <span className="text-[10px] px-1.5 py-0.2 bg-amber-950 text-amber-300 rounded border border-amber-600/50 font-bold">
                          Bậc {sp.tier}
                        </span>
                      </div>
                      <p className="text-xs text-stone-400">
                        Đang nuôi: <strong className="text-amber-400">{pen.count}/10 con</strong> • Cho ra: {sp.harvestProductIcon} {sp.harvestProductName}
                      </p>
                    </div>
                  </div>

                  {/* Sell Button */}
                  <button
                    type="button"
                    onClick={() => {
                      setSellModalSpecies(pen.speciesId);
                      setSellCount(1);
                    }}
                    className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-rose-300 border border-stone-700 transition"
                  >
                    <DollarSign className="w-3 h-3 text-rose-400" />
                    <span>Bán Bớt</span>
                  </button>
                </div>

                {/* 3 Status Bars */}
                <div className="space-y-2 bg-stone-950/60 p-2.5 rounded-xl border border-stone-800/80 text-xs">
                  {/* 1. Hunger */}
                  <div>
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="flex items-center gap-1 text-stone-300 font-semibold">
                        <Utensils className="w-3 h-3 text-amber-400" />
                        Độ No (Cần no 100% để tạo sản phẩm)
                      </span>
                      <strong className={pen.hunger >= 100 ? 'text-emerald-400' : 'text-amber-400'}>
                        {pen.hunger}%
                      </strong>
                    </div>
                    <div className="w-full bg-stone-800 rounded-full h-2 overflow-hidden border border-stone-700">
                      <div
                        className="bg-amber-500 h-full transition-all duration-300"
                        style={{ width: `${pen.hunger}%` }}
                      />
                    </div>
                  </div>

                  {/* 2. Satisfaction */}
                  <div>
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="flex items-center gap-1 text-stone-300 font-semibold">
                        <Sparkles className="w-3 h-3 text-emerald-400" />
                        Độ Hài Lòng Hiện Tại (Reset khi thu hoạch)
                      </span>
                      <strong className="text-emerald-300 font-bold">
                        {pen.satisfaction}% {pen.satisfaction >= 100 ? '(+35% & ⭐)' : pen.satisfaction >= 75 ? '(+20%)' : pen.satisfaction >= 50 ? '(+10%)' : ''}
                      </strong>
                    </div>
                    <div className="w-full bg-stone-800 rounded-full h-2 overflow-hidden border border-stone-700">
                      <div
                        className="bg-emerald-500 h-full transition-all duration-300"
                        style={{ width: `${pen.satisfaction}%` }}
                      />
                    </div>
                  </div>

                  {/* 3. Affection (Permanent) */}
                  <div>
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="flex items-center gap-1 text-stone-300 font-semibold">
                        <Heart className="w-3 h-3 text-rose-400" />
                        Độ Thân Mật Dài Hạn (Vĩnh viễn không reset)
                      </span>
                      <strong className="text-rose-400 font-bold">{pen.affection}%</strong>
                    </div>
                    <div className="w-full bg-stone-800 rounded-full h-2 overflow-hidden border border-stone-700">
                      <div
                        className="bg-rose-500 h-full transition-all duration-300"
                        style={{ width: `${pen.affection}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Butler Section (Unlocks at 100% Affection) */}
                {pen.affection >= 100 && (
                  <div className="bg-purple-950/40 border border-purple-500/40 rounded-xl p-2 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-purple-400" />
                      <div>
                        <div className="font-bold text-purple-300">Quản Gia Tự Động</div>
                        <div className="text-[10px] text-purple-200/80">{butlerPerk.label}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => toggleAnimalButler(pen.speciesId)}
                      className={`px-2.5 py-1 rounded-lg font-bold text-xs transition ${
                        pen.butlerActive
                          ? 'bg-purple-600 text-white shadow ring-1 ring-purple-400'
                          : 'bg-stone-800 text-stone-300 border border-stone-700'
                      }`}
                    >
                      {pen.butlerActive ? 'Đang Bật' : 'Bật Quản Gia'}
                    </button>
                  </div>
                )}

                {/* Action Buttons: Feed, Pet, Harvest */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-1.5">
                    {/* Feed Button */}
                    <button
                      type="button"
                      disabled={pen.hunger >= 100}
                      onClick={() => setFeedModalSpecies(pen.speciesId)}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition ${
                        pen.hunger < 100
                          ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500 shadow'
                          : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
                      }`}
                    >
                      <Utensils className="w-3.5 h-3.5" />
                      <span>{pen.hunger >= 100 ? 'Đã No Đủ' : `Cho Ăn (${pen.count} phần)`}</span>
                    </button>

                    {/* Pet Button */}
                    <button
                      type="button"
                      disabled={pen.isPetToday}
                      onClick={() => petAnimal(pen.speciesId)}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition ${
                        !pen.isPetToday
                          ? 'bg-rose-900/40 hover:bg-rose-900/60 text-rose-300 border-rose-700/60'
                          : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
                      }`}
                    >
                      <Hand className="w-3.5 h-3.5 text-rose-400" />
                      <span>{pen.isPetToday ? 'Đã Vuốt Ve' : 'Vuốt Ve'}</span>
                    </button>
                  </div>

                  {/* Harvest Button or Countdown */}
                  {isRipe ? (
                    <button
                      type="button"
                      onClick={() => harvestAnimal(pen.speciesId)}
                      className="flex items-center gap-1 px-4 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-black border border-amber-300 shadow-lg ring-2 ring-amber-300/60"
                    >
                      <span>✨ Thu Hoạch!</span>
                    </button>
                  ) : pen.readyAt ? (
                    <div className="flex items-center gap-1 text-xs text-stone-400 font-semibold bg-stone-800 px-2.5 py-1.5 rounded-xl border border-stone-700">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>{remainingSec}s</span>
                    </div>
                  ) : (
                    <span className="text-[11px] text-stone-500 italic">Đang đói - cần cho ăn</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Choose Feed Type */}
      {feedModalSpecies && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                <span>🥣</span> Chọn Thức Ăn Cho Đàn Thú
              </h3>
              <button
                type="button"
                onClick={() => setFeedModalSpecies(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            <p className="text-xs text-stone-400">
              Cần cho ăn đủ theo số lượng con trong chuồng ({animalPens[feedModalSpecies]?.count} con).
            </p>

            <div className="space-y-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  feedAnimal(feedModalSpecies, 'basic');
                  setFeedModalSpecies(null);
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-left text-stone-200"
              >
                <div>
                  <div className="font-bold text-amber-300">Thức Ăn Cơ Bản / Yêu Thích</div>
                  <div className="text-[10px] text-stone-400">+50% Hài Lòng • Tốc độ tiêu chuẩn</div>
                </div>
                <span className="font-bold text-amber-400">Cho Ăn</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  feedAnimal(feedModalSpecies, 'premium');
                  setFeedModalSpecies(null);
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-stone-800 hover:bg-stone-700 border border-amber-500/50 text-left text-amber-200"
              >
                <div>
                  <div className="font-bold text-amber-300">✨ Cám Dinh Dưỡng Cao Cấp</div>
                  <div className="text-[10px] text-stone-400">+60% Hài Lòng • Giảm 25% thời gian chờ!</div>
                </div>
                <span className="font-bold text-emerald-400">Cho Ăn</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Sell Animals */}
      {sellModalSpecies && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-rose-300 text-sm flex items-center gap-1.5">
                <span>💰</span> Bán Bớt Vật Nuôi
              </h3>
              <button
                type="button"
                onClick={() => setSellModalSpecies(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            {(() => {
              const pen = animalPens[sellModalSpecies];
              const sp = SPECIES_MAP.get(sellModalSpecies);
              if (!pen || !sp) return null;

              return (
                <div className="space-y-3 text-xs">
                  <p className="text-stone-300">
                    Chọn số lượng <strong>{sp.name}</strong> muốn bán (Hiện có {pen.count} con trong chuồng):
                  </p>

                  <div className="flex items-center justify-center gap-3 py-2 bg-stone-950 rounded-xl border border-stone-800">
                    <button
                      type="button"
                      onClick={() => setSellCount(Math.max(1, sellCount - 1))}
                      className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                    >
                      -
                    </button>
                    <span className="text-lg font-black text-amber-400 w-12 text-center">{sellCount}</span>
                    <button
                      type="button"
                      onClick={() => setSellCount(Math.min(pen.count, sellCount + 1))}
                      className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                    >
                      +
                    </button>
                    <button
                      type="button"
                      onClick={() => setSellCount(pen.count)}
                      className="px-2 py-1 text-[11px] rounded bg-amber-600 hover:bg-amber-500 font-bold text-stone-950"
                    >
                      Tất Cả
                    </button>
                  </div>

                  <div className="text-center text-stone-400">
                    Thu về: <strong className="text-amber-400 font-bold">{(sp.baseSellPrice * 5 * sellCount).toLocaleString()} 🪙 Vàng</strong>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-stone-800">
                    <button
                      type="button"
                      onClick={() => setSellModalSpecies(null)}
                      className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold"
                    >
                      Hủy
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        sellAnimal(sellModalSpecies, sellCount);
                        setSellModalSpecies(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold"
                    >
                      Xác Nhận Bán
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
