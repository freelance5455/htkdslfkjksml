import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, DollarSign, Smartphone, ArrowRight, ShieldCheck, CheckCircle2, RefreshCw, Sparkles, Wallet, Building2, Cpu, Wrench, Globe, ExternalLink, ArrowLeft, History, Lock, Check, Activity } from 'lucide-react';
import { financialMessenger, AirtimeToCashRequest, DataToCryptoRequest } from '../lib/financialMessenger';
import { imsiEngine, ImsiWalletBalances } from '../lib/imsiEngine';
import { ConversionTracker } from './ConversionTracker';

interface ConvertoPageViewProps {
  onBackToOwner?: () => void;
  onOpenWallet?: () => void;
  onOpenImsiData?: () => void;
}

export const ConvertoPageView: React.FC<ConvertoPageViewProps> = ({
  onBackToOwner,
  onOpenWallet,
  onOpenImsiData
}) => {
  const [activeTab, setActiveTab] = useState<'AIRTIME_TO_CASH' | 'DATA_TO_CRYPTO'>('AIRTIME_TO_CASH');
  const [wallet, setWallet] = useState<ImsiWalletBalances>(() => imsiEngine.getWalletBalances());

  // Conversion Tracker Modal State
  const [showTracker, setShowTracker] = useState<boolean>(false);
  const [trackerConfig, setTrackerConfig] = useState<{
    type: 'AIRTIME_TO_CASH' | 'DATA_TO_CRYPTO';
    phoneNumber: string;
    amountText: string;
    carrier: string;
    destinationText: string;
    onFinishCallback?: () => void;
  }>({
    type: 'AIRTIME_TO_CASH',
    phoneNumber: '07071918280',
    amountText: '₦500',
    carrier: 'MTN Nigeria',
    destinationText: 'Opay Bank'
  });

  // Airtime to Cash Engine State
  const [airtimePhone, setAirtimePhone] = useState<string>('07071918280');
  const [airtimeAmountNgn, setAirtimeAmountNgn] = useState<string>('500');
  const [airtimeCarrier, setAirtimeCarrier] = useState<string>('MTN Nigeria 4G/5G');
  const [airtimePayoutTarget, setAirtimePayoutTarget] = useState<'wallet' | 'opay_bank' | 'fidelity_bank' | 'moniepoint_bank'>('opay_bank');
  const [airtimeCustomAccount, setAirtimeCustomAccount] = useState<string>('');
  const [airtimeConverting, setAirtimeConverting] = useState<boolean>(false);
  const [airtimeResult, setAirtimeResult] = useState<{
    cashCreditedNgn: number;
    cashEquivalentUsd: number;
    txHash: string;
    bankRef: string;
    destinationDesc: string;
  } | null>(null);

  // Data to Crypto Engine State
  const [dataPhone, setDataPhone] = useState<string>('07071918280');
  const [dataMbAmount, setDataMbAmount] = useState<string>('2.5');
  const [dataCarrier, setDataCarrier] = useState<string>('MTN Nigeria 4G/5G LTE');
  const [dataPayoutTarget, setDataPayoutTarget] = useState<'wallet' | 'altar_vault' | 'metamask' | 'trust_wallet' | 'minipay'>('altar_vault');
  const [dataCustomWallet, setDataCustomWallet] = useState<string>('');
  const [dataConverting, setDataConverting] = useState<boolean>(false);
  const [dataResult, setDataResult] = useState<{
    dataDeductedMb: number;
    btcAmount: number;
    btcSats: number;
    btcFormatted: string;
    txHash: string;
    bankRef: string;
    destinationDesc: string;
  } | null>(null);

  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 4000);
  };

  useEffect(() => {
    const unsub = imsiEngine.subscribe(() => {
      setWallet(imsiEngine.getWalletBalances());
    });
    return () => unsub();
  }, []);

  // Finalize Airtime to Cash Conversion
  const handleFinalizeAirtimeToCash = async () => {
    if (!airtimePhone.trim()) {
      showToast('❌ Please type in a valid mobile phone number for airtime deduction.');
      return;
    }
    const amount = Number(airtimeAmountNgn);
    if (isNaN(amount) || amount <= 0) {
      showToast('❌ Please enter a valid airtime amount.');
      return;
    }

    let destDesc = 'Opay Mobile Bank (7071918280)';
    if (airtimePayoutTarget === 'wallet') destDesc = 'JUHNKRIX Cash Wallet';
    else if (airtimePayoutTarget === 'fidelity_bank') destDesc = 'Fidelity Bank (6555712574)';
    else if (airtimePayoutTarget === 'moniepoint_bank') destDesc = 'Moniepoint MFB (7071918280)';

    // Launch Real-Time Conversion Tracker Animation
    setTrackerConfig({
      type: 'AIRTIME_TO_CASH',
      phoneNumber: airtimePhone.trim(),
      amountText: `₦${amount} Airtime`,
      carrier: airtimeCarrier,
      destinationText: destDesc
    });
    setShowTracker(true);
    setAirtimeConverting(true);
    setAirtimeResult(null);

    try {
      const request: AirtimeToCashRequest = {
        phoneNumber: airtimePhone.trim(),
        amountNgn: amount,
        carrier: airtimeCarrier,
        payoutTarget: airtimePayoutTarget,
        customAccountNo: airtimeCustomAccount.trim()
      };

      const result = await financialMessenger.executeAirtimeToCashConversion(request);
      setAirtimeResult(result);
    } catch (err: any) {
      showToast(`❌ Conversion error: ${err.message || 'Failed to convert airtime'}`);
      setShowTracker(false);
      setAirtimeConverting(false);
    }
  };

  // Finalize Data to Crypto Conversion
  const handleFinalizeDataToCrypto = async () => {
    if (!dataPhone.trim()) {
      showToast('❌ Please type in a valid mobile phone number for data deduction.');
      return;
    }
    const mb = Number(dataMbAmount);
    if (isNaN(mb) || mb <= 0) {
      showToast('❌ Please enter a valid mobile data (MB) amount.');
      return;
    }

    let destDesc = 'Bitcoin Altar Vault';
    if (dataPayoutTarget === 'wallet') destDesc = 'JUHNKRIX Crypto Wallet';
    else if (dataPayoutTarget === 'metamask') destDesc = 'MetaMask Web3 Wallet';
    else if (dataPayoutTarget === 'trust_wallet') destDesc = 'Trust Wallet';
    else if (dataPayoutTarget === 'minipay') destDesc = 'MiniPay Stablecoin';

    // Launch Real-Time Conversion Tracker Animation
    setTrackerConfig({
      type: 'DATA_TO_CRYPTO',
      phoneNumber: dataPhone.trim(),
      amountText: `${mb} MB Data`,
      carrier: dataCarrier,
      destinationText: destDesc
    });
    setShowTracker(true);
    setDataConverting(true);
    setDataResult(null);

    try {
      const request: DataToCryptoRequest = {
        phoneNumber: dataPhone.trim(),
        dataMb: mb,
        carrier: dataCarrier,
        payoutTarget: dataPayoutTarget,
        customWalletAddress: dataCustomWallet.trim()
      };

      const result = await financialMessenger.executeDataToCryptoConversion(request);
      setDataResult(result);
    } catch (err: any) {
      showToast(`❌ Conversion error: ${err.message || 'Failed to convert mobile data'}`);
      setShowTracker(false);
      setDataConverting(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn text-slate-100 max-w-7xl mx-auto">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border-2 border-amber-400 text-amber-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              {onBackToOwner && (
                <button
                  onClick={onBackToOwner}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-all flex items-center space-x-1 text-xs font-bold"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Owner Dashboard</span>
                </button>
              )}
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
                <Zap className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>CONVERTO • ADVANCED TELECOM CONVERSION POWERHOUSE</span>
              </div>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-amber-100">
              CONVERTO Engines, Machines & Plugins Suite
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl">
              Equipped with professional advance engines, machines, plugins, tools, and elements to instantly convert <strong>AIRTIME to Real Cash Money</strong> and <strong>MOBILE DATA to BITCOIN</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {onOpenWallet && (
              <button
                onClick={onOpenWallet}
                className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-105"
              >
                <Wallet className="w-4 h-4 text-slate-950" />
                <span>JUHNKRIX WALLET</span>
              </button>
            )}

            {onOpenImsiData && (
              <button
                onClick={onOpenImsiData}
                className="px-5 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center space-x-2 transition-all"
              >
                <History className="w-4 h-4 text-amber-400" />
                <span>IMSI DATA INFO</span>
              </button>
            )}
          </div>
        </div>

        {/* Real-Time Balance Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Cash Money Balance</span>
            <div className="text-base font-black text-amber-300">₦{wallet.cashNgn.toLocaleString()}</div>
            <div className="text-[10px] text-slate-500">(${(wallet.cashNgn).toLocaleString()} USD)</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Bitcoin Balance</span>
            <div className="text-base font-black text-amber-300">{wallet.bitcoinSats.toLocaleString()} Sats</div>
            <div className="text-[10px] text-slate-500">{wallet.bitcoinFormatted}</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Airtime Equivalence</span>
            <div className="text-xs font-bold text-emerald-400">1 NGN Airtime = $1 USD</div>
            <div className="text-[10px] text-slate-500">World & Local Bank Synced</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/20 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Data Equivalence</span>
            <div className="text-xs font-bold text-amber-400">1 MB Data = 1 Bitcoin</div>
            <div className="text-[10px] text-slate-500">Blockchain Synced</div>
          </div>
        </div>
      </div>

      {/* CONVERTO Engine Tabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-slate-950 p-2 rounded-3xl border border-amber-500/30">
        <div className="grid grid-cols-2 gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('AIRTIME_TO_CASH')}
            className={`px-6 py-3.5 rounded-2xl text-xs font-black flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'AIRTIME_TO_CASH'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/30 scale-105'
                : 'bg-slate-900 text-slate-400 hover:text-amber-200 border border-slate-800'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>AIRTIME TO CASH MONEY ENGINES AND MACHINES</span>
          </button>

          <button
            onClick={() => setActiveTab('DATA_TO_CRYPTO')}
            className={`px-6 py-3.5 rounded-2xl text-xs font-black flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'DATA_TO_CRYPTO'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-xl shadow-amber-500/30 scale-105'
                : 'bg-slate-900 text-slate-400 hover:text-amber-200 border border-slate-800'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>DATA TO CRYPTOCURRENCY ENGINES AND MACHINES</span>
          </button>
        </div>

        <div className="flex items-center space-x-2 px-4 py-1 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>SMPP v3.4 / Diameter SS7 Active</span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. AIRTIME TO CASH MONEY ENGINES AND MACHINES BLOCK */}
      {/* ========================================================================= */}
      {activeTab === 'AIRTIME_TO_CASH' && (
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8 animate-fadeIn">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-6">
            <div className="space-y-1">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black uppercase">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>AIRTIME → CASH MONEY CONVERTO ENGINE</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
                Airtime Credit to Real Live Cash Money Engine
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm max-w-3xl">
                Type in any mobile phone number to deduct airtime credit from. CONVERTO automatically converts it into real live cash money ($1 per 1 NGN / ₦ Cash) and deposits it directly into your JUHNKRIX WALLET or bank accounts.
              </p>
            </div>

            <div className="px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-300">
              Exchange: 1 Naira Airtime = $1.00 USD / ₦ Cash
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Configuration Column */}
            <div className="space-y-6 bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-amber-500/30">
              <h3 className="text-base font-extrabold text-amber-200 flex items-center space-x-2 border-b border-slate-800 pb-3">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <span>Deduction Mobile Number & Airtime Parameters</span>
              </h3>

              {/* Mobile Phone Number Input Box */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Target Mobile Phone Number (Deduct Airtime Credit From):
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    value={airtimePhone}
                    onChange={(e) => setAirtimePhone(e.target.value)}
                    placeholder="e.g. 07071918280 or +234 803 000 0000"
                    className="w-full bg-slate-950 border-2 border-amber-500/40 focus:border-amber-400 rounded-2xl px-4 py-3.5 text-base font-mono font-bold text-amber-100 focus:outline-none shadow-inner"
                  />
                  <span className="absolute right-3.5 top-3.5 px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                    IMSI ACTIVE
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  CONVERTO powerful telecom networking engines will initiate SS7/Diameter deduction from this SIM.
                </p>
              </div>

              {/* Airtime Amount Selection */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Airtime Amount to Deduct & Convert (₦ NGN):
                </label>
                <input
                  type="number"
                  value={airtimeAmountNgn}
                  onChange={(e) => setAirtimeAmountNgn(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 focus:border-amber-400 rounded-2xl px-4 py-3 text-sm font-bold text-amber-200 focus:outline-none"
                />

                {/* Preset Chips */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {['5', '50', '100', '500', '1000', '5000', '10000'].map((val) => (
                    <button
                      key={val}
                      onClick={() => setAirtimeAmountNgn(val)}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                        airtimeAmountNgn === val
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
                      }`}
                    >
                      ₦{val}
                    </button>
                  ))}
                </div>
              </div>

              {/* Carrier Selection */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  SIM Telecommunication Network Carrier:
                </label>
                <select
                  value={airtimeCarrier}
                  onChange={(e) => setAirtimeCarrier(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="MTN Nigeria 4G/5G">MTN Nigeria (SIM 1 / 4G / 5G)</option>
                  <option value="Airtel Nigeria 5G">Airtel Nigeria (High-Speed)</option>
                  <option value="Glo Mobile Nigeria">Glo Mobile (Unlimited)</option>
                  <option value="9mobile Nigeria">9mobile Network</option>
                  <option value="International Telco Roaming">International Telco Roaming (Global SMPP)</option>
                </select>
              </div>

              {/* Target Payout Destination */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Deposit Live Cash Money Into:
                </label>
                <select
                  value={airtimePayoutTarget}
                  onChange={(e) => setAirtimePayoutTarget(e.target.value as any)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="opay_bank">Opay Mobile Bank (7071918280 - JUHNKRIX STEPHEN)</option>
                  <option value="wallet">JUHNKRIX MUSIKA APP Cash Money Wallet</option>
                  <option value="fidelity_bank">Fidelity Bank (6555712574 - JUHNKRIX STEPHEN)</option>
                  <option value="moniepoint_bank">Moniepoint MFB (7071918280 - JUHNKRIX STEPHEN)</option>
                </select>
              </div>

              {/* FINALIZE BUTTON */}
              <div className="pt-4">
                <button
                  disabled={airtimeConverting}
                  onClick={handleFinalizeAirtimeToCash}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center space-x-2 shadow-2xl shadow-amber-500/40 transition-all hover:scale-[1.02]"
                >
                  {airtimeConverting ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                      <span>DEDUCTING AIRTIME & CONVERTING TO CASH...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-slate-950" />
                      <span>FINALIZE AIRTIME TO CASH CONVERSION</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Live Calculation Preview & Settlement Column */}
            <div className="space-y-6 flex flex-col justify-between">
              <div className="bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-amber-500/30 space-y-5">
                <h3 className="text-base font-extrabold text-amber-200 flex items-center space-x-2 border-b border-slate-800 pb-3">
                  <Cpu className="w-5 h-5 text-amber-400" />
                  <span>CONVERTO Networking Engine Calculations</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Airtime to Deduct:</span>
                    <span className="font-black text-amber-300">₦{Number(airtimeAmountNgn || 0).toLocaleString()} NGN</span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Real Cash Money Credited:</span>
                    <span className="font-black text-emerald-400 text-sm">₦{Number(airtimeAmountNgn || 0).toLocaleString()} NGN</span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Global USD Equivalent:</span>
                    <span className="font-black text-amber-200">${Number(airtimeAmountNgn || 0).toLocaleString()} USD</span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Target SIM:</span>
                    <span className="font-mono text-slate-200">{airtimePhone}</span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className="text-slate-400">Network Settlement Protocol:</span>
                    <span className="font-mono text-amber-400">SMPP / SS7 Live Carrier Bridge</span>
                  </div>
                </div>

                {/* Conversion Success Notification Card */}
                {airtimeResult && (
                  <div className="p-5 bg-emerald-950/80 border-2 border-emerald-400 rounded-2xl space-y-3 animate-fadeIn">
                    <div className="flex items-center space-x-2 text-emerald-300 font-extrabold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>Airtime Converted & Settled Successfully!</span>
                    </div>
                    <div className="text-xs text-emerald-200 space-y-1">
                      <div>Credited: <strong>₦{airtimeResult.cashCreditedNgn.toLocaleString()} NGN (${airtimeResult.cashEquivalentUsd} USD)</strong></div>
                      <div>Destination: <strong>{airtimeResult.destinationDesc}</strong></div>
                      <div className="font-mono text-[10px] text-emerald-400 truncate">Ref: {airtimeResult.bankRef}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Advance Plugins Toolbar Card */}
              <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800 space-y-3">
                <span className="text-[11px] font-bold text-amber-300 uppercase flex items-center space-x-1.5">
                  <Wrench className="w-3.5 h-3.5" />
                  <span>CONVERTO Active Plugins & Hardware Bridges</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400">
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>SMPP Gateway v3.4</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Diameter SS7 Billing</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Opay 7071918280 Auto-Sync</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>142.250.190.46 Magic Fixed IP</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. DATA TO CRYPTOCURRENCY ENGINES AND MACHINES BLOCK */}
      {/* ========================================================================= */}
      {activeTab === 'DATA_TO_CRYPTO' && (
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8 animate-fadeIn">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-6">
            <div className="space-y-1">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>MOBILE DATA → BITCOIN CONVERTO ENGINE</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
                Mobile Data to Bitcoin & Cryptocurrency Engine
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm max-w-3xl">
                Type in any mobile phone number to deduct mobile data bundle credit from. CONVERTO automatically tokenizes it into real live Bitcoin (1 MB = 1 Bitcoin / satoshis) and deposits it into your CRYPTO wallets or Bitcoin Altar Vault.
              </p>
            </div>

            <div className="px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-300">
              Exchange: 1 MB Mobile Data = 1 Bitcoin (100,000,000 Sats)
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Configuration Column */}
            <div className="space-y-6 bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-amber-500/30">
              <h3 className="text-base font-extrabold text-amber-200 flex items-center space-x-2 border-b border-slate-800 pb-3">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <span>Deduction Mobile Number & Mobile Data Parameters</span>
              </h3>

              {/* Mobile Phone Number Input Box */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Target Mobile Phone Number (Deduct Mobile Data Credit From):
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    value={dataPhone}
                    onChange={(e) => setDataPhone(e.target.value)}
                    placeholder="e.g. 07071918280 or +234 803 000 0000"
                    className="w-full bg-slate-950 border-2 border-amber-500/40 focus:border-amber-400 rounded-2xl px-4 py-3.5 text-base font-mono font-bold text-amber-100 focus:outline-none shadow-inner"
                  />
                  <span className="absolute right-3.5 top-3.5 px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                    DATA 4G/5G
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  CONVERTO mobile data networking machines will deduct data bundle from this SIM line.
                </p>
              </div>

              {/* Data Amount Selection */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Mobile Data Amount to Deduct (Megabytes / MB):
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={dataMbAmount}
                  onChange={(e) => setDataMbAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 focus:border-amber-400 rounded-2xl px-4 py-3 text-sm font-bold text-amber-200 focus:outline-none"
                />

                {/* Preset Chips */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {['1', '2.5', '5', '10', '50', '100', '500', '1024'].map((val) => (
                    <button
                      key={val}
                      onClick={() => setDataMbAmount(val)}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                        dataMbAmount === val
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
                      }`}
                    >
                      {val === '1024' ? '1 GB' : `${val} MB`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Carrier Selection */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Carrier SIM Data Gateway:
                </label>
                <select
                  value={dataCarrier}
                  onChange={(e) => setDataCarrier(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="MTN Nigeria 4G/5G LTE">MTN Nigeria 4G/5G LTE Broadband</option>
                  <option value="Airtel Nigeria 5G Data">Airtel Nigeria 5G Ultra-Fast</option>
                  <option value="Glo Mobile High-Speed">Glo Mobile High-Speed Data</option>
                  <option value="9mobile Nigeria Broadband">9mobile Nigeria Broadband</option>
                  <option value="International Telco Roaming">International Telco Roaming Data</option>
                </select>
              </div>

              {/* Target Crypto Destination */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold text-amber-200 block">
                  Deposit Live Bitcoin Into:
                </label>
                <select
                  value={dataPayoutTarget}
                  onChange={(e) => setDataPayoutTarget(e.target.value as any)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="altar_vault">Bitcoin Altar Vault (bc1qjuhnkrixaltarvaultbitcoin999777888)</option>
                  <option value="wallet">JUHNKRIX MUSIKA APP CRYPTO Wallet</option>
                  <option value="metamask">MetaMask / Web3 Wallet (0xJUHNKRIX...9a8f)</option>
                  <option value="trust_wallet">Trust Wallet (bc1qjuhnkrix...7721)</option>
                  <option value="minipay">MiniPay Opera Stablecoin (minipay.juhnkrix@gmail.com)</option>
                </select>
              </div>

              {/* FINALIZE BUTTON */}
              <div className="pt-4">
                <button
                  disabled={dataConverting}
                  onClick={handleFinalizeDataToCrypto}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center space-x-2 shadow-2xl shadow-amber-500/40 transition-all hover:scale-[1.02]"
                >
                  {dataConverting ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                      <span>DEDUCTING DATA & TOKENIZING INTO BITCOIN...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-slate-950" />
                      <span>FINALIZE DATA TO BITCOIN CONVERSION</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Live Calculation Preview & Blockchain Settlement Column */}
            <div className="space-y-6 flex flex-col justify-between">
              <div className="bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-amber-500/30 space-y-5">
                <h3 className="text-base font-extrabold text-amber-200 flex items-center space-x-2 border-b border-slate-800 pb-3">
                  <Cpu className="w-5 h-5 text-amber-400" />
                  <span>CONVERTO Blockchain & Data Tokenizer Engine</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Mobile Data to Deduct:</span>
                    <span className="font-black text-amber-300">{dataMbAmount} MB Data Bundle</span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Calculated Bitcoin Tokenized:</span>
                    <span className="font-black text-amber-400 text-sm">{Number(dataMbAmount || 0).toFixed(8)} BTC</span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Calculated Satoshis:</span>
                    <span className="font-black text-emerald-400">
                      {Math.round(Number(dataMbAmount || 0) * 100000000).toLocaleString()} Sats
                    </span>
                  </div>

                  <div className="flex justify-between py-2 border-b border-slate-800">
                    <span className="text-slate-400">Target SIM:</span>
                    <span className="font-mono text-slate-200">{dataPhone}</span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className="text-slate-400">Blockchain Network:</span>
                    <span className="font-mono text-amber-400">Bitcoin Mainnet / Altar Ledger</span>
                  </div>
                </div>

                {/* Conversion Success Notification Card */}
                {dataResult && (
                  <div className="p-5 bg-amber-950/80 border-2 border-amber-400 rounded-2xl space-y-3 animate-fadeIn">
                    <div className="flex items-center space-x-2 text-amber-300 font-extrabold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-amber-400" />
                      <span>Data Converted & Tokenized into Bitcoin!</span>
                    </div>
                    <div className="text-xs text-amber-200 space-y-1">
                      <div>Tokenized: <strong>{dataResult.btcFormatted} ({dataResult.btcSats.toLocaleString()} Sats)</strong></div>
                      <div>Destination: <strong>{dataResult.destinationDesc}</strong></div>
                      <div className="font-mono text-[10px] text-amber-400 truncate">TxHash: {dataResult.txHash}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Advance Plugins Toolbar Card */}
              <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800 space-y-3">
                <span className="text-[11px] font-bold text-amber-300 uppercase flex items-center space-x-1.5">
                  <Wrench className="w-3.5 h-3.5" />
                  <span>CONVERTO Active Crypto Blockchain & Telecom Engines</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400">
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span>Bitcoin Altar Vault Linker</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span>4G/5G Carrier Billing</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span>Real-time On-Chain Ledger</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center space-x-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span>Balance Update Toast Hook</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Real-time Conversion Tracker Progress Visualizer */}
      <ConversionTracker
        isOpen={showTracker}
        type={trackerConfig.type}
        phoneNumber={trackerConfig.phoneNumber}
        amountText={trackerConfig.amountText}
        carrier={trackerConfig.carrier}
        destinationText={trackerConfig.destinationText}
        isProcessing={airtimeConverting || dataConverting}
        onComplete={() => {
          setShowTracker(false);
          setAirtimeConverting(false);
          setDataConverting(false);
          showToast(`✓ CONVERTO: Transaction successfully processed & settled on ${trackerConfig.destinationText}!`);
        }}
      />
    </div>
  );
};
