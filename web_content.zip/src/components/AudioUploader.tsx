import React, { useRef, useState, useEffect } from 'react';
import {
  Upload,
  FileAudio,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Music2,
  Sparkles,
} from 'lucide-react';
import { AudioMetadata, DemoSample } from '../types/audio';
import {
  parseAudioMetadata,
  DEMO_SAMPLES,
  generateDemoSampleFile,
  formatDurationSimple,
} from '../utils/audioUtils';

interface AudioUploaderProps {
  onAudioSelected?: (metadata: AudioMetadata) => void;
  onAudioRemoved?: () => void;
  initialMetadata?: AudioMetadata | null;
  className?: string;
}

export const AudioUploader: React.FC<AudioUploaderProps> = ({
  onAudioSelected,
  onAudioRemoved,
  initialMetadata = null,
  className = '',
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const scrubberRef = useRef<HTMLDivElement | null>(null);

  const [metadata, setMetadata] = useState<AudioMetadata | null>(initialMetadata);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [generatingDemoId, setGeneratingDemoId] = useState<string | null>(null);

  // Audio Playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  useEffect(() => {
    if (initialMetadata) {
      setMetadata(initialMetadata);
    }
  }, [initialMetadata]);

  // Clean up Object URL on unmount or file replacement
  useEffect(() => {
    return () => {
      if (metadata?.audioUrl && !metadata.audioUrl.startsWith('data:')) {
        URL.revokeObjectURL(metadata.audioUrl);
      }
    };
  }, [metadata?.audioUrl]);

  const processFile = async (file: File) => {
    setErrorMsg(null);

    // Validate audio file
    if (!file || file.size === 0) {
      setErrorMsg('The selected file is empty or invalid.');
      return;
    }

    const validExtensions = ['mp3', 'wav', 'm4a', 'ogg', 'flac', 'aac'];
    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    const isAudioMime = file.type.startsWith('audio/') || file.type.includes('mp4');

    if (!validExtensions.includes(extension) && !isAudioMime) {
      setErrorMsg(
        `Unsupported format ".${extension || 'unknown'}". Please upload an MP3, WAV, or M4A audio file.`
      );
      return;
    }

    const maxSizeBytes = 100 * 1024 * 1024; // 100 MB
    if (file.size > maxSizeBytes) {
      setErrorMsg(
        'File size exceeds 100 MB limit. Please select a smaller MP3, WAV, or M4A file.'
      );
      return;
    }

    setIsLoading(true);
    setIsPlaying(false);
    setCurrentTime(0);

    try {
      const parsed = await parseAudioMetadata(file);
      setMetadata(parsed);
      onAudioSelected?.(parsed);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown decoding error';
      setErrorMsg(`Failed to process audio file: ${msg}`);
      setMetadata(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles && droppedFiles.length > 0) {
      processFile(droppedFiles[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleRemoveFile = () => {
    if (metadata?.audioUrl && !metadata.audioUrl.startsWith('data:')) {
      URL.revokeObjectURL(metadata.audioUrl);
    }
    setMetadata(null);
    setIsPlaying(false);
    setCurrentTime(0);
    setErrorMsg(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    onAudioRemoved?.();
  };

  const handleLoadDemo = async (sample: DemoSample) => {
    setGeneratingDemoId(sample.id);
    setErrorMsg(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 50));
      const file = generateDemoSampleFile(sample);
      await processFile(file);
    } catch (err: unknown) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Could not generate demo audio sample.'
      );
    } finally {
      setGeneratingDemoId(null);
    }
  };

  // Audio Playback Handlers
  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  };

  const skipSeconds = (delta: number) => {
    const audio = audioRef.current;
    if (!audio || !metadata) return;
    const target = Math.max(0, Math.min(metadata.duration, audio.currentTime + delta));
    audio.currentTime = target;
    setCurrentTime(target);
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleScrubberClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!scrubberRef.current || !audioRef.current || !metadata?.duration) return;
    const rect = scrubberRef.current.getBoundingClientRect();
    const clickX = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    const ratio = clickX / rect.width;
    const targetTime = ratio * metadata.duration;
    audioRef.current.currentTime = targetTime;
    setCurrentTime(targetTime);
  };

  const progressPercent =
    metadata && metadata.duration > 0
      ? Math.min(100, (currentTime / metadata.duration) * 100)
      : 0;

  return (
    <div className={`w-full space-y-4 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept=".mp3,.wav,.m4a,audio/mpeg,audio/wav,audio/mp4,audio/x-m4a,audio/*"
        onChange={handleFileInputChange}
        className="hidden"
        aria-label="Upload Audio File"
      />

      {/* Hidden Audio Player for Preview */}
      {metadata && (
        <audio
          ref={audioRef}
          src={metadata.audioUrl}
          onTimeUpdate={() => {
            if (audioRef.current) setCurrentTime(audioRef.current.currentTime);
          }}
          onEnded={() => setIsPlaying(false)}
          preload="metadata"
        />
      )}

      {/* Error Message Display */}
      {errorMsg && (
        <div
          role="alert"
          className="bg-rose-950/40 border border-rose-500/40 rounded-xl p-3.5 flex items-start gap-3 text-rose-200 text-xs sm:text-sm animate-in fade-in"
        >
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold text-rose-300">File Error: </span>
            <span>{errorMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-rose-400 hover:text-rose-200 p-1"
            title="Dismiss error"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* State 1: No File Loaded -> Modern Drag & Drop Zone */}
      {!metadata && (
        <div className="space-y-4">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') fileInputRef.current?.click();
            }}
            className={`relative rounded-2xl border-2 border-dashed p-6 sm:p-10 transition-all duration-200 cursor-pointer flex flex-col items-center justify-center text-center select-none ${
              isDragging
                ? 'border-amber-400 bg-amber-500/10 scale-[0.99]'
                : 'border-slate-800 hover:border-amber-500/60 bg-[#111827] hover:bg-[#141d2e]'
            }`}
          >
            {/* Visual Icon Container */}
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-400 mb-4 transition-transform group-hover:scale-105">
              {isLoading ? (
                <Loader2 className="w-7 h-7 animate-spin" />
              ) : (
                <Upload className="w-7 h-7" />
              )}
            </div>

            {/* Headline and Instructions */}
            <h3 className="text-base sm:text-lg font-semibold text-slate-100 font-display">
              {isLoading
                ? 'Extracting audio metadata and waveform...'
                : 'Drag and drop your audio file here'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md">
              Supports <strong className="text-slate-200">MP3, WAV, and M4A</strong> audio files up to 100 MB. Instant in-browser metadata extraction.
            </p>

            {/* Supported Formats Indicator */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-xs font-mono">
              <span className="px-2.5 py-1 rounded bg-[#0B0F17] border border-slate-800 text-slate-300">
                MP3
              </span>
              <span className="px-2.5 py-1 rounded bg-[#0B0F17] border border-slate-800 text-slate-300">
                WAV
              </span>
              <span className="px-2.5 py-1 rounded bg-[#0B0F17] border border-slate-800 text-slate-300">
                M4A
              </span>
              <span className="px-2.5 py-1 rounded bg-[#0B0F17] border border-slate-800 text-slate-400">
                OGG / FLAC
              </span>
            </div>

            {/* Action Trigger Button (44px+ touch target) */}
            <button
              type="button"
              disabled={isLoading}
              onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
              className="mt-6 min-h-[44px] px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-lg shadow-amber-500/10"
            >
              <Upload className="w-4 h-4" />
              <span>Browse Audio Files</span>
            </button>
          </div>

          {/* Quick Demo Audio Samples for Immediate Testing */}
          <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs sm:text-sm font-semibold text-slate-200">
                  Quick Testing Samples (Built-in Web Audio PCM)
                </h4>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                Click any sample to test upload & metadata instantly
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {DEMO_SAMPLES.map((sample) => {
                const isCurrentLoading = generatingDemoId === sample.id;
                return (
                  <button
                    key={sample.id}
                    type="button"
                    disabled={isLoading || isCurrentLoading}
                    onClick={() => handleLoadDemo(sample)}
                    className="p-3 rounded-xl bg-[#0B0F17] border border-slate-800/80 hover:border-amber-500/50 hover:bg-[#0e1420] text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 disabled:opacity-50 min-h-[72px]"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-100 truncate">
                        {sample.title}
                      </span>
                      {isCurrentLoading ? (
                        <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />
                      ) : (
                        <span className="text-[10px] font-mono text-amber-400 shrink-0">
                          {sample.format} · {sample.durationSec}s
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1">
                      {sample.genre} · {sample.bpm} BPM
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* State 2: File Loaded -> Rich Metadata Display & Audio Waveform Player */}
      {metadata && (
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-6 space-y-5 animate-in fade-in duration-200">
          {/* Header Row: File Identity & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
            <div className="flex items-start gap-3.5 min-w-0">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
                <FileAudio className="w-5 h-5" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3
                    className="text-base sm:text-lg font-semibold text-slate-100 truncate"
                    title={metadata.name}
                  >
                    {metadata.name}
                  </h3>
                  <span className="text-emerald-400 shrink-0" title="Valid audio format">
                    <CheckCircle2 className="w-4 h-4" />
                  </span>
                </div>

                {/* Clean unboxed metadata with dot separators per zero-pill discipline */}
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 font-mono tabular-nums mt-0.5">
                  <span className="text-amber-400 font-semibold">{metadata.format}</span>
                  <span aria-hidden="true">·</span>
                  <span>{metadata.formattedSize}</span>
                  <span aria-hidden="true">·</span>
                  <span>{metadata.formattedDuration}</span>
                  <span aria-hidden="true">·</span>
                  <span>{(metadata.sampleRate / 1000).toFixed(1)} kHz</span>
                  <span aria-hidden="true">·</span>
                  <span>{metadata.channels === 1 ? 'Mono (1ch)' : `Stereo (${metadata.channels}ch)`}</span>
                </div>
              </div>
            </div>

            {/* Replace & Remove Actions */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-800 bg-[#0B0F17] hover:border-slate-700 text-xs font-medium text-slate-300 hover:text-slate-100 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Replace</span>
              </button>

              <button
                type="button"
                onClick={handleRemoveFile}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-800 bg-[#0B0F17] hover:border-rose-500/40 text-xs font-medium text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Remove</span>
              </button>
            </div>
          </div>

          {/* Detailed Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-1">
            <div className="p-3 rounded-xl bg-[#0B0F17] border border-slate-800/80">
              <div className="text-[11px] text-slate-400 font-medium">Exact Duration</div>
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-100 mt-0.5">
                {metadata.duration}s
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                {metadata.formattedDuration} (mm:ss)
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0B0F17] border border-slate-800/80">
              <div className="text-[11px] text-slate-400 font-medium">File Size</div>
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-amber-400 mt-0.5">
                {metadata.formattedSize}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                {metadata.size.toLocaleString()} bytes
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0B0F17] border border-slate-800/80">
              <div className="text-[11px] text-slate-400 font-medium">Sample Rate &amp; Channels</div>
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-100 mt-0.5">
                {metadata.sampleRate} Hz
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {metadata.channels === 2 ? 'Stereo (L/R)' : 'Mono Channel'}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0B0F17] border border-slate-800/80">
              <div className="text-[11px] text-slate-400 font-medium">Dynamic Levels</div>
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-100 mt-0.5">
                {metadata.rmsDb ?? '-14.0'} dBFS
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                True Peak: {metadata.peakDb ?? '-0.5'} dBFS
              </div>
            </div>
          </div>

          {/* Interactive Waveform Scrubber Display */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-1.5 font-medium text-slate-300">
                <Music2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Audio Waveform &amp; Playback Scrubber</span>
              </div>
              <span className="font-mono tabular-nums">
                {formatDurationSimple(currentTime)} / {metadata.formattedDuration}
              </span>
            </div>

            {/* Clickable Waveform Track */}
            <div
              ref={scrubberRef}
              onClick={handleScrubberClick}
              role="slider"
              aria-label="Audio Playback Position"
              aria-valuemin={0}
              aria-valuemax={Math.round(metadata.duration)}
              aria-valuenow={Math.round(currentTime)}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'ArrowRight') skipSeconds(5);
                if (e.key === 'ArrowLeft') skipSeconds(-5);
              }}
              className="relative h-20 sm:h-24 bg-[#0B0F17] border border-slate-800/90 rounded-xl overflow-hidden cursor-pointer select-none group"
            >
              {/* Waveform Bars */}
              <div className="absolute inset-0 flex items-center justify-between px-2 py-3 gap-[2px]">
                {metadata.waveformPeaks.map((peak, idx) => {
                  const barPosPercent = (idx / metadata.waveformPeaks.length) * 100;
                  const isPlayed = barPosPercent <= progressPercent;
                  const heightPercent = Math.max(12, Math.round(peak * 90));
                  return (
                    <div
                      key={idx}
                      className={`flex-1 rounded-full transition-colors duration-150 ${
                        isPlayed
                          ? 'bg-amber-400'
                          : 'bg-slate-700/80 group-hover:bg-slate-600'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  );
                })}
              </div>

              {/* Progress Playhead Line */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-amber-400 pointer-events-none z-10"
                style={{ left: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Playback Transport Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={togglePlay}
                className="min-h-[44px] min-w-[130px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-500/10 shrink-0"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>Pause Audio</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Play Audio</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => skipSeconds(-5)}
                title="Rewind 5 seconds"
                className="min-h-[44px] min-w-[44px] px-2.5 rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-mono flex items-center justify-center gap-1 transition-colors shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>-5s</span>
              </button>

              <button
                type="button"
                onClick={() => skipSeconds(5)}
                title="Fast forward 5 seconds"
                className="min-h-[44px] min-w-[44px] px-2.5 rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-mono flex items-center justify-center gap-1 transition-colors shrink-0 cursor-pointer"
              >
                <span>+5s</span>
                <RotateCw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleMute}
                title={isMuted ? 'Unmute' : 'Mute'}
                className="min-h-[44px] min-w-[44px] rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-300 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
