import {
  Layers,
  Users,
  BookOpen,
  Crown,
  Award,
  BarChart3,
} from 'lucide-react';
import { useGame, BuyMode } from '../context/GameContext';
import { formatNumber } from '../utils/formatters';

const BUY_MODES: { label: string; mode: BuyMode }[] = [
  { label: '1x', mode: '1' },
  { label: '10x', mode: '10' },
  { label: '25x', mode: '25' },
  { label: '100x', mode: '100' },
  { label: 'Next Goal', mode: 'NEXT' },
  { label: 'MAX', mode: 'MAX' },
];

export type TabType = 'ventures' | 'managers' | 'upgrades' | 'altar' | 'achievements' | 'stats';

interface TreasuryHUDProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export function TreasuryHUD({ activeTab, setActiveTab }: TreasuryHUDProps) {
  const {
    buyMode,
    setBuyMode,
    numberFormat,
    pendingArchons,
    ventures,
    ventureStates,
    upgrades,
    achievements,
  } = useGame();

  const hiredManagersCount = Object.values(ventureStates).filter((v) => v.managerHired).length;
  const purchasedUpgradesCount = upgrades.filter((u) => u.purchased).length;
  const unlockedAchievementsCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div
      className="sticky top-[52px] z-30 bg-slate-950 border-b border-amber-900/30 px-4 md:px-8 py-3 shadow-lg select-none"
      style={{
        overscrollBehavior: 'none',
        overscrollBehaviorY: 'none',
        backgroundColor: '#020617',
      }}
    >
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Navigation Tabs (Ventures, Guildmasters, Grimoire, Celestial Altar) */}
        <nav className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto w-full md:w-auto py-0.5">
          {/* Ventures Tab */}
          <button
            onClick={() => setActiveTab('ventures')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              activeTab === 'ventures'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold border-amber-400 shadow-md shadow-amber-950/40'
                : 'bg-slate-900 text-slate-300 hover:text-slate-100 hover:bg-slate-800 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Layers className="w-4 h-4 shrink-0" />
            <span>Ventures</span>
          </button>

          {/* Guildmasters Tab */}
          <button
            onClick={() => setActiveTab('managers')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              activeTab === 'managers'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold border-amber-400 shadow-md shadow-amber-950/40'
                : 'bg-slate-900 text-slate-300 hover:text-slate-100 hover:bg-slate-800 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            <span>Guildmasters</span>
            <span
              className={`text-[11px] px-1.5 py-0.2 rounded-md ${
                activeTab === 'managers'
                  ? 'bg-slate-950/30 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {hiredManagersCount}/{ventures.length}
            </span>
          </button>

          {/* Grimoire Upgrades Tab */}
          <button
            onClick={() => setActiveTab('upgrades')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              activeTab === 'upgrades'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold border-amber-400 shadow-md shadow-amber-950/40'
                : 'bg-slate-900 text-slate-300 hover:text-slate-100 hover:bg-slate-800 border-slate-800 hover:border-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span>Grimoire</span>
            <span
              className={`text-[11px] px-1.5 py-0.2 rounded-md ${
                activeTab === 'upgrades'
                  ? 'bg-slate-950/30 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {purchasedUpgradesCount}/{upgrades.length}
            </span>
          </button>

          {/* Celestial Altar Tab */}
          <button
            onClick={() => setActiveTab('altar')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer border relative ${
              activeTab === 'altar'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold border-amber-400 shadow-md shadow-amber-950/40'
                : 'bg-slate-900 text-slate-300 hover:text-slate-100 hover:bg-slate-800 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Crown className="w-4 h-4 shrink-0" />
            <span>Celestial</span>
            {pendingArchons > 0 && (
              <span
                className={`text-[11px] px-1.5 py-0.2 rounded-md font-bold ${
                  activeTab === 'altar'
                    ? 'bg-slate-950 text-amber-300'
                    : 'bg-amber-500/30 text-amber-300 border border-amber-400/40 animate-pulse'
                }`}
              >
                +{formatNumber(pendingArchons, numberFormat)}
              </span>
            )}
          </button>

          {/* Feats & Ledger */}
          <button
            onClick={() => setActiveTab('achievements')}
            className={`flex shrink-0 items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              activeTab === 'achievements'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Feats ({unlockedAchievementsCount}/{achievements.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('stats')}
            className={`flex shrink-0 items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              activeTab === 'stats'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Ledger</span>
          </button>
        </nav>

        {/* Buy Multiplier Selector */}
        <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Multiplier:
          </span>
          <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-xl shadow-inner">
            {BUY_MODES.map(({ label, mode }) => {
              const active = buyMode === mode;
              return (
                <button
                  key={mode}
                  onClick={() => setBuyMode(mode)}
                  className={`px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-900/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
