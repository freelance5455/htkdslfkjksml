import {
  Bird,
  Cat,
  Clover,
  Coffee,
  Crown,
  Feather,
  Flower2,
  Gem,
  House,
  Moon,
  Music,
  Shell,
  Sparkles,
  Star,
  Sun,
  Users,
  type LucideIcon,
} from "lucide-react";
import { POST_KINDS, roleLabel, type PostKind, type Role } from "@/lib/cutegirls/model";

const ICONS: Record<string, LucideIcon> = {
  gleam: Sparkles,
  crown: Crown,
  feather: Feather,
  gem: Gem,
  moon: Moon,
  bloom: Flower2,
  cat: Cat,
  star: Star,
  clover: Clover,
  note: Music,
  cup: Coffee,
  bird: Bird,
  shell: Shell,
  sun: Sun,
  users: Users,
  house: House,
};

export function MarkIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICONS[name] ?? Sparkles;
  return <Icon className={className ?? "size-4"} strokeWidth={1.75} aria-hidden="true" />;
}

export function Avatar({
  src,
  name,
  className,
}: {
  src: string | null;
  name: string;
  className?: string;
}) {
  const frame = className ?? "size-11 text-base";
  if (src) {
    return <img src={src} alt="" className={`${frame} rounded-full object-cover`} />;
  }
  return (
    <span className={`${frame} grid place-items-center rounded-full bg-rose/10 font-display text-rose`}>
      {(name || "?").slice(0, 1).toUpperCase()}
    </span>
  );
}

export function RolePill({ role }: { role: Role }) {
  const creator = role === "creator";
  return (
    <span
      className={
        creator
          ? "rounded-full bg-rose px-2.5 py-0.5 text-xs font-medium text-paper"
          : "rounded-full bg-rose/10 px-2.5 py-0.5 text-xs font-medium text-rose"
      }
    >
      {roleLabel(role)}
    </span>
  );
}

export function KindPill({ kind }: { kind: PostKind }) {
  return (
    <span className="text-xs font-medium tracking-wide text-rose">{POST_KINDS[kind].label}</span>
  );
}

export const fieldClass =
  "w-full rounded-2xl bg-ivory px-4 text-base text-ink shadow-card outline-none placeholder:text-mute focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose";

export const primaryBtn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-rose px-5 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:cursor-wait disabled:opacity-50";

export const quietBtn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-medium text-ink shadow-card transition-[box-shadow] hover:shadow-lift disabled:cursor-wait disabled:opacity-50";

export function EmptyNote({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-3xl bg-paper px-6 py-10 text-center shadow-card">
      <h2 className="font-display text-2xl text-ink">{title}</h2>
      <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-mute">{body}</p>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="animate-pulse rounded-3xl bg-paper p-5 shadow-card">
      <div className="flex items-center gap-3">
        <div className="size-11 rounded-full bg-ivory" />
        <div className="space-y-2">
          <div className="h-3 w-28 rounded-full bg-ivory" />
          <div className="h-3 w-16 rounded-full bg-ivory" />
        </div>
      </div>
      <div className="mt-4 h-3 w-full rounded-full bg-ivory" />
      <div className="mt-2 h-3 w-4/5 rounded-full bg-ivory" />
    </div>
  );
}
