import type { ButtonHTMLAttributes } from "react";
import { dict, type CopyKey } from "@/lib/i18n";
import type { Mark } from "@/lib/model";
import { useStudy } from "@/lib/store";

export function useCopy() {
  const lang = useStudy((s) => s.lang);
  return { lang, t: (key: CopyKey) => dict[lang][key] };
}

export const fieldClass =
  "w-full rounded-md border border-border bg-bg px-3 py-3 text-base text-fg outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-primary";

const variants = {
  primary: "bg-primary text-primary-fg hover:opacity-90",
  accent: "bg-accent text-accent-fg hover:opacity-90",
  surface: "border border-border bg-surface text-fg hover:bg-surface-2",
  ghost: "bg-transparent text-fg hover:bg-surface-2",
} as const;

export function Button({
  variant = "primary",
  className = "",
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof variants }) {
  return (
    <button
      type={type}
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-opacity disabled:cursor-not-allowed disabled:opacity-40 ${variants[variant]} ${className}`}
      {...props}
    />
  );
}

export function Monogram({ name, mark }: { name: string; mark: Mark }) {
  const tone = mark === "gold" ? "bg-accent text-accent-fg" : "bg-primary text-primary-fg";
  return (
    <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-md text-lg font-semibold ${tone}`}>
      {name.slice(0, 1) || "·"}
    </span>
  );
}

export function Meter({ pct }: { pct: number }) {
  const width = Math.min(100, Math.max(0, pct));
  return (
    <div className="h-1.5 overflow-hidden rounded-full bg-surface-2" aria-hidden="true">
      <div className="h-full rounded-full bg-primary" style={{ width: `${width}%` }} />
    </div>
  );
}

export function IconButton({
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={`grid h-11 w-11 place-items-center rounded-md text-fg hover:bg-surface-2 disabled:opacity-40 ${className}`}
      {...props}
    />
  );
}
