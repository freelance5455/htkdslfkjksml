import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext.tsx';
import {
  Star,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Plus,
  Filter,
  Calendar,
  Package,
  Send
} from 'lucide-react';

interface VouchesPageProps {
  onBackHome: () => void;
}

const PAGE_SIZE = 8;

export const VouchesPage: React.FC<VouchesPageProps> = ({ onBackHome }) => {
  const {
    approvedVouches,
    vouchStats,
    vouchProductOptions,
    submitVouch
  } = useData();

  // Filter & Pagination states
  const [selectedProductFilter, setSelectedProductFilter] = useState<string>('all');
  const [selectedRatingFilter, setSelectedRatingFilter] = useState<string>('all');
  const [visibleCount, setVisibleCount] = useState<number>(PAGE_SIZE);

  // Submission Form states
  const [name, setName] = useState('');
  const [discordUsername, setDiscordUsername] = useState('');
  const [productOrService, setProductOrService] = useState('');
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);

  const [submitting, setSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);
  const [lastSubmittedKey, setLastSubmittedKey] = useState<string>('');

  // Dynamic filter dropdown options combining admin products + any approved vouch product names
  const filterProductOptions = useMemo(() => {
    const seen = new Set<string>();
    const list: string[] = [];
    const add = (val?: string) => {
      const clean = String(val || '').trim();
      if (!clean) return;
      const lower = clean.toLowerCase();
      if (!seen.has(lower)) {
        seen.add(lower);
        list.push(clean);
      }
    };
    for (const opt of vouchProductOptions) add(opt);
    for (const v of approvedVouches) add(v.productOrService);
    return list;
  }, [vouchProductOptions, approvedVouches]);

  // Filtered approved vouches (already sorted newest first by approvedAt descending in DataContext)
  const filteredVouches = useMemo(() => {
    return approvedVouches.filter((v) => {
      if (
        selectedProductFilter !== 'all' &&
        v.productOrService.toLowerCase() !== selectedProductFilter.toLowerCase()
      ) {
        return false;
      }
      if (selectedRatingFilter !== 'all' && Number(v.rating) !== Number(selectedRatingFilter)) {
        return false;
      }
      return true;
    });
  }, [approvedVouches, selectedProductFilter, selectedRatingFilter]);

  const visibleVouches = useMemo(() => {
    return filteredVouches.slice(0, visibleCount);
  }, [filteredVouches, visibleCount]);

  const scrollToForm = () => {
    const el = document.getElementById('submit-vouch');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const formatDate = (iso?: string | null) => {
    if (!iso) return '';
    try {
      return new Date(iso).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    const cleanName = name.trim();
    const cleanDiscord = discordUsername.trim();
    const cleanProduct = productOrService.trim();
    const cleanFeedback = feedback.trim();

    if (!cleanName) {
      errors.name = 'Your Name is required.';
    } else if (cleanName.length < 2) {
      errors.name = 'Please enter at least 2 characters for your name.';
    }

    if (!cleanDiscord) {
      errors.discordUsername = 'Discord Username is required.';
    } else if (cleanDiscord.length < 2) {
      errors.discordUsername = 'Please enter a valid Discord username.';
    }

    if (!cleanProduct) {
      errors.productOrService = 'Please select the Product / Service you purchased.';
    }

    if (!cleanFeedback) {
      errors.feedback = 'Your Vouch feedback is required.';
    } else if (cleanFeedback.length < 15) {
      errors.feedback = 'Please share at least 15 characters about your experience.';
    } else if (cleanFeedback.length > 1000) {
      errors.feedback = 'Please keep your vouch under 1,000 characters.';
    }

    if (!rating || rating < 1 || rating > 5) {
      errors.rating = 'Please select a star rating from 1 to 5.';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitError(null);
    setSubmitSuccess(null);

    if (!validateForm()) {
      return;
    }

    const dedupeSignature = `${discordUsername.trim().toLowerCase()}::${productOrService.trim().toLowerCase()}::${feedback.trim().toLowerCase()}`;
    if (lastSubmittedKey && lastSubmittedKey === dedupeSignature) {
      setSubmitError('You have already submitted this exact vouch.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await submitVouch({
        name: name.trim(),
        discordUsername: discordUsername.trim(),
        productOrService: productOrService.trim(),
        feedback: feedback.trim(),
        rating
      });

      if (res.success) {
        setLastSubmittedKey(dedupeSignature);
        setSubmitSuccess('Your vouch has been submitted successfully and is awaiting approval.');
        setName('');
        setDiscordUsername('');
        setProductOrService('');
        setFeedback('');
        setRating(0);
        setHoverRating(0);
        setFormErrors({});
      } else {
        setSubmitError(res.error || 'Could not submit your vouch. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const ratingLabels: Record<number, string> = {
    1: '1/5 — Poor',
    2: '2/5 — Fair',
    3: '3/5 — Good',
    4: '4/5 — Very Good',
    5: '5/5 — Exceptional'
  };

  return (
    <div className="py-10 sm:py-14 max-w-[980px] mx-auto px-4 sm:px-6">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <button
          type="button"
          onClick={onBackHome}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#060f1d] hover:bg-[#0b1930] border border-slate-800/90 text-slate-300 hover:text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-400" />
          <span>Back to Homepage</span>
        </button>

        <button
          type="button"
          onClick={scrollToForm}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs sm:text-sm transition-all cursor-pointer shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add a Vouch</span>
        </button>
      </div>

      {/* Page Header & Reputation Summary */}
      <div className="rounded-2xl border border-slate-800/90 bg-[#060f1d] p-6 sm:p-9 mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[11px] font-mono uppercase tracking-wider">
              <span>CUBIX VOUCHES</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight font-['Plus_Jakarta_Sans']">
              Trust is built, not claimed.
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Real feedback from people who have experienced Cubix Studio.
            </p>
          </div>

          <div className="lg:col-span-5 grid grid-cols-2 gap-3.5">
            <div className="p-4 sm:p-5 rounded-xl bg-[#040a14] border border-slate-800/90">
              <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                Total Vouches
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-1.5">
                {vouchStats.totalVouches}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Approved client reviews</div>
            </div>

            <div className="p-4 sm:p-5 rounded-xl bg-[#040a14] border border-slate-800/90">
              <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                Client Rating
              </div>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
                  {vouchStats.formattedRating}
                </span>
                <Star className="w-5 h-5 text-amber-400 fill-amber-400 shrink-0" />
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Verified rating average</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
        <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
          <Filter className="w-3.5 h-3.5 text-cyan-400" />
          <span>
            Showing <strong className="text-white">{filteredVouches.length}</strong> approved{' '}
            {filteredVouches.length === 1 ? 'vouch' : 'vouches'} • Sorted by Newest First
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <select
            aria-label="Filter by Product or Service"
            value={selectedProductFilter}
            onChange={(e) => {
              setSelectedProductFilter(e.target.value);
              setVisibleCount(PAGE_SIZE);
            }}
            className="px-3 py-2 rounded-lg bg-[#040a14] border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
          >
            <option value="all">All Products &amp; Services</option>
            {filterProductOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by Star Rating"
            value={selectedRatingFilter}
            onChange={(e) => {
              setSelectedRatingFilter(e.target.value);
              setVisibleCount(PAGE_SIZE);
            }}
            className="px-3 py-2 rounded-lg bg-[#040a14] border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
          >
            <option value="all">All Ratings</option>
            <option value="5">5 Stars (5/5)</option>
            <option value="4">4 Stars (4/5)</option>
            <option value="3">3 Stars (3/5)</option>
            <option value="2">2 Stars (2/5)</option>
            <option value="1">1 Star (1/5)</option>
          </select>

          {(selectedProductFilter !== 'all' || selectedRatingFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setSelectedProductFilter('all');
                setSelectedRatingFilter('all');
                setVisibleCount(PAGE_SIZE);
              }}
              className="px-2.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs text-cyan-300 font-semibold cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Classic Vertical List of Approved Vouches */}
      <div className="max-w-3xl mx-auto space-y-4 mb-12">
        {filteredVouches.length === 0 ? (
          <div className="rounded-xl border border-slate-800/90 bg-[#060f1d] p-8 sm:p-10 text-center space-y-3">
            <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 flex items-center justify-center mx-auto">
              <Star className="w-5 h-5" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white">
              {approvedVouches.length === 0
                ? 'No published vouches yet'
                : 'No vouches match your selected filters'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
              {approvedVouches.length === 0
                ? 'Worked with Cubix Studio? Share your experience below—your vouch will appear here as soon as it is reviewed and approved.'
                : 'Try clearing the product or star rating filter to view all approved client feedback.'}
            </p>
            {approvedVouches.length === 0 && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={scrollToForm}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Submit the First Vouch</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            {visibleVouches.map((vouch) => (
              <article
                key={vouch.id}
                className="rounded-xl border border-slate-800/90 bg-[#060f1d] p-5 sm:p-6 transition-colors hover:border-slate-700/90"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3.5 mb-3.5 border-b border-slate-800/80">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-bold text-white">{vouch.name}</span>
                      <span className="text-xs font-mono text-cyan-300 bg-slate-950/90 border border-slate-800 px-2 py-0.5 rounded">
                        Discord: {vouch.discordUsername}
                      </span>
                      {vouch.isVerified && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-medium">
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          <span>Verified Client</span>
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-0.5">
                      <span className="inline-flex items-center gap-1.5 text-slate-300 font-medium">
                        <Package className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{vouch.productOrService}</span>
                      </span>
                      <span className="inline-flex items-center gap-1 text-slate-400 font-mono text-[11px]">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        <span>{formatDate(vouch.approvedAt || vouch.createdAt)}</span>
                      </span>
                    </div>
                  </div>

                  {/* Star Rating out of 5 */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <div className="flex items-center gap-0.5" aria-label={`Rated ${vouch.rating} out of 5 stars`}>
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= vouch.rating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-700'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-300 ml-1">
                      {vouch.rating}/5
                    </span>
                  </div>
                </div>

                <p className="text-slate-200 text-sm sm:text-[15px] leading-relaxed whitespace-pre-line">
                  {vouch.feedback}
                </p>
              </article>
            ))}

            {filteredVouches.length > visibleCount && (
              <div className="pt-3 text-center">
                <button
                  type="button"
                  onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#060f1d] hover:bg-[#0b1930] border border-slate-800 text-slate-200 hover:text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer"
                >
                  <span>
                    Load More Vouches ({filteredVouches.length - visibleCount} remaining)
                  </span>
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Add a Vouch – Dedicated Inline Submission Form */}
      <section
        id="submit-vouch"
        className="max-w-3xl mx-auto rounded-2xl border border-slate-800/90 bg-[#060f1d] p-6 sm:p-8 scroll-mt-24"
      >
        <div className="pb-5 mb-6 border-b border-slate-800">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[11px] font-mono uppercase tracking-wider mb-2.5">
            <span>ADD A VOUCH</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-['Plus_Jakarta_Sans']">
            Share Your Experience
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Your feedback helps others discover Cubix Studio.
          </p>
        </div>

        {submitSuccess && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 text-xs sm:text-sm flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-white">Vouch Submitted</div>
              <div className="mt-0.5">{submitSuccess}</div>
            </div>
          </div>
        )}

        {submitError && (
          <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs sm:text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>{submitError}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 1. Your Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                Your Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (formErrors.name) setFormErrors((prev) => ({ ...prev, name: '' }));
                }}
                placeholder="Enter your name"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-[#040a14] border text-white placeholder-slate-500 text-sm focus:outline-none ${
                  formErrors.name ? 'border-rose-500' : 'border-slate-800 focus:border-cyan-400'
                }`}
              />
              {formErrors.name && (
                <p className="text-[11px] text-rose-400 mt-1">{formErrors.name}</p>
              )}
            </div>

            {/* 2. Discord Username (REQUIRED) */}
            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                Discord Username <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={discordUsername}
                onChange={(e) => {
                  setDiscordUsername(e.target.value);
                  if (formErrors.discordUsername) {
                    setFormErrors((prev) => ({ ...prev, discordUsername: '' }));
                  }
                }}
                placeholder="e.g. username or user#0001"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-[#040a14] border text-white placeholder-slate-500 text-sm font-mono focus:outline-none ${
                  formErrors.discordUsername
                    ? 'border-rose-500'
                    : 'border-slate-800 focus:border-cyan-400'
                }`}
              />
              {formErrors.discordUsername && (
                <p className="text-[11px] text-rose-400 mt-1">{formErrors.discordUsername}</p>
              )}
            </div>
          </div>

          {/* 3. Product / Service Purchased */}
          <div>
            <label className="block text-xs font-semibold text-slate-200 mb-1.5">
              Product / Service Purchased <span className="text-rose-400">*</span>
            </label>
            <select
              required
              value={productOrService}
              onChange={(e) => {
                setProductOrService(e.target.value);
                if (formErrors.productOrService) {
                  setFormErrors((prev) => ({ ...prev, productOrService: '' }));
                }
              }}
              className={`w-full px-3.5 py-2.5 rounded-xl bg-[#040a14] border text-white text-sm focus:outline-none cursor-pointer ${
                formErrors.productOrService
                  ? 'border-rose-500'
                  : 'border-slate-800 focus:border-cyan-400'
              }`}
            >
              <option value="">Select a Product or Service...</option>
              {vouchProductOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
            {formErrors.productOrService && (
              <p className="text-[11px] text-rose-400 mt-1">{formErrors.productOrService}</p>
            )}
          </div>

          {/* 5. Your Rating (1 to 5 stars) */}
          <div>
            <label className="block text-xs font-semibold text-slate-200 mb-1.5">
              Your Rating <span className="text-rose-400">*</span>
            </label>
            <div className="flex flex-wrap items-center gap-3 p-3.5 rounded-xl bg-[#040a14] border border-slate-800">
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((starValue) => {
                  const active = (hoverRating || rating) >= starValue;
                  return (
                    <button
                      key={starValue}
                      type="button"
                      onClick={() => {
                        setRating(starValue);
                        if (formErrors.rating) setFormErrors((prev) => ({ ...prev, rating: '' }));
                      }}
                      onMouseEnter={() => setHoverRating(starValue)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="p-1.5 rounded-lg hover:bg-slate-900 transition-transform hover:scale-105 cursor-pointer focus:outline-none"
                      aria-label={`Rate ${starValue} out of 5 stars`}
                    >
                      <Star
                        className={`w-6 h-6 transition-colors ${
                          active ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>
              <span className="text-xs font-mono text-slate-300">
                {rating > 0
                  ? ratingLabels[rating]
                  : 'Select 1 to 5 stars'}
              </span>
            </div>
            {formErrors.rating && (
              <p className="text-[11px] text-rose-400 mt-1">{formErrors.rating}</p>
            )}
          </div>

          {/* 4. Your Vouch */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-200">
                Your Vouch <span className="text-rose-400">*</span>
              </label>
              <span className="text-[11px] font-mono text-slate-500">
                {feedback.trim().length}/1000
              </span>
            </div>
            <textarea
              rows={4}
              required
              maxLength={1000}
              value={feedback}
              onChange={(e) => {
                setFeedback(e.target.value);
                if (formErrors.feedback) setFormErrors((prev) => ({ ...prev, feedback: '' }));
              }}
              placeholder="Write your genuine feedback about working with Cubix Studio..."
              className={`w-full px-3.5 py-2.5 rounded-xl bg-[#040a14] border text-white placeholder-slate-500 text-sm leading-relaxed focus:outline-none ${
                formErrors.feedback
                  ? 'border-rose-500'
                  : 'border-slate-800 focus:border-cyan-400'
              }`}
            />
            {formErrors.feedback && (
              <p className="text-[11px] text-rose-400 mt-1">{formErrors.feedback}</p>
            )}
          </div>

          <div className="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <p className="text-[11px] text-slate-400">
              All submitted vouches are reviewed by our team before publication.
            </p>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? 'Submitting Vouch...' : 'Submit Vouch'}</span>
            </button>
          </div>
        </form>
      </section>
    </div>
  );
};
