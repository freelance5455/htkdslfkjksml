import React, { useState, useEffect } from 'react';
import { X, BookmarkPlus, Sparkles, Check, Sliders, Volume2, Mic, Music2, Gauge, Clock } from 'lucide-react';
import { NarrationStyleId, VoiceSettings } from '../types/tts';
import { TELUGU_VOICES, NARRATION_STYLES } from '../data/voicesAndStyles';

interface SavePresetModalProps {
  isOpen: boolean;
  onClose: () => void;
  voiceId: string;
  narrationStyle: NarrationStyleId;
  voiceSettings: VoiceSettings;
  onSavePreset: (name: string) => void;
}

export const SavePresetModal: React.FC<SavePresetModalProps> = ({
  isOpen,
  onClose,
  voiceId,
  narrationStyle,
  voiceSettings,
  onSavePreset,
}) => {
  const selectedVoice = TELUGU_VOICES.find((v) => v.id === voiceId) || TELUGU_VOICES[0];
  const selectedStyle = NARRATION_STYLES.find((s) => s.id === narrationStyle) || NARRATION_STYLES[0];

  const defaultSuggestedName = `${selectedVoice.teluguName} • ${selectedStyle.teluguName}`;
  const [presetName, setPresetName] = useState(defaultSuggestedName);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setPresetName(`${selectedVoice.teluguName} • ${selectedStyle.teluguName}`);
      setError(null);
    }
  }, [isOpen, selectedVoice, selectedStyle]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = presetName.trim();
    if (!trimmed) {
      setError('దయచేసి ప్రీసెట్ పేరును నమోదు చేయండి. (Please provide a preset name)');
      return;
    }
    onSavePreset(trimmed);
    onClose();
  };

  const quickSuggestions = [
    `${selectedVoice.teluguName} - ${selectedStyle.teluguName}`,
    'యూట్యూబ్ వాయిస్‌ఓవర్',
    'తెలుగు కథల నేరేషన్',
    'వార్తలు & సమాచారం',
    'మోటివేషనల్ స్పీచ్',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-lg bg-[#0d121f] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#101626]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <BookmarkPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <span>వ్యక్తిగత ప్రీసెట్‌గా సేవ్ చేయండి</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-normal">
                  Personal Preset
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                ప్రస్తుత కాంబినేషన్‌ను లోకల్ స్టోరేజ్‌లో సేవ్ చేసుకోండి
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4 overflow-y-auto">
          {/* Summary Preview Box */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800/90 space-y-2.5">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span>సేవ్ కాబోయే సెట్టింగ్‌లు (Settings to be saved):</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#0a0d16] p-2.5 rounded-lg border border-slate-800/80 flex items-center gap-2">
                <Mic className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <div className="truncate">
                  <div className="text-[10px] text-slate-500 uppercase">గళం (Voice)</div>
                  <div className="font-semibold text-slate-200 truncate">
                    {selectedVoice.name} <span className="text-slate-400 font-telugu">({selectedVoice.teluguName})</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#0a0d16] p-2.5 rounded-lg border border-slate-800/80 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <div className="truncate">
                  <div className="text-[10px] text-slate-500 uppercase">రీతి (Style)</div>
                  <div className="font-semibold text-slate-200 truncate font-telugu">
                    {selectedStyle.teluguName} <span className="text-slate-400 font-sans">({selectedStyle.name})</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2 text-[11px] font-mono">
              <div className="bg-[#0a0d16] p-2 rounded-lg border border-slate-800/80 text-center">
                <div className="text-[9px] text-slate-500 uppercase flex items-center justify-center gap-1">
                  <Gauge className="w-2.5 h-2.5 text-cyan-400" /> వేగం
                </div>
                <div className="font-bold text-cyan-300 mt-0.5">{voiceSettings.speed.toFixed(2)}x</div>
              </div>

              <div className="bg-[#0a0d16] p-2 rounded-lg border border-slate-800/80 text-center">
                <div className="text-[9px] text-slate-500 uppercase flex items-center justify-center gap-1">
                  <Music2 className="w-2.5 h-2.5 text-blue-400" /> పిచ్
                </div>
                <div className="font-bold text-blue-300 mt-0.5">
                  {voiceSettings.pitch > 0 ? `+${voiceSettings.pitch}` : voiceSettings.pitch}
                </div>
              </div>

              <div className="bg-[#0a0d16] p-2 rounded-lg border border-slate-800/80 text-center">
                <div className="text-[9px] text-slate-500 uppercase flex items-center justify-center gap-1">
                  <Volume2 className="w-2.5 h-2.5 text-emerald-400" /> వాల్యూమ్
                </div>
                <div className="font-bold text-emerald-300 mt-0.5">{voiceSettings.volume}%</div>
              </div>

              <div className="bg-[#0a0d16] p-2 rounded-lg border border-slate-800/80 text-center">
                <div className="text-[9px] text-slate-500 uppercase flex items-center justify-center gap-1">
                  <Clock className="w-2.5 h-2.5 text-purple-400" /> విరామం
                </div>
                <div className="font-bold text-purple-300 mt-0.5">{voiceSettings.sentencePause.toFixed(2)}s</div>
              </div>
            </div>
          </div>

          {/* Input field */}
          <div className="space-y-1.5">
            <label htmlFor="input-preset-name" className="block text-xs font-semibold text-slate-300">
              ప్రీసెట్ పేరు (Preset Name) <span className="text-red-400">*</span>
            </label>
            <input
              id="input-preset-name"
              type="text"
              value={presetName}
              onChange={(e) => {
                setPresetName(e.target.value);
                if (error) setError(null);
              }}
              placeholder="ఉదా: నా సినిమాటిక్ కథల వాయిస్"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              autoFocus
            />
            {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
          </div>

          {/* Quick suggestions */}
          <div className="space-y-1.5">
            <div className="text-[11px] text-slate-400 font-medium">సూచించిన పేర్లు (Suggestions):</div>
            <div className="flex flex-wrap gap-1.5">
              {quickSuggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPresetName(suggestion)}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 transition-colors cursor-pointer"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors cursor-pointer"
            >
              రద్దు (Cancel)
            </button>
            <button
              id="btn-save-personal-preset"
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>సేవ్ చేయండి (Save Preset)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
