import React from 'react';
import {
  Zap,
  TrendingUp,
  Plane as PlaneIcon,
  Users,
  X,
  Gauge
} from 'lucide-react';
import {
  getSpeedUpgradeCost,
  getMoneyMakerUpgradeCost,
  getCapacityUpgradeCost,
  getNewPlaneCost,
  getPassengerCapacity,
  getAircraftTierName
} from '../game/flightLogic';
import { sound } from '../game/sound';

interface UpgradesDrawerProps {
  cash: number;
  speedLevel: number;
  moneyMakerLevel: number;
  capacityLevel: number;
  fleetCount: number;
  onUpgradeSpeed: () => void;
  onUpgradeMoneyMaker: () => void;
  onUpgradeCapacity: () => void;
  onBuyPlane: () => void;
  onClose: () => void;
}

export const UpgradesDrawer: React.FC<UpgradesDrawerProps> = ({
  cash,
  speedLevel,
  moneyMakerLevel,
  capacityLevel,
  fleetCount,
  onUpgradeSpeed,
  onUpgradeMoneyMaker,
  onUpgradeCapacity,
  onBuyPlane,
  onClose
}) => {
  const speedCost = getSpeedUpgradeCost(speedLevel);
  const moneyMakerCost = getMoneyMakerUpgradeCost(moneyMakerLevel);
  const capacityCost = getCapacityUpgradeCost(capacityLevel);
  const newPlaneCost = getNewPlaneCost(fleetCount);

  const canAffordSpeed = cash >= speedCost;
  const canAffordMoneyMaker = cash >= moneyMakerCost;
  const canAffordCapacity = cash >= capacityCost;
  const canAffordNewPlane = cash >= newPlaneCost;

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#0a0b10] border-l border-[#27272a] shadow-2xl flex flex-col text-white animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-[#27272a]">
        <div>
          <h2 className="font-mono text-base font-bold tracking-tight">ENGINEERING & UPGRADES</h2>
          <p className="text-xs text-[#71717a] font-mono mt-0.5">Optimize airline efficiency, speed & fleet size</p>
        </div>
        <button
          onClick={onClose}
          aria-label="Close Upgrades Panel"
          className="p-1.5 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-lg transition-colors"
        >
          <X size={18} />
        </button>
      </div>

      {/* Upgrades List */}
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-4">
        {/* 1. SPEED UPGRADE */}
        <div className="p-4 bg-[#111218] border border-[#27272a] rounded-xl flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#1f2029] rounded-lg text-white">
                <Gauge size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">Flight Speed</h3>
                <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mt-0.5 font-mono">
                  <span>Level {speedLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>+{((speedLevel - 1) * 28)}% Cruise Velocity</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            Turbofan aerodynamics boost aircraft speed across all active routes, reducing flight time and increasing turnover.
          </p>
          <div className="flex items-center justify-between pt-2 border-t border-[#1e1f29]">
            <span className="font-mono text-xs text-[#71717a]">
              NEXT: +28% SPEED
            </span>
            <button
              onClick={() => {
                if (canAffordSpeed) {
                  onUpgradeSpeed();
                  sound.playUpgrade();
                }
              }}
              disabled={!canAffordSpeed}
              className={`px-4 py-2 rounded-lg font-mono text-xs font-semibold transition-all ${
                canAffordSpeed
                  ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                  : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
              }`}
            >
              UPGRADE (${speedCost.toLocaleString()})
            </button>
          </div>
        </div>

        {/* 2. MONEY MAKER UPGRADE */}
        <div className="p-4 bg-[#111218] border border-[#27272a] rounded-xl flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#1f2029] rounded-lg text-white">
                <TrendingUp size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">Money Maker (Ticket Pricing)</h3>
                <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mt-0.5 font-mono">
                  <span>Level {moneyMakerLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>+{((moneyMakerLevel - 1) * 35)}% Revenue</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            Dynamic premium fare pricing and onboard services maximize revenue earned per passenger and nautical mile.
          </p>
          <div className="flex items-center justify-between pt-2 border-t border-[#1e1f29]">
            <span className="font-mono text-xs text-[#71717a]">
              NEXT: +35% PROFIT
            </span>
            <button
              onClick={() => {
                if (canAffordMoneyMaker) {
                  onUpgradeMoneyMaker();
                  sound.playUpgrade();
                }
              }}
              disabled={!canAffordMoneyMaker}
              className={`px-4 py-2 rounded-lg font-mono text-xs font-semibold transition-all ${
                canAffordMoneyMaker
                  ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                  : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
              }`}
            >
              UPGRADE (${moneyMakerCost.toLocaleString()})
            </button>
          </div>
        </div>

        {/* 3. +1 PLANE (FLEET EXPANSION) */}
        <div className="p-4 bg-[#111218] border border-[#27272a] rounded-xl flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#1f2029] rounded-lg text-white">
                <PlaneIcon size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">+1 Plane (Fleet Expansion)</h3>
                <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mt-0.5 font-mono">
                  <span>Fleet: {fleetCount} Aircraft</span>
                  <span aria-hidden="true">·</span>
                  <span>Simultaneous Routes</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            Commission a brand-new aircraft into your commercial hangar. Assign it to any unlocked city pair to double your operational footprint.
          </p>
          <div className="flex items-center justify-between pt-2 border-t border-[#1e1f29]">
            <span className="font-mono text-xs text-[#71717a]">
              +1 ACTIVE AIRFRAME
            </span>
            <button
              onClick={() => {
                if (canAffordNewPlane) {
                  onBuyPlane();
                  sound.playUpgrade();
                }
              }}
              disabled={!canAffordNewPlane}
              className={`px-4 py-2 rounded-lg font-mono text-xs font-semibold transition-all ${
                canAffordNewPlane
                  ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                  : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
              }`}
            >
              BUY PLANE (${newPlaneCost.toLocaleString()})
            </button>
          </div>
        </div>

        {/* 4. PASSENGER CAPACITY */}
        <div className="p-4 bg-[#111218] border border-[#27272a] rounded-xl flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#1f2029] rounded-lg text-white">
                <Users size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">Aircraft Model & Capacity</h3>
                <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mt-0.5 font-mono">
                  <span>Tier {capacityLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{getPassengerCapacity(capacityLevel)} Seats</span>
                </div>
              </div>
            </div>
          </div>
          <div className="text-xs text-[#d4d4d8] font-mono bg-[#161720] px-3 py-1.5 rounded border border-[#27272a]">
            Current: {getAircraftTierName(capacityLevel)}
          </div>
          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            Upgrade the fleet airframe model to carry more passengers on every flight, drastically compounding revenue.
          </p>
          <div className="flex items-center justify-between pt-2 border-t border-[#1e1f29]">
            <span className="font-mono text-xs text-[#71717a]">
              UPGRADE CAPACITY
            </span>
            <button
              onClick={() => {
                if (canAffordCapacity) {
                  onUpgradeCapacity();
                  sound.playUpgrade();
                }
              }}
              disabled={!canAffordCapacity}
              className={`px-4 py-2 rounded-lg font-mono text-xs font-semibold transition-all ${
                canAffordCapacity
                  ? 'bg-white text-black hover:bg-[#e4e4e7] cursor-pointer'
                  : 'bg-[#18181b] text-[#52525b] border border-[#27272a] cursor-not-allowed'
              }`}
            >
              UPGRADE (${capacityCost.toLocaleString()})
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
