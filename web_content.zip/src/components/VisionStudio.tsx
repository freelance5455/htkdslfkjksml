import React, { useState, useRef } from 'react';
import { 
  Scan, 
  Monitor, 
  Camera, 
  Upload, 
  Sparkles, 
  Volume2, 
  Copy, 
  Check, 
  ArrowLeft, 
  FileText, 
  Code, 
  Eye, 
  RefreshCw,
  Send
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface VisionStudioProps {
  language: SupportedLanguage;
  onAnalyze: (prompt: string, imageBase64: string) => Promise<string>;
  onSendToChat: (text: string, imageBase64: string) => void;
  onSpeak: (text: string) => void;
}

export const VisionStudio: React.FC<VisionStudioProps> = ({
  language,
  onAnalyze,
  onSendToChat,
  onSpeak,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState<string>(
    language === 'bn'
      ? 'এই ছবিটিতে কী কী দেখা যাচ্ছে বিস্তারিত বাংলায় বর্ণনা করো এবং গুরুত্বপূর্ণ পয়েন্টগুলো তুলে ধরো।'
      : 'Analyze and describe this image in detail, pointing out key elements, text, or issues.'
  );
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [analysisReport, setAnalysisReport] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);

  // File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
        setAnalysisReport(null);
        setStatusMessage('Image loaded successfully.');
      };
      reader.readAsDataURL(file);
    }
  };

  // Screen Sharing Capture
  const handleScreenCapture = async () => {
    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        setStatusMessage('Screen sharing is not supported in this browser environment.');
        return;
      }
      setStatusMessage('Requesting screen permission...');
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setSelectedImage(dataUrl);
        setAnalysisReport(null);
        setStatusMessage('Screen frame captured successfully.');
      }

      // Stop tracks
      stream.getTracks().forEach((track) => track.stop());
    } catch (err: any) {
      setStatusMessage(`Screen capture cancelled or unavailable: ${err?.message || ''}`);
    }
  };

  // Camera Snapshot
  const handleStartCamera = async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setStatusMessage('Camera access not supported in this browser.');
        return;
      }
      setIsCameraActive(true);
      setStatusMessage('Starting camera stream...');
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      setIsCameraActive(false);
      setStatusMessage(`Camera access denied: ${err?.message || ''}`);
    }
  };

  const handleCaptureCamera = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setSelectedImage(dataUrl);
        setAnalysisReport(null);
        setStatusMessage('Camera snapshot captured.');
      }
      // Stop video
      const stream = video.srcObject as MediaStream;
      stream?.getTracks().forEach((track) => track.stop());
      setIsCameraActive(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    setIsScanning(true);
    setStatusMessage('Quantum Gemini Scanner processing image...');
    try {
      const result = await onAnalyze(customPrompt, selectedImage);
      setAnalysisReport(result);
      setStatusMessage('Analysis complete.');
    } catch (err: any) {
      setAnalysisReport(`Analysis error: ${err?.message || 'Could not complete scan.'}`);
      setStatusMessage('Error encountered.');
    } finally {
      setIsScanning(false);
    }
  };

  const handleCopy = () => {
    if (analysisReport) {
      navigator.clipboard.writeText(analysisReport);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0d1629] to-[#160c2b] border border-cyan-500/30 p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono-tech">
              <Scan className="w-3.5 h-3.5 text-cyan-400" />
              <span>MULTIMODAL GEMINI 2.5 FLASH</span>
            </div>
            <h2 className="text-2xl font-orbitron font-extrabold tracking-wide text-white">
              VISION AI STUDIO
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              Inspect screenshots, live screens, documents, code, or camera feeds with Rubel Boss AI.
            </p>
          </div>
        </div>
      </div>

      {/* Capture Options Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Upload File */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center justify-center gap-2.5 p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 transition-all font-semibold text-sm shadow-md"
        >
          <Upload className="w-5 h-5 text-cyan-400" />
          <span>Upload Image / Photo</span>
        </button>

        {/* Screen Share Vision */}
        <button
          onClick={handleScreenCapture}
          className="flex items-center justify-center gap-2.5 p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-fuchsia-500/30 hover:border-fuchsia-400 text-fuchsia-300 transition-all font-semibold text-sm shadow-md"
        >
          <Monitor className="w-5 h-5 text-fuchsia-400" />
          <span>Capture Screen Frame</span>
        </button>

        {/* Live Camera */}
        <button
          onClick={isCameraActive ? handleCaptureCamera : handleStartCamera}
          className="flex items-center justify-center gap-2.5 p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-emerald-500/30 hover:border-emerald-400 text-emerald-300 transition-all font-semibold text-sm shadow-md"
        >
          <Camera className="w-5 h-5 text-emerald-400" />
          <span>{isCameraActive ? 'Snap Photo Now' : 'Camera Snapshot'}</span>
        </button>
      </div>

      {/* Camera Live Stream (if active) */}
      {isCameraActive && (
        <div className="relative rounded-3xl overflow-hidden border-2 border-emerald-500 bg-black max-w-lg mx-auto shadow-2xl">
          <video ref={videoRef} autoPlay playsInline className="w-full h-72 object-cover" />
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
            <button
              onClick={handleCaptureCamera}
              className="px-6 py-2.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/50 flex items-center gap-2"
            >
              <Camera className="w-4 h-4" />
              <span>Capture Target</span>
            </button>
          </div>
        </div>
      )}

      {/* Image Preview & Target Container */}
      <div className="rounded-3xl bg-slate-950/90 border border-cyan-900/40 p-4 sm:p-6 shadow-xl relative min-h-[260px] flex flex-col items-center justify-center">
        {selectedImage ? (
          <div className="relative w-full rounded-2xl overflow-hidden border border-cyan-500/40 max-h-[380px] bg-black/60 flex items-center justify-center">
            <img
              src={selectedImage}
              alt="Scan Target"
              className="max-h-[380px] w-auto object-contain mx-auto"
            />
            <div className="absolute top-3 left-3 bg-slate-950/80 border border-cyan-400/80 px-2.5 py-1 rounded-md text-[10px] font-mono-tech text-cyan-300">
              [TARGET ACQUIRED · READY FOR SCAN]
            </div>
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-3 right-3 bg-red-950/80 border border-red-500/80 text-red-300 px-2.5 py-1 rounded-md text-[10px] font-mono-tech hover:bg-red-900"
            >
              Remove
            </button>
          </div>
        ) : (
          <div className="text-center py-10 space-y-3">
            <div className="w-16 h-16 rounded-full bg-cyan-950/60 border border-cyan-500/40 flex items-center justify-center mx-auto text-cyan-400">
              <Eye className="w-8 h-8" />
            </div>
            <p className="text-slate-300 font-semibold text-base">No Target Image Loaded</p>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              Choose an image, take a camera snapshot, or share your screen to allow Rubel Boss AI to inspect it.
            </p>
          </div>
        )}

        {statusMessage && (
          <p className="mt-3 text-xs font-mono-tech text-cyan-400">{statusMessage}</p>
        )}
      </div>

      {/* Preset Directives */}
      <div className="space-y-2">
        <label className="text-xs font-mono-tech font-bold text-cyan-400 tracking-wider">
          PRESET AI DIRECTIVES
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() =>
              setCustomPrompt(
                'এই ছবিটিতে কী কী দেখা যাচ্ছে বিস্তারিত বাংলায় বর্ণনা করো এবং গুরুত্বপূর্ণ পয়েন্টগুলো তুলে ধরো।'
              )
            }
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500 text-xs text-left text-slate-200 transition-all flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">বাংলায় বর্ণনা</span>
          </button>

          <button
            onClick={() =>
              setCustomPrompt(
                'Extract and accurately transcribe all text, numbers, code, and symbols present in this image.'
              )
            }
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-fuchsia-500 text-xs text-left text-slate-200 transition-all flex items-center gap-1.5"
          >
            <Scan className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
            <span className="truncate">Text & OCR Extract</span>
          </button>

          <button
            onClick={() =>
              setCustomPrompt(
                'Analyze the code or error message visible in this screenshot. Explain what is happening and provide the exact corrected code snippet.'
              )
            }
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500 text-xs text-left text-slate-200 transition-all flex items-center gap-1.5"
          >
            <Code className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">Fix Code & Errors</span>
          </button>

          <button
            onClick={() =>
              setCustomPrompt(
                'Solve the question, math problem, or challenge shown in this image with step-by-step logic.'
              )
            }
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-amber-500 text-xs text-left text-slate-200 transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">Solve Problem</span>
          </button>
        </div>
      </div>

      {/* Custom Prompt Directive Input */}
      <div className="space-y-2">
        <label className="text-xs font-mono-tech font-bold text-slate-400 tracking-wider">
          AI VISION DIRECTIVE
        </label>
        <textarea
          rows={2}
          value={customPrompt}
          onChange={(e) => setCustomPrompt(e.target.value)}
          placeholder="Enter prompt for the AI to analyze this image..."
          className="w-full bg-slate-950 text-slate-100 placeholder:text-slate-500 text-sm p-3.5 rounded-2xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400 transition-all resize-none"
        />
      </div>

      {/* Scan Action Button */}
      <button
        onClick={handleAnalyze}
        disabled={!selectedImage || isScanning}
        className={`w-full py-3.5 px-6 rounded-2xl font-orbitron font-bold text-sm tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg ${
          !selectedImage || isScanning
            ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
            : 'bg-gradient-to-r from-cyan-500 via-cyan-400 to-fuchsia-500 hover:from-cyan-400 hover:to-fuchsia-400 text-slate-950 shadow-cyan-500/20'
        }`}
      >
        {isScanning ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>SCANNING INTEL WITH GEMINI...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>SCAN & ANALYZE IMAGE</span>
          </>
        )}
      </button>

      {/* Analysis Report Output Card */}
      {analysisReport && (
        <div className="rounded-3xl bg-[#090f1e] border border-cyan-500/40 p-5 md:p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
            <div className="flex items-center gap-2">
              <Scan className="w-4 h-4 text-cyan-400" />
              <span className="font-orbitron font-bold text-xs sm:text-sm text-cyan-300 tracking-wide">
                AI VISION INTEL REPORT
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onSpeak(analysisReport)}
                title="Speak Report"
                className="p-1.5 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 transition-colors"
              >
                <Volume2 className="w-4 h-4" />
              </button>
              <button
                onClick={handleCopy}
                title="Copy Report"
                className="p-1.5 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              {selectedImage && (
                <button
                  onClick={() => onSendToChat(analysisReport, selectedImage)}
                  title="Send to Main Chat"
                  className="px-2.5 py-1 rounded-lg bg-fuchsia-950/60 border border-fuchsia-500/40 text-fuchsia-300 hover:bg-fuchsia-900 text-xs font-mono-tech flex items-center gap-1 transition-colors"
                >
                  <Send className="w-3 h-3" />
                  <span>Send to Chat</span>
                </button>
              )}
            </div>
          </div>

          <div className="prose prose-invert prose-cyan max-w-none text-slate-100 text-sm whitespace-pre-wrap leading-relaxed font-sans">
            {analysisReport}
          </div>
        </div>
      )}
    </div>
  );
};
