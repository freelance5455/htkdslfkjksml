import React from 'react';
import { Wifi, Battery, Volume2, X } from 'lucide-react';
import { AndroidNotification } from '../types';

interface AndroidDeviceFrameProps {
  children: React.ReactNode;
  activeNotification: AndroidNotification | null;
  onDismissNotification: () => void;
  onReadNotificationAloud: (notification: AndroidNotification) => void;
  isFullScreenMode: boolean;
  currentTime: string;
}

export const AndroidDeviceFrame: React.FC<AndroidDeviceFrameProps> = ({
  children,
  activeNotification,
  onDismissNotification,
  onReadNotificationAloud,
  isFullScreenMode,
  currentTime,
}) => {
  if (isFullScreenMode) {
    return (
      <div className="w-full h-full relative overflow-hidden bg-[#0A0E17] flex flex-col">
        {/* Heads Up Notification Banner */}
        {activeNotification && (
          <div
            id="notification-banner"
            className="absolute top-4 left-4 right-4 z-50 bg-[#162032]/95 backdrop-blur-md border border-[#00E5FF]/40 rounded-xl p-3.5 shadow-2xl shadow-[#00E5FF]/20 animate-in slide-in-from-top-4 duration-300"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] font-semibold">
                  {activeNotification.app}
                </span>
                <span className="text-xs text-slate-400 font-mono">{activeNotification.time}</span>
              </div>
              <button
                onClick={onDismissNotification}
                className="text-slate-400 hover:text-white p-1"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-sm font-semibold text-white mt-1">{activeNotification.title}</p>
            <p className="text-xs text-slate-300 mt-0.5">{activeNotification.body}</p>
            <div className="mt-2.5 flex items-center gap-2">
              <button
                id="btn-vocalize-notification"
                onClick={() => onReadNotificationAloud(activeNotification)}
                className="text-xs flex items-center gap-1.5 bg-[#00E5FF] text-[#0A0E17] px-3 py-1.5 rounded-lg font-semibold hover:bg-[#00c4db] transition-colors"
              >
                <Volume2 className="w-3.5 h-3.5" />
                Vocalize with JARVIS
              </button>
            </div>
          </div>
        )}
        {children}
      </div>
    );
  }

  return (
    <div className="relative mx-auto my-auto w-full max-w-[390px] h-[780px] max-h-[92vh] bg-[#0A0E17] rounded-[44px] p-3 shadow-2xl shadow-cyan-950/40 border-[8px] border-[#1C2536] flex flex-col ring-1 ring-white/10">
      {/* Top Phone Speaker Slit */}
      <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-14 h-1 bg-[#2D3748] rounded-full z-40 pointer-events-none" />

      {/* Screen Inner Container */}
      <div className="relative w-full h-full bg-[#0A0E17] rounded-[34px] overflow-hidden flex flex-col border border-white/5">
        {/* Android Status Bar */}
        <div className="w-full h-8 px-6 pt-1 flex items-center justify-between text-xs text-slate-300 font-mono select-none z-30 bg-[#0A0E17]">
          <span className="font-semibold text-[11px] text-slate-200 tracking-tight">{currentTime}</span>

          {/* Front Camera Cutout */}
          <div className="w-3.5 h-3.5 rounded-full bg-[#06080D] border border-white/10" />

          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-[10px] font-bold text-[#00E5FF]">5G</span>
            <Wifi className="w-3 h-3 text-slate-300" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">98%</span>
              <Battery className="w-3 h-3 text-[#00E5FF]" />
            </div>
          </div>
        </div>

        {/* Heads Up Notification Banner */}
        {activeNotification && (
          <div
            id="notification-banner-framed"
            className="absolute top-10 left-3 right-3 z-50 bg-[#162032]/95 backdrop-blur-md border border-[#00E5FF]/40 rounded-xl p-3 shadow-2xl shadow-[#00E5FF]/20 animate-in slide-in-from-top-3 duration-300"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] font-semibold">
                  {activeNotification.app}
                </span>
                <span className="text-xs text-slate-400 font-mono">{activeNotification.time}</span>
              </div>
              <button
                onClick={onDismissNotification}
                className="text-slate-400 hover:text-white p-0.5"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs font-semibold text-white mt-1 line-clamp-1">{activeNotification.title}</p>
            <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-2">{activeNotification.body}</p>
            <div className="mt-2 flex items-center gap-2">
              <button
                id="btn-vocalize-notification-framed"
                onClick={() => onReadNotificationAloud(activeNotification)}
                className="text-[11px] flex items-center gap-1.5 bg-[#00E5FF] text-[#0A0E17] px-2.5 py-1 rounded-md font-semibold hover:bg-[#00c4db] transition-colors"
              >
                <Volume2 className="w-3 h-3" />
                Vocalize
              </button>
            </div>
          </div>
        )}

        {/* Screen Content */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {children}
        </div>

        {/* Android Gesture Bar */}
        <div className="w-full h-5 flex items-center justify-center bg-[#0A0E17]">
          <div className="w-24 h-1 bg-slate-600 rounded-full" />
        </div>
      </div>
    </div>
  );
};
