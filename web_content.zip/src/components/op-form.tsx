import { EXPENSE_CODES, INCOME_CODES } from "@/lib/accounting/chart";
import { computeInvoiceTotals } from "@/lib/accounting/engine";
import { formatRial } from "@/lib/accounting/format";
import { todayIso } from "@/lib/accounting/jalali";
import { OP_LABELS, type DiscountMode, type OperationType, type Settlement } from "@/lib/accounting/types";
import { postOperation, saveItem, saveParty } from "@/lib/server/books";
import { AmountInput, JalaliDateField, MoneyText, SearchSelect } from "@/components/fields";
import { Button, Field, Input, Modal, Select, Textarea } from "@/components/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";

type Party = { id: string; code: string; name: string; is_customer?: boolean; is_supplier?: boolean; mobile?: string };
type Item = { id: string; code: string; name: string; unit?: string; sale_price?: string | number; purchase_price?: string | number };
type Source = { id: string; name: string; kind: string };

const INVOICE_TYPES: OperationType[] = ["sale", "sale_return", "purchase", "purchase_return"];
const PARTY_TYPES: OperationType[] = [
  "sale", "sale_return", "purchase", "purchase_return", "receipt", "payment",
  "receipt_invoice", "receipt_other", "payment_invoice", "payment_other",
  "check_in", "check_out", "check_bounce",
];
const SOURCE_TYPES: OperationType[] = [
  "receipt", "payment", "transfer", "sale", "purchase", "expense", "income",
  "receipt_invoice", "receipt_other", "payment_invoice", "payment_other",
  "transfer_cash_bank", "transfer_banks", "petty_in", "check_collect",
  "capital_in", "draw",
];
const DEST_TYPES: OperationType[] = ["transfer", "transfer_cash_bank", "transfer_banks"];

export function OpForm({
  type,
  parties,
  items,
  sources,
  onDone,
}: {
  type: OperationType;
  parties: Party[];
  items: Item[];
  sources: Source[];
  onDone?: () => void;
}) {
  const qc = useQueryClient();
  const [date, setDate] = useState(todayIso());
  const [partyId, setPartyId] = useState("");
  const [sourceId, setSourceId] = useState("");
  const [destSourceId, setDestSourceId] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState(0);
  const [shipping, setShipping] = useState(0);
  const [discountMode, setDiscountMode] = useState<DiscountMode>("percent");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [settlement, setSettlement] = useState<Settlement>("cash");
  const [cashAmount, setCashAmount] = useState(0);
  const [expenseAccountCode, setExpenseAccountCode] = useState("6991");
  const [incomeAccountCode, setIncomeAccountCode] = useState("4391");
  const [checkNumber, setCheckNumber] = useState("");
  const [checkDueDate, setCheckDueDate] = useState(todayIso());
  const [lines, setLines] = useState([{ itemId: "", qty: 1, unitPrice: 0 }]);
  const [partyOpen, setPartyOpen] = useState(false);
  const [itemOpen, setItemOpen] = useState(false);
  const isInvoice = INVOICE_TYPES.includes(type);

  const totals = useMemo(() => {
    try {
      return computeInvoiceTotals({
        lines: isInvoice ? lines.filter((l) => l.itemId) : undefined,
        amount,
        shipping,
        discountMode,
        discountPercent,
        discountAmount,
      });
    } catch {
      return null;
    }
  }, [lines, amount, shipping, discountMode, discountPercent, discountAmount, isInvoice]);

  const mut = useMutation({
    mutationFn: () =>
      postOperation({
        data: {
          type,
          date,
          partyId: partyId || undefined,
          sourceId: sourceId || undefined,
          destSourceId: destSourceId || undefined,
          description: description || OP_LABELS[type],
          amount: isInvoice ? undefined : amount,
          shipping: isInvoice ? shipping : 0,
          discountMode: isInvoice ? discountMode : undefined,
          discountPercent: isInvoice ? discountPercent : undefined,
          discountAmount: isInvoice ? discountAmount : undefined,
          settlement: isInvoice ? settlement : undefined,
          cashAmount: settlement === "mixed" ? cashAmount : undefined,
          expenseAccountCode: type === "expense" || type === "petty_settle" ? expenseAccountCode : undefined,
          incomeAccountCode: type === "income" ? incomeAccountCode : undefined,
          checkNumber: checkNumber || undefined,
          checkDueDate: type.startsWith("check") ? checkDueDate : undefined,
          lines: isInvoice ? lines.filter((l) => l.itemId) : undefined,
        },
      }),
    onSuccess: (res) => {
      toast.success(`ثبت شد — ${res.operationNumber} / ${res.journalNumber}`);
      qc.invalidateQueries();
      onDone?.();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function onPercent(v: number) {
    setDiscountMode("percent");
    setDiscountPercent(v);
    const g = totals?.gross ?? 0;
    setDiscountAmount(g ? Math.round((g * v) / 100) : 0);
  }
  function onAmountDisc(v: number) {
    setDiscountMode("amount");
    setDiscountAmount(v);
    const g = totals?.gross ?? 0;
    setDiscountPercent(g ? Math.round((v / g) * 10000) / 100 : 0);
  }

  const partyOpts = parties.map((p) => ({ id: p.id, label: p.name, sub: p.code }));
  const itemOpts = items.map((i) => ({ id: i.id, label: i.name, sub: i.code }));
  const sourceOpts = sources.map((s) => ({ id: s.id, label: s.name, sub: s.kind }));

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        mut.mutate();
      }}
    >
      <h2 className="text-lg font-semibold text-navy">{OP_LABELS[type]}</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="تاریخ">
          <JalaliDateField value={date} onChange={setDate} />
        </Field>
        {PARTY_TYPES.includes(type) && (
          <Field label="شخص">
            <SearchSelect
              options={partyOpts}
              value={partyId}
              onChange={setPartyId}
              placeholder="جستجوی شخص"
              onCreate={() => setPartyOpen(true)}
              createLabel="+ شخص جدید"
            />
          </Field>
        )}
        {SOURCE_TYPES.includes(type) && settlement !== "credit" && (
          <Field label={DEST_TYPES.includes(type) ? "مبدأ" : "منبع مالی"}>
            <SearchSelect options={sourceOpts} value={sourceId} onChange={setSourceId} placeholder="صندوق یا بانک" />
          </Field>
        )}
        {DEST_TYPES.includes(type) && (
          <Field label="مقصد">
            <SearchSelect options={sourceOpts} value={destSourceId} onChange={setDestSourceId} placeholder="مقصد" />
          </Field>
        )}
        {isInvoice && (
          <Field label="نحوه تسویه">
            <Select value={settlement} onChange={(e) => setSettlement(e.target.value as Settlement)}>
              <option value="cash">نقد / صندوق</option>
              <option value="bank">بانکی</option>
              <option value="credit">نسیه</option>
              <option value="mixed">ترکیبی</option>
            </Select>
          </Field>
        )}
        {type === "expense" && (
          <Field label="حساب هزینه">
            <Select value={expenseAccountCode} onChange={(e) => setExpenseAccountCode(e.target.value)}>
              {EXPENSE_CODES.map((c) => (
                <option key={c.code} value={c.code}>{c.name}</option>
              ))}
            </Select>
          </Field>
        )}
        {type === "income" && (
          <Field label="حساب درآمد">
            <Select value={incomeAccountCode} onChange={(e) => setIncomeAccountCode(e.target.value)}>
              {INCOME_CODES.map((c) => (
                <option key={c.code} value={c.code}>{c.name}</option>
              ))}
            </Select>
          </Field>
        )}
      </div>

      {isInvoice && (
        <div className="space-y-2 rounded-xl border border-line p-3">
          <p className="text-xs font-medium text-muted">اقلام فاکتور</p>
          {lines.map((ln, i) => (
            <div key={i} className="grid grid-cols-12 gap-2">
              <div className="col-span-12 sm:col-span-5">
                <SearchSelect
                  options={itemOpts}
                  value={ln.itemId}
                  onChange={(id) => {
                    const it = items.find((x) => x.id === id);
                    const price = type.startsWith("purchase")
                      ? Number(it?.purchase_price ?? 0)
                      : Number(it?.sale_price ?? 0);
                    setLines((prev) => prev.map((p, idx) => (idx === i ? { ...p, itemId: id, unitPrice: price } : p)));
                  }}
                  placeholder="کالا"
                  onCreate={() => setItemOpen(true)}
                  createLabel="+ کالای جدید"
                />
              </div>
              <div className="col-span-4 sm:col-span-2">
                <Input
                  type="number"
                  min={0}
                  value={ln.qty}
                  onChange={(e) => setLines((prev) => prev.map((p, idx) => (idx === i ? { ...p, qty: Number(e.target.value) } : p)))}
                />
              </div>
              <div className="col-span-8 sm:col-span-3">
                <AmountInput
                  value={ln.unitPrice}
                  onChange={(n) => setLines((prev) => prev.map((p, idx) => (idx === i ? { ...p, unitPrice: n } : p)))}
                />
              </div>
              <div className="col-span-12 flex items-center justify-between sm:col-span-2">
                <MoneyText value={ln.qty * ln.unitPrice} />
                <button
                  type="button"
                  className="text-xs text-danger"
                  onClick={() => setLines((prev) => prev.filter((_, idx) => idx !== i))}
                >
                  حذف
                </button>
              </div>
            </div>
          ))}
          <Button type="button" variant="ghost" onClick={() => setLines((p) => [...p, { itemId: "", qty: 1, unitPrice: 0 }])}>
            + ردیف
          </Button>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="درصد تخفیف">
              <Input
                type="number"
                step="0.01"
                value={discountPercent || ""}
                onChange={(e) => onPercent(Number(e.target.value) || 0)}
              />
            </Field>
            <Field label="مبلغ تخفیف">
              <AmountInput value={discountAmount} onChange={onAmountDisc} />
            </Field>
            <Field label="هزینه حمل">
              <AmountInput value={shipping} onChange={setShipping} />
            </Field>
          </div>
          {totals && (
            <div className="space-y-1 rounded-md bg-paper-2 p-3 text-sm">
              <Row k="مبلغ ناخالص" v={totals.gross} />
              <Row k="تخفیف" v={totals.discountAmount} />
              <Row k="حمل" v={totals.shipping} />
              <Row k="مبلغ نهایی" v={totals.net} strong />
            </div>
          )}
        </div>
      )}

      {!isInvoice && (
        <Field label="مبلغ">
          <AmountInput value={amount} onChange={setAmount} />
        </Field>
      )}

      {type.startsWith("check") && (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="شماره چک">
            <Input value={checkNumber} onChange={(e) => setCheckNumber(e.target.value)} />
          </Field>
          <Field label="سررسید">
            <JalaliDateField value={checkDueDate} onChange={setCheckDueDate} />
          </Field>
        </div>
      )}

      {settlement === "mixed" && (
        <Field label="مبلغ نقدی تسویه ترکیبی">
          <AmountInput value={cashAmount} onChange={setCashAmount} />
        </Field>
      )}

      <Field label="شرح">
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="شرح عملیات" />
      </Field>

      <Button type="submit" className="w-full" disabled={mut.isPending}>
        {mut.isPending ? "در حال ثبت..." : "ثبت عملیات"}
      </Button>

      <QuickParty open={partyOpen} onClose={() => setPartyOpen(false)} onSaved={(id) => { setPartyId(id); qc.invalidateQueries(); }} />
      <QuickItem open={itemOpen} onClose={() => setItemOpen(false)} onSaved={(id) => { qc.invalidateQueries(); setLines((p) => { const copy = [...p]; if (copy.length) copy[copy.length - 1] = { ...copy[copy.length - 1], itemId: id }; return copy; }); }} />
    </form>
  );
}

function Row({ k, v, strong }: { k: string; v: number; strong?: boolean }) {
  return (
    <div className={cnRow(strong)}>
      <span>{k}</span>
      <span dir="ltr">{formatRial(v)}</span>
    </div>
  );
}
function cnRow(strong?: boolean) {
  return strong ? "flex justify-between font-semibold text-navy" : "flex justify-between text-muted";
}

function QuickParty({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: (id: string) => void }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [mobile, setMobile] = useState("");
  const [role, setRole] = useState("customer");
  return (
    <Modal open={open} onClose={onClose} title="شخص جدید">
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            const res = await saveParty({
              data: {
                code: code || `P${Date.now().toString().slice(-5)}`,
                name,
                mobile,
                isCustomer: role !== "supplier",
                isSupplier: role !== "customer",
              },
            });
            if (res.duplicates?.length) toast.message("احتمال رکورد تکراری وجود دارد.");
            onSaved(res.id);
            onClose();
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "خطا");
          }
        }}
      >
        <Field label="نام"><Input required value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="کد"><Input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Field label="موبایل"><Input value={mobile} onChange={(e) => setMobile(e.target.value)} /></Field>
        <Field label="نقش">
          <Select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="customer">مشتری</option>
            <option value="supplier">تأمین‌کننده</option>
            <option value="both">هر دو</option>
          </Select>
        </Field>
        <Button type="submit" className="w-full">ذخیره</Button>
      </form>
    </Modal>
  );
}

function QuickItem({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: (id: string) => void }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [sale, setSale] = useState(0);
  const [buy, setBuy] = useState(0);
  return (
    <Modal open={open} onClose={onClose} title="کالای جدید">
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            const res = await saveItem({
              data: { code: code || `G${Date.now().toString().slice(-5)}`, name, salePrice: sale, purchasePrice: buy },
            });
            if (res.duplicates?.length) toast.message("احتمال کالای تکراری وجود دارد.");
            onSaved(res.id);
            onClose();
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "خطا");
          }
        }}
      >
        <Field label="نام"><Input required value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="کد"><Input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Field label="قیمت فروش"><AmountInput value={sale} onChange={setSale} /></Field>
        <Field label="قیمت خرید"><AmountInput value={buy} onChange={setBuy} /></Field>
        <Button type="submit" className="w-full">ذخیره</Button>
      </form>
    </Modal>
  );
}
