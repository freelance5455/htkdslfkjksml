import React from 'react';
import { RotateCcw, Lightbulb, RefreshCw, PlusCircle } from 'lucide-react';
import { sound } from '../utils/audio';

interface GameControlsProps {
  onUndo: () => void;
  onHint: () => void;
  onRestart: () => void;
  onAddExtraTube: () => void;
  canUndo: boolean;
  undosCount: number;
  hintsCount: number;
  extraTubesCount: number;
  isNoUndoLevel: boolean;
  isExtraTubeUsed: boolean;
  disabled?: boolean;
}

export const GameControls: React.FC<GameControlsProps> = ({
  onUndo,
  onHint,
  onRestart,
  onAddExtraTube,
  canUndo,
  undosCount,
  hintsCount,
  extraTubesCount,
  isNoUndoLevel,
  isExtraTubeUsed,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-3 pb-3 sm:pb-4 pt-1 flex items-center justify-center gap-2.5 sm:gap-3 select-none z-20 shrink-0 touch-manipulation">
      {/* UNDO BUTTON */}
      <button
        disabled={disabled || !canUndo || isNoUndoLevel}
        onClick={() => {
          sound.playClick();
          onUndo();
        }}
        className={`relative flex-1 min-h-[52px] flex flex-col items-center justify-center py-2 px-1.5 rounded-2xl border transition-all active:scale-95 touch-manipulation ${
          !canUndo || isNoUndoLevel || disabled
            ? 'bg-slate-900/40 border-slate-800/40 text-slate-600 cursor-not-allowed opacity-60'
            : 'crystal-button bg-slate-900/80 border-cyan-500/30 text-slate-100 hover:text-white hover:border-cyan-400/60 shadow-[0_4px_16px_rgba(0,0,0,0.4)] active:bg-slate-800'
        }`}
      >
        <RotateCcw className="w-4.5 h-4.5 mb-0.5 text-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
        <span className="text-[11px] font-black tracking-wide uppercase">Undo</span>
        <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-black bg-cyan-400 text-slate-950 shadow-[0_0_8px_rgba(34,211,238,0.7)] border border-cyan-200">
          {undosCount}
        </span>
      </button>

      {/* RESTART BUTTON */}
      <button
        disabled={disabled}
        onClick={() => {
          sound.playClick();
          onRestart();
        }}
        className="flex-1 min-h-[52px] flex flex-col items-center justify-center py-2 px-1.5 rounded-2xl crystal-button bg-slate-900/80 border-rose-500/30 text-slate-100 hover:text-white hover:border-rose-400/60 shadow-[0_4px_16px_rgba(0,0,0,0.4)] active:scale-95 active:bg-slate-800 transition-all touch-manipulation"
      >
        <RefreshCw className="w-4.5 h-4.5 mb-0.5 text-rose-400 drop-shadow-[0_0_6px_rgba(251,113,133,0.5)]" />
        <span className="text-[11px] font-black tracking-wide uppercase">Reset</span>
      </button>

      {/* HINT BUTTON */}
      <button
        disabled={disabled}
        onClick={() => {
          sound.playClick();
          onHint();
        }}
        className="relative flex-1 min-h-[52px] flex flex-col items-center justify-center py-2 px-1.5 rounded-2xl crystal-button bg-slate-900/80 border-yellow-500/30 text-slate-100 hover:text-white hover:border-yellow-400/60 shadow-[0_4px_16px_rgba(0,0,0,0.4)] active:scale-95 active:bg-slate-800 transition-all touch-manipulation"
      >
        <Lightbulb className="w-4.5 h-4.5 mb-0.5 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.6)]" />
        <span className="text-[11px] font-black tracking-wide uppercase">Hint</span>
        <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-black bg-yellow-400 text-slate-950 shadow-[0_0_8px_rgba(250,204,21,0.7)] border border-yellow-200">
          {hintsCount}
        </span>
      </button>

      {/* ADD EXTRA TUBE POWERUP */}
      <button
        disabled={disabled || isExtraTubeUsed}
        onClick={() => {
          sound.playClick();
          onAddExtraTube();
        }}
        className={`relative flex-1 min-h-[52px] flex flex-col items-center justify-center py-2 px-1.5 rounded-2xl border transition-all active:scale-95 touch-manipulation ${
          isExtraTubeUsed || disabled
            ? 'bg-slate-900/40 border-slate-800/40 text-slate-600 cursor-not-allowed opacity-60'
            : 'crystal-button bg-gradient-to-b from-purple-900/60 to-slate-900/90 border-purple-500/40 text-purple-100 hover:text-white hover:border-purple-400/70 shadow-[0_4px_16px_rgba(0,0,0,0.4)] active:bg-purple-900'
        }`}
      >
        <PlusCircle className="w-4.5 h-4.5 mb-0.5 text-purple-400 drop-shadow-[0_0_6px_rgba(192,132,252,0.6)]" />
        <span className="text-[11px] font-black tracking-wide uppercase">+Tube</span>
        <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-black bg-purple-400 text-slate-950 shadow-[0_0_8px_rgba(192,132,252,0.7)] border border-purple-200">
          {extraTubesCount}
        </span>
      </button>
    </div>
  );
};
