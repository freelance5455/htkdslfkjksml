import React, { useState } from 'react';
import { ScriptScene } from '../data/scriptData';
import {
  Mic,
  Play,
  Pause,
  Download,
  Sparkles,
  Volume2,
  RefreshCw,
  Check,
  AlertCircle,
  FileText,
  Sliders,
  Radio,
} from 'lucide-react';
import { calculateEstimatedDuration, formatTime } from '../utils/scriptUtils';

interface VoiceOption {
  id: string;
  nameBn: string;
  nameEn: string;
  tone: string;
  gender: string;
  bestFor: string;
}

const VOICES: VoiceOption[] = [
  { id: 'Puck', nameBn: 'পাক (Puck)', nameEn: 'Puck', tone: 'উৎসাহী ও ডায়নামিক (Energetic & Dynamic)', gender: 'Male', bestFor: 'Shorts, Reels, Tech Hype' },
  { id: 'Kore', nameBn: 'কোরে (Kore)', nameEn: 'Kore', tone: 'স্পষ্ট ও প্রফেশনাল (Clear & Articulate)', gender: 'Female', bestFor: 'Documentary, Career Guide' },
  { id: 'Zephyr', nameBn: 'জেফির (Zephyr)', nameEn: 'Zephyr', tone: 'বন্ধুত্বপূর্ণ ও সাবলীল (Warm & Conversational)', gender: 'Female', bestFor: 'Storytelling, Mentorship' },
  { id: 'Fenrir', nameBn: 'ফেনরির (Fenrir)', nameEn: 'Fenrir', tone: 'গম্ভীর ও নির্ভরযোগ্য (Deep & Authoritative)', gender: 'Male', bestFor: 'Market Analysis, Serious Overview' },
  { id: 'Charon', nameBn: 'ক্যারন (Charon)', nameEn: 'Charon', tone: 'শান্ত ও বর্ণনামূলক (Calm & Reflective)', gender: 'Male', bestFor: 'Educational, Long-form' },
];

const STYLE_PRESETS = [
  { id: 'tech', label: 'Inspiring Bengali Tech Presenter (প্রেজেন্টার)', style: 'Inspiring, articulate Bengali tech presenter, clear and modern tone' },
  { id: 'documentary', label: 'Professional Documentary (ডকুমেন্টারি)', style: 'Deep, informative, measured documentary narrator style' },
  { id: 'shorts', label: 'Fast-paced Viral Shorts (শর্টস/রিলস)', style: 'Punchy, high-energy YouTube Shorts presenter with crisp pauses' },
  { id: 'mentor', label: 'Warm Motivational Mentor (মেন্টর)', style: 'Encouraging, friendly career mentor talking to ambitious learners' },
];

interface TTSStudioProps {
  scenes: ScriptScene[];
  selectedSceneIndex: number;
  onAudioGenerated: (audioUrl: string, sceneTitle: string) => void;
}

export const TTSStudio: React.FC<TTSStudioProps> = ({
  scenes,
  selectedSceneIndex,
  onAudioGenerated,
}) => {
  const [selectedVoice, setSelectedVoice] = useState<string>('Puck');
  const [selectedStyle, setSelectedStyle] = useState<string>(STYLE_PRESETS[0].style);
  const [customStyle, setCustomStyle] = useState<string>('');
  const [generationMode, setGenerationMode] = useState<'scene' | 'full' | 'custom'>('scene');
  const [customText, setCustomText] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string | null>(null);
  const [lastGeneratedTitle, setLastGeneratedTitle] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPlayingLocal, setIsPlayingLocal] = useState<boolean>(false);

  const localAudioRef = React.useRef<HTMLAudioElement | null>(null);

  const activeScene = scenes[selectedSceneIndex] || scenes[0];

  // Full concatenated script
  const fullScript = scenes.map((s) => s.textBn).join('\n\n---\n\n');

  const getTextToSynthesize = (): string => {
    if (generationMode === 'scene') return activeScene.textBn;
    if (generationMode === 'full') return fullScript;
    return customText;
  };

  const textToSynthesize = getTextToSynthesize();
  const estimatedSeconds = calculateEstimatedDuration(textToSynthesize);

  const handleGenerateTTS = async () => {
    const text = textToSynthesize.trim();
    if (!text) {
      setErrorMsg('ভয়েসওভার তৈরি করার জন্য টেক্সট খালি রাখা যাবে না।');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);

    const styleToUse = customStyle.trim() || selectedStyle;
    const title =
      generationMode === 'scene'
        ? activeScene.titleBn
        : generationMode === 'full'
        ? 'সম্পূর্ণ ৫টি স্কিল ভিডিও স্ক্রিপ্ট'
        : 'কাস্টম ভয়েসওভার';

    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voiceName: selectedVoice,
          style: styleToUse,
          speaker: 'Presenter',
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || data.message || 'TTS generation failed');
      }

      // Convert base64 to data URL
      const audioUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      setGeneratedAudioUrl(audioUrl);
      setLastGeneratedTitle(title);
      onAudioGenerated(audioUrl, title);

      // Reset local player
      if (localAudioRef.current) {
        localAudioRef.current.src = audioUrl;
      }
    } catch (err: any) {
      console.error('TTS error:', err);
      setErrorMsg(err.message || 'ভয়েস তৈরিতে সমস্যা হয়েছে। সার্ভার স্ট্যাটাস চেক করুন।');
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleLocalPlay = () => {
    const audio = localAudioRef.current;
    if (!audio || !generatedAudioUrl) return;

    if (isPlayingLocal) {
      audio.pause();
      setIsPlayingLocal(false);
    } else {
      audio.play().catch(console.error);
      setIsPlayingLocal(true);
    }
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Hidden local audio element */}
      <audio
        ref={localAudioRef}
        onEnded={() => setIsPlayingLocal(false)}
        preload="auto"
      />

      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-800/40 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              Model: gemini-3.8-flash-tts
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-bengali">
              Gemini 3.8 Flash ভয়েসওভার স্টুডিও
            </h1>
            <p className="mt-1 text-sm text-slate-300 font-bengali">
              অত্যাধুনিক AI ভয়েস সিন্থেসিস মডেল gemini-3.8-flash-tts ব্যবহার করে স্ক্রিপ্টের বাংলা ভয়েস ট্র্যাক তৈরি করুন।
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <div>
              <p className="text-slate-400 text-[10px]">WAV 24kHz Unary</p>
              <p className="text-emerald-300 font-bold">gemini-3.8-flash-tts</p>
            </div>
          </div>
        </div>
      </div>

      {/* Error Alert */}
      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/80 flex items-start gap-3 text-red-200 text-sm">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1 font-bengali">
            <strong className="block text-red-300">ভয়েস তৈরিতে ত্রুটি:</strong>
            {errorMsg}
          </div>
          <button
            onClick={() => setErrorMsg(null)}
            className="text-red-400 hover:text-red-200 text-xs font-mono"
          >
            বন্ধ
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Script Mode & Content Input */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
            {/* Mode Selector Tabs */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <span className="text-sm font-bold text-white font-bengali">
                সিন্থেসিস মোড নির্বাচন করুন:
              </span>
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  onClick={() => setGenerationMode('scene')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bengali transition cursor-pointer ${
                    generationMode === 'scene'
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  বর্তমান দৃশ্য (#{activeScene.order})
                </button>
                <button
                  onClick={() => setGenerationMode('full')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bengali transition cursor-pointer ${
                    generationMode === 'full'
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  সম্পূর্ণ স্ক্রিপ্ট (৭ দৃশ্য)
                </button>
                <button
                  onClick={() => setGenerationMode('custom')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bengali transition cursor-pointer ${
                    generationMode === 'custom'
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  কাস্টম টেক্সট
                </button>
              </div>
            </div>

            {/* Content Display / Input */}
            <div className="mt-4 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-bengali">
                  {generationMode === 'scene' && `দৃশ্য: ${activeScene.titleBn}`}
                  {generationMode === 'full' && 'সম্পূর্ণ ভিডিও স্ক্রিপ্ট (Full Flow)'}
                  {generationMode === 'custom' && 'আপনার নিজের প্রম্পট বা ডায়লগ লিখুন'}
                </span>
                <span className="font-mono text-emerald-400">
                  ~{formatTime(estimatedSeconds)} ({textToSynthesize.split(/\s+/).filter(Boolean).length} শব্দ)
                </span>
              </div>

              {generationMode === 'custom' ? (
                <textarea
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  placeholder="এখানে আপনার কাঙ্ক্ষিত বাংলা স্ক্রিপ্ট লিখুন..."
                  rows={8}
                  className="w-full p-4 rounded-xl bg-slate-950/80 border border-slate-700/80 text-slate-100 font-bengali text-base focus:outline-none focus:ring-2 focus:ring-emerald-500 transition resize-y"
                />
              ) : (
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 max-h-72 overflow-y-auto">
                  <p className="font-bengali text-slate-200 text-base leading-relaxed whitespace-pre-line">
                    {textToSynthesize}
                  </p>
                </div>
              )}
            </div>

            {/* Generation CTA Button */}
            <div className="mt-5">
              <button
                onClick={handleGenerateTTS}
                disabled={isGenerating || !textToSynthesize.trim()}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-bold text-base shadow-xl shadow-emerald-500/20 hover:brightness-110 active:scale-[0.99] transition disabled:opacity-50 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span className="font-bengali">Gemini 3.8 Flash TTS প্রসেস হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5 fill-slate-950" />
                    <span className="font-bengali">Gemini 3.8 Flash TTS ভয়েস জেনারেট করুন</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Generated Audio Preview & Actions */}
          {generatedAudioUrl && (
            <div className="bg-slate-900/90 rounded-2xl border border-emerald-500/40 p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-5 h-5" />
                  <span className="font-bengali font-bold text-sm">
                    ভয়েসওভার সফলভাবে তৈরি হয়েছে!
                  </span>
                </div>
                <span className="text-xs font-mono text-slate-400">{lastGeneratedTitle}</span>
              </div>

              {/* Player Card */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800">
                <button
                  onClick={toggleLocalPlay}
                  className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer"
                  aria-label={isPlayingLocal ? 'Pause' : 'Play'}
                >
                  {isPlayingLocal ? <Pause className="w-5 h-5 fill-slate-950" /> : <Play className="w-5 h-5 fill-slate-950 ml-0.5" />}
                </button>

                <div className="flex-1">
                  <div className="flex items-center justify-between text-xs text-slate-300 font-mono">
                    <span>Voice: {selectedVoice}</span>
                    <span className="text-emerald-400">WAV (24kHz Mono)</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 mt-2 overflow-hidden">
                    <div
                      className={`h-full bg-emerald-500 ${isPlayingLocal ? 'animate-pulse' : ''}`}
                      style={{ width: isPlayingLocal ? '80%' : '100%' }}
                    />
                  </div>
                </div>

                <a
                  href={generatedAudioUrl}
                  download="Skill2027_Gemini_TTS_Audio.wav"
                  className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 transition cursor-pointer"
                  title="Download WAV File"
                  aria-label="Download WAV"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Voice Personas & Style Tuner */}
        <div className="lg:col-span-5 space-y-6">
          {/* Voice Selector Card */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              ভয়েস পারসোনা নির্বাচন (Prebuilt Voices)
            </h3>

            <div className="mt-3 space-y-2">
              {VOICES.map((voice) => {
                const isSelected = selectedVoice === voice.id;
                return (
                  <button
                    key={voice.id}
                    onClick={() => setSelectedVoice(voice.id)}
                    className={`w-full p-3 rounded-xl text-left border transition cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800 border-emerald-500 text-white ring-1 ring-emerald-500/50 shadow-md shadow-emerald-950/50'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            isSelected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                          }`}
                        />
                        <span className="font-bold text-xs sm:text-sm font-bengali text-slate-100">
                          {voice.nameBn}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {voice.gender}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 font-bengali mt-1 pl-4">
                      {voice.tone}
                    </p>
                    <p className="text-[11px] text-emerald-400/80 font-mono mt-0.5 pl-4">
                      Best: {voice.bestFor}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Delivery Style Presets */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              ডেলিভারি স্টাইল ও স্পিচ মেটাডেটা (Speech Style)
            </h3>

            <div className="mt-3 space-y-2">
              {STYLE_PRESETS.map((preset) => {
                const isSelected = selectedStyle === preset.style;
                return (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setSelectedStyle(preset.style);
                      setCustomStyle('');
                    }}
                    className={`w-full p-2.5 rounded-xl text-left text-xs transition cursor-pointer border ${
                      isSelected && !customStyle
                        ? 'bg-slate-800 border-cyan-500 text-cyan-300 font-medium'
                        : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:bg-slate-800/30'
                    }`}
                  >
                    <p className="font-bengali text-slate-200">{preset.label}</p>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5 truncate">
                      "{preset.style}"
                    </p>
                  </button>
                );
              })}
            </div>

            <div className="mt-3 pt-3 border-t border-slate-800">
              <label className="text-[11px] text-slate-400 font-bengali block mb-1">
                কাস্টম স্পিচ স্টাইল প্রম্পট (ঐচ্ছিক):
              </label>
              <input
                type="text"
                value={customStyle}
                onChange={(e) => setCustomStyle(e.target.value)}
                placeholder="যেমন: Urgent and dramatic, slow clear pronunciation..."
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
