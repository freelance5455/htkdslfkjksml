import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Sparkles,
  Send,
  Bot,
  User,
  Loader2,
  HelpCircle,
  LogIn,
  CheckCircle2,
  ArrowRight,
  Zap,
  Trash2,
  Copy,
  Check,
  Lightbulb,
  FileText,
  ShieldCheck,
  CornerDownLeft,
  Mail
} from "lucide-react";
import { Note, UserProfile } from "../types";
import { AuthModal } from "./AuthModal";

interface Message {
  role: "user" | "assistant";
  text: string;
  timestamp?: string;
}

interface AIChatModalProps {
  notes: Note[];
  profile: UserProfile;
  onUpdateProfile?: (p: UserProfile) => void;
  onOpenProfile?: () => void;
  onClose: () => void;
}

const QUICK_SUGGESTIONS = [
  "📋 Notlarımdaki tüm yapılacak görevleri ve öncelikleri özetle",
  "💡 Bu haftaki çalışma konularımdan 3 önemli sınav sorusu çıkar",
  "🚀 Notlarımdaki fikirleri birleştirip yaratıcı bir proje planı sun",
  "📊 Genel bilgi ekosistemimdeki eksik veya geliştirilmesi gereken alanlar neler?",
];

export const AIChatModal: React.FC<AIChatModalProps> = ({
  notes,
  profile,
  onUpdateProfile,
  onOpenProfile,
  onClose,
}) => {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      text: `Merhaba ${profile.name || "Kullanıcı"}! 👋 Ben NoteFlow Akıllı Asistanınızım. Notlarınızla ilgili sorular sorabilir, derin kavramsal analizler isteyebilir veya yeni yaratıcı fikirler üretebilirsiniz. Size nasıl yardımcı olabilirim?`,
      timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedNoteId, setSelectedNoteId] = useState<string>("all");
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  // Guest / Trial state if not logged in
  const [guestTrialUsed, setGuestTrialUsed] = useState(false);
  const [showGuestTrial, setShowGuestTrial] = useState(false);
  const [tempEmailInput, setTempEmailInput] = useState("");
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleCopyMessage = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleClearChat = () => {
    setMessages([
      {
        role: "assistant",
        text: "Sohbet geçmişi temizlendi. Yeni bir soru sorabilirsiniz!",
        timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
  };

  // 1-Click Quick Google Connect from inside Modal
  const handleModalGoogleSignIn = () => {
    setIsAuthenticating(true);
    setTimeout(() => {
      if (onUpdateProfile) {
        onUpdateProfile({
          ...profile,
          name: profile.name || "Enes Erdem",
          email: "enes02erdm@gmail.com",
          isLoggedIn: true,
          authProvider: "google",
          aiModeEnabled: true,
        });
      }
      setIsAuthenticating(false);
    }, 500);
  };

  // Quick Email Connect from inside Modal
  const handleModalEmailSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempEmailInput.trim()) return;
    setIsAuthenticating(true);
    setTimeout(() => {
      if (onUpdateProfile) {
        onUpdateProfile({
          ...profile,
          name: tempEmailInput.split("@")[0] || "Kullanıcı",
          email: tempEmailInput.trim(),
          isLoggedIn: true,
          authProvider: "email",
          aiModeEnabled: true,
        });
      }
      setIsAuthenticating(false);
    }, 500);
  };

  const handleSend = async (queryText?: string) => {
    const query = (queryText || input).trim();
    if (!query || loading) return;

    const newMsgs: Message[] = [
      ...messages,
      {
        role: "user",
        text: query,
        timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
      },
    ];
    setMessages(newMsgs);
    setInput("");
    setLoading(true);

    if (!profile.isLoggedIn) {
      setGuestTrialUsed(true);
    }

    let contextTitle = "";
    let contextContent = "";

    if (selectedNoteId === "all") {
      contextTitle = "Tüm Notlar Ekosistemi";
      contextContent = notes
        .map((n) => `[Kategori: ${n.category}] ${n.title}\n${n.content.slice(0, 350)}\nEtiketler: ${(n.tags || []).join(", ")}`)
        .join("\n---\n");
    } else {
      const selected = notes.find((n) => n.id === selectedNoteId);
      if (selected) {
        contextTitle = selected.title;
        contextContent = `${selected.content}\n\nGörevler: ${(selected.tasks || []).map((t) => t.text).join(", ")}`;
      }
    }

    try {
      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: query,
          noteTitle: contextTitle,
          noteContent: contextContent,
        }),
      });
      const data = await res.json();
      if (data.answer) {
        setMessages([
          ...newMsgs,
          {
            role: "assistant",
            text: data.answer,
            timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
          },
        ]);
        if (onUpdateProfile && profile.isLoggedIn) {
          onUpdateProfile({
            ...profile,
            aiQuestionsCount: (profile.aiQuestionsCount || 0) + 1,
          });
        }
      } else {
        setMessages([
          ...newMsgs,
          {
            role: "assistant",
            text: data.error || "Yanıt oluşturulurken bir aksaklık oldu. Lütfen tekrar deneyin.",
            timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
          },
        ]);
      }
    } catch (err) {
      setMessages([
        ...newMsgs,
        {
          role: "assistant",
          text: "Bağlantı hatası: Yapay zeka asistan servisine şu anda ulaşılamıyor.",
          timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const isUserBlockedFromAI = !profile.isLoggedIn && guestTrialUsed && !showGuestTrial;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-5 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full h-[100dvh] sm:h-[88dvh] sm:max-w-2xl bg-white dark:bg-slate-900 sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[100dvh] sm:max-h-[800px] relative modal-overscroll-contain">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-gradient-to-bl from-teal-500/10 via-emerald-500/5 to-transparent rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-800/80 backdrop-blur-sm z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-teal-600 via-emerald-600 to-cyan-500 text-white flex items-center justify-center shadow-md shadow-teal-500/20">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  NoteFlow Akıllı Asistan & Soru Sor
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {profile.isLoggedIn
                  ? `Bağlı: ${profile.email} (${profile.name})`
                  : "Yapay zeka erişimi için Gmail/E-posta ile giriş yapın"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {messages.length > 1 && (
              <button
                onClick={handleClearChat}
                className="p-2 text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                title="Sohbeti Temizle"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
              title="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* NOT LOGGED IN / AUTHENTICATION GATEWAY VIEW */}
        {!profile.isLoggedIn && !showGuestTrial ? (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-center items-center text-center space-y-5 bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-950">
            <div className="w-16 h-16 rounded-3xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto shadow-inner">
              <Sparkles className="w-8 h-8 text-amber-500 animate-pulse" />
            </div>

            <div className="max-w-md space-y-2">
              <h4 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                Yapay Zeka Soru-Cevap & Asistan Girişi
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Tüm yapay zeka araçlarından (soru sorma, otomatik özetleme, zihin haritası, flashcard) faydalanmak için profilinizden Gmail veya e-posta ile bağlanın.
              </p>
            </div>

            {/* Quick Login Options inside modal */}
            <div className="w-full max-w-sm space-y-2.5 pt-2">
              <button
                onClick={() => {
                  setAuthMode("login");
                  setShowAuthModal(true);
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-800 dark:text-white font-extrabold text-xs border border-slate-300 dark:border-slate-700 shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer hover:border-teal-500"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Google ile Bağlan</span>
              </button>

              <button
                onClick={() => {
                  setAuthMode("login");
                  setShowAuthModal(true);
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-extrabold text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
              >
                <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 170 170">
                  <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.74 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.7-3.04-7.65-7.79-11.86-14.24-7.51-11.53-13.08-24.66-16.71-39.38-3.63-14.73-5.45-28.53-5.45-41.42 0-16.14 3.8-29.58 11.41-40.32 7.6-10.74 17.54-16.2 29.82-16.39 4.8 0 10.37 1.34 16.71 4.02 6.34 2.68 10.38 4.07 12.13 4.18 1.45 0 5.75-1.5 12.89-4.5 7.15-3 13.01-4.32 17.58-3.96 13.62.77 24.52 5.72 32.7 14.86-11.96 7.27-17.84 17.2-17.65 29.8.19 9.87 3.99 18.06 11.38 24.57 7.4 6.51 16.12 10.2 26.17 11.07-2.6 7.82-5.75 16.03-9.47 24.62zm-35.34-106.6c.13-5.11 2.05-10.25 5.76-15.42 3.71-5.17 8.3-8.88 13.78-11.13.39 1.13.58 2.22.58 3.27 0 5.48-2.07 10.9-6.2 16.27-4.13 5.37-9.39 8.87-15.77 10.51-.13-.98-.22-2.14-.22-3.5z" />
                </svg>
                <span>Apple ile Giriş Yap</span>
              </button>

              <button
                onClick={() => {
                  setAuthMode("login");
                  setShowAuthModal(true);
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs shadow-md shadow-teal-600/20 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>E-posta ve Şifre ile Giriş Yap / Kayıt Ol</span>
              </button>

              {/* Guest test button */}
              <button
                onClick={() => setShowGuestTrial(true)}
                className="w-full py-2 px-3 rounded-xl border border-dashed border-teal-300 dark:border-teal-700 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-bold transition-colors cursor-pointer"
              >
                ✨ Giriş Yapmadan 1 Deneme Sorusu Sor
              </button>
            </div>

            {/* Reassurance for non-AI users */}
            <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/60 max-w-md text-left text-xs text-slate-600 dark:text-slate-400 space-y-1">
              <p className="font-bold text-slate-800 dark:text-slate-200">
                🍃 Yapay zeka kullanmak istemiyor musunuz?
              </p>
              <p>
                Hiçbir giriş yapmadan tüm standart notlarınızı, 30 çerçeve şablonunu, ses kaydı, çizim ve kasa özelliklerini sınırsızca kullanabilirsiniz.
              </p>
              <button
                onClick={onClose}
                className="mt-1 text-teal-600 dark:text-teal-400 font-bold hover:underline"
              >
                Klasik Not Defterine Dön →
              </button>
            </div>
          </div>
        ) : (
          /* ACTIVE CHAT WORKSPACE */
          <>
            {/* Note context selector bar */}
            <div className="px-4 py-2.5 bg-slate-100/90 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs z-10">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span className="text-slate-500 font-semibold shrink-0">Bağlam Notu:</span>
                <select
                  value={selectedNoteId}
                  onChange={(e) => setSelectedNoteId(e.target.value)}
                  className="flex-1 bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg px-2 py-1 focus:outline-none truncate text-xs"
                >
                  <option value="all">Tüm Notlarımın Ekosistemi ({notes.length} not)</option>
                  {notes.map((n) => (
                    <option key={n.id} value={n.id}>
                      [{n.category}] {n.title || "Başlıksız Not"}
                    </option>
                  ))}
                </select>
              </div>

              {!profile.isLoggedIn && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 shrink-0">
                  Deneme Modu
                </span>
              )}
            </div>

            {/* Chat message stream */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex items-start gap-3 ${
                    m.role === "user" ? "flex-row-reverse" : "flex-row"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 shadow-xs ${
                      m.role === "user"
                        ? "bg-teal-600 text-white"
                        : "bg-gradient-to-tr from-slate-200 to-slate-100 dark:from-slate-800 dark:to-slate-700 text-teal-600 dark:text-teal-400 border border-slate-200 dark:border-slate-700"
                    }`}
                  >
                    {m.role === "user" ? (
                      profile.name.slice(0, 1).toUpperCase() || <User className="w-4 h-4" />
                    ) : (
                      <Bot className="w-4 h-4" />
                    )}
                  </div>

                  <div className="flex flex-col space-y-1 max-w-[85%] sm:max-w-[78%]">
                    <div
                      className={`rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed relative group ${
                        m.role === "user"
                          ? "bg-teal-600 text-white rounded-tr-xs shadow-xs"
                          : "bg-slate-100 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 rounded-tl-xs border border-slate-200/70 dark:border-slate-700/70 whitespace-pre-wrap shadow-2xs"
                      }`}
                    >
                      {m.text}

                      {/* Message Actions */}
                      {m.role === "assistant" && (
                        <button
                          onClick={() => handleCopyMessage(m.text, idx)}
                          className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 p-1 rounded-lg bg-white/80 dark:bg-slate-700/80 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-opacity"
                          title="Cevabı Kopyala"
                        >
                          {copiedIdx === idx ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </div>

                    {m.timestamp && (
                      <span
                        className={`text-[10px] text-slate-400 px-1 ${
                          m.role === "user" ? "text-right" : "text-left"
                        }`}
                      >
                        {m.timestamp}
                      </span>
                    )}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-3 p-3 rounded-2xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/50 dark:border-teal-900/40 text-teal-700 dark:text-teal-300 text-xs animate-pulse w-fit">
                  <Loader2 className="w-4 h-4 animate-spin text-teal-600 shrink-0" />
                  <span>Notlarınız inceleniyor ve yanıt oluşturuluyor...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestion Chips (when messages are few) */}
            {messages.length <= 2 && !loading && (
              <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 overflow-x-auto">
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-[11px] font-bold text-slate-400 shrink-0 flex items-center gap-1">
                    <Lightbulb className="w-3 h-3 text-amber-500" />
                    Örnek Sorular:
                  </span>
                  {QUICK_SUGGESTIONS.map((sug, i) => (
                    <button
                      key={i}
                      onClick={() => handleSend(sug)}
                      className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-400 hover:text-teal-600 text-[11px] font-medium whitespace-nowrap transition-colors"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Chat input box */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="p-3 sm:p-4 safe-bottom border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-800/80 backdrop-blur-sm flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Notlarınızla ilgili bir soru sorun veya fikir isteyin..."
                className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl px-4 py-3 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-2xs"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="p-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-40 text-white rounded-2xl shadow-md shadow-teal-600/20 transition-all active:scale-95 cursor-pointer"
                title="Gönder"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        )}
      </div>

      {/* Direct Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        currentProfile={profile}
        initialMode={authMode}
        onSuccess={(updatedProfile) => {
          if (onUpdateProfile) {
            onUpdateProfile(updatedProfile);
          }
          setShowAuthModal(false);
        }}
      />
    </div>
  );
};
