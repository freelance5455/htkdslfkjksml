import React, { useState, useEffect, useRef } from 'react';
import { X, Send, Mic, MicOff, Volume2, Sparkles, Bot, User, RefreshCw } from 'lucide-react';
import { sound } from '../utils/sound';

interface AIChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  childName: string;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
}

export const AIChatModal: React.FC<AIChatModalProps> = ({
  isOpen,
  onClose,
  childName,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init',
      sender: 'ai',
      text: `السلام علیکم ${childName} بیٹا! 🧸 میں آپ کا استاد میاں بھالو ہوں۔ آپ مجھ سے الف بے تے، اے بی سی، گنتی یا کوئی بھی مزے دار کہانی پوچھ سکتے ہیں! آج آپ کیا پڑھنا چاہتے ہیں؟`,
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const teacherAvatar = '/src/assets/images/teacher_character_1790357459776.jpg';

  const quickPrompts = [
    `الف سے کیا بنتا ہے؟`,
    `A for Apple سکھائیں`,
    `ایک سے دس تک گنتی سنیں`,
    `${childName} کو پیاری کہانی سنائیں`,
    `${childName} کو شاباش دیں ⭐`,
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query || isLoading) return;

    sound.playPopSound();
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: query,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsLoading(true);

    try {
      const history = messages.slice(-5).map((m) => ({
        role: m.sender === 'user' ? 'user' : 'model',
        text: m.text,
      }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          childName,
          history,
        }),
      });

      const data = await res.json();
      const reply = data.text || `شاباش ${childName} بیٹا! آپ بہت ہونہار بچے ہیں۔`;

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: reply,
      };

      setMessages((prev) => [...prev, aiMsg]);
      sound.playSuccessSound();

      // Automatically speak the response for the child
      handleSpeakMessage(aiMsg.id, reply);
    } catch {
      const fallbackReply = `شاباش ${childName} بیٹا! آپ کا استاد میاں بھالو آپ سے بہت پیار کرتا ہے۔ آئیں مل کر الف بے اور اے بی سی پڑھتے ہیں! 🌟`;
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: fallbackReply,
      };
      setMessages((prev) => [...prev, aiMsg]);
      handleSpeakMessage(aiMsg.id, fallbackReply);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeakMessage = async (msgId: string, text: string) => {
    if (isSpeakingId === msgId) {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsSpeakingId(null);
      return;
    }

    setIsSpeakingId(msgId);
    await sound.speakWithGeminiOrLocal(text, 'ur');
    setIsSpeakingId(null);
  };

  const handleToggleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('آواز سے بولنے کی سہولت آپ کے براؤزر میں سپورٹ نہیں ہے، آپ لکھ کر میسج کر سکتے ہیں۔');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ur-PK';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputVal(transcript);
          handleSendMessage(transcript);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl h-[85vh] flex flex-col overflow-hidden border-4 border-amber-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 p-4 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-md">
              <img
                src={teacherAvatar}
                alt="استاد میاں بھالو"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-urdu text-lg font-bold flex items-center gap-1.5">
                <span>استاد میاں بھالو 🧸</span>
                <span className="text-xs bg-amber-800/40 px-2 py-0.5 rounded-full font-sans">
                  {childName}'s AI Tutor
                </span>
              </h3>
              <p className="text-xs text-amber-100 font-medium">
                ہر وقت {childName} سے محبت اور شفقت سے بات چیت کے لیے تیار!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Quick Taps Tray for the Child */}
        <div className="bg-amber-50/80 px-4 py-2 border-b border-amber-100 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="font-urdu font-bold text-amber-900 shrink-0">جلدی سوال پوچھیں:</span>
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="shrink-0 font-urdu px-3 py-1 bg-white hover:bg-amber-100 text-amber-900 font-semibold rounded-full border border-amber-200 shadow-xs cursor-pointer transition-all active:scale-95"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Messages Feed */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-gradient-to-b from-amber-50/30 to-white">
          {messages.map((msg) => {
            const isAi = msg.sender === 'ai';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 ${isAi ? 'flex-row' : 'flex-row-reverse'}`}
              >
                {/* Sender Avatar */}
                <div
                  className={`w-9 h-9 rounded-full shrink-0 flex items-center justify-center font-bold text-xs shadow-sm overflow-hidden ${
                    isAi
                      ? 'bg-amber-400 text-amber-950 border-2 border-amber-300'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  {isAi ? (
                    <img
                      src={teacherAvatar}
                      alt="میاں بھالو"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{childName.slice(0, 1)}</span>
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[80%] rounded-2xl p-3.5 shadow-sm space-y-1.5 ${
                    isAi
                      ? 'bg-white border-2 border-amber-100 text-slate-800 rounded-tr-xs'
                      : 'bg-blue-600 text-white rounded-tl-xs'
                  }`}
                >
                  <p className="font-urdu text-sm sm:text-base leading-relaxed">
                    {msg.text}
                  </p>

                  {/* Audio Speaker button for AI messages */}
                  {isAi && (
                    <div className="pt-1 flex items-center justify-end">
                      <button
                        onClick={() => handleSpeakMessage(msg.id, msg.text)}
                        className={`text-xs px-2.5 py-1 rounded-full flex items-center gap-1 font-bold cursor-pointer transition-all ${
                          isSpeakingId === msg.id
                            ? 'bg-amber-500 text-white animate-pulse'
                            : 'bg-amber-50 hover:bg-amber-100 text-amber-700'
                        }`}
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{isSpeakingId === msg.id ? 'بول رہے ہیں...' : 'آواز سنیں'}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-amber-700 font-urdu font-bold bg-amber-50 px-4 py-2 rounded-2xl w-fit border border-amber-200 animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-500" />
              <span>استاد میاں بھالو پیارے {childName} کے لیے جواب سوچ رہے ہیں... 🧸</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-amber-100 flex items-center gap-2">
          <button
            onClick={handleToggleVoiceInput}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all cursor-pointer shadow-md ${
              isListening
                ? 'bg-rose-600 text-white animate-bounce'
                : 'bg-amber-100 hover:bg-amber-200 text-amber-800'
            }`}
            title="مائیک سے بولیں"
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={`استاد میاں بھالو سے کچھ پوچھیں (${childName} کے لیے)...`}
            className="flex-1 font-urdu bg-amber-50/60 text-slate-800 px-4 py-2.5 rounded-2xl border-2 border-amber-200 focus:outline-none focus:border-amber-400 text-sm"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!inputVal.trim() || isLoading}
            className="w-11 h-11 rounded-2xl bg-amber-500 hover:bg-amber-600 active:scale-95 disabled:opacity-40 text-white flex items-center justify-center transition-all cursor-pointer shadow-md"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
