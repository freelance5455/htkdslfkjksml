import React from 'react';
import { WhatWeDoSection } from './WhatWeDoSection.tsx';

interface WhatWeDoPageProps {
  onBack: () => void;
}

export const WhatWeDoPage: React.FC<WhatWeDoPageProps> = ({ onBack }) => {
  return <WhatWeDoSection onBack={onBack} isStandalonePage={true} />;
};
