import React, { useState, useEffect } from 'react';
import { Wifi, Signal, Battery, ShieldCheck } from 'lucide-react';

export const StatusBar: React.FC = () => {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const timer = setInterval(updateClock, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full bg-slate-900 text-white px-5 py-1.5 flex items-center justify-between text-xs font-semibold select-none z-50">
      <div className="flex items-center space-x-2">
        <span>{timeStr || '10:16'}</span>
        <span className="text-[10px] text-blue-400 bg-blue-950 px-1.5 py-0.5 rounded-full flex items-center gap-1 font-mono">
          <ShieldCheck className="w-3 h-3 text-emerald-400" /> 5G SECURE
        </span>
      </div>

      <div className="flex items-center space-x-2.5">
        <Signal className="w-3.5 h-3.5" />
        <Wifi className="w-3.5 h-3.5" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-mono">98%</span>
          <Battery className="w-4 h-4 text-emerald-400 fill-emerald-400" />
        </div>
      </div>
    </div>
  );
};
