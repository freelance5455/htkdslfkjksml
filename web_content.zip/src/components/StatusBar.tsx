import { LANG_LABEL, type LangId } from "@/lib/language";
import type { StudioApi, StudioFile } from "@/hooks/useStudio";

interface Props {
  studio: StudioApi;
  activeFile: StudioFile | null;
}

export function StatusBar({ studio, activeFile }: Props) {
  const { settings } = studio;
  const content = activeFile?.content ?? "";
  const lines = content ? content.split("\n").length : 0;
  const chars = content.length;
  const lang = (activeFile?.language as LangId) ?? "text";

  return (
    <div className="flex items-center gap-3 border-t border-slate-200 bg-slate-50 px-3 py-1 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
      <span className="font-semibold text-sky-600 dark:text-sky-400">
        {activeFile ? LANG_LABEL[lang] : "—"}
      </span>
      <span>أسطر: {lines}</span>
      <span>أحرف: {chars}</span>
      <span className="ms-auto flex items-center gap-2">
        {activeFile?.dirty ? (
          <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
            غير محفوظ
          </span>
        ) : (
          <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            محفوظ
          </span>
        )}
        <span>{settings.autoSave ? "حفظ تلقائي" : "حفظ يدوي"}</span>
      </span>
    </div>
  );
}