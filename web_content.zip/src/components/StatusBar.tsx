import React, { useState, useEffect } from 'react';
import { Wifi, Tv, Settings as SettingsIcon, Cable } from 'lucide-react';
import { LauncherSettings } from '../types/launcher';

interface StatusBarProps {
  settings: LauncherSettings;
  focusedActionIndex?: number | null;
  onOpenSettings: () => void;
  onOpenWifi: () => void;
  onOpenInputs: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  settings,
  focusedActionIndex = null,
  onOpenSettings,
  onOpenWifi,
  onOpenInputs,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
      );
      setDateStr(
        now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const inputLabel = {
    hdmi1: 'HDMI 1',
    hdmi2: 'HDMI 2 (eARC)',
    hdmi3: 'HDMI 3',
    tuner: 'TV Tuner',
  }[settings.activeInput];

  return (
    <header className="relative z-30 w-full flex items-center justify-between gap-8 px-6 md:px-12 py-5 select-none">
      {/* Zone 1: Time & Date (Clean, unbranded Apple TV clock) */}
      <div className="flex items-center gap-3 shrink-0">
        <span className="text-white font-bold font-mono text-lg md:text-xl tracking-tight">
          {timeStr}
        </span>
        <span aria-hidden="true" className="text-slate-600">·</span>
        <span className="text-xs md:text-sm text-slate-400 font-medium tracking-wide">
          {dateStr}
        </span>
      </div>

      {/* Zone 2: Empty / Spacing for minimal aesthetic */}
      <div className="hidden md:flex items-center gap-2 text-xs text-slate-500">
        {/* Anti-clutter: intentional clean whitespace */}
      </div>

      {/* Zone 3: Direct TV Settings, Wi-Fi, and Input Controls (Focusable via TV Remote) */}
      <div className="flex items-center gap-2.5 shrink-0">
        {/* Wi-Fi Quick Button */}
        <button
          id="nav-wifi-btn"
          onClick={onOpenWifi}
          title="Wi-Fi & Network Settings"
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer whitespace-nowrap shrink-0 outline-hidden ${
            focusedActionIndex === 0
              ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl scale-105 border-white'
              : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/15'
          }`}
        >
          <Wifi className={`w-3.5 h-3.5 ${focusedActionIndex === 0 ? 'text-slate-950' : 'text-emerald-400'}`} />
          <span className="hidden sm:inline">{settings.connectedWifiSsid}</span>
        </button>

        {/* TV Input Source Switcher */}
        <button
          id="nav-input-btn"
          onClick={onOpenInputs}
          title="TV Input Source Settings"
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer whitespace-nowrap shrink-0 outline-hidden ${
            focusedActionIndex === 1
              ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl scale-105 border-white'
              : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/15'
          }`}
        >
          <Cable className={`w-3.5 h-3.5 ${focusedActionIndex === 1 ? 'text-slate-950' : 'text-sky-400'}`} />
          <span className="hidden sm:inline">{inputLabel}</span>
        </button>

        {/* TV System Settings */}
        <button
          id="nav-settings-btn"
          onClick={onOpenSettings}
          title="TV System Settings"
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer shrink-0 outline-hidden ${
            focusedActionIndex === 2
              ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl scale-105 border-white'
              : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/15'
          }`}
        >
          <SettingsIcon className={`w-4 h-4 ${focusedActionIndex === 2 ? 'text-slate-950' : 'text-slate-300'}`} />
          <span className="hidden sm:inline">TV Settings</span>
        </button>
      </div>
    </header>
  );
};
