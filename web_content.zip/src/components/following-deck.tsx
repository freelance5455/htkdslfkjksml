import { SubscribeButton } from "@/components/subscribe-button";
import { Badge } from "@/components/ui/badge";
import { formatCount } from "@/lib/utils";
import type { SubChannel } from "@/lib/subscriptions";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

export function FollowingDeck({ channels }: { channels: SubChannel[] }) {
  const [index, setIndex] = useState(0);
  const max = channels.length;
  const i = max ? ((index % max) + max) % max : 0;
  const channel = channels[i];
  if (!channel) return null;

  return (
    <div className="flex h-full min-h-0 flex-col px-4 pb-28 pt-4 lg:pb-10">
      <p className="pb-3 text-center text-xs text-muted-foreground">
        {i + 1} / {max} · newest subscriptions first
      </p>
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6">
          <Link
            to="/channel/$channelId"
            params={{ channelId: channel.id }}
            className="flex flex-col items-center text-center"
          >
            {channel.thumbnail ? (
              <img
                src={channel.thumbnail}
                alt=""
                className="size-28 rounded-full object-cover"
              />
            ) : (
              <span className="flex size-28 items-center justify-center rounded-full bg-muted text-3xl font-medium">
                {channel.title.slice(0, 1)}
              </span>
            )}
            <h2 className="mt-4 font-display text-xl font-semibold">{channel.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {channel.handle ? `${channel.handle} · ` : ""}
              {channel.subscriberText || `${formatCount(channel.subscriberCount)} subscribers`}
            </p>
          </Link>
          <div className="mt-3 flex justify-center gap-1.5">
            {channel.hasPostsTab ? <Badge>Community tab</Badge> : <Badge variant="outline">No community tab</Badge>}
            {channel.subscriberCount === 0 ? <Badge variant="outline">0 subscribers</Badge> : null}
          </div>
          <div className="mt-5 flex justify-center">
            <SubscribeButton channel={channel} size="default" />
          </div>
          <Link
            to="/channel/$channelId"
            params={{ channelId: channel.id }}
            className="mt-4 flex h-11 items-center justify-center rounded-xl bg-secondary text-sm font-medium"
          >
            Open community
          </Link>
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 pt-4">
        <button
          type="button"
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-secondary"
          onClick={() => setIndex((n) => n - 1)}
          disabled={max < 2}
        >
          <ChevronLeft className="size-5" />
          Previous
        </button>
        <button
          type="button"
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-secondary"
          onClick={() => setIndex((n) => n + 1)}
          disabled={max < 2}
        >
          Next
          <ChevronRight className="size-5" />
        </button>
      </div>
    </div>
  );
}
