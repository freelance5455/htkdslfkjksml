import React, { useRef, useState } from 'react';
import { X, Download, Upload, Check, AlertCircle, Database, RotateCcw } from 'lucide-react';

interface BackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExportData: () => void;
  onImportData: (importedData: any) => boolean;
  onResetData: () => void;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  isOpen,
  onClose,
  onExportData,
  onImportData,
  onResetData
}) => {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const ok = onImportData(parsed);
        if (ok) {
          setImportStatus({ success: true, message: 'Data backup successfully restored!' });
        } else {
          setImportStatus({ success: false, message: 'File format is invalid.' });
        }
      } catch (err) {
        setImportStatus({ success: false, message: 'Could not read JSON backup file.' });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 rounded-lg text-stone-800">
              <Database className="w-5 h-5 text-stone-800" />
            </div>
            <div>
              <h2 className="font-serif text-2xl font-semibold text-stone-900">
                Local Data & Backup Center
              </h2>
              <p className="text-xs text-stone-500">
                Manage all your stored orders, wishlist, cart, and customized room checklists.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="mt-6 space-y-6 text-xs text-stone-600 leading-relaxed">
          <p>
            Bait ul Ukasha is engineered with an <strong>Offline-First & Local Storage</strong> architecture. All your shopping activity is kept private on this device with zero external cloud subscriptions or trackers.
          </p>

          {/* Export Box */}
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between gap-4">
            <div>
              <h4 className="font-semibold text-stone-900 text-sm">Export Data Backup (.JSON)</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">
                Save an offline snapshot of your orders, delivery address, wishlist, and checklists.
              </p>
            </div>
            <button
              onClick={onExportData}
              className="px-4 py-2 bg-stone-900 text-white rounded-lg font-medium hover:bg-stone-800 flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export JSON</span>
            </button>
          </div>

          {/* Import Box */}
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between gap-4">
            <div>
              <h4 className="font-semibold text-stone-900 text-sm">Restore from Backup (.JSON)</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">
                Load a previously saved backup file to restore your orders and wishlist.
              </p>
            </div>
            <div>
              <input
                type="file"
                ref={fileInputRef}
                accept=".json"
                onChange={handleFileChange}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-white border border-stone-300 text-stone-800 rounded-lg font-medium hover:bg-stone-100 flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Choose File</span>
              </button>
            </div>
          </div>

          {importStatus && (
            <div
              className={`p-3 rounded-lg flex items-center gap-2 text-xs font-medium ${
                importStatus.success
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              {importStatus.success ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{importStatus.message}</span>
            </div>
          )}

          {/* Reset Box */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
            <span className="text-stone-500">Need a fresh start?</span>
            <button
              onClick={() => {
                if (window.confirm('Reset local storage to initial demo state? This will clear your current cart and order history.')) {
                  onResetData();
                  onClose();
                }
              }}
              className="text-stone-500 hover:text-rose-700 flex items-center gap-1.5 cursor-pointer underline decoration-stone-300"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Default State</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
