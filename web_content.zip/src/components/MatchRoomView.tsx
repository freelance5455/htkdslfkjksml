import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PlayerRosterItem } from '../types/index.ts';

export const MatchRoomView: React.FC = () => {
  const { ign, uid, chatMessages, sendChatMessage, showToast } = useApp();

  // Countdown timer
  const [secondsLeft, setSecondsLeft] = useState(12 * 60 + 41);
  const [isPasswordVisible, setIsPasswordVisible] = useState(true);
  const [searchRoster, setSearchRoster] = useState('');
  const [chatInputText, setChatInputText] = useState('');
  const [uploadedScreenshot, setUploadedScreenshot] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`${label} Copied!`);
  };

  const rosterData: PlayerRosterItem[] = [
    { slot: '#24', ign: ign, uid: uid, isUser: true, bounty: '₹20 BOUNTY', kd: '4.8', status: 'READY' },
    { slot: '#01', ign: 'SHADOW_RAZOR', uid: '10293481', bounty: '₹20 BOUNTY', kd: '3.9', status: 'READY' },
    { slot: '#02', ign: 'VIPER_OP', uid: '99482711', bounty: '₹20 BOUNTY', kd: '5.1', status: 'READY' },
    { slot: '#03', ign: 'GHOST_KILLER', uid: '44820199', bounty: '₹20 BOUNTY', kd: '2.7', status: 'READY' },
    { slot: '#04', ign: 'NIGHT_STALKER', uid: '39485122', bounty: '₹20 BOUNTY', kd: '3.4', status: 'WAITING' },
    { slot: '#05', ign: 'BLAZE_FIRE', uid: '77482910', bounty: '₹20 BOUNTY', kd: '4.2', status: 'READY' },
    { slot: '#06', ign: 'THUNDER_CLASH', uid: '61928472', bounty: '₹20 BOUNTY', kd: '3.1', status: 'READY' },
    { slot: '#07', ign: 'SNIPER_PRO_99', uid: '55910283', bounty: '₹20 BOUNTY', kd: '4.5', status: 'READY' },
    { slot: '#08', ign: 'IMMORTAL_KING', uid: '32198402', bounty: '₹20 BOUNTY', kd: '2.9', status: 'WAITING' },
  ];

  const filteredRoster = rosterData.filter(
    (p) =>
      p.ign.toLowerCase().includes(searchRoster.toLowerCase()) ||
      p.uid.toLowerCase().includes(searchRoster.toLowerCase()) ||
      p.slot.toLowerCase().includes(searchRoster.toLowerCase())
  );

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInputText.trim()) return;
    sendChatMessage(chatInputText.trim());
    setChatInputText('');
  };

  const handleScreenshotSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedScreenshot(e.target.files[0].name);
      showToast(`Screenshot uploaded: ${e.target.files[0].name}`);
    }
  };

  const handleSubmitScore = () => {
    if (!uploadedScreenshot) {
      showToast('Please attach your post-match scoreboard screenshot first.', 'info');
      return;
    }
    showToast('Scorecard submitted! Automated OCR Audit in progress. Bounty will credit in ~5 mins.');
  };

  return (
    <div className="flex flex-col w-full">
      {/* Live Match Telemetry Status Bar */}
      <div className="w-full bg-[#0b0e14] px-4 sm:px-6 lg:px-10 py-3 shadow-md">
        <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5 bg-[#ff5e00]/20 px-3 py-1 rounded">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff5e00] animate-ping"></span>
              <span className="font-label-sm text-label-sm text-[#ffdbce] uppercase tracking-widest font-bold">
                LIVE LOBBY STAGING
              </span>
            </div>
            <div className="h-4 w-[1px] bg-surface-variant hidden sm:block"></div>
            <span className="font-label-md text-label-md uppercase text-on-surface-variant tracking-wider font-semibold">
              ROOM PROTOCOL: <span className="text-[#00dbe9]">#BR-BERMUDA-1042</span>
            </span>
          </div>

          <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#00dbe9] text-base">wifi_tethering</span>
              <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                REGION: <strong className="text-on-surface">IND-MUMBAI-01</strong>
              </span>
            </div>
            <div className="flex items-center gap-2 bg-[#272a31] px-3.5 py-1 rounded">
              <span className="material-symbols-outlined text-secondary text-base">timer</span>
              <span className="font-label-sm text-label-sm uppercase text-secondary font-bold">STARTS IN:</span>
              <span className="font-headline-sm text-headline-sm text-[#ff5e00] font-bold tracking-widest">
                {formatTimer(secondsLeft)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Stage Hero Header */}
      <div className="w-full px-4 sm:px-6 lg:px-10 py-8 bg-[#191c22] shadow-sm relative overflow-hidden">
        <div className="absolute -right-24 -top-24 w-96 h-96 bg-primary-container/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute left-1/3 -bottom-32 w-80 h-80 bg-tertiary-container/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-[1440px] mx-auto flex flex-col lg:flex-row lg:items-end justify-between gap-6 relative z-10">
          <div className="flex flex-col gap-1 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-[#32353c] font-label-sm text-label-sm uppercase text-[#00dbe9] rounded tracking-widest font-bold">
                TIER 1 SCRIM
              </span>
              <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                UID RESTRICTION: LEVEL 40+ ONLY
              </span>
            </div>
            <h1 className="font-display-xl text-3xl sm:text-5xl uppercase tracking-tight text-on-surface font-bold">
              Match Lobby: Solo Battle Royale #1042
            </h1>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Secure competitive room credentials verified by Garena Tournament API. Ensure you join lobby slot #24 according to your verified seed before deployment timer expires.
            </p>
          </div>

          {/* Quick Telemetry Stats Widget */}
          <div className="grid grid-cols-3 gap-2 bg-[#0b0e14] p-4 rounded shadow-lg min-w-[320px]">
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
                ENTRY POOL
              </span>
              <span className="font-headline-sm text-headline-sm text-secondary font-bold">₹30</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Coins Paid</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
                KILL BOUNTY
              </span>
              <span className="font-headline-sm text-headline-sm text-[#ff5e00] font-bold">
                ₹20<span className="text-xs text-on-surface-variant font-normal">/kill</span>
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Instant Claim</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
                MAP ARENA
              </span>
              <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">BERMUDA</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Solo Classic</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Content Area */}
      <div className="w-full px-4 sm:px-6 lg:px-10 py-8">
        <div className="max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* LEFT COLUMN: Credentials & Tutorial & Screenshot (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            {/* Room Credentials HUD Card */}
            <div className="bg-surface-container rounded-lg p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-container via-secondary to-tertiary"></div>
              <div className="flex items-center justify-between pb-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ff5e00]">lock_open</span>
                  <div className="flex flex-col">
                    <span className="font-headline-sm text-headline-sm uppercase tracking-wide text-on-surface font-bold">
                      CUSTOM ROOM ACCESS CODE
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-[#00dbe9] font-semibold">
                      STATUS: VERIFIED &amp; ACCESSIBLE
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 px-3 py-1 rounded bg-surface-container-high">
                  <span className="material-symbols-outlined text-sm text-[#00dbe9]">speed</span>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] font-bold">PING: 24MS</span>
                </div>
              </div>

              {/* Credentials Display Units */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {/* Room ID Box */}
                <div className="bg-[#0b0e14] p-4 rounded flex flex-col justify-between gap-2">
                  <div className="flex items-center justify-between">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                      ROOM ID
                    </span>
                    <span className="font-label-sm text-label-sm text-[#00dbe9] bg-surface-container px-2 py-0.5 rounded font-bold">
                      NUMERIC ID
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-headline-lg text-2xl sm:text-3xl font-bold tracking-wider text-on-surface">
                      8943 2091
                    </span>
                    <button
                      onClick={() => copyToClipboard('89432091', 'Room ID')}
                      className="p-2 bg-surface-container-high hover:bg-[#ff5e00] hover:text-[#531900] text-on-surface rounded transition-colors cursor-pointer"
                      title="Copy Room ID"
                    >
                      <span className="material-symbols-outlined text-xl">content_copy</span>
                    </button>
                  </div>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Click copy to paste into Free Fire custom match finder.
                  </span>
                </div>

                {/* Password Box */}
                <div className="bg-[#0b0e14] p-4 rounded flex flex-col justify-between gap-2">
                  <div className="flex items-center justify-between">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                      ROOM PASSWORD
                    </span>
                    <span className="font-label-sm text-label-sm text-secondary bg-surface-container px-2 py-0.5 rounded font-bold">
                      CASE SENSITIVE
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <span className="font-headline-lg text-xl sm:text-2xl font-bold tracking-wider text-on-surface">
                        {isPasswordVisible ? 'FF_IGNITE_99' : '•••••••••••••'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                        className="p-2 bg-surface-container-high hover:bg-surface-variant text-on-surface rounded transition-colors cursor-pointer"
                        title="Toggle Visibility"
                      >
                        <span className="material-symbols-outlined text-xl">
                          {isPasswordVisible ? 'visibility' : 'visibility_off'}
                        </span>
                      </button>
                      <button
                        onClick={() => copyToClipboard('FF_IGNITE_99', 'Password')}
                        className="p-2 bg-surface-container-high hover:bg-[#ff5e00] hover:text-[#531900] text-on-surface rounded transition-colors cursor-pointer"
                        title="Copy Password"
                      >
                        <span className="material-symbols-outlined text-xl">content_copy</span>
                      </button>
                    </div>
                  </div>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Strictly confidential. Unauthorized distribution leads to ban.
                  </span>
                </div>
              </div>

              {/* Slot Allocation Ribbon */}
              <div className="mt-4 p-4 bg-surface-container-high rounded flex items-start gap-3">
                <span className="material-symbols-outlined text-secondary text-xl mt-0.5">warning</span>
                <div className="flex flex-col">
                  <span className="font-label-md text-label-md text-secondary uppercase font-bold">
                    YOUR ALLOCATED LOBBY SLOT: #24
                  </span>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Do NOT jump to another slot or sit in spectator seats. Match starts promptly at zero count. Players in incorrect slots will be kicked by the automated room bot.
                  </p>
                </div>
              </div>
            </div>

            {/* In-Game Joining Directive */}
            <div className="bg-surface-container rounded-lg p-6 shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00dbe9]">how_to_reg</span>
                  <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                    IN-GAME JOINING DIRECTIVE
                  </span>
                </div>
                <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                  MANDATORY PROTOCOL
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#0b0e14] p-4 rounded flex gap-3 items-start hover:bg-surface-container-low transition-colors">
                  <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-primary font-bold shrink-0">
                    01
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                      LAUNCH GARENA FREE FIRE
                    </span>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                      Open the Free Fire mobile app and ensure you are logged into the registered account linked with your UID.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0b0e14] p-4 rounded flex gap-3 items-start hover:bg-surface-container-low transition-colors">
                  <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-primary font-bold shrink-0">
                    02
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                      LOCATE CUSTOM MATCHMAKING
                    </span>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                      Tap the game mode selector located at bottom-right, navigate to <strong>Custom</strong>, and select <strong>Join Room</strong>.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0b0e14] p-4 rounded flex gap-3 items-start hover:bg-surface-container-low transition-colors">
                  <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-primary font-bold shrink-0">
                    03
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                      ENTER ROOM ID &amp; PASS
                    </span>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                      Paste numeric ID <strong>89432091</strong>, search, press Join and type password <strong>FF_IGNITE_99</strong>.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0b0e14] p-4 rounded flex gap-3 items-start hover:bg-surface-container-low transition-colors">
                  <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-[#ff5e00] font-bold shrink-0">
                    04
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md uppercase text-secondary font-bold">
                      OCCUPY ASSIGNED SLOT #24
                    </span>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                      Directly move your avatar to <strong>Slot #24</strong>. Stay prepared for automatic deployment!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Post-Match Claim & Result Submission */}
            <div className="bg-surface-container rounded-lg p-6 shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">military_tech</span>
                  <div className="flex flex-col">
                    <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                      POST-MATCH CLAIM &amp; RESULT SUBMISSION
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-[#00dbe9] font-semibold">
                      AUTOMATED OCR BOUNTY ENGINE
                    </span>
                  </div>
                </div>
                <span className="px-2.5 py-1 bg-surface-container-highest font-label-sm text-label-sm text-on-surface uppercase rounded font-bold">
                  WINDOW: 15 MINS
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                After match conclusion, capture a full-screen screenshot of your final elimination scoreboard displaying total kills, damage, and placement for automated validation.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 items-center">
                {/* Upload Trigger Area */}
                <label className="w-full sm:w-1/2 bg-[#0b0e14] p-6 rounded flex flex-col items-center justify-center text-center cursor-pointer hover:bg-surface-container-high transition-colors group border border-dashed border-surface-variant">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleScreenshotSelect}
                  />
                  <span className="material-symbols-outlined text-3xl text-on-surface-variant group-hover:text-primary-container transition-colors mb-1">
                    {uploadedScreenshot ? 'check_circle' : 'cloud_upload'}
                  </span>
                  <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                    {uploadedScreenshot ? 'SCREENSHOT READY' : 'UPLOAD END-GAME SCREENSHOT'}
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                    {uploadedScreenshot ? uploadedScreenshot : 'PNG, JPG up to 10MB'}
                  </span>
                </label>

                {/* Telemetry Checkpoints */}
                <div className="w-full sm:w-1/2 bg-[#0b0e14] p-4 rounded flex flex-col gap-2">
                  <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
                    TELEMETRY CHECKPOINTS
                  </span>
                  <div className="flex items-center justify-between text-body-sm font-body-sm">
                    <span className="text-on-surface-variant">Kill Count OCR:</span>
                    <span className="text-[#00dbe9] font-bold">Awaiting Match End</span>
                  </div>
                  <div className="flex items-center justify-between text-body-sm font-body-sm">
                    <span className="text-on-surface-variant">Booyah Multiplier:</span>
                    <span className="text-secondary font-bold">2.5x Priority</span>
                  </div>
                  <div className="flex items-center justify-between text-body-sm font-body-sm">
                    <span className="text-on-surface-variant">Direct Wallet Credit:</span>
                    <span className="text-primary font-bold">Enabled</span>
                  </div>
                  <button
                    onClick={handleSubmitScore}
                    className="mt-2 w-full py-2 bg-surface-container-highest hover:bg-surface-variant text-on-surface font-label-md text-label-md uppercase rounded transition-colors text-center font-bold cursor-pointer"
                  >
                    Submit For Arbiter Review
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Roster Table & Emergency Arbiter (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Registered Players Table */}
            <div className="bg-surface-container rounded-lg p-4 shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary-container">groups</span>
                  <div className="flex flex-col">
                    <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                      LOBBY ROSTER
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                      CAPACITY: 48 / 48 (FULL)
                    </span>
                  </div>
                </div>
                <span className="font-label-sm text-label-sm uppercase bg-primary-container/20 text-primary-fixed px-3 py-1 rounded font-bold">
                  LOCKED
                </span>
              </div>

              {/* Search Filter */}
              <div className="relative w-full">
                <span className="material-symbols-outlined absolute left-3 top-2.5 text-on-surface-variant text-base">
                  search
                </span>
                <input
                  type="text"
                  value={searchRoster}
                  onChange={(e) => setSearchRoster(e.target.value)}
                  placeholder="FILTER BY IGN OR UID..."
                  className="w-full bg-[#0b0e14] text-on-surface placeholder:text-on-surface-variant font-label-sm text-label-sm uppercase pl-9 pr-4 py-2 rounded outline-none"
                />
              </div>

              {/* Roster List */}
              <div className="flex flex-col gap-1.5 max-h-[460px] overflow-y-auto pr-1">
                {filteredRoster.map((player) => {
                  return (
                    <div
                      key={player.slot + player.uid}
                      className={`p-3 rounded flex items-center justify-between transition-colors shadow-sm ${
                        player.isUser
                          ? 'bg-primary-container/15 hover:bg-primary-container/20 border border-primary-container/30'
                          : 'bg-[#0b0e14] hover:bg-[#191c22]'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-7 h-7 rounded flex items-center justify-center font-label-md text-label-md font-bold shrink-0 ${
                            player.isUser ? 'bg-[#ff5e00] text-[#531900]' : 'bg-surface-container-high text-on-surface'
                          }`}
                        >
                          {player.slot}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`font-label-md text-label-md uppercase font-bold truncate ${
                                player.isUser ? 'text-primary' : 'text-on-surface'
                              }`}
                            >
                              {player.ign}
                            </span>
                            {player.isUser && (
                              <span className="px-1.5 py-0.2 bg-[#ff5e00] text-[#531900] text-[10px] rounded uppercase font-bold tracking-wider">
                                YOU
                              </span>
                            )}
                          </div>
                          <span className="font-body-sm text-body-sm text-on-surface-variant truncate">
                            UID: {player.uid}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 shrink-0">
                        <div className="flex flex-col text-right">
                          <span className="font-label-sm text-label-sm text-[#00dbe9]">{player.bounty}</span>
                          <span className="font-body-sm text-body-sm text-secondary font-bold">
                            KD: {player.kd}
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 text-xs rounded uppercase font-semibold ${
                            player.status === 'READY'
                              ? 'bg-surface-container-highest text-[#00dbe9]'
                              : 'bg-surface-container-highest text-secondary'
                          }`}
                        >
                          {player.status}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Emergency Match Arbiter */}
            <div className="bg-surface-container rounded-lg p-4 shadow-md flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">headset_mic</span>
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                      EMERGENCY MATCH ARBITER
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-[#00dbe9]">
                      AVERAGE RESPONSE: &lt; 45 SECS
                    </span>
                  </div>
                </div>
                <div className="w-2.5 h-2.5 rounded-full bg-[#00dbe9] animate-pulse"></div>
              </div>

              {/* Chat Stream Box */}
              <div className="h-44 bg-[#0b0e14] p-3 rounded overflow-y-auto flex flex-col gap-2 text-body-sm font-body-sm">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`p-2 rounded max-w-[85%] ${
                      msg.isUser
                        ? 'bg-primary-container/20 text-on-surface self-end'
                        : 'bg-surface-container text-on-surface-variant self-start'
                    }`}
                  >
                    <span
                      className={`font-bold text-xs uppercase block ${
                        msg.isUser
                          ? 'text-primary'
                          : msg.role === 'System'
                          ? 'text-secondary'
                          : 'text-[#00dbe9]'
                      }`}
                    >
                      {msg.sender}
                    </span>
                    <span>{msg.text}</span>
                  </div>
                ))}
              </div>

              {/* Input bar */}
              <form onSubmit={handleChatSubmit} className="flex gap-1.5">
                <input
                  type="text"
                  value={chatInputText}
                  onChange={(e) => setChatInputText(e.target.value)}
                  placeholder="Dispute a slot thief or ask arbiter..."
                  className="flex-1 bg-[#0b0e14] px-3 py-2 rounded text-body-sm text-on-surface placeholder:text-on-surface-variant outline-none"
                />
                <button
                  type="submit"
                  className="px-4 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-md text-label-md uppercase rounded transition-colors flex items-center justify-center font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base">send</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
