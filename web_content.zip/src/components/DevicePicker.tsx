import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { CATALOG, searchCatalog } from "@/lib/hardware/devices";
import { TIER_LABEL, classifySoc } from "@/lib/hardware/soc";
import { useCaliber } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function DevicePicker({ featured }: { featured?: boolean }) {
  const { dict, lang, pickDevice, pickerOpen, setPickerOpen } = useCaliber();
  const [q, setQ] = useState("");
  const list = useMemo(() => (featured && !q ? CATALOG.slice(0, 6) : searchCatalog(q)), [q, featured]);

  if (featured) {
    return (
      <div>
        <p className="mb-3 text-xs uppercase tracking-[0.16em] text-subtle">{dict.featured}</p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {CATALOG.filter((d) =>
            ["samsung-a55", "poco-x6-pro", "redmi-13c", "samsung-s24", "infinix-hot-40", "poco-f6"].includes(d.id),
          ).map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => pickDevice(d)}
              className="rounded-lg bg-surface p-3 text-start shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
            >
              <div className="text-[10px] uppercase tracking-wider text-subtle">{d.brand}</div>
              <div className="font-display text-sm font-semibold leading-tight">{d.name}</div>
              <div className="mt-1 truncate text-[11px] text-muted">{d.soc}</div>
            </button>
          ))}
        </div>
        <Button variant="ghost" className="mt-2 w-full" onClick={() => setPickerOpen(true)}>
          {dict.pickPhone}
        </Button>
        {pickerOpen ? <PickerModal q={q} setQ={setQ} list={list} /> : null}
      </div>
    );
  }

  return (
    <>
      <Button variant="secondary" onClick={() => setPickerOpen(true)}>
        {dict.pickPhone}
      </Button>
      {pickerOpen ? <PickerModal q={q} setQ={setQ} list={list} /> : null}
    </>
  );
}

function PickerModal({
  q,
  setQ,
  list,
}: {
  q: string;
  setQ: (v: string) => void;
  list: ReturnType<typeof searchCatalog>;
}) {
  const { dict, lang, pickDevice, setPickerOpen } = useCaliber();
  return (
    <div className="fixed inset-0 z-50 grid place-items-end sm:place-items-center">
      <button
        type="button"
        className="absolute inset-0 bg-bg/70"
        aria-label="Close"
        onClick={() => setPickerOpen(false)}
      />
      <div className="relative z-10 flex max-h-[82dvh] w-full max-w-lg flex-col rounded-t-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:rounded-2xl sm:p-5">
        <div className="relative mb-3">
          <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={dict.searchPhone}
            className="h-11 w-full rounded-md bg-bg ps-10 pe-3 text-sm text-fg placeholder:text-subtle shadow-[var(--shadow-border)] focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="min-h-0 flex-1 space-y-1 overflow-y-auto">
          {list.map((d) => {
            const tier = classifySoc(d.soc).tier;
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => pickDevice(d)}
                className={cn(
                  "flex w-full items-center justify-between gap-3 rounded-md px-3 py-2.5 text-start hover:bg-bg",
                )}
              >
                <span>
                  <span className="block font-display text-sm font-semibold">
                    {d.brand} {d.name}
                  </span>
                  <span className="block text-[11px] text-muted">
                    {d.soc} · {d.typicalRamGb} GB · {Math.max(...d.refreshRates)} Hz
                  </span>
                </span>
                <span className="shrink-0 text-[10px] uppercase tracking-wider text-primary">
                  {TIER_LABEL[tier][lang]}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
