import { useState, type FormEvent } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useVault } from "@/lib/vault-store";

export function SettingsPanel() {
  const setSettingsOpen = useVault((s) => s.setSettingsOpen);
  const changePassword = useVault((s) => s.changePassword);
  const resetVault = useVault((s) => s.resetVault);
  const lock = useVault((s) => s.lock);

  const [oldPw, setOldPw] = useState("");
  const [nextPw, setNextPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [wipe, setWipe] = useState(false);

  async function onChange(e: FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    if (nextPw.trim().length < 4) {
      setError("Новый пароль — не короче четырёх знаков.");
      return;
    }
    if (nextPw !== confirm) {
      setError("Новые пароли не совпадают.");
      return;
    }
    setBusy(true);
    const ok = await changePassword(oldPw, nextPw.trim());
    setBusy(false);
    if (!ok) {
      setError("Старый пароль неверный.");
      return;
    }
    setOldPw("");
    setNextPw("");
    setConfirm("");
    setMessage("Пароль заменён.");
  }

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="Закрыть"
        className="absolute inset-0 bg-ink/70"
        onClick={() => setSettingsOpen(false)}
      />
      <div className="relative w-full max-w-md overflow-y-auto rounded-t-3xl bg-ink-2 p-5 shadow-lift sm:rounded-3xl sm:p-7">
        <div className="mb-6 flex items-start justify-between">
          <h2 className="font-display text-2xl tracking-tight">Замок</h2>
          <Button variant="ghost" size="icon-sm" aria-label="Закрыть" onClick={() => setSettingsOpen(false)}>
            <X className="size-4" />
          </Button>
        </div>

        <form onSubmit={onChange} className="space-y-3">
          <p className="font-reading text-sm text-muted">Сменить пароль</p>
          <div className="space-y-1.5">
            <Label htmlFor="old-pw">Сейчас</Label>
            <Input
              id="old-pw"
              type="password"
              autoComplete="current-password"
              value={oldPw}
              onChange={(e) => setOldPw(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-pw">Новый</Label>
            <Input
              id="new-pw"
              type="password"
              autoComplete="new-password"
              value={nextPw}
              onChange={(e) => setNextPw(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-pw-2">Ещё раз</Label>
            <Input
              id="new-pw-2"
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>
          {error && (
            <p className="text-sm text-danger" role="alert">
              {error}
            </p>
          )}
          {message && <p className="text-sm text-sage">{message}</p>}
          <Button type="submit" variant="sage" className="w-full" disabled={busy}>
            Сменить пароль
          </Button>
        </form>

        <div className="mt-8 border-t border-cream/10 pt-6">
          {!wipe ? (
            <button
              type="button"
              onClick={() => setWipe(true)}
              className="text-sm text-faint underline-offset-4 hover:text-danger hover:underline"
            >
              Стереть сейф
            </button>
          ) : (
            <div className="space-y-3">
              <p className="font-reading text-sm leading-relaxed text-cream-2">
                Пароль, свои тексты и закладки будут удалены с этого устройства.
              </p>
              <div className="flex gap-2">
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => {
                    resetVault();
                    lock();
                  }}
                >
                  Стереть
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setWipe(false)}>
                  Отмена
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
