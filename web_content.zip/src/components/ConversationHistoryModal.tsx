import React, { useState } from 'react';
import { ChatMessage, UserProfile } from '../types';
import { speechManager } from '../utils/speechUtils';
import { playClickTone, playReplyTone } from '../utils/audioEffects';
import {
  X,
  Volume2,
  Trash2,
  Search,
  Download,
  Copy,
  Check,
  MessageSquare,
  Bot,
  User,
  Clock,
} from 'lucide-react';

interface ConversationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onClearHistory: () => void;
  onDeleteMessage: (id: string) => void;
  profile: UserProfile;
}

export const ConversationHistoryModal: React.FC<ConversationHistoryModalProps> = ({
  isOpen,
  onClose,
  messages,
  onClearHistory,
  onDeleteMessage,
  profile,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredMessages = messages.filter((m) =>
    m.text.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCopy = (id: string, text: string) => {
    playClickTone();
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const modalAudioRef = React.useRef<HTMLAudioElement | null>(null);

  const handlePlayVoice = async (id: string, text: string, role: 'user' | 'model') => {
    playReplyTone();
    setPlayingId(id);

    if (modalAudioRef.current) {
      try {
        modalAudioRef.current.pause();
      } catch (e) {}
      modalAudioRef.current = null;
    }

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          botGender: role === 'model' ? profile.gender : 'Male',
          language: profile.language || 'Urdu',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
          modalAudioRef.current = audio;
          audio.playbackRate = profile.speechRate || 1.0;
          audio.onended = () => {
            setPlayingId(null);
            modalAudioRef.current = null;
          };
          audio.onerror = () => {
            fallbackModalTTS(text, role);
          };
          await audio.play();
          return;
        }
      }
    } catch (err) {
      console.warn('Modal TTS fetch failed, using fallback:', err);
    }

    fallbackModalTTS(text, role);
  };

  const fallbackModalTTS = (text: string, role: 'user' | 'model') => {
    speechManager.speak(text, {
      gender: role === 'model' ? profile.gender : 'Male',
      language: profile.language || 'Urdu',
      rate: profile.speechRate,
      pitch: profile.speechPitch,
      onEnd: () => setPlayingId(null),
      onError: () => setPlayingId(null),
    });
  };

  const handleExportJSON = () => {
    playClickTone();
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(messages, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `AB_Voice_Bot_History_${new Date().toISOString().slice(0, 10)}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const formatTime = (ts: number) => {
    const date = new Date(ts);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (ts: number) => {
    const date = new Date(ts);
    return date.toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0c1830] border border-[#1e3258] rounded-2xl shadow-2xl flex flex-col max-h-[88vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#1e3258] bg-[#081225]/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#E2C067]/15 border border-[#E2C067]/30 flex items-center justify-center text-[#E2C067]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#E2C067] flex items-center gap-2">
                <span>گفتگو کی تاریخ</span>
                <span className="text-xs font-normal text-gray-400">
                  (Conversation History)
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                {messages.length} messages saved in memory
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playClickTone();
              onClose();
            }}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Actions */}
        <div className="p-3 border-b border-[#1e3258] bg-[#09152b] flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="پیغام تلاش کریں (Search messages)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
            />
          </div>

          <button
            onClick={handleExportJSON}
            disabled={messages.length === 0}
            title="Export History JSON"
            className="p-2 text-xs font-semibold rounded-xl bg-[#112244] border border-[#2a4365] text-[#E2C067] hover:bg-[#162d5a] disabled:opacity-40 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              if (window.confirm('کیا آپ تمام پچھلی گفتگو مٹانا چاہتے ہیں؟ (Clear all history?)')) {
                playClickTone();
                onClearHistory();
              }
            }}
            disabled={messages.length === 0}
            title="Clear All History"
            className="p-2 text-xs font-semibold rounded-xl bg-red-900/30 border border-red-500/30 text-red-300 hover:bg-red-900/50 disabled:opacity-40 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {filteredMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-gray-400">
              <MessageSquare className="w-12 h-12 text-gray-600 mb-3 stroke-[1.5]" />
              <p className="text-sm font-semibold text-gray-300">
                {searchQuery
                  ? 'کوئی پیغام نہیں ملا (No matching messages)'
                  : 'ابھی تک کوئی گفتگو محفوظ نہیں ہے'}
              </p>
              <p className="text-xs text-gray-500 mt-1 max-w-xs">
                {searchQuery
                  ? 'مختلف الفاظ سے دوبارہ تلاش کریں۔'
                  : 'جب آپ مائیک یا ٹیکسٹ کے ذریعے بات کریں گے تو پیغامات یہاں نظر آئیں گے۔'}
              </p>
            </div>
          ) : (
            filteredMessages.map((msg, index) => {
              const isBot = msg.role === 'model';
              const isPlaying = playingId === msg.id;
              const isCopied = copiedId === msg.id;

              return (
                <div
                  key={msg.id || index}
                  className={`flex flex-col ${
                    isBot ? 'items-start' : 'items-end'
                  } group`}
                >
                  {/* Sender Header */}
                  <div className="flex items-center gap-1.5 mb-1 text-[11px] text-gray-400 px-1">
                    {isBot ? (
                      <>
                        <Bot className="w-3.5 h-3.5 text-[#E2C067]" />
                        <span className="font-semibold text-[#E2C067]">
                          {profile.gender === 'Female' ? 'عائشہ (Ayesha)' : 'حمزہ (Hamza)'}
                        </span>
                      </>
                    ) : (
                      <>
                        <span className="font-semibold text-cyan-400">
                          {profile.name || 'آپ (You)'}
                        </span>
                        <User className="w-3.5 h-3.5 text-cyan-400" />
                      </>
                    )}
                    <span className="text-[10px] text-gray-500 flex items-center gap-0.5 ml-1">
                      <Clock className="w-2.5 h-2.5" />
                      {formatTime(msg.timestamp)}
                    </span>
                  </div>

                  {/* Message Bubble */}
                  <div
                    className={`relative max-w-[85%] rounded-2xl p-3.5 text-sm transition-all shadow-md ${
                      isBot
                        ? 'bg-[#111e38] border border-[#1e3258] text-white rounded-tl-sm'
                        : 'bg-gradient-to-r from-[#19325c] to-[#122240] border border-[#2a4d7d] text-cyan-50 rounded-tr-sm'
                    }`}
                  >
                    <p className="font-urdu leading-relaxed whitespace-pre-wrap text-[15px]">
                      {msg.text}
                    </p>

                    {/* Bottom controls inside message */}
                    <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between gap-3 text-xs text-gray-400">
                      <span className="text-[10px] text-gray-400">
                        {formatDate(msg.timestamp)}
                      </span>

                      <div className="flex items-center gap-2">
                        {/* Play voice button */}
                        <button
                          onClick={() => handlePlayVoice(msg.id, msg.text, msg.role)}
                          title="Play aloud"
                          className={`p-1 rounded-md transition-colors ${
                            isPlaying
                              ? 'text-[#E2C067] bg-[#E2C067]/20'
                              : 'hover:text-[#E2C067] hover:bg-white/5 text-gray-400'
                          }`}
                        >
                          <Volume2 className={`w-3.5 h-3.5 ${isPlaying ? 'animate-bounce' : ''}`} />
                        </button>

                        {/* Copy text */}
                        <button
                          onClick={() => handleCopy(msg.id, msg.text)}
                          title="Copy text"
                          className="p-1 rounded-md hover:text-white hover:bg-white/5 text-gray-400 transition-colors"
                        >
                          {isCopied ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>

                        {/* Delete single message */}
                        <button
                          onClick={() => onDeleteMessage(msg.id)}
                          title="Delete message"
                          className="p-1 rounded-md hover:text-red-400 hover:bg-red-500/10 text-gray-400 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081225] border-t border-[#1e3258] flex items-center justify-between text-xs text-gray-400">
          <span>AB Voice Memory Engine</span>
          <button
            onClick={() => {
              playClickTone();
              onClose();
            }}
            className="py-1.5 px-4 rounded-lg bg-[#112244] border border-[#2a4365] text-white hover:bg-[#1a3366] cursor-pointer"
          >
            بند کریں (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
