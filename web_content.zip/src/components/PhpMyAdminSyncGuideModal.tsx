import React, { useState } from 'react';
import { BookOpen, ExternalLink, Copy, Check, Terminal, RefreshCw, X, ShieldCheck } from 'lucide-react';
import { mysqlSyncService } from '../lib/mysqlSyncService';

interface PhpMyAdminSyncGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast: (msg: string) => void;
}

export const PhpMyAdminSyncGuideModal: React.FC<PhpMyAdminSyncGuideModalProps> = ({ isOpen, onClose, showToast }) => {
  const [copiedDelta, setCopiedDelta] = useState<boolean>(false);
  const [phpMyAdminUrl, setPhpMyAdminUrl] = useState<string>('http://localhost/phpmyadmin');

  if (!isOpen) return null;

  const handleCopyDelta = () => {
    const delta = mysqlSyncService.generateIncrementalDeltaSql();
    navigator.clipboard.writeText(delta);
    setCopiedDelta(true);
    showToast('Incremental SQL delta statements copied to clipboard!');
    setTimeout(() => setCopiedDelta(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 bg-slate-950 border-b border-amber-500/20 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-400 border border-amber-500/30">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-amber-100 font-serif">phpMyAdmin Sync Guide & Incremental Delta</h3>
              <p className="text-xs text-slate-400">Step-by-step connection & delta INSERT generator</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
          
          {/* Quick Connect to phpMyAdmin */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3">
            <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center space-x-2">
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>Direct Link to your phpMyAdmin Instance</span>
            </h4>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={phpMyAdminUrl}
                onChange={(e) => setPhpMyAdminUrl(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                placeholder="http://localhost/phpmyadmin"
              />
              <a 
                href={phpMyAdminUrl} 
                target="_blank" 
                rel="noreferrer"
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all shadow-md shrink-0"
              >
                <span>Open phpMyAdmin</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Step-by-Step Instructions */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider">Step-by-Step Synchronization Instructions</h4>
            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <li>Open your <strong className="text-white">phpMyAdmin</strong> dashboard using the link above or your server control panel.</li>
              <li>Select or create a database named <code className="text-amber-300">juhnkrix_musika</code> with collation <code className="text-amber-300">utf8mb4_unicode_ci</code>.</li>
              <li>To perform a full initial migration, click the <strong className="text-white">Import</strong> tab and upload the exported <code className="text-amber-300">.sql</code> file.</li>
              <li>For ongoing updates (prayer entries and custom playlists added since last export), use the <strong className="text-white">Incremental Delta Generator</strong> below to copy recent SQL statements directly into the phpMyAdmin SQL console.</li>
            </ol>
          </div>

          {/* Incremental Delta Generator */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center space-x-2">
                <RefreshCw className="w-4 h-4 text-amber-400" />
                <span>Incremental Delta SQL (Auto-Generated for New Data)</span>
              </h4>
              <button 
                onClick={handleCopyDelta}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow"
              >
                {copiedDelta ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedDelta ? 'Copied!' : 'Copy Delta SQL'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              This helper script auto-generates SQL <code className="text-amber-300">REPLACE INTO</code> statements for any new prayer entries or playlists created since your last export.
            </p>
            <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-[11px] font-mono text-amber-300/90 max-h-36 overflow-y-auto whitespace-pre">
              {mysqlSyncService.generateIncrementalDeltaSql()}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button onClick={onClose} className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all">
            Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
