import { useEffect, useState, type ReactNode } from "react";
import {
  store,
  useStore,
  levelOf,
  luck,
  netWorth,
  stamina,
  restMs,
  clickReward,
  JOBS_PER_REST,
  TAPS_PER_BREAK,
  type PanelId,
} from "../lib/store";
import { CARS, FOODS, HUB_SECTIONS, JOB_LIST, ROUTES } from "../lib/world";
import { toFa } from "../lib/fa";
import { boop, fanfare } from "../lib/sound";
import { Btn, fmt } from "./Hud";
import { CoinIcon } from "./icons";
import { MarsTicket } from "./MarsHud";
import { WheelEntry } from "./WheelHud";

/* ================================================================== */
/*  shell                                                              */
/* ================================================================== */
function useNow(active = true, ms = 500) {
  const [, setN] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setN((v) => v + 1), ms);
    return () => window.clearInterval(id);
  }, [active, ms]);
  return Date.now();
}

function Sheet({
  title,
  emoji,
  back,
  children,
}: {
  title: string;
  emoji: string;
  back: PanelId;
  children: ReactNode;
}) {
  const points = useStore((s) => s.points);
  return (
    <div className="pointer-events-auto fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <div
        className="fade-in absolute inset-0 bg-amber-950/70"
        onClick={() => store.openPanel(null)}
      />
      <div
        className="sheet panel relative flex w-full flex-col overflow-hidden rounded-t-3xl sm:m-4 sm:max-w-lg sm:rounded-3xl"
        style={{ maxHeight: "min(88dvh, 780px)" }}
      >
        <div className="flex shrink-0 items-center gap-2 border-b border-white/10 bg-white/[0.06] px-3 py-2.5">
          <button
            type="button"
            aria-label="بازگشت"
            onClick={() => {
              store.openPanel(back);
              boop();
            }}
            className="grid size-8 shrink-0 place-items-center rounded-xl bg-white/12 text-violet-100 ring-1 ring-white/15 transition hover:bg-white/20"
          >
            <svg viewBox="0 0 24 24" fill="none" className="size-4">
              <path
                d="M9.5 5.5l6.5 6.5-6.5 6.5"
                stroke="currentColor"
                strokeWidth="2.3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <h2 className="flex min-w-0 flex-1 items-center gap-1.5 text-[14px] font-black text-amber-950">
            <span className="text-base">{emoji}</span>
            <span className="truncate">{title}</span>
          </h2>
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-950/90 px-2.5 py-1 text-[11.5px] font-black tabular-nums text-amber-100">
            <CoinIcon className="size-3.5 text-amber-300" />
            {toFa(points)}
          </span>
        </div>
        <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto p-3">{children}</div>
      </div>
    </div>
  );
}

function Box({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`tile rounded-2xl p-3 ${className}`}>
      {children}
    </div>
  );
}

function Cell({ label, value, tint }: { label: string; value: string; tint?: string }) {
  return (
    <div className="tile-soft rounded-xl px-2 py-1.5 text-center">
      <div className="text-[13px] font-black tabular-nums" style={{ color: tint ?? "#451a03" }}>
        {value}
      </div>
      <div className="text-[9.5px] font-bold text-amber-900/50">{label}</div>
    </div>
  );
}

function Meter({ pct, tint = "#f59e0b" }: { pct: number; tint?: string }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/14">
      <div
        className="h-full rounded-full transition-[width] duration-300"
        style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: tint }}
      />
    </div>
  );
}

/* ================================================================== */
/*  HUB — the card dashboard                                           */
/* ================================================================== */
function Hub() {
  const points = useStore((s) => s.points);
  const bank = useStore((s) => s.bank);
  const earned = useStore((s) => s.earned);
  const stats = useStore((s) => s.stats);
  const jobs = useStore((s) => s.jobsSinceRest);
  const taps = useStore((s) => s.tapsSinceBreak);
  const st = useStore(stamina);
  const lvl = levelOf(earned);

  return (
    <Sheet title="منوی جیکو" emoji="🎮" back={null}>
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-2xl bg-gradient-to-br from-amber-400/90 to-amber-500/90 p-3 text-amber-950">
            <div className="flex items-center gap-1 text-[10.5px] font-bold opacity-75">
              <CoinIcon className="size-3.5" /> جیب
            </div>
            <div className="text-xl font-black tabular-nums">{toFa(points)}</div>
          </div>
          <div className="rounded-2xl bg-gradient-to-br from-sky-400/85 to-sky-600/85 p-3 text-white">
            <div className="text-[10.5px] font-bold opacity-80">🏦 بانک</div>
            <div className="text-xl font-black tabular-nums">
              {bank === null ? "—" : toFa(bank)}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          <Cell label="سطح" value={toFa(lvl)} />
          <Cell label="کار تا خواب" value={`${toFa(jobs)}/${toFa(st)}`} />
          <Cell label="ضربه تا استراحت" value={`${toFa(taps)}/${toFa(TAPS_PER_BREAK)}`} />
        </div>

        <div className="grid grid-cols-2 gap-2">
          {HUB_SECTIONS.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                store.openPanel(c.id as PanelId);
                boop();
              }}
              className="tile flex items-start gap-2 rounded-2xl p-2.5 text-right transition hover:-translate-y-0.5 hover:brightness-[1.03]"
            >
              <span
                className="grid size-9 shrink-0 place-items-center rounded-xl text-xl"
                style={{ background: c.tint }}
              >
                {c.emoji}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[12px] font-black text-amber-950">{c.title}</span>
                <span className="block text-[9.5px] leading-4 font-medium text-amber-900/55">
                  {c.desc}
                </span>
              </span>
            </button>
          ))}
        </div>

        {/* shop — clothes, colours, accessories & upgrades */}
        <button
          type="button"
          onClick={() => {
            store.setShop(true);
            boop();
          }}
          className="flex items-center gap-3 rounded-2xl border border-amber-400/70 bg-gradient-to-l from-amber-200 to-amber-100 p-3 text-right transition hover:-translate-y-0.5"
        >
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-amber-400 text-xl">
            🛍️
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[12.5px] font-black text-amber-950">فروشگاه جیکو</div>
            <div className="text-[10px] leading-4 font-medium text-amber-900/60">
              رنگ جوجه، کلاه، عینک، گردنی، آب‌نبات و ارتقاها
            </div>
          </div>
          <span className="text-[10px] font-black text-amber-800">
            {toFa(26)} آیتم
          </span>
        </button>

        <WheelEntry />

        <div className="grid grid-cols-4 gap-1.5">
          <Cell label="شیفت" value={toFa(stats.shifts)} />
          <Cell label="سرقت" value={toFa(stats.heists)} />
          <Cell label="برد" value={toFa(stats.wins)} />
          <Cell label="تخم" value={toFa(stats.eggs)} />
        </div>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  JOBS                                                               */
/* ================================================================== */
function Jobs() {
  const earned = useStore((s) => s.earned);
  const lvl = levelOf(earned);

  return (
    <Sheet title="شغل‌ها و بازی‌ها" emoji="💼" back="hub">
      <div className="flex flex-col gap-2">
        {JOB_LIST.map((j) => {
          const locked = j.id === "taxi" && lvl < 3;
          return (
            <div
              key={j.id}
              className="tile flex items-center gap-2.5 rounded-2xl p-2.5"
            >
              <span
                className="grid size-11 shrink-0 place-items-center rounded-2xl text-2xl"
                style={{ background: j.tint }}
              >
                {j.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[12.5px] font-black text-amber-950">{j.title}</div>
                <div className="text-[10px] leading-4 font-medium text-amber-900/55">{j.desc}</div>
                <div className="text-[10px] font-bold text-emerald-700">{j.pay}</div>
              </div>
              <Btn
                size="sm"
                disabled={locked}
                onClick={() => {
                  if (j.live) store.startPlay(j.id as "sweep" | "heist");
                  else store.openPanel(j.id as PanelId);
                }}
              >
                {locked ? `سطح ${toFa(3)}` : "بازی"}
              </Btn>
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  WALLET / BANK                                                      */
/* ================================================================== */
function Wallet() {
  const bank = useStore((s) => s.bank);
  const points = useStore((s) => s.points);
  const loan = useStore((s) => s.loan);
  const earned = useStore((s) => s.earned);
  const worth = useStore(netWorth);
  const [amount, setAmount] = useState(100);
  const now = useNow(!!loan, 1000);
  const lvl = levelOf(earned);
  const loanCap = lvl * 500;

  if (bank === null) {
    return (
      <Sheet title="کیف پول و بانک" emoji="🏦" back="hub">
        <div className="flex flex-col items-center gap-3 py-6 text-center">
          <span className="text-5xl">🏦</span>
          <div className="text-[14px] font-black text-amber-950">هنوز حساب بانکی نداری</div>
          <p className="max-w-[270px] text-[11.5px] leading-5 text-amber-900/60">
            با افتتاح حساب می‌تونی پس‌انداز کنی، سود روزانه ۱٪ بگیری و وام بگیری.
          </p>
          <Btn onClick={() => store.openAccount()}>افتتاح حساب — {toFa(50)} پوینت</Btn>
        </div>
      </Sheet>
    );
  }

  const overdue = loan && loan.due < now;
  const max = Math.max(100, Math.max(points, bank));

  return (
    <Sheet title="کیف پول و بانک" emoji="🏦" back="hub">
      <div className="flex flex-col gap-3">
        <div className="rounded-2xl bg-gradient-to-br from-sky-500/90 to-indigo-600/90 p-4 text-white">
          <div className="text-[10.5px] font-bold opacity-80">موجودی حساب</div>
          <div className="text-3xl font-black tabular-nums">{toFa(bank)}</div>
          <div className="mt-2 flex items-center justify-between text-[10.5px] font-semibold opacity-85">
            <span>جیب: {toFa(points)}</span>
            <span dir="ltr">JEEKO •••• {toFa(String(1000 + (bank % 9000)).slice(-4))}</span>
          </div>
        </div>

        <Cell label="مجموع دارایی" value={toFa(worth)} />

        <Box>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[12px] font-bold text-amber-900/70">مبلغ</span>
            <span className="text-[14px] font-black tabular-nums text-amber-950">{toFa(amount)}</span>
          </div>
          <input
            type="range"
            min={25}
            max={max}
            step={25}
            value={Math.min(amount, max)}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full accent-amber-500"
          />
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Btn full onClick={() => store.deposit(amount)} disabled={points < amount}>
              واریز ↓
            </Btn>
            <Btn full tone="ghost" onClick={() => store.withdraw(amount)} disabled={bank < amount}>
              برداشت ↑
            </Btn>
          </div>
        </Box>

        <Box>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[12.5px] font-black text-amber-950">سود روزانه ۱٪</div>
              <div className="text-[10.5px] text-amber-900/55">
                حدود {toFa(Math.max(1, Math.round(bank * 0.01)))} پوینت
              </div>
            </div>
            <Btn size="sm" onClick={() => store.collectInterest()} disabled={bank <= 0}>
              دریافت
            </Btn>
          </div>
        </Box>

        <Box>
          <div className="mb-2 text-[12.5px] font-black text-amber-950">وام هوشمند</div>
          {loan ? (
            <div className="flex flex-col gap-2">
              <div
                className={`rounded-xl px-3 py-2 text-[11.5px] font-bold ${
                  overdue ? "bg-rose-500/20 text-rose-300" : "bg-amber-400/20 text-amber-200"
                }`}
              >
                بدهی {toFa(loan.amount)} ·{" "}
                {overdue ? "سررسید گذشته — حساب قفله" : `مهلت ${fmt(loan.due - now)}`}
              </div>
              <Btn full onClick={() => store.repayLoan()} disabled={points < loan.amount}>
                تسویه وام
              </Btn>
            </div>
          ) : (
            <>
              <p className="text-[11px] leading-5 text-amber-900/60">
                سقف بر اساس سطح: <b className="text-amber-950">{toFa(loanCap)}</b> — بازپرداخت با
                ۱۵٪ کارمزد ظرف ۲۴ ساعت.
              </p>
              <div className="mt-2 grid grid-cols-3 gap-1.5">
                {[0.25, 0.5, 1].map((f) => (
                  <Btn key={f} size="sm" tone="ghost" onClick={() => store.takeLoan(Math.round(loanCap * f))}>
                    {toFa(Math.round(loanCap * f))}
                  </Btn>
                ))}
              </div>
            </>
          )}
        </Box>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  FARM                                                               */
/* ================================================================== */
function Farm() {
  const farm = useStore((s) => s.farm);
  const now = useNow(true, 1000);
  const [msg, setMsg] = useState<string | null>(null);

  if (!farm.owned) {
    return (
      <Sheet title="مزرعه" emoji="🌾" back="hub">
        <div className="flex flex-col items-center gap-3 py-6 text-center">
          <span className="text-5xl">🚜</span>
          <div className="text-[14px] font-black text-amber-950">مزرعه‌ای نداری</div>
          <p className="max-w-[270px] text-[11.5px] leading-5 text-amber-900/60">
            مرغ‌ها هر ساعت برات پوینت تولید می‌کنن — فقط باید سطل غذا پر باشه.
          </p>
          <Btn onClick={() => store.buyFarm()}>خرید مزرعه — {toFa(400)} پوینت</Btn>
        </div>
      </Sheet>
    );
  }

  const fed = farm.feedUntil > now;
  const hours = Math.min(6, Math.floor((now - farm.lastCollect) / 3600e3));
  const pending = hours * 45 * farm.capacity;

  return (
    <Sheet title="مزرعه" emoji="🌾" back="hub">
      <div className="flex flex-col gap-3">
        <div className="rounded-2xl border border-white/60 bg-gradient-to-b from-sky-200/70 to-lime-200/70 p-3">
          <div className="flex flex-wrap gap-1 text-2xl">
            {Array.from({ length: farm.capacity * 3 }).map((_, i) => (
              <span key={i} className="animate-floaty" style={{ animationDelay: `${(i % 6) * 0.35}s` }}>
                🐔
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          <Cell label="سود آماده" value={toFa(pending)} tint="#15803d" />
          <Cell label="ساعت" value={toFa(hours)} />
          <Cell label="ظرفیت" value={`${toFa(farm.capacity)}/${toFa(6)}`} />
        </div>

        <Box>
          <div className="mb-1.5 flex items-center justify-between text-[11.5px] font-bold">
            <span className="text-amber-900/70">سطل غذا</span>
            <span className={fed ? "text-emerald-700" : "text-rose-600"}>
              {fed ? fmt(farm.feedUntil - now) : "خالی"}
            </span>
          </div>
          <Meter pct={fed ? ((farm.feedUntil - now) / (6 * 3600e3)) * 100 : 0} tint={fed ? "#22c55e" : "#f43f5e"} />
          <div className="mt-2">
            <Btn full size="sm" tone="ghost" onClick={() => store.feedFarm()}>
              پر کردن — {toFa(60)} پوینت (۶ ساعت)
            </Btn>
          </div>
        </Box>

        <div className="grid grid-cols-2 gap-2">
          <Btn full onClick={() => store.collectFarm()} disabled={pending <= 0 || !fed}>
            جمع‌آوری {pending > 0 ? `+${toFa(pending)}` : ""}
          </Btn>
          <Btn full tone="ghost" onClick={() => store.upgradeFarm()} disabled={farm.capacity >= 6}>
            ارتقا — {toFa(300 * farm.capacity)}
          </Btn>
        </div>

        <Box>
          <div className="mb-1 text-[12.5px] font-black text-amber-950">🚚 قاچاق مرغ به مرز</div>
          <p className="text-[11px] leading-5 text-amber-900/60">
            سود بزرگ ولی <b className="text-rose-600">۴۰٪ شانس دستگیری</b>.
          </p>
          {msg && (
            <div
              className={`pop mt-2 rounded-xl px-3 py-2 text-[11.5px] font-black ${
                msg.startsWith("+") ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"
              }`}
            >
              {msg}
            </div>
          )}
          <div className="mt-2">
            <Btn
              full
              size="sm"
              tone="danger"
              onClick={() => {
                const ok = store.smuggle();
                setMsg(ok ? "+ محموله سالم رد شد" : "دستگیر شدی!");
                if (ok) fanfare();
              }}
            >
              ارسال محموله — {toFa(100)} پوینت
            </Btn>
          </div>
        </Box>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  MARKET                                                             */
/* ================================================================== */
function Market() {
  const fridge = useStore((s) => s.fridge);
  const age = useStore((s) => s.pet.age);

  return (
    <Sheet title="سوپرمارکت" emoji="🛒" back="hub">
      <p className="mb-2 text-[11px] font-medium text-amber-900/55">
        هرچی بخری میره توی یخچال، بعد از یخچال به جیکو بده بخوره.
      </p>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
        {FOODS.map((f) => {
          const locked = !!f.adult && age < 18;
          const have = fridge[f.id] ?? 0;
          return (
            <button
              key={f.id}
              type="button"
              disabled={locked}
              onClick={() => {
                store.buyFood(f.id, f.price);
                boop();
              }}
              className={`tile flex flex-col items-center gap-1 rounded-2xl p-2.5 transition ${
                locked ? "opacity-50" : "hover:-translate-y-0.5 hover:brightness-[1.03]"
              }`}
            >
              <span className="relative text-2xl">
                {f.emoji}
                {have > 0 && (
                  <span className="absolute -top-1 -right-2 grid size-4 place-items-center rounded-full bg-amber-950/90 text-[9px] font-black text-amber-50">
                    {toFa(have)}
                  </span>
                )}
              </span>
              <span className="text-[10px] font-black text-amber-950">{f.name}</span>
              <span className="text-[9.5px] font-bold text-emerald-700">+{toFa(f.fill)} سیری</span>
              <span className="inline-flex items-center gap-0.5 text-[10.5px] font-black text-amber-900">
                <CoinIcon className="size-3" />
                {toFa(f.price)}
              </span>
              {locked && <span className="text-[9px] font-black text-rose-600">۱۸+</span>}
            </button>
          );
        })}
      </div>
      <div className="mt-3">
        <Btn full tone="cool" onClick={() => store.setFridge(true)}>
          🧊 باز کردن یخچال
        </Btn>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  GARAGE                                                             */
/* ================================================================== */
function Garage() {
  const cars = useStore((s) => s.cars);
  const active = useStore((s) => s.activeCar);
  const fuel = useStore((s) => s.fuel);
  const health = useStore((s) => s.carHealth);
  const [page, setPage] = useState(0);
  const per = 6;
  const pages = Math.ceil(CARS.length / per);
  const slice = CARS.slice(page * per, page * per + per);

  return (
    <Sheet title="نمایشگاه و گاراژ" emoji="🚗" back="hub">
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-2">
          <Box>
            <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
              <span className="text-amber-900/70">⛽ بنزین</span>
              <span className="text-amber-950">{toFa(Math.round(fuel))}٪</span>
            </div>
            <Meter pct={fuel} />
            <div className="mt-2">
              <Btn full size="sm" tone="ghost" onClick={() => store.refuel()}>
                پر کردن — {toFa(70)}
              </Btn>
            </div>
          </Box>
          <Box>
            <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
              <span className="text-amber-900/70">🔧 سلامت</span>
              <span className="text-amber-950">{"★".repeat(health) || "—"}</span>
            </div>
            <Meter pct={(health / 3) * 100} tint="#22c55e" />
            <div className="mt-2">
              <Btn full size="sm" tone="ghost" onClick={() => store.repairCar()}>
                تعمیرگاه — {toFa(120)}
              </Btn>
            </div>
          </Box>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {slice.map((c) => {
            const owned = cars.includes(c.id);
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  owned ? store.selectCar(c.id) : store.buyCar(c.id, c.price);
                  boop();
                }}
                className={`flex flex-col items-center gap-0.5 rounded-2xl border p-2 transition hover:-translate-y-0.5 ${
                  active === c.id
                    ? "border-amber-400 bg-amber-400/25"
                    : "tile hover:brightness-[1.03]"
                }`}
              >
                <span className="text-2xl">{c.emoji}</span>
                <span className="text-[10px] font-black text-amber-950">{c.name}</span>
                <span className="text-[9px] font-bold text-amber-900/45">
                  ×{toFa(c.speed.toFixed(1))}
                </span>
                {owned ? (
                  <span className="text-[9.5px] font-black text-emerald-700">
                    {active === c.id ? "فعال" : "انتخاب"}
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-0.5 text-[10px] font-black text-amber-900">
                    <CoinIcon className="size-2.5" />
                    {toFa(c.price)}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="flex items-center justify-center gap-2">
          <Btn size="sm" tone="ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
            ‹ قبلی
          </Btn>
          <span className="text-[11px] font-black text-amber-900/60">
            {toFa(page + 1)} / {toFa(pages)}
          </span>
          <Btn size="sm" tone="ghost" disabled={page >= pages - 1} onClick={() => setPage((p) => p + 1)}>
            بعدی ›
          </Btn>
        </div>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  TAXI                                                               */
/* ================================================================== */
function Taxi() {
  const activeCar = useStore((s) => s.activeCar);
  const fuel = useStore((s) => s.fuel);
  const health = useStore((s) => s.carHealth);
  const ride = useStore((s) => s.ride);
  const now = useNow(!!ride, 200);
  const car = CARS.find((c) => c.id === activeCar);

  useEffect(() => {
    if (ride && ride.until <= now) store.finishRide();
  }, [ride, now]);

  if (ride) {
    const pct = 100 - Math.max(0, ((ride.until - now) / 30000) * 100);
    return (
      <Sheet title="مسافرکشی" emoji="🚕" back="jobs">
        <div className="flex flex-col items-center gap-3 py-4 text-center">
          <div className="relative h-16 w-full overflow-hidden rounded-2xl bg-gradient-to-b from-slate-200/70 to-slate-300/60">
            <div className="absolute bottom-3 h-1 w-full bg-white/70" />
            <span
              className="absolute bottom-3 -translate-x-1/2 text-3xl transition-[right] duration-300"
              style={{ right: `${Math.min(92, Math.max(4, pct))}%` }}
            >
              {car?.emoji ?? "🚕"}
            </span>
          </div>
          <div className="text-[13px] font-black text-amber-950">{ride.label}</div>
          <div className="text-2xl font-black tabular-nums text-amber-600">{fmt(ride.until - now)}</div>
        </div>
      </Sheet>
    );
  }

  const blocked = !car
    ? "اول باید یک ماشین بخری"
    : health <= 0
      ? "ماشینت خرابه، ببرش تعمیرگاه"
      : fuel < 10
        ? "باک خالیه، برو پمپ بنزین"
        : null;

  return (
    <Sheet title="مسافرکشی" emoji="🚕" back="jobs">
      <div className="flex flex-col gap-3">
        <Box>
          <div className="flex items-center gap-3">
            <span className="text-3xl">{car?.emoji ?? "🚘"}</span>
            <div className="min-w-0 flex-1">
              <div className="text-[12.5px] font-black text-amber-950">{car?.name ?? "بدون ماشین"}</div>
              <div className="text-[10.5px] font-semibold text-amber-900/55">
                بنزین {toFa(Math.round(fuel))}٪ · سلامت {toFa(health)}/۳
              </div>
            </div>
            <Btn size="sm" tone="ghost" onClick={() => store.openPanel("garage")}>
              گاراژ
            </Btn>
          </div>
        </Box>

        {blocked ? (
          <div className="rounded-2xl bg-rose-500/12 px-3 py-3 text-center text-[12px] font-black text-rose-700">
            {blocked}
          </div>
        ) : (
          ROUTES.map((r) => {
            const pay = Math.round(r.pay * (car?.speed ?? 1));
            const noFuel = fuel < r.fuel;
            return (
              <button
                key={r.id}
                type="button"
                disabled={noFuel}
                onClick={() => {
                  store.startRide(r.label, r.seconds, pay, r.fuel);
                  boop();
                }}
                className={`tile flex items-center gap-3 rounded-2xl p-3 text-right transition ${
                  noFuel ? "opacity-50" : "hover:-translate-y-0.5 hover:brightness-[1.03]"
                }`}
              >
                <span className="text-2xl">{r.emoji}</span>
                <div className="min-w-0 flex-1">
                  <div className="text-[12.5px] font-black text-amber-950">{r.label}</div>
                  <div className="text-[10.5px] font-semibold text-amber-900/55">
                    {toFa(r.seconds)} ثانیه · {toFa(r.fuel)}٪ بنزین
                  </div>
                </div>
                <span className="inline-flex items-center gap-0.5 text-[12px] font-black text-emerald-700">
                  <CoinIcon className="size-3.5" />
                  {toFa(pay)}
                </span>
              </button>
            );
          })
        )}
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  DOOZ                                                               */
/* ================================================================== */
const LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];
type Cell3 = "X" | "O" | null;
const BET = 50;

function winnerOf(b: Cell3[]) {
  for (const l of LINES) {
    const [a, c, d] = l;
    if (b[a] && b[a] === b[c] && b[a] === b[d]) return { who: b[a], line: l };
  }
  return null;
}
function aiMove(b: Cell3[], perfect: boolean) {
  const empty = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  if (perfect) {
    for (const p of ["O", "X"] as const) {
      for (const l of LINES) {
        const vals = l.map((i) => b[i]);
        if (vals.filter((v) => v === p).length === 2 && vals.includes(null)) {
          return l[vals.indexOf(null)];
        }
      }
    }
    if (!b[4]) return 4;
    const corners = [0, 2, 6, 8].filter((i) => !b[i]);
    if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  }
  return empty[Math.floor(Math.random() * empty.length)];
}

function Dooz() {
  const rich = useStore(luck) < 0.35;
  const [board, setBoard] = useState<Cell3[]>(Array(9).fill(null));
  const [turn, setTurn] = useState<"me" | "cpu">("me");
  const [result, setResult] = useState<"win" | "lose" | "draw" | null>(null);
  const [playing, setPlaying] = useState(false);
  const win = winnerOf(board);

  const start = () => {
    if (!store.bet(BET)) return;
    setBoard(Array(9).fill(null));
    setTurn("me");
    setResult(null);
    setPlaying(true);
  };

  useEffect(() => {
    if (!playing) return;
    const w = winnerOf(board);
    const full = board.every(Boolean);
    if (w || full) {
      const r = w ? (w.who === "X" ? "win" : "lose") : "draw";
      setResult(r);
      setPlaying(false);
      if (r === "win") {
        store.winBet(BET * 2);
        fanfare();
      } else if (r === "draw") store.refund(BET);
      return;
    }
    if (turn === "cpu") {
      const id = window.setTimeout(() => {
        const mv = aiMove(board, rich || Math.random() < 0.7);
        setBoard((b) => {
          const n = [...b];
          if (n[mv] === null) n[mv] = "O";
          return n;
        });
        setTurn("me");
      }, 400);
      return () => window.clearTimeout(id);
    }
  }, [board, turn, playing, rich]);

  return (
    <Sheet title="دوز" emoji="⭕" back="jobs">
      <div className="flex flex-col gap-3">
        <div className="tile flex justify-between rounded-2xl px-3 py-2 text-[12px] font-bold">
          <span className="text-amber-900/70">شرط {toFa(BET)}</span>
          <span className="text-emerald-700">برد {toFa(BET * 2)}</span>
        </div>

        <div className="mx-auto grid w-full max-w-[250px] grid-cols-3 gap-2">
          {board.map((c, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                if (!playing || turn !== "me" || board[i]) return;
                boop();
                const n = [...board];
                n[i] = "X";
                setBoard(n);
                setTurn("cpu");
              }}
              className={`grid aspect-square place-items-center rounded-2xl border text-3xl font-black transition ${
                win?.line.includes(i)
                  ? "border-emerald-500 bg-emerald-200"
                  : "tile hover:brightness-[1.03]"
              }`}
            >
              <span className={c === "X" ? "text-amber-600" : "text-sky-600"}>
                {c === "X" ? "✕" : c === "O" ? "◯" : ""}
              </span>
            </button>
          ))}
        </div>

        {result && (
          <div
            className={`pop rounded-2xl px-3 py-2 text-center text-[13px] font-black ${
              result === "win"
                ? "bg-emerald-500/20 text-emerald-300"
                : result === "draw"
                  ? "bg-amber-400/20 text-amber-200"
                  : "bg-rose-500/20 text-rose-300"
            }`}
          >
            {result === "win" ? "بردی! 🎉" : result === "draw" ? "مساوی" : "باختی"}
          </div>
        )}

        <Btn full onClick={start} disabled={playing}>
          {playing ? "در حال بازی…" : `دست جدید (${toFa(BET)} پوینت)`}
        </Btn>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  CASINO                                                             */
/* ================================================================== */
const REEL = ["🥚", "🐥", "🌽", "💛", "🍀", "💎"];
const PAY: Record<string, number> = { "🥚": 3, "🐥": 4, "🌽": 5, "💛": 8, "🍀": 12, "💎": 20 };

function Casino() {
  const points = useStore((s) => s.points);
  const fortune = useStore(luck);
  const [bet, setBet] = useState(50);
  const [reels, setReels] = useState(["🥚", "🐥", "🌽"]);
  const [spinning, setSpinning] = useState(false);
  const [msg, setMsg] = useState<{ t: string; good: boolean } | null>(null);

  const spin = () => {
    if (spinning || !store.bet(bet)) return;
    setSpinning(true);
    setMsg(null);
    let ticks = 0;
    const id = window.setInterval(() => {
      ticks++;
      setReels([
        REEL[Math.floor(Math.random() * 6)],
        REEL[Math.floor(Math.random() * 6)],
        REEL[Math.floor(Math.random() * 6)],
      ]);
      if (ticks > 15) {
        window.clearInterval(id);
        const roll = () => {
          const r = Math.random();
          if (r < 0.32) return "🥚";
          if (r < 0.56) return "🐥";
          if (r < 0.74) return "🌽";
          if (r < 0.87) return "💛";
          if (r < 0.96) return "🍀";
          return "💎";
        };
        let final = [roll(), roll(), roll()];
        // the very rich quietly stop hitting jackpots
        if (fortune < 0.35 && final[0] === final[1] && final[1] === final[2]) {
          final = [final[0], final[1], REEL[(REEL.indexOf(final[2]) + 1) % 6]];
        }
        setReels(final);
        setSpinning(false);
        const [a, b, c] = final;
        if (a === b && b === c) {
          const gain = bet * PAY[a];
          store.winBet(gain);
          fanfare();
          setMsg({ t: `جکپات ${a} — ${toFa(gain)} پوینت!`, good: true });
        } else if (a === b || b === c || a === c) {
          const gain = Math.round(bet * 1.5);
          store.refund(gain);
          setMsg({ t: `دوتایی! +${toFa(gain)}`, good: true });
        } else {
          setMsg({ t: "این دست رو باختی", good: false });
        }
      }
    }, 80);
  };

  return (
    <Sheet title="قمار" emoji="🎰" back="jobs">
      <div className="flex flex-col gap-3">
        <div className="rounded-3xl border-4 border-amber-500/40 bg-gradient-to-b from-fuchsia-200/60 to-amber-100/60 p-3">
          <div className="flex justify-center gap-2">
            {reels.map((r, i) => (
              <div
                key={i}
                className={`grid size-[70px] place-items-center rounded-2xl bg-white/12 text-4xl shadow-inner ring-1 ring-white/15 ${
                  spinning ? "blur-[1px]" : "pop"
                }`}
              >
                {r}
              </div>
            ))}
          </div>
        </div>

        {msg && (
          <div
            className={`pop rounded-2xl px-3 py-2 text-center text-[12.5px] font-black ${
              msg.good ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"
            }`}
          >
            {msg.t}
          </div>
        )}

        <Box>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[12px] font-bold text-amber-900/70">مبلغ شرط</span>
            <span className="text-[13px] font-black text-amber-950">{toFa(bet)}</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[25, 50, 100, 250].map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => {
                  setBet(v);
                  boop();
                }}
                disabled={points < v}
                className={`rounded-xl py-1.5 text-[11.5px] font-black transition ${
                  bet === v
                    ? "bg-gradient-to-b from-fuchsia-500 to-purple-600 text-white"
                    : points < v
                      ? "bg-white/8 text-violet-200/35"
                      : "bg-white/10 text-violet-100 ring-1 ring-white/15 hover:bg-white/18"
                }`}
              >
                {toFa(v)}
              </button>
            ))}
          </div>
        </Box>

        <Btn full onClick={spin} disabled={spinning || points < bet}>
          {spinning ? "در حال چرخش…" : "بچرخون"}
        </Btn>

        <Box>
          <div className="mb-1.5 text-[11.5px] font-black text-amber-950">جدول جوایز (سه‌تایی)</div>
          <div className="grid grid-cols-3 gap-1.5">
            {REEL.map((r) => (
              <div key={r} className="tile-soft flex items-center justify-between rounded-lg px-2 py-1 text-[11px] font-bold">
                <span className="text-base">{r}</span>
                <span className="text-amber-900/70">×{toFa(PAY[r])}</span>
              </div>
            ))}
          </div>
        </Box>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  PROFILE                                                            */
/* ================================================================== */
function Profile() {
  const pet = useStore((s) => s.pet);
  const earned = useStore((s) => s.earned);
  const since = useStore((s) => s.repsSinceFood);
  const st = useStore(stamina);
  const rest = useStore(restMs);
  const reward = useStore(clickReward);
  const [name, setName] = useState(pet.name);

  return (
    <Sheet title="شناسنامه جیکو" emoji="📋" back="hub">
      <div className="flex flex-col gap-3">
        <Box>
          <div className="grid grid-cols-2 gap-2">
            <Cell label="اسم" value={pet.name} />
            <Cell label="جنسیت" value={pet.gender === "male" ? "نر ♂️" : "ماده ♀️"} />
            <Cell label="سن" value={`${toFa(pet.age)} سال`} />
            <Cell label="کد شناسنامه" value={toFa(pet.code)} />
            <Cell label="سطح" value={toFa(levelOf(earned))} />
            <Cell label="وضعیت" value={pet.age >= 18 ? "بالغ" : "نوجوان"} />
          </div>
        </Box>

        <Box>
          <div className="mb-2 text-[12.5px] font-black text-amber-950">🏋️ باشگاه</div>
          <p className="text-[11px] leading-5 text-amber-900/60">
            هر ۱۲ حرکت = ۱ سال بزرگ‌تر. بعد از ۳ حرکت گشنه می‌شه.
          </p>
          <div className="my-2">
            <Meter pct={(pet.reps / 12) * 100} tint="#a855f7" />
          </div>
          <div className="flex items-center justify-between text-[11px] font-bold text-amber-900/60">
            <span>
              {toFa(pet.reps)}/{toFa(12)} حرکت · گرسنگی {toFa(since)}/۳
            </span>
            <Btn size="sm" onClick={() => store.goMap("gym")}>
              رفتن به باشگاه
            </Btn>
          </div>
        </Box>

        <Box>
          <div className="mb-2 text-[12.5px] font-black text-amber-950">آمار ارتقاها</div>
          <div className="grid grid-cols-3 gap-1.5">
            <Cell label="پوینت هر ۳ کلیک" value={toFa(reward)} />
            <Cell label="کار تا خواب" value={toFa(st)} />
            <Cell label="مدت خواب" value={fmt(rest)} />
          </div>
        </Box>

        <Box>
          <div className="mb-2 text-[12.5px] font-black text-amber-950">✏️ تغییر اسم</div>
          <div className="flex gap-1.5">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={14}
              className="min-w-0 flex-1 rounded-xl bg-white/12 px-3 py-2 text-[12.5px] font-bold text-violet-50 ring-1 ring-white/15 outline-none placeholder:text-violet-200/40"
            />
            <Btn size="sm" onClick={() => store.renamePet(name)}>
              ثبت
            </Btn>
          </div>
          <div className="mt-2">
            <Btn full size="sm" tone="ghost" onClick={() => store.flipGender()}>
              ⚧ تغییر جنسیت — {toFa(120)} پوینت
            </Btn>
          </div>
        </Box>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  MARS                                                               */
/* ================================================================== */
function Mars() {
  return (
    <Sheet title="سفر به مریخ" emoji="🔴" back="hub">
      <MarsTicket />
    </Sheet>
  );
}

/* ================================================================== */
export function Panel() {
  const panel = useStore((s) => s.panel);
  const jailed = useStore((s) => s.jailUntil > Date.now());

  useEffect(() => {
    if (!panel) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") store.openPanel(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panel]);

  if (jailed || !panel) return null;

  switch (panel) {
    case "hub":
      return <Hub />;
    case "jobs":
      return <Jobs />;
    case "wallet":
      return <Wallet />;
    case "farm":
      return <Farm />;
    case "market":
      return <Market />;
    case "garage":
      return <Garage />;
    case "profile":
      return <Profile />;
    case "mars":
      return <Mars />;
    case "taxi":
      return <Taxi />;
    case "dooz":
      return <Dooz />;
    case "casino":
      return <Casino />;
    default:
      return null;
  }
}

export { JOBS_PER_REST };
