import { useState } from 'react';
import { useGame } from '../context/GameContext';
import { formatNumber } from '../utils/formatters';
import { Sparkles, Shield, AlertTriangle, ArrowRight, CheckCircle2, RotateCcw } from 'lucide-react';
import celestialArchonCrestImg from '../assets/images/celestial_archon_crest_1791261402662.jpg';

export function CelestialAltarTab() {
  const {
    archons,
    lifetimeArchons,
    archonBoostPercent,
    pendingArchons,
    ascendRealm,
    ascensionsCount,
    numberFormat,
    gold,
  } = useGame();

  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  const currentBoostPercent = Math.round(archons * archonBoostPercent);
  const potentialNewTotal = archons + pendingArchons;
  const potentialNewBoost = Math.round(potentialNewTotal * archonBoostPercent);

  const handleAscendConfirm = () => {
    ascendRealm();
    setConfirmModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Visual Celestial Crest Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-violet-900/40 shadow-2xl bg-slate-950">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/3 h-52 sm:h-64 relative overflow-hidden shrink-0">
            <img
              src={celestialArchonCrestImg}
              alt="Celestial Archon Crest"
              className="w-full h-full object-cover object-center"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-transparent via-slate-950/40 to-slate-950" />
          </div>

          <div className="p-6 md:p-8 flex-1">
            <div className="flex items-center gap-2 text-violet-400 text-xs font-semibold uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span>Divine Realm Ascension</span>
            </div>
            <h2 className="font-cinzel text-2xl sm:text-3xl font-extrabold text-amber-100">
              The Celestial Altar of Rebirth
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              Ascending your realm appeals to the higher pantheon. Sacrifice your mortal gold and reset your workshops to receive divine{' '}
              <strong className="text-violet-300 font-semibold">Celestial Archons</strong>. Each Archon permanently bestows{' '}
              <strong className="text-amber-300 font-semibold">+{archonBoostPercent}% profit boost</strong> across every venture in your kingdom!
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-5">
              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
                <div className="text-[11px] text-slate-400">Current Archons</div>
                <div className="font-cinzel text-lg sm:text-xl font-bold text-violet-300 tabular-nums">
                  {formatNumber(archons, numberFormat)}
                </div>
              </div>

              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
                <div className="text-[11px] text-slate-400">Active Profit Boost</div>
                <div className="font-cinzel text-lg sm:text-xl font-bold text-emerald-400 tabular-nums">
                  +{formatNumber(currentBoostPercent, numberFormat)}%
                </div>
              </div>

              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl col-span-2 sm:col-span-1">
                <div className="text-[11px] text-slate-400">Total Ascensions</div>
                <div className="font-cinzel text-lg sm:text-xl font-bold text-amber-300 tabular-nums">
                  {ascensionsCount}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ascension Readiness Box */}
      <div className="rounded-2xl border border-amber-900/30 bg-slate-900/90 p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="text-xs uppercase font-semibold text-amber-400 tracking-wider mb-1">
            Rebirth Dividend
          </div>
          <h3 className="font-cinzel text-xl font-bold text-slate-100">
            Pending Celestial Archons
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-lg">
            {pendingArchons > 0
              ? `Rebirth now to gain +${formatNumber(pendingArchons, numberFormat)} Archons. Your all-venture bonus will rise from +${formatNumber(currentBoostPercent, numberFormat)}% to +${formatNumber(potentialNewBoost, numberFormat)}%!`
              : 'Keep expanding your realm workshops to accumulate more lifetime gold before celestial favors can be bestowed.'}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
          <div className="text-center sm:text-right">
            <div className="text-xs text-slate-400">Archons Waiting</div>
            <div className="font-cinzel text-2xl sm:text-3xl font-extrabold text-amber-300 tabular-nums">
              +{formatNumber(pendingArchons, numberFormat)}
            </div>
          </div>

          <button
            onClick={() => setConfirmModalOpen(true)}
            disabled={pendingArchons <= 0}
            className={`w-full sm:w-auto px-6 py-3.5 rounded-2xl font-cinzel text-sm font-bold tracking-wide transition-all cursor-pointer flex items-center justify-center gap-2 ${
              pendingArchons > 0
                ? 'bg-gradient-to-r from-amber-500 via-violet-500 to-amber-500 hover:from-amber-400 hover:to-violet-400 text-slate-950 shadow-lg shadow-violet-950/50 active:scale-95'
                : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-75'
            }`}
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>Ascend Realm ({pendingArchons > 0 ? `+${formatNumber(pendingArchons, numberFormat)}` : '0'})</span>
          </button>
        </div>
      </div>

      {/* Ascension Guide Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2 font-cinzel text-base font-bold text-slate-200 mb-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>What You Keep Upon Rebirth</span>
          </div>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span>All currently owned Celestial Archons + newly claimed Archons</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span>All Celestial Archon Relics and permanent power boosts</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span>All unlocked Kingdom Achievements and statistics history</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span>Exponential profit boost allowing you to reach previous records in minutes!</span>
            </li>
          </ul>
        </div>

        <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2 font-cinzel text-base font-bold text-slate-200 mb-3">
            <RotateCcw className="w-5 h-5 text-amber-400" />
            <span>What Resets in Exchange</span>
          </div>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">↺</span>
              <span>Current Gold treasury resets to initial founding balance</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">↺</span>
              <span>Venture levels and workshop counts reset to 0 (except 1st plot)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">↺</span>
              <span>Guildmaster manager contracts must be re-commissioned</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">↺</span>
              <span>Standard Gold Grimoire upgrades return to the archives</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Confirmation Modal */}
      {confirmModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-amber-600/40 p-6 shadow-2xl relative">
            <div className="flex items-center gap-3 text-amber-400 mb-3">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
              <h3 className="font-cinzel text-xl font-bold text-slate-100">
                Confirm Realm Rebirth?
              </h3>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              You are about to ascend your mortal kingdom. Your current Gold and workshops will reset, but you will receive{' '}
              <strong className="text-amber-300 font-semibold">+{formatNumber(pendingArchons, numberFormat)} Celestial Archons</strong>, raising your permanent multiplier to{' '}
              <strong className="text-emerald-300 font-semibold">+{formatNumber(potentialNewBoost, numberFormat)}%</strong>!
            </p>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setConfirmModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleAscendConfirm}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
              >
                Ascend Realm Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
