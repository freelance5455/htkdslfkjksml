import React from 'react';
import { GameMode, LevelConfig } from '../types/game';
import { RotateCcw, Home, PlusCircle, AlertCircle } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface GameOverModalProps {
  level: LevelConfig;
  mode: GameMode;
  extraMovesCount: number;
  onUseExtraMoves: () => void;
  onRetry: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  level,
  mode,
  extraMovesCount,
  onUseExtraMoves,
  onRetry,
  onHome
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm sm:max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center">
        {/* Glow Accent */}
        <div className="absolute -top-10 w-28 h-28 bg-rose-500/20 rounded-full blur-2xl pointer-events-none" />

        <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4">
          <AlertCircle className="w-7 h-7" />
        </div>

        <div className="text-xs font-bold tracking-widest uppercase text-rose-400 mb-1">
          {mode === 'time_challenge' ? "Time's Up!" : 'Out of Moves!'}
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
          PUZZLE FAILED
        </h2>
        <p className="text-xs text-slate-400 max-w-xs mb-6">
          {mode === 'time_challenge'
            ? 'The clock ran out before all color connections were completed.'
            : 'You reached the move limit before linking all color nodes.'}
        </p>

        {/* Continue with +5 Moves Booster if classic */}
        {mode !== 'time_challenge' && (
          <div className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-4 mb-5 flex flex-col items-center">
            <div className="text-xs font-semibold text-slate-300 mb-2">
              Want to keep playing this puzzle?
            </div>
            <button
              onClick={() => {
                soundEngine.playBooster();
                onUseExtraMoves();
              }}
              disabled={extraMovesCount <= 0}
              className={`w-full py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 font-bold text-sm transition-all ${
                extraMovesCount > 0
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              <span>Use +5 Moves Booster ({extraMovesCount} left)</span>
            </button>
          </div>
        )}

        {/* Actions */}
        <div className="w-full flex items-center gap-3">
          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onHome();
            }}
            title="Main Menu"
            className="w-12 h-12 flex items-center justify-center rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
          >
            <Home className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onRetry();
            }}
            className="flex-1 h-12 flex items-center justify-center gap-2 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm tracking-wide shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all hover:scale-102 active:scale-98"
          >
            <RotateCcw className="w-4 h-4" />
            <span>TRY AGAIN</span>
          </button>
        </div>
      </div>
    </div>
  );
};
