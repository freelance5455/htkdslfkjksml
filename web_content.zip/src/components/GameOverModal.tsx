import React from 'react';
import { RotateCcw, Home, ShoppingBag, Trophy } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  coins: number;
  distance: number;
  isNewHighScore: boolean;
  onRestart: () => void;
  onHome: () => void;
  onOpenShop: () => void;
}

const MOM_QUOTES = [
  'يا واد تعال هنا! الغدا برد وكنت بتلعب في الشارع؟! 🍲',
  'الشبشب الطائر لا يخطئ هدفه أبداً! 🩴💨',
  'ما ذاكرتش دروسك ورايح تتزحلق بين الأتوبيسات؟! 📚',
  'مفيش مصروف بكرة يا شقي.. تعال ساعدني في البيت! 🧹',
  'جريت كل المسافة دي عشان تهرب من طبق البامية؟! 🥘',
  'شفت لما قلتلك البس الخوذة وما سمعتش الكلام؟! ⚠️'
];

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  coins,
  distance,
  isNewHighScore,
  onRestart,
  onHome,
  onOpenShop
}) => {
  const [randomQuote] = React.useState(() => {
    return MOM_QUOTES[Math.floor(Math.random() * MOM_QUOTES.length)];
  });

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-red-500/60 rounded-3xl p-5 md:p-6 max-w-md w-full shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
        {/* Mom Icon Badge */}
        <div className="w-16 h-16 rounded-full bg-red-600 border-4 border-amber-400 flex items-center justify-center text-3xl shadow-lg -mt-12 mb-2">
          🩴
        </div>

        <h2 className="text-2xl md:text-3xl font-black text-red-500 mb-1">
          أمسكت بك ماما!
        </h2>

        {/* Mom's funny quote card */}
        <div className="bg-red-950/50 border border-red-500/30 rounded-2xl p-3 my-2.5 text-xs md:text-sm text-red-200 font-bold leading-relaxed">
          &ldquo;{randomQuote}&rdquo;
        </div>

        {/* New high score banner */}
        {isNewHighScore && (
          <div className="bg-amber-500/20 border border-amber-400 rounded-xl px-3 py-1 text-amber-300 font-extrabold text-xs flex items-center gap-1.5 mb-3">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>رقم قياسي جديد! كفووو! 🔥</span>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2.5 w-full my-3">
          <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-2.5">
            <div className="text-[11px] text-slate-400 font-bold">النقاط</div>
            <div className="text-lg font-black text-cyan-400 tabular-nums">
              {score.toLocaleString('ar-EG')}
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-2.5">
            <div className="text-[11px] text-slate-400 font-bold">العملات</div>
            <div className="text-lg font-black text-amber-400 tabular-nums">
              +{coins.toLocaleString('ar-EG')} 🪙
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-2.5">
            <div className="text-[11px] text-slate-400 font-bold">المسافة</div>
            <div className="text-lg font-black text-emerald-400 tabular-nums">
              {distance} م
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full mt-2">
          <button
            onClick={onRestart}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-lg shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            <span>إعادة الهروب</span>
          </button>

          <div className="grid grid-cols-2 gap-2 w-full">
            <button
              onClick={onOpenShop}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span>ترقية العتاد</span>
            </button>

            <button
              onClick={onHome}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Home className="w-4 h-4 text-slate-300" />
              <span>القائمة</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
