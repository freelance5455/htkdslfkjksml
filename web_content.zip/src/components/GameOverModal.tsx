import { HudSnapshot } from '../game/types';

interface GameOverModalProps {
  hud: HudSnapshot;
  onRestart: () => void;
  onTitle: () => void;
}

function formatDuration(totalSec: number): string {
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
}

export function GameOverModal({ hud, onRestart, onTitle }: GameOverModalProps) {
  const isLehau = hud.deathReason === 'LEHAU';

  return (
    <div
      className="absolute inset-0 z-20 flex items-center justify-center bg-[#09130c]/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="gameover-title"
    >
      <div
        className={`w-full max-w-sm p-6 text-center ${
          isLehau ? 'rainbow-pixel-border animate-lehau-pop' : 'pixel-panel'
        }`}
      >
        {hud.isNewRecord && (
          <div className="mb-1.5 font-pixel-display text-xs tracking-wider text-[#facc15]">
            NEW HIGH SCORE!
          </div>
        )}

        {isLehau ? (
          <>
            {/* Pixel-art Rainbow Hair NPC portrait */}
            <div className="mx-auto mb-3 flex justify-center">
              <svg
                width="56"
                height="56"
                viewBox="0 0 16 16"
                className="pixelated"
                aria-hidden="true"
              >
                {/* 7-color rainbow pixel hair */}
                <rect x="1" y="1" width="2" height="5" fill="#ef4444" />
                <rect x="3" y="0" width="2" height="6" fill="#f97316" />
                <rect x="5" y="0" width="2" height="5" fill="#facc15" />
                <rect x="7" y="0" width="2" height="5" fill="#22c55e" />
                <rect x="9" y="0" width="2" height="5" fill="#06b6d4" />
                <rect x="11" y="0" width="2" height="6" fill="#3b82f6" />
                <rect x="13" y="1" width="2" height="5" fill="#a855f7" />
                {/* Face */}
                <rect x="3" y="5" width="10" height="7" fill="#111827" />
                <rect x="4" y="6" width="8" height="5" fill="#ffd5b3" />
                {/* Eyes + cheeky smirk */}
                <rect x="5" y="7" width="2" height="2" fill="#111827" />
                <rect x="9" y="7" width="2" height="2" fill="#111827" />
                <rect x="5" y="7" width="1" height="1" fill="#ffffff" />
                <rect x="9" y="7" width="1" height="1" fill="#ffffff" />
                <rect x="7" y="10" width="3" height="1" fill="#be123c" />
                {/* Jacket shoulders */}
                <rect x="3" y="12" width="10" height="4" fill="#312e81" />
                <rect x="5" y="13" width="6" height="1" fill="#facc15" />
              </svg>
            </div>

            <h2
              id="gameover-title"
              className="font-pixel-ui text-xl sm:text-2xl font-bold leading-snug text-[#fef08a] drop-shadow-[0_3px_0_#09130c]"
            >
              BẠN ĐÃ BỊ LEHAU CHƠI TỪ ĐẰNG SAU
            </h2>
          </>
        ) : (
          <>
            <h2
              id="gameover-title"
              className="font-pixel-display text-2xl sm:text-3xl font-bold text-[#ef4444] drop-shadow-[0_2px_0_#09130c]"
            >
              GAME OVER
            </h2>
            <p className="mt-1 text-sm text-[#c6dec9]">Watch out for oncoming vehicles!</p>
          </>
        )}

        {/* Clean 2x2 tabular stats grid */}
        <div className="mt-5 grid grid-cols-2 gap-3 border-y-2 border-[#2a4734] py-4 text-left">
          <div className="bg-[#0e1c13] px-3 py-2.5 border border-[#2a4734]">
            <div className="text-[11px] uppercase tracking-wider text-[#9ec2a5]">Score</div>
            <div className="font-pixel-display text-xl text-[#f4f7ec] tabular-nums">
              {hud.score.toLocaleString()}
            </div>
          </div>

          <div className="bg-[#0e1c13] px-3 py-2.5 border border-[#2a4734]">
            <div className="text-[11px] uppercase tracking-wider text-[#9ec2a5]">Best</div>
            <div className="font-pixel-display text-xl text-[#facc15] tabular-nums">
              {hud.bestScore.toLocaleString()}
            </div>
          </div>

          <div className="bg-[#0e1c13] px-3 py-2.5 border border-[#2a4734]">
            <div className="text-[11px] uppercase tracking-wider text-[#9ec2a5]">MARAU</div>
            <div className="font-pixel-display text-lg text-[#86efac] tabular-nums">
              {hud.clovers}
            </div>
          </div>

          <div className="bg-[#0e1c13] px-3 py-2.5 border border-[#2a4734]">
            <div className="text-[11px] uppercase tracking-wider text-[#9ec2a5]">Survived</div>
            <div className="font-pixel-display text-lg text-[#f4f7ec] tabular-nums">
              {formatDuration(hud.elapsedSeconds)}
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onRestart}
            className="pixel-btn min-h-[48px] w-full bg-[#da251d] px-6 py-3 font-pixel-display text-base font-bold text-[#fef08a] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
          >
            RESTART
          </button>

          <button
            type="button"
            onClick={onTitle}
            className="pixel-btn min-h-[44px] w-full bg-[#1f2937] px-4 py-2.5 font-pixel-display text-sm font-bold text-[#c6dec9] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
          >
            Title Screen
          </button>
        </div>
      </div>
    </div>
  );
}
