import React, { useState } from 'react';
import { Trophy, RotateCcw, Share2, Check, Sparkles, Flame, Coins, Home, Play, Bomb } from 'lucide-react';
import { GameStats } from '../types';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHighScore: boolean;
  maxCombo: number;
  coinsEarned: number;
  feverScore: number;
  reason: 'wrong_color' | 'timeout' | 'bomb';
  stats: GameStats;
  onRestart: () => void;
  onHome: () => void;
  onWatchAd: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHighScore,
  maxCombo,
  coinsEarned,
  feverScore,
  reason,
  onRestart,
  onHome,
  onWatchAd,
}) => {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const text = `🎨 I scored ${score} in Color Rush! Highest combo: ${maxCombo}x streak. Can you beat me?`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Color Rush Score',
          text,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-200">
      <div className="flex w-full max-w-sm flex-col items-center rounded-3xl bg-slate-900 border border-slate-800 p-5 text-center shadow-2xl">
        {/* Banner Badge */}
        {isNewHighScore ? (
          <div className="mb-2 flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-1 text-xs font-black tracking-wide text-amber-300 border border-amber-500/40 animate-pulse">
            <Sparkles className="h-3.5 w-3.5 fill-amber-300" />
            <span>NEW HIGH SCORE!</span>
            <Sparkles className="h-3.5 w-3.5 fill-amber-300" />
          </div>
        ) : (
          <div className="mb-1.5 flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-rose-400">
            {reason === 'bomb' ? (
              <>
                <Bomb className="h-4 w-4 fill-rose-500/20" />
                <span>BOOM! YOU TAPPED A BOMB</span>
              </>
            ) : reason === 'wrong_color' ? (
              <span>WRONG COLOR TAPPED</span>
            ) : (
              <span>TIME'S UP!</span>
            )}
          </div>
        )}

        <h2 className="text-2xl font-black text-white">GAME OVER</h2>

        {/* Current Score Spotlight */}
        <div className="my-3 flex flex-col items-center justify-center rounded-2xl bg-slate-950/80 w-full py-3 border border-slate-800/80">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
            FINAL SCORE
          </span>
          <span className="font-mono text-5xl font-black tabular-nums tracking-tight text-white mt-0.5">
            {score}
          </span>
        </div>

        {/* Detailed Breakdown Grid 4-Stats */}
        <div className="grid grid-cols-2 gap-2 w-full mb-3">
          <div className="flex flex-col items-center rounded-xl bg-slate-800/60 p-2 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 text-[10px] font-bold">
              <Trophy className="h-3 w-3 fill-amber-400" />
              <span>BEST SCORE</span>
            </div>
            <span className="font-mono text-lg font-black text-amber-300 tabular-nums">
              {highScore}
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-800/60 p-2 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 text-[10px] font-bold">
              <Coins className="h-3 w-3 fill-amber-400/20" />
              <span>COINS EARNED</span>
            </div>
            <span className="font-mono text-lg font-black text-amber-300 tabular-nums">
              +{coinsEarned}
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-800/60 p-2 border border-slate-800">
            <div className="flex items-center gap-1 text-rose-400 text-[10px] font-bold">
              <Flame className="h-3 w-3 fill-rose-400" />
              <span>MAX COMBO</span>
            </div>
            <span className="font-mono text-lg font-black text-white tabular-nums">
              {maxCombo}x
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-800/60 p-2 border border-slate-800">
            <div className="flex items-center gap-1 text-orange-400 text-[10px] font-bold">
              <Sparkles className="h-3 w-3 fill-orange-400" />
              <span>FEVER BONUS</span>
            </div>
            <span className="font-mono text-lg font-black text-orange-300 tabular-nums">
              +{feverScore}
            </span>
          </div>
        </div>

        {/* Rewarded Ad Option: Earn +10 Coins */}
        <button
          onClick={onWatchAd}
          className="mb-3 flex h-10 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/40 text-xs font-bold text-amber-300 active:scale-95 hover:bg-amber-500/30 transition-all"
        >
          <Play className="h-3.5 w-3.5 fill-amber-300" />
          <span>Watch Ad (+10 Coins)</span>
        </button>

        {/* Action Buttons: Play Again, Home, Share */}
        <div className="flex flex-col gap-2 w-full">
          <button
            onClick={onRestart}
            className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 font-black text-sm text-white shadow-[0_4px_20px_rgba(16,185,129,0.35)] transition-all active:scale-95 hover:brightness-110"
          >
            <RotateCcw className="h-4 w-4" />
            <span>PLAY AGAIN</span>
          </button>

          <div className="grid grid-cols-2 gap-2 w-full">
            <button
              onClick={onHome}
              className="flex h-10 cursor-pointer items-center justify-center gap-1.5 rounded-xl bg-slate-800/80 font-bold text-xs text-slate-300 hover:text-white transition-all active:scale-95"
            >
              <Home className="h-4 w-4" />
              <span>HOME</span>
            </button>

            <button
              onClick={handleShare}
              className="flex h-10 cursor-pointer items-center justify-center gap-1.5 rounded-xl bg-slate-800/80 font-bold text-xs text-slate-300 hover:text-white transition-all active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Share2 className="h-4 w-4" />
                  <span>SHARE</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
