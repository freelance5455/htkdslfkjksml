/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RotateCcw, Home, Trophy, Sparkles } from 'lucide-react';
import { RunSummary } from '../types/game';

interface GameOverModalProps {
  summary: RunSummary;
  highScore: number;
  totalCoins: number;
  onRestart: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  summary,
  highScore,
  totalCoins,
  onRestart,
  onHome,
}) => {
  const isNewHigh = summary.score >= highScore && summary.score > 0;

  return (
    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-none flex items-center justify-center p-4 z-50 pointer-events-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl flex flex-col items-center">
        {/* Banner */}
        {isNewHigh ? (
          <div className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider mb-2 shadow-lg">
            <Sparkles className="w-4 h-4 fill-amber-950" />
            <span>NEW HIGH SCORE!</span>
          </div>
        ) : (
          <span className="text-xs font-bold uppercase tracking-widest text-rose-400 mb-1">
            CRASHED ON THE TRACKS!
          </span>
        )}

        <h2 className="text-4xl font-black text-white italic tracking-wider text-shadow-arcade mb-6">
          GAME OVER
        </h2>

        {/* Score Card */}
        <div className="w-full bg-slate-950/70 border border-slate-800 rounded-2xl p-4 mb-4 flex flex-col gap-3">
          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-xs uppercase font-bold text-slate-400">Final Score</span>
            <span className="text-2xl font-black text-white font-mono tabular-nums">
              {summary.score.toLocaleString()}
            </span>
          </div>

          <div className="flex justify-between items-center text-sm">
            <span className="text-slate-400 font-medium">Distance</span>
            <span className="font-mono font-bold text-cyan-400">{summary.distance}m</span>
          </div>

          <div className="flex justify-between items-center text-sm">
            <span className="text-slate-400 font-medium">Coins Collected</span>
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[10px] font-black text-amber-950">
                $
              </div>
              <span className="font-mono font-bold text-amber-300">+{summary.coins}</span>
            </div>
          </div>

          <div className="flex justify-between items-center text-sm pt-2 border-t border-slate-800">
            <span className="text-slate-400 font-medium flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-yellow-400" />
              All-Time Best
            </span>
            <span className="font-mono font-bold text-slate-200">
              {Math.max(highScore, summary.score).toLocaleString()}
            </span>
          </div>
        </div>

        {/* Total Bank Coins */}
        <div className="w-full flex justify-between items-center px-4 py-2 bg-slate-800/60 rounded-xl mb-6 text-xs font-semibold text-slate-300">
          <span>Total Coins in Vault</span>
          <span className="font-mono text-amber-300 font-bold">{totalCoins.toLocaleString()}</span>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={onRestart}
            className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white font-black text-lg tracking-wider rounded-xl shadow-lg border border-emerald-400/40 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            <span>RUN AGAIN</span>
          </button>

          <button
            onClick={onHome}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white font-bold text-sm rounded-xl border border-slate-700 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
