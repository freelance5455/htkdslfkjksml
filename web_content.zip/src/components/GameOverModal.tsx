import React from 'react';
import { RotateCcw, Clock, ShieldAlert } from 'lucide-react';
import { GameStats } from '../types/game';

interface GameOverModalProps {
  stats: GameStats;
  onRetry: () => void;
  onBackToMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  onRetry,
  onBackToMenu,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins}m ${secs}.${ms}s`;
  };

  return (
    <div className="absolute inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border-2 border-red-500/80 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl shadow-red-950/60 text-center flex flex-col items-center space-y-5 animate-in fade-in zoom-in-95 duration-200">
        {/* Chicken caught cartoon avatar */}
        <div className="relative">
          <div className="w-20 h-20 rounded-2xl bg-linear-to-tr from-red-600 to-amber-600 flex items-center justify-center shadow-xl shadow-red-600/40 border-2 border-white">
            <span className="text-4xl animate-bounce">🐔</span>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-slate-950 text-red-400 font-black text-xs px-2 py-0.5 rounded-full border border-red-500">
            BAWK!
          </div>
        </div>

        <div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight drop-shadow-md">
            CAUGHT BY A <span className="text-red-500">CHICKEN!</span>
          </h2>
          <p className="text-slate-300 font-medium text-xs sm:text-sm mt-1">
            A dangerous chicken cornered you before you could reach the portal.
          </p>
        </div>

        {/* Survival Run Stats */}
        <div className="w-full grid grid-cols-3 gap-2 bg-slate-950/60 rounded-2xl p-3 border border-slate-800">
          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <Clock className="w-4 h-4 text-amber-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">SURVIVED</span>
            <span className="font-mono-num font-bold text-white text-sm">
              {formatTime(stats.timeElapsed)}
            </span>
          </div>

          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <span className="text-sm mb-0.5">💎</span>
            <span className="text-[10px] uppercase font-bold text-slate-400">CRYSTALS</span>
            <span className="font-mono-num font-bold text-cyan-300 text-sm">
              {stats.crystalsCollected}/{stats.totalCrystals}
            </span>
          </div>

          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <ShieldAlert className="w-4 h-4 text-red-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">CHASES</span>
            <span className="font-mono-num font-bold text-amber-400 text-sm">
              {stats.chaseCount}
            </span>
          </div>
        </div>

        {/* Tip for next run */}
        <div className="text-xs text-amber-300/90 bg-amber-950/30 border border-amber-800/40 rounded-xl p-2.5 w-full text-left">
          💡 <strong>Survival Tip:</strong> Find the 3 crystals in the outer corners to unlock the central portal! Dive into <strong>real bushes</strong> to lose pursuing chickens.
        </div>

        {/* Retry & Menu buttons */}
        <div className="w-full flex flex-col space-y-2.5">
          <button
            onClick={onRetry}
            className="w-full py-3.5 px-6 rounded-2xl bg-linear-to-r from-red-500 via-orange-500 to-amber-500 hover:from-red-400 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-lg shadow-xl shadow-red-500/40 border-2 border-white flex items-center justify-center space-x-2 transition cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            <span>RETRY</span>
          </button>

          <button
            onClick={onBackToMenu}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-sm transition"
          >
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
