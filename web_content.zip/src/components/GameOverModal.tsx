import React from 'react';
import { PlayerStats } from '../game/player/PlayerController';
import { RotateCcw, Home, Skull, Target, Award } from 'lucide-react';
import { sound } from '../audio/SoundEngine';

interface GameOverModalProps {
  stats: PlayerStats;
  wave: number;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  wave,
  onRestart,
  onMainMenu,
}) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-lg flex items-center justify-center p-6 select-none animate-fade-in">
      <div className="relative w-full max-w-md bg-zinc-950 border-2 border-red-700/80 rounded-2xl p-8 flex flex-col items-center text-center shadow-2xl shadow-red-950/60">
        {/* Skull Icon badge */}
        <div className="w-20 h-20 rounded-full bg-red-950/80 border-2 border-red-500 flex items-center justify-center mb-4 shadow-xl shadow-red-600/40">
          <Skull className="w-12 h-12 text-red-500 animate-pulse" />
        </div>

        <span className="text-red-500 font-mono-tech text-xs tracking-widest uppercase">
          OPERATIONAL CASUALTY // SECTOR 07
        </span>
        <h2 className="text-6xl font-teko uppercase font-extrabold text-white tracking-wide leading-none mt-1 mb-6">
          YOU <span className="text-red-600">DIED</span>
        </h2>

        {/* Combat Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 mb-8">
          <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col items-center">
            <Award className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-xs font-mono-tech text-zinc-400">SURVIVED</span>
            <span className="text-3xl font-teko font-bold text-white leading-none mt-0.5">
              WAVE {wave}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col items-center">
            <Skull className="w-5 h-5 text-red-400 mb-1" />
            <span className="text-xs font-mono-tech text-zinc-400">ELIMINATIONS</span>
            <span className="text-3xl font-teko font-bold text-white leading-none mt-0.5">
              {stats.kills}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col items-center">
            <Target className="w-5 h-5 text-cyan-400 mb-1" />
            <span className="text-xs font-mono-tech text-zinc-400">HEADSHOTS</span>
            <span className="text-3xl font-teko font-bold text-white leading-none mt-0.5">
              {stats.headshots}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col items-center">
            <span className="text-emerald-400 font-teko text-xl leading-none mb-1 font-bold">$</span>
            <span className="text-xs font-mono-tech text-zinc-400">FINAL SCORE</span>
            <span className="text-3xl font-teko font-bold text-emerald-400 leading-none mt-0.5">
              ${stats.points}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="w-full flex flex-col gap-3">
          <button
            onClick={() => {
              sound.playUIClick();
              onRestart();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-2xl tracking-wider uppercase font-bold rounded-xl shadow-xl shadow-red-600/40 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <RotateCcw className="w-5 h-5" />
            <span>PLAY AGAIN</span>
          </button>

          <button
            onClick={() => {
              sound.playUIClick();
              onMainMenu();
            }}
            className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-semibold rounded-xl border border-zinc-800 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
