/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Skull, RotateCcw, Home, Sparkles } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  kills: number;
  onRestart: () => void;
  onQuitToTitle: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  kills,
  onRestart,
  onQuitToTitle,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0e090a] border-2 border-red-600/70 rounded-3xl max-w-md w-full p-6 sm:p-8 text-slate-100 shadow-[0_0_60px_rgba(239,68,68,0.4)] text-center relative overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Skull Icon */}
        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-red-950 to-red-900 border-2 border-red-500 flex items-center justify-center shadow-lg shadow-red-950/80 animate-pulse">
          <Skull className="w-10 h-10 text-red-400" />
        </div>

        <div className="text-xs font-mono text-red-500 font-bold uppercase tracking-widest mb-1">
          SURVIVOR OVERWHELMED
        </div>
        <h2 className="text-3xl font-black tracking-tight text-white uppercase drop-shadow">
          YOU DIED
        </h2>

        {/* Creator Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mt-2 mb-6 rounded-full bg-slate-950 border border-slate-800 text-xs text-slate-400">
          <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
          <span>DEADZONE: OUTBREAK · BY REHANX</span>
        </div>

        {/* Performance stats */}
        <div className="grid grid-cols-2 gap-3 mb-6 font-mono text-left">
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest">
              INFECTED KILLED
            </div>
            <div className="text-2xl font-black text-white tabular-nums mt-0.5">{kills}</div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest">
              TOTAL SCORE
            </div>
            <div className="text-2xl font-black text-red-400 tabular-nums mt-0.5">{score}</div>
          </div>
        </div>

        {/* CTAs */}
        <div className="space-y-2.5">
          <button
            onClick={onRestart}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-900/50"
          >
            <RotateCcw className="w-4 h-4 text-white" />
            <span>RESPAWN / TRY AGAIN</span>
          </button>

          <button
            onClick={onQuitToTitle}
            className="w-full py-3 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>RETURN TO TITLE SCREEN</span>
          </button>
        </div>
      </div>
    </div>
  );
};
