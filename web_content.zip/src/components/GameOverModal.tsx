import React from 'react';
import { Trophy, Skull, Crosshair, Shield, Clock, Flame, RotateCcw } from 'lucide-react';
import { GameStats } from '../game/types';

interface GameOverModalProps {
  stats: GameStats;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ stats, onRestart }) => {
  const minutes = Math.floor(stats.survivalTime / 60);
  const seconds = stats.survivalTime % 60;
  const timeFormatted = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  const accuracy = stats.shotsFired > 0 ? Math.round((stats.shotsHit / stats.shotsFired) * 100) : 0;

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 select-none">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500/80 rounded-3xl p-6 md:p-8 shadow-[0_0_50px_rgba(245,158,11,0.4)] flex flex-col items-center text-center">
        {/* Banner Header */}
        {stats.isVictory ? (
          <div className="flex flex-col items-center mb-6">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <Trophy className="w-8 h-8 text-amber-400" />
              <span className="font-mono text-xs uppercase tracking-widest font-bold">
                CHAMPION OF BERMUDA
              </span>
            </div>

            {/* Giant Free Fire BOOYAH! title */}
            <h1 className="text-6xl md:text-7xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-400 to-red-500 filter drop-shadow-[0_4px_12px_rgba(245,158,11,0.8)]">
              BOOYAH!
            </h1>
            <p className="text-amber-200 text-sm font-semibold mt-1">
              Zabardast Bhai! Aapne akele sab ko eliminate kiya!
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center mb-6">
            <div className="text-red-500 font-mono text-xs uppercase tracking-widest font-bold mb-1">
              BETTER LUCK NEXT TIME
            </div>
            <h1 className="text-5xl font-black text-red-500 tracking-wide filter drop-shadow-[0_4px_12px_rgba(239,68,68,0.5)]">
              DEFEATED
            </h1>
            <p className="text-slate-400 text-sm mt-1">
              Koi baat nahi bhai, agli baar BOOYAH pakka!
            </p>
          </div>
        )}

        {/* Rank Placement Badge */}
        <div className="mb-6 bg-slate-800/80 border border-slate-700 px-6 py-2 rounded-2xl flex items-center gap-3">
          <span className="text-xs uppercase font-bold text-slate-400">Match Rank:</span>
          <span
            className={`text-2xl font-black ${
              stats.isVictory ? 'text-amber-400' : 'text-slate-200'
            }`}
          >
            #{stats.rank} <span className="text-xs text-slate-500 font-normal">/ {stats.totalPlayers}</span>
          </span>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full mb-8">
          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Skull className="w-5 h-5 text-red-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Eliminations</span>
            <span className="text-xl font-black text-white">{stats.kills}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Flame className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Total Damage</span>
            <span className="text-xl font-black text-white">{stats.damageDealt}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Crosshair className="w-5 h-5 text-purple-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Headshots</span>
            <span className="text-xl font-black text-white">{stats.headshots}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Clock className="w-5 h-5 text-blue-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Survival Time</span>
            <span className="text-xl font-black text-white">{timeFormatted}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Shield className="w-5 h-5 text-cyan-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Gloo Walls</span>
            <span className="text-xl font-black text-white">{stats.gloowallsPlaced}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl flex flex-col items-center">
            <Crosshair className="w-5 h-5 text-emerald-400 mb-1" />
            <span className="text-[10px] uppercase font-bold text-slate-400">Accuracy</span>
            <span className="text-xl font-black text-white">{accuracy}%</span>
          </div>
        </div>

        {/* Play Again Button */}
        <button
          onClick={onRestart}
          className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-lg rounded-2xl tracking-wider uppercase shadow-[0_0_25px_rgba(245,158,11,0.5)] cursor-pointer flex items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <RotateCcw className="w-5 h-5" />
          <span>PLAY AGAIN</span>
        </button>
      </div>
    </div>
  );
};
