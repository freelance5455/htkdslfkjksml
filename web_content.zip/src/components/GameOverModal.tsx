/**
 * SPR - Sahil Powerful Run
 * Game Over Summary Modal
 */

import React from 'react';
import { RotateCcw, Home, Trophy, Sparkles, Award } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  finalScore: number;
  distance: number;
  coinsEarned: number;
  isNewHigh: boolean;
  highScore: number;
  onRestart: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<Props> = ({
  finalScore,
  distance,
  coinsEarned,
  isNewHigh,
  highScore,
  onRestart,
  onHome,
}) => {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-slate-950 to-black border-2 border-red-500/50 rounded-3xl shadow-[0_0_50px_rgba(239,68,68,0.35)] p-5 sm:p-6 flex flex-col gap-4 text-center overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Banner */}
        <div className="flex flex-col items-center">
          <span className="text-xs font-bold text-red-400 tracking-[0.3em] uppercase mb-1">
            RUN TERMINATED
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-orange-400 to-amber-400 font-heading">
            GAME OVER
          </h2>
          {isNewHigh && (
            <div className="mt-2 flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 border border-amber-400 rounded-full text-amber-300 font-extrabold text-xs tracking-wider animate-bounce">
              <Award className="w-4 h-4" />
              NEW HIGH SCORE RECORD!
            </div>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-1">
          {/* Final Score */}
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              FINAL SCORE
            </span>
            <span className="text-2xl sm:text-3xl font-black text-white font-display">
              {finalScore.toLocaleString()}
            </span>
          </div>

          {/* Highest Score */}
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              HIGHEST SCORE
            </span>
            <span className="text-2xl sm:text-3xl font-black text-amber-400 font-display">
              {Math.max(highScore, finalScore).toLocaleString()}
            </span>
          </div>

          {/* Coins Earned */}
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              COINS EARNED
            </span>
            <div className="flex items-center justify-center gap-1 text-2xl sm:text-3xl font-black text-yellow-300 font-display">
              <span>🪙</span>
              <span>+{coinsEarned.toLocaleString()}</span>
            </div>
          </div>

          {/* Distance */}
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              DISTANCE COVERED
            </span>
            <span className="text-2xl sm:text-3xl font-black text-cyan-300 font-display">
              {distance}m
            </span>
          </div>
        </div>

        {/* Action Buttons: RESTART & HOME */}
        <div className="flex flex-col gap-2.5 mt-2">
          <button
            id="gameover-btn-restart"
            onClick={() => {
              soundManager.playButtonClick();
              onRestart();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 hover:from-orange-500 hover:to-amber-400 text-slate-950 font-black text-lg uppercase tracking-widest rounded-xl transition shadow-[0_0_25px_rgba(249,115,22,0.5)] active:scale-98 flex items-center justify-center gap-2 cursor-pointer font-display"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            RUN AGAIN (RESTART)
          </button>

          <button
            id="gameover-btn-home"
            onClick={() => {
              soundManager.playButtonClick();
              onHome();
            }}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-sm uppercase tracking-wider rounded-xl transition active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            RETURN TO MENU
          </button>
        </div>
      </div>
    </div>
  );
};
