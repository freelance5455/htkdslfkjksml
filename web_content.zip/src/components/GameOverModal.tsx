import React from 'react';
import { RotateCcw, Skull, Trophy, Target, ShieldAlert } from 'lucide-react';

interface GameOverModalProps {
  isOpen: boolean;
  wave: number;
  kills: number;
  score: number;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  wave,
  kills,
  score,
  onRestart,
  onMainMenu,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="gameover-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-300 select-none text-zinc-100"
    >
      <div
        id="gameover-card"
        className="relative w-full max-w-md bg-zinc-900 border border-red-900/60 rounded-2xl shadow-2xl p-6 text-center overflow-hidden"
      >
        {/* Decorative skull */}
        <div className="mx-auto w-16 h-16 rounded-full bg-red-600/20 border-2 border-red-500/50 flex items-center justify-center mb-4 text-red-500 animate-bounce">
          <Skull className="w-8 h-8" />
        </div>

        <h2 className="text-3xl font-display font-bold uppercase tracking-wider text-red-500">
          Oʻyin Tugadi!
        </h2>
        <p className="text-xs text-zinc-400 mt-1 mb-6">
          Baza zoʻmbilar toʻdasi tomonidan bosib olindi yoki mudofaa chizigʻi yorib oʻtildi.
        </p>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-6">
          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800">
            <div className="flex justify-center text-amber-400 mb-1">
              <Trophy className="w-4 h-4" />
            </div>
            <div className="text-[10px] text-zinc-400 uppercase">Toʻlqin</div>
            <div className="text-xl font-bold text-white font-mono">{wave}</div>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800">
            <div className="flex justify-center text-red-400 mb-1">
              <Target className="w-4 h-4" />
            </div>
            <div className="text-[10px] text-zinc-400 uppercase">Oʻldirildi</div>
            <div className="text-xl font-bold text-white font-mono">{kills}</div>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800">
            <div className="flex justify-center text-yellow-400 mb-1">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div className="text-[10px] text-zinc-400 uppercase">Ball</div>
            <div className="text-xl font-bold text-white font-mono">{score}</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            id="restart-game-btn"
            onClick={onRestart}
            className="flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold font-display text-lg uppercase tracking-wider shadow-lg shadow-red-950/60 transition active:scale-95"
          >
            <RotateCcw className="w-5 h-5" />
            Qayta Oʻynash
          </button>

          <button
            id="main-menu-btn"
            onClick={onMainMenu}
            className="py-2.5 px-6 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs uppercase tracking-wider transition"
          >
            Bosh Menyu
          </button>
        </div>
      </div>
    </div>
  );
};
