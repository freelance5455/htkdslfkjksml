import React from 'react';
import { GameEngine } from '../game/engine';
import { RotateCcw, Skull, Sun, Trees, Swords, Hammer, Tent } from 'lucide-react';

interface GameOverModalProps {
  engine: GameEngine;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ engine, onRestart }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-md bg-neutral-950 border-2 border-red-700 rounded-2xl shadow-2xl p-6 text-white flex flex-col items-center gap-5 text-center">
        {/* Skull Icon */}
        <div className="w-16 h-16 rounded-full bg-red-950/60 border-2 border-red-500 flex items-center justify-center shadow-lg shadow-red-600/30 animate-pulse text-red-400">
          <Skull className="w-8 h-8 text-red-500" />
        </div>

        <div className="flex flex-col gap-1">
          <h2 className="text-xl sm:text-2xl font-black text-red-500 font-['Press_Start_2P',monospace] tracking-tight">
            GAME OVER
          </h2>
          <span className="text-sm font-bold text-neutral-300">سقطت في البرية — انتهى اليوم الأخير</span>
        </div>

        {/* Survival Stats Card */}
        <div className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-4 flex flex-col gap-2.5 text-xs text-neutral-300">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="font-bold text-amber-400 flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>الأيام التي صمدت فيها:</span>
            </span>
            <span className="font-mono text-sm font-bold text-white">{engine.stats.daysSurvived}</span>
          </div>
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="flex items-center gap-1.5">
              <Trees className="w-3.5 h-3.5 text-emerald-400" />
              <span>الموارد المجمعة:</span>
            </span>
            <span className="font-mono text-sm font-bold text-white">{engine.stats.resourcesCollected}</span>
          </div>
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="flex items-center gap-1.5">
              <Swords className="w-3.5 h-3.5 text-red-400" />
              <span>الأعداء والوحوش المهزومة:</span>
            </span>
            <span className="font-mono text-sm font-bold text-white">{engine.stats.enemiesDefeated}</span>
          </div>
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="flex items-center gap-1.5">
              <Hammer className="w-3.5 h-3.5 text-cyan-400" />
              <span>الأدوات والمواد المصنوعة:</span>
            </span>
            <span className="font-mono text-sm font-bold text-white">{engine.stats.itemsCrafted}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Tent className="w-3.5 h-3.5 text-amber-300" />
              <span>الهياكل والمباني المشيدة:</span>
            </span>
            <span className="font-mono text-sm font-bold text-white">{engine.stats.structuresBuilt}</span>
          </div>
        </div>

        {/* Restart Button */}
        <button
          id="btn-restart-game"
          onClick={onRestart}
          className="w-full py-3.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 active:scale-95 text-white font-black text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-xl cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>بدء محاولة جديدة للبقاء</span>
        </button>
      </div>
    </div>
  );
};
