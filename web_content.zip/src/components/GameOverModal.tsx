import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Home, Award, Trophy } from 'lucide-react';
import { CarModel, TrackConfig } from '../types.ts';
import { saveHighScore } from '../utils/storage.ts';

interface GameOverModalProps {
  score: number;
  highScore: number;
  distanceKm: number;
  topSpeedKmh: number;
  powerupsCount: number;
  car: CarModel;
  track: TrackConfig;
  onRestart: () => void;
  onGoToMenu: () => void;
  onShowLeaderboard: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  distanceKm,
  topSpeedKmh,
  powerupsCount,
  car,
  track,
  onRestart,
  onGoToMenu,
  onShowLeaderboard
}) => {
  const [playerName, setPlayerName] = useState('CHAMSOU');
  const [isSaved, setIsSaved] = useState(false);
  const isNewHighScore = score > highScore && score > 0;

  useEffect(() => {
    if (isNewHighScore) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore
      }
    }
  }, [isNewHighScore]);

  const handleSaveScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim() || isSaved) return;
    saveHighScore(playerName, score, car.name, track.id, distanceKm);
    setIsSaved(true);
  };

  return (
    <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-30 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-gradient-to-b from-[#2a0418] via-[#1a0011] to-black border-4 border-rose-600 rounded-3xl p-6 text-white text-center shadow-2xl relative overflow-hidden">
        {/* Glow corner accents */}
        <div className="absolute -top-12 -left-12 w-28 h-28 bg-rose-600/30 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-28 h-28 bg-amber-600/30 rounded-full blur-2xl pointer-events-none" />

        {/* Title */}
        <div className="text-4xl sm:text-5xl font-black font-press-start text-rose-500 mb-1 arcade-text-red">
          GAME OVER
        </div>
        <p className="text-amber-400 font-bold font-cairo text-sm mb-4">
          💥 انتهى السباق.. قدر الله وما شاء فعل! 💥
        </p>

        {/* New High Score Alert */}
        {isNewHighScore && (
          <div className="bg-amber-500/20 border-2 border-amber-400 rounded-2xl p-2.5 mb-4 flex items-center justify-center gap-2 animate-bounce">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span className="text-amber-300 font-bold text-xs font-press-start">NEW HIGH SCORE!</span>
          </div>
        )}

        {/* Run Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 bg-black/60 border border-white/10 rounded-2xl p-3.5 mb-4 text-xs font-mono">
          <div className="flex flex-col items-center p-2 bg-white/5 rounded-xl">
            <span className="text-gray-400 font-cairo text-[11px]">النتيجة النهائية</span>
            <span className="text-2xl font-black text-amber-400 font-press-start mt-1">{score}</span>
          </div>

          <div className="flex flex-col items-center p-2 bg-white/5 rounded-xl">
            <span className="text-gray-400 font-cairo text-[11px]">المسافة المقطوعة</span>
            <span className="text-xl font-bold text-emerald-400 mt-1">{distanceKm.toFixed(1)} KM</span>
          </div>

          <div className="flex flex-col items-center p-2 bg-white/5 rounded-xl">
            <span className="text-gray-400 font-cairo text-[11px]">أعلى سرعة</span>
            <span className="text-lg font-bold text-cyan-400 mt-1">{topSpeedKmh} KM/H</span>
          </div>

          <div className="flex flex-col items-center p-2 bg-white/5 rounded-xl">
            <span className="text-gray-400 font-cairo text-[11px]">مكافآت مجمّعة</span>
            <span className="text-lg font-bold text-rose-400 mt-1">{powerupsCount}</span>
          </div>
        </div>

        {/* Car and Track info */}
        <div className="flex justify-between items-center text-[11px] text-gray-300 font-cairo px-2 mb-4 border-b border-white/10 pb-3">
          <span>السيارة: <strong className="text-amber-300 font-mono">{car.name}</strong></span>
          <span>المسار: <strong className="text-amber-300">{track.name}</strong></span>
        </div>

        {/* Save High Score Form */}
        <form onSubmit={handleSaveScore} className="mb-5 flex gap-2">
          <input
            type="text"
            maxLength={12}
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            disabled={isSaved}
            placeholder="أدخل اسمك"
            className="flex-1 bg-black/70 border-2 border-amber-500/60 rounded-xl px-3 py-2 text-center text-sm font-bold font-mono text-amber-300 focus:outline-none focus:border-amber-400 uppercase"
          />
          <button
            type="submit"
            disabled={isSaved || !playerName.trim()}
            className={`px-4 py-2 rounded-xl font-bold text-xs font-cairo flex items-center gap-1.5 transition-colors ${
              isSaved
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-amber-500 hover:bg-amber-400 text-black active:scale-95 cursor-pointer'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>{isSaved ? 'تم الحفظ!' : 'حفظ النتيجة'}</span>
          </button>
        </form>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={onRestart}
            className="flex-1 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-press-start text-xs sm:text-sm py-3.5 px-4 rounded-xl border-2 border-amber-300 flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
          >
            <RotateCcw className="w-4 h-4" />
            <span>إعادة اللعب</span>
          </button>

          <button
            onClick={onShowLeaderboard}
            className="bg-black/80 hover:bg-gray-800 text-amber-400 border border-amber-500/50 rounded-xl px-4 py-3 flex items-center justify-center gap-1.5 text-xs font-cairo font-bold active:scale-95 transition-transform"
          >
            <Trophy className="w-4 h-4" />
            <span>قائمة الشرف</span>
          </button>

          <button
            onClick={onGoToMenu}
            className="bg-black/80 hover:bg-gray-800 text-white border border-gray-600 rounded-xl px-4 py-3 flex items-center justify-center gap-1.5 text-xs font-cairo font-bold active:scale-95 transition-transform"
          >
            <Home className="w-4 h-4" />
            <span>القائمة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
