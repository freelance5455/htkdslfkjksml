import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { soundEngine } from '../audio/soundEngine';
import { STADIUMS, resolveClubKit } from '../data/clubs';
import {
  CameraPreset,
  Club,
  Difficulty,
  Formation,
  HairStyle,
  Language,
  MatchConfig,
  MatchStats,
  WeatherType,
} from '../types/game';

export interface MatchInputState {
  moveX: number;
  moveZ: number;
  sprint: boolean;
  passJustPressed: boolean;
  shootJustPressed: boolean;
  crossJustPressed: boolean;
}

export interface LiveHudSnapshot {
  homeScore: number;
  awayScore: number;
  matchMinute: number;
  addedMinutes: number;
  half: 1 | 2;
  phase: 'kickoff' | 'playing' | 'goal' | 'halftime' | 'fulltime';
  goalTeam: 'home' | 'away' | null;
  goalScorer: string;
  activePlayerName: string;
  activePlayerPos: string;
  activePlayerOvr: number;
  activePlayerStamina: number;
  hasBall: boolean;
  radarPlayers: Array<{ x: number; z: number; team: 'home' | 'away'; active: boolean }>;
  radarBall: { x: number; z: number };
}

interface MatchCanvasProps {
  mode: 'showcase' | 'match';
  homeClub: Club;
  awayClub: Club;
  matchConfig: MatchConfig;
  paused: boolean;
  cameraPreset: CameraPreset;
  language: Language;
  inputRef: React.MutableRefObject<MatchInputState>;
  onHudUpdate: (snapshot: LiveHudSnapshot) => void;
  onMatchFinish: (stats: MatchStats) => void;
}

// Pitch dimensions (FIFA-proportioned scaled units)
const PITCH_W = 92; // X axis (-46 to +46)
const PITCH_H = 58; // Z axis (-29 to +29)
const HALF_W = PITCH_W / 2; // 46
const HALF_H = PITCH_H / 2; // 29
const GOAL_W = 8.4; // Z (-4.2 to +4.2)
const GOAL_H = 2.9;
const GOAL_D = 2.6;
const BALL_R = 0.34;

// Pre-allocated scratch vectors (Zero-GC in animation loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camLook = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2') || c.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createPitchTexture(turfHex: string, isWet: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1280;
  const ctx = canvas.getContext('2d')!;

  const base = new THREE.Color(turfHex);
  const darkGrass = base.clone().multiplyScalar(isWet ? 0.78 : 0.9).getStyle();
  const lightGrass = base.clone().multiplyScalar(isWet ? 0.94 : 1.08).getStyle();

  const stripes = 18;
  const stripeW = canvas.width / stripes;
  for (let i = 0; i < stripes; i++) {
    ctx.fillStyle = i % 2 === 0 ? darkGrass : lightGrass;
    ctx.fillRect(i * stripeW, 0, stripeW + 1, canvas.height);
  }

  // Subtle organic turf grain
  ctx.fillStyle = 'rgba(255,255,255,0.015)';
  for (let i = 0; i < 4500; i++) {
    ctx.fillRect(Math.random() * canvas.width, Math.random() * canvas.height, 3, 2);
  }

  // Crisp white pitch lines
  const padX = 76;
  const padY = 64;
  const fw = canvas.width - padX * 2;
  const fh = canvas.height - padY * 2;
  const midX = canvas.width / 2;
  const midY = canvas.height / 2;

  ctx.strokeStyle = 'rgba(248, 250, 252, 0.9)';
  ctx.lineWidth = 7;

  // Outer touchlines
  ctx.strokeRect(padX, padY, fw, fh);
  // Halfway line
  ctx.beginPath();
  ctx.moveTo(midX, padY);
  ctx.lineTo(midX, padY + fh);
  ctx.stroke();

  // Center circle & spot
  ctx.beginPath();
  ctx.arc(midX, midY, 155, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(midX, midY, 10, 0, Math.PI * 2);
  ctx.fill();

  // Left penalty box & 6-yard box
  const penW = 285;
  const penH = 660;
  const sixW = 100;
  const sixH = 310;

  ctx.strokeRect(padX, midY - penH / 2, penW, penH);
  ctx.strokeRect(padX, midY - sixH / 2, sixW, sixH);
  ctx.beginPath();
  ctx.arc(padX + 195, midY, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(padX + 195, midY, 140, -0.68, 0.68);
  ctx.stroke();

  // Right penalty box & 6-yard box
  ctx.strokeRect(padX + fw - penW, midY - penH / 2, penW, penH);
  ctx.strokeRect(padX + fw - sixW, midY - sixH / 2, sixW, sixH);
  ctx.beginPath();
  ctx.arc(padX + fw - 195, midY, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(padX + fw - 195, midY, 140, Math.PI - 0.68, Math.PI + 0.68);
  ctx.stroke();

  // Corner arcs
  const cr = 34;
  ctx.beginPath();
  ctx.arc(padX, padY, cr, 0, Math.PI / 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX + fw, padY, cr, Math.PI / 2, Math.PI);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX + fw, padY + fh, cr, Math.PI, Math.PI * 1.5);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX, padY + fh, cr, Math.PI * 1.5, Math.PI * 2);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createBallTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#F8FAFC';
  ctx.fillRect(0, 0, 512, 256);

  // FC 27 Match Ball modern panels
  ctx.strokeStyle = '#0F172A';
  ctx.lineWidth = 4;
  for (let x = 0; x < 512; x += 64) {
    for (let y = 0; y < 256; y += 64) {
      ctx.fillStyle = (x / 64 + y / 64) % 2 === 0 ? '#0F172A' : '#F5C451';
      ctx.beginPath();
      ctx.arc(x + 32, y + 32, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeRect(x, y, 64, 64);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createNetTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.strokeStyle = 'rgba(241, 245, 249, 0.85)';
  ctx.lineWidth = 3;
  for (let i = 0; i <= 128; i += 16) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 128);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(128, i);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 3);
  return tex;
}

function createJerseyTexture(primary: string, secondary: string, pattern: Club['pattern']): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = primary;
  ctx.fillRect(0, 0, 256, 256);

  ctx.fillStyle = secondary;
  if (pattern === 'stripes') {
    for (let x = 0; x < 256; x += 48) ctx.fillRect(x, 0, 22, 256);
  } else if (pattern === 'halves') {
    ctx.fillRect(128, 0, 128, 256);
  } else if (pattern === 'sash') {
    ctx.beginPath();
    ctx.moveTo(0, 220);
    ctx.lineTo(220, 0);
    ctx.lineTo(256, 36);
    ctx.lineTo(36, 256);
    ctx.closePath();
    ctx.fill();
  } else if (pattern === 'cross') {
    ctx.fillRect(108, 0, 40, 256);
    ctx.fillRect(0, 96, 256, 40);
  } else if (pattern === 'chevron') {
    ctx.beginPath();
    ctx.moveTo(0, 60);
    ctx.lineTo(128, 140);
    ctx.lineTo(256, 60);
    ctx.lineTo(256, 105);
    ctx.lineTo(128, 185);
    ctx.lineTo(0, 105);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillRect(0, 0, 256, 28);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createNumberBadgeTexture(num: number, textColor: string, outlineColor: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.font = '800 84px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 8;
  ctx.strokeStyle = outlineColor;
  ctx.strokeText(String(num), 64, 68);
  ctx.fillStyle = textColor;
  ctx.fillText(String(num), 64, 68);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function getContrastHex(hex: string): string {
  const c = hex.replace('#', '');
  if (c.length !== 6) return '#F8FAFC';
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.62 ? '#0F172A' : '#F8FAFC';
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0,0,0,0.55)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

function createLedBoardTexture(homeAbbr: string, awayAbbr: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, 1024, 96);

  ctx.fillStyle = '#F5C451';
  ctx.fillRect(0, 0, 1024, 6);
  ctx.fillRect(0, 90, 1024, 6);

  ctx.font = '800 40px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText(`ARENA FOOTBALL   ·   ${homeAbbr} vs ${awayAbbr}   ·   CHAMPIONS SERIES   ·   ULTIMATE MATCH`, 512, 50);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.repeat.set(3, 1);
  return tex;
}

function getFormationOffsets(formation: Formation): Array<[number, number]> {
  // Normalized coordinates for home side attacking +X: x in [-0.95..-0.05], z in [-0.85..+0.85]
  if (formation === '4-4-2') {
    return [
      [-0.95, 0], // GOL
      [-0.70, -0.68], [-0.73, -0.24], [-0.73, 0.24], [-0.70, 0.68], // 4 ZAG
      [-0.45, -0.65], [-0.48, -0.22], [-0.48, 0.22], [-0.45, 0.65], // 4 MEI/VOL
      [-0.18, -0.24], [-0.18, 0.24], // 2 ATA
    ];
  }
  if (formation === '3-5-2') {
    return [
      [-0.95, 0],
      [-0.73, -0.50], [-0.76, 0], [-0.73, 0.50], // 3 ZAG
      [-0.46, -0.74], [-0.52, -0.28], [-0.40, 0], [-0.52, 0.28], [-0.46, 0.74], // 5 MID
      [-0.18, -0.24], [-0.18, 0.24], // 2 ATA
    ];
  }
  // Default 4-3-3
  return [
    [-0.95, 0],
    [-0.70, -0.68], [-0.74, -0.24], [-0.74, 0.24], [-0.70, 0.68],
    [-0.46, -0.45], [-0.52, 0], [-0.46, 0.45],
    [-0.18, -0.60], [-0.14, 0], [-0.18, 0.60],
  ];
}

interface SimPlayer {
  id: string;
  name: string;
  pos: string;
  ovr: number;
  pac: number;
  sho: number;
  pas: number;
  def: number;
  team: 'home' | 'away';
  isGk: boolean;
  homeX: number;
  homeZ: number;
  x: number;
  z: number;
  vx: number;
  vz: number;
  facing: number;
  stamina: number;
  runCycle: number;
  kickAnim: number;
  diveAnim: number;
  mesh: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
}

export const MatchCanvas: React.FC<MatchCanvasProps> = ({
  mode,
  homeClub,
  awayClub,
  matchConfig,
  paused,
  cameraPreset,
  language,
  inputRef,
  onHudUpdate,
  onMatchFinish,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Mutable refs so the Three.js loop never restarts on React prop updates
  const modeRef = useRef(mode);
  const pausedRef = useRef(paused);
  const cameraPresetRef = useRef(cameraPreset);
  const languageRef = useRef(language);
  const matchConfigRef = useRef(matchConfig);
  const clubsRef = useRef({ home: homeClub, away: awayClub });
  const callbacksRef = useRef({ onHudUpdate, onMatchFinish });

  modeRef.current = mode;
  pausedRef.current = paused;
  cameraPresetRef.current = cameraPreset;
  languageRef.current = language;
  matchConfigRef.current = matchConfig;
  clubsRef.current = { home: homeClub, away: awayClub };
  callbacksRef.current = { onHudUpdate, onMatchFinish };

  // Trigger reset when entering a new match or changing matchConfig / club kits / players
  const matchVersionRef = useRef(0);
  const lastMatchKeyRef = useRef('');
  const homeKitSig = JSON.stringify(resolveClubKit(homeClub, matchConfig.homeKitVariant ?? 'home'));
  const awayKitSig = JSON.stringify(resolveClubKit(awayClub, matchConfig.awayKitVariant ?? 'away'));
  const rosterSig = `${homeClub.players.map((p) => `${p.number}:${p.hairStyle || ''}:${p.hairColor || ''}`).join(',')}|${awayClub.players.map((p) => `${p.number}:${p.hairStyle || ''}:${p.hairColor || ''}`).join(',')}`;
  const currentMatchKey = `${mode}:${matchConfig.homeClubId}:${matchConfig.awayClubId}:${matchConfig.homeKitVariant || 'home'}:${matchConfig.awayKitVariant || 'away'}:${matchConfig.stadiumId}:${matchConfig.weather}:${matchConfig.durationMinutes}:${matchConfig.formation}:${matchConfig.difficulty}:${matchConfig.careerMatchId || ''}:${homeKitSig}:${awayKitSig}:${rosterSig}`;
  if (currentMatchKey !== lastMatchKeyRef.current) {
    lastMatchKeyRef.current = currentMatchKey;
    matchVersionRef.current += 1;
  }

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      46,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.5,
      360
    );
    camera.position.set(0, 32, 46);
    camera.lookAt(0, 0, 0);

    // Lighting rig (Key + Hemisphere Fill + Stadium Rim)
    const hemiLight = new THREE.HemisphereLight(0xcbe6ff, 0x1b3a24, 0.72);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1d6, 1.8);
    keyLight.position.set(32, 55, 28);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.left = -58;
    keyLight.shadow.camera.right = 58;
    keyLight.shadow.camera.top = 42;
    keyLight.shadow.camera.bottom = -42;
    keyLight.shadow.camera.near = 10;
    keyLight.shadow.camera.far = 140;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.55);
    rimLight.position.set(-40, 28, -36);
    scene.add(rimLight);

    // Environment Group (rebuilt only when weather/stadium/clubs change)
    const stadiumGroup = new THREE.Group();
    scene.add(stadiumGroup);

    const playersGroup = new THREE.Group();
    scene.add(playersGroup);

    // Shared geometries for composite 3D players (Zero-GC, high FPS)
    const shadowGeo = new THREE.CircleGeometry(0.62, 16);
    shadowGeo.rotateX(-Math.PI / 2);
    const torsoGeo = new THREE.CylinderGeometry(0.28, 0.24, 0.64, 12);
    const shortsGeo = new THREE.CylinderGeometry(0.24, 0.25, 0.26, 12);
    const thighGeo = new THREE.CapsuleGeometry(0.085, 0.26, 4, 8);
    const sockGeo = new THREE.CylinderGeometry(0.072, 0.062, 0.28, 8);
    const bootGeo = new THREE.BoxGeometry(0.14, 0.09, 0.26);
    const armGeo = new THREE.CapsuleGeometry(0.062, 0.36, 4, 8);
    const headGeo = new THREE.SphereGeometry(0.19, 14, 12);
    const hairShortGeo = new THREE.SphereGeometry(0.198, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.56);
    const hairFadeGeo = new THREE.CylinderGeometry(0.165, 0.178, 0.14, 12);
    const hairAfroGeo = new THREE.SphereGeometry(0.27, 14, 12);
    const hairMohawkGeo = new THREE.BoxGeometry(0.085, 0.15, 0.32);
    const hairLongTailGeo = new THREE.CapsuleGeometry(0.08, 0.24, 4, 8);
    const numberBadgeGeo = new THREE.PlaneGeometry(0.28, 0.28);

    const contactShadowTex = createContactShadowTexture();
    const shadowMat = new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd99b72, roughness: 0.68, metalness: 0.02 });
    const hairMatDark = new THREE.MeshStandardMaterial({ color: 0x1e1b18, roughness: 0.85, metalness: 0.05 });
    const hairMatLight = new THREE.MeshStandardMaterial({ color: 0x7c542b, roughness: 0.8, metalness: 0.05 });
    const bootMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.32, metalness: 0.25 });

    // Active Player Ring + Direction Arrow
    const ringGeo = new THREE.RingGeometry(0.58, 0.78, 28);
    ringGeo.rotateX(-Math.PI / 2);
    const activeRingMat = new THREE.MeshBasicMaterial({
      color: 0xf5c451,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.92,
      depthWrite: false,
    });
    const activeRingMesh = new THREE.Mesh(ringGeo, activeRingMat);
    activeRingMesh.position.y = 0.04;
    scene.add(activeRingMesh);

    const arrowShape = new THREE.Shape();
    arrowShape.moveTo(0, 0.32);
    arrowShape.lineTo(-0.18, -0.1);
    arrowShape.lineTo(0.18, -0.1);
    arrowShape.closePath();
    const arrowGeo = new THREE.ShapeGeometry(arrowShape);
    arrowGeo.rotateX(-Math.PI / 2);
    const aimArrowMesh = new THREE.Mesh(
      arrowGeo,
      new THREE.MeshBasicMaterial({ color: 0xf5c451, side: THREE.DoubleSide, depthWrite: false })
    );
    aimArrowMesh.position.y = 0.05;
    scene.add(aimArrowMesh);

    // 3D Football + Shadow
    const ballTex = createBallTexture();
    const ballMat = new THREE.MeshStandardMaterial({
      map: ballTex,
      roughness: 0.38,
      metalness: 0.08,
    });
    const ballMesh = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 24, 20), ballMat);
    ballMesh.castShadow = !isSoftwareGl;
    scene.add(ballMesh);

    const ballShadow = new THREE.Mesh(shadowGeo, shadowMat);
    ballShadow.scale.set(0.8, 1, 0.8);
    ballShadow.position.y = 0.03;
    scene.add(ballShadow);

    // Rain particle system
    const rainCount = 900;
    const rainGeo = new THREE.BufferGeometry();
    const rainPositions = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      rainPositions[i * 3] = (Math.random() - 0.5) * 120;
      rainPositions[i * 3 + 1] = Math.random() * 34;
      rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 80;
    }
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0xcbd5e1,
      size: 0.24,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    const rainPoints = new THREE.Points(rainGeo, rainMat);
    rainPoints.visible = false;
    scene.add(rainPoints);

    // Goal confetti burst particles
    const confettiCount = 140;
    const confettiGeo = new THREE.BufferGeometry();
    const confettiPos = new Float32Array(confettiCount * 3);
    const confettiVel: THREE.Vector3[] = [];
    for (let i = 0; i < confettiCount; i++) {
      confettiPos[i * 3] = 0;
      confettiPos[i * 3 + 1] = -20;
      confettiPos[i * 3 + 2] = 0;
      confettiVel.push(new THREE.Vector3());
    }
    confettiGeo.setAttribute('position', new THREE.BufferAttribute(confettiPos, 3));
    const confettiMat = new THREE.PointsMaterial({
      color: 0xf5c451,
      size: 0.45,
      transparent: true,
      opacity: 0.95,
    });
    const confettiPoints = new THREE.Points(confettiGeo, confettiMat);
    scene.add(confettiPoints);

    // Dynamic Scene State
    let crowdInstanced: THREE.InstancedMesh | null = null;
    let crowdBaseMatrices: THREE.Matrix4[] = [];
    let disposableResources: Array<{ dispose: () => void }> = [];

    let simPlayers: SimPlayer[] = [];
    let activeHomeIndex = 9;
    let ballPos = new THREE.Vector3(0, BALL_R, 0);
    let ballVel = new THREE.Vector3(0, 0, 0);
    let lastTouchTeam: 'home' | 'away' = 'home';
    let lastTouchName = '';

    let homeScore = 0;
    let awayScore = 0;
    let elapsedMatchSec = 0;
    let half: 1 | 2 = 1;
    let addedMinutes = 2;
    let phase: LiveHudSnapshot['phase'] = 'kickoff';
    let phaseTimer = 1.2;
    let goalTeam: 'home' | 'away' | null = null;
    let goalScorer = '';
    let celebrationTimer = 0;
    let hitstopTimer = 0;
    let shakeIntensity = 0;

    // Stats tracking
    let homePossFrames = 1;
    let awayPossFrames = 1;
    let homeShots = 0;
    let awayShots = 0;
    let homeOnTarget = 0;
    let awayOnTarget = 0;
    let homePasses = 0;
    let awayPasses = 0;
    let scorers: MatchStats['scorers'] = [];
    let statsSubmitted = false;

    const cleanupDynamicResources = () => {
      for (const r of disposableResources) r.dispose();
      disposableResources = [];
      stadiumGroup.clear();
      playersGroup.clear();
      crowdInstanced = null;
      crowdBaseMatrices = [];
    };

    const buildEnvironmentAndTeams = () => {
      cleanupDynamicResources();

      const cfg = matchConfigRef.current;
      const { home, away } = clubsRef.current;
      const stadium = STADIUMS.find((s) => s.id === cfg.stadiumId) || STADIUMS[0];
      const weather: WeatherType = modeRef.current === 'showcase' ? 'night' : cfg.weather;

      // Sky & Fog & Lighting per Weather
      if (weather === 'day') {
        const sky = new THREE.Color(0x8ec5fc);
        scene.background = sky;
        scene.fog = new THREE.FogExp2(0x8ec5fc, 0.0042);
        hemiLight.color.setHex(0xdbeafe);
        hemiLight.groundColor.setHex(0x274e2d);
        hemiLight.intensity = 0.85;
        keyLight.color.setHex(0xfff5dc);
        keyLight.intensity = 2.0;
        rainPoints.visible = false;
      } else if (weather === 'rain') {
        const sky = new THREE.Color(0x162033);
        scene.background = sky;
        scene.fog = new THREE.FogExp2(0x162033, 0.0072);
        hemiLight.color.setHex(0x64748b);
        hemiLight.groundColor.setHex(0x13281b);
        hemiLight.intensity = 0.62;
        keyLight.color.setHex(0xdbeafe);
        keyLight.intensity = 1.45;
        rainPoints.visible = true;
      } else {
        // Night stadium lights
        const sky = new THREE.Color(0x070b14);
        scene.background = sky;
        scene.fog = new THREE.FogExp2(0x070b14, 0.0052);
        hemiLight.color.setHex(0x93c5fd);
        hemiLight.groundColor.setHex(0x0f2518);
        hemiLight.intensity = 0.65;
        keyLight.color.setHex(0xfff1d6);
        keyLight.intensity = 1.95;
        rainPoints.visible = false;
      }

      // Extended Ground Apron (Natural Outdoor Stadium Perimeter)
      const apronGeo = new THREE.PlaneGeometry(320, 260);
      apronGeo.rotateX(-Math.PI / 2);
      const apronMat = new THREE.MeshStandardMaterial({
        color: weather === 'day' ? 0x1a2634 : 0x0b1220,
        roughness: 0.92,
        metalness: 0.05,
      });
      const apron = new THREE.Mesh(apronGeo, apronMat);
      apron.position.y = -0.04;
      apron.receiveShadow = !isSoftwareGl;
      stadiumGroup.add(apron);
      disposableResources.push(apronGeo, apronMat);

      // Synthetic Track Border around Pitch
      const trackGeo = new THREE.PlaneGeometry(PITCH_W + 14, PITCH_H + 12);
      trackGeo.rotateX(-Math.PI / 2);
      const trackMat = new THREE.MeshStandardMaterial({
        color: 0x16293d,
        roughness: 0.85,
        metalness: 0.08,
      });
      const track = new THREE.Mesh(trackGeo, trackMat);
      track.position.y = -0.02;
      track.receiveShadow = !isSoftwareGl;
      stadiumGroup.add(track);
      disposableResources.push(trackGeo, trackMat);

      // Main Turf Pitch
      const pitchTex = createPitchTexture(stadium.turfTone, weather === 'rain');
      pitchTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
      const pitchGeo = new THREE.PlaneGeometry(PITCH_W + 4, PITCH_H + 4);
      pitchGeo.rotateX(-Math.PI / 2);
      const pitchMat = new THREE.MeshStandardMaterial({
        map: pitchTex,
        roughness: weather === 'rain' ? 0.35 : 0.82,
        metalness: weather === 'rain' ? 0.14 : 0.02,
      });
      const pitchMesh = new THREE.Mesh(pitchGeo, pitchMat);
      pitchMesh.receiveShadow = !isSoftwareGl;
      stadiumGroup.add(pitchMesh);
      disposableResources.push(pitchTex, pitchGeo, pitchMat);

      // Composite 3D Goals (Left = -HALF_W, Right = +HALF_W)
      const postMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.25, metalness: 0.82 });
      const netTex = createNetTexture();
      const netMat = new THREE.MeshStandardMaterial({
        map: netTex,
        transparent: true,
        opacity: 0.72,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const postGeo = new THREE.CylinderGeometry(0.08, 0.08, GOAL_H, 10);
      const barGeo = new THREE.CylinderGeometry(0.08, 0.08, GOAL_W + 0.16, 10);
      barGeo.rotateX(Math.PI / 2);
      const backNetGeo = new THREE.PlaneGeometry(GOAL_W, GOAL_H);
      const sideNetGeo = new THREE.PlaneGeometry(GOAL_D, GOAL_H);
      const topNetGeo = new THREE.PlaneGeometry(GOAL_W, GOAL_D);
      disposableResources.push(postMat, netTex, netMat, postGeo, barGeo, backNetGeo, sideNetGeo, topNetGeo);

      [-1, 1].forEach((dir) => {
        const goalGroup = new THREE.Group();
        const xLine = dir * HALF_W;
        const backX = xLine + dir * GOAL_D;

        const p1 = new THREE.Mesh(postGeo, postMat);
        p1.position.set(xLine, GOAL_H / 2, -GOAL_W / 2);
        p1.castShadow = !isSoftwareGl;
        const p2 = new THREE.Mesh(postGeo, postMat);
        p2.position.set(xLine, GOAL_H / 2, GOAL_W / 2);
        p2.castShadow = !isSoftwareGl;
        const bar = new THREE.Mesh(barGeo, postMat);
        bar.position.set(xLine, GOAL_H, 0);
        bar.castShadow = !isSoftwareGl;

        const bp1 = new THREE.Mesh(postGeo, postMat);
        bp1.position.set(backX, GOAL_H / 2, -GOAL_W / 2);
        const bp2 = new THREE.Mesh(postGeo, postMat);
        bp2.position.set(backX, GOAL_H / 2, GOAL_W / 2);

        const backNet = new THREE.Mesh(backNetGeo, netMat);
        backNet.rotation.y = Math.PI / 2;
        backNet.position.set(backX, GOAL_H / 2, 0);

        const sideNetL = new THREE.Mesh(sideNetGeo, netMat);
        sideNetL.position.set((xLine + backX) / 2, GOAL_H / 2, -GOAL_W / 2);

        const sideNetR = new THREE.Mesh(sideNetGeo, netMat);
        sideNetR.position.set((xLine + backX) / 2, GOAL_H / 2, GOAL_W / 2);

        const topNet = new THREE.Mesh(topNetGeo, netMat);
        topNet.rotation.x = Math.PI / 2;
        topNet.rotation.z = Math.PI / 2;
        topNet.position.set((xLine + backX) / 2, GOAL_H, 0);

        goalGroup.add(p1, p2, bar, bp1, bp2, backNet, sideNetL, sideNetR, topNet);
        stadiumGroup.add(goalGroup);
      });

      // Perimeter LED Advertising Boards
      const ledTex = createLedBoardTexture(home.abbr, away.abbr);
      const ledMat = new THREE.MeshStandardMaterial({
        map: ledTex,
        emissive: 0xffffff,
        emissiveMap: ledTex,
        emissiveIntensity: weather === 'day' ? 0.35 : 0.75,
        roughness: 0.4,
      });
      const ledNorthGeo = new THREE.BoxGeometry(PITCH_W + 4, 1.15, 0.35);
      const ledNorth = new THREE.Mesh(ledNorthGeo, ledMat);
      ledNorth.position.set(0, 0.58, -HALF_H - 3.2);
      const ledSouth = new THREE.Mesh(ledNorthGeo, ledMat);
      ledSouth.position.set(0, 0.58, HALF_H + 3.2);
      stadiumGroup.add(ledNorth, ledSouth);
      disposableResources.push(ledTex, ledMat, ledNorthGeo);

      // Tiered Grandstands (4 sides)
      const standMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.85, metalness: 0.15 });
      const standRoofMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.45 });
      const tierLongGeo = new THREE.BoxGeometry(PITCH_W + 22, 8.5, 13);
      const tierShortGeo = new THREE.BoxGeometry(13, 8.5, PITCH_H + 14);
      const roofLongGeo = new THREE.BoxGeometry(PITCH_W + 26, 0.9, 15);
      disposableResources.push(standMat, standRoofMat, tierLongGeo, tierShortGeo, roofLongGeo);

      const standN = new THREE.Mesh(tierLongGeo, standMat);
      standN.position.set(0, 4.2, -HALF_H - 13);
      const roofN = new THREE.Mesh(roofLongGeo, standRoofMat);
      roofN.position.set(0, 12.2, -HALF_H - 12);

      const standS = new THREE.Mesh(tierLongGeo, standMat);
      standS.position.set(0, 4.2, HALF_H + 13);

      const standW = new THREE.Mesh(tierShortGeo, standMat);
      standW.position.set(-HALF_W - 13, 4.2, 0);
      const standE = new THREE.Mesh(tierShortGeo, standMat);
      standE.position.set(HALF_W + 13, 4.2, 0);

      stadiumGroup.add(standN, roofN, standS, standW, standE);

      // Instanced Crowd Spectators (700 animated fans)
      const fanGeo = new THREE.BoxGeometry(0.65, 1.05, 0.55);
      const fanMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, metalness: 0.05 });
      const fanCount = 680;
      crowdInstanced = new THREE.InstancedMesh(fanGeo, fanMat, fanCount);
      crowdBaseMatrices = [];
      const dummy = new THREE.Object3D();
      const homeCol = new THREE.Color(home.primaryColor);
      const awayCol = new THREE.Color(away.primaryColor);
      const neutralCol = new THREE.Color(0x94a3b8);

      for (let i = 0; i < fanCount; i++) {
        const side = i % 4;
        let fx = 0;
        let fz = 0;
        let fy = 2.0 + (i % 6) * 1.15;
        if (side === 0) {
          fx = ((i * 3.7) % (PITCH_W + 8)) - (PITCH_W + 8) / 2;
          fz = -HALF_H - 8.5 - (i % 6) * 1.5;
        } else if (side === 1) {
          fx = ((i * 3.9) % (PITCH_W + 8)) - (PITCH_W + 8) / 2;
          fz = HALF_H + 8.5 + (i % 6) * 1.5;
        } else if (side === 2) {
          fx = -HALF_W - 8.5 - (i % 6) * 1.5;
          fz = ((i * 2.9) % (PITCH_H + 4)) - (PITCH_H + 4) / 2;
        } else {
          fx = HALF_W + 8.5 + (i % 6) * 1.5;
          fz = ((i * 3.1) % (PITCH_H + 4)) - (PITCH_H + 4) / 2;
        }
        dummy.position.set(fx, fy, fz);
        dummy.rotation.set(0, 0, 0);
        const s = 0.88 + (i % 5) * 0.06;
        dummy.scale.set(s, s, s);
        dummy.updateMatrix();
        crowdInstanced.setMatrixAt(i, dummy.matrix);
        crowdBaseMatrices.push(dummy.matrix.clone());

        const col = i % 5 === 0 ? neutralCol : i % 2 === 0 ? homeCol : awayCol;
        crowdInstanced.setColorAt(i, col);
      }
      crowdInstanced.instanceMatrix.needsUpdate = true;
      if (crowdInstanced.instanceColor) crowdInstanced.instanceColor.needsUpdate = true;
      crowdInstanced.computeBoundingSphere();
      stadiumGroup.add(crowdInstanced);
      disposableResources.push(fanGeo, fanMat);

      // 4 Composite Corner Stadium Floodlight Towers
      const mastGeo = new THREE.CylinderGeometry(0.45, 0.85, 28, 10);
      const lampHousingGeo = new THREE.BoxGeometry(5.6, 2.4, 0.9);
      const lampFaceGeo = new THREE.PlaneGeometry(5.1, 1.9);
      const mastMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.35, metalness: 0.78 });
      const bulbMat = new THREE.MeshStandardMaterial({
        color: 0xfffbeb,
        emissive: 0xfef3c7,
        emissiveIntensity: weather === 'day' ? 0.3 : 2.2,
        roughness: 0.2,
      });
      disposableResources.push(mastGeo, lampHousingGeo, lampFaceGeo, mastMat, bulbMat);

      [
        [-HALF_W - 14, -HALF_H - 14],
        [HALF_W + 14, -HALF_H - 14],
        [-HALF_W - 14, HALF_H + 14],
        [HALF_W + 14, HALF_H + 14],
      ].forEach(([tx, tz]) => {
        const tower = new THREE.Group();
        tower.position.set(tx, 0, tz);
        const mast = new THREE.Mesh(mastGeo, mastMat);
        mast.position.y = 14;
        const housing = new THREE.Mesh(lampHousingGeo, mastMat);
        housing.position.y = 28.2;
        housing.lookAt(0, 0, 0);
        const face = new THREE.Mesh(lampFaceGeo, bulbMat);
        face.position.set(0, 0, 0.48);
        housing.add(face);
        tower.add(mast, housing);
        stadiumGroup.add(tower);
      });

      // Build 22 Composite 3D Players (11 Home + 11 Away) with Custom Kits, Hairstyles & Jersey Numbers
      const homeKit = resolveClubKit(home, cfg.homeKitVariant ?? 'home');
      const awayKit = resolveClubKit(away, cfg.awayKitVariant ?? 'away');

      const homeJerseyTex = createJerseyTexture(homeKit.primaryColor, homeKit.secondaryColor, homeKit.pattern);
      const awayJerseyTex = createJerseyTexture(awayKit.primaryColor, awayKit.secondaryColor, awayKit.pattern);
      const homeJerseyMat = new THREE.MeshStandardMaterial({ map: homeJerseyTex, roughness: 0.84, metalness: 0.04 });
      const awayJerseyMat = new THREE.MeshStandardMaterial({ map: awayJerseyTex, roughness: 0.84, metalness: 0.04 });
      const gkHomeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.82, metalness: 0.05 });
      const gkAwayMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.82, metalness: 0.05 });
      const homeShortsMat = new THREE.MeshStandardMaterial({ color: homeKit.shortsColor, roughness: 0.85, metalness: 0.03 });
      const awayShortsMat = new THREE.MeshStandardMaterial({ color: awayKit.shortsColor, roughness: 0.85, metalness: 0.03 });

      const hairMatCache = new Map<string, THREE.MeshStandardMaterial>();
      const getHairMat = (hex?: string) => {
        const key = (hex || '#1E1B18').toUpperCase();
        let mat = hairMatCache.get(key);
        if (!mat) {
          mat = new THREE.MeshStandardMaterial({ color: key, roughness: 0.84, metalness: 0.04 });
          hairMatCache.set(key, mat);
          disposableResources.push(mat);
        }
        return mat;
      };

      const numMatCache = new Map<string, THREE.MeshBasicMaterial>();
      const getNumberMat = (num: number, primaryHex: string) => {
        const textHex = getContrastHex(primaryHex);
        const outlineHex = textHex === '#0F172A' ? '#F8FAFC' : '#0F172A';
        const key = `${num}_${textHex}`;
        let mat = numMatCache.get(key);
        if (!mat) {
          const tex = createNumberBadgeTexture(num, textHex, outlineHex);
          mat = new THREE.MeshBasicMaterial({
            map: tex,
            transparent: true,
            depthWrite: false,
            polygonOffset: true,
            polygonOffsetFactor: -1,
            polygonOffsetUnits: -1,
          });
          numMatCache.set(key, mat);
          disposableResources.push(tex, mat);
        }
        return mat;
      };

      disposableResources.push(
        homeJerseyTex,
        awayJerseyTex,
        homeJerseyMat,
        awayJerseyMat,
        gkHomeMat,
        gkAwayMat,
        homeShortsMat,
        awayShortsMat
      );

      simPlayers = [];
      const homeOffsets = getFormationOffsets(cfg.formation);
      const awayOffsets = getFormationOffsets('4-3-3');

      const spawnTeam = (
        club: Club,
        team: 'home' | 'away',
        offsets: Array<[number, number]>,
        kitPrimaryHex: string
      ) => {
        const jMat = team === 'home' ? homeJerseyMat : awayJerseyMat;
        const gkMat = team === 'home' ? gkHomeMat : gkAwayMat;
        const sMat = team === 'home' ? homeShortsMat : awayShortsMat;

        for (let i = 0; i < 11; i++) {
          const pData = club.players[i] || club.players[0];
          const isGk = i === 0 || pData.position === 'GOL';
          const [nx, nz] = offsets[i] || [-0.5, 0];
          const hx = team === 'home' ? nx * (HALF_W - 2) : -nx * (HALF_W - 2);
          const hz = nz * (HALF_H - 3);

          const root = new THREE.Group();
          root.position.set(hx, 0, hz);

          // Contact shadow
          const sh = new THREE.Mesh(shadowGeo, shadowMat);
          sh.position.y = 0.025;
          root.add(sh);

          // Left & Right articulated leg groups pivoted at hip (y = 0.78)
          const makeLeg = (xOff: number) => {
            const legGrp = new THREE.Group();
            legGrp.position.set(xOff, 0.78, 0);
            const thigh = new THREE.Mesh(thighGeo, skinMat);
            thigh.position.y = -0.18;
            const sock = new THREE.Mesh(sockGeo, jMat);
            sock.position.y = -0.48;
            const boot = new THREE.Mesh(bootGeo, bootMat);
            boot.position.set(0, -0.70, 0.05);
            boot.castShadow = !isSoftwareGl;
            legGrp.add(thigh, sock, boot);
            return legGrp;
          };
          const legL = makeLeg(-0.13);
          const legR = makeLeg(0.13);
          root.add(legL, legR);

          // Shorts & Torso
          const shorts = new THREE.Mesh(shortsGeo, sMat);
          shorts.position.y = 0.84;
          shorts.castShadow = !isSoftwareGl;

          const torso = new THREE.Mesh(torsoGeo, isGk ? gkMat : jMat);
          torso.position.y = 1.24;
          torso.castShadow = !isSoftwareGl;

          // Back Jersey Number Decal
          const numBadge = new THREE.Mesh(
            numberBadgeGeo,
            getNumberMat(pData.number, isGk ? '#F59E0B' : kitPrimaryHex)
          );
          numBadge.position.set(0, 1.29, -0.275);
          numBadge.rotation.y = Math.PI;

          // Arms pivoted at shoulders
          const makeArm = (xOff: number) => {
            const armGrp = new THREE.Group();
            armGrp.position.set(xOff, 1.48, 0);
            const arm = new THREE.Mesh(armGeo, isGk ? gkMat : jMat);
            arm.position.y = -0.22;
            armGrp.add(arm);
            return armGrp;
          };
          const armL = makeArm(-0.34);
          const armR = makeArm(0.34);

          // Head + Customizable 3D Hairstyle
          const head = new THREE.Mesh(headGeo, skinMat);
          head.position.y = 1.74;
          head.castShadow = !isSoftwareGl;
          root.add(shorts, torso, numBadge, armL, armR, head);

          const hStyle: HairStyle = pData.hairStyle ?? 'short';
          const hMat = getHairMat(pData.hairColor);
          if (hStyle === 'short') {
            const hair = new THREE.Mesh(hairShortGeo, hMat);
            hair.position.y = 1.76;
            root.add(hair);
          } else if (hStyle === 'fade') {
            const hair = new THREE.Mesh(hairFadeGeo, hMat);
            hair.position.y = 1.88;
            root.add(hair);
          } else if (hStyle === 'afro') {
            const hair = new THREE.Mesh(hairAfroGeo, hMat);
            hair.position.set(0, 1.82, -0.02);
            root.add(hair);
          } else if (hStyle === 'mohawk') {
            const hair = new THREE.Mesh(hairMohawkGeo, hMat);
            hair.position.set(0, 1.94, 0);
            root.add(hair);
          } else if (hStyle === 'long') {
            const cap = new THREE.Mesh(hairShortGeo, hMat);
            cap.position.y = 1.76;
            const tail = new THREE.Mesh(hairLongTailGeo, hMat);
            tail.position.set(0, 1.66, -0.19);
            tail.rotation.x = 0.25;
            root.add(cap, tail);
          }
          playersGroup.add(root);

          simPlayers.push({
            id: pData.id,
            name: pData.name,
            pos: pData.position,
            ovr: pData.ovr,
            pac: pData.pac,
            sho: pData.sho,
            pas: pData.pas,
            def: pData.def,
            team,
            isGk,
            homeX: hx,
            homeZ: hz,
            x: hx,
            z: hz,
            vx: 0,
            vz: 0,
            facing: team === 'home' ? Math.PI / 2 : -Math.PI / 2,
            stamina: 100,
            runCycle: Math.random() * Math.PI * 2,
            kickAnim: 0,
            diveAnim: 0,
            mesh: root,
            legL,
            legR,
            armL,
            armR,
          });
        }
      };

      spawnTeam(home, 'home', homeOffsets, homeKit.primaryColor);
      spawnTeam(away, 'away', awayOffsets, awayKit.primaryColor);

      // Reset Match Counters
      homeScore = 0;
      awayScore = 0;
      elapsedMatchSec = 0;
      half = 1;
      addedMinutes = 1 + Math.floor(Math.random() * 3);
      phase = modeRef.current === 'showcase' ? 'playing' : 'kickoff';
      phaseTimer = 1.1;
      goalTeam = null;
      goalScorer = '';
      celebrationTimer = 0;
      homePossFrames = 1;
      awayPossFrames = 1;
      homeShots = 0;
      awayShots = 0;
      homeOnTarget = 0;
      awayOnTarget = 0;
      homePasses = 0;
      awayPasses = 0;
      scorers = [];
      statsSubmitted = false;
      activeHomeIndex = 9;
      resetPositionsForKickoff();

      if (modeRef.current === 'match') {
        soundEngine.playWhistle(false);
        soundEngine.speakCommentary('kickoff', languageRef.current, `${home.name} vs ${away.name}!`);
      }
    };

    const resetPositionsForKickoff = () => {
      ballPos.set(0, BALL_R, 0);
      ballVel.set(0, 0, 0);
      for (const p of simPlayers) {
        p.x = p.homeX * 0.92;
        p.z = p.homeZ * 0.92;
        p.vx = 0;
        p.vz = 0;
        p.diveAnim = 0;
        p.mesh.position.set(p.x, 0, p.z);
        p.mesh.rotation.z = 0;
      }
      // Put home striker near center circle
      if (simPlayers[9]) {
        simPlayers[9].x = -1.6;
        simPlayers[9].z = 0;
      }
      activeHomeIndex = 9;
    };

    const triggerConfetti = (gx: number) => {
      const posAttr = confettiGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < confettiCount; i++) {
        posAttr.setXYZ(i, gx, 1.5 + Math.random() * 2, (Math.random() - 0.5) * 8);
        confettiVel[i].set(
          (Math.random() - 0.5) * 14,
          6 + Math.random() * 10,
          (Math.random() - 0.5) * 14
        );
      }
      posAttr.needsUpdate = true;
    };

    const findBestPassTarget = (passer: SimPlayer, aimX: number, aimZ: number): SimPlayer | null => {
      let best: SimPlayer | null = null;
      let bestScore = -Infinity;
      for (const p of simPlayers) {
        if (p.team !== passer.team || p === passer) continue;
        const dx = p.x - passer.x;
        const dz = p.z - passer.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 2 || dist > 48) continue;
        const dot = (dx / dist) * aimX + (dz / dist) * aimZ;
        const score = dot * 3.0 - dist * 0.04 + (p.isGk ? -1.5 : 0);
        if (score > bestScore) {
          bestScore = score;
          best = p;
        }
      }
      return best;
    };

    const kickBall = (
      p: SimPlayer,
      dirX: number,
      dirZ: number,
      speed: number,
      loftY: number,
      isShot: boolean
    ) => {
      const len = Math.hypot(dirX, dirZ) || 1;
      ballVel.set((dirX / len) * speed, loftY, (dirZ / len) * speed);
      ballPos.y = Math.max(BALL_R, ballPos.y + 0.06);
      p.kickAnim = 0.28;
      lastTouchTeam = p.team;
      lastTouchName = p.name;
      soundEngine.playKick(Math.min(1, speed / 34));

      if (isShot) {
        if (p.team === 'home') homeShots++;
        else awayShots++;
        if (Math.abs(dirZ / len) < 0.45 && Math.abs(p.x) > 16) {
          if (p.team === 'home') homeOnTarget++;
          else awayOnTarget++;
        }
        if (speed > 22 && modeRef.current === 'match') {
          soundEngine.playCrowdChance();
          if (speed > 26) {
            soundEngine.speakCommentary('shot_danger', languageRef.current);
          }
        }
      } else {
        if (p.team === 'home') homePasses++;
        else awayPasses++;
      }
    };

    // Initial build
    let builtVersion = matchVersionRef.current;
    buildEnvironmentAndTeams();

    // Compile shaders on GPU
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Resize Observer / Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Context Loss Safety
    const onContextLost = (e: Event) => {
      e.preventDefault();
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);

    const clock = new THREE.Clock();
    let frameId = 0;
    let hudAccumulator = 0;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || !gl.fenceSync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (disposed) return;

      // Rebuild stadium/teams if match config changed
      if (matchVersionRef.current !== builtVersion) {
        builtVersion = matchVersionRef.current;
        buildEnvironmentAndTeams();
      }

      const rawDt = clock.getDelta();
      const dt = Math.min(rawDt, 0.05);
      const elapsedTotal = clock.elapsedTime;
      const isMatch = modeRef.current === 'match';
      const isPaused = isMatch && pausedRef.current;

      if (!isPaused) {
        // Hitstop micro-freeze on crossbar/hard shots
        if (hitstopTimer > 0) {
          hitstopTimer -= dt;
        } else {
          // Match Clock Progression
          const totalRealSeconds = Math.max(60, matchConfigRef.current.durationMinutes * 60);
          if (isMatch && phase === 'playing') {
            elapsedMatchSec += dt;
            const halfRealSec = totalRealSeconds / 2;
            const addedSec = (addedMinutes / 45) * halfRealSec;

            if (half === 1 && elapsedMatchSec >= halfRealSec + addedSec) {
              phase = 'halftime';
              phaseTimer = 2.6;
              soundEngine.playWhistle(true);
              soundEngine.speakCommentary('halftime', languageRef.current);
            } else if (half === 2 && elapsedMatchSec >= totalRealSeconds + addedSec * 1.5) {
              phase = 'fulltime';
              soundEngine.playWhistle(true);
              soundEngine.speakCommentary('fulltime', languageRef.current);
              if (!statsSubmitted) {
                statsSubmitted = true;
                const totalPoss = homePossFrames + awayPossFrames;
                const homeP = Math.round((homePossFrames / totalPoss) * 100);
                callbacksRef.current.onMatchFinish({
                  homeScore,
                  awayScore,
                  homeShots,
                  awayShots,
                  homeOnTarget,
                  awayOnTarget,
                  homePossession: homeP,
                  awayPossession: 100 - homeP,
                  homePasses,
                  awayPasses,
                  scorers: [...scorers],
                });
              }
            }
          } else if (isMatch && phase === 'kickoff') {
            phaseTimer -= dt;
            if (phaseTimer <= 0) phase = 'playing';
          } else if (isMatch && phase === 'halftime') {
            phaseTimer -= dt;
            if (phaseTimer <= 0) {
              half = 2;
              elapsedMatchSec = totalRealSeconds / 2;
              phase = 'kickoff';
              phaseTimer = 1.0;
              resetPositionsForKickoff();
              soundEngine.playWhistle(false);
            }
          } else if (isMatch && phase === 'goal') {
            celebrationTimer -= dt;
            if (celebrationTimer <= 0) {
              goalTeam = null;
              phase = 'kickoff';
              phaseTimer = 1.0;
              resetPositionsForKickoff();
              soundEngine.playWhistle(false);
            }
          }

          // Difficulty multiplier for CPU AI
          const diff: Difficulty = matchConfigRef.current.difficulty;
          const aiSpeedMult = diff === 'legendary' ? 1.04 : diff === 'professional' ? 0.94 : 0.80;
          const aiReaction = diff === 'legendary' ? 1.0 : diff === 'professional' ? 0.85 : 0.68;

          // Ball Physics
          if (phase === 'playing' || !isMatch) {
            ballPos.x += ballVel.x * dt;
            ballPos.z += ballVel.z * dt;
            ballPos.y += ballVel.y * dt;

            if (ballPos.y > BALL_R) {
              ballVel.y -= 24 * dt; // Gravity
            }
            if (ballPos.y <= BALL_R) {
              ballPos.y = BALL_R;
              if (Math.abs(ballVel.y) > 1.8) {
                ballVel.y = -ballVel.y * 0.56;
              } else {
                ballVel.y = 0;
              }
              const turfDrag = matchConfigRef.current.weather === 'rain' ? 1.55 : 2.25;
              const damp = Math.exp(-turfDrag * dt);
              ballVel.x *= damp;
              ballVel.z *= damp;
            } else {
              const airDrag = Math.exp(-0.35 * dt);
              ballVel.x *= airDrag;
              ballVel.z *= airDrag;
            }

            // Ball rolling rotation
            const bSpeed = Math.hypot(ballVel.x, ballVel.z);
            if (bSpeed > 0.05) {
              ballMesh.rotation.z -= (ballVel.x * dt) / BALL_R;
              ballMesh.rotation.x += (ballVel.z * dt) / BALL_R;
            }

            // Goalpost / Crossbar Collisions & Goal Detection
            const inGoalZ = Math.abs(ballPos.z) < GOAL_W / 2 - BALL_R * 0.3;
            const inGoalY = ballPos.y < GOAL_H;

            // Check goalposts
            [-HALF_W, HALF_W].forEach((gx) => {
              [-GOAL_W / 2, GOAL_W / 2].forEach((gz) => {
                const distPost = Math.hypot(ballPos.x - gx, ballPos.z - gz);
                if (distPost < BALL_R + 0.14 && ballPos.y < GOAL_H + 0.1) {
                  ballVel.x = -ballVel.x * 0.72;
                  ballVel.z = -ballVel.z * 0.72;
                  hitstopTimer = 0.045;
                  shakeIntensity = 0.45;
                  soundEngine.playPostClang();
                  if (isMatch) {
                    soundEngine.playCrowdChance();
                    soundEngine.speakCommentary('post', languageRef.current);
                  }
                }
              });
            });

            if (Math.abs(ballPos.x) > HALF_W) {
              if (inGoalZ && inGoalY) {
                // GOAL SCORED!
                if (isMatch) {
                  const scoringTeam: 'home' | 'away' = ballPos.x > 0 ? 'home' : 'away';
                  if (scoringTeam === 'home') homeScore++;
                  else awayScore++;

                  const totalRealSeconds = Math.max(60, matchConfigRef.current.durationMinutes * 60);
                  const currentMin = Math.min(90, Math.max(1, Math.round((elapsedMatchSec / totalRealSeconds) * 90)));
                  const teamPlayers = simPlayers.filter((p) => p.team === scoringTeam && !p.isGk);
                  const scorer =
                    lastTouchTeam === scoringTeam && lastTouchName
                      ? lastTouchName
                      : teamPlayers[Math.floor(Math.random() * teamPlayers.length)]?.name || 'Striker';

                  scorers.push({ team: scoringTeam, playerName: scorer, minute: currentMin });
                  goalTeam = scoringTeam;
                  goalScorer = scorer;
                  phase = 'goal';
                  celebrationTimer = 3.2;
                  shakeIntensity = 0.65;
                  triggerConfetti(ballPos.x);
                  soundEngine.playWhistle(true);
                  soundEngine.playCrowdRoar();
                  soundEngine.speakCommentary(
                    scoringTeam === 'home' ? 'goal_home' : 'goal_away',
                    languageRef.current,
                    `${scorer}!`
                  );
                } else {
                  resetPositionsForKickoff();
                }
              } else {
                // Out over goal line -> smooth quick bounce/restart towards goalkeeper
                ballPos.x = Math.sign(ballPos.x) * (HALF_W - 0.5);
                ballVel.x = -ballVel.x * 0.5;
              }
            }

            // Sidelines bounce softly (arcade fluid flow without dead stoppages)
            if (Math.abs(ballPos.z) > HALF_H) {
              ballPos.z = Math.sign(ballPos.z) * HALF_H;
              ballVel.z = -ballVel.z * 0.68;
            }
          }

          ballMesh.position.copy(ballPos);
          ballShadow.position.set(ballPos.x, 0.03, ballPos.z);
          const shadowScale = Math.max(0.35, 0.85 - ballPos.y * 0.08);
          ballShadow.scale.set(shadowScale, 1, shadowScale);

          // Find closest players to ball per team
          let closestHomeIdx = 9;
          let closestHomeDist = Infinity;
          let closestAwayIdx = 20;
          let closestAwayDist = Infinity;

          for (let i = 0; i < simPlayers.length; i++) {
            const p = simPlayers[i];
            const d = Math.hypot(p.x - ballPos.x, p.z - ballPos.z);
            if (p.team === 'home' && !p.isGk && d < closestHomeDist) {
              closestHomeDist = d;
              closestHomeIdx = i;
            }
            if (p.team === 'away' && !p.isGk && d < closestAwayDist) {
              closestAwayDist = d;
              closestAwayIdx = i;
            }
          }

          // Possession stat & auto-switch on home team if user is far and ball is loose
          if (closestHomeDist < closestAwayDist) homePossFrames++;
          else awayPossFrames++;

          const controlledPlayer = simPlayers[activeHomeIndex] || simPlayers[9];
          const controlledDist = controlledPlayer
            ? Math.hypot(controlledPlayer.x - ballPos.x, controlledPlayer.z - ballPos.z)
            : 99;

          const input = inputRef.current;

          // Edge-triggered actions for user
          if (isMatch && phase === 'playing' && controlledPlayer) {
            const hasBall = controlledDist < 1.85 && ballPos.y < 1.5;

            if (input.passJustPressed) {
              input.passJustPressed = false;
              if (hasBall) {
                const aimX = Math.abs(input.moveX) > 0.1 || Math.abs(input.moveZ) > 0.1
                  ? input.moveX
                  : Math.sin(controlledPlayer.facing);
                const aimZ = Math.abs(input.moveX) > 0.1 || Math.abs(input.moveZ) > 0.1
                  ? input.moveZ
                  : Math.cos(controlledPlayer.facing);
                const target = findBestPassTarget(controlledPlayer, aimX, aimZ);
                if (target) {
                  const dx = target.x + target.vx * 0.25 - controlledPlayer.x;
                  const dz = target.z + target.vz * 0.25 - controlledPlayer.z;
                  const dist = Math.hypot(dx, dz);
                  kickBall(controlledPlayer, dx, dz, Math.min(28, 12 + dist * 0.55), 0.5, false);
                  // Switch to receiver
                  const idx = simPlayers.indexOf(target);
                  if (idx >= 0) activeHomeIndex = idx;
                } else {
                  kickBall(controlledPlayer, aimX, aimZ, 18, 0.4, false);
                }
              } else {
                // Switch to nearest home outfielder to the ball
                activeHomeIndex = closestHomeIdx;
              }
            }

            if (input.shootJustPressed) {
              input.shootJustPressed = false;
              if (hasBall) {
                const goalDirX = HALF_W - controlledPlayer.x;
                const aimOffsetZ = Math.abs(input.moveZ) > 0.15 ? input.moveZ * 3.2 : (Math.random() - 0.5) * 2.2;
                const goalDirZ = aimOffsetZ - controlledPlayer.z;
                const power = 26 + (controlledPlayer.sho / 99) * 10;
                kickBall(controlledPlayer, goalDirX, goalDirZ, power, 3.2 + Math.random() * 2.2, true);
                shakeIntensity = 0.22;
              } else {
                // Defend / Lunge Tackle
                const dx = ballPos.x - controlledPlayer.x;
                const dz = ballPos.z - controlledPlayer.z;
                const d = Math.hypot(dx, dz) || 1;
                if (d < 3.6) {
                  controlledPlayer.vx = (dx / d) * 13;
                  controlledPlayer.vz = (dz / d) * 13;
                  controlledPlayer.kickAnim = 0.25;
                  if (d < 2.1) {
                    kickBall(controlledPlayer, 1, input.moveZ * 0.5, 11, 0.2, false);
                  }
                }
              }
            }

            if (input.crossJustPressed) {
              input.crossJustPressed = false;
              if (hasBall) {
                const aimX = Math.abs(input.moveX) > 0.1 ? input.moveX : 1;
                const aimZ = Math.abs(input.moveZ) > 0.1 ? input.moveZ : -Math.sign(controlledPlayer.z) * 0.6;
                kickBall(controlledPlayer, aimX, aimZ, 23, 6.2, false);
              } else {
                // Sliding pressure toward ball
                const dx = ballPos.x - controlledPlayer.x;
                const dz = ballPos.z - controlledPlayer.z;
                const d = Math.hypot(dx, dz) || 1;
                controlledPlayer.vx = (dx / d) * 14.5;
                controlledPlayer.vz = (dz / d) * 14.5;
                controlledPlayer.diveAnim = 0.35;
              }
            }
          } else {
            input.passJustPressed = false;
            input.shootJustPressed = false;
            input.crossJustPressed = false;
          }

          // Update All 22 Players (User + Teammates + CPU AI + Goalkeepers)
          const ballRatioX = ballPos.x / HALF_W; // -1 to +1

          for (let i = 0; i < simPlayers.length; i++) {
            const p = simPlayers[i];
            const isUserControlled = isMatch && i === activeHomeIndex && phase === 'playing';
            let targetVx = 0;
            let targetVz = 0;
            const baseMaxSpeed = (7.2 + (p.pac / 99) * 3.4) * (p.team === 'away' ? aiSpeedMult : 1);

            if (phase === 'goal') {
              // Celebration run!
              if (p.team === goalTeam) {
                targetVx = Math.cos(elapsedTotal * 3 + i) * 4.5;
                targetVz = Math.sin(elapsedTotal * 3 + i) * 4.5;
              }
            } else if (phase === 'playing' || !isMatch) {
              if (isUserControlled) {
                const mag = Math.hypot(input.moveX, input.moveZ);
                if (mag > 0.08) {
                  const sprinting = input.sprint && p.stamina > 8;
                  const spd = baseMaxSpeed * (sprinting ? 1.32 : 1.0);
                  if (sprinting) p.stamina = Math.max(0, p.stamina - 18 * dt);
                  else p.stamina = Math.min(100, p.stamina + 8 * dt);

                  const nx = input.moveX / Math.max(1, mag);
                  const nz = input.moveZ / Math.max(1, mag);
                  targetVx = nx * spd;
                  targetVz = nz * spd;
                } else {
                  p.stamina = Math.min(100, p.stamina + 14 * dt);
                }

                // Smooth dribble carry when user touches ball
                const distToBall = Math.hypot(p.x - ballPos.x, p.z - ballPos.z);
                if (distToBall < 1.25 && ballPos.y < 1.3 && p.kickAnim <= 0) {
                  const fx = Math.sin(p.facing);
                  const fz = Math.cos(p.facing);
                  ballPos.x = THREE.MathUtils.lerp(ballPos.x, p.x + fx * 0.85, 0.38);
                  ballPos.z = THREE.MathUtils.lerp(ballPos.z, p.z + fz * 0.85, 0.38);
                  ballVel.x = p.vx * 1.08;
                  ballVel.z = p.vz * 1.08;
                  lastTouchTeam = 'home';
                  lastTouchName = p.name;
                }
              } else if (p.isGk) {
                // Goalkeeper Positioning & Diving Save AI
                const goalLineX = p.team === 'home' ? -HALF_W + 1.8 : HALF_W - 1.8;
                const desiredZ = THREE.MathUtils.clamp(ballPos.z * 0.35, -GOAL_W * 0.44, GOAL_W * 0.44);
                const dx = goalLineX - p.x;
                const dz = desiredZ - p.z;
                targetVx = THREE.MathUtils.clamp(dx * 4, -6, 6);
                targetVz = THREE.MathUtils.clamp(dz * 4.5, -7.5, 7.5);

                const distToBall = Math.hypot(p.x - ballPos.x, p.z - ballPos.z);
                if (distToBall < 1.85 && ballPos.y < 2.2) {
                  // Goalkeeper Save + Clearance!
                  const clearDirX = p.team === 'home' ? 1 : -1;
                  const clearDirZ = (Math.random() - 0.5) * 1.1;
                  const wasShot = Math.abs(ballVel.x) > 14;
                  kickBall(p, clearDirX, clearDirZ, 22, 4.2, false);
                  p.diveAnim = 0.4;
                  if (wasShot && isMatch) {
                    soundEngine.playCrowdChance();
                    soundEngine.speakCommentary('save', languageRef.current);
                  }
                }
              } else {
                // Outfield AI (Teammates + CPU Opponents)
                const isPrimaryChaser =
                  (p.team === 'home' && i === closestHomeIdx && (!isMatch || closestHomeDist < controlledDist * 0.65)) ||
                  (p.team === 'away' && i === closestAwayIdx) ||
                  (!isMatch && ((p.team === 'home' && i === closestHomeIdx) || (p.team === 'away' && i === closestAwayIdx)));

                const distToBall = Math.hypot(p.x - ballPos.x, p.z - ballPos.z);

                if (isPrimaryChaser) {
                  const dx = ballPos.x - p.x;
                  const dz = ballPos.z - p.z;
                  const d = Math.hypot(dx, dz) || 1;
                  targetVx = (dx / d) * baseMaxSpeed * 0.96;
                  targetVz = (dz / d) * baseMaxSpeed * 0.96;

                  if (distToBall < 1.3 && ballPos.y < 1.35 && p.kickAnim <= 0) {
                    const attackDir = p.team === 'home' ? 1 : -1;
                    const distToGoal = Math.abs(attackDir * HALF_W - p.x);

                    if (distToGoal < 25 && Math.random() < 0.08 * aiReaction) {
                      // AI Shoot!
                      const gx = attackDir * HALF_W - p.x;
                      const gz = (Math.random() - 0.5) * (GOAL_W * 0.85) - p.z;
                      kickBall(p, gx, gz, 25 + (p.sho / 99) * 8, 2.5 + Math.random() * 2, true);
                    } else if (Math.random() < 0.045 * aiReaction) {
                      // AI Pass!
                      const mate = findBestPassTarget(p, attackDir, (Math.random() - 0.5) * 0.8);
                      if (mate) {
                        kickBall(p, mate.x - p.x, mate.z - p.z, 17, 0.4, false);
                      }
                    } else {
                      // AI Dribble towards opponent goal
                      const dribX = attackDir * HALF_W - p.x;
                      const dribZ = -p.z * 0.35 + Math.sin(elapsedTotal * 2 + i) * 6;
                      const dl = Math.hypot(dribX, dribZ) || 1;
                      ballPos.x = THREE.MathUtils.lerp(ballPos.x, p.x + (dribX / dl) * 0.85, 0.34);
                      ballPos.z = THREE.MathUtils.lerp(ballPos.z, p.z + (dribZ / dl) * 0.85, 0.34);
                      ballVel.x = (dribX / dl) * 8.2;
                      ballVel.z = (dribZ / dl) * 8.2;
                      lastTouchTeam = p.team;
                      lastTouchName = p.name;
                    }
                  }
                } else {
                  // Tactical Zone Positioning & Infiltrations
                  const shiftX = ballRatioX * 16;
                  const shiftZ = (ballPos.z / HALF_H) * 6;
                  const desiredX = THREE.MathUtils.clamp(p.homeX + shiftX, -HALF_W + 4, HALF_W - 4);
                  const desiredZ = THREE.MathUtils.clamp(p.homeZ + shiftZ, -HALF_H + 2, HALF_H - 2);
                  const dx = desiredX - p.x;
                  const dz = desiredZ - p.z;
                  const d = Math.hypot(dx, dz);
                  if (d > 1.2) {
                    targetVx = (dx / d) * Math.min(baseMaxSpeed * 0.82, d * 2.2);
                    targetVz = (dz / d) * Math.min(baseMaxSpeed * 0.82, d * 2.2);
                  }
                  p.stamina = Math.min(100, p.stamina + 10 * dt);
                }
              }
            }

            // Smooth velocity damping
            const accel = 1 - Math.exp(-10 * dt);
            p.vx = THREE.MathUtils.lerp(p.vx, targetVx, accel);
            p.vz = THREE.MathUtils.lerp(p.vz, targetVz, accel);
            p.x = THREE.MathUtils.clamp(p.x + p.vx * dt, -HALF_W - 1, HALF_W + 1);
            p.z = THREE.MathUtils.clamp(p.z + p.vz * dt, -HALF_H - 1, HALF_H + 1);

            const spd = Math.hypot(p.vx, p.vz);
            if (spd > 0.4) {
              const targetFacing = Math.atan2(p.vx, p.vz);
              let diffAng = targetFacing - p.facing;
              while (diffAng > Math.PI) diffAng -= Math.PI * 2;
              while (diffAng < -Math.PI) diffAng += Math.PI * 2;
              p.facing += diffAng * (1 - Math.exp(-12 * dt));
              p.runCycle += spd * dt * 2.1;
            } else {
              p.runCycle = THREE.MathUtils.lerp(p.runCycle, 0, 0.15);
            }

            // Animate composite limbs
            if (p.kickAnim > 0) p.kickAnim = Math.max(0, p.kickAnim - dt);
            if (p.diveAnim > 0) p.diveAnim = Math.max(0, p.diveAnim - dt);

            const swing = spd > 0.4 ? Math.sin(p.runCycle) * 0.65 : 0;
            const kickBoost = p.kickAnim > 0 ? Math.sin((p.kickAnim / 0.28) * Math.PI) * 1.15 : 0;

            p.legL.rotation.x = swing;
            p.legR.rotation.x = -swing - kickBoost;
            p.armL.rotation.x = -swing * 0.7;
            p.armR.rotation.x = swing * 0.7;

            p.mesh.position.set(p.x, p.diveAnim > 0 ? 0.15 : 0, p.z);
            p.mesh.rotation.y = p.facing;
            p.mesh.rotation.z = p.diveAnim > 0 ? Math.sin((p.diveAnim / 0.4) * Math.PI) * 0.75 : 0;
          }

          // Update Active Player Indicator Ring & Aim Arrow
          if (isMatch && controlledPlayer) {
            activeRingMesh.visible = true;
            aimArrowMesh.visible = true;
            activeRingMesh.position.set(controlledPlayer.x, 0.04, controlledPlayer.z);
            const fx = Math.sin(controlledPlayer.facing);
            const fz = Math.cos(controlledPlayer.facing);
            aimArrowMesh.position.set(controlledPlayer.x + fx * 1.05, 0.05, controlledPlayer.z + fz * 1.05);
            aimArrowMesh.rotation.y = controlledPlayer.facing;
          } else {
            activeRingMesh.visible = false;
            aimArrowMesh.visible = false;
          }

          // Animate Rain Particles
          if (rainPoints.visible) {
            const posAttr = rainGeo.attributes.position as THREE.BufferAttribute;
            for (let i = 0; i < rainCount; i++) {
              let ry = posAttr.getY(i) - 32 * dt;
              if (ry < 0) ry = 32;
              posAttr.setY(i, ry);
            }
            posAttr.needsUpdate = true;
          }

          // Animate Confetti Burst
          if (celebrationTimer > 0) {
            const posAttr = confettiGeo.attributes.position as THREE.BufferAttribute;
            for (let i = 0; i < confettiCount; i++) {
              const vx = confettiVel[i].x;
              const vy = confettiVel[i].y - 14 * dt;
              const vz = confettiVel[i].z;
              confettiVel[i].y = vy;
              posAttr.setXYZ(
                i,
                posAttr.getX(i) + vx * dt,
                Math.max(0.1, posAttr.getY(i) + vy * dt),
                posAttr.getZ(i) + vz * dt
              );
            }
            posAttr.needsUpdate = true;
          }

          // Animate Crowd Excitation during goals
          if (crowdInstanced && crowdBaseMatrices.length > 0) {
            const cheerAmp = phase === 'goal' ? 0.55 : 0.08;
            const cheerFreq = phase === 'goal' ? 11 : 2.2;
            const mat4 = new THREE.Matrix4();
            for (let i = 0; i < crowdBaseMatrices.length; i += 3) {
              mat4.copy(crowdBaseMatrices[i]);
              const bounce = Math.abs(Math.sin(elapsedTotal * cheerFreq + i)) * cheerAmp;
              mat4.elements[13] += bounce;
              crowdInstanced.setMatrixAt(i, mat4);
            }
            crowdInstanced.instanceMatrix.needsUpdate = true;
          }
        }
      }

      // Smooth Camera Choreography (TV Broadcast Damping / Showcase Orbit)
      if (!isMatch) {
        const orbitAngle = elapsedTotal * 0.14;
        _camTarget.set(Math.cos(orbitAngle) * 48, 24 + Math.sin(elapsedTotal * 0.25) * 4, Math.sin(orbitAngle) * 38);
        _camLook.set(0, 1.5, 0);
        camera.position.lerp(_camTarget, 1 - Math.exp(-3.5 * dt));
        camera.lookAt(_camLook);
      } else {
        const preset = cameraPresetRef.current;
        if (phase === 'goal' && goalTeam) {
          const gx = goalTeam === 'home' ? HALF_W - 6 : -HALF_W + 6;
          _camTarget.set(gx * 0.72, 9.5, 16);
          _camLook.set(gx, 1.5, 0);
        } else if (preset === 'endToEnd') {
          _camTarget.set(ballPos.x - 24, 17, ballPos.z * 0.55);
          _camLook.set(ballPos.x + 12, 1, ballPos.z * 0.4);
        } else if (preset === 'tele') {
          _camTarget.set(ballPos.x * 0.78, 34, 42 + ballPos.z * 0.28);
          _camLook.set(ballPos.x * 0.85, 0, ballPos.z * 0.55);
        } else {
          // TV Broadcast (Dynamic side view with subtle zoom near penalty boxes)
          const boxZoom = Math.max(0, (Math.abs(ballPos.x) - 20) / 26) * 5.5;
          _camTarget.set(ballPos.x * 0.82, 23 - boxZoom * 0.65, 36 - boxZoom + ballPos.z * 0.3);
          _camLook.set(ballPos.x * 0.9, 0.5, ballPos.z * 0.55);
        }

        const camSmooth = 1 - Math.exp(-5.5 * dt);
        camera.position.lerp(_camTarget, camSmooth);
        if (shakeIntensity > 0.01) {
          camera.position.x += (Math.random() - 0.5) * shakeIntensity;
          camera.position.y += (Math.random() - 0.5) * shakeIntensity;
          shakeIntensity *= Math.exp(-7 * dt);
        }
        camera.lookAt(_camLook);
      }

      renderer.render(scene, camera);

      // Push throttled HUD snapshot (~10Hz or immediately on phase/score change)
      hudAccumulator += dt;
      if (isMatch && hudAccumulator >= 0.1) {
        hudAccumulator = 0;
        const zoneTension = phase === 'goal' ? 1 : 0.2 + Math.pow(Math.min(1, Math.abs(ballPos.x) / HALF_W), 1.5) * 0.75;
        soundEngine.setCrowdExcitement(zoneTension);
        const totalRealSeconds = Math.max(60, matchConfigRef.current.durationMinutes * 60);
        const rawMin = Math.floor((elapsedMatchSec / totalRealSeconds) * 90);
        const matchMinute = half === 1 ? Math.min(45, rawMin) : Math.min(90, Math.max(45, rawMin));
        const cp = simPlayers[activeHomeIndex] || simPlayers[9];
        callbacksRef.current.onHudUpdate({
          homeScore,
          awayScore,
          matchMinute,
          addedMinutes,
          half,
          phase,
          goalTeam,
          goalScorer,
          activePlayerName: cp?.name || '',
          activePlayerPos: cp?.pos || 'ATA',
          activePlayerOvr: cp?.ovr || 84,
          activePlayerStamina: Math.round(cp?.stamina ?? 100),
          hasBall: cp ? Math.hypot(cp.x - ballPos.x, cp.z - ballPos.z) < 2.0 : false,
          radarPlayers: simPlayers.map((pl, idx) => ({
            x: (pl.x + HALF_W) / PITCH_W,
            z: (pl.z + HALF_H) / PITCH_H,
            team: pl.team,
            active: idx === activeHomeIndex,
          })),
          radarBall: {
            x: (ballPos.x + HALF_W) / PITCH_W,
            z: (ballPos.z + HALF_H) / PITCH_H,
          },
        });
      }

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      cleanupDynamicResources();
      shadowGeo.dispose();
      torsoGeo.dispose();
      shortsGeo.dispose();
      thighGeo.dispose();
      sockGeo.dispose();
      bootGeo.dispose();
      armGeo.dispose();
      headGeo.dispose();
      hairShortGeo.dispose();
      hairFadeGeo.dispose();
      hairAfroGeo.dispose();
      hairMohawkGeo.dispose();
      hairLongTailGeo.dispose();
      numberBadgeGeo.dispose();
      ringGeo.dispose();
      arrowGeo.dispose();
      rainGeo.dispose();
      confettiGeo.dispose();
      ballMesh.geometry.dispose();
      ballMat.dispose();
      ballTex.dispose();
      contactShadowTex.dispose();
      shadowMat.dispose();
      skinMat.dispose();
      hairMatDark.dispose();
      hairMatLight.dispose();
      bootMat.dispose();
      activeRingMat.dispose();
      rainMat.dispose();
      confettiMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 w-full h-full overflow-hidden select-none"
      style={{ zIndex: 0 }}
    />
  );
};
