import React, { useState, useEffect, useRef } from 'react';
import { X, Check, SkipForward, RotateCcw, Sparkles } from 'lucide-react';
import { BacklogItem } from '../types';
import { SUBJECT_CONFIGS, SubjectConfig } from '../data/batchData';

interface BacklogModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: BacklogItem[];
  onMarkDone: (item: BacklogItem) => void;
  initialFilter?: 'all' | 'T1' | 'L' | 'M' | 'T';
}

export const BacklogModal: React.FC<BacklogModalProps> = ({
  isOpen,
  onClose,
  items,
  onMarkDone,
  initialFilter = 'all',
}) => {
  const [filter, setFilter] = useState<'all' | 'T1' | 'L' | 'M' | 'T'>(initialFilter);
  const [skippedMap, setSkippedMap] = useState<Record<string, boolean>>({});
  const [clearedByGroup, setClearedByGroup] = useState<{
    all: number;
    T1: number;
    L: number;
    M: number;
    T: number;
  }>({ all: 0, T1: 0, L: 0, M: 0, T: 0 });
  const [swipeOffset, setSwipeOffset] = useState<number>(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isFlipped, setIsFlipped] = useState(false);

  const prevOpenRef = useRef(false);
  const dragStartXRef = useRef<number | null>(null);
  const didDragRef = useRef<boolean>(false);

  // Only reset session counters when modal transitions from closed -> open
  useEffect(() => {
    if (isOpen && !prevOpenRef.current) {
      setFilter(initialFilter);
      setSkippedMap({});
      setClearedByGroup({ all: 0, T1: 0, L: 0, M: 0, T: 0 });
      setSwipeOffset(0);
      setIsAnimating(false);
      setIsFlipped(false);
    }
    prevOpenRef.current = isOpen;
  }, [isOpen, initialFilter]);

  const matchesFilter = (item: BacklogItem, f: 'all' | 'T1' | 'L' | 'M' | 'T') => {
    if (f === 'all') return true;
    if (f === 'T1') return item.priorityTier === 1;
    return item.g === f;
  };

  // Counts of remaining items for each group
  const counts = {
    all: items.length,
    T1: items.filter((x) => x.priorityTier === 1).length,
    L: items.filter((x) => x.g === 'L').length,
    M: items.filter((x) => x.g === 'M').length,
    T: items.filter((x) => x.g === 'T').length,
  };

  // Filtered active (non-skipped) list
  const activeList = items.filter(
    (item) => !skippedMap[item.id] && matchesFilter(item, filter)
  );

  // Skipped count for current filter
  const skippedCount = items.filter(
    (item) => skippedMap[item.id] && matchesFilter(item, filter)
  ).length;

  const clearedCount = clearedByGroup[filter];
  const totalDeck = clearedCount + skippedCount + activeList.length;

  const currentItem = activeList[0];

  // Reset flip state whenever the top card changes
  useEffect(() => {
    setIsFlipped(false);
  }, [currentItem?.id, filter]);

  const handleDone = () => {
    if (!currentItem || isAnimating) return;
    const targetItem = currentItem;
    setIsAnimating(true);
    setSwipeOffset(220);

    setTimeout(() => {
      onMarkDone(targetItem);
      setClearedByGroup((prev) => ({
        ...prev,
        all: prev.all + 1,
        T1: targetItem.priorityTier === 1 ? prev.T1 + 1 : prev.T1,
        [targetItem.g]: prev[targetItem.g] + 1,
      }));
      setSwipeOffset(0);
      setIsFlipped(false);
      setIsAnimating(false);
    }, 180);
  };

  const handleSkip = () => {
    if (!currentItem || isAnimating) return;
    const targetItem = currentItem;
    setIsAnimating(true);
    setSwipeOffset(-220);

    setTimeout(() => {
      setSkippedMap((prev) => ({ ...prev, [targetItem.id]: true }));
      setSwipeOffset(0);
      setIsFlipped(false);
      setIsAnimating(false);
    }, 180);
  };

  const handleResetDeck = () => {
    setSkippedMap({});
    setClearedByGroup((prev) => ({
      ...prev,
      [filter]: 0,
      ...(filter === 'all' ? { all: 0, T1: 0, L: 0, M: 0, T: 0 } : {}),
    }));
    setSwipeOffset(0);
    setIsFlipped(false);
    setIsAnimating(false);
  };

  // Pointer drag / swipe & click-to-flip handlers on top card
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isAnimating) return;
    dragStartXRef.current = e.clientX;
    didDragRef.current = false;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore pointer capture errors
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStartXRef.current === null || isAnimating) return;
    const dx = e.clientX - dragStartXRef.current;
    if (Math.abs(dx) > 6) {
      didDragRef.current = true;
    }
    setSwipeOffset(dx);
  };

  const handlePointerEnd = () => {
    if (dragStartXRef.current === null || isAnimating) return;
    const wasDragged = didDragRef.current;
    dragStartXRef.current = null;
    didDragRef.current = false;

    if (swipeOffset > 80) {
      handleDone();
    } else if (swipeOffset < -80) {
      handleSkip();
    } else {
      setSwipeOffset(0);
      if (!wasDragged) {
        setIsFlipped((prev) => !prev);
      }
    }
  };

  const handlePointerCancel = () => {
    dragStartXRef.current = null;
    didDragRef.current = false;
    setSwipeOffset(0);
  };

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleDone();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleSkip();
      } else if (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        setIsFlipped((prev) => !prev);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  if (!isOpen) return null;

  // Arc Gauge calculation
  const safeTotal = totalDeck || 1;
  const pc = Math.min(1, clearedCount / safeTotal);
  const ps = Math.min(1, skippedCount / safeTotal);

  const getArcPath = (f0: number, f1: number) => {
    if (f1 - f0 <= 0.001) return '';
    const safeF1 = Math.min(f1, 0.9999);
    const p0 = [140 - 105 * Math.cos(f0 * Math.PI), 125 - 105 * Math.sin(f0 * Math.PI)];
    const p1 = [140 - 105 * Math.cos(safeF1 * Math.PI), 125 - 105 * Math.sin(safeF1 * Math.PI)];
    return `M ${p0[0].toFixed(1)} ${p0[1].toFixed(1)} A 105 105 0 0 1 ${p1[0].toFixed(1)} ${p1[1].toFixed(1)}`;
  };

  const subjectConfig: SubjectConfig | undefined = currentItem
    ? SUBJECT_CONFIGS[currentItem.s as keyof typeof SUBJECT_CONFIGS]
    : undefined;
  const subjectName = subjectConfig ? subjectConfig.name : currentItem?.s || '';
  const isLectureCard = currentItem?.g === 'L';

  const getTierDetails = (item?: BacklogItem) => {
    if (!item) {
      return {
        badge: 'Tier 3 · Booster',
        cls: 'bg-zinc-800 text-zinc-300 border-zinc-700',
        glow: 'from-zinc-800/40 via-zinc-900/90 to-zinc-950',
        note: 'Complete this task to keep your chapter progress on track.',
      };
    }

    const mat = item.m || item.kd;
    let note = 'Complete this material to stay ahead of your batch schedule.';
    if (mat === 'Lectures' || item.kd === 'Lecture') {
      note = 'Watch the lecture & complete class notes first before starting DPPs or sheets.';
    } else if (mat === 'DPP') {
      note = 'Core Daily Practice Problem — solve right after the lecture to lock in concepts.';
    } else if (mat === 'KPP Practice Sheet') {
      note = 'Top-priority Physics KPP sheet — essential for numerical speed and accuracy.';
    } else if (mat === 'Class Questions') {
      note = 'Re-solve teacher class illustrations without looking at the solution first.';
    } else if (mat === 'Red Sheet (Tulki Mam)') {
      note = 'High-yield Zoology Red Sheet — revise key NCERT & teacher points thoroughly.';
    } else if (mat === 'Question Practice Lecture') {
      note = 'Botany question practice session — master application of NCERT lines.';
    } else if (mat.includes('PYQ') || mat === 'Motikitab NEET') {
      note = 'NEET Previous Year Questions — verify exam-level pattern accuracy.';
    } else if (item.kd === 'Test') {
      note = 'Missed batch test — attempt with a strict timer and log your subject-wise marks.';
    } else {
      note = 'Booster practice material — tackle after finishing Tier 1 & Tier 2 items.';
    }

    if (item.priorityTier === 1) {
      return {
        badge: '🔥 Tier 1 · Top Priority',
        cls: 'bg-orange-500/20 text-orange-300 border-orange-500/50',
        glow: 'from-[#3b1d5e] via-[#1a1128] to-[#0f0d16]',
        note,
      };
    }
    if (item.priorityTier === 2) {
      return {
        badge: '⚡ Tier 2 · Core Practice',
        cls: 'bg-purple-500/20 text-purple-300 border-purple-500/50',
        glow: 'from-[#291749] via-[#151024] to-[#0d0c14]',
        note,
      };
    }
    return {
      badge: '📘 Tier 3 · Booster',
      cls: 'bg-zinc-800 text-zinc-300 border-zinc-700',
      glow: 'from-[#1f1f2e] via-[#13131c] to-[#0c0c12]',
      note,
    };
  };

  const tierInfo = getTierDetails(currentItem);

  return (
    <div
      role="dialog"
      aria-label="Backlog Flashcards"
      className="fixed inset-0 z-50 bg-black/92 backdrop-blur-xl text-white flex flex-col p-4 overflow-y-auto animate-in fade-in duration-200"
    >
      {/* Top Bar: Header & Filter Chips */}
      <div className="w-full max-w-md mx-auto flex flex-col items-center pt-1">
        <div className="w-full flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-lg">⚡</span>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              Backlog Flashcards
            </h2>
            <span className="text-xs text-zinc-400 font-medium">
              ({items.length} left)
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Backlog Flashcards"
            className="w-10 h-10 rounded-full bg-zinc-900/90 border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter chips */}
        <div className="w-full flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {(
            [
              ['all', 'All'],
              ['T1', '🔥 Tier 1'],
              ['L', 'Lectures'],
              ['M', 'Materials'],
              ['T', 'Tests'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                filter === key
                  ? 'bg-white text-[#0b0b0f] font-bold shadow-sm'
                  : 'bg-zinc-900/90 text-zinc-400 border border-zinc-800/90 hover:text-zinc-200'
              }`}
            >
              {label} · {counts[key]}
            </button>
          ))}
        </div>
      </div>

      {/* Vertically Centered Flashcard & Controls Block */}
      <div className="w-full max-w-md mx-auto flex flex-col items-center justify-center my-auto py-4">
        {activeList.length === 0 ? (
          <div className="w-full py-12 px-4 text-center space-y-4">
            <div className="text-5xl">🎉</div>
            <div className="space-y-1">
              <h3 className="text-xl font-black text-white">
                {counts[filter] === 0 ? 'Backlog Clear!' : 'Deck Finished'}
              </h3>
              <p className="text-xs text-zinc-400">
                Cleared: <strong className="text-emerald-400">{clearedCount}</strong> · Skipped:{' '}
                <strong className="text-amber-400">{skippedCount}</strong> · Left in backlog:{' '}
                <strong>{counts[filter]}</strong>
              </p>
            </div>
          </div>
        ) : (
          /* 3D Flip Card Stack */
          <div className="relative w-full max-w-[340px] h-[260px] my-2 select-none perspective-1000">
            {/* Background card 2 */}
            {activeList[2] && (
              <div className="absolute inset-0 rounded-[24px] bg-zinc-900/35 border border-zinc-800/40 transform translate-y-3.5 scale-[0.92] opacity-40 pointer-events-none" />
            )}

            {/* Background card 1 */}
            {activeList[1] && (
              <div className="absolute inset-0 rounded-[24px] bg-zinc-900/65 border border-zinc-800/60 transform translate-y-2 scale-[0.96] opacity-70 pointer-events-none" />
            )}

            {/* Swipeable + Click-to-Flip Active Card Wrapper */}
            <div
              role="button"
              tabIndex={0}
              aria-label="Flashcard — tap or click to flip for priority and study note, or swipe left/right"
              aria-pressed={isFlipped}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerEnd}
              onPointerCancel={handlePointerCancel}
              style={{
                transform: `translateX(${swipeOffset}px) rotate(${swipeOffset / 16}deg)`,
                transition:
                  dragStartXRef.current !== null
                    ? 'none'
                    : 'transform 0.2s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.18s',
                opacity: isAnimating ? 0 : 1,
                touchAction: 'none',
              }}
              className="w-full h-full cursor-grab active:cursor-grabbing focus:outline-none"
            >
              <div className={`flip-card-inner ${isFlipped ? 'is-flipped' : ''}`}>
                {/* FRONT FACE (Original Text & Location Inside Card; Priority Hidden until Clicked) */}
                <div
                  className={`flip-card-face rounded-[24px] bg-gradient-to-b ${tierInfo.glow} border border-white/15 p-5 flex flex-col justify-between text-center shadow-[0_20px_50px_rgba(0,0,0,0.75)] overflow-hidden`}
                >
                  {/* Top Row: #Rank pill + Tap to flip hint */}
                  <div className="w-full flex items-center justify-between z-10">
                    <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-black/65 backdrop-blur-md text-white border border-white/10 shadow-sm">
                      #{clearedCount + skippedCount + 1}
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-black/45 backdrop-blur-md text-zinc-300 border border-white/10 flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5 text-purple-400" />
                      <span>Tap to flip</span>
                    </span>
                  </div>

                  {/* Center Content: Subject · Kind, Chapter Name, High-Visibility Material/Lecture Name */}
                  <div className="my-auto py-1 flex flex-col items-center">
                    <div
                      style={{ color: subjectConfig?.color || '#a1a1aa' }}
                      className="text-[11px] font-extrabold uppercase tracking-widest mb-1.5"
                    >
                      {subjectName} · {currentItem.kd}
                    </div>
                    <div className="text-base sm:text-lg font-extrabold text-zinc-100 leading-snug mb-3.5 line-clamp-2 px-1">
                      {currentItem.c}
                    </div>
                    <div className="inline-flex items-center justify-center gap-2.5 bg-white/14 border-2 border-purple-400/55 shadow-[0_6px_24px_rgba(168,85,247,0.28)] rounded-2xl px-5 py-2.5 max-w-full">
                      <span className="text-lg sm:text-xl shrink-0">{currentItem.ic}</span>
                      <span className="text-lg sm:text-xl font-black text-white tracking-tight truncate">
                        {currentItem.d}
                      </span>
                    </div>
                  </div>

                  {/* Bottom subtle prompt */}
                  <div className="text-[10px] font-medium text-zinc-400/90 tracking-wide">
                    Tap card to reveal priority & study note
                  </div>
                </div>

                {/* BACK FACE (Reveals Priority Tier, Rank & Study Note) */}
                <div className="flip-card-face flip-card-back rounded-[24px] bg-gradient-to-b from-[#23143c] via-[#130d21] to-[#0b0a10] border border-purple-500/40 p-5 flex flex-col items-center justify-between text-center shadow-[0_20px_50px_rgba(0,0,0,0.85)]">
                  {/* Top Row */}
                  <div className="w-full flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-black/60 text-zinc-300 border border-white/10">
                      #{clearedCount + skippedCount + 1}
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-black/45 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                      <RotateCcw className="w-2.5 h-2.5" />
                      <span>Flip back</span>
                    </span>
                  </div>

                  {/* Priority Badge & Study Note */}
                  <div className="flex flex-col items-center justify-center my-auto space-y-2 px-2">
                    <span
                      className={`px-3.5 py-1 rounded-full text-xs font-extrabold border shadow-sm ${tierInfo.cls}`}
                    >
                      {tierInfo.badge}
                    </span>
                    <div className="text-xs font-extrabold text-white">
                      Priority #{currentItem.priorityRank} · {currentItem.d}
                    </div>
                    <div className="mt-1 p-3 rounded-2xl bg-black/45 border border-white/10 text-xs leading-relaxed text-zinc-200 font-medium">
                      {tierInfo.note}
                    </div>
                  </div>

                  {/* Bottom Chapter Context */}
                  <div className="text-[10px] font-medium text-zinc-400 truncate max-w-full">
                    {subjectName} • {currentItem.c}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Progress Arc Gauge (Moctale Green + Purple Arc) */}
        <div className="mt-4 mb-1 text-center flex flex-col items-center">
          <div className="relative w-[260px] h-[115px]">
            <svg viewBox="0 0 280 140" className="w-[260px] h-[115px]">
              {/* Background Track */}
              <path
                d={getArcPath(0, 1)}
                fill="none"
                stroke="#232329"
                strokeWidth="20"
                strokeLinecap="round"
              />
              {/* Skipped arc (Moctale vibrant green) */}
              {ps > 0 && (
                <path
                  d={getArcPath(0, ps)}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="20"
                  strokeLinecap="round"
                />
              )}
              {/* Cleared arc (Moctale vibrant purple) */}
              {pc > 0 && (
                <path
                  d={getArcPath(ps, Math.min(1, ps + pc))}
                  fill="none"
                  stroke="#a855f7"
                  strokeWidth="20"
                  strokeLinecap="round"
                />
              )}
            </svg>
            <div className="absolute inset-x-0 top-[44px] text-center">
              <div className="text-2xl font-black text-[#b56bff]">
                {Math.round(pc * 100)}%
              </div>
              <div className="text-[11px] font-medium text-zinc-400">
                {clearedCount}/{totalDeck} Cleared
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons (Moctale Pill-Bordered Bottom Buttons) */}
        {activeList.length > 0 ? (
          <div className="flex gap-3 w-full max-w-[340px] mt-1">
            <button
              type="button"
              onClick={handleDone}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-[#22103b]/90 hover:bg-[#2d154e] border border-purple-500/50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] cursor-pointer"
            >
              <Check className="w-4 h-4 text-purple-300" />
              <span>{isLectureCard ? 'Mark watched' : 'Mark done'}</span>
            </button>
            <button
              type="button"
              onClick={handleSkip}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-[#111116] hover:bg-[#191920] border border-zinc-700/80 text-zinc-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
            >
              <SkipForward className="w-4 h-4 text-zinc-400" />
              <span>Skip</span>
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={handleResetDeck}
            className="w-full max-w-[340px] py-3.5 px-4 rounded-2xl bg-[#22103b] hover:bg-[#2d154e] border border-purple-500/50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Start over</span>
          </button>
        )}

        <div className="text-[11px] text-zinc-500 mt-3 text-center">
          Tap card to flip · Swipe or <kbd className="px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">→</kbd>{' '}
          {isLectureCard ? 'Watched' : 'Done'} ·{' '}
          <kbd className="px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">←</kbd> Skip
        </div>
      </div>
    </div>
  );
};

