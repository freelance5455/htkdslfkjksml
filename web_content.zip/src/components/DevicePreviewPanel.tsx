import { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Copy,
  ExternalLink,
  Play,
  RotateCcw,
  Smartphone,
  UserCheck,
  Wifi,
} from 'lucide-react';
import type {
  ApkBuildConfig,
  BuildArtifactSummary,
  UrlInspectionResult,
} from '../types/apk';
import { buildPreviewSrcDoc } from '../lib/templates';
import { buildManifestXmlText } from '../lib/apkCore/axmlCompiler';
import { buildDeveloperAboutHtml } from '../lib/apkCore/htmlGenerators';

interface DevicePreviewPanelProps {
  config: ApkBuildConfig;
  inspection: UrlInspectionResult | null;
  latestBuild: BuildArtifactSummary | null;
  previewIconUrl: string;
  splashNonce: number;
}

type InspectorTab = 'device' | 'manifest' | 'tree';

export function DevicePreviewPanel({
  config,
  inspection,
  latestBuild,
  previewIconUrl,
  splashNonce,
}: DevicePreviewPanelProps) {
  const [activeTab, setActiveTab] = useState<InspectorTab>('device');
  const [showSplash, setShowSplash] = useState(false);
  const [reloadNonce, setReloadNonce] = useState(0);
  const [copiedManifest, setCopiedManifest] = useState(false);
  const [previewDevPage, setPreviewDevPage] = useState(false);
  const [simulatedAdsRemoved, setSimulatedAdsRemoved] = useState(false);

  const isLandscape = config.orientation === 'landscape';

  const manifestText = useMemo(
    () => latestBuild?.manifestXmlPreview || buildManifestXmlText(config),
    [config, latestBuild]
  );

  const htmlSrcDoc = useMemo(() => {
    if (previewDevPage) {
      return buildDeveloperAboutHtml(config);
    }
    if (config.sourceMode === 'code') {
      return (
        config.rawHtmlCode ||
        '<html><body style="font-family:sans-serif;padding:24px;">Paste HTML code to preview.</body></html>'
      );
    }
    if (config.sourceMode === 'html') {
      return buildPreviewSrcDoc(config.htmlFiles, config.htmlEntryFile);
    }
    return '';
  }, [
    config,
    previewDevPage,
  ]);

  const projectedEntries = useMemo(() => {
    if (latestBuild) return latestBuild.entries;
    const base = [
      { path: 'AndroidManifest.xml', sizeBytes: 1420, compression: 'DEFLATE' },
      { path: 'classes.dex', sizeBytes: 1680, compression: 'DEFLATE' },
      { path: 'resources.arsc', sizeBytes: 620, compression: 'STORE' },
      { path: 'res/mipmap/ic_launcher.png', sizeBytes: 8400, compression: 'STORE' },
    ];
    if (config.sourceMode === 'code') {
      base.push({
        path: 'assets/index.html',
        sizeBytes: new TextEncoder().encode(config.rawHtmlCode || '').length,
        compression: 'DEFLATE',
      });
    } else if (config.sourceMode === 'html') {
      config.htmlFiles.forEach((f) => {
        base.push({
          path: `assets/${f.path}`,
          sizeBytes: f.size,
          compression: 'DEFLATE',
        });
      });
    }
    if (config.developer.includeAboutPageInAssets) {
      base.push({
        path: 'assets/developer.html',
        sizeBytes: 1850,
        compression: 'DEFLATE',
      });
    }
    base.push(
      { path: 'META-INF/MANIFEST.MF', sizeBytes: 480, compression: 'DEFLATE' },
      { path: 'META-INF/CERT.SF', sizeBytes: 510, compression: 'DEFLATE' },
      { path: 'META-INF/CERT.RSA', sizeBytes: 1320, compression: 'DEFLATE' }
    );
    return base;
  }, [latestBuild, config]);

  useEffect(() => {
    if (splashNonce > 0 && config.splash.enabled) {
      setActiveTab('device');
      setShowSplash(true);
    }
  }, [splashNonce, config.splash.enabled]);

  useEffect(() => {
    if (!showSplash) return;
    const dur = Math.max(400, Math.min(4000, config.splash.durationMs));
    const timer = setTimeout(() => setShowSplash(false), dur);
    return () => clearTimeout(timer);
  }, [showSplash, config.splash.durationMs]);

  const handleCopyManifest = async () => {
    try {
      await navigator.clipboard.writeText(manifestText);
      setCopiedManifest(true);
      setTimeout(() => setCopiedManifest(false), 1500);
    } catch {
      // Clipboard unavailable
    }
  };

  const statusTextColor =
    config.statusBarStyle === 'light' ? 'text-white' : 'text-slate-900';

  const splashLogoSrc = config.splash.customLogoBase64Png
    ? `data:image/png;base64,${config.splash.customLogoBase64Png}`
    : previewIconUrl;

  const splashLogoSizeClass =
    config.splash.logoScale === 'lg'
      ? 'w-20 h-20'
      : config.splash.logoScale === 'sm'
        ? 'w-12 h-12'
        : 'w-16 h-16';

  return (
    <aside className="bg-white border border-slate-200 rounded-xl flex flex-col overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('device')}
            className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'device'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Preview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manifest')}
            className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'manifest'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Manifest
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('tree')}
            className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'tree'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Contents
          </button>
        </div>

        {activeTab === 'device' && (
          <div className="flex items-center gap-1.5 shrink-0">
            {config.developer.includeAboutPageInAssets && (
              <button
                type="button"
                onClick={() => setPreviewDevPage((v) => !v)}
                title="Toggle Developer & Social Links page"
                className={`inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium border rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  previewDevPage
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                Links
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowSplash(true)}
              disabled={!config.splash.enabled}
              title="Replay launch splash screen"
              className="inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 border border-slate-200 rounded-md hover:bg-slate-50 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5" />
              Splash
            </button>
            <button
              type="button"
              onClick={() => {
                setPreviewDevPage(false);
                setReloadNonce((n) => n + 1);
              }}
              title="Reload WebView"
              className="p-1.5 text-slate-600 hover:text-slate-900 border border-slate-200 rounded-md hover:bg-slate-50 transition-colors shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {activeTab === 'device' && (
        <div className="p-5 bg-slate-50/70 flex flex-col items-center justify-center flex-1 min-h-[600px]">
          <div
            className={`relative bg-slate-900 rounded-[28px] p-2.5 shadow-sm border border-slate-800 transition-all duration-200 ${
              isLandscape ? 'w-full max-w-[440px]' : 'w-[310px]'
            }`}
          >
            <div
              className={`bg-white rounded-[20px] overflow-hidden flex flex-col ${
                isLandscape ? 'h-[260px]' : 'h-[560px]'
              }`}
            >
              {!config.fullscreen && (
                <div
                  className={`px-4 py-1.5 flex items-center justify-between text-[11px] font-medium tabular-nums select-none shrink-0 ${statusTextColor}`}
                  style={{ backgroundColor: config.themeColor }}
                >
                  <span>9:41</span>
                  <div className="flex items-center gap-1.5">
                    <Wifi className="w-3 h-3" />
                    <span>5G</span>
                    <span>98%</span>
                  </div>
                </div>
              )}

              <div className="relative flex-1 bg-white overflow-hidden">
                {showSplash && config.splash.enabled ? (
                  <div
                    className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 z-20"
                    style={{
                      backgroundColor: config.splash.backgroundColor,
                      color: config.splash.textColor,
                    }}
                  >
                    {splashLogoSrc ? (
                      <img
                        src={splashLogoSrc}
                        alt={config.splash.headline || config.appName}
                        className={`${splashLogoSizeClass} rounded-2xl object-cover shadow-xs`}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div
                        className={`${splashLogoSizeClass} rounded-2xl bg-white/15 flex items-center justify-center font-display font-bold text-xl`}
                      >
                        {(config.splash.headline || config.appName)
                          .slice(0, 2)
                          .toUpperCase()}
                      </div>
                    )}
                    <p className="text-base font-display font-semibold mt-4">
                      {config.splash.headline || config.appName}
                    </p>
                    {config.splash.tagline && (
                      <p className="text-xs opacity-80 mt-1 max-w-[220px]">
                        {config.splash.tagline}
                      </p>
                    )}
                    {config.splash.showSpinner && (
                      <div
                        className="w-5 h-5 mt-5 rounded-full border-2 animate-spin"
                        style={{
                          borderColor: 'rgba(255,255,255,0.25)',
                          borderTopColor: config.splash.textColor,
                        }}
                      />
                    )}
                  </div>
                ) : null}

                {previewDevPage ||
                config.sourceMode === 'html' ||
                config.sourceMode === 'code' ? (
                  <iframe
                    key={`doc-${reloadNonce}-${config.sourceMode}-${config.htmlEntryFile}-${previewDevPage}`}
                    title="Android WebView HTML Preview"
                    srcDoc={htmlSrcDoc}
                    sandbox={
                      config.enableJavaScript
                        ? 'allow-scripts allow-forms allow-modals allow-popups'
                        : 'allow-forms'
                    }
                    className="w-full h-full border-0 bg-white"
                  />
                ) : inspection?.frameBlocked ? (
                  <div className="h-full flex flex-col items-center justify-center p-6 text-center bg-slate-50">
                    <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center mb-3">
                      <Smartphone className="w-5 h-5 text-slate-600" />
                    </div>
                    <p className="text-sm font-semibold text-slate-900">
                      {inspection.title || config.appName}
                    </p>
                    <p className="text-xs text-slate-500 mt-1 font-mono break-all">
                      {inspection.finalUrl}
                    </p>
                    <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                      Browser iframe embedding is restricted by this site ({inspection.frameHeaderReason}). Native Android WebView ignores this header and loads the full site directly inside the APK.
                    </p>
                    <a
                      href={inspection.finalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors whitespace-nowrap"
                    >
                      Open Target Site
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ) : (
                  <iframe
                    key={`url-${reloadNonce}-${config.websiteUrl}`}
                    title="Android WebView URL Preview"
                    src={config.websiteUrl}
                    sandbox={
                      config.enableJavaScript
                        ? 'allow-scripts allow-same-origin allow-forms allow-popups'
                        : 'allow-same-origin allow-forms'
                    }
                    className="w-full h-full border-0 bg-white"
                  />
                )}
              </div>

              {config.enableAdMob &&
                config.showBottomBanner &&
                !simulatedAdsRemoved && (
                  <div className="px-3 py-1.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between gap-2 text-[10px] text-slate-600 shrink-0">
                    <span className="font-medium text-slate-800 truncate">
                      AdMob Banner · 320×50
                    </span>
                    {config.enableRemoveAds ? (
                      <button
                        type="button"
                        onClick={() => setSimulatedAdsRemoved(true)}
                        className="px-2 py-0.5 font-medium text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                      >
                        Remove Ads ({config.removeAdsPrice || '$2.99'})
                      </button>
                    ) : (
                      <span className="font-mono text-slate-500 shrink-0">
                        Test Unit
                      </span>
                    )}
                  </div>
                )}

              <div className="h-5 bg-slate-950 flex items-center justify-center shrink-0">
                <div className="w-20 h-1 rounded-full bg-slate-600" />
              </div>
            </div>
          </div>

          <div className="mt-4 text-xs text-slate-500 flex flex-wrap items-center justify-center gap-2 tabular-nums">
            <span>{config.orientation === 'landscape' ? 'Landscape' : 'Portrait'}</span>
            <span aria-hidden="true">·</span>
            <span>API {config.minSdkVersion}+</span>
            <span aria-hidden="true">·</span>
            <span>JS {config.enableJavaScript ? 'On' : 'Off'}</span>
            {simulatedAdsRemoved && (
              <>
                <span aria-hidden="true">·</span>
                <button
                  type="button"
                  onClick={() => setSimulatedAdsRemoved(false)}
                  className="text-emerald-700 hover:underline font-medium"
                >
                  Ads removed (Restore preview)
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {activeTab === 'manifest' && (
        <div className="flex flex-col flex-1 min-h-[600px]">
          <div className="px-4 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <span className="text-xs font-mono text-slate-600">
              AndroidManifest.xml
            </span>
            <button
              type="button"
              onClick={handleCopyManifest}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap"
            >
              {copiedManifest ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy XML
                </>
              )}
            </button>
          </div>
          <pre className="p-4 text-[11px] leading-relaxed font-mono text-slate-100 bg-slate-900 overflow-auto flex-1">
            {manifestText}
          </pre>
        </div>
      )}

      {activeTab === 'tree' && (
        <div className="flex flex-col flex-1 min-h-[600px]">
          <div className="px-4 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <span className="text-xs text-slate-600">
              {latestBuild ? 'Compiled APK Archive Entries' : 'Projected APK Archive Structure'}
            </span>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {projectedEntries.length} entries
            </span>
          </div>
          <div className="divide-y divide-slate-100 overflow-auto flex-1">
            {projectedEntries.map((entry) => (
              <div
                key={entry.path}
                className="px-4 py-2.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-50"
              >
                <span className="font-mono text-slate-800 truncate">{entry.path}</span>
                <div className="flex items-center gap-3 shrink-0 tabular-nums font-mono text-slate-500">
                  <span>{entry.compression}</span>
                  <span className="w-16 text-right">
                    {(entry.sizeBytes / 1024).toFixed(1)} KB
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </aside>
  );
}
