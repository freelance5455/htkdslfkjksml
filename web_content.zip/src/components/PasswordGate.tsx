import { useState, type FormEvent } from 'react';
import { Lock, Unlock, Key, AlertTriangle, ShieldCheck, Eye, EyeOff, Sparkles } from 'lucide-react';
import { cyberAudio } from '../audio';
import CyberLogo from './CyberLogo';

interface Props {
  onSuccess: () => void;
  customLogoUrl?: string | null;
}

export default function PasswordGate({ onSuccess, customLogoUrl }: Props) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const REQUIRED_KEY = 'MEHEDIVAI115';

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    cyberAudio.playClick();
    setIsVerifying(true);
    setError(false);

    setTimeout(() => {
      // Clean up whitespace & check key
      const trimmed = password.trim();
      if (trimmed.toUpperCase() === REQUIRED_KEY) {
        cyberAudio.playAccessGranted();
        if (rememberMe) {
          localStorage.setItem('gx_team_authenticated_passkey', REQUIRED_KEY);
        }
        onSuccess();
      } else {
        cyberAudio.playAccessDenied();
        setError(true);
        setAttempts((prev) => prev + 1);
        setErrorMessage('ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন: MEHEDIVAI115');
      }
      setIsVerifying(false);
    }, 400);
  };

  const handleQuickFill = () => {
    cyberAudio.playKeyBlip();
    setPassword(REQUIRED_KEY);
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-40 bg-[#040608] flex items-center justify-center p-4 text-emerald-400 select-none scanlines">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-md bg-black/90 border border-emerald-500/50 rounded-2xl p-6 sm:p-8 shadow-[0_0_40px_rgba(0,255,136,0.2)] box-glow-green">
        {/* Top Logo & Title */}
        <div className="flex flex-col items-center text-center mb-6">
          <CyberLogo size="lg" customLogoUrl={customLogoUrl} />
          
          <h1 className="mt-4 text-xl sm:text-2xl font-black font-cyber text-emerald-300 tracking-wider neon-glow-green">
            SECURITY GATEWAY
          </h1>
          <p className="mt-1 text-xs text-emerald-500/80 font-mono">
            ভিতরে প্রবেশ করতে সিকিউরিটি পাসওয়ার্ড লিখুন
          </p>
        </div>

        {/* Security Badge */}
        <div className="mb-6 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2 text-emerald-300">
            <Lock className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>AUTHENTICATION PROTOCOL</span>
          </div>
          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
            AES-256 VIP
          </span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-emerald-400/90 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-cyan-400" /> ACCESS KEY (পাসওয়ার্ড):
              </span>
              <button
                type="button"
                onClick={handleQuickFill}
                className="text-[10px] text-cyan-400 hover:text-cyan-300 underline font-mono cursor-pointer"
              >
                [অটো বসান: {REQUIRED_KEY}]
              </button>
            </label>
            <div className="relative">
              <input
                id="passkey-input"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(false);
                }}
                placeholder="এখানে MEHEDIVAI115 লিখুন..."
                className={`w-full bg-black/80 border ${
                  error ? 'border-red-500 text-red-400 shadow-[0_0_15px_rgba(255,51,102,0.4)]' : 'border-emerald-500/60 text-emerald-300'
                } rounded-xl px-4 py-3 text-sm font-mono tracking-wider focus:outline-none focus:border-cyan-400 transition-all placeholder:text-emerald-800`}
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-500 hover:text-emerald-300 transition-colors p-1"
                title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Remember me option */}
          <div className="flex items-center justify-between text-xs font-mono text-emerald-400/80">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded accent-emerald-500 w-3.5 h-3.5 bg-black border-emerald-500 cursor-pointer"
              />
              <span>পাসওয়ার্ড মনে রাখুন (লগইন সেভ)</span>
            </label>
            {attempts > 0 && (
              <span className="text-[11px] text-red-400">
                ভুল চেষ্টা: {attempts}
              </span>
            )}
          </div>

          {/* Error Message Alert */}
          {error && (
            <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/60 text-red-300 text-xs font-mono flex items-center gap-2 animate-shake">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            id="unlock-terminal-btn"
            type="submit"
            disabled={isVerifying}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-cyber font-black text-sm tracking-wider uppercase shadow-[0_0_20px_rgba(0,255,136,0.5)] transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isVerifying ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>VERIFYING KEY...</span>
              </>
            ) : (
              <>
                <Unlock className="w-4 h-4" />
                <span>TERMINAL UNLOCK // প্রবেশ করুন</span>
              </>
            )}
          </button>
        </form>

        {/* Password Hint Card */}
        <div className="mt-6 pt-4 border-t border-emerald-500/20 text-center">
          <p className="text-[11px] font-mono text-emerald-400/80">
            দরকারি পাসওয়ার্ড: <span className="font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/40">MEHEDIVAI115</span>
          </p>
          <p className="text-[10px] text-emerald-600 mt-1.5 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-500" />
            <span>GX TEAM MEHEDI VAI OFFICIALLY SECURED</span>
          </p>
        </div>
      </div>
    </div>
  );
}
