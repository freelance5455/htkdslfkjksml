import React from 'react';
import { Home, BookOpen, Plus, BarChart3, Users } from 'lucide-react';
import { ActiveScreen } from '../types/tally';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface BottomNavBarProps {
  activeScreen: ActiveScreen;
  onSelectScreen: (screen: ActiveScreen) => void;
  onOpenNewVoucher: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeScreen,
  onSelectScreen,
  onOpenNewVoucher,
}) => {
  const isReportsActive = [
    'balancesheet',
    'profitloss',
    'trialbalance',
    'stocksummary',
    'gst_reports',
  ].includes(activeScreen);

  const isLedgersActive = ['ledgers', 'ledger_statement'].includes(activeScreen);

  const handleNav = (screen: ActiveScreen) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    onSelectScreen(screen);
  };

  const handleVoucherClick = () => {
    triggerHaptic('medium');
    soundManager.playKeyClick();
    onOpenNewVoucher();
  };

  return (
    <div className="sticky bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1.5 shadow-lg select-none">
      <div className="grid grid-cols-5 items-center justify-items-center">
        {/* 1. Gateway */}
        <button
          onClick={() => handleNav('gateway')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 transition-all touch-press ${
            activeScreen === 'gateway'
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          aria-label="Gateway of Tally"
        >
          <Home className={`w-5 h-5 ${activeScreen === 'gateway' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[10px] tracking-tight mt-0.5">Gateway</span>
        </button>

        {/* 2. Day Book */}
        <button
          onClick={() => handleNav('daybook')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 transition-all touch-press ${
            activeScreen === 'daybook'
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          aria-label="Day Book"
        >
          <BookOpen className={`w-5 h-5 ${activeScreen === 'daybook' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[10px] tracking-tight mt-0.5">Day Book</span>
        </button>

        {/* 3. Floating Quick Voucher Button */}
        <div className="relative -top-3">
          <button
            onClick={handleVoucherClick}
            className="w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 ring-4 ring-white dark:ring-slate-900 transition-all touch-press"
            aria-label="Create Voucher"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* 4. Reports */}
        <button
          onClick={() => handleNav('balancesheet')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 transition-all touch-press ${
            isReportsActive
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          aria-label="Reports"
        >
          <BarChart3 className={`w-5 h-5 ${isReportsActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[10px] tracking-tight mt-0.5">Reports</span>
        </button>

        {/* 5. Ledgers */}
        <button
          onClick={() => handleNav('ledgers')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 transition-all touch-press ${
            isLedgersActive
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          aria-label="Ledgers"
        >
          <Users className={`w-5 h-5 ${isLedgersActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[10px] tracking-tight mt-0.5">Ledgers</span>
        </button>
      </div>
    </div>
  );
};
