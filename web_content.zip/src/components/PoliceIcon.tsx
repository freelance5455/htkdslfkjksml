interface PoliceIconProps {
  name: string;
  className?: string;
}

const paths: Record<string, string> = {
  shield: 'M12 3l7 3v5c0 4.6-2.9 8.3-7 10-4.1-1.7-7-5.4-7-10V6l7-3z',
  home: 'M3 11.5L12 4l9 7.5M5.5 10v10h13V10M9 20v-6h6v6',
  guide: 'M4 5.5A2.5 2.5 0 016.5 3H11v17H6.5A2.5 2.5 0 004 22V5.5zm16 0A2.5 2.5 0 0017.5 3H13v17h4.5a2.5 2.5 0 012.5 2V5.5z',
  scales: 'M12 3v18M7 6h10M5 6l-3 7h6L5 6zm14 0l-3 7h6l-3-7zM8 21h8',
  clipboard: 'M9 4h6l1 2h3v15H5V6h3l1-2zm0 6h6m-6 4h6m-6 4h4',
  response: 'M13 3L4 14h7v7l9-11h-7V3z',
  equipment: 'M8 3h8v3l-1 1v4l5 7a2 2 0 01-1.7 3H5.7A2 2 0 014 18l5-7V7L8 6V3zm0 12h8',
  policy: 'M6 3h9l4 4v14H6V3zm9 0v5h5M9 12h7m-7 4h7',
  search: 'M11 4a7 7 0 100 14 7 7 0 000-14zm5 12l5 5',
  print: 'M7 9V3h10v6M7 18H4V10h16v8h-3m-10-4h10v7H7v-7z',
  menu: 'M4 7h16M4 12h16M4 17h16',
  close: 'M6 6l12 12M18 6L6 18',
  info: 'M12 22a10 10 0 100-20 10 10 0 000 20zm0-11v6m0-10h.01',
  warning: 'M12 3L2 21h20L12 3zm0 7v5m0 3h.01',
  check: 'M5 13l4 4L19 7',
  chevron: 'M9 5l7 7-7 7',
  radio: 'M5 8h14v12H5V8zm3-3l8-2M8 12h8m-8 4h4',
  camera: 'M4 7h4l2-3h4l2 3h4v13H4V7zm8 4a3 3 0 100 6 3 3 0 000-6z',
  document: 'M6 3h9l4 4v14H6V3zm9 0v5h5M9 12h6m-6 4h6',
  forces: 'M4 20v-8l8-5 8 5v8M8 20v-5h8v5M9 7V4h6v3',
  user: 'M12 3a4 4 0 110 8 4 4 0 010-8zm-7 18a7 7 0 0114 0',
};

const PoliceIcon = ({ name, className = 'h-5 w-5' }: PoliceIconProps) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d={paths[name] ?? paths.document} />
  </svg>
);

export default PoliceIcon;