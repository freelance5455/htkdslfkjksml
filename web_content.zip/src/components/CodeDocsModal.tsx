import React, { useState } from 'react';
import { X, Code2, BookOpen, Terminal, CheckCircle2, Copy, Check } from 'lucide-react';

interface CodeDocsModalProps {
  onClose: () => void;
}

export const CodeDocsModal: React.FC<CodeDocsModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'dns' | 'docker' | 'checklist'>('architecture');
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
        {/* HEADER */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-blue-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-600/20">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">TempBox Architecture &amp; Production Setup</h2>
              <p className="text-xs text-slate-500">DNS/MX records, Fastify backend, Twilio/Telnyx SMS, and Jest test plan</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 text-xs">
          {[
            { id: 'architecture', label: 'Tech Stack & Architecture', icon: BookOpen },
            { id: 'dns', label: 'Domain & MX Records Setup', icon: Terminal },
            { id: 'docker', label: 'Docker & Deployment', icon: Code2 },
            { id: 'checklist', label: 'Verification Checklist', icon: CheckCircle2 },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`py-3 px-3.5 font-bold flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === t.id
                  ? 'border-blue-600 text-blue-700 bg-white'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* CONTENT */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-slate-700">
          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h3 className="text-sm font-bold text-slate-900 mb-2">Production Architecture Map</h3>
                <p className="text-slate-600 leading-relaxed mb-3">
                  TempBox is architected as an end-to-end full-stack platform:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-white border border-slate-200">
                    <div className="font-bold text-blue-700 mb-1">📱 Frontend (React / Tailwind)</div>
                    <ul className="list-disc list-inside space-y-1 text-slate-600">
                      <li>White &amp; Blue clean, modern Temp Mail aesthetic</li>
                      <li>Auto-OTP extractor and instant 1-tap clipboard copy</li>
                      <li>Real-time polling and live delivery updates</li>
                      <li>Temporary phone numbers for SMS verification</li>
                    </ul>
                  </div>

                  <div className="p-3 rounded-lg bg-white border border-slate-200">
                    <div className="font-bold text-blue-700 mb-1">⚡ Inbound Mail Routing</div>
                    <ul className="list-disc list-inside space-y-1 text-slate-600">
                      <li>Mail.tm high-deliverability engine with clean MX</li>
                      <li>Guerrilla Mail fallback engine</li>
                      <li>AES-256 client encryption for messages</li>
                      <li>Anti-tracking pixel and script sanitization</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'dns' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h3 className="text-sm font-bold text-slate-900 mb-2">DNS Records for Live Email Deliverability</h3>
                <div className="space-y-2 mt-3 font-mono text-xs">
                  <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-blue-700">MX</span> @ in.mail.tm (Priority 10)
                    </div>
                    <button
                      onClick={() => copyToClipboard('in.mail.tm', 'mx1')}
                      className="px-2 py-1 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 text-[11px] font-sans font-bold"
                    >
                      {copied === 'mx1' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-blue-700">TXT</span> @ v=spf1 include:mail.tm ~all
                    </div>
                    <button
                      onClick={() => copyToClipboard('v=spf1 include:mail.tm ~all', 'spf')}
                      className="px-2 py-1 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 text-[11px] font-sans font-bold"
                    >
                      {copied === 'spf' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'docker' && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Containerized Deployment</h3>
              <pre className="p-3 bg-white border border-slate-200 rounded-lg font-mono text-[11px] text-blue-900 overflow-x-auto">
{`# Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "run", "dev"]`}
              </pre>
            </div>
          )}

          {activeTab === 'checklist' && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Deliverability Checklist</h3>
              <div className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Real-time polling active every 2.5 seconds</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Live active MX domain (maxxspace.com) default</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Automatic 4-8 digit OTP regex detector with 1-tap copy</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Temporary Phone Numbers for receiving SMS codes</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
