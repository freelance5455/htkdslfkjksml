import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { useActiveStory, useDesk, useUi } from "@/lib/desk-store";
import { SEED_BODY, activeChapter, wordCount } from "@/lib/story";

export function Manuscript() {
  const story = useActiveStory();
  const focus = useUi((state) => state.focus);
  const pane = useUi((state) => state.pane);
  const caret = useUi((state) => state.caret);
  const setSelection = useUi((state) => state.setSelection);
  const updateChapter = useDesk((state) => state.updateChapter);
  const addChapter = useDesk((state) => state.addChapter);
  const removeChapter = useDesk((state) => state.removeChapter);
  const patchStory = useDesk((state) => state.patchStory);
  const pageRef = useRef<HTMLTextAreaElement>(null);

  const chapter = story ? activeChapter(story) : undefined;

  useEffect(() => {
    const page = pageRef.current;
    if (!page) return;
    page.style.height = "0px";
    page.style.height = `${page.scrollHeight}px`;
  }, [chapter?.body, chapter?.id]);

  useEffect(() => {
    const page = pageRef.current;
    if (!page || !caret) return;
    page.focus();
    page.setSelectionRange(caret.start, caret.end);
  }, [caret]);

  if (!story || !chapter) return null;

  const pristine = story.id === "seed-salt" && chapter.body === SEED_BODY;
  const words = wordCount(chapter.body);

  function capture() {
    const page = pageRef.current;
    if (!page) return;
    const start = page.selectionStart ?? 0;
    const end = page.selectionEnd ?? 0;
    setSelection({
      start,
      end,
      text: end > start ? page.value.slice(start, end) : "",
    });
  }

  return (
    <main
      className={cn(
        "min-h-0 min-w-0 flex-1 flex-col bg-sheet",
        focus || pane === "write" ? "flex" : "hidden lg:flex",
      )}
    >
      <div className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-line px-3 py-2">
        {story.chapters.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => patchStory(story.id, { activeChapterId: item.id })}
            className={cn(
              "min-h-11 shrink-0 rounded-md px-3 font-serif",
              item.id === chapter.id ? "bg-desk text-ink" : "text-muted",
            )}
          >
            {item.title}
          </button>
        ))}
        <Button tone="ghost" className="shrink-0" onClick={() => addChapter(story.id)}>
          Add chapter
        </Button>
        {story.chapters.length > 1 ? (
          <Button
            tone="ghost"
            className="shrink-0"
            onClick={() => removeChapter(story.id, chapter.id)}
          >
            Remove
          </Button>
        ) : null}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <article className="mx-auto w-full max-w-prose px-5 py-8 lg:px-8">
          <input
            className="w-full bg-transparent font-serif text-3xl text-ink outline-none"
            aria-label="Chapter title"
            value={chapter.title}
            onChange={(event) =>
              updateChapter(story.id, chapter.id, { title: event.target.value })
            }
          />
          <p className="mt-2 text-sm tabular-nums text-muted">
            {words.toLocaleString()} {words === 1 ? "word" : "words"}
            {pristine ? " · sample, yours to overwrite" : ""}
          </p>
          <textarea
            ref={pageRef}
            className="page manuscript mt-6 text-lg leading-relaxed lg:text-xl"
            aria-label="Manuscript"
            placeholder="Begin. Ink can continue from an empty page."
            value={chapter.body}
            spellCheck
            onChange={(event) => updateChapter(story.id, chapter.id, { body: event.target.value })}
            onSelect={capture}
            onKeyUp={capture}
            onMouseUp={capture}
          />
        </article>
      </div>
    </main>
  );
}
