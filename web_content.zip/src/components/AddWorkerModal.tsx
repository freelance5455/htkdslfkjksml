import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import type { Worker } from '../types/attendance';
import { COMMON_ROLES } from '../utils/attendanceLogic';

interface AddWorkerModalProps {
  isOpen: boolean;
  existingWorkers: Worker[];
  onClose: () => void;
  onAdd: (worker: Worker) => void;
}

export function AddWorkerModal({
  isOpen,
  existingWorkers,
  onClose,
  onAdd,
}: AddWorkerModalProps) {
  const [workerId, setWorkerId] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      const nextNum = 101 + existingWorkers.length;
      setWorkerId(`WRK-${nextNum}`);
      setFullName('');
      setRole('');
      setError('');
    }
  }, [isOpen, existingWorkers.length]);

  if (!isOpen) {
    return null;
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const id = workerId.trim();
    const name = fullName.trim();
    const designation = role.trim();

    if (!id) {
      setError('Please enter a Worker ID.');
      return;
    }
    if (!name) {
      setError('Please enter the worker’s full name.');
      return;
    }
    if (!designation) {
      setError('Please enter a role or designation.');
      return;
    }
    const duplicate = existingWorkers.some((w) => w.id.toLowerCase() === id.toLowerCase());
    if (duplicate) {
      setError(`Worker ID "${id}" already exists in this department.`);
      return;
    }

    onAdd({ id, name, role: designation });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-worker-modal-title"
    >
      <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 id="add-worker-modal-title" className="text-lg font-semibold text-slate-900">
            Add Worker
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close add worker modal"
            className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label htmlFor="worker-id-input" className="block text-sm font-medium text-slate-700 mb-1.5">
              Worker ID
            </label>
            <input
              id="worker-id-input"
              type="text"
              value={workerId}
              onChange={(e) => {
                setWorkerId(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. WRK-109"
              className="w-full px-3.5 py-2.5 text-sm font-mono text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          <div>
            <label htmlFor="worker-name-input" className="block text-sm font-medium text-slate-700 mb-1.5">
              Full Name
            </label>
            <input
              id="worker-name-input"
              type="text"
              value={fullName}
              onChange={(e) => {
                setFullName(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Ramesh Oraon"
              autoFocus
              className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          <div>
            <label htmlFor="worker-role-input" className="block text-sm font-medium text-slate-700 mb-1.5">
              Role / Designation
            </label>
            <input
              id="worker-role-input"
              type="text"
              value={role}
              onChange={(e) => {
                setRole(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Welder, Fitter, Mason"
              className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {COMMON_ROLES.slice(0, 5).map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    setRole(preset);
                    if (error) setError('');
                  }}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors ${
                    role === preset
                      ? 'bg-blue-50 text-blue-700 border-blue-200'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <p role="alert" className="text-sm font-medium text-rose-600 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl shadow-xs transition-colors"
            >
              Add Worker
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
