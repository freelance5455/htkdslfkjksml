import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Coins, 
  DollarSign, 
  ArrowRightLeft, 
  ChevronDown, 
  Check, 
  Sparkles,
  Zap,
  Globe
} from 'lucide-react';
import { 
  currencyConverter, 
  DisplayCurrency, 
  CURRENCY_REGISTRY 
} from '../lib/currencyConverter';

interface CurrencyToggleProps {
  className?: string;
  onCurrencyChange?: (currency: DisplayCurrency) => void;
}

export const CurrencyToggle: React.FC<CurrencyToggleProps> = ({ className = '', onCurrencyChange }) => {
  const [currentCurrency, setCurrentCurrency] = useState<DisplayCurrency>(() => currencyConverter.getCurrency());
  const [isOpen, setIsOpen] = useState<boolean>(false);

  useEffect(() => {
    const unsub = currencyConverter.subscribe((curr) => {
      setCurrentCurrency(curr);
      onCurrencyChange?.(curr);
    });
    return () => unsub();
  }, [onCurrencyChange]);

  const handleSelect = (code: DisplayCurrency) => {
    currencyConverter.setCurrency(code);
    setIsOpen(false);
  };

  const activeConfig = CURRENCY_REGISTRY[currentCurrency];

  const fiatOptions: DisplayCurrency[] = ['NGN', 'USD', 'EUR', 'GBP'];
  const cryptoOptions: DisplayCurrency[] = ['BTC', 'ETH', 'SOL', 'CVT'];

  return (
    <div className={`relative inline-block ${className}`}>
      {/* Main Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2.5 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 hover:from-slate-850 hover:to-slate-900 border-2 border-amber-500/40 hover:border-amber-400 text-amber-200 shadow-lg shadow-amber-500/10 transition-all cursor-pointer group"
        title="Switch Base Financial UI Display Currency (Fiat ⇄ Crypto)"
      >
        <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold text-xs group-hover:scale-110 transition-transform">
          <span>{activeConfig.symbol}</span>
        </div>

        <div className="text-left">
          <div className="flex items-center space-x-1.5">
            <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
              Currency
            </span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-300 font-bold">
              {activeConfig.type}
            </span>
          </div>
          <p className="text-xs font-black text-amber-100 flex items-center space-x-1">
            <span>{activeConfig.flagOrIcon}</span>
            <span>{activeConfig.code}</span>
            <span className="text-slate-400 font-normal">({activeConfig.name})</span>
          </p>
        </div>

        <ChevronDown className={`w-4 h-4 text-amber-400/80 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 rounded-3xl bg-slate-950/95 border-2 border-amber-500/50 shadow-2xl backdrop-blur-2xl p-3 z-50 animate-fadeIn space-y-3">
          <div className="flex items-center justify-between px-2 pt-1 pb-2 border-b border-slate-800">
            <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center space-x-1.5">
              <ArrowRightLeft className="w-3.5 h-3.5 text-amber-400" />
              <span>Select Base Display</span>
            </span>
            <span className="text-[10px] text-slate-400">Global Rates Active</span>
          </div>

          {/* FIAT Section */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 flex items-center space-x-1">
              <DollarSign className="w-3 h-3 text-emerald-400" />
              <span>Local & Global Fiat</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {fiatOptions.map((code) => {
                const config = CURRENCY_REGISTRY[code];
                const isSelected = currentCurrency === code;
                return (
                  <button
                    key={code}
                    onClick={() => handleSelect(code)}
                    className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                        : 'bg-slate-900/80 hover:bg-slate-850 text-slate-300 hover:text-amber-200 border border-slate-800'
                    }`}
                  >
                    <div className="flex items-center space-x-1.5 truncate">
                      <span>{config.flagOrIcon}</span>
                      <span>{code}</span>
                      <span className="text-[10px] opacity-75 font-mono">({config.symbol})</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-slate-950 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* CRYPTO Section */}
          <div className="space-y-1 pt-1 border-t border-slate-800/80">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 flex items-center space-x-1">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Cryptocurrency & Tokens</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {cryptoOptions.map((code) => {
                const config = CURRENCY_REGISTRY[code];
                const isSelected = currentCurrency === code;
                return (
                  <button
                    key={code}
                    onClick={() => handleSelect(code)}
                    className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                        : 'bg-slate-900/80 hover:bg-slate-850 text-slate-300 hover:text-amber-200 border border-slate-800'
                    }`}
                  >
                    <div className="flex items-center space-x-1.5 truncate">
                      <span>{config.flagOrIcon}</span>
                      <span>{code}</span>
                      <span className="text-[10px] opacity-75 font-mono">({config.symbol})</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-slate-950 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Live Peg Notice */}
          <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-200/80 space-y-0.5">
            <div className="flex justify-between">
              <span>1 BTC = $96,420.00</span>
              <span>1 USD = ₦1,550.00</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>1 ETH = $2,780.00</span>
              <span>1 CVT = $1.00 USD</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
