import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Volume2, Pause, Play, Square } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PreferredLanguage } from '../types';
import { voiceAssistant, TTSStatus } from '../services/voiceAssistant';

export interface ReadAloudButtonProps {
  /** The fallback visible text if whole page extraction is empty */
  text: string;
  /** Current language */
  language?: PreferredLanguage;
  /** Optional custom ID for accessibility/DOM */
  id?: string;
  /** Optional button styling variation */
  variant?: 'pill' | 'compact' | 'bar' | 'outline';
  className?: string;
  /** Optional custom label */
  customLabel?: string;
}

const UI_TEXT = {
  English: {
    readAloud: 'Read Aloud',
    readSelection: 'Read Selection',
    playing: 'Reading aloud...',
    playingSelection: 'Reading selection...',
    paused: 'Paused',
    pause: 'Pause',
    resume: 'Resume',
    stop: 'Stop',
  },
  Hindi: {
    readAloud: 'बोलकर सुनाएं',
    readSelection: 'चयनित पाठ सुनें',
    playing: 'सुनाया जा रहा है...',
    playingSelection: 'चयनित पाठ सुना रहे हैं...',
    paused: 'रुका हुआ',
    pause: 'रोकें',
    resume: 'जारी रखें',
    stop: 'बंद करें',
  },
  Marathi: {
    readAloud: 'मोठ्याने वाचा',
    readSelection: 'निवडलेला मजकूर ऐका',
    playing: 'वाचून दाखवत आहे...',
    playingSelection: 'निवडलेला मजकूर वाचत आहे...',
    paused: 'थांबवले',
    pause: 'थांबवा',
    resume: 'पुढे चालू ठेवा',
    stop: 'बंद करा',
  },
};

// Tracks single active floating selection reader instance across multiple buttons
let activeFloatingReaderId: string | null = null;

export const ReadAloudButton: React.FC<ReadAloudButtonProps> = ({
  text,
  language = 'English',
  id,
  variant = 'pill',
  className = '',
  customLabel,
}) => {
  const [componentSessionId] = useState<string>(
    () => `tts_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`
  );
  const [ttsStatus, setTtsStatus] = useState<TTSStatus>({
    state: 'idle',
    sessionId: null,
    language,
    progress: 0,
    readingMode: 'page',
  });
  const [activeSelectionText, setActiveSelectionText] = useState<string>('');
  const [isFloatingOwner, setIsFloatingOwner] = useState<boolean>(false);
  const [floatingPos, setFloatingPos] = useState<{ top: number; left: number } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<string>(text);
  const langRef = useRef<PreferredLanguage>(language);

  useEffect(() => {
    textRef.current = text;
    langRef.current = language;
  }, [text, language]);

  // Subscribe to central VoiceAssistant state
  useEffect(() => {
    const unsubscribeTts = voiceAssistant.subscribe((status) => {
      setTtsStatus(status);
    });

    const unsubscribeSelection = voiceAssistant.subscribeToSelection((sel) => {
      setActiveSelectionText(sel);
    });

    // Designate this component as floating reader owner if none exists
    if (!activeFloatingReaderId) {
      activeFloatingReaderId = componentSessionId;
      setIsFloatingOwner(true);
    }

    return () => {
      unsubscribeTts();
      unsubscribeSelection();
      if (activeFloatingReaderId === componentSessionId) {
        activeFloatingReaderId = null;
      }
      if (voiceAssistant.getSessionId() === componentSessionId) {
        voiceAssistant.stop(componentSessionId);
      }
    };
  }, [componentSessionId]);

  // Track selection position on screen for the floating quick-reader
  useEffect(() => {
    if (!isFloatingOwner) return;

    const updateFloatingPosition = () => {
      if (typeof window === 'undefined') return;
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0 || !activeSelectionText.trim()) {
        setFloatingPos(null);
        return;
      }

      try {
        const range = sel.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) {
          setFloatingPos(null);
          return;
        }

        // Place floating pill right above the selection (or below if near top of window)
        const top = rect.top >= 52 ? rect.top - 46 : rect.bottom + 10;
        const left = Math.max(16, Math.min(window.innerWidth - 170, rect.left + rect.width / 2 - 75));
        setFloatingPos({ top, left });
      } catch {
        setFloatingPos(null);
      }
    };

    updateFloatingPosition();

    window.addEventListener('scroll', updateFloatingPosition, { passive: true });
    window.addEventListener('resize', updateFloatingPosition, { passive: true });

    return () => {
      window.removeEventListener('scroll', updateFloatingPosition);
      window.removeEventListener('resize', updateFloatingPosition);
    };
  }, [isFloatingOwner, activeSelectionText]);

  const isCurrentSession = ttsStatus.sessionId === componentSessionId;
  const isPlaying = isCurrentSession && ttsStatus.state === 'playing';
  const isPaused = isCurrentSession && ttsStatus.state === 'paused';
  const isActive = isPlaying || isPaused;

  const labels = UI_TEXT[language] || UI_TEXT.English;

  // Resolve active language (prop or stored user setting)
  const getActiveLang = (): PreferredLanguage => {
    if (language === 'Hindi' || language === 'Marathi' || language === 'English') {
      return language;
    }
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('preferred_language');
      if (stored === 'Hindi' || stored === 'Marathi') {
        return stored;
      }
    }
    return 'English';
  };

  const handleStart = (e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }

    const activeLang = getActiveLang();

    // SELECTION RULE PRIORITY:
    // 1. If text is selected/highlighted: READ ONLY THE SELECTED TEXT.
    //    It must NOT start reading from the beginning of the page.
    //    It must NOT read other sections.
    const activeSelection = voiceAssistant.getActiveSelection();

    if (activeSelection && activeSelection.trim().length > 0) {
      // MODE 2 — SELECTED TEXT READING
      voiceAssistant.speak(
        activeSelection.trim(),
        activeLang,
        componentSessionId,
        undefined,
        'selection'
      );
      return;
    }

    // 2. If NO text is selected: MODE 1 — COMPLETE PAGE READING
    //    Read ALL meaningful visible information on current page from top to bottom
    const pageText = voiceAssistant.extractVisibleTextFromPage(containerRef.current);
    const fullTextToRead = pageText && pageText.trim().length > 0 ? pageText : (textRef.current || '');

    if (!fullTextToRead.trim()) return;

    voiceAssistant.speak(
      fullTextToRead,
      activeLang,
      componentSessionId,
      undefined,
      'page'
    );
  };

  const handlePause = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    voiceAssistant.pause();
  };

  const handleResume = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    voiceAssistant.resume();
  };

  const handleStop = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    voiceAssistant.stop(componentSessionId);
  };

  // Check if a valid text selection currently exists on screen
  const hasSelection = activeSelectionText.trim().length > 0;
  const isReadingSelection = ttsStatus.readingMode === 'selection';

  // Floating reader element for selected text
  const floatingReaderElement =
    isFloatingOwner &&
    hasSelection &&
    floatingPos &&
    typeof document !== 'undefined'
      ? createPortal(
          <div
            style={{
              position: 'fixed',
              top: `${floatingPos.top}px`,
              left: `${floatingPos.left}px`,
              zIndex: 99999,
            }}
            data-read-aloud-control="true"
            className="pointer-events-auto select-none"
          >
            <motion.button
              initial={{ opacity: 0, y: 5, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 5, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              type="button"
              onMouseDown={(e) => {
                // Prevent collapsing browser text selection on click
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleStart();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-blue-900/30 border border-blue-400/40 cursor-pointer transition-all"
            >
              <Volume2 className="w-3.5 h-3.5 shrink-0" />
              <span className="whitespace-nowrap">{labels.readSelection}</span>
            </motion.button>
          </div>,
          document.body
        )
      : null;

  if (variant === 'bar') {
    return (
      <>
        {floatingReaderElement}
        <div
          ref={containerRef}
          data-read-aloud-control="true"
          id={id || `read-aloud-bar-${componentSessionId}`}
          className={`w-full rounded-2xl border transition-all p-3 flex items-center justify-between gap-3 ${
            isActive
              ? 'bg-blue-50/90 border-blue-300 text-blue-900 shadow-sm'
              : 'bg-slate-50 border-slate-200/90 text-slate-700 hover:bg-slate-100'
          } ${className}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                isActive ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              <Volume2 className={`w-4 h-4 ${isPlaying ? 'animate-pulse' : ''}`} />
            </div>
            <div className="truncate">
              <p className="text-xs font-semibold leading-tight truncate">
                {isActive
                  ? isPlaying
                    ? isReadingSelection
                      ? labels.playingSelection
                      : labels.playing
                    : labels.paused
                  : hasSelection
                  ? labels.readSelection
                  : customLabel || labels.readAloud}
              </p>
              {isActive && (
                <p className="text-[10px] text-blue-600 font-medium">
                  {language} • {isReadingSelection ? labels.readSelection : `${ttsStatus.progress}%`}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {!isActive ? (
              <button
                type="button"
                onMouseDown={(e) => {
                  // Keep text selection intact
                  e.preventDefault();
                }}
                onClick={handleStart}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all cursor-pointer select-none"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{hasSelection ? labels.readSelection : labels.readAloud}</span>
              </button>
            ) : (
              <>
                {isPlaying ? (
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={handlePause}
                    title={labels.pause}
                    aria-label={labels.pause}
                    className="w-8 h-8 rounded-xl bg-blue-200 hover:bg-blue-300 text-blue-900 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                  >
                    <Pause className="w-3.5 h-3.5 fill-current" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={handleResume}
                    title={labels.resume}
                    aria-label={labels.resume}
                    className="w-8 h-8 rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                  </button>
                )}
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleStop}
                  title={labels.stop}
                  aria-label={labels.stop}
                  className="w-8 h-8 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-700 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                </button>
              </>
            )}
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      {floatingReaderElement}
      <div
        ref={containerRef}
        data-read-aloud-control="true"
        id={id || `read-aloud-btn-${componentSessionId}`}
        className={`inline-flex items-center gap-1.5 ${className}`}
      >
        <AnimatePresence mode="wait">
          {!isActive ? (
            <motion.button
              key="idle"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              type="button"
              onMouseDown={(e) => {
                // Prevent browser click from collapsing user's text selection
                e.preventDefault();
              }}
              onClick={handleStart}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold shadow-xs transition-all active:scale-95 cursor-pointer select-none ${
                hasSelection
                  ? 'bg-blue-700 text-white ring-2 ring-blue-300'
                  : variant === 'outline'
                  ? 'bg-white border border-blue-200 text-blue-700 hover:bg-blue-50'
                  : variant === 'compact'
                  ? 'bg-blue-100 text-blue-800 hover:bg-blue-200 border border-blue-200'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5 shrink-0" />
              <span className="whitespace-nowrap">
                {hasSelection ? labels.readSelection : customLabel || labels.readAloud}
              </span>
            </motion.button>
          ) : (
            <motion.div
              key="active-controls"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="inline-flex items-center gap-1.5 bg-blue-50 border border-blue-300 rounded-full px-2.5 py-1 text-blue-900 shadow-xs"
            >
              {/* Animated Soundwave Indicator */}
              <div className="flex items-center gap-0.5 px-1">
                <span
                  className={`w-0.5 bg-blue-600 rounded-full ${
                    isPlaying ? 'h-3 animate-pulse' : 'h-1.5'
                  }`}
                />
                <span
                  className={`w-0.5 bg-blue-600 rounded-full ${
                    isPlaying ? 'h-4 animate-bounce' : 'h-2'
                  }`}
                  style={{ animationDelay: '150ms' }}
                />
                <span
                  className={`w-0.5 bg-blue-600 rounded-full ${
                    isPlaying ? 'h-2.5 animate-pulse' : 'h-1'
                  }`}
                  style={{ animationDelay: '300ms' }}
                />
              </div>

              <span className="text-[11px] font-semibold text-blue-800 px-1 select-none">
                {isPlaying
                  ? isReadingSelection
                    ? labels.playingSelection
                    : labels.playing
                  : labels.paused}
              </span>

              {isPlaying ? (
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handlePause}
                  title={labels.pause}
                  aria-label={labels.pause}
                  className="w-6 h-6 rounded-full bg-blue-200 hover:bg-blue-300 text-blue-900 flex items-center justify-center active:scale-90 transition-all cursor-pointer"
                >
                  <Pause className="w-3 h-3 fill-current" />
                </button>
              ) : (
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleResume}
                  title={labels.resume}
                  aria-label={labels.resume}
                  className="w-6 h-6 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center active:scale-90 transition-all cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-current" />
                </button>
              )}

              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleStop}
                title={labels.stop}
                aria-label={labels.stop}
                className="w-6 h-6 rounded-full bg-rose-100 hover:bg-rose-200 text-rose-700 flex items-center justify-center active:scale-90 transition-all cursor-pointer"
              >
                <Square className="w-2.5 h-2.5 fill-current" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};
