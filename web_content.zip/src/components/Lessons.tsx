import { useEffect, useMemo, useState } from "react";
import { Chess } from "chess.js";
import Board from "./Board";
import { LESSONS, PIECE_DEMOS } from "../data/content";
import { GLYPH, PIECE_NAME, type PieceType } from "../lib/chess";
import { cn } from "../utils/cn";

const STORAGE_KEY = "chess-academy-progress";

export default function Lessons() {
  const [demoIndex, setDemoIndex] = useState(1);
  const [done, setDone] = useState<Record<string, boolean>>({});
  const [openLesson, setOpenLesson] = useState<string | null>(LESSONS[0].id);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setDone(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  const toggle = (id: string) => {
    setDone((d) => {
      const next = { ...d, [id]: !d[id] };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const demo = PIECE_DEMOS[demoIndex];
  const targets = useMemo(() => {
    try {
      const g = new Chess(demo.fen);
      return (g.moves({ square: demo.from as never, verbose: true }) as Array<{ to: string }>).map(
        (m) => m.to,
      );
    } catch {
      return [];
    }
  }, [demo]);

  const completed = LESSONS.filter((l) => done[l.id]).length;
  const pct = Math.round((completed / LESSONS.length) * 100);

  return (
    <div className="grid gap-8">
      <section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <div>
          <h3 className="mb-3 text-lg font-semibold text-neutral-50">How the pieces move</h3>
          <Board fen={demo.fen} targets={targets} selected={demo.from} />
        </div>
        <aside className="flex flex-col gap-4">
          <div className="grid grid-cols-3 gap-2">
            {PIECE_DEMOS.map((d, i) => (
              <button
                key={d.id}
                onClick={() => setDemoIndex(i)}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-xl border px-2 py-3 transition",
                  i === demoIndex
                    ? "border-emerald-500/60 bg-emerald-500/15"
                    : "border-white/10 bg-black/20 hover:border-white/25",
                )}
              >
                <span
                  className="text-3xl leading-none text-white"
                  style={{ WebkitTextStroke: "1px rgba(0,0,0,.6)" }}
                >
                  {GLYPH[d.id === "knight" ? "n" : (d.id[0] as PieceType)]}
                </span>
                <span className="text-xs font-medium text-neutral-300">{d.name}</span>
              </button>
            ))}
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h4 className="text-base font-semibold text-neutral-50">
              The {PIECE_NAME[demo.id === "knight" ? "n" : (demo.id[0] as PieceType)]}
            </h4>
            <p className="mt-2 text-sm leading-relaxed text-neutral-300">{demo.text}</p>
            <p className="mt-3 text-xs text-neutral-500">
              Green dots = every legal move from {demo.from}.
            </p>
          </div>
        </aside>
      </section>

      <section>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-lg font-semibold text-neutral-50">Course path</h3>
          <div className="flex items-center gap-3">
            <div className="h-2 w-40 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className="text-sm text-neutral-400">
              {completed}/{LESSONS.length} complete
            </span>
          </div>
        </div>

        <div className="grid gap-3">
          {LESSONS.map((lesson) => {
            const open = openLesson === lesson.id;
            return (
              <article
                key={lesson.id}
                className={cn(
                  "rounded-2xl border transition",
                  open ? "border-emerald-500/40 bg-emerald-500/5" : "border-white/10 bg-white/5",
                )}
              >
                <button
                  onClick={() => setOpenLesson(open ? null : lesson.id)}
                  className="flex w-full items-center gap-4 px-5 py-4 text-left"
                >
                  <span
                    className={cn(
                      "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold",
                      done[lesson.id]
                        ? "bg-emerald-500 text-white"
                        : "bg-black/40 text-neutral-400 ring-1 ring-white/10",
                    )}
                  >
                    {done[lesson.id] ? "✓" : "♟"}
                  </span>
                  <span className="flex-1">
                    <span className="block font-semibold text-neutral-50">{lesson.title}</span>
                    <span className="block text-sm text-neutral-400">{lesson.summary}</span>
                  </span>
                  <span className="hidden shrink-0 text-right text-xs text-neutral-500 sm:block">
                    <span className="block">{lesson.level}</span>
                    <span className="block">{lesson.minutes} min</span>
                  </span>
                </button>
                {open && (
                  <div className="border-t border-white/10 px-5 py-4">
                    <ul className="grid gap-2">
                      {lesson.points.map((p) => (
                        <li key={p} className="flex gap-3 text-sm text-neutral-300">
                          <span className="text-emerald-400">▸</span>
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => toggle(lesson.id)}
                      className={cn(
                        "mt-4 rounded-xl px-4 py-2 text-sm font-semibold transition",
                        done[lesson.id]
                          ? "bg-white/5 text-neutral-300 ring-1 ring-white/10 hover:bg-white/10"
                          : "bg-emerald-600 text-white hover:bg-emerald-500",
                      )}
                    >
                      {done[lesson.id] ? "Mark as not done" : "Mark lesson complete"}
                    </button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
