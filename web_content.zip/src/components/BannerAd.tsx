import React, { useState } from 'react';
import { ExternalLink, Info } from 'lucide-react';
import { adManager } from '../services/adManager';

interface BannerAdProps {
  className?: string;
}

/**
 * Standard AdMob 320x50 Horizontal Mobile Banner.
 * Positioned at the bottom of screens, adhering to strict AdMob guidelines:
 * - Slim horizontal banner format (NOT a square/rectangle card)
 * - Clear "Ad" badge & AdChoices indicator
 * - Never obscures interactive buttons, puzzle tiles or board areas
 */
export const BannerAd: React.FC<BannerAdProps> = ({ className = '' }) => {
  const [showUnitIdTooltip, setShowUnitIdTooltip] = useState(false);
  const bannerId = adManager.config.bannerUnitId;

  return (
    <aside
      id="admob-banner-ad-container"
      aria-label="Advertisement Banner"
      className={`w-full flex-shrink-0 flex items-center justify-center bg-slate-900 border-t border-slate-800 text-white z-30 select-none ${className}`}
      style={{ 
        minHeight: 'calc(52px + env(safe-area-inset-bottom, 0px))',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
    >
      {/* Standard 320x50 AdMob Horizontal Banner Frame */}
      <div className="w-full max-w-[360px] h-[50px] px-2.5 flex items-center justify-between gap-2 overflow-hidden relative">
        {/* Left: Ad tag & Sponsor Creative */}
        <div className="flex items-center gap-2 min-w-0">
          {/* Ad badge */}
          <span className="px-1 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider shrink-0">
            Ad
          </span>

          {/* Ad Creative thumbnail */}
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-sky-500 flex items-center justify-center shrink-0 shadow-sm border border-indigo-400/40">
            <span className="text-[10px] font-black text-white">AS</span>
          </div>

          {/* Title & subtitle in single line */}
          <div className="flex flex-col min-w-0 text-left">
            <span className="text-xs font-bold text-slate-100 truncate leading-tight">
              Play ArrowScape Pro
            </span>
            <span className="text-[10px] text-slate-400 truncate leading-tight">
              Test Ad • adunit: {bannerId.split('/')[1] || '6300978111'}
            </span>
          </div>
        </div>

        {/* Right: CTA button & Info icon */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setShowUnitIdTooltip(!showUnitIdTooltip)}
            title={`AdMob Unit ID: ${bannerId}`}
            className="w-5 h-5 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-200 transition"
          >
            <Info className="w-3.5 h-3.5" />
          </button>

          <a
            href="https://google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="h-7 px-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-white font-black text-[11px] flex items-center gap-1 tracking-wide shadow transition active:scale-95 whitespace-nowrap"
          >
            <span>INSTALL</span>
            <ExternalLink className="w-2.5 h-2.5" />
          </a>
        </div>

        {/* Tooltip on tap */}
        {showUnitIdTooltip && (
          <div className="absolute inset-x-2 bottom-12 p-2 rounded-xl bg-slate-950 border border-slate-700 text-[10px] text-slate-300 shadow-xl z-50 flex items-center justify-between">
            <span className="font-mono text-sky-400 truncate mr-2">
              Unit: {bannerId}
            </span>
            <button
              type="button"
              onClick={() => setShowUnitIdTooltip(false)}
              className="text-slate-400 hover:text-white text-[11px] font-bold px-1"
            >
              ✕
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
