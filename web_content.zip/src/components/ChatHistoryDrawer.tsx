import { useState } from 'react';
import { MessageSquare, Plus, Trash2, X } from 'lucide-react';
import type { ChatSession } from '../types/chat';

interface ChatHistoryDrawerProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
}

function formatSessionDate(timestamp: number): string {
  const now = new Date();
  const date = new Date(timestamp);
  const diffDays = Math.floor(
    (new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() -
      new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()) /
      86400000
  );

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(date);
}

export function ChatHistoryDrawer({
  sessions,
  activeSessionId,
  isOpen,
  onClose,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onClearAll,
}: ChatHistoryDrawerProps) {
  const [confirmClear, setConfirmClear] = useState(false);

  const nonEmptySessions = sessions.filter((s) => s.messages.length > 0);

  const sidebarContent = (
    <div className="flex h-full flex-col bg-white">
      <div className="flex h-14 shrink-0 items-center justify-between border-b border-slate-200 px-4">
        <span className="text-base font-bold tracking-tight text-slate-900">
          Chat History
        </span>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close chat history"
          className="-mr-2 flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 lg:hidden"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      <div className="p-3">
        <button
          type="button"
          onClick={() => {
            onNewChat();
            onClose();
          }}
          className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F766E] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#0D655E] active:scale-[0.99] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 whitespace-nowrap"
        >
          <Plus className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>New Chat</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto overscroll-contain px-2 pb-4">
        {nonEmptySessions.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <MessageSquare
              className="mx-auto h-7 w-7 text-slate-300"
              aria-hidden="true"
            />
            <p className="mt-2.5 text-sm font-medium text-slate-600">
              No saved chats yet
            </p>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">
              Your questions and Dawitai answers will appear here.
            </p>
          </div>
        ) : (
          <ul className="space-y-1" role="list">
            {nonEmptySessions.map((session) => {
              const isActive = session.id === activeSessionId;
              return (
                <li key={session.id}>
                  <div
                    className={`group flex min-h-[48px] items-center justify-between gap-1 rounded-xl px-2 transition-colors ${
                      isActive
                        ? 'bg-teal-50 text-teal-950'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onSelectSession(session.id);
                        onClose();
                      }}
                      className="flex min-h-[48px] min-w-0 flex-1 flex-col justify-center px-2 py-2 text-left focus-visible:outline-2 focus-visible:outline-teal-700"
                    >
                      <span className="truncate text-sm font-medium">
                        {session.title}
                      </span>
                      <span className="mt-0.5 text-xs text-slate-400 tabular-nums">
                        {formatSessionDate(session.updatedAt)} · {session.messages.length} msgs
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSession(session.id);
                      }}
                      aria-label={`Delete chat ${session.title}`}
                      className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 focus-visible:outline-2 focus-visible:outline-red-600 lg:opacity-0 lg:group-hover:opacity-100 lg:focus-visible:opacity-100"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {nonEmptySessions.length > 0 && (
        <div className="shrink-0 border-t border-slate-200 p-3">
          {confirmClear ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onClearAll();
                  setConfirmClear(false);
                }}
                className="min-h-[44px] flex-1 rounded-xl bg-red-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-red-700"
              >
                Confirm Clear
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="min-h-[44px] rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-red-600"
            >
              <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Clear all history</span>
            </button>
          )}
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop persistent sidebar */}
      <aside
        aria-label="Chat history"
        className="hidden h-full w-72 shrink-0 border-r border-slate-200 bg-white lg:block"
      >
        {sidebarContent}
      </aside>

      {/* Mobile slide-over drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden" role="dialog" aria-modal="true" aria-label="Chat history">
          <div
            className="fixed inset-0 bg-slate-950/45 backdrop-blur-xs transition-opacity"
            onClick={onClose}
            aria-hidden="true"
          />
          <div className="relative z-10 flex h-full w-[84%] max-w-xs flex-col bg-white shadow-2xl">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
