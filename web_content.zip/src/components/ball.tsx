import { cn } from "@/lib/utils";

const TONE = [
  "bg-[#e8e0d0] text-[#1a1712]",
  "bg-[#3e6b86] text-[#f3ece0]",
  "bg-[#3f6e58] text-[#f3ece0]",
  "bg-[#8b5340] text-[#f3ece0]",
  "bg-[#8a7040] text-[#f3ece0]",
  "bg-[#4a5560] text-[#f3ece0]",
  "bg-[#6a3d42] text-[#f3ece0]",
  "bg-[#355e62] text-[#f3ece0]",
  "bg-[#2c2c34] text-gold-2",
] as const;

export function ballTone(n: number) {
  const d = Math.min(8, Math.floor((n - 1) / 10));
  return TONE[d];
}

export function Ball({
  n,
  size = "md",
  highlight = false,
  dim = false,
  delay = 0,
  drop = false,
}: {
  n: number;
  size?: "sm" | "md" | "lg";
  highlight?: boolean;
  dim?: boolean;
  delay?: number;
  drop?: boolean;
}) {
  const sz = size === "lg" ? "h-14 w-14 text-[18px]" : size === "sm" ? "h-8 w-8 text-[12px]" : "h-11 w-11 text-[15px]";
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-full font-semibold tabular-nums",
        "shadow-[inset_0_1px_0_rgba(255,255,255,0.28),0_2px_6px_rgba(0,0,0,0.35)]",
        sz,
        ballTone(n),
        highlight && "ring-2 ring-gold ring-offset-2 ring-offset-bg",
        dim && "opacity-45",
        drop && "ball-drop",
      )}
      style={drop ? { animationDelay: `${delay}ms` } : undefined}
    >
      {n}
    </span>
  );
}

export function BallRow({
  numbers,
  highlight,
  size = "md",
  drop = false,
}: {
  numbers: readonly number[];
  highlight?: number[];
  size?: "sm" | "md" | "lg";
  drop?: boolean;
}) {
  const hi = new Set(highlight ?? []);
  return (
    <div className="flex items-center gap-2">
      {numbers.map((n, i) => (
        <Ball
          key={`${n}-${i}`}
          n={n}
          size={size}
          highlight={hi.has(n)}
          drop={drop}
          delay={i * 140}
        />
      ))}
    </div>
  );
}
