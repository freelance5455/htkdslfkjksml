/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export const FuturisticFrame: React.FC = () => {
  return (
    <div className="absolute inset-0 pointer-events-none z-10 p-2 sm:p-4 overflow-hidden">
      {/* Outer Glow Border SVG */}
      <svg
        className="w-full h-full"
        viewBox="0 0 1000 1500"
        preserveAspectRatio="none"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <linearGradient id="frameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.7" />
          </linearGradient>
        </defs>

        {/* Master Futuristic Cybernetic Perimeter Frame */}
        <path
          d="
            M 60,30
            H 420
            L 440,48
            H 560
            L 580,30
            H 940
            A 30,30 0 0 1 970,60
            V 220
            L 945,260
            L 945,340
            L 970,380
            V 680
            L 935,720
            L 935,840
            L 970,880
            V 1440
            A 30,30 0 0 1 940,1470
            H 560
            L 540,1455
            H 460
            L 440,1470
            H 60
            A 30,30 0 0 1 30,1440
            V 880
            L 65,840
            L 65,720
            L 30,680
            V 380
            L 55,340
            L 55,260
            L 30,220
            V 60
            A 30,30 0 0 1 60,30
            Z
          "
          stroke="url(#frameGrad)"
          strokeWidth="2.5"
          filter="url(#cyanGlow)"
        />

        {/* Secondary Inner Fine Boundary Line */}
        <path
          d="
            M 75,45
            H 415
            L 435,60
            H 565
            L 585,45
            H 925
            V 215
            L 905,250
            V 350
            L 925,385
            V 675
            L 895,715
            V 845
            L 925,885
            V 1455
            H 565
            L 545,1440
            H 455
            L 435,1455
            H 75
            V 885
            L 105,845
            V 715
            L 75,675
            V 385
            L 95,350
            V 250
            L 75,215
            Z
          "
          stroke="#06b6d4"
          strokeWidth="0.8"
          strokeOpacity="0.35"
        />

        {/* Left Wing Accent Tick Marks */}
        <line x1="100" y1="420" x2="100" y2="445" stroke="#38bdf8" strokeWidth="2.5" />
        <line x1="50" y1="780" x2="130" y2="780" stroke="#06b6d4" strokeWidth="1.2" strokeDasharray="4,4" />

        {/* Right Wing Accent Tick Marks */}
        <line x1="900" y1="420" x2="900" y2="445" stroke="#38bdf8" strokeWidth="2.5" />
        <line x1="870" y1="780" x2="950" y2="780" stroke="#06b6d4" strokeWidth="1.2" strokeDasharray="4,4" />

        {/* Bottom Corner Diagonal Hatch Ticks (///) */}
        {/* Bottom Left */}
        <line x1="65" y1="1400" x2="90" y2="1375" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />
        <line x1="80" y1="1415" x2="105" y2="1390" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />
        <line x1="95" y1="1430" x2="120" y2="1405" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />

        {/* Bottom Right */}
        <line x1="935" y1="1400" x2="910" y2="1375" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />
        <line x1="920" y1="1415" x2="895" y2="1390" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />
        <line x1="905" y1="1430" x2="880" y2="1405" stroke="#06b6d4" strokeWidth="1.8" strokeOpacity="0.7" />

        {/* Bottom Center Circular Reticle / Crosshair Indicator */}
        <g transform="translate(500, 1450)">
          <circle r="22" stroke="#06b6d4" strokeWidth="1.5" strokeOpacity="0.6" fill="rgba(3, 7, 18, 0.7)" />
          <circle r="14" stroke="#38bdf8" strokeWidth="1" strokeOpacity="0.8" />
          <circle r="4" fill="#67e8f9" filter="url(#cyanGlow)" />
          {/* Crosshair ticks */}
          <line x1="0" y1="-28" x2="0" y2="-22" stroke="#38bdf8" strokeWidth="1.5" />
          <line x1="0" y1="22" x2="0" y2="28" stroke="#38bdf8" strokeWidth="1.5" />
          <line x1="-28" y1="0" x2="-22" y2="0" stroke="#38bdf8" strokeWidth="1.5" />
          <line x1="22" y1="0" x2="28" y2="0" stroke="#38bdf8" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
};
