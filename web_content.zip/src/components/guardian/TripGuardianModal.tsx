import { ShieldAlert, Clock, Plane, Sun, CloudRain, BellRing, MapPin, CheckCircle, X } from 'lucide-react';
import { TravelTrip, Language } from '../../types';
import { translations } from '../../i18n/translations';

interface TripGuardianModalProps {
  isOpen: boolean;
  onClose: () => void;
  trip: TravelTrip;
  language: Language;
}

export function TripGuardianModal({ isOpen, onClose, trip, language }: TripGuardianModalProps) {
  if (!isOpen) return null;

  const t = translations[language];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="glass-panel-elevated rounded-3xl p-6 max-w-md w-full border border-cyan-400/40 text-white space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{t.guardianTitle}</h3>
              <p className="text-[11px] text-cyan-400 font-mono">Live Aviation & Safety Radar</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Flight Status Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-[#071d2b] border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
              {trip.flightInfo.guardianStatus === 'on_time' ? '● ON TIME · في موعدها' : '● STATUS UPDATE'}
            </span>
            <p className="text-sm font-bold text-white mt-0.5">
              {trip.flightInfo.airline} {trip.flightInfo.flightNumber}
            </p>
            <p className="text-xs text-slate-300 mt-1">{trip.flightInfo.statusNote}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/40">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        {/* Airport Flight Critical Specs */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">{t.gateNotice}</span>
            <p className="text-sm font-black text-cyan-400 font-mono">{trip.flightInfo.gate}</p>
          </div>
          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">{language === 'ar' ? 'المقعد' : 'Seat'}</span>
            <p className="text-sm font-black text-white font-mono">{trip.flightInfo.seat}</p>
          </div>
          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">{language === 'ar' ? 'المحطة' : 'Terminal'}</span>
            <p className="text-sm font-black text-white font-mono truncate">{trip.flightInfo.terminal}</p>
          </div>
        </div>

        {/* Live Weather at Destination */}
        <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{trip.weather.icon}</span>
            <div>
              <p className="text-xs font-bold text-white">الطقس في {trip.destinationCity}</p>
              <p className="text-[11px] text-slate-400">{trip.weather.condition}</p>
            </div>
          </div>
          <span className="text-lg font-black text-cyan-300 font-mono">
            {trip.weather.temperatureC}°C
          </span>
        </div>

        {/* Essential Travel Alerts */}
        <div className="space-y-2">
          <p className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <BellRing className="w-4 h-4 text-cyan-400" />
            <span>{language === 'ar' ? 'تنبيهات السفر الهامة:' : 'Crucial Travel Alerts:'}</span>
          </p>
          <div className="space-y-1.5 text-xs text-slate-300">
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
              <span>يُرجى الحضور إلى المطار قبل 3 ساعات من موعد الإقلاع الدولي.</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-400 shrink-0" />
              <span>مندوب Tourism By Taki في انتظارك بالخروج رقم 2 بمطار إسطنبول.</span>
            </div>
          </div>
        </div>

        {/* Dismiss CTA */}
        <button
          onClick={onClose}
          className="w-full h-11 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 transition-colors"
        >
          {language === 'ar' ? 'إغلاق المساعد' : 'Close Guardian'}
        </button>
      </div>
    </div>
  );
}
