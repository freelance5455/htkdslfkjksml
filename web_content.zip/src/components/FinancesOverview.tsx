import React from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  Film,
  Briefcase,
  AlertTriangle,
  Wallet,
  ShieldCheck,
} from 'lucide-react';
import { Sponsor, StationDirector, Talent, TVProgram } from '../types/game';

interface FinancesOverviewProps {
  cash: number;
  dailyRevenue: number;
  dailyExpenses: number;
  sponsors: Sponsor[];
  talents: Talent[];
  directors: StationDirector[];
  programs: TVProgram[];
  day: number;
}

export const FinancesOverview: React.FC<FinancesOverviewProps> = ({
  cash,
  dailyRevenue,
  dailyExpenses,
  sponsors,
  talents,
  directors,
  programs,
  day,
}) => {
  const activeSponsors = sponsors.filter((s) => s.isActive);
  const hiredTalents = talents.filter((t) => t.isHired);
  const hiredDirectors = directors.filter((d) => d.isHired);

  // Daily projections
  const projectedDailyAdRevenue = activeSponsors.reduce((sum, s) => sum + s.payoutPerSlot, 0);
  const scheduledPrograms = programs.filter((p) => p.assignedSlot !== null);
  const projectedDailyShowCost = scheduledPrograms.reduce((sum, p) => sum + p.productionCost, 0);
  const dailyTalentPayroll = Math.round(hiredTalents.reduce((sum, t) => sum + t.salary, 0) / 7);
  const dailyDirectorPayroll = hiredDirectors.reduce((sum, d) => sum + d.salary, 0);

  const totalProjectedDailyExpenses = projectedDailyShowCost + dailyTalentPayroll + dailyDirectorPayroll;
  const projectedNetDaily = projectedDailyAdRevenue - totalProjectedDailyExpenses;
  const isHealthy = projectedNetDaily >= 0;

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Wallet className="w-4 h-4 text-emerald-400" />
            Controladoria Financeira & Livro-Caixa da Emissora
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitore receitas publicitárias, custos de produção de programas, salários de artistas e diretoria para manter a emissora no azul.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-400 block uppercase">SALDO EM CAIXA</span>
          <span className="text-base font-mono font-bold text-emerald-400">
            R$ {cash.toLocaleString('pt-BR')}
          </span>
        </div>
      </div>

      {/* KPI Financial Overview Cards - Compact */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Receita Diária Estimada */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Receita Publicitária / Dia</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2">
            <span className="text-lg font-mono font-bold text-emerald-400">
              + R$ {projectedDailyAdRevenue.toLocaleString('pt-BR')}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {activeSponsors.length} marcas veiculadas na grade
            </span>
          </div>
        </div>

        {/* Despesas Diárias Estimadas */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Custos Operacionais / Dia</span>
            <ArrowDownRight className="w-4 h-4 text-red-400" />
          </div>
          <div className="mt-2">
            <span className="text-lg font-mono font-bold text-red-400">
              - R$ {totalProjectedDailyExpenses.toLocaleString('pt-BR')}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Programas, artistas e diretores
            </span>
          </div>
        </div>

        {/* Lucro Diário Projetado */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Resultado Diário Previsto</span>
            {isHealthy ? (
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            ) : (
              <TrendingDown className="w-4 h-4 text-red-400" />
            )}
          </div>
          <div className="mt-2">
            <span
              className={`text-lg font-mono font-bold ${
                isHealthy ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {isHealthy ? '+' : ''} R$ {projectedNetDaily.toLocaleString('pt-BR')}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {isHealthy ? 'Operação lucrativa' : 'Alerta: défict diário'}
            </span>
          </div>
        </div>

        {/* Faturamento do Dia Atual */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Faturado Hoje (Dia {day})</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2">
            <span className="text-lg font-mono font-bold text-amber-400">
              R$ {dailyRevenue.toLocaleString('pt-BR')}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Despesas hoje: R$ {dailyExpenses.toLocaleString('pt-BR')}
            </span>
          </div>
        </div>
      </div>

      {/* Breakdown Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Cost Breakdown */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <Film className="w-3.5 h-3.5 text-amber-400" />
            Detalhamento de Custos da Emissora
          </h3>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-slate-400" />
                Produção & Exibição de Atrações (4 faixas):
              </span>
              <span className="font-mono font-bold text-slate-200">
                R$ {projectedDailyShowCost.toLocaleString('pt-BR')} / dia
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                Folha Salarial de Apresentadores ({hiredTalents.length}):
              </span>
              <span className="font-mono font-bold text-slate-200">
                R$ {dailyTalentPayroll.toLocaleString('pt-BR')} / dia
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                Salários da Diretoria Executiva ({hiredDirectors.length}):
              </span>
              <span className="font-mono font-bold text-slate-200">
                R$ {dailyDirectorPayroll.toLocaleString('pt-BR')} / dia
              </span>
            </div>
          </div>
        </div>

        {/* Revenue Contracts List */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            Receita por Contrato Publicitário
          </h3>

          {activeSponsors.length === 0 ? (
            <div className="text-xs text-slate-500 italic py-2">
              Nenhum patrocinador ativo no momento. Assine cotas na aba de Comerciais para gerar caixa!
            </div>
          ) : (
            <div className="space-y-2 text-xs">
              {activeSponsors.map((sp) => (
                <div key={sp.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sp.logoColor }} />
                    <span className="text-white font-medium">{sp.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">({sp.assignedSlot || 'Avulso'})</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400">
                    + R$ {sp.payoutPerSlot.toLocaleString('pt-BR')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
