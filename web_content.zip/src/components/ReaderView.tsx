import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion, type Variants } from 'motion/react';
import {
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  BookOpen,
  Check,
  List,
  Loader2,
  RotateCw,
  Settings,
  SkipBack,
  SkipForward,
  X,
} from 'lucide-react';
import type {
  AppThemeSettings,
  ComicEntry,
  DecodedPageAsset,
  PageTransition,
  ReaderSettings,
  ReadingMode,
  ScreenOrientationMode,
  TocBookmark,
} from '../types/comic';
import { openComicArchive, type OpenedComicArchive } from '../utils/archiveEngine';
import { decodeComicPage } from '../utils/imageDecoder';
import { resolveComicBlob } from '../utils/localFolderScanner';
import { PageCurlStage, preloadCurlAsset, type PageCurlStageHandle } from './PageCurlStage';
import { SettingsSheet } from './SettingsSheet';

interface ReaderViewProps {
  comic: ComicEntry;
  initialPage?: number;
  settings: ReaderSettings;
  theme: AppThemeSettings;
  onChangeSettings: (next: ReaderSettings) => void;
  onChangeTheme: (next: AppThemeSettings) => void;
  onProgressChange: (
    comicId: string,
    progress: {
      currentPage: number;
      scrollProgress: number;
      scrollOffsetY?: number;
      scrollRatio?: number;
    },
  ) => void;
  onUpdateUserBookmarks: (comicId: string, bookmarks: TocBookmark[]) => void;
  onOpenComicInfo?: (comic: ComicEntry) => void;
  onClose: () => void;
}

const MAX_DECODED_CACHE = 12;

function isLightHex(hex: string): boolean {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return false;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.65;
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  comic,
  initialPage,
  settings,
  theme,
  onChangeSettings,
  onChangeTheme,
  onProgressChange,
  onUpdateUserBookmarks,
  onClose,
}) => {
  const [archive, setArchive] = useState<OpenedComicArchive | null>(null);
  const [loadingArchive, setLoadingArchive] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const startPage = Math.max(
    0,
    Math.min(
      Math.max(0, comic.pageCount - 1),
      initialPage !== undefined ? initialPage : comic.currentPage || 0,
    ),
  );

  const [currentPage, setCurrentPage] = useState(startPage);
  const [navDirection, setNavDirection] = useState<1 | -1>(1);
  const [hudVisible, setHudVisible] = useState(false);
  const [activeBottomMenu, setActiveBottomMenu] = useState<'mode' | 'orientation' | null>(null);
  const [orientationNotice, setOrientationNotice] = useState<string | null>(null);
  const [tocOpen, setTocOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const prefersReducedMotion = useReducedMotion();

  // Decoded pages map (re-rendered cleanly via version tick)
  const decodedCacheRef = useRef<Map<number, DecodedPageAsset>>(new Map());
  const inFlightRef = useRef<Map<number, Promise<DecodedPageAsset | null>>>(new Map());
  const dimensionsRef = useRef<Map<number, { width: number; height: number }>>(new Map());
  const [cacheVersion, setCacheVersion] = useState(0);

  // Continuous vertical scrolling refs & internal pinch zoom
  const verticalContainerRef = useRef<HTMLDivElement | null>(null);
  const pageSlotRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const initialScrollDoneRef = useRef(false);
  const scrollSaveTimerRef = useRef<number | null>(null);
  const [verticalPinchZoom, setVerticalPinchZoom] = useState(1);
  const verticalPinchZoomRef = useRef(1);
  verticalPinchZoomRef.current = verticalPinchZoom;

  const latestScrollMetricsRef = useRef<{
    currentPage: number;
    scrollOffsetY: number;
    scrollRatio: number;
  }>({
    currentPage: startPage,
    scrollOffsetY: comic.scrollOffsetY ?? 0,
    scrollRatio: comic.scrollRatio ?? comic.scrollProgress ?? 0,
  });

  // Paged stage (LTR, RTL, Paged Vertical) pinch zoom, pan, swipe & physical curl
  const pagedStageRef = useRef<HTMLDivElement | null>(null);
  const curlStageRef = useRef<PageCurlStageHandle | null>(null);
  const [stageSize, setStageSize] = useState<{ width: number; height: number }>({
    width: 0,
    height: 0,
  });
  const [pagedPinchZoom, setPagedPinchZoom] = useState(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isGesturing, setIsGesturing] = useState(false);

  const pagedPinchZoomRef = useRef(1);
  pagedPinchZoomRef.current = pagedPinchZoom;
  const panOffsetRef = useRef({ x: 0, y: 0 });
  panOffsetRef.current = panOffset;
  const activeTouchCountRef = useRef(0);
  const suppressNextClickRef = useRef(false);

  const curlDragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    lastX: number;
    lastTime: number;
    vx: number;
    mode: 'pending' | 'active';
    targetPage: number;
    isForward: boolean;
    curlEdge: 'right' | 'left';
    frontPage: DecodedPageAsset | null;
    backPage: DecodedPageAsset | null;
    progress: number;
    dragRatio: number;
    anchorYRatio: number;
  } | null>(null);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);

  const isContinuousVertical = settings.readingMode === 'vertical';
  const isPagedVertical = settings.readingMode === 'paged-vertical';

  const activeBaseZoom = settings.fitMode === 'custom' ? settings.customZoom / 100 : 1;
  const totalPagedScale = activeBaseZoom * pagedPinchZoom;
  const isPagedZoomed = pagedPinchZoom > 1.02 || (settings.fitMode === 'custom' && settings.customZoom > 105);

  const effectiveTransition: PageTransition = useMemo(() => {
    if (prefersReducedMotion) return 'none';
    const raw = settings.pageTransition || 'slide';
    if (isPagedVertical && raw === 'curl') return 'slide';
    return raw;
  }, [prefersReducedMotion, settings.pageTransition, isPagedVertical]);

  // Apply Screen Orientation lock/unlock safely
  const applyScreenOrientation = useCallback(async (mode: ScreenOrientationMode) => {
    const orientation = (
      typeof screen !== 'undefined' ? screen.orientation : undefined
    ) as
      | (ScreenOrientation & {
          lock?: (o: string) => Promise<void>;
          unlock?: () => void;
        })
      | undefined;

    if (!orientation) {
      setOrientationNotice(
        mode === 'free' ? null : 'Rotation lock works in supported mobile browsers / installed PWA.',
      );
      return;
    }

    try {
      if (mode === 'free') {
        orientation.unlock?.();
        setOrientationNotice(null);
        return;
      }
      const lockTarget =
        mode === 'portrait'
          ? 'portrait-primary'
          : mode === 'portrait-reverse'
            ? 'portrait-secondary'
            : 'landscape';

      if (typeof orientation.lock === 'function') {
        await orientation.lock(lockTarget);
        setOrientationNotice(null);
      } else {
        setOrientationNotice(
          'Orientation preference saved (full lock requires installed Android PWA or fullscreen).',
        );
      }
    } catch {
      setOrientationNotice(
        'Orientation preference saved (browser restricts lock outside installed PWA / fullscreen).',
      );
    }
  }, []);

  useEffect(() => {
    void applyScreenOrientation(settings.orientationMode || 'free');
  }, [settings.orientationMode, applyScreenOrientation]);

  useEffect(() => {
    return () => {
      const orientation = (
        typeof screen !== 'undefined' ? screen.orientation : undefined
      ) as (ScreenOrientation & { unlock?: () => void }) | undefined;
      try {
        orientation?.unlock?.();
      } catch {
        // Ignore unlock errors on unsupported browsers
      }
    };
  }, []);

  // Open archive on mount
  useEffect(() => {
    let cancelled = false;
    let opened: OpenedComicArchive | null = null;

    setLoadingArchive(true);
    setErrorMsg(null);
    initialScrollDoneRef.current = false;

    (async () => {
      try {
        const blob = await resolveComicBlob(comic);
        opened = await openComicArchive(blob, comic.fileName);
        if (cancelled) {
          opened.dispose();
          return;
        }
        setArchive(opened);
        setLoadingArchive(false);
      } catch (err) {
        if (!cancelled) {
          setErrorMsg(err instanceof Error ? err.message : 'Unable to open comic archive.');
          setLoadingArchive(false);
        }
      }
    })();

    return () => {
      cancelled = true;
      if (opened) opened.dispose();
      for (const asset of decodedCacheRef.current.values()) {
        asset.revoke();
      }
      decodedCacheRef.current.clear();
      inFlightRef.current.clear();
    };
  }, [comic.id]);

  // Reset pinch zoom & pan cleanly when reading mode switches
  useEffect(() => {
    setPagedPinchZoom(1);
    setPanOffset({ x: 0, y: 0 });
    setVerticalPinchZoom(1);
    curlStageRef.current?.clear();
  }, [settings.readingMode]);

  // Measure paged stage viewport for DPI-aware PageCurlStage & focal pinch-zoom clamping
  useEffect(() => {
    const el = pagedStageRef.current;
    if (!el || isContinuousVertical || loadingArchive || errorMsg) {
      return;
    }

    const updateSize = () => {
      const rect = el.getBoundingClientRect();
      setStageSize((prev) =>
        prev.width === Math.round(rect.width) && prev.height === Math.round(rect.height)
          ? prev
          : { width: Math.round(rect.width), height: Math.round(rect.height) },
      );
    };

    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(el);
    return () => ro.disconnect();
  }, [isContinuousVertical, loadingArchive, errorMsg]);

  // Non-passive touch pinch & pan handler for Paged Modes (LTR, RTL, Paged Vertical)
  useEffect(() => {
    const el = pagedStageRef.current;
    if (!el || isContinuousVertical || loadingArchive || errorMsg) return;

    let gesture:
      | {
          mode: 'pinch';
          d0: number;
          startScale: number;
          startPan: { x: number; y: number };
          midX: number;
          midY: number;
        }
      | {
          mode: 'pan';
          startX: number;
          startY: number;
          startPan: { x: number; y: number };
          moved: boolean;
        }
      | null = null;

    const getBounds = (scale: number) => {
      const rect = el.getBoundingClientRect();
      const totalScale = activeBaseZoom * scale;
      const maxX = Math.max(0, (rect.width * Math.max(1, totalScale) - rect.width) / 2 + 40);
      const maxY = Math.max(0, (rect.height * Math.max(1, totalScale) - rect.height) / 2 + 40);
      return { rect, maxX, maxY };
    };

    const onTouchStart = (e: TouchEvent) => {
      activeTouchCountRef.current = e.touches.length;

      if (e.touches.length === 2) {
        e.preventDefault();
        curlDragRef.current = null;
        curlStageRef.current?.clear();
        touchStartRef.current = null;
        suppressNextClickRef.current = true;

        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const rect = el.getBoundingClientRect();
        const midX = (t0.clientX + t1.clientX) / 2 - (rect.left + rect.width / 2);
        const midY = (t0.clientY + t1.clientY) / 2 - (rect.top + rect.height / 2);
        const d0 = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);

        gesture = {
          mode: 'pinch',
          d0: Math.max(10, d0),
          startScale: pagedPinchZoomRef.current,
          startPan: { ...panOffsetRef.current },
          midX,
          midY,
        };
        setIsGesturing(true);
      } else if (e.touches.length === 1 && pagedPinchZoomRef.current > 1.02) {
        const t0 = e.touches[0];
        gesture = {
          mode: 'pan',
          startX: t0.clientX,
          startY: t0.clientY,
          startPan: { ...panOffsetRef.current },
          moved: false,
        };
        setIsGesturing(true);
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        curlDragRef.current = null;
        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const rect = el.getBoundingClientRect();
        const midX = (t0.clientX + t1.clientX) / 2 - (rect.left + rect.width / 2);
        const midY = (t0.clientY + t1.clientY) / 2 - (rect.top + rect.height / 2);
        const d1 = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);

        if (!gesture || gesture.mode !== 'pinch') {
          gesture = {
            mode: 'pinch',
            d0: Math.max(10, d1),
            startScale: pagedPinchZoomRef.current,
            startPan: { ...panOffsetRef.current },
            midX,
            midY,
          };
          setIsGesturing(true);
        }

        const nextScale = clamp(gesture.startScale * (d1 / gesture.d0), 1, 4);
        const ratio = nextScale / gesture.startScale;
        const { maxX, maxY } = getBounds(nextScale);

        const rawX = midX - (gesture.midX - gesture.startPan.x) * ratio;
        const rawY = midY - (gesture.midY - gesture.startPan.y) * ratio;

        setPagedPinchZoom(nextScale);
        setPanOffset(
          nextScale <= 1.02
            ? { x: 0, y: 0 }
            : { x: clamp(rawX, -maxX, maxX), y: clamp(rawY, -maxY, maxY) },
        );
      } else if (e.touches.length === 1 && gesture?.mode === 'pan' && pagedPinchZoomRef.current > 1.02) {
        e.preventDefault();
        const t0 = e.touches[0];
        const dx = t0.clientX - gesture.startX;
        const dy = t0.clientY - gesture.startY;
        if (Math.hypot(dx, dy) > 6) {
          gesture.moved = true;
          suppressNextClickRef.current = true;
        }
        const { maxX, maxY } = getBounds(pagedPinchZoomRef.current);
        setPanOffset({
          x: clamp(gesture.startPan.x + dx, -maxX, maxX),
          y: clamp(gesture.startPan.y + dy, -maxY, maxY),
        });
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      activeTouchCountRef.current = e.touches.length;
      if (e.touches.length < 2 && gesture?.mode === 'pinch') {
        if (pagedPinchZoomRef.current < 1.06) {
          setPagedPinchZoom(1);
          setPanOffset({ x: 0, y: 0 });
        }
        gesture = null;
        setIsGesturing(false);
      }
      if (e.touches.length === 0) {
        gesture = null;
        setIsGesturing(false);
      }
    };

    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      const delta = -e.deltaY * 0.01;
      const nextScale = clamp(pagedPinchZoomRef.current + delta, 1, 4);
      const { maxX, maxY } = getBounds(nextScale);
      setPagedPinchZoom(nextScale);
      if (nextScale <= 1.02) {
        setPanOffset({ x: 0, y: 0 });
      } else {
        setPanOffset((prev) => ({
          x: clamp(prev.x, -maxX, maxX),
          y: clamp(prev.y, -maxY, maxY),
        }));
      }
    };

    el.addEventListener('touchstart', onTouchStart, { passive: false });
    el.addEventListener('touchmove', onTouchMove, { passive: false });
    el.addEventListener('touchend', onTouchEnd, { passive: true });
    el.addEventListener('touchcancel', onTouchEnd, { passive: true });
    el.addEventListener('wheel', onWheel, { passive: false });

    return () => {
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
      el.removeEventListener('touchend', onTouchEnd);
      el.removeEventListener('touchcancel', onTouchEnd);
      el.removeEventListener('wheel', onWheel);
    };
  }, [isContinuousVertical, loadingArchive, errorMsg, activeBaseZoom]);

  // Non-passive touch pinch handler for Continuous Vertical mode (prevents browser HUD magnification)
  useEffect(() => {
    const container = verticalContainerRef.current;
    if (!container || !isContinuousVertical || loadingArchive || errorMsg) return;

    let pinch:
      | {
          d0: number;
          startZoom: number;
          midX: number;
          midY: number;
          startScrollLeft: number;
          startScrollTop: number;
        }
      | null = null;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        suppressNextClickRef.current = true;
        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const rect = container.getBoundingClientRect();
        pinch = {
          d0: Math.max(10, Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY)),
          startZoom: verticalPinchZoomRef.current,
          midX: (t0.clientX + t1.clientX) / 2 - rect.left,
          midY: (t0.clientY + t1.clientY) / 2 - rect.top,
          startScrollLeft: container.scrollLeft,
          startScrollTop: container.scrollTop,
        };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const rect = container.getBoundingClientRect();
        const d1 = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);

        if (!pinch) {
          pinch = {
            d0: Math.max(10, d1),
            startZoom: verticalPinchZoomRef.current,
            midX: (t0.clientX + t1.clientX) / 2 - rect.left,
            midY: (t0.clientY + t1.clientY) / 2 - rect.top,
            startScrollLeft: container.scrollLeft,
            startScrollTop: container.scrollTop,
          };
        }

        const nextZoom = clamp(pinch.startZoom * (d1 / pinch.d0), 1, 3.5);
        const ratio = nextZoom / pinch.startZoom;
        const targetLeft = Math.max(0, (pinch.startScrollLeft + pinch.midX) * ratio - pinch.midX);
        const targetTop = Math.max(0, (pinch.startScrollTop + pinch.midY) * ratio - pinch.midY);

        setVerticalPinchZoom(nextZoom);
        requestAnimationFrame(() => {
          container.scrollLeft = targetLeft;
          container.scrollTop = targetTop;
        });
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (e.touches.length < 2 && pinch) {
        if (verticalPinchZoomRef.current < 1.06) {
          setVerticalPinchZoom(1);
        }
        pinch = null;
      }
    };

    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      const nextZoom = clamp(verticalPinchZoomRef.current - e.deltaY * 0.01, 1, 3.5);
      setVerticalPinchZoom(nextZoom <= 1.04 ? 1 : nextZoom);
    };

    container.addEventListener('touchstart', onTouchStart, { passive: false });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    container.addEventListener('touchcancel', onTouchEnd, { passive: true });
    container.addEventListener('wheel', onWheel, { passive: false });

    return () => {
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
      container.removeEventListener('wheel', onWheel);
    };
  }, [isContinuousVertical, loadingArchive, errorMsg]);

  // Decode a specific page with LRU eviction
  const ensureDecodedPage = useCallback(
    async (pageIndex: number): Promise<DecodedPageAsset | null> => {
      if (!archive) return null;
      if (pageIndex < 0 || pageIndex >= archive.pages.length) return null;

      const existing = decodedCacheRef.current.get(pageIndex);
      if (existing) {
        decodedCacheRef.current.delete(pageIndex);
        decodedCacheRef.current.set(pageIndex, existing);
        return existing;
      }

      const pending = inFlightRef.current.get(pageIndex);
      if (pending) return pending;

      const task = (async () => {
        try {
          const desc = archive.pages[pageIndex];
          const bytes = await archive.getPageBytes(pageIndex);
          const asset = await decodeComicPage(bytes, pageIndex, desc.name, desc.ext, {
            hardwareAccel: settings.hardwareAccel,
            sliceLongStrips: settings.sliceLongStrips,
          });
          dimensionsRef.current.set(pageIndex, { width: asset.width, height: asset.height });

          if (decodedCacheRef.current.size >= MAX_DECODED_CACHE) {
            const firstKey = decodedCacheRef.current.keys().next().value;
            if (firstKey !== undefined && Math.abs(firstKey - pageIndex) > 3) {
              const evicted = decodedCacheRef.current.get(firstKey);
              evicted?.revoke();
              decodedCacheRef.current.delete(firstKey);
            }
          }

          decodedCacheRef.current.set(pageIndex, asset);
          setCacheVersion((v) => v + 1);
          return asset;
        } catch {
          return null;
        } finally {
          inFlightRef.current.delete(pageIndex);
        }
      })();

      inFlightRef.current.set(pageIndex, task);
      return task;
    },
    [archive, settings.hardwareAccel, settings.sliceLongStrips],
  );

  // Re-decode active window when hardwareAccel / sliceLongStrips toggles
  useEffect(() => {
    for (const asset of decodedCacheRef.current.values()) {
      asset.revoke();
    }
    decodedCacheRef.current.clear();
    setCacheVersion((v) => v + 1);
  }, [settings.hardwareAccel, settings.sliceLongStrips]);

  // Prefetch sliding window around currentPage
  useEffect(() => {
    if (!archive) return;
    const total = archive.pages.length;
    const ahead = isContinuousVertical ? 4 : 2;
    const behind = isContinuousVertical ? 2 : 1;

    const indices: number[] = [currentPage];
    for (let i = 1; i <= ahead; i++) {
      if (currentPage + i < total) indices.push(currentPage + i);
    }
    for (let i = 1; i <= behind; i++) {
      if (currentPage - i >= 0) indices.push(currentPage - i);
    }

    for (const idx of indices) {
      void ensureDecodedPage(idx).then((asset) => {
        if (!isContinuousVertical && !isPagedVertical && settings.pageTransition === 'curl') {
          preloadCurlAsset(asset);
        }
      });
    }
  }, [
    archive,
    currentPage,
    isContinuousVertical,
    isPagedVertical,
    settings.pageTransition,
    ensureDecodedPage,
    cacheVersion,
  ]);

  const flushProgress = useCallback(
    (pageIdx: number, offsetY?: number, ratioVal?: number) => {
      if (!archive || archive.pages.length === 0) return;
      const pageRatio = (pageIdx + 1) / archive.pages.length;
      const effectiveProgress =
        isContinuousVertical && ratioVal !== undefined ? Math.max(pageRatio, ratioVal) : pageRatio;
      onProgressChange(comic.id, {
        currentPage: pageIdx,
        scrollProgress: Math.min(1, Math.max(0, effectiveProgress)),
        scrollOffsetY: offsetY,
        scrollRatio: ratioVal,
      });
    },
    [archive, comic.id, onProgressChange, isContinuousVertical],
  );

  // Persist reading progress whenever page changes
  useEffect(() => {
    if (!archive || archive.pages.length === 0) return;
    if (!isContinuousVertical) {
      flushProgress(currentPage, 0, (currentPage + 1) / archive.pages.length);
    } else if (initialScrollDoneRef.current) {
      const m = latestScrollMetricsRef.current;
      flushProgress(currentPage, m.scrollOffsetY, m.scrollRatio);
    }
  }, [currentPage, archive, isContinuousVertical, flushProgress]);

  // Flush final scroll & page position when leaving the reader
  useEffect(() => {
    return () => {
      if (scrollSaveTimerRef.current !== null) {
        window.clearTimeout(scrollSaveTimerRef.current);
      }
      const m = latestScrollMetricsRef.current;
      if (archive && archive.pages.length > 0) {
        const pageRatio = (m.currentPage + 1) / archive.pages.length;
        onProgressChange(comic.id, {
          currentPage: m.currentPage,
          scrollProgress: isContinuousVertical
            ? Math.min(1, Math.max(pageRatio, m.scrollRatio))
            : pageRatio,
          scrollOffsetY: m.scrollOffsetY,
          scrollRatio: m.scrollRatio,
        });
      }
    };
  }, [archive, comic.id, onProgressChange, isContinuousVertical]);

  const totalPages = archive?.pages.length ?? comic.pageCount;

  // Restore saved scroll position (or jump to TOC initialPage) once startPage is decoded & sized
  useEffect(() => {
    if (
      loadingArchive ||
      !archive ||
      !isContinuousVertical ||
      initialScrollDoneRef.current
    ) {
      return;
    }

    const isExplicitJump = initialPage !== undefined && initialPage !== comic.currentPage;
    const hasDecodedStart = decodedCacheRef.current.has(startPage);
    if (!hasDecodedStart && archive.pages.length > 0) {
      return;
    }

    initialScrollDoneRef.current = true;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const container = verticalContainerRef.current;
        if (!container) return;

        if (!isExplicitJump && (comic.scrollOffsetY || comic.scrollRatio)) {
          const maxScroll = Math.max(0, container.scrollHeight - container.clientHeight);
          if (comic.scrollOffsetY && comic.scrollOffsetY > 0 && comic.scrollOffsetY <= maxScroll + 120) {
            container.scrollTop = Math.min(maxScroll, comic.scrollOffsetY);
          } else if (comic.scrollRatio && comic.scrollRatio > 0) {
            container.scrollTop = Math.round(comic.scrollRatio * maxScroll);
          } else if (startPage > 0) {
            pageSlotRefs.current.get(startPage)?.scrollIntoView({ behavior: 'auto', block: 'start' });
          }
        } else if (startPage > 0) {
          pageSlotRefs.current.get(startPage)?.scrollIntoView({ behavior: 'auto', block: 'start' });
        }
      });
    });
  }, [
    loadingArchive,
    archive,
    isContinuousVertical,
    startPage,
    initialPage,
    comic.currentPage,
    comic.scrollOffsetY,
    comic.scrollRatio,
    cacheVersion,
  ]);

  const jumpToPage = useCallback(
    (target: number, anchorYRatio = 0.85) => {
      const clamped = Math.max(0, Math.min(Math.max(0, totalPages - 1), target));
      if (clamped !== currentPage) {
        setNavDirection(clamped > currentPage ? 1 : -1);

        if (!isContinuousVertical && effectiveTransition === 'curl') {
          const oldAsset = decodedCacheRef.current.get(currentPage) || null;
          const newAsset = decodedCacheRef.current.get(clamped) || null;
          if (oldAsset && newAsset) {
            const isRtl = settings.readingMode === 'horizontal-rtl';
            const isForward = clamped > currentPage;
            curlStageRef.current?.animateTurn({
              frontPage: isForward ? oldAsset : newAsset,
              backPage: isForward ? newAsset : oldAsset,
              curlEdge: isRtl ? 'left' : 'right',
              fromProgress: isForward ? 0 : 1,
              toProgress: isForward ? 1 : 0,
              anchorYRatio,
              durationMs: 420,
            });
          }
        }
      }
      setCurrentPage(clamped);
      latestScrollMetricsRef.current.currentPage = clamped;
      setPagedPinchZoom(1);
      setPanOffset({ x: 0, y: 0 });
      if (isContinuousVertical) {
        const el = pageSlotRefs.current.get(clamped);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    },
    [
      totalPages,
      currentPage,
      isContinuousVertical,
      effectiveTransition,
      settings.readingMode,
    ],
  );

  // Track visible page AND exact scroll offset/ratio in continuous vertical scroll mode
  const handleVerticalScroll = useCallback(() => {
    const container = verticalContainerRef.current;
    if (!container || !isContinuousVertical) return;
    const containerRect = container.getBoundingClientRect();
    const probeY = containerRect.top + containerRect.height * 0.35;

    let closestIdx = currentPage;
    let bestDist = Infinity;

    pageSlotRefs.current.forEach((el, idx) => {
      const r = el.getBoundingClientRect();
      if (r.top <= probeY && r.bottom >= probeY) {
        closestIdx = idx;
        bestDist = 0;
        return;
      }
      const dist = Math.min(Math.abs(r.top - probeY), Math.abs(r.bottom - probeY));
      if (dist < bestDist) {
        bestDist = dist;
        closestIdx = idx;
      }
    });

    const maxScroll = Math.max(1, container.scrollHeight - container.clientHeight);
    const offsetY = Math.round(container.scrollTop);
    const scrollRatio = Math.min(1, Math.max(0, container.scrollTop / maxScroll));

    latestScrollMetricsRef.current = {
      currentPage: closestIdx,
      scrollOffsetY: offsetY,
      scrollRatio,
    };

    if (closestIdx !== currentPage) {
      setCurrentPage(closestIdx);
    }

    if (initialScrollDoneRef.current) {
      if (scrollSaveTimerRef.current !== null) {
        window.clearTimeout(scrollSaveTimerRef.current);
      }
      scrollSaveTimerRef.current = window.setTimeout(() => {
        flushProgress(closestIdx, offsetY, scrollRatio);
      }, 220);
    }
  }, [currentPage, isContinuousVertical, flushProgress]);

  // Keyboard navigation
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (settingsOpen || tocOpen) {
        if (e.key === 'Escape') {
          setSettingsOpen(false);
          setTocOpen(false);
        }
        return;
      }
      if (e.key === 'Escape') {
        if (activeBottomMenu) {
          setActiveBottomMenu(null);
          return;
        }
        onClose();
        return;
      }
      if (!isContinuousVertical) {
        if (isPagedVertical) {
          if (e.key === 'ArrowDown' || e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            jumpToPage(currentPage + 1);
          } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
            e.preventDefault();
            jumpToPage(currentPage - 1);
          }
        } else {
          const isRtl = settings.readingMode === 'horizontal-rtl';
          if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            jumpToPage(isRtl ? currentPage - 1 : currentPage + 1);
          } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            jumpToPage(isRtl ? currentPage + 1 : currentPage - 1);
          }
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    settingsOpen,
    tocOpen,
    activeBottomMenu,
    isContinuousVertical,
    isPagedVertical,
    settings.readingMode,
    currentPage,
    jumpToPage,
    onClose,
  ]);

  // Combined TOC from ComicInfo.xml + User Bookmarks
  const xmlChapters = useMemo(
    () => [...(archive?.comicInfo?.toc || comic.comicInfo?.toc || [])].sort((a, b) => a.pageIndex - b.pageIndex),
    [archive?.comicInfo, comic.comicInfo],
  );

  const combinedToc = useMemo(() => {
    const list: TocBookmark[] = [...xmlChapters, ...(comic.userBookmarks || [])];
    return list.sort((a, b) => a.pageIndex - b.pageIndex);
  }, [xmlChapters, comic.userBookmarks]);

  // Chapter navigation list (prefers ComicInfo chapters when present, else combined bookmarks)
  const chapterList = useMemo(
    () => (xmlChapters.length > 0 ? xmlChapters : combinedToc),
    [xmlChapters, combinedToc],
  );

  const currentChapterIndex = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < chapterList.length; i++) {
      if (chapterList[i].pageIndex <= currentPage) idx = i;
    }
    return idx;
  }, [chapterList, currentPage]);

  const currentChapter = currentChapterIndex >= 0 ? chapterList[currentChapterIndex] : null;
  const prevChapter = currentChapterIndex > 0 ? chapterList[currentChapterIndex - 1] : null;
  const nextChapter = useMemo(
    () => chapterList.find((item) => item.pageIndex > currentPage) || null,
    [chapterList, currentPage],
  );

  const isCurrentPageUserBookmarked = useMemo(
    () => (comic.userBookmarks || []).some((b) => b.pageIndex === currentPage),
    [comic.userBookmarks, currentPage],
  );

  const toggleUserBookmark = () => {
    const currentList = comic.userBookmarks || [];
    if (isCurrentPageUserBookmarked) {
      onUpdateUserBookmarks(
        comic.id,
        currentList.filter((b) => b.pageIndex !== currentPage),
      );
    } else {
      const newBookmark: TocBookmark = {
        pageIndex: currentPage,
        title: `Bookmark · Page ${currentPage + 1}`,
        source: 'user',
      };
      const next: TocBookmark[] = [...currentList, newBookmark].sort(
        (a, b) => a.pageIndex - b.pageIndex,
      );
      onUpdateUserBookmarks(comic.id, next);
    }
  };

  // Tap zone handler for Paged modes (LTR, RTL, Paged Vertical)
  const handlePagedTap = (e: React.MouseEvent<HTMLDivElement>) => {
    if (suppressNextClickRef.current) {
      suppressNextClickRef.current = false;
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const relX = (e.clientX - rect.left) / Math.max(1, rect.width);
    const relY = clamp((e.clientY - rect.top) / Math.max(1, rect.height), 0.05, 0.95);

    if (isPagedVertical) {
      if (relY < 0.3) {
        jumpToPage(currentPage - 1);
      } else if (relY > 0.7) {
        jumpToPage(currentPage + 1);
      } else {
        setActiveBottomMenu(null);
        setHudVisible((v) => !v);
      }
      return;
    }

    if (relX < 0.3) {
      const target = settings.readingMode === 'horizontal-rtl' ? currentPage + 1 : currentPage - 1;
      jumpToPage(target, relY);
    } else if (relX > 0.7) {
      const target = settings.readingMode === 'horizontal-rtl' ? currentPage - 1 : currentPage + 1;
      jumpToPage(target, relY);
    } else {
      setActiveBottomMenu(null);
      setHudVisible((v) => !v);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length !== 1 || pagedPinchZoom > 1.02) {
      touchStartRef.current = null;
      return;
    }
    if (effectiveTransition === 'curl' && !isPagedVertical) return;
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
      time: Date.now(),
    };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (
      !touchStartRef.current ||
      isContinuousVertical ||
      pagedPinchZoom > 1.02 ||
      activeTouchCountRef.current > 1
    ) {
      touchStartRef.current = null;
      return;
    }
    if (effectiveTransition === 'curl' && !isPagedVertical) return;
    if (settings.fitMode === 'custom' && settings.customZoom > 110) return;

    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;
    const dx = endX - touchStartRef.current.x;
    const dy = endY - touchStartRef.current.y;
    const dt = Date.now() - touchStartRef.current.time;
    touchStartRef.current = null;

    if (dt >= 420) return;

    if (isPagedVertical) {
      if (Math.abs(dy) > 55 && Math.abs(dy) > Math.abs(dx) * 1.3) {
        jumpToPage(dy < 0 ? currentPage + 1 : currentPage - 1);
      }
      return;
    }

    if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.35) {
      const isRtl = settings.readingMode === 'horizontal-rtl';
      if (dx < 0) {
        jumpToPage(isRtl ? currentPage - 1 : currentPage + 1);
      } else {
        jumpToPage(isRtl ? currentPage + 1 : currentPage - 1);
      }
    }
  };

  // Interactive finger / pointer drag-to-curl handlers for Kindle-style curl mode
  const handleCurlPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (
      effectiveTransition !== 'curl' ||
      isPagedVertical ||
      pagedPinchZoom > 1.02 ||
      activeTouchCountRef.current >= 2 ||
      !e.isPrimary
    ) {
      return;
    }
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (settings.fitMode === 'custom' && settings.customZoom > 110) return;

    const now = performance.now();
    const rect = e.currentTarget.getBoundingClientRect();
    const anchorYRatio = clamp((e.clientY - rect.top) / Math.max(1, rect.height), 0.06, 0.94);

    curlDragRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      lastX: e.clientX,
      lastTime: now,
      vx: 0,
      mode: 'pending',
      targetPage: currentPage,
      isForward: true,
      curlEdge: settings.readingMode === 'horizontal-rtl' ? 'left' : 'right',
      frontPage: null,
      backPage: null,
      progress: 0,
      dragRatio: 0,
      anchorYRatio,
    };
  };

  const handleCurlPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activeTouchCountRef.current >= 2 || pagedPinchZoomRef.current > 1.02) {
      if (curlDragRef.current?.mode === 'active') {
        curlStageRef.current?.clear();
      }
      curlDragRef.current = null;
      return;
    }

    const drag = curlDragRef.current;
    if (!drag || e.pointerId !== drag.pointerId) return;

    const now = performance.now();
    const dt = Math.max(1, now - drag.lastTime);
    drag.vx = (e.clientX - drag.lastX) / dt;
    drag.lastX = e.clientX;
    drag.lastTime = now;

    const dx = e.clientX - drag.startX;
    const dy = e.clientY - drag.startY;

    if (drag.mode === 'pending') {
      if (Math.hypot(dx, dy) < 9) return;
      if (Math.abs(dx) <= Math.abs(dy) * 1.1) {
        curlDragRef.current = null;
        return;
      }

      const isRtl = settings.readingMode === 'horizontal-rtl';
      const isForward = isRtl ? dx > 0 : dx < 0;
      const targetPage = currentPage + (isForward ? 1 : -1);

      if (targetPage < 0 || targetPage >= totalPages) {
        curlDragRef.current = null;
        return;
      }

      const currAsset = decodedCacheRef.current.get(currentPage) || null;
      const targetAsset = decodedCacheRef.current.get(targetPage) || null;
      if (!currAsset || !targetAsset) {
        curlDragRef.current = null;
        return;
      }

      drag.mode = 'active';
      drag.isForward = isForward;
      drag.targetPage = targetPage;
      drag.curlEdge = isRtl ? 'left' : 'right';
      drag.frontPage = isForward ? currAsset : targetAsset;
      drag.backPage = isForward ? targetAsset : currAsset;
      suppressNextClickRef.current = true;
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore if pointer capture is unsupported
      }
    }

    if (drag.mode === 'active') {
      const rect = e.currentTarget.getBoundingClientRect();
      const dragSpan = Math.max(200, rect.width * 0.72);
      const directionalDx =
        drag.curlEdge === 'right'
          ? drag.isForward
            ? -dx
            : dx
          : drag.isForward
            ? dx
            : -dx;
      const dragRatio = clamp(directionalDx / dragSpan, 0, 1);
      const progress = drag.isForward ? dragRatio : 1 - dragRatio;
      const anchorYRatio = clamp((e.clientY - rect.top) / Math.max(1, rect.height), 0.06, 0.94);

      drag.dragRatio = dragRatio;
      drag.progress = progress;
      drag.anchorYRatio = anchorYRatio;

      curlStageRef.current?.renderLive({
        frontPage: drag.frontPage,
        backPage: drag.backPage,
        curlEdge: drag.curlEdge,
        progress,
        anchorYRatio,
      });
    }
  };

  const handleCurlPointerEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    const drag = curlDragRef.current;
    if (!drag || e.pointerId !== drag.pointerId) return;
    curlDragRef.current = null;

    if (drag.mode !== 'active') return;

    const expectedVxSign =
      drag.curlEdge === 'right' ? (drag.isForward ? -1 : 1) : drag.isForward ? 1 : -1;
    const flickedForward = drag.vx * expectedVxSign > 0.32;
    const shouldCommit = drag.dragRatio > 0.28 || (drag.dragRatio > 0.08 && flickedForward);

    if (shouldCommit) {
      const toProgress = drag.isForward ? 1 : 0;
      const remaining = Math.abs(toProgress - drag.progress);
      curlStageRef.current?.animateTurn({
        frontPage: drag.frontPage,
        backPage: drag.backPage,
        curlEdge: drag.curlEdge,
        fromProgress: drag.progress,
        toProgress,
        anchorYRatio: drag.anchorYRatio,
        durationMs: Math.max(140, Math.round(remaining * 340)),
      });
      setNavDirection(drag.isForward ? 1 : -1);
      setCurrentPage(drag.targetPage);
      latestScrollMetricsRef.current.currentPage = drag.targetPage;
      setPagedPinchZoom(1);
      setPanOffset({ x: 0, y: 0 });
    } else {
      const toProgress = drag.isForward ? 0 : 1;
      const remaining = Math.abs(toProgress - drag.progress);
      curlStageRef.current?.animateTurn({
        frontPage: drag.frontPage,
        backPage: drag.backPage,
        curlEdge: drag.curlEdge,
        fromProgress: drag.progress,
        toProgress,
        anchorYRatio: drag.anchorYRatio,
        durationMs: Math.max(120, Math.round(remaining * 260)),
      });
    }
  };

  const readerBgIsLight = isLightHex(settings.readerBg);

  // Render Continuous Vertical Mode pages
  const renderVerticalPages = () => {
    if (!archive) return null;

    const isPinchZoomed = verticalPinchZoom > 1.02;
    const basePct = settings.fitMode === 'custom' ? settings.customZoom : 100;
    const effectiveColumnPct = Math.round(basePct * verticalPinchZoom);

    return (
      <div
        ref={verticalContainerRef}
        onScroll={handleVerticalScroll}
        onClick={() => {
          if (suppressNextClickRef.current) {
            suppressNextClickRef.current = false;
            return;
          }
          setActiveBottomMenu(null);
          setHudVisible((v) => !v);
        }}
        className="w-full h-full overflow-y-auto overflow-x-auto no-scrollbar gpu-layer"
        style={{ backgroundColor: settings.readerBg, touchAction: 'pan-x pan-y' }}
      >
        <div
          className="mx-auto flex flex-col items-center min-h-full transition-[padding] duration-150"
          style={{
            width: isPinchZoomed ? `${effectiveColumnPct}%` : '100%',
            paddingLeft: isPinchZoomed ? `${settings.marginLeft * 0.4}%` : `${settings.marginLeft}%`,
            paddingRight: isPinchZoomed ? `${settings.marginRight * 0.4}%` : `${settings.marginRight}%`,
            gap: `${settings.pageGap}px`,
            paddingTop: '12px',
            paddingBottom: '48px',
          }}
        >
          {archive.pages.map((pageDesc) => {
            const isNear = Math.abs(pageDesc.index - currentPage) <= 4;
            const decoded = decodedCacheRef.current.get(pageDesc.index);
            const dims = dimensionsRef.current.get(pageDesc.index);
            const ratio = dims ? dims.height / Math.max(1, dims.width) : 1.42;

            const widthStyle: React.CSSProperties = isPinchZoomed
              ? { width: '100%', maxWidth: 'none' }
              : settings.fitMode === 'custom'
                ? { width: `${settings.customZoom}%`, maxWidth: 'none' }
                : settings.fitMode === 'fit-height'
                  ? { width: 'auto', maxHeight: '96dvh' }
                  : { width: '100%', maxWidth: '980px' };

            return (
              <div
                key={pageDesc.index}
                ref={(el) => {
                  if (el) pageSlotRefs.current.set(pageDesc.index, el);
                  else pageSlotRefs.current.delete(pageDesc.index);
                }}
                className="comic-page-contain gpu-layer flex flex-col items-center shrink-0"
                style={
                  isPinchZoomed
                    ? { width: '100%', maxWidth: `${980 * verticalPinchZoom}px` }
                    : settings.fitMode === 'fit-height'
                      ? { maxWidth: '100%' }
                      : {
                          width: settings.fitMode === 'custom' ? `${settings.customZoom}%` : '100%',
                          maxWidth: settings.fitMode === 'custom' ? 'none' : '980px',
                        }
                }
              >
                {isNear && decoded ? (
                  <div className="w-full flex flex-col items-center" style={widthStyle}>
                    {decoded.tiles.map((tile, tIdx) => (
                      <img
                        key={`${decoded.index}-${tIdx}`}
                        src={tile.url}
                        alt={`Page ${pageDesc.index + 1}${decoded.wasSliced ? ` part ${tIdx + 1}` : ''}`}
                        referrerPolicy="no-referrer"
                        decoding="async"
                        draggable={false}
                        className="block w-full h-auto select-none gpu-layer"
                        style={
                          settings.fitMode === 'fit-height' && !decoded.wasSliced && !isPinchZoomed
                            ? { maxHeight: '96dvh', width: 'auto', maxWidth: '100%' }
                            : undefined
                        }
                      />
                    ))}
                  </div>
                ) : (
                  <div
                    className="w-full flex items-center justify-center rounded-sm"
                    style={{
                      aspectRatio: `1 / ${ratio}`,
                      maxWidth: settings.fitMode === 'custom' || isPinchZoomed ? 'none' : '980px',
                      backgroundColor: readerBgIsLight
                        ? 'rgba(0,0,0,0.04)'
                        : 'rgba(255,255,255,0.04)',
                    }}
                  >
                    {isNear && (
                      <Loader2
                        className={`w-6 h-6 animate-spin ${
                          readerBgIsLight ? 'text-zinc-500' : 'text-zinc-400'
                        }`}
                      />
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Build page transition variants for Paged modes (LTR, RTL, Paged Vertical)
  const visualDirection: 1 | -1 =
    settings.readingMode === 'horizontal-rtl' ? (navDirection === 1 ? -1 : 1) : navDirection;

  const pageVariants: Variants = useMemo(() => {
    switch (effectiveTransition) {
      case 'none':
      case 'curl':
        return {
          enter: { opacity: 1 },
          center: { opacity: 1 },
          exit: { opacity: 1 },
        };
      case 'fade':
        return {
          enter: { opacity: 0 },
          center: { opacity: 1, transition: { duration: 0.18, ease: 'easeOut' } },
          exit: { opacity: 0, transition: { duration: 0.15, ease: 'easeIn' } },
        };
      case 'zoom':
        return {
          enter: { opacity: 0, scale: 0.92 },
          center: {
            opacity: 1,
            scale: 1,
            transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
          },
          exit: {
            opacity: 0,
            scale: 1.05,
            transition: { duration: 0.18, ease: 'easeIn' },
          },
        };
      case 'stack':
        if (isPagedVertical) {
          return {
            enter: (dir: number) => ({
              y: dir > 0 ? '92%' : '-24%',
              scale: dir > 0 ? 1 : 0.94,
              opacity: dir > 0 ? 0.95 : 0.45,
            }),
            center: {
              y: '0%',
              scale: 1,
              opacity: 1,
              transition: { duration: 0.24, ease: [0.16, 1, 0.3, 1] },
            },
            exit: (dir: number) => ({
              y: dir > 0 ? '-22%' : '92%',
              scale: dir > 0 ? 0.94 : 1,
              opacity: dir > 0 ? 0.4 : 0.95,
              transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
            }),
          };
        }
        return {
          enter: (dir: number) => ({
            x: dir > 0 ? '92%' : '-24%',
            scale: dir > 0 ? 1 : 0.94,
            opacity: dir > 0 ? 0.95 : 0.45,
          }),
          center: {
            x: '0%',
            scale: 1,
            opacity: 1,
            transition: { duration: 0.24, ease: [0.16, 1, 0.3, 1] },
          },
          exit: (dir: number) => ({
            x: dir > 0 ? '-22%' : '92%',
            scale: dir > 0 ? 0.94 : 1,
            opacity: dir > 0 ? 0.4 : 0.95,
            transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
          }),
        };
      case 'slide':
      default:
        if (isPagedVertical) {
          return {
            enter: (dir: number) => ({
              y: dir > 0 ? '28%' : '-28%',
              opacity: 0,
            }),
            center: {
              y: '0%',
              opacity: 1,
              transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
            },
            exit: (dir: number) => ({
              y: dir > 0 ? '-28%' : '28%',
              opacity: 0,
              transition: { duration: 0.18, ease: 'easeIn' },
            }),
          };
        }
        return {
          enter: (dir: number) => ({
            x: dir > 0 ? '28%' : '-28%',
            opacity: 0,
          }),
          center: {
            x: '0%',
            opacity: 1,
            transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
          },
          exit: (dir: number) => ({
            x: dir > 0 ? '-28%' : '28%',
            opacity: 0,
            transition: { duration: 0.18, ease: 'easeIn' },
          }),
        };
    }
  }, [effectiveTransition, isPagedVertical]);

  // Render Paged Mode (LTR, RTL, Paged Vertical)
  const renderPagedView = () => {
    if (!archive) return null;
    const decoded = decodedCacheRef.current.get(currentPage);

    const imgClass =
      settings.fitMode === 'fit-width'
        ? 'w-full h-auto max-w-5xl'
        : settings.fitMode === 'fit-height'
          ? 'h-[100dvh] w-auto max-w-none'
          : 'max-h-[100dvh] max-w-full w-auto h-auto object-contain';

    const pageSurface = decoded ? (
      <div
        className={`gpu-layer flex flex-col items-center justify-center relative ${
          isGesturing ? '' : 'transition-transform duration-150 ease-out'
        }`}
        style={{
          transform:
            totalPagedScale !== 1 || panOffset.x !== 0 || panOffset.y !== 0
              ? `translate3d(${panOffset.x}px, ${panOffset.y}px, 0) scale(${totalPagedScale})`
              : 'translate3d(0, 0, 0)',
          transformOrigin: 'center center',
        }}
      >
        {decoded.tiles.map((tile, idx) => (
          <img
            key={`${decoded.index}-${idx}`}
            src={tile.url}
            alt={`Page ${currentPage + 1}`}
            referrerPolicy="no-referrer"
            decoding="async"
            draggable={false}
            className={`${imgClass} block select-none`}
          />
        ))}
      </div>
    ) : (
      <div className="flex flex-col items-center gap-3">
        <Loader2
          className={`w-7 h-7 animate-spin ${
            readerBgIsLight ? 'text-zinc-600' : 'text-zinc-300'
          }`}
        />
        <span
          className={`text-xs font-mono-nums ${
            readerBgIsLight ? 'text-zinc-600' : 'text-zinc-400'
          }`}
        >
          Decoding page {currentPage + 1}…
        </span>
      </div>
    );

    return (
      <div
        ref={pagedStageRef}
        className="w-full h-full relative overflow-hidden select-none"
        style={{
          backgroundColor: settings.readerBg,
          touchAction:
            pagedPinchZoom > 1.02 ||
            (effectiveTransition === 'curl' && !isPagedVertical) ||
            settings.fitMode !== 'fit-width'
              ? 'none'
              : 'pan-y',
        }}
        onClick={handlePagedTap}
        onDoubleClick={(e) => {
          e.stopPropagation();
          if (pagedPinchZoom > 1.05) {
            setPagedPinchZoom(1);
            setPanOffset({ x: 0, y: 0 });
          } else {
            const rect = e.currentTarget.getBoundingClientRect();
            const tapRelX = e.clientX - (rect.left + rect.width / 2);
            const tapRelY = e.clientY - (rect.top + rect.height / 2);
            setPagedPinchZoom(2);
            setPanOffset({
              x: clamp(-tapRelX * 0.5, -rect.width * 0.45, rect.width * 0.45),
              y: clamp(-tapRelY * 0.5, -rect.height * 0.45, rect.height * 0.45),
            });
          }
        }}
        onPointerDown={handleCurlPointerDown}
        onPointerMove={handleCurlPointerMove}
        onPointerUp={handleCurlPointerEnd}
        onPointerCancel={handleCurlPointerEnd}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <div
          className={`w-full h-full no-scrollbar flex items-center justify-center ${
            isPagedZoomed ? 'overflow-hidden' : 'overflow-x-hidden overflow-y-auto'
          }`}
        >
          {effectiveTransition === 'curl' && !isPagedVertical ? (
            <div className="w-full h-full flex items-center justify-center">{pageSurface}</div>
          ) : (
            <AnimatePresence mode="popLayout" custom={visualDirection} initial={false}>
              <motion.div
                key={currentPage}
                custom={visualDirection}
                variants={pageVariants}
                initial="enter"
                animate="center"
                exit="exit"
                className="w-full h-full flex items-center justify-center gpu-layer"
              >
                {pageSurface}
              </motion.div>
            </AnimatePresence>
          )}
        </div>

        {effectiveTransition === 'curl' && !isPagedVertical && (
          <PageCurlStage
            ref={curlStageRef}
            viewportWidth={stageSize.width}
            viewportHeight={stageSize.height}
            fitMode={settings.fitMode}
            zoomMultiplier={totalPagedScale}
            readerBg={settings.readerBg}
          />
        )}
      </div>
    );
  };

  const progressPct =
    totalPages > 1 ? Math.round((currentPage / Math.max(1, totalPages - 1)) * 100) : 100;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col overflow-hidden"
      style={{ backgroundColor: settings.readerBg }}
    >
      {/* Main Viewport */}
      {loadingArchive ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
          <Loader2
            className={`w-8 h-8 animate-spin ${
              readerBgIsLight ? 'text-zinc-700' : 'text-zinc-300'
            }`}
          />
          <p className={`text-sm font-medium ${readerBgIsLight ? 'text-zinc-800' : 'text-zinc-200'}`}>
            Opening {comic.displayTitle}
          </p>
          <p className={`text-xs ${readerBgIsLight ? 'text-zinc-500' : 'text-zinc-400'}`}>
            Preparing {comic.format.toUpperCase()} archive &amp; image decoders
          </p>
        </div>
      ) : errorMsg ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-4 p-6 text-center max-w-md mx-auto">
          <p className={`text-base font-semibold ${readerBgIsLight ? 'text-zinc-900' : 'text-white'}`}>
            Could not open archive
          </p>
          <p className={`text-sm ${readerBgIsLight ? 'text-zinc-600' : 'text-zinc-400'}`}>
            {errorMsg}
          </p>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-5 rounded-xl text-sm font-medium text-white"
            style={{ backgroundColor: 'var(--app-accent)' }}
          >
            Back to Library
          </button>
        </div>
      ) : isContinuousVertical ? (
        renderVerticalPages()
      ) : (
        renderPagedView()
      )}

      {/* Subtle Corner Page Counter when HUD is hidden */}
      {!loadingArchive && !errorMsg && settings.showPageNumberHud && !hudVisible && (
        <div
          className={`fixed bottom-3 right-4 z-10 pointer-events-none text-xs font-mono-nums tracking-tight select-none ${
            readerBgIsLight ? 'text-zinc-700/80' : 'text-zinc-200/75'
          }`}
          style={{
            textShadow: readerBgIsLight
              ? '0 1px 3px rgba(255,255,255,0.9)'
              : '0 1px 4px rgba(0,0,0,0.85)',
          }}
        >
          {currentPage + 1} / {Math.max(1, totalPages)}
        </div>
      )}

      {/* Top Kuro-style HUD (Single Bookmark Button at Top Right) */}
      <header
        style={{ touchAction: 'pan-x pan-y' }}
        className={`fixed top-0 inset-x-0 z-30 pt-safe bg-zinc-950/90 backdrop-blur-md text-white border-b border-white/10 transition-all duration-200 ${
          hudVisible
            ? 'translate-y-0 opacity-100'
            : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        <div className="h-14 px-2 sm:px-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 min-w-0">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors shrink-0"
              aria-label="Exit reader"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="min-w-0 pr-2">
              <h1 className="text-sm font-semibold truncate leading-tight">
                {comic.displayTitle}
              </h1>
              <p className="text-xs text-zinc-400 truncate">
                {currentChapter
                  ? currentChapter.title
                  : `${comic.format.toUpperCase()} · ${totalPages} pages`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={toggleUserBookmark}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors shrink-0"
            aria-label={isCurrentPageUserBookmarked ? 'Remove bookmark' : 'Bookmark current page'}
            title={isCurrentPageUserBookmarked ? 'Remove Bookmark' : 'Bookmark Page'}
          >
            {isCurrentPageUserBookmarked ? (
              <BookmarkCheck className="w-5 h-5" style={{ color: 'var(--app-accent)' }} />
            ) : (
              <Bookmark className="w-5 h-5" />
            )}
          </button>
        </div>
      </header>

      {/* Bottom Kuro-style Status Bar (Prev/Next Chapter + Center Progress Bar + 4 Bottom Action Buttons) */}
      <footer
        style={{ touchAction: 'pan-x pan-y' }}
        className={`fixed bottom-0 inset-x-0 z-30 pb-safe bg-zinc-950/90 backdrop-blur-md text-white border-t border-white/10 transition-all duration-200 ${
          hudVisible
            ? 'translate-y-0 opacity-100'
            : 'translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        {/* Popover Tray Anchored Directly Above Bottom Bar */}
        {hudVisible && activeBottomMenu && (
          <div className="absolute bottom-full mb-2 inset-x-0 px-3 flex justify-center pointer-events-none">
            <div
              className="w-full max-w-md rounded-2xl bg-zinc-900/95 backdrop-blur-md border border-white/12 p-3 text-white shadow-2xl pointer-events-auto space-y-2.5"
              onClick={(e) => e.stopPropagation()}
            >
              {activeBottomMenu === 'mode' ? (
                <>
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-semibold text-zinc-200">Reading Mode</span>
                    <button
                      type="button"
                      onClick={() => setActiveBottomMenu(null)}
                      className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white hover:bg-white/10"
                      aria-label="Close reading mode options"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(
                      [
                        { id: 'horizontal-ltr', label: 'LTR (Left to Right)' },
                        { id: 'horizontal-rtl', label: 'RTL (Manga)' },
                        { id: 'vertical', label: 'Continuous Vertical' },
                        { id: 'paged-vertical', label: 'Paged Vertical' },
                      ] as { id: ReadingMode; label: string }[]
                    ).map((opt) => {
                      const active = settings.readingMode === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => {
                            onChangeSettings({ ...settings, readingMode: opt.id });
                            setActiveBottomMenu(null);
                          }}
                          className={`min-h-[44px] px-3 rounded-xl text-xs font-medium flex items-center justify-between gap-2 transition-colors ${
                            active
                              ? 'text-white'
                              : 'bg-white/8 text-zinc-300 hover:bg-white/14 hover:text-white'
                          }`}
                          style={active ? { backgroundColor: 'var(--app-accent)' } : undefined}
                        >
                          <span className="truncate">{opt.label}</span>
                          {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-semibold text-zinc-200">Screen Orientation</span>
                    <button
                      type="button"
                      onClick={() => setActiveBottomMenu(null)}
                      className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white hover:bg-white/10"
                      aria-label="Close orientation options"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(
                      [
                        { id: 'portrait', label: 'Locked Portrait' },
                        { id: 'portrait-reverse', label: 'Locked Reverse Portrait' },
                        { id: 'landscape', label: 'Locked Landscape' },
                        { id: 'free', label: 'Free Rotate' },
                      ] as { id: ScreenOrientationMode; label: string }[]
                    ).map((opt) => {
                      const active = (settings.orientationMode || 'free') === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => {
                            onChangeSettings({ ...settings, orientationMode: opt.id });
                            setActiveBottomMenu(null);
                          }}
                          className={`min-h-[44px] px-3 rounded-xl text-xs font-medium flex items-center justify-between gap-2 transition-colors ${
                            active
                              ? 'text-white'
                              : 'bg-white/8 text-zinc-300 hover:bg-white/14 hover:text-white'
                          }`}
                          style={active ? { backgroundColor: 'var(--app-accent)' } : undefined}
                        >
                          <span className="truncate">{opt.label}</span>
                          {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                  {orientationNotice && (
                    <p className="text-[11px] text-zinc-400 px-1 leading-snug">
                      {orientationNotice}
                    </p>
                  )}
                </>
              )}
            </div>
          </div>
        )}
        <div className="max-w-3xl mx-auto px-3 sm:px-4 pt-2 pb-2 space-y-1.5">
          {/* Center Progress Bar Flanked by Previous & Next Chapter Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={!prevChapter}
              onClick={() => prevChapter && jumpToPage(prevChapter.pageIndex)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors text-zinc-100 disabled:opacity-30 disabled:text-zinc-500 disabled:pointer-events-none shrink-0"
              aria-label="Previous chapter"
              title={prevChapter ? `Previous chapter: ${prevChapter.title}` : 'No previous chapter'}
            >
              <SkipBack className="w-5 h-5" />
            </button>

            <div className="flex-1 flex flex-col gap-1 min-w-0">
              <input
                type="range"
                min={0}
                max={Math.max(0, totalPages - 1)}
                value={currentPage}
                onChange={(e) => jumpToPage(Number(e.target.value))}
                className="koma-slider w-full"
                style={{
                  background: `linear-gradient(to right, var(--app-accent) ${progressPct}%, rgba(255, 255, 255, 0.22) ${progressPct}%)`,
                }}
                aria-label="Reading progress"
              />
              <div className="flex items-center justify-between text-[11px] font-mono-nums text-zinc-400 px-0.5">
                <span className="truncate">
                  {currentChapter ? currentChapter.title : comic.displayTitle}
                </span>
                <span className="shrink-0 ml-2 text-zinc-300">
                  {currentPage + 1} / {Math.max(1, totalPages)}
                </span>
              </div>
            </div>

            <button
              type="button"
              disabled={!nextChapter}
              onClick={() => nextChapter && jumpToPage(nextChapter.pageIndex)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors text-zinc-100 disabled:opacity-30 disabled:text-zinc-500 disabled:pointer-events-none shrink-0"
              aria-label="Next chapter"
              title={nextChapter ? `Next chapter: ${nextChapter.title}` : 'No next chapter'}
            >
              <SkipForward className="w-5 h-5" />
            </button>
          </div>

          {/* 4 Action Buttons Below the Progress Bar */}
          <div className="grid grid-cols-4 gap-1.5">
            <button
              type="button"
              onClick={() =>
                setActiveBottomMenu((prev) => (prev === 'mode' ? null : 'mode'))
              }
              className={`min-h-[44px] px-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                activeBottomMenu === 'mode'
                  ? 'bg-white/15 text-white'
                  : 'text-zinc-300 hover:bg-white/10 hover:text-white'
              }`}
              aria-label="Reading mode options"
              aria-expanded={activeBottomMenu === 'mode'}
            >
              <BookOpen className="w-4 h-4 shrink-0" />
              <span className="truncate">Mode</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveBottomMenu((prev) => (prev === 'orientation' ? null : 'orientation'))
              }
              className={`min-h-[44px] px-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                activeBottomMenu === 'orientation'
                  ? 'bg-white/15 text-white'
                  : 'text-zinc-300 hover:bg-white/10 hover:text-white'
              }`}
              aria-label="Orientation options"
              aria-expanded={activeBottomMenu === 'orientation'}
            >
              <RotateCw className="w-4 h-4 shrink-0" />
              <span className="truncate">Rotate</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveBottomMenu(null);
                setTocOpen((v) => !v);
              }}
              className={`min-h-[44px] px-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                tocOpen
                  ? 'bg-white/15 text-white'
                  : 'text-zinc-300 hover:bg-white/10 hover:text-white'
              }`}
              aria-label="Toggle table of contents"
              aria-expanded={tocOpen}
            >
              <List className="w-4 h-4 shrink-0" />
              <span className="truncate">Contents</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveBottomMenu(null);
                setSettingsOpen(true);
              }}
              className="min-h-[44px] px-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-medium text-zinc-300 hover:bg-white/10 hover:text-white transition-colors whitespace-nowrap"
              aria-label="Reader and theme settings"
            >
              <Settings className="w-4 h-4 shrink-0" />
              <span className="truncate">Settings</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Table of Contents & Bookmarks Slide-Over Drawer */}
      {tocOpen && (
        <div
          className="fixed inset-0 z-40 flex justify-end bg-black/60 backdrop-blur-sm"
          onClick={() => setTocOpen(false)}
        >
          <aside
            className="w-full max-w-sm h-full bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 border-l border-zinc-200 dark:border-zinc-800 flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-zinc-200 dark:border-zinc-800">
              <div>
                <h2 className="text-sm font-semibold">Table of Contents</h2>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {combinedToc.length} entries from ComicInfo &amp; bookmarks
                </p>
              </div>
              <button
                type="button"
                onClick={() => setTocOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800"
                aria-label="Close table of contents"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-zinc-200/70 dark:divide-zinc-800/80">
              {combinedToc.length > 0 ? (
                combinedToc.map((item, idx) => {
                  const isActive = item.pageIndex === currentPage;
                  return (
                    <button
                      key={`${item.pageIndex}-${item.title}-${idx}`}
                      type="button"
                      onClick={() => {
                        setTocOpen(false);
                        jumpToPage(item.pageIndex);
                      }}
                      className={`w-full min-h-[52px] px-4 py-3 flex items-center justify-between gap-3 text-left transition-colors ${
                        isActive
                          ? 'bg-zinc-100 dark:bg-zinc-900'
                          : 'hover:bg-zinc-50 dark:hover:bg-zinc-900/50'
                      }`}
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{item.title}</p>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">
                          {item.source === 'user'
                            ? 'Personal Bookmark'
                            : item.source === 'bookmarks-tag'
                              ? 'ComicInfo Bookmarks Tag'
                              : item.type || 'ComicInfo Chapter'}
                        </p>
                      </div>
                      <span
                        className="text-xs font-mono-nums shrink-0 font-medium"
                        style={isActive ? { color: 'var(--app-accent)' } : undefined}
                      >
                        P.{item.pageIndex + 1}
                      </span>
                    </button>
                  );
                })
              ) : (
                <div className="p-6 text-center space-y-2">
                  <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
                    No bookmarks in this archive
                  </p>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Tap the bookmark button at the top right to save pages to your table of contents.
                  </p>
                </div>
              )}
            </div>
          </aside>
        </div>
      )}

      {/* Live Reader Quick Settings Sheet */}
      <SettingsSheet
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        theme={theme}
        readerSettings={settings}
        onChangeTheme={onChangeTheme}
        onChangeReader={onChangeSettings}
      />
    </div>
  );
};
