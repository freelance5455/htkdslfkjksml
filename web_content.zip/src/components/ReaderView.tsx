import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { Manhwa, Chapter, WorkType, WORK_TYPE_LABELS, MANHWA_GENRES } from '../types';
import { useAuth } from '../context/AuthContext';
import { SmartImage } from './SmartImage';
import {
  Search,
  Star,
  Eye,
  BookOpen,
  Bookmark,
  Calendar,
  Flame,
  Sparkles,
  ChevronLeft,
  X,
  Plus,
  Users,
  Compass
} from 'lucide-react';

interface ReaderViewProps {
  manhwas: Manhwa[];
  chapters: Chapter[];
  bookmarkedIds: string[];
  onToggleBookmark: (manhwa: Manhwa) => void;
  onOpenChapter: (manhwa: Manhwa, chapter: Chapter) => void;
  onSwitchToPublisher: () => void;
  onSelectTeam?: (teamId: string) => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  manhwas,
  chapters,
  bookmarkedIds,
  onToggleBookmark,
  onOpenChapter,
  onSwitchToPublisher
}) => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<WorkType | 'all'>('all');
  const [selectedGenre, setSelectedGenre] = useState<string>('الكل');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'views' | 'rating'>('latest');
  const [activeManhwa, setActiveManhwa] = useState<Manhwa | null>(null);

  // Filter and sort works
  const filteredManhwas = manhwas
    .filter((m) => {
      const matchesSearch =
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.titleOriginal && m.titleOriginal.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (m.author && m.author.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (m.teamName && m.teamName.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesType = selectedType === 'all' || m.type === selectedType;
      const matchesGenre = selectedGenre === 'الكل' || (m.genres && m.genres.includes(selectedGenre));
      const matchesStatus = selectedStatus === 'all' || m.status === selectedStatus;

      return matchesSearch && matchesType && matchesGenre && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'views') return (b.views || 0) - (a.views || 0);
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  // Featured spotlight work
  const featured = manhwas.length > 0 ? manhwas[0] : null;

  // Chapters of active work loaded on-demand
  const [activeChaptersList, setActiveChaptersList] = useState<Chapter[]>([]);

  useEffect(() => {
    if (!activeManhwa) {
      setActiveChaptersList([]);
      return;
    }

    const q = query(collection(db, 'chapters'), where('manhwaId', '==', activeManhwa.id));
    const unsubscribe = onSnapshot(
      q,
      (snap) => {
        const loaded: Chapter[] = [];
        snap.forEach((d) => loaded.push({ id: d.id, ...(d.data() as Omit<Chapter, 'id'>) }));
        loaded.sort((a, b) => a.chapterNumber - b.chapterNumber);
        setActiveChaptersList(loaded);
      },
      (err) => {
        console.warn('Chapters query notice:', err);
      }
    );

    return () => unsubscribe();
  }, [activeManhwa?.id]);

  const activeManhwaChapters = activeChaptersList.length > 0
    ? activeChaptersList
    : activeManhwa
    ? chapters.filter((c) => c.manhwaId === activeManhwa.id).sort((a, b) => a.chapterNumber - b.chapterNumber)
    : [];

  return (
    <div className="min-h-screen pb-20">
      
      {/* Featured Spotlight Banner */}
      {featured && !searchQuery && selectedGenre === 'الكل' && selectedType === 'all' && (
        <section className="relative overflow-hidden mb-8 border-b border-purple-900/20 bg-gradient-to-b from-[#141029] to-[#0b0f19]">
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-20 left-10 w-80 h-80 bg-pink-600/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-8">
              
              {/* Cover Poster */}
              <div 
                onClick={() => setActiveManhwa(featured)}
                className="w-48 sm:w-56 aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl shadow-purple-950/60 border-2 border-purple-500/30 shrink-0 cursor-pointer group transform hover:scale-105 transition-all"
              >
                <SmartImage
                  src={featured.coverUrl}
                  alt={featured.title}
                  fallbackText={featured.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  aspectRatio="aspect-[3/4]"
                  loading="eager"
                />
              </div>

              {/* Spotlight Info */}
              <div className="flex-1 text-center md:text-right">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-900/60 to-pink-900/60 border border-purple-500/30 text-purple-300 text-xs font-bold mb-4">
                  <Flame className="w-3.5 h-3.5 text-pink-400" />
                  <span>العمل المميز اليوم في مانهوا هارت</span>
                  <span className="text-[10px] bg-purple-700/60 px-2 py-0.5 rounded-full text-white">
                    {WORK_TYPE_LABELS[featured.type || 'manhwa']?.label || 'مانهوا'}
                  </span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight mb-2">
                  {featured.title}
                </h1>
                {featured.titleOriginal && (
                  <p className="text-sm font-semibold text-purple-300/80 mb-2 font-sans">
                    {featured.titleOriginal}
                  </p>
                )}

                {featured.teamName && (
                  <div className="inline-flex items-center gap-1.5 text-xs text-pink-300 font-semibold mb-3">
                    <Users className="w-3.5 h-3.5" />
                    <span>ترجمة ونشر: {featured.teamName}</span>
                  </div>
                )}

                <p className="text-gray-300 text-xs sm:text-sm leading-relaxed max-w-2xl line-clamp-3 mb-6">
                  {featured.description}
                </p>

                {/* Genre Tags */}
                <div className="flex flex-wrap gap-2 justify-center md:justify-start mb-6">
                  {featured.genres?.map((g) => (
                    <span
                      key={g}
                      className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#1a2035] text-purple-300 border border-purple-500/20"
                    >
                      {g}
                    </span>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3 justify-center md:justify-start">
                  <button
                    onClick={() => setActiveManhwa(featured)}
                    className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-bold text-sm shadow-xl shadow-purple-600/30 transition-all hover:scale-105"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>تصفح الفصول والتفاصيل</span>
                  </button>

                  <button
                    onClick={() => onToggleBookmark(featured)}
                    className={`p-3 rounded-xl border transition-all ${
                      bookmarkedIds.includes(featured.id)
                        ? 'bg-pink-600 text-white border-pink-500'
                        : 'bg-[#151b2d] text-gray-300 border-white/10 hover:text-white'
                    }`}
                    title="إضافة إلى المفضلة"
                  >
                    <Bookmark className="w-4 h-4 fill-current" />
                  </button>
                </div>

              </div>

            </div>
          </div>
        </section>
      )}

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Content Type Filter Tabs: مانهوا / مانجا / مانها / كوميكس / روايات */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mb-6 pb-1">
          <button
            onClick={() => setSelectedType('all')}
            className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedType === 'all'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-900/40'
                : 'bg-[#101627] text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>جميع الأعمال ({manhwas.length})</span>
          </button>

          {(Object.keys(WORK_TYPE_LABELS) as WorkType[]).map((type) => {
            const count = manhwas.filter((m) => m.type === type).length;
            return (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedType === type
                    ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-900/40'
                    : 'bg-[#101627] text-gray-400 hover:text-white border border-white/5'
                }`}
              >
                <span>{WORK_TYPE_LABELS[type].flag}</span>
                <span>{WORK_TYPE_LABELS[type].label}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search, Filter & Sort Controls */}
        <div className="bg-[#101627] p-4 rounded-3xl border border-white/5 shadow-xl mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
            
            {/* Search Input */}
            <div className="relative w-full md:w-96">
              <Search className="absolute right-3.5 top-3 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن اسم مانهوا، مانجا، رواية، فريق..."
                className="w-full bg-[#171f33] border border-white/10 rounded-xl pr-10 pl-4 py-2.5 text-xs text-gray-100 placeholder-gray-500 outline-none focus:border-purple-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-3 text-gray-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Sort & Status Selectors */}
            <div className="flex items-center gap-2 w-full md:w-auto justify-end">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-[#171f33] border border-white/10 text-xs font-bold text-gray-200 px-3 py-2 rounded-xl outline-none focus:border-purple-500"
              >
                <option value="all">جميع الحالات</option>
                <option value="ongoing">مستمرة</option>
                <option value="completed">مكتملة</option>
                <option value="hiatus">متوقفة</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'latest' | 'views' | 'rating')}
                className="bg-[#171f33] border border-white/10 text-xs font-bold text-gray-200 px-3 py-2 rounded-xl outline-none focus:border-purple-500"
              >
                <option value="latest">الأحدث إضافة</option>
                <option value="views">الأكثر مشاهدة</option>
                <option value="rating">الأعلى تقييماً</option>
              </select>
            </div>

          </div>

          {/* Genre Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
            <button
              onClick={() => setSelectedGenre('الكل')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedGenre === 'الكل'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'bg-[#171f33] text-gray-400 hover:text-white'
              }`}
            >
              الكل
            </button>
            {MANHWA_GENRES.map((genre) => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedGenre === genre
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'bg-[#171f33] text-gray-400 hover:text-white'
                }`}
              >
                {genre}
              </button>
            ))}
          </div>
        </div>

        {/* Works Grid */}
        {filteredManhwas.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6">
            {filteredManhwas.map((manhwa) => {
              const manhwaChs = chapters.filter((c) => c.manhwaId === manhwa.id);
              const latestCh = manhwaChs.sort((a, b) => b.chapterNumber - a.chapterNumber)[0];
              const isBookmarked = bookmarkedIds.includes(manhwa.id);
              const typeInfo = WORK_TYPE_LABELS[manhwa.type || 'manhwa'] || WORK_TYPE_LABELS.manhwa;

              return (
                <div
                  key={manhwa.id}
                  onClick={() => setActiveManhwa(manhwa)}
                  className="group relative bg-[#101627] rounded-2xl overflow-hidden border border-white/5 hover:border-purple-500/40 shadow-lg hover:shadow-purple-900/20 transition-all duration-300 flex flex-col cursor-pointer"
                >
                  {/* Poster Image Container */}
                  <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#181f33]">
                    <SmartImage
                      src={manhwa.coverUrl}
                      alt={manhwa.title}
                      fallbackText={manhwa.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      aspectRatio="aspect-[3/4]"
                      loading="lazy"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#101627] via-transparent to-black/30"></div>

                    {/* Type Badge & Status */}
                    <div className="absolute top-2 right-2 flex flex-col gap-1 items-end">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-950/80 backdrop-blur-md text-purple-300 border border-purple-500/40">
                        {typeInfo.flag} {typeInfo.ar}
                      </span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-black/70 backdrop-blur-md text-gray-300">
                        {manhwa.status === 'completed' ? 'مكتملة' : 'مستمرة'}
                      </span>
                    </div>

                    {/* Bookmark Quick Action */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleBookmark(manhwa);
                      }}
                      className={`absolute top-2 left-2 p-1.5 rounded-md backdrop-blur-md transition-all ${
                        isBookmarked
                          ? 'bg-pink-600 text-white'
                          : 'bg-black/60 text-gray-300 hover:text-white hover:bg-black/80'
                      }`}
                    >
                      <Bookmark className="w-3.5 h-3.5 fill-current" />
                    </button>

                    {/* Latest Chapter Pill */}
                    {(latestCh || manhwa.latestChapterNumber !== undefined) && (
                      <div className="absolute bottom-2 right-2 left-2 flex items-center justify-between text-[11px] font-bold bg-purple-950/85 backdrop-blur-md border border-purple-500/30 px-2 py-1 rounded-lg text-purple-200">
                        <span>
                          {manhwa.type === 'novel' ? 'فصل/حلقة' : 'فصل'} {latestCh?.chapterNumber ?? manhwa.latestChapterNumber}
                        </span>
                        <div className="flex items-center gap-1 text-[10px] text-gray-400">
                          <Eye className="w-3 h-3" />
                          <span>{manhwa.views || 0}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Card Content */}
                  <div className="p-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-xs sm:text-sm text-gray-100 group-hover:text-purple-400 transition-colors line-clamp-2 mb-1">
                        {manhwa.title}
                      </h3>
                      {manhwa.teamName && (
                        <p className="text-[10px] text-pink-400 truncate mb-1">
                          {manhwa.teamName}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-400 pt-2 border-t border-white/5">
                      <span className="truncate max-w-[80px]">
                        {manhwa.genres?.[0] || 'عمل'}
                      </span>
                      <div className="flex items-center gap-1 text-amber-400 font-bold">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{manhwa.rating ? manhwa.rating.toFixed(1) : '5.0'}</span>
                      </div>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        ) : (
          /* Empty State */
          <div className="py-20 text-center max-w-md mx-auto bg-[#101627] rounded-3xl border border-white/5 p-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-900/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Sparkles className="w-8 h-8" />
            </div>
            
            <h3 className="text-xl font-bold text-white mb-2">
              {searchQuery || selectedGenre !== 'الكل' || selectedType !== 'all'
                ? 'لا توجد أعمال مطابقة لبحثك'
                : 'قاعدة البيانات جاهزة للأعمال الحقيقية!'}
            </h3>
            
            <p className="text-xs text-gray-400 mb-6 leading-relaxed">
              {searchQuery || selectedGenre !== 'الكل' || selectedType !== 'all'
                ? 'جرب البحث بكلمات أخرى أو اختر نوعاً وتصنيفاً مختلفاً'
                : 'تم تنظيف قاعدة البيانات من أي أعمال وهمية أو متجر عملات. بصفتك ناشراً أو فريق ترجمة، يمكنك البدء فوراً برفع أول مانهوا أو مانجا أو رواية وفصولها!'}
            </p>

            <button
              onClick={onSwitchToPublisher}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-bold shadow-lg shadow-purple-600/30 transition-transform hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>نشر عمل جديد الآن</span>
            </button>
          </div>
        )}

      </div>

      {/* Details Modal */}
      {activeManhwa && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl relative">
            
            <button
              onClick={() => setActiveManhwa(null)}
              className="absolute top-4 left-4 z-10 p-2 rounded-full bg-black/60 text-gray-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header Poster & Details */}
            <div className="p-6 sm:p-8 bg-gradient-to-b from-purple-950/40 to-transparent flex flex-col sm:flex-row gap-6 items-center sm:items-start">
              <SmartImage
                src={activeManhwa.coverUrl}
                alt={activeManhwa.title}
                fallbackText={activeManhwa.title}
                className="w-full h-full object-cover"
                aspectRatio="aspect-[3/4]"
                containerClassName="w-40 sm:w-48 rounded-2xl shadow-xl border-2 border-purple-500/30 shrink-0"
                loading="eager"
              />

              <div className="flex-1 text-center sm:text-right">
                <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start mb-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-900/60 text-purple-300 border border-purple-500/30">
                    {WORK_TYPE_LABELS[activeManhwa.type || 'manhwa']?.label || 'مانهوا'}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-gray-800 text-gray-300">
                    {activeManhwa.status === 'completed' ? 'مكتملة' : 'مستمرة'}
                  </span>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>{activeManhwa.rating ? activeManhwa.rating.toFixed(1) : '5.0'}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-400 text-xs">
                    <Eye className="w-3.5 h-3.5" />
                    <span>{activeManhwa.views || 0} مشاهدة</span>
                  </div>
                </div>

                <h2 className="text-2xl font-black text-white mb-1">{activeManhwa.title}</h2>
                {activeManhwa.titleOriginal && (
                  <p className="text-xs text-purple-300/80 font-sans mb-2">{activeManhwa.titleOriginal}</p>
                )}

                {activeManhwa.teamName && (
                  <div className="inline-flex items-center gap-1.5 text-xs text-pink-400 font-bold mb-3">
                    <Users className="w-3.5 h-3.5" />
                    <span>فريق العمل: {activeManhwa.teamName}</span>
                  </div>
                )}

                <div className="flex flex-wrap gap-1.5 justify-center sm:justify-start mb-4">
                  {activeManhwa.genres?.map((g) => (
                    <span key={g} className="px-2 py-0.5 rounded-md bg-[#1a2035] text-[11px] text-gray-300">
                      {g}
                    </span>
                  ))}
                </div>

                <p className="text-xs text-gray-300 leading-relaxed mb-4 max-h-32 overflow-y-auto">
                  {activeManhwa.description}
                </p>

                <div className="flex items-center gap-3 justify-center sm:justify-start">
                  {activeManhwaChapters.length > 0 && (
                    <button
                      onClick={() => onOpenChapter(activeManhwa, activeManhwaChapters[0])}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-bold text-xs shadow-md shadow-purple-600/30"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>قراءة الفصل الأول</span>
                    </button>
                  )}

                  <button
                    onClick={() => onToggleBookmark(activeManhwa)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold transition-all ${
                      bookmarkedIds.includes(activeManhwa.id)
                        ? 'bg-pink-600 text-white border-pink-500'
                        : 'bg-[#151b2d] text-gray-300 border-white/10 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-4 h-4 fill-current" />
                    <span>{bookmarkedIds.includes(activeManhwa.id) ? 'في المفضلة' : 'أضف للمفضلة'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Chapters List */}
            <div className="p-6 border-t border-white/5">
              <h3 className="font-bold text-sm text-white mb-4">
                قائمة الفصول المتاحة ({activeManhwaChapters.length})
              </h3>

              {activeManhwaChapters.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto no-scrollbar">
                  {activeManhwaChapters.map((chapter) => (
                    <div
                      key={chapter.id}
                      onClick={() => onOpenChapter(activeManhwa, chapter)}
                      className="p-3 bg-[#151b2d] hover:bg-[#1f2844] rounded-xl border border-white/5 hover:border-purple-500/40 flex items-center justify-between cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-purple-900/30 text-purple-400 font-bold text-xs flex items-center justify-center">
                          {chapter.chapterNumber}
                        </div>
                        <div>
                          <span className="text-xs font-bold text-gray-200 group-hover:text-purple-300">
                            {activeManhwa.type === 'novel' ? 'فصل/حلقة' : 'الفصل'} {chapter.chapterNumber}
                          </span>
                          {chapter.title && (
                            <span className="text-[11px] text-gray-400 block truncate max-w-[140px]">
                              {chapter.title}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-gray-400 group-hover:text-purple-400">
                        {activeManhwa.type === 'novel' ? (
                          <span className="text-[10px] text-purple-300">نص الرواية</span>
                        ) : (
                          <span className="text-[10px] font-mono">{chapter.pagesCount || chapter.pages?.length || 0} ص</span>
                        )}
                        <ChevronLeft className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-xs text-gray-400">
                  لم يتم رفع فصول لهذا العمل بعد.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
