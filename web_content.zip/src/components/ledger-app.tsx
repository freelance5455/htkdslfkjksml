import { useEffect, useMemo, useState, type Dispatch, type FormEvent, type ReactNode, type SetStateAction } from "react";
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  Minus,
  Moon,
  Pencil,
  Plus,
  Stethoscope,
  Sun,
  Trash2,
} from "lucide-react";
import {
  BASE_HOURS,
  DEFAULT_FX,
  DEFAULT_HOURLY,
  KIND_LABEL,
  MONTHS,
  entryHours,
  formatInt,
  formatJalaliDate,
  formatMoney,
  formatQty,
  formatRial,
  income,
  inMonth,
  isoFromJalali,
  loadModel,
  monthLength,
  parseAmount,
  saveModel,
  shiftMonth,
  summarize,
  summaryText,
  todayIso,
  toJalaliParts,
  weekdayName,
  type Entry,
  type Kind,
  type Model,
} from "@/lib/ledger";

type Draft = {
  jy: number;
  jm: number;
  jd: number;
  kind: Kind;
  overtime: string;
  note: string;
};

type View = { jy: number; jm: number };

const OT_CHIPS = ["0", "0.5", "1", "1.5", "2", "3", "4"];

function blankDraft(iso: string, kind: Kind = "morning"): Draft {
  const j = toJalaliParts(iso);
  return { jy: j.jy, jm: j.jm, jd: j.jd, kind, overtime: "0", note: "" };
}

export function LedgerApp() {
  const [model, setModel] = useState<Model>({
    entries: [],
    hourlyRate: DEFAULT_HOURLY,
    fxRate: DEFAULT_FX,
  });
  const [view, setView] = useState<View>(() => {
    const today = toJalaliParts(todayIso());
    return { jy: today.jy, jm: today.jm };
  });
  const [scope, setScope] = useState<"month" | "all">("month");
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const loaded = loadModel();
    setModel(loaded);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveModel(model);
  }, [model, hydrated]);

  return (
    <Ledger model={model} setModel={setModel} view={view} setView={setView} scope={scope} setScope={setScope} />
  );
}

function Ledger({
  model,
  setModel,
  view,
  setView,
  scope,
  setScope,
}: {
  model: Model;
  setModel: Dispatch<SetStateAction<Model>>;
  view: View;
  setView: (view: View) => void;
  scope: "month" | "all";
  setScope: (scope: "month" | "all") => void;
}) {
  const today = toJalaliParts(todayIso());
  const yearAnchor = today.jy;
  const [draft, setDraft] = useState<Draft>(() => blankDraft(todayIso()));
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const visible = useMemo(() => {
    return model.entries
      .filter((entry) => (scope === "all" ? true : inMonth(entry.iso, view.jy, view.jm)))
      .sort((a, b) => b.iso.localeCompare(a.iso) || b.id.localeCompare(a.id));
  }, [model.entries, scope, view]);

  const stats = summarize(visible);
  const hourly = parseAmount(model.hourlyRate);
  const fx = parseAmount(model.fxRate);
  const pay = hourly != null && fx != null ? income(stats.totalHours, hourly, fx) : null;
  const periodTitle = scope === "all" ? "همه شیفت‌ها" : `${MONTHS[view.jm - 1]} ${formatInt(view.jy)}`;

  const years = useMemo(() => {
    const list = new Set<number>();
    for (let y = yearAnchor - 5; y <= yearAnchor + 1; y += 1) list.add(y);
    list.add(draft.jy);
    return [...list].sort((a, b) => a - b);
  }, [draft.jy, yearAnchor]);

  const days = monthLength(draft.jy, draft.jm);
  const overtimeValue = parseAmount(draft.overtime);
  const shiftTotal = overtimeValue == null ? null : BASE_HOURS[draft.kind] + overtimeValue;

  function updateDraft(partial: Partial<Draft>) {
    setDraft((current) => {
      const next = { ...current, ...partial };
      const len = monthLength(next.jy, next.jm);
      if (next.jd > len) next.jd = len;
      return next;
    });
    setFormError(null);
    setFlash(null);
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const overtime = parseAmount(draft.overtime);
    if (overtime == null || overtime > 24) {
      setFormError("ساعت اضافه‌کاری را بین ۰ تا ۲۴ وارد کنید.");
      return;
    }
    const iso = isoFromJalali(draft.jy, draft.jm, draft.jd);
    const nextEntry: Entry = {
      id: editingId ?? crypto.randomUUID(),
      iso,
      kind: draft.kind,
      overtime: Math.round(overtime * 100) / 100,
      note: draft.note.trim().slice(0, 80),
    };
    setModel((current) => {
      const entries = editingId
        ? current.entries.map((entry) => (entry.id === editingId ? nextEntry : entry))
        : [nextEntry, ...current.entries];
      return { ...current, entries };
    });
    setFormError(null);
    setFlash(editingId ? "شیفت ویرایش شد" : "شیفت ثبت شد");
    if (scope === "month") {
      const saved = toJalaliParts(iso);
      setView({ jy: saved.jy, jm: saved.jm });
    }
    setDraft((current) => ({ ...current, overtime: "0", note: "" }));
    if (editingId) setEditingId(null);
  }

  function startEdit(entry: Entry) {
    const j = toJalaliParts(entry.iso);
    setEditingId(entry.id);
    setDraft({
      jy: j.jy,
      jm: j.jm,
      jd: j.jd,
      kind: entry.kind,
      overtime: String(entry.overtime),
      note: entry.note,
    });
    setFormError(null);
    setFlash(null);
    document.getElementById("shift-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function cancelEdit() {
    setEditingId(null);
    setDraft(blankDraft(todayIso()));
    setFormError(null);
  }

  async function copySummary() {
    const text = summaryText({
      title: periodTitle,
      ...stats,
      hourly,
      fx,
      iqd: pay?.iqd ?? null,
      irr: pay?.irr ?? null,
    });
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setFlash("کپی انجام نشد");
    }
  }

  function bumpOvertime(delta: number) {
    const current = parseAmount(draft.overtime) ?? 0;
    const next = Math.min(24, Math.max(0, Math.round((current + delta) * 2) / 2));
    updateDraft({ overtime: String(next) });
  }

  return (
    <main className="mx-auto min-h-screen w-full max-w-xl px-4 py-6 sm:py-10">
      <header className="mb-6 flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-primary">کادر درمان</p>
          <h1 className="mt-1 text-3xl font-extrabold text-balance">دفتر شیفت</h1>
          <p className="mt-2 text-pretty text-muted">
            شیفت صبح ۹ ساعت است و شیفت عصر ۸ ساعت. اگر بیشتر از شیفت مانده‌اید، فقط همان ساعت اضافه را بنویسید.
          </p>
        </div>
        <div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary text-on-primary" aria-hidden>
          <Stethoscope size={22} strokeWidth={1.75} />
        </div>
      </header>

      <section className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line bg-surface text-ink disabled:opacity-40"
            aria-label="ماه قبل"
            disabled={scope === "all"}
            onClick={() => setView(shiftMonth(view.jy, view.jm, -1))}
          >
            <ChevronRight size={20} />
          </button>
          <p className="min-w-36 text-center text-lg font-bold">{periodTitle}</p>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line bg-surface text-ink disabled:opacity-40"
            aria-label="ماه بعد"
            disabled={scope === "all"}
            onClick={() => setView(shiftMonth(view.jy, view.jm, 1))}
          >
            <ChevronLeft size={20} />
          </button>
        </div>
        <div className="grid h-14 grid-cols-2 rounded-full border border-line bg-surface p-1" role="tablist" aria-label="بازه محاسبه">
          <button
            type="button"
            role="tab"
            aria-selected={scope === "month"}
            className={scope === "month" ? "rounded-full bg-primary font-semibold text-on-primary" : "rounded-full text-muted"}
            onClick={() => setScope("month")}
          >
            این ماه
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={scope === "all"}
            className={scope === "all" ? "rounded-full bg-primary font-semibold text-on-primary" : "rounded-full text-muted"}
            onClick={() => setScope("all")}
          >
            همه
          </button>
        </div>
      </section>

      <section className="payslip mb-5 rounded-card px-5 py-5 ps-8 shadow-card sm:px-6 sm:ps-10" aria-live="polite">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-bold">فیش کارکرد</h2>
            <p className="text-sm text-muted">{periodTitle}</p>
          </div>
          <button
            type="button"
            onClick={copySummary}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-bg px-3 text-sm font-medium text-ink"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
            {copied ? "کپی شد" : "کپی خلاصه"}
          </button>
        </div>

        <dl className="mt-2">
          <div className="border-t border-line py-4">
            <dt className="text-sm text-muted">ساعت کل کارکرد</dt>
            <dd className="num mt-1 text-4xl font-extrabold leading-none">
              {formatQty(stats.totalHours)}
              <span className="ms-2 text-lg font-semibold text-muted">ساعت</span>
            </dd>
            <p className="mt-2 text-sm text-muted">
              {formatInt(stats.morningCount)} صبح ({formatQty(stats.morningHours)})
              <span className="px-1.5">·</span>
              {formatInt(stats.eveningCount)} عصر ({formatQty(stats.eveningHours)})
              <span className="px-1.5">·</span>
              اضافه‌کار {formatQty(stats.overtime)}
            </p>
          </div>

          <div className="border-t border-line py-4">
            <dt className="text-sm text-muted">
              ساعت کل × {hourly == null ? "—" : formatQty(hourly)} دینار عراق
            </dt>
            <dd className="num mt-1 text-3xl font-bold leading-tight">
              {pay ? formatMoney(pay.iqd) : "—"}
              <span className="ms-2 text-base font-semibold text-muted">دینار</span>
            </dd>
          </div>

          <div className="border-t border-line py-4">
            <dt className="text-sm text-muted">ارزش درآمد کل به ریال ایران</dt>
            <dd className="num mt-1 text-3xl font-extrabold leading-tight text-primary">
              {pay ? formatRial(pay.irr) : "—"}
              <span className="ms-2 text-base font-semibold text-muted">ریال</span>
            </dd>
            <p className="mt-1 text-sm text-muted">
              {pay ? `معادل ${formatRial(pay.toman)} تومان` : "نرخ ساعت یا نرخ تبدیل نامعتبر است"}
            </p>
          </div>
        </dl>

        <div className="grid gap-3 border-t border-line pt-4 sm:grid-cols-2">
          <label className="block text-sm">
            <span className="font-medium">نرخ هر ساعت (دینار)</span>
            <input
              inputMode="decimal"
              value={model.hourlyRate}
              onChange={(event) =>
                setModel((current) => ({ ...current, hourlyRate: event.target.value }))
              }
              className="mt-1 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base text-ink"
            />
          </label>
          <label className="block text-sm">
            <span className="font-medium">هر دینار چند ریال</span>
            <input
              inputMode="decimal"
              value={model.fxRate}
              onChange={(event) =>
                setModel((current) => ({ ...current, fxRate: event.target.value }))
              }
              className="mt-1 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base text-ink"
            />
          </label>
        </div>
        <p className="mt-3 text-sm text-pretty text-muted">
          پیش‌فرض نرخ ساعت ۴٫۵ دینار است. تبدیل پیش‌فرض، نرخ میان‌بازار ۱۸ آبان ۱۴۰۵ است: هر دینار ≈ ۹۰۵٫۵۲ ریال.
          تومان برابر ریال تقسیم بر ۱۰ است. هر دو عدد را می‌توانید عوض کنید.
        </p>
        {(model.hourlyRate !== DEFAULT_HOURLY || model.fxRate !== DEFAULT_FX) && (
          <button
            type="button"
            className="mt-2 text-sm font-semibold text-primary"
            onClick={() =>
              setModel((current) => ({ ...current, hourlyRate: DEFAULT_HOURLY, fxRate: DEFAULT_FX }))
            }
          >
            بازگشت به نرخ پیش‌فرض
          </button>
        )}
      </section>

      <form id="shift-form" onSubmit={onSubmit} className="mb-5 rounded-card bg-surface p-4 shadow-card sm:p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">{editingId ? "ویرایش شیفت" : "ثبت شیفت"}</h2>
          {editingId && (
            <button type="button" onClick={cancelEdit} className="text-sm font-semibold text-muted">
              انصراف
            </button>
          )}
        </div>

        <fieldset>
          <legend className="mb-2 text-sm font-medium">تاریخ شمسی</legend>
          <div className="grid grid-cols-3 gap-2">
            <Select
              label="روز"
              value={draft.jd}
              onChange={(jd) => updateDraft({ jd })}
              options={Array.from({ length: days }, (_, i) => i + 1)}
            />
            <Select
              label="ماه"
              value={draft.jm}
              onChange={(jm) => updateDraft({ jm })}
              options={MONTHS.map((name, index) => ({ value: index + 1, label: name }))}
            />
            <Select
              label="سال"
              value={draft.jy}
              onChange={(jy) => updateDraft({ jy })}
              options={years}
            />
          </div>
        </fieldset>

        <fieldset className="mt-4">
          <legend className="mb-2 text-sm font-medium">نوع شیفت</legend>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="نوع شیفت">
            <KindButton
              active={draft.kind === "morning"}
              onClick={() => updateDraft({ kind: "morning" })}
              icon={<Sun size={18} />}
              title="صبح"
              detail="۹ ساعت"
            />
            <KindButton
              active={draft.kind === "evening"}
              onClick={() => updateDraft({ kind: "evening" })}
              icon={<Moon size={18} />}
              title="عصر"
              detail="۸ ساعت"
              tone="accent"
            />
          </div>
        </fieldset>

        <div className="mt-4">
          <label htmlFor="overtime" className="text-sm font-medium">
            ساعت اضافه‌کاری
          </label>
          <p className="mb-2 text-sm text-muted">فقط ساعت‌های بیشتر از طول شیفت. اگر اضافه نمانده‌اید، صفر بگذارید.</p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label="کم کردن اضافه‌کاری"
              onClick={() => bumpOvertime(-0.5)}
              className="grid size-12 place-items-center rounded-xl border border-line bg-bg"
            >
              <Minus size={18} />
            </button>
            <input
              id="overtime"
              inputMode="decimal"
              value={draft.overtime}
              onChange={(event) => updateDraft({ overtime: event.target.value })}
              className="num h-12 min-w-0 flex-1 rounded-xl border border-line bg-bg px-3 text-center text-lg font-bold"
            />
            <button
              type="button"
              aria-label="افزودن اضافه‌کاری"
              onClick={() => bumpOvertime(0.5)}
              className="grid size-12 place-items-center rounded-xl border border-line bg-bg"
            >
              <Plus size={18} />
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {OT_CHIPS.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => updateDraft({ overtime: chip })}
                className={
                  draft.overtime === chip
                    ? "h-11 rounded-full bg-primary px-3 text-sm font-semibold text-on-primary"
                    : "h-11 rounded-full border border-line bg-bg px-3 text-sm text-ink"
                }
              >
                {formatQty(Number(chip))}
              </button>
            ))}
          </div>
        </div>

        <label className="mt-4 block text-sm font-medium" htmlFor="note">
          توضیح (اختیاری)
          <input
            id="note"
            value={draft.note}
            maxLength={80}
            onChange={(event) => updateDraft({ note: event.target.value })}
            placeholder="مثلاً اورژانس یا بخش داخلی"
            className="mt-2 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base font-normal placeholder:text-muted"
          />
        </label>

        <p className="mt-4 rounded-xl bg-primary-soft px-3 py-3 text-sm text-primary">
          {shiftTotal == null
            ? "ساعت اضافه‌کاری نامعتبر است."
            : `این نوبت: ${formatQty(BASE_HOURS[draft.kind])} ساعت ${KIND_LABEL[draft.kind]} + ${formatQty(overtimeValue ?? 0)} اضافه‌کار = ${formatQty(shiftTotal)} ساعت`}
        </p>
        {formError && <p className="mt-2 text-sm font-medium text-accent">{formError}</p>}
        {flash && (
          <p className="mt-2 text-sm font-medium text-primary" role="status">
            {flash}
          </p>
        )}

        <button
          type="submit"
          className="mt-4 h-12 w-full rounded-xl bg-primary text-base font-bold text-on-primary transition-colors duration-200 hover:bg-primary/90"
        >
          {editingId ? "ذخیره ویرایش" : "ثبت شیفت"}
        </button>
      </form>

      <section>
        <h2 className="mb-3 text-lg font-bold">
          شیفت‌ها
          <span className="ms-2 text-sm font-medium text-muted">{formatInt(visible.length)} مورد</span>
        </h2>
        {visible.length === 0 ? (
          <div className="rounded-card border border-dashed border-line bg-surface px-4 py-8 text-center">
            <p className="font-semibold">هنوز شیفتی در این بازه نیست</p>
            <p className="mt-1 text-sm text-muted">اولین صبح یا عصر را ثبت کنید تا فیش بالا پر شود.</p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {visible.map((entry) => {
              const j = toJalaliParts(entry.iso);
              const confirming = pendingDelete === entry.id;
              return (
                <li key={entry.id} className="rounded-card border border-line bg-surface px-3 py-3 sm:px-4">
                  <div className="flex items-start gap-3">
                    <div
                      className={
                        entry.kind === "morning"
                          ? "grid size-12 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary"
                          : "grid size-12 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent"
                      }
                    >
                      <span className="num text-lg font-extrabold leading-none">{formatInt(j.jd)}</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={
                            entry.kind === "morning"
                              ? "rounded-full bg-primary-soft px-2 py-0.5 text-xs font-bold text-primary"
                              : "rounded-full bg-accent-soft px-2 py-0.5 text-xs font-bold text-accent"
                          }
                        >
                          {KIND_LABEL[entry.kind]}
                        </span>
                        <span className="text-sm text-muted">
                          {weekdayName(entry.iso)} {MONTHS[j.jm - 1]}
                        </span>
                      </div>
                      <p className="num mt-1 font-semibold">
                        {entry.overtime > 0
                          ? `${formatQty(BASE_HOURS[entry.kind])} + ${formatQty(entry.overtime)} اضافه‌کار = ${formatQty(entryHours(entry))} ساعت`
                          : `${formatQty(BASE_HOURS[entry.kind])} ساعت شیفت`}
                      </p>
                      {entry.note && <p className="truncate text-sm text-muted">{entry.note}</p>}
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <button
                        type="button"
                        aria-label={`ویرایش شیفت ${formatJalaliDate(entry.iso)}`}
                        onClick={() => startEdit(entry)}
                        className="grid size-11 place-items-center rounded-xl text-ink"
                      >
                        <Pencil size={18} />
                      </button>
                      <button
                        type="button"
                        aria-label={`حذف شیفت ${formatJalaliDate(entry.iso)}`}
                        onClick={() => setPendingDelete(confirming ? null : entry.id)}
                        className="grid size-11 place-items-center rounded-xl text-accent"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                  {confirming && (
                    <div className="mt-2 flex items-center justify-between gap-2 rounded-xl bg-accent-soft px-3 py-2">
                      <span className="text-sm font-medium text-accent">این شیفت حذف شود؟</span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          className="h-10 rounded-lg px-3 text-sm font-semibold text-muted"
                          onClick={() => setPendingDelete(null)}
                        >
                          خیر
                        </button>
                        <button
                          type="button"
                          className="h-10 rounded-lg bg-accent px-3 text-sm font-semibold text-on-primary"
                          onClick={() => {
                            setModel((current) => ({
                              ...current,
                              entries: current.entries.filter((item) => item.id !== entry.id),
                            }));
                            if (editingId === entry.id) cancelEdit();
                            setPendingDelete(null);
                          }}
                        >
                          بله، حذف
                        </button>
                      </div>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {model.entries.length > 0 && (
        <div className="mt-8 border-t border-line pt-4">
          {confirmClear ? (
            <div className="flex flex-wrap items-center gap-3">
              <p className="text-sm text-muted">همه شیفت‌های ذخیره‌شده پاک شوند؟</p>
              <button
                type="button"
                className="h-10 rounded-lg px-3 text-sm font-semibold text-muted"
                onClick={() => setConfirmClear(false)}
              >
                انصراف
              </button>
              <button
                type="button"
                className="h-10 rounded-lg bg-accent px-3 text-sm font-semibold text-on-primary"
                onClick={() => {
                  setModel((current) => ({ ...current, entries: [] }));
                  setConfirmClear(false);
                  setEditingId(null);
                }}
              >
                پاک کردن همه
              </button>
            </div>
          ) : (
            <button type="button" onClick={() => setConfirmClear(true)} className="text-sm font-medium text-muted">
              پاک کردن همه شیفت‌ها
            </button>
          )}
          <p className="mt-3 text-sm text-muted">شیفت‌ها فقط روی همین دستگاه می‌مانند.</p>
        </div>
      )}
    </main>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  options: Array<number | { value: number; label: string }>;
}) {
  return (
    <label className="block text-xs text-muted">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-1 h-12 w-full rounded-xl border border-line bg-bg px-2 text-base font-semibold text-ink"
      >
        {options.map((option) => {
          const item = typeof option === "number" ? { value: option, label: formatInt(option) } : option;
          return (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          );
        })}
      </select>
    </label>
  );
}

function KindButton({
  active,
  onClick,
  icon,
  title,
  detail,
  tone = "primary",
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  title: string;
  detail: string;
  tone?: "primary" | "accent";
}) {
  const activeClass = tone === "accent" ? "border-accent bg-accent-soft text-accent" : "border-primary bg-primary-soft text-primary";
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      className={`flex h-16 items-center justify-center gap-2 rounded-xl border text-base font-bold ${
        active ? activeClass : "border-line bg-bg text-ink"
      }`}
    >
      {icon}
      <span>
        {title}
        <span className="mt-0.5 block text-xs font-medium">{detail}</span>
      </span>
    </button>
  );
}
