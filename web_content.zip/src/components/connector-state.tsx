import {
  redirectToLoginIfRequired,
  type CallToolErrorState,
} from "@/lib/app-data";
import type { ConnectorPack } from "@/lib/assistant/types";
import { Button } from "@/components/ui/button";

export function ConnectorState({
  pack,
  label,
}: {
  pack: ConnectorPack;
  label: string;
}) {
  if (pack.pending) {
    return (
      <p className="text-sm text-muted">Connecting to {label.toLowerCase()}…</p>
    );
  }

  const error = pack.error as CallToolErrorState | null;
  if (!error && pack.ok) return null;

  const kind = error?.kind ?? "error";
  const message =
    error?.message ?? `Could not load ${label.toLowerCase()}.`;

  if (kind === "login") {
    return (
      <div className="flex flex-col gap-3 rounded-xl bg-raised p-4 shadow-[var(--shadow-border)]">
        <p className="text-sm leading-relaxed text-fg">{message}</p>
        <Button
          size="sm"
          className="self-start"
          onClick={() =>
            redirectToLoginIfRequired({
              ok: false,
              data: null,
              loginRequired: true,
              loginUrl: pack.loginUrl,
            })
          }
        >
          Continue with Grok
        </Button>
      </div>
    );
  }

  if (kind === "not_connected") {
    return (
      <div className="rounded-xl bg-raised p-4 shadow-[var(--shadow-border)]">
        <p className="text-sm leading-relaxed text-fg">
          Connect {label} in Grok to load this here. Open your Grok connectors,
          grant access, then come back.
        </p>
      </div>
    );
  }

  if (kind === "pending") {
    return <p className="text-sm text-muted">Connecting to your data…</p>;
  }

  return <p className="text-sm text-muted">{message}</p>;
}
