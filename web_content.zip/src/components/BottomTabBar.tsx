import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Home, 
  Compass, 
  Plus, 
  MessageCircle, 
  Gamepad2, 
  User as UserIcon,
  Sparkles 
} from 'lucide-react';

interface BottomTabBarProps {
  isDockedInFrame?: boolean;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({ isDockedInFrame = false }) => {
  const { 
    activeTab, 
    setActiveTab, 
    setIsCreateOpen, 
    user,
    t 
  } = useApp();

  const tabs = [
    { id: 'feed', label: t.home, icon: Home },
    { id: 'explore', label: t.explore, icon: Compass },
    // Center is '+' Add button
    { id: 'chat', label: t.chat, icon: MessageCircle, badge: 'Rooms' },
    { id: 'games', label: t.games, icon: Gamepad2 },
    { id: 'profile', label: t.profile, icon: UserIcon, isProfile: true },
  ];

  return (
    <nav 
      aria-label="Bottom Navigation Taskbar"
      className={`${
        isDockedInFrame 
          ? 'w-full bg-[#090b14]' 
          : 'fixed bottom-0 left-0 right-0 z-50 bg-[#090b14]/98 backdrop-blur-xl border-t border-slate-800/90 shadow-[0_-4px_30px_rgba(0,0,0,0.7)]'
      } px-3 py-1.5 transition-all select-none`}
    >
      <div className="max-w-lg mx-auto flex items-center justify-between relative px-1 sm:px-2">
        
        {/* Left Side: Home & Explore */}
        {tabs.slice(0, 2).map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col items-center justify-center min-w-[50px] sm:min-w-[56px] py-1 transition-all group ${
                isActive ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'stroke-[2.5px] text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]' : 'stroke-[1.8px]'}`} />
                {isActive && (
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400 animate-pulse" />
                )}
              </div>
              <span className={`text-[10px] font-medium tracking-tight mt-0.5 ${isActive ? 'text-cyan-300 font-bold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* Center: BIG Floating Glowing Neon "+" Add Confession Button (Instagram / TikTok Style) */}
        <div className="relative -top-3 sm:-top-3.5 flex items-center justify-center px-2">
          <button
            onClick={() => setIsCreateOpen(true)}
            title="Create / Whisper a new confession"
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 p-[2.5px] shadow-[0_0_20px_rgba(6,182,212,0.5)] hover:shadow-[0_0_28px_rgba(6,182,212,0.7)] hover:scale-108 active:scale-95 transition-all duration-200 flex items-center justify-center group"
          >
            <div className="w-full h-full rounded-full bg-[#090b14] flex flex-col items-center justify-center group-hover:bg-[#060810] transition-colors relative overflow-hidden">
              <Plus className="w-6 h-6 sm:w-7 sm:h-7 text-cyan-300 group-hover:text-cyan-100 group-hover:rotate-90 transition-transform duration-300 stroke-[3]" />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </div>
            {/* Ambient Pulse Ripple */}
            <span className="absolute inset-0 rounded-full border border-cyan-400/40 animate-ping opacity-35 pointer-events-none" />
          </button>
        </div>

        {/* Right Side: Chat, Games, Profile */}
        {tabs.slice(2).map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col items-center justify-center min-w-[50px] sm:min-w-[56px] py-1 transition-all group ${
                isActive ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative flex items-center justify-center">
                {tab.isProfile ? (
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs border ${
                    isActive ? 'border-cyan-400 bg-cyan-950 shadow-[0_0_8px_rgba(6,182,212,0.6)]' : 'border-slate-700 bg-slate-800'
                  }`}>
                    {user.avatarEmoji}
                  </div>
                ) : (
                  <Icon className={`w-5 h-5 transition-transform ${isActive ? 'stroke-[2.5px] text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]' : 'stroke-[1.8px]'}`} />
                )}

                {isActive && !tab.isProfile && (
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400 animate-pulse" />
                )}
              </div>
              <span className={`text-[10px] font-medium tracking-tight mt-0.5 ${isActive ? 'text-cyan-300 font-bold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}

      </div>
    </nav>
  );
};
