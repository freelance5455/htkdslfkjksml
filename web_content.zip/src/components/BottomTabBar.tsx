import React from 'react';
import { ActiveTab } from '../types';
import { 
  Home, 
  Eye, 
  Volume2, 
  Wrench, 
  Activity 
} from 'lucide-react';

interface BottomTabBarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home' as ActiveTab, label: 'الرئيسية', icon: Home },
    { id: 'screen' as ActiveTab, label: 'إبقاء الشاشة', icon: Eye },
    { id: 'audio' as ActiveTab, label: 'إصلاح الصوت', icon: Volume2 },
    { id: 'services' as ActiveTab, label: 'الخدمات', icon: Wrench },
    { id: 'diagnostics' as ActiveTab, label: 'الفحص', icon: Activity },
  ];

  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800 pb-safe shadow-2xl">
      <div className="grid grid-cols-5 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center h-full py-1 transition-all cursor-pointer ${
                isActive ? 'text-red-500 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className={`p-1 rounded-xl transition-all ${isActive ? 'bg-red-600/10' : ''}`}>
                <Icon className={`w-5 h-5 ${isActive ? 'text-red-500 stroke-[2.4]' : ''}`} />
              </div>
              <span className="text-[10px] mt-0.5 truncate max-w-[62px]">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
