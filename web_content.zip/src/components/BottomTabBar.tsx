import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Home, 
  Compass, 
  MessageCircle, 
  Gamepad2, 
  User as UserIcon 
} from 'lucide-react';

interface BottomTabBarProps {
  isDockedInFrame?: boolean;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({ isDockedInFrame = false }) => {
  const { 
    activeTab, 
    setActiveTab, 
    user,
    t 
  } = useApp();

  const tabs = [
    { id: 'feed', label: t.home, icon: Home },
    { id: 'explore', label: t.explore, icon: Compass },
    { id: 'chat', label: t.chat, icon: MessageCircle },
    { id: 'games', label: t.games, icon: Gamepad2 },
    { id: 'profile', label: t.profile, icon: UserIcon, isProfile: true },
  ];

  return (
    <nav 
      aria-label="Bottom Navigation Taskbar"
      className={`${
        isDockedInFrame 
          ? 'w-full bg-[#090b14]/98' 
          : 'fixed bottom-0 left-0 right-0 z-50 bg-[#090b14]/98 backdrop-blur-xl border-t border-slate-800/90 shadow-[0_-4px_30px_rgba(0,0,0,0.7)]'
      } px-2 sm:px-4 py-1.5 transition-all select-none`}
    >
      <div className="max-w-md mx-auto grid grid-cols-5 items-center justify-items-center gap-1 sm:gap-2">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all group ${
                isActive 
                  ? 'text-cyan-400 bg-cyan-500/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              } active:scale-95`}
            >
              <div className="relative flex items-center justify-center my-0.5">
                {tab.isProfile ? (
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs border transition-transform ${
                    isActive ? 'border-cyan-400 bg-cyan-950 shadow-[0_0_8px_rgba(6,182,212,0.6)] scale-110' : 'border-slate-700 bg-slate-800'
                  }`}>
                    {user.avatarEmoji}
                  </div>
                ) : (
                  <Icon className={`w-5 h-5 transition-transform ${
                    isActive 
                      ? 'stroke-[2.5px] text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)] scale-110' 
                      : 'stroke-[1.8px]'
                  }`} />
                )}
                {isActive && !tab.isProfile && (
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400 animate-pulse" />
                )}
              </div>
              <span className={`text-[10px] font-semibold tracking-tight truncate max-w-full ${
                isActive ? 'text-cyan-300 font-bold' : ''
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
