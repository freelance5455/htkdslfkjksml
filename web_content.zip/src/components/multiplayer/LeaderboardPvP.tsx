import React, { useState } from 'react';
import { LeaderboardUser, HunterProfile, Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { 
  Trophy, 
  Swords, 
  Users, 
  Flame, 
  Medal, 
  Crown, 
  CheckCircle2, 
  XCircle,
  Play
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  profile: HunterProfile;
  language: Language;
  soundEnabled: boolean;
  onAddXp: (amount: number) => void;
}

const INITIAL_PEERS: LeaderboardUser[] = [
  { id: 'p-1', name: 'أمينة الجزائرية', wilaya: 'الجزائر (16)', rank: 'S', level: 34, xp: 8940, streak: 18, avatarSeed: 'Amina' },
  { id: 'p-2', name: 'ياسين وهران', wilaya: 'وهران (31)', rank: 'A', level: 27, xp: 6420, streak: 12, avatarSeed: 'Yacine' },
  { id: 'p-3', name: 'مهدي قسنطينة', wilaya: 'قسنطينة (25)', rank: 'A', level: 24, xp: 5800, streak: 9, avatarSeed: 'Mehdi' },
  { id: 'p-4', name: 'فاطمة سطيف', wilaya: 'سطيف (19)', rank: 'B', level: 19, xp: 4100, streak: 7, avatarSeed: 'Fatima' },
  { id: 'p-5', name: 'كريم عنابة', wilaya: 'عنابة (23)', rank: 'B', level: 16, xp: 3500, streak: 5, avatarSeed: 'Karim' },
  { id: 'p-6', name: 'سارة تيزي وزو', wilaya: 'تيزي وزو (15)', rank: 'C', level: 11, xp: 2200, streak: 4, avatarSeed: 'Sarah' },
];

export const LeaderboardPvP: React.FC<Props> = ({
  profile,
  language,
  soundEnabled,
  onAddXp
}) => {
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'pvp'>('leaderboard');
  const [timeframe, setTimeframe] = useState<'daily' | 'weekly' | 'allTime'>('weekly');
  const [isDuelActive, setIsDuelActive] = useState(false);
  const [duelRound, setDuelRound] = useState(1);
  const [playerScore, setPlayerScore] = useState(0);
  const [opponentScore, setOpponentScore] = useState(0);
  const [duelQuestion, setDuelQuestion] = useState({
    q: 'ما هو العظم الأطول والأقوى في جسم الإنسان؟',
    options: ['عظم الفخذ (Fémur)', 'عظم العضد (Humérus)', 'عظم الظنبوب (Tibia)', 'الترقوة (Clavicule)'],
    correct: 0
  });
  const [isDuelFinished, setIsDuelFinished] = useState(false);

  // Combine user into leaderboard
  const fullLeaderboard: LeaderboardUser[] = [
    ...INITIAL_PEERS,
    {
      id: 'current-user',
      name: profile.name || 'أنت (الصياد)',
      wilaya: 'الجزائر DZ',
      rank: profile.rank,
      level: profile.level,
      xp: profile.currentXp + (profile.level - 1) * 300,
      streak: profile.streak,
      avatarSeed: 'User',
      isCurrentUser: true
    }
  ].sort((a, b) => b.xp - a.xp);

  const handleStartDuel = () => {
    setIsDuelActive(true);
    setDuelRound(1);
    setPlayerScore(0);
    setOpponentScore(0);
    setIsDuelFinished(false);
    soundManager.playSlash(soundEnabled);
  };

  const handleDuelAnswer = (index: number) => {
    const isCorrect = index === duelQuestion.correct;
    // Opponent random outcome (70% chance correct)
    const opponentCorrect = Math.random() < 0.7;

    const newPlayerScore = playerScore + (isCorrect ? 1 : 0);
    const newOppScore = opponentScore + (opponentCorrect ? 1 : 0);

    setPlayerScore(newPlayerScore);
    setOpponentScore(newOppScore);

    if (isCorrect) {
      soundManager.playSuccess(soundEnabled);
    } else {
      soundManager.playError(soundEnabled);
    }

    if (duelRound >= 3) {
      setIsDuelFinished(true);
      if (newPlayerScore > newOppScore) {
        onAddXp(120);
        soundManager.playRankUp(soundEnabled);
        try {
          confetti({ particleCount: 70, spread: 60 });
        } catch {}
      }
    } else {
      setDuelRound((r) => r + 1);
      // Next rapid duel question
      if (duelRound === 1) {
        setDuelQuestion({
          q: 'ما هي كثافة الهواء على مقياس هاونسفيلد (UH) في السكانير؟',
          options: ['-1000 UH', '0 UH', '+100 UH', '+1000 UH'],
          correct: 0
        });
      } else {
        setDuelQuestion({
          q: 'أي تسلسل رنين تظهر فيه السوائل الحرة سوداء لإظهار التصلب اللويحي؟',
          options: ['FLAIR', 'T2', 'T1', 'Diffusion'],
          correct: 0
        });
      }
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-indigo-950 p-5 rounded-2xl border border-purple-500/40 shadow-neon-purple text-right">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-100 flex items-center gap-2">
              <Users className="w-6 h-6 text-purple-400" />
              <span>ميدان التنافس وسلم الصدارة (Leaderboard & 1v1 Arena)</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              تنافس مع طلبة الباراميديكال في الجزائر، ارتقِ في سلم الصيادين، وتحدى زملاءك في مبارزات فورية.
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex items-center gap-1.5 bg-black/60 p-1 rounded-xl border border-purple-900 text-xs">
            <button
              onClick={() => { setActiveTab('leaderboard'); soundManager.playTick(soundEnabled); }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold transition-colors ${
                activeTab === 'leaderboard' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Medal className="w-4 h-4" />
              <span>سلم الصدارة</span>
            </button>
            <button
              onClick={() => { setActiveTab('pvp'); soundManager.playTick(soundEnabled); }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold transition-colors ${
                activeTab === 'pvp' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Swords className="w-4 h-4" />
              <span>مبارزة 1 ضد 1</span>
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'leaderboard' ? (
        /* Leaderboard Table */
        <div className="bg-slate-950/80 rounded-2xl border border-purple-900/40 overflow-hidden text-right shadow-xl">
          {/* Timeframe filters */}
          <div className="flex items-center justify-between p-3.5 border-b border-purple-900/30 bg-black/40 text-xs">
            <span className="font-bold text-slate-300">أقوى صيادي الأشعة في الجزائر:</span>
            <div className="flex items-center gap-1">
              {(['daily', 'weekly', 'allTime'] as const).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                    timeframe === tf
                      ? 'bg-purple-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tf === 'daily' ? 'اليومي' : tf === 'weekly' ? 'الأسبوعي' : 'الكلي'}
                </button>
              ))}
            </div>
          </div>

          {/* Rows */}
          <div className="divide-y divide-purple-900/20">
            {fullLeaderboard.map((user, idx) => (
              <div
                key={user.id}
                className={`flex items-center justify-between p-4 transition-colors ${
                  user.isCurrentUser
                    ? 'bg-purple-950/60 border-l-4 border-l-purple-500 font-bold'
                    : 'hover:bg-slate-900/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank Index */}
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center font-black text-xs font-mono ${
                    idx === 0
                      ? 'bg-amber-400 text-slate-950'
                      : idx === 1
                      ? 'bg-slate-300 text-slate-950'
                      : idx === 2
                      ? 'bg-amber-700 text-white'
                      : 'bg-slate-900 text-slate-400'
                  }`}>
                    {idx + 1}
                  </span>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-slate-100">
                        {user.name}
                      </span>
                      {user.isCurrentUser && (
                        <span className="text-[10px] bg-purple-600 text-white px-2 py-0.5 rounded-full">
                          أنت
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {user.wilaya}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  {/* Streak */}
                  <div className="flex items-center gap-1 text-amber-400">
                    <Flame className="w-3.5 h-3.5 fill-current" />
                    <span>{user.streak}d</span>
                  </div>

                  {/* Rank Badge */}
                  <span className="px-2 py-0.5 rounded-md bg-purple-900/80 text-purple-200 border border-purple-700/60 font-bold text-[10px]">
                    {user.rank}-Rank
                  </span>

                  {/* XP */}
                  <span className="text-purple-300 font-bold w-16 text-left">
                    {user.xp} XP
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* 1v1 PvP Duel Mode */
        <div className="bg-slate-950/90 p-6 rounded-3xl border border-rose-500/40 shadow-neon-crimson text-right max-w-xl mx-auto w-full">
          {!isDuelActive ? (
            <div className="text-center py-6">
              <Swords className="w-16 h-16 text-rose-500 mx-auto mb-3" />
              <h3 className="text-xl font-black text-slate-100 mb-1">
                مبارزة المصطلحات الشعاعية السريعة
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto mb-6">
                تحدَّ طالباً منافساً في 3 جولات خاطفة وسريعة لاختبار سرعتك في التعرف على المصطلحات والتشريح الإشعاعي!
              </p>
              <button
                onClick={handleStartDuel}
                className="px-8 py-3 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 text-white font-extrabold text-xs rounded-xl shadow-neon-crimson transition-all active:scale-95"
              >
                العثور على خصم وبدء المبارزة
              </button>
            </div>
          ) : !isDuelFinished ? (
            <div>
              {/* Scoreboard */}
              <div className="flex items-center justify-between border-b border-rose-900/40 pb-3 mb-4 font-mono text-xs">
                <div className="text-purple-400 font-bold">
                  أنت: {playerScore}
                </div>
                <div className="text-xs text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-purple-900">
                  الجولة {duelRound} من 3
                </div>
                <div className="text-rose-400 font-bold">
                  الخصم: {opponentScore}
                </div>
              </div>

              {/* Question */}
              <h4 className="text-sm md:text-base font-black text-slate-100 mb-4 leading-relaxed">
                {duelQuestion.q}
              </h4>

              {/* Options */}
              <div className="space-y-2.5">
                {duelQuestion.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleDuelAnswer(idx)}
                    className="w-full text-right p-3.5 bg-black/60 hover:bg-rose-950/40 border border-purple-900/40 hover:border-rose-500/60 rounded-xl text-xs font-semibold text-slate-200 transition-all active:scale-95"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Duel Finished */
            <div className="text-center py-4">
              {playerScore > opponentScore ? (
                <>
                  <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-2 animate-bounce" />
                  <h3 className="text-xl font-black text-emerald-400 mb-1">
                    انتصار ساحق في المبارزة!
                  </h3>
                  <p className="text-xs text-slate-300 mb-4">
                    تغلبت على الخصم بنتيجة {playerScore} مقابل {opponentScore}. كسبت +120 XP!
                  </p>
                </>
              ) : playerScore < opponentScore ? (
                <>
                  <XCircle className="w-16 h-16 text-rose-500 mx-auto mb-2" />
                  <h3 className="text-xl font-black text-rose-400 mb-1">
                    خسارة بشرف!
                  </h3>
                  <p className="text-xs text-slate-300 mb-4">
                    الخصم كان أسرع هذه المرة ({opponentScore} مقابل {playerScore}). راجع معلوماتك وحاول ثانية!
                  </p>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-16 h-16 text-purple-400 mx-auto mb-2" />
                  <h3 className="text-xl font-black text-purple-300 mb-1">
                    تعادل الأبطال!
                  </h3>
                  <p className="text-xs text-slate-300 mb-4">
                    تكافؤ القوى الشعاعية بينك وبين الخصم ({playerScore} - {opponentScore}).
                  </p>
                </>
              )}

              <button
                onClick={() => setIsDuelActive(false)}
                className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all active:scale-95"
              >
                العودة إلى ساحة التحدي
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
