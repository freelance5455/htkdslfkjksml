import React, { useState } from 'react';
import { Track, VisualizerMode } from '../types/audio';
import { DynamicVisualizer } from './DynamicVisualizer';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Sliders,
  Moon,
  Volume2,
  VolumeX,
  Disc,
  Radio,
  Layers,
  Sparkles,
  Maximize2
} from 'lucide-react';

interface Props {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isShuffle: boolean;
  repeatMode: 'off' | 'all' | 'one';
  bpm: number;
  isBeat: boolean;
  beatStrength: number;
  reactiveVisualFx: boolean;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onToggleFavorite: (trackId: string) => void;
  onOpenDSP: () => void;
  onOpenSleepTimer: () => void;
}

export const PlayerView: React.FC<Props> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  isShuffle,
  repeatMode,
  bpm,
  isBeat,
  beatStrength,
  reactiveVisualFx,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onVolumeChange,
  onToggleShuffle,
  onCycleRepeat,
  onToggleFavorite,
  onOpenDSP,
  onOpenSleepTimer,
}) => {
  const [displayMode, setDisplayMode] = useState<'cover' | 'visualizer'>('visualizer');
  const [visualizerMode, setVisualizerMode] = useState<VisualizerMode>('spectre');

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="max-w-xl mx-auto flex flex-col items-center space-y-6">
      {/* Top Bar inside Player View: Display Mode switch (Cover vs Visualizer) & Tool shortcuts */}
      <div className="w-full flex items-center justify-between px-2 text-xs">
        {/* Toggle Cover vs Visualizer */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setDisplayMode('cover')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition ${
              displayMode === 'cover'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Disc className="w-3.5 h-3.5" />
            <span>Portada</span>
          </button>
          <button
            onClick={() => setDisplayMode('visualizer')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition ${
              displayMode === 'visualizer'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Visualizador FX</span>
          </button>
        </div>

        {/* Visualizer Mode selector when visualizer is active */}
        {displayMode === 'visualizer' && (
          <div className="hidden sm:flex items-center gap-1 text-[11px] text-slate-400">
            {(['spectre', 'waves', 'bars', 'aura'] as VisualizerMode[]).map((vMode) => {
              const labels: Record<VisualizerMode, string> = {
                spectre: 'Pulsar',
                waves: 'Ondas',
                bars: 'Barras',
                aura: 'Aura',
              };
              return (
                <button
                  key={vMode}
                  onClick={() => setVisualizerMode(vMode)}
                  className={`px-2 py-0.5 rounded-md transition ${
                    visualizerMode === vMode
                      ? 'bg-slate-800 text-indigo-300 font-semibold border border-indigo-500/40'
                      : 'hover:text-slate-200'
                  }`}
                >
                  {labels[vMode]}
                </button>
              );
            })}
          </div>
        )}

        {/* Quick Tools: DSP & Sleep Timer */}
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenDSP}
            className="p-2 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition"
            title="Abrir Ecualizador DSP"
          >
            <Sliders className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenSleepTimer}
            className="p-2 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition"
            title="Temporizador de apagado"
          >
            <Moon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Visual Arena: Album Cover or Dynamic Visualizer */}
      <div
        className={`relative w-full aspect-square max-w-[340px] sm:max-w-[380px] rounded-3xl overflow-hidden border transition-all duration-150 flex items-center justify-center bg-slate-950 shadow-2xl ${
          reactiveVisualFx && isBeat
            ? 'border-indigo-500 shadow-indigo-500/30'
            : 'border-slate-800/80 shadow-black/80'
        }`}
      >
        {displayMode === 'cover' ? (
          <div className="relative w-full h-full p-4 flex items-center justify-center">
            {/* Spinning Vinyl Record behind jacket */}
            <div
              className={`w-full h-full rounded-2xl overflow-hidden shadow-2xl relative border border-white/10 ${
                isPlaying ? 'scale-100' : 'scale-[0.98]'
              } transition-transform duration-500`}
            >
              <img
                src={currentTrack?.coverUrl || '/icon.svg'}
                alt={currentTrack?.title || 'Reproduciendo'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />

              {/* Dynamic subtle beat pulse overlay */}
              {reactiveVisualFx && (
                <div
                  className="absolute inset-0 bg-indigo-500/20 pointer-events-none transition-opacity duration-75"
                  style={{ opacity: isBeat ? 0.4 : 0 }}
                />
              )}
            </div>
          </div>
        ) : (
          <div className="w-full h-full relative">
            <DynamicVisualizer
              mode={visualizerMode}
              isPlaying={isPlaying}
              beatStrength={beatStrength}
              bpm={bpm}
              className="w-full h-full"
            />
            {/* Ambient center thumbnail if visualizer is running */}
            <div className="absolute top-4 left-4 flex items-center gap-2 p-1.5 bg-black/60 backdrop-blur-md rounded-xl border border-white/10">
              <div className="w-7 h-7 rounded-lg overflow-hidden shrink-0">
                <img
                  src={currentTrack?.coverUrl || '/icon.svg'}
                  alt={currentTrack?.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="pr-2 min-w-0">
                <p className="text-[11px] font-semibold text-white truncate max-w-[120px]">
                  {currentTrack?.title}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Audiophile Hi-Fi Quality Badge */}
        <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/15 flex items-center gap-1.5 text-[10px] font-mono text-slate-300">
          <Sparkles className="w-3 h-3 text-indigo-400" />
          <span className="uppercase font-semibold text-white">
            {currentTrack?.format || 'Hi-Fi'}
          </span>
          <span className="text-slate-400">·</span>
          <span>{currentTrack?.sampleRate ? `${currentTrack.sampleRate / 1000}kHz` : '48kHz'}</span>
          <span className="text-slate-400">·</span>
          <span>{currentTrack?.bitDepth ? `${currentTrack.bitDepth}-bit` : '24-bit'}</span>
        </div>

        {/* BPM Badge */}
        <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/15 flex items-center gap-1.5 text-[10px] font-mono">
          <div
            className={`w-1.5 h-1.5 rounded-full transition-colors ${
              isBeat ? 'bg-emerald-400' : 'bg-slate-500'
            }`}
          />
          <span className="tabular-nums text-white font-semibold">{bpm} BPM</span>
        </div>
      </div>

      {/* Track Title, Artist, Album & Favorite Toggle */}
      <div className="w-full flex items-center justify-between px-1">
        <div className="min-w-0 flex-1 pr-3">
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight truncate">
            {currentTrack?.title || 'Sin reproducción activa'}
          </h1>
          <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-400 mt-1 truncate">
            <span className="font-medium text-slate-300 truncate">
              {currentTrack?.artist || 'Selecciona una canción en tu biblioteca'}
            </span>
            {currentTrack?.album && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-slate-500 truncate">{currentTrack.album}</span>
              </>
            )}
          </div>
        </div>

        {currentTrack && (
          <button
            onClick={() => onToggleFavorite(currentTrack.id)}
            className={`p-2.5 rounded-2xl border transition ${
              currentTrack.isFavorite
                ? 'bg-pink-500/10 border-pink-500/30 text-pink-500 shadow-sm'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Heart
              className={`w-5 h-5 ${currentTrack.isFavorite ? 'fill-current' : ''}`}
            />
          </button>
        )}
      </div>

      {/* Seek Progress Bar */}
      <div className="w-full space-y-1.5">
        <div className="relative flex items-center">
          <input
            type="range"
            min="0"
            max={duration || 100}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>
        <div className="flex justify-between text-xs font-mono tabular-nums text-slate-400 px-0.5">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      {/* Main Playback Controls */}
      <div className="w-full flex items-center justify-between px-2 pt-1">
        {/* Shuffle */}
        <button
          onClick={onToggleShuffle}
          className={`p-2.5 rounded-xl transition ${
            isShuffle
              ? 'text-indigo-400 bg-indigo-500/15'
              : 'text-slate-500 hover:text-slate-300'
          }`}
          title="Modo aleatorio"
        >
          <Shuffle className="w-5 h-5" />
        </button>

        {/* Previous */}
        <button
          onClick={onPrev}
          className="p-3 text-slate-300 hover:text-white rounded-2xl hover:bg-slate-800/80 transition active:scale-95"
          title="Canción anterior"
        >
          <SkipBack className="w-6 h-6" />
        </button>

        {/* Play/Pause Button */}
        <button
          onClick={onTogglePlay}
          className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white flex items-center justify-center shadow-xl shadow-indigo-500/30 active:scale-95 transition-transform"
          title={isPlaying ? 'Pausar' : 'Reproducir'}
        >
          {isPlaying ? (
            <Pause className="w-7 h-7 fill-current" />
          ) : (
            <Play className="w-7 h-7 fill-current ml-1" />
          )}
        </button>

        {/* Next */}
        <button
          onClick={onNext}
          className="p-3 text-slate-300 hover:text-white rounded-2xl hover:bg-slate-800/80 transition active:scale-95"
          title="Canción siguiente"
        >
          <SkipForward className="w-6 h-6" />
        </button>

        {/* Repeat */}
        <button
          onClick={onCycleRepeat}
          className={`p-2.5 rounded-xl transition ${
            repeatMode !== 'off'
              ? 'text-indigo-400 bg-indigo-500/15'
              : 'text-slate-500 hover:text-slate-300'
          }`}
          title={`Repetir: ${repeatMode}`}
        >
          {repeatMode === 'one' ? (
            <Repeat1 className="w-5 h-5" />
          ) : (
            <Repeat className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Volume slider */}
      <div className="w-full flex items-center gap-3 px-4 py-2.5 bg-slate-900/60 border border-slate-800/80 rounded-2xl">
        <button
          onClick={() => onVolumeChange(volume === 0 ? 0.8 : 0)}
          className="text-slate-400 hover:text-white"
        >
          {volume === 0 ? (
            <VolumeX className="w-4 h-4" />
          ) : (
            <Volume2 className="w-4 h-4" />
          )}
        </button>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={(e) => onVolumeChange(Number(e.target.value))}
          className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
        />
        <span className="text-xs font-mono tabular-nums text-slate-400 w-9 text-right">
          {Math.round(volume * 100)}%
        </span>
      </div>
    </div>
  );
};
