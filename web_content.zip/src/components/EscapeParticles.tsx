import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export interface ParticleBurst {
  id: string;
  x: number;
  y: number;
  color: string;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  shape: 'circle' | 'star' | 'ring';
}

interface EscapeParticlesProps {
  bursts: ParticleBurst[];
  onBurstComplete: (id: string) => void;
}

export const EscapeParticles: React.FC<EscapeParticlesProps> = ({
  bursts,
  onBurstComplete,
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
      <AnimatePresence>
        {bursts.map((burst) => (
          <BurstGroup
            key={burst.id}
            burst={burst}
            onComplete={() => onBurstComplete(burst.id)}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

const BurstGroup: React.FC<{
  burst: ParticleBurst;
  onComplete: () => void;
}> = ({ burst, onComplete }) => {
  const [particles] = useState<Particle[]>(() => {
    const list: Particle[] = [];
    const count = 14;
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.5;
      const speed = 40 + Math.random() * 85;
      list.push({
        id: i,
        x: 0,
        y: 0,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 4 + Math.random() * 6,
        color: burst.color,
        shape: i % 3 === 0 ? 'star' : i % 3 === 1 ? 'ring' : 'circle',
      });
    }
    return list;
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 650);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div
      className="absolute pointer-events-none"
      style={{ left: burst.x, top: burst.y }}
    >
      {/* Central flash shockwave */}
      <motion.div
        className="absolute rounded-full -translate-x-1/2 -translate-y-1/2 border-2"
        style={{ borderColor: burst.color }}
        initial={{ scale: 0.2, opacity: 0.9 }}
        animate={{ scale: 2.2, opacity: 0 }}
        transition={{ duration: 0.45, ease: 'easeOut' }}
      />

      {/* Sparkles */}
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{
            width: p.size,
            height: p.size,
            backgroundColor: p.shape === 'ring' ? 'transparent' : p.color,
            border: p.shape === 'ring' ? `2px solid ${p.color}` : undefined,
            boxShadow: `0 0 8px ${p.color}`,
          }}
          initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
          animate={{
            x: p.vx,
            y: p.vy,
            scale: 0,
            opacity: 0,
          }}
          transition={{
            duration: 0.55 + Math.random() * 0.1,
            ease: [0.16, 1, 0.3, 1],
          }}
        />
      ))}
    </div>
  );
};
