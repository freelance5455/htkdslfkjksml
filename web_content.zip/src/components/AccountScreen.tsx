import React from 'react';
import { 
  CreditCard, 
  Package, 
  Truck, 
  MessageSquare, 
  Star, 
  Coins, 
  Ticket, 
  Heart, 
  HelpCircle, 
  Settings, 
  ChevronRight, 
  ShieldCheck, 
  UserCheck,
  Download,
  MessageCircle
} from 'lucide-react';
import { OrderRecord } from '../types/ecommerce';

interface AccountScreenProps {
  orders: OrderRecord[];
  onOpenOrders: () => void;
  onOpenWishlist: () => void;
  onOpenVouchers: () => void;
  onOpenExport?: () => void;
  onOpenWhatsAppSupport?: () => void;
}

export const AccountScreen: React.FC<AccountScreenProps> = ({
  orders,
  onOpenOrders,
  onOpenWishlist,
  onOpenVouchers,
  onOpenExport,
  onOpenWhatsAppSupport
}) => {
  return (
    <div className="pb-24 bg-slate-100 min-h-screen">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-[#FF6600] to-[#E05500] text-white p-4 pt-6 rounded-b-3xl shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full bg-white/20 p-1 backdrop-blur-xs border-2 border-white/60">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                alt="Kasun Perera"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-extrabold text-white">Kasun Perera</h2>
                <span className="bg-amber-400 text-slate-900 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                  GOLD VIP
                </span>
              </div>
              <p className="text-[11px] text-orange-100">seworamart@gmail.com</p>
            </div>
          </div>

          <button 
            onClick={() => alert('Settings opened')}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Wallet & Rewards Strip */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/20 text-center text-white">
          <button onClick={onOpenVouchers} className="cursor-pointer hover:opacity-80">
            <div className="text-xs font-black tabular-nums">Rs. 2,450</div>
            <div className="text-[10px] text-orange-100 mt-0.5">Sewora Pay</div>
          </button>
          <button onClick={onOpenVouchers} className="border-x border-white/20 cursor-pointer hover:opacity-80">
            <div className="text-xs font-black tabular-nums flex items-center justify-center gap-1">
              <Coins className="w-3 h-3 text-amber-300" />
              <span>480</span>
            </div>
            <div className="text-[10px] text-orange-100 mt-0.5">Coins</div>
          </button>
          <button onClick={onOpenVouchers} className="cursor-pointer hover:opacity-80">
            <div className="text-xs font-black tabular-nums">4</div>
            <div className="text-[10px] text-orange-100 mt-0.5">Vouchers</div>
          </button>
        </div>
      </div>

      <div className="p-3 space-y-3">
        {/* 1. My Orders Status Buckets (Daraz-inspired) */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-900">My Orders</h3>
            <button
              onClick={onOpenOrders}
              className="text-[11px] font-semibold text-[#FF6600] flex items-center hover:underline"
            >
              <span>View All ({orders.length + 3})</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-1 text-center pt-3">
            <button onClick={onOpenOrders} className="flex flex-col items-center cursor-pointer group">
              <div className="relative p-2 rounded-xl bg-orange-50 text-[#FF6600] group-hover:scale-105 transition-transform">
                <CreditCard className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-[#FF6600] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  1
                </span>
              </div>
              <span className="text-[10px] font-medium text-slate-600 mt-1.5">To Pay</span>
            </button>

            <button onClick={onOpenOrders} className="flex flex-col items-center cursor-pointer group">
              <div className="relative p-2 rounded-xl bg-blue-50 text-blue-600 group-hover:scale-105 transition-transform">
                <Package className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  2
                </span>
              </div>
              <span className="text-[10px] font-medium text-slate-600 mt-1.5">To Ship</span>
            </button>

            <button onClick={onOpenOrders} className="flex flex-col items-center cursor-pointer group">
              <div className="relative p-2 rounded-xl bg-purple-50 text-purple-600 group-hover:scale-105 transition-transform">
                <Truck className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-purple-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  1
                </span>
              </div>
              <span className="text-[10px] font-medium text-slate-600 mt-1.5">To Receive</span>
            </button>

            <button onClick={onOpenOrders} className="flex flex-col items-center cursor-pointer group">
              <div className="relative p-2 rounded-xl bg-amber-50 text-amber-600 group-hover:scale-105 transition-transform">
                <Star className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-medium text-slate-600 mt-1.5">To Review</span>
            </button>
          </div>
        </div>

        {/* 2. Account Features & Shortcuts */}
        <div className="bg-white rounded-2xl divide-y divide-slate-100 border border-slate-200 shadow-2xs overflow-hidden">
          {onOpenExport && (
            <button
              onClick={onOpenExport}
              className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-semibold text-slate-700 bg-orange-50/60 hover:bg-orange-100/60 transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <Download className="w-4 h-4 text-[#FF6600]" />
                <span className="font-bold text-slate-900">Export Project ZIP & Android APK</span>
              </div>
              <span className="bg-[#FF6600] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                Download
              </span>
            </button>
          )}

          <button
            onClick={onOpenWishlist}
            className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Heart className="w-4 h-4 text-rose-500" />
              <span>My Wishlist & Saved Items</span>
            </div>
            <span className="text-slate-400 text-[11px]">8 items</span>
          </button>

          <button
            onClick={onOpenVouchers}
            className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Ticket className="w-4 h-4 text-amber-500" />
              <span>Voucher Wallet & Coupons</span>
            </div>
            <span className="text-emerald-600 font-bold text-[11px]">2 New</span>
          </button>

          <button
            onClick={() => alert('Delivery Addresses list opened')}
            className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <UserCheck className="w-4 h-4 text-blue-500" />
              <span>Address Book & Defaults</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-300" />
          </button>

          {onOpenWhatsAppSupport && (
            <button
              onClick={onOpenWhatsAppSupport}
              className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-bold text-emerald-800 bg-emerald-50/70 hover:bg-emerald-100/70 transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 fill-[#25D366] text-[#25D366]" />
                <span>WhatsApp Order Support (24/7)</span>
              </div>
              <span className="text-[10px] bg-[#25D366] text-white px-2 py-0.5 rounded-full font-bold">
                Online
              </span>
            </button>
          )}

          <button
            onClick={() => alert('Help Center & FAQs opened')}
            className="w-full px-3.5 py-3 flex items-center justify-between text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <span>Customer Care & FAQs</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-300" />
          </button>
        </div>

        {/* 3. Buyer Protection Notice */}
        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-3 flex items-center gap-2.5 text-xs text-slate-700">
          <ShieldCheck className="w-6 h-6 text-[#FF6600] shrink-0" />
          <div>
            <div className="font-bold text-slate-900">Sewora Buyer Protection Guarantee</div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Get full refund if item is not as described or not delivered within promised timeline.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
