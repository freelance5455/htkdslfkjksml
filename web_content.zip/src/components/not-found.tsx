import { Link } from "@tanstack/react-router";

export function NotFound() {
  return (
    <main id="content" className="mx-auto flex min-h-[60vh] max-w-3xl flex-col items-start justify-center px-4 py-16">
      <p className="text-sm text-olive">الصفحة غير موجودة</p>
      <h1 className="mt-2 font-display text-4xl text-primary">لم نعثر على هذا المسار</h1>
      <p className="mt-4 leading-relaxed text-muted">
        قد يكون الرابط ناقصًا أو أن المحتوى لم يُضف. يمكن العودة إلى الرئيسية أو البحث في الأسماء والآيات.
      </p>
      <div className="mt-6 flex flex-wrap gap-3">
        <Link to="/" className="rounded-full bg-primary px-5 py-3 text-primary-fg">
          الرئيسية
        </Link>
        <Link to="/search" search={{ q: "" }} className="rounded-full border border-line px-5 py-3">
          البحث
        </Link>
      </div>
    </main>
  );
}
