import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { Star, Coins, ArrowRight, RotateCcw, Home, Trophy } from 'lucide-react';
import { Language } from '../types';
import { getTranslations } from '../services/i18n';
import { BannerAd } from './BannerAd';

interface WinModalProps {
  levelNumber: number;
  stars: number;
  moves: number;
  bestMoves: number;
  timeSeconds: number;
  maxCombo: number;
  coinsEarned: number;
  language?: Language;
  onNextLevel: () => void;
  onReplay: () => void;
  onHome: () => void;
}

export const WinModal: React.FC<WinModalProps> = ({
  levelNumber,
  stars,
  moves,
  coinsEarned,
  language = 'en',
  onNextLevel,
  onReplay,
  onHome,
}) => {
  const t = getTranslations(language);

  // Fire celebratory confetti on mount
  useEffect(() => {
    try {
      confetti({
        particleCount: 75,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#38bdf8', '#facc15', '#f43f5e', '#a855f7'],
      });
    } catch (e) {
      // Ignore
    }
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.8, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-100 dark:border-slate-700 p-6 pb-0 flex flex-col items-center text-center overflow-hidden relative"
      >
        {/* Soft top gradient accent */}
        <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-400 via-sky-400 to-emerald-400" />

        <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 flex items-center justify-center text-amber-500 mb-2 shadow-inner">
          <Trophy className="w-8 h-8 fill-amber-400" />
        </div>

        <h3 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight">
          {t.levelComplete}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t.levelMastered.replace('{0}', String(levelNumber))}
        </p>

        {/* 3-Star Rating Row with animated pop-ins */}
        <div className="flex items-center gap-3 my-3">
          {[1, 2, 3].map((starIndex) => (
            <motion.div
              key={starIndex}
              initial={{ scale: 0, rotate: -30 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15 * starIndex, type: 'spring' }}
              className="relative"
            >
              <Star
                className={`w-9 h-9 ${
                  starIndex <= stars
                    ? 'text-amber-400 fill-amber-400 drop-shadow-[0_4px_10px_rgba(251,191,36,0.5)]'
                    : 'text-slate-300 dark:text-slate-600'
                }`}
              />
            </motion.div>
          ))}
        </div>

        {/* Coins Reward & Moves Stat Row */}
        <div className="w-full grid grid-cols-2 gap-2.5 my-2">
          {/* Coins Earned */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 flex flex-col items-center justify-center shadow-sm"
          >
            <div className="flex items-center gap-1.5 mb-0.5">
              <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wide">
                {t.coinsEarned}
              </span>
            </div>
            <strong className="text-base font-black text-amber-900 dark:text-amber-200">
              +{coinsEarned}
            </strong>
          </motion.div>

          {/* Moves Taken */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.45 }}
            className="p-2.5 rounded-2xl bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 flex flex-col items-center justify-center shadow-sm"
          >
            <span className="text-[10px] font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide mb-0.5">
              {t.moves}
            </span>
            <strong className="text-base font-black text-sky-950 dark:text-sky-200">
              {moves}
            </strong>
          </motion.div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2 mt-2 mb-4">
          {/* Next Level */}
          <button
            id="btn-win-next"
            type="button"
            onClick={onNextLevel}
            className="w-full h-12 py-3 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-black text-sm shadow-lg shadow-sky-500/30 flex items-center justify-center gap-2 active:scale-98 transition tracking-wide"
          >
            <span>{t.nextLevel}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Replay & Home Buttons */}
          <div className="flex items-center gap-2">
            <button
              id="btn-win-replay"
              type="button"
              onClick={onReplay}
              className="flex-1 h-10 rounded-xl bg-slate-100 dark:bg-slate-700/70 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-98 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.replay}</span>
            </button>
            <button
              id="btn-win-home"
              type="button"
              onClick={onHome}
              className="flex-1 h-10 rounded-xl bg-slate-100 dark:bg-slate-700/70 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-98 transition"
            >
              <Home className="w-3.5 h-3.5" />
              <span>{t.home}</span>
            </button>
          </div>
        </div>

        {/* Banner Ad docked at bottom of Level Complete Screen */}
        <div className="w-full -mx-6 overflow-hidden rounded-b-3xl">
          <BannerAd />
        </div>
      </motion.div>
    </div>
  );
};
