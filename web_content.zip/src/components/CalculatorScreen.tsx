import React, { useState, useEffect } from "react";
import { CategoryItem, CalculationResult } from "../types";
import { computeEstimate, formatINR, formatNumber, generateBOQ } from "../utils/calculator";
import {
  ArrowLeft,
  Calculator,
  RotateCcw,
  Sparkles,
  Info,
  Check,
  AlertCircle,
  Layers,
  ShieldCheck,
  Package,
  Phone,
  MessageCircle,
} from "lucide-react";

interface CalculatorScreenProps {
  categories: CategoryItem[];
  rates: Record<string, number | null>;
  selectedCategoryId: string;
  onBack: () => void;
  onCalculateComplete: (result: CalculationResult) => void;
  onOpenRates: () => void;
}

export const CalculatorScreen: React.FC<CalculatorScreenProps> = ({
  categories,
  rates,
  selectedCategoryId,
  onBack,
  onCalculateComplete,
  onOpenRates,
}) => {
  const [currentCategoryId, setCurrentCategoryId] = useState<string>(
    selectedCategoryId || categories[0]?.id || "gypsum_ceiling"
  );
  const [lengthStr, setLengthStr] = useState<string>("10");
  const [widthStr, setWidthStr] = useState<string>("10");
  const [includeLabour, setIncludeLabour] = useState<boolean>(true);
  const [labourRateStr, setLabourRateStr] = useState<string>("20");
  const [includeBuffer, setIncludeBuffer] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Update category when prop changes
  useEffect(() => {
    if (selectedCategoryId) {
      setCurrentCategoryId(selectedCategoryId);
      const cat = categories.find((c) => c.id === selectedCategoryId);
      if (cat?.defaultLabourRate) {
        setLabourRateStr(String(cat.defaultLabourRate));
      }
    }
  }, [selectedCategoryId, categories]);

  const activeCategory =
    categories.find((c) => c.id === currentCategoryId) || categories[0];
  const activeRate = rates[activeCategory?.id] ?? activeCategory?.defaultRate;
  const isRateConfigured = activeRate !== null && activeRate !== undefined;

  // When user switches category, adapt default labour rate
  const handleCategoryChange = (catId: string) => {
    setCurrentCategoryId(catId);
    setErrorMessage(null);
    const cat = categories.find((c) => c.id === catId);
    if (cat?.defaultLabourRate) {
      setLabourRateStr(String(cat.defaultLabourRate));
    }
  };

  // Numeric values
  const lengthNum = parseFloat(lengthStr);
  const widthNum = parseFloat(widthStr);
  const labourRateNum = parseFloat(labourRateStr) || 0;

  const isValidInput =
    !isNaN(lengthNum) &&
    lengthNum > 0 &&
    !isNaN(widthNum) &&
    widthNum > 0;

  const currentArea = isValidInput ? Number((lengthNum * widthNum).toFixed(2)) : 0;

  // Compute live estimate preview
  const liveEstimate = isValidInput
    ? computeEstimate(
        lengthNum,
        widthNum,
        activeCategory,
        activeRate,
        includeLabour,
        labourRateNum,
        includeBuffer,
        5
      )
    : null;

  // Common room preset dimensions
  const presetDimensions = [
    { label: "10 × 10", l: "10", w: "10" },
    { label: "12 × 10", l: "12", w: "10" },
    { label: "12 × 14", l: "12", w: "14" },
    { label: "14 × 16", l: "14", w: "16" },
    { label: "15 × 20", l: "15", w: "20" },
  ];

  const handleCalculate = () => {
    if (!lengthStr.trim() || !widthStr.trim()) {
      setErrorMessage("Please enter length and width.");
      return;
    }

    if (isNaN(lengthNum) || isNaN(widthNum) || lengthNum <= 0 || widthNum <= 0) {
      setErrorMessage("Please enter a valid measurement.");
      return;
    }

    setErrorMessage(null);

    const result = computeEstimate(
      lengthNum,
      widthNum,
      activeCategory,
      activeRate,
      includeLabour,
      labourRateNum,
      includeBuffer,
      5
    );

    onCalculateComplete(result);
  };

  const handleReset = () => {
    setLengthStr("");
    setWidthStr("");
    setIncludeLabour(true);
    setIncludeBuffer(false);
    if (activeCategory?.defaultLabourRate) {
      setLabourRateStr(String(activeCategory.defaultLabourRate));
    }
    setErrorMessage(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Bar with Back */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-2 rounded-xl active:scale-95 transition-all shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
          Ceiling & Interior Calculator
        </h2>

        <button
          onClick={handleReset}
          className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-800 px-3 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 transition-colors shadow-sm"
          title="Reset Inputs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Main Calculation Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xl space-y-6">
        {/* Step 1: Work Category Selection */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
              1. Select Type of Work
            </label>
            <button
              type="button"
              onClick={onOpenRates}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-700 underline"
            >
              Rate Settings
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {categories.map((cat) => {
              const rate = rates[cat.id] ?? cat.defaultRate;
              const isSelected = cat.id === currentCategoryId;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleCategoryChange(cat.id)}
                  className={`flex flex-col items-center justify-between p-3 rounded-2xl transition-all text-left ${
                    isSelected
                      ? "border-2 border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-sm"
                      : "border border-slate-200 hover:border-indigo-300 bg-white text-slate-700 hover:bg-slate-50/60"
                  }`}
                >
                  <div className="w-full text-center">
                    <span className="text-xs font-bold line-clamp-1">
                      {cat.name}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {cat.hindiName}
                    </span>
                  </div>

                  <div className="mt-2 text-center">
                    <span className={`text-base font-black ${isSelected ? "text-indigo-600" : "text-slate-900"}`}>
                      {rate !== null ? `₹${rate}` : "—"}
                    </span>
                    <span className="text-[9px] text-slate-400 block font-medium">
                      {cat.hasDetailedBOQ ? "Detailed BOQ" : rate !== null ? "per sq ft" : "Unset"}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Category Info Banner */}
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div>
            <span className="text-slate-500 font-medium">Selected Work: </span>
            <strong className="text-slate-900 font-bold text-sm ml-1">{activeCategory?.name}</strong>
            <span className="text-slate-500 block text-[11px] mt-0.5">{activeCategory?.hindiName} • {activeCategory?.description}</span>
          </div>
          <div className="text-left sm:text-right shrink-0">
            <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">
              Rate Standard
            </span>
            <span className="text-xs font-extrabold text-indigo-600">
              {activeCategory?.rateNote || (isRateConfigured ? `₹${activeRate} / sq ft` : "Rate not configured")}
            </span>
          </div>
        </div>

        {/* Step 2: Room Dimensions */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
              2. Room Dimensions (Feet)
            </label>
            <span className="text-[11px] text-slate-400 font-mono">Length × Width</span>
          </div>

          {/* Quick presets */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-[11px] text-slate-400 font-medium shrink-0">Presets:</span>
            {presetDimensions.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => {
                  setLengthStr(preset.l);
                  setWidthStr(preset.w);
                  setErrorMessage(null);
                }}
                className={`px-3 py-1.5 text-xs rounded-xl border font-semibold whitespace-nowrap transition-colors ${
                  lengthStr === preset.l && widthStr === preset.w
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200"
                }`}
              >
                {preset.label} ft
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Length Input */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">
                Length (ft)
              </label>
              <input
                type="number"
                inputMode="decimal"
                min="0"
                step="0.1"
                placeholder="10"
                value={lengthStr}
                onChange={(e) => {
                  setLengthStr(e.target.value);
                  setErrorMessage(null);
                }}
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xl font-bold text-slate-900"
              />
            </div>

            {/* Width Input */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">
                Width (ft)
              </label>
              <input
                type="number"
                inputMode="decimal"
                min="0"
                step="0.1"
                placeholder="10"
                value={widthStr}
                onChange={(e) => {
                  setWidthStr(e.target.value);
                  setErrorMessage(null);
                }}
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xl font-bold text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Labour & Buffer Controls */}
        <div className="pt-3 border-t border-slate-100 space-y-4">
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
            3. Labour & Cost Adjustments
          </label>

          {/* Labour Toggle */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 block">
                  Include Labour Calculation?
                </span>
                <span className="text-[11px] text-slate-500">
                  {activeCategory.id === "wallpaper"
                    ? "Wallpaper installation charge per Roll"
                    : "Contractor installation rate per sq ft"}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeLabour}
                  onChange={(e) => setIncludeLabour(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            {includeLabour && (
              <div className="pt-2 border-t border-slate-200/60 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">
                    Labour Rate ({activeCategory.id === "wallpaper" ? "₹ per Roll" : "₹ per sq ft"})
                  </label>
                  <span className="text-[11px] text-indigo-600 font-semibold">
                    Standard: ₹{activeCategory.defaultLabourRate ?? 20} / {activeCategory.labourUnit || "sq ft"}
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    inputMode="decimal"
                    min="0"
                    placeholder={String(activeCategory.defaultLabourRate ?? 20)}
                    value={labourRateStr}
                    onChange={(e) => setLabourRateStr(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">
                    ₹ / {activeCategory.labourUnit || "sq ft"}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Buffer / Wastage Toggle (Default Off) */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-800 block">
                Add 5% Material Buffer / Wastage?
              </span>
              <span className="text-[11px] text-slate-500">
                Covers on-site cutting wastage (0% by default, shown separately)
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={includeBuffer}
                onChange={(e) => setIncludeBuffer(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        </div>

        {/* Error message banner */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Live Calculation Preview Card - Geometric Balance Style */}
        {liveEstimate && (
          <div className="bg-slate-900 rounded-3xl p-5 sm:p-6 text-white shadow-xl space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-slate-400 text-xs uppercase tracking-wider font-semibold">Total Area</div>
                <div className="text-3xl font-black tracking-tight mt-0.5 font-mono text-white">
                  {formatNumber(currentArea)}{" "}
                  <span className="text-base font-normal text-slate-400">sq ft</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-slate-400 text-xs uppercase tracking-wider font-semibold">Grand Total</div>
                <div className="text-2xl sm:text-3xl font-black text-indigo-400 font-mono mt-0.5">
                  {formatINR(liveEstimate.grandTotal)}
                </div>
              </div>
            </div>

            {/* Quick Summary Lines */}
            <div className="border-t border-slate-800 pt-3 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-indigo-400" />
                  Material Total ({liveEstimate.boqItems.length} items)
                </span>
                <span className="font-bold text-white font-mono text-sm">
                  {formatINR(liveEstimate.materialTotal)}
                </span>
              </div>

              {liveEstimate.bufferEnabled && (
                <div className="flex justify-between items-center text-amber-400">
                  <span>+ Material Buffer (5%)</span>
                  <span className="font-bold font-mono">
                    {formatINR(liveEstimate.bufferAmount)}
                  </span>
                </div>
              )}

              {liveEstimate.includeLabour && (
                <div className="flex justify-between items-center text-emerald-400">
                  <span>
                    + Labour Total ({formatNumber(liveEstimate.labourQuantity)} {liveEstimate.labourUnit} @ ₹{liveEstimate.labourRate})
                  </span>
                  <span className="font-bold font-mono text-sm">
                    {formatINR(liveEstimate.labourTotal)}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* View Complete Detailed BOQ & Result Button */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
          <button
            onClick={handleReset}
            id="reset-calc-btn"
            className="sm:col-span-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 text-sm transition-all active:scale-[0.98] border border-slate-200"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESET</span>
          </button>
          <button
            onClick={handleCalculate}
            id="calculate-estimate-btn"
            className="sm:col-span-3 bg-indigo-600 text-white font-extrabold py-4 rounded-2xl shadow-lg shadow-indigo-600/25 hover:bg-indigo-700 active:bg-indigo-800 flex items-center justify-center gap-2 text-base tracking-wide uppercase transition-all active:scale-[0.98]"
          >
            <Calculator className="w-5 h-5 stroke-[2.5]" />
            <span>CALCULATE COST</span>
          </button>
        </div>

        {/* Clean Contact Strip (Non-interfering) */}
        <div className="mt-4 pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-medium block">For Enquiry & Work Contact</span>
              <a href="tel:9068926728" className="font-extrabold text-slate-900 hover:text-indigo-600 text-sm font-mono">
                📞 9068926728
              </a>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href="tel:9068926728"
              className="flex-1 sm:flex-initial bg-slate-900 hover:bg-slate-800 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>CALL NOW</span>
            </a>
            <a
              href="https://wa.me/919068926728?text=Hello!%20I%20need%20ceiling%20and%20interior%20work%20enquiry."
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white text-white" />
              <span>WHATSAPP</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

