import React from 'react';
import { MessageCircle, CheckCircle2, Sparkles, MapPin, ShieldCheck } from 'lucide-react';
import { DJ_SERVICES, ServiceItem } from '../data/djData';

interface ServicesProps {
  onSelectServiceForBooking: (serviceId: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectServiceForBooking }) => {
  const getWhatsAppServiceLink = (svc: ServiceItem) => {
    const text = encodeURIComponent(
      `Hello DJ EVAN PRO UG THE CUE KING! I want to book the *${svc.name}* package (${svc.displayPrice} UGX - ${svc.duration}). My event is in Kyebando/Kampala. Please let me know if your date is available.`
    );
    return `https://wa.me/256742094651?text=${text}`;
  };

  return (
    <section id="services" className="py-12 px-4 max-w-5xl mx-auto">
      {/* Section Header */}
      <div className="mb-6">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-widest bg-cyan-950/60 px-3 py-1 rounded-full border border-cyan-800/40 mb-2">
          <MapPin className="w-3.5 h-3.5 text-rose-400" />
          Kyebando Base · Serving All Kampala, Wakiso &amp; Mukono
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          <span>🎧 DJ BOOKING — Kyebando Base, All Kampala</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Real transparent prices. Zero agency markups. Arrives 2 hours before start time with clean sound.
        </p>
      </div>

      {/* Grid of the 4 Real Priced Services */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {DJ_SERVICES.map((svc) => {
          let priceColor = 'text-cyan-400';
          if (svc.id === 'kwanjula') priceColor = 'text-pink-400';
          if (svc.id === 'wedding') priceColor = 'text-purple-400';

          return (
            <div
              key={svc.id}
              className={`bg-zinc-900 p-5 rounded-2xl border transition-all flex flex-col justify-between hover:border-purple-500/60 shadow-lg ${
                svc.popular ? 'border-zinc-700 bg-zinc-900/90' : 'border-zinc-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <h3 className="font-bold text-base text-white">{svc.name}</h3>
                  {svc.popular && (
                    <span className="text-[9px] font-black uppercase bg-purple-600/60 text-purple-200 px-1.5 py-0.5 rounded">
                      Popular
                    </span>
                  )}
                </div>

                <p className={`font-black text-2xl font-mono ${priceColor} my-1`}>
                  {svc.displayPrice} UGX
                </p>

                <p className="text-[11px] text-zinc-400 font-semibold mb-3">
                  {svc.duration}
                </p>

                <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                  {svc.tagline}
                </p>

                <div className="space-y-1.5 mb-5 border-t border-zinc-800 pt-3">
                  {svc.features.slice(0, 3).map((feat, i) => (
                    <div key={i} className="flex items-start gap-1.5 text-[11px] text-zinc-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <a
                  href={getWhatsAppServiceLink(svc)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider text-center block transition-all shadow-md active:scale-95"
                >
                  Book on WhatsApp
                </a>

                <button
                  onClick={() => onSelectServiceForBooking(svc.id)}
                  className="w-full py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-[11px] font-semibold transition-colors"
                >
                  Customize Booking &darr;
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Punctuality and Transport Assurance */}
      <div className="mt-4 p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-300">
        <span className="flex items-center gap-1.5 font-bold text-white">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Location Guarantee: Based in Kyebando, Kawempe
        </span>
        <span className="text-slate-400 text-[11px]">
          Fast transport across Bwaise, Kalerwe, Mulago, Kamwokya, Ntinda, Kira, Munyonyo &amp; Entebbe!
        </span>
      </div>
    </section>
  );
};
