import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Table, 
  History, 
  Search, 
  Filter, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  Eye, 
  ChevronLeft, 
  ChevronRight, 
  FileSpreadsheet, 
  FileCode, 
  FileCheck,
  Zap,
  Building2,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { ImsiLedgerTransaction, ImsiWalletBalances } from '../lib/imsiEngine';
import { generateSignedPdfLedger } from '../lib/pdfLedgerGenerator';
import { exportAccountingCsv } from '../lib/csvLedgerExporter';

interface DetailedTransactionLogTableProps {
  ledger: ImsiLedgerTransaction[];
  wallet: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
}

export const DetailedTransactionLogTable: React.FC<DetailedTransactionLogTableProps> = ({
  ledger,
  wallet,
  onShowToast
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [assetFilter, setAssetFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [selectedTxDetail, setSelectedTxDetail] = useState<ImsiLedgerTransaction | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isExportingCsv, setIsExportingCsv] = useState<boolean>(false);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    onShowToast?.(`✓ Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Filtered & Sorted Ledger List
  const processedTransactions = useMemo(() => {
    return ledger.filter((tx) => {
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesQuery = 
          tx.id.toLowerCase().includes(q) ||
          tx.txHash.toLowerCase().includes(q) ||
          tx.bankRef.toLowerCase().includes(q) ||
          tx.senderPhone.toLowerCase().includes(q) ||
          tx.carrier.toLowerCase().includes(q) ||
          tx.payoutDestination.toLowerCase().includes(q);

        if (!matchesQuery) return false;
      }

      // Asset Filter
      if (assetFilter === 'BITCOIN' && tx.convertedBtcSats <= 0) return false;
      if (assetFilter === 'CASH' && tx.convertedCashNgn <= 0) return false;
      if (assetFilter === 'SMS_CHARGE' && !tx.carrier.toLowerCase().includes('mtn') && !tx.carrier.toLowerCase().includes('imsi')) return false;
      if (assetFilter === 'CONVERTO' && !tx.payoutDestination.toLowerCase().includes('converto') && !tx.payoutDestination.toLowerCase().includes('altar')) return false;

      // Status Filter
      if (statusFilter !== 'ALL' && tx.status !== statusFilter) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'date_desc') return b.id.localeCompare(a.id);
      if (sortBy === 'date_asc') return a.id.localeCompare(b.id);
      if (sortBy === 'amount_desc') {
        const valA = a.convertedCashNgn + (a.convertedBtcSats * 0.95);
        const valB = b.convertedCashNgn + (b.convertedBtcSats * 0.95);
        return valB - valA;
      }
      if (sortBy === 'amount_asc') {
        const valA = a.convertedCashNgn + (a.convertedBtcSats * 0.95);
        const valB = b.convertedCashNgn + (b.convertedBtcSats * 0.95);
        return valA - valB;
      }
      return 0;
    });
  }, [ledger, searchQuery, assetFilter, statusFilter, sortBy]);

  // Pagination calculation
  const totalPages = Math.ceil(processedTransactions.length / rowsPerPage) || 1;
  const paginatedTransactions = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return processedTransactions.slice(start, start + rowsPerPage);
  }, [processedTransactions, currentPage, rowsPerPage]);

  // Export JSON
  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(processedTransactions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `juhnkrix-ledger-export-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    onShowToast?.(`✓ Exported ${processedTransactions.length} transaction records to JSON!`);
  };

  // Export CSV
  const handleExportCsv = () => {
    try {
      setIsExportingCsv(true);
      const res = exportAccountingCsv({
        wallet,
        ledger: processedTransactions,
        ownerName: 'PROPHET JUHNKRIX SYNVAGORD',
        companyName: 'JUHNKRIX MUSIKA SOVEREIGN TREASURY',
        subdomain: 'juhnkrixmusika.pages.dev',
        phone: '07071918280'
      });
      onShowToast?.(`✓ Exported ${res.rowCount} transactions to CSV (${res.fileName})!`);
    } catch (e: any) {
      onShowToast?.(`❌ Export failed: ${e.message}`);
    } finally {
      setIsExportingCsv(false);
    }
  };

  // Export PDF
  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      onShowToast?.('📄 Compiling cryptographically signed transaction ledger PDF...');
      const { blob, fileName } = await generateSignedPdfLedger({
        wallet,
        ledger: processedTransactions,
        ownerName: 'PROPHET JUHNKRIX SYNVAGORD',
        phoneNumber: '07071918280',
        subdomain: 'juhnkrixmusika.pages.dev'
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onShowToast?.('✓ Signed PDF Ledger saved successfully!');
    } catch (e: any) {
      onShowToast?.(`❌ PDF generation failed: ${e.message}`);
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
      {/* Header with Search & Filter Tooling */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black uppercase tracking-wider">
            <Table className="w-4 h-4 text-amber-400" />
            <span>HISTORICAL CRYPTO & CASH TRANSACTION LEDGER</span>
          </div>
          <h2 className="text-2xl font-black font-serif text-slate-100 tracking-tight">
            Detailed Cross-Chain Transaction Logs
          </h2>
          <p className="text-xs text-slate-400">
            Immutable cryptographic records of all Bitcoin mining shares, CONVERTO swaps, IMSI SMS charges, and instant NIBSS banking settlements.
          </p>
        </div>

        {/* Export Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCsv}
            disabled={isExportingCsv}
            className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>CSV EXPORT</span>
          </button>

          <button
            onClick={handleExportJson}
            className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>JSON EXPORT</span>
          </button>

          <button
            onClick={handleExportPdf}
            disabled={isExportingPdf}
            className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>SIGNED PDF</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Search Field */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search TxHash, phone, ref, bank..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Asset Category Filter */}
        <div>
          <select
            value={assetFilter}
            onChange={(e) => {
              setAssetFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-400"
          >
            <option value="ALL">All Asset Types (Crypto & Cash)</option>
            <option value="BITCOIN">Bitcoin (BTC / Sats)</option>
            <option value="CASH">Cash Treasury (₦ NGN)</option>
            <option value="SMS_CHARGE">IMSI SMS Deductions</option>
            <option value="CONVERTO">CONVERTO Swaps</option>
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-bold focus:outline-none focus:border-amber-400"
          >
            <option value="ALL">All Statuses</option>
            <option value="CONFIRMED_ON_CHAIN">Confirmed On-Chain</option>
            <option value="BANK_SETTLED">Bank Settled (NIBSS)</option>
            <option value="PENDING_MEMPOOL">Pending Mempool</option>
          </select>
        </div>

        {/* Sort Dropdown */}
        <div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-bold focus:outline-none focus:border-amber-400"
          >
            <option value="date_desc">Sort: Newest First</option>
            <option value="date_asc">Sort: Oldest First</option>
            <option value="amount_desc">Sort: Highest Valuation</option>
            <option value="amount_asc">Sort: Lowest Valuation</option>
          </select>
        </div>
      </div>

      {/* Main Table Responsive Container */}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60 scrollbar-thin">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-extrabold text-[10px]">
              <th className="py-3.5 px-4">Timestamp & ID</th>
              <th className="py-3.5 px-4">Asset & Flow</th>
              <th className="py-3.5 px-4">Sender / Origin</th>
              <th className="py-3.5 px-4">Amount & Valuation</th>
              <th className="py-3.5 px-4">Proof & TxHash</th>
              <th className="py-3.5 px-4">Status</th>
              <th className="py-3.5 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {paginatedTransactions.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400 space-y-2">
                  <History className="w-8 h-8 mx-auto text-amber-400/40" />
                  <p className="text-xs">No transaction records found matching your filters.</p>
                </td>
              </tr>
            ) : (
              paginatedTransactions.map((tx) => {
                const hasBtc = tx.convertedBtcSats > 0;
                const hasCash = tx.convertedCashNgn > 0;

                return (
                  <tr key={tx.id} className="hover:bg-slate-900/90 transition-colors">
                    {/* Timestamp & ID */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-mono text-slate-200 font-bold">{tx.timestamp}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{tx.id}</div>
                    </td>

                    {/* Asset & Flow */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                          hasBtc 
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}>
                          {hasBtc ? '₿' : '₦'}
                        </div>
                        <div>
                          <div className="font-bold text-slate-200 text-xs">
                            {hasBtc ? 'Bitcoin Sats' : 'Cash Treasury'}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {tx.payoutDestination.includes('Swap') ? 'Conversion' : 'Inflow Settlement'}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Sender / Origin */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-bold text-slate-100">{tx.senderPhone}</div>
                      <div className="text-[10px] text-slate-400 flex items-center space-x-1">
                        <span>{tx.carrier}</span>
                      </div>
                    </td>

                    {/* Amount & Valuation */}
                    <td className="py-3.5 px-4 whitespace-nowrap font-mono">
                      {hasCash && (
                        <div className="text-emerald-400 font-bold text-xs">
                          +₦{tx.convertedCashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })} NGN
                        </div>
                      )}
                      {hasBtc && (
                        <div className="text-amber-300 font-bold text-xs">
                          +{tx.convertedBtcSats.toLocaleString()} Sats ({tx.convertedBtcFormatted})
                        </div>
                      )}
                    </td>

                    {/* Proof & TxHash */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="flex items-center space-x-1.5 font-mono text-[11px]">
                        <span className="text-amber-400/90 truncate max-w-[120px]">{tx.txHash}</span>
                        <button
                          onClick={() => handleCopy(tx.txHash, `TxHash-${tx.id}`)}
                          className="text-slate-400 hover:text-amber-300 p-1"
                          title="Copy TxHash"
                        >
                          {copiedKey === `TxHash-${tx.id}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Ref: {tx.bankRef}
                      </div>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase inline-flex items-center space-x-1 ${
                        tx.status === 'CONFIRMED_ON_CHAIN'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{tx.status.replace(/_/g, ' ')}</span>
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-right">
                      <button
                        onClick={() => setSelectedTxDetail(tx)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-700 text-[11px] font-bold inline-flex items-center space-x-1 transition-all"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <span>Showing {paginatedTransactions.length} of {processedTransactions.length} records</span>
          <span>•</span>
          <span>Rows per page:</span>
          <select
            value={rowsPerPage}
            onChange={(e) => {
              setRowsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-slate-200 text-xs"
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 disabled:opacity-40 text-slate-300 hover:text-amber-300"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="font-bold text-slate-200 font-mono">
            Page {currentPage} of {totalPages}
          </span>
          <button
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 disabled:opacity-40 text-slate-300 hover:text-amber-300"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Transaction Detail Inspector Modal */}
      <AnimatePresence>
        {selectedTxDetail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-lg font-black text-slate-100 font-serif">
                    Cryptographic Transaction Inspector
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedTxDetail(null)}
                  className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-slate-100 flex items-center justify-center text-sm font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>Transaction ID:</span>
                    <span className="text-amber-300 font-bold">{selectedTxDetail.id}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Timestamp:</span>
                    <span className="text-slate-200">{selectedTxDetail.timestamp}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Carrier Network:</span>
                    <span className="text-blue-300 font-bold">{selectedTxDetail.carrier}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Sender Endpoint:</span>
                    <span className="text-slate-200">{selectedTxDetail.senderPhone}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Cash Settlement:</span>
                    <span className="text-emerald-400 font-bold">₦{selectedTxDetail.convertedCashNgn.toLocaleString()} NGN</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Bitcoin Holding:</span>
                    <span className="text-amber-300 font-bold">{selectedTxDetail.convertedBtcFormatted} ({selectedTxDetail.convertedBtcSats} Sats)</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Destination Vault:</span>
                    <span className="text-slate-200 truncate max-w-[200px]">{selectedTxDetail.payoutDestination}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-400">Blockchain SHA-256 TxHash:</label>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-amber-300 break-all select-all flex items-center justify-between">
                    <span>{selectedTxDetail.txHash}</span>
                    <button
                      onClick={() => handleCopy(selectedTxDetail.txHash, 'Inspector TxHash')}
                      className="ml-2 p-1 text-slate-400 hover:text-amber-300"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-400">NIBSS Bank Reference Number:</label>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-emerald-300 break-all select-all">
                    {selectedTxDetail.bankRef}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => setSelectedTxDetail(null)}
                  className="px-5 py-2.5 bg-amber-500 text-slate-950 font-black text-xs rounded-xl hover:bg-amber-400 transition-all"
                >
                  CLOSE INSPECTOR
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
