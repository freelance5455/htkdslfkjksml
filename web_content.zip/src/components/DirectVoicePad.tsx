import React, { useState } from 'react';
import { 
  Mic, 
  Sparkles, 
  Volume2, 
  Zap, 
  User, 
  Monitor, 
  Youtube, 
  Clock, 
  Smile, 
  Flashlight, 
  FileText, 
  Headphones, 
  Radio,
  Share2
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface DirectVoicePadProps {
  language: SupportedLanguage;
  onExecuteCommand: (commandText: string) => void;
  isListening: boolean;
  handsFreeActive: boolean;
  onToggleHandsFree: () => void;
}

export const DirectVoicePad: React.FC<DirectVoicePadProps> = ({
  language,
  onExecuteCommand,
  isListening,
  handsFreeActive,
  onToggleHandsFree,
}) => {
  const [directInput, setDirectInput] = useState('');

  const quickCommands = language === 'bn'
    ? [
        { label: 'কে তৈরি করেছে তোমাকে?', query: 'তোমাকে কে তৈরি করেছে?', icon: <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> },
        { label: 'আমার নাম কী?', query: 'আমার নাম কি?', icon: <User className="w-3.5 h-3.5 text-fuchsia-400" /> },
        { label: 'স্ক্রিনের সবকিছু দেখো', query: 'আমার বর্তমান স্ক্রিনের সবকিছু স্ক্যান করে বিস্তারিত বিশ্লেষণ করো।', icon: <Monitor className="w-3.5 h-3.5 text-emerald-400" /> },
        { label: 'সময় ও ব্যাটারি কত?', query: 'বর্তমান সময় এবং ব্যাটারি লেভেল কত?', icon: <Clock className="w-3.5 h-3.5 text-amber-400" /> },
        { label: 'একটি কৌতুক বলো', query: 'বস-কে একটি মজার টেক জোক শোনাও।', icon: <Smile className="w-3.5 h-3.5 text-pink-400" /> },
        { label: 'টর্চ অন/অফ করো', query: 'টর্চ ফ্ল্যাশলাইট অন করো', icon: <Flashlight className="w-3.5 h-3.5 text-amber-300" /> },
        { label: 'ফেসবুকে পোস্ট করো', query: 'ফেসবুকে পোস্ট করার জন্য সুন্দর একটি টেক স্ট্যাটাস লিখে দাও', icon: <Share2 className="w-3.5 h-3.5 text-blue-400" /> },
        { label: 'টিকটক ওপেন করো', query: 'টিকটক ওপেন করে ট্রেন্ডিং ভিডিও দেখাও', icon: <Share2 className="w-3.5 h-3.5 text-cyan-400" /> },
        { label: 'সিস্টেম স্ট্যাটাস চেক', query: 'সিস্টেমের বর্তমান স্ট্যাটাস ও কার্যক্ষমতা কেমন?', icon: <Radio className="w-3.5 h-3.5 text-cyan-300" /> },
      ]
    : [
        { label: 'Who created you?', query: 'Who created you?', icon: <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> },
        { label: 'What is my name?', query: 'What is my name?', icon: <User className="w-3.5 h-3.5 text-fuchsia-400" /> },
        { label: 'Scan my screen', query: 'Scan and analyze everything on my screen right now.', icon: <Monitor className="w-3.5 h-3.5 text-emerald-400" /> },
        { label: 'Post to Facebook', query: 'Write a powerful post for Facebook', icon: <Share2 className="w-3.5 h-3.5 text-blue-400" /> },
        { label: 'Search YouTube', query: 'Search YouTube for sci-fi tech', icon: <Youtube className="w-3.5 h-3.5 text-red-400" /> },
        { label: 'Open TikTok', query: 'Open TikTok trending content', icon: <Share2 className="w-3.5 h-3.5 text-cyan-400" /> },
        { label: 'Time & Battery', query: 'What is the current time and battery level?', icon: <Clock className="w-3.5 h-3.5 text-amber-400" /> },
        { label: 'Toggle Torch', query: 'Toggle the system flashlight.', icon: <Flashlight className="w-3.5 h-3.5 text-amber-300" /> },
      ];

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!directInput.trim()) return;
    onExecuteCommand(directInput.trim());
    setDirectInput('');
  };

  return (
    <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-500/30 p-4 sm:p-5 shadow-xl space-y-4">
      {/* Header with Hands-Free Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-900/40 pb-3">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" />
          <span className="font-orbitron font-bold text-xs sm:text-sm text-cyan-300 tracking-wide">
            {language === 'bn' ? 'ডাইরেক্ট ভয়েস ও কমান্ড প্যাড' : 'DIRECT VOICE & COMMAND PAD'}
          </span>
          <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-500/40">
            {language === 'bn' ? 'মাইক ছাড়াও ভয়েস দিন' : 'NO MIC PLUG REQUIRED'}
          </span>
        </div>

        {/* Continuous Hands-Free Switch */}
        <button
          onClick={onToggleHandsFree}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-mono-tech transition-all border ${
            handsFreeActive
              ? 'bg-gradient-to-r from-fuchsia-900 to-cyan-900 border-cyan-400 text-white font-bold shadow-md shadow-cyan-500/30 animate-pulse'
              : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Headphones className="w-3.5 h-3.5 text-fuchsia-400" />
          <span>
            {handsFreeActive
              ? language === 'bn' ? 'অটো-লিসেনিং: সক্রিয়' : 'Hands-Free: ACTIVE'
              : language === 'bn' ? 'অটো-লিসেনিং চালু করুন' : 'Enable Hands-Free'}
          </span>
        </button>
      </div>

      {/* Direct Voice Command Buttons Grid */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-mono-tech text-slate-400">
          {language === 'bn' ? 'এক ক্লিকেই ডাইরেক্ট ভয়েস প্রশ্ন করুন:' : 'One-tap direct voice commands:'}
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {quickCommands.map((item, idx) => (
            <button
              key={idx}
              onClick={() => onExecuteCommand(item.query)}
              className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-400/70 text-xs text-left text-slate-200 transition-all flex items-center gap-2 shadow-sm group hover:scale-[1.02]"
            >
              <div className="p-1 rounded bg-slate-900 group-hover:bg-cyan-950 shrink-0">
                {item.icon}
              </div>
              <span className="truncate font-semibold">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Direct Custom Command Input */}
      <form onSubmit={handleCustomSubmit} className="flex items-center gap-2 pt-1">
        <input
          type="text"
          value={directInput}
          onChange={(e) => setDirectInput(e.target.value)}
          placeholder={
            language === 'bn'
              ? 'মাইক্রোফোন ছাড়া সরাসরি ভয়েস কমান্ড লিখুন বা বলুন...'
              : 'Type direct voice command without microphone...'
          }
          className="flex-1 bg-slate-950 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-cyan-900/50 focus:outline-none focus:border-cyan-400 font-sans"
        />
        <button
          type="submit"
          disabled={!directInput.trim()}
          className={`px-4 py-2.5 rounded-xl font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-1.5 shrink-0 ${
            directInput.trim()
              ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5" />
          <span>VOICE RUN</span>
        </button>
      </form>
    </div>
  );
};
