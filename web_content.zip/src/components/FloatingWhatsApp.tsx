import React from 'react';
import { MessageCircle, Phone, ChevronUp } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappDirectUrl =
    'https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20want%20to%20book%20you%20in%20Kyebando%20Kampala';

  return (
    <>
      {/* Desktop & Tablet Floating WhatsApp Bubble */}
      <div className="fixed bottom-6 right-6 z-50 hidden sm:flex flex-col items-end gap-3 pointer-events-auto">
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-300 hover:text-white flex items-center justify-center shadow-lg transition-transform active:scale-90"
            title="Scroll to top"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}

        {/* Floating WhatsApp Card */}
        <a
          href={whatsappDirectUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center gap-3 bg-green-500 hover:bg-green-400 text-white pl-4 pr-5 py-3.5 rounded-full shadow-[0_0_35px_rgba(34,197,94,0.6)] border border-green-300/40 transition-all hover:scale-105 active:scale-95"
        >
          <div className="relative flex items-center justify-center">
            <MessageCircle className="w-7 h-7 fill-white" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
            </span>
          </div>

          <div className="text-left">
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-green-100 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              Kyebando Base · Online
            </div>
            <div className="text-sm font-black tracking-tight leading-none mt-0.5">
              WhatsApp 0742094651
            </div>
            <div className="text-[10px] text-green-100 font-mono">Instant Reply 24/7</div>
          </div>
        </a>
      </div>

      {/* Mobile-First Sticky Bottom Action Bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-t border-zinc-800 p-2.5 flex items-center gap-2">
        <a
          href="tel:+256742094651"
          className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-full bg-zinc-900 border border-zinc-700 text-white font-bold text-xs active:scale-95 transition-transform"
        >
          <Phone className="w-4 h-4 text-cyan-400" />
          <span>Call 0742094651</span>
        </a>

        <a
          href={whatsappDirectUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-2 flex items-center justify-center gap-2 py-3 rounded-full bg-green-500 hover:bg-green-400 text-white font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(34,197,94,0.5)] active:scale-95 transition-transform"
        >
          <MessageCircle className="w-4 h-4 fill-white" />
          <span>WhatsApp 0742094651</span>
        </a>
      </div>
    </>
  );
};
