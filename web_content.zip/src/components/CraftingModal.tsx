import React, { useState } from 'react';
import { GameEngine } from '../game/engine';
import { CRAFTING_RECIPES, ITEMS } from '../game/items';
import { HotbarItemIcon } from './HUD';
import { X, Flame, Hammer, Shield, Home, Sparkles } from 'lucide-react';

interface CraftingModalProps {
  engine: GameEngine;
  onClose: () => void;
}

export const CraftingModal: React.FC<CraftingModalProps> = ({ engine, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const isNearCampfire = engine.isNearCampfire(engine.player.x, engine.player.y, 75);

  const filteredRecipes = CRAFTING_RECIPES.filter((r) => {
    if (selectedCategory === 'all') return true;
    return r.category === selectedCategory;
  });

  const getItemCountInInventory = (itemId: string) => {
    let sum = 0;
    for (const slot of engine.inventory) {
      if (slot && slot.item === itemId) {
        sum += slot.count;
      }
    }
    return sum;
  };

  const handleCraft = (recipeId: string) => {
    engine.craftItem(recipeId);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-2xl bg-neutral-900 border-2 border-cyan-600/80 rounded-2xl shadow-2xl p-4 sm:p-6 text-white flex flex-col gap-4 max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-700 pb-3">
          <div className="flex items-center gap-2">
            <Hammer className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base sm:text-lg font-bold text-cyan-300">طاولة الصناعة والابتكار</h2>
          </div>
          <button
            id="btn-close-crafting"
            onClick={onClose}
            className="p-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Campfire Status Banner */}
        <div
          className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs border ${
            isNearCampfire
              ? 'bg-amber-950/40 border-amber-600/60 text-amber-300'
              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400'
          }`}
        >
          <div className="flex items-center gap-2">
            <Flame className={`w-4 h-4 ${isNearCampfire ? 'text-amber-400 animate-pulse' : 'text-neutral-500'}`} />
            <span>
              {isNearCampfire
                ? 'موقد النار نشط وقريب — يمكنك طهي الأطعمة والمأكولات المشوية!'
                : 'أنت لست بالقرب من موقد نار (تحتاجه فقط لطهي الطعام)'}
            </span>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'الكل', icon: Sparkles },
            { id: 'tools', label: 'الأدوات والأسلحة', icon: Hammer },
            { id: 'survival', label: 'أدوات النجاة', icon: Shield },
            { id: 'building', label: 'عناصر البناء', icon: Home },
            { id: 'food', label: 'الطبخ والمؤن', icon: Flame },
          ].map((cat) => {
            const Icon = cat.icon;
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border whitespace-nowrap transition cursor-pointer font-bold ${
                  active
                    ? 'bg-cyan-900/80 border-cyan-400 text-cyan-200'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:border-neutral-500'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Recipe Cards List */}
        <div className="flex flex-col gap-2.5 overflow-y-auto pr-1 max-h-[50vh]">
          {filteredRecipes.map((recipe) => {
            const canCraft = engine.canCraft(recipe.id);
            const outputDef = ITEMS[recipe.output];

            return (
              <div
                key={recipe.id}
                className={`bg-neutral-950/80 border rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 transition ${
                  canCraft ? 'border-neutral-700 hover:border-cyan-500/80' : 'border-neutral-800/80 opacity-75'
                }`}
              >
                {/* Left: Recipe Info */}
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="w-12 h-12 bg-neutral-850 rounded-lg border border-neutral-700 flex items-center justify-center shrink-0">
                    <HotbarItemIcon itemId={recipe.output} />
                  </div>
                  <div className="flex flex-col text-right">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{recipe.nameAr}</span>
                      {recipe.outputCount > 1 && (
                        <span className="text-[10px] font-mono bg-cyan-950 border border-cyan-700 px-1.5 py-0.5 rounded text-cyan-300">
                          +{recipe.outputCount}
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-neutral-400">{outputDef.descriptionAr}</span>
                  </div>
                </div>

                {/* Right: Requirements & Craft Button */}
                <div className="flex flex-wrap items-center justify-end gap-3 w-full sm:w-auto">
                  <div className="flex items-center gap-1.5">
                    {recipe.requirements.map((req, rIdx) => {
                      const userHave = getItemCountInInventory(req.item);
                      const hasEnough = userHave >= req.count;
                      const reqDef = ITEMS[req.item];

                      return (
                        <div
                          key={rIdx}
                          className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded border font-mono ${
                            hasEnough
                              ? 'bg-emerald-950/50 border-emerald-700/60 text-emerald-300'
                              : 'bg-red-950/40 border-red-800/60 text-red-400'
                          }`}
                        >
                          <span className="text-xs">{reqDef.nameAr}:</span>
                          <span>
                            {userHave}/{req.count}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  <button
                    id={`btn-craft-${recipe.id}`}
                    onClick={() => handleCraft(recipe.id)}
                    disabled={!canCraft}
                    className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow ${
                      canCraft
                        ? 'bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white cursor-pointer'
                        : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                    }`}
                  >
                    <Hammer className="w-3.5 h-3.5" />
                    <span>صناعة</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
