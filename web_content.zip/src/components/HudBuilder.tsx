import React, { useState } from 'react';
import { 
  Smartphone, 
  Hand, 
  Layers, 
  Sparkles, 
  Info, 
  Shield, 
  Crosshair, 
  Flame, 
  ArrowUp, 
  ChevronDown, 
  Target, 
  Repeat, 
  Zap, 
  Navigation
} from 'lucide-react';
import { HUD_PRESETS } from '../data/freeFireData';
import { HudPreset, HudButtonConfig } from '../types';
import { sounds } from '../utils/soundEffects';

export const HudBuilder: React.FC = () => {
  const [activePreset, setActivePreset] = useState<HudPreset>(HUD_PRESETS[1]); // 3-finger default
  const [selectedButton, setSelectedButton] = useState<HudButtonConfig>(HUD_PRESETS[1].buttons[0]);

  const selectPreset = (preset: HudPreset) => {
    sounds.playClick();
    setActivePreset(preset);
    setSelectedButton(preset.buttons[0]);
  };

  const handleButtonClick = (btn: HudButtonConfig) => {
    sounds.playClick();
    setSelectedButton(btn);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'crosshair': return <Crosshair className="w-4 h-4" />;
      case 'flame': return <Flame className="w-4 h-4" />;
      case 'shield': return <Shield className="w-4 h-4" />;
      case 'arrow-up': return <ArrowUp className="w-4 h-4" />;
      case 'chevron-down': return <ChevronDown className="w-4 h-4" />;
      case 'target': return <Target className="w-4 h-4" />;
      case 'repeat': return <Repeat className="w-4 h-4" />;
      case 'zap': return <Zap className="w-4 h-4" />;
      case 'navigation': return <Navigation className="w-4 h-4" />;
      default: return <Crosshair className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* HUD Header Overview */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-rajdhani">
                CUSTOM HUD ARCHITECTURE
              </span>
              <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> 0.1s Reaction Layouts
              </span>
            </div>
            <h2 className="text-2xl font-bold font-heading text-white">
              Claw Control & HUD Placement Lab
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Preview and configure championship claw button mappings. Click on any button below to see exact finger distribution, opacity recommendations, and sit-up gloo wall execution.
            </p>
          </div>

          {/* Finger Presets Switcher */}
          <div className="flex items-center gap-2 bg-[#090b14] p-1.5 rounded-xl border border-slate-700">
            {HUD_PRESETS.map((preset) => {
              const isActive = activePreset.id === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => selectPreset(preset)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {preset.fingers}-Finger Claw
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main HUD Interactive Screen & Button Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive Phone Screen Mockup (8 cols) */}
        <div className="lg:col-span-8 bg-[#090b14] border-2 border-slate-700/80 rounded-3xl p-4 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[380px] sm:min-h-[460px]">
          {/* Top Notch & Camera Bezel */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-b-xl border-x border-b border-slate-700 flex items-center justify-center gap-2">
            <div className="w-2 h-2 rounded-full bg-slate-800 border border-slate-600"></div>
            <div className="w-8 h-1 rounded-full bg-slate-800"></div>
          </div>

          {/* Background Battlefield Grid Overlay */}
          <div className="absolute inset-0 pointer-events-none opacity-20">
            <div className="w-full h-full bg-[radial-gradient(#f97316_1px,transparent_1px)] [background-size:24px_24px]"></div>
          </div>

          {/* Center Crosshair Reference */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-40 flex items-center justify-center">
            <div className="w-10 h-10 rounded-full border border-orange-400/50 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
            </div>
          </div>

          {/* Interactive Screen Buttons */}
          <div className="relative w-full h-full flex-1">
            {activePreset.buttons.map((btn) => {
              const isSelected = selectedButton?.id === btn.id;
              return (
                <button
                  key={btn.id}
                  onClick={() => handleButtonClick(btn)}
                  style={{
                    left: `${btn.x}%`,
                    top: `${btn.y}%`,
                    width: `${btn.size * 0.9}px`,
                    height: `${btn.size * 0.9}px`,
                    transform: 'translate(-50%, -50%)',
                    opacity: btn.opacity,
                    borderColor: btn.color,
                    backgroundColor: `${btn.color}25`,
                  }}
                  className={`absolute rounded-full border-2 flex flex-col items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-110 active:scale-95 shadow-lg ${
                    isSelected ? 'ring-4 ring-white ring-offset-2 ring-offset-black scale-110 z-20' : 'z-10'
                  }`}
                  title={`${btn.name} (${btn.finger})`}
                >
                  <div style={{ color: btn.color }}>
                    {getIcon(btn.iconType)}
                  </div>
                  <span className="text-[8px] font-bold text-white uppercase font-rajdhani tracking-tighter mt-0.5 truncate max-w-[45px]">
                    {btn.name.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Bottom HUD Metadata */}
          <div className="relative z-10 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-bold text-white">{activePreset.name}</span>
            </div>
            <div className="text-[11px] font-mono text-amber-300">
              Finger Allocation: {activePreset.fingers} Active Digits
            </div>
          </div>
        </div>

        {/* Selected Button Details & Claw Mechanics (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Button Details Inspector */}
          {selectedButton && (
            <div className="bg-[#101423] border border-orange-500/40 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div 
                    style={{ backgroundColor: `${selectedButton.color}30`, borderColor: selectedButton.color }} 
                    className="p-2.5 rounded-xl border"
                  >
                    {getIcon(selectedButton.iconType)}
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-white text-base">
                      {selectedButton.name}
                    </h3>
                    <span className="text-xs text-orange-400 font-bold font-rajdhani">
                      {selectedButton.finger}
                    </span>
                  </div>
                </div>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Recommended Size</span>
                  <span className="text-base font-bold font-mono text-white">{selectedButton.size}%</span>
                </div>
                <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Display Opacity</span>
                  <span className="text-base font-bold font-mono text-amber-400">{Math.round(selectedButton.opacity * 100)}%</span>
                </div>
                <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Screen X Coords</span>
                  <span className="text-base font-bold font-mono text-cyan-400">{selectedButton.x}%</span>
                </div>
                <div className="bg-[#090b14] p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Screen Y Coords</span>
                  <span className="text-base font-bold font-mono text-cyan-400">{selectedButton.y}%</span>
                </div>
              </div>

              {/* Tactical Advice for this button */}
              <div className="text-xs text-slate-300 bg-[#151a2d] p-3 rounded-xl border border-slate-700 space-y-1">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-orange-400" />
                  Pro Placement Advice:
                </div>
                {selectedButton.id === 'gloo' && (
                  <p className="text-[11px] text-slate-300">
                    Keep close to Left Index or Left Thumb. Never overlap with the weapon switch button to avoid accidentally equipping a medkit instead of gloo under pressure.
                  </p>
                )}
                {selectedButton.id === 'fire' && (
                  <p className="text-[11px] text-slate-300">
                    Position in lower right half. Ensure at least 35% empty vertical space above it for the upward drag path to reach helmet level without thumb running off the screen.
                  </p>
                )}
                {selectedButton.id === 'left-fire' && (
                  <p className="text-[11px] text-slate-300">
                    Set in Free Fire settings: 'Left Fire Button: ALWAYS ON'. Used for the fastest 360 sit-up gloo wall deployment while right thumb rotates the view.
                  </p>
                )}
                {selectedButton.id === 'crouch' && (
                  <p className="text-[11px] text-slate-300">
                    Placing crouch near the right fire button enables the famous 3-finger crouch-shot and instant headshot dodge.
                  </p>
                )}
                {!['gloo', 'fire', 'left-fire', 'crouch'].includes(selectedButton.id) && (
                  <p className="text-[11px] text-slate-300">
                    Tune opacity to 60-80% so enemy movements across the screen remain visible even behind HUD icons.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Pro Sit-Up Gloo Wall Sequence Card */}
          <div className="bg-[#101423] border border-slate-800 rounded-2xl p-4 text-xs space-y-2.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold font-heading">
              <Shield className="w-4 h-4" />
              <span>0.1s Fast Sit-Up Gloo Wall Sequence</span>
            </div>
            <ol className="text-slate-300 space-y-1.5 list-decimal list-inside text-[11px]">
              <li><strong className="text-white">Shoot:</strong> Drag Right Fire button up to headshot</li>
              <li><strong className="text-amber-400">Pull Down:</strong> Drag camera down instantly to your feet</li>
              <li><strong className="text-cyan-400">Gloo Wall:</strong> Tap Gloo icon with Left Hand</li>
              <li><strong className="text-yellow-400">Crouch:</strong> Tap Crouch button (Sit-up posture)</li>
              <li><strong className="text-red-400">Left Fire:</strong> Tap Left Fire button to drop wall</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
