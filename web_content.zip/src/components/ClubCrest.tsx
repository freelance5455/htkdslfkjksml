import React from 'react';
import { Club } from '../types/game';

interface ClubCrestProps {
  club: Pick<Club, 'abbr' | 'primaryColor' | 'secondaryColor' | 'pattern' | 'icon'>;
  size?: number;
  className?: string;
}

export const ClubCrest: React.FC<ClubCrestProps> = ({ club, size = 48, className = '' }) => {
  const uid = React.useId().replace(/:/g, '');
  const clipId = `crest-clip-${uid}`;

  const renderPattern = () => {
    switch (club.pattern) {
      case 'stripes':
        return (
          <>
            <rect x="0" y="0" width="100" height="110" fill={club.primaryColor} />
            <rect x="16" y="0" width="14" height="110" fill={club.secondaryColor} />
            <rect x="43" y="0" width="14" height="110" fill={club.secondaryColor} />
            <rect x="70" y="0" width="14" height="110" fill={club.secondaryColor} />
          </>
        );
      case 'halves':
        return (
          <>
            <rect x="0" y="0" width="50" height="110" fill={club.primaryColor} />
            <rect x="50" y="0" width="50" height="110" fill={club.secondaryColor} />
          </>
        );
      case 'sash':
        return (
          <>
            <rect x="0" y="0" width="100" height="110" fill={club.primaryColor} />
            <polygon points="-10,95 95,-10 115,10 10,115" fill={club.secondaryColor} />
          </>
        );
      case 'cross':
        return (
          <>
            <rect x="0" y="0" width="100" height="110" fill={club.secondaryColor} />
            <rect x="0" y="38" width="100" height="26" fill={club.primaryColor} />
            <rect x="38" y="0" width="24" height="110" fill={club.primaryColor} />
          </>
        );
      case 'chevron':
        return (
          <>
            <rect x="0" y="0" width="100" height="110" fill={club.primaryColor} />
            <polygon points="0,30 50,62 100,30 100,52 50,84 0,52" fill={club.secondaryColor} />
          </>
        );
      case 'solid':
      default:
        return (
          <>
            <rect x="0" y="0" width="100" height="110" fill={club.primaryColor} />
            <circle cx="50" cy="48" r="28" fill="none" stroke={club.secondaryColor} strokeWidth="4" opacity="0.35" />
          </>
        );
    }
  };

  const renderIcon = () => {
    const strokeCol = '#FFFFFF';
    switch (club.icon) {
      case 'crown':
        return (
          <path
            d="M32 34 L38 20 L50 29 L62 20 L68 34 Z"
            fill="#F5C451"
            stroke="#0F172A"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        );
      case 'star':
        return (
          <polygon
            points="50,15 54,25 65,25 56,31 59,41 50,35 41,41 44,31 35,25 46,25"
            fill="#F5C451"
            stroke="#0F172A"
            strokeWidth="1.5"
          />
        );
      case 'flame':
        return (
          <path
            d="M50 15 C56 24 62 29 58 37 C56 41 53 43 50 43 C45 43 42 38 43 32 C44 26 48 21 50 15 Z"
            fill="#F5C451"
            stroke="#0F172A"
            strokeWidth="1.8"
          />
        );
      case 'eagle':
        return (
          <path
            d="M30 25 L45 29 L50 20 L55 29 L70 25 L59 37 L50 42 L41 37 Z"
            fill="#F5C451"
            stroke="#0F172A"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
        );
      case 'anchor':
        return (
          <path
            d="M50 18 V38 M42 23 H58 M39 33 C39 40 61 40 61 33"
            fill="none"
            stroke={strokeCol}
            strokeWidth="3.2"
            strokeLinecap="round"
          />
        );
      case 'shield':
      default:
        return (
          <path
            d="M50 18 L61 23 V32 C61 38 55 42 50 44 C45 42 39 38 39 32 V23 Z"
            fill="#F5C451"
            stroke="#0F172A"
            strokeWidth="1.8"
          />
        );
    }
  };

  return (
    <svg
      width={size}
      height={size * 1.1}
      viewBox="0 0 100 110"
      className={`shrink-0 drop-shadow-md ${className}`}
      aria-label={club.abbr}
    >
      <defs>
        <clipPath id={clipId}>
          <path d="M12 10 L50 4 L88 10 V54 C88 80 68 97 50 105 C32 97 12 80 12 54 Z" />
        </clipPath>
      </defs>

      <g clipPath={`url(#${clipId})`}>
        {renderPattern()}
        <rect x="0" y="54" width="100" height="28" fill="rgba(7, 11, 20, 0.86)" />
        {renderIcon()}
        <text
          x="50"
          y="74"
          textAnchor="middle"
          fill="#F8FAFC"
          fontSize="19"
          fontWeight="800"
          fontFamily="Barlow Condensed, sans-serif"
          letterSpacing="1.5"
        >
          {club.abbr}
        </text>
      </g>

      <path
        d="M12 10 L50 4 L88 10 V54 C88 80 68 97 50 105 C32 97 12 80 12 54 Z"
        fill="none"
        stroke="#F5C451"
        strokeWidth="3.2"
      />
    </svg>
  );
};
