import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  X,
  Camera,
  RefreshCw,
  Hand,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Eye,
  Radio,
} from 'lucide-react';
import { CameraState, ScannerStep } from '../types';

interface PalmScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  cameraState: CameraState;
  onCameraStateChange: (state: CameraState) => void;
  onSendFrame: (base64Jpeg: string, force?: boolean) => boolean;
  onStartAnalysis: (capturedImage: string) => void;
}

const SCANNER_STEPS: ScannerStep[] = [
  {
    id: 1,
    title: 'Show the full palm',
    hindiTitle: 'पूरी हथेली कैमरे के सामने लाएं',
    description: 'Keep your open palm facing directly towards the camera lens.',
    hint: 'हथेली को सीधा और कैमरे के बीच में रखें',
    tip: 'Make sure your fingers are naturally spread out.',
  },
  {
    id: 2,
    title: 'Keep hand steady',
    hindiTitle: 'हाथ को स्थिर रखें',
    description: 'Hold your hand still for 2-3 seconds for crystal clear focus.',
    hint: 'हाथ हिलाएं नहीं ताकि रेखाएं साफ़ दिखें',
    tip: 'Avoid shaking or moving too quickly.',
  },
  {
    id: 3,
    title: 'Check lighting & contrast',
    hindiTitle: 'अच्छी रोशनी में दिखाएं',
    description: 'Ensure natural light falls directly onto your palm without heavy shadows.',
    hint: 'छाया से बचें, पर्याप्त रोशनी रखें',
    tip: 'Turn on room light or flash if it is dark.',
  },
  {
    id: 4,
    title: 'Heart & Head line focus',
    hindiTitle: 'हृदय और मस्तिष्क रेखा पर ध्यान',
    description: 'Bring the upper half of your palm slightly closer to highlight major lines.',
    hint: 'हथेली के ऊपरी हिस्से को थोड़ा पास लाएं',
    tip: 'Heart line reflects empathy; Head line reflects intellectual clarity.',
  },
  {
    id: 5,
    title: 'Life line & Venus mount',
    hindiTitle: 'जीवन रेखा और शुक्र पर्वत',
    description: 'Tilt your palm slightly so the curved life line around the thumb is visible.',
    hint: 'अंगूठे के पास की जीवन रेखा साफ़ दिखाएं',
    tip: 'The base of the thumb signifies energy, warmth, and vitality.',
  },
  {
    id: 6,
    title: 'Finger & Mounts alignment',
    hindiTitle: 'उंगलियों और पर्वतों की स्थिति',
    description: 'Straighten your fingers upward so planetary mounts can be inspected.',
    hint: 'उंगलियों को सीधा ऊपर की ओर रखें',
    tip: 'Mounts under fingers indicate leadership, intuition, and discipline.',
  },
  {
    id: 7,
    title: 'Full palm reading synthesis',
    hindiTitle: 'संपूर्ण हस्तरेखा का अंतिम स्कैन',
    description: 'Ready! Tap Capture to synthesize your traditional palm reading.',
    hint: 'अब कैप्चर दबाकर अपनी हस्तरेखा का फल जानें',
    tip: 'AI.P is ready to interpret your unique palm features.',
  },
];

export const PalmScannerModal: React.FC<PalmScannerModalProps> = ({
  isOpen,
  onClose,
  cameraState,
  onCameraStateChange,
  onSendFrame,
  onStartAnalysis,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const frameTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [framesSentCount, setFramesSentCount] = useState<number>(0);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);

  const currentStep = SCANNER_STEPS[currentStepIndex];

  // Helper to capture an optimized low-latency JPEG frame from the active video feed
  const captureFrame = useCallback(
    (maxDimension: number = 512, quality: number = 0.65): string | null => {
      if (!videoRef.current || !canvasRef.current) return null;
      const video = videoRef.current;
      if (video.readyState < 2 || video.videoWidth === 0 || video.videoHeight === 0) {
        return null;
      }

      const canvas = canvasRef.current;
      let width = video.videoWidth;
      let height = video.videoHeight;

      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      ctx.drawImage(video, 0, 0, width, height);
      return canvas.toDataURL('image/jpeg', quality);
    },
    []
  );

  // Stop camera tracks cleanly
  const stopCamera = useCallback(() => {
    if (frameTimerRef.current) {
      clearInterval(frameTimerRef.current);
      frameTimerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    onCameraStateChange('CAMERA_OFF');
  }, [onCameraStateChange]);

  // Request REAL camera access via getUserMedia
  const startCamera = useCallback(async () => {
    stopCamera();
    setErrorMessage(null);
    onCameraStateChange('CAMERA_REQUESTING_PERMISSION');

    try {
      // First attempt with preferred facingMode
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
      } catch {
        // Fallback to generic video if environment camera is not accessible (e.g. desktop)
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }

      onCameraStateChange('CAMERA_ACTIVE');

      // Start periodic frame capture pipeline (~1 frame per 850ms)
      frameTimerRef.current = setInterval(() => {
        const frameData = captureFrame(0.6, 0.7);
        if (frameData) {
          const sent = onSendFrame(frameData);
          if (sent) {
            setFramesSentCount((prev) => prev + 1);
          }
        }
      }, 850);

      // Immediately send initial frame
      setTimeout(() => {
        const initialFrame = captureFrame(0.7, 0.75);
        if (initialFrame) {
          onSendFrame(initialFrame, true);
        }
      }, 300);
    } catch (err: unknown) {
      console.error('Real Camera access error:', err);
      let errorText = 'Unable to access camera.';
      if (err instanceof DOMException) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          errorText = 'Camera permission was denied. Please allow camera access in your browser settings.';
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          errorText = 'No camera found on this device.';
        } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
          errorText = 'Camera is currently in use by another application.';
        }
      }
      setErrorMessage(errorText);
      onCameraStateChange('CAMERA_ERROR');
    }
  }, [captureFrame, facingMode, onCameraStateChange, onSendFrame, stopCamera]);

  // Start or stop camera when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, startCamera, stopCamera]);

  // Flip camera between front & back
  const handleToggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Immediate frame dispatch when step changes
  const handleNextStep = () => {
    if (currentStepIndex < SCANNER_STEPS.length - 1) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      // Immediately send fresh frame for this step
      setTimeout(() => {
        const frame = captureFrame(0.75, 0.8);
        if (frame) {
          onSendFrame(frame, true);
        }
      }, 100);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  // Take high quality capture for palm analysis
  const handleCaptureSnapshot = async () => {
    if (cameraState !== 'CAMERA_ACTIVE') return;
    setIsCapturing(true);

    try {
      // Capture high-fidelity frame for reading
      const highResFrame = captureFrame(1.0, 0.85);
      if (highResFrame) {
        onStartAnalysis(highResFrame);
      } else {
        setErrorMessage('Could not capture frame. Please ensure camera is clearly visible.');
      }
    } finally {
      setIsCapturing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black text-white select-none overflow-hidden animate-fade-in">
      {/* Hidden processing canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Top Header / Nav */}
      <div className="relative z-30 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md text-white transition active:scale-95"
          title="Close Scanner"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Live Vision Transmission Badge */}
        <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-black/60 border border-purple-500/40 backdrop-blur-md text-xs">
          <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
          <span className="text-purple-300 font-medium">AI.P Live Vision</span>
          <span className="text-[10px] text-slate-400">({framesSentCount} frames)</span>
        </div>

        {/* Flip Camera */}
        <button
          onClick={handleToggleFacingMode}
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md text-white transition active:scale-95"
          title="Flip Camera"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {/* Viewfinder Area (REAL CAMERA) */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-[#05070f]">
        {/* Real Live Video */}
        <video
          ref={videoRef}
          playsInline
          autoPlay
          muted
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            cameraState === 'CAMERA_ACTIVE' ? 'opacity-100' : 'opacity-0'
          }`}
        />

        {/* Permission Requesting State */}
        {cameraState === 'CAMERA_REQUESTING_PERMISSION' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 bg-black/80">
            <div className="w-16 h-16 rounded-full border-4 border-purple-500 border-t-transparent animate-spin mb-4" />
            <h3 className="text-lg font-semibold text-white">Opening Camera...</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Please grant camera permission in your browser prompt to activate palm scanner.
            </p>
          </div>
        )}

        {/* Camera Error State */}
        {cameraState === 'CAMERA_ERROR' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 bg-black/90">
            <AlertTriangle className="w-12 h-12 text-amber-400 mb-3" />
            <h3 className="text-lg font-semibold text-white">Camera Access Error</h3>
            <p className="text-xs text-slate-300 mt-2 max-w-xs leading-relaxed">
              {errorMessage || 'Camera could not be accessed. Please check permissions.'}
            </p>
            <button
              onClick={startCamera}
              className="mt-5 px-5 py-2.5 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-medium text-xs shadow-lg active:scale-95"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Corner Reticle Brackets [ ] overlay (Screen 2 from screenshot) */}
        {cameraState === 'CAMERA_ACTIVE' && (
          <div className="absolute inset-6 sm:inset-12 pointer-events-none flex flex-col justify-between">
            <div className="flex justify-between">
              <div className="w-10 h-10 border-t-4 border-l-4 border-white/90 rounded-tl-2xl shadow-[0_0_10px_rgba(255,255,255,0.4)]" />
              <div className="w-10 h-10 border-t-4 border-r-4 border-white/90 rounded-tr-2xl shadow-[0_0_10px_rgba(255,255,255,0.4)]" />
            </div>

            {/* Scanning Laser Beam */}
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="absolute w-full h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#06b6d4] animate-scan-line pointer-events-none" />

              {/* Hand Outline Guide */}
              <div className="w-48 h-64 border border-dashed border-cyan-400/40 rounded-[40px] flex items-center justify-center opacity-40">
                <Hand className="w-20 h-20 text-cyan-300 stroke-1 opacity-60" />
              </div>
            </div>

            <div className="flex justify-between">
              <div className="w-10 h-10 border-b-4 border-l-4 border-white/90 rounded-bl-2xl shadow-[0_0_10px_rgba(255,255,255,0.4)]" />
              <div className="w-10 h-10 border-b-4 border-r-4 border-white/90 rounded-br-2xl shadow-[0_0_10px_rgba(255,255,255,0.4)]" />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Step Guide & Controls Card (Matching Screen 2 from Screenshot) */}
      <div className="relative z-30 w-full bg-[#0a0d1a]/95 backdrop-blur-xl border-t border-purple-500/20 px-5 pt-4 pb-6 rounded-t-3xl shadow-2xl">
        {/* Step progress dots */}
        <div className="flex items-center justify-center space-x-1.5 mb-3">
          {SCANNER_STEPS.map((s, idx) => (
            <div
              key={s.id}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentStepIndex
                  ? 'w-6 bg-gradient-to-r from-purple-400 to-cyan-400'
                  : idx < currentStepIndex
                  ? 'w-2 bg-purple-500/70'
                  : 'w-2 bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Current Step Instruction */}
        <div className="flex items-start space-x-3 mb-3">
          <div className="p-2 rounded-xl bg-purple-600/20 border border-purple-500/30 text-purple-300 shrink-0 mt-0.5">
            <Hand className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white tracking-wide">
                {currentStep.title}
              </h3>
              <span className="text-xs font-bold text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded-md border border-purple-800/50">
                {currentStep.id} / 7
              </span>
            </div>
            <p className="text-xs text-purple-200/90 font-medium mt-0.5">
              {currentStep.hindiTitle}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">{currentStep.tip}</p>
          </div>
        </div>

        {/* Checklist item (Screen 2: "Show full palm", "Keep hand steady", etc.) */}
        <div className="space-y-1.5 bg-black/40 rounded-xl p-3 border border-white/5 mb-4 text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Show the full palm clearly in the frame</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Hold steady; AI inspects live video frames</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Speak or ask AI Partner anytime: "मेरा हाथ दिख रहा है?"</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          {currentStepIndex > 0 && (
            <button
              onClick={handlePrevStep}
              className="p-3 rounded-2xl glass-panel text-slate-300 hover:text-white transition active:scale-95"
              title="Previous Step"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {/* Primary Action Button */}
          <button
            onClick={handleCaptureSnapshot}
            disabled={cameraState !== 'CAMERA_ACTIVE' || isCapturing}
            className={`flex-1 py-3 px-4 rounded-2xl font-bold text-sm flex items-center justify-center space-x-2 shadow-xl transition-all duration-300 active:scale-95 ${
              cameraState === 'CAMERA_ACTIVE'
                ? 'bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 text-white shadow-purple-500/25 hover:shadow-purple-500/40'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {isCapturing ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Camera className="w-4 h-4" />
                <span>Capture & Analyze Palm</span>
              </>
            )}
          </button>

          {currentStepIndex < SCANNER_STEPS.length - 1 && (
            <button
              onClick={handleNextStep}
              className="p-3 rounded-2xl glass-panel text-purple-300 hover:text-white hover:border-purple-500/50 transition active:scale-95"
              title="Next Step"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
