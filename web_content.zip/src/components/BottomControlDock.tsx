import React, { useState } from 'react';
import {
  Car,
  Palette,
  MapPin,
  Users,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Sliders,
  Globe,
  Cpu,
  Award,
  RotateCcw,
  Trophy,
  Flag,
  Flame,
  Gauge,
  Zap,
  Compass,
  Wrench,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import {
  AeroPreset,
  AUTOMATED_LEVELS,
  CareerStats,
  FinishType,
  HYPERCARS,
  LiveTelemetry,
  NetworkMode,
  PAINT_SWATCHES,
  RaceParticipant,
  RIM_SWATCHES,
  VehicleCustomization,
} from '../types/game';
import {
  ACHIEVEMENTS_LIST,
  AchievementCategory,
  AchievementItem,
  AchievementTier,
} from '../types/achievements';

export type DockTab = 'vehicles' | 'customize' | 'levels' | 'players' | 'profile' | 'achievements';

interface BottomControlDockProps {
  isOpen: boolean;
  activeTab: DockTab;
  customization: VehicleCustomization;
  levelIndex: number;
  customLaps: number;
  autoAdvanceLevels: boolean;
  autoDrive: boolean;
  networkMode: NetworkMode;
  roomCode: string;
  localPlayerName: string;
  participants: RaceParticipant[];
  remotePeers: Array<{ id: string; name: string; carId: string; lap: number; speedKmh: number }>;
  telemetry: LiveTelemetry;
  careerStats: CareerStats;
  onToggleOpen: () => void;
  onSelectTab: (tab: DockTab) => void;
  onUpdateCustomization: (patch: Partial<VehicleCustomization>) => void;
  onSelectLevel: (idx: number) => void;
  onChangeCustomLaps: (laps: number) => void;
  onToggleAutoAdvance: () => void;
  onToggleAutoDrive: () => void;
  onSelectNetworkMode: (mode: NetworkMode) => void;
  onChangeRoomCode: (code: string) => void;
  onChangeLocalPlayerName: (name: string) => void;
  onUpdateDriverProfile: (
    patch: Partial<Pick<CareerStats, 'driverAge' | 'driverCountry' | 'driverNumber' | 'driverTeam'>>
  ) => void;
  onAddPlayer: (name: string, carId: string, paintHex: string, controlType: 'ai-bot' | 'local-p2', skillRating: number) => void;
  onRemovePlayer: (id: string) => void;
  onResetCareerStats: () => void;
}

const FINISH_OPTIONS: Array<{ id: FinishType; label: string }> = [
  { id: 'metallic', label: 'Metallic Clearcoat' },
  { id: 'matte', label: 'Stealth Satin' },
  { id: 'titanium', label: 'Brushed Titanium' },
  { id: 'iridescent', label: 'Iridescent Pearl' },
  { id: 'carbon', label: 'Exposed Carbon' },
];

const AERO_OPTIONS: Array<{ id: AeroPreset; label: string }> = [
  { id: 'street', label: 'Street Ducktail' },
  { id: 'gt3', label: 'GT3 Swan-Neck Wing' },
  { id: 'widebody', label: 'Time-Attack Widebody' },
];

const TIER_STYLES: Record<
  AchievementTier,
  {
    badgeClass: string;
    borderClass: string;
    iconBgClass: string;
    accentColor: string;
    points: number;
  }
> = {
  platinum: {
    badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
    borderClass: 'border-cyan-400/40 hover:border-cyan-400/70',
    iconBgClass: 'bg-cyan-950/80 text-cyan-300 border-cyan-400/40',
    accentColor: '#22d3ee',
    points: 100,
  },
  gold: {
    badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
    borderClass: 'border-amber-400/40 hover:border-amber-400/70',
    iconBgClass: 'bg-amber-950/80 text-amber-300 border-amber-400/40',
    accentColor: '#fbbf24',
    points: 50,
  },
  silver: {
    badgeClass: 'bg-slate-300/20 text-slate-200 border-slate-300/40',
    borderClass: 'border-slate-500/40 hover:border-slate-400/70',
    iconBgClass: 'bg-slate-900/90 text-slate-200 border-slate-400/40',
    accentColor: '#cbd5e1',
    points: 25,
  },
  bronze: {
    badgeClass: 'bg-orange-500/20 text-orange-300 border-orange-400/40',
    borderClass: 'border-orange-500/40 hover:border-orange-400/70',
    iconBgClass: 'bg-orange-950/80 text-orange-300 border-orange-400/40',
    accentColor: '#fb923c',
    points: 10,
  },
};

function renderAchievementIcon(name: string, className?: string) {
  switch (name) {
    case 'Trophy':
      return <Trophy className={className} />;
    case 'Flag':
      return <Flag className={className} />;
    case 'Flame':
      return <Flame className={className} />;
    case 'Gauge':
      return <Gauge className={className} />;
    case 'Zap':
      return <Zap className={className} />;
    case 'Compass':
      return <Compass className={className} />;
    case 'Wrench':
      return <Wrench className={className} />;
    case 'Sparkles':
      return <Sparkles className={className} />;
    case 'ShieldCheck':
      return <ShieldCheck className={className} />;
    default:
      return <Award className={className} />;
  }
}

export const BottomControlDock: React.FC<BottomControlDockProps> = ({
  isOpen,
  activeTab,
  customization,
  levelIndex,
  customLaps,
  autoAdvanceLevels,
  autoDrive,
  networkMode,
  roomCode,
  localPlayerName,
  participants,
  remotePeers,
  telemetry,
  careerStats,
  onToggleOpen,
  onSelectTab,
  onUpdateCustomization,
  onSelectLevel,
  onChangeCustomLaps,
  onToggleAutoAdvance,
  onToggleAutoDrive,
  onSelectNetworkMode,
  onChangeRoomCode,
  onChangeLocalPlayerName,
  onUpdateDriverProfile,
  onAddPlayer,
  onRemovePlayer,
  onResetCareerStats,
}) => {
  const [newDriverName, setNewDriverName] = useState('Apex Challenger');
  const [newDriverCarId, setNewDriverCarId] = useState('ferrari-296-gt3');
  const [newDriverPaint, setNewDriverPaint] = useState('#DC2626');
  const [newDriverType, setNewDriverType] = useState<'ai-bot' | 'local-p2'>('ai-bot');
  const [newDriverSkill, setNewDriverSkill] = useState(0.92);
  const [carCategoryFilter, setCarCategoryFilter] = useState<
    'all' | 'Hypercar / LMH' | 'LMGT3 / GT3' | 'GT2 / GT4'
  >('all');

  const [achievementFilter, setAchievementFilter] = useState<
    'all' | 'milestones' | 'mastery' | 'tuning' | 'speed' | 'completed' | 'in_progress'
  >('all');

  const selectedCar = HYPERCARS.find((c) => c.id === customization.carId) || HYPERCARS[0];
  const filteredCars =
    carCategoryFilter === 'all'
      ? HYPERCARS
      : HYPERCARS.filter((c) => c.category === carCategoryFilter);
  const hasLocalP2 = participants.some((p) => p.controlType === 'local-p2');

  const liveTotalMeters = careerStats.baseDistanceMeters + (telemetry.sessionDistanceMeters || 0);

  const achievementsWithProgress = ACHIEVEMENTS_LIST.map((ach) => {
    const prog = ach.checkProgress(careerStats, telemetry, liveTotalMeters, customization);
    const isUnlocked = prog.completed || !!careerStats.unlockedAchievements?.[ach.id];
    return {
      ...ach,
      progress: prog,
      isUnlocked,
    };
  });

  const unlockedCount = achievementsWithProgress.filter((a) => a.isUnlocked).length;
  const overallPercent = Math.round((unlockedCount / ACHIEVEMENTS_LIST.length) * 100);
  const totalPoints = achievementsWithProgress
    .filter((a) => a.isUnlocked)
    .reduce((sum, a) => sum + TIER_STYLES[a.tier].points, 0);

  const filteredAchievements = achievementsWithProgress.filter((item) => {
    if (achievementFilter === 'all') return true;
    if (achievementFilter === 'completed') return item.isUnlocked;
    if (achievementFilter === 'in_progress') return !item.isUnlocked;
    return item.category === achievementFilter;
  });

  const handleAddParticipant = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newDriverName.trim() || `Racer ${participants.length + 1}`;
    onAddPlayer(cleanName, newDriverCarId, newDriverPaint, newDriverType, newDriverSkill);
    setNewDriverName(`GT Rival ${participants.length + 1}`);
  };

  return (
    <div
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-20 w-[min(940px,94vw)] pointer-events-none"
      aria-label="Unified Bottom Control Dock"
    >
      {/* Cinema / Zen Mode Collapse Toggle attached to top edge of the dock */}
      <div className="flex justify-center mb-1.5">
        <button
          onClick={onToggleOpen}
          className="pointer-events-auto px-4 py-1 rounded-t-xl rounded-b-md bg-[#090d16]/92 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/15 text-xs font-medium flex items-center gap-1.5 shadow-lg transition-colors whitespace-nowrap"
          title="Toggle Cinema / Zen Mode (Shortcut: H)"
        >
          {isOpen ? (
            <>
              <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
              <span>Hide Controls (H)</span>
            </>
          ) : (
            <>
              <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
              <span>Show Garage, Levels & Players Dock (H)</span>
            </>
          )}
        </button>
      </div>

      {/* Collapsible Dock Container */}
      <div
        className={`pointer-events-auto rounded-2xl bg-[#090d16]/95 border border-white/15 shadow-2xl transition-all duration-200 overflow-hidden ${
          isOpen ? 'opacity-100 translate-y-0 max-h-[340px]' : 'opacity-0 translate-y-8 max-h-0 pointer-events-none border-0'
        }`}
      >
        {/* Top Tab Navigation Row + Exploded View Inspection Slider */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-white/10 bg-[#07090e]/80">
          <div className="flex items-center gap-1 overflow-x-auto">
            <button
              onClick={() => onSelectTab('vehicles')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'vehicles'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Motorsport Fleet ({HYPERCARS.length})</span>
            </button>

            <button
              onClick={() => onSelectTab('customize')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'customize'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Paint, Rims & Tuning</span>
            </button>

            <button
              onClick={() => onSelectTab('levels')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'levels'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>Automated Levels ({AUTOMATED_LEVELS.length})</span>
            </button>

            <button
              onClick={() => onSelectTab('players')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'players'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Players & Multiplayer ({telemetry.totalRacers})</span>
            </button>

            <button
              onClick={() => onSelectTab('profile')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'profile'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Driver Profile</span>
            </button>

            <button
              onClick={() => onSelectTab('achievements')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'achievements'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Achievements ({unlockedCount}/{ACHIEVEMENTS_LIST.length})</span>
            </button>
          </div>

          {/* Real-Time 3D Exploded View Slider */}
          <div className="flex items-center gap-2.5 text-xs">
            <Sliders className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <label htmlFor="exploded-slider" className="text-slate-300 whitespace-nowrap">
              Exploded View
            </label>
            <input
              id="exploded-slider"
              type="range"
              min={0}
              max={1}
              step={0.02}
              value={customization.explodedView}
              onChange={(e) =>
                onUpdateCustomization({ explodedView: parseFloat(e.target.value) })
              }
              className="w-24 accent-amber-500 cursor-pointer"
            />
            <span className="font-mono-tabular text-amber-400 w-9 text-right">
              {Math.round(customization.explodedView * 100)}%
            </span>
          </div>
        </div>

        {/* Tab 1: Official Motorsport Fleet & Aero Configuration */}
        {activeTab === 'vehicles' && (
          <div className="p-3.5 space-y-2.5">
            {/* Category Filter Chips */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
                {(['all', 'Hypercar / LMH', 'LMGT3 / GT3', 'GT2 / GT4'] as const).map((cat) => {
                  const count =
                    cat === 'all'
                      ? HYPERCARS.length
                      : HYPERCARS.filter((c) => c.category === cat).length;
                  return (
                    <button
                      key={cat}
                      onClick={() => setCarCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
                        carCategoryFilter === cat
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'bg-slate-800/90 text-slate-300 hover:text-white hover:bg-slate-700/80'
                      }`}
                    >
                      {cat === 'all' ? `All Models (${count})` : `${cat} (${count})`}
                    </button>
                  );
                })}
              </div>

              <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
                <span className="font-medium text-white">{selectedCar.name}</span>
                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-semibold">
                  {selectedCar.category}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
              {/* Scrollable Car Fleet Cards Grid */}
              <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[195px] overflow-y-auto pr-1">
                {filteredCars.map((car) => {
                  const isSelected = car.id === customization.carId;
                  return (
                    <button
                      key={car.id}
                      onClick={() =>
                        onUpdateCustomization({
                          carId: car.id,
                          paintHex: car.defaultPaintHex,
                          finishType: car.defaultFinish,
                          rimHex: car.defaultRimHex,
                          caliperHex: car.defaultCaliperHex,
                        })
                      }
                      className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-slate-800/95 border-amber-400 shadow-md ring-1 ring-amber-400/50'
                          : 'bg-slate-900/70 border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-[9px] text-amber-400 uppercase tracking-wider font-semibold">
                          {car.category.split('/')[0].trim()}
                        </span>
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0 border border-white/20"
                          style={{ backgroundColor: car.defaultPaintHex }}
                          title={car.defaultPaintHex}
                        />
                      </div>
                      <div className="font-display text-xs font-bold text-white truncate" title={car.name}>
                        {car.name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5" title={car.liveryName}>
                        {car.liveryName}
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[10px] text-slate-300 font-mono-tabular">
                        <span>{car.horsepower} HP</span>
                        <span className="text-amber-400">{car.topSpeedKmh} KM/H</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Selected Vehicle Specs & Aero Package */}
              <div className="lg:col-span-4 flex flex-col gap-2 pl-0 lg:pl-3 lg:border-l border-white/10">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white truncate">{selectedCar.name}</span>
                    <span className="font-mono-tabular text-emerald-400 text-xs shrink-0">
                      0-100: {selectedCar.accel0to100}s
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 truncate" title={selectedCar.powertrain}>
                    {selectedCar.powertrain}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate italic">
                    {selectedCar.liveryName}
                  </div>
                </div>

                <div>
                  <div className="text-[11px] text-slate-400 mb-1">Aerodynamic Package</div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {AERO_OPTIONS.map((aero) => (
                      <button
                        key={aero.id}
                        onClick={() => onUpdateCustomization({ aeroPreset: aero.id })}
                        className={`px-2 py-1 rounded-lg text-[10px] font-medium transition-colors truncate ${
                          customization.aeroPreset === aero.id
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                      >
                        {aero.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Paint Swatches, PBR Surface Finish, Rims & Performance Upgrades */}
        {activeTab === 'customize' && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            {/* Paint Swatches & Finish */}
            <div className="md:col-span-5 space-y-2.5">
              <div>
                <div className="text-[11px] text-slate-400 mb-1.5">Factory & Custom Livery Paint</div>
                <div className="flex flex-wrap items-center gap-2">
                  {PAINT_SWATCHES.map((sw) => (
                    <button
                      key={sw.hex}
                      onClick={() => onUpdateCustomization({ paintHex: sw.hex })}
                      className={`w-7 h-7 rounded-lg border-2 transition-transform cursor-pointer ${
                        customization.paintHex.toLowerCase() === sw.hex.toLowerCase()
                          ? 'border-white scale-110'
                          : 'border-white/20 hover:scale-105'
                      }`}
                      style={{ backgroundColor: sw.hex }}
                      title={sw.name}
                      aria-label={sw.name}
                    />
                  ))}
                  <input
                    type="color"
                    value={customization.paintHex}
                    onChange={(e) => onUpdateCustomization({ paintHex: e.target.value })}
                    className="w-7 h-7 rounded-lg bg-transparent border border-white/20 cursor-pointer"
                    title="Custom Hex Color Picker"
                  />
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400 mb-1">PBR Surface Finish</div>
                <div className="flex flex-wrap gap-1.5">
                  {FINISH_OPTIONS.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onUpdateCustomization({ finishType: f.id })}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap ${
                        customization.finishType === f.id
                          ? 'bg-amber-500 text-slate-950 font-semibold'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Rims & Calipers */}
            <div className="md:col-span-3 space-y-2.5 md:border-l md:border-white/10 md:pl-3">
              <div>
                <div className="text-[11px] text-slate-400 mb-1">Forged Alloy Rims</div>
                <div className="flex items-center gap-2">
                  {RIM_SWATCHES.map((r) => (
                    <button
                      key={r.hex}
                      onClick={() => onUpdateCustomization({ rimHex: r.hex })}
                      className={`w-6 h-6 rounded-md border-2 ${
                        customization.rimHex === r.hex ? 'border-amber-400 scale-110' : 'border-white/20'
                      }`}
                      style={{ backgroundColor: r.hex }}
                      title={r.name}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400 mb-1">Brake Caliper Accent</div>
                <div className="flex items-center gap-2">
                  {['#EF4444', '#F59E0B', '#10B981', '#06B6D4', '#A855F7'].map((cHex) => (
                    <button
                      key={cHex}
                      onClick={() => onUpdateCustomization({ caliperHex: cHex })}
                      className={`w-6 h-6 rounded-md border-2 ${
                        customization.caliperHex === cHex ? 'border-white scale-110' : 'border-white/20'
                      }`}
                      style={{ backgroundColor: cHex }}
                      title={`Caliper ${cHex}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Performance Tuning Stages */}
            <div className="md:col-span-4 space-y-2 md:border-l md:border-white/10 md:pl-3">
              <div className="text-[11px] text-slate-400">Performance Stage Tuning</div>
              {[
                { key: 'engineStage' as const, label: 'ECU & Powertrain', val: customization.engineStage },
                { key: 'turboStage' as const, label: 'Twin-Turbo & Nitro', val: customization.turboStage },
                { key: 'suspensionStage' as const, label: 'Active Suspension', val: customization.suspensionStage },
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between text-xs">
                  <span className="text-slate-300">{item.label}</span>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3].map((stg) => (
                      <button
                        key={stg}
                        onClick={() => onUpdateCustomization({ [item.key]: stg })}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono-tabular font-semibold ${
                          item.val >= stg
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        S{stg}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Automated Levels, Custom Lap Count & Autonomous Pilot Controls */}
        {activeTab === 'levels' && (
          <div className="p-3.5 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              {/* Custom Lap Count Selector */}
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-300 font-medium">Race Laps (~1 Min / Lap):</span>
                <div className="flex items-center gap-1 bg-slate-900 border border-white/15 rounded-lg p-0.5">
                  <button
                    type="button"
                    onClick={() => onChangeCustomLaps(Math.max(1, customLaps - 1))}
                    className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer"
                    title="Decrease Laps"
                  >
                    -
                  </button>
                  <span className="px-2.5 font-mono-tabular font-bold text-amber-400">
                    {customLaps} {customLaps === 1 ? 'Lap' : 'Laps'}
                  </span>
                  <button
                    type="button"
                    onClick={() => onChangeCustomLaps(Math.min(50, customLaps + 1))}
                    className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer"
                    title="Increase Laps"
                  >
                    +
                  </button>
                </div>
                <div className="hidden sm:flex items-center gap-1">
                  {[1, 3, 5, 8, 12].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => onChangeCustomLaps(preset)}
                      className={`px-2 py-0.5 rounded text-[11px] font-mono-tabular font-semibold cursor-pointer transition-colors ${
                        customLaps === preset
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-800/80 text-slate-300 hover:text-white'
                      }`}
                    >
                      {preset}L
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onToggleAutoAdvance}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    autoAdvanceLevels
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  Auto-Advance Levels: {autoAdvanceLevels ? 'ON' : 'OFF'}
                </button>
                <button
                  onClick={onToggleAutoDrive}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                    autoDrive
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>AI Auto-Drive: {autoDrive ? 'ACTIVE' : 'OFF'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
              {AUTOMATED_LEVELS.map((lvl, idx) => {
                const active = idx === levelIndex;
                return (
                  <button
                    key={lvl.id}
                    onClick={() => onSelectLevel(idx)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      active
                        ? 'bg-slate-800 border-amber-400 shadow-md'
                        : 'bg-slate-900/70 border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="text-[10px] text-amber-400 font-semibold truncate">
                      {lvl.location}
                    </div>
                    <div className="font-display text-xs font-bold text-white truncate mt-0.5">
                      {lvl.name}
                    </div>
                    <div className="mt-1 text-[11px] text-slate-400 font-mono-tabular">
                      {active ? customLaps : lvl.laps} Laps · ~1:00/Lap
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 4: Player Add (AI Rivals & Local 2P Split-Keyboard) + Live Multiplayer Room */}
        {activeTab === 'players' && (
          <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 items-start max-h-[240px] overflow-y-auto">
            {/* Left: Add Player / Rival Form */}
            <form onSubmit={handleAddParticipant} className="lg:col-span-5 space-y-2">
              <div className="text-xs font-semibold text-white flex items-center justify-between">
                <span>Add Player or Custom AI Rival to Grid</span>
                <span className="text-[11px] text-slate-400 font-normal">
                  {participants.length}/10 Racers
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newDriverName}
                  onChange={(e) => setNewDriverName(e.target.value)}
                  placeholder="Driver Name"
                  maxLength={18}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <select
                  value={newDriverCarId}
                  onChange={(e) => setNewDriverCarId(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  {HYPERCARS.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setNewDriverType('ai-bot')}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium ${
                      newDriverType === 'ai-bot'
                        ? 'bg-amber-500 text-slate-950 font-semibold'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    AI Rival
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewDriverType('local-p2')}
                    disabled={hasLocalP2}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium ${
                      newDriverType === 'local-p2'
                        ? 'bg-emerald-500 text-slate-950 font-semibold'
                        : hasLocalP2
                        ? 'bg-slate-900 text-slate-600 cursor-not-allowed'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                    title="Local Player 2 drives with Arrow Keys + Right Shift"
                  >
                    {hasLocalP2 ? 'Local P2 Added' : 'Local P2 (Arrows)'}
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={newDriverPaint}
                    onChange={(e) => setNewDriverPaint(e.target.value)}
                    className="w-6 h-6 rounded bg-transparent border border-white/20 cursor-pointer"
                    title="Driver Car Color"
                  />
                  <select
                    value={newDriverSkill}
                    onChange={(e) => setNewDriverSkill(parseFloat(e.target.value))}
                    className="px-2 py-1 rounded bg-slate-900 border border-white/15 text-[11px] text-slate-200"
                    title="AI Skill Pace"
                  >
                    <option value={0.82}>Rookie Pace</option>
                    <option value={0.92}>Pro Pace</option>
                    <option value={1.0}>Champion Pace</option>
                  </select>
                  <button
                    type="submit"
                    disabled={participants.length >= 10}
                    className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-semibold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            </form>

            {/* Center: Active Offline & Local Roster */}
            <div className="lg:col-span-4 space-y-1.5 lg:border-l lg:border-white/10 lg:pl-3">
              <div className="text-xs font-semibold text-white">Active Grid Roster</div>
              <div className="space-y-1 max-h-[135px] overflow-y-auto pr-1">
                {participants.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between px-2.5 py-1 rounded-lg bg-slate-900/90 border border-white/10 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: p.id === 'local-p1' ? customization.paintHex : p.paintHex }}
                      />
                      <span className="font-medium text-white truncate">
                        {p.id === 'local-p1'
                          ? `${localPlayerName} (${careerStats.driverAge || 24}y)`
                          : p.name}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        · {p.controlType === 'local-p1' ? 'P1 (WASD)' : p.controlType === 'local-p2' ? 'P2 (Arrows)' : 'AI'}
                      </span>
                    </div>
                    {p.id !== 'local-p1' && (
                      <button
                        onClick={() => onRemovePlayer(p.id)}
                        className="text-slate-400 hover:text-red-400 p-0.5"
                        title="Remove Player"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Online WebSocket Multiplayer Lobby & Driver Name/Age */}
            <div className="lg:col-span-3 space-y-2 lg:border-l lg:border-white/10 lg:pl-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Network & Driver</span>
                </span>
                <button
                  onClick={() =>
                    onSelectNetworkMode(networkMode === 'offline' ? 'multiplayer' : 'offline')
                  }
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                    networkMode === 'multiplayer'
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {networkMode === 'multiplayer' ? 'Live WebSocket' : 'Offline Solo/Local'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5">
                <div className="col-span-2">
                  <label className="block text-[10px] text-slate-400 mb-0.5">Player Name</label>
                  <input
                    type="text"
                    value={localPlayerName}
                    onChange={(e) => onChangeLocalPlayerName(e.target.value)}
                    maxLength={16}
                    className="w-full px-2 py-1 rounded bg-slate-900 border border-white/15 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-0.5">Age (Wayasa)</label>
                  <input
                    type="number"
                    min={8}
                    max={99}
                    value={careerStats.driverAge ?? 24}
                    onChange={(e) =>
                      onUpdateDriverProfile({
                        driverAge: Math.max(8, Math.min(99, parseInt(e.target.value, 10) || 18)),
                      })
                    }
                    className="w-full px-2 py-1 rounded bg-slate-900 border border-white/15 text-xs font-mono-tabular text-amber-400"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
                <span>Room:</span>
                <input
                  type="text"
                  value={roomCode}
                  onChange={(e) => onChangeRoomCode(e.target.value.toUpperCase())}
                  maxLength={10}
                  className="w-24 px-2 py-0.5 rounded bg-slate-900 border border-white/15 text-xs font-mono-tabular text-cyan-300"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Editable Driver Profile (Name, Age, Nationality, Number, Team) & Career Telemetry */}
        {activeTab === 'profile' && (() => {
          const liveTotalMeters = careerStats.baseDistanceMeters + (telemetry.sessionDistanceMeters || 0);
          const totalKm = (liveTotalMeters / 1000).toFixed(2);
          const avgFinish =
            careerStats.totalRaces > 0
              ? `P${(careerStats.finishPositionsSum / careerStats.totalRaces).toFixed(1)}`
              : '--';
          const winRate =
            careerStats.totalRaces > 0
              ? `${Math.round((careerStats.totalWins / careerStats.totalRaces) * 100)}%`
              : '0%';
          const licenseTier =
            careerStats.totalWins >= 5 || liveTotalMeters >= 25000
              ? 'FIA Platinum Superlicense'
              : careerStats.totalWins >= 2 || liveTotalMeters >= 8000
              ? 'FIA Gold GT License'
              : 'FIA Silver Circuit License';

          return (
            <div className="p-3.5 grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-center">
              {/* Left: Editable Personal Driver Bio (Name, Age / Wayasa, Country, Number, Team) */}
              <div className="lg:col-span-5 space-y-2">
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-10 h-10 rounded-xl border border-white/20 flex flex-col items-center justify-center font-display font-bold text-slate-950 shrink-0"
                    style={{ backgroundColor: customization.paintHex }}
                  >
                    <span className="text-[9px] leading-none">#{careerStats.driverNumber || '59'}</span>
                    <span className="text-xs leading-tight">{localPlayerName.slice(0, 2).toUpperCase()}</span>
                  </div>
                  <div className="min-w-0 flex-1 grid grid-cols-12 gap-1.5">
                    <div className="col-span-7">
                      <label className="block text-[9px] text-slate-400 uppercase tracking-wider">
                        Driver Name (Nama)
                      </label>
                      <input
                        type="text"
                        value={localPlayerName}
                        onChange={(e) => onChangeLocalPlayerName(e.target.value)}
                        maxLength={18}
                        aria-label="Driver Name"
                        className="px-2 py-1 rounded bg-slate-900 border border-white/15 font-display text-xs font-bold text-white focus:outline-none focus:border-amber-400 w-full"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[9px] text-slate-400 uppercase tracking-wider">
                        Age
                      </label>
                      <input
                        type="number"
                        min={8}
                        max={99}
                        value={careerStats.driverAge ?? 24}
                        onChange={(e) =>
                          onUpdateDriverProfile({
                            driverAge: Math.max(8, Math.min(99, parseInt(e.target.value, 10) || 18)),
                          })
                        }
                        aria-label="Driver Age"
                        className="px-1.5 py-1 rounded bg-slate-900 border border-white/15 font-mono-tabular text-xs font-bold text-amber-400 focus:outline-none focus:border-amber-400 w-full text-center"
                      />
                    </div>
                    <div className="col-span-3">
                      <label className="block text-[9px] text-slate-400 uppercase tracking-wider">
                        Car #
                      </label>
                      <input
                        type="text"
                        maxLength={3}
                        value={careerStats.driverNumber ?? '59'}
                        onChange={(e) =>
                          onUpdateDriverProfile({
                            driverNumber: e.target.value.replace(/[^0-9]/g, '').slice(0, 3) || '1',
                          })
                        }
                        aria-label="Racing Number"
                        className="px-1.5 py-1 rounded bg-slate-900 border border-white/15 font-mono-tabular text-xs font-bold text-cyan-300 focus:outline-none focus:border-amber-400 w-full text-center"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <label className="block text-[9px] text-slate-400 uppercase tracking-wider">
                      Country / Nationality
                    </label>
                    <select
                      value={careerStats.driverCountry ?? 'Sri Lanka'}
                      onChange={(e) => onUpdateDriverProfile({ driverCountry: e.target.value })}
                      className="w-full px-2 py-1 rounded bg-slate-900 border border-white/15 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                    >
                      <option value="Sri Lanka">Sri Lanka</option>
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="Italy">Italy</option>
                      <option value="Germany">Germany</option>
                      <option value="Japan">Japan</option>
                      <option value="Monaco">Monaco</option>
                      <option value="United States">United States</option>
                      <option value="Australia">Australia</option>
                      <option value="France">France</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-400 uppercase tracking-wider">
                      Racing Team
                    </label>
                    <input
                      type="text"
                      maxLength={22}
                      value={careerStats.driverTeam ?? 'Apex Horizon Works'}
                      onChange={(e) => onUpdateDriverProfile({ driverTeam: e.target.value })}
                      className="w-full px-2 py-1 rounded bg-slate-900 border border-white/15 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/10">
                  <span className="truncate">
                    {licenseTier} · Age <strong className="text-white">{careerStats.driverAge ?? 24}</strong> · {careerStats.driverCountry ?? 'Sri Lanka'}
                  </span>
                  <button
                    onClick={onResetCareerStats}
                    className="text-[11px] text-slate-400 hover:text-red-400 flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                    title="Reset Career Telemetry"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>

              {/* Center: Primary Career Stat Readouts (Total Distance, Total Wins, Average Finish Position) */}
              <div className="lg:col-span-4 grid grid-cols-3 gap-2 lg:border-l lg:border-white/10 lg:pl-3.5">
                <div className="p-2 rounded-xl bg-slate-900/90 border border-white/10">
                  <div className="text-[10px] text-slate-400">Total Distance</div>
                  <div className="font-display text-base font-bold text-cyan-400 font-mono-tabular mt-0.5">
                    {totalKm} <span className="text-[10px] font-normal text-slate-300">km</span>
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-tabular">
                    {liveTotalMeters.toLocaleString()} m
                  </div>
                </div>

                <div className="p-2 rounded-xl bg-slate-900/90 border border-white/10">
                  <div className="text-[10px] text-slate-400">Total Wins</div>
                  <div className="font-display text-base font-bold text-amber-400 font-mono-tabular mt-0.5">
                    {careerStats.totalWins}
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-tabular">
                    Win {winRate}
                  </div>
                </div>

                <div className="p-2 rounded-xl bg-slate-900/90 border border-white/10">
                  <div className="text-[10px] text-slate-400">Avg Finish</div>
                  <div className="font-display text-base font-bold text-emerald-400 font-mono-tabular mt-0.5">
                    {avgFinish}
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-tabular">
                    Peak {Math.max(careerStats.peakSpeedKmh, telemetry.speedKmh)} km/h
                  </div>
                </div>
              </div>

              {/* Right: Recent Race Log */}
              <div className="lg:col-span-3 space-y-1.5 lg:border-l lg:border-white/10 lg:pl-3.5">
                <div className="text-[11px] font-semibold text-slate-300">Recent Career Finishes</div>
                {careerStats.recentRaces.length === 0 ? (
                  <div className="text-[11px] text-slate-400 py-2">
                    Complete a race to log official lap times and podium standings.
                  </div>
                ) : (
                  <div className="space-y-1 max-h-[88px] overflow-y-auto pr-1">
                    {careerStats.recentRaces.slice(0, 4).map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between text-[11px] px-2 py-1 rounded bg-slate-900/80 border border-white/10"
                      >
                        <span className="text-slate-200 truncate max-w-[125px]">
                          {rec.levelName}
                        </span>
                        <span className="font-mono-tabular text-amber-400 font-semibold shrink-0">
                          P{rec.position}/{rec.totalRacers}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })()}

        {/* Tab 6: Career Achievements & Milestones */}
        {activeTab === 'achievements' && (
          <div className="p-3.5 space-y-3">
            {/* Header: Trophy Counter, Category Filters, Points */}
            <div className="flex flex-wrap items-center justify-between gap-2.5 pb-2 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span className="font-display text-sm font-bold text-white">Career Milestones</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <span className="font-mono-tabular font-bold text-amber-400">
                    {unlockedCount} / {ACHIEVEMENTS_LIST.length}
                  </span>
                  <span className="text-slate-400">({overallPercent}%)</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-cyan-400 font-mono-tabular font-semibold">
                    {totalPoints} Trophy Pts
                  </span>
                </div>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1 overflow-x-auto text-[11px]">
                {(
                  [
                    { id: 'all', label: 'All' },
                    { id: 'milestones', label: 'Milestones' },
                    { id: 'mastery', label: 'Mastery' },
                    { id: 'speed', label: 'Speed' },
                    { id: 'tuning', label: 'Tuning' },
                    { id: 'completed', label: 'Unlocked' },
                    { id: 'in_progress', label: 'In Progress' },
                  ] as const
                ).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setAchievementFilter(cat.id)}
                    className={`px-2.5 py-0.5 rounded-full font-medium transition-colors cursor-pointer ${
                      achievementFilter === cat.id
                        ? 'bg-amber-400 text-slate-950 font-semibold'
                        : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Achievements Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[220px] overflow-y-auto pr-1">
              {filteredAchievements.map((item) => {
                const tier = TIER_STYLES[item.tier];
                const isUnlocked = item.isUnlocked;

                return (
                  <div
                    key={item.id}
                    className={`p-2.5 rounded-xl border transition-all ${
                      isUnlocked
                        ? `${tier.borderClass} bg-slate-900/90 shadow-sm`
                        : 'border-white/10 bg-slate-900/50 opacity-85'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${
                          isUnlocked ? tier.iconBgClass : 'bg-slate-800 border-white/10 text-slate-500'
                        }`}
                      >
                        {renderAchievementIcon(item.iconName, 'w-4 h-4')}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1.5 mb-0.5">
                          <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                          <span
                            className={`text-[9px] uppercase tracking-wider px-1.5 py-0.2 rounded font-mono-tabular border font-semibold shrink-0 ${tier.badgeClass}`}
                          >
                            {item.tier}
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-400 leading-tight line-clamp-2 mb-2">
                          {item.description}
                        </p>

                        {/* Progress Bar & Value Readout */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[10px] text-slate-300 font-mono-tabular">
                            <span>{item.progress.formattedProgress}</span>
                            <span className={isUnlocked ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                              {item.progress.percent}%
                            </span>
                          </div>

                          <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                            <div
                              className={`h-full transition-all duration-300 ${
                                isUnlocked ? 'bg-emerald-400' : 'bg-amber-500'
                              }`}
                              style={{ width: `${item.progress.percent}%` }}
                            />
                          </div>
                        </div>

                        {/* Status Footer */}
                        <div className="flex items-center justify-between text-[10px] mt-1.5 pt-1 border-t border-white/5">
                          <span className="text-slate-400 capitalize">{item.category}</span>
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              <span>UNLOCKED</span>
                            </span>
                          ) : (
                            <span className="text-slate-400 flex items-center gap-1 font-mono-tabular">
                              <Lock className="w-3 h-3 text-slate-500" />
                              <span>IN PROGRESS</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
