import React, { useState } from 'react';
import { QUIZ_QUESTIONS } from '../../data/quizQuestions';
import { RADIOLOGY_LESSONS } from '../../data/radiologyCurriculum';
import { HunterProfile, HunterRank, Language, QuizQuestion } from '../../types';
import { soundManager } from '../../utils/audio';
import { 
  Flame, 
  Heart, 
  Zap, 
  Crown, 
  Lock, 
  CheckCircle, 
  Play, 
  ShieldAlert, 
  Sparkles,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  profile: HunterProfile;
  language: Language;
  soundEnabled: boolean;
  onAnswerQuestion: (isCorrect: boolean, xpReward: number) => void;
  onConsumeHeart: () => boolean;
  onRefillHearts: () => void;
}

interface DungeonGate {
  id: string;
  rank: HunterRank;
  titleAr: string;
  titleFr: string;
  descAr: string;
  requiredLevel: number;
  xpBonus: number;
  questionIds: string[];
}

const DUNGEON_GATES: DungeonGate[] = [
  {
    id: 'gate-e',
    rank: 'E',
    titleAr: 'بوابة الرتبة E: فيزياء الأشعة والمصطلحات',
    titleFr: 'Porte Rang E : Physique X et Lexique',
    descAr: 'تعلم أساسيات إنتاج الأشعة في أنبوب كوليدج، معايير kVp و mAs والمصطلحات الجوهرية.',
    requiredLevel: 1,
    xpBonus: 100,
    questionIds: ['q-01', 'q-02']
  },
  {
    id: 'gate-d',
    rank: 'D',
    titleAr: 'بوابة الرتبة D: درع الوقاية الإشعاعية ALARA',
    titleFr: 'Porte Rang D : Bouclier ALARA',
    descAr: 'إتقان حماية المريض والطاقم، حدود الجرعات القانونية في المستشفيات الجزائرية.',
    requiredLevel: 3,
    xpBonus: 150,
    questionIds: ['q-03', 'q-04', 'q-07']
  },
  {
    id: 'gate-c',
    rank: 'C',
    titleAr: 'بوابة الرتبة C: المفراس الحلزوني والوضعيات',
    titleFr: 'Porte Rang C : Scanner TDM & Incidences',
    descAr: 'كثافات هاونسفيلد، النوافذ الرئوية والعظمية، وتدوير القدمين في صورة الحوض.',
    requiredLevel: 7,
    xpBonus: 220,
    questionIds: ['q-05', 'q-06']
  },
  {
    id: 'gate-b',
    rank: 'B',
    titleAr: 'بوابة الرتبة B: أسرار الرنين المغناطيسي الطارئ',
    titleFr: 'Porte Rang B : Arcanes IRM & Sécurité',
    descAr: 'تسلسلات FLAIR و T1 و T2، موانع الرنين الصارمة وإدارة تسرب مادة التباين.',
    requiredLevel: 12,
    xpBonus: 300,
    questionIds: ['q-08', 'q-10']
  },
  {
    id: 'gate-a',
    rank: 'A',
    titleAr: 'بوابة الرتبة A: الإيكوغرافيا والماموغرافي',
    titleFr: 'Porte Rang A : Échographie & Sénologie',
    descAr: 'أنواع المجسات الصوتية، تصنيف BI-RADS، ومحاكاة الحالات الاستشفائية الحقيقية.',
    requiredLevel: 20,
    xpBonus: 400,
    questionIds: ['q-05', 'q-09', 'q-01']
  },
  {
    id: 'gate-s',
    rank: 'S',
    titleAr: 'بوابة سيد الظلال S: امتحان النخبة الشامل',
    titleFr: 'Porte S : Monarque des Ombres',
    descAr: 'تحدٍ ملحمي يجمع كافة تخصصات الأشعة والتشريح لتتويج الصياد في الرتبة القصوى!',
    requiredLevel: 30,
    xpBonus: 800,
    questionIds: ['q-01', 'q-02', 'q-03', 'q-04', 'q-05', 'q-06', 'q-07', 'q-08', 'q-09', 'q-10']
  }
];

export const LearningDungeon: React.FC<Props> = ({
  profile,
  language,
  soundEnabled,
  onAnswerQuestion,
  onConsumeHeart,
  onRefillHearts
}) => {
  const [activeGate, setActiveGate] = useState<DungeonGate | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [gateQuestions, setGateQuestions] = useState<QuizQuestion[]>([]);
  const [isGateCompleted, setIsGateCompleted] = useState(false);

  // Start Gate Quest
  const handleStartGate = (gate: DungeonGate) => {
    if (profile.level < gate.requiredLevel) {
      soundManager.playError(soundEnabled);
      return;
    }

    if (profile.hearts <= 0) {
      soundManager.playError(soundEnabled);
      return;
    }

    // Filter questions
    const questions = QUIZ_QUESTIONS.filter((q) => gate.questionIds.includes(q.id));
    setGateQuestions(questions.length > 0 ? questions : [QUIZ_QUESTIONS[0]]);
    setActiveGate(gate);
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswerChecked(false);
    setIsGateCompleted(false);
    soundManager.playSlash(soundEnabled);
  };

  const handleCheckAnswer = () => {
    if (selectedOption === null || !activeGate || gateQuestions.length === 0) return;

    const currentQ = gateQuestions[currentQuestionIndex];
    const correct = selectedOption === currentQ.correctIndex;
    setIsCorrect(correct);
    setIsAnswerChecked(true);

    if (correct) {
      soundManager.playSuccess(soundEnabled);
      onAnswerQuestion(true, 40);
    } else {
      soundManager.playError(soundEnabled);
      const hasHeartsLeft = onConsumeHeart();
      onAnswerQuestion(false, 0);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex + 1 < gateQuestions.length) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      soundManager.playTick(soundEnabled);
    } else {
      // Completed Gate!
      setIsGateCompleted(true);
      soundManager.playRankUp(soundEnabled);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {}
      if (activeGate) {
        onAnswerQuestion(true, activeGate.xpBonus);
      }
    }
  };

  const handleCloseDungeon = () => {
    setActiveGate(null);
    soundManager.playTick(soundEnabled);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Hunter Stats Bar (Duolingo Hearts & Streaks) */}
      <div className="flex items-center justify-between bg-slate-950/90 p-3.5 rounded-2xl border border-purple-900/40 shadow-neon-purple backdrop-blur-md">
        <div className="flex items-center gap-3">
          {/* Hearts / Mana */}
          <div className="flex items-center gap-1.5 bg-rose-950/50 px-3 py-1.5 rounded-xl border border-rose-600/40">
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
            <span className="text-sm font-black text-rose-300 font-mono">
              {profile.hearts}/{profile.maxHearts}
            </span>
            {profile.hearts < profile.maxHearts && (
              <button
                onClick={() => {
                  onRefillHearts();
                  soundManager.playManaRestore(soundEnabled);
                }}
                title="تعبئة القلوب بمراجعة سريعة"
                className="text-[10px] text-rose-300 underline mr-1 hover:text-white"
              >
                تعبئة
              </button>
            )}
          </div>

          {/* Daily Streak */}
          <div className="flex items-center gap-1.5 bg-amber-950/50 px-3 py-1.5 rounded-xl border border-amber-500/40">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-sm font-black text-amber-300 font-mono">
              {profile.streak} أيام متواصلة
            </span>
          </div>
        </div>

        {/* Hunter Level & XP */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs font-black text-purple-300 font-tech">
              المستوى {profile.level} ({profile.rank}-Rank)
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              {profile.currentXp} / {profile.nextLevelXp} XP
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-purple-900/60 border border-purple-400 flex items-center justify-center font-black text-xs text-purple-200">
            {profile.rank}
          </div>
        </div>
      </div>

      {/* Active Dungeon Question Modal Overlay */}
      {activeGate && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-lg w-full bg-slate-950 p-6 rounded-3xl border-2 border-purple-500 shadow-neon-purple text-right animate-scale-up">
            {!isGateCompleted ? (
              <>
                {/* Dungeon Quest Header */}
                <div className="flex items-center justify-between border-b border-purple-900/40 pb-3 mb-4">
                  <span className="text-xs font-black text-purple-400 font-tech">
                    {activeGate.titleAr} ({currentQuestionIndex + 1}/{gateQuestions.length})
                  </span>
                  <button
                    onClick={handleCloseDungeon}
                    className="text-slate-400 hover:text-white text-xs bg-slate-900 px-2.5 py-1 rounded-lg"
                  >
                    انسحاب
                  </button>
                </div>

                {/* Question */}
                {gateQuestions[currentQuestionIndex] && (
                  <div>
                    <h3 className="text-base font-extrabold text-slate-100 leading-relaxed mb-4">
                      {language === 'ar'
                        ? gateQuestions[currentQuestionIndex].questionAr
                        : gateQuestions[currentQuestionIndex].questionFr}
                    </h3>

                    {/* Options */}
                    <div className="space-y-2.5 mb-5">
                      {gateQuestions[currentQuestionIndex].optionsAr.map((opt, idx) => {
                        const isSelected = selectedOption === idx;
                        return (
                          <button
                            key={idx}
                            onClick={() => {
                              if (!isAnswerChecked) {
                                setSelectedOption(idx);
                                soundManager.playTick(soundEnabled);
                              }
                            }}
                            disabled={isAnswerChecked}
                            className={`w-full text-right p-3.5 rounded-xl border font-semibold text-xs transition-all ${
                              isSelected
                                ? 'bg-purple-600/40 border-purple-400 text-white shadow-neon-purple'
                                : 'bg-slate-900/70 border-purple-900/40 text-slate-300 hover:bg-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full border border-purple-400/50 flex items-center justify-center text-[10px] font-mono">
                                {idx + 1}
                              </span>
                              <span>
                                {language === 'ar'
                                  ? opt
                                  : gateQuestions[currentQuestionIndex].optionsFr[idx]}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Feedback Explanation */}
                    {isAnswerChecked && (
                      <div
                        className={`p-3.5 rounded-xl border text-xs leading-relaxed mb-4 ${
                          isCorrect
                            ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200'
                            : 'bg-rose-950/60 border-rose-500 text-rose-200'
                        }`}
                      >
                        <div className="font-bold mb-1 flex items-center gap-1.5">
                          {isCorrect ? (
                            <>
                              <CheckCircle className="w-4 h-4 text-emerald-400" />
                              <span>ضربة صحيحة! +40 XP</span>
                            </>
                          ) : (
                            <>
                              <ShieldAlert className="w-4 h-4 text-rose-400" />
                              <span>خسرت قلباً واحداً! التفسير الطبي:</span>
                            </>
                          )}
                        </div>
                        <p>
                          {language === 'ar'
                            ? gateQuestions[currentQuestionIndex].explanationAr
                            : gateQuestions[currentQuestionIndex].explanationFr}
                        </p>
                      </div>
                    )}

                    {/* Action Button */}
                    {!isAnswerChecked ? (
                      <button
                        onClick={handleCheckAnswer}
                        disabled={selectedOption === null}
                        className="w-full py-3 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50"
                      >
                        تأكيد الضربة الشعاعية
                      </button>
                    ) : (
                      <button
                        onClick={handleNextQuestion}
                        className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all active:scale-95"
                      >
                        {currentQuestionIndex + 1 < gateQuestions.length ? 'السؤال التالي' : 'إكمال البوابة'}
                      </button>
                    )}
                  </div>
                )}
              </>
            ) : (
              /* Gate Victory Celebration */
              <div className="text-center py-4">
                <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-3 animate-bounce" />
                <h3 className="text-xl font-black text-slate-100 mb-1">
                  تم تطهير البوابة بنجاح!
                </h3>
                <p className="text-xs text-purple-300 mb-4">
                  أثبتت جدارتك كصياد أشعة مقتدر، كسبت مكافأة قدرها{' '}
                  <span className="font-bold text-yellow-400 font-mono">
                    +{activeGate.xpBonus} XP
                  </span>
                </p>

                <button
                  onClick={handleCloseDungeon}
                  className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-rose-600 text-white font-bold text-xs rounded-xl shadow-neon-purple active:scale-95"
                >
                  العودة إلى خريطة البوابات
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Solo Leveling Dungeon Path (Duolingo Style Map) */}
      <div className="relative flex flex-col items-center gap-8 py-4">
        {DUNGEON_GATES.map((gate, index) => {
          const isUnlocked = profile.level >= gate.requiredLevel;
          const isCurrentRank = profile.rank === gate.rank;

          return (
            <div
              key={gate.id}
              className={`relative flex flex-col items-center max-w-md w-full p-5 rounded-2xl border transition-all duration-300 ${
                isUnlocked
                  ? 'bg-slate-950/90 border-purple-500/50 hover:border-purple-400 shadow-neon-purple'
                  : 'bg-black/60 border-slate-800 opacity-60'
              }`}
            >
              {/* Node Header */}
              <div className="w-full flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center font-black text-xs ${
                    isUnlocked ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-500'
                  }`}>
                    {gate.rank}
                  </span>
                  <h4 className="text-sm font-extrabold text-slate-100">
                    {language === 'ar' ? gate.titleAr : gate.titleFr}
                  </h4>
                </div>

                {!isUnlocked && (
                  <span className="flex items-center gap-1 text-[11px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                    <Lock className="w-3 h-3" /> يتطلب مستوى {gate.requiredLevel}
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed text-right w-full mb-3">
                {gate.descAr}
              </p>

              <div className="w-full flex items-center justify-between border-t border-purple-900/30 pt-3">
                <span className="text-xs text-yellow-400 font-mono font-bold">
                  +{gate.xpBonus} XP مكافأة
                </span>

                <button
                  onClick={() => handleStartGate(gate)}
                  disabled={!isUnlocked || profile.hearts <= 0}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-black transition-all ${
                    isUnlocked && profile.hearts > 0
                      ? 'bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white shadow-md active:scale-95'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>دخول البوابة</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
