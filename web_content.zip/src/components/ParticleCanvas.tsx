import React, { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';

export interface ParticleCanvasHandle {
  burst: (x: number, y: number, color: string, count?: number, isGolden?: boolean) => void;
  celebrate: () => void;
  shockwave: (x: number, y: number, color: string) => void;
  bombExplosion: (x: number, y: number) => void;
  feverSparks: (count?: number) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  gravity: number;
  shape: 'circle' | 'star' | 'confetti' | 'ember';
  angle: number;
  angularVelocity: number;
}

interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
}

export const ParticleCanvas = forwardRef<ParticleCanvasHandle>((_, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const shockwavesRef = useRef<Shockwave[]>([]);
  const animFrameRef = useRef<number | null>(null);

  // Resize canvas to window dimensions
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const startLoop = () => {
    if (animFrameRef.current !== null) return;

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        animFrameRef.current = null;
        return;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        animFrameRef.current = null;
        return;
      }

      const dpr = window.devicePixelRatio || 1;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.scale(dpr, dpr);

      // Render shockwaves
      const shockwaves = shockwavesRef.current;
      for (let i = shockwaves.length - 1; i >= 0; i--) {
        const sw = shockwaves[i];
        sw.radius += 8;
        sw.alpha = Math.max(0, 1 - sw.radius / sw.maxRadius);

        if (sw.alpha <= 0.01 || sw.radius >= sw.maxRadius) {
          shockwaves.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.strokeStyle = sw.color;
        ctx.globalAlpha = sw.alpha * 0.8;
        ctx.lineWidth = Math.max(1.5, 7 * sw.alpha);
        ctx.stroke();
        ctx.restore();
      }

      // Render particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.gravity;
        p.alpha -= p.decay;
        p.angle += p.angularVelocity;

        if (p.alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle);

        if (p.shape === 'star') {
          drawStar(ctx, 0, 0, 5, p.size * 1.4, p.size * 0.6, p.color);
        } else if (p.shape === 'confetti') {
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size, -p.size * 0.5, p.size * 2, p.size);
        } else if (p.shape === 'ember') {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 8;
          ctx.shadowColor = p.color;
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.fill();
        }
        ctx.restore();
      }

      ctx.restore();

      if (particlesRef.current.length > 0 || shockwavesRef.current.length > 0) {
        animFrameRef.current = requestAnimationFrame(render);
      } else {
        animFrameRef.current = null;
      }
    };

    animFrameRef.current = requestAnimationFrame(render);
  };

  const drawStar = (
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    spikes: number,
    outerRadius: number,
    innerRadius: number,
    color: string
  ) => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  };

  useImperativeHandle(ref, () => ({
    burst: (x: number, y: number, color: string, count = 18, isGolden = false) => {
      const pCount = isGolden ? count * 1.5 : count;
      const palette = isGolden
        ? ['#FBBF24', '#F59E0B', '#FEF08A', '#FFFFFF', '#D97706']
        : [color, '#FFFFFF', color];

      for (let i = 0; i < pCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = (isGolden ? 3.5 : 2.5) + Math.random() * 6.5;
        const particleColor = palette[Math.floor(Math.random() * palette.length)];

        particlesRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: (isGolden ? 4 : 3) + Math.random() * 4,
          color: particleColor,
          alpha: 1,
          decay: 0.02 + Math.random() * 0.025,
          gravity: 0.18,
          shape: isGolden ? (Math.random() > 0.4 ? 'star' : 'circle') : 'circle',
          angle: Math.random() * Math.PI * 2,
          angularVelocity: (Math.random() - 0.5) * 0.2,
        });
      }

      startLoop();
    },

    shockwave: (x: number, y: number, color: string) => {
      shockwavesRef.current.push({
        x,
        y,
        radius: 10,
        maxRadius: 70,
        color,
        alpha: 1,
      });
      startLoop();
    },

    bombExplosion: (x: number, y: number) => {
      // Concussive shockwave
      shockwavesRef.current.push({
        x,
        y,
        radius: 10,
        maxRadius: 130,
        color: '#EF4444',
        alpha: 1,
      });

      // Explosion fragments
      const palette = ['#EF4444', '#F97316', '#FBBF24', '#18181B', '#71717A', '#FFFFFF'];
      for (let i = 0; i < 45; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 4 + Math.random() * 9;
        particlesRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 3 + Math.random() * 6,
          color: palette[Math.floor(Math.random() * palette.length)],
          alpha: 1,
          decay: 0.025 + Math.random() * 0.03,
          gravity: 0.22,
          shape: Math.random() > 0.5 ? 'ember' : 'circle',
          angle: Math.random() * Math.PI * 2,
          angularVelocity: (Math.random() - 0.5) * 0.4,
        });
      }

      startLoop();
    },

    feverSparks: (count = 20) => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const palette = ['#EF4444', '#F97316', '#FBBF24', '#FB7185'];

      for (let i = 0; i < count; i++) {
        particlesRef.current.push({
          x: Math.random() * width,
          y: height - Math.random() * 80,
          vx: (Math.random() - 0.5) * 4,
          vy: -(3 + Math.random() * 5),
          size: 2.5 + Math.random() * 3.5,
          color: palette[Math.floor(Math.random() * palette.length)],
          alpha: 1,
          decay: 0.02 + Math.random() * 0.02,
          gravity: -0.05, // Float upwards!
          shape: 'ember',
          angle: Math.random() * Math.PI * 2,
          angularVelocity: (Math.random() - 0.5) * 0.2,
        });
      }

      startLoop();
    },

    celebrate: () => {
      const colors = ['#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4', '#FBBF24'];
      const width = window.innerWidth;
      const height = window.innerHeight;

      for (let i = 0; i < 90; i++) {
        const x = Math.random() * width;
        const y = Math.random() * (height * 0.4);
        const color = colors[Math.floor(Math.random() * colors.length)];
        const speed = 2 + Math.random() * 5;

        particlesRef.current.push({
          x,
          y,
          vx: (Math.random() - 0.5) * 6,
          vy: speed,
          size: 4 + Math.random() * 5,
          color,
          alpha: 1,
          decay: 0.008 + Math.random() * 0.012,
          gravity: 0.12,
          shape: 'confetti',
          angle: Math.random() * Math.PI * 2,
          angularVelocity: (Math.random() - 0.5) * 0.25,
        });
      }

      startLoop();
    },
  }));

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-30 h-full w-full"
    />
  );
});

ParticleCanvas.displayName = 'ParticleCanvas';
