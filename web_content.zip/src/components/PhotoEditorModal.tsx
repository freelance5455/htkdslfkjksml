import React, { useState, useRef, useEffect } from "react";
import {
  X,
  RotateCw,
  FlipHorizontal,
  Sliders,
  Sparkles,
  Check,
  Undo2,
  Image as ImageIcon,
  Type,
  Sun,
  Contrast,
  Palette,
} from "lucide-react";

export type ImageFilterKey =
  | "none"
  | "warm"
  | "cool"
  | "vibrant"
  | "vintage"
  | "bw";

interface PhotoEditorModalProps {
  isOpen: boolean;
  imageSrc: string | null;
  initialCaption?: string;
  onClose: () => void;
  onSave: (result: {
    dataUrl: string;
    caption: string;
  }) => void;
}

const PRESET_FILTERS: {
  key: ImageFilterKey;
  labelBn: string;
  cssFilter: string;
  previewBg: string;
}[] = [
  {
    key: "none",
    labelBn: "স্বাভাবিক",
    cssFilter: "none",
    previewBg: "from-slate-700 to-slate-900",
  },
  {
    key: "warm",
    labelBn: "উষ্ণ",
    cssFilter: "sepia(0.28) saturate(1.25) hue-rotate(-10deg)",
    previewBg: "from-amber-600 to-orange-800",
  },
  {
    key: "cool",
    labelBn: "স্নিগ্ধ",
    cssFilter: "hue-rotate(18deg) saturate(1.15) brightness(1.02)",
    previewBg: "from-sky-600 to-indigo-800",
  },
  {
    key: "vibrant",
    labelBn: "প্রাণবন্ত",
    cssFilter: "contrast(1.2) saturate(1.4) brightness(1.04)",
    previewBg: "from-rose-600 to-amber-700",
  },
  {
    key: "vintage",
    labelBn: "ভিন্টেজ",
    cssFilter: "sepia(0.55) contrast(1.15) brightness(0.95)",
    previewBg: "from-stone-600 to-amber-900",
  },
  {
    key: "bw",
    labelBn: "সাদাকালো",
    cssFilter: "grayscale(1) contrast(1.2)",
    previewBg: "from-neutral-700 to-neutral-900",
  },
];

export const PhotoEditorModal: React.FC<PhotoEditorModalProps> = ({
  isOpen,
  imageSrc,
  initialCaption = "",
  onClose,
  onSave,
}) => {
  const [activeTab, setActiveTab] = useState<"filters" | "adjust" | "caption">(
    "filters"
  );
  const [selectedFilter, setSelectedFilter] = useState<ImageFilterKey>("none");
  const [brightness, setBrightness] = useState(100); // 50 to 150
  const [contrast, setContrast] = useState(100); // 50 to 150
  const [saturation, setSaturation] = useState(100); // 0 to 200
  const [rotation, setRotation] = useState(0); // 0, 90, 180, 270
  const [isFlippedH, setIsFlippedH] = useState(false);
  const [caption, setCaption] = useState(initialCaption);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCaption(initialCaption || "");
    }
  }, [isOpen, initialCaption]);

  if (!isOpen || !imageSrc) return null;

  const handleReset = () => {
    setSelectedFilter("none");
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setRotation(0);
    setIsFlippedH(false);
    setCaption("");
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const handleFlip = () => {
    setIsFlippedH((prev) => !prev);
  };

  // Get combined CSS filter string for live preview
  const getCombinedFilterString = () => {
    const filterDef = PRESET_FILTERS.find((f) => f.key === selectedFilter);
    const presetCss = filterDef && filterDef.cssFilter !== "none" ? filterDef.cssFilter : "";
    return `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) ${presetCss}`.trim();
  };

  // Render to canvas and export final edited image
  const handleApplyAndSave = async () => {
    if (!imageSrc) return;
    setIsProcessing(true);

    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = imageSrc;

      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas context unavailable");

      const isRotated90or270 = rotation === 90 || rotation === 270;
      canvas.width = isRotated90or270 ? img.naturalHeight : img.naturalWidth;
      canvas.height = isRotated90or270 ? img.naturalWidth : img.naturalHeight;

      ctx.save();

      // Translate and rotate around center
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      if (isFlippedH) {
        ctx.scale(-1, 1);
      }

      // Apply CSS filters on context
      ctx.filter = getCombinedFilterString();

      // Draw original image centered
      ctx.drawImage(
        img,
        -img.naturalWidth / 2,
        -img.naturalHeight / 2,
        img.naturalWidth,
        img.naturalHeight
      );

      ctx.restore();

      const exportedDataUrl = canvas.toDataURL("image/jpeg", 0.92);
      onSave({
        dataUrl: exportedDataUrl,
        caption: caption.trim(),
      });
      onClose();
    } catch (err) {
      console.error("Error exporting edited image:", err);
      // Fallback: save original if canvas fails
      onSave({
        dataUrl: imageSrc,
        caption: caption.trim(),
      });
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="photo-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl border border-slate-700/80 bg-[#0E1528] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/90 px-5 py-3.5 bg-[#090E1D]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm">
              <ImageIcon className="h-4 w-4" />
            </div>
            <div>
              <h2
                id="photo-editor-title"
                className="text-sm font-semibold text-slate-100 flex items-center gap-2"
              >
                <span>ছবি এডিটর</span>
                <span className="rounded border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.2 text-[10px] font-mono text-amber-300 font-bold uppercase">
                  Photo Editor
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                ছবিতে ফিল্টার, উজ্জ্বলতা ও ক্যাপশন যোগ করে Thunder-কে পাঠাও
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleReset}
              title="সব পরিবর্তন রিসেট করো"
              className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
            >
              <Undo2 className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">রিসেট</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="বন্ধ করো"
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Live Canvas / Image Preview Area */}
        <div className="relative flex-1 min-h-[240px] max-h-[46vh] bg-[#070B16] flex items-center justify-center p-4 overflow-hidden select-none">
          <div className="relative max-h-full max-w-full flex items-center justify-center transition-transform duration-200">
            <img
              src={imageSrc}
              alt="সম্পাদনার পূর্বরূপ"
              style={{
                filter: getCombinedFilterString(),
                transform: `rotate(${rotation}deg) scaleX(${isFlippedH ? -1 : 1})`,
                maxHeight: "40vh",
                maxWidth: "100%",
                objectFit: "contain",
              }}
              className="rounded-xl shadow-2xl transition-all duration-150"
            />
          </div>

          {/* Floating Transform Bar on top of image */}
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-xl border border-slate-700/80 bg-slate-950/75 backdrop-blur-md px-2.5 py-1.5 shadow-lg">
            <button
              type="button"
              onClick={handleRotate}
              title="ঘড়ির কাঁটার দিকে ৯০° ঘোরান"
              className="flex items-center gap-1 rounded-lg p-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-300 transition-colors"
            >
              <RotateCw className="h-4 w-4" />
              <span className="text-[11px] font-mono">{rotation}°</span>
            </button>
            <span className="h-4 w-[1px] bg-slate-800" />
            <button
              type="button"
              onClick={handleFlip}
              title="আনুভূমিকভাবে উল্টান (Flip Horizontal)"
              className={`rounded-lg p-1.5 text-xs transition-colors ${
                isFlippedH
                  ? "bg-amber-500/20 text-amber-300"
                  : "text-slate-300 hover:bg-slate-800 hover:text-amber-300"
              }`}
            >
              <FlipHorizontal className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-y border-slate-800/80 bg-[#0B1020] px-4 py-1.5 text-xs">
          {[
            { id: "filters", label: "ফিল্টার (Filters)", icon: Sparkles },
            { id: "adjust", label: "আলো ও রঙ (Adjust)", icon: Sliders },
            { id: "caption", label: "ক্যাপশন (Caption)", icon: Type },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex flex-1 items-center justify-center gap-1.5 py-2 font-medium rounded-xl transition-colors ${
                  active
                    ? "bg-amber-500/15 text-amber-300 border border-amber-500/30"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Panel */}
        <div className="p-4 bg-[#0E1528] space-y-4">
          {/* TAB 1: FILTERS */}
          {activeTab === "filters" && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400">
                  পছন্দের শৈল্পিক ফিল্টার নির্বাচন করো:
                </span>
                <span className="text-xs font-medium text-amber-300">
                  {PRESET_FILTERS.find((f) => f.key === selectedFilter)?.labelBn}
                </span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {PRESET_FILTERS.map((f) => {
                  const isSelected = selectedFilter === f.key;
                  return (
                    <button
                      key={f.key}
                      type="button"
                      onClick={() => setSelectedFilter(f.key)}
                      className={`flex flex-col items-center gap-1.5 rounded-xl border p-2 transition-all text-xs ${
                        isSelected
                          ? "border-amber-500 bg-amber-500/15 text-amber-200 ring-1 ring-amber-500/40"
                          : "border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                      }`}
                    >
                      <div
                        className={`h-9 w-full rounded-lg bg-gradient-to-tr ${f.previewBg} flex items-center justify-center`}
                      >
                        {isSelected && <Check className="h-4 w-4 text-white" />}
                      </div>
                      <span className="font-medium text-[11px] truncate">
                        {f.labelBn}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: ADJUST (Brightness, Contrast, Saturation) */}
          {activeTab === "adjust" && (
            <div className="space-y-3.5">
              {/* Brightness */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <Sun className="h-3.5 w-3.5 text-amber-400" />
                    <span>উজ্জ্বলতা (Brightness)</span>
                  </span>
                  <span className="font-mono text-amber-300 tabular-nums">
                    {brightness}%
                  </span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="150"
                  value={brightness}
                  onChange={(e) => setBrightness(parseInt(e.target.value, 10))}
                  className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-amber-500"
                />
              </div>

              {/* Contrast */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <Contrast className="h-3.5 w-3.5 text-amber-400" />
                    <span>কনট্রাস্ট (Contrast)</span>
                  </span>
                  <span className="font-mono text-amber-300 tabular-nums">
                    {contrast}%
                  </span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="150"
                  value={contrast}
                  onChange={(e) => setContrast(parseInt(e.target.value, 10))}
                  className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-amber-500"
                />
              </div>

              {/* Saturation */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <Palette className="h-3.5 w-3.5 text-amber-400" />
                    <span>রঙের গভীরতা (Saturation)</span>
                  </span>
                  <span className="font-mono text-amber-300 tabular-nums">
                    {saturation}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={saturation}
                  onChange={(e) => setSaturation(parseInt(e.target.value, 10))}
                  className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-amber-500"
                />
              </div>
            </div>
          )}

          {/* TAB 3: CAPTION */}
          {activeTab === "caption" && (
            <div>
              <label
                htmlFor="photo-caption"
                className="block text-xs font-medium text-slate-300 mb-1.5"
              >
                ছবি সম্পর্কে কিছু লিখে দাও (ঐচ্ছিক):
              </label>
              <textarea
                id="photo-caption"
                rows={2}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="যেমন: এই সুন্দর জায়গাটা দেখে তোর কথা মনে পড়লো ভাই..."
                className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between border-t border-slate-800/90 bg-[#090E1D] px-5 py-3">
          <span className="text-[11px] text-slate-400">
            {isProcessing ? "ছবি প্রস্তুত হচ্ছে..." : "ছবি এডিট সম্পন্ন করে সংযুক্ত করো"}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleApplyAndSave}
              disabled={isProcessing}
              className="flex items-center gap-1.5 rounded-xl bg-amber-500 px-5 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors shadow-[0_0_12px_rgba(245,158,11,0.25)]"
            >
              <Check className="h-3.5 w-3.5" />
              <span>{isProcessing ? "প্রসেসিং..." : "সংযুক্ত করো"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
