import { useState } from "react";
import { measureRefresh } from "@/lib/device";
import { formatWhen } from "@/lib/model";
import { useAppStore } from "@/lib/store";
import { Button, Notice } from "@/components/ui";

export function RefreshMeasure() {
  const sample = useAppStore((state) => state.refreshSample);
  const setRefresh = useAppStore((state) => state.setRefresh);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [when, setWhen] = useState<string | null>(null);

  async function run() {
    setBusy(true);
    setError(null);
    const result = await measureRefresh();
    setBusy(false);
    if (!result) {
      setError("Sample failed. Keep this tab in the foreground and try again.");
      return;
    }
    setRefresh(result);
    setWhen(formatWhen(result.at));
  }

  const stamped = sample ? (when ?? formatWhen(sample.at)) : null;

  return (
    <div>
      <p className="text-xs font-semibold tracking-widest text-faint uppercase">This page</p>
      <p className="font-display text-4xl font-semibold tabular-nums">{sample ? `${sample.displayHz} Hz` : "—"}</p>
      <p className="mt-1 text-sm text-muted">
        {sample
          ? sample.snapped
            ? `Estimated display refresh, snapped to a common rate. Raw sample ${sample.rawHz} Hz from ${sample.frames} frames.`
            : `Rough page estimate ${sample.rawHz} Hz from ${sample.frames} frames. It did not sit on a common panel rate.`
          : "Not measured yet. This does not read the game."}
      </p>
      {stamped && sample ? <p className="mt-1 text-xs text-faint">Sampled {stamped}. Source: requestAnimationFrame on this page.</p> : null}
      <div className="mt-4">
        <Button onClick={() => void run()} disabled={busy}>
          {busy ? "Measuring…" : sample ? "Measure again" : "Measure this page"}
        </Button>
      </div>
      {busy ? <p className="mt-2 text-sm text-muted">Keep this tab visible for about a second.</p> : null}
      {error ? <div className="mt-2"><Notice tone="warn">{error}</Notice></div> : null}
    </div>
  );
}
