/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Volume2, Zap, Radio, Bell, Disc, Mic, RotateCcw, Users } from 'lucide-react';
import { audioEngine } from '../services/audioEngine';

interface PadConfig {
  id: 'airhorn' | 'laser' | 'scratch' | 'drop808' | 'siren' | 'sunny_voice' | 'rewind' | 'cheer';
  name: string;
  subtext: string;
  key: string;
  icon: React.ReactNode;
  colorClass: string;
  glowClass: string;
}

export const DJSoundboard: React.FC = () => {
  const [activePad, setActivePad] = useState<string | null>(null);

  const pads: PadConfig[] = [
    {
      id: 'airhorn',
      name: 'AIRHORN',
      subtext: 'Rave Blast',
      key: '1',
      icon: <Volume2 className="w-5 h-5" />,
      colorClass: 'border-amber-400 text-amber-300 bg-amber-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(251,191,36,0.6)] bg-amber-500/40 text-white',
    },
    {
      id: 'laser',
      name: 'LASER ZAP',
      subtext: 'Electro Beam',
      key: '2',
      icon: <Zap className="w-5 h-5" />,
      colorClass: 'border-cyan-400 text-cyan-300 bg-cyan-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(0,240,255,0.6)] bg-cyan-500/40 text-white',
    },
    {
      id: 'scratch',
      name: 'SCRATCH',
      subtext: 'Vinyl Zip',
      key: '3',
      icon: <Disc className="w-5 h-5" />,
      colorClass: 'border-purple-400 text-purple-300 bg-purple-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(176,38,255,0.6)] bg-purple-500/40 text-white',
    },
    {
      id: 'drop808',
      name: '808 DROP',
      subtext: 'Sub Bass Boom',
      key: '4',
      icon: <Radio className="w-5 h-5" />,
      colorClass: 'border-red-500 text-red-400 bg-red-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(239,68,68,0.7)] bg-red-500/40 text-white',
    },
    {
      id: 'siren',
      name: 'SIREN',
      subtext: 'Alarm Buildup',
      key: '5',
      icon: <Bell className="w-5 h-5" />,
      colorClass: 'border-orange-500 text-orange-400 bg-orange-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(249,115,22,0.6)] bg-orange-500/40 text-white',
    },
    {
      id: 'sunny_voice',
      name: 'DJ SUNNY',
      subtext: 'Voice Drop',
      key: '6',
      icon: <Mic className="w-5 h-5" />,
      colorClass: 'border-blue-400 text-blue-300 bg-blue-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(59,130,246,0.7)] bg-blue-500/40 text-white',
    },
    {
      id: 'rewind',
      name: 'REWIND',
      subtext: 'Tape Spin',
      key: '7',
      icon: <RotateCcw className="w-5 h-5" />,
      colorClass: 'border-pink-500 text-pink-400 bg-pink-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(236,72,153,0.6)] bg-pink-500/40 text-white',
    },
    {
      id: 'cheer',
      name: 'CHEER',
      subtext: 'Crowd Hype',
      key: '8',
      icon: <Users className="w-5 h-5" />,
      colorClass: 'border-emerald-400 text-emerald-300 bg-emerald-950/20',
      glowClass: 'shadow-[0_0_20px_rgba(52,211,153,0.6)] bg-emerald-500/40 text-white',
    },
  ];

  const triggerPad = (id: PadConfig['id']) => {
    setActivePad(id);
    audioEngine.playSFX(id);
    setTimeout(() => {
      setActivePad((curr) => (curr === id ? null : curr));
    }, 180);
  };

  return (
    <div className="p-4 rounded-3xl bg-[#0c0d17]/95 border border-cyan-500/25 shadow-[0_10px_35px_rgba(0,0,0,0.8)]">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-[12px] font-bold tracking-widest text-cyan-300 font-dj uppercase">
            DJ SAMPLER &amp; SOUND PADS
          </span>
        </div>
        <span className="text-[10px] text-zinc-500 font-mono tracking-wider">
          INSTANT TRIGGER FX
        </span>
      </div>

      {/* 8 Drum Pads Grid */}
      <div className="grid grid-cols-4 gap-2.5">
        {pads.map((pad) => {
          const isTriggered = activePad === pad.id;
          return (
            <button
              key={pad.id}
              onClick={() => triggerPad(pad.id)}
              className={`relative flex flex-col items-center justify-center py-3 px-2 rounded-2xl border-2 transition-all duration-100 select-none cursor-pointer active:scale-95 ${
                pad.colorClass
              } ${isTriggered ? pad.glowClass + ' scale-95' : 'hover:brightness-125'}`}
            >
              {/* Keyboard index tag */}
              <span className="absolute top-1 right-2 text-[8px] font-mono font-bold text-zinc-400 opacity-60">
                {pad.key}
              </span>

              {/* Icon */}
              <div className={`mb-1 transition-transform ${isTriggered ? 'scale-125' : ''}`}>
                {pad.icon}
              </div>

              {/* Title & Subtitle */}
              <span className="text-[10px] font-extrabold tracking-wider font-dj uppercase leading-tight text-center">
                {pad.name}
              </span>
              <span className="text-[8px] opacity-70 font-mono leading-none mt-0.5 text-center">
                {pad.subtext}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
