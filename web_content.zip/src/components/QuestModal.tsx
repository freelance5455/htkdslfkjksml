import React from 'react';
import { Check, Compass, X } from 'lucide-react';
import { QUESTS } from '../game/worldData';
import { PlayerStats, Quest } from '../types/game';

interface QuestModalProps {
  stats: PlayerStats;
  activeQuest: Quest | null;
  onClose: () => void;
  onAcceptQuest: (quest: Quest) => void;
}

export const QuestModal: React.FC<QuestModalProps> = ({
  stats,
  activeQuest,
  onClose,
  onAcceptQuest,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Grand Sea Bounty Board</h2>
              <p className="text-xs text-slate-400">Accept pirate quests and boss suppression missions</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-3">
          {QUESTS.map((quest) => {
            const isCurrent = activeQuest?.id === quest.id;
            const levelTooLow = stats.level < quest.minLevel;

            return (
              <div
                key={quest.id}
                className={`border rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                  isCurrent
                    ? 'bg-amber-950/40 border-amber-500/60'
                    : levelTooLow
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                    : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{quest.title}</span>
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                      Req. Lv. {quest.minLevel}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 mt-1">
                    Target: Defeat {quest.targetCount}x {quest.targetEnemyType.replace('_', ' ')}
                  </div>
                  <div className="mt-1 flex items-center gap-3 text-xs font-mono">
                    <span className="text-emerald-400 font-bold">+{quest.rewardBeli.toLocaleString()} Beli</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-amber-400 font-bold">+{quest.rewardExp.toLocaleString()} EXP</span>
                  </div>
                </div>

                <div className="shrink-0">
                  {isCurrent ? (
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 bg-amber-950/60 border border-amber-600/60 px-3 py-1.5 rounded-lg">
                      <Check className="w-3.5 h-3.5" />
                      <span>In Progress ({activeQuest?.currentCount}/{quest.targetCount})</span>
                    </div>
                  ) : levelTooLow ? (
                    <span className="text-xs font-mono text-slate-500 px-3 py-1.5 block">
                      Locked (Lv. {quest.minLevel})
                    </span>
                  ) : (
                    <button
                      onClick={() => onAcceptQuest(quest)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-transform active:scale-95 cursor-pointer"
                    >
                      Accept Bounty
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
