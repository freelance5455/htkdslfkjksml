import React, { useState } from 'react';
import { Video, Sparkles, Copy, Check, Bookmark, Film, Clapperboard } from 'lucide-react';
import confetti from 'canvas-confetti';

interface VideoTabProps {
  onSave: (type: 'video', title: string, subtitle: string, content: string) => void;
  showToast: (msg: string) => void;
}

export const VideoTab: React.FC<VideoTabProps> = ({ onSave, showToast }) => {
  const [concept, setConcept] = useState('');
  const [duration, setDuration] = useState('3 Scenes (15s Reel / TikTok)');
  const [style, setStyle] = useState(
    'Cinematic 4K, 35mm anamorphic lens, warm golden hour, slow motion'
  );
  const [isPlanning, setIsPlanning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const presets = [
    {
      title: '✨ Malawian Textile Runway',
      concept:
        'An ambitious designer showcasing vibrant handwoven heritage fabrics under golden sunset lights in Lilongwe, celebrating modern African fashion with slow-motion fabric flow.',
      duration: '3 Scenes (15s Reel / TikTok)',
      style: 'Cinematic 4K, 35mm anamorphic lens, warm golden hour, slow motion',
    },
    {
      title: '🎶 Blantyre Vinyl Discovery',
      concept:
        'A passionate young beatmaker flipping through dusty vintage vinyl crates in a bustling Blantyre market, finding a 1970s African funk record and smiling as the needle drops.',
      duration: '5 Scenes (30s Commercial)',
      style: 'Authentic documentary style, handheld 16mm film, natural sunlight',
    },
    {
      title: '☕ Luxury Mountain Coffee',
      concept:
        'Cinematic journey of coffee cherries harvested on the misty slopes of Mount Mulanje, roasted in bronze drums, and poured into porcelain cups overlooking rolling tea estates.',
      duration: '5 Scenes (30s Commercial)',
      style: 'High-fashion studio editorial, dark moody vignette, rim lighting',
    },
  ];

  const handlePlanVideo = async () => {
    if (!concept.trim()) {
      showToast('Please outline your video concept');
      return;
    }

    setIsPlanning(true);
    setResult(null);
    setSaved(false);

    try {
      const res = await fetch('/api/video-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ concept, duration, style }),
      });
      const data = await res.json();

      if (data.result) {
        setResult(data.result);
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 },
            colors: ['#fae48c', '#d4af37', '#e11d48'],
          });
        } catch {
          // ignore
        }
      } else {
        showToast(data.error || 'Failed to generate video storyboard');
      }
    } catch {
      showToast('Network error while planning video');
    } finally {
      setIsPlanning(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    showToast('Video storyboard copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const titleMatch = result.match(/^#\s*(.+)$/m);
    const title = titleMatch ? titleMatch[1].replace(/[*#]/g, '').trim() : 'Video Storyboard';
    onSave('video', title, `${duration} • ${style.slice(0, 30)}...`, result);
    setSaved(true);
    showToast('Saved to your vault!');
  };

  return (
    <div className="p-3.5 space-y-4 max-w-2xl mx-auto">
      {/* Title Card */}
      <div className="bg-[#1b0a33] border border-[#d4af37]/35 rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#d4af37]/15 to-transparent rounded-bl-full pointer-events-none" />

        <div className="flex items-center gap-2 mb-1">
          <Clapperboard className="w-5 h-5 text-[#fae48c]" />
          <h2 className="royal-heading text-lg font-bold gold-gradient-text">
            Video Story Planner
          </h2>
        </div>
        <p className="text-xs text-[#bfaad4] leading-relaxed">
          Transform video ideas into cinematic treatments with character tokens, camera framing, and ready-to-copy prompts for Sora, Runway Gen-3, Kling, and Pika.
        </p>

        {/* Quick Presets */}
        <div className="mt-3 pt-3 border-t border-[#d4af37]/15">
          <label className="text-[10px] tracking-wider uppercase text-[#d4af37] font-semibold block mb-1.5">
            Story Presets
          </label>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setConcept(preset.concept);
                  setDuration(preset.duration);
                  setStyle(preset.style);
                }}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-[#250f44] border border-[#d4af37]/25 hover:border-[#fae48c] text-[11px] text-[#fae48c] text-left transition-all active:scale-95"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        {/* Inputs */}
        <div className="mt-3.5 space-y-3">
          <div>
            <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
              Core Concept or Plot
            </label>
            <textarea
              value={concept}
              onChange={(e) => setConcept(e.target.value)}
              rows={3}
              placeholder="e.g. An ambitious designer showcasing handwoven heritage fabrics under golden sunset lights in Blantyre..."
              className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none placeholder-[#8771a3] transition-colors resize-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
                Duration / Scene Scope
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none transition-colors"
              >
                <option value="3 Scenes (15s Reel / TikTok)">3 Scenes (15s Reel / TikTok)</option>
                <option value="5 Scenes (30s Commercial)">5 Scenes (30s Commercial)</option>
                <option value="8 Scenes (60s Cinematic Narrative)">8 Scenes (60s Short Film)</option>
                <option value="12 Scenes (90s Music Video Sequence)">12 Scenes (90s Music Video)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
                Cinematic Style
              </label>
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none transition-colors"
              >
                <option value="Cinematic 4K, 35mm anamorphic lens, warm golden hour, slow motion">
                  Cinematic 4K Golden Hour
                </option>
                <option value="Vibrant Afro-futuristic neon, shallow depth of field, cyberpunk bokeh">
                  Afro-Futuristic Neon
                </option>
                <option value="Authentic documentary style, handheld 16mm film, natural sunlight">
                  Authentic 16mm Documentary
                </option>
                <option value="High-fashion studio editorial, dark moody vignette, rim lighting">
                  High-Fashion Luxury Studio
                </option>
                <option value="Aerial drone establishing shots, cinematic hyperlapse, epic scale">
                  Epic Aerial Drone
                </option>
              </select>
            </div>
          </div>

          <button
            onClick={handlePlanVideo}
            disabled={isPlanning || !concept.trim()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#fae48c] via-[#d4af37] to-[#8d6f1a] text-[#120422] font-bold text-sm tracking-wide shadow-[0_3px_15px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {isPlanning ? 'Directing Scenes & Framing...' : 'Plan Video Scenes'}
          </button>
        </div>
      </div>

      {/* Output Storyboard */}
      {result && (
        <div className="bg-[#18082f] border border-[#d4af37]/40 rounded-2xl p-4 shadow-2xl space-y-3 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-[#d4af37]/20 pb-3 flex-wrap gap-2">
            <span className="text-xs uppercase font-bold tracking-widest gold-gradient-text flex items-center gap-1.5">
              <Film className="w-4 h-4 text-[#fae48c]" />
              Production Storyboard & AI Prompts
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#240e45] text-xs text-[#fae48c] border border-[#d4af37]/30 hover:bg-[#30125c] transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy All'}</span>
              </button>

              <button
                onClick={handleSave}
                disabled={saved}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#d4af37] text-xs text-[#120422] font-bold hover:brightness-110 transition-colors disabled:opacity-60"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{saved ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>

          <div className="text-[13px] leading-relaxed text-[#eee4f5] whitespace-pre-wrap font-sans bg-[#110424] p-3.5 rounded-xl border border-[#d4af37]/15 overflow-x-auto max-h-[520px] overflow-y-auto">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};
