import React, { useState } from 'react';
import { Play, Clock, User, CheckCircle, ExternalLink, Sparkles } from 'lucide-react';
import { ChapterData, BIOLOGY_CHAPTERS } from '../data/biologyData';

interface VideoTabProps {
  onSelectChapterVideo: (chapter: ChapterData) => void;
}

export const VideoTab: React.FC<VideoTabProps> = ({ onSelectChapterVideo }) => {
  const [selectedVideoUrl, setSelectedVideoUrl] = useState<string | null>(null);
  const [activeVideoTitle, setActiveVideoTitle] = useState<string>('');

  const featuredVideos = [
    {
      id: 'f1',
      title: 'जीव जगत (The Living World) - One Shot NCERT Revision',
      chapter: 'अध्याय 1',
      duration: '45 मिनट',
      teacher: 'डॉ. वी. के. शर्मा (NEET विशेषज्ञ)',
      views: '1.2 लाख दृश्य',
      tag: 'अति महत्वपूर्ण',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['सजीव के लक्षण', 'द्विनाम नामकरण', 'वर्गिकी पदानुक्रम', 'NEET PYQ हल']
    },
    {
      id: 'f2',
      title: 'पाँच जगत वर्गीकरण (Whittaker 5 Kingdom Classification)',
      chapter: 'अध्याय 2',
      duration: '52 मिनट',
      teacher: 'प्रो. अर्चना सिंह',
      views: '98 हज़ार दृश्य',
      tag: 'NEET Special',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['मोनेरा व जीवाणु', 'प्रोटिस्टा जगत', 'कवक के वर्ग', 'वायरस एवं विरोइड']
    },
    {
      id: 'f3',
      title: 'कोशिका: जीवन की इकाई (Cell Theory & Organelles 3D)',
      chapter: 'अध्याय 8',
      duration: '1 घंटा 2 मिनट',
      teacher: 'डॉ. वी. के. शर्मा',
      views: '2.5 लाख दृश्य',
      tag: 'सर्वाधिक लोकप्रिय',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['फ्लूइड मोज़ेक मॉडल', 'माइटोकॉन्ड्रिया व क्लोरोप्लास्ट', 'राइबोसोम 70S/80S', 'केंद्रक संरचना']
    },
    {
      id: 'f4',
      title: 'कोशिका चक्र एवं विभाजन (Mitosis & Meiosis Crossing Over)',
      chapter: 'अध्याय 10',
      duration: '48 मिनट',
      teacher: 'डॉ. राजेश कुमार',
      views: '84 हज़ार दृश्य',
      tag: 'हाई-यील्ड',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['S-प्रावस्था DNA 2C→4C', 'प्रोफेज I की 5 अवस्थाएँ', 'जीन विनिमय (Recombinase)', 'सूत्री विभाजन']
    },
    {
      id: 'f5',
      title: 'उच्च पादपों में प्रकाश-संश्लेषण (Light Reaction & Calvin Cycle)',
      chapter: 'अध्याय 11',
      duration: '58 मिनट',
      teacher: 'प्रो. अर्चना सिंह',
      views: '1.1 लाख दृश्य',
      tag: 'कॉन्सेप्ट बूस्टर',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['Z-स्कीम व जल अपघटन', 'केल्विन C3 चक्र', 'C4 पथ व क्रांज शारीरिकी', 'प्रकाश-श्वसन']
    },
    {
      id: 'f6',
      title: 'मानव हृदय एवं दोहरा परिसंचरण (ECG & Double Circulation)',
      chapter: 'अध्याय 15',
      duration: '51 मिनट',
      teacher: 'डॉ. वी. के. शर्मा',
      views: '1.4 लाख दृश्य',
      tag: 'NEET PYQ',
      youtubeEmbedId: 'dQw4w9WgXcQ',
      topics: ['SAN पेसमेकर', 'कार्डियक चक्र 0.8s', 'ECG P-QRS-T तरंगें', 'Rh असंगतता']
    }
  ];

  const playVideo = (v: typeof featuredVideos[0]) => {
    setSelectedVideoUrl(v.youtubeEmbedId);
    setActiveVideoTitle(v.title);
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-800 font-devanagari">
          कक्षा 11 जीव विज्ञान वीडियो कक्षाएँ
        </h2>
        <p className="text-xs text-slate-500">
          अध्यायवार हिंदी वीडियो लेक्चर्स, 3D एनिमेशन एवं NEET गाइडेंस
        </p>
      </div>

      {/* Video Player Box if selected */}
      {selectedVideoUrl && (
        <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-lg border border-slate-800 p-2 text-white space-y-2">
          <div className="relative aspect-video bg-black rounded-xl overflow-hidden flex flex-col items-center justify-center">
            {/* Simulation of Educational Video Lecture Player */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900 to-teal-950 flex flex-col items-center justify-center p-4 text-center">
              <span className="text-3xl mb-2">🎬</span>
              <p className="text-xs font-bold text-teal-300 font-devanagari line-clamp-1">
                {activeVideoTitle}
              </p>
              <p className="text-[11px] text-slate-300 mt-1">
                फुल HD हिंदी लेक्चर तैयार है
              </p>
              <div className="mt-3 flex items-center gap-2">
                <a
                  href={`https://www.youtube.com/results?search_query=${encodeURIComponent(activeVideoTitle)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-1.5 rounded-full bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  YouTube पर देखें ↗
                </a>
                <button
                  onClick={() => setSelectedVideoUrl(null)}
                  className="px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white text-xs"
                >
                  बंद करें
                </button>
              </div>
            </div>
          </div>
          <div className="px-2 py-1 flex items-center justify-between text-[11px] text-slate-400">
            <span>HD 1080p · हिंदी भाषा</span>
            <span className="text-teal-400 font-medium">ToppersCBSE & NCERT</span>
          </div>
        </div>
      )}

      {/* Video Lecture Cards List */}
      <div className="space-y-3">
        {featuredVideos.map((video) => (
          <div
            key={video.id}
            className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-sm hover:shadow transition-all group"
          >
            <div className="flex items-start gap-3">
              {/* Thumbnail with Play Overlay */}
              <button
                onClick={() => playVideo(video)}
                className="relative w-28 h-20 rounded-xl bg-gradient-to-br from-teal-700 to-cyan-900 flex items-center justify-center text-white shrink-0 overflow-hidden shadow-sm group-hover:scale-[1.02] transition-transform cursor-pointer"
              >
                <div className="w-9 h-9 rounded-full bg-white/25 backdrop-blur-xs flex items-center justify-center group-hover:bg-red-600 transition-colors">
                  <Play className="w-4 h-4 fill-white ml-0.5" />
                </div>
                <span className="absolute bottom-1 right-1 bg-black/80 text-[10px] text-white px-1.5 py-0.5 rounded font-mono">
                  {video.duration}
                </span>
              </button>

              {/* Video Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full">
                    {video.chapter}
                  </span>
                  <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                    {video.tag}
                  </span>
                </div>

                <h3
                  onClick={() => playVideo(video)}
                  className="text-xs font-bold text-slate-900 font-devanagari line-clamp-2 leading-snug group-hover:text-[#00838f] cursor-pointer"
                >
                  {video.title}
                </h3>

                <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  <span>{video.teacher}</span>
                </p>
              </div>
            </div>

            {/* Key topics badges */}
            <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap gap-1.5">
              {video.topics.map((t, i) => (
                <span key={i} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-medium">
                  {t}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
