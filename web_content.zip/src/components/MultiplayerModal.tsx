import React, { useState } from 'react';
import { X, Wifi, Bluetooth, Radio, Play, Users, CheckCircle } from 'lucide-react';
import { multiplayerManager } from '../game/multiplayer';

interface MultiplayerModalProps {
  onStartMultiplayerRace: (roomCode: string, mode: 'local_lan' | 'bluetooth' | 'online_room') => void;
  onClose: () => void;
}

export const MultiplayerModal: React.FC<MultiplayerModalProps> = ({
  onStartMultiplayerRace,
  onClose
}) => {
  const [mode, setMode] = useState<'local_lan' | 'bluetooth' | 'online_room'>('local_lan');
  const [playerName, setPlayerName] = useState('البطل السريع');
  const [roomCode, setRoomCode] = useState('777');
  const [isReady, setIsReady] = useState(false);

  const handleConnect = () => {
    setIsReady(true);
    multiplayerManager.connectRoom(roomCode, playerName, mode);
  };

  const handleLaunchGame = () => {
    onStartMultiplayerRace(roomCode, mode);
    onClose();
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-lg shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-xl">
              🏎️
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">سباق التحدي مع الأصدقاء</h2>
              <div className="text-xs text-slate-400">تواصل عبر البلوتوث أو الشبكة المحلية وتحدَّ صديقك في نفس الشارع!</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => { setMode('local_lan'); setIsReady(false); }}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                mode === 'local_lan'
                  ? 'border-indigo-400 bg-indigo-950/40 text-white font-extrabold shadow-md'
                  : 'border-slate-800 bg-slate-950 text-slate-400'
              }`}
            >
              <Wifi className="w-5 h-5 text-indigo-400 mb-1" />
              <span className="text-xs">شبكة محلية (LAN)</span>
            </button>

            <button
              onClick={() => { setMode('bluetooth'); setIsReady(false); }}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                mode === 'bluetooth'
                  ? 'border-blue-400 bg-blue-950/40 text-white font-extrabold shadow-md'
                  : 'border-slate-800 bg-slate-950 text-slate-400'
              }`}
            >
              <Bluetooth className="w-5 h-5 text-blue-400 mb-1" />
              <span className="text-xs">بلوتوث مجاور</span>
            </button>

            <button
              onClick={() => { setMode('online_room'); setIsReady(false); }}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                mode === 'online_room'
                  ? 'border-amber-400 bg-amber-950/40 text-white font-extrabold shadow-md'
                  : 'border-slate-800 bg-slate-950 text-slate-400'
              }`}
            >
              <Radio className="w-5 h-5 text-amber-400 mb-1" />
              <span className="text-xs">غرفة أونلاين</span>
            </button>
          </div>

          {/* Form Fields */}
          <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسمك في السباق:</label>
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-400 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">رمز الغرفة / القناة المشتركة:</label>
              <input
                type="text"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value)}
                placeholder="أدخل رمز مثل: 777"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-400 font-bold"
              />
              <div className="text-[11px] text-slate-400 mt-1">
                اجعل صديقك يدخل نفس الرمز على جهازه أو في تبويبة أخرى للانضمام لنفس السباق فوراً!
              </div>
            </div>
          </div>

          {/* Connection Status Box */}
          {isReady && (
            <div className="bg-emerald-950/30 border border-emerald-500/40 rounded-2xl p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <div>
                  <div className="text-xs font-black text-emerald-300">تم تجهيز الاتصال بنجاح! 🏃‍♂️</div>
                  <div className="text-[11px] text-slate-400">سترى صديقك يركض بجانبك في الشارع ثلاثي الأبعاد!</div>
                </div>
              </div>
              <Users className="w-5 h-5 text-indigo-400" />
            </div>
          )}

          {/* Actions */}
          <div className="pt-2">
            {!isReady ? (
              <button
                onClick={handleConnect}
                className="w-full py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg cursor-pointer"
              >
                <Radio className="w-4 h-4" />
                <span>إنشاء / الانضمام لغرفة السباق</span>
              </button>
            ) : (
              <button
                onClick={handleLaunchGame}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-base flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl cursor-pointer animate-pulse"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>انطلاق السباق الثنائي الآن!</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
