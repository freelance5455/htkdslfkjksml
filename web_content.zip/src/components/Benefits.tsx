import { Check, MonitorPlay, RotateCw, Scan, Type, Users, X } from "lucide-react";

const ROWS = [
  { label: "Precio", tvlo3: "0 € — usa el móvil que ya tienes", box: "60–250 € + mando + cables", win: true },
  { label: "Instalación", tvlo3: "2 minutos · APK firmada", box: "HDMI, corriente, red Wi-Fi, mando", win: true },
  { label: "Actualizaciones", tvlo3: "Automáticas dentro de la app", box: "Firmware manual del fabricante", win: true },
  { label: "Portabilidad", tvlo3: "En tu bolsillo, siempre 16:9", box: "Atado a un televisor concreto", win: true },
  { label: "Offline", tvlo3: "Sí — biblioteca local + descargas", box: "Depende del launcher del box", win: true },
  { label: "Legalidad", tvlo3: "Solo fuentes con licencia / autorizadas", box: "Según modelo, tienda y vendedor", win: true },
];

const PILLARS = [
  { icon: Scan, text: "16:9 panorámico forzado" },
  { icon: RotateCw, text: "Orientación bloqueada" },
  { icon: Type, text: "Alto contraste y letra grande" },
  { icon: Users, text: "Perfiles para toda la casa" },
];

export default function Benefits() {
  return (
    <section id="ventajas" className="scroll-mt-28 mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div>
          <p className="eyebrow">Sin hardware añadido</p>
          <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
            ¿Por qué otro<br /><span className="grad-text">TV Box más?</span>
          </h2>
          <p className="mt-4 max-w-lg text-lg leading-relaxed text-slate-300">
            Un TV Box tradicional es una caja más en el salón, otro mando perdido en el sofá y otro firmware
            congelado. TV LO3 convierte el hardware que ya tienes — tu Android — en un centro multimedia
            completo, actualizado y <strong className="text-white">legal</strong>.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {PILLARS.map((p) => (
              <span key={p.text} className="flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-3.5 py-2 text-xs font-semibold text-slate-200">
                <p.icon size={14} className="text-cyanx" />
                {p.text}
              </span>
            ))}
          </div>
          <div className="mt-8 flex items-center gap-4 rounded-2xl border border-electric/25 bg-electric/8 p-4">
            <MonitorPlay size={34} className="shrink-0 text-cyanx" strokeWidth={1.6} />
            <p className="text-sm text-slate-300"><strong className="text-white">Diseñado para el móvil primero.</strong> Tablet, Android TV y Google TV reciben la misma experiencia adaptativa — el móvil funciona solo, sin depender de tele ni HDMI.</p>
          </div>
        </div>

        {/* comparison table */}
        <div className="tile overflow-hidden rounded-2xl">
          <div className="grid grid-cols-[0.9fr_1.15fr_1.15fr] border-b border-white/10 bg-white/[0.04] text-[11px] font-bold uppercase tracking-wider">
            <span className="px-4 py-3.5 text-slate-500">Comparativa</span>
            <span className="px-4 py-3.5 text-cyanx">TV LO3 en tu Android</span>
            <span className="px-4 py-3.5 text-slate-500">TV Box 4K típico</span>
          </div>
          {ROWS.map((r, i) => (
            <div key={i} className={`grid grid-cols-[0.9fr_1.15fr_1.15fr] text-xs ${i !== ROWS.length - 1 ? "border-b border-white/5" : ""}`}>
              <span className="px-4 py-3.5 font-semibold text-slate-400">{r.label}</span>
              <span className="flex items-start gap-1.5 px-4 py-3.5 text-emerald-100/90"><Check size={13} strokeWidth={3} className="mt-0.5 shrink-0 text-emerald-400" />{r.tvlo3}</span>
              <span className="flex items-start gap-1.5 px-4 py-3.5 text-slate-500"><X size={13} strokeWidth={3} className="mt-0.5 shrink-0 text-rose-500/80" />{r.box}</span>
            </div>
          ))}
          <p className="border-t border-white/5 bg-black/30 px-4 py-2.5 text-center text-[10px] text-slate-600">Ejemplo representativo de gama media (Xiaomi Mi Box / Fire TV Stick 4K / Chromecast). Precios orientativos 2026.</p>
        </div>
      </div>
    </section>
  );
}
