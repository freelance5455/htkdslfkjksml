import { benefits } from "../data/content";
import { CheckCircleIcon } from "./icons";

export function Benefits() {
  return (
    <section id="benefits" className="relative py-20 sm:py-28">
      <div className="absolute inset-0 bg-gradient-to-b from-ink-950 via-ink-900/50 to-ink-950" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
              Benefits
            </p>
            <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Outcomes your board{" "}
              <span className="text-gradient-brand">will notice</span>
            </h2>
            <p className="reveal delay-200 mt-4 text-base leading-relaxed text-ink-400 sm:text-lg">
              Cascade isn't another dashboard to ignore. It's the operating
              system that turns process debt into compounding leverage.
            </p>

            <div className="mt-8 space-y-4">
              {[
                "Deploy production workflows in under an hour",
                "Cut tool sprawl without ripping out what works",
                "Give every team self-serve automation with guardrails",
                "Prove ROI with built-in impact analytics",
              ].map((item, i) => {
                const delays = ["delay-300", "delay-400", "delay-500", "delay-600"] as const;
                return (
                <div
                  key={item}
                  className={`reveal ${delays[i]} flex items-start gap-3`}
                >
                  <CheckCircleIcon
                    size={20}
                    className="mt-0.5 shrink-0 text-brand-400"
                  />
                  <span className="text-sm text-ink-200 sm:text-base">{item}</span>
                </div>
              );
              })}
            </div>
          </div>

          <div className="space-y-4">
            {benefits.map((b, i) => {
              const delays = ["delay-100", "delay-200", "delay-300"] as const;
              return (
              <article
                key={b.title}
                className={`reveal-right ${delays[i]} group card-lift overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-6 backdrop-blur-sm sm:p-7`}
              >
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white">
                      {b.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink-400">
                      {b.description}
                    </p>
                  </div>
                  <div className="shrink-0 rounded-xl border border-brand-400/20 bg-brand-500/10 px-4 py-3 text-center sm:min-w-[120px]">
                    <div className="text-2xl font-semibold tracking-tight text-brand-300">
                      {b.metric}
                    </div>
                    <div className="mt-0.5 text-[11px] leading-tight text-ink-500">
                      {b.metricLabel}
                    </div>
                  </div>
                </div>
              </article>
            );
            })}
          </div>
        </div>

        {/* Secondary visual band */}
        <div className="reveal-scale mt-16 overflow-hidden rounded-2xl border border-white/10">
          <div className="relative aspect-[21/9] min-h-[200px] sm:min-h-[280px]">
            <img
              src="/images/team-collab.jpg"
              alt="Team collaborating with Cascade to streamline operations"
              className="h-full w-full object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-ink-950/90 via-ink-950/50 to-ink-950/30" />
            <div className="absolute inset-0 flex items-center">
              <div className="max-w-md px-6 sm:px-10">
                <p className="text-sm font-semibold tracking-wider text-brand-300 uppercase">
                  Built for humans
                </p>
                <p className="mt-2 text-xl font-semibold tracking-tight text-white sm:text-2xl">
                  “We stopped firefighting and started building the company we
                  imagined.”
                </p>
                <p className="mt-3 text-sm text-ink-400">
                  — Ops leaders at high-growth SaaS companies
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
