import React, { useState } from 'react';
import { 
  Clipboard, 
  Trash2, 
  Dices, 
  Clock, 
  FileText, 
  Sparkles,
  Quote,
  Plus,
  Flame,
  ChevronDown,
  Cloud
} from 'lucide-react';
import { Language, PersonaId } from '../types/tts';

interface StudioEditorProps {
  text: string;
  onChangeText: (text: string) => void;
  selectedLanguage: Language;
  speed: number;
  selectedPersona?: PersonaId;
  onCreateNewTTS?: (option: 'soda' | 'blank' | PersonaId) => void;
  onOpenCloudModal?: () => void;
}

export const StudioEditor: React.FC<StudioEditorProps> = ({
  text,
  onChangeText,
  selectedLanguage,
  speed,
  selectedPersona,
  onCreateNewTTS,
  onOpenCloudModal,
}) => {
  const [isNewMenuOpen, setIsNewMenuOpen] = useState(false);
  const charCount = text.length;
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  
  // Estimate audio speaking duration based on word count and speed
  // Average speaking rate: ~140 words per minute at 1.0x
  const estimatedSeconds = wordCount > 0 ? Math.round((wordCount / (140 * speed)) * 60) : 0;
  const formattedDuration =
    estimatedSeconds < 60
      ? `${estimatedSeconds}s`
      : `${Math.floor(estimatedSeconds / 60)}m ${estimatedSeconds % 60}s`;

  const handleClear = () => {
    onChangeText('');
  };

  const handlePaste = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (clipText) {
        onChangeText(clipText);
      }
    } catch (e) {
      // Fallback
    }
  };

  const handleRandomSample = () => {
    if (selectedLanguage.sampleTexts.length > 0) {
      const randomIndex = Math.floor(Math.random() * selectedLanguage.sampleTexts.length);
      onChangeText(selectedLanguage.sampleTexts[randomIndex].text);
    }
  };

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm overflow-hidden flex flex-col">
      {/* Top action bar */}
      <div className="px-4 py-3 border-b border-zinc-100 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-2 bg-zinc-50/50 dark:bg-zinc-950/40">
        
        {/* Sample text pill recommendations & Soda Option */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none">
          {/* Prominent Soda Option for Create New TTS */}
          <button
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('soda');
              } else {
                const soda = selectedLanguage.sampleTexts.find((s) => s.title.includes('Soda') || s.title.includes('சோடா') || s.title.includes('సోడా') || s.title.includes('സോഡ') || s.title.includes('ಸೋಡಾ') || s.title.includes('सोडा'));
                if (soda) onChangeText(soda.text);
              }
            }}
            className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 shadow-xs cursor-pointer active:scale-95 ${
              selectedPersona === 'soda'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-amber-500/25 ring-1 ring-amber-400'
                : 'bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-200 dark:hover:bg-amber-900/60 border border-amber-300/80 dark:border-amber-700/50'
            }`}
            title="Create new energetic speech synthesis using Soda voice"
          >
            <span>🥤</span>
            <span>Soda Voice TTS</span>
            <span className="text-[9px] bg-amber-400/40 text-amber-950 dark:text-amber-100 px-1 py-0.2 rounded-full uppercase font-extrabold">
              Fizzy
            </span>
          </button>

          <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1 shrink-0 ml-1 mr-1">
            <Quote className="w-3 h-3 text-violet-500" />
            Samples:
          </span>

          {selectedLanguage.sampleTexts.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => onChangeText(sample.text)}
              className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800/80 hover:bg-violet-100 dark:hover:bg-violet-900/40 text-zinc-700 dark:text-zinc-300 hover:text-violet-700 dark:hover:text-violet-300 transition-colors shrink-0 truncate max-w-[170px]"
              title={sample.text}
            >
              {sample.title}
            </button>
          ))}
        </div>

        {/* Quick Toolbar */}
        <div className="flex items-center gap-1 ml-auto shrink-0 relative">
          {/* Create New TTS Menu Button */}
          {onCreateNewTTS && (
            <div className="relative">
              <button
                onClick={() => setIsNewMenuOpen(!isNewMenuOpen)}
                className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                title="Create a new TTS synthesis"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New TTS</span>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>

              {isNewMenuOpen && (
                <div 
                  className="absolute right-0 top-full mt-1.5 w-52 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-xl z-30 py-1 text-xs animate-in fade-in"
                  onMouseLeave={() => setIsNewMenuOpen(false)}
                >
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400 border-b border-zinc-100 dark:border-zinc-800">
                    Create New TTS
                  </div>

                  {/* Prominent Soda Option inside New TTS Menu */}
                  <button
                    onClick={() => {
                      onCreateNewTTS('soda');
                      setIsNewMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-amber-50 dark:hover:bg-amber-950/40 text-amber-700 dark:text-amber-300 flex items-center justify-between font-bold"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>🥤</span>
                      <span>Soda Voice (Fizzy Pop)</span>
                    </div>
                    <span className="text-[9px] bg-amber-500/20 px-1 py-0.5 rounded font-extrabold uppercase">
                      Popular
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      onCreateNewTTS('blank');
                      setIsNewMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                  >
                    <FileText className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Blank Canvas</span>
                  </button>

                  <button
                    onClick={() => {
                      onCreateNewTTS('female');
                      setIsNewMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                  >
                    <span>👩</span>
                    <span>Aria Female Voice</span>
                  </button>

                  <button
                    onClick={() => {
                      onCreateNewTTS('male');
                      setIsNewMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                  >
                    <span>👨</span>
                    <span>Roger Male Voice</span>
                  </button>
                </div>
              )}
            </div>
          )}

          <button
            onClick={handleRandomSample}
            className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all text-xs flex items-center gap-1"
            title="Load random quote"
          >
            <Dices className="w-3.5 h-3.5 text-indigo-500" />
            <span className="hidden sm:inline">Random</span>
          </button>

          <button
            onClick={handlePaste}
            className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all text-xs flex items-center gap-1"
            title="Paste text from clipboard"
          >
            <Clipboard className="w-3.5 h-3.5 text-cyan-500" />
            <span className="hidden sm:inline">Paste</span>
          </button>

          {onOpenCloudModal && (
            <button
              onClick={onOpenCloudModal}
              className="px-2 py-1.5 rounded-lg text-cyan-700 dark:text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 transition-all text-xs flex items-center gap-1 font-semibold cursor-pointer"
              title="Open Cloud Storage Box (Google Drive Sync)"
            >
              <Cloud className="w-3.5 h-3.5 text-cyan-500" />
              <span className="hidden sm:inline">Drive</span>
            </button>
          )}

          {text && (
            <button
              onClick={handleClear}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-red-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all text-xs flex items-center gap-1"
              title="Clear text"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Textarea */}
      <div className="relative flex-1 min-h-[220px] p-4">
        <textarea
          value={text}
          onChange={(e) => onChangeText(e.target.value)}
          placeholder={`Enter or paste text in ${selectedLanguage.name} (${selectedLanguage.nativeName})...\n\nExample: ${
            selectedLanguage.sampleTexts[0]?.text || 'Type your message to convert into natural speech.'
          }`}
          className="w-full h-full min-h-[190px] resize-none bg-transparent text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-600 focus:outline-none text-base leading-relaxed selection:bg-violet-500/30 font-normal"
          maxLength={5000}
        />
      </div>

      {/* Footer Info Bar */}
      <div className="px-4 py-2.5 border-t border-zinc-100 dark:border-zinc-800/80 bg-zinc-50/50 dark:bg-zinc-950/40 flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-zinc-400" />
            <span className="font-semibold text-zinc-700 dark:text-zinc-300">{wordCount}</span> words
          </span>

          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-zinc-400" />
            ~<span className="font-semibold text-zinc-700 dark:text-zinc-300">{formattedDuration}</span> speech
          </span>
        </div>

        <div className="flex items-center gap-2">
          {selectedPersona === 'soda' && (
            <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
              <span>🥤</span> Soda Voice Active (Fizzy)
            </span>
          )}
          <span className="font-mono text-[11px]">
            <span className={charCount > 4000 ? 'text-amber-500 font-bold' : ''}>{charCount}</span> / 5,000 chars
          </span>
        </div>
      </div>
    </div>
  );
};
