"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { CommentaryItem, MatchState } from "@/lib/types";
import { LANG_META, type Lang } from "@/lib/commentary";
import { LanguageSelect, useLang } from "./lang";

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

export type Speed = "slow" | "normal" | "fast";

export type VoiceSettings = {
  voiceOn: boolean;
  volume: number; // 0..1
  speed: Speed;
  autoVoice: boolean;
  textCommentary: boolean;
  soundEffects: boolean;
  voiceURI: string | null;
};

const DEFAULTS: VoiceSettings = {
  voiceOn: false,
  volume: 0.9,
  speed: "normal",
  autoVoice: true,
  textCommentary: true,
  soundEffects: true,
  voiceURI: null,
};

const RATE: Record<Speed, number> = { slow: 0.78, normal: 1, fast: 1.3 };
const STORAGE_KEY = "mc-voice-settings-v1";

/* ------------------------------------------------------------------ */
/* Sound effects (WebAudio — fully separate from the Urdu voice)       */
/* ------------------------------------------------------------------ */

type SfxKind = "four" | "six" | "wicket" | "over";

function playSfx(ctx: AudioContext, kind: SfxKind, volume: number) {
  const now = ctx.currentTime;
  const master = ctx.createGain();
  master.gain.value = Math.min(0.35, volume * 0.35);
  master.connect(ctx.destination);

  const tone = (freq: number, start: number, dur: number, type: OscillatorType = "sine", g = 1) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now + start);
    gain.gain.setValueAtTime(0, now + start);
    gain.gain.linearRampToValueAtTime(g, now + start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
    osc.connect(gain);
    gain.connect(master);
    osc.start(now + start);
    osc.stop(now + start + dur + 0.02);
    return osc;
  };

  if (kind === "four") {
    // Short bat-crack + rising boundary blip
    tone(520, 0, 0.09, "triangle");
    tone(780, 0.07, 0.14, "triangle", 0.8);
  } else if (kind === "six") {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(1180, now + 0.42);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.9, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc.connect(gain);
    gain.connect(master);
    osc.start(now);
    osc.stop(now + 0.55);
  } else if (kind === "wicket") {
    // Low thud + stump rattle
    tone(120, 0, 0.22, "square", 0.9);
    tone(90, 0.05, 0.3, "sine", 0.7);
    const buf = ctx.createBuffer(1, ctx.sampleRate * 0.18, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const noise = ctx.createBufferSource();
    const ng = ctx.createGain();
    ng.gain.value = 0.35;
    noise.buffer = buf;
    noise.connect(ng);
    ng.connect(master);
    noise.start(now + 0.02);
  } else {
    tone(660, 0, 0.1, "sine", 0.7);
    tone(880, 0.13, 0.14, "sine", 0.7);
  }
}

/* ------------------------------------------------------------------ */
/* Context                                                             */
/* ------------------------------------------------------------------ */

type Ctx = {
  settings: VoiceSettings;
  update: (patch: Partial<VoiceSettings>) => void;
  speak: (text: string, sfx?: SfxKind | null) => void;
  stop: () => void;
  speaking: boolean;
  blocked: boolean;
  supported: boolean;
  voices: { uri: string; label: string }[];
  voiceAvailable: boolean;
  activeVoiceLabel: string;
};

const VoiceCtx = createContext<Ctx | null>(null);

export function useVoice() {
  const c = useContext(VoiceCtx);
  if (!c) throw new Error("useVoice must be used inside CommentaryAudioProvider");
  return c;
}

export function CommentaryAudioProvider({ children }: { children: ReactNode }) {
  const { lang } = useLang();
  const [settings, setSettings] = useState<VoiceSettings>(DEFAULTS);
  const [speaking, setSpeaking] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [supported, setSupported] = useState(true);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const interacted = useRef(false);

  // Persisted settings are hydrated once, after mount, to keep the server and
  // first client render identical (avoids hydration mismatch and cascading renders).
  const hydrated = useRef(false);
  useEffect(() => {
    if (hydrated.current) return;
    hydrated.current = true;
    let stored: Partial<VoiceSettings> | null = null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) stored = JSON.parse(raw) as Partial<VoiceSettings>;
    } catch {
      /* ignore */
    }
    const canSpeak = typeof window !== "undefined" && "speechSynthesis" in window;
    queueMicrotask(() => {
      if (stored) setSettings({ ...DEFAULTS, ...stored });
      if (!canSpeak) setSupported(false);
    });
  }, []);

  // Voice list (async on most browsers)
  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const load = () => setVoices(window.speechSynthesis.getVoices());
    load();
    window.speechSynthesis.addEventListener("voiceschanged", load);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", load);
  }, []);

  // Track the first user gesture so we never autoplay before interaction
  useEffect(() => {
    const mark = () => {
      interacted.current = true;
      if (!audioCtxRef.current) {
        const AC =
          window.AudioContext ??
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AC) audioCtxRef.current = new AC();
      }
      void audioCtxRef.current?.resume();
    };
    window.addEventListener("pointerdown", mark, { once: false });
    window.addEventListener("keydown", mark, { once: false });
    return () => {
      window.removeEventListener("pointerdown", mark);
      window.removeEventListener("keydown", mark);
    };
  }, []);

  const update = useCallback((patch: Partial<VoiceSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      if (patch.voiceOn === false && typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      return next;
    });
  }, []);

  /**
   * Picks the best available voice for the selected commentary language.
   *
   * Preference order: exact language → closely related language → none.
   * Returning null is completely normal: the UI simply notes that voice is
   * unavailable on this device and keeps showing the text commentary.
   * Within a language, a mature/natural voice is preferred over a compact one
   * so delivery sounds like a sports broadcaster rather than a toy.
   */
  const selectedVoice = useMemo(() => {
    if (voices.length === 0) return null;
    if (settings.voiceURI) {
      const chosen = voices.find((v) => v.voiceURI === settings.voiceURI);
      if (chosen) return chosen;
    }
    // Urdu/Hindi/Punjabi are mutually intelligible enough that a sibling
    // voice is a far better fallback than an English one.
    const FALLBACKS: Record<Lang, string[]> = {
      en: ["en"],
      ur: ["ur", "hi", "pa"],
      hi: ["hi", "ur", "pa"],
      pa: ["pa", "hi", "ur"],
    };
    const score = (v: SpeechSynthesisVoice) => {
      const n = `${v.name} ${v.voiceURI}`.toLowerCase();
      let s = 0;
      if (/natural|neural|enhanced|premium|wavenet/.test(n)) s += 6;
      if (/male|hamid|ravi|hemant|madhur|guy|ryan|rishi/.test(n)) s += 3;
      if (/compact|espeak|robot/.test(n)) s -= 4;
      if (v.localService) s += 1;
      return s;
    };
    for (const prefix of FALLBACKS[lang]) {
      const matches = voices.filter((v) => v.lang?.toLowerCase().startsWith(prefix));
      if (matches.length > 0) return [...matches].sort((a, b) => score(b) - score(a))[0];
    }
    return null;
  }, [voices, settings.voiceURI, lang]);

  const stop = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string, sfx: SfxKind | null = null) => {
      if (!settings.voiceOn) return;
      if (!interacted.current) {
        setBlocked(true);
        return;
      }
      // Sound effect first, independent of the spoken commentary
      if (sfx && settings.soundEffects && audioCtxRef.current) {
        try {
          playSfx(audioCtxRef.current, sfx, settings.volume);
        } catch {
          /* ignore */
        }
      }
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
      try {
        const synth = window.speechSynthesis;
        synth.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = selectedVoice?.lang ?? LANG_META[lang].bcp47;
        if (selectedVoice) u.voice = selectedVoice;
        u.volume = settings.volume;
        u.rate = RATE[settings.speed];
        // Slightly lowered pitch for a mature, broadcast-style delivery.
        u.pitch = 0.92;
        u.onstart = () => {
          setSpeaking(true);
          setBlocked(false);
        };
        u.onend = () => setSpeaking(false);
        u.onerror = (e) => {
          setSpeaking(false);
          if (e.error === "not-allowed") setBlocked(true);
        };
        // Delay slightly so the sound effect is not talked over
        window.setTimeout(() => synth.speak(u), sfx && settings.soundEffects ? 260 : 0);
      } catch {
        setSpeaking(false);
      }
    },
    [settings, selectedVoice, lang],
  );

  const voiceList = useMemo(() => {
    const families: Record<Lang, string[]> = {
      en: ["en"],
      ur: ["ur", "hi", "pa"],
      hi: ["hi", "ur", "pa"],
      pa: ["pa", "hi", "ur"],
    };
    return voices
      .filter((v) => families[lang].some((p) => v.lang?.toLowerCase().startsWith(p)))
      .map((v) => ({ uri: v.voiceURI, label: `${v.name} (${v.lang})` }));
  }, [voices, lang]);

  const value: Ctx = {
    settings,
    update,
    speak,
    stop,
    speaking,
    blocked,
    supported,
    voices: voiceList,
    voiceAvailable: selectedVoice !== null,
    activeVoiceLabel: selectedVoice
      ? `${selectedVoice.name} (${selectedVoice.lang})`
      : "Voice unavailable on this device",
  };

  return <VoiceCtx.Provider value={value}>{children}</VoiceCtx.Provider>;
}

/* ------------------------------------------------------------------ */
/* Auto announcer — speaks only genuinely new recorded events          */
/* ------------------------------------------------------------------ */

function sfxFor(item: CommentaryItem): SfxKind | null {
  if (item.kind === "wicket") return "wicket";
  if (item.kind === "six") return "six";
  if (item.kind === "boundary") return "four";
  if (item.kind === "over") return "over";
  return null;
}

export function CommentaryAnnouncer({ state }: { state: MatchState }) {
  const { settings, speak } = useVoice();
  const { lang } = useLang();
  const lastId = useRef<number | null>(null);
  const primed = useRef(false);

  useEffect(() => {
    const latest = state.commentary[0];
    if (!latest) return;
    // First render: set baseline so we never read out the whole history
    if (!primed.current) {
      primed.current = true;
      lastId.current = latest.id;
      return;
    }
    if (lastId.current === latest.id) return;
    const previous = lastId.current ?? 0;
    lastId.current = latest.id;
    if (latest.id <= previous) return; // undo — never announce
    if (!settings.voiceOn || !settings.autoVoice) return;
    // Announce every new line generated since the last poll, oldest first
    const fresh = state.commentary.filter((c) => c.id > previous).reverse();
    fresh.forEach((item, i) => {
      window.setTimeout(() => speak(item.texts[lang] ?? item.texts.en, sfxFor(item)), i * 2600);
    });
  }, [state.commentary, settings.voiceOn, settings.autoVoice, speak, lang]);

  return null;
}

/* ------------------------------------------------------------------ */
/* Controls                                                            */
/* ------------------------------------------------------------------ */

export function SpeakerIndicator() {
  const { speaking } = useVoice();
  if (!speaking) return null;
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-500/15 px-2 py-1 text-[11px] font-black tracking-wider text-emerald-300">
      <span className="flex h-3 items-end gap-0.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="mc-eq w-0.5 rounded bg-emerald-400"
            style={{ animationDelay: `${i * 0.12}s` }}
          />
        ))}
      </span>
      بول رہا ہے
    </span>
  );
}

export function ReplayButton({ text, kind }: { text: string; kind?: SfxKind | null }) {
  const { speak, settings, update } = useVoice();
  return (
    <button
      onClick={() => {
        if (!settings.voiceOn) update({ voiceOn: true });
        // slight delay so the newly enabled setting is used
        window.setTimeout(() => speak(text, kind ?? null), settings.voiceOn ? 0 : 60);
      }}
      title="Replay Urdu commentary"
      className="mc-btn shrink-0 rounded-lg border border-slate-700 px-2 py-1 text-xs text-slate-300 hover:border-emerald-500 hover:text-emerald-400"
    >
      🔊
    </button>
  );
}

export function VoiceToggleInline() {
  const { settings, update, blocked } = useVoice();
  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => update({ voiceOn: !settings.voiceOn })}
        className={`mc-btn flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-black ${
          settings.voiceOn
            ? "bg-emerald-500 text-slate-950"
            : "border border-slate-700 text-slate-300"
        }`}
      >
        {settings.voiceOn ? "🔊 VOICE ON" : "🔇 MUTED"}
      </button>
      <input
        type="range"
        min={0}
        max={100}
        value={Math.round(settings.volume * 100)}
        onChange={(e) => update({ volume: Number(e.target.value) / 100 })}
        className="h-1.5 w-24 accent-emerald-500"
        aria-label="Commentary volume"
      />
      <span className="w-9 text-[11px] text-slate-400">{Math.round(settings.volume * 100)}%</span>
      {blocked && settings.voiceOn && (
        <span className="text-[11px] text-amber-300">Tap 🔊 to enable</span>
      )}
    </div>
  );
}

export function CommentaryAudioDock() {
  const {
    settings,
    update,
    blocked,
    supported,
    voices,
    voiceAvailable,
    activeVoiceLabel,
    speak,
    speaking,
    stop,
  } = useVoice();
  const { lang } = useLang();
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Autoplay-blocked hint */}
      {blocked && settings.voiceOn && (
        <div style={{ bottom: "calc(env(safe-area-inset-bottom, 0px) + var(--mc-dock-bottom, 1.25rem) + 3.5rem)" }}
          className="fixed left-1/2 z-[60] w-[min(92vw,26rem)] -translate-x-1/2 rounded-xl border border-amber-500/50 bg-amber-500/15 px-4 py-2.5 text-center text-xs font-semibold text-amber-200 backdrop-blur">
          Tap the speaker button to enable live commentary.
        </div>
      )}

      {/* Floating button */}
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Commentary audio settings"
        style={{ bottom: "calc(env(safe-area-inset-bottom, 0px) + var(--mc-dock-bottom, 1.25rem))" }}
        className={`mc-btn fixed right-3 z-[60] flex h-11 w-11 items-center justify-center rounded-full text-lg shadow-xl ring-1 ring-black/40 sm:right-5 ${
          settings.voiceOn
            ? "bg-emerald-500 text-slate-950"
            : "bg-slate-800 text-slate-300 ring-slate-700"
        }`}
      >
        {speaking ? (
          <span className="flex h-[18px] items-end gap-0.5">
            {[0, 1, 2, 3].map((i) => (
              <span
                key={i}
                className="mc-eq w-1 rounded bg-slate-950"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </span>
        ) : settings.voiceOn ? (
          "🔊"
        ) : (
          "🔇"
        )}
      </button>

      {open && (
        <div className="fixed inset-0 z-[69]" onClick={() => setOpen(false)}>
          <div
            onClick={(e) => e.stopPropagation()}
            style={{ bottom: "calc(env(safe-area-inset-bottom, 0px) + var(--mc-dock-bottom, 1.25rem) + 3.5rem)" }}
            className="mc-pop mc-card mc-scroll absolute right-3 max-h-[68vh] w-[min(92vw,21rem)] overflow-y-auto px-4 py-4 sm:right-5"
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-wider">Commentary Settings</h3>
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            {!supported && (
              <p className="mb-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-200">
                This browser does not support speech synthesis. Text commentary still works.
              </p>
            )}

            <Row label="Language">
              <LanguageSelect compact />
            </Row>
            {!voiceAvailable && (
              <p className="mb-2 rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1.5 text-[11px] text-slate-400">
                Voice unavailable on this device — text commentary continues normally.
              </p>
            )}
            <Row label="Voice">
              {voices.length > 0 ? (
                <select
                  value={settings.voiceURI ?? ""}
                  onChange={(e) => update({ voiceURI: e.target.value || null })}
                  className="w-40 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs outline-none focus:border-emerald-500"
                >
                  <option value="">Default Urdu voice</option>
                  {voices.map((v) => (
                    <option key={v.uri} value={v.uri}>
                      {v.label}
                    </option>
                  ))}
                </select>
              ) : (
                <span className="text-right text-[11px] text-slate-400">{activeVoiceLabel}</span>
              )}
            </Row>

            <div className="my-3 border-t border-slate-800" />

            <Toggle
              label="Commentary voice"
              value={settings.voiceOn}
              onChange={(v) => update({ voiceOn: v })}
              onText="🔊 ON"
              offText="🔇 OFF"
            />

            <div className="mt-3">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="font-bold uppercase tracking-wider text-slate-400">Volume</span>
                <span className="text-slate-300">{Math.round(settings.volume * 100)}%</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-500">
                <span>0%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.volume * 100)}
                  onChange={(e) => update({ volume: Number(e.target.value) / 100 })}
                  className="h-1.5 flex-1 accent-emerald-500"
                />
                <span>100%</span>
              </div>
            </div>

            <div className="mt-3">
              <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">
                Voice speed
              </p>
              <div className="grid grid-cols-3 gap-1.5">
                {(["slow", "normal", "fast"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => update({ speed: s })}
                    className={`mc-btn rounded-lg px-2 py-2 text-xs font-bold capitalize ${
                      settings.speed === s
                        ? "bg-emerald-500 text-slate-950"
                        : "border border-slate-700 text-slate-300"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="my-3 border-t border-slate-800" />

            <Toggle
              label="Auto voice"
              value={settings.autoVoice}
              onChange={(v) => update({ autoVoice: v })}
            />
            <Toggle
              label="Text commentary"
              value={settings.textCommentary}
              onChange={(v) => update({ textCommentary: v })}
            />
            <Toggle
              label="Sound effects"
              value={settings.soundEffects}
              onChange={(v) => update({ soundEffects: v })}
            />

            <div className="mt-4 flex gap-2">
              <button
                onClick={() => {
                  if (!settings.voiceOn) update({ voiceOn: true });
                  const demo: Record<Lang, string> = {
                    en: "Commentary is now enabled.",
                    ur: "کمنٹری فعال ہو گئی ہے۔",
                    hi: "कॉमेंट्री अब चालू है।",
                    pa: "ਕਮੈਂਟਰੀ ਹੁਣ ਚਾਲੂ ਹੈ।",
                  };
                  window.setTimeout(() => speak(demo[lang], "four"), settings.voiceOn ? 0 : 80);
                }}
                className="mc-btn flex-1 rounded-lg bg-emerald-500 py-2 text-xs font-black text-slate-950"
              >
                Test voice
              </button>
              <button
                onClick={stop}
                className="mc-btn rounded-lg border border-slate-700 px-3 py-2 text-xs font-bold text-slate-300"
              >
                Stop
              </button>
            </div>
            <p className="mt-3 text-[10px] leading-relaxed text-slate-500">
              Commentary is generated only from recorded scoring events. Muting audio never changes
              the scorecard, and text commentary keeps updating.
            </p>
          </div>
        </div>
      )}
    </>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</span>
      {children}
    </div>
  );
}

function Toggle({
  label,
  value,
  onChange,
  onText = "ON",
  offText = "OFF",
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  onText?: string;
  offText?: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`mc-btn rounded-lg px-3 py-1.5 text-xs font-black ${
          value ? "bg-emerald-500 text-slate-950" : "border border-slate-700 text-slate-400"
        }`}
      >
        {value ? onText : offText}
      </button>
    </div>
  );
}
