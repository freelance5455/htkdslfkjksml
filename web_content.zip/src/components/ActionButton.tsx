import { useRef, useState, type ReactNode } from "react";

interface ActionButtonProps {
  label: string;
  icon: ReactNode;
  color: string;
  onPress: () => void;
  onHold?: (held: boolean) => void;
  cooldown?: number;
  disabled?: boolean;
  ready?: boolean;
  hint?: string;
}

export function ActionButton({
  label,
  icon,
  color,
  onPress,
  onHold,
  cooldown = 0,
  disabled,
  ready,
  hint,
}: ActionButtonProps) {
  const [pressed, setPressed] = useState(false);
  const pointerId = useRef<number | null>(null);
  const cd = Math.max(0, Math.min(1, cooldown));

  const release = () => {
    pointerId.current = null;
    setPressed(false);
    onHold?.(false);
  };

  return (
    <button
      type="button"
      aria-label={label}
      className="no-touch touch-action-btn pointer-events-auto relative grid place-items-center overflow-hidden rounded-full"
      style={{
        width: "clamp(44px, 12vw, 64px)",
        height: "clamp(44px, 12vw, 64px)",
        background: pressed
          ? `radial-gradient(circle at 50% 40%, ${color}cc, rgba(8,12,18,0.95) 78%)`
          : `radial-gradient(circle at 50% 32%, ${color}44, rgba(8,12,18,0.92) 76%)`,
        border: `1.5px solid ${ready ? color : `${color}77`}`,
        boxShadow: pressed
          ? `0 0 22px ${color}aa, inset 0 0 16px ${color}66`
          : ready
            ? `0 0 16px ${color}66, inset 0 1px 0 rgba(255,255,255,0.16)`
            : `0 2px 10px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.1)`,
        transform: pressed ? "scale(0.93)" : "scale(1)",
        transition: "transform 0.08s ease, box-shadow 0.15s ease, background 0.15s ease",
        opacity: disabled ? 0.42 : 1,
        touchAction: "none",
        WebkitUserSelect: "none",
        userSelect: "none",
      }}
      onPointerDown={(e) => {
        if (disabled) return;
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        pointerId.current = e.pointerId;
        setPressed(true);
        onPress();
        onHold?.(true);
      }}
      onPointerUp={(e) => {
        if (pointerId.current !== e.pointerId) return;
        e.preventDefault();
        release();
      }}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(e) => e.preventDefault()}
    >
      <span
        className="pointer-events-none absolute inset-0 rounded-full"
        style={{
          background: `conic-gradient(from 180deg, ${color}00 ${(1 - cd) * 360}deg, rgba(2,4,8,0.78) ${(1 - cd) * 360}deg)`,
          opacity: cd > 0.02 ? 0.9 : 0,
        }}
      />
      <span className="relative flex flex-col items-center gap-0.5" style={{ color: ready ? "#fff8e6" : color }}>
        <span style={{ filter: `drop-shadow(0 0 6px ${color}aa)` }}>{icon}</span>
        <span className="text-[7px] font-extrabold leading-none tracking-[0.12em] sm:text-[8px]">{label}</span>
      </span>
      {hint && (
        <span className="pointer-events-none absolute -bottom-0.5 right-0 text-[6px] font-bold tracking-wider text-white/40">
          {hint}
        </span>
      )}
    </button>
  );
}
