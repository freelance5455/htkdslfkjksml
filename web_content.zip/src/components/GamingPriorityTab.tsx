/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNetwork } from '../context/NetworkContext';
import { 
  Gamepad2, 
  Zap, 
  ShieldCheck, 
  Sliders, 
  Cpu, 
  Radio, 
  CheckCircle2, 
  AlertCircle, 
  Laptop, 
  Server,
  Activity,
  Flame
} from 'lucide-react';

export const GamingPriorityTab: React.FC = () => {
  const { 
    gamingConfig, 
    setGamingModeEnabled, 
    updateGamingConfig, 
    devices, 
    toggleDeviceGamingPriority,
    gameServers,
    metrics
  } = useNetwork();

  const [activeTab, setActiveTab] = useState<'devices' | 'servers' | 'engine'>('devices');

  const vipDevices = devices.filter(d => d.isGamingPriority);
  const otherDevices = devices.filter(d => !d.isGamingPriority);

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Master Gaming Switch Hero Banner */}
      <div className={`rounded-2xl p-4 border transition-all duration-300 ${
        gamingConfig.enabled
          ? 'bg-gradient-to-r from-purple-950/60 via-slate-900 to-indigo-950/40 border-purple-500/40 shadow-lg shadow-purple-950/20'
          : 'bg-slate-900/90 border-slate-800/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl ${
              gamingConfig.enabled 
                ? 'bg-purple-500/20 text-purple-300 ring-2 ring-purple-500/30' 
                : 'bg-slate-800 text-slate-400'
            }`}>
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  Gaming Priority Mode
                </h2>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  gamingConfig.enabled
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'bg-slate-800 text-slate-400'
                }`}>
                  {gamingConfig.enabled ? 'ACTIVE' : 'DISABLED'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {gamingConfig.enabled 
                  ? 'Eliminating queue delay & reserving zero-jitter bandwidth' 
                  : 'Normal multi-client queue scheduling'}
              </p>
            </div>
          </div>

          {/* Toggle Switch */}
          <button
            onClick={() => setGamingModeEnabled(!gamingConfig.enabled)}
            className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              gamingConfig.enabled ? 'bg-purple-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                gamingConfig.enabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Live A/B Latency Comparison Matrix */}
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          <div className="text-[11px] font-semibold text-slate-300 mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Real-Time Latency Under Heavy Download Load</span>
            </span>
            <span className="text-[10px] font-mono text-purple-300">
              {gamingConfig.enabled ? 'SQM Cake Active' : 'Unmanaged Bufferbloat'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center text-xs">
            <div className={`p-2.5 rounded-xl border transition-all ${
              !gamingConfig.enabled 
                ? 'bg-amber-950/20 border-amber-500/30' 
                : 'bg-slate-950/60 border-slate-800/60 opacity-60'
            }`}>
              <div className="text-[10px] text-slate-400">Standard Traffic</div>
              <div className="text-lg font-bold text-amber-400 font-mono mt-0.5">
                114 <span className="text-xs font-normal">ms</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Jitter: ±18ms · Bufferbloat D</div>
            </div>

            <div className={`p-2.5 rounded-xl border transition-all ${
              gamingConfig.enabled 
                ? 'bg-emerald-950/30 border-emerald-500/40 shadow-sm' 
                : 'bg-slate-950/60 border-slate-800/60 opacity-60'
            }`}>
              <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                <Flame className="w-3 h-3 text-purple-400" />
                <span>Gaming Priority</span>
              </div>
              <div className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
                16 <span className="text-xs font-normal">ms</span>
              </div>
              <div className="text-[10px] text-emerald-400 font-medium mt-0.5">Jitter: 0.8ms · Bufferbloat A+</div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
        <button
          onClick={() => setActiveTab('devices')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            activeTab === 'devices'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          VIP Devices ({vipDevices.length})
        </button>
        <button
          onClick={() => setActiveTab('servers')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            activeTab === 'servers'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Game Server Radar
        </button>
        <button
          onClick={() => setActiveTab('engine')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            activeTab === 'engine'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          QoS Engine Rules
        </button>
      </div>

      {/* TAB CONTENT: VIP DEVICES */}
      {activeTab === 'devices' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 px-1">
            Devices selected below receive guaranteed jitter-free queues. Any background downloads (Steam, 4K TV streams) are automatically throttled if game packets arrive.
          </div>

          <div className="space-y-2">
            {devices.map(dev => {
              const isVip = dev.isGamingPriority;

              return (
                <div
                  key={dev.id}
                  onClick={() => toggleDeviceGamingPriority(dev.id)}
                  className={`cursor-pointer p-3 rounded-2xl border transition-all flex items-center justify-between ${
                    isVip
                      ? 'bg-purple-950/20 border-purple-500/40 shadow-sm'
                      : 'bg-slate-900/80 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${isVip ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-800 text-slate-400'}`}>
                      <Gamepad2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">
                          {dev.customAlias || dev.name}
                        </span>
                        {dev.type === 'console' && (
                          <span className="text-[9px] font-semibold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded">
                            CONSOLE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {dev.ip} · {dev.wifiBand}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleDeviceGamingPriority(dev.id);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      isVip
                        ? 'bg-purple-600 text-white shadow-md shadow-purple-900/30'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isVip ? 'PRIORITIZED' : 'PRIORITIZE'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB CONTENT: GAME SERVER RADAR */}
      {activeTab === 'servers' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 px-1 flex items-center justify-between">
            <span>Live multiplayer datacenter telemetry</span>
            <span className="text-[10px] text-emerald-400 font-mono">Status: All Optimal</span>
          </div>

          <div className="space-y-2">
            {gameServers.map((server, idx) => (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-white">{server.game}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {server.region} · <span className="text-slate-500">{server.location}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-bold text-emerald-400 font-mono flex items-center justify-end gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>{server.pingMs} ms</span>
                  </div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">
                    {server.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: ENGINE SETTINGS */}
      {activeTab === 'engine' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>Low-Latency SQM Queue Architecture</span>
            </h3>

            {/* Algorithm Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Active Queue Management (AQM) Algorithm
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {(['Cake (SQM)', 'fq_codel', 'Adaptive QoS'] as const).map(algo => (
                  <button
                    key={algo}
                    onClick={() => updateGamingConfig({ algorithm: algo })}
                    className={`p-2.5 rounded-xl border text-center font-medium transition ${
                      gamingConfig.algorithm === algo
                        ? 'bg-purple-500/20 border-purple-500 text-purple-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {algo}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                Cake handles per-host/per-flow fair queuing and completely prevents TCP queue bloat.
              </p>
            </div>

            {/* DSCP Marking toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-semibold text-white">DSCP DiffServ Packet Tagging</div>
                <div className="text-[10px] text-slate-400">
                  Tag gaming UDP ports (3074, 3478-3480) with CS4/EF priority
                </div>
              </div>
              <input
                type="checkbox"
                checked={gamingConfig.dscpTagging}
                onChange={e => updateGamingConfig({ dscpTagging: e.target.checked })}
                className="w-4 h-4 accent-purple-500"
              />
            </div>

            {/* Bufferbloat Mitigation Ceiling */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">QoS Rate Ceiling</span>
                <span className="font-mono text-purple-400 font-bold">
                  {gamingConfig.bandwidthCeilingPct}% of ISP speed
                </span>
              </div>
              <input
                type="range"
                min="80"
                max="98"
                value={gamingConfig.bandwidthCeilingPct}
                onChange={e => updateGamingConfig({ bandwidthCeilingPct: Number(e.target.value) })}
                className="w-full accent-purple-500"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                Reserves a small overhead margin to prevent the ISP modem queue from filling up.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
