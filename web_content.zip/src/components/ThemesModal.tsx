import React from 'react';
import { GameTheme, GAME_THEMES } from '../types';
import { X, Check, Lock, Coins, Sparkles } from 'lucide-react';

interface ThemesModalProps {
  currentTheme: GameTheme;
  coins: number;
  unlockedThemes: string[];
  onSelectTheme: (themeId: string) => void;
  onUnlockTheme: (theme: GameTheme) => void;
  onClose: () => void;
}

export const ThemesModal: React.FC<ThemesModalProps> = ({
  currentTheme,
  coins,
  unlockedThemes,
  onSelectTheme,
  onUnlockTheme,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col max-h-[90vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-white">THEME SHOP</h2>
            <div className="flex items-center gap-1 rounded-full bg-slate-800 px-2 py-0.5 text-xs font-bold text-amber-400">
              <Coins className="h-3 w-3 fill-amber-400/20" />
              <span>{coins}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Theme List */}
        <div className="flex flex-col gap-3 py-4 overflow-y-auto no-scrollbar">
          {GAME_THEMES.map((theme) => {
            const isUnlocked = unlockedThemes.includes(theme.id);
            const isEquipped = currentTheme.id === theme.id;
            const canAfford = coins >= theme.cost;

            return (
              <div
                key={theme.id}
                className={`relative flex items-center justify-between rounded-2xl p-3 border transition-all ${
                  isEquipped
                    ? 'bg-slate-800/90 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                    : isUnlocked
                    ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    : 'bg-slate-950/40 border-slate-800/60 opacity-85'
                }`}
              >
                {/* Theme Palette Swatch & Info */}
                <div className="flex items-center gap-3">
                  <div
                    className="flex h-11 w-11 items-center justify-center rounded-xl shadow-inner border border-white/20"
                    style={{
                      background: `linear-gradient(135deg, ${theme.ambientGlow} 0%, #090d16 100%)`,
                      boxShadow: `0 0 12px ${theme.ambientGlow}`,
                    }}
                  >
                    <Sparkles className="h-5 w-5 text-white/90" />
                  </div>

                  <div className="flex flex-col text-left">
                    <span className="text-sm font-bold text-white flex items-center gap-1.5">
                      {theme.name}
                      {isEquipped && (
                        <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/20 px-1.5 py-0.2 rounded-full">
                          EQUIPPED
                        </span>
                      )}
                    </span>
                    <span className="text-[11px] text-slate-400 max-w-[150px] truncate">
                      {theme.description}
                    </span>
                  </div>
                </div>

                {/* Action: Equip or Unlock */}
                <div>
                  {isEquipped ? (
                    <div className="flex h-8 items-center gap-1 px-3 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs">
                      <Check className="h-3.5 w-3.5" />
                      <span>Active</span>
                    </div>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => onSelectTheme(theme.id)}
                      className="flex h-8 items-center px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 active:scale-95 transition-all"
                    >
                      Equip
                    </button>
                  ) : (
                    <button
                      onClick={() => onUnlockTheme(theme)}
                      disabled={!canAfford}
                      className={`flex h-8 items-center gap-1 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                        canAfford
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-800/80 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Lock className="h-3 w-3" />
                      <Coins className="h-3 w-3" />
                      <span>{theme.cost}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="pt-2 text-center text-[11px] text-slate-500 border-t border-slate-800">
          Earn coins during gameplay or complete daily challenges to unlock!
        </div>
      </div>
    </div>
  );
};
