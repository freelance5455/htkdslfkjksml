import React, { useState } from 'react';
import { Users, Plus, Search, Filter, ChevronRight, X, Phone, Building } from 'lucide-react';
import { Ledger, LedgerGroupType } from '../types/tally';
import { formatCurrency } from '../utils/tallyEngine';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface LedgerDirectoryViewProps {
  ledgers: Ledger[];
  onSelectLedger: (ledger: Ledger) => void;
  onAddLedger: (ledger: Ledger) => void;
}

export const LedgerDirectoryView: React.FC<LedgerDirectoryViewProps> = ({
  ledgers,
  onSelectLedger,
  onAddLedger,
}) => {
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // New ledger form state
  const [name, setName] = useState<string>('');
  const [group, setGroup] = useState<LedgerGroupType>('Sundry Debtors');
  const [openingBalance, setOpeningBalance] = useState<number>(0);
  const [openingBalanceType, setOpeningBalanceType] = useState<'Dr' | 'Cr'>('Dr');
  const [gstin, setGstin] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [state, setState] = useState<string>('Maharashtra');

  const groupsList: string[] = [
    'all',
    'Sundry Debtors',
    'Sundry Creditors',
    'Bank Accounts',
    'Cash-in-hand',
    'Indirect Expenses',
    'Duties & Taxes',
    'Sales Accounts',
    'Purchase Accounts',
    'Fixed Assets',
    'Capital Account',
  ];

  const filteredLedgers = ledgers.filter((l) => {
    if (selectedGroup !== 'all' && l.group !== selectedGroup) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = l.name.toLowerCase().includes(q);
      const matchGstin = l.gstin?.toLowerCase().includes(q);
      const matchPhone = l.phone?.includes(q);
      if (!matchName && !matchGstin && !matchPhone) return false;
    }
    return true;
  });

  const handleCreateLedger = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    triggerHaptic('success');
    soundManager.playAcceptChime();

    const newLedger: Ledger = {
      id: 'led_' + Date.now(),
      name: name.trim(),
      group,
      openingBalance: Number(openingBalance) || 0,
      openingBalanceType,
      currentBalance: Number(openingBalance) || 0,
      currentBalanceType: openingBalanceType,
      gstin: gstin.trim() || undefined,
      phone: phone.trim() || undefined,
      address: address.trim() || undefined,
      state: state.trim() || undefined,
    };

    onAddLedger(newLedger);
    setIsAddModalOpen(false);
    setName('');
    setOpeningBalance(0);
    setGstin('');
    setPhone('');
  };

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between shadow-xs">
        <div>
          <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
            Masters & Chart of Accounts
          </div>
          <h2 className="text-base font-bold">Ledgers & Parties</h2>
        </div>
        <button
          onClick={() => {
            triggerHaptic('light');
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1.5 rounded-lg text-xs font-semibold shadow-xs touch-press"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Ledger</span>
        </button>
      </div>

      {/* Filter and search bar */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 space-y-2">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search party name, GSTIN, phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        {/* Group chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {groupsList.map((g) => {
            const active = selectedGroup === g;
            return (
              <button
                key={g}
                onClick={() => {
                  triggerHaptic('light');
                  setSelectedGroup(g);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors touch-press ${
                  active
                    ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {g === 'all' ? 'ALL ACCOUNTS' : g}
              </button>
            );
          })}
        </div>

        <div className="text-[11px] text-slate-500 font-mono px-1">
          Showing {filteredLedgers.length} Ledgers
        </div>
      </div>

      {/* Ledgers List */}
      <div className="p-3 space-y-2">
        {filteredLedgers.map((led) => {
          const isDr = led.currentBalanceType === 'Dr';
          return (
            <div
              key={led.id}
              onClick={() => {
                triggerHaptic('light');
                onSelectLedger(led);
              }}
              className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-3 shadow-xs hover:border-emerald-500/60 cursor-pointer transition-all flex items-center justify-between gap-2"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {led.name}
                  </h3>
                  {led.isSystem && (
                    <span className="text-[9px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-1 rounded">
                      System
                    </span>
                  )}
                </div>

                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5 truncate">
                  <span>{led.group}</span>
                  {led.gstin && <span> · GST: {led.gstin}</span>}
                </div>
              </div>

              <div className="text-right shrink-0">
                <div
                  className={`text-xs font-bold font-mono tabular-nums ${
                    isDr ? 'text-slate-900 dark:text-white' : 'text-slate-900 dark:text-white'
                  }`}
                >
                  {formatCurrency(led.currentBalance)}
                </div>
                <span
                  className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded ${
                    isDr
                      ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                      : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                  }`}
                >
                  {led.currentBalanceType}
                </span>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
            </div>
          );
        })}
      </div>

      {/* Add New Ledger Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between">
              <span className="text-xs font-bold">New Ledger Account Creation</span>
              <button onClick={() => setIsAddModalOpen(false)}>
                <X className="w-4 h-4 text-emerald-200" />
              </button>
            </div>

            <form onSubmit={handleCreateLedger} className="p-4 space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Name (Ledger Account Title)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Traders & Co."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Under (Account Group)
                </label>
                <select
                  value={group}
                  onChange={(e) => setGroup(e.target.value as LedgerGroupType)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium"
                >
                  <option value="Sundry Debtors">Sundry Debtors (Customers)</option>
                  <option value="Sundry Creditors">Sundry Creditors (Suppliers)</option>
                  <option value="Bank Accounts">Bank Accounts</option>
                  <option value="Cash-in-hand">Cash-in-hand</option>
                  <option value="Indirect Expenses">Indirect Expenses</option>
                  <option value="Direct Expenses">Direct Expenses</option>
                  <option value="Sales Accounts">Sales Accounts</option>
                  <option value="Purchase Accounts">Purchase Accounts</option>
                  <option value="Fixed Assets">Fixed Assets</option>
                  <option value="Duties & Taxes">Duties & Taxes</option>
                  <option value="Capital Account">Capital Account</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Opening Balance (₹)
                  </label>
                  <input
                    type="number"
                    value={openingBalance}
                    onChange={(e) => setOpeningBalance(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Dr / Cr Type
                  </label>
                  <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setOpeningBalanceType('Dr')}
                      className={`py-1 rounded-lg text-xs font-bold ${
                        openingBalanceType === 'Dr'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-500'
                      }`}
                    >
                      Dr
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpeningBalanceType('Cr')}
                      className={`py-1 rounded-lg text-xs font-bold ${
                        openingBalanceType === 'Cr'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-500'
                      }`}
                    >
                      Cr
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    GSTIN
                  </label>
                  <input
                    type="text"
                    placeholder="27ABCDE1234F1Z5"
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value.toUpperCase())}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Phone / Mobile
                  </label>
                  <input
                    type="text"
                    placeholder="+91 98..."
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Address & State
                </label>
                <input
                  type="text"
                  placeholder="Market road, Mumbai, Maharashtra"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 text-white font-bold shadow-xs hover:bg-emerald-500"
                >
                  Create Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
