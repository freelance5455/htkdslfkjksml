import { useState } from "react";
import { faqs } from "../data/content";
import { cn } from "../utils/cn";
import { PlusIcon, MinusIcon } from "./icons";

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
            FAQ
          </p>
          <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Questions,{" "}
            <span className="text-gradient-brand">answered</span>
          </h2>
          <p className="reveal delay-200 mt-4 text-base text-ink-400 sm:text-lg">
            Everything you need to know before you launch your first workflow.
          </p>
        </div>

        <div className="reveal delay-300 mt-12 divide-y divide-white/8 rounded-2xl border border-white/8 bg-white/[0.02]">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div key={faq.question} className="px-5 sm:px-6">
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    id={`faq-button-${i}`}
                    onClick={() => setOpenIndex(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-4 py-5 text-left transition-colors"
                  >
                    <span className="text-sm font-medium text-white sm:text-base">
                      {faq.question}
                    </span>
                    <span
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-300",
                        isOpen
                          ? "border-brand-400/40 bg-brand-500/20 text-brand-300"
                          : "border-white/10 bg-white/5 text-ink-400"
                      )}
                    >
                      {isOpen ? (
                        <MinusIcon size={16} />
                      ) : (
                        <PlusIcon size={16} />
                      )}
                    </span>
                  </button>
                </h3>
                <div
                  id={`faq-panel-${i}`}
                  role="region"
                  aria-labelledby={`faq-button-${i}`}
                  className={cn("faq-content", isOpen && "open")}
                >
                  <div>
                    <p className="pb-5 text-sm leading-relaxed text-ink-400">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
