import React from 'react';
import type { PeriodSummary } from '../types';
import { formatArabicDateShort } from '../utils/attendance';

interface SummaryStripProps {
  summary: PeriodSummary;
  returnStartDate: string;
  todayKey: string;
  loading: boolean;
}

export const SummaryStrip: React.FC<SummaryStripProps> = ({
  summary,
  returnStartDate,
  todayKey,
  loading,
}) => {
  const hasStart = Boolean(returnStartDate);

  return (
    <section id="summary" aria-label="ملخص أيام الحضور والإجازة الاعتيادي">
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-slate-200">
          {/* Work Days */}
          <div className="p-5 sm:p-6">
            <div className="flex items-baseline justify-between gap-2 mb-2">
              <span className="text-sm font-medium text-slate-600">عدد أيام الحضور</span>
              <span className="text-xs font-semibold text-emerald-700">حضور</span>
            </div>
            {loading ? (
              <div className="h-10 w-24 bg-slate-100 rounded animate-pulse" />
            ) : (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-bold text-slate-900 font-mono-num tabular-nums">
                  {summary.workDays}
                </span>
                <span className="text-sm text-slate-500">يوم</span>
              </div>
            )}
          </div>

          {/* Annual Leave Days */}
          <div className="p-5 sm:p-6">
            <div className="flex items-baseline justify-between gap-2 mb-2">
              <span className="text-sm font-medium text-slate-600">الإجازة الاعتيادي</span>
              <span className="text-xs font-semibold text-sky-700">اعتيادي</span>
            </div>
            {loading ? (
              <div className="h-10 w-24 bg-slate-100 rounded animate-pulse" />
            ) : (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-bold text-slate-900 font-mono-num tabular-nums">
                  {summary.annualLeaveDays}
                </span>
                <span className="text-sm text-slate-500">يوم</span>
              </div>
            )}
          </div>

          {/* Total Days */}
          <div className="p-5 sm:p-6">
            <div className="flex items-baseline justify-between gap-2 mb-2">
              <span className="text-sm font-medium text-slate-600">إجمالي الأيام</span>
              <span className="text-xs font-medium text-slate-500">حتى اليوم</span>
            </div>
            {loading ? (
              <div className="h-10 w-24 bg-slate-100 rounded animate-pulse" />
            ) : (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-bold text-slate-900 font-mono-num tabular-nums">
                  {summary.totalDays}
                </span>
                <span className="text-sm text-slate-500">يوم</span>
              </div>
            )}
          </div>
        </div>

        {/* Attached clean metadata bar */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
          {hasStart ? (
            <div className="flex flex-wrap items-center gap-2">
              <span>
                أول يوم عودة للعمل:{' '}
                <strong className="font-semibold text-slate-900">
                  {formatArabicDateShort(returnStartDate)}
                </strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                محتسبة حتى تاريخ:{' '}
                <strong className="font-semibold text-slate-900">
                  {formatArabicDateShort(todayKey)}
                </strong>
              </span>
              {summary.manualOverrides > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">
                    أيام مسجلة يدوياً: {summary.manualOverrides}
                  </span>
                </>
              )}
            </div>
          ) : (
            <span>
              سجّل أول يوم عودة للعمل أو سجّل أيام الإجازة الاعتيادي أدناه.
            </span>
          )}
        </div>
      </div>
    </section>
  );
};
