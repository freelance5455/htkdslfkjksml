import type { ApkBuildConfig, DeveloperProfile } from '../types/apk';

interface DeveloperLinksSectionProps {
  config: ApkBuildConfig;
  onChange: (patch: Partial<ApkBuildConfig>) => void;
}

export function DeveloperLinksSection({
  config,
  onChange,
}: DeveloperLinksSectionProps) {
  const d = config.developer;

  const updateDev = (patch: Partial<DeveloperProfile>) => {
    onChange({
      developer: { ...d, ...patch },
    });
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70">
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={d.includeAboutPageInAssets}
            onChange={(e) =>
              updateDev({ includeAboutPageInAssets: e.target.checked })
            }
            className="mt-0.5 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              Bundle Developer & Social Hub (<code className="font-mono text-xs">assets/developer.html</code>)
            </div>
            <div className="text-xs text-slate-600 mt-0.5 leading-relaxed">
              Packages a styled Developer & Support page inside your APK containing your social links, support email, and Play Store legal URLs. Accessible via <code className="font-mono">developer.html</code> or <code className="font-mono">window.AndroidNative.openDeveloperInfo()</code>.
            </div>
          </div>
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5">
            Developer / Studio Name
          </label>
          <input
            type="text"
            value={d.developerName}
            onChange={(e) => updateDev({ developerName: e.target.value })}
            placeholder="Acme Mobile Labs"
            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5">
            Support Email
          </label>
          <input
            type="email"
            value={d.supportEmail}
            onChange={(e) => updateDev({ supportEmail: e.target.value })}
            placeholder="support@yourdomain.com"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5">
            Developer Website / Portfolio
          </label>
          <input
            type="url"
            value={d.websiteUrl}
            onChange={(e) => updateDev({ websiteUrl: e.target.value })}
            placeholder="https://yourdomain.com"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5">
            Privacy Policy URL (Required for Play Store)
          </label>
          <input
            type="url"
            value={d.privacyPolicyUrl}
            onChange={(e) => updateDev({ privacyPolicyUrl: e.target.value })}
            placeholder="https://yourdomain.com/privacy"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5">
            Terms of Service URL
          </label>
          <input
            type="url"
            value={d.termsUrl}
            onChange={(e) => updateDev({ termsUrl: e.target.value })}
            placeholder="https://yourdomain.com/terms"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
          />
        </div>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <div className="text-xs font-medium text-slate-700 mb-3">
          Social Media & Community Links
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {[
            { key: 'githubUrl', label: 'GitHub', placeholder: 'https://github.com/username' },
            { key: 'xTwitterUrl', label: 'X / Twitter', placeholder: 'https://x.com/handle' },
            { key: 'youtubeUrl', label: 'YouTube', placeholder: 'https://youtube.com/@channel' },
            { key: 'discordUrl', label: 'Discord Invite', placeholder: 'https://discord.gg/invite' },
            { key: 'instagramUrl', label: 'Instagram', placeholder: 'https://instagram.com/handle' },
            { key: 'tiktokUrl', label: 'TikTok', placeholder: 'https://tiktok.com/@handle' },
          ].map((field) => (
            <div key={field.key}>
              <label className="block text-xs text-slate-600 mb-1">
                {field.label}
              </label>
              <input
                type="url"
                value={String(d[field.key as keyof DeveloperProfile] || '')}
                onChange={(e) =>
                  updateDev({ [field.key]: e.target.value } as Partial<DeveloperProfile>)
                }
                placeholder={field.placeholder}
                className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
