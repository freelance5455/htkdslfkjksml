import React, { useState, useEffect } from 'react';
import { Flame, Trophy, ShieldCheck, ArrowRight, X } from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

export const OnboardingModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    const hasSeen = localStorage.getItem('est_onboarding_seen');
    if (!hasSeen) {
      setIsOpen(true);
    }
  }, []);

  const closeOnboarding = () => {
    localStorage.setItem('est_onboarding_seen', 'true');
    setIsOpen(false);
  };

  if (!isOpen) return null;

  const slides = [
    {
      title: `Welcome to ${APP_CONFIG.appName}`,
      subtitle: `The premier Free Fire tournament platform built by ${APP_CONFIG.developerName}.`,
      desc: "Join daily Battle Royale and Clash Squad 4v4 custom matches. Win cash prizes directly credited to your wallet with transparent per-kill bounties.",
      icon: Flame,
      color: "text-red-500",
      bg: "bg-red-500/10 border-red-500/30"
    },
    {
      title: "Instant Room ID & Password",
      subtitle: "Never wait in long queues or messy third-party groups.",
      desc: "Our automated room scheduler unlocks your Free Fire custom room credentials exactly 15 minutes before the match start in the 'My Matches' tab.",
      icon: Trophy,
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/30"
    },
    {
      title: "Fast bKash & Nagad Cashouts",
      subtitle: "0% fee on winnings withdrawals.",
      desc: "Instant deposits and fast cashouts directly to your personal mobile banking account, backed by double-entry auditable ledger security.",
      icon: ShieldCheck,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10 border-emerald-500/30"
    }
  ];

  const current = slides[slide];
  const Icon = current.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md bg-[#0c1017] border border-red-950/60 rounded-3xl p-6 shadow-2xl text-center space-y-4">
        <button
          onClick={closeOnboarding}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className={`w-16 h-16 rounded-2xl mx-auto flex items-center justify-center border ${current.bg} ${current.color} shadow-lg`}>
          <Icon className="w-8 h-8" />
        </div>

        <div>
          <h3 className="text-xl font-bold font-display text-white mb-1">
            {current.title}
          </h3>
          <p className="text-xs font-semibold text-red-400 mb-2">
            {current.subtitle}
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            {current.desc}
          </p>
        </div>

        {/* Dots */}
        <div className="flex items-center justify-center gap-1.5 pt-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              className={`h-1.5 rounded-full transition-all ${
                slide === i ? 'w-6 bg-red-600' : 'w-1.5 bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Next / Get Started button */}
        <button
          onClick={() => {
            if (slide < slides.length - 1) {
              setSlide(slide + 1);
            } else {
              closeOnboarding();
            }
          }}
          className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/50"
        >
          <span>{slide === slides.length - 1 ? 'Start Competing Now' : 'Continue'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
