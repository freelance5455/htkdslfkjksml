import {
  Award,
  Briefcase,
  Check,
  Clock,
  GraduationCap,
  MessageCircle,
  Plane,
  Sparkles,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { BANDS, BAND_META } from '../data/constants';
import type { CefrBand, DailyPaceMinutes, LearningGoalId } from '../types';
import { paceToDailyGoal } from '../utils/learningFeaturesLogic';

interface OnboardingModalProps {
  open: boolean;
  initialGoal?: LearningGoalId;
  initialPace?: DailyPaceMinutes;
  initialBand?: CefrBand;
  onComplete: (result: {
    learningGoal: LearningGoalId;
    dailyPaceMinutes: DailyPaceMinutes;
    dailyGoal: number;
    lastBand: CefrBand;
  }) => void;
  onLaunchPlacement: (result: {
    learningGoal: LearningGoalId;
    dailyPaceMinutes: DailyPaceMinutes;
    dailyGoal: number;
  }) => void;
  onSkip: () => void;
}

const GOALS: Array<{
  id: LearningGoalId;
  titleAr: string;
  descAr: string;
  icon: typeof MessageCircle;
}> = [
  {
    id: 'daily_chat',
    titleAr: 'المحادثة اليومية',
    descAr: 'التحدث بطلاقة وثقة في المواقف اليومية والحياة العامة',
    icon: MessageCircle,
  },
  {
    id: 'work_interviews',
    titleAr: 'العمل والمقابلات',
    descAr: 'تطوير الإنجليزية المهنية والاجتماعات ومقابلات الوظائف',
    icon: Briefcase,
  },
  {
    id: 'travel',
    titleAr: 'السفر والسياحة',
    descAr: 'التعامل بسهولة في المطار والفندق والمطاعم والتنقل',
    icon: Plane,
  },
  {
    id: 'study_exams',
    titleAr: 'الدراسة والامتحانات',
    descAr: 'بناء مفردات وقواعد قوية للجامعة واختبارات IELTS / TOEFL',
    icon: GraduationCap,
  },
];

const PACES: Array<{
  minutes: DailyPaceMinutes;
  titleAr: string;
  descAr: string;
  wordsLabel: string;
}> = [
  {
    minutes: 5,
    titleAr: 'خفيف — 5 دقائق يومياً',
    descAr: 'مثالي لبناء عادة يومية بدون أي ضغط',
    wordsLabel: '10 كلمات يومياً',
  },
  {
    minutes: 10,
    titleAr: 'متوازن — 10 دقائق يومياً',
    descAr: 'التوازن الأفضل لتقدم ثابت وملموس كل أسبوع',
    wordsLabel: '20 كلمة يومياً',
  },
  {
    minutes: 20,
    titleAr: 'مكثّف — 20 دقيقة يومياً',
    descAr: 'تقدّم سريع للوصول إلى الطلاقة في وقت أقصر',
    wordsLabel: '40 كلمة يومياً',
  },
];

export function OnboardingModal({
  open,
  initialGoal = 'daily_chat',
  initialPace = 10,
  initialBand = 'A0',
  onComplete,
  onLaunchPlacement,
  onSkip,
}: OnboardingModalProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [goal, setGoal] = useState<LearningGoalId>(initialGoal);
  const [pace, setPace] = useState<DailyPaceMinutes>(initialPace);
  const [band, setBand] = useState<CefrBand>(initialBand);

  if (!open) return null;

  const handleFinish = () => {
    onComplete({
      learningGoal: goal,
      dailyPaceMinutes: pace,
      dailyGoal: paceToDailyGoal(pace),
      lastBand: band,
    });
  };

  const handleStartPlacement = () => {
    onLaunchPlacement({
      learningGoal: goal,
      dailyPaceMinutes: pace,
      dailyGoal: paceToDailyGoal(pace),
    });
  };

  return (
    <div
      data-testid="onboarding-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="إعداد خطة التعلم الذكية"
    >
      <div className="tmn-card relative flex max-h-[90vh] w-full max-w-xl flex-col overflow-hidden rounded-3xl">
        {/* Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600/12 text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-300">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
            </div>
            <div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                خصّص خطتك في 30 ثانية
              </div>
              <div className="text-[11px] font-semibold text-slate-500 tabular-nums dark:text-slate-400">
                الخطوة {step} من 3
              </div>
            </div>
          </div>

          <button
            type="button"
            data-testid="onboarding-skip-btn"
            onClick={onSkip}
            className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <span>تخطي</span>
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* 3-Step Indicator Bar */}
        <div className="grid grid-cols-3 gap-2 px-5 pt-4 sm:px-6">
          {[1, 2, 3].map((idx) => (
            <div
              key={idx}
              className={`h-1.5 rounded-full transition-colors ${
                idx <= step
                  ? 'bg-indigo-600 dark:bg-indigo-400'
                  : 'bg-slate-200 dark:bg-slate-800'
              }`}
            />
          ))}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  ما هو هدفك الرئيسي من تعلم الإنجليزية؟
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  سنرتّب خطتك اليومية بما يتناسب مع هدفك.
                </p>
              </div>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {GOALS.map((item) => {
                  const Icon = item.icon;
                  const active = goal === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      data-testid={`onboarding-goal-${item.id}`}
                      onClick={() => setGoal(item.id)}
                      className={`flex flex-col items-start gap-2 rounded-2xl border p-4 text-start transition-colors ${
                        active
                          ? 'border-indigo-500 bg-indigo-50/80 dark:border-indigo-400 dark:bg-indigo-500/15'
                          : 'border-slate-200/80 bg-slate-50/70 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900/50 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex w-full items-center justify-between">
                        <div
                          className={`flex h-9 w-9 items-center justify-center rounded-xl ${
                            active
                              ? 'bg-indigo-600 text-white'
                              : 'bg-white text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          <Icon className="h-4.5 w-4.5" aria-hidden="true" />
                        </div>
                        {active && (
                          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-600 text-white">
                            <Check className="h-3.5 w-3.5" />
                          </span>
                        )}
                      </div>
                      <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                        {item.titleAr}
                      </div>
                      <div className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                        {item.descAr}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  كم دقيقة تناسبك يومياً؟
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  سنضبط هدف الكلمات اليومي تلقائياً ويمكنك تغييره في أي وقت.
                </p>
              </div>
              <div className="space-y-2.5">
                {PACES.map((item) => {
                  const active = pace === item.minutes;
                  return (
                    <button
                      key={item.minutes}
                      type="button"
                      data-testid={`onboarding-pace-${item.minutes}`}
                      onClick={() => setPace(item.minutes)}
                      className={`flex w-full items-center justify-between gap-3 rounded-2xl border p-4 text-start transition-colors ${
                        active
                          ? 'border-indigo-500 bg-indigo-50/80 dark:border-indigo-400 dark:bg-indigo-500/15'
                          : 'border-slate-200/80 bg-slate-50/70 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900/50 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                            active
                              ? 'bg-indigo-600 text-white'
                              : 'bg-white text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="h-4.5 w-4.5" aria-hidden="true" />
                        </div>
                        <div>
                          <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                            {item.titleAr}
                          </div>
                          <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                            {item.descAr}
                          </div>
                        </div>
                      </div>
                      <span className="shrink-0 text-xs font-bold text-indigo-600 tabular-nums dark:text-indigo-300">
                        {item.wordsLabel}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  اختر مستوى البداية المناسب لك
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  اختر مستواك مباشرة من A0 إلى C2 أو ابدأ باختبار تحديد المستوى السريع.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {BANDS.map((b) => {
                  const meta = BAND_META[b];
                  const active = band === b;
                  return (
                    <button
                      key={b}
                      type="button"
                      data-testid={`onboarding-band-${b}`}
                      onClick={() => setBand(b)}
                      className={`flex flex-col items-start rounded-xl border p-3 text-start transition-colors ${
                        active
                          ? 'border-indigo-500 bg-indigo-600 text-white shadow-sm'
                          : 'border-slate-200/80 bg-slate-50/70 text-slate-800 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900/50 dark:text-slate-200'
                      }`}
                    >
                      <span className="font-en text-base font-extrabold">{b}</span>
                      <span
                        className={`mt-0.5 text-[11px] font-semibold ${
                          active ? 'text-indigo-100' : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {meta.ar}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="rounded-2xl border border-indigo-200/70 bg-indigo-50/60 p-4 dark:border-indigo-500/25 dark:bg-indigo-500/10">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <Award className="h-5 w-5 text-indigo-600 dark:text-indigo-300" aria-hidden="true" />
                    <div>
                      <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                        غير متأكد من مستواك؟
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-300">
                        اختبر مهاراتك الـ 6 لتحديد مستواك الدقيق تلقائياً
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    data-testid="onboarding-placement-btn"
                    onClick={handleStartPlacement}
                    className="whitespace-nowrap rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white transition-colors hover:bg-indigo-700"
                  >
                    ابدأ اختبار تحديد المستوى
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Buttons */}
        <div className="flex items-center justify-between gap-3 border-t border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => setStep((s) => (s === 3 ? 2 : 1))}
              className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
            >
              السابق
            </button>
          ) : (
            <span className="text-[11px] font-medium text-slate-400">
              يمكنك تعديل خطتك لاحقاً من الإعدادات
            </span>
          )}

          {step < 3 ? (
            <button
              type="button"
              data-testid="onboarding-next-btn"
              onClick={() => setStep((s) => (s === 1 ? 2 : 3))}
              className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-indigo-700"
            >
              التالي
            </button>
          ) : (
            <button
              type="button"
              data-testid="onboarding-finish-btn"
              onClick={handleFinish}
              className="rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-emerald-700"
            >
              اعتماد خطتي والبدء
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
