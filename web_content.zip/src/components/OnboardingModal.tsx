import React, { useState } from 'react';
import { AlertCircle, ShieldCheck, Heart, PhoneCall, Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { supportedLanguages, changeAppLanguage } from '../i18n/index.ts';

interface OnboardingModalProps {
  isOpen: boolean;
  onAccept: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onAccept,
}) => {
  const { t, i18n } = useTranslation();
  const [hasAgreed, setHasAgreed] = useState<boolean>(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 my-auto text-left">
        {/* Language switcher right inside the disclaimer modal */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Globe className="w-4 h-4 text-slate-400" />
            <span>Choisir la langue / Language :</span>
          </div>
          <select
            value={i18n.language.substring(0, 2)}
            onChange={(e) => changeAppLanguage(e.target.value)}
            className="text-xs font-semibold px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none"
          >
            {supportedLanguages.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.flag} {lang.label}
              </option>
            ))}
          </select>
        </div>

        {/* Modal Badge & Title */}
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 flex items-center justify-center shrink-0">
            <AlertCircle className="w-7 h-7" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300">
              {t('disclaimerModal.mandatoryBadge')}
            </span>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mt-1">
              {t('disclaimerModal.title')}
            </h2>
          </div>
        </div>

        {/* Core Mandatory Disclaimer text */}
        <div className="p-4 rounded-2xl bg-rose-50/70 dark:bg-slate-800/80 border border-rose-200/60 dark:border-slate-700 space-y-3 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          <p className="font-semibold text-rose-900 dark:text-rose-200">
            "{t('disclaimerModal.body1')}"
          </p>

          <p className="text-xs">
            {t('disclaimerModal.body2')}
          </p>

          <div className="pt-2 border-t border-rose-200/50 dark:border-slate-700 flex flex-wrap items-center gap-2">
            <a
              href="tel:3114"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold shadow-xs hover:bg-rose-700"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>3114 (France 24/7)</span>
            </a>
            <a
              href="tel:112"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-white text-xs font-bold hover:bg-slate-700"
            >
              <span>112 (Europe)</span>
            </a>
            <a
              href="tel:988"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-700 text-white text-xs font-bold hover:bg-teal-800"
            >
              <span>988 (USA/Canada)</span>
            </a>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 italic pt-1">
            {t('disclaimerModal.body3')}
          </p>
        </div>

        {/* Checkbox agreement */}
        <label className="flex items-start gap-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={hasAgreed}
            onChange={(e) => setHasAgreed(e.target.checked)}
            className="mt-1 w-5 h-5 rounded-lg border-slate-300 text-rose-600 focus:ring-rose-400 accent-rose-600 cursor-pointer shrink-0"
          />
          <span className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200 group-hover:text-rose-600 transition-colors">
            {t('disclaimerModal.checkboxLabel')}
          </span>
        </label>

        {/* Action Button */}
        <button
          onClick={onAccept}
          disabled={!hasAgreed}
          className={`w-full py-4 px-6 rounded-2xl font-bold text-base transition-all flex items-center justify-center gap-2 shadow-lg ${
            hasAgreed
              ? 'bg-gradient-to-r from-rose-500 to-teal-600 hover:from-rose-600 hover:to-teal-700 text-white shadow-rose-200 dark:shadow-none cursor-pointer'
              : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed shadow-none'
          }`}
        >
          <ShieldCheck className="w-5 h-5" />
          <span>{t('disclaimerModal.confirmButton')}</span>
        </button>
      </div>
    </div>
  );
};
