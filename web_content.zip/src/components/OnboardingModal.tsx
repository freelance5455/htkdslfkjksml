import React, { useState } from 'react';
import { UserProfile } from '../types';
import { StorageService } from '../services/storage';
import { Zap, ArrowRight, ShieldCheck } from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: (profile: UserProfile) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onComplete }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState<number>(22);
  const [heightCm, setHeightCm] = useState<number>(175);
  const [weightKg, setWeightKg] = useState<number>(68);
  const [experience, setExperience] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [currentPb1600m, setCurrentPb1600m] = useState('5:30');
  const [weeklyVolumeKm, setWeeklyVolumeKm] = useState<number>(20);
  const [trainingDaysPerWeek, setTrainingDaysPerWeek] = useState<number>(5);
  const [preferredLanguage, setPreferredLanguage] = useState<'Hinglish' | 'Hindi' | 'English'>('Hinglish');
  const [preferredTime, setPreferredTime] = useState<'Morning' | 'Evening'>('Morning');
  const [currentInjuries, setCurrentInjuries] = useState('None');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const profile: UserProfile = {
      name: name.trim() || 'Runner',
      age,
      heightCm,
      weightKg,
      experience,
      currentPb1600m: currentPb1600m || '5:30',
      target1600m: '4:50',
      weeklyVolumeKm,
      trainingDaysPerWeek,
      currentInjuries: currentInjuries.trim() || 'None',
      medicalLimitations: 'None',
      preferredLanguage,
      preferredTime,
      hasCompletedOnboarding: true,
      isBaselineVerified: false,
    };

    StorageService.saveProfile(profile);
    onComplete(profile);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
        {/* Brand Banner */}
        <div className="text-center space-y-1.5">
          <div className="w-12 h-12 rounded-2xl bg-black border-2 border-[#00FF66] flex items-center justify-center mx-auto glow-neon-sm">
            <Zap className="w-7 h-7 text-[#00FF66] fill-[#00FF66]/20" />
          </div>
          <h1 className="font-athletic text-2xl font-black uppercase tracking-tight text-white mt-2">
            JAAT RUNNER
          </h1>
          <p className="text-xs uppercase tracking-widest text-[#00FF66] font-bold">
            Run With Discipline &bull; Train With Purpose
          </p>
          <p className="text-xs text-zinc-400">
            Welcome, Athlete. Setup your 1600m baseline to generate your personalized coaching plan.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-zinc-300 block mb-1">Runner Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#00FF66]"
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="font-medium text-zinc-400 block mb-1">Age</label>
              <input
                type="number"
                min="14"
                max="80"
                value={Number.isNaN(age) || age === 0 ? '' : age}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setAge(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2.5 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="font-medium text-zinc-400 block mb-1">Height (cm)</label>
              <input
                type="number"
                min="130"
                max="220"
                value={Number.isNaN(heightCm) || heightCm === 0 ? '' : heightCm}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setHeightCm(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2.5 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="font-medium text-zinc-400 block mb-1">Weight (kg)</label>
              <input
                type="number"
                min="40"
                max="140"
                value={Number.isNaN(weightKg) || weightKg === 0 ? '' : weightKg}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setWeightKg(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2.5 py-2 text-sm text-white"
              />
            </div>
          </div>

          {/* 1600m Target & Baseline */}
          <div className="p-3 bg-black/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-[#00FF66] uppercase">Main Objective</span>
              <span className="text-[10px] bg-[#00FF66]/20 text-[#00FF66] px-2 py-0.5 rounded font-mono-numbers font-bold">
                Goal: 4:50 (Sub 5m)
              </span>
            </div>

            <div>
              <label className="font-medium text-zinc-300 block mb-1">
                Current / Estimated 1600m Personal Best
              </label>
              <input
                type="text"
                value={currentPb1600m}
                onChange={(e) => setCurrentPb1600m(e.target.value)}
                placeholder="e.g. 5:30"
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3 py-1.5 text-sm font-mono-numbers text-white"
              />
              <span className="text-[10px] text-zinc-400 block mt-1">
                Note: Treated as unverified until confirmed in a live GPS time trial.
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-zinc-400 block mb-1">Experience</label>
              <select
                value={experience}
                onChange={(e) => setExperience(e.target.value as any)}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2 py-2 text-xs text-white"
              >
                <option value="Beginner">Beginner (0-6 mos)</option>
                <option value="Intermediate">Intermediate (1-2 yrs)</option>
                <option value="Advanced">Advanced / Competitor</option>
              </select>
            </div>

            <div>
              <label className="font-medium text-zinc-400 block mb-1">Days / Week</label>
              <select
                value={trainingDaysPerWeek}
                onChange={(e) => setTrainingDaysPerWeek(parseInt(e.target.value))}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2 py-2 text-xs text-white"
              >
                <option value={4}>4 Days</option>
                <option value={5}>5 Days</option>
                <option value={6}>6 Days</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-zinc-400 block mb-1">Coach Language</label>
              <select
                value={preferredLanguage}
                onChange={(e) => setPreferredLanguage(e.target.value as any)}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2 py-2 text-xs text-white"
              >
                <option value="Hinglish">Hinglish</option>
                <option value="Hindi">Hindi (हिन्दी)</option>
                <option value="English">English</option>
              </select>
            </div>

            <div>
              <label className="font-medium text-zinc-400 block mb-1">Training Time</label>
              <select
                value={preferredTime}
                onChange={(e) => setPreferredTime(e.target.value as any)}
                className="w-full bg-black border border-zinc-700 rounded-xl px-2 py-2 text-xs text-white"
              >
                <option value="Morning">Early Morning</option>
                <option value="Evening">Evening</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-medium text-zinc-400 block mb-1">
              Any Current Injuries or Pain?
            </label>
            <input
              type="text"
              value={currentInjuries}
              onChange={(e) => setCurrentInjuries(e.target.value)}
              placeholder="e.g. none, or right knee tightness"
              className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-1.5 text-xs text-white"
            />
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-3.5 rounded-xl bg-[#00FF66] text-black font-athletic font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-[#10B981] transition shadow-lg glow-neon-sm active:scale-95"
          >
            <span>Activate JAAT RUNNER</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
