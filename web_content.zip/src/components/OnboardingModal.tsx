import React, { useState } from 'react';
import { GradeLevel, StudentProfile } from '../types';
import { GRADE_LEVELS, AVATAR_OPTIONS } from '../utils/sampleData';
import { Sparkles, GraduationCap, School, User, Check, BookOpen } from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface OnboardingModalProps {
  isOpen: boolean;
  onSaveProfile: (profile: StudentProfile) => void;
  existingProfile?: StudentProfile | null;
  onClose?: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onSaveProfile,
  existingProfile,
  onClose,
}) => {
  const [name, setName] = useState(existingProfile?.name || '');
  const [grade, setGrade] = useState<GradeLevel>(existingProfile?.grade || '8th Grade');
  const [schoolName, setSchoolName] = useState(existingProfile?.schoolName || '');
  const [selectedAvatar, setSelectedAvatar] = useState(existingProfile?.avatar || '🦉');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!schoolName.trim()) {
      setError('Please enter your school name.');
      return;
    }

    setError('');
    const profile: StudentProfile = {
      name: name.trim(),
      grade,
      schoolName: schoolName.trim(),
      avatar: selectedAvatar,
      createdAt: existingProfile?.createdAt || new Date().toISOString(),
      studyStreakDays: existingProfile?.studyStreakDays || 1,
      lastStudyDate: new Date().toISOString().split('T')[0],
      solvedProblemsCount: existingProfile?.solvedProblemsCount || 0,
      writtenParagraphsCount: existingProfile?.writtenParagraphsCount || 0,
      writtenEssaysCount: existingProfile?.writtenEssaysCount || 0,
      checkedGrammarCount: existingProfile?.checkedGrammarCount || 0,
    };

    fireCelebration();
    onSaveProfile(profile);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header gradient banner */}
        <div className="bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-700 px-6 pt-7 pb-6 text-white text-center relative overflow-hidden">
          <div className="absolute -top-12 -right-12 w-36 h-36 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-amber-400/20 rounded-full blur-xl pointer-events-none" />

          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-semibold tracking-wide uppercase text-blue-100 mb-3 border border-white/20">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            No Password Or Email Needed
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight">
            {existingProfile ? 'Edit Your Student Profile' : 'Welcome to StudySnap AI'}
          </h2>
          <p className="text-blue-100 text-sm mt-1 max-w-sm mx-auto">
            {existingProfile
              ? 'Update your grade level to keep AI explanations perfectly tailored.'
              : 'Create your account instantly. Just your name, grade, and school to get personalized tutoring!'}
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-xl flex items-center gap-2">
              <span className="font-semibold">Notice:</span> {error}
            </div>
          )}

          {/* Avatar Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Pick Your Study Avatar
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  type="button"
                  key={av.emoji}
                  onClick={() => setSelectedAvatar(av.emoji)}
                  className={`flex flex-col items-center justify-center p-2 rounded-2xl border-2 transition-all text-2xl ${
                    selectedAvatar === av.emoji
                      ? 'border-blue-600 bg-blue-50 shadow-md scale-105'
                      : 'border-slate-100 hover:border-slate-200 bg-slate-50'
                  }`}
                  title={av.label}
                >
                  <span>{av.emoji}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Name Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-600" />
              Your Name or Nickname
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Maya Carter"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600 text-slate-800 text-sm transition"
            />
          </div>

          {/* Grade Level Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-blue-600" />
              Your Current Grade Level
            </label>
            <div className="relative">
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value as GradeLevel)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600 text-slate-800 text-sm transition appearance-none cursor-pointer"
              >
                {GRADE_LEVELS.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              AI solutions, essays, and paragraphs will automatically adjust vocabulary & depth to your grade.
            </p>
          </div>

          {/* School Name Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <School className="w-4 h-4 text-blue-600" />
              School Name
            </label>
            <input
              type="text"
              required
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              placeholder="e.g. Lincoln High School or Oakridge Middle"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600 text-slate-800 text-sm transition"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center gap-3">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-3 rounded-xl border border-slate-200 text-slate-600 font-semibold text-sm hover:bg-slate-100 transition"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              {existingProfile ? 'Save Changes' : 'Start Studying Now'}
            </button>
          </div>

          <div className="text-center">
            <span className="text-xs text-slate-400">
              🔒 100% private. Stored in your browser session with zero login hassles.
            </span>
          </div>
        </form>
      </div>
    </div>
  );
};
