import React, { useState } from 'react';
import { Mail, Phone, ShieldCheck, ArrowRight, UserCheck, KeyRound } from 'lucide-react';

interface OnboardingModalProps {
  onComplete: (isGuest: boolean, email?: string) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [authMode, setAuthMode] = useState<'welcome' | 'signin'>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const slides = [
    {
      icon: Mail,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      title: 'Disposable Email Addresses',
      description:
        'Instant temporary inboxes. Neutralize tracking pixels, block spam, and receive activation links with auto-detected OTP codes.',
    },
    {
      icon: Phone,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      title: 'Temporary SMS Phone Numbers',
      description:
        'Rent private numbers across the US, UK, Canada, and Europe to receive SMS verifications for WhatsApp, Uber, Telegram, and Discord.',
    },
    {
      icon: ShieldCheck,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      title: 'Zero Tracking & Total Privacy',
      description:
        'All message bodies are encrypted at rest with AES-256-GCM. Unused numbers are automatically refunded to your credit balance.',
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setAuthMode('welcome');
    }
  };

  const handleGuest = () => {
    onComplete(true);
  };

  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    onComplete(false, email);
  };

  const CurrentIcon = slides[currentSlide].icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md p-6 sm:p-8 shadow-2xl relative text-center text-slate-800">
        {authMode === 'welcome' && (
          <div>
            {/* ICON HERO */}
            <div
              className={`w-16 h-16 rounded-3xl border flex items-center justify-center mx-auto mb-6 shadow-inner ${slides[currentSlide].color}`}
            >
              <CurrentIcon className="w-8 h-8" />
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">{slides[currentSlide].title}</h2>
            <p className="text-xs sm:text-sm text-slate-500 mb-8 leading-relaxed max-w-xs mx-auto">
              {slides[currentSlide].description}
            </p>

            {/* SLIDE INDICATORS */}
            <div className="flex items-center justify-center gap-1.5 mb-8">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`h-1.5 rounded-full transition-all ${
                    currentSlide === i ? 'w-6 bg-blue-600' : 'w-1.5 bg-slate-200'
                  }`}
                />
              ))}
            </div>

            {currentSlide < slides.length - 1 ? (
              <button
                onClick={handleNext}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-600/25"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="space-y-3">
                <button
                  onClick={handleGuest}
                  className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-600/25"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Start Instantly in Guest Mode</span>
                </button>
                <button
                  onClick={() => setAuthMode('signin')}
                  className="w-full py-3 rounded-2xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs transition-colors border border-slate-200"
                >
                  Sign in with Email / Account
                </button>
              </div>
            )}
          </div>
        )}

        {authMode === 'signin' && (
          <div>
            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <KeyRound className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-1">Sign In to TempBox</h3>
            <p className="text-xs text-slate-500 mb-6">Access your cloud sync across mobile and desktop.</p>

            <form onSubmit={handleSignInSubmit} className="space-y-3.5 text-left">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer shadow-md shadow-blue-600/25"
              >
                Sign In
              </button>

              <button
                type="button"
                onClick={() => setAuthMode('welcome')}
                className="w-full text-center text-xs text-slate-500 hover:text-slate-900 pt-2"
              >
                Back to Guest Mode
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
