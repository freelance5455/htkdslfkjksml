import React, { useState } from 'react';
import { 
  Sparkles, 
  GraduationCap, 
  Building2, 
  Briefcase, 
  BookOpen, 
  Check, 
  Calendar, 
  Clock, 
  Target, 
  ArrowRight,
  CheckSquare,
  Square,
  AlertCircle,
  HelpCircle,
  ListFilter
} from 'lucide-react';
import { UserProfile, ExamCategory, Language } from '../types';
import { EXAM_CATEGORIES, getExamSubjects, ALL_STANDARD_SUBJECTS } from '../presets';

interface OnboardingModalProps {
  language: Language;
  onComplete: (profile: UserProfile) => void;
  initialProfile?: UserProfile;
}

export default function OnboardingModal({ language, onComplete, initialProfile }: OnboardingModalProps) {
  const [step, setStep] = useState<number>(1);
  const [name, setName] = useState<string>(initialProfile?.name || 'Rahul');
  const [category, setCategory] = useState<ExamCategory>(initialProfile?.category || 'govt');
  const [subCategory, setSubCategory] = useState<string>(initialProfile?.subCategory || 'railway');
  const [targetExam, setTargetExam] = useState<string>(initialProfile?.targetExam || 'RRB NTPC');
  const [customExamName, setCustomExamName] = useState<string>(initialProfile?.customExamName || '');
  
  // Selected Subjects State
  const initialSubjects = initialProfile?.selectedSubjects && initialProfile.selectedSubjects.length > 0
    ? initialProfile.selectedSubjects
    : getExamSubjects(initialProfile?.targetExam || 'RRB NTPC');
  
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(initialSubjects);
  const [dailyQuestionTarget, setDailyQuestionTarget] = useState<number>(initialProfile?.dailyQuestionTarget || 100);
  
  const [qualification, setQualification] = useState<string>(initialProfile?.qualification || 'Graduate');
  const [boardOrUniversity, setBoardOrUniversity] = useState<string>(initialProfile?.boardOrUniversity || 'RRB Board');
  const [targetYear, setTargetYear] = useState<string>(initialProfile?.targetYear || '2026');
  const [examDate, setExamDate] = useState<string>(initialProfile?.examDate || '2026-09-15');
  const [dailyTime, setDailyTime] = useState<number>(initialProfile?.dailyStudyTimeMinutes || 120);
  const [currentLevel, setCurrentLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>(initialProfile?.currentLevel || 'Intermediate');
  const [subjectError, setSubjectError] = useState<string>('');

  const selectedCategoryObj = EXAM_CATEGORIES.find(c => c.id === category) || EXAM_CATEGORIES[0];
  const availableSubjects = category === 'custom' && customExamName 
    ? ALL_STANDARD_SUBJECTS
    : getExamSubjects(targetExam);

  // Toggle subject selection
  const handleToggleSubject = (subject: string) => {
    setSubjectError('');
    setSelectedSubjects(prev => {
      if (prev.includes(subject)) {
        return prev.filter(s => s !== subject);
      } else {
        return [...prev, subject];
      }
    });
  };

  const handleSelectAllSubjects = () => {
    setSubjectError('');
    setSelectedSubjects([...availableSubjects]);
  };

  const handleClearAllSubjects = () => {
    setSelectedSubjects([]);
  };

  const handleExamChange = (newExam: string) => {
    setTargetExam(newExam);
    const newSubjects = getExamSubjects(newExam);
    setSelectedSubjects(newSubjects);
  };

  const handleFinish = () => {
    if (selectedSubjects.length === 0) {
      setSubjectError(language === 'bn' ? 'অনুগ্রহ করে কমপক্ষে একটি বিষয় নির্বাচন করুন' : 'Please select at least 1 subject');
      setStep(3);
      return;
    }

    const finalExam = category === 'custom' && customExamName.trim() ? customExamName : targetExam;
    const updated: UserProfile = {
      name: name.trim() || 'Learner',
      category,
      subCategory,
      qualification,
      boardOrUniversity,
      targetExam: finalExam,
      customExamName: category === 'custom' ? customExamName : undefined,
      selectedSubjects,
      dailyQuestionTarget,
      targetYear,
      examDate: examDate || undefined,
      dailyStudyTimeMinutes: dailyTime,
      currentLevel,
      preferredLanguage: language,
      notificationsEnabled: true,
      theme: 'light',
      onboardingCompleted: true,
      streakDays: initialProfile?.streakDays || 1,
      lastActiveDate: new Date().toISOString().split('T')[0]
    };
    onComplete(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl max-w-2xl w-full p-6 md:p-8 shadow-2xl relative my-8">
        
        {/* Top Progress Header */}
        <div className="flex items-center justify-between pb-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-600 rounded-2xl shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-6 h-6 text-white animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-black text-white font-display">
                {language === 'bn' ? 'StudySkill AI ব্যক্তিকেন্দ্রিক সেটআপ' : 'Personalize Your StudySkill AI'}
              </h2>
              <p className="text-xs text-indigo-300 font-medium">
                {language === 'bn' ? `ধাপ ${step} এর ৪` : `Step ${step} of 4`}
              </p>
            </div>
          </div>
          <div className="flex gap-1.5">
            {[1, 2, 3, 4].map(s => (
              <div 
                key={s} 
                className={`h-2 rounded-full transition-all duration-300 ${
                  s === step ? 'w-8 bg-indigo-500' : s < step ? 'w-3 bg-indigo-800' : 'w-3 bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* STEP 1: Name & Prep Category */}
        {step === 1 && (
          <div className="py-6 space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {language === 'bn' ? 'আপনার সুন্দর নাম' : 'Your Name'}
              </label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name"
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <h3 className="text-sm font-extrabold text-white mb-3 flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-400" />
                {language === 'bn' ? 'আপনি কিসের প্রস্তুতি নিচ্ছেন?' : 'What are you preparing for?'}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {EXAM_CATEGORIES.map((cat) => {
                  const isSel = category === cat.id;
                  const title = language === 'bn' ? cat.title.bn : cat.title.en;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setCategory(cat.id as ExamCategory);
                        const firstExam = cat.exams[0]?.id || 'Madhyamik';
                        handleExamChange(firstExam);
                      }}
                      className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-3 cursor-pointer ${
                        isSel 
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10' 
                          : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <div className={`p-2.5 rounded-xl shrink-0 ${isSel ? 'bg-indigo-600 text-white' : 'bg-slate-700 text-slate-300'}`}>
                        {cat.id === 'school' && <GraduationCap className="w-5 h-5" />}
                        {cat.id === 'college' && <BookOpen className="w-5 h-5" />}
                        {cat.id === 'govt' && <Building2 className="w-5 h-5" />}
                        {cat.id === 'private' && <Briefcase className="w-5 h-5" />}
                        {cat.id === 'custom' && <Sparkles className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="font-bold text-sm">{title}</div>
                        <div className="text-[11px] text-slate-400 mt-1">
                          {cat.exams.map(e => e.label).slice(0, 2).join(', ')}...
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setStep(2)}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30 transition-all"
              >
                {language === 'bn' ? 'পরবর্তী ধাপ' : 'Next Step'} <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Exact Exam Selection & Sub-category */}
        {step === 2 && (
          <div className="py-6 space-y-6">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <ListFilter className="w-4 h-4 text-indigo-400" />
              {language === 'bn' ? 'আপনার নির্দিষ্ট টার্গেট পরীক্ষা নির্বাচন করুন' : 'Select your exact target exam'}
            </h3>

            {category === 'govt' && selectedCategoryObj.subCategories && (
              <div className="flex flex-wrap gap-2 pb-2 border-b border-slate-800">
                {selectedCategoryObj.subCategories.map(sub => (
                  <button
                    key={sub.id}
                    onClick={() => {
                      setSubCategory(sub.id);
                      if (sub.exams[0]) handleExamChange(sub.exams[0]);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      subCategory === sub.id 
                        ? 'bg-indigo-600 text-white' 
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    {language === 'bn' ? sub.name.bn : sub.name.en}
                  </button>
                ))}
              </div>
            )}

            {category === 'custom' ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-indigo-300 mb-1">
                    {language === 'bn' ? 'কাস্টম পরীক্ষার নাম' : 'Custom Exam Name'}
                  </label>
                  <input
                    type="text"
                    value={customExamName}
                    onChange={(e) => setCustomExamName(e.target.value)}
                    placeholder="e.g. WBSET / GATE / Custom Exam 2026"
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto pr-1">
                {selectedCategoryObj.exams.map((ex) => {
                  const isSel = targetExam === ex.id;
                  return (
                    <button
                      key={ex.id}
                      onClick={() => handleExamChange(ex.id)}
                      className={`p-3.5 rounded-xl border text-left text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                        isSel
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow-md'
                          : 'bg-slate-800 border-slate-700/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <span>{ex.label}</span>
                      {isSel && <Check className="w-4 h-4 text-white" />}
                    </button>
                  );
                })}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  {language === 'bn' ? 'পর্ষদ / বোর্ড / বিশ্ববিদ্যালয়' : 'Board / University'}
                </label>
                <input
                  type="text"
                  value={boardOrUniversity}
                  onChange={(e) => setBoardOrUniversity(e.target.value)}
                  placeholder="e.g. WBBSE / RRB / SSC / CU"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  {language === 'bn' ? 'লক্ষ্য বছর (Target Year)' : 'Target Year'}
                </label>
                <select
                  value={targetYear}
                  onChange={(e) => setTargetYear(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                </select>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button
                onClick={() => setStep(1)}
                className="bg-slate-800 text-slate-300 hover:bg-slate-700 font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer"
              >
                {language === 'bn' ? 'আগের ধাপ' : 'Back'}
              </button>
              <button
                onClick={() => setStep(3)}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                {language === 'bn' ? 'পরবর্তী ধাপ' : 'Next Step'} <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: SUBJECT SELECTION & DAILY TARGET (CORE FEATURE) */}
        {step === 3 && (
          <div className="py-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-emerald-400" />
                  {language === 'bn' ? `পছন্দের বিষয় নির্বাচন (${targetExam})` : `Select Focus Subjects (${targetExam})`}
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {language === 'bn' 
                    ? 'আপনার পছন্দকৃত বিষয় ছাড়া AI অন্য কোনো বিষয়ের প্রশ্ন তৈরি করবে না।' 
                    : 'AI will strictly generate questions ONLY from your selected subjects.'}
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleSelectAllSubjects}
                  className="px-2.5 py-1 bg-indigo-600/30 text-indigo-300 hover:bg-indigo-600/50 border border-indigo-500/40 text-[11px] font-bold rounded-lg cursor-pointer"
                >
                  {language === 'bn' ? 'সবগুলো নির্বাচন' : 'Select All'}
                </button>
                <button
                  onClick={handleClearAllSubjects}
                  className="px-2.5 py-1 bg-slate-800 text-slate-400 hover:bg-slate-700 border border-slate-700 text-[11px] font-bold rounded-lg cursor-pointer"
                >
                  {language === 'bn' ? 'সব মুছুন' : 'Clear All'}
                </button>
              </div>
            </div>

            {subjectError && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2 font-bold">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                {subjectError}
              </div>
            )}

            {/* Subjects Checkbox Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
              {availableSubjects.map((subject) => {
                const isSelected = selectedSubjects.includes(subject);
                return (
                  <button
                    key={subject}
                    type="button"
                    onClick={() => handleToggleSubject(subject)}
                    className={`p-3 rounded-xl border text-left text-xs font-bold transition-all flex items-center gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600/20 border-emerald-500 text-emerald-200 shadow-sm'
                        : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <div className={`p-1 rounded-md shrink-0 ${isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-500'}`}>
                      {isSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                    </div>
                    <span>{subject}</span>
                  </button>
                );
              })}
            </div>

            {/* Daily Question Target Selector */}
            <div className="pt-2 border-t border-slate-800">
              <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                {language === 'bn' ? 'দৈনিক অনুশীলনের প্রশ্নের লক্ষ্য (Daily Target)' : 'Daily Practice Question Goal'}
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[50, 100, 150, 200].map((count) => {
                  const isSel = dailyQuestionTarget === count;
                  return (
                    <button
                      key={count}
                      type="button"
                      onClick={() => setDailyQuestionTarget(count)}
                      className={`py-2.5 px-3 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                        isSel
                          ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <div>{count} {language === 'bn' ? 'টি প্রশ্ন' : 'Questions'}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {count === 100 ? (language === 'bn' ? 'সুপারিশকৃত' : 'Recommended') : ''}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button
                onClick={() => setStep(2)}
                className="bg-slate-800 text-slate-300 hover:bg-slate-700 font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer"
              >
                {language === 'bn' ? 'আগের ধাপ' : 'Back'}
              </button>
              <button
                onClick={() => {
                  if (selectedSubjects.length === 0) {
                    setSubjectError(language === 'bn' ? 'অনুগ্রহ করে কমপক্ষে একটি বিষয় নির্বাচন করুন' : 'Please select at least 1 subject');
                    return;
                  }
                  setStep(4);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                {language === 'bn' ? 'পরবর্তী ধাপ' : 'Next Step'} <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Schedule, Exam Date & Finish */}
        {step === 4 && (
          <div className="py-6 space-y-5">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-400" />
              {language === 'bn' ? 'পড়াশোনার সময় ও প্রস্তুতি লেভেল' : 'Study Schedule & Prep Level'}
            </h3>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                {language === 'bn' ? 'পরীক্ষার তারিখ (যদি জানা থাকে)' : 'Exam Date (Optional)'}
              </label>
              <input
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                {language === 'bn' ? 'দৈনিক পড়াশোনার মোট বরাদ্দ সময় (মিনিটে)' : 'Daily Total Study Goal (Minutes)'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min={30}
                  max={360}
                  step={30}
                  value={dailyTime}
                  onChange={(e) => setDailyTime(Number(e.target.value))}
                  className="flex-1 accent-indigo-500 cursor-pointer"
                />
                <span className="bg-indigo-600/30 border border-indigo-500/50 text-indigo-300 font-extrabold px-3 py-1 rounded-xl text-xs min-w-[80px] text-center">
                  {dailyTime} {language === 'bn' ? 'মিনিট' : 'mins'} ({Math.round(dailyTime / 60 * 10) / 10}h)
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-indigo-400" />
                {language === 'bn' ? 'বর্তমান প্রস্তুতি লেভেল' : 'Current Prep Level'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Beginner', 'Intermediate', 'Advanced'] as const).map((lvl) => {
                  const isSel = currentLevel === lvl;
                  const lbl = language === 'bn' 
                    ? lvl === 'Beginner' ? 'প্রাথমিক' : lvl === 'Intermediate' ? 'মাঝারি' : 'উন্নত'
                    : lvl;
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setCurrentLevel(lvl)}
                      className={`py-2 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                        isSel 
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow-sm' 
                          : 'bg-slate-800 border-slate-700/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {lbl}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 bg-indigo-950/40 border border-indigo-800/50 rounded-2xl text-xs space-y-1 text-indigo-200">
              <div className="font-bold text-indigo-100 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                {language === 'bn' ? 'আপনার ব্যক্তিগত প্ল্যান রেডি:' : 'Personalized Setup Summary:'}
              </div>
              <div className="text-[11px] text-slate-300">
                • {language === 'bn' ? 'টার্গেট পরীক্ষা:' : 'Target Exam:'} <span className="font-bold text-white">{targetExam}</span> ({selectedSubjects.length} {language === 'bn' ? 'টি বিষয় নির্বাচিত' : 'subjects selected'})
              </div>
              <div className="text-[11px] text-slate-300">
                • {language === 'bn' ? 'দৈনিক প্রশ্ন লক্ষ্য:' : 'Daily Target:'} <span className="font-bold text-emerald-400">{dailyQuestionTarget} {language === 'bn' ? 'টি প্রশ্ন' : 'Questions'}</span>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button
                onClick={() => setStep(3)}
                className="bg-slate-800 text-slate-300 hover:bg-slate-700 font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer"
              >
                {language === 'bn' ? 'আগের ধাপ' : 'Back'}
              </button>
              <button
                onClick={handleFinish}
                className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:opacity-95 text-white font-black px-8 py-3 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-xl shadow-indigo-500/20 transform hover:scale-105 active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                {language === 'bn' ? 'StudySkill AI শুরু করুন' : 'Start Learning Now'}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
