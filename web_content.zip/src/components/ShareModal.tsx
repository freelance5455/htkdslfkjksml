import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  Send, 
  Code, 
  Smartphone,
  ExternalLink,
  Globe
} from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  text: string;
  languageName: string;
  personaName: string;
  audioBlob: Blob | null;
  audioUrl: string | null;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  text,
  languageName,
  personaName,
  audioBlob,
  audioUrl,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  if (!isOpen) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://sk-text-to-speech.studio';
  const previewText = text.length > 100 ? `${text.slice(0, 97)}...` : text;
  const shareTitle = `SK text to speech: ${languageName} (${personaName})`;
  const shareMessage = `🎙️ Listen to this audio synthesized with SK text to speech in ${languageName}:\n"${previewText}"\n\nTry it here: ${appUrl}`;

  const encodedUrl = encodeURIComponent(appUrl);
  const encodedText = encodeURIComponent(shareMessage);

  // Native Web Share API
  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        const shareData: ShareData = {
          title: shareTitle,
          text: shareMessage,
          url: appUrl,
        };

        if (audioBlob && navigator.canShare && navigator.canShare({ files: [new File([audioBlob], 'speech.wav', { type: audioBlob.type })] })) {
          const file = new File([audioBlob], `sk_tts_${languageName.toLowerCase()}_${Date.now()}.wav`, {
            type: audioBlob.type || 'audio/wav',
          });
          shareData.files = [file];
        }

        await navigator.share(shareData);
      } catch (err) {
        // User cancelled or not supported
      }
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const embedCode = `<audio controls src="${audioUrl || '#'}" style="width: 100%; border-radius: 8px;">\n  Your browser does not support audio.\n</audio>`;

  const handleCopyEmbed = () => {
    navigator.clipboard.writeText(embedCode);
    setCopiedEmbed(true);
    setTimeout(() => setCopiedEmbed(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative space-y-5 animate-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-violet-600/10 text-violet-600 dark:text-violet-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                Share Audio Creation
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {languageName} · {personaName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Public Web Address Box */}
        <div className="p-3.5 bg-violet-50/70 dark:bg-violet-950/30 rounded-2xl border border-violet-500/30 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-700 dark:text-violet-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-violet-500" />
              Public App Link
            </span>
            <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
              Live & Accessible
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="flex-1 bg-white dark:bg-zinc-900 border border-violet-300 dark:border-violet-800 text-xs text-zinc-800 dark:text-zinc-200 px-3 py-2 rounded-xl font-mono select-all focus:outline-none"
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <button
              onClick={handleCopyLink}
              className="px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer shrink-0 active:scale-95"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Text Preview Quote Card */}
        <div className="p-3 bg-zinc-50 dark:bg-zinc-950/60 rounded-xl border border-zinc-200/80 dark:border-zinc-800 text-xs text-zinc-600 dark:text-zinc-300 italic line-clamp-3">
          "{text}"
        </div>

        {/* Social Share Buttons Grid */}
        <div className="space-y-2">
          <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
            Share to Social Channels
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            
            {/* WhatsApp */}
            <a
              href={`https://api.whatsapp.com/send?text=${encodedText}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-all text-zinc-800 dark:text-zinc-200 group"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Send className="w-4 h-4" />
              </div>
              <span className="text-xs font-semibold">WhatsApp</span>
            </a>

            {/* X / Twitter */}
            <a
              href={`https://twitter.com/intent/tweet?text=${encodedText}&hashtags=SKTextToSpeech,AIVoice,TTS`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-sky-500 hover:bg-sky-50 dark:hover:bg-sky-950/30 transition-all text-zinc-800 dark:text-zinc-200 group"
            >
              <div className="w-8 h-8 rounded-full bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-sm font-black font-sans">𝕏</span>
              </div>
              <span className="text-xs font-semibold">X (Twitter)</span>
            </a>

            {/* LinkedIn */}
            <a
              href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-all text-zinc-800 dark:text-zinc-200 group"
            >
              <div className="w-8 h-8 rounded-full bg-blue-600/10 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ExternalLink className="w-4 h-4" />
              </div>
              <span className="text-xs font-semibold">LinkedIn</span>
            </a>

            {/* Telegram */}
            <a
              href={`https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-cyan-500 hover:bg-cyan-50 dark:hover:bg-cyan-950/30 transition-all text-zinc-800 dark:text-zinc-200 group"
            >
              <div className="w-8 h-8 rounded-full bg-cyan-500/10 text-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Send className="w-4 h-4" />
              </div>
              <span className="text-xs font-semibold">Telegram</span>
            </a>

          </div>
        </div>

        {/* Native mobile device share */}
        {typeof navigator !== 'undefined' && 'share' in navigator && (
          <button
            onClick={handleNativeShare}
            className="w-full py-2.5 px-4 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold text-xs flex items-center justify-center gap-2 transition-all"
          >
            <Smartphone className="w-4 h-4 text-violet-500" />
            <span>Open System Share Sheet (AirDrop, Messages, Instagram...)</span>
          </button>
        )}

        {/* Copy Tools */}
        <div className="space-y-2 pt-2 border-t border-zinc-200 dark:border-zinc-800">
          <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
            Copy Options
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={handleCopyLink}
              className="flex-1 py-2 px-3 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Studio Link'}</span>
            </button>

            <button
              onClick={handleCopyText}
              className="flex-1 py-2 px-3 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300"
            >
              {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedText ? 'Text Copied!' : 'Copy Text'}</span>
            </button>

            <button
              onClick={handleCopyEmbed}
              className="flex-1 py-2 px-3 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300"
            >
              {copiedEmbed ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Code className="w-3.5 h-3.5" />}
              <span>{copiedEmbed ? 'Embed Copied!' : 'Copy Embed Code'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
