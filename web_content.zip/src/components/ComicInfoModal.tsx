import React, { useEffect, useState } from 'react';
import { Bookmark, BookOpen, Code2, HardDriveDownload, X } from 'lucide-react';
import type { ComicEntry, TocBookmark } from '../types/comic';

interface ComicInfoModalProps {
  comic: ComicEntry | null;
  onClose: () => void;
  onReadAtPage: (comic: ComicEntry, pageIndex: number) => void;
  onToggleOffline: (comic: ComicEntry) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const ComicInfoModal: React.FC<ComicInfoModalProps> = ({
  comic,
  onClose,
  onReadAtPage,
  onToggleOffline,
}) => {
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [showRawXml, setShowRawXml] = useState(false);

  useEffect(() => {
    if (!comic?.coverBlob) {
      setCoverUrl(null);
      return;
    }
    const url = URL.createObjectURL(comic.coverBlob);
    setCoverUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [comic?.coverBlob]);

  if (!comic) return null;

  const info = comic.comicInfo;
  const combinedToc: TocBookmark[] = [
    ...(info?.toc || []),
    ...(comic.userBookmarks || []),
  ].sort((a, b) => a.pageIndex - b.pageIndex);

  const metaRows: { label: string; value?: string }[] = [
    { label: 'Series', value: info?.series },
    {
      label: 'Issue / Vol',
      value: [
        info?.number ? `#${info.number}` : null,
        info?.volume !== undefined ? `Vol. ${info.volume}` : null,
        info?.count !== undefined ? `of ${info.count}` : null,
      ]
        .filter(Boolean)
        .join(' · ') || undefined,
    },
    { label: 'Writer', value: info?.writer },
    { label: 'Penciller', value: info?.penciller },
    { label: 'Colorist', value: info?.colorist },
    { label: 'Publisher', value: info?.publisher },
    {
      label: 'Published',
      value: [info?.year, info?.month, info?.day].filter((v) => v !== undefined).join('-') || undefined,
    },
    { label: 'Genre', value: info?.genre },
    { label: 'Tags', value: info?.tags },
    { label: 'Story Arc', value: info?.storyArc },
    { label: 'Language', value: info?.languageISO?.toUpperCase() },
    { label: 'Manga Layout', value: info?.manga },
    { label: 'Archive', value: `${comic.format.toUpperCase()} · ${formatBytes(comic.fileSize)} · ${comic.pageCount} pages` },
    {
      label: 'Image Formats',
      value: comic.imageFormatsFound.length > 0 ? comic.imageFormatsFound.join(', ') : undefined,
    },
    { label: 'Folder', value: comic.folderName },
  ].filter((r) => Boolean(r.value));

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm sm:p-4"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-2xl max-h-[90dvh] flex flex-col rounded-t-3xl sm:rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Mobile sheet drag handle */}
        <div className="sm:hidden w-10 h-1 bg-zinc-300 dark:bg-zinc-700 rounded-full mx-auto mt-3 shrink-0" />

        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-200/80 dark:border-zinc-800">
          <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100 truncate pr-4">
            ComicInfo &amp; Contents
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
            aria-label="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-5 space-y-6">
          {/* Header summary */}
          <div className="flex gap-4 items-start">
            <div className="w-24 sm:w-28 aspect-[3/4] shrink-0 rounded-xl overflow-hidden bg-zinc-200 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-800">
              {coverUrl ? (
                <img
                  src={coverUrl}
                  alt={comic.displayTitle}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-zinc-400" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-semibold text-zinc-900 dark:text-zinc-100 leading-snug">
                {comic.displayTitle}
              </h3>
              <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400 font-mono-nums">
                {comic.fileName}
              </p>
              {info?.summary && (
                <p className="mt-2.5 text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed line-clamp-4">
                  {info.summary}
                </p>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onReadAtPage(comic, comic.currentPage || 0);
                  }}
                  className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-xl text-sm font-medium text-white transition-opacity hover:opacity-90 whitespace-nowrap"
                  style={{ backgroundColor: 'var(--app-accent)' }}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>{comic.currentPage > 0 ? `Resume · Page ${comic.currentPage + 1}` : 'Start Reading'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleOffline(comic)}
                  className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-xl text-sm font-medium border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 whitespace-nowrap"
                >
                  <HardDriveDownload className="w-4 h-4" />
                  <span>{comic.isOfflineCached ? 'Cached Offline' : 'Cache Offline'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Table of Contents from ComicInfo.xml Bookmarks */}
          <section>
            <div className="flex items-center justify-between mb-2.5">
              <h4 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                Table of Contents ({combinedToc.length})
              </h4>
              <span className="text-xs text-zinc-500 dark:text-zinc-400">
                ComicInfo Bookmarks &amp; Saved
              </span>
            </div>

            {combinedToc.length > 0 ? (
              <div className="divide-y divide-zinc-200/70 dark:divide-zinc-800 border border-zinc-200/80 dark:border-zinc-800 rounded-xl overflow-hidden">
                {combinedToc.map((entry, idx) => (
                  <button
                    key={`${entry.pageIndex}-${entry.title}-${idx}`}
                    type="button"
                    onClick={() => {
                      onClose();
                      onReadAtPage(comic, entry.pageIndex);
                    }}
                    className="w-full min-h-[48px] px-4 py-2.5 flex items-center justify-between gap-3 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Bookmark
                        className="w-4 h-4 shrink-0"
                        style={{ color: 'var(--app-accent)' }}
                      />
                      <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                        {entry.title}
                      </span>
                    </div>
                    <span className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 shrink-0">
                      Page {entry.pageIndex + 1}
                    </span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-zinc-500 dark:text-zinc-400 py-3 px-4 rounded-xl border border-dashed border-zinc-200 dark:border-zinc-800">
                No chapter bookmarks found in ComicInfo.xml. You can still add personal bookmarks while reading.
              </p>
            )}
          </section>

          {/* Parsed ComicInfo Metadata Table */}
          <section>
            <div className="flex items-center justify-between mb-2.5">
              <h4 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                Archive Metadata
              </h4>
              {info?.rawXml && (
                <button
                  type="button"
                  onClick={() => setShowRawXml((v) => !v)}
                  className="inline-flex items-center gap-1.5 min-h-[36px] px-2.5 rounded-lg text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>{showRawXml ? 'Hide XML' : 'Inspect ComicInfo.xml'}</span>
                </button>
              )}
            </div>

            {showRawXml && info?.rawXml ? (
              <pre className="p-3.5 rounded-xl bg-zinc-950 text-zinc-200 text-xs font-mono-nums overflow-x-auto max-h-64 border border-zinc-800">
                {info.rawXml}
              </pre>
            ) : (
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2.5 text-sm border-t border-zinc-200/80 dark:border-zinc-800 pt-3">
                {metaRows.map((row) => (
                  <div key={row.label} className="flex flex-col">
                    <dt className="text-xs text-zinc-500 dark:text-zinc-400">{row.label}</dt>
                    <dd className="text-zinc-900 dark:text-zinc-100 font-medium break-words">
                      {row.value}
                    </dd>
                  </div>
                ))}
              </dl>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
