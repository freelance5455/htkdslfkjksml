import React, { useState, useMemo, useEffect } from 'react';
import {
  X, User, MapPin, Package, Shield, LogOut, Plus, Trash2,
  CheckCircle2, Clock, Truck, RotateCcw, Search, FileText,
  Ban, RefreshCw, Bell, Copy, Check, Banknote, Globe,
  Navigation, Sparkles, Loader2,
} from 'lucide-react';
import { useAuth, Order } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { getProductById } from '../../data/products';
import { TrackOrderModal } from '../orders/TrackOrderModal';
import { OrderDetailsModal } from '../orders/OrderDetailsModal';
import { CancelOrderModal } from '../orders/CancelOrderModal';
import { ReturnExchangeModal } from '../orders/ReturnExchangeModal';
import { TaxInvoiceModal } from '../orders/TaxInvoiceModal';
import { NotificationsDrawer } from '../orders/NotificationsDrawer';
import { getCurrentLiveLocation } from '../../utils/locationService';

interface UserAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'profile' | 'orders' | 'addresses' | 'security';
}

type OrderFilter =
  | 'All'
  | 'Processing'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Returned';

export const UserAccountModal: React.FC<UserAccountModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'orders',
}) => {
  const {
    user,
    logout,
    updateProfile,
    addresses,
    addAddress,
    deleteAddress,
    orders,
    fetchOrders,
    cancelOrder,
    requestReturnOrExchange,
    unreadNotificationCount,
  } = useAuth();
  const { currentLanguageMeta, openLanguageModal, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses' | 'security'>(initialTab);
  const [isRefreshingOrders, setIsRefreshingOrders] = useState(false);

  useEffect(() => {
    if (isOpen && user) {
      fetchOrders().catch(() => {});
    }
  }, [isOpen, activeTab, user]);

  const handleRefreshOrders = async () => {
    setIsRefreshingOrders(true);
    try {
      await fetchOrders();
    } finally {
      setIsRefreshingOrders(false);
    }
  };

  const [orderFilter, setOrderFilter] = useState<OrderFilter>('All');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [selectedTrackingOrder, setSelectedTrackingOrder] = useState<Order | null>(null);
  const [selectedDetailsOrder, setSelectedDetailsOrder] = useState<Order | null>(null);
  const [selectedCancelOrder, setSelectedCancelOrder] = useState<Order | null>(null);
  const [selectedReturnOrder, setSelectedReturnOrder] = useState<Order | null>(null);
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  // Address form
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [addrName, setAddrName] = useState('');
  const [addrPhone, setAddrPhone] = useState('');
  const [addrStreet, setAddrStreet] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrState, setAddrState] = useState('');
  const [addrPin, setAddrPin] = useState('');
  const [addrType] = useState<'home' | 'work' | 'other'>('home');
  const [addrDefault, setAddrDefault] = useState(true);

  // Live Location states
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [locationSuccess, setLocationSuccess] = useState<string | null>(null);

  const handleUseGpsLocation = async () => {
    setIsDetectingGps(true);
    setLocationSuccess(null);
    try {
      const loc = await getCurrentLiveLocation();
      setAddrStreet(loc.street);
      setAddrCity(loc.city);
      setAddrPin(loc.pincode);
      setAddrState(loc.state);
      setLocationSuccess(`Live Location: ${loc.street}, ${loc.city} (${loc.pincode})`);
    } catch (err: any) {
      alert(err.message || 'Unable to detect live location');
    } finally {
      setIsDetectingGps(false);
    }
  };

  // Profile editing
  const [editName, setEditName] = useState(user?.name || '');
  const [editPhone, setEditPhone] = useState(user?.phone || '');
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  useEffect(() => {
    if (user) {
      setEditName(user.name || '');
      setEditPhone(user.phone || '');
    }
  }, [user]);

  const filteredOrders = useMemo(() => {
    return orders.filter((ord) => {
      if (orderFilter !== 'All') {
        const s = ord.orderStatus;
        if (orderFilter === 'Processing') {
          if (!['PENDING', 'CONFIRMED', 'PROCESSING', 'PACKED'].includes(s)) return false;
        } else if (orderFilter === 'Shipped') {
          if (!['READY_FOR_PICKUP', 'PICKED_UP', 'SHIPPED', 'IN_TRANSIT'].includes(s)) return false;
        } else if (orderFilter === 'Out for Delivery') {
          if (s !== 'OUT_FOR_DELIVERY') return false;
        } else if (orderFilter === 'Delivered') {
          if (s !== 'DELIVERED') return false;
        } else if (orderFilter === 'Cancelled') {
          if (s !== 'CANCELLED') return false;
        } else if (orderFilter === 'Returned') {
          if (!['RETURN_REQUESTED', 'RETURN_APPROVED', 'RETURN_PICKED_UP', 'RETURNED'].includes(s)) return false;
        }
      }
      if (orderSearchQuery.trim()) {
        const q = orderSearchQuery.toLowerCase().trim();
        const matchesId = ord.id.toLowerCase().includes(q);
        const matchesAwb = ord.awbNumber?.toLowerCase().includes(q);
        const matchesProduct = ord.items.some((it) => it.productName.toLowerCase().includes(q));
        if (!matchesId && !matchesAwb && !matchesProduct) return false;
      }
      return true;
    });
  }, [orders, orderFilter, orderSearchQuery]);

  if (!isOpen || !user) return null;

  const handleCopyOrderId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(id);
    setCopiedOrderId(id);
    setTimeout(() => setCopiedOrderId(null), 2000);
  };

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addAddress({
        fullName: addrName,
        phone: addrPhone,
        street: addrStreet,
        city: addrCity,
        state: addrState,
        pincode: addrPin,
        type: addrType,
        isDefault: addrDefault,
      });
      setIsAddingAddress(false);
      setAddrName('');
      setAddrPhone('');
      setAddrStreet('');
      setAddrCity('');
      setAddrState('');
      setAddrPin('');
    } catch {
      // Ignored
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingProfile(true);
    setProfileMsg(null);
    try {
      await updateProfile(editName, editPhone);
      setProfileMsg('Profile information updated successfully!');
      setTimeout(() => setProfileMsg(null), 3000);
    } catch {
      setProfileMsg('Failed to update profile.');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'DELIVERED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Delivered
          </span>
        );
      case 'OUT_FOR_DELIVERY':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#000000] bg-[#FAFAFA] px-2.5 py-0.5 rounded-full border border-[#EAEAEA] animate-pulse">
            <Truck className="w-3 h-3 text-black font-bold" /> Out for Delivery
          </span>
        );
      case 'IN_TRANSIT':
      case 'SHIPPED':
      case 'PICKED_UP':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-800 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
            <Truck className="w-3 h-3 text-blue-600" /> In Transit
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-300">
            <Ban className="w-3 h-3 text-slate-500" /> Cancelled
          </span>
        );
      case 'RETURN_REQUESTED':
      case 'RETURN_APPROVED':
      case 'RETURN_PICKED_UP':
      case 'RETURNED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#000000] bg-[#FAFAFA] px-2.5 py-0.5 rounded-full border border-[#EAEAEA]">
            <RotateCcw className="w-3 h-3 text-black font-bold" /> {status.replace('_', ' ')}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" /> Processing
          </span>
        );
    }
  };

  const ORDER_FILTER_TABS: OrderFilter[] = [
    'All',
    'Processing',
    'Shipped',
    'Out for Delivery',
    'Delivered',
    'Cancelled',
    'Returned',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-5xl h-[92vh] bg-white rounded-3xl shadow-2xl border border-[#FAFAFA] flex flex-col md:flex-row overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Sidebar Navigation */}
        <div className="w-full md:w-64 bg-[#FAFAFA]/50 border-b md:border-b-0 md:border-r border-[#FAFAFA] p-5 flex flex-col justify-between flex-shrink-0">
          <div>
            <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-[#FAFAFA] shadow-2xs mb-5">
              <div className="flex items-center gap-3 min-w-0">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover border border-[#EAEAEA] flex-shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-[#FFD400] text-black font-black font-black text-base flex items-center justify-center flex-shrink-0">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="min-w-0">
                  <p className="font-bold text-slate-900 text-sm truncate">{user.name}</p>
                  <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                </div>
              </div>

              <button
                onClick={() => setIsNotificationsOpen(true)}
                className="relative p-2 rounded-xl text-black font-bold hover:bg-[#FAFAFA] transition-colors cursor-pointer flex-shrink-0"
                title="Delivery Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#FFD400] text-black font-black text-[9px] font-black flex items-center justify-center animate-pulse">
                    {unreadNotificationCount}
                  </span>
                )}
              </button>
            </div>

            <div className="space-y-1">
              <button
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === 'orders'
                    ? 'bg-[#FFD400] text-black font-black shadow-xs'
                    : 'text-slate-700 hover:bg-[#FAFAFA]'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>My Orders</span>
                {orders.length > 0 && (
                  <span
                    className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      activeTab === 'orders'
                        ? 'bg-[#000000] text-white'
                        : 'bg-[#FAFAFA] text-[#000000]'
                    }`}
                  >
                    {orders.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('addresses')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === 'addresses'
                    ? 'bg-[#FFD400] text-black font-black shadow-xs'
                    : 'text-slate-700 hover:bg-[#FAFAFA]'
                }`}
              >
                <MapPin className="w-4 h-4" />
                <span>Saved Addresses</span>
              </button>

              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === 'profile'
                    ? 'bg-[#FFD400] text-black font-black shadow-xs'
                    : 'text-slate-700 hover:bg-[#FAFAFA]'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Profile Details</span>
              </button>

              <button
                onClick={() => setActiveTab('security')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === 'security'
                    ? 'bg-[#FFD400] text-black font-black shadow-xs'
                    : 'text-slate-700 hover:bg-[#FAFAFA]'
                }`}
              >
                <Shield className="w-4 h-4" />
                <span>Google Account</span>
              </button>

              <button
                onClick={openLanguageModal}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 hover:bg-[#FAFAFA] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Globe className="w-4 h-4 text-black font-bold" />
                  <span>{t('language')}</span>
                </div>
                <span className="text-[11px] font-bold text-black font-bold bg-[#FAFAFA] px-2 py-0.5 rounded-md border border-[#EAEAEA]">
                  {currentLanguageMeta.nativeName}
                </span>
              </button>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-black font-bold hover:bg-[#FAFAFA] transition-colors cursor-pointer mt-4"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Content Pane */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7">
          {activeTab === 'orders' && (
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
                <div>
                  <h3 className="text-xl font-black text-slate-900 tracking-tight">My Orders (Cash on Delivery)</h3>
                  <p className="text-xs text-slate-500">
                    Track live shipments, check delivery dates & current locations, download tax invoices
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRefreshOrders}
                    disabled={isRefreshingOrders}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-60"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingOrders ? 'animate-spin text-black font-bold' : ''}`} />
                    <span>{isRefreshingOrders ? 'Refreshing...' : 'Refresh'}</span>
                  </button>
                  <button
                    onClick={() => setIsNotificationsOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAFAFA] hover:bg-[#FAFAFA] text-black font-bold rounded-xl text-xs font-bold border border-[#EAEAEA] cursor-pointer"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>Delivery Alerts</span>
                    {unreadNotificationCount > 0 && (
                      <span className="w-2 h-2 rounded-full bg-[#FFD400] ml-0.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Search Orders */}
              <div className="relative mb-4">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={orderSearchQuery}
                  onChange={(e) => setOrderSearchQuery(e.target.value)}
                  placeholder="Search by Order ID, product name, or AWB tracking number..."
                  className="w-full h-10 pl-10 pr-4 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-black focus:bg-white focus:outline-none transition-all"
                />
                {orderSearchQuery && (
                  <button
                    onClick={() => setOrderSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Order Status Filters */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-4 scrollbar-none">
                {ORDER_FILTER_TABS.map((tab) => {
                  const isActive = orderFilter === tab;
                  return (
                    <button
                      key={tab}
                      onClick={() => setOrderFilter(tab)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                        isActive
                          ? 'bg-[#FFD400] text-black font-black shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {tab}
                    </button>
                  );
                })}
              </div>

              {/* Orders List */}
              {filteredOrders.length === 0 ? (
                <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-100">
                  <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-800 text-sm">
                    {orderSearchQuery || orderFilter !== 'All'
                      ? 'No matching orders found'
                      : 'No orders placed yet'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    {orderSearchQuery || orderFilter !== 'All'
                      ? 'Try clearing your search query or selecting a different filter above.'
                      : 'Explore our latest curated footwear, bags, and luxury timepieces with Cash on Delivery.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((ord) => {
                    const isCancelable = [
                      'PENDING',
                      'CONFIRMED',
                      'PROCESSING',
                      'PACKED',
                    ].includes(ord.orderStatus);
                    const isReturnEligible = ord.orderStatus === 'DELIVERED';
                    return (
                      <div
                        key={ord.id}
                        className="bg-white border border-[#FAFAFA] rounded-3xl p-4 sm:p-5 shadow-xs hover:border-[#000000] transition-all space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-black text-slate-900">
                              #{ord.id}
                            </span>
                            <button
                              onClick={(e) => handleCopyOrderId(ord.id, e)}
                              className="text-slate-400 hover:text-black font-bold cursor-pointer p-0.5"
                              title="Copy Order ID"
                            >
                              {copiedOrderId === ord.id ? (
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <span className="text-slate-300">•</span>
                            <span className="text-xs text-slate-500">
                              {new Date(ord.createdAt).toLocaleDateString('en-IN', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric',
                              })}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusBadge(ord.orderStatus)}
                            <span className="text-sm font-black text-black font-bold">
                              ₹{ord.total.toLocaleString()}
                            </span>
                          </div>
                        </div>

                        <div className="divide-y divide-slate-50">
                          {ord.items.map((it, idx) => {
                            const masterProduct = getProductById(it.productId);
                            const displayName = masterProduct?.name || it.productName;
                            const displayImage = masterProduct?.images?.[0] || it.image;
                            const displayBrand = masterProduct?.brand;
                            return (
                              <div key={idx} className="flex items-center gap-3 py-2.5">
                                <img
                                  src={displayImage}
                                  alt={displayName}
                                  className="w-14 h-14 object-contain rounded-xl bg-slate-50 border border-slate-100 p-1 flex-shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="text-xs font-bold text-slate-900 truncate">
                                    {displayName}
                                  </p>
                                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                                    {displayBrand && (
                                      <span className="font-semibold text-black font-bold bg-[#FAFAFA] px-1.5 py-0.2 rounded text-[10px]">
                                        {displayBrand}
                                      </span>
                                    )}
                                    {[
                                      it.selectedSize ? `Size: ${it.selectedSize}` : '',
                                      it.selectedColor ? `Color: ${it.selectedColor}` : '',
                                      `Qty: ${it.quantity}`,
                                    ]
                                      .filter(Boolean)
                                      .join(' • ')}
                                  </div>
                                </div>
                                <span className="text-xs font-bold text-slate-800 flex-shrink-0">
                                  ₹{(it.price * it.quantity).toLocaleString()}
                                </span>
                              </div>
                            );
                          })}
                        </div>

                        <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div className="flex flex-wrap items-center gap-3 text-slate-600">
                            {ord.courierPartner && (
                              <span className="inline-flex items-center gap-1 font-semibold text-[#000000] bg-[#FAFAFA] px-2 py-0.5 rounded text-[11px]">
                                <Truck className="w-3 h-3 text-black font-bold" />
                                {ord.courierPartner}
                              </span>
                            )}
                            <span className="inline-flex items-center gap-1 font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                              <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                              Cash on Delivery (Pay at Doorstep)
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-700 font-bold">
                            Total Payable: <span className="text-black font-bold text-xs font-extrabold">₹{ord.total.toLocaleString()}</span>
                          </div>
                        </div>

                        <div className="pt-1 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setSelectedTrackingOrder(ord)}
                              className="px-3.5 py-1.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              <span>Track Live</span>
                            </button>
                            <button
                              onClick={() => setSelectedDetailsOrder(ord)}
                              className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold cursor-pointer"
                            >
                              View Details
                            </button>
                          </div>
                          <div className="flex items-center gap-2">
                            {isCancelable && (
                              <button
                                onClick={() => setSelectedCancelOrder(ord)}
                                className="px-3 py-1.5 rounded-xl border border-[#EAEAEA] text-black font-bold hover:bg-[#FAFAFA] text-xs font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>Cancel</span>
                              </button>
                            )}
                            {isReturnEligible && (
                              <button
                                onClick={() => setSelectedReturnOrder(ord)}
                                className="px-3 py-1.5 rounded-xl bg-[#FAFAFA] hover:bg-[#FAFAFA] text-black font-bold border border-[#EAEAEA] text-xs font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Return / Exchange</span>
                              </button>
                            )}
                            <button
                              onClick={() => setSelectedInvoiceOrder(ord)}
                              className="px-3 py-1.5 rounded-xl border border-[#EAEAEA] text-[#000000] hover:bg-[#FAFAFA] text-xs font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span>Invoice</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB: ADDRESSES */}
          {activeTab === 'addresses' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="text-lg font-black text-slate-900">Saved Addresses</h3>
                  <p className="text-xs text-slate-500">
                    Manage delivery locations for fast Cash on Delivery checkout
                  </p>
                </div>
                {!isAddingAddress && (
                  <button
                    onClick={() => setIsAddingAddress(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#FFD400] hover:bg-[#FFC800] text-black font-black rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add New</span>
                  </button>
                )}
              </div>

              {isAddingAddress && (
                <form
                  onSubmit={handleSaveAddress}
                  className="bg-slate-50 p-5 rounded-2xl border border-[#FAFAFA] space-y-3 mb-4"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-[#000000] uppercase tracking-wider">
                      New Delivery Address
                    </h4>
                  </div>

                  <button
                    type="button"
                    disabled={isDetectingGps}
                    onClick={handleUseGpsLocation}
                    className="w-full py-2.5 px-3 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60 transition-colors"
                  >
                    {isDetectingGps ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                        <span>Detecting Live GPS Location...</span>
                      </>
                    ) : (
                      <>
                        <Navigation className="w-4 h-4 text-white" />
                        <span>Use My Live Location (GPS Auto-Detect)</span>
                      </>
                    )}
                  </button>



                  {locationSuccess && (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span>{locationSuccess}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={addrName}
                        onChange={(e) => setAddrName(e.target.value)}
                        placeholder="Receiver's name"
                        className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        Contact Phone
                      </label>
                      <input
                        type="tel"
                        required
                        value={addrPhone}
                        onChange={(e) => setAddrPhone(e.target.value)}
                        placeholder="+91 9876543210"
                        className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Street Address / Landmark
                    </label>
                    <input
                      type="text"
                      required
                      value={addrStreet}
                      onChange={(e) => setAddrStreet(e.target.value)}
                      placeholder="Apartment, building, street address"
                      className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        required
                        value={addrCity}
                        onChange={(e) => setAddrCity(e.target.value)}
                        className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        State
                      </label>
                      <input
                        type="text"
                        required
                        value={addrState}
                        onChange={(e) => setAddrState(e.target.value)}
                        className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        PIN Code
                      </label>
                      <input
                        type="text"
                        required
                        value={addrPin}
                        onChange={(e) => setAddrPin(e.target.value)}
                        placeholder="400001"
                        className="w-full h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:border-black focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addrDefault}
                        onChange={(e) => setAddrDefault(e.target.checked)}
                        className="accent-[#FFD400]"
                      />
                      <span>Make this my default delivery address</span>
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingAddress(false)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 rounded-lg bg-[#FFD400] text-black font-black text-xs font-semibold hover:bg-[#000000] shadow-xs cursor-pointer"
                      >
                        Save Address
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {addresses.length === 0 && !isAddingAddress ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-100">
                  <MapPin className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="font-semibold text-slate-800 text-sm">No saved addresses</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Add your shipping details for quick checkout.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {addresses.map((a) => (
                    <div
                      key={a.id}
                      className="bg-white border border-[#FAFAFA] rounded-2xl p-4 shadow-2xs relative flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-bold text-slate-900">{a.fullName}</span>
                          {a.isDefault && (
                            <span className="text-[10px] font-bold text-black font-bold bg-[#FAFAFA] px-2 py-0.5 rounded-full border border-[#EAEAEA]">
                              Default
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {a.street}, {a.city}, {a.state} - {a.pincode}
                        </p>
                        <p className="text-xs text-slate-500 mt-2">Phone: {a.phone}</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                        <button
                          onClick={() => deleteAddress(a.id)}
                          className="text-black font-bold hover:text-[#000000] p-1 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          aria-label="Delete address"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: PROFILE */}
          {activeTab === 'profile' && (
            <div className="max-w-md">
              <h3 className="text-lg font-black text-slate-900 mb-1">Profile Details</h3>
              <p className="text-xs text-slate-500 mb-5">Your verified OMAZIFY account profile</p>

              <div className="flex items-center gap-3.5 p-4 bg-[#FAFAFA] border border-[#FAFAFA] rounded-2xl mb-4">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-[#000000] shadow-sm flex-shrink-0"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-[#FFD400] text-black font-black font-extrabold text-xl flex items-center justify-center flex-shrink-0">
                    {user.name ? user.name[0].toUpperCase() : 'U'}
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-sm font-bold text-slate-900 truncate">{user.name}</p>
                  <p className="text-xs text-slate-500 truncate">{user.email}</p>
                  <p className="text-[10px] text-black font-bold font-mono mt-0.5 truncate">
                    Account ID: {user.uid || user.id}
                  </p>
                </div>
              </div>

              {profileMsg && (
                <div className="p-3 mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                  {profileMsg}
                </div>
              )}

              <form
                onSubmit={handleProfileSubmit}
                className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-200"
              >
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full h-10 px-3 text-xs bg-white border border-slate-200 rounded-xl focus:border-black focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Account Email</label>
                  <input
                    type="email"
                    disabled
                    value={user.email}
                    className="w-full h-10 px-3 text-xs bg-slate-100 border border-slate-200 rounded-xl text-slate-500 cursor-not-allowed"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Verified account email cannot be edited
                  </span>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="+91 9876543210"
                    className="w-full h-10 px-3 text-xs bg-white border border-slate-200 rounded-xl focus:border-black focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Account ID</label>
                  <input
                    type="text"
                    disabled
                    value={user.uid || user.id}
                    className="w-full h-10 px-3 text-xs font-mono bg-slate-100 border border-slate-200 rounded-xl text-slate-500 cursor-not-allowed"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSavingProfile}
                  className="w-full h-10 bg-[#FFD400] hover:bg-[#FFC800] text-black font-black font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSavingProfile ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </form>
            </div>
          )}

          {/* TAB: GOOGLE ACCOUNT SECURITY */}
          {activeTab === 'security' && (
            <div className="max-w-md space-y-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 mb-1">Account Security</h3>
                <p className="text-xs text-slate-500">
                  Your OMAZIFY account is securely protected and authenticated.
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
                  <div className="flex items-center gap-3">
                    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <div>
                      <p className="text-xs font-bold text-slate-900">Google / Gmail Account</p>
                      <p className="text-[11px] text-slate-500">{user.email}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Verified
                  </span>
                </div>
              </div>

              <div className="p-4 bg-[#FAFAFA] border border-[#FAFAFA] rounded-2xl text-xs text-[#000000] space-y-1.5">
                <p className="font-bold flex items-center gap-1.5 text-[#000000]">
                  <Shield className="w-4 h-4 text-black font-bold" />
                  <span>Password-Free Protected Authentication</span>
                </p>
                <p className="text-[11px] text-[#000000]/90 leading-relaxed">
                  Your credentials are authenticated directly through encrypted OAuth tokens. No passwords are stored on OMAZIFY servers, ensuring immunity from credential theft.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      <TrackOrderModal
        order={selectedTrackingOrder}
        onClose={() => setSelectedTrackingOrder(null)}
      />
      <OrderDetailsModal
        order={selectedDetailsOrder}
        onClose={() => setSelectedDetailsOrder(null)}
        onTrackOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedTrackingOrder(ord);
        }}
        onDownloadInvoice={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedInvoiceOrder(ord);
        }}
        onCancelOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedCancelOrder(ord);
        }}
        onReturnOrder={(ord) => {
          setSelectedDetailsOrder(null);
          setSelectedReturnOrder(ord);
        }}
      />
      <CancelOrderModal
        order={selectedCancelOrder}
        isOpen={!!selectedCancelOrder}
        onClose={() => setSelectedCancelOrder(null)}
        onConfirmCancel={async (orderId, reason) => {
          await cancelOrder(orderId, reason);
        }}
      />
      <ReturnExchangeModal
        order={selectedReturnOrder}
        isOpen={!!selectedReturnOrder}
        onClose={() => setSelectedReturnOrder(null)}
        onSubmitReturnOrExchange={async (orderId, payload) => {
          await requestReturnOrExchange(orderId, payload);
        }}
      />
      <TaxInvoiceModal
        order={selectedInvoiceOrder}
        isOpen={!!selectedInvoiceOrder}
        onClose={() => setSelectedInvoiceOrder(null)}
      />
      <NotificationsDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onSelectOrder={(ordId) => {
          setIsNotificationsOpen(false);
          const found = orders.find((o) => o.id === ordId);
          if (found) {
            setSelectedTrackingOrder(found);
          }
        }}
      />
    </div>
  );
};
