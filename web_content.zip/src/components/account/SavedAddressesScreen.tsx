import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Plus,
  MapPin,
  Search,
  Navigation,
  Loader2,
  AlertCircle,
  Check,
  MoreVertical,
  Edit2,
  Trash2,
  CheckCircle2,
  Home,
  Briefcase,
  X,
  Phone,
  Building,
  ChevronRight,
} from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth, Address } from '../../context/AuthContext';
import {
  getRawCurrentCoords,
  resolveExactLocation,
  searchLocationsNominatim,
  verifyIndianPinCode,
  GeocodedAddress,
  SearchLocationResult,
  parseIndianAddressEngine,
} from '../../utils/locationService';

interface SavedAddressesScreenProps {
  onBack: () => void;
  onSelectAddressForCheckout?: (address: Address) => void;
  isCheckoutSelection?: boolean;
}

// Custom Indian Map Pin Icon with Black (#000000) and Yellow (#FFD600) accents
const createMapPinIcon = () => {
  return L.divIcon({
    className: 'custom-saved-address-pin',
    html: `
      <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 44px; height: 44px; cursor: grab;">
        <div style="position: absolute; width: 38px; height: 38px; background: rgba(255, 214, 0, 0.35); border-radius: 50%; animation: ping 1.8s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
        <div style="position: absolute; bottom: 0; width: 14px; height: 5px; background: rgba(0,0,0,0.35); border-radius: 50%; filter: blur(1px);"></div>
        <div style="position: relative; width: 32px; height: 32px; background: #000000; border: 3px solid #FFD600; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.45); top: -6px;">
          <div style="width: 10px; height: 10px; background: #FFD600; border-radius: 50%; transform: rotate(45deg); box-shadow: 0 0 3px #FFD600;"></div>
        </div>
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 38],
    popupAnchor: [0, -38],
  });
};

export const SavedAddressesScreen: React.FC<SavedAddressesScreenProps> = ({
  onBack,
  onSelectAddressForCheckout,
  isCheckoutSelection = false,
}) => {
  const {
    user,
    isAuthenticated,
    addresses,
    fetchAddresses,
    addAddress,
    updateAddress,
    setDefaultAddress,
    deleteAddress,
  } = useAuth();

  // Map refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const lookupIdRef = useRef(0);

  // Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchLocationResult[]>([]);
  const [searchMessage, setSearchMessage] = useState<{ type: 'error' | 'info'; text: string } | null>(null);

  // Map Selection states
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationSummary, setLocationSummary] = useState<string | null>(null);
  const [isResolvingLocation, setIsResolvingLocation] = useState(false);

  // Current Location / GPS states
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gpsSuccessMsg, setGpsSuccessMsg] = useState<string | null>(null);

  // Add / Edit Form Modal or Sheet
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);

  // Form Fields
  const [formFullName, setFormFullName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formPincode, setFormPincode] = useState('');
  const [formHouse, setFormHouse] = useState('');
  const [formStreet, setFormStreet] = useState('');
  const [formLandmark, setFormLandmark] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formState, setFormState] = useState('');
  const [formType, setFormType] = useState<'home' | 'work' | 'other'>('home');
  const [formIsDefault, setFormIsDefault] = useState(false);

  // Form validation & status
  const [formError, setFormError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [pinVerificationText, setPinVerificationText] = useState<string | null>(null);
  const [isVerifyingPin, setIsVerifyingPin] = useState(false);

  // Card Action Menu & Delete Confirmation
  const [actionMenuOpenId, setActionMenuOpenId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Show Toast
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedbackToast({ type, message });
    setTimeout(() => {
      setFeedbackToast((prev) => (prev?.message === message ? null : prev));
    }, 3500);
  };

  // Close card action menu on outside tap
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.card-action-menu-container')) {
        setActionMenuOpenId(null);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  // Fetch addresses on mount if authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchAddresses().catch(() => {});
    }
  }, [isAuthenticated]);

  // Leaflet Map Initialization
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!mapContainerRef.current) return;

      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }

      // Default Center: Pan-India center
      const defaultCenter: [number, number] = [20.5937, 78.9629];
      const defaultZoom = 5;

      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: defaultZoom,
        zoomControl: true,
        attributionControl: true,
      });

      // Attribution
      if (map.attributionControl) {
        map.attributionControl.setPrefix(
          '<a href="https://leafletjs.com" target="_blank" rel="noopener noreferrer">Leaflet</a>'
        );
      }

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution:
          '&copy; <a href="https://omazify.com/" target="_blank" rel="noopener noreferrer">Omazify Map</a> | &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
      }).addTo(map);

      // Map Click / Tap to pin delivery spot
      map.on('click', (e: L.LeafletMouseEvent) => {
        handleSelectCoordinates(e.latlng.lat, e.latlng.lng, map);
      });

      mapInstanceRef.current = map;

      // Invalidate size for responsive layout
      setTimeout(() => map.invalidateSize(), 150);
      setTimeout(() => map.invalidateSize(), 400);
      setTimeout(() => map.invalidateSize(), 800);
    }, 80);

    const handleResize = () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', handleResize);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
    };
  }, []);

  // Update or create marker on map
  const updateMarkerPosition = (lat: number, lng: number, map: L.Map) => {
    if (markerRef.current) {
      markerRef.current.setLatLng([lat, lng]);
    } else {
      const marker = L.marker([lat, lng], {
        icon: createMapPinIcon(),
        draggable: true,
      }).addTo(map);

      marker.on('dragend', () => {
        const newPos = marker.getLatLng();
        handleSelectCoordinates(newPos.lat, newPos.lng, map);
      });

      markerRef.current = marker;
    }
  };

  // Coordinate selection handler with reverse geocoding
  const handleSelectCoordinates = async (lat: number, lng: number, mapOverride?: L.Map) => {
    const map = mapOverride || mapInstanceRef.current;
    setSelectedCoords({ lat, lng });
    setGpsError(null);
    setGpsSuccessMsg(null);

    if (map) {
      updateMarkerPosition(lat, lng, map);
      map.panTo([lat, lng], { animate: true });
    }

    setIsResolvingLocation(true);
    const lookupId = ++lookupIdRef.current;

    try {
      const geo: GeocodedAddress = await resolveExactLocation(lat, lng);
      if (lookupIdRef.current === lookupId) {
        const summary = geo.displayName || `${geo.street || geo.shortLabel}, ${geo.city} - ${geo.pincode}`;
        setLocationSummary(summary);

        // Pre-fill form state if user opens "Add Address"
        if (!editingAddressId) {
          if (geo.city) setFormCity(geo.city);
          if (geo.state) setFormState(geo.state);
          if (geo.pincode) {
            setFormPincode(geo.pincode);
            setPinVerificationText(`Verified: ${geo.district || geo.city} (${geo.state})`);
          }
          if (geo.street) setFormStreet(geo.street);
        }
      }
    } catch {
      if (lookupIdRef.current === lookupId) {
        // Fallback engine
        const parsed = parseIndianAddressEngine({
          device_gps: { lat, lng },
        });
        setLocationSummary(`${parsed.road_area_colony}, ${parsed.city_district} - ${parsed.pincode}`);
        if (!editingAddressId) {
          setFormCity(parsed.city_district);
          setFormState(parsed.state);
          setFormPincode(parsed.pincode);
          setFormStreet(parsed.road_area_colony);
          setFormLandmark(parsed.inferred_landmark);
        }
      }
    } finally {
      if (lookupIdRef.current === lookupId) {
        setIsResolvingLocation(false);
      }
    }
  };

  // Search location via Nominatim
  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchQuery.trim();
    if (!query) return;

    setIsSearching(true);
    setSearchMessage(null);
    setSearchResults([]);

    try {
      const results = await searchLocationsNominatim(query);
      if (!results || results.length === 0) {
        setSearchMessage({
          type: 'info',
          text: 'No matching location found. Please try another Indian city, locality, or PIN code.',
        });
      } else {
        setSearchResults(results);
      }
    } catch (err: any) {
      setSearchMessage({
        type: 'error',
        text: 'Unable to connect to search service. Please check your connection or tap on the map.',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (res: SearchLocationResult) => {
    setSearchResults([]);
    setSearchMessage(null);
    setSearchQuery(res.primaryName);

    const map = mapInstanceRef.current;
    if (map) {
      map.setView([res.latitude, res.longitude], 15, { animate: true });
      handleSelectCoordinates(res.latitude, res.longitude, map);
    }
  };

  // "Use My Current Location" button handler
  const handleUseCurrentLocation = async () => {
    setIsDetectingGps(true);
    setGpsError(null);
    setGpsSuccessMsg(null);

    try {
      const coords = await getRawCurrentCoords();
      const map = mapInstanceRef.current;
      if (map) {
        map.setView([coords.latitude, coords.longitude], 16, { animate: true });
        await handleSelectCoordinates(coords.latitude, coords.longitude, map);
        setGpsSuccessMsg('Live GPS location detected successfully!');
      }
    } catch (err: any) {
      const errMessage = err?.message || 'Unable to detect current location.';
      setGpsError(errMessage);
    } finally {
      setIsDetectingGps(false);
    }
  };

  // Real-time PIN code verification
  const handlePincodeChange = async (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 6);
    setFormPincode(clean);
    setFormError(null);

    if (clean.length === 6) {
      setIsVerifyingPin(true);
      try {
        const res = await verifyIndianPinCode(clean);
        if (res.isValid) {
          setPinVerificationText(`Verified: ${res.district || ''} (${res.state || ''})`);
          if (res.district && !formCity) setFormCity(res.district);
          if (res.state && !formState) setFormState(res.state);
        } else {
          setPinVerificationText('PIN code not found in postal directory.');
        }
      } catch {
        setPinVerificationText(null);
      } finally {
        setIsVerifyingPin(false);
      }
    } else {
      setPinVerificationText(null);
    }
  };

  // Open "Add New Address" modal
  const handleOpenAddForm = () => {
    setEditingAddressId(null);
    setFormFullName(user?.name || '');
    setFormPhone(user?.phone || '');
    setFormHouse('');
    setFormStreet(locationSummary ? locationSummary.split(',')[0] || '' : '');
    setFormLandmark('');
    setFormPincode('');
    setFormCity('');
    setFormState('');
    setFormType('home');
    setFormIsDefault(addresses.length === 0);
    setFormError(null);
    setPinVerificationText(null);
    setIsFormOpen(true);
  };

  // Open "Edit Address" modal
  const handleOpenEditForm = (addr: Address) => {
    setEditingAddressId(addr.id);
    setFormFullName(addr.fullName);
    setFormPhone(addr.phone);
    setFormHouse(addr.house || '');
    setFormStreet(addr.street);
    setFormLandmark(addr.landmark || '');
    setFormCity(addr.city);
    setFormState(addr.state);
    setFormPincode(addr.pincode);
    setFormType(addr.type || 'home');
    setFormIsDefault(addr.isDefault);
    setFormError(null);
    setPinVerificationText(`Verified: ${addr.city} (${addr.state})`);

    // Center map on address coords if present
    if (addr.latitude && addr.longitude && mapInstanceRef.current) {
      mapInstanceRef.current.setView([addr.latitude, addr.longitude], 15, { animate: true });
      updateMarkerPosition(addr.latitude, addr.longitude, mapInstanceRef.current);
      setSelectedCoords({ lat: addr.latitude, lng: addr.longitude });
    }

    setIsFormOpen(true);
    setActionMenuOpenId(null);
  };

  // Save Address submission handler
  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // 1. Full name validation
    if (!formFullName.trim()) {
      setFormError('Please enter recipient full name.');
      return;
    }

    // 2. Mobile phone validation (Indian 10-digit)
    const cleanPhone = formPhone.replace(/[\s\-+]/g, '');
    const tenDigit = cleanPhone.length === 12 && cleanPhone.startsWith('91') ? cleanPhone.slice(2) : cleanPhone;
    if (!/^[6-9]\d{9}$/.test(tenDigit)) {
      setFormError('Please enter a valid 10-digit Indian mobile number (e.g. 9876543210).');
      return;
    }

    // 3. Indian PIN code validation
    const cleanPin = formPincode.trim();
    if (!/^[1-9][0-9]{5}$/.test(cleanPin)) {
      setFormError('Please enter a valid 6-digit Indian PIN code.');
      return;
    }

    // 4. Street and Building validation
    if (!formStreet.trim()) {
      setFormError('Please enter street, road or locality.');
      return;
    }

    // 5. City and State validation
    if (!formCity.trim() || !formState.trim()) {
      setFormError('Please enter city and state.');
      return;
    }

    setIsSaving(true);

    try {
      const addressPayload = {
        fullName: formFullName.trim(),
        phone: tenDigit,
        house: formHouse.trim() || undefined,
        street: formStreet.trim(),
        landmark: formLandmark.trim() || undefined,
        city: formCity.trim(),
        state: formState.trim(),
        pincode: cleanPin,
        type: formType,
        isDefault: formIsDefault,
        latitude: selectedCoords?.lat,
        longitude: selectedCoords?.lng,
      };

      if (editingAddressId) {
        await updateAddress(editingAddressId, addressPayload);
        showToast('Address updated successfully!');
      } else {
        const saved = await addAddress(addressPayload);
        showToast('Address saved successfully!');

        // If checkout selection mode, select newly saved address
        if (isCheckoutSelection && onSelectAddressForCheckout) {
          onSelectAddressForCheckout(saved);
        }
      }

      setIsFormOpen(false);
      setEditingAddressId(null);
    } catch (err: any) {
      setFormError(err?.message || 'Failed to save address. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Set Address as default
  const handleSetDefault = async (addr: Address) => {
    setActionMenuOpenId(null);
    try {
      await setDefaultAddress(addr.id);
      showToast(`${addr.fullName}'s address set as default.`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to update default address.', 'error');
    }
  };

  // Confirm delete address
  const handleConfirmDelete = async () => {
    if (!deleteConfirmId) return;
    setIsDeleting(true);
    try {
      await deleteAddress(deleteConfirmId);
      showToast('Address deleted successfully.');
      setDeleteConfirmId(null);
    } catch (err: any) {
      showToast(err?.message || 'Failed to delete address.', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Address card click (if used during checkout or card selection)
  const handleCardClick = (addr: Address) => {
    if (isCheckoutSelection && onSelectAddressForCheckout) {
      onSelectAddressForCheckout(addr);
      onBack();
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#F5F5F5] flex flex-col pb-24 md:pb-12 text-[#171717]">
      {/* Toast Feedback */}
      {feedbackToast && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl shadow-xl text-xs font-black flex items-center gap-2 animate-in fade-in slide-in-from-top-2 ${
            feedbackToast.type === 'success'
              ? 'bg-black text-white border border-neutral-700'
              : 'bg-rose-600 text-white'
          }`}
        >
          {feedbackToast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-[#FFD600]" />
          ) : (
            <AlertCircle className="w-4 h-4 text-white" />
          )}
          <span>{feedbackToast.message}</span>
        </div>
      )}

      {/* TOP HEADER */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#E5E5E5] shadow-2xs">
        <div className="max-w-xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="w-9 h-9 rounded-full flex items-center justify-center text-black hover:bg-neutral-100 transition-colors cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-extrabold text-black tracking-tight">
              Saved Addresses
            </h1>
          </div>
          <span className="text-xs font-bold text-black bg-[#FFF3AE]/70 px-2.5 py-1 rounded-full border border-[#FFD600]/40">
            {addresses.length} {addresses.length === 1 ? 'Address' : 'Addresses'}
          </span>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="max-w-xl mx-auto w-full px-4 pt-3.5 space-y-4">
        {/* ACTION: Add New Address */}
        <button
          onClick={handleOpenAddForm}
          className="w-full bg-white hover:bg-neutral-50 active:scale-[0.99] border border-[#E5E5E5] text-black rounded-2xl p-3.5 flex items-center justify-between font-extrabold text-sm transition-all shadow-2xs cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#FFD600] text-black flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
              <Plus className="w-4 h-4 stroke-[3]" />
            </div>
            <span className="text-sm font-extrabold text-black">Add New Address</span>
          </div>
          <ChevronRight className="w-5 h-5 text-black group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* MAP SECTION */}
        <section className="bg-white rounded-2xl border border-[#E5E5E5] p-3.5 sm:p-4 shadow-2xs space-y-3">
          {/* Heading */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#FFF3AE] text-black flex items-center justify-center">
                <MapPin className="w-4 h-4 text-black" />
              </div>
              <div>
                <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider text-black">
                  SELECT DELIVERY SPOT ON MAP
                </h2>
                <p className="text-[11px] text-[#737373] font-medium">
                  Tap map or drag pin to choose exact delivery point
                </p>
              </div>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <form onSubmit={handleSearch} className="flex items-center gap-1.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-black" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search city, locality, street or PIN"
                  className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-white border border-[#E5E5E5] text-black placeholder:text-[#737373] focus:outline-none focus:border-black transition-colors"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSearchResults([]);
                      setSearchMessage(null);
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#737373] hover:text-black cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                type="submit"
                disabled={isSearching}
                className="px-4 py-2 bg-[#FFD600] hover:bg-[#ECC600] active:scale-95 text-black font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-2xs disabled:opacity-50"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Searching...</span>
                  </>
                ) : (
                  <span>Search</span>
                )}
              </button>
            </form>

            {/* Search results dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-[#E5E5E5] z-30 max-h-48 overflow-y-auto divide-y divide-neutral-100">
                {searchResults.map((res) => (
                  <button
                    key={res.placeId}
                    type="button"
                    onClick={() => handleSelectSearchResult(res)}
                    className="w-full text-left px-3 py-2.5 hover:bg-neutral-50 flex items-start gap-2.5 transition-colors cursor-pointer"
                  >
                    <MapPin className="w-4 h-4 text-black shrink-0 mt-0.5" />
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-black truncate">{res.primaryName}</p>
                      <p className="text-[11px] text-[#737373] truncate">{res.secondaryName}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Search feedback */}
            {searchMessage && (
              <div
                className={`mt-1.5 p-2 rounded-lg text-xs font-medium flex items-center gap-2 ${
                  searchMessage.type === 'error'
                    ? 'bg-rose-50 text-rose-700 border border-rose-200'
                    : 'bg-amber-50 text-amber-800 border border-amber-200'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{searchMessage.text}</span>
              </div>
            )}
          </div>

          {/* Interactive Map Container */}
          <div className="relative w-full h-56 sm:h-64 rounded-xl overflow-hidden border border-[#E5E5E5] shadow-inner bg-neutral-100">
            <div ref={mapContainerRef} className="w-full h-full z-10" />

            {/* Map badge overlay */}
            <div className="absolute top-2 left-2 z-20 pointer-events-none">
              <span className="px-2.5 py-1 bg-black/80 backdrop-blur-xs text-white text-[10px] font-bold rounded-lg shadow-xs flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FFD600] animate-pulse" />
                Interactive OpenStreetMap
              </span>
            </div>

            {/* Reverse Geocoding Loader */}
            {isResolvingLocation && (
              <div className="absolute inset-0 z-20 bg-black/25 backdrop-blur-[1px] flex items-center justify-center pointer-events-none">
                <div className="px-3.5 py-1.5 bg-black/90 text-white text-xs font-semibold rounded-xl flex items-center gap-2 shadow-lg">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-[#FFD600]" />
                  <span>Detecting location...</span>
                </div>
              </div>
            )}
          </div>

          {/* Selected Location Summary */}
          {locationSummary && (
            <div className="p-2.5 rounded-xl bg-[#FFF3AE]/40 border border-[#FFD600]/60 text-xs flex items-start justify-between gap-2">
              <div className="flex items-start gap-2 overflow-hidden">
                <MapPin className="w-4 h-4 text-black shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-black text-black block">
                    Selected Pin Spot
                  </span>
                  <p className="text-xs font-semibold text-black line-clamp-2">
                    {locationSummary}
                  </p>
                </div>
              </div>
              <button
                onClick={handleOpenAddForm}
                className="shrink-0 px-2.5 py-1 bg-[#FFD600] text-black rounded-lg text-[11px] font-extrabold hover:bg-[#ECC600] transition-colors cursor-pointer shadow-2xs"
              >
                Use For Address
              </button>
            </div>
          )}

          {/* "Use My Current Location" Button */}
          <button
            type="button"
            disabled={isDetectingGps}
            onClick={handleUseCurrentLocation}
            className="w-full py-3 px-4 rounded-xl bg-[#FFD600] hover:bg-[#ECC600] active:scale-[0.99] text-black font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs disabled:opacity-60"
          >
            {isDetectingGps ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-black" />
                <span>Detecting Location...</span>
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4 text-black fill-black" />
                <span>Use My Current Location</span>
              </>
            )}
          </button>

          {/* GPS Error notice */}
          {gpsError && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{gpsError}</span>
            </div>
          )}

          {/* GPS Success notice */}
          {gpsSuccessMsg && !gpsError && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{gpsSuccessMsg}</span>
            </div>
          )}
        </section>

        {/* SAVED ADDRESS CARDS */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs sm:text-sm font-extrabold text-black uppercase tracking-wider flex items-center gap-1.5">
              <span>Saved Addresses</span>
            </h3>
            {addresses.length > 0 && (
              <span className="text-[11px] font-bold text-[#737373]">
                {addresses.length} total
              </span>
            )}
          </div>

          {/* Address List */}
          {addresses.length === 0 ? (
            <div className="bg-white rounded-2xl border border-[#E5E5E5] p-8 text-center space-y-3 shadow-2xs">
              <div className="w-14 h-14 rounded-2xl bg-[#FFF3AE] text-black flex items-center justify-center mx-auto">
                <MapPin className="w-7 h-7 text-black" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-black">
                  No saved addresses yet
                </h4>
                <p className="text-xs text-[#737373] mt-1 max-w-xs mx-auto">
                  Add your delivery address for a faster checkout experience.
                </p>
              </div>
              <button
                onClick={handleOpenAddForm}
                className="py-2.5 px-5 bg-[#FFD600] hover:bg-[#ECC600] text-black font-extrabold text-xs rounded-xl shadow-2xs cursor-pointer transition-transform active:scale-95 inline-flex items-center gap-2"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Add New Address</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {addresses.map((addr) => {
                const isMenuOpen = actionMenuOpenId === addr.id;
                return (
                  <div
                    key={addr.id}
                    onClick={() => handleCardClick(addr)}
                    className={`bg-white rounded-2xl border p-4 shadow-2xs transition-all relative ${
                      addr.isDefault
                        ? 'border-neutral-800 bg-white ring-1 ring-neutral-200'
                        : 'border-[#E5E5E5] hover:border-neutral-300'
                    } ${isCheckoutSelection ? 'cursor-pointer hover:ring-2 hover:ring-black' : ''}`}
                  >
                    {/* Header Row: Type icon, Name, Default Badge, 3-dot Menu */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-neutral-100 text-black flex items-center justify-center shrink-0">
                          {addr.type === 'work' ? (
                            <Briefcase className="w-3.5 h-3.5" />
                          ) : (
                            <Home className="w-3.5 h-3.5" />
                          )}
                        </span>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-extrabold text-black">
                              {addr.fullName}
                            </span>
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-neutral-100 text-black">
                              {addr.type || 'home'}
                            </span>
                            {addr.isDefault && (
                              <span className="text-[10px] font-black text-black bg-[#FFF3AE] border border-[#FFD600]/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <Check className="w-3 h-3 stroke-[3]" />
                                Default delivery address
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Three-dot menu trigger */}
                      <div className="relative card-action-menu-container">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActionMenuOpenId(isMenuOpen ? null : addr.id);
                          }}
                          className="w-8 h-8 rounded-full flex items-center justify-center text-black hover:bg-neutral-100 transition-colors cursor-pointer"
                          aria-label="Address actions"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>

                        {/* Dropdown Menu */}
                        {isMenuOpen && (
                          <div
                            onClick={(e) => e.stopPropagation()}
                            className="absolute right-0 top-full mt-1 w-44 bg-white rounded-xl shadow-xl border border-[#E5E5E5] py-1 z-30 divide-y divide-neutral-100 animate-in fade-in zoom-in-95 duration-100"
                          >
                            {!addr.isDefault && (
                              <button
                                type="button"
                                onClick={() => handleSetDefault(addr)}
                                className="w-full px-3.5 py-2 text-left text-xs font-semibold text-neutral-800 hover:bg-neutral-50 flex items-center gap-2 cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5 text-black" />
                                <span>Set as default</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleOpenEditForm(addr)}
                              className="w-full px-3.5 py-2 text-left text-xs font-semibold text-neutral-800 hover:bg-neutral-50 flex items-center gap-2 cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5 text-neutral-600" />
                              <span>Edit Address</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setActionMenuOpenId(null);
                                setDeleteConfirmId(addr.id);
                              }}
                              className="w-full px-3.5 py-2 text-left text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                              <span>Delete Address</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Address details */}
                    <div className="mt-2.5 text-xs text-[#737373] space-y-1">
                      <p className="font-medium text-black/90 leading-relaxed">
                        {addr.house ? `${addr.house}, ` : ''}
                        {addr.street}
                        {addr.landmark ? `, Landmark: ${addr.landmark}` : ''}
                      </p>
                      <p className="font-bold text-black">
                        {addr.city}, {addr.state} - <span className="text-black font-black">{addr.pincode}</span>
                      </p>
                      <p className="flex items-center gap-1.5 text-black font-semibold pt-1">
                        <Phone className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{addr.phone}</span>
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      {/* ADD / EDIT ADDRESS MODAL (Page-like mobile-first sheet) */}
      {isFormOpen && (
        <div
          onClick={() => setIsFormOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#E5E5E5] max-h-[92vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E5E5] bg-white shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#FFD600] text-black font-black flex items-center justify-center shadow-2xs">
                  <MapPin className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-black">
                    {editingAddressId ? 'Edit Delivery Address' : 'Add New Address'}
                  </h3>
                  <p className="text-[11px] text-[#737373]">
                    Accurate details ensure seamless delivery
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-neutral-500 hover:text-black hover:bg-neutral-100 transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Form Body */}
            <form onSubmit={handleSaveAddress} className="p-5 space-y-3.5 overflow-y-auto">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Recipient full name"
                  value={formFullName}
                  onChange={(e) => setFormFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Mobile Phone */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                  Mobile Number *
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500">
                    +91
                  </span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="10-digit mobile number"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full pl-12 pr-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                  />
                </div>
              </div>

              {/* PIN Code & Verification */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-neutral-800">
                    PIN Code *
                  </label>
                  {isVerifyingPin && (
                    <span className="text-[10px] text-neutral-700 font-semibold flex items-center gap-1">
                      <Loader2 className="w-2.5 h-2.5 animate-spin text-black" /> Verifying...
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  required
                  maxLength={6}
                  placeholder="6-digit Indian PIN code"
                  value={formPincode}
                  onChange={(e) => handlePincodeChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs font-bold text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                />
                {pinVerificationText && (
                  <p className="text-[10px] font-bold text-black mt-1 flex items-center gap-1">
                    <Check className="w-3 h-3 stroke-[3] text-emerald-600" />
                    <span>{pinVerificationText}</span>
                  </p>
                )}
              </div>

              {/* House / Flat / Building */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                  House / Flat / Building No.
                </label>
                <input
                  type="text"
                  placeholder="Flat No, Floor, Building Name"
                  value={formHouse}
                  onChange={(e) => setFormHouse(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Street / Road / Locality */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                  Street, Road or Locality *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Colony, Sector, Village or Road"
                  value={formStreet}
                  onChange={(e) => setFormStreet(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Landmark */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                  Landmark (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Near Primary School, Temple, Main Chowk"
                  value={formLandmark}
                  onChange={(e) => setFormLandmark(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                />
              </div>

              {/* City and State Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="City"
                    value={formCity}
                    onChange={(e) => setFormCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-neutral-800 block mb-1">
                    State *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="State"
                    value={formState}
                    onChange={(e) => setFormState(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E5E5] text-xs text-black focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                  />
                </div>
              </div>

              {/* Address Type Buttons */}
              <div>
                <label className="text-[11px] font-bold text-neutral-800 block mb-1.5">
                  Address Type
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['home', 'work', 'other'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setFormType(type)}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold capitalize flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        formType === type
                          ? 'bg-black text-white border-black shadow-2xs'
                          : 'bg-neutral-50 text-black border-[#E5E5E5] hover:bg-neutral-100'
                      }`}
                    >
                      {type === 'home' && <Home className="w-3.5 h-3.5" />}
                      {type === 'work' && <Briefcase className="w-3.5 h-3.5" />}
                      {type === 'other' && <Building className="w-3.5 h-3.5" />}
                      <span>{type}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Set as Default Address Checkbox */}
              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-50 border border-[#E5E5E5] cursor-pointer">
                <input
                  type="checkbox"
                  checked={formIsDefault}
                  onChange={(e) => setFormIsDefault(e.target.checked)}
                  className="w-4 h-4 accent-black rounded cursor-pointer"
                />
                <span className="text-xs font-semibold text-neutral-800">
                  Make this my default delivery address
                </span>
              </label>

              {/* Actions: Save & Cancel */}
              <div className="pt-2 flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="w-1/3 py-3 rounded-xl border border-[#E5E5E5] text-black font-bold text-xs hover:bg-neutral-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="w-2/3 py-3 rounded-xl bg-[#FFD600] hover:bg-[#ECC600] text-black font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                      <span>Saving Delivery Address...</span>
                    </>
                  ) : (
                    <span>Save Delivery Address</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteConfirmId && (
        <div
          onClick={() => setDeleteConfirmId(null)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-2xl border border-slate-100 space-y-4 text-center"
          >
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-extrabold text-slate-900">
                Delete Address?
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to remove this saved delivery address? This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="w-1/2 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 cursor-pointer"
              >
                Keep Address
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="w-1/2 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer disabled:opacity-60 flex items-center justify-center gap-1.5"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <span>Yes, Delete</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
