import React, { useState, useEffect, useRef } from 'react';
import {
  Package, Heart, MapPin, Bell, Headphones,
  RotateCcw, FileText, Lock, LogOut, ChevronRight,
  Edit2, ArrowLeft, Tag, ShieldCheck, HelpCircle,
  Globe, Check, X, Search, Copy, Truck, ExternalLink,
  Navigation, Loader2, AlertCircle
} from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { OmazifyLogo } from '../common/OmazifyLogo';
import { SUPPORTED_LANGUAGES, LanguageCode } from '../../types/language';
import {
  getRawCurrentCoords,
  resolveExactLocation,
  searchLocationsNominatim,
  verifyIndianPinCode,
  verifyLocationMatchesPin,
  IndiaPostVerificationResult,
  SearchLocationResult,
} from '../../utils/locationService';

// Custom Omazify delivery pin marker
const createDeliveryPinIcon = () => {
  return L.divIcon({
    className: 'custom-delivery-pin',
    html: `
      <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 44px; height: 44px; cursor: grab;">
        <div style="position: absolute; width: 40px; height: 40px; background: rgba(255, 212, 0, 0.4); border-radius: 50%; animation: ping 1.8s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
        <div style="position: absolute; bottom: 0; width: 14px; height: 6px; background: rgba(0,0,0,0.35); border-radius: 50%; filter: blur(1.5px);"></div>
        <div style="position: relative; width: 32px; height: 32px; background: #000000; border: 3px solid #FFD400; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 14px rgba(0,0,0,0.45); top: -6px;">
          <div style="width: 10px; height: 10px; background: #FFD400; border-radius: 50%; transform: rotate(45deg); box-shadow: 0 0 6px #FFD400;"></div>
        </div>
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 38],
    popupAnchor: [0, -38],
  });
};

interface AccountScreenProps {
  onBack: () => void;
  onOpenOrders: () => void;
  onOpenWishlist: () => void;
  onOpenNotifications: () => void;
  onOpenSupport: () => void;
  onOpenPolicies: (title: string) => void;
  onOpenAddresses: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  wishlistCount: number;
}

export const AccountScreen: React.FC<AccountScreenProps> = ({
  onBack,
  onOpenOrders,
  onOpenWishlist,
  onOpenNotifications,
  onOpenSupport,
  onOpenPolicies,
  onOpenAddresses,
  onOpenAuth,
  wishlistCount,
}) => {
  const { user, isAuthenticated, logout, unreadNotificationCount, updateProfile, addAddress } = useAuth();
  const { t, currentLanguageMeta, currentLanguage, setLanguage } = useLanguage();

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editPhone, setEditPhone] = useState(user?.phone || '');
  const [isSaving, setIsSaving] = useState(false);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  const [isLanguageSheetOpen, setIsLanguageSheetOpen] = useState(false);
  const [languageSearch, setLanguageSearch] = useState('');
  const [isAddressSheetOpen, setIsAddressSheetOpen] = useState(false);
  const [guestAddress, setGuestAddress] = useState(() => {
    try {
      const saved = localStorage.getItem('ntix_saved_address');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [addrForm, setAddrForm] = useState(() => {
    try {
      const saved = localStorage.getItem('ntix_saved_address');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          name: parsed.name || '',
          phone: parsed.phone || '',
          pincode: parsed.pincode || '',
          city: parsed.city || '',
          street: parsed.street || '',
        };
      }
    } catch {}
    return {
      name: '',
      phone: '',
      pincode: localStorage.getItem('ntix_delivery_pin') || '',
      city: localStorage.getItem('ntix_delivery_city') || '',
      street: '',
    };
  });

  // Map DOM & Leaflet instance refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const lookupIdRef = useRef(0);

  // Map search & geocoding states
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchLocationResult[]>([]);
  const [searchMessage, setSearchMessage] = useState<{ type: 'error' | 'info'; text: string } | null>(null);
  const [selectedLocationLabel, setSelectedLocationLabel] = useState<string | null>(null);
  const [isReverseGeocoding, setIsReverseGeocoding] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [locationSuccessMsg, setLocationSuccessMsg] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isSavingAddress, setIsSavingAddress] = useState(false);

  // India Post PIN Verification states
  const [pinVerification, setPinVerification] = useState<IndiaPostVerificationResult | null>(null);
  const [isVerifyingPin, setIsVerifyingPin] = useState(false);

  const [isPrivacySheetOpen, setIsPrivacySheetOpen] = useState(false);
  const [isCouponsSheetOpen, setIsCouponsSheetOpen] = useState(false);
  const [copiedCoupon, setCopiedCoupon] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setFeedbackNotice(msg);
    setTimeout(() => setFeedbackNotice(null), 2500);
  };

  // Helper to place or move marker on map
  const updateMapMarker = (lat: number, lng: number, map: L.Map) => {
    if (markerRef.current) {
      markerRef.current.setLatLng([lat, lng]);
    } else {
      const marker = L.marker([lat, lng], {
        icon: createDeliveryPinIcon(),
        draggable: true,
      }).addTo(map);

      marker.on('dragend', () => {
        const pos = marker.getLatLng();
        handleSelectMapCoords(pos.lat, pos.lng);
      });
      markerRef.current = marker;
    }
  };

  // Coordinate selection from map click, search result, or GPS
  const handleSelectMapCoords = async (lat: number, lng: number, mapOverride?: L.Map) => {
    const map = mapOverride || mapInstanceRef.current;
    if (!map) return;

    setGpsError(null);
    setFormError(null);
    updateMapMarker(lat, lng, map);
    map.panTo([lat, lng], { animate: true });

    // Immediately clear stale location-dependent values while new lookup is pending
    setAddrForm((prev) => ({
      ...prev,
      city: '',
      pincode: '',
    }));
    setPinVerification(null);
    setSelectedLocationLabel(null);
    setLocationSuccessMsg(null);
    setIsReverseGeocoding(true);

    const currentLookupId = ++lookupIdRef.current;

    try {
      const geo = await resolveExactLocation(lat, lng);
      // Prevent race conditions
      if (lookupIdRef.current === currentLookupId) {
        setSelectedLocationLabel(geo.displayName || `${geo.street}, ${geo.city}`);

        setAddrForm((prev) => ({
          ...prev,
          city: geo.city && geo.city !== 'Selected Location' ? geo.city : '',
          pincode: geo.isPinVerified && geo.pincode ? geo.pincode : '',
          street: prev.street.trim() ? prev.street : (geo.street || geo.shortLabel || ''),
        }));

        if (geo.isPinVerified && geo.pincode) {
          setPinVerification({
            isValid: true,
            pincode: geo.pincode,
            district: geo.district || geo.city,
            state: geo.state,
            postOffices: geo.verifiedPostOffices || [],
            message: geo.pinVerificationMessage || 'Verified by India Post',
          });
          setLocationSuccessMsg(`Location pinned: ${geo.street || geo.shortLabel}, ${geo.city} - PIN: ${geo.pincode} (India Post Verified)`);
        } else {
          setPinVerification(null);
          setLocationSuccessMsg('PIN code could not be verified for this location. Please enter 6-digit PIN manually.');
        }
      }
    } catch {
      if (lookupIdRef.current === currentLookupId) {
        setSelectedLocationLabel(`Location (${lat.toFixed(5)}, ${lng.toFixed(5)})`);
        setLocationSuccessMsg('PIN code could not be verified for this location. Please enter manually.');
      }
    } finally {
      if (lookupIdRef.current === currentLookupId) {
        setIsReverseGeocoding(false);
      }
    }
  };

  // Real-time manual PIN code change and India Post directory validation
  const handlePinChange = async (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 6);
    setAddrForm((prev) => ({ ...prev, pincode: clean }));
    setFormError(null);

    if (clean.length === 6) {
      setIsVerifyingPin(true);
      try {
        const res = await verifyIndianPinCode(clean);
        setPinVerification(res);
        if (res.isValid && res.district && !addrForm.city.trim()) {
          setAddrForm((prev) => ({ ...prev, city: res.district }));
        }
      } finally {
        setIsVerifyingPin(false);
      }
    } else {
      setPinVerification(null);
    }
  };

  // Initialize and clean up Leaflet Map
  useEffect(() => {
    if (!isAddressSheetOpen) {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
      setSearchQuery('');
      setSearchResults([]);
      setSearchMessage(null);
      setGpsError(null);
      setFormError(null);
      setIsSearching(false);
      return;
    }

    const timer = setTimeout(() => {
      if (!mapContainerRef.current) return;

      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }

      // Default center: India overview without hardcoded location default
      const defaultCenter: [number, number] = [20.5937, 78.9629];
      const defaultZoom = 5;

      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: defaultZoom,
        zoomControl: true,
        attributionControl: true,
      });

      if (map.attributionControl) {
        map.attributionControl.setPrefix(
          '<a href="https://leafletjs.com" target="_blank" rel="noopener noreferrer">Leaflet</a>'
        );
      }

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution:
          '&copy; <a href="https://omazify.com/" target="_blank" rel="noopener noreferrer">Omazify Map</a> | &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
      }).addTo(map);

      map.on('click', (e: L.LeafletMouseEvent) => {
        handleSelectMapCoords(e.latlng.lat, e.latlng.lng, map);
      });

      mapInstanceRef.current = map;

      // Invalidate size to guarantee responsive rendering
      setTimeout(() => {
        if (mapInstanceRef.current) mapInstanceRef.current.invalidateSize();
      }, 100);
      setTimeout(() => {
        if (mapInstanceRef.current) mapInstanceRef.current.invalidateSize();
      }, 300);
      setTimeout(() => {
        if (mapInstanceRef.current) mapInstanceRef.current.invalidateSize();
      }, 600);
    }, 60);

    const handleResize = () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', handleResize);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
    };
  }, [isAddressSheetOpen]);

  // Use My Current Location (GPS)
  const handleUseLiveLocation = async () => {
    setIsDetectingLocation(true);
    setLocationSuccessMsg(null);
    setGpsError(null);
    setFormError(null);

    try {
      const coords = await getRawCurrentCoords();
      const map = mapInstanceRef.current;
      if (map) {
        map.setView([coords.latitude, coords.longitude], 16, { animate: true });
        await handleSelectMapCoords(coords.latitude, coords.longitude, map);
      }
      showToast('Live GPS location detected & map centered!');
    } catch (err: any) {
      setGpsError(err.message || 'Unable to detect live location. Please tap directly on the map.');
      showToast(err.message || 'Unable to detect live location');
    } finally {
      setIsDetectingLocation(false);
    }
  };

  // Location search using OpenStreetMap Nominatim
  const handleSearchLocation = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchQuery.trim();
    if (!query) {
      setSearchMessage({ type: 'error', text: 'Please enter a city, locality, street, or landmark.' });
      return;
    }

    setIsSearching(true);
    setSearchMessage(null);
    setSearchResults([]);

    try {
      const results = await searchLocationsNominatim(query);
      if (!results || results.length === 0) {
        setSearchMessage({
          type: 'info',
          text: `No matching locations found for "${query}". Try searching a city, locality or tap on the map.`,
        });
      } else {
        setSearchResults(results);
      }
    } catch (err: any) {
      setSearchMessage({
        type: 'error',
        text: err.message || 'Search request failed. Please check connection or tap on the map.',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (res: SearchLocationResult) => {
    setSearchResults([]);
    setSearchMessage(null);
    setSearchQuery(res.primaryName);
    const map = mapInstanceRef.current;
    if (map) {
      map.setView([res.latitude, res.longitude], 15, { animate: true });
      handleSelectMapCoords(res.latitude, res.longitude, map);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    setIsSaving(true);
    try {
      await updateProfile(editName.trim(), editPhone.trim());
      setIsEditingProfile(false);
      showToast('Profile updated successfully!');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelectLanguage = (code: LanguageCode, nativeName: string) => {
    setLanguage(code);
    setIsLanguageSheetOpen(false);
    showToast(`Language set to ${nativeName}`);
  };

  // Save Delivery Address with strict Indian phone & PIN validation + persistent workflow
  const handleSaveGuestAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // 1. Validate full name
    if (!addrForm.name.trim()) {
      setFormError("Please enter the receiver's Full Name.");
      return;
    }

    // 2. Validate Indian 10-digit mobile number
    const cleanPhone = addrForm.phone.replace(/[\s\-+]/g, '');
    const tenDigitPhone = cleanPhone.length === 12 && cleanPhone.startsWith('91') ? cleanPhone.slice(2) : cleanPhone;
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(tenDigitPhone)) {
      setFormError('Please enter a valid 10-digit Indian mobile number (e.g. 9876543210).');
      return;
    }

    // 3. Validate 6-digit Indian PIN code against India Post
    const cleanPin = addrForm.pincode.replace(/\s+/g, '');
    const pinRegex = /^[1-9][0-9]{5}$/;
    if (!pinRegex.test(cleanPin)) {
      setFormError('Please enter a valid 6-digit Indian PIN code (e.g. 110001, 400050).');
      return;
    }

    const pinCheck = await verifyIndianPinCode(cleanPin);
    if (!pinCheck.isValid) {
      setFormError('PIN code could not be verified in India Post directory. Please enter a valid Indian PIN.');
      return;
    }

    // 4. Validate City
    if (!addrForm.city.trim()) {
      setFormError('Please enter or select City.');
      return;
    }

    // 5. Validate House / Flat / Street / Area
    if (!addrForm.street.trim()) {
      setFormError('Please enter House / Flat / Street / Area.');
      return;
    }

    setIsSavingAddress(true);
    try {
      const newAddr = {
        name: addrForm.name.trim(),
        phone: tenDigitPhone,
        pincode: cleanPin,
        city: addrForm.city.trim(),
        street: addrForm.street.trim(),
      };

      // Save locally in persistent storage for 1-click Cash on Delivery
      localStorage.setItem('ntix_saved_address', JSON.stringify(newAddr));
      localStorage.setItem('ntix_delivery_pin', newAddr.pincode);
      localStorage.setItem('ntix_delivery_city', newAddr.city);
      setGuestAddress(newAddr);

      // If user is authenticated, sync with user profile backend addresses
      if (isAuthenticated) {
        try {
          await addAddress({
            fullName: newAddr.name,
            phone: newAddr.phone,
            street: newAddr.street,
            city: newAddr.city,
            state: '',
            pincode: newAddr.pincode,
            type: 'home',
            isDefault: true,
          });
        } catch (backendErr: any) {
          console.warn('Backend sync note:', backendErr?.message);
        }
      }

      showToast('Delivery Address saved successfully!');
      setLocationSuccessMsg('Delivery Address saved successfully for Cash on Delivery!');
      setTimeout(() => {
        setIsAddressSheetOpen(false);
      }, 700);
    } catch (err: any) {
      setFormError(err.message || 'Unable to save delivery address. Please check your details and try again.');
    } finally {
      setIsSavingAddress(false);
    }
  };

  const handleCopyCoupon = (code: string) => {
    navigator.clipboard?.writeText(code);
    setCopiedCoupon(code);
    showToast(`Coupon "${code}" copied!`);
    setTimeout(() => setCopiedCoupon(null), 2500);
  };

  const filteredLanguages = SUPPORTED_LANGUAGES.filter((l) =>
    l.name.toLowerCase().includes(languageSearch.toLowerCase()) ||
    l.nativeName.toLowerCase().includes(languageSearch.toLowerCase())
  );

  return (
    <div className="w-full min-h-screen bg-[#FAFAFA] pb-24 flex flex-col">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-[#FAFAFA] px-4 py-2.5 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-[#FAFAFA] active:scale-95 text-slate-700 hover:text-black font-bold flex items-center justify-center transition-all cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="text-base font-extrabold text-[#172033] tracking-tight">
            My Account
          </h1>
        </div>
        <OmazifyLogo size="sm" />
      </div>

      <div className="max-w-xl mx-auto w-full px-4 py-3.5 space-y-3.5">
        {/* Feedback Alert Toast */}
        {feedbackNotice && (
          <div className="p-2.5 bg-[#FFD400] text-black font-black rounded-xl shadow-md text-xs font-bold text-center animate-in fade-in duration-150">
            {feedbackNotice}
          </div>
        )}

        {/* LOGGED IN vs LOGGED OUT CARD */}
        {!isAuthenticated ? (
          <div className="bg-white rounded-[20px] border border-[#FAFAFA] p-4 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#172033]">
                Login to your OMAZIFY account
              </h2>
              <p className="text-xs text-[#7B8496] mt-0.5">
                Track your orders, view wishlist & manage addresses
              </p>
            </div>
            <button
              onClick={() => onOpenAuth('login')}
              className="py-2 px-5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black font-extrabold text-xs shadow-2xs cursor-pointer self-start sm:self-auto transition-transform active:scale-95"
            >
              Login
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-[20px] border border-[#FAFAFA] p-4 shadow-2xs space-y-3">
            <div className="flex items-center gap-3">
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.name}
                  className="w-12 h-12 rounded-xl object-cover border border-[#EAEAEA] flex-shrink-0"
                />
              ) : (
                <div className="w-12 h-12 rounded-xl bg-[#FFD400] text-black font-black font-black text-lg flex items-center justify-center flex-shrink-0 shadow-xs">
                  {user?.name ? user.name[0].toUpperCase() : 'U'}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold text-[#172033] truncate">
                    {user?.name || 'Valued Shopper'}
                  </h3>
                  <button
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                    className="text-[11px] font-bold text-black font-bold hover:text-[#000000] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>{isEditingProfile ? 'Cancel' : 'Edit'}</span>
                  </button>
                </div>
                <p className="text-xs text-[#7B8496] truncate">{user?.email}</p>
                {user?.phone && (
                  <p className="text-[11px] text-black font-bold font-semibold">{user.phone}</p>
                )}
              </div>
            </div>

            {isEditingProfile && (
              <form onSubmit={handleSaveProfile} className="pt-2 border-t border-[#FAFAFA] space-y-2">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-[#EAEAEA] text-xs text-[#172033] focus:outline-none focus:ring-1 focus:ring-black focus:border-black"
                />
                <input
                  type="tel"
                  placeholder="Mobile Phone (10 digits)"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-[#EAEAEA] text-xs text-[#172033] focus:outline-none focus:ring-1 focus:ring-black focus:border-black"
                />
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-4 py-1 rounded-lg text-xs font-bold bg-[#FFD400] hover:bg-[#FFC800] text-black font-black cursor-pointer transition-colors shadow-2xs"
                  >
                    {isSaving ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* GROUP 1: ACCOUNT SETTINGS */}
        <div className="bg-white rounded-[20px] border border-[#FAFAFA] overflow-hidden shadow-2xs">
          <div className="px-4 py-2.5 bg-[#FAFAFA] border-b border-[#FAFAFA]">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#7B8496]">
              Account Settings
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {/* 1. Language Option */}
            <button
              onClick={() => setIsLanguageSheetOpen(true)}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">
                    {t('language') || 'Language'}
                  </span>
                  <span className="text-[10px] text-[#7B8496]">
                    13 Indian Languages Supported
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-extrabold text-black font-bold bg-[#FAFAFA] px-2 py-0.5 rounded-md border border-[#EAEAEA]">
                  {currentLanguageMeta.nativeName}
                </span>
                <ChevronRight className="w-4 h-4 text-black font-bold group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            {/* 2. Notifications */}
            <button
              onClick={onOpenNotifications}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">Notifications</span>
                  <span className="text-[10px] text-[#7B8496]">Order tracking & COD alerts</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {unreadNotificationCount > 0 && (
                  <span className="px-2 py-0.5 bg-[#FFD400] text-black font-black text-[10px] font-bold rounded-full">
                    {unreadNotificationCount}
                  </span>
                )}
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            {/* 3. Privacy & Security */}
            <button
              onClick={() => setIsPrivacySheetOpen(true)}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">Privacy & Security</span>
                  <span className="text-[10px] text-[#7B8496]">100% Cash on Delivery Safety</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
            </button>

            {/* 4. Saved Addresses */}
            <button
              onClick={() => onOpenAddresses()}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">Saved Addresses</span>
                  <span className="text-[10px] text-[#7B8496]">
                    {guestAddress ? `${guestAddress.city} - ${guestAddress.pincode}` : 'Delivery address for 1-click COD'}
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* GROUP 2: MY SHOPPING */}
        <div className="bg-white rounded-[20px] border border-[#FAFAFA] overflow-hidden shadow-2xs">
          <div className="px-4 py-2.5 bg-[#FAFAFA] border-b border-[#FAFAFA]">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#7B8496]">
              My Shopping
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            <button
              onClick={() => {
                if (isAuthenticated) {
                  onOpenOrders();
                } else {
                  onOpenAuth('login');
                }
              }}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">My Orders</span>
                  <span className="text-[10px] text-[#7B8496]">Track and view past purchases</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
            </button>

            <button
              onClick={onOpenWishlist}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Heart className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">Wishlist</span>
                  <span className="text-[10px] text-[#7B8496]">Saved favorite styles</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {wishlistCount > 0 && (
                  <span className="px-2 py-0.5 bg-[#FAFAFA] text-[#000000] text-[10px] font-bold rounded-full">
                    {wishlistCount}
                  </span>
                )}
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            <button
              onClick={() => setIsCouponsSheetOpen(true)}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FAFAFA] text-black font-bold flex items-center justify-center">
                  <Tag className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#172033] block">Coupons & Offers</span>
                  <span className="text-[10px] text-[#7B8496] font-medium">View active promotional offers</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* GROUP 3: HELP & SUPPORT */}
        <div className="bg-white rounded-[20px] border border-[#FAFAFA] overflow-hidden shadow-2xs">
          <div className="px-4 py-2.5 bg-[#FAFAFA] border-b border-[#FAFAFA]">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#7B8496]">
              Help & Support
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            <button
              onClick={onOpenSupport}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <Headphones className="w-4 h-4 text-black font-bold" />
                <span className="text-xs font-bold text-[#172033]">Help Center & Live Chat</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              onClick={onOpenSupport}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <HelpCircle className="w-4 h-4 text-black font-bold" />
                <span className="text-xs font-bold text-[#172033]">FAQs & COD Delivery Rules</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              onClick={() => onOpenPolicies('return_refund')}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <RotateCcw className="w-4 h-4 text-black font-bold" />
                <span className="text-xs font-bold text-[#172033]">Easy 7-Day Returns</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* GROUP 4: LEGAL & POLICIES */}
        <div className="bg-white rounded-[20px] border border-[#FAFAFA] overflow-hidden shadow-2xs">
          <div className="px-4 py-2.5 bg-[#FAFAFA] border-b border-[#FAFAFA]">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#7B8496]">
              Legal & Policies
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            <button
              onClick={() => onOpenPolicies('terms')}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-black font-bold" />
                <span className="text-xs font-bold text-[#172033]">Terms of Use</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              onClick={() => onOpenPolicies('privacy')}
              className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-black font-bold" />
                <span className="text-xs font-bold text-[#172033]">Privacy Policy</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* LOG OUT BUTTON */}
        {isAuthenticated && (
          <button
            onClick={logout}
            className="w-full py-3 rounded-2xl bg-white border border-[#EAEAEA] text-black font-bold hover:bg-[#FAFAFA] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-2xs"
          >
            <LogOut className="w-4 h-4 text-black font-bold" />
            <span>Sign Out</span>
          </button>
        )}
      </div>

      {/* LANGUAGE SELECTION BOTTOM SHEET */}
      {isLanguageSheetOpen && (
        <div
          onClick={() => setIsLanguageSheetOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#FAFAFA] max-h-[85vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#FAFAFA] bg-gradient-to-r from-[#FAFAFA] via-white to-[#FAFAFA]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#FFD400] text-black font-black flex items-center justify-center shadow-xs">
                  <Globe className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-[#172033] leading-tight">
                    Select Language / भाषा चुनें
                  </h3>
                  <p className="text-[11px] text-[#7B8496] font-medium">
                    13 Indian Languages Supported
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsLanguageSheetOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-[#172033] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-4 py-2.5 bg-[#FAFAFA] border-b border-[#FAFAFA]">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Search language / भाषा खोजें..."
                  value={languageSearch}
                  onChange={(e) => setLanguageSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-white border border-[#EAEAEA] text-xs font-medium text-[#172033] focus:outline-none focus:border-black"
                />
              </div>
            </div>

            <div className="p-4 overflow-y-auto max-h-[55vh] grid grid-cols-1 sm:grid-cols-2 gap-2">
              {filteredLanguages.map((lang) => {
                const isSelected = currentLanguage === lang.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => handleSelectLanguage(lang.code, lang.nativeName)}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-black bg-[#FAFAFA] shadow-xs ring-1 ring-black'
                        : 'border-slate-200 hover:border-[#000000] hover:bg-[#FAFAFA] bg-white'
                    }`}
                  >
                    <div className="min-w-0 pr-1">
                      <p
                        className={`text-sm sm:text-base font-extrabold leading-tight ${
                          isSelected ? 'text-[#000000]' : 'text-[#172033]'
                        }`}
                      >
                        {lang.nativeName}
                      </p>
                      <p className="text-[11px] font-medium text-[#7B8496] mt-0.5">
                        {lang.name}
                      </p>
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-[#FFD400] text-black font-black flex items-center justify-center flex-shrink-0 shadow-2xs">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="px-5 py-3 bg-[#FAFAFA] border-t border-[#FAFAFA] text-center text-[11px] text-[#000000] font-semibold">
              Tap any language to apply instantly across the whole app
            </div>
          </div>
        </div>
      )}

      {/* SAVED ADDRESS SHEET */}
      {isAddressSheetOpen && (
        <div
          onClick={() => setIsAddressSheetOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-100 max-h-[90vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-gradient-to-r from-[#FAFAFA] via-white to-[#FAFAFA] shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#FFD400] text-black font-black flex items-center justify-center shadow-xs">
                  <MapPin className="w-5 h-5 text-black" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-[#172033] leading-tight">
                    Delivery Address (Cash on Delivery)
                  </h3>
                  <p className="text-[11px] text-[#7B8496] font-medium">
                    Pin delivery location on map & save address
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddressSheetOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-[#172033] hover:bg-slate-100 transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Modal Content */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
              {guestAddress && (
                <div className="p-3.5 rounded-2xl bg-[#FFF9DB]/40 border border-[#FFD400]/40 space-y-1 text-left">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#000000]">{guestAddress.name}</span>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-700" />
                      Active Address
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium">
                    {guestAddress.street}, {guestAddress.city} - {guestAddress.pincode}
                  </p>
                  <p className="text-[11px] text-black font-bold">{guestAddress.phone}</p>
                </div>
              )}

              {/* MAP & SEARCH SECTION AT TOP */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#FFD400]" />
                    <span>Select Delivery Spot On Map</span>
                  </label>
                  <span className="text-[10px] text-slate-500 font-medium">
                    Tap map or drag pin
                  </span>
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <form onSubmit={handleSearchLocation} className="flex items-center gap-1.5">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search Indian city, locality, street, landmark..."
                        className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 text-[#172033] placeholder:text-slate-400 focus:outline-none focus:border-black focus:bg-white transition-colors"
                      />
                      {searchQuery && (
                        <button
                          type="button"
                          onClick={() => {
                            setSearchQuery('');
                            setSearchResults([]);
                            setSearchMessage(null);
                          }}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <button
                      type="submit"
                      disabled={isSearching}
                      className="px-3.5 py-2 bg-[#FFD400] hover:bg-[#FFC800] text-black font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 disabled:opacity-50 shadow-xs"
                    >
                      {isSearching ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Searching...</span>
                        </>
                      ) : (
                        <span>Search</span>
                      )}
                    </button>
                  </form>

                  {/* Search Results Dropdown */}
                  {searchResults.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-slate-200 z-30 max-h-48 overflow-y-auto divide-y divide-slate-100">
                      {searchResults.map((res) => (
                        <button
                          key={res.placeId}
                          type="button"
                          onClick={() => handleSelectSearchResult(res)}
                          className="w-full text-left px-3 py-2.5 hover:bg-amber-50/60 flex items-start gap-2.5 transition-colors cursor-pointer"
                        >
                          <MapPin className="w-4 h-4 text-[#FFD400] shrink-0 mt-0.5" />
                          <div className="overflow-hidden">
                            <p className="text-xs font-bold text-slate-900 truncate">{res.primaryName}</p>
                            <p className="text-[11px] text-slate-500 truncate">{res.secondaryName}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Search feedback / message */}
                  {searchMessage && (
                    <div className={`mt-1.5 p-2 rounded-lg text-xs font-medium flex items-center gap-2 ${
                      searchMessage.type === 'error'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}>
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{searchMessage.text}</span>
                    </div>
                  )}
                </div>

                {/* Leaflet Map container */}
                <div className="relative w-full h-56 sm:h-64 rounded-2xl overflow-hidden border border-slate-200 shadow-inner bg-slate-100">
                  <div ref={mapContainerRef} className="w-full h-full z-10" />

                  {/* Map overlay hint */}
                  <div className="absolute top-2 left-2 z-20 pointer-events-none">
                    <span className="px-2.5 py-1 bg-black/75 backdrop-blur-xs text-white text-[10px] font-bold rounded-lg shadow-sm flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#FFD400] animate-pulse" />
                      Tap map to select delivery point
                    </span>
                  </div>

                  {/* Geocoding loading overlay */}
                  {isReverseGeocoding && (
                    <div className="absolute inset-0 z-20 bg-black/20 backdrop-blur-[1px] flex items-center justify-center pointer-events-none">
                      <div className="px-3 py-1.5 bg-black/85 text-white text-xs font-semibold rounded-xl flex items-center gap-2 shadow-lg">
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-[#FFD400]" />
                        <span>Detecting address...</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Prominent Use My Current Location Button */}
                <button
                  type="button"
                  disabled={isDetectingLocation}
                  onClick={handleUseLiveLocation}
                  className="w-full py-3 px-4 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] active:scale-[0.99] text-black font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm disabled:opacity-60"
                >
                  {isDetectingLocation ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                      <span>Detecting Live GPS Location...</span>
                    </>
                  ) : (
                    <>
                      <Navigation className="w-4 h-4 text-black" />
                      <span>Use My Current Location</span>
                    </>
                  )}
                </button>

                {/* GPS Error notice */}
                {gpsError && (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>{gpsError}</span>
                  </div>
                )}

                {/* Selected location feedback banner */}
                {selectedLocationLabel && !gpsError && (
                  <div className="p-2.5 bg-amber-50/80 border border-[#FFD400]/60 rounded-xl text-xs text-slate-800 font-semibold flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-black shrink-0 mt-0.5" />
                    <div className="overflow-hidden">
                      <span className="text-[10px] text-slate-500 uppercase font-black block">Selected Location</span>
                      <span className="text-xs text-black font-bold truncate block">{selectedLocationLabel}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Form Error Banner */}
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Success Banner */}
              {locationSuccessMsg && !formError && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{locationSuccessMsg}</span>
                </div>
              )}

              {/* Address Form Fields */}
              <form onSubmit={handleSaveGuestAddress} className="space-y-3 pt-1">
                <div>
                  <label className="text-[11px] font-bold text-[#172033] block mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Receiver's name"
                    value={addrForm.name}
                    onChange={(e) => setAddrForm({ ...addrForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-[#172033] focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-[#172033] block mb-1">Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    placeholder="10-digit mobile number for COD OTP"
                    value={addrForm.phone}
                    onChange={(e) => setAddrForm({ ...addrForm, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-[#172033] focus:outline-none focus:border-black"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-bold text-[#172033]">Pincode *</label>
                      {isVerifyingPin && (
                        <span className="text-[10px] text-amber-700 font-medium flex items-center gap-1">
                          <Loader2 className="w-2.5 h-2.5 animate-spin text-amber-600" />
                          Checking...
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      placeholder="6-digit PIN code"
                      value={addrForm.pincode}
                      onChange={(e) => handlePinChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-[#172033] focus:outline-none focus:border-black font-bold"
                    />
                    {pinVerification && pinVerification.isValid && (
                      <p className="text-[10px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                        <span className="truncate">Verified: {pinVerification.district || pinVerification.state}</span>
                      </p>
                    )}
                    {pinVerification && !pinVerification.isValid && (
                      <p className="text-[10px] text-rose-600 font-semibold mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3 text-rose-500 flex-shrink-0" />
                        <span>Unverified PIN code</span>
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#172033] block mb-1">City *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Mumbai, Patna, Delhi"
                      value={addrForm.city}
                      onChange={(e) => setAddrForm({ ...addrForm, city: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-[#172033] focus:outline-none focus:border-black font-bold"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-[#172033] block mb-1">House / Flat / Street / Area *</label>
                  <textarea
                    required
                    rows={2}
                    placeholder="House/Flat number, Building, Colony, Landmark"
                    value={addrForm.street}
                    onChange={(e) => setAddrForm({ ...addrForm, street: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-[#172033] focus:outline-none focus:border-black resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSavingAddress}
                  className="w-full py-3.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black font-extrabold text-xs shadow-md cursor-pointer transition-colors mt-2 flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {isSavingAddress ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                      <span>Saving Address...</span>
                    </>
                  ) : (
                    <span>Save Delivery Address</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* PRIVACY & SECURITY SHEET */}
      {isPrivacySheetOpen && (
        <div
          onClick={() => setIsPrivacySheetOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#FAFAFA] max-h-[85vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#FAFAFA] bg-gradient-to-r from-[#FAFAFA] via-white to-[#FAFAFA]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#FFD400] text-black font-black flex items-center justify-center shadow-xs">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-[#172033] leading-tight">
                    Privacy & Shopping Safety
                  </h3>
                  <p className="text-[11px] text-[#7B8496] font-medium">
                    100% Cash on Delivery protection
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPrivacySheetOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-[#172033] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3.5 overflow-y-auto text-xs text-[#172033]">
              <div className="p-3 bg-[#FAFAFA] rounded-xl border border-[#EAEAEA]">
                <h4 className="font-bold text-[#000000] mb-1 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-black font-bold" />
                  Zero Online Payment Risk
                </h4>
                <p className="text-[11px] text-[#000000] leading-relaxed">
                  We never ask for credit card numbers, debit card details, or UPI PINs. You pay exclusively cash or phone delivery UPI upon receiving your package.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <h4 className="font-bold text-[#172033] mb-1 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-black font-bold" />
                  Doorstep Inspection & OTP Verification
                </h4>
                <p className="text-[11px] text-[#7B8496] leading-relaxed">
                  All deliveries include an OTP sent directly to your phone. Check the package exterior before sharing OTP and paying cash.
                </p>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setIsPrivacySheetOpen(false);
                    onOpenPolicies('privacy');
                  }}
                  className="w-full py-2.5 rounded-xl border border-[#EAEAEA] text-black font-bold hover:text-[#000000] font-bold text-xs hover:bg-[#FAFAFA] cursor-pointer flex items-center justify-center gap-1 transition-colors"
                >
                  <span>Read Full Privacy Policy</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* COUPONS & OFFERS SHEET */}
      {isCouponsSheetOpen && (
        <div
          onClick={() => setIsCouponsSheetOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#FAFAFA] max-h-[85vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#FAFAFA] bg-gradient-to-r from-[#FAFAFA] via-white to-[#FAFAFA]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#FFD400] text-black font-black flex items-center justify-center shadow-xs">
                  <Tag className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-[#172033] leading-tight">
                    Available Coupons & Offers
                  </h3>
                  <p className="text-[11px] text-[#7B8496] font-medium">
                    Click copy to apply on Cash on Delivery checkout
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCouponsSheetOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-[#172033] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 overflow-y-auto">
              <div className="p-3.5 rounded-2xl border border-[#EAEAEA] bg-gradient-to-br from-[#FAFAFA] to-white flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-sm text-[#000000] tracking-wider">
                      OMAZIFY500
                    </span>
                    <span className="text-[9px] font-extrabold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                      ACTIVE
                    </span>
                  </div>
                  <p className="text-xs text-[#172033] font-medium mt-0.5">
                    Flat ₹500 OFF on orders above ₹1,999
                  </p>
                  <p className="text-[10px] text-[#7B8496]">Valid on Footwear & Bags</p>
                </div>
                <button
                  onClick={() => handleCopyCoupon('OMAZIFY500')}
                  className="px-3 py-1.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black text-xs font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-2xs"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedCoupon === 'OMAZIFY500' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-3.5 rounded-2xl border border-[#EAEAEA] bg-gradient-to-br from-[#FAFAFA] to-white flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-sm text-[#000000] tracking-wider">
                      WELCOME10
                    </span>
                    <span className="text-[9px] font-extrabold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                      NEW USER
                    </span>
                  </div>
                  <p className="text-xs text-[#172033] font-medium mt-0.5">
                    10% Instant Discount on First COD Order
                  </p>
                  <p className="text-[10px] text-[#7B8496]">No minimum cart value</p>
                </div>
                <button
                  onClick={() => handleCopyCoupon('WELCOME10')}
                  className="px-3 py-1.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-black font-black text-xs font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-2xs"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedCoupon === 'WELCOME10' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>All Cash on Delivery orders currently qualify for 100% Free Shipping!</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
