import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Calendar,
  Filter,
  FileText,
  Image as ImageIcon,
  Monitor,
  Sparkles,
  User,
  ArrowRight,
  Copy,
  Check,
  Download,
  Clock,
  Layers,
  ChevronDown,
  RotateCcw,
  Paperclip,
  Eye
} from 'lucide-react';
import { ChatMessage, Attachment, PersonaType } from '../types';

interface ChatSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onJumpToMessage: (messageId: string) => void;
}

type DatePreset = 'all' | 'today' | 'yesterday' | 'week' | 'month' | 'custom';
type ContentFilter = 'all' | 'model' | 'user' | 'attachments';
type SortOrder = 'newest' | 'oldest' | 'relevance';

// Helper to highlight matching text
function HighlightedText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) {
    return <span>{text}</span>;
  }

  // Split query into keywords
  const terms = query
    .trim()
    .split(/\s+/)
    .filter((t) => t.length > 0)
    .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));

  if (terms.length === 0) return <span>{text}</span>;

  const regex = new RegExp(`(${terms.join('|')})`, 'gi');
  const parts = text.split(regex);

  return (
    <span>
      {parts.map((part, i) => {
        const isMatch = terms.some((t) => t.toLowerCase() === part.toLowerCase());
        return isMatch ? (
          <mark
            key={i}
            className="bg-amber-400/30 text-amber-200 px-1 py-0.5 rounded font-semibold border-b border-amber-400/50"
          >
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        );
      })}
    </span>
  );
}

// Format relative date and time
function formatMessageDate(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (isToday) return `Today at ${timeStr}`;
  if (isYesterday) return `Yesterday at ${timeStr}`;

  return `${date.toLocaleDateString([], {
    month: 'short',
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
  })} at ${timeStr}`;
}

export function ChatSearchModal({
  isOpen,
  onClose,
  messages,
  onJumpToMessage,
}: ChatSearchModalProps) {
  const [query, setQuery] = useState('');
  const [datePreset, setDatePreset] = useState<DatePreset>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [contentFilter, setContentFilter] = useState<ContentFilter>('all');
  const [fileTypeFilter, setFileTypeFilter] = useState<'all' | 'image' | 'file' | 'screen'>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');
  const [selectedPersona, setSelectedPersona] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewAttachment, setPreviewAttachment] = useState<Attachment | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Focus search input when modal opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        if (previewAttachment) {
          setPreviewAttachment(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, previewAttachment]);

  // Filter messages based on criteria
  const filteredResults = useMemo(() => {
    const trimmedQuery = query.trim().toLowerCase();
    const queryTerms = trimmedQuery ? trimmedQuery.split(/\s+/).filter(Boolean) : [];

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
    const startOfWeek = startOfToday - 7 * 24 * 60 * 60 * 1000;
    const startOfMonth = startOfToday - 30 * 24 * 60 * 60 * 1000;

    return messages
      .filter((msg) => {
        // 1. Content filter (role / attachments)
        if (contentFilter === 'model' && msg.role !== 'model') return false;
        if (contentFilter === 'user' && msg.role !== 'user') return false;
        if (contentFilter === 'attachments') {
          if (!msg.attachments || msg.attachments.length === 0) return false;
        }

        // 2. File type filter (if attachments exist and not 'all')
        if (fileTypeFilter !== 'all') {
          const hasMatchingAttachment = msg.attachments?.some(
            (att) => att.type === fileTypeFilter
          );
          if (!hasMatchingAttachment) return false;
        }

        // 3. Persona filter
        if (selectedPersona !== 'all') {
          if (msg.role === 'model' && msg.persona !== selectedPersona) return false;
        }

        // 4. Date filtering
        const msgTime = msg.timestamp;
        if (datePreset === 'today') {
          if (msgTime < startOfToday) return false;
        } else if (datePreset === 'yesterday') {
          if (msgTime < startOfYesterday || msgTime >= startOfToday) return false;
        } else if (datePreset === 'week') {
          if (msgTime < startOfWeek) return false;
        } else if (datePreset === 'month') {
          if (msgTime < startOfMonth) return false;
        } else if (datePreset === 'custom') {
          if (startDate) {
            const startTs = new Date(startDate).setHours(0, 0, 0, 0);
            if (msgTime < startTs) return false;
          }
          if (endDate) {
            const endTs = new Date(endDate).setHours(23, 59, 59, 999);
            if (msgTime > endTs) return false;
          }
        }

        // 5. Keyword search query
        if (queryTerms.length > 0) {
          const content = (msg.content || '').toLowerCase();
          const attachmentNames = (msg.attachments || [])
            .map((a) => a.name.toLowerCase())
            .join(' ');
          const attachmentTexts = (msg.attachments || [])
            .map((a) => (a.text || '').toLowerCase())
            .join(' ');
          const personaStr = (msg.persona || '').toLowerCase();

          const combinedSearchTarget = `${content} ${attachmentNames} ${attachmentTexts} ${personaStr}`;

          // All terms must be present
          const matchesAll = queryTerms.every((term) =>
            combinedSearchTarget.includes(term)
          );
          if (!matchesAll) return false;
        }

        return true;
      })
      .map((msg) => {
        // Calculate match relevance score
        let score = 0;
        if (queryTerms.length > 0) {
          const lower = msg.content.toLowerCase();
          queryTerms.forEach((term) => {
            const occurrences = lower.split(term).length - 1;
            score += occurrences * 2;
          });
          // Attachment name matches give high relevance
          msg.attachments?.forEach((att) => {
            queryTerms.forEach((term) => {
              if (att.name.toLowerCase().includes(term)) score += 5;
            });
          });
        }
        return { message: msg, score };
      })
      .sort((a, b) => {
        if (sortOrder === 'relevance' && queryTerms.length > 0) {
          if (b.score !== a.score) return b.score - a.score;
        }
        if (sortOrder === 'oldest') {
          return a.message.timestamp - b.message.timestamp;
        }
        // newest first (default)
        return b.message.timestamp - a.message.timestamp;
      });
  }, [
    messages,
    query,
    datePreset,
    startDate,
    endDate,
    contentFilter,
    fileTypeFilter,
    selectedPersona,
    sortOrder,
  ]);

  // Total attachment count in filtered results
  const totalAttachmentsFound = useMemo(() => {
    return filteredResults.reduce(
      (acc, curr) => acc + (curr.message.attachments?.length || 0),
      0
    );
  }, [filteredResults]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetFilters = () => {
    setQuery('');
    setDatePreset('all');
    setStartDate('');
    setEndDate('');
    setContentFilter('all');
    setFileTypeFilter('all');
    setSelectedPersona('all');
    setSortOrder('newest');
  };

  const hasActiveFilters =
    query.trim() !== '' ||
    datePreset !== 'all' ||
    contentFilter !== 'all' ||
    fileTypeFilter !== 'all' ||
    selectedPersona !== 'all' ||
    sortOrder !== 'newest';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header with Search Input */}
        <div className="p-3 sm:p-5 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-500/20">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Chat & File History Search
                  <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-mono font-medium">
                    {messages.length} stored messages
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Search previous responses, user queries, files, photos, and screen captures by keyword or date
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Primary Search Bar */}
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-cyan-400" />
            <input
              ref={searchInputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by keywords, file name, OCR text, or topics (e.g. 'code', 'photo.jpg', 'summary')..."
              className="w-full pl-10 pr-24 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition shadow-inner"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-12 p-1 text-slate-400 hover:text-white transition"
                title="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <div className="absolute right-3 hidden sm:flex items-center gap-1 text-[11px] font-mono text-slate-500 bg-slate-800/60 px-1.5 py-0.5 rounded border border-slate-700">
              ESC
            </div>
          </div>

          {/* Filter Bar Controls */}
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs">
            {/* Quick Content Type Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
              <button
                onClick={() => setContentFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                  contentFilter === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                All Messages
              </button>
              <button
                onClick={() => setContentFilter('model')}
                className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1.5 cursor-pointer ${
                  contentFilter === 'model'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400" /> AI Replies
              </button>
              <button
                onClick={() => setContentFilter('user')}
                className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1.5 cursor-pointer ${
                  contentFilter === 'user'
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <User className="w-3.5 h-3.5 text-blue-400" /> My Questions
              </button>
              <button
                onClick={() => setContentFilter('attachments')}
                className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1.5 cursor-pointer ${
                  contentFilter === 'attachments'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Paperclip className="w-3.5 h-3.5 text-emerald-400" /> With Files & Media
              </button>
            </div>

            {/* Sort & Reset */}
            <div className="flex items-center gap-2 ml-auto">
              {hasActiveFilters && (
                <button
                  onClick={handleResetFilters}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition cursor-pointer"
                  title="Reset all filters"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}

              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as SortOrder)}
                className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 text-xs focus:outline-none focus:border-cyan-500 cursor-pointer"
              >
                <option value="newest">Latest First</option>
                <option value="oldest">Oldest First</option>
                {query.trim() && <option value="relevance">Highest Relevance</option>}
              </select>
            </div>
          </div>

          {/* Date & Detailed Filters Strip */}
          <div className="mt-2.5 flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/60 text-xs text-slate-400">
            {/* Date Preset Selector */}
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-medium text-slate-300">Date:</span>
              <div className="flex items-center gap-1 flex-wrap">
                {(
                  [
                    { id: 'all', label: 'All' },
                    { id: 'today', label: 'Today' },
                    { id: 'yesterday', label: 'Yesterday' },
                    { id: 'week', label: '7 Days' },
                    { id: 'month', label: '30 Days' },
                    { id: 'custom', label: 'Custom' },
                  ] as const
                ).map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setDatePreset(preset.id)}
                    className={`px-2 py-0.5 rounded text-[11px] transition cursor-pointer ${
                      datePreset === preset.id
                        ? 'bg-slate-700 text-cyan-300 font-semibold border border-cyan-500/40'
                        : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Date Pickers when 'custom' is active */}
            {datePreset === 'custom' && (
              <div className="flex items-center gap-1.5 ml-1 bg-slate-950/90 px-2 py-1 rounded-lg border border-slate-700 animate-in fade-in duration-150">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-[11px] text-white focus:outline-none focus:border-cyan-500"
                  title="From Date"
                />
                <span className="text-slate-500">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-[11px] text-white focus:outline-none focus:border-cyan-500"
                  title="To Date"
                />
              </div>
            )}

            {/* File type filter if files filter or in general */}
            {(contentFilter === 'attachments' || contentFilter === 'all') && (
              <div className="flex items-center gap-1 ml-auto">
                <Filter className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <select
                  value={fileTypeFilter}
                  onChange={(e) => setFileTypeFilter(e.target.value as any)}
                  className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 text-[11px] focus:outline-none cursor-pointer"
                >
                  <option value="all">All File Types</option>
                  <option value="image">Photos & Images</option>
                  <option value="file">Documents & Code</option>
                  <option value="screen">Screen Captures</option>
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Results Count & Summary Bar */}
        <div className="px-4 py-2 bg-slate-950/40 border-b border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing <span className="font-bold text-cyan-300">{filteredResults.length}</span> results
            {totalAttachmentsFound > 0 && (
              <span>
                {' '}
                • <span className="text-emerald-300 font-medium">{totalAttachmentsFound}</span> files/images
              </span>
            )}
            {query.trim() && (
              <span>
                {' '}
                matching "<span className="text-amber-300 font-medium">{query.trim()}</span>"
              </span>
            )}
          </div>

          <div className="text-[11px] text-slate-500">
            Click result or "Jump to Message" to view in chat
          </div>
        </div>

        {/* Search Results List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3 divide-y divide-slate-800/40">
          {filteredResults.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-slate-500">
              <div className="w-14 h-14 rounded-2xl bg-slate-800/50 flex items-center justify-center mb-3 text-slate-600">
                <Search className="w-7 h-7" />
              </div>
              <h3 className="text-base font-semibold text-slate-300 mb-1">
                No matching messages found
              </h3>
              <p className="text-xs max-w-sm text-slate-400 mb-4">
                {query.trim()
                  ? `No previous messages matched "${query}". Try searching with different keywords or clearing active date filters.`
                  : 'No messages match the current filter criteria.'}
              </p>
              {hasActiveFilters && (
                <button
                  onClick={handleResetFilters}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition cursor-pointer"
                >
                  Clear All Filters
                </button>
              )}
            </div>
          ) : (
            filteredResults.map(({ message, score }) => {
              const isUser = message.role === 'user';
              const formattedDate = formatMessageDate(message.timestamp);
              const hasAttachments = message.attachments && message.attachments.length > 0;

              return (
                <div
                  key={message.id}
                  className="pt-3 first:pt-0 group hover:bg-slate-800/40 p-3 rounded-xl transition duration-150 border border-transparent hover:border-slate-800"
                >
                  {/* Result Header */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      {isUser ? (
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[11px] font-semibold">
                          <User className="w-3 h-3" /> You
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-semibold">
                          <Sparkles className="w-3 h-3 text-cyan-400" /> Nova AI
                        </span>
                      )}

                      {message.persona && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/50">
                          {message.persona}
                        </span>
                      )}

                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {formattedDate}
                      </span>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopy(message.id, message.content)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
                        title="Copy message content"
                      >
                        {copiedId === message.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={() => {
                          onJumpToMessage(message.id);
                          onClose();
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow transition cursor-pointer hover:scale-[1.02]"
                        title="Jump directly to this message in chat"
                      >
                        <span>Jump to Chat</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Message Content Preview with Highlight */}
                  <div
                    onClick={() => {
                      onJumpToMessage(message.id);
                      onClose();
                    }}
                    className="text-xs sm:text-sm text-slate-200 line-clamp-3 leading-relaxed cursor-pointer hover:text-white mb-2"
                  >
                    <HighlightedText text={message.content} query={query} />
                  </div>

                  {/* Attachment chips if any */}
                  {hasAttachments && (
                    <div className="flex flex-wrap items-center gap-2 mt-2 pt-2 border-t border-slate-800/50">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Paperclip className="w-3 h-3 text-slate-500" /> Attachments:
                      </span>
                      {message.attachments!.map((att) => (
                        <div
                          key={att.id}
                          className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-800/90 border border-slate-700 text-[11px] text-slate-200 hover:border-cyan-500/50 transition"
                        >
                          {att.type === 'image' && (
                            <ImageIcon className="w-3 h-3 text-cyan-400" />
                          )}
                          {att.type === 'file' && (
                            <FileText className="w-3 h-3 text-amber-400" />
                          )}
                          {att.type === 'screen' && (
                            <Monitor className="w-3 h-3 text-emerald-400" />
                          )}
                          <span className="font-medium truncate max-w-[150px]">
                            <HighlightedText text={att.name} query={query} />
                          </span>

                          {att.previewUrl || att.base64 ? (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreviewAttachment(att);
                              }}
                              className="text-cyan-400 hover:text-cyan-300 p-0.5 rounded cursor-pointer ml-1"
                              title="Preview file"
                            >
                              <Eye className="w-3 h-3" />
                            </button>
                          ) : null}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer with Quick Stats & Shortcuts */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-3">
            <span>
              💡 Tip: Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono border border-slate-700">Ctrl + F</kbd> anytime to open Search
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Attachment Preview Modal */}
      {previewAttachment && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-150">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl p-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold text-white text-sm truncate max-w-sm">
                  {previewAttachment.name}
                </span>
              </div>
              <button
                onClick={() => setPreviewAttachment(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-auto flex items-center justify-center bg-slate-950 rounded-xl p-2">
              {previewAttachment.previewUrl || previewAttachment.base64 ? (
                <img
                  src={previewAttachment.previewUrl || previewAttachment.base64}
                  alt={previewAttachment.name}
                  className="max-h-[55vh] max-w-full rounded object-contain"
                />
              ) : previewAttachment.text ? (
                <pre className="text-xs text-slate-300 font-mono whitespace-pre-wrap p-2 w-full">
                  {previewAttachment.text}
                </pre>
              ) : (
                <div className="text-xs text-slate-400">Preview not available</div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
