import React, { useState } from 'react';
import {
  Calculator as CalcIcon,
  Wifi,
  WifiOff,
  History,
  RotateCcw,
  Sparkles,
  Delete,
  Equal,
  Percent,
  Check,
  ChevronRight
} from 'lucide-react';
import { CalculationHistoryItem } from '../types';
import { saveCalculation } from '../utils/storage';

interface SmartCalculatorProps {
  calculationHistory: CalculationHistoryItem[];
  onAddCalculation: (item: CalculationHistoryItem) => void;
  isGlobalOffline: boolean;
}

export const SmartCalculator: React.FC<SmartCalculatorProps> = ({
  calculationHistory,
  onAddCalculation,
  isGlobalOffline,
}) => {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [steps, setSteps] = useState<string[]>([]);
  const [calcMode, setCalcMode] = useState<'offline' | 'online'>(isGlobalOffline ? 'offline' : 'offline');
  const [isSolvingOnline, setIsSolvingOnline] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Offline basic math evaluator (+, -, *, /)
  const evaluateOffline = (expr: string): string => {
    try {
      // Sanitize: allow numbers, decimal, parentheses, and operators + - * /
      const sanitized = expr.replace(/×/g, '*').replace(/÷/g, '/');
      if (!/^[0-9+\-*/().\s%]+$/.test(sanitized)) {
        throw new Error('Offline mode only handles (+ - × ÷ %) arithmetic.');
      }
      // Safe evaluation using Function with no globals
      const evalResult = new Function(`return (${sanitized})`)();
      if (typeof evalResult !== 'number' || isNaN(evalResult) || !isFinite(evalResult)) {
        throw new Error('Invalid calculation');
      }
      return String(Number(evalResult.toFixed(8)));
    } catch (e: any) {
      throw new Error(e.message || 'Syntax Error');
    }
  };

  // Online advanced solver for π, √, %, powers ^, calculus, etc.
  const evaluateOnline = async (expr: string) => {
    setIsSolvingOnline(true);
    setErrorMsg(null);
    try {
      const response = await fetch('/api/calculate-advanced', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expression: expr }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to calculate online');
      }

      setResult(data.result);
      setSteps(data.steps || ['Solved accurately with AI mathematics']);

      const historyItem: CalculationHistoryItem = {
        id: `calc_${Date.now()}`,
        expression: expr,
        result: data.result,
        mode: 'online',
        steps: data.steps,
        timestamp: Date.now(),
      };
      onAddCalculation(historyItem);
      saveCalculation(historyItem);
    } catch (err: any) {
      setErrorMsg(err.message || 'Online calculation failed');
    } finally {
      setIsSolvingOnline(false);
    }
  };

  const handleCalculate = () => {
    if (!expression.trim()) return;
    setErrorMsg(null);

    // If expression contains advanced symbols (π, √, ^, etc.) or mode is set to online
    const hasAdvancedSymbols = /[π√^sincoletan∫log]/i.test(expression);

    if (calcMode === 'offline' && !hasAdvancedSymbols) {
      try {
        const res = evaluateOffline(expression);
        setResult(res);
        setSteps(['Computed instantly offline']);
        const historyItem: CalculationHistoryItem = {
          id: `calc_${Date.now()}`,
          expression,
          result: res,
          mode: 'offline',
          timestamp: Date.now(),
        };
        onAddCalculation(historyItem);
        saveCalculation(historyItem);
      } catch (err: any) {
        setErrorMsg(err.message);
      }
    } else {
      // Evaluate online
      evaluateOnline(expression);
    }
  };

  const appendToExpr = (char: string) => {
    setExpression((prev) => prev + char);
  };

  const clearAll = () => {
    setExpression('');
    setResult(null);
    setSteps([]);
    setErrorMsg(null);
  };

  const backspace = () => {
    setExpression((prev) => prev.slice(0, -1));
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-4 lg:p-6 w-full max-w-5xl mx-auto">
      {/* Calculator Main Pane */}
      <div className="w-full lg:w-7/12 flex flex-col gap-4">
        {/* Header & Mode Switcher */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <CalcIcon className="w-5 h-5 text-indigo-400" />
              Smart Calculator
            </h2>
            <p className="text-xs text-slate-400">
              Basic arithmetic (+, -, ×, ÷) offline • Advanced (π, √, %, ^) online
            </p>
          </div>

          {/* Mode Pill */}
          <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
            <button
              onClick={() => setCalcMode('offline')}
              className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
                calcMode === 'offline' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <WifiOff className="w-3.5 h-3.5" />
              Offline (+ - × ÷)
            </button>
            <button
              onClick={() => setCalcMode('online')}
              className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
                calcMode === 'online' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wifi className="w-3.5 h-3.5 text-cyan-300" />
              Online (π √ % ^)
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-2.5 bg-red-950/60 border border-red-500/40 rounded-xl text-red-200 text-xs">
            {errorMsg}
          </div>
        )}

        {/* Display Screen */}
        <div className="glass-panel rounded-2xl p-4 border border-slate-800 flex flex-col justify-end min-h-[110px] text-right">
          <input
            type="text"
            value={expression}
            onChange={(e) => setExpression(e.target.value)}
            placeholder="0"
            className="w-full bg-transparent text-xl font-mono text-slate-300 text-right focus:outline-none tracking-wider"
          />
          <div className="text-3xl font-extrabold font-mono text-white mt-1 min-h-[36px] flex items-center justify-end gap-2">
            {isSolvingOnline ? (
              <span className="text-xs text-indigo-400 animate-pulse flex items-center gap-1">
                <Sparkles className="w-4 h-4 animate-spin" /> Solving with AI math engine...
              </span>
            ) : result !== null ? (
              <span className="text-emerald-400">= {result}</span>
            ) : null}
          </div>
          {steps.length > 0 && (
            <div className="text-[11px] text-slate-400 font-sans mt-1 text-left border-t border-slate-800/80 pt-1">
              <span className="text-indigo-300 font-semibold">Steps: </span>
              {steps.join(' → ')}
            </div>
          )}
        </div>

        {/* Keypad Grid */}
        <div className="grid grid-cols-4 gap-2">
          {/* Scientific / Advanced Row (Online available) */}
          <button
            onClick={() => appendToExpr('π')}
            className="p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 text-indigo-300 font-bold text-sm"
          >
            π
          </button>
          <button
            onClick={() => appendToExpr('√(')}
            className="p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 text-indigo-300 font-bold text-sm"
          >
            √
          </button>
          <button
            onClick={() => appendToExpr('^')}
            className="p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 text-indigo-300 font-bold text-sm"
          >
            x^y
          </button>
          <button
            onClick={() => appendToExpr('%')}
            className="p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 text-indigo-300 font-bold text-sm"
          >
            %
          </button>

          {/* Standard rows */}
          <button
            onClick={clearAll}
            className="p-3 rounded-xl bg-rose-950/50 hover:bg-rose-900 border border-rose-500/40 text-rose-300 font-bold text-sm"
          >
            C
          </button>
          <button
            onClick={() => appendToExpr('(')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-sm"
          >
            (
          </button>
          <button
            onClick={() => appendToExpr(')')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-sm"
          >
            )
          </button>
          <button
            onClick={() => appendToExpr('÷')}
            className="p-3 rounded-xl bg-purple-900/50 hover:bg-purple-800 border border-purple-500/40 text-purple-300 font-bold text-base"
          >
            ÷
          </button>

          {/* 7 8 9 × */}
          <button
            onClick={() => appendToExpr('7')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            7
          </button>
          <button
            onClick={() => appendToExpr('8')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            8
          </button>
          <button
            onClick={() => appendToExpr('9')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            9
          </button>
          <button
            onClick={() => appendToExpr('×')}
            className="p-3 rounded-xl bg-purple-900/50 hover:bg-purple-800 border border-purple-500/40 text-purple-300 font-bold text-base"
          >
            ×
          </button>

          {/* 4 5 6 - */}
          <button
            onClick={() => appendToExpr('4')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            4
          </button>
          <button
            onClick={() => appendToExpr('5')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            5
          </button>
          <button
            onClick={() => appendToExpr('6')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            6
          </button>
          <button
            onClick={() => appendToExpr('-')}
            className="p-3 rounded-xl bg-purple-900/50 hover:bg-purple-800 border border-purple-500/40 text-purple-300 font-bold text-base"
          >
            -
          </button>

          {/* 1 2 3 + */}
          <button
            onClick={() => appendToExpr('1')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            1
          </button>
          <button
            onClick={() => appendToExpr('2')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            2
          </button>
          <button
            onClick={() => appendToExpr('3')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            3
          </button>
          <button
            onClick={() => appendToExpr('+')}
            className="p-3 rounded-xl bg-purple-900/50 hover:bg-purple-800 border border-purple-500/40 text-purple-300 font-bold text-base"
          >
            +
          </button>

          {/* 0 . ⌫ = */}
          <button
            onClick={() => appendToExpr('0')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            0
          </button>
          <button
            onClick={() => appendToExpr('.')}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white font-bold text-base"
          >
            .
          </button>
          <button
            onClick={backspace}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-sm flex items-center justify-center"
          >
            <Delete className="w-4 h-4" />
          </button>
          <button
            onClick={handleCalculate}
            className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xl flex items-center justify-center shadow-lg shadow-emerald-600/30"
          >
            =
          </button>
        </div>
      </div>

      {/* History Column */}
      <div className="w-full lg:w-5/12 glass-panel rounded-2xl p-4 border border-slate-800 flex flex-col">
        <h3 className="font-bold text-white text-sm flex items-center gap-2 mb-3">
          <History className="w-4 h-4 text-indigo-400" />
          Calculation Ledger
        </h3>

        <div className="flex-1 overflow-y-auto space-y-2 max-h-[380px]">
          {calculationHistory.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-8">No calculations performed yet.</p>
          ) : (
            calculationHistory.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setExpression(item.expression);
                  setResult(item.result);
                }}
                className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
                  <span className="font-mono">{item.expression}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                    item.mode === 'offline' ? 'bg-emerald-950 text-emerald-400' : 'bg-indigo-950 text-indigo-400'
                  }`}>
                    {item.mode}
                  </span>
                </div>
                <div className="text-sm font-bold text-emerald-300 font-mono text-right">= {item.result}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
