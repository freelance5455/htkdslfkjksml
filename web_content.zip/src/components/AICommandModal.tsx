import React, { useState } from 'react';
import { Wand2, X, Check, Loader2, Sparkles, AlertCircle, ArrowRight, CornerDownLeft } from 'lucide-react';
import { AIExecutionPlan, VideoProject } from '../types/project';

interface AICommandModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: VideoProject;
  onApplyPlan: (plan: AIExecutionPlan) => void;
  lang: 'ar' | 'en';
}

export const AICommandModal: React.FC<AICommandModalProps> = ({
  isOpen,
  onClose,
  project,
  onApplyPlan,
  lang
}) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<AIExecutionPlan | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    'قسّم هذا الفيديو إلى أجزاء مدة كل جزء 50 ثانية',
    'قسّم الفيديو إلى مقاطع مدة كل منها 40 ثانية',
    'اجعل كل مقطع مدته 30 ثانية',
    'قسّم الفيديو إلى 5 أجزاء متساوية تقريبًا',
    'حوّل الفيديو إلى عمودي 9:16 مع خلفية ضبابية وأضف اسم قناتي في الزاوية',
    'طبّق قالباً سينمائياً وأضف عنوان "ترند الأسبوع"',
    'اجعل الفيديو سريعًا 1.25x مع ألوان حيوية للمنصات'
  ];

  const handleGenerate = async (textToUse?: string) => {
    const finalPrompt = textToUse || prompt;
    if (!finalPrompt.trim()) {
      setError(lang === 'ar' ? 'يرجى كتابة طلبك أولاً' : 'Please enter your request first');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedPlan(null);

    try {
      const res = await fetch('/api/ai/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: finalPrompt,
          videoDuration: project.duration || 60,
          currentSettings: {
            aspectRatio: project.aspectRatio,
            filter: project.filter,
            duration: project.duration
          }
        })
      });

      const data = await res.json();
      if (data.success && data.plan) {
        setGeneratedPlan(data.plan);
      } else {
        setError(data.error || 'تعذر معالجة الطلب، يرجى المحاولة بصيغة أخرى');
      }
    } catch (err: any) {
      setError(err?.message || 'فشل الاتصال بالخدمة الذكية');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirm = () => {
    if (generatedPlan) {
      onApplyPlan(generatedPlan);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-[#111224] border border-purple-800/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-purple-900/30 flex items-center justify-between bg-gradient-to-r from-purple-950/40 to-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/30">
              <Wand2 className="w-5 h-5 text-purple-300 animate-spin-slow" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                {lang === 'ar' ? 'المساعد الذكي لمونتاج الفيديو' : 'AI Video Montage Assistant'}
              </h3>
              <p className="text-xs text-purple-300/80">
                {lang === 'ar' ? 'اكتب أمرك باللغة الطبيعية وسيحوله الذكاء الاصطناعي لعمليات تحرير فعلية' : 'Type in natural language to execute real edits'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Main Prompt Box */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-purple-200">
              {lang === 'ar' ? 'ماذا تريد أن أفعل بالفيديو؟' : 'What do you want to do with the video?'}
            </label>
            <div className="relative">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={3}
                placeholder={
                  lang === 'ar'
                    ? 'مثال: قسّم الفيديو كل 40 ثانية، واجعله عمودياً 9:16 مع خلفية ضبابية وأضف اسم قناتي في الزاوية...'
                    : 'Example: Split the video every 40s, make it 9:16 vertical with blurred backdrop, and add my channel name...'
                }
                className="w-full px-4 py-3 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 resize-none"
              />
              <button
                onClick={() => handleGenerate()}
                disabled={isLoading || !prompt.trim()}
                className="absolute left-3 bottom-3 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 transition cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === 'ar' ? 'جاري التحليل...' : 'Analyzing...'}</span>
                  </>
                ) : (
                  <>
                    <CornerDownLeft className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'تحليل وتنفيذ' : 'Generate'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="space-y-1.5">
            <span className="text-xs text-slate-400 font-medium">
              {lang === 'ar' ? 'أوامر سريعة مقترحة:' : 'Quick prompt suggestions:'}
            </span>
            <div className="flex flex-wrap gap-1.5">
              {quickPrompts.map((qp, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(qp);
                    handleGenerate(qp);
                  }}
                  className="text-xs px-2.5 py-1 rounded-lg bg-purple-950/40 hover:bg-purple-900/60 border border-purple-800/30 text-purple-200 transition cursor-pointer text-start"
                >
                  {qp}
                </button>
              ))}
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 rounded-xl bg-red-950/50 border border-red-800/50 flex items-center gap-2 text-xs text-red-200">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Generated Plan Review */}
          {generatedPlan && (
            <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-700/50 space-y-3 animate-fadeIn">
              <div className="flex items-center gap-2 text-xs font-bold text-purple-300">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                <span>
                  {lang === 'ar' ? 'خطة التحرير المقترحة (يرجى المراجعة):' : 'Proposed Editing Plan (Review):'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-[#0b0c17] border border-purple-900/50 text-sm text-slate-200 space-y-2">
                <p className="font-semibold text-purple-200">
                  {lang === 'ar' ? generatedPlan.summaryArabic : generatedPlan.summaryEnglish}
                </p>

                {/* Details Breakdown */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-purple-900/30 text-xs">
                  {generatedPlan.actions.split.enabled && (
                    <div className="p-2 rounded bg-purple-900/20">
                      <span className="text-slate-400 block">{lang === 'ar' ? 'التقسيم:' : 'Splitting:'}</span>
                      <span className="font-medium text-white">
                        {generatedPlan.actions.split.mode === 'duration'
                          ? `كل ${generatedPlan.actions.split.value} ثانية`
                          : `${generatedPlan.actions.split.value} أجزاء`}
                      </span>
                    </div>
                  )}

                  <div className="p-2 rounded bg-purple-900/20">
                    <span className="text-slate-400 block">{lang === 'ar' ? 'الأبعاد:' : 'Aspect Ratio:'}</span>
                    <span className="font-medium text-white">
                      {generatedPlan.actions.aspectRatio}
                      {generatedPlan.actions.blurBackground ? ' (خلفية ضبابية)' : ''}
                    </span>
                  </div>

                  {generatedPlan.actions.filter !== 'normal' && (
                    <div className="p-2 rounded bg-purple-900/20">
                      <span className="text-slate-400 block">{lang === 'ar' ? 'المؤثر:' : 'Filter:'}</span>
                      <span className="font-medium text-white">{generatedPlan.actions.filter}</span>
                    </div>
                  )}

                  {generatedPlan.actions.title && (
                    <div className="p-2 rounded bg-purple-900/20 col-span-2">
                      <span className="text-slate-400 block">{lang === 'ar' ? 'العنوان:' : 'Title:'}</span>
                      <span className="font-medium text-white">{generatedPlan.actions.title}</span>
                    </div>
                  )}

                  {generatedPlan.actions.watermarkText && (
                    <div className="p-2 rounded bg-purple-900/20 col-span-2">
                      <span className="text-slate-400 block">{lang === 'ar' ? 'العلامة المائية:' : 'Watermark:'}</span>
                      <span className="font-medium text-white">{generatedPlan.actions.watermarkText}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  onClick={() => setGeneratedPlan(null)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  {lang === 'ar' ? 'تعديل الأمر' : 'Modify'}
                </button>
                <button
                  onClick={handleConfirm}
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-950 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تطبيق الخطة على الفيديو' : 'Apply Plan to Video'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
