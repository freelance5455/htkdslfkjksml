import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, Category, PaymentMethod, TransactionType, AppSettings, Account, UserProfile } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { AccountSelectDropdown } from './AccountSelectDropdown';
import {
  X,
  Save,
  AlertTriangle,
  Calendar,
  Wallet,
  FileText,
  Lock,
  ArrowRightLeft,
  Trash2,
  Shield,
  Handshake,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';

interface EditTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  categories: Category[];
  accounts?: Account[];
  onSave: (tx: Transaction) => void;
  onAddAccount?: (account: Omit<Account, 'id'>) => Account;
  onDeleteRequest?: (tx: Transaction) => void;
  userProfile: UserProfile;
  appSettings: AppSettings;
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  onClose,
  transaction,
  categories = [],
  accounts = [],
  onSave,
  onAddAccount,
  onDeleteRequest,
  userProfile,
  appSettings,
}) => {
  const safeAccounts = Array.isArray(accounts) ? accounts : [];
  const safeCategories = Array.isArray(categories) ? categories : [];

  const [type, setType] = useState<TransactionType>(transaction?.type || 'expense');
  const [amount, setAmount] = useState<string>(transaction?.amount?.toString() || '');
  const [categoryId, setCategoryId] = useState<string>(transaction?.categoryId || '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(transaction?.paymentMethod || 'cash');
  const [accountId, setAccountId] = useState<string>(transaction?.accountId || safeAccounts[0]?.id || 'acc_cash');
  const [fromAccountId, setFromAccountId] = useState<string>(
    transaction?.fromAccountId || safeAccounts[0]?.id || 'acc_bank'
  );
  const [toAccountId, setToAccountId] = useState<string>(
    transaction?.toAccountId || safeAccounts[1]?.id || safeAccounts[0]?.id || 'acc_bkash'
  );
  const [date, setDate] = useState<string>(transaction?.date || new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState<string>(transaction?.note || '');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Recipient / Giver (গ্রহিতা/দাতা) Ledger state
  const [ledgerMode, setLedgerMode] = useState<'select' | 'new'>('select');
  const [selectedLedgerAccountId, setSelectedLedgerAccountId] = useState<string>(transaction?.ledgerAccountId || '');
  const [customLedgerName, setCustomLedgerName] = useState<string>(transaction?.ledgerPerson || '');
  const [customLedgerPhone, setCustomLedgerPhone] = useState<string>('');
  const [hasLedgerValidationError, setHasLedgerValidationError] = useState<boolean>(false);

  // Group accounts
  const walletAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) =>
        a.type !== 'receivable' &&
        a.type !== 'payable' &&
        a.id !== 'acc_receivable' &&
        a.id !== 'acc_payable'
    );
  }, [safeAccounts]);

  const receivableAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) => a.type === 'receivable' || a.id === 'acc_receivable'
    );
  }, [safeAccounts]);

  const payableAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) => a.type === 'payable' || a.id === 'acc_payable'
    );
  }, [safeAccounts]);

  // Synchronize state when transaction prop changes
  useEffect(() => {
    if (transaction) {
      setType(transaction.type || 'expense');
      setAmount(transaction.amount !== undefined ? transaction.amount.toString() : '');
      setCategoryId(transaction.categoryId || '');
      setPaymentMethod(transaction.paymentMethod || 'cash');
      setAccountId(transaction.accountId || accounts[0]?.id || 'acc_cash');
      setFromAccountId(transaction.fromAccountId || accounts[0]?.id || 'acc_bank');
      setToAccountId(transaction.toAccountId || accounts[1]?.id || 'acc_bkash');
      setDate(transaction.date || new Date().toISOString().split('T')[0]);
      setNote(transaction.note || '');
      setSelectedLedgerAccountId(transaction.ledgerAccountId || '');
      setCustomLedgerName(transaction.ledgerPerson || '');
      setLedgerMode(transaction.ledgerAccountId ? 'select' : transaction.ledgerPerson ? 'new' : 'select');
      setPassword('');
      setError('');
      setHasLedgerValidationError(false);
    }
  }, [transaction, accounts]);

  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  // Check if primary account or transfer counterpart is a loan/debt account (Receivables or Payables)
  const isIncomeExpenseLoan = useMemo(() => {
    const acc = safeAccounts.find((a) => a.id === accountId);
    return (
      acc?.type === 'receivable' ||
      acc?.type === 'payable' ||
      accountId === 'acc_receivable' ||
      accountId === 'acc_payable'
    );
  }, [accountId, safeAccounts]);

  const fromAcc = safeAccounts.find((a) => a.id === fromAccountId);
  const toAcc = safeAccounts.find((a) => a.id === toAccountId);

  const isTransferFromLoan =
    fromAcc?.type === 'receivable' ||
    fromAcc?.type === 'payable' ||
    fromAccountId === 'acc_receivable' ||
    fromAccountId === 'acc_payable';

  const isTransferToLoan =
    toAcc?.type === 'receivable' ||
    toAcc?.type === 'payable' ||
    toAccountId === 'acc_receivable' ||
    toAccountId === 'acc_payable';

  const isTransferLoan = isTransferFromLoan || isTransferToLoan;
  const isLedgerRequired = type === 'transfer' ? isTransferLoan : isIncomeExpenseLoan;

  const isReceivableContext = useMemo(() => {
    if (type === 'transfer') {
      return (
        toAcc?.type === 'receivable' ||
        toAccountId === 'acc_receivable' ||
        fromAcc?.type === 'receivable' ||
        fromAccountId === 'acc_receivable'
      );
    }
    const acc = safeAccounts.find((a) => a.id === accountId);
    return acc?.type === 'receivable' || accountId === 'acc_receivable';
  }, [type, accountId, fromAccountId, toAccountId, fromAcc, toAcc, safeAccounts]);

  const existingLedgers = useMemo(() => {
    return safeAccounts.filter(
      (a) =>
        (a.type === 'receivable' || a.type === 'payable') &&
        a.id !== 'acc_receivable' &&
        a.id !== 'acc_payable'
    );
  }, [safeAccounts]);

  useEffect(() => {
    if (existingLedgers.length === 0 && !selectedLedgerAccountId) {
      setLedgerMode('new');
    }
  }, [existingLedgers.length, selectedLedgerAccountId]);

  if (!isOpen || !transaction) return null;

  const filteredCategories = safeCategories.filter((c) => c.type === (type === 'transfer' ? 'expense' : type));
  const activeMasterPassword = userProfile.profilePassword?.trim() || '';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasLedgerValidationError(false);
    const parsedAmount = parseFloat(amount) || 0;

    if (!parsedAmount || parsedAmount <= 0) {
      setError(isEn ? 'Please enter a valid amount' : 'অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন');
      return;
    }

    if (type !== 'transfer' && !categoryId) {
      setError(isEn ? 'Please select a category' : 'একটি খাত বা ক্যাটাগরি নির্বাচন করুন');
      return;
    }

    if (type === 'transfer' && fromAccountId === toAccountId) {
      setError(
        isEn
          ? 'Sender and receiver accounts cannot be the same'
          : 'প্রেরক ও প্রাপক অ্যাকাউন্ট একই হতে পারে না'
      );
      return;
    }

    // Security check: if PIN is set in profile, verify it
    if (activeMasterPassword) {
      if (!password) {
        setError(isEn ? 'Please enter your Security PIN' : 'অনুগ্রহ করে আপনার নিরাপত্তা পিন লিখুন');
        return;
      }
      if (password.trim() !== activeMasterPassword) {
        setError(isEn ? 'Incorrect Security PIN' : 'ভুল নিরাপত্তা পিন প্রদান করা হয়েছে');
        return;
      }
    }

    // Enforce mandatory ledger for Receivables / Payables
    let finalPersonName = '';
    let finalLedgerAccountId = '';

    if (isLedgerRequired) {
      if (ledgerMode === 'select' && selectedLedgerAccountId && selectedLedgerAccountId !== '__new__') {
        const found = safeAccounts.find((a) => a.id === selectedLedgerAccountId);
        if (found) {
          finalPersonName = isEn ? found.nameEnglish : found.nameBangla;
          finalLedgerAccountId = found.id;
        }
      } else {
        finalPersonName = customLedgerName.trim();
      }

      // Check if user selected a specific individual person directly from the account dropdown
      if (!finalPersonName) {
        const targetId = type === 'transfer' ? (isTransferToLoan ? toAccountId : fromAccountId) : accountId;
        const directAcc = safeAccounts.find((a) => a.id === targetId);
        if (directAcc && directAcc.id !== 'acc_receivable' && directAcc.id !== 'acc_payable') {
          finalPersonName = isEn ? directAcc.nameEnglish : directAcc.nameBangla;
          finalLedgerAccountId = directAcc.id;
        }
      }

      if (!finalPersonName) {
        setHasLedgerValidationError(true);
        setError(
          isEn
            ? 'Recipient / Giver (গ্রহিতা/দাতা) ledger is strictly mandatory for Receivables and Payables'
            : 'Receivables বা Payables এর ক্ষেত্রে গ্রহিতা/দাতা লেজার সংযুক্ত করা বাধ্যতামূলক'
        );
        return;
      }

      // If a new name was entered, find or create ledger account
      if (!finalLedgerAccountId) {
        const matchByName = safeAccounts.find(
          (a) =>
            (a.type === 'receivable' || a.type === 'payable') &&
            (a.nameBangla.trim().toLowerCase() === finalPersonName.toLowerCase() ||
              a.nameEnglish.trim().toLowerCase() === finalPersonName.toLowerCase())
        );

        if (matchByName) {
          finalLedgerAccountId = matchByName.id;
        } else if (onAddAccount) {
          const determinedType = isReceivableContext ? 'receivable' : 'payable';
          const newAccount = onAddAccount({
            nameBangla: finalPersonName,
            nameEnglish: finalPersonName,
            phoneNumber: customLedgerPhone.trim(),
            type: determinedType,
            openingBalance: 0,
            notes: 'ট্রানজেকশন এডিট থেকে তৈরি গ্রহিতা/দাতা লেজার',
            color: determinedType === 'receivable' ? '#06B6D4' : '#EF4444',
            icon: determinedType === 'receivable' ? 'ArrowDownLeft' : 'ArrowUpRight',
            createdAt: Date.now(),
          });
          finalLedgerAccountId = newAccount.id;
        }
      }
    }

    let resolvedAccountId = accountId;
    let resolvedFromAccountId = fromAccountId;
    let resolvedToAccountId = toAccountId;

    if (isLedgerRequired && finalLedgerAccountId) {
      if (type !== 'transfer') {
        if (accountId === 'acc_receivable' || accountId === 'acc_payable') {
          resolvedAccountId = finalLedgerAccountId;
        }
      } else {
        if (fromAccountId === 'acc_receivable' || fromAccountId === 'acc_payable') {
          resolvedFromAccountId = finalLedgerAccountId;
        }
        if (toAccountId === 'acc_receivable' || toAccountId === 'acc_payable') {
          resolvedToAccountId = finalLedgerAccountId;
        }
      }
    }

    let formattedNote = note.trim();
    if (finalPersonName) {
      const personTag = `[গ্রহিতা/দাতা: ${finalPersonName}]`;
      if (!formattedNote.includes(finalPersonName)) {
        formattedNote = formattedNote ? `${formattedNote} ${personTag}` : personTag;
      }
    }

    const updated: Transaction = {
      ...transaction,
      type,
      amount: parsedAmount,
      categoryId: type === 'transfer' ? 'transfer' : categoryId,
      paymentMethod,
      accountId: type === 'transfer' ? undefined : resolvedAccountId,
      fromAccountId: type === 'transfer' ? resolvedFromAccountId : undefined,
      toAccountId: type === 'transfer' ? resolvedToAccountId : undefined,
      ledgerPerson: finalPersonName || undefined,
      ledgerAccountId: finalLedgerAccountId || undefined,
      date,
      note: formattedNote,
    };

    onSave(updated);
    onClose();
  };

  return (
    <div
      id="edit_transaction_modal_overlay"
      className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/70 backdrop-blur-xs'
      } p-0 sm:p-4 animate-in fade-in duration-200`}
    >
      <div
        id="edit_transaction_modal_container"
        className={`w-full max-w-lg ${
          isLight
            ? 'bg-white border-sky-200 text-sky-950'
            : 'bg-slate-800 border-slate-700 text-slate-100'
        } border rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]`}
      >
        {/* Header */}
        <div
          id="edit_transaction_modal_header"
          className={`flex items-center justify-between px-6 py-4 border-b ${
            isLight
              ? 'border-sky-200 bg-sky-50/90 text-sky-950'
              : 'border-slate-700 bg-slate-800/80 text-slate-100'
          }`}
        >
          <div className="flex items-center gap-2">
            <div
              className="p-1.5 rounded-lg text-white"
              style={{ backgroundColor: dualAccent.primary.hex }}
            >
              <Save className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold">
                {isEn ? 'Modify Transaction' : 'পুরাতন হিসাব পরিমার্জন (Edit)'}
              </h2>
              <span className="text-[11px] text-amber-500 font-semibold flex items-center gap-1">
                <Shield className="w-3 h-3" />
                {isEn ? 'Password Protected' : 'পাসওয়ার্ড সুরক্ষিত'}
              </span>
            </div>
          </div>
          <button
            id="close_edit_transaction_modal_btn"
            onClick={onClose}
            className={`p-2 rounded-full ${
              isLight
                ? 'text-sky-700 hover:text-sky-950 hover:bg-sky-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-700'
            } transition`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Transaction Type Selector */}
          <div
            id="edit_transaction_type_tabs"
            className={`grid grid-cols-3 gap-1.5 p-1.5 ${
              isLight ? 'bg-sky-100/80 border-sky-200' : 'bg-slate-900 border-slate-700'
            } rounded-2xl border`}
          >
            <button
              type="button"
              id="edit_type_expense"
              onClick={() => {
                setType('expense');
                setCategoryId('');
              }}
              className={`py-2 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                type === 'expense'
                  ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30 font-bold'
                  : isLight
                  ? 'text-sky-800 hover:text-sky-950'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <span>{isEn ? '💸 Expense' : '💸 খরচ'}</span>
            </button>

            <button
              type="button"
              id="edit_type_income"
              onClick={() => {
                setType('income');
                setCategoryId('');
              }}
              className={`py-2 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                type === 'income'
                  ? 'text-white shadow-lg font-bold'
                  : isLight
                  ? 'text-sky-800 hover:text-sky-950'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
              style={type === 'income' ? dualAccent.primaryButtonStyle : undefined}
            >
              <span>{isEn ? '💰 Income' : '💰 আয়'}</span>
            </button>

            <button
              type="button"
              id="edit_type_transfer"
              onClick={() => {
                setType('transfer');
                setCategoryId('');
              }}
              className={`py-2 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                type === 'transfer'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 font-bold'
                  : isLight
                  ? 'text-sky-800 hover:text-sky-950'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>{isEn ? 'Transfer' : 'ট্রান্সফার'}</span>
            </button>
          </div>

          {/* Amount Input */}
          <div>
            <label
              className={`block text-xs font-semibold uppercase tracking-wider ${
                isLight ? 'text-sky-800' : 'text-gray-400'
              } mb-1.5`}
            >
              {isEn ? 'Amount (৳) *' : 'টাকার পরিমাণ (৳) *'}
            </label>
            <div className="relative">
              <span
                className="absolute left-4 top-1/2 -translate-y-1/2 text-xl font-bold"
                style={{ color: dualAccent.primary.hex }}
              >
                ৳
              </span>
              <input
                id="edit_amount_input"
                type="number"
                step="any"
                placeholder="0.00"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                className={`w-full pl-10 pr-4 py-3 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950 placeholder-sky-700/50'
                    : 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                } border rounded-xl text-xl font-bold focus:outline-none transition`}
                style={{ borderColor: `${dualAccent.primary.hex}40` }}
                autoFocus
              />
            </div>
          </div>

          {/* Account Selection: Transfer vs Standard with Grouped Options */}
          {type === 'transfer' ? (
            <div className="p-4 rounded-2xl border space-y-3 bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-800/40">
              <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
                <ArrowRightLeft className="w-4 h-4" />
                <span>{isEn ? 'Account-to-Account Transfer' : 'এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে ট্রান্সফার'}</span>
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    {isEn ? 'From Account (প্রেরক) *' : 'কোন অ্যাকাউন্ট থেকে যাবে (প্রেরক) *'}
                  </label>
                  <AccountSelectDropdown
                    id="edit_transfer_from_select"
                    accounts={safeAccounts}
                    selectedAccountId={fromAccountId}
                    onSelectAccount={(newId) => setFromAccountId(newId)}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={isEn ? 'Select From Account' : 'প্রেরক অ্যাকাউন্ট বেছে নিন'}
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    {isEn ? 'To Account (প্রাপক) *' : 'কোন অ্যাকাউন্টে জমা হবে (প্রাপক) *'}
                  </label>
                  <AccountSelectDropdown
                    id="edit_transfer_to_select"
                    accounts={safeAccounts}
                    selectedAccountId={toAccountId}
                    onSelectAccount={(newId) => setToAccountId(newId)}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={isEn ? 'Select To Account' : 'প্রাপক অ্যাকাউন্ট বেছে নিন'}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>
                  {type === 'expense'
                    ? isEn
                      ? 'Expense From Account *'
                      : 'কোন অ্যাকাউন্ট থেকে খরচ হচ্ছে? *'
                    : isEn
                    ? 'Deposit To Account *'
                    : 'টাকা কোন অ্যাকাউন্টে জমা হচ্ছে? *'}
                </span>
              </label>
              <AccountSelectDropdown
                id="edit_primary_account_select"
                accounts={safeAccounts}
                selectedAccountId={accountId}
                onSelectAccount={(newId) => setAccountId(newId)}
                isLight={isLight}
                isEn={isEn}
                placeholder={
                  type === 'expense'
                    ? isEn ? 'Expense From Account *' : 'খরচের অ্যাকাউন্ট নির্বাচন করুন *'
                    : isEn ? 'Deposit To Account *' : 'জমার অ্যাকাউন্ট নির্বাচন করুন *'
                }
              />
            </div>
          )}

          {/* Mandatory Recipient/Giver (গ্রহিতা/দাতা) Ledger Component for Receivables/Payables */}
          {isLedgerRequired && (
            <div
              id="edit_mandatory_ledger_container"
              className={`p-4 rounded-2xl border transition-all ${
                hasLedgerValidationError
                  ? 'ring-2 ring-rose-500 border-rose-500 bg-rose-50/60 dark:bg-rose-950/40 animate-pulse'
                  : isLight
                  ? 'bg-amber-50/80 border-amber-200/90 text-amber-950 shadow-xs'
                  : 'bg-amber-950/20 border-amber-900/60 text-amber-100'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-amber-900 dark:text-amber-300">
                  <Handshake className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>{isEn ? 'Recipient / Giver (গ্রহিতা/দাতা) Ledger *' : 'গ্রহিতা/দাতা লেজার *'}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500 text-white shadow-xs">
                  {isEn ? 'Mandatory' : 'বাধ্যতামূলক'}
                </span>
              </div>

              {/* Toggle: Select Existing or Add New */}
              {existingLedgers.length > 0 && (
                <div className="flex rounded-xl p-1 bg-amber-100/70 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900/40 mb-3 text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => {
                      setLedgerMode('select');
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                      ledgerMode === 'select'
                        ? 'bg-white dark:bg-slate-800 text-amber-950 dark:text-amber-100 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {isEn ? 'Choose Existing' : 'বিদ্যমান লেজার থেকে নির্বাচন'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLedgerMode('new');
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                      ledgerMode === 'new'
                        ? 'bg-white dark:bg-slate-800 text-amber-950 dark:text-amber-100 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {isEn ? '+ Add New Person' : '+ নতুন গ্রহিতা/দাতা'}
                  </button>
                </div>
              )}

              {ledgerMode === 'select' && existingLedgers.length > 0 ? (
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    {isEn ? 'Select Recipient / Giver *' : 'গ্রহিতা/দাতা নির্বাচন করুন *'}
                  </label>
                  <AccountSelectDropdown
                    id="edit_ledger_account_select"
                    accounts={existingLedgers}
                    selectedAccountId={selectedLedgerAccountId}
                    onSelectAccount={(newId) => {
                      setSelectedLedgerAccountId(newId);
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={isEn ? '-- Select Recipient / Giver --' : '-- গ্রহিতা/দাতা বেছে নিন --'}
                    className={
                      hasLedgerValidationError
                        ? 'border-rose-500 ring-1 ring-rose-500'
                        : isLight
                        ? 'border-amber-300'
                        : 'border-amber-800'
                    }
                  />
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      {isEn ? 'Recipient / Giver Name * (Mandatory)' : 'গ্রহিতা/দাতার নাম * (বাধ্যতামূলক)'}
                    </label>
                    <input
                      id="edit_custom_ledger_name_input"
                      type="text"
                      placeholder={isEn ? 'e.g. Rahim, Karim, or Supplier' : 'যেমন: রহিম, করিম, বা প্রতিষ্ঠানের নাম'}
                      value={customLedgerName}
                      onChange={(e) => {
                        setCustomLedgerName(e.target.value);
                        setError('');
                        setHasLedgerValidationError(false);
                      }}
                      className={`w-full px-3 py-2.5 rounded-xl border text-xs sm:text-sm font-bold ${
                        hasLedgerValidationError
                          ? 'border-rose-500 ring-1 ring-rose-500'
                          : 'border-amber-300 dark:border-amber-800/80'
                      } ${
                        isLight
                          ? 'bg-white text-slate-900 placeholder-slate-400'
                          : 'bg-slate-900 text-slate-100 placeholder-slate-500'
                      } outline-hidden focus:ring-2 focus:ring-amber-500`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      {isEn ? 'Phone Number (Optional)' : 'মোবাইল নম্বর (ঐচ্ছিক)'}
                    </label>
                    <input
                      id="edit_custom_ledger_phone_input"
                      type="tel"
                      placeholder="01XXXXXXXXX"
                      value={customLedgerPhone}
                      onChange={(e) => setCustomLedgerPhone(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight
                          ? 'bg-white border-amber-200 text-slate-900'
                          : 'bg-slate-900 border-slate-700 text-slate-100'
                      } outline-hidden focus:ring-2 focus:ring-amber-500`}
                    />
                  </div>
                </div>
              )}

              {hasLedgerValidationError && (
                <p className="text-xs font-bold text-rose-600 dark:text-rose-400 mt-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {isEn
                      ? 'Recipient / Giver (গ্রহিতা/দাতা) ledger is required for Receivables/Payables'
                      : 'Receivables বা Payables এর ক্ষেত্রে গ্রহিতা/দাতা লেজার সংযুক্ত করা বাধ্যতামূলক'}
                  </span>
                </p>
              )}
            </div>
          )}

          {/* Category Selector */}
          {type !== 'transfer' && (
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-2`}
              >
                {isEn ? 'Category *' : 'খাত বা ক্যাটাগরি *'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto p-1 pr-1">
                {filteredCategories.map((cat) => {
                  const isSelected = categoryId === cat.id;
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => {
                        setCategoryId(cat.id);
                        setError('');
                      }}
                      className={`flex items-center gap-2 p-2 rounded-xl border text-left text-xs transition cursor-pointer ${
                        isSelected
                          ? 'font-bold'
                          : isLight
                          ? 'border-sky-200 bg-sky-50/80 text-sky-950 hover:bg-sky-100'
                          : 'border-gray-800 bg-gray-950/60 text-gray-300 hover:bg-gray-800/50'
                      }`}
                      style={
                        isSelected
                          ? {
                              borderColor: dualAccent.primary.hex,
                              backgroundColor: `${dualAccent.primary.hex}22`,
                              boxShadow: `0 0 0 1.5px ${dualAccent.primary.hex}`,
                            }
                          : undefined
                      }
                    >
                      <div
                        className="p-1 rounded-lg shrink-0"
                        style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                      >
                        <CategoryIcon name={cat.icon} className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-medium truncate">
                        {isEn ? cat.nameEnglish : cat.nameBangla}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Date & Note */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <Calendar className="w-3.5 h-3.5" /> <span>{isEn ? 'Date' : 'তারিখ'}</span>
              </label>
              <input
                id="edit_date_input"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full px-3 py-2.5 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950'
                    : 'bg-slate-900 border-slate-700 text-gray-200'
                } border rounded-xl text-sm focus:outline-none`}
              />
            </div>

            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <FileText className="w-3.5 h-3.5" /> <span>{isEn ? 'Note' : 'নোট / বিবরণ'}</span>
              </label>
              <input
                id="edit_note_input"
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className={`w-full px-3 py-2.5 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950'
                    : 'bg-slate-900 border-slate-700 text-gray-200'
                } border rounded-xl text-sm focus:outline-none`}
              />
            </div>
          </div>

          {/* REQUIRED SECURITY PASSWORD INPUT (Only if user has set a PIN) */}
          {activeMasterPassword ? (
            <div
              className={`p-4 rounded-2xl border ${
                isLight
                  ? 'bg-amber-50/60 border-amber-200/80'
                  : 'bg-amber-950/20 border-amber-700/50'
              } space-y-2`}
            >
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                  <Lock className="w-4 h-4" />
                  <span>{isEn ? 'Security PIN (Required) *' : 'নিরাপত্তা পিন (আবশ্যক) *'}</span>
                </label>
              </div>
              <input
                id="edit_security_pin_input"
                type="password"
                required
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder={isEn ? 'Enter PIN to save changes' : 'এন্টার পিন'}
                className={`w-full px-3 py-2 rounded-xl border text-sm font-mono tracking-widest ${
                  isLight
                    ? 'bg-white border-amber-300 text-slate-900'
                    : 'bg-slate-900 border-amber-800 text-slate-100'
                } outline-hidden focus:ring-2`}
              />
              <p className="text-[10px] text-amber-700/80 dark:text-amber-400/80">
                {isEn
                  ? 'This change will be audited and recorded in the Profile History section.'
                  : 'এই পরিবর্তনের বিবরণ ও তারিখ প্রোফাইলের হিস্ট্রি লগ সেকশনে সংরক্ষিত থাকবে।'}
              </p>
            </div>
          ) : (
            <div
              className={`p-3 rounded-xl border text-xs ${
                isLight
                  ? 'bg-slate-50 border-slate-200 text-slate-600'
                  : 'bg-slate-850 border-slate-800 text-slate-400'
              }`}
            >
              <p>
                {isEn
                  ? 'Note: This modification will be logged in your Profile Audit History.'
                  : 'নোট: এই পরিবর্তনটি আপনার প্রোফাইল অডিট হিস্ট্রিতে সংরক্ষিত থাকবে।'}
              </p>
            </div>
          )}

          {error && <p className="text-xs font-semibold text-rose-500">{error}</p>}

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-between gap-3">
            {onDeleteRequest && (
              <button
                type="button"
                id="delete_transaction_btn"
                onClick={() => onDeleteRequest(transaction)}
                className="py-3 px-3 rounded-xl border border-rose-500/30 text-rose-500 hover:bg-rose-500/10 font-bold text-xs transition flex items-center gap-1.5 shrink-0"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isEn ? 'Delete' : 'ডিলিট'}</span>
              </button>
            )}

            <div className="flex items-center gap-2 flex-1 justify-end">
              <button
                type="button"
                id="cancel_edit_transaction_btn"
                onClick={onClose}
                className={`py-3 px-4 rounded-xl border ${
                  isLight
                    ? 'border-sky-200 text-sky-800 hover:bg-sky-100'
                    : 'border-gray-800 text-gray-400 hover:text-white'
                } font-medium text-xs transition cursor-pointer`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="submit"
                id="save_edit_transaction_btn"
                className="py-3 px-5 rounded-xl font-bold text-xs text-white shadow-lg transition flex items-center justify-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <Save className="w-4 h-4" />
                <span>{isEn ? 'Save Changes' : 'পরিবর্তন সংরক্ষণ'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
