import React, { useState } from 'react';
import { Wrench } from 'lucide-react';
import { BiText, LangMode } from '../data/types';

export function pickText(text: BiText, lang: LangMode): string {
  if (lang === 'hi') return text.hi;
  return text.en;
}

export const BiTextBlock: React.FC<{
  text: BiText;
  lang: LangMode;
  className?: string;
  hiClassName?: string;
}> = ({ text, lang, className = 'text-slate-700', hiClassName = 'text-slate-600' }) => {
  if (lang === 'en') {
    return <p className={className}>{text.en}</p>;
  }
  if (lang === 'hi') {
    return <p className={className}>{text.hi}</p>;
  }
  return (
    <div className="space-y-1.5">
      <p className={className}>{text.en}</p>
      <p className={`text-[14px] leading-relaxed ${hiClassName}`}>{text.hi}</p>
    </div>
  );
};

export const SafeImage: React.FC<{
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}> = ({ src, alt, className = 'w-full h-48 object-cover', fallbackLabel }) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-slate-100 border border-slate-200 text-blue-700 p-4 text-center ${className}`}
      >
        <Wrench className="w-8 h-8 mb-2 opacity-75" />
        <span className="text-xs font-medium text-slate-700">{fallbackLabel || alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
