import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  Copy,
  Edit3,
  Link2,
  Mail,
  Plus,
  ShieldAlert,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  ConfirmDialogState,
  EMPLOYEE_DIVISIONS,
  EmployeeDivision,
  EmployeeInvite,
  EmployeeRecord,
  EmployeeShift,
  FIELD_LIMITS,
  HOST_LIVE_SHIFTS,
  UserProfile,
} from '../types/ops';
import {
  createEmployeeInvite,
  createEmployeeRecord,
  deleteEmployeeRecord,
  deleteInvite,
  revokeInvite,
  updateEmployeeRecord,
  updateUserAccessByAdmin,
} from '../lib/firestoreOps';

interface EmployeesInvitesViewProps {
  isAdmin: boolean;
  currentUserUid: string;
  currentUserEmail: string;
  currentUserDivision: string;
  employees: EmployeeRecord[];
  invites: EmployeeInvite[];
  registeredUsers: UserProfile[];
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

type TabMode = 'directory' | 'invites';

export const EmployeesInvitesView: React.FC<EmployeesInvitesViewProps> = ({
  isAdmin,
  currentUserUid,
  currentUserEmail,
  currentUserDivision,
  employees,
  invites,
  registeredUsers,
  onRequestConfirm,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<TabMode>('directory');

  // Employee Modal (Admin)
  const [empModalOpen, setEmpModalOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<EmployeeRecord | null>(null);
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empDivision, setEmpDivision] = useState<EmployeeDivision>('Gudang & Packing');
  const [empPhone, setEmpPhone] = useState('');
  const [empShift, setEmpShift] = useState<EmployeeShift>('');
  const [empStatus, setEmpStatus] = useState<'Aktif' | 'Nonaktif'>('Aktif');
  const [empNotes, setEmpNotes] = useState('');
  const [savingEmp, setSavingEmp] = useState(false);
  const [empError, setEmpError] = useState('');

  // Invite Form (Admin)
  const [invName, setInvName] = useState('');
  const [invEmail, setInvEmail] = useState('');
  const [invDivision, setInvDivision] = useState<EmployeeDivision>('Gudang & Packing');
  const [invShift, setInvShift] = useState<EmployeeShift>('');
  const [invNotes, setInvNotes] = useState('');
  const [creatingInvite, setCreatingInvite] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const openAddEmployee = (defaultDiv: EmployeeDivision = 'Gudang & Packing') => {
    setEditingEmp(null);
    setEmpName('');
    setEmpEmail('');
    setEmpDivision(defaultDiv);
    setEmpPhone('');
    setEmpShift(defaultDiv === 'Host Live' ? 'Shift 1' : '');
    setEmpStatus('Aktif');
    setEmpNotes('');
    setEmpError('');
    setEmpModalOpen(true);
  };

  const openEditEmployee = (emp: EmployeeRecord) => {
    setEditingEmp(emp);
    setEmpName(emp.employeeName);
    setEmpEmail(emp.email);
    setEmpDivision(emp.division);
    setEmpPhone(emp.phone);
    setEmpShift(emp.division === 'Host Live' ? (emp.shift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : '');
    setEmpStatus(emp.status);
    setEmpNotes(emp.notes);
    setEmpError('');
    setEmpModalOpen(true);
  };

  const handleEmpDivisionChange = (nextDiv: EmployeeDivision) => {
    setEmpDivision(nextDiv);
    if (nextDiv === 'Host Live') {
      setEmpShift((prev) => (prev === 'Shift 2' ? 'Shift 2' : 'Shift 1'));
    } else {
      setEmpShift('');
    }
  };

  const handleInvDivisionChange = (nextDiv: EmployeeDivision) => {
    setInvDivision(nextDiv);
    if (nextDiv === 'Host Live') {
      setInvShift((prev) => (prev === 'Shift 2' ? 'Shift 2' : 'Shift 1'));
    } else {
      setInvShift('');
    }
  };

  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setEmpError('');
    setSavingEmp(true);
    try {
      const normalizedShift: EmployeeShift =
        empDivision === 'Host Live' ? (empShift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : '';
      const payload = {
        employeeName: empName,
        email: empEmail,
        division: empDivision,
        phone: empPhone,
        shift: normalizedShift,
        status: empStatus,
        notes: empNotes,
      };
      if (editingEmp) {
        await updateEmployeeRecord(editingEmp.id, payload);
        onNotify(`Data karyawan ${empName} berhasil diperbarui.`, 'success');
      } else {
        await createEmployeeRecord(currentUserUid, payload);
        onNotify(`Karyawan ${empName} ditambahkan ke divisi ${empDivision}.`, 'success');
      }
      setEmpModalOpen(false);
    } catch (err) {
      setEmpError(err instanceof Error ? err.message : 'Gagal menyimpan data karyawan.');
    } finally {
      setSavingEmp(false);
    }
  };

  const handleDeleteEmployee = (emp: EmployeeRecord) => {
    onRequestConfirm({
      open: true,
      title: `Hapus Data Karyawan ${emp.employeeName}?`,
      description: `Data karyawan dari divisi ${emp.division} akan dihapus dari daftar tim.`,
      confirmLabel: 'Hapus Karyawan',
      variant: 'danger',
      onConfirm: async () => {
        await deleteEmployeeRecord(emp.id);
        onNotify(`Data ${emp.employeeName} telah dihapus.`, 'success');
      },
    });
  };

  const handleCreateInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setCreatingInvite(true);
    try {
      const normalizedShift: EmployeeShift =
        invDivision === 'Host Live' ? (invShift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : '';
      const created = await createEmployeeInvite(currentUserUid, {
        employeeName: invName,
        email: invEmail,
        division: invDivision,
        shift: normalizedShift,
        notes: invNotes,
      });
      setInvName('');
      setInvEmail('');
      setInvNotes('');
      setInvShift(invDivision === 'Host Live' ? 'Shift 1' : '');
      onNotify(`Undangan untuk ${created.employeeName} (${created.email}) siap dibagikan.`, 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Gagal membuat undangan.', 'error');
    } finally {
      setCreatingInvite(false);
    }
  };

  const buildInviteLink = (inviteCode: string) => {
    return `${window.location.origin}/?invite=${encodeURIComponent(inviteCode)}`;
  };

  const handleCopyInviteLink = async (invite: EmployeeInvite) => {
    const link = buildInviteLink(invite.inviteCode);
    await navigator.clipboard.writeText(link);
    setCopiedId(invite.id);
    onNotify(`Tautan undangan untuk ${invite.employeeName} disalin.`, 'success');
    setTimeout(() => setCopiedId((prev) => (prev === invite.id ? null : prev)), 2500);
  };

  const buildMailtoHref = (invite: EmployeeInvite) => {
    const link = buildInviteLink(invite.inviteCode);
    const subject = encodeURIComponent(`Undangan Akses Kerja Tiga Rekan ID — Divisi ${invite.division}`);
    const shiftLine =
      invite.division === 'Host Live' && invite.shift
        ? `\n- Status Shift Kerja: ${invite.shift}`
        : '';
    const body = encodeURIComponent(
      `Halo ${invite.employeeName},\n\nAnda diundang oleh Administrator Tiga Rekan ID untuk bergabung ke aplikasi kerja operasional dengan peran:\n- Peran: Karyawan\n- Divisi: ${invite.division}${shiftLine}\n- Email Google: ${invite.email}\n\nSilakan buka tautan undangan berikut dan masuk menggunakan akun Google ${invite.email}:\n${link}\n\nTerima kasih.`
    );
    return `mailto:${encodeURIComponent(invite.email)}?subject=${subject}&body=${body}`;
  };

  const handleRevokeInvite = (invite: EmployeeInvite) => {
    onRequestConfirm({
      open: true,
      title: `Batalkan Undangan ${invite.employeeName}?`,
      description: `Tautan undangan untuk ${invite.email} tidak akan bisa digunakan lagi.`,
      confirmLabel: 'Batalkan Undangan',
      variant: 'danger',
      onConfirm: async () => {
        await revokeInvite(invite.id);
        onNotify(`Undangan ${invite.email} dibatalkan.`, 'success');
      },
    });
  };

  const handleDeleteInvite = (invite: EmployeeInvite) => {
    onRequestConfirm({
      open: true,
      title: `Hapus Riwayat Undangan ${invite.employeeName}?`,
      description: `Entri undangan untuk ${invite.email} akan dihapus permanen.`,
      confirmLabel: 'Hapus',
      variant: 'danger',
      onConfirm: async () => {
        await deleteInvite(invite.id);
        onNotify('Undangan dihapus.', 'success');
      },
    });
  };

  const handleToggleUserActive = (user: UserProfile) => {
    const nextActive = !user.active;
    onRequestConfirm({
      open: true,
      title: `${nextActive ? 'Aktifkan' : 'Nonaktifkan'} Akses ${user.displayName}?`,
      description: nextActive
        ? `Akun ${user.email} akan kembali memperoleh akses Karyawan (${user.division}).`
        : `Akun ${user.email} akan kehilangan akses masuk ke ruang kerja Tiga Rekan ID.`,
      confirmLabel: nextActive ? 'Aktifkan Akses' : 'Nonaktifkan',
      variant: nextActive ? 'primary' : 'danger',
      onConfirm: async () => {
        await updateUserAccessByAdmin(user.uid, { active: nextActive });
        onNotify(`Status akses ${user.displayName} diperbarui.`, 'success');
      },
    });
  };

  const handleChangeUserDivision = async (user: UserProfile, newDivision: EmployeeDivision) => {
    await updateUserAccessByAdmin(user.uid, { division: newDivision });
    onNotify(`Divisi ${user.displayName} diubah ke ${newDivision}.`, 'success');
  };

  const employeeAccounts = registeredUsers.filter((u) => u.role === 'employee');

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <p className="text-xs font-semibold text-orange-700">
            Struktur Tim & Hak Akses · Tiga Rekan ID
          </p>
          <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight mt-1">
            Manajemen Karyawan & Undangan Akses
          </h1>
          <p className="text-sm text-stone-600 mt-1 max-w-2xl">
            {isAdmin
              ? 'Kelola daftar karyawan berdasarkan divisi Gudang & Packing, Host Live, dan Konten Kreator serta kirim tautan undangan masuk.'
              : `Anda masuk sebagai Karyawan Divisi ${currentUserDivision} (${currentUserEmail}). Penambahan atau pengeditan data karyawan hanya dapat dilakukan oleh Administrator.`}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3 w-full lg:w-auto shrink-0">
          {isAdmin && (
            <div className="grid grid-cols-2 sm:inline-flex items-center gap-1 p-1 bg-stone-100 rounded-xl w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setActiveTab('directory')}
                className={`px-3 py-2 sm:py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap text-center ${
                  activeTab === 'directory'
                    ? 'bg-white text-orange-700 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Daftar Karyawan ({employees.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('invites')}
                className={`px-3 py-2 sm:py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap text-center ${
                  activeTab === 'invites'
                    ? 'bg-white text-orange-700 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Undangan ({invites.filter((i) => i.status === 'pending').length})
              </button>
            </div>
          )}

          {isAdmin && activeTab === 'directory' && (
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={() => openAddEmployee('Gudang & Packing')}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors whitespace-nowrap shrink-0 w-full sm:w-auto"
            >
              <Plus className="w-4 h-4" />
              Tambah Karyawan
            </motion.button>
          )}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'directory' ? (
          <motion.div
            key="directory"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            {!isAdmin && (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-orange-700 shrink-0 mt-0.5" />
                <div className="text-xs text-stone-700 leading-relaxed">
                  <p className="font-semibold text-stone-900">Akses Terbatas Peran Karyawan</p>
                  <p className="mt-0.5">
                    Anda terdaftar pada divisi <span className="font-semibold text-orange-700">{currentUserDivision}</span>. Untuk perubahan divisi, penambahan anggota baru, atau undangan akun, hubungi Administrator Utama.
                  </p>
                </div>
              </div>
            )}

            {/* Grouped by the 3 Divisions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 items-start">
              {EMPLOYEE_DIVISIONS.map((divName) => {
                const divEmployees = employees.filter((e) => e.division === divName);
                return (
                  <section
                    key={divName}
                    className="bg-white border border-stone-200 rounded-xl overflow-hidden"
                  >
                    <div className="px-4 sm:px-5 py-3.5 sm:py-4 border-b border-stone-200 flex items-center justify-between gap-3 bg-stone-50/60">
                      <div className="flex items-center gap-2 min-w-0">
                        <Users className="w-4 h-4 text-orange-600 shrink-0" />
                        <h2 className="text-sm font-bold text-stone-900 truncate">{divName}</h2>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-xs font-mono font-semibold text-stone-600 tabular-nums">
                          {divEmployees.length} orang
                        </span>
                        {isAdmin && (
                          <button
                            type="button"
                            onClick={() => openAddEmployee(divName)}
                            title={`Tambah karyawan ${divName}`}
                            className="p-1.5 text-orange-700 hover:bg-orange-100 rounded-md transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {divEmployees.length === 0 ? (
                      <div className="p-6 text-center text-xs text-stone-500">
                        Belum ada karyawan tercatat di divisi {divName}.
                      </div>
                    ) : (
                      <div className="divide-y divide-stone-100">
                        {divEmployees.map((emp) => {
                          const metaParts = [
                            emp.division === 'Host Live' && emp.shift ? emp.shift : '',
                            emp.phone || '',
                          ].filter(Boolean);

                          return (
                            <div
                              key={emp.id}
                              className="px-4 sm:px-5 py-3.5 hover:bg-orange-50/40 transition-colors"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <p className="text-sm font-semibold text-stone-900 truncate">
                                    {emp.employeeName}
                                  </p>
                                  <p className="text-xs text-stone-500 truncate font-mono mt-0.5">
                                    {emp.email}
                                  </p>
                                </div>
                                <span
                                  className={`text-xs font-semibold shrink-0 ${
                                    emp.status === 'Aktif' ? 'text-emerald-700' : 'text-stone-400'
                                  }`}
                                >
                                  {emp.status}
                                </span>
                              </div>

                              {(metaParts.length > 0 || isAdmin) && (
                                <div className="mt-2 flex items-center justify-between gap-2 text-xs text-stone-600">
                                  <span className="truncate font-medium text-stone-600">
                                    {metaParts.join(' · ')}
                                  </span>
                                  {isAdmin && (
                                    <div className="flex items-center gap-1 shrink-0 ml-auto">
                                      <button
                                        type="button"
                                        onClick={() => openEditEmployee(emp)}
                                        title="Edit data karyawan"
                                        className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                                      >
                                        <Edit3 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteEmployee(emp)}
                                        title="Hapus data karyawan"
                                        className="p-2 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              )}
                              {emp.notes && (
                                <p className="mt-1.5 text-xs text-stone-500 leading-relaxed">
                                  {emp.notes}
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </section>
                );
              })}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="invites"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
          >
            {/* Create Invitation Form */}
            <section className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-stone-200">
                <UserPlus className="w-4 h-4 text-orange-600 shrink-0" />
                <h2 className="text-base font-bold text-stone-900">
                  Buat Undangan Karyawan Baru
                </h2>
              </div>
              <p className="text-xs text-stone-600 leading-relaxed">
                Pendaftaran publik ditutup. Hanya akun Google yang diundang di sini yang dapat masuk sebagai Karyawan sesuai divisi pekerjaannya.
              </p>

              <form onSubmit={handleCreateInvite} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Nama Lengkap Karyawan
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={FIELD_LIMITS.employeeNameMax}
                    value={invName}
                    onChange={(e) => setInvName(e.target.value)}
                    placeholder="Contoh: Bagus Setiawan"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Email Akun Google Karyawan
                  </label>
                  <input
                    type="email"
                    required
                    maxLength={FIELD_LIMITS.emailMax}
                    value={invEmail}
                    onChange={(e) => setInvEmail(e.target.value)}
                    placeholder="nama.karyawan@gmail.com"
                    className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Divisi / Role Karyawan
                  </label>
                  <select
                    value={invDivision}
                    onChange={(e) => handleInvDivisionChange(e.target.value as EmployeeDivision)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                  >
                    {EMPLOYEE_DIVISIONS.map((div) => (
                      <option key={div} value={div}>
                        {div}
                      </option>
                    ))}
                  </select>
                </div>

                {invDivision === 'Host Live' && (
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Status Shift Kerja (Khusus Host Live)
                    </label>
                    <select
                      value={invShift || 'Shift 1'}
                      onChange={(e) => setInvShift(e.target.value as EmployeeShift)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      {HOST_LIVE_SHIFTS.map((sh) => (
                        <option key={sh} value={sh}>
                          {sh}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Catatan Tugas (Opsional)
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.inviteNotesMax}
                    value={invNotes}
                    onChange={(e) => setInvNotes(e.target.value)}
                    placeholder="Misal: PIC packing TikTok Tiga Rekan ID"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={creatingInvite}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-60"
                >
                  <Link2 className="w-4 h-4" />
                  {creatingInvite ? 'Membuat Undangan...' : 'Buat Tautan Undangan'}
                </motion.button>
              </form>
            </section>

            {/* Invitations List & Active Accounts */}
            <div className="lg:col-span-7 space-y-6">
              <section className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="px-4 sm:px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-2">
                  <h2 className="text-base font-bold text-stone-900">
                    Daftar Tautan & Email Undangan
                  </h2>
                  <span className="text-xs font-mono text-stone-500 tabular-nums shrink-0">
                    {invites.length} undangan
                  </span>
                </div>

                {invites.length === 0 ? (
                  <div className="p-8 text-center text-sm text-stone-600">
                    Belum ada undangan karyawan yang dibuat.
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100">
                    {invites.map((inv) => {
                      const statusLabel =
                        inv.status === 'pending'
                          ? 'Menunggu Login'
                          : inv.status === 'accepted'
                          ? 'Sudah Bergabung'
                          : 'Dibatalkan';
                      const statusColor =
                        inv.status === 'pending'
                          ? 'text-orange-700'
                          : inv.status === 'accepted'
                          ? 'text-emerald-700'
                          : 'text-stone-400';

                      return (
                        <div key={inv.id} className="p-4 sm:p-5 space-y-3 hover:bg-stone-50/70">
                          <div className="flex flex-wrap items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-stone-900">
                                {inv.employeeName} ·{' '}
                                <span className="text-orange-700">{inv.division}</span>
                                {inv.division === 'Host Live' && inv.shift && (
                                  <span className="text-stone-600 font-medium"> · {inv.shift}</span>
                                )}
                              </p>
                              <p className="text-xs font-mono text-stone-500 mt-0.5 break-all">
                                {inv.email}
                              </p>
                            </div>
                            <span className={`text-xs font-semibold shrink-0 ${statusColor}`}>
                              {statusLabel}
                            </span>
                          </div>

                          {inv.status === 'pending' && (
                            <div className="flex flex-wrap items-center gap-2 pt-1">
                              <button
                                type="button"
                                onClick={() => handleCopyInviteLink(inv)}
                                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-orange-700 bg-orange-50 border border-orange-200 rounded-lg hover:bg-orange-100 transition-colors flex-1 sm:flex-initial whitespace-nowrap"
                              >
                                {copiedId === inv.id ? (
                                  <Check className="w-3.5 h-3.5" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                                {copiedId === inv.id ? 'Tautan Disalin' : 'Salin Link'}
                              </button>
                              <a
                                href={buildMailtoHref(inv)}
                                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors flex-1 sm:flex-initial whitespace-nowrap"
                              >
                                <Mail className="w-3.5 h-3.5" />
                                Kirim Email
                              </a>
                              <button
                                type="button"
                                onClick={() => handleRevokeInvite(inv)}
                                className="px-3 py-2 text-xs font-medium text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                Batalkan
                              </button>
                            </div>
                          )}

                          {inv.status !== 'pending' && (
                            <div className="flex justify-end">
                              <button
                                type="button"
                                onClick={() => handleDeleteInvite(inv)}
                                className="px-2 py-1 text-xs font-medium text-stone-400 hover:text-red-700"
                              >
                                Hapus Riwayat
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Active Registered Employee Accounts */}
              <section className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="px-4 sm:px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-2">
                  <h2 className="text-base font-bold text-stone-900">
                    Akun Karyawan Terhubung
                  </h2>
                  <span className="text-xs font-mono text-stone-500 tabular-nums shrink-0">
                    {employeeAccounts.length} akun
                  </span>
                </div>

                {employeeAccounts.length === 0 ? (
                  <div className="p-6 text-sm text-stone-600">
                    Belum ada karyawan yang mengklaim undangan akses.
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100">
                    {employeeAccounts.map((acc) => (
                      <div
                        key={acc.uid}
                        className="px-4 sm:px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-stone-900 truncate">
                            {acc.displayName}
                          </p>
                          <p className="text-xs font-mono text-stone-500 truncate">{acc.email}</p>
                        </div>
                        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                          <select
                            value={acc.division}
                            onChange={(e) =>
                              handleChangeUserDivision(acc, e.target.value as EmployeeDivision)
                            }
                            aria-label={`Ubah divisi ${acc.displayName}`}
                            className="flex-1 sm:flex-initial px-2.5 py-2 sm:py-1.5 text-xs border border-stone-300 rounded-lg bg-white"
                          >
                            {EMPLOYEE_DIVISIONS.map((d) => (
                              <option key={d} value={d}>
                                {d}
                              </option>
                            ))}
                          </select>
                          <button
                            type="button"
                            onClick={() => handleToggleUserActive(acc)}
                            className={`px-3 py-2 sm:py-1.5 text-xs font-semibold rounded-lg border transition-colors shrink-0 ${
                              acc.active
                                ? 'text-emerald-700 border-emerald-200 bg-emerald-50 hover:bg-emerald-100'
                                : 'text-red-700 border-red-200 bg-red-50 hover:bg-red-100'
                            }`}
                          >
                            {acc.active ? 'Aktif' : 'Nonaktif'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add / Edit Employee Modal (Admin) */}
      <AnimatePresence>
        {empModalOpen && isAdmin && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-stone-900/40 p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-lg bg-white border border-stone-200 rounded-xl p-5 sm:p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
                <h2 className="text-base font-bold text-stone-900">
                  {editingEmp ? 'Edit Data Karyawan' : 'Tambah Data Karyawan'}
                </h2>
                <button
                  type="button"
                  onClick={() => setEmpModalOpen(false)}
                  className="p-1.5 text-stone-400 hover:text-stone-700 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {empError && (
                <div className="mb-4 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                  {empError}
                </div>
              )}

              <form onSubmit={handleSaveEmployee} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Nama Karyawan
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={FIELD_LIMITS.employeeNameMax}
                      value={empName}
                      onChange={(e) => setEmpName(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Email Google
                    </label>
                    <input
                      type="email"
                      required
                      maxLength={FIELD_LIMITS.emailMax}
                      value={empEmail}
                      onChange={(e) => setEmpEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                </div>

                <div
                  className={`grid grid-cols-1 ${
                    empDivision === 'Host Live' ? 'sm:grid-cols-2' : ''
                  } gap-4`}
                >
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Divisi / Role
                    </label>
                    <select
                      value={empDivision}
                      onChange={(e) =>
                        handleEmpDivisionChange(e.target.value as EmployeeDivision)
                      }
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      {EMPLOYEE_DIVISIONS.map((div) => (
                        <option key={div} value={div}>
                          {div}
                        </option>
                      ))}
                    </select>
                  </div>
                  {empDivision === 'Host Live' && (
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">
                        Status Shift Kerja
                      </label>
                      <select
                        value={empShift || 'Shift 1'}
                        onChange={(e) => setEmpShift(e.target.value as EmployeeShift)}
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                      >
                        {HOST_LIVE_SHIFTS.map((sh) => (
                          <option key={sh} value={sh}>
                            {sh}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      No. WhatsApp / Telepon
                    </label>
                    <input
                      type="text"
                      maxLength={FIELD_LIMITS.phoneMax}
                      value={empPhone}
                      onChange={(e) => setEmpPhone(e.target.value)}
                      placeholder="0812..."
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Status Karyawan
                    </label>
                    <select
                      value={empStatus}
                      onChange={(e) => setEmpStatus(e.target.value as 'Aktif' | 'Nonaktif')}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      <option value="Aktif">Aktif</option>
                      <option value="Nonaktif">Nonaktif</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Catatan Tambahan
                  </label>
                  <textarea
                    rows={2}
                    maxLength={FIELD_LIMITS.inviteNotesMax}
                    value={empNotes}
                    onChange={(e) => setEmpNotes(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="flex flex-col-reverse sm:flex-row justify-end gap-2.5 sm:gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEmpModalOpen(false)}
                    className="px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={savingEmp}
                    className="px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:opacity-60"
                  >
                    {savingEmp ? 'Menyimpan...' : 'Simpan Karyawan'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
