import { useState } from 'react';
import { Hadith, Meta, matnOf, sanadOf } from '../data/db';

interface Props {
  h: Hadith;
  meta: Meta;
  fontSize: number;
  saved: boolean;
  onToggleSave: (key: string) => void;
  highlight?: string;
}

const TIER_STYLE: Record<number, string> = {
  3: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  2: 'bg-teal-100 text-teal-800 border-teal-300',
  1: 'bg-amber-100 text-amber-800 border-amber-300',
};
const TIER_LABEL: Record<number, string> = {
  3: 'سند صحيح',
  2: 'في حكم الصحيح',
  1: 'سند معتبر',
};

export default function HadithCard({ h, meta, fontSize, saved, onToggleSave }: Props) {
  const [showSanad, setShowSanad] = useState(false);
  const [copied, setCopied] = useState(false);
  const matn = matnOf(h);
  const sanad = sanadOf(h);
  const speaker = h.speaker >= 0 ? meta.masoomsNames[h.speaker] : 'عن المعصوم (ع)';
  const ref = `${meta.books[h.book]} – رقم ${h.num}`;

  const fullText = () =>
    `${matn}\n\n— ${speaker}\n${ref}\nالدرجة: ${meta.grades[h.grade]} (${meta.graders[h.grader]})`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(fullText());
    } catch {
      const ta = document.createElement('textarea');
      ta.value = fullText();
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ text: fullText() });
        return;
      } catch {
        /* cancelled */
      }
    }
    copy();
  };

  return (
    <article className="rounded-2xl bg-white shadow-sm border border-emerald-900/10 overflow-hidden">
      <div className="flex items-center justify-between gap-2 px-4 py-2.5 bg-emerald-950/[0.04] border-b border-emerald-900/10">
        <div className="text-[13px] font-bold text-emerald-900 leading-snug">{speaker}</div>
        <span className={`shrink-0 text-[11px] font-bold border rounded-full px-2.5 py-0.5 ${TIER_STYLE[h.tier]}`}>
          {TIER_LABEL[h.tier]}
        </span>
      </div>

      <div className="px-4 pt-4 pb-3">
        <p
          className="text-stone-900 whitespace-pre-line"
          style={{ fontSize, lineHeight: 2.1, fontFamily: '"Amiri","Noto Naskh Arabic","Traditional Arabic","Geeza Pro",serif' }}
        >
          {matn}
        </p>

        {showSanad && sanad && (
          <div className="mt-3 rounded-xl bg-stone-50 border border-stone-200 p-3">
            <div className="text-[11px] font-bold text-stone-500 mb-1">السند</div>
            <p className="text-stone-700 text-[15px] leading-8">{sanad}</p>
          </div>
        )}

        <div className="mt-3 text-[12px] text-stone-500 leading-6">
          <span className="font-semibold text-stone-700">{ref}</span>
          <span className="mx-1.5">•</span>
          <span>
            {meta.grades[h.grade]} — {meta.graders[h.grader]}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-1 px-2 pb-2.5">
        <button
          onClick={() => onToggleSave(h.key)}
          className={`flex-1 rounded-xl py-2 text-sm font-bold transition ${
            saved ? 'bg-amber-100 text-amber-800' : 'bg-stone-100 text-stone-700 active:bg-stone-200'
          }`}
        >
          {saved ? '★ محفوظ' : '☆ حفظ'}
        </button>
        <button onClick={copy} className="flex-1 rounded-xl py-2 text-sm font-bold bg-stone-100 text-stone-700 active:bg-stone-200">
          {copied ? '✓ تم النسخ' : 'نسخ'}
        </button>
        <button onClick={share} className="flex-1 rounded-xl py-2 text-sm font-bold bg-stone-100 text-stone-700 active:bg-stone-200">
          مشاركة
        </button>
        {sanad && (
          <button
            onClick={() => setShowSanad((s) => !s)}
            className="flex-1 rounded-xl py-2 text-sm font-bold bg-emerald-50 text-emerald-800 active:bg-emerald-100"
          >
            {showSanad ? 'إخفاء السند' : 'السند'}
          </button>
        )}
      </div>
    </article>
  );
}
