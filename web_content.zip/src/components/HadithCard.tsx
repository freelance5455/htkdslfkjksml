import { memo, useMemo, useState, type ReactNode } from "react";
import { bookLabel, TIER_STYLE, toArabicDigits, type Db, type Hadith } from "../lib/data";
import { useStore } from "../lib/store";
import { ChevronDown, CopyIcon, HeartIcon, ShareIcon, CheckIcon } from "./Icons";

function highlight(text: string, re: RegExp | null): ReactNode {
  if (!re) return text;
  const parts = text.split(re);
  if (parts.length === 1) return text;
  return parts.map((p, i) => (i % 2 === 1 ? <mark key={i}>{p}</mark> : <span key={i}>{p}</span>));
}

type Props = {
  db: Db;
  h: Hadith;
  re?: RegExp | null;
  onTopic?: (code: string) => void;
  onImam?: (code: string) => void;
};

function HadithCardBase({ db, h, re = null, onTopic, onImam }: Props) {
  const { isFav, toggleFav, fontSize, showSanad } = useStore();
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const key = `${h.b}:${h.n}`;
  const fav = isFav(key);
  const tier = TIER_STYLE[h.g];

  const hasSplit = h.s > 0;
  const sanad = hasSplit ? h.t.slice(0, h.s).trim() : "";
  const matn = (hasSplit ? h.t.slice(h.s) : h.t).trim();
  const sanadOpen = open || showSanad;

  const speaker = db.imamName[h.m[0]];
  const quoted = h.m.slice(1);

  const plain = useMemo(
    () =>
      `${h.t}\n\n— ${speaker}\n${bookLabel(db, h)} — ح${toArabicDigits(h.n)}\nدرجة الحديث: ${tier.label} (${h.gs})\nمن تطبيق ABK`,
    [db, h, speaker, tier.label]
  );

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(plain);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = plain;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch {
        /* ignore */
      }
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ text: plain });
        return;
      } catch {
        /* ignore */
      }
    }
    copy();
  };

  return (
    <article className="fade-up overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm dark:border-stone-700/60 dark:bg-stone-900">
      <header className="flex flex-wrap items-center gap-2 border-b border-stone-100 bg-emerald-50/60 px-4 py-2.5 dark:border-stone-800 dark:bg-emerald-950/40">
        <button
          onClick={() => onImam?.(h.m[0])}
          className="rounded-full bg-emerald-800 px-3 py-1 text-xs font-bold text-white active:scale-95 dark:bg-emerald-700"
        >
          {speaker}
        </button>
        {quoted.slice(0, 3).map((q) => (
          <span
            key={q}
            className="rounded-full bg-white px-2.5 py-0.5 text-[11px] text-emerald-900 ring-1 ring-emerald-200 dark:bg-stone-800 dark:text-emerald-200 dark:ring-emerald-800"
          >
            يُنقل فيه: {db.imamName[q]}
          </span>
        ))}
        <span
          title={tier.desc}
          className={`mr-auto rounded-full px-2.5 py-0.5 text-xs font-bold ring-1 ${tier.cls}`}
        >
          {tier.label}
        </span>
      </header>

      <div className="px-4 py-3">
        <p className="font-hadith whitespace-pre-line text-stone-900 dark:text-stone-100" style={{ fontSize }}>
          {highlight(matn, re)}
        </p>

        {hasSplit && (
          <div className="mt-2">
            <button
              onClick={() => setOpen(!open)}
              className="flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400"
            >
              <ChevronDown open={sanadOpen} />
              {sanadOpen ? "إخفاء السند" : "عرض السند"}
            </button>
            {sanadOpen && (
              <p
                className="font-hadith mt-1 rounded-xl bg-stone-50 p-3 text-stone-600 dark:bg-stone-800/70 dark:text-stone-300"
                style={{ fontSize: Math.max(15, fontSize - 6) }}
              >
                {highlight(sanad, re)}
              </p>
            )}
          </div>
        )}
      </div>

      <footer className="border-t border-stone-100 px-4 py-2.5 text-xs text-stone-500 dark:border-stone-800 dark:text-stone-400">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <span className="font-semibold text-stone-700 dark:text-stone-200">
            📖 {bookLabel(db, h)} · ح{toArabicDigits(h.n)}
          </span>
          <span>التصحيح: {h.gs}</span>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {h.c.slice(0, 2).map((c) => (
            <button
              key={c}
              onClick={() => onTopic?.(c)}
              className="rounded-full bg-stone-100 px-2.5 py-1 text-[11px] text-stone-700 active:scale-95 dark:bg-stone-800 dark:text-stone-300"
            >
              {db.topicInfo[c]?.icon} {db.topicInfo[c]?.name}
            </button>
          ))}
          <div className="mr-auto flex items-center gap-1">
            <button
              onClick={() => toggleFav(key)}
              aria-label="مفضلة"
              className={`rounded-full p-2 active:scale-90 ${fav ? "text-rose-600" : "text-stone-500 dark:text-stone-400"}`}
            >
              <HeartIcon filled={fav} size={18} />
            </button>
            <button onClick={copy} aria-label="نسخ" className="rounded-full p-2 text-stone-500 active:scale-90 dark:text-stone-400">
              {copied ? <CheckIcon /> : <CopyIcon />}
            </button>
            <button onClick={share} aria-label="مشاركة" className="rounded-full p-2 text-stone-500 active:scale-90 dark:text-stone-400">
              <ShareIcon />
            </button>
          </div>
        </div>
      </footer>
    </article>
  );
}

export const HadithCard = memo(HadithCardBase);
