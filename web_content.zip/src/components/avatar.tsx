import { cn } from "@/lib/cn";
import { initials } from "@/lib/format";

export function Avatar({
  name,
  size = "md",
}: {
  name: string;
  size?: "sm" | "md" | "lg" | "xl";
}) {
  const unknown = !name || name === "Unknown";
  return (
    <div
      className={cn(
        "grid shrink-0 place-items-center rounded-full bg-muted font-medium text-accent",
        size === "sm" && "size-9 text-xs",
        size === "md" && "size-11 text-sm",
        size === "lg" && "size-16 text-lg",
        size === "xl" && "size-24 text-2xl",
      )}
      aria-hidden
    >
      {unknown ? "?" : initials(name)}
    </div>
  );
}
