import React, { useState } from 'react';
import { Topic } from '../types';
import { FORGETTING_INTERVALS, calculateRetention } from '../utils/spacedRepetition';
import { Info, Sparkles, TrendingUp, Calendar, CheckCircle2 } from 'lucide-react';

interface ForgettingCurveVisualizerProps {
  topics: Topic[];
  selectedTopicId?: string;
  onSelectTopic?: (topicId: string) => void;
}

export const ForgettingCurveVisualizer: React.FC<ForgettingCurveVisualizerProps> = ({
  topics,
  selectedTopicId,
  onSelectTopic,
}) => {
  const [activeTab, setActiveTab] = useState<'theory' | 'customTopic'>('theory');
  const [hoveredMilestone, setHoveredMilestone] = useState<number | null>(null);

  const selectedTopic = topics.find((t) => t.id === selectedTopicId) || topics[0];

  // SVG coordinate configuration
  const svgWidth = 840;
  const svgHeight = 350;
  const padding = { top: 48, right: 40, bottom: 50, left: 60 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  const totalDays = 35; // Show days 0 to 35

  const getX = (day: number) => padding.left + (day / totalDays) * graphWidth;
  const getY = (retentionPct: number) => padding.top + ((100 - retentionPct) / 100) * graphHeight;

  // 1. Generate path for unreinforced forgetting curve: R(t) = e^(-t / 1.5)
  const unreinforcedPoints: string[] = [];
  for (let d = 0; d <= totalDays; d += 0.5) {
    const r = Math.max(5, Math.exp(-d / 1.6) * 100);
    const x = getX(d);
    const y = getY(r);
    unreinforcedPoints.push(`${d === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const unreinforcedPath = unreinforcedPoints.join(' ');

  // 2. Generate spaced repetition curve with reviews at Day 1, 3, 7, 21, 30
  // Each review jumps retention back to 100% and increases stability S
  const reviewMilestones = [
    { day: 0, s: 1.5, label: 'Learn' },
    { day: 1, s: 3.5, label: 'Day 1' },
    { day: 3, s: 8.0, label: 'Day 3' },
    { day: 7, s: 20.0, label: 'Day 7' },
    { day: 21, s: 45.0, label: 'Day 21' },
    { day: 30, s: 90.0, label: 'Day 30' },
  ];

  const spacedSegments: string[] = [];
  for (let i = 0; i < reviewMilestones.length; i++) {
    const currentM = reviewMilestones[i];
    const nextDay = i < reviewMilestones.length - 1 ? reviewMilestones[i + 1].day : totalDays;

    for (let d = currentM.day; d <= nextDay; d += 0.5) {
      const elapsedSinceM = d - currentM.day;
      const r = Math.max(10, Math.exp(-elapsedSinceM / currentM.s) * 100);
      const x = getX(d);
      const y = getY(r);
      if (d === currentM.day) {
        spacedSegments.push(`M ${x.toFixed(1)} ${y.toFixed(1)}`);
      } else {
        spacedSegments.push(`L ${x.toFixed(1)} ${y.toFixed(1)}`);
      }
    }
  }
  const spacedCurvePath = spacedSegments.join(' ');

  // Milestone explanations based on cognitive science
  const milestoneExplanations = [
    {
      day: 1,
      title: 'First Review (24 Hours)',
      detail: 'Arrests initial rapid decay. Over 70% of new information vanishes within 24 hours without this check.',
    },
    {
      day: 3,
      title: 'Second Review (72 Hours)',
      detail: 'Consolidates early neural traces as hippocampus starts transfer to neocortex.',
    },
    {
      day: 7,
      title: 'Third Review (1 Week)',
      detail: 'Synaptic stabilization. Memory trace requires less retrieval effort, extending stability.',
    },
    {
      day: 21,
      title: 'Fourth Review (3 Weeks)',
      detail: 'Long-term storage transition. Protects against proactive and retroactive interference.',
    },
    {
      day: 30,
      title: 'Fifth Review (1 Month)',
      detail: 'Permanent structural consolidation. Concept transitions to automatic recall bank.',
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-6">
      {/* Header and selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
              Ebbinghaus Forgetting Curve & Spaced Schedule
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Visualizing the exponential decay of memory vs how spaced recall at Day 1, 3, 7, 21, and 30 cements retention.
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium shrink-0">
          <button
            onClick={() => setActiveTab('theory')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'theory'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Scientific Model
          </button>
          <button
            onClick={() => setActiveTab('customTopic')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'customTopic'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Topic Diagnostic
          </button>
        </div>
      </div>

      {/* Topic selection if diagnostic mode */}
      {activeTab === 'customTopic' && (
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200/60 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <label htmlFor="topic-curve-select" className="font-medium text-slate-700 dark:text-slate-300">
              Active Topic:
            </label>
            <select
              id="topic-curve-select"
              value={selectedTopic?.id || ''}
              onChange={(e) => onSelectTopic && onSelectTopic(e.target.value)}
              className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            >
              {topics.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} (Stage {t.stage} · {t.masteryScore}%)
                </option>
              ))}
            </select>
          </div>

          {selectedTopic && (
            <div className="flex items-center gap-4 text-slate-600 dark:text-slate-300 font-mono tabular-nums">
              <span>
                Estimated Retention:{' '}
                <strong className="text-emerald-600 dark:text-emerald-400">
                  {calculateRetention(selectedTopic.lastReviewedAt, selectedTopic.createdAt, selectedTopic.stability)}%
                </strong>
              </span>
              <span>·</span>
              <span>
                Memory Stability S:{' '}
                <strong className="text-indigo-600 dark:text-indigo-400">
                  {selectedTopic.stability.toFixed(1)} days
                </strong>
              </span>
            </div>
          )}
        </div>
      )}

      {/* Interactive SVG Chart */}
      <div className="overflow-x-auto">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto min-w-[620px] max-h-[340px]"
          role="img"
          aria-label="Graph of Ebbinghaus Forgetting Curve comparing passive forgetting against spaced repetitions"
        >
          {/* Background grid lines */}
          {[100, 75, 50, 25, 0].map((pct) => (
            <g key={pct}>
              <line
                x1={padding.left}
                y1={getY(pct)}
                x2={svgWidth - padding.right}
                y2={getY(pct)}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray={pct === 50 || pct === 0 ? undefined : '2,2'}
                strokeWidth={pct === 0 ? '1.5' : '1'}
              />
              <text
                x={padding.left - 10}
                y={getY(pct) + 4}
                textAnchor="end"
                className="text-[11px] font-mono tabular-nums fill-slate-500 dark:fill-slate-400"
              >
                {pct}%
              </text>
            </g>
          ))}

          {/* Critical Retention Threshold: 70% */}
          <line
            x1={padding.left}
            y1={getY(70)}
            x2={svgWidth - padding.right}
            y2={getY(70)}
            stroke="#f59e0b"
            strokeDasharray="4,4"
            strokeWidth="1.2"
            opacity="0.7"
          />
          <text
            x={svgWidth - padding.right - 8}
            y={getY(70) - 6}
            textAnchor="end"
            className="text-[10px] font-mono fill-amber-600 dark:fill-amber-400 font-medium"
          >
            Review Trigger (70% Retention)
          </text>

          {/* X-axis milestone ticks */}
          {[1, 3, 7, 14, 21, 30].map((day) => (
            <g key={day}>
              <line
                x1={getX(day)}
                y1={padding.top}
                x2={getX(day)}
                y2={svgHeight - padding.bottom}
                stroke="currentColor"
                className={
                  [1, 3, 7, 21, 30].includes(day)
                    ? 'text-indigo-200 dark:text-indigo-900/50'
                    : 'text-slate-100 dark:text-slate-800/40'
                }
                strokeWidth={[1, 3, 7, 21, 30].includes(day) ? '1.5' : '1'}
              />
              <text
                x={getX(day)}
                y={svgHeight - padding.bottom + 18}
                textAnchor="middle"
                className={`text-[11px] font-mono tabular-nums ${
                  [1, 3, 7, 21, 30].includes(day)
                    ? 'fill-indigo-600 dark:fill-indigo-400 font-semibold'
                    : 'fill-slate-500 dark:fill-slate-400'
                }`}
              >
                Day {day}
              </text>
            </g>
          ))}

          {/* Curve 1: Passive forgetting (Without Review) */}
          <path
            d={unreinforcedPath}
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2.5"
            strokeDasharray="4,3"
            opacity="0.85"
          />

          {/* Curve 2: Spaced Repetition (With Reviews at Day 1, 3, 7, 21, 30) */}
          <path
            d={spacedCurvePath}
            fill="none"
            stroke="#10b981"
            strokeWidth="3"
            strokeLinecap="round"
          />

          {/* Milestone Dots & Jump Spikes */}
          {reviewMilestones.map((m, idx) => {
            const x = getX(m.day);
            const y100 = getY(100);
            const yOffset = m.day === 0 ? -16 : m.day === 1 ? -26 : -12;
            const xOffset = m.day === 0 ? -6 : m.day === 1 ? 6 : 0;
            return (
              <g
                key={m.day}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredMilestone(m.day)}
                onMouseLeave={() => setHoveredMilestone(null)}
              >
                {/* Spaced review spike vertical line */}
                {m.day > 0 && (
                  <line
                    x1={x}
                    y1={getY(Math.max(10, Math.exp(-(m.day - reviewMilestones[idx - 1].day) / reviewMilestones[idx - 1].s) * 100))}
                    x2={x}
                    y2={y100}
                    stroke="#10b981"
                    strokeWidth="1.5"
                    strokeDasharray="2,2"
                  />
                )}
                {/* Circle marker at 100% recall reset */}
                <circle
                  cx={x}
                  cy={y100}
                  r={hoveredMilestone === m.day ? 7 : 5}
                  className="fill-emerald-500 stroke-white dark:stroke-slate-900 transition-all"
                  strokeWidth="2.5"
                />
                <text
                  x={x + xOffset}
                  y={y100 + yOffset}
                  textAnchor="middle"
                  className="text-[10px] font-mono fill-slate-700 dark:fill-slate-300 font-medium"
                >
                  {m.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend & Milestone Cards */}
      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-4 h-0.5 border-t-2 border-dashed border-rose-500 inline-block" />
            <span className="text-slate-600 dark:text-slate-400">
              Passive Learning (Decays to ~25% in 48h)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-0.5 bg-emerald-500 inline-block rounded-full" />
            <span className="text-slate-600 dark:text-slate-400 font-medium">
              Spaced Repetition (Stabilizes to &gt;90%)
            </span>
          </div>
        </div>

        <div className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-mono text-[11px]">
          <Info className="w-3.5 h-3.5 text-indigo-500" />
          <span>Formula: R(t) = e^(-t/S)</span>
        </div>
      </div>

      {/* Milestone Intervals Breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
        {milestoneExplanations.map((m) => (
          <div
            key={m.day}
            className={`p-3 rounded-lg border text-xs transition-all ${
              hoveredMilestone === m.day
                ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-700'
                : 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-200/70 dark:border-slate-800'
            }`}
            onMouseEnter={() => setHoveredMilestone(m.day)}
            onMouseLeave={() => setHoveredMilestone(null)}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {m.title}
              </span>
              <span className="font-mono text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">
                Day {m.day}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              {m.detail}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
