import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';
import { ConfirmDialogState } from '../types/ops';

interface ConfirmModalProps {
  dialog: ConfirmDialogState | null;
  onClose: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({ dialog, onClose }) => {
  const [submitting, setSubmitting] = useState(false);

  const handleConfirm = async () => {
    if (!dialog) return;
    setSubmitting(true);
    try {
      await dialog.onConfirm();
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  const isDanger = dialog?.variant === 'danger';

  return (
    <AnimatePresence>
      {dialog && dialog.open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/40 backdrop-blur-[1px] p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-modal-title"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.16 }}
            className="w-full max-w-md bg-white border border-stone-200 rounded-xl p-6 shadow-xl"
          >
            <div className="flex items-start justify-between gap-4 mb-3">
              <div className="flex items-center gap-2.5">
                {isDanger && <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />}
                <h2 id="confirm-modal-title" className="text-base font-semibold text-stone-900">
                  {dialog.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                disabled={submitting}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
                aria-label="Tutup dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-stone-600 leading-relaxed mb-4">{dialog.description}</p>

            {dialog.details && dialog.details.length > 0 && (
              <ul className="mb-5 bg-stone-50 border border-stone-200 rounded-lg px-3.5 py-2.5 space-y-1 text-xs text-stone-700">
                {dialog.details.map((item, idx) => (
                  <li key={idx} className="truncate">
                    • {item}
                  </li>
                ))}
              </ul>
            )}

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={submitting}
                className="px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap shrink-0"
              >
                Batal
              </button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={handleConfirm}
                disabled={submitting}
                className={`px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isDanger ? 'bg-red-600 hover:bg-red-700' : 'bg-orange-600 hover:bg-orange-700'
                } disabled:opacity-60`}
              >
                {submitting ? 'Memproses...' : dialog.confirmLabel}
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
