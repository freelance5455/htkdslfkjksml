import { ChannelCard } from "@/components/channel-card";
import { Button } from "@/components/ui/button";
import { useSubscriptions, type SubChannel } from "@/lib/subscriptions";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useRef, useState, type TouchEvent } from "react";

export function FollowingList({
  onSearch,
}: {
  onSearch: () => void;
}) {
  const channels = useSubscriptions((s) => s.channels);
  const sorted = useMemo(
    () => [...channels].sort((a, b) => (b.subscribedAt ?? 0) - (a.subscribedAt ?? 0)),
    [channels],
  );
  const [index, setIndex] = useState(0);
  const startX = useRef(0);

  if (sorted.length === 0) {
    return (
      <div className="rounded-2xl border border-border bg-card px-6 py-12 text-center">
        <h2 className="font-display text-lg font-semibold">No subscriptions yet</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          Subscribe to any channel. This tab lists them one at a time, newest subscription first.
        </p>
        <Button className="mt-5" onClick={onSearch}>
          Search channels
        </Button>
      </div>
    );
  }

  const safeIndex = Math.min(index, sorted.length - 1);
  const channel: SubChannel = sorted[safeIndex]!;
  const go = (dir: -1 | 1) => {
    setIndex((i) => Math.min(sorted.length - 1, Math.max(0, i + dir)));
  };

  const onTouchStart = (e: TouchEvent) => {
    startX.current = e.touches[0]?.clientX ?? 0;
  };
  const onTouchEnd = (e: TouchEvent) => {
    const x = e.changedTouches[0]?.clientX ?? startX.current;
    const dx = x - startX.current;
    if (dx > 48) go(-1);
    if (dx < -48) go(1);
  };

  return (
    <div className="flex min-h-[70dvh] flex-col" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <p className="mb-3 px-1 text-xs text-muted-foreground">
        {safeIndex + 1} of {sorted.length} · most recently subscribed first
      </p>
      <div className="flex min-h-0 flex-1 flex-col justify-center">
        <ChannelCard channel={channel} />
      </div>
      <div className="mt-4 flex items-center justify-between gap-3">
        <Button
          type="button"
          variant="outline"
          className="flex-1"
          disabled={safeIndex === 0}
          onClick={() => go(-1)}
        >
          <ChevronLeft />
          Previous
        </Button>
        <Button
          type="button"
          variant="outline"
          className="flex-1"
          disabled={safeIndex >= sorted.length - 1}
          onClick={() => go(1)}
        >
          Next
          <ChevronRight />
        </Button>
      </div>
    </div>
  );
}
