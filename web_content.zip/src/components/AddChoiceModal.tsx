import React from 'react';
import { X, ArrowUpRight, ArrowDownLeft, PackagePlus, Barcode, Sparkles } from 'lucide-react';
import { feedback } from '../utils/haptics';

interface AddChoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onChooseSale: () => void;
  onChoosePurchase: () => void;
  onChooseNewItem: () => void;
  onChooseScanner: () => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const AddChoiceModal: React.FC<AddChoiceModalProps> = ({
  isOpen,
  onClose,
  onChooseSale,
  onChoosePurchase,
  onChooseNewItem,
  onChooseScanner,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl p-5 border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom-6 duration-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Create New Entry
            </h3>
            <p className="text-xs text-slate-500">What would you like to record?</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {/* Sale button */}
          <button
            onClick={() => {
              feedback.vibrateSoft(hapticsEnabled);
              feedback.playTap(soundEnabled);
              onChooseSale();
              onClose();
            }}
            className="w-full p-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white flex items-center justify-between shadow-sm transition"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <ArrowUpRight className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-sm">Sale (Stock Out)</div>
                <div className="text-[11px] text-emerald-100">Sell item to customer & invoice</div>
              </div>
            </div>
            <span className="text-xs font-semibold bg-white/20 px-2 py-1 rounded-lg">New Sale</span>
          </button>

          {/* Purchase button */}
          <button
            onClick={() => {
              feedback.vibrateSoft(hapticsEnabled);
              feedback.playTap(soundEnabled);
              onChoosePurchase();
              onClose();
            }}
            className="w-full p-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white flex items-center justify-between shadow-sm transition"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <ArrowDownLeft className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-sm">Purchase (Stock In)</div>
                <div className="text-[11px] text-blue-100">Restock inventory from supplier</div>
              </div>
            </div>
            <span className="text-xs font-semibold bg-white/20 px-2 py-1 rounded-lg">New Purchase</span>
          </button>

          {/* New Item button */}
          <button
            onClick={() => {
              feedback.vibrateSoft(hapticsEnabled);
              feedback.playTap(soundEnabled);
              onChooseNewItem();
              onClose();
            }}
            className="w-full p-3.5 rounded-2xl bg-slate-800 hover:bg-slate-900 active:scale-98 text-white flex items-center justify-between shadow-sm transition"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <PackagePlus className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-sm">New Product Item</div>
                <div className="text-[11px] text-slate-300">Add SKU, cost, price & reorder rule</div>
              </div>
            </div>
            <span className="text-xs font-semibold bg-white/20 px-2 py-1 rounded-lg">+ Product</span>
          </button>

          {/* Barcode Quick Scan */}
          <button
            onClick={() => {
              feedback.vibrateSoft(hapticsEnabled);
              feedback.playTap(soundEnabled);
              onChooseScanner();
              onClose();
            }}
            className="w-full p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-98 text-slate-800 dark:text-slate-100 flex items-center justify-between border border-slate-200 dark:border-slate-700 transition"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                <Barcode className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-sm">Scan Barcode / QR</div>
                <div className="text-[11px] text-slate-500">Scan product label with camera</div>
              </div>
            </div>
            <span className="text-xs font-semibold text-red-600 dark:text-red-400">Scan</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 transition"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
