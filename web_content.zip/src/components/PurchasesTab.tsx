import React, { useState, useRef } from 'react';
import {
  Plus,
  Search,
  Camera,
  Barcode,
  Calendar,
  Trash2,
  ShoppingCart,
  X,
  Check,
  Building2,
  Layers,
  List,
  Sparkles,
  FileText,
  PackagePlus,
  CheckCircle2,
  AlertCircle,
  Printer,
} from 'lucide-react';
import type { PurchaseItem, MedicineStock, MedicineItem } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic } from '../utils/calculations.ts';
import {
  buildPrintableFromPurchasesGroup,
  type PrintableInvoiceConfig,
} from '../utils/invoicePrint.ts';

interface DraftPurchaseLine {
  tempId: string;
  barcode: string;
  medicineName: string;
  qty: number;
  unitPrice: number;
  expiryDate: string;
}

interface PurchasesTabProps {
  purchases: PurchaseItem[];
  medicines: MedicineItem[];
  stocks: Record<string, MedicineStock>;
  onAddPurchase: (purchase: Omit<PurchaseItem, 'id' | 'createdAt'>) => void;
  onAddPurchaseBatch?: (items: Array<Omit<PurchaseItem, 'id' | 'createdAt'>>) => void;
  onDeletePurchase: (id: string) => void;
  onOpenScanner: (callback: (code: string) => void) => void;
  onOpenCatalogModal?: () => void;
  onPrintInvoice?: (config: PrintableInvoiceConfig) => void;
  initialBarcode?: string | null;
  onClearInitialBarcode?: () => void;
}

export const PurchasesTab: React.FC<PurchasesTabProps> = ({
  purchases,
  medicines,
  stocks,
  onAddPurchase,
  onAddPurchaseBatch,
  onDeletePurchase,
  onOpenScanner,
  onOpenCatalogModal,
  onPrintInvoice,
  initialBarcode,
  onClearInitialBarcode,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSupplier, setSelectedSupplier] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grouped' | 'items'>('grouped');

  // Invoice header state (filled ONCE per invoice)
  const todayStr = new Date().toISOString().split('T')[0];
  const nextYearStr = new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0];

  const [date, setDate] = useState(todayStr);
  const [supplier, setSupplier] = useState('');
  const [notes, setNotes] = useState('');

  // Multi-item cart state
  const [invoiceItems, setInvoiceItems] = useState<DraftPurchaseLine[]>([]);

  // Current item entry inputs
  const [barcode, setBarcode] = useState('');
  const [medicineName, setMedicineName] = useState('');
  const [qty, setQty] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [expiryDate, setExpiryDate] = useState(nextYearStr);
  const [matchedFromSystem, setMatchedFromSystem] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Invoice-level payment state
  const [isPaidInFull, setIsPaidInFull] = useState(true);
  const [amountPaid, setAmountPaid] = useState('');

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const qtyInputRef = useRef<HTMLInputElement>(null);

  // Merge catalog medicines + stock items for instant lookup & autocomplete
  const catalogMap = React.useMemo(() => {
    const map = new Map<string, { barcode: string; name: string; lastPurchasePrice: number }>();
    for (const m of medicines) {
      const lastP = purchases.find((p) => p.barcode === m.barcode);
      map.set(m.barcode, {
        barcode: m.barcode,
        name: m.name,
        lastPurchasePrice: lastP?.unitPrice ?? stocks[m.barcode]?.averageCost ?? 0,
      });
    }
    for (const st of Object.values(stocks)) {
      if (!map.has(st.barcode)) {
        const lastP = purchases.find((p) => p.barcode === st.barcode);
        map.set(st.barcode, {
          barcode: st.barcode,
          name: st.name,
          lastPurchasePrice: lastP?.unitPrice ?? st.averageCost ?? 0,
        });
      }
    }
    return map;
  }, [medicines, stocks, purchases]);

  // If passed an initial barcode from Details screen
  React.useEffect(() => {
    if (initialBarcode) {
      handleSelectBarcode(initialBarcode);
      setShowAddModal(true);
      if (onClearInitialBarcode) onClearInitialBarcode();
    }
  }, [initialBarcode]);

  const handleSelectBarcode = (code: string) => {
    setBarcode(code);
    setFormError(null);
    const trimmed = code.trim();
    const found = catalogMap.get(trimmed);
    if (found) {
      setMedicineName(found.name);
      setMatchedFromSystem(true);
      if (found.lastPurchasePrice > 0) {
        setUnitPrice(String(found.lastPurchasePrice));
      }
      const lastP = purchases.find((p) => p.barcode === trimmed);
      if (lastP && !supplier) {
        setSupplier(lastP.supplier);
      }
      setTimeout(() => qtyInputRef.current?.focus(), 60);
    } else {
      setMatchedFromSystem(false);
    }
  };

  // Handle selecting medicine by name from quick dropdown
  const handleSelectMedicineByName = (val: string) => {
    setMedicineName(val);
    setFormError(null);
    // Check if matches any catalog item by name
    const match = Array.from(catalogMap.values()).find(
      (item) => item.name.toLowerCase() === val.trim().toLowerCase()
    );
    if (match) {
      setBarcode(match.barcode);
      setMatchedFromSystem(true);
      if (match.lastPurchasePrice > 0 && !unitPrice) {
        setUnitPrice(String(match.lastPurchasePrice));
      }
    }
  };

  // Add current line item to the multi-item invoice list
  const handleAddLineToInvoice = () => {
    if (!medicineName.trim()) {
      setFormError('يرجى مسح الباركود أو كتابة اسم المادة أولاً');
      return;
    }
    const q = Math.max(1, parseInt(qty, 10) || 0);
    const price = Math.max(0, parseFloat(unitPrice) || 0);
    if (q <= 0 || price <= 0) {
      setFormError('يرجى إدخال الكمية وسعر الشراء للوحدة بشكل صحيح');
      return;
    }
    if (!expiryDate) {
      setFormError('يرجى تحديد تاريخ الصلاحية للمادة');
      return;
    }

    const finalCode = barcode.trim() || `629${Date.now().toString().slice(-9)}`;

    setInvoiceItems((prev) => [
      ...prev,
      {
        tempId: `line-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        barcode: finalCode,
        medicineName: medicineName.trim(),
        qty: q,
        unitPrice: price,
        expiryDate,
      },
    ]);

    // Clear line inputs for the next item on the SAME invoice!
    setBarcode('');
    setMedicineName('');
    setQty('1');
    setUnitPrice('');
    setMatchedFromSystem(false);
    setFormError(null);
    setTimeout(() => barcodeInputRef.current?.focus(), 50);
  };

  const handleRemoveLine = (tempId: string) => {
    setInvoiceItems((prev) => prev.filter((item) => item.tempId !== tempId));
  };

  const handleUpdateLine = (
    tempId: string,
    field: 'qty' | 'unitPrice' | 'expiryDate',
    val: string
  ) => {
    setInvoiceItems((prev) =>
      prev.map((item) => {
        if (item.tempId !== tempId) return item;
        if (field === 'qty') return { ...item, qty: Math.max(1, parseInt(val, 10) || 1) };
        if (field === 'unitPrice') return { ...item, unitPrice: Math.max(0, parseFloat(val) || 0) };
        return { ...item, expiryDate: val };
      })
    );
  };

  // Pending draft item total if user hasn't clicked "إضافة للفاتورة +" yet
  const pendingDraftValid =
    medicineName.trim().length > 0 && (parseFloat(qty) || 0) > 0 && (parseFloat(unitPrice) || 0) > 0;
  const pendingDraftTotal = pendingDraftValid
    ? (parseFloat(qty) || 0) * (parseFloat(unitPrice) || 0)
    : 0;

  const cartItemsTotal = invoiceItems.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  const grandTotal = cartItemsTotal + (invoiceItems.length === 0 ? pendingDraftTotal : 0);

  React.useEffect(() => {
    if (isPaidInFull) {
      setAmountPaid(grandTotal > 0 ? String(grandTotal) : '');
    }
  }, [grandTotal, isPaidInFull]);

  const saveInvoiceInternal = (openPrintAfter: boolean) => {
    setFormError(null);

    if (!supplier.trim()) {
      setFormError('يرجى إدخال اسم المذخر / المورد في أعلى الفاتورة');
      return;
    }

    // Combine cart items + any valid item currently in the input boxes
    const finalLines: DraftPurchaseLine[] = [...invoiceItems];
    if (pendingDraftValid) {
      finalLines.push({
        tempId: `line-${Date.now()}`,
        barcode: barcode.trim() || `629${Date.now().toString().slice(-9)}`,
        medicineName: medicineName.trim(),
        qty: Math.max(1, parseInt(qty, 10) || 1),
        unitPrice: Math.max(0, parseFloat(unitPrice) || 0),
        expiryDate: expiryDate || nextYearStr,
      });
    }

    if (finalLines.length === 0) {
      setFormError('يرجى إضافة مادة واحدة على الأقل إلى الفاتورة');
      return;
    }

    const totalInvoiceSum = finalLines.reduce((sum, l) => sum + l.qty * l.unitPrice, 0);
    const totalPaid = isPaidInFull
      ? totalInvoiceSum
      : Math.min(totalInvoiceSum, Math.max(0, parseFloat(amountPaid) || 0));

    // Shared invoice batch code so items in the same invoice group cleanly
    const invoiceCode = `INV-${Date.now().toString().slice(-5)}`;
    const invoiceNote = notes.trim()
      ? `[${invoiceCode}] ${notes.trim()}`
      : finalLines.length > 1
      ? `[${invoiceCode}] قائمة مجمعة (${finalLines.length} مواد)`
      : undefined;

    let remainingPaidToAllocate = totalPaid;
    const payloads: Array<Omit<PurchaseItem, 'id' | 'createdAt'>> = finalLines.map((line, index) => {
      const lineTotal = line.qty * line.unitPrice;
      let linePaid = 0;
      if (isPaidInFull) {
        linePaid = lineTotal;
      } else if (index === finalLines.length - 1) {
        linePaid = Math.min(lineTotal, Math.max(0, remainingPaidToAllocate));
      } else if (totalInvoiceSum > 0) {
        linePaid = Math.min(
          lineTotal,
          Math.round((lineTotal / totalInvoiceSum) * totalPaid)
        );
        remainingPaidToAllocate -= linePaid;
      }

      return {
        date,
        supplier: supplier.trim(),
        barcode: line.barcode,
        medicineName: line.medicineName,
        qty: line.qty,
        unitPrice: line.unitPrice,
        totalAmount: lineTotal,
        expiryDate: line.expiryDate,
        amountPaid: linePaid,
        remainingUnpaid: Math.max(0, lineTotal - linePaid),
        notes: invoiceNote,
      };
    });

    if (onAddPurchaseBatch) {
      onAddPurchaseBatch(payloads);
    } else {
      payloads.forEach((p) => onAddPurchase(p));
    }

    if (openPrintAfter && onPrintInvoice) {
      const syntheticItems: PurchaseItem[] = payloads.map((p, idx) => ({
        ...p,
        id: `temp_p_${idx}`,
        createdAt: Date.now() + idx,
      }));
      onPrintInvoice(
        buildPrintableFromPurchasesGroup({
          date,
          supplier: supplier.trim(),
          invoiceTag: invoiceCode,
          items: syntheticItems,
          totalAmount: totalInvoiceSum,
          amountPaid: totalPaid,
        })
      );
    }

    // Reset modal
    setShowAddModal(false);
    setInvoiceItems([]);
    setBarcode('');
    setMedicineName('');
    setQty('1');
    setUnitPrice('');
    setAmountPaid('');
    setNotes('');
    setMatchedFromSystem(false);
    setFormError(null);
  };

  const handleSubmitInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    saveInvoiceInternal(false);
  };

  // Unique suppliers list for filter & autocomplete
  const suppliers = Array.from(new Set(purchases.map((p) => p.supplier))).filter(Boolean);

  // Filtered purchases
  const filtered = purchases
    .filter((p) => {
      const matchSearch =
        !searchQuery ||
        p.medicineName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.supplier.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.notes && p.notes.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchSupplier = selectedSupplier === 'all' || p.supplier === selectedSupplier;
      return matchSearch && matchSupplier;
    })
    .sort(
      (a, b) =>
        new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt
    );

  // Group filtered purchases into Unified Invoices (by invoice code or supplier + date + minute)
  const groupedInvoices = React.useMemo(() => {
    const groups = new Map<
      string,
      {
        groupKey: string;
        date: string;
        supplier: string;
        addedByName: string;
        invoiceTag?: string;
        items: PurchaseItem[];
        totalAmount: number;
        amountPaid: number;
        remainingUnpaid: number;
        latestCreatedAt: number;
      }
    >();

    for (const item of filtered) {
      const tagMatch = item.notes?.match(/^\[(INV-[A-Za-z0-9_-]+)\]/);
      const timeBucket = Math.floor((item.createdAt || 0) / 120000); // 2-minute window for same supplier+date
      const key = tagMatch
        ? `${item.supplier}_${item.date}_${tagMatch[1]}`
        : `${item.supplier}_${item.date}_${timeBucket}`;

      const existing = groups.get(key);
      if (existing) {
        existing.items.push(item);
        existing.totalAmount += item.totalAmount;
        existing.amountPaid += item.amountPaid;
        existing.remainingUnpaid += item.remainingUnpaid;
      } else {
        groups.set(key, {
          groupKey: key,
          date: item.date,
          supplier: item.supplier,
          addedByName: item.addedByName || 'مسؤول المخزن',
          invoiceTag: tagMatch ? tagMatch[1] : undefined,
          items: [item],
          totalAmount: item.totalAmount,
          amountPaid: item.amountPaid,
          remainingUnpaid: item.remainingUnpaid,
          latestCreatedAt: item.createdAt,
        });
      }
    }

    return Array.from(groups.values()).sort((a, b) => b.latestCreatedAt - a.latestCreatedAt);
  }, [filtered]);

  const totalFilteredPurchases = filtered.reduce((s, p) => s + p.totalAmount, 0);
  const totalFilteredPaid = filtered.reduce((s, p) => s + p.amountPaid, 0);
  const totalFilteredDebt = filtered.reduce((s, p) => s + p.remainingUnpaid, 0);

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <ShoppingCart className="h-6 w-6 text-teal-700" />
            سجل المشتريات وقوائم التوريد
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            إدخال قوائم شراء متعددة المواد على نفس الفاتورة مع قراءة الباركود والاسم تلقائياً
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onPrintInvoice && (
            <button
              type="button"
              onClick={() => {
                if (groupedInvoices.length > 0) {
                  onPrintInvoice(buildPrintableFromPurchasesGroup(groupedInvoices[0]));
                } else {
                  onPrintInvoice(
                    buildPrintableFromPurchasesGroup({
                      date: todayStr,
                      supplier: '',
                      items: [],
                      totalAmount: 0,
                      amountPaid: 0,
                    })
                  );
                }
              }}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 px-3.5 py-2.5 text-xs font-black transition active:scale-95"
            >
              <Printer className="h-4 w-4" />
              <span>طباعة طلبية / فاتورة</span>
            </button>
          )}

          {onOpenCatalogModal && (
            <button
              onClick={onOpenCatalogModal}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 px-3 py-2.5 text-xs font-black transition active:scale-95"
            >
              <PackagePlus className="h-4 w-4 text-teal-700" />
              <span>تعريف مواد</span>
            </button>
          )}

          <button
            onClick={() => {
              setDate(todayStr);
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2.5 text-xs font-black text-white shadow-xs hover:bg-teal-800 active:scale-98 transition"
          >
            <Plus className="h-4 w-4" />
            <span>قائمة شراء جديدة</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-white p-3 border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold text-slate-500">إجمالي المشتريات</div>
          <div className="text-sm sm:text-base font-black text-slate-900 mt-1">
            {formatIQD(totalFilteredPurchases)}
          </div>
        </div>
        <div className="rounded-xl bg-emerald-50/70 p-3 border border-emerald-200/70 shadow-xs">
          <div className="text-[11px] font-bold text-emerald-800">المدفوع كاش</div>
          <div className="text-sm sm:text-base font-black text-emerald-700 mt-1">
            {formatIQD(totalFilteredPaid)}
          </div>
        </div>
        <div className="rounded-xl bg-amber-50/70 p-3 border border-amber-200/70 shadow-xs">
          <div className="text-[11px] font-bold text-amber-800">دين للموردين</div>
          <div className="text-sm sm:text-base font-black text-amber-700 mt-1">
            {formatIQD(totalFilteredDebt)}
          </div>
        </div>
      </div>

      {/* Filter, Search & View Mode Bar */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث باسم الدواء، الباركود، أو المذخر..."
            className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pr-10 pl-3 text-xs placeholder:text-slate-400 focus:border-teal-500 focus:outline-hidden"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <select
          value={selectedSupplier}
          onChange={(e) => setSelectedSupplier(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-teal-500 focus:outline-hidden"
        >
          <option value="all">جميع الموردين والمذاخر ({suppliers.length})</option>
          {suppliers.map((sup) => (
            <option key={sup} value={sup}>
              {sup}
            </option>
          ))}
        </select>

        {/* View Toggle: Grouped Invoices vs Individual Items */}
        <div className="inline-flex rounded-xl bg-slate-200/80 p-1 shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('grouped')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'grouped'
                ? 'bg-white text-teal-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>كفواتير ({groupedInvoices.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode('items')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'items'
                ? 'bg-white text-teal-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <List className="h-3.5 w-3.5" />
            <span>بالمواد ({filtered.length})</span>
          </button>
        </div>
      </div>

      {/* Purchases List */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-400">
          <ShoppingCart className="mx-auto h-8 w-8 text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">لا توجد قوائم شراء مطابقة</p>
          <p className="text-xs text-slate-400 mt-1">
            اضغط على &quot;قائمة شراء جديدة (عدة مواد)&quot; لإضافة فاتورة شراء.
          </p>
        </div>
      ) : viewMode === 'grouped' ? (
        <div className="space-y-3">
          {groupedInvoices.map((inv) => (
            <div
              key={inv.groupKey}
              className="rounded-2xl bg-white border border-slate-200/90 shadow-xs overflow-hidden hover:border-teal-300 transition"
            >
              {/* Invoice Header */}
              <div className="bg-slate-50/90 px-4 py-3 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1 text-xs font-black text-teal-900">
                      <Building2 className="h-4 w-4 text-teal-700" />
                      {inv.supplier}
                    </span>
                    <span className="text-[11px] font-bold bg-teal-100 text-teal-800 px-2 py-0.5 rounded-md">
                      {inv.items.length} {inv.items.length === 1 ? 'مادة' : 'مواد'}
                    </span>
                    <span className="text-[10px] font-bold bg-slate-900 text-amber-300 px-2 py-0.5 rounded-md">
                      بواسطة: {inv.addedByName}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                    <Calendar className="h-3 w-3 text-slate-400" />
                    <span>تاريخ الفاتورة: {formatDateArabic(inv.date)}</span>
                    {inv.invoiceTag && (
                      <span className="font-mono text-[10px] text-slate-400">#{inv.invoiceTag}</span>
                    )}
                  </div>
                </div>

                <div className="text-left flex flex-col items-end gap-1.5">
                  <div className="text-base font-black font-mono text-slate-900">
                    {formatIQD(inv.totalAmount)}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 justify-end">
                    {inv.remainingUnpaid > 0 ? (
                      <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60">
                        باقي: {formatIQD(inv.remainingUnpaid)}
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        مدفوعة
                      </span>
                    )}
                    {onPrintInvoice && (
                      <button
                        type="button"
                        onClick={() => onPrintInvoice(buildPrintableFromPurchasesGroup(inv))}
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 px-2.5 py-1 text-[11px] font-black transition active:scale-95"
                        title="ترتيب الطلبية/الفاتورة واختيار الاسم وطباعتها"
                      >
                        <Printer className="h-3 w-3" />
                        <span>ترتيب وطباعة</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Invoice Line Items */}
              <div className="divide-y divide-slate-100 px-4 py-1">
                {inv.items.map((item) => (
                  <div
                    key={item.id}
                    className="py-2.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 truncate">
                          {item.medicineName}
                        </span>
                        <span className="font-mono text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          {item.barcode}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
                        <span>
                          الكمية: <strong className="text-slate-800">{item.qty}</strong> ×{' '}
                          {formatIQD(item.unitPrice)}
                        </span>
                        <span>•</span>
                        <span>
                          إكسباير: <strong className="font-mono">{formatDateArabic(item.expiryDate)}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-black text-slate-800">{formatIQD(item.totalAmount)}</span>
                      <button
                        onClick={() => onDeletePurchase(item.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded-lg hover:bg-rose-50 transition"
                        title="حذف هذه المادة من الفاتورة"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-teal-300 transition"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Barcode className="h-3 w-3 text-slate-400" />
                      {item.barcode}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-slate-400" />
                      {formatDateArabic(item.date)}
                    </span>
                    <span className="text-[10px] font-bold bg-slate-900 text-amber-300 px-2 py-0.5 rounded-md">
                      بواسطة: {item.addedByName || 'مسؤول المخزن'}
                    </span>
                  </div>
                  <h3 className="text-sm font-black text-slate-900 mt-1">{item.medicineName}</h3>
                  <p className="text-xs text-teal-800 font-semibold mt-0.5 flex items-center gap-1">
                    <Building2 className="h-3 w-3 text-teal-600" />
                    {item.supplier}
                  </p>
                </div>

                <div className="text-left">
                  <div className="text-base font-black text-slate-900">{formatIQD(item.totalAmount)}</div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {item.qty} باكيت × {formatIQD(item.unitPrice)}
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-slate-600">
                    الصلاحية:{' '}
                    <strong className="text-slate-900 font-mono">
                      {formatDateArabic(item.expiryDate)}
                    </strong>
                  </span>
                  {item.remainingUnpaid > 0 ? (
                    <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
                      باقي دين للمذخر: {formatIQD(item.remainingUnpaid)}
                    </span>
                  ) : (
                    <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                      مدفوع بالكامل (كاش)
                    </span>
                  )}
                </div>

                <button
                  onClick={() => onDeletePurchase(item.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition"
                  title="حذف الفاتورة"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Multi-Item Purchase Invoice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 p-0 sm:p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full sm:max-w-3xl max-h-[94vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-4 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-100 text-teal-800">
                  <ShoppingCart className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-base font-black text-slate-900">
                    إنشاء فاتورة شراء موحدة (عدة مواد بنفس القائمة)
                  </h2>
                  <p className="text-[11px] text-slate-500">
                    اختر المذخر مرة واحدة، ثم امسح باركود المواد تباعاً لإضافتها لنفس الفاتورة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-3 rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-bold text-rose-800 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitInvoice} className="space-y-4">
              {/* STEP 1: Invoice Header (Supplier & Date - filled ONCE) */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200/90 p-3.5 space-y-3">
                <div className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                  <Building2 className="h-4 w-4 text-teal-700" />
                  <span>1. بيانات المذخر والفاتورة (تُكتب مرة واحدة لجميع المواد)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-6">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      اسم المذخر / المورد *
                    </label>
                    <input
                      type="text"
                      list="suppliers-list"
                      required
                      value={supplier}
                      onChange={(e) => setSupplier(e.target.value)}
                      placeholder="مثال: مذخر الرشيد - السعدون"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                    <datalist id="suppliers-list">
                      {suppliers.map((s) => (
                        <option key={s} value={s} />
                      ))}
                    </datalist>
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      تاريخ الفاتورة *
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رقم القائمة / ملاحظة
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="مثال: قائمة رقم 405"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* STEP 2: Rapid Item Entry by Barcode / Catalog Lookup */}
              <div className="rounded-2xl bg-teal-50/60 border-2 border-teal-200/90 p-3.5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-xs font-black text-teal-950 flex items-center gap-1.5">
                    <Barcode className="h-4 w-4 text-teal-700" />
                    <span>2. إضافة مادة إلى الفاتورة (امسح الباركود ليقرأ الاسم والسعر تلقائياً)</span>
                  </div>

                  {matchedFromSystem && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 text-emerald-800 px-2.5 py-0.5 text-[11px] font-black">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      تم التعرف على المادة من النظام تلقائياً
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                  {/* Barcode Input + Camera */}
                  <div className="sm:col-span-5">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      الباركود (كاميرا / جهاز ليزر / يدوي)
                    </label>
                    <div className="flex gap-1.5">
                      <input
                        ref={barcodeInputRef}
                        type="text"
                        value={barcode}
                        onChange={(e) => handleSelectBarcode(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSelectBarcode(barcode);
                          }
                        }}
                        placeholder="امسح الباركود هنا..."
                        className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-mono font-bold focus:border-teal-600 focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          onOpenScanner((code) => {
                            handleSelectBarcode(code);
                          })
                        }
                        className="flex items-center gap-1 rounded-xl bg-teal-700 px-3 py-2 text-xs font-bold text-white hover:bg-teal-800 transition shrink-0"
                      >
                        <Camera className="h-4 w-4" />
                        <span>مسح</span>
                      </button>
                    </div>
                  </div>

                  {/* Medicine Name (Auto-filled from Barcode or selectable from list) */}
                  <div className="sm:col-span-7">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      اسم المادة / الدواء (يُقرأ تلقائياً أو اختر من القائمة) *
                    </label>
                    <input
                      type="text"
                      list="medicines-catalog-purchase"
                      value={medicineName}
                      onChange={(e) => handleSelectMedicineByName(e.target.value)}
                      placeholder="يظهر تلقائياً عند مسح الباركود أو اكتب الاسم..."
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                    <datalist id="medicines-catalog-purchase">
                      {Array.from(catalogMap.values()).map((m) => (
                        <option key={m.barcode} value={m.name}>
                          {m.barcode} - آخر سعر: {m.lastPurchasePrice}
                        </option>
                      ))}
                    </datalist>
                  </div>

                  {/* Quantity */}
                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      الكمية (العدد) *
                    </label>
                    <input
                      ref={qtyInputRef}
                      type="number"
                      min="1"
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                      placeholder="مثال: 50"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Unit Price */}
                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      سعر الشراء للمادة (د.ع) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      placeholder="مثال: 2250"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Expiry Date */}
                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      تاريخ الصلاحية *
                    </label>
                    <input
                      type="date"
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 bg-white px-2.5 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Add to Invoice Button */}
                  <div className="sm:col-span-3 flex items-end">
                    <button
                      type="button"
                      onClick={handleAddLineToInvoice}
                      className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 py-2 px-3 text-xs font-black shadow-xs transition active:scale-95"
                    >
                      <Plus className="h-4 w-4" />
                      <span>إضافة للقائمة +</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* STEP 3: Added Items Table in Current Invoice */}
              {invoiceItems.length > 0 && (
                <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
                  <div className="bg-slate-100 px-3.5 py-2 flex items-center justify-between text-xs font-black text-slate-800">
                    <span>مواد الفاتورة الحالية ({invoiceItems.length} مواد)</span>
                    <span className="text-teal-800">المجموع: {formatIQD(cartItemsTotal)}</span>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-52 overflow-y-auto">
                    {invoiceItems.map((line, idx) => (
                      <div
                        key={line.tempId}
                        className="p-3 sm:px-3.5 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <div className="font-black text-slate-900 truncate">
                              {idx + 1}. {line.medicineName}
                            </div>
                            <div className="font-mono text-[10px] text-slate-400">{line.barcode}</div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="font-black text-teal-900 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200/70">
                              {formatIQD(line.qty * line.unitPrice)}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleRemoveLine(line.tempId)}
                              className="text-rose-500 hover:bg-rose-50 p-1 rounded-lg"
                              title="إزالة من الفاتورة"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-12 gap-1.5 items-center">
                          <div className="col-span-3">
                            <label className="block text-[10px] text-slate-400 mb-0.5">الكمية</label>
                            <input
                              type="number"
                              min="1"
                              value={line.qty}
                              onChange={(e) => handleUpdateLine(line.tempId, 'qty', e.target.value)}
                              className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-bold"
                            />
                          </div>
                          <div className="col-span-4">
                            <label className="block text-[10px] text-slate-400 mb-0.5">السعر</label>
                            <input
                              type="number"
                              min="0"
                              value={line.unitPrice}
                              onChange={(e) =>
                                handleUpdateLine(line.tempId, 'unitPrice', e.target.value)
                              }
                              className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-bold"
                            />
                          </div>
                          <div className="col-span-5">
                            <label className="block text-[10px] text-slate-400 mb-0.5">الصلاحية</label>
                            <input
                              type="date"
                              value={line.expiryDate}
                              onChange={(e) =>
                                handleUpdateLine(line.tempId, 'expiryDate', e.target.value)
                              }
                              className="w-full rounded-lg border border-slate-200 px-1.5 py-1 text-[11px] font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 4: Invoice Grand Total & Payment */}
              <div className="rounded-2xl bg-slate-50 p-3.5 border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-bold">
                    إجمالي مبلغ الفاتورة الكلي ({invoiceItems.length || (pendingDraftValid ? 1 : 0)} مادة):
                  </span>
                  <span className="text-base font-black text-teal-900">
                    {formatIQD(grandTotal)}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/70">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isPaidInFull}
                      onChange={(e) => setIsPaidInFull(e.target.checked)}
                      className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 h-4 w-4"
                    />
                    الفاتورة مدفوعة بالكامل (نقداً كاش)
                  </label>
                </div>

                {!isPaidInFull && (
                  <div className="pt-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      المبلغ المدفوع نقداً من إجمالي الفاتورة (الباقي يُسجل دين للمذخر)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={grandTotal}
                      value={amountPaid}
                      onChange={(e) => setAmountPaid(e.target.value)}
                      placeholder="0 إذا كانت القائمة آجل بالكامل"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold focus:border-teal-600 focus:outline-hidden"
                    />
                    <div className="text-[11px] text-amber-700 font-bold mt-1">
                      المتبقي دين للمذخر:{' '}
                      {formatIQD(Math.max(0, grandTotal - (parseFloat(amountPaid) || 0)))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 rounded-xl bg-teal-700 py-3 px-3 text-xs font-black text-white shadow-sm hover:bg-teal-800 transition"
                >
                  <Check className="h-4 w-4 shrink-0" />
                  <span>
                    حفظ الفاتورة ({invoiceItems.length + (pendingDraftValid ? 1 : 0)})
                  </span>
                </button>
                {onPrintInvoice && (
                  <button
                    type="button"
                    onClick={() => saveInvoiceInternal(true)}
                    className="flex-1 min-w-[160px] flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 py-3 px-3 text-xs font-black text-amber-300 shadow-sm transition"
                  >
                    <Printer className="h-4 w-4 shrink-0" />
                    <span>حفظ وترتيب للطباعة</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl bg-slate-100 px-4 py-3 text-xs font-bold text-slate-600 hover:bg-slate-200 transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
