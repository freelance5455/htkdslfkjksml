import { useState } from 'react';
import { Plane, Calendar, Users, ArrowRightLeft, ShieldCheck, Briefcase, ChevronDown, CheckCircle, Clock, Mic, Sparkles } from 'lucide-react';
import { FlightOffer, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';
import { useSpeechRecognition } from '../../hooks/useSpeechRecognition';

interface FlightSearchScreenProps {
  flights: FlightOffer[];
  language: Language;
  currency: Currency;
  onBookFlight: (flight: FlightOffer) => void;
}

const CITY_AIRPORT_MAP: Record<string, { code: string; nameAr: string; nameEn: string; airportAr: string }> = {
  'الجزائر': { code: 'ALG', nameAr: 'الجزائر العاصمة', nameEn: 'Algiers', airportAr: 'مطار هواري بومدين الدولي' },
  'algiers': { code: 'ALG', nameAr: 'الجزائر العاصمة', nameEn: 'Algiers', airportAr: 'مطار هواري بومدين الدولي' },
  'alg': { code: 'ALG', nameAr: 'الجزائر العاصمة', nameEn: 'Algiers', airportAr: 'مطار هواري بومدين الدولي' },

  'إسطنبول': { code: 'IST', nameAr: 'إسطنبول', nameEn: 'Istanbul', airportAr: 'مطار إسطنبول الدولي' },
  'اسطنبول': { code: 'IST', nameAr: 'إسطنبول', nameEn: 'Istanbul', airportAr: 'مطار إسطنبول الدولي' },
  'istanbul': { code: 'IST', nameAr: 'إسطنبول', nameEn: 'Istanbul', airportAr: 'مطار إسطنبول الدولي' },
  'ist': { code: 'IST', nameAr: 'إسطنبول', nameEn: 'Istanbul', airportAr: 'مطار إسطنبول الدولي' },

  'باريس': { code: 'CDG', nameAr: 'باريس', nameEn: 'Paris', airportAr: 'مطار شارل ديغول الدولي' },
  'paris': { code: 'CDG', nameAr: 'باريس', nameEn: 'Paris', airportAr: 'مطار شارل ديغول الدولي' },
  'cdg': { code: 'CDG', nameAr: 'باريس', nameEn: 'Paris', airportAr: 'مطار شارل ديغول الدولي' },

  'دبي': { code: 'DXB', nameAr: 'دبي', nameEn: 'Dubai', airportAr: 'مطار دبي الدولي' },
  'dubai': { code: 'DXB', nameAr: 'دبي', nameEn: 'Dubai', airportAr: 'مطار دبي الدولي' },
  'dxb': { code: 'DXB', nameAr: 'دبي', nameEn: 'Dubai', airportAr: 'مطار دبي الدولي' },

  'مكة': { code: 'JED', nameAr: 'مكة المكرمة / جدة', nameEn: 'Mecca / Jeddah', airportAr: 'مطار الملك عبد العزيز الدولي' },
  'جدة': { code: 'JED', nameAr: 'جدة', nameEn: 'Jeddah', airportAr: 'مطار الملك عبد العزيز الدولي' },
  'jed': { code: 'JED', nameAr: 'جدة', nameEn: 'Jeddah', airportAr: 'مطار الملك عبد العزيز الدولي' },

  'الدوحة': { code: 'DOH', nameAr: 'الدوحة', nameEn: 'Doha', airportAr: 'مطار حمد الدولي' },
  'قطر': { code: 'DOH', nameAr: 'الدوحة', nameEn: 'Doha', airportAr: 'مطار حمد الدولي' },
  'doha': { code: 'DOH', nameAr: 'الدوحة', nameEn: 'Doha', airportAr: 'مطار حمد الدولي' },

  'القاهرة': { code: 'CAI', nameAr: 'القاهرة', nameEn: 'Cairo', airportAr: 'مطار القاهرة الدولي' },
  'cairo': { code: 'CAI', nameAr: 'القاهرة', nameEn: 'Cairo', airportAr: 'مطار القاهرة الدولي' },
};

export function FlightSearchScreen({ flights, language, currency, onBookFlight }: FlightSearchScreenProps) {
  const [tripType, setTripType] = useState<'round' | 'oneway'>('round');
  const [origin, setOrigin] = useState('ALG');
  const [originCity, setOriginCity] = useState('الجزائر (ALG)');
  const [destination, setDestination] = useState('IST');
  const [destinationCity, setDestinationCity] = useState('إسطنبول (IST)');
  const [departureDate, setDepartureDate] = useState('2026-12-12');
  const [returnDate, setReturnDate] = useState('2026-12-19');
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);
  const [selectedClass, setSelectedClass] = useState<'economy' | 'premium' | 'business' | 'first'>('economy');
  const [selectedFlight, setSelectedFlight] = useState<FlightOffer | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [activeVoiceTarget, setActiveVoiceTarget] = useState<'destination' | 'origin' | 'general' | null>(null);
  const [voiceNotice, setVoiceNotice] = useState<string>('');

  const t = translations[language];

  // Helper to find city in CITY_AIRPORT_MAP
  const findCityInMap = (term: string) => {
    const clean = term.toLowerCase().trim().replace(/[.,!؟?]/g, '');
    for (const [key, val] of Object.entries(CITY_AIRPORT_MAP)) {
      if (clean === key || clean.includes(key) || key.includes(clean)) {
        return val;
      }
    }
    return null;
  };

  // Speech Recognition Hook for Flight Destinations & Compound Routes
  const { isListening, startListening, stopListening } = useSpeechRecognition({
    language,
    onResult: (spokenText) => {
      const lower = spokenText.toLowerCase().trim();

      // Check compound route: "من X إلى Y", "from X to Y", "de X à Y"
      const arCompound = lower.match(/(?:من|من مطار)\s+([^\s]+(?:\s+[^\s]+)?)\s+(?:إلى|الى)\s+(.+)/);
      const enCompound = lower.match(/(?:from)\s+([^\s]+(?:\s+[^\s]+)?)\s+(?:to)\s+(.+)/);
      const frCompound = lower.match(/(?:de|d')\s+([^\s]+(?:\s+[^\s]+)?)\s+(?:à|a)\s+(.+)/);
      const compoundMatch = arCompound || enCompound || frCompound;

      if (compoundMatch) {
        const foundOrigin = findCityInMap(compoundMatch[1]);
        const foundDest = findCityInMap(compoundMatch[2]);
        if (foundOrigin) {
          setOrigin(foundOrigin.code);
          setOriginCity(`${foundOrigin.nameAr} (${foundOrigin.code})`);
        }
        if (foundDest) {
          setDestination(foundDest.code);
          setDestinationCity(`${foundDest.nameAr} (${foundDest.code})`);
        }
        if (foundOrigin || foundDest) {
          const originName = foundOrigin ? foundOrigin.nameAr : compoundMatch[1];
          const destName = foundDest ? foundDest.nameAr : compoundMatch[2];
          setVoiceNotice(
            language === 'ar'
              ? `تم تحديد المسار: ${originName} ➔ ${destName}`
              : `Route set: ${foundOrigin ? foundOrigin.nameEn : compoundMatch[1]} ➔ ${foundDest ? foundDest.nameEn : compoundMatch[2]}`
          );
          setTimeout(() => setVoiceNotice(''), 3500);
          setActiveVoiceTarget(null);
          return;
        }
      }

      // Single city check
      const foundCity = findCityInMap(lower);
      if (foundCity) {
        if (activeVoiceTarget === 'origin') {
          setOrigin(foundCity.code);
          setOriginCity(`${foundCity.nameAr} (${foundCity.code})`);
          setVoiceNotice(language === 'ar' ? `تم تحديد مطار المغادرة: ${foundCity.nameAr}` : `Origin set to: ${foundCity.nameEn}`);
        } else {
          setDestination(foundCity.code);
          setDestinationCity(`${foundCity.nameAr} (${foundCity.code})`);
          setVoiceNotice(language === 'ar' ? `تم تحديد وجهة الوصول: ${foundCity.nameAr}` : `Destination set to: ${foundCity.nameEn}`);
        }
      } else {
        // Fallback match flights from list
        const matchedFlight = flights.find(f =>
          f.toCity.toLowerCase().includes(lower) ||
          f.toAirport.toLowerCase().includes(lower)
        );
        if (matchedFlight) {
          setDestination(matchedFlight.toCode);
          setDestinationCity(`${matchedFlight.toCity} (${matchedFlight.toCode})`);
          setVoiceNotice(language === 'ar' ? `وجهة الرحلة: ${matchedFlight.toCity}` : `Flight to: ${matchedFlight.toCity}`);
        } else {
          if (activeVoiceTarget === 'origin') {
            setOriginCity(spokenText);
          } else {
            setDestinationCity(spokenText);
          }
          setVoiceNotice(language === 'ar' ? `تم تسجيل الصوت: "${spokenText}"` : `Heard: "${spokenText}"`);
        }
      }

      setTimeout(() => setVoiceNotice(''), 3500);
      setActiveVoiceTarget(null);
    },
  });

  const handleStartVoice = (target: 'destination' | 'origin') => {
    setActiveVoiceTarget(target);
    const demoFallbacks = target === 'destination' ? ['إسطنبول', 'باريس', 'دبي', 'الدوحة', 'من الجزائر إلى باريس'] : ['الجزائر', 'وهران', 'قسنطينة'];
    startListening(demoFallbacks);
  };

  const handleSwapAirports = () => {
    const tempCode = origin;
    const tempCity = originCity;
    setOrigin(destination);
    setOriginCity(destinationCity);
    setDestination(tempCode);
    setDestinationCity(tempCity);
  };

  // Filter flights by selected destination if user searches or speaks a destination
  const filteredFlights = flights.filter(f => {
    if (destination) {
      const matchDest = f.toCode.toLowerCase() === destination.toLowerCase() ||
        f.toCity.toLowerCase().includes(destination.toLowerCase());
      if (!matchDest) return false;
    }
    return true;
  });

  // Fallback to all flights if destination filter yields 0 so user is never stranded
  const displayFlights = filteredFlights.length > 0 ? filteredFlights : flights;

  const handleConfirmBooking = (flight: FlightOffer) => {
    onBookFlight(flight);
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedFlight(null);
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white">
            {t.flightSearchTitle}
          </h1>
          <p className="text-xs text-cyan-400 font-mono mt-0.5">
            Tourism By Taki Global Air Consolidator · Web Speech API
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setTripType('round')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              tripType === 'round' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.tripTypeRound}
          </button>
          <button
            onClick={() => setTripType('oneway')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              tripType === 'oneway' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.tripTypeOneWay}
          </button>
        </div>
      </div>

      {/* Instant Voice Search Command Bar */}
      <div className="p-3.5 rounded-3xl bg-gradient-to-r from-blue-950/80 via-slate-900 to-cyan-950/80 border border-cyan-400/40 flex flex-col gap-3 shadow-[0_0_25px_rgba(0,240,255,0.18)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30 shrink-0">
              <Mic className={`w-5 h-5 ${isListening ? 'animate-bounce text-rose-400' : 'text-cyan-400'}`} />
            </div>
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>{language === 'ar' ? 'البحث الصوتي الفوري عن الرحلات' : 'Voice Flight Search'}</span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-800">
                  Web Speech API
                </span>
              </p>
              <p className="text-[11px] text-slate-300 mt-0.5">
                {language === 'ar'
                  ? 'انقر وتحدث لتغيير وجهتك أو مسارك فوراً (مثال: "إسطنبول" أو "من الجزائر إلى باريس")'
                  : 'Speak a destination or full route (e.g. "From Algiers to Paris" or "Dubai")'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={() => isListening ? stopListening() : handleStartVoice('destination')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
                isListening && activeVoiceTarget === 'destination'
                  ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_#f43f5e]'
                  : 'bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white hover:brightness-110 active:scale-95'
              }`}
              aria-label="Trigger Voice Flight Search"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>
                {isListening && activeVoiceTarget === 'destination'
                  ? (language === 'ar' ? 'جاري الاستماع...' : 'Listening...')
                  : (language === 'ar' ? 'تحدث للبحث' : 'Speak Destination')}
              </span>
            </button>
          </div>
        </div>

        {/* Quick Voice Suggestions */}
        <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-cyan-500/15 text-[11px] text-slate-400">
          <span className="text-cyan-400 font-semibold flex items-center gap-1 text-[10px]">
            <Sparkles className="w-3 h-3" />
            {language === 'ar' ? 'أوامر صوتية سريعة:' : 'Quick Voice Queries:'}
          </span>
          {[
            {
              label: language === 'ar' ? 'من الجزائر إلى باريس' : 'Algiers to Paris',
              action: () => {
                setOrigin('ALG');
                setOriginCity('الجزائر العاصمة (ALG)');
                setDestination('CDG');
                setDestinationCity('باريس (CDG)');
                setVoiceNotice(language === 'ar' ? 'تم تحديد المسار: الجزائر ➔ باريس' : 'Route: Algiers ➔ Paris');
                setTimeout(() => setVoiceNotice(''), 3000);
              },
            },
            {
              label: language === 'ar' ? 'إسطنبول (IST)' : 'Istanbul (IST)',
              action: () => {
                setDestination('IST');
                setDestinationCity('إسطنبول (IST)');
                setVoiceNotice(language === 'ar' ? 'تم تحديد الوجهة: إسطنبول' : 'Destination: Istanbul');
                setTimeout(() => setVoiceNotice(''), 3000);
              },
            },
            {
              label: language === 'ar' ? 'دبي (DXB)' : 'Dubai (DXB)',
              action: () => {
                setDestination('DXB');
                setDestinationCity('دبي (DXB)');
                setVoiceNotice(language === 'ar' ? 'تم تحديد الوجهة: دبي' : 'Destination: Dubai');
                setTimeout(() => setVoiceNotice(''), 3000);
              },
            },
            {
              label: language === 'ar' ? 'الدوحة (DOH)' : 'Doha (DOH)',
              action: () => {
                setDestination('DOH');
                setDestinationCity('الدوحة (DOH)');
                setVoiceNotice(language === 'ar' ? 'تم تحديد الوجهة: الدوحة' : 'Destination: Doha');
                setTimeout(() => setVoiceNotice(''), 3000);
              },
            },
            {
              label: language === 'ar' ? 'مكة المكرمة (JED)' : 'Mecca (JED)',
              action: () => {
                setDestination('JED');
                setDestinationCity('مكة المكرمة / جدة (JED)');
                setVoiceNotice(language === 'ar' ? 'تم تحديد الوجهة: مكة المكرمة' : 'Destination: Mecca');
                setTimeout(() => setVoiceNotice(''), 3000);
              },
            },
          ].map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={chip.action}
              className="px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-400/50 text-slate-300 hover:text-cyan-300 transition-colors text-[10px]"
            >
              "{chip.label}"
            </button>
          ))}
        </div>
      </div>

      {/* Voice Status Alert if active */}
      {isListening && (
        <div className="p-3 rounded-2xl bg-gradient-to-r from-rose-950/60 to-cyan-950/60 border border-rose-500/40 text-white flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2.5 text-xs">
            <Mic className="w-4 h-4 text-rose-400 animate-bounce" />
            <span className="font-semibold">
              {language === 'ar'
                ? `جاري الاستماع لتحديد ${activeVoiceTarget === 'origin' ? 'مطار المغادرة' : 'وجهة السفر'}... (تحدث الآن)`
                : `Listening for ${activeVoiceTarget === 'origin' ? 'Origin' : 'Destination'}...`}
            </span>
          </div>
          <button
            onClick={stopListening}
            className="text-xs font-mono text-slate-300 hover:text-white underline"
          >
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </button>
        </div>
      )}

      {/* Voice feedback confirmation toast */}
      {voiceNotice && (
        <div className="p-2.5 rounded-xl bg-cyan-950/70 border border-cyan-400/40 text-cyan-300 text-xs flex items-center gap-2 animate-fade-in font-medium">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>{voiceNotice}</span>
        </div>
      )}

      {/* Search Input Box */}
      <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-500/20 space-y-4">
        {/* Origin & Destination Bar */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
          {/* Origin card with Voice Button */}
          <div className="md:col-span-2 bg-[#060c20] p-3.5 rounded-2xl border border-slate-800 relative group">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                {t.fromAirport}
              </span>
              <button
                type="button"
                onClick={() => handleStartVoice('origin')}
                className={`p-1.5 rounded-lg flex items-center gap-1 text-[10px] transition-colors ${
                  isListening && activeVoiceTarget === 'origin'
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'bg-slate-800 text-cyan-300 hover:bg-slate-700'
                }`}
                title="تحدث لتحديد مطار المغادرة"
                aria-label="Speak Origin Airport"
              >
                <Mic className="w-3 h-3" />
                <span className="hidden sm:inline">{language === 'ar' ? 'صوت' : 'Voice'}</span>
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-base font-bold text-white">{originCity}</p>
                <p className="text-[11px] text-slate-400 truncate">مطار هواري بومدين الدولي</p>
              </div>
              <span className="text-sm font-mono text-cyan-400 font-bold px-2 py-0.5 bg-cyan-950/60 rounded border border-cyan-800/60">
                {origin}
              </span>
            </div>
          </div>

          <div className="flex justify-center -my-2 md:my-0">
            <button
              onClick={handleSwapAirports}
              className="w-10 h-10 rounded-full bg-slate-800 border border-cyan-500/40 text-cyan-400 flex items-center justify-center hover:bg-slate-700 transition-transform active:scale-90"
              aria-label="Swap origins"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Destination card with Voice Button */}
          <div className="md:col-span-2 bg-[#060c20] p-3.5 rounded-2xl border border-slate-800 relative group">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                {t.toAirport}
              </span>
              <button
                type="button"
                onClick={() => handleStartVoice('destination')}
                className={`p-1.5 rounded-lg flex items-center gap-1 text-[10px] transition-colors ${
                  isListening && activeVoiceTarget === 'destination'
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 hover:bg-cyan-500/30'
                }`}
                title="تحدث لتحديد وجهة الوصول"
                aria-label="Speak Destination Airport"
              >
                <Mic className="w-3 h-3" />
                <span className="font-bold">{language === 'ar' ? 'تحدث للوجهة' : 'Voice'}</span>
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-base font-bold text-white">{destinationCity}</p>
                <p className="text-[11px] text-slate-400 truncate">مطار إسطنبول الدولي</p>
              </div>
              <span className="text-sm font-mono text-cyan-400 font-bold px-2 py-0.5 bg-cyan-950/60 rounded border border-cyan-800/60">
                {destination}
              </span>
            </div>
          </div>
        </div>

        {/* Dates & Passengers & Class */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Departure Date */}
          <div className="bg-[#060c20] p-3 rounded-2xl border border-slate-800">
            <label className="text-[10px] text-slate-400 block mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.departureDate}</span>
            </label>
            <input
              type="date"
              value={departureDate}
              onChange={e => setDepartureDate(e.target.value)}
              className="w-full bg-transparent text-xs text-white outline-none font-mono"
            />
          </div>

          {/* Return Date */}
          <div className={`bg-[#060c20] p-3 rounded-2xl border border-slate-800 ${tripType === 'oneway' ? 'opacity-40 pointer-events-none' : ''}`}>
            <label className="text-[10px] text-slate-400 block mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.returnDate}</span>
            </label>
            <input
              type="date"
              value={returnDate}
              onChange={e => setReturnDate(e.target.value)}
              disabled={tripType === 'oneway'}
              className="w-full bg-transparent text-xs text-white outline-none font-mono"
            />
          </div>

          {/* Passenger counter */}
          <div className="bg-[#060c20] p-3 rounded-2xl border border-slate-800">
            <label className="text-[10px] text-slate-400 block mb-1 flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t.passengers}</span>
            </label>
            <div className="flex items-center justify-between text-xs font-bold text-white">
              <span>{adults} بالغ {children > 0 ? `· ${children} أطفال` : ''}</span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setAdults(Math.max(1, adults - 1))}
                  className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-xs"
                >
                  -
                </button>
                <span className="w-4 text-center font-mono">{adults}</span>
                <button
                  type="button"
                  onClick={() => setAdults(adults + 1)}
                  className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-xs"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Cabin Class Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {(['economy', 'premium', 'business', 'first'] as const).map(c => (
            <button
              key={c}
              onClick={() => setSelectedClass(c)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                selectedClass === c
                  ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_12px_rgba(0,240,255,0.25)]'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {t[c]}
            </button>
          ))}
        </div>
      </div>

      {/* Flight Results Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <p className="text-xs text-slate-400">
            <span className="font-bold text-white font-mono">{displayFlights.length}</span> {t.flightResultsCount} ({origin} → {destination})
          </p>
          {filteredFlights.length !== flights.length && (
            <button
              onClick={() => {
                setDestination('');
                setDestinationCity(language === 'ar' ? 'جميع الوجهات' : 'All Destinations');
              }}
              className="text-[10px] text-cyan-400 hover:underline bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60"
            >
              {language === 'ar' ? 'إلغاء التصفية (عرض الكل)' : 'Show All'}
            </button>
          )}
        </div>
        <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/70 border border-cyan-800/80 px-2.5 py-0.5 rounded-full">
          Live Realtime Quotes
        </span>
      </div>

      {/* Flight Results Cards List */}
      <div className="space-y-3">
        {displayFlights.map(flight => (
          <div
            key={flight.id}
            className="glass-panel hover:border-cyan-400/40 rounded-3xl p-5 transition-all text-white relative group"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Airline header */}
              <div className="flex items-center justify-between md:justify-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-xl shrink-0">
                  {flight.airlineLogo}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-bold text-white">{flight.airline}</p>
                    <span className="text-[10px] font-mono text-slate-400">{flight.flightNumber}</span>
                  </div>
                  <p className="text-[11px] text-cyan-400 font-medium">
                    {flight.stops === 0 ? t.directFlight : t.oneStop} · {flight.duration}
                  </p>
                </div>
              </div>

              {/* Flight Times & Route Visualizer */}
              <div className="flex items-center justify-between md:justify-center gap-6 py-2 border-y md:border-y-0 border-slate-800/60">
                <div className="text-center">
                  <p className="text-lg font-black text-white font-mono">{flight.departureTime}</p>
                  <p className="text-[11px] font-bold text-slate-400">{flight.fromCode}</p>
                </div>

                <div className="flex-1 md:w-36 flex flex-col items-center">
                  <span className="text-[10px] text-slate-400 font-mono mb-1">{flight.duration}</span>
                  <div className="w-full flex items-center relative">
                    <div className="h-0.5 w-full bg-slate-700" />
                    <Plane className="w-3.5 h-3.5 text-cyan-400 absolute left-1/2 -translate-x-1/2 -top-1.5" />
                  </div>
                  <span className="text-[10px] text-emerald-400 mt-1 font-semibold">
                    {flight.stops === 0 ? 'مباشر بدون توقف' : 'ترانزيت 1'}
                  </span>
                </div>

                <div className="text-center">
                  <p className="text-lg font-black text-white font-mono">{flight.arrivalTime}</p>
                  <p className="text-[11px] font-bold text-slate-400">{flight.toCode}</p>
                </div>
              </div>

              {/* Price & Booking Button */}
              <div className="flex items-center justify-between md:flex-col md:items-end gap-2 shrink-0">
                <div>
                  <span className="text-[10px] text-slate-400 block md:text-left">{language === 'ar' ? 'السعر للشخص' : 'Price / person'}</span>
                  <p className="text-lg font-black text-cyan-300 font-mono">
                    {formatPrice(flight.basePriceDZD * adults, currency, language)}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedFlight(flight)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_15px_rgba(0,102,255,0.3)]"
                >
                  {t.bookFlight}
                </button>
              </div>
            </div>

            {/* Baggage & Policy tags */}
            <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-cyan-400" />
                <span>{flight.baggage}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{flight.refundable ? (language === 'ar' ? 'قابلة للاسترجاع والتغيير' : 'Refundable') : (language === 'ar' ? 'غير قابلة للاسترجاع' : 'Non-refundable')}</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Flight Detail & Confirmation Modal */}
      {selectedFlight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-elevated rounded-3xl p-6 max-w-md w-full border border-cyan-400/40 text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">{t.flightDetails}</h3>
                <p className="text-xs text-cyan-400 font-mono">{selectedFlight.airline} · {selectedFlight.flightNumber}</p>
              </div>
              <button
                onClick={() => setSelectedFlight(null)}
                className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            {bookingSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-white">
                  {language === 'ar' ? 'تم تأكيد حجز رحلتك بنجاح!' : 'Flight Booked Successfully!'}
                </h4>
                <p className="text-xs text-slate-300 max-w-xs mx-auto">
                  {language === 'ar' ? 'تمت إضافة التذكرة إلى محفظتك الإلكترونية وإرسال التأكيد إلى Tourism By Taki.' : 'Ticket added to your Travel Wallet and recorded in agency console.'}
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-2.5 text-xs">
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">{t.fromAirport}:</span>
                    <span className="font-semibold">{selectedFlight.fromCity} ({selectedFlight.fromCode})</span>
                  </div>
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">{t.toAirport}:</span>
                    <span className="font-semibold">{selectedFlight.toCity} ({selectedFlight.toCode})</span>
                  </div>
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">{t.passengers}:</span>
                    <span className="font-semibold">{adults} مسافر</span>
                  </div>
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">{language === 'ar' ? 'الدرجة' : 'Cabin'}:</span>
                    <span className="font-semibold capitalize text-cyan-300">{selectedFlight.cabinClass}</span>
                  </div>
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-cyan-500/30 flex justify-between text-sm">
                    <span className="font-bold text-white">{language === 'ar' ? 'المبلغ الإجمالي' : 'Total'}:</span>
                    <span className="font-black text-cyan-400 font-mono">
                      {formatPrice(selectedFlight.basePriceDZD * adults, currency, language)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleConfirmBooking(selectedFlight)}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all"
                >
                  {language === 'ar' ? 'تأكيد الحجز وإصدار التذكرة' : 'Confirm & Issue Ticket'}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
