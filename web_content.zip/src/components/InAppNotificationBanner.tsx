import React from 'react';
import { Sun, Moon, X, Clock, ChevronLeft, Check, Sparkles, Volume2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MORNING_ADHKAR, EVENING_ADHKAR } from '../data/adhkarData';

export const InAppNotificationBanner: React.FC = () => {
  const { 
    inAppAlert, 
    dismissInAppAlert, 
    snoozeInAppAlert, 
    openDhikr, 
    showToast 
  } = useApp();

  if (!inAppAlert) return null;

  const isMorning = inAppAlert.category === 'morning';

  const handleStartReading = () => {
    const list = isMorning ? MORNING_ADHKAR : EVENING_ADHKAR;
    dismissInAppAlert();
    openDhikr(list[0]);
    showToast(isMorning ? 'تقبل الله أذكار صباحك ☀️' : 'تقبل الله أذكار مساءك 🌙');
  };

  const handleSnooze = () => {
    snoozeInAppAlert(10);
    showToast('تم تأجيل التذكير لمدة 10 دقائق ⏰');
  };

  const handleDone = () => {
    dismissInAppAlert();
    showToast('بارك الله فيك وجعلها في ميزان حسناتك 🌿');
  };

  return (
    <div 
      className="fixed inset-x-0 top-3 z-50 flex justify-center px-3.5 pointer-events-none animate-in slide-in-from-top-4 duration-300 select-none"
      role="alert"
      aria-live="assertive"
    >
      <div className="w-full max-w-md pointer-events-auto bg-gradient-to-b from-[#03261b] via-[#042d20] to-[#021a12] border-2 border-emerald-500/60 dark:border-amber-500/50 rounded-3xl p-4.5 shadow-2xl shadow-black/60 ring-4 ring-emerald-500/20 text-right space-y-3.5">
        {/* Top Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-md ${
              isMorning 
                ? 'bg-gradient-to-br from-amber-500 to-amber-700 text-amber-100 ring-2 ring-amber-400/40' 
                : 'bg-gradient-to-br from-indigo-700 to-emerald-900 text-amber-200 ring-2 ring-emerald-400/40'
            }`}>
              {isMorning ? (
                <Sun className="w-6 h-6 animate-pulse" />
              ) : (
                <Moon className="w-6 h-6 animate-pulse fill-amber-200/30" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-900/80 text-amber-300 font-tajawal font-bold border border-emerald-700/60">
                  تنبيه الأذكار اليومي 🔔
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  {inAppAlert.time}
                </span>
              </div>
              <h3 className="text-base font-extrabold text-[#e8f5ee] font-cairo mt-0.5">
                {inAppAlert.title}
              </h3>
            </div>
          </div>

          <button
            onClick={dismissInAppAlert}
            className="p-1.5 rounded-full text-emerald-400/80 hover:text-white hover:bg-emerald-900/60 transition-colors cursor-pointer"
            aria-label="إغلاق التنبيه"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message Quotation */}
        <div className="p-3 rounded-2xl bg-[#021811]/70 border border-emerald-800/60 text-xs text-emerald-100/90 font-tajawal leading-relaxed">
          {inAppAlert.body}
        </div>

        {/* Actions Row */}
        <div className="flex items-center gap-2 pt-0.5">
          <button
            onClick={handleStartReading}
            className="flex-1 py-2.5 px-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-[#021811] font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer font-cairo"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#021811]" />
            <span>ابدأ القراءة الآن</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleSnooze}
            className="py-2.5 px-3 rounded-xl bg-[#062c20] hover:bg-[#093526] text-emerald-300 border border-emerald-700/60 font-bold text-xs font-cairo flex items-center gap-1.5 transition-colors cursor-pointer"
            title="تأجيل 10 دقائق"
          >
            <Clock className="w-3.5 h-3.5 text-amber-300" />
            <span>تأجيل ١٠ د</span>
          </button>

          <button
            onClick={handleDone}
            className="p-2.5 rounded-xl bg-emerald-900/50 hover:bg-emerald-800/60 text-emerald-300 border border-emerald-700/60 font-bold text-xs transition-colors cursor-pointer"
            title="تم الإنجاز"
            aria-label="تم الإنجاز"
          >
            <Check className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
