import React, { useState, useEffect } from 'react';
import { Target, Zap, TrendingUp, Flame, Snowflake } from 'lucide-react';
import { cyberAudio } from '../audio';
import { computePeriodId, getWingoColor } from '../data/servers';

export const NumberShotPredictor: React.FC = () => {
  const [period, setPeriod] = useState('');
  const [targetNumber, setTargetNumber] = useState<number>(7);
  const [alternateNumber, setAlternateNumber] = useState<number>(3);
  const [confidence, setConfidence] = useState<number>(98.5);

  // Probability distribution for 0 to 9
  const [probs, setProbs] = useState<{ num: number; prob: number }[]>([
    { num: 0, prob: 6 },
    { num: 1, prob: 9 },
    { num: 2, prob: 5 },
    { num: 3, prob: 28 },
    { num: 4, prob: 8 },
    { num: 5, prob: 7 },
    { num: 6, prob: 4 },
    { num: 7, prob: 44 },
    { num: 8, prob: 12 },
    { num: 9, prob: 15 },
  ]);

  useEffect(() => {
    const update = () => {
      const now = Date.now();
      const p = computePeriodId(now, '30s');
      setPeriod(p);

      // Generate realistic hot numbers
      const seed = Number(p.slice(-4)) || 1234;
      const tNum = (seed * 7 + 3) % 10;
      const aNum = (seed * 3 + 1) % 10;
      setTargetNumber(tNum);
      setAlternateNumber(aNum === tNum ? (tNum + 1) % 10 : aNum);
      setConfidence(97 + (seed % 3));

      // Build probability weights
      const newProbs = Array.from({ length: 10 }, (_, i) => {
        if (i === tNum) return { num: i, prob: 45 };
        if (i === aNum) return { num: i, prob: 28 };
        return { num: i, prob: Math.max(3, (seed * (i + 1)) % 14) };
      });
      setProbs(newProbs);
    };

    update();
    const interval = setInterval(update, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col flex-1 w-full max-w-md mx-auto p-3 space-y-3 select-none pb-24">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-[#2c1a02] via-[#3a2304] to-[#1e1102] border border-amber-500/40 p-4 shadow-[0_4px_20px_rgba(234,179,8,0.2)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white tracking-wider">NUMBER SHOT HACK</h2>
              <span className="text-[10px] text-amber-300 font-mono">VTRX 10-NODE DIRECT HIT ALGORITHM</span>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950/60 px-2 py-1 rounded-lg border border-amber-500/30">
            #{period.slice(-4) || '---'}
          </span>
        </div>
      </div>

      {/* Main Target Shot Card */}
      <div className="p-4 rounded-2xl bg-[#0e0a02] border border-amber-500/50 shadow-[0_0_25px_rgba(245,158,11,0.15)] flex flex-col items-center">
        <span className="text-[10px] font-mono font-bold text-amber-300 uppercase tracking-widest mb-2">
          🎯 PRIMARY DIRECT SHOT NUMBER
        </span>

        <div className="flex items-center gap-4 my-2">
          {/* Primary Target */}
          <div className="flex flex-col items-center">
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 rounded-3xl bg-amber-500/30 blur-md animate-pulse" />
              <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-600 via-yellow-500 to-amber-300 border-2 border-yellow-200 text-black flex items-center justify-center text-4xl font-black shadow-[0_4px_25px_rgba(245,158,11,0.7)]">
                {targetNumber}
              </div>
            </div>
            <span className="text-[10px] font-bold text-amber-300 font-mono mt-1.5">SURE SHOT</span>
          </div>

          {/* Secondary Backup */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-stone-800 to-stone-700 border border-amber-500/40 text-amber-300 flex items-center justify-center text-2xl font-bold">
              {alternateNumber}
            </div>
            <span className="text-[10px] font-mono text-slate-400 mt-1">BACKUP</span>
          </div>
        </div>

        <div className="w-full mt-3 p-2.5 rounded-xl bg-black/60 border border-amber-500/30 flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">STRIKE PROBABILITY:</span>
          <span className="font-black text-amber-400">{confidence}% CONVERGENCE</span>
        </div>
      </div>

      {/* 0 to 9 Probability Distribution Bars */}
      <div className="p-3.5 rounded-2xl bg-[#0a0701] border border-amber-900/60 shadow-md space-y-2">
        <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5" />
          NEURAL DENSITY DISTRIBUTION (0-9)
        </span>

        <div className="space-y-1.5 pt-1">
          {probs.map((p) => {
            const isTarget = p.num === targetNumber;
            return (
              <div key={p.num} className="flex items-center gap-2 text-xs font-mono">
                <span
                  className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                    isTarget
                      ? 'bg-amber-400 text-black shadow-[0_0_8px_#f59e0b]'
                      : 'bg-black/80 text-slate-300 border border-amber-950'
                  }`}
                >
                  {p.num}
                </span>

                <div className="flex-1 h-3 rounded-full bg-black/80 border border-amber-950 overflow-hidden relative">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isTarget
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-400 shadow-[0_0_8px_#fbbf24]'
                        : 'bg-amber-800/40'
                    }`}
                    style={{ width: `${Math.min(100, p.prob * 2)}%` }}
                  />
                </div>

                <span className={`w-8 text-right font-bold text-[10px] ${isTarget ? 'text-amber-400' : 'text-slate-500'}`}>
                  {p.prob}%
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hot & Cold Numbers Analytics */}
      <div className="grid grid-cols-2 gap-2">
        <div className="p-3 rounded-xl bg-red-950/20 border border-red-500/30 flex items-center gap-2.5">
          <Flame className="w-5 h-5 text-red-400 shrink-0" />
          <div>
            <span className="text-[10px] text-red-300 font-bold block">HOT NUMBERS</span>
            <span className="text-xs font-mono font-black text-white">3, 7, 9</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-blue-950/20 border border-blue-500/30 flex items-center gap-2.5">
          <Snowflake className="w-5 h-5 text-cyan-400 shrink-0" />
          <div>
            <span className="text-[10px] text-cyan-300 font-bold block">COLD NUMBERS</span>
            <span className="text-xs font-mono font-black text-white">0, 4, 6</span>
          </div>
        </div>
      </div>
    </div>
  );
};
export default NumberShotPredictor;
