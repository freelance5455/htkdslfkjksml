import React, { useState } from 'react';
import { Lock, ShieldCheck, X, Delete } from 'lucide-react';

interface PinVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  correctPin: string;
  title?: string;
  subtitle?: string;
  amountToAuthorize?: number;
}

export const PinVerificationModal: React.FC<PinVerificationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  correctPin,
  title = 'Masukkan PIN Keamanan',
  subtitle = 'Otorisasi transaksi Anda dengan 6-digit PIN',
  amountToAuthorize,
}) => {
  const [pin, setPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isShaking, setIsShaking] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    if (pin.length < 6) {
      const nextPin = pin + num;
      setPin(nextPin);
      setErrorMsg('');

      if (nextPin.length === 6) {
        // Auto verify
        if (nextPin === correctPin) {
          setTimeout(() => {
            setPin('');
            onSuccess();
          }, 200);
        } else {
          setIsShaking(true);
          setErrorMsg('PIN salah. Silakan coba lagi.');
          setTimeout(() => {
            setIsShaking(false);
            setPin('');
          }, 600);
        }
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden ${
          isShaking ? 'animate-shake' : ''
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <div className="flex items-center gap-2 text-emerald-600 font-semibold text-xs tracking-wider uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Verifikasi Keamanan</span>
          </div>
          <button
            onClick={() => {
              setPin('');
              setErrorMsg('');
              onClose();
            }}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 pb-6 text-center">
          <div className="w-12 h-12 mx-auto mb-3 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
            <Lock className="w-6 h-6" />
          </div>

          <h3 className="text-lg font-bold text-slate-900">{title}</h3>
          <p className="text-xs text-slate-500 mt-1">{subtitle}</p>

          {amountToAuthorize !== undefined && (
            <div className="my-3 py-2 px-3 bg-slate-50 rounded-xl text-center border border-slate-100">
              <span className="text-xs text-slate-500">Total Transaksi: </span>
              <span className="text-sm font-bold text-slate-900">
                {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(
                  amountToAuthorize
                )}
              </span>
            </div>
          )}

          {/* PIN Dots */}
          <div className="flex justify-center items-center gap-3 my-6">
            {[0, 1, 2, 3, 4, 5].map((idx) => {
              const isFilled = pin.length > idx;
              return (
                <div
                  key={idx}
                  className={`w-4 h-4 rounded-full transition-all duration-200 ${
                    isFilled
                      ? 'bg-emerald-600 scale-110 shadow-sm shadow-emerald-600/30'
                      : 'border-2 border-slate-300 bg-transparent'
                  }`}
                />
              );
            })}
          </div>

          {errorMsg ? (
            <p className="text-xs font-medium text-rose-500 mb-2 h-4">{errorMsg}</p>
          ) : (
            <p className="text-xs text-slate-400 mb-2 h-4">
              PIN Default: <span className="font-semibold text-slate-600">{correctPin}</span>
            </p>
          )}

          {/* Numeric Keypad */}
          <div className="grid grid-cols-3 gap-2 max-w-[260px] mx-auto mt-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
              <button
                key={digit}
                type="button"
                onClick={() => handleKeyPress(digit)}
                className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 font-bold text-lg transition-colors flex items-center justify-center select-none shadow-sm border border-slate-100"
              >
                {digit}
              </button>
            ))}

            <button
              type="button"
              onClick={handleClear}
              className="h-12 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 hover:bg-slate-100 active:bg-slate-200 transition-colors flex items-center justify-center select-none"
            >
              Hapus
            </button>

            <button
              type="button"
              onClick={() => handleKeyPress('0')}
              className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 font-bold text-lg transition-colors flex items-center justify-center select-none shadow-sm border border-slate-100"
            >
              0
            </button>

            <button
              type="button"
              onClick={handleDelete}
              className="h-12 rounded-xl text-slate-600 hover:bg-slate-100 active:bg-slate-200 transition-colors flex items-center justify-center select-none"
              aria-label="Hapus digit"
            >
              <Delete className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
