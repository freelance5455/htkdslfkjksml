interface VRCardboardMaskProps {
  className?: string;
}

export function VRCardboardMask({ className = '' }: VRCardboardMaskProps) {
  return (
    <div className={`vr-cardboard-mask-overlay ${className}`} aria-hidden="true">
      <svg
        className="vr-cardboard-mask-svg"
        viewBox="0 0 1000 562.5"
        preserveAspectRatio="none"
      >
        {/* Pitch black background with two barrel-distorted lens apertures cut out */}
        <path
          fill="#000000"
          fillRule="evenodd"
          d="
            M 0 0 H 1000 V 562.5 H 0 Z

            M 85 96
            Q 275 66 470 96
            Q 486 102 489 116
            Q 504 300 489 486
            Q 486 500 470 506
            Q 275 536 85 506
            Q 69 500 66 486
            Q 51 300 66 116
            Q 69 102 85 96 Z

            M 530 96
            Q 725 66 915 96
            Q 931 102 934 116
            Q 949 300 934 486
            Q 931 500 915 506
            Q 725 536 530 506
            Q 514 500 511 486
            Q 496 300 511 116
            Q 514 102 530 96 Z
          "
        />
        {/* Center white alignment guide line at the bottom (Google Cardboard nose divider) */}
        <line
          x1="500"
          y1="562.5"
          x2="500"
          y2="362"
          stroke="#ffffff"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}
