import React, { useState, useMemo } from 'react';
import {
  Image as ImageIcon,
  Search,
  Filter,
  Maximize2,
  Calendar,
  FileText,
  Wrench,
  Layers,
  ArrowRight,
  ArrowLeft,
  Home
} from 'lucide-react';
import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';

interface Props {
  paintingReports: PaintingReport[];
  maintenanceReports: MaintenanceReport[];
  procedureReports: ProcedureReport[];
  onOpenPhotoLightbox: (url: string, caption: string, title: string, tag?: string) => void;
  onNavigateToPainting: (report: PaintingReport) => void;
  onNavigateToMaintenance: (report: MaintenanceReport) => void;
  onNavigateToProcedure: (report: ProcedureReport) => void;
  onBackToMenu?: () => void;
}

interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  tag: string;
  category: 'Painting Report' | 'Manutenzione Impianti' | 'Specifica / Procedura';
  title: string;
  date: string;
  parentObj: PaintingReport | MaintenanceReport | ProcedureReport;
}

export const UnifiedPhotoGallery: React.FC<Props> = ({
  paintingReports,
  maintenanceReports,
  procedureReports,
  onOpenPhotoLightbox,
  onNavigateToPainting,
  onNavigateToMaintenance,
  onNavigateToProcedure,
  onBackToMenu
}) => {
  const [sourceFilter, setSourceFilter] = useState<'all' | 'painting' | 'maintenance' | 'procedure'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const allPhotos: GalleryItem[] = useMemo(() => {
    const list: GalleryItem[] = [];

    // Photos from Painting Reports
    paintingReports.forEach((pr) => {
      pr.images.forEach((img) => {
        list.push({
          id: img.id,
          url: img.url,
          caption: img.caption,
          tag: img.stage,
          category: 'Painting Report',
          title: `${pr.reportNumber} · ${pr.client}`,
          date: pr.date,
          parentObj: pr
        });
      });
    });

    // Photos from Maintenance Reports
    maintenanceReports.forEach((mr) => {
      mr.images.forEach((img) => {
        list.push({
          id: img.id,
          url: img.url,
          caption: img.caption,
          tag: img.tag,
          category: 'Manutenzione Impianti',
          title: `${mr.plantName} · ${mr.equipmentServiced || 'Manutenzione'}`,
          date: mr.date,
          parentObj: mr
        });
      });
    });

    // Photos from Procedure Reports (Procedure & Schede Libere)
    procedureReports.forEach((proc) => {
      if (proc.blocks && proc.blocks.length > 0) {
        proc.blocks.forEach((block, bIdx) => {
          if (block.type === 'photo' && block.photoUrl) {
            list.push({
              id: block.id,
              url: block.photoUrl,
              caption: block.photoCaption || `Evidenza #${bIdx + 1}`,
              tag: block.photoTag || 'Scheda Libera',
              category: 'Specifica / Procedura',
              title: `${proc.code} · ${proc.title}`,
              date: proc.date,
              parentObj: proc
            });
          }
        });
      } else if (proc.steps) {
        proc.steps.forEach((step) => {
          (step.images || []).forEach((img) => {
            list.push({
              id: img.id,
              url: img.url,
              caption: img.caption,
              tag: img.tag || `Passo ${step.stepNumber}`,
              category: 'Specifica / Procedura',
              title: `${proc.code} · ${step.title}`,
              date: proc.date,
              parentObj: proc
            });
          });
        });
      }
    });

    return list;
  }, [paintingReports, maintenanceReports, procedureReports]);

  const filteredPhotos = allPhotos.filter((item) => {
    if (sourceFilter === 'painting' && item.category !== 'Painting Report') return false;
    if (sourceFilter === 'maintenance' && item.category !== 'Manutenzione Impianti') return false;
    if (sourceFilter === 'procedure' && item.category !== 'Specifica / Procedura') return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.caption.toLowerCase().includes(q) ||
        item.title.toLowerCase().includes(q) ||
        item.tag.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-4 pb-16 sm:pb-0">
      {/* Mobile Top Back Banner for Google Pixel 9 */}
      {onBackToMenu && (
        <div className="flex items-center justify-between bg-neutral-900 text-white px-3.5 py-2.5 rounded-2xl shadow-sm md:hidden">
          <button
            onClick={onBackToMenu}
            className="inline-flex items-center gap-2 text-xs font-bold hover:text-amber-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Torna al Menù Principale</span>
          </button>
          <span className="text-[10px] font-mono text-neutral-400">Google Pixel 9</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-900">
            Archivio Fotografico Aziendale
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Rilievi visivi di sabbiatura SA 2.5, rugosità, prove spessore film secco DFT e interventi di manutenzione
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-neutral-200 rounded-lg p-3 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-2.5">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cerca fotografie per didascalia, commessa, impianto o fase..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-900"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setSourceFilter('all')}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                sourceFilter === 'all'
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              Tutte ({allPhotos.length})
            </button>

            <button
              onClick={() => setSourceFilter('painting')}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                sourceFilter === 'painting'
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Solo Painting Report</span>
            </button>

            <button
              onClick={() => setSourceFilter('maintenance')}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                sourceFilter === 'maintenance'
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>Solo Manutenzioni</span>
            </button>

            <button
              onClick={() => setSourceFilter('procedure')}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                sourceFilter === 'procedure'
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Specifiche & Procedure</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Photos */}
      {filteredPhotos.length === 0 ? (
        <div className="p-12 bg-white border border-neutral-200 rounded-lg text-center space-y-2">
          <ImageIcon className="w-8 h-8 text-neutral-400 mx-auto" />
          <h3 className="text-xs font-semibold text-neutral-900">
            Nessuna fotografia corrisponde ai filtri selezionati
          </h3>
          <p className="text-[11px] text-neutral-500">
            Carica fotografie all&apos;interno dei Painting Report, delle schede di manutenzione o delle specifiche di lavorazione.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredPhotos.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-neutral-200 rounded-lg overflow-hidden group hover:border-neutral-400 transition-all flex flex-col justify-between"
            >
              {/* Photo */}
              <div
                className="relative aspect-4/3 bg-neutral-100 overflow-hidden cursor-pointer"
                onClick={() => onOpenPhotoLightbox(item.url, item.caption, item.title, item.tag)}
              >
                <img
                  src={item.url}
                  alt={item.caption || item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                />

                <div className="absolute top-2 left-2 text-[10px] font-semibold text-white bg-black/70 px-2 py-0.5 rounded backdrop-blur-xs">
                  {item.tag}
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenPhotoLightbox(item.url, item.caption, item.title, item.tag);
                  }}
                  className="absolute top-2 right-2 w-7 h-7 rounded bg-black/70 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Information */}
              <div className="p-3 space-y-2 text-xs flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 text-[10px] font-semibold text-neutral-500 mb-0.5">
                    {item.category === 'Painting Report' && (
                      <span className="text-blue-700 flex items-center gap-1 font-semibold">
                        <FileText className="w-3 h-3" />
                        Painting Report
                      </span>
                    )}
                    {item.category === 'Manutenzione Impianti' && (
                      <span className="text-amber-700 flex items-center gap-1 font-semibold">
                        <Wrench className="w-3 h-3" />
                        Manutenzione
                      </span>
                    )}
                    {item.category === 'Specifica / Procedura' && (
                      <span className="text-emerald-700 flex items-center gap-1 font-semibold">
                        <Layers className="w-3 h-3" />
                        Specifica Modulare
                      </span>
                    )}
                    <span>·</span>
                    <span className="font-mono">{item.date}</span>
                  </div>

                  <h4 className="font-semibold text-neutral-900 line-clamp-1">
                    {item.title}
                  </h4>

                  <p className="text-[11px] text-neutral-600 line-clamp-2 mt-1">
                    {item.caption || 'Nessuna didascalia'}
                  </p>
                </div>

                <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-[11px]">
                  <button
                    onClick={() => {
                      if (item.category === 'Painting Report') {
                        onNavigateToPainting(item.parentObj as PaintingReport);
                      } else if (item.category === 'Manutenzione Impianti') {
                        onNavigateToMaintenance(item.parentObj as MaintenanceReport);
                      } else {
                        onNavigateToProcedure(item.parentObj as ProcedureReport);
                      }
                    }}
                    className="inline-flex items-center gap-1 text-neutral-900 font-bold hover:underline"
                  >
                    <span>Apri Scheda</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Google Pixel 9 Mobile Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-neutral-200 p-2 sm:hidden z-40 flex items-center justify-around gap-1 shadow-lg">
        {onBackToMenu && (
          <button
            onClick={onBackToMenu}
            className="flex flex-col items-center justify-center py-1 px-3 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
          >
            <Home className="w-4 h-4 mb-0.5" />
            <span>Menù</span>
          </button>
        )}
        <button
          onClick={() => {
            if (paintingReports[0]) onNavigateToPainting(paintingReports[0]);
          }}
          className="flex flex-col items-center justify-center py-1 px-3 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
        >
          <FileText className="w-4 h-4 mb-0.5" />
          <span>Painting</span>
        </button>
        <button
          onClick={() => {
            if (maintenanceReports[0]) onNavigateToMaintenance(maintenanceReports[0]);
          }}
          className="flex flex-col items-center justify-center py-1 px-3 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
        >
          <Wrench className="w-4 h-4 mb-0.5" />
          <span>Manutenz.</span>
        </button>
        <button
          onClick={() => {
            if (procedureReports[0]) onNavigateToProcedure(procedureReports[0]);
          }}
          className="flex flex-col items-center justify-center py-1 px-3 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
        >
          <Layers className="w-4 h-4 mb-0.5" />
          <span>Specifiche</span>
        </button>
      </div>
    </div>
  );
};
