import React, { useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import { NICAS_LEVEL_TITLES, NICASLevelNumber } from '../types/climbing';
import {
  Printer,
  X,
  ShieldCheck,
  CheckCircle2,
  FileText,
  ListOrdered,
  Award,
  Layers,
  FileCheck2
} from 'lucide-react';

export type ReportType = 'dossier' | 'climbs' | 'checklist' | 'master';

interface PrintableLogbookProps {
  isOpen: boolean;
  onClose: () => void;
  defaultReport?: ReportType;
}

export const PrintableLogbook: React.FC<PrintableLogbookProps> = ({
  isOpen,
  onClose,
  defaultReport = 'dossier'
}) => {
  const { profile, climbs, checklist, clubs, getClubById } = useClimbing();
  const [selectedReport, setSelectedReport] = useState<ReportType>(defaultReport);
  const [targetLevelFilter, setTargetLevelFilter] = useState<number | 'all'>('all');

  if (!isOpen) return null;

  const homeClub = getClubById(profile.homeClubId);
  const totalClimbs = climbs.length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[94vh] flex flex-col border border-slate-200 overflow-hidden">
        {/* Controls Toolbar (Hidden when printing) */}
        <div className="no-print px-4 sm:px-6 py-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-orange-600 shrink-0" />
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900">
                Official NICAS PDF Reports Generator
              </h2>
              <span className="text-[11px] text-slate-500">
                Candidate: {profile.candidateName || 'Unnamed Candidate'} ({profile.candidateNumber || 'Unassigned'})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            {/* Report Type Selector */}
            <select
              value={selectedReport}
              onChange={e => setSelectedReport(e.target.value as ReportType)}
              className="text-xs font-semibold px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="dossier">Report: Candidate Summary Dossier</option>
              <option value="climbs">Report: Complete Climbs Log Ledger</option>
              <option value="checklist">Report: NICAS Syllabus & Checklist</option>
              <option value="master">Report: Full All-in-One Master Portfolio</option>
            </select>

            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document View */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 font-sans text-slate-900 space-y-6 bg-white text-xs">
          {/* Universal Official NICAS Header on all reports */}
          <div className="border-b-2 border-slate-900 pb-4 flex flex-col sm:flex-row justify-between items-start gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-2xl tracking-tight text-slate-900">NICAS</span>
                <span className="text-[11px] font-bold text-orange-800 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded">
                  National Indoor Climbing Award Scheme (UK)
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1 uppercase tracking-wider font-semibold">
                {selectedReport === 'dossier' && 'Official Candidate Progress Dossier'}
                {selectedReport === 'climbs' && 'Verified Ascent Logbook Ledger'}
                {selectedReport === 'checklist' && 'NICAS 5-Level Competency Syllabus Checklist'}
                {selectedReport === 'master' && 'Complete All-in-One Candidate Portfolio'}
              </p>
            </div>
            <div className="text-right text-xs font-mono">
              <div className="font-bold text-slate-900">NICAS ID: {profile.candidateNumber || 'Pending'}</div>
              <div className="text-slate-500">Date Issued: {new Date().toLocaleDateString('en-GB')}</div>
            </div>
          </div>

          {/* Universal Candidate Dossier Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-500 block text-[11px]">Candidate Name</span>
              <span className="font-bold text-slate-900 text-sm">{profile.candidateName || '—'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Age & DOB</span>
              <span className="font-bold text-slate-900 text-sm">
                {profile.age ? `${profile.age} yrs` : '—'} {profile.dateOfBirth ? `(${profile.dateOfBirth})` : ''}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Home Climbing Centre</span>
              <span className="font-bold text-slate-900 text-sm truncate block">{homeClub?.name || 'Unassigned'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Current / Target Level</span>
              <span className="font-bold text-orange-800 text-sm">
                Level {profile.currentLevel} (Target: Level {profile.targetLevel})
              </span>
            </div>
            {profile.emergencyContactName && (
              <div className="col-span-2 pt-1 border-t border-slate-200">
                <span className="text-slate-500 text-[10px]">Emergency Contact:</span>{' '}
                <span className="font-semibold text-slate-800">{profile.emergencyContactName} ({profile.emergencyContactPhone || '—'})</span>
              </div>
            )}
            {profile.medicalNotes && (
              <div className="col-span-2 pt-1 border-t border-slate-200">
                <span className="text-slate-500 text-[10px]">Medical / Notes:</span>{' '}
                <span className="italic text-slate-700">{profile.medicalNotes}</span>
              </div>
            )}
          </div>

          {/* REPORT 1: DOSSIER VIEW */}
          {(selectedReport === 'dossier' || selectedReport === 'master') && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1">
                Scheme Level Progress Summary
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
                {([1, 2, 3, 4, 5] as const).map(lvl => {
                  const items = checklist.filter(c => c.level === lvl);
                  const completed = items.filter(c => c.status === 'Completed').length;
                  const isPassed = completed === items.length && items.length > 0;
                  return (
                    <div key={lvl} className="p-2.5 border border-slate-200 rounded-lg bg-slate-50/50">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-900">Level {lvl}</span>
                        {isPassed ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <span className="font-mono text-slate-500">{completed}/{items.length}</span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-600 truncate">{NICAS_LEVEL_TITLES[lvl].subtitle}</div>
                      <div className="mt-1 text-[10px] font-semibold text-slate-500 uppercase">
                        {isPassed ? '✓ Certified' : completed > 0 ? 'In Progress' : 'Pending'}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Summary Stats Table */}
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 font-mono text-center">
                <div>
                  <span className="text-slate-500 text-[11px] block">Total Climbs Logged</span>
                  <span className="font-bold text-base text-slate-900">{totalClimbs}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">Lead Assessor</span>
                  <span className="font-bold text-xs text-slate-900 truncate block">{profile.leadInstructor || 'Not Assigned'}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">Registration Date</span>
                  <span className="font-bold text-xs text-slate-900">{profile.startDate || '—'}</span>
                </div>
              </div>
            </div>
          )}

          {/* REPORT 2: CLIMB LOG LEDGER */}
          {(selectedReport === 'climbs' || selectedReport === 'master') && (
            <div className={`space-y-3 ${selectedReport === 'master' ? 'print-page-break pt-4' : ''}`}>
              <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                  Candidate Ascent Logbook Ledger ({climbs.length} ascents)
                </h3>
                <span className="text-[11px] text-slate-500">Ordered by Ascent Date</span>
              </div>

              {climbs.length === 0 ? (
                <div className="p-8 text-center text-slate-500 bg-slate-50 rounded-lg border border-slate-200 italic">
                  No climbs logged yet in candidate logbook. Ascents logged on the Climb Log tab will appear here.
                </div>
              ) : (
                <table className="w-full text-left text-xs border border-slate-200">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Date</th>
                      <th className="py-2 px-3">Route / Problem</th>
                      <th className="py-2 px-2">Style</th>
                      <th className="py-2 px-2 text-center">Grade</th>
                      <th className="py-2 px-2">Angle</th>
                      <th className="py-2 px-2">Outcome</th>
                      <th className="py-2 px-3">Centre</th>
                      <th className="py-2 px-3">Notes & Beta</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {climbs.map(c => {
                      const club = getClubById(c.clubId);
                      return (
                        <tr key={c.id}>
                          <td className="py-1.5 px-3 font-mono text-slate-600 whitespace-nowrap">{c.date}</td>
                          <td className="py-1.5 px-3 font-semibold text-slate-900">{c.routeName}</td>
                          <td className="py-1.5 px-2">{c.style}</td>
                          <td className="py-1.5 px-2 text-center font-mono font-bold">{c.grade}</td>
                          <td className="py-1.5 px-2 text-slate-600">{c.wallAngle}</td>
                          <td className="py-1.5 px-2 font-semibold text-slate-800">{c.outcome}</td>
                          <td className="py-1.5 px-3 text-slate-600 truncate max-w-[120px]">{club?.name || c.clubId}</td>
                          <td className="py-1.5 px-3 text-slate-500 truncate max-w-[200px]">{c.notes || '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {/* REPORT 3: CHECKLIST REPORT */}
          {(selectedReport === 'checklist' || selectedReport === 'master') && (
            <div className={`space-y-4 ${selectedReport === 'master' ? 'print-page-break pt-4' : ''}`}>
              <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                  NICAS Official Syllabus & Skills Checklist
                </h3>
                <span className="text-[11px] text-slate-500">Mountain Training Standard</span>
              </div>

              {([1, 2, 3, 4, 5] as const).map(lvl => {
                const items = checklist.filter(c => c.level === lvl);
                return (
                  <div key={lvl} className="space-y-1.5 print-avoid-break">
                    <div className="flex items-center justify-between bg-slate-100 px-3 py-1.5 rounded font-bold text-slate-900">
                      <span>Level {lvl}: {NICAS_LEVEL_TITLES[lvl].title}</span>
                      <span className="text-[11px] font-normal text-slate-600 font-mono">
                        {items.filter(i => i.status === 'Completed').length}/{items.length} signed off
                      </span>
                    </div>

                    <table className="w-full text-left text-[11px] border border-slate-200">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                          <th className="py-1 px-2 w-20">Category</th>
                          <th className="py-1 px-2">Skill / Criterion</th>
                          <th className="py-1 px-2 w-24">Status</th>
                          <th className="py-1 px-2 w-28">Sign-Off Date</th>
                          <th className="py-1 px-2 w-32">Instructor</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {items.map(item => (
                          <tr key={item.id}>
                            <td className="py-1 px-2 font-medium text-slate-600">{item.category}</td>
                            <td className="py-1 px-2">
                              <span className="font-semibold text-slate-900">{item.title}</span>
                              <p className="text-[10px] text-slate-500 leading-tight">{item.description}</p>
                            </td>
                            <td className="py-1 px-2">
                              <span
                                className={`font-semibold ${
                                  item.status === 'Completed'
                                    ? 'text-emerald-700'
                                    : item.status === 'In Progress'
                                    ? 'text-amber-700'
                                    : 'text-slate-400'
                                }`}
                              >
                                {item.status === 'Completed' ? '✓ Passed' : item.status}
                              </span>
                            </td>
                            <td className="py-1 px-2 font-mono text-slate-600">{item.signOffDate || '—'}</td>
                            <td className="py-1 px-2 text-slate-700">{item.instructorName || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          )}

          {/* Official Sign-Off Block for Instructor */}
          <div className="border border-slate-300 rounded-lg p-4 mt-6 print-avoid-break bg-slate-50/40">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-4">
              NICAS Course Director / Lead Instructor Endorsement
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
              <div className="border-b border-slate-300 pb-2">
                <span className="text-slate-500 block mb-6">Assessor / Instructor Name:</span>
                <span className="font-semibold text-slate-800">{profile.leadInstructor || '_____________________'}</span>
              </div>
              <div className="border-b border-slate-300 pb-2">
                <span className="text-slate-500 block mb-6">Candidate Signature:</span>
                <span className="font-semibold text-slate-800 italic">{profile.candidateName || '_____________________'}</span>
              </div>
              <div className="border-b border-slate-300 pb-2">
                <span className="text-slate-500 block mb-6">Official Centre Stamp & Date:</span>
                <span className="font-semibold text-slate-800 font-mono">{new Date().toISOString().split('T')[0]}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="no-print px-4 sm:px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Choose "Save as PDF" in your print dialog destination to download this report.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-lg shadow-xs"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
};
