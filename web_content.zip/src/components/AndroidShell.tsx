import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Briefcase,
  TrendingUp,
  User,
  Wifi,
  Battery,
  Smartphone,
  Globe,
  Database,
  ArrowRight,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { NavTab, Language, SystemStatus } from '../types';
import { translations } from '../translations/translations';

interface Props {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenFirebaseStatus: () => void;
  systemStatus: SystemStatus | null;
  savedCount: number;
  applicationCount: number;
  children: React.ReactNode;
}

export const AndroidShell: React.FC<Props> = ({
  activeTab,
  onTabChange,
  language,
  onLanguageChange,
  onOpenFirebaseStatus,
  systemStatus,
  savedCount,
  applicationCount,
  children,
}) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [currentTime, setCurrentTime] = useState('10:45');

  const t = translations[language];

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    {
      id: 'solver' as NavTab,
      label: t.nav.solver,
      icon: Sparkles,
      badge: 0,
    },
    {
      id: 'jobs' as NavTab,
      label: t.nav.jobs,
      icon: Briefcase,
      badge: applicationCount,
    },
    {
      id: 'business' as NavTab,
      label: t.nav.business,
      icon: TrendingUp,
      badge: 0,
    },
    {
      id: 'profile' as NavTab,
      label: t.nav.profile,
      icon: User,
      badge: savedCount,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-0 md:p-4 text-slate-900 selection:bg-emerald-200">
      {/* Top Floating Control Bar for Preview mode */}
      <div className="w-full max-w-5xl mb-2 px-4 py-2 hidden md:flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center space-x-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-semibold text-emerald-300">PROJECT ZERO</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400 italic">“{t.appTagline}”</span>
        </div>

        <div className="flex items-center space-x-3">
          {/* Language Toggle Pill */}
          <div className="flex items-center bg-slate-800 rounded-full p-0.5 border border-slate-700">
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${
                language === 'en'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => onLanguageChange('am')}
              className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${
                language === 'am'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              አማርኛ
            </button>
          </div>

          {/* Config / Firebase Status Chip */}
          <button
            onClick={onOpenFirebaseStatus}
            className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-medium">
              {systemStatus?.firebase?.configured ? 'Firestore Synced' : t.topBar.offlineMode}
            </span>
          </button>

          {/* Frame Mode Switcher */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Toggle between Android Phone View and Wide View"
          >
            {isPhoneFrame ? <Maximize2 className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            <span>{isPhoneFrame ? 'Full View' : 'Phone Frame'}</span>
          </button>
        </div>
      </div>

      {/* Main Container - Can be Phone Frame or Full-Width Tablet/Desktop */}
      <div
        className={`w-full bg-white transition-all duration-300 flex flex-col shadow-2xl overflow-hidden ${
          isPhoneFrame
            ? 'max-w-[430px] h-[92vh] md:h-[860px] md:rounded-[44px] md:border-[10px] md:border-slate-800 md:ring-1 md:ring-slate-700'
            : 'max-w-5xl min-h-[90vh] md:rounded-3xl border border-slate-200'
        }`}
      >
        {/* Android Status Bar (Simulated) */}
        <div className="bg-emerald-950 text-white px-6 pt-3 pb-2 flex items-center justify-between text-xs select-none">
          <div className="font-semibold tracking-wider font-mono text-[13px]">{currentTime}</div>
          
          {/* Android Camera Punch-Hole Simulation in Phone Mode */}
          {isPhoneFrame && (
            <div className="w-3.5 h-3.5 bg-black rounded-full border border-slate-800"></div>
          )}

          <div className="flex items-center space-x-2 text-slate-300">
            <span className="text-[10px] font-bold font-mono tracking-tight text-emerald-400">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center">
              <span className="text-[10px] mr-0.5">100%</span>
              <Battery className="w-4 h-4 fill-emerald-400 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* Top App Bar with Branding and Language Quick Toggle */}
        <header className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-800 text-white px-4 py-3 shadow-md flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/20 flex items-center justify-center shadow-inner">
              <div className="relative">
                <span className="text-xl font-extrabold text-white">0</span>
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-emerald-900"></span>
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h1 className="font-extrabold tracking-tight text-base sm:text-lg text-white">PROJECT ZERO</h1>
                <span className="text-[10px] px-1.5 py-0.2 rounded font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  v1.0
                </span>
              </div>
              <p className="text-[11px] text-emerald-200 line-clamp-1 font-medium">
                {t.appTagline}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Quick Language Toggle on Mobile Bar */}
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'am' : 'en')}
              className="flex items-center space-x-1 px-2.5 py-1 rounded-full bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-xs transition-colors border border-white/20"
              title="Switch language between English and Amharic"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-300" />
              <span>{language === 'en' ? 'አማ' : 'EN'}</span>
            </button>

            {/* Quick Status / Config button */}
            <button
              onClick={onOpenFirebaseStatus}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-emerald-300 transition-colors"
              title="View Firebase & Gemini configuration"
            >
              <Database className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Scrollable Main Screen Body */}
        <main className="flex-1 overflow-y-auto bg-slate-50 overscroll-contain">
          {children}
        </main>

        {/* Android Material 3 Style Bottom Navigation Bar */}
        <nav className="bg-white border-t border-slate-200/80 px-2 py-2 flex items-center justify-around z-20 shrink-0 shadow-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className="relative flex flex-col items-center justify-center flex-1 py-1 focus:outline-hidden transition-all duration-200 group"
              >
                {/* Active Indicator Pill */}
                <div
                  className={`w-14 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
                    isActive
                      ? 'bg-emerald-100 text-emerald-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 group-hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'}`} />

                  {/* Badge */}
                  {item.badge > 0 && (
                    <span className="absolute top-0 right-3 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white ring-2 ring-white">
                      {item.badge}
                    </span>
                  )}
                </div>

                <span
                  className={`text-[11px] mt-1 tracking-tight transition-colors line-clamp-1 ${
                    isActive ? 'font-bold text-emerald-900' : 'font-medium text-slate-500'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Android Gesture Navigation Bar pill at bottom */}
        {isPhoneFrame && (
          <div className="bg-white pb-1 pt-0.5 flex justify-center items-center">
            <div className="w-32 h-1 bg-slate-300 rounded-full"></div>
          </div>
        )}
      </div>
    </div>
  );
};
