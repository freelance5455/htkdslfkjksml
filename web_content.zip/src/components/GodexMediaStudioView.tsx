/**
 * GODEX Media Studio - Text-to-Video & Generative Media Suite
 * Mobile-First, Touch-Optimized Cinematic Engineering Workspace.
 * 
 * Features:
 * - Text-to-Video Prompt Engine with Cinematic Prompt Presets
 * - Style / Aesthetic Direction Controls (Photorealism, Cyberpunk, 3D Octane, Anime, Noir)
 * - Aspect Ratio Selectors (16:9 Landscape, 9:16 Vertical, 1:1 Square, 21:9 Ultrawide, 4:3 Classic)
 * - Duration & Framerate Presets
 * - Multi-axis Camera Trajectory & Motion Control
 * - Storyboard Clip Pipeline & Active Queue
 * - Live Viewport Stage with Aspect Ratio Scaling
 * - Zero Fabrication Guarantee: Truthfully reports NOT_CONFIGURED when no backend video model endpoint is wired.
 */

import React, { useState } from 'react';
import { 
  Film, 
  Sparkles, 
  Video, 
  Image as ImageIcon, 
  Sliders, 
  AlertCircle, 
  Lock, 
  Layers, 
  Clock, 
  Play, 
  Settings, 
  Upload, 
  Compass, 
  Camera, 
  Monitor, 
  HelpCircle,
  CheckCircle2,
  FileVideo,
  ChevronRight,
  Maximize2,
  RotateCcw,
  Tag,
  Palette,
  Eye,
  Plus,
  Trash2,
  Check
} from 'lucide-react';
import { GodexLogo } from './GodexLogo';

export type MediaWorkflowMode = 'TEXT_TO_VIDEO' | 'IMAGE_TO_VIDEO' | 'VIDEO_TO_VIDEO';
export type VideoStylePreset = 'CINEMATIC' | 'PHOTOREAL' | 'CYBERPUNK' | 'OCTANE_3D' | 'ANIME' | 'NOIR' | 'ARCHITECTURAL';

export interface StoryboardClip {
  id: string;
  title: string;
  prompt: string;
  style: VideoStylePreset;
  aspectRatio: string;
  duration: number;
  camera: string;
  status: 'DRAFT' | 'READY_FOR_DISPATCH' | 'QUEUED';
  createdAt: string;
}

export const GodexMediaStudioView: React.FC = () => {
  const [activeWorkflow, setActiveWorkflow] = useState<MediaWorkflowMode>('TEXT_TO_VIDEO');
  const [promptText, setPromptText] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<VideoStylePreset>('CINEMATIC');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1' | '21:9' | '4:3'>('16:9');
  const [durationSec, setDurationSec] = useState<number>(5);
  const [cameraMotion, setCameraMotion] = useState<'PAN_RIGHT' | 'ORBIT' | 'DOLLY_IN' | 'STATIC' | 'CRANE_UP' | 'ZOOM_PULL'>('DOLLY_IN');
  const [fps, setFps] = useState<24 | 30 | 60>(24);
  const [showConfigHelp, setShowConfigHelp] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationFeedback, setGenerationFeedback] = useState<string | null>(null);

  // Storyboard queue
  const [clips, setClips] = useState<StoryboardClip[]>([
    {
      id: 'clip-1',
      title: 'Opening Shot: Neon Skyline',
      prompt: 'Cinematic drone flythrough of futuristic metropolis at dusk with volumetric fog and reflective puddles',
      style: 'CYBERPUNK',
      aspectRatio: '16:9',
      duration: 5,
      camera: 'Dolly In',
      status: 'READY_FOR_DISPATCH',
      createdAt: 'Just now'
    },
    {
      id: 'clip-2',
      title: 'Macro Reveal: Neural Core',
      prompt: 'Studio macro rotation of iridescent semiconductor chip with pulsing indigo photonic channels',
      style: 'OCTANE_3D',
      aspectRatio: '16:9',
      duration: 4,
      camera: 'Orbital 360°',
      status: 'DRAFT',
      createdAt: '2m ago'
    }
  ]);

  const stylePresets: Array<{ id: VideoStylePreset; label: string; tag: string }> = [
    { id: 'CINEMATIC', label: 'Cinematic Film', tag: '35mm Anamorphic' },
    { id: 'PHOTOREAL', label: 'Photorealistic', tag: '8K Hyperreal' },
    { id: 'CYBERPUNK', label: 'Cyberpunk Neon', tag: 'Volumetric Lights' },
    { id: 'OCTANE_3D', label: '3D Octane Render', tag: 'Raytraced Glass' },
    { id: 'ANIME', label: 'Anime Cel-Shade', tag: 'Studio Ghibli' },
    { id: 'NOIR', label: 'Film Noir', tag: 'High Contrast B&W' },
    { id: 'ARCHITECTURAL', label: 'Architectural', tag: 'Clean Geometry' },
  ];

  const quickPrompts = [
    'Cinematic drone flythrough of a futuristic architectural pavilion at sunset',
    'Macro studio product reveal with dramatic specular rim lighting and shallow DOF',
    'Volumetric storm clouds parting over neon-lit skyscraper rooftops',
    'Fluid organic particle simulation blooming in zero-gravity space'
  ];

  const cameraMotions = [
    { id: 'DOLLY_IN', label: 'Dolly In', desc: 'Forward smooth camera glide' },
    { id: 'PAN_RIGHT', label: 'Pan Right', desc: 'Horizontal architectural sweep' },
    { id: 'ORBIT', label: 'Orbital 360°', desc: 'Curved subject focus sweep' },
    { id: 'CRANE_UP', label: 'Crane Elevation', desc: 'Vertical upward cinematic lift' },
    { id: 'ZOOM_PULL', label: 'Zoom Pull', desc: 'Dramatic focal length expansion' },
    { id: 'STATIC', label: 'Tripod Static', desc: 'Stable fixed viewpoint' }
  ];

  const handleGenerate = () => {
    if (!promptText.trim()) {
      setGenerationFeedback('Please enter a scene description prompt first.');
      return;
    }

    setIsGenerating(true);
    setGenerationFeedback('Validating video generation parameters and checking backend provider connection...');

    setTimeout(() => {
      setIsGenerating(false);
      // Add drafted clip to storyboard
      const newClip: StoryboardClip = {
        id: `clip-${Date.now()}`,
        title: `Scene: ${promptText.slice(0, 24)}...`,
        prompt: promptText.trim(),
        style: selectedStyle,
        aspectRatio,
        duration: durationSec,
        camera: cameraMotions.find(m => m.id === cameraMotion)?.label || cameraMotion,
        status: 'READY_FOR_DISPATCH',
        createdAt: 'Just now'
      };
      setClips(prev => [newClip, ...prev]);
      setGenerationFeedback('Scene queued in Storyboard. Real video rendering will dispatch once a video endpoint (e.g. Veo, Imagen Video) is configured.');
    }, 800);
  };

  const handleDeleteClip = (id: string) => {
    setClips(prev => prev.filter(c => c.id !== id));
  };

  return (
    <div 
      id="godex-media-studio-view"
      className="flex-1 h-full flex flex-col bg-[#07090D] overflow-y-auto select-none font-sans p-3 sm:p-5 md:p-6 space-y-5"
    >
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#182030] pb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#0F1420] border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-md shrink-0">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-wide">GODEX Media Studio</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-800/60">
                PHASE 11 ARCHITECTURE
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono">
              Text-to-Video • Image-to-Video • Video-to-Video Foundations
            </p>
          </div>
        </div>

        {/* Provider Status Pill (Truthful - NEVER Fake) */}
        <div className="flex items-center gap-2 font-mono text-xs self-start sm:self-auto">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0F131D] border border-amber-500/40 text-amber-300">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">PROVIDER: NOT_CONFIGURED</span>
          </div>
        </div>
      </div>

      {/* Workflow Tabs (Text-to-Video, Image-to-Video, Video-to-Video) */}
      <div className="flex items-center gap-2 border-b border-[#182030] pb-2 font-mono text-xs overflow-x-auto no-scrollbar">
        {[
          { id: 'TEXT_TO_VIDEO', label: 'Text-to-Video', icon: Sparkles },
          { id: 'IMAGE_TO_VIDEO', label: 'Image-to-Video', icon: ImageIcon },
          { id: 'VIDEO_TO_VIDEO', label: 'Video-to-Video', icon: Video }
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeWorkflow === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveWorkflow(tab.id as MediaWorkflowMode)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-semibold transition-all whitespace-nowrap text-xs ${
                active
                  ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0F1420] border border-transparent'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-cyan-400" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Studio Grid (Controls + Canvas) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Parameter & Prompt Engine */}
        <div className="lg:col-span-6 xl:col-span-5 space-y-4 font-sans text-xs">
          
          {/* Prompt Box & Inspiration Chips */}
          <div className="p-4 rounded-2xl bg-[#0B0E16] border border-[#182030] space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] font-mono flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Text-to-Video Scene Prompt</span>
              </span>
              <span className="text-[10px] font-mono text-neutral-500">Latent Scene Guidance</span>
            </div>

            <textarea
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder={
                activeWorkflow === 'TEXT_TO_VIDEO'
                  ? 'Describe cinematic scene, volumetric lighting, optical motion, lens characteristics, and mood...'
                  : activeWorkflow === 'IMAGE_TO_VIDEO'
                  ? 'Describe target camera motion and temporal transformation from anchor image...'
                  : 'Describe neural style transfer, temporal re-timing, or visual restyling...'
              }
              rows={4}
              className="w-full p-3 rounded-xl bg-[#07090F] border border-[#1A2234] text-neutral-200 text-xs placeholder-neutral-600 focus:outline-none focus:border-cyan-500 font-sans leading-relaxed resize-none transition-colors"
            />

            {/* Quick Inspiration Chips */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-mono text-neutral-500 block uppercase">Quick Cinematic Ideas:</span>
              <div className="flex flex-wrap gap-1.5">
                {quickPrompts.map((qp, idx) => (
                  <button
                    key={idx}
                    onClick={() => setPromptText(qp)}
                    className="text-[10px] font-sans px-2.5 py-1 rounded-lg bg-[#0E1422] hover:bg-[#152035] border border-[#1A253C] text-neutral-300 hover:text-cyan-300 text-left transition-colors truncate max-w-full"
                  >
                    {qp.length > 40 ? qp.slice(0, 38) + '...' : qp}
                  </button>
                ))}
              </div>
            </div>

            {/* Workflow Specific Inputs */}
            {activeWorkflow === 'IMAGE_TO_VIDEO' && (
              <div className="p-4 rounded-xl bg-[#080B12] border border-dashed border-[#1E283E] text-center space-y-1.5 cursor-pointer hover:border-cyan-500/50 transition-colors">
                <Upload className="w-5 h-5 text-cyan-400 mx-auto" />
                <div className="font-semibold text-neutral-300 text-[11px]">Upload Keyframe Image Anchor</div>
                <div className="text-[10px] text-neutral-500">PNG, JPG, WebP up to 20MB</div>
              </div>
            )}

            {activeWorkflow === 'VIDEO_TO_VIDEO' && (
              <div className="p-4 rounded-xl bg-[#080B12] border border-dashed border-[#1E283E] text-center space-y-1.5 cursor-pointer hover:border-cyan-500/50 transition-colors">
                <FileVideo className="w-5 h-5 text-indigo-400 mx-auto" />
                <div className="font-semibold text-neutral-300 text-[11px]">Upload Source Video Footage</div>
                <div className="text-[10px] text-neutral-500">MP4, MOV, WebM up to 100MB (Max 30s)</div>
              </div>
            )}
          </div>

          {/* Aesthetic Style & Visual Direction */}
          <div className="p-4 rounded-2xl bg-[#0B0E16] border border-[#182030] space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] font-mono flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-purple-400" />
                <span>Visual Style & Atmosphere</span>
              </span>
              <span className="text-[10px] font-mono text-cyan-400">{selectedStyle}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {stylePresets.map((style) => (
                <button
                  key={style.id}
                  onClick={() => setSelectedStyle(style.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    selectedStyle === style.id
                      ? 'bg-purple-950/40 border-purple-500/60 text-purple-200 shadow-sm'
                      : 'bg-[#080B12] border-[#161D2B] text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1320]'
                  }`}
                >
                  <div className="font-semibold text-xs truncate">{style.label}</div>
                  <div className="text-[9px] text-neutral-500 truncate">{style.tag}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Camera Motion & Trajectory */}
          <div className="p-4 rounded-2xl bg-[#0B0E16] border border-[#182030] space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] font-mono flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-amber-400" />
                <span>Camera Motion & Trajectory</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {cameraMotions.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setCameraMotion(m.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    cameraMotion === m.id
                      ? 'bg-[#121927] border-cyan-500/70 text-cyan-300 shadow-xs'
                      : 'bg-[#080B12] border-[#161D2B] text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <div className="font-bold text-xs">{m.label}</div>
                  <div className="text-[9px] text-neutral-500 truncate">{m.desc}</div>
                </button>
              ))}
            </div>

            {/* Aspect Ratio, Duration & FPS Controls */}
            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-[#141B28] font-mono text-[11px]">
              <div>
                <label className="text-neutral-500 text-[10px] block mb-1">Aspect Ratio</label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full p-2 rounded-xl bg-[#07090F] border border-[#1A2234] text-neutral-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="16:9">16:9 (Cinema)</option>
                  <option value="9:16">9:16 (Stories)</option>
                  <option value="1:1">1:1 (Square)</option>
                  <option value="21:9">21:9 (Ultrawide)</option>
                  <option value="4:3">4:3 (Classic)</option>
                </select>
              </div>
              <div>
                <label className="text-neutral-500 text-[10px] block mb-1">Duration</label>
                <select
                  value={durationSec}
                  onChange={(e) => setDurationSec(Number(e.target.value))}
                  className="w-full p-2 rounded-xl bg-[#07090F] border border-[#1A2234] text-neutral-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value={4}>4 seconds</option>
                  <option value={5}>5 seconds</option>
                  <option value={8}>8 seconds</option>
                  <option value={10}>10 seconds</option>
                  <option value={15}>15 seconds</option>
                </select>
              </div>
              <div>
                <label className="text-neutral-500 text-[10px] block mb-1">Framerate</label>
                <select
                  value={fps}
                  onChange={(e) => setFps(Number(e.target.value) as any)}
                  className="w-full p-2 rounded-xl bg-[#07090F] border border-[#1A2234] text-neutral-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value={24}>24 FPS (Film)</option>
                  <option value={30}>30 FPS (Video)</option>
                  <option value={60}>60 FPS (Ultra)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Primary Action Button */}
          <div className="space-y-2">
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin text-cyan-200" />
                  <span>Validating Generation Parameters...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-300" />
                  <span>Queue Text-to-Video Scene</span>
                </>
              )}
            </button>

            {generationFeedback && (
              <div className="p-2.5 rounded-xl bg-[#0D1424] border border-cyan-500/30 text-cyan-300 text-[11px] font-mono leading-relaxed">
                {generationFeedback}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Viewport Canvas & Storyboard Clips */}
        <div className="lg:col-span-6 xl:col-span-7 flex flex-col space-y-4">
          
          {/* Main Viewport Stage */}
          <div className="p-6 rounded-2xl bg-[#090C14] border border-[#182030] shadow-2xl flex flex-col items-center justify-center text-center space-y-4 min-h-[320px] relative overflow-hidden">
            {/* Background Grid Pattern */}
            <div className="absolute inset-0 bg-[radial-gradient(#182234_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-40" />

            {/* Viewport Meta Overlays */}
            <div className="absolute top-3 left-3 flex items-center gap-2 z-20">
              <span className="px-2 py-0.5 rounded bg-[#06080E]/80 border border-[#1A2234] text-[10px] font-mono text-neutral-400">
                Aspect: {aspectRatio}
              </span>
              <span className="px-2 py-0.5 rounded bg-[#06080E]/80 border border-[#1A2234] text-[10px] font-mono text-neutral-400">
                {fps} FPS • {durationSec}s
              </span>
            </div>

            {/* Provider Policy Notice (Truthful - Never Fabricates Fake Video Output) */}
            <div className="relative z-10 max-w-md space-y-3 p-4">
              <div className="w-12 h-12 rounded-2xl bg-[#121624] border border-amber-500/40 flex items-center justify-center text-amber-400 mx-auto shadow-xl shadow-amber-950/40">
                <Lock className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white tracking-wide font-mono">
                  GENERATION_NOT_CONFIGURED
                </h3>
                <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                  No video generation model provider (e.g. Veo, Imagen Video, Sora) has been configured in this environment.
                </p>
                <div className="text-[11px] text-amber-300/90 font-mono bg-amber-950/50 p-2.5 rounded-xl border border-amber-900/60 mt-2">
                  GODEX strictly adheres to zero-fabrication: video generation will only execute when a verified real provider endpoint is connected.
                </div>
              </div>

              {/* Configuration Guidance Button */}
              <div className="pt-2">
                <button
                  onClick={() => setShowConfigHelp(!showConfigHelp)}
                  className="px-3.5 py-1.5 rounded-lg bg-[#141C2B] hover:bg-[#1C273C] border border-[#223048] text-cyan-300 font-mono text-xs font-semibold transition-colors inline-flex items-center gap-1.5"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{showConfigHelp ? 'Hide Provider Config Guide' : 'Provider Integration Architecture'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Expandable Provider Integration Spec */}
          {showConfigHelp && (
            <div className="p-4 rounded-2xl bg-[#090C14] border border-[#1B2538] space-y-3 font-mono text-xs animate-in fade-in duration-150">
              <div className="flex items-center justify-between text-neutral-200 font-bold border-b border-[#161F2E] pb-2">
                <span>Real Media Provider Adapter Contract</span>
                <span className="text-[10px] text-cyan-400">Server-Side Proxy Architecture</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">
                To enable live media rendering, connect a real backend adapter in <code className="text-cyan-300">server.ts</code> implementing the standard <code className="text-cyan-300">/api/media/generate</code> endpoint with authenticated API keys.
              </p>
              <div className="p-3 rounded-lg bg-[#06080E] border border-[#131A26] text-[10px] text-neutral-300 space-y-1">
                <div>POST /api/media/generate</div>
                <div>{'{'} prompt, mode: "TEXT_TO_VIDEO" | "IMAGE_TO_VIDEO", aspectRatio, fps, duration {'}'}</div>
                <div className="text-emerald-400">{'->'} Returns: {'{'} videoUrl: string, latencyMs: number, verified: true {'}'}</div>
              </div>
            </div>
          )}

          {/* Storyboard Clip Timeline & Scene Queue */}
          <div className="p-4 rounded-2xl bg-[#0A0D15] border border-[#182030] space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span className="font-bold text-white uppercase text-xs font-mono">Storyboard Clip Queue</span>
                <span className="px-1.5 py-0.5 rounded bg-[#141B2B] text-[10px] font-mono text-neutral-400">
                  {clips.length} scenes
                </span>
              </div>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto no-scrollbar">
              {clips.map((clip) => (
                <div 
                  key={clip.id}
                  className="p-3 rounded-xl bg-[#07090F] border border-[#161E2E] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:border-cyan-500/30 transition-colors"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-xs text-white truncate">{clip.title}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-purple-950/60 text-purple-300 border border-purple-800/40">
                        {clip.style}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 line-clamp-1 font-sans">
                      {clip.prompt}
                    </p>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-500">
                      <span>{clip.aspectRatio}</span>
                      <span>•</span>
                      <span>{clip.duration}s</span>
                      <span>•</span>
                      <span>{clip.camera}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    <span className="px-2 py-1 rounded text-[10px] font-mono bg-[#0F1626] text-cyan-300 border border-cyan-500/30">
                      {clip.status}
                    </span>
                    <button
                      onClick={() => handleDeleteClip(clip.id)}
                      className="p-1 rounded text-neutral-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                      title="Remove scene"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
