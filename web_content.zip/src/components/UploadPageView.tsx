import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Upload, FileAudio, Video, Image as ImageIcon, Shield, Sparkles, HardDrive, Settings, Sliders, CheckCircle2, Clock, Lock, ShieldAlert } from 'lucide-react';
import { MinistryContentUploader } from './MinistryContentUploader';
import { offlineCache } from '../lib/offlineCache';

export const UploadPageView: React.FC = () => {
  const profile = offlineCache.getProfile();
  const isOwner = (profile.email.toLowerCase() === 'juhnkrix.musika@gmail.com') && offlineCache.checkAdminVault();

  const audioInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Admin System Settings State
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [expirationDays, setExpirationDays] = useState<string>('never');
  const [autoArchive, setAutoArchive] = useState<boolean>(true);
  const [accessPermission, setAccessPermission] = useState<string>('public-sanctuary');
  const [maxSizeMB, setMaxSizeMB] = useState<number>(500);
  const [settingsSaved, setSettingsSaved] = useState<boolean>(false);

  if (!isOwner) {
    return (
      <div className="max-w-2xl mx-auto py-20 px-6 text-center space-y-6 bg-slate-900/90 border border-amber-500/30 rounded-3xl shadow-2xl my-12">
        <div className="w-16 h-16 bg-red-500/20 text-red-400 rounded-2xl flex items-center justify-center mx-auto border border-red-500/40">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold font-serif text-amber-100">Access Denied • Administrative Sanctuary Only</h2>
        <p className="text-xs text-slate-300">
          This exclusive administrative upload portal is restricted strictly to Prophet JUHNKRIX SYNVAGORD (<code className="text-amber-300 font-mono">juhnkrix.musika@gmail.com</code>). Your current session ({profile.email}) is unauthorized.
        </p>
      </div>
    );
  }

  const triggerUpload = (type: 'audio' | 'video' | 'image') => {
    if (type === 'audio' && audioInputRef.current) audioInputRef.current.click();
    if (type === 'video' && videoInputRef.current) videoInputRef.current.click();
    if (type === 'image' && imageInputRef.current) imageInputRef.current.click();
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-8 max-w-6xl mx-auto pb-16"
    >
      {/* Hidden file inputs for dedicated buttons */}
      <input
        type="file"
        ref={audioInputRef}
        accept="audio/*"
        multiple
        className="hidden"
      />
      <input
        type="file"
        ref={videoInputRef}
        accept="video/*"
        multiple
        className="hidden"
      />
      <input
        type="file"
        ref={imageInputRef}
        accept="image/*"
        multiple
        className="hidden"
      />

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-950 border border-amber-500/40 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Prophet JUHNKRIX SYNVAGORD • Exclusive Upload Portal</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold font-serif tracking-tight text-amber-100">
              Dedicated Ministry Upload Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Quickly upload anointed audio soaking tracks, live broadcast altar videos, and celestial sanctuary devotional images (Imoges) directly into secure IndexedDB offline storage.
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 bg-slate-950/80 border border-amber-500/30 px-4 py-3 rounded-2xl shadow-lg">
              <HardDrive className="w-5 h-5 text-amber-400" />
              <div>
                <p className="text-[10px] uppercase font-mono text-slate-400">Storage Engine</p>
                <p className="text-xs font-bold text-amber-200">IndexedDB Vault Active</p>
              </div>
            </div>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-3 rounded-2xl border transition-all flex items-center space-x-2 shadow-lg ${
                showSettings 
                  ? 'bg-amber-500 text-slate-950 border-amber-400' 
                  : 'bg-slate-950/80 text-amber-300 border-amber-500/40 hover:bg-amber-500/10'
              }`}
              title="Admin System Settings"
            >
              <Sliders className="w-5 h-5" />
              <span className="text-xs font-mono font-bold hidden sm:inline">Settings</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin-Only System Settings Panel (Collapsible) */}
      {showSettings && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-amber-500/20">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
                <Settings className="w-5 h-5 animate-spin-slow" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-serif text-amber-100">
                  Admin System Settings • Upload Control Center
                </h3>
                <p className="text-xs text-amber-300/80 font-mono">
                  Configured by Prophet JUHNKRIX SYNVAGORD for Audio, Video & Imoge Vaults
                </p>
              </div>
            </div>
            {settingsSaved && (
              <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-3 py-1.5 rounded-xl animate-bounce">
                <CheckCircle2 className="w-4 h-4" />
                <span>Settings Saved Successfully</span>
              </div>
            )}
          </div>

          <form onSubmit={handleSaveSettings} className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Content Expiration */}
            <div className="space-y-2 bg-slate-950/60 p-5 rounded-2xl border border-amber-500/20">
              <label className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Content Expiration Policy</span>
              </label>
              <select
                value={expirationDays}
                onChange={(e) => setExpirationDays(e.target.value)}
                className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="never">Never Expire (Permanent Sanctuary Archive)</option>
                <option value="30">30 Days</option>
                <option value="90">90 Days</option>
                <option value="365">1 Year</option>
              </select>
              <p className="text-[10px] text-slate-400">
                Defines retention period for newly uploaded media in IndexedDB.
              </p>
            </div>

            {/* Auto-Archive Legacy Media */}
            <div className="space-y-3 bg-slate-950/60 p-5 rounded-2xl border border-amber-500/20 flex flex-col justify-between">
              <div className="space-y-1">
                <label className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                  <HardDrive className="w-4 h-4 text-amber-400" />
                  <span>Auto-Archive Legacy Media</span>
                </label>
                <p className="text-[10px] text-slate-400">
                  Automatically move older broadcasts and soaking tracks to compressed local cold storage.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer pt-2">
                <input
                  type="checkbox"
                  checked={autoArchive}
                  onChange={(e) => setAutoArchive(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[11px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                <span className="ml-3 text-xs font-mono font-bold text-amber-200">
                  {autoArchive ? 'Enabled (Active)' : 'Disabled'}
                </span>
              </label>
            </div>

            {/* File Access Permissions */}
            <div className="space-y-2 bg-slate-950/60 p-5 rounded-2xl border border-amber-500/20">
              <label className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                <Lock className="w-4 h-4 text-amber-400" />
                <span>Default Access Permissions</span>
              </label>
              <select
                value={accessPermission}
                onChange={(e) => setAccessPermission(e.target.value)}
                className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="public-sanctuary">Public Sanctuary (All Believers)</option>
                <option value="partners-only">Prophetic Partners & Members Only</option>
                <option value="owner-private">Private Vault (Prophet Only)</option>
              </select>
              <p className="text-[10px] text-slate-400">
                Restricts streaming access across all connected disciple devices.
              </p>
            </div>
          </form>

          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSaveSettings}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition-all hover:scale-105"
            >
              Save Admin Settings
            </button>
          </div>
        </motion.div>
      )}

      {/* Three Prominent Action Buttons Grid with Framer Motion entry and glow hover */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* UPLOAD AUDIO */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          whileHover={{ 
            scale: 1.02, 
            boxShadow: '0 0 30px rgba(245, 158, 11, 0.35)',
            borderColor: 'rgba(251, 191, 36, 0.8)'
          }}
          whileTap={{ scale: 0.98 }}
          onClick={() => triggerUpload('audio')}
          className="group bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-8 text-left transition-colors shadow-2xl flex flex-col justify-between space-y-6 relative overflow-hidden cursor-pointer"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <div className="space-y-4 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40 group-hover:scale-110 group-hover:bg-amber-500/30 transition-all shadow-lg">
              <FileAudio className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">Sound & Frequency</span>
              <h3 className="text-lg font-extrabold font-mono tracking-tight text-amber-100">UPLOAD AUDIO</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Upload MP3, WAV soaking worship streams, prophetic chants, and acoustic altar sessions.
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300 group-hover:translate-x-1.5 transition-transform relative z-10">
            <span>Select Audio Files →</span>
          </div>
        </motion.button>

        {/* UPLOAD VIDEO */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          whileHover={{ 
            scale: 1.02, 
            boxShadow: '0 0 30px rgba(245, 158, 11, 0.35)',
            borderColor: 'rgba(251, 191, 36, 0.8)'
          }}
          whileTap={{ scale: 0.98 }}
          onClick={() => triggerUpload('video')}
          className="group bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-8 text-left transition-colors shadow-2xl flex flex-col justify-between space-y-6 relative overflow-hidden cursor-pointer"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <div className="space-y-4 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40 group-hover:scale-110 group-hover:bg-amber-500/30 transition-all shadow-lg">
              <Video className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">Broadcast & Stream</span>
              <h3 className="text-lg font-extrabold font-mono tracking-tight text-amber-100">UPLOAD VIDEO</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Upload MP4 sermon recordings, live altar broadcasts, and miraculous revival services.
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300 group-hover:translate-x-1.5 transition-transform relative z-10">
            <span>Select Video Files →</span>
          </div>
        </motion.button>

        {/* UPLOAD IMOGE */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          whileHover={{ 
            scale: 1.02, 
            boxShadow: '0 0 30px rgba(245, 158, 11, 0.35)',
            borderColor: 'rgba(251, 191, 36, 0.8)'
          }}
          whileTap={{ scale: 0.98 }}
          onClick={() => triggerUpload('image')}
          className="group bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-8 text-left transition-colors shadow-2xl flex flex-col justify-between space-y-6 relative overflow-hidden cursor-pointer"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <div className="space-y-4 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40 group-hover:scale-110 group-hover:bg-amber-500/30 transition-all shadow-lg">
              <ImageIcon className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">Glory Visuals</span>
              <h3 className="text-lg font-extrabold font-mono tracking-tight text-amber-100">UPLOAD IMOGE</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Upload high-definition PNG, JPG devotional art, sanctuary banners, and prophetic imagery (Imoges).
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300 group-hover:translate-x-1.5 transition-transform relative z-10">
            <span>Select Image Files →</span>
          </div>
        </motion.button>
      </div>

      {/* Comprehensive Batch Uploader Component */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <MinistryContentUploader />
      </div>
    </motion.div>
  );
};

