import React, { useState } from 'react';
import { ChevronDown, Calendar, Award, AlertCircle, TrendingUp, CheckCircle, Clock } from 'lucide-react';
import { TestDefinition, TestResult, TestSeries, TestStore } from '../types';
import { ALL_TEST_SERIES, SEED_TEST_RESULTS } from '../data/batchData';
import {
  calculateDaysDifference,
  calculateSeriesStats,
  formatDisplayDate,
  formatRelativeDate,
  getTestDetails,
  getTodayDateString,
} from '../utils/trackerLogic';

interface TestsViewProps {
  testStore: TestStore;
  onUpdateTest: (testKey: string, updates: Partial<TestResult>) => void;
}

export const TestsView: React.FC<TestsViewProps> = ({ testStore, onUpdateTest }) => {
  const [selectedSeriesId, setSelectedSeriesId] = useState<string>('b');
  const [modeFilter, setModeFilter] = useState<'all' | 'Offline' | 'Online'>('all');
  const [openCards, setOpenCards] = useState<Record<string, boolean>>({});

  const todayStr = getTodayDateString();
  const currentSeries =
    ALL_TEST_SERIES.find((s) => s.id === selectedSeriesId) || ALL_TEST_SERIES[0];
  const stats = calculateSeriesStats(currentSeries, testStore, todayStr);

  const toggleCard = (key: string) => {
    setOpenCards((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleStatusToggle = (e: React.MouseEvent, testKey: string) => {
    e.stopPropagation();
    const current = getTestDetails(testKey, testStore);
    const nextStatus = current.s ? 0 : 1;
    onUpdateTest(testKey, { s: nextStatus });
  };

  const handleInputChange = (
    testKey: string,
    field: keyof TestResult,
    value: string
  ) => {
    const updates: Partial<TestResult> = { [field]: value };
    // If setting total score and test was not marked done, mark it as done!
    if (field === 't' && value !== '') {
      updates.s = 1;
    }
    onUpdateTest(testKey, updates);
  };

  // Find next upcoming tests across all test series
  const upcomingList: { test: TestDefinition; series: TestSeries; diff: number }[] = [];
  ALL_TEST_SERIES.forEach((s) => {
    s.list.forEach((t) => {
      const res = getTestDetails(t.k, testStore);
      const diff = calculateDaysDifference(t.d, todayStr);
      if (!res.s && diff >= 0) {
        upcomingList.push({ test: t, series: s, diff });
      }
    });
  });
  upcomingList.sort((a, b) => a.diff - b.diff);
  const nextTests = upcomingList.slice(0, 5);

  // Filter tests in current series
  const filteredTests = currentSeries.list.filter((t) => {
    if (modeFilter === 'all') return true;
    return t.m === modeFilter;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Test Series Switcher Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {ALL_TEST_SERIES.map((s) => {
          const isSelected = s.id === currentSeries.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => {
                setSelectedSeriesId(s.id);
                setModeFilter('all');
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-white text-[#0b0b0f] font-bold shadow-sm'
                  : 'bg-[#17171d] text-[#a3a3b0] font-medium hover:text-white'
              }`}
            >
              {s.name}
            </button>
          );
        })}
      </div>

      {/* Coming Up Widget */}
      {nextTests.length > 0 && (
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/50 p-3.5 backdrop-blur-sm">
          <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Clock className="w-3 h-3 text-purple-400" /> Coming Up Next
          </div>
          <div className="divide-y divide-zinc-800/40 text-xs">
            {nextTests.map(({ test, series }) => (
              <div
                key={test.k}
                className="py-1.5 flex items-center justify-between gap-3 text-zinc-300"
              >
                <div className="flex items-center gap-1.5 truncate">
                  <span className="font-bold text-white">{test.n}</span>
                  <span className="text-zinc-500">·</span>
                  <span className="text-zinc-400">{series.sh}</span>
                </div>
                <div className="text-orange-400 font-semibold whitespace-nowrap text-[11px]">
                  {formatDisplayDate(test.d)} · {formatRelativeDate(test.d, todayStr)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Series Summary Stats */}
      <div className="grid grid-cols-4 gap-2 text-center">
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-lg sm:text-xl font-extrabold text-white leading-none">
            {stats.attempted}/{stats.total}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Attempted</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-lg sm:text-xl font-extrabold text-amber-400 leading-none">
            {stats.missed}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">
            {currentSeries.late}
          </div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-lg sm:text-xl font-extrabold text-purple-400 leading-none">
            {stats.avg}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Avg Score</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-lg sm:text-xl font-extrabold text-emerald-400 leading-none">
            {stats.best}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Best</div>
        </div>
      </div>

      {/* RTS Mode Filter (Offline / Online) */}
      {currentSeries.modes && (
        <div className="flex gap-1.5">
          {(['all', 'Offline', 'Online'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setModeFilter(mode)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                modeFilter === mode
                  ? 'bg-zinc-800 text-white border border-zinc-700'
                  : 'bg-zinc-950 text-zinc-500 border border-zinc-900 hover:text-zinc-300'
              }`}
            >
              {mode === 'all' ? 'All Modes' : mode}
            </button>
          ))}
        </div>
      )}

      {/* Tests Card List */}
      <div className="space-y-2">
        {filteredTests.map((test) => {
          const res = getTestDetails(test.k, testStore);
          const diff = calculateDaysDifference(test.d, todayStr);
          const isOpen = !!openCards[test.k];

          let label = 'Upcoming';
          let statusStyle = 'bg-zinc-800 border-zinc-700 text-zinc-400';

          if (res.s) {
            label = 'Done';
            statusStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-300';
          } else if (diff < 0) {
            label = currentSeries.late;
            statusStyle = 'bg-amber-950/80 border-amber-500 text-amber-300';
          } else if (diff === 0) {
            label = 'Today';
            statusStyle = 'bg-orange-950/80 border-orange-500 text-orange-300';
          }

          // Calculate sum if individual subjects are filled
          const p = parseFloat(String(res.p || '0')) || 0;
          const c = parseFloat(String(res.c || '0')) || 0;
          const b = parseFloat(String(res.b || '0')) || 0;
          const z = parseFloat(String(res.z || '0')) || 0;
          const calculatedTotal = p + c + b + z;
          const hasIndividualMarks = !!(res.p || res.c || res.b || res.z);

          return (
            <div
              key={test.k}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/60 overflow-hidden shadow-sm"
            >
              {/* Card Header */}
              <div
                onClick={() => toggleCard(test.k)}
                className="px-3.5 py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-zinc-800/30 transition-colors"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-bold text-white">{test.n}</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-medium border ${
                        test.f
                          ? 'bg-amber-950/60 border-amber-500/40 text-amber-300'
                          : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                      }`}
                    >
                      {test.f ? 'Full' : 'Part'}
                    </span>
                    {test.m && (
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-medium border ${
                          test.m === 'Offline'
                            ? 'bg-purple-950/60 border-purple-500/40 text-purple-300'
                            : 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
                        }`}
                      >
                        {test.m}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-0.5">
                    {formatDisplayDate(test.d)} · {formatRelativeDate(test.d, todayStr)}
                  </div>
                </div>

                {/* Score Preview & Status */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  {res.t !== undefined && res.t !== '' && (
                    <span className="text-xs font-extrabold text-orange-400">
                      {res.t}
                    </span>
                  )}
                  <button
                    onClick={(e) => handleStatusToggle(e, test.k)}
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border transition-colors ${statusStyle}`}
                  >
                    {label}
                  </button>
                  <ChevronDown
                    className={`w-3.5 h-3.5 text-zinc-500 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </div>

              {/* Card Expanded Inputs */}
              {isOpen && (
                <div className="px-3.5 pb-3.5 pt-2 border-t border-zinc-800/60 space-y-3 text-xs">
                  {/* Score inputs grid */}
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] text-zinc-400 uppercase font-semibold block mb-1">
                        Total / 720
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.t ?? ''}
                        onChange={(e) => handleInputChange(test.k, 't', e.target.value)}
                        placeholder="e.g. 580"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white font-semibold focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-blue-400 uppercase font-semibold block mb-1">
                        Phy / 180
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.p ?? ''}
                        onChange={(e) => handleInputChange(test.k, 'p', e.target.value)}
                        placeholder="140"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-orange-400 uppercase font-semibold block mb-1">
                        Chem / 180
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.c ?? ''}
                        onChange={(e) => handleInputChange(test.k, 'c', e.target.value)}
                        placeholder="130"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-emerald-400 uppercase font-semibold block mb-1">
                        Bot / 180
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.b ?? ''}
                        onChange={(e) => handleInputChange(test.k, 'b', e.target.value)}
                        placeholder="160"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-pink-400 uppercase font-semibold block mb-1">
                        Zoo / 180
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.z ?? ''}
                        onChange={(e) => handleInputChange(test.k, 'z', e.target.value)}
                        placeholder="150"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-pink-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 uppercase font-semibold block mb-1">
                        Rank
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={res.r ?? ''}
                        onChange={(e) => handleInputChange(test.k, 'r', e.target.value)}
                        placeholder="Rank"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>

                  {/* Auto-sum helper */}
                  {hasIndividualMarks && calculatedTotal > 0 && String(res.t) !== String(calculatedTotal) && (
                    <div className="flex items-center justify-between p-2 rounded-xl bg-purple-950/40 border border-purple-800/40 text-[11px] text-purple-300">
                      <span>Sum of subjects = {calculatedTotal} / 720</span>
                      <button
                        onClick={() => handleInputChange(test.k, 't', String(calculatedTotal))}
                        className="px-2 py-0.5 rounded-lg bg-purple-600 text-white font-bold hover:bg-purple-500 transition-colors"
                      >
                        Apply as Total
                      </button>
                    </div>
                  )}

                  {/* Reflection & Mistakes Note */}
                  <div>
                    <input
                      type="text"
                      placeholder="Notes / mistakes to fix / paper analysis..."
                      value={res.n ?? ''}
                      onChange={(e) => handleInputChange(test.k, 'n', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-700"
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
