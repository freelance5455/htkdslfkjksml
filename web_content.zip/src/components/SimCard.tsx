import React from 'react';
import { Smartphone, Signal, Wifi, CheckCircle2 } from 'lucide-react';
import { SIMSlot, TelecomOperator, Language } from '../types';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface SimCardProps {
  selectedSim: SIMSlot;
  onSimChange: (slot: SIMSlot) => void;
  operator: TelecomOperator;
  onOperatorChange: (op: TelecomOperator) => void;
  language: Language;
}

const OPERATORS: TelecomOperator[] = ['Jazz', 'Telenor', 'Zong', 'Ufone', 'Onic', 'Warid', 'SCOM'];

const OPERATOR_COLORS: Record<TelecomOperator, { bg: string; text: string; border: string }> = {
  Jazz: { bg: 'bg-red-950/70', text: 'text-red-400', border: 'border-red-600/40' },
  Telenor: { bg: 'bg-blue-950/70', text: 'text-blue-400', border: 'border-blue-500/40' },
  Zong: { bg: 'bg-emerald-950/70', text: 'text-emerald-400', border: 'border-emerald-500/40' },
  Ufone: { bg: 'bg-amber-950/70', text: 'text-amber-400', border: 'border-amber-500/40' },
  Onic: { bg: 'bg-purple-950/70', text: 'text-purple-300', border: 'border-purple-500/40' },
  Warid: { bg: 'bg-rose-950/70', text: 'text-rose-400', border: 'border-rose-600/40' },
  SCOM: { bg: 'bg-teal-950/70', text: 'text-teal-300', border: 'border-teal-500/40' },
};

export const SimCard: React.FC<SimCardProps> = ({
  selectedSim,
  onSimChange,
  operator,
  onOperatorChange,
  language,
}) => {
  const tr = t[language];

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.simSelection}
          </h3>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-cyan-300 font-mono bg-[#09182b] px-2.5 py-1 rounded-lg border border-[#208fc0]/50">
          <Signal className="w-3.5 h-3.5 text-emerald-400" />
          <span>4G LTE</span>
        </div>
      </div>

      {/* Dual SIM Selector Buttons */}
      <div className="grid grid-cols-2 gap-3 mb-3">
        {(['SIM 1', 'SIM 2'] as SIMSlot[]).map((slot) => {
          const isActive = selectedSim === slot;
          return (
            <button
              key={slot}
              type="button"
              onClick={() => {
                onSimChange(slot);
                sounds.playClick();
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                isActive
                  ? 'bg-gradient-to-r from-[#0d3f66] to-[#085a82] border-cyan-400 shadow-[0_0_15px_rgba(0,220,255,0.25)] text-white'
                  : 'bg-[#09182b] border-[#208fc0]/40 text-slate-300 hover:border-[#208fc0]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm tracking-wide">{slot}</span>
                {isActive && <CheckCircle2 className="w-4 h-4 text-cyan-300" />}
              </div>
              <span className="text-xs text-cyan-300/80 font-mono">
                {slot === selectedSim ? `${operator} Network` : 'Standby'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Operator Dropdown */}
      <div className="mt-2">
        <label className="block text-xs text-cyan-200/90 mb-1 font-medium">
          {language === 'ur' ? 'ٹیلی کام نیٹ ورک / آپریٹر:' : 'Telecom Operator / Carrier:'}
        </label>
        <select
          value={operator}
          onChange={(e) => {
            onOperatorChange(e.target.value as TelecomOperator);
            sounds.playClick();
          }}
          className="w-full p-3.5 bg-[#09182b] text-white border border-[#208fc0] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 cursor-pointer transition-colors"
        >
          {OPERATORS.map((op) => (
            <option key={op} value={op} className="bg-[#09182b] text-white">
              {op} Pakistan (4G / VoLTE)
            </option>
          ))}
        </select>
      </div>

      {/* Status Bar */}
      <div className="mt-3.5 pt-3 border-t border-[#1a3857] flex items-center justify-between text-xs">
        <div className="text-[#9cb9d5]">
          {tr.selectedSim}{' '}
          <span className="text-cyan-300 font-bold ml-1">
            {selectedSim} ({operator})
          </span>
        </div>
        <div className={`px-2 py-0.5 rounded border text-[11px] font-mono ${OPERATOR_COLORS[operator].bg} ${OPERATOR_COLORS[operator].text} ${OPERATOR_COLORS[operator].border}`}>
          {operator} Active
        </div>
      </div>
    </div>
  );
};
