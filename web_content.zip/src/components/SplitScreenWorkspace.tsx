import React, { useState } from 'react';
import {
  LayoutGrid,
  Sparkles,
  Film,
  MessageSquare,
  Calculator,
  Image as ImageIcon,
  Camera,
  Maximize2,
  Columns,
  Rows,
  ArrowLeftRight,
  X
} from 'lucide-react';
import { AppSettings, LogoItem, VideoItem, SplitAppType } from '../types';

interface SplitScreenWorkspaceProps {
  settings: AppSettings;
  activeLogo: LogoItem | null;
  savedLogos: LogoItem[];
  savedVideos: VideoItem[];
  renderLogoDesigner: () => React.ReactNode;
  renderVideoStudio: () => React.ReactNode;
  renderCalculator: () => React.ReactNode;
  renderJulliChat: () => React.ReactNode;
  renderGallery: () => React.ReactNode;
  renderCamera: () => React.ReactNode;
  onCloseSplit: () => void;
}

const APPS: { id: SplitAppType; name: string; icon: any }[] = [
  { id: 'logo', name: 'Logo Designer', icon: Sparkles },
  { id: 'animate', name: 'Video Studio', icon: Film },
  { id: 'julli', name: 'Julli AI Assistant', icon: MessageSquare },
  { id: 'calculator', name: 'Smart Calculator', icon: Calculator },
  { id: 'gallery', name: 'Media Gallery', icon: ImageIcon },
  { id: 'camera', name: 'Camera Snapper', icon: Camera },
];

export const SplitScreenWorkspace: React.FC<SplitScreenWorkspaceProps> = ({
  renderLogoDesigner,
  renderVideoStudio,
  renderCalculator,
  renderJulliChat,
  renderGallery,
  renderCamera,
  onCloseSplit,
}) => {
  const [leftApp, setLeftApp] = useState<SplitAppType>('logo');
  const [rightApp, setRightApp] = useState<SplitAppType>('julli');
  const [splitRatio, setSplitRatio] = useState<'50-50' | '70-30' | '30-70'>('50-50');
  const [orientation, setOrientation] = useState<'horizontal' | 'vertical'>('horizontal');

  const swapApps = () => {
    const temp = leftApp;
    setLeftApp(rightApp);
    setRightApp(temp);
  };

  const renderComponentFor = (appType: SplitAppType) => {
    switch (appType) {
      case 'logo':
        return renderLogoDesigner();
      case 'animate':
        return renderVideoStudio();
      case 'calculator':
        return renderCalculator();
      case 'julli':
        return renderJulliChat();
      case 'gallery':
        return renderGallery();
      case 'camera':
        return renderCamera();
      default:
        return renderLogoDesigner();
    }
  };

  // Determine flex basis classes based on splitRatio
  const leftClass =
    splitRatio === '50-50'
      ? 'flex-1'
      : splitRatio === '70-30'
      ? orientation === 'horizontal' ? 'w-full lg:w-7/12' : 'h-7/12'
      : orientation === 'horizontal' ? 'w-full lg:w-5/12' : 'h-5/12';

  const rightClass =
    splitRatio === '50-50'
      ? 'flex-1'
      : splitRatio === '70-30'
      ? orientation === 'horizontal' ? 'w-full lg:w-5/12' : 'h-5/12'
      : orientation === 'horizontal' ? 'w-full lg:w-7/12' : 'h-7/12';

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] w-full overflow-hidden bg-slate-950">
      {/* Split Screen Control Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-bold text-indigo-400">
            <LayoutGrid className="w-4 h-4" />
            <span>Dual Split Screen Mode (Ek Saath Do App)</span>
          </div>

          {/* Left App Picker */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 px-1 font-semibold">Pane 1:</span>
            <select
              value={leftApp}
              onChange={(e) => setLeftApp(e.target.value as SplitAppType)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              {APPS.map((a) => (
                <option key={a.id} value={a.id} className="bg-slate-900">
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={swapApps}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title="Swap Panes"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
          </button>

          {/* Right App Picker */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 px-1 font-semibold">Pane 2:</span>
            <select
              value={rightApp}
              onChange={(e) => setRightApp(e.target.value as SplitAppType)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              {APPS.map((a) => (
                <option key={a.id} value={a.id} className="bg-slate-900">
                  {a.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Ratio & Orientation buttons */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setSplitRatio('50-50')}
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                splitRatio === '50-50' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              50 : 50
            </button>
            <button
              onClick={() => setSplitRatio('70-30')}
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                splitRatio === '70-30' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              70 : 30
            </button>
            <button
              onClick={() => setSplitRatio('30-70')}
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                splitRatio === '30-70' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              30 : 70
            </button>
          </div>

          <button
            onClick={() => setOrientation(orientation === 'horizontal' ? 'vertical' : 'horizontal')}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
            title="Toggle Horizontal / Vertical orientation"
          >
            {orientation === 'horizontal' ? <Columns className="w-3.5 h-3.5" /> : <Rows className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onCloseSplit}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-slate-400 flex items-center gap-1 transition-colors"
          >
            <X className="w-3.5 h-3.5" /> Exit Split
          </button>
        </div>
      </div>

      {/* Dual Pane Layout */}
      <div
        className={`flex-1 overflow-hidden flex ${
          orientation === 'horizontal' ? 'flex-col lg:flex-row' : 'flex-col'
        }`}
      >
        {/* Left / Top Pane */}
        <div
          className={`${leftClass} overflow-y-auto border-r border-b border-slate-800/80 bg-slate-950/50 p-2 relative`}
        >
          <div className="absolute top-2 right-2 z-10 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-900/90 text-indigo-300 border border-indigo-500/30">
            {APPS.find((a) => a.id === leftApp)?.name}
          </div>
          {renderComponentFor(leftApp)}
        </div>

        {/* Right / Bottom Pane */}
        <div className={`${rightClass} overflow-y-auto bg-slate-950/50 p-2 relative`}>
          <div className="absolute top-2 right-2 z-10 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-900/90 text-purple-300 border border-purple-500/30">
            {APPS.find((a) => a.id === rightApp)?.name}
          </div>
          {renderComponentFor(rightApp)}
        </div>
      </div>
    </div>
  );
};
