import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useVideo } from '../context/VideoContext';
import { formatTimeCode } from '../utils/format';
import {
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  Volume1,
  VolumeX,
  Maximize,
  Minimize,
  SkipForward,
  Settings,
  MessageSquare,
  PictureInPicture2,
  Check,
} from 'lucide-react';

export const VideoPlayerModal: React.FC = () => {
  const {
    activeVideo,
    setActiveVideo,
    setYoutubeVideo,
    saveWatchProgress,
    watchHistory,
    playNextVideo,
    language,
  } = useVideo();

  if (!activeVideo) return null;

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(activeVideo.duration || 0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showSubtitleMenu, setShowSubtitleMenu] = useState(false);
  const [selectedSubtitle, setSelectedSubtitle] = useState<'off' | 'en' | 'ur'>('off');
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState<number>(0);
  const [isBuffering, setIsBuffering] = useState(false);

  const hideControlsTimer = useRef<NodeJS.Timeout | null>(null);

  // Resume from previous watch progress
  useEffect(() => {
    const prev = watchHistory.find((h) => h.videoId === activeVideo.id);
    if (prev && prev.currentTime > 5 && prev.currentTime < (prev.duration - 10)) {
      if (videoRef.current) {
        videoRef.current.currentTime = prev.currentTime;
      }
    }
  }, [activeVideo.id]);

  // Handle controls auto-hide
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideControlsTimer.current) {
      clearTimeout(hideControlsTimer.current);
    }
    hideControlsTimer.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
        setShowSpeedMenu(false);
        setShowSubtitleMenu(false);
      }
    }, 3200);
  }, [isPlaying]);

  useEffect(() => {
    window.addEventListener('mousemove', resetHideTimer);
    return () => {
      window.removeEventListener('mousemove', resetHideTimer);
      if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    };
  }, [resetHideTimer]);

  // Periodic watch progress saving
  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef.current && !videoRef.current.paused) {
        saveWatchProgress(
          activeVideo.id,
          videoRef.current.currentTime,
          videoRef.current.duration || duration
        );
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [activeVideo.id, duration, saveWatchProgress]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture if focused on an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      switch (e.key) {
        case ' ':
        case 'k':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowLeft':
        case 'j':
          e.preventDefault();
          skip(-10);
          break;
        case 'ArrowRight':
        case 'l':
          e.preventDefault();
          skip(10);
          break;
        case 'm':
          e.preventDefault();
          toggleMute();
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
        case 'Escape':
          if (!document.fullscreenElement) {
            handleClose();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, volume]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
    resetHideTimer();
  };

  const skip = (seconds: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.currentTime + seconds, duration));
    resetHideTimer();
  };

  const handleVolumeChange = (newVol: number) => {
    if (!videoRef.current) return;
    videoRef.current.volume = newVol;
    setVolume(newVol);
    setIsMuted(newVol === 0);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
      videoRef.current.volume = volume || 0.5;
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => console.error(err));
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch((err) => console.error(err));
      setIsFullscreen(false);
    }
  };

  const togglePiP = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (e) {
      console.error('PiP error:', e);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleProgressScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || !videoRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, clickX / rect.width));
    const newTime = percentage * duration;
    videoRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleProgressMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const hoverX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, hoverX / rect.width));
    setHoverTime(percentage * duration);
    setHoverPosition(hoverX);
  };

  const handleClose = () => {
    if (videoRef.current) {
      saveWatchProgress(activeVideo.id, videoRef.current.currentTime, videoRef.current.duration || duration);
      videoRef.current.pause();
    }
    setActiveVideo(null);
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 bg-black flex items-center justify-center select-none overflow-hidden"
      onMouseMove={resetHideTimer}
      onClick={(e) => {
        // Toggle play if clicking on the main backdrop video area
        if ((e.target as HTMLElement).tagName === 'VIDEO') {
          togglePlay();
        }
      }}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={activeVideo.videoUrl}
        poster={activeVideo.backdropUrl || activeVideo.thumbnailUrl}
        autoPlay
        playsInline
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onWaiting={() => setIsBuffering(true)}
        onPlaying={() => setIsBuffering(false)}
        onEnded={() => {
          setIsPlaying(false);
          playNextVideo();
        }}
        className="w-full h-full object-contain cursor-pointer"
      />

      {/* Buffering Spinner */}
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {/* Custom Subtitles Overlay */}
      {selectedSubtitle !== 'off' && (
        <div className="absolute bottom-24 inset-x-0 text-center pointer-events-none px-4">
          <span className="bg-black/80 text-yellow-300 text-lg sm:text-2xl px-4 py-1.5 rounded font-medium shadow-2xl">
            {selectedSubtitle === 'ur'
              ? 'یہ ویڈیو CineStream نیٹ فلکس پلیئر پر چل رہی ہے...'
              : 'Now streaming on CineStream Netflix High-Definition Player...'}
          </span>
        </div>
      )}

      {/* Top Header Overlay */}
      <div
        className={`absolute top-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-b from-black/90 via-black/40 to-transparent flex items-center justify-between transition-opacity duration-300 z-40 ${
          showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center space-x-4">
          <button
            onClick={handleClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
            title="Back to Browse (Esc)"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h2 className="text-white font-extrabold text-base sm:text-xl drop-shadow">
              {activeVideo.title}
            </h2>
            <p className="text-zinc-400 text-xs flex items-center space-x-2">
              <span className="text-[#E50914] font-bold uppercase tracking-wider">CineStream</span>
              <span>•</span>
              <span>{activeVideo.quality} Ultra HD</span>
              <span>•</span>
              <span>{activeVideo.rating}</span>
            </p>
          </div>
        </div>

        {/* Switch to YouTube View Button */}
        <button
          onClick={() => {
            saveWatchProgress(activeVideo.id, videoRef.current?.currentTime || currentTime, duration);
            setActiveVideo(null);
            setYoutubeVideo(activeVideo);
          }}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-red-600/30 hover:bg-red-600/50 border border-red-500/40 text-white text-xs font-semibold backdrop-blur-sm transition-all transform hover:scale-105 active:scale-95 cursor-pointer shadow-lg"
          title="Watch with YouTube layout & comments"
        >
          <div className="w-3.5 h-3.5 rounded-xs bg-[#E50914] flex items-center justify-center">
            <Play className="w-2 h-2 fill-white text-white ml-0.5" />
          </div>
          <span>{language === 'ur' ? 'یوٹیوب موڈ میں دیکھیں' : 'Switch to YouTube View'}</span>
        </button>
      </div>

      {/* Bottom Controls Overlay */}
      <div
        className={`absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black/95 via-black/60 to-transparent transition-opacity duration-300 z-40 ${
          showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Scrubber / Progress Bar */}
        <div
          ref={progressBarRef}
          onClick={handleProgressScrub}
          onMouseMove={handleProgressMouseMove}
          onMouseLeave={() => setHoverTime(null)}
          className="relative h-2 hover:h-3.5 bg-white/20 hover:bg-white/30 rounded-full cursor-pointer transition-all duration-150 mb-4 group"
        >
          {/* Watched progress (red) */}
          <div
            className="absolute top-0 left-0 bottom-0 bg-[#E50914] rounded-full flex items-center justify-end"
            style={{ width: `${progressPercent}%` }}
          >
            {/* Scrubber Knob */}
            <div className="w-3.5 h-3.5 bg-[#E50914] border-2 border-white rounded-full shadow-md transform scale-0 group-hover:scale-100 transition-transform -mr-1" />
          </div>

          {/* Hover Time Tooltip */}
          {hoverTime !== null && (
            <div
              className="absolute -top-9 -translate-x-1/2 bg-black/90 text-white text-xs px-2 py-0.5 rounded font-mono border border-white/20 pointer-events-none"
              style={{ left: `${hoverPosition}px` }}
            >
              {formatTimeCode(hoverTime)}
            </div>
          )}
        </div>

        {/* Control Buttons Dock */}
        <div className="flex items-center justify-between text-white">
          {/* Left Controls */}
          <div className="flex items-center space-x-3 sm:space-x-5">
            {/* Play/Pause */}
            <button
              onClick={togglePlay}
              className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            >
              {isPlaying ? <Pause className="w-6 h-6 fill-white" /> : <Play className="w-6 h-6 fill-white" />}
            </button>

            {/* Skip 10s Backward */}
            <button
              onClick={() => skip(-10)}
              className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
              title="Rewind 10s (Left Arrow)"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            {/* Skip 10s Forward */}
            <button
              onClick={() => skip(10)}
              className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
              title="Fast Forward 10s (Right Arrow)"
            >
              <RotateCw className="w-5 h-5" />
            </button>

            {/* Volume Control */}
            <div className="flex items-center space-x-2 group/vol">
              <button
                onClick={toggleMute}
                className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
                title={isMuted ? 'Unmute (M)' : 'Mute (M)'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-5 h-5" />
                ) : volume < 0.5 ? (
                  <Volume1 className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-16 sm:w-24 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-[#E50914]"
              />
            </div>

            {/* Time Display */}
            <span className="text-xs sm:text-sm font-mono text-zinc-300">
              {formatTimeCode(currentTime)} / {formatTimeCode(duration)}
            </span>
          </div>

          {/* Right Controls */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Next Video */}
            <button
              onClick={playNextVideo}
              className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
              title="Play Next Title"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            {/* Subtitles & Audio Menu */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowSubtitleMenu(!showSubtitleMenu);
                  setShowSpeedMenu(false);
                }}
                className={`p-1.5 hover:text-red-500 transition-colors cursor-pointer ${
                  selectedSubtitle !== 'off' ? 'text-red-500' : ''
                }`}
                title="Subtitles & Audio"
              >
                <MessageSquare className="w-5 h-5" />
              </button>

              {showSubtitleMenu && (
                <div className="absolute right-0 bottom-10 bg-[#1c1c1c] border border-white/20 rounded-md p-3 w-48 shadow-2xl text-xs space-y-2 z-50">
                  <span className="text-zinc-400 font-bold block mb-1 uppercase tracking-wider text-[10px]">
                    Subtitles
                  </span>
                  {[
                    { id: 'off', label: 'Off' },
                    { id: 'en', label: 'English [CC]' },
                    { id: 'ur', label: 'اردو Subtitles' },
                  ].map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => {
                        setSelectedSubtitle(sub.id as any);
                        setShowSubtitleMenu(false);
                      }}
                      className={`w-full text-left py-1 px-2 rounded flex items-center justify-between hover:bg-zinc-800 ${
                        selectedSubtitle === sub.id ? 'text-red-500 font-bold bg-zinc-800/80' : 'text-zinc-300'
                      }`}
                    >
                      <span>{sub.label}</span>
                      {selectedSubtitle === sub.id && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Playback Speed Menu */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowSpeedMenu(!showSpeedMenu);
                  setShowSubtitleMenu(false);
                }}
                className="p-1.5 hover:text-red-500 transition-colors text-xs font-bold font-mono cursor-pointer"
                title="Playback Speed"
              >
                {playbackRate}x
              </button>

              {showSpeedMenu && (
                <div className="absolute right-0 bottom-10 bg-[#1c1c1c] border border-white/20 rounded-md p-2 w-32 shadow-2xl text-xs space-y-1 z-50">
                  <span className="text-zinc-400 font-bold block px-2 py-0.5 text-[10px] uppercase tracking-wider">
                    Speed
                  </span>
                  {[0.5, 0.75, 1, 1.25, 1.5, 2].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        if (videoRef.current) {
                          videoRef.current.playbackRate = rate;
                        }
                        setPlaybackRate(rate);
                        setShowSpeedMenu(false);
                      }}
                      className={`w-full text-left py-1 px-2 rounded flex items-center justify-between hover:bg-zinc-800 ${
                        playbackRate === rate ? 'text-red-500 font-bold bg-zinc-800/80' : 'text-zinc-300'
                      }`}
                    >
                      <span>{rate}x</span>
                      {playbackRate === rate && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Picture in Picture */}
            <button
              onClick={togglePiP}
              className="p-1.5 hover:text-red-500 transition-colors hidden sm:inline-block cursor-pointer"
              title="Picture in Picture"
            >
              <PictureInPicture2 className="w-5 h-5" />
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 hover:text-red-500 transition-colors cursor-pointer"
              title={isFullscreen ? 'Exit Fullscreen (F)' : 'Fullscreen (F)'}
            >
              {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
