import React from 'react';
import { MessageSquare, X } from 'lucide-react';
import type { InAppToast } from '../services/notificationService.ts';

interface NotificationToastProps {
  toast: InAppToast | null;
  onOpen: (chatId?: string) => void;
  onDismiss: () => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({
  toast,
  onOpen,
  onDismiss,
}) => {
  if (!toast) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4 animate-in slide-in-from-top duration-200">
      <div
        onClick={() => onOpen(toast.chatId)}
        className="p-3.5 rounded-2xl bg-[#0c121e] border border-cyan-500/50 shadow-[0_4px_25px_rgba(0,210,255,0.3)] flex items-center justify-between gap-3 text-slate-100 cursor-pointer hover:bg-[#0f1726] transition-colors"
      >
        <div className="flex items-center gap-3 min-w-0">
          <img
            src={toast.avatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=user'}
            alt=""
            className="w-10 h-10 rounded-xl bg-slate-900 border border-cyan-400 object-cover shrink-0"
          />
          <div className="min-w-0">
            <div className="font-bold text-white text-xs truncate flex items-center gap-1.5">
              <span>{toast.title}</span>
              <span className="text-[10px] font-semibold text-cyan-400 bg-cyan-950/80 px-1.5 py-0.2 rounded">
                New Message
              </span>
            </div>
            <div className="text-xs text-slate-300 truncate mt-0.5">
              {toast.body}
            </div>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onDismiss();
          }}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 shrink-0"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
};
