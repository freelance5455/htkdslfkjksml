import { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Student, Lesson, Currency } from '../types';
import { X, DollarSign, Sparkles, CheckCircle2 } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  preSelectedStudent?: Student | null;
  preSelectedLesson?: Lesson | null;
  onConfirmPayment: (paymentData: {
    studentId: string;
    studentName: string;
    amount: number;
    currency: Currency;
    lessonsCovered: number;
    cycleDescription: string;
    paymentMethod: 'Nakit' | 'Banka Havalesi / EFT' | 'Kredi Kartı' | 'Diğer';
    note?: string;
    date: string;
  }) => void;
}

export const PaymentModal = ({
  isOpen,
  onClose,
  students,
  preSelectedStudent,
  onConfirmPayment,
}: PaymentModalProps) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [amount, setAmount] = useState<number>(0);
  const [currency, setCurrency] = useState<Currency>('TL');
  const [lessonsCovered, setLessonsCovered] = useState<number>(4);
  const [cycleDescription, setCycleDescription] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'Nakit' | 'Banka Havalesi / EFT' | 'Kredi Kartı' | 'Diğer'>('Banka Havalesi / EFT');
  const [note, setNote] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().slice(0, 10));

  const activeStudent = students.find((s) => s.id === selectedStudentId);

  useEffect(() => {
    if (preSelectedStudent) {
      setSelectedStudentId(preSelectedStudent.id);
      const covered = preSelectedStudent.paymentFrequency || 4;
      setLessonsCovered(covered);
      setAmount(preSelectedStudent.hourlyRate * covered);
      setCurrency(preSelectedStudent.currency);
      setCycleDescription(
        `${covered} Derslik ${preSelectedStudent.subject === 'english' ? 'İngilizce' : 'Türkçe'} Paketi Tahsilatı`
      );
    } else if (students.length > 0 && !selectedStudentId) {
      const first = students[0];
      setSelectedStudentId(first.id);
      setLessonsCovered(first.paymentFrequency);
      setAmount(first.hourlyRate * first.paymentFrequency);
      setCurrency(first.currency);
      setCycleDescription(`${first.paymentFrequency} Derslik Paket Tahsilatı`);
    }
  }, [preSelectedStudent, students, isOpen]);

  const handleStudentChange = (id: string) => {
    setSelectedStudentId(id);
    const s = students.find((st) => st.id === id);
    if (s) {
      const covered = s.paymentFrequency || 4;
      setLessonsCovered(covered);
      setAmount(s.hourlyRate * covered);
      setCurrency(s.currency);
      setCycleDescription(
        `${covered} Derslik ${s.subject === 'english' ? 'İngilizce' : 'Türkçe'} Paketi Tahsilatı`
      );
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent || amount <= 0) return;

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (err) {
      // ignore
    }

    onConfirmPayment({
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      amount: Number(amount),
      currency,
      lessonsCovered: Number(lessonsCovered),
      cycleDescription: cycleDescription.trim() || `${lessonsCovered} Derslik Paket Ödemesi`,
      paymentMethod,
      note: note.trim(),
      date: new Date(paymentDate).toISOString(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-zinc-800">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 rounded-xl">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif text-white">
                Ödeme Alındı İşaretle & Cüzdana Ekle
              </h3>
              <p className="text-xs text-stone-400">
                Öğrenci döngüsünü sıfırlar ve cüzdan bakiyenize işler
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Öğrenci Seçin *
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => handleStudentChange(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
            >
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.subject === 'english' ? 'İngilizce' : 'Türkçe'} • {s.hourlyRate} {s.currency}/ders • Döngü: {s.lessonsInCurrentCycle}/{s.paymentFrequency})
                </option>
              ))}
            </select>
          </div>

          {activeStudent && (
            <div className="bg-emerald-950/40 border border-emerald-500/40 p-3 rounded-xl flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-emerald-300">
                  Döngü Durumu: {activeStudent.lessonsInCurrentCycle} / {activeStudent.paymentFrequency} ders tamamlandı
                </span>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Ödeme alındığında bu öğrencinin döngüsü sıfırlanıp yeni döngü başlar.
                </p>
              </div>
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Tahsil Edilen Tutar *
              </label>
              <input
                type="number"
                min="1"
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm bg-zinc-900 border border-zinc-800 rounded-xl font-mono font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Para Birimi
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setCurrency('TL')}
                  className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    currency === 'TL'
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-zinc-900 border-zinc-800 text-stone-400'
                  }`}
                >
                  ₺ (TL)
                </button>
                <button
                  type="button"
                  onClick={() => setCurrency('USD')}
                  className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    currency === 'USD'
                      ? 'bg-sky-600 text-white border-sky-500'
                      : 'bg-zinc-900 border-zinc-800 text-stone-400'
                  }`}
                >
                  $ (USD)
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Sayısı
              </label>
              <input
                type="number"
                min="1"
                value={lessonsCovered}
                onChange={(e) => setLessonsCovered(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-bold text-center text-white"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Açıklama / Paket Adı
              </label>
              <input
                type="text"
                value={cycleDescription}
                onChange={(e) => setCycleDescription(e.target.value)}
                placeholder="Örn: 4 Ders Paketi Ödemesi"
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-medium text-white placeholder:text-stone-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ödeme Yöntemi
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
              >
                <option value="Banka Havalesi / EFT">Banka Havalesi / EFT</option>
                <option value="Nakit">Nakit Elden</option>
                <option value="Kredi Kartı">Kredi Kartı</option>
                <option value="Diğer">Diğer</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Tahsilat Tarihi
              </label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-mono font-medium text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Makbuz Notu (İsteğe bağlı)
            </label>
            <input
              type="text"
              placeholder="Örn: WhatsApp'tan dekont iletildi."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder:text-stone-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-stone-400 hover:text-white rounded-xl transition-all cursor-pointer"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg shadow-emerald-950/50 transition-all cursor-pointer active:scale-95 flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Cüzdana Kaydet</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
