import React, { useState } from 'react';
import { X, CreditCard, Check, AlertCircle } from 'lucide-react';
import { Customer } from '../db/indexedDB';
import { formatMoney } from '../utils/calc';
import { sound } from '../utils/sound';

interface PaymentModalProps {
  customer: Customer | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (customerId: string, amount: number, notes: string, shouldPrint?: boolean) => Promise<void>;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  customer,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('تحصيل نقدي');
  const [shouldPrint, setShouldPrint] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !customer) return null;

  const currentBalance = Number(customer.balance) || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const num = Number(amount);
    if (!Number.isFinite(num) || num <= 0) {
      setError('يرجى إدخال مبلغ تحصيل صحيح أكبر من صفر');
      sound.playError();
      return;
    }
    if (num > currentBalance) {
      setError('مبلغ التحصيل أكبر من إجمالي مديونية العميل');
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      await onConfirm(customer.id, num, notes, shouldPrint);
      sound.playSuccess();
      onClose();
    } catch {
      setError('حدث خطأ أثناء حفظ التحصيل');
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-right">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">تحصيل دفعة نقدية</h3>
              <p className="text-xs text-slate-400">{customer.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Balance Preview */}
          <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700/60 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block">المديونية الحالية</span>
              <span className="text-lg font-black text-rose-400 font-mono">
                {formatMoney(currentBalance)} ج.م
              </span>
            </div>
            <button
              type="button"
              onClick={() => setAmount(String(currentBalance))}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-bold active:scale-95 transition"
            >
              تحصيل كامل المديونية
            </button>
          </div>

          {/* Amount input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              المبلغ المحصل (ج.م) *
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max={currentBalance}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full text-base font-bold font-mono bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
              required
              autoFocus
            />
          </div>

          {/* Quick chip increments */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {[50, 100, 200, 500, 1000].map((val) => (
              <button
                key={val}
                type="button"
                onClick={() => setAmount(String(Math.min(currentBalance, (Number(amount) || 0) + val)))}
                className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700 shrink-0 active:scale-95 transition"
              >
                +{val}
              </button>
            ))}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              البيان / ملاحظات التحصيل
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: تحصيل كاش دفعة من الحساب"
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Print receipt option */}
          <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={shouldPrint}
              onChange={(e) => setShouldPrint(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-500 bg-slate-700 border-slate-600 focus:ring-0"
            />
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>طباعة سند قبض وإيصال سداد حراري 80mm للعميل</span>
            </span>
          </label>

          {/* Action buttons */}
          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg shadow-emerald-950"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'جاري الحفظ…' : 'اعتماد التحصيل وإيداع الخزنة'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
