import React, { useState } from 'react';
import { sampleAnalyzedSentences } from '../data/sentenceAnalysisData';
import { SentenceToken } from '../types';
import { useLanguage } from '../context/LanguageContext';
import {
  BookOpen,
  Sparkles,
  Info,
  CheckCircle,
  HelpCircle,
  Layers
} from 'lucide-react';

export const SentenceAnalyzerView: React.FC = () => {
  const { language, getText, isRtl } = useLanguage();
  const [selectedSentenceId, setSelectedSentenceId] = useState<string>(sampleAnalyzedSentences[0].id);
  const [activeToken, setActiveToken] = useState<SentenceToken | null>(sampleAnalyzedSentences[0].tokens[0]);

  const currentSentence = sampleAnalyzedSentences.find((s) => s.id === selectedSentenceId) || sampleAnalyzedSentences[0];

  const getCaseStateBadge = (state: SentenceToken['caseState']) => {
    switch (state) {
      case 'marfoo':
        return {
          bg: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          label: language === 'pashto' ? 'مرفوع (حالتِ رفع)' : language === 'urdu' ? 'مرفوع (حالتِ رفع)' : 'Nominative (Marfoo\')'
        };
      case 'mansoob':
        return {
          bg: 'bg-amber-100 text-amber-800 border-amber-300',
          label: language === 'pashto' ? 'منصوب (حالتِ نصب)' : language === 'urdu' ? 'منصوب (حالتِ نصب)' : 'Accusative (Mansoob)'
        };
      case 'majroor':
        return {
          bg: 'bg-sky-100 text-sky-800 border-sky-300',
          label: language === 'pashto' ? 'مجرور (حالتِ جر)' : language === 'urdu' ? 'مجرور (حالتِ جر)' : 'Genitive (Majroor)'
        };
      case 'majzoom':
        return {
          bg: 'bg-rose-100 text-rose-800 border-rose-300',
          label: language === 'pashto' ? 'مجزوم (حالتِ جزم)' : language === 'urdu' ? 'مجزوم (حالتِ جزم)' : 'Jussive (Majzoom)'
        };
      case 'mabni':
      default:
        return {
          bg: 'bg-stone-200 text-stone-800 border-stone-300',
          label: language === 'pashto' ? 'مبني (نه بدلېدونکی)' : language === 'urdu' ? 'مبنی (ناقابلِ تغیر)' : 'Indeclinable (Mabni)'
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-emerald-950 to-stone-900 text-white p-6 sm:p-8 rounded-3xl border border-amber-500/20 shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>
              {language === 'pashto'
                ? 'د ترکیب او اعراب متقابل تحلیلګر'
                : language === 'urdu'
                ? 'ترکیبِ نحوی اور اعراب کا انٹرایکٹو نظام'
                : 'Interactive I\'rab & Syntax Analyzer'}
            </span>
          </div>

          <h2 className="font-arabic text-3xl sm:text-4xl font-bold text-amber-200 mb-2">
            مُحَلِّلُ التَّرْكِيبِ النَّحْوِيِّ وَمَوَاقِعِ الإِعْرَابِ
          </h2>

          <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
            {language === 'pashto'
              ? 'د قرآن کریم او فصیح عربي جملو ترکیب وګورئ. په هر توري یا لفظ کلیک وکړئ تر څو د هغې دقیق اعراب، عامل، او د نحو بشپړ قانون درته څرګند شي.'
              : language === 'urdu'
              ? 'قرآن مجید اور فصیح عربی جملوں کی ترکیبِ نحوی دیکھیے۔ ہر لفظ پر کلک کر کے اس کا محلِ اعراب، عامل، علامت اور مکمل نحوی قاعدہ دیکھیں۔'
              : 'Explore deep grammatical parsing (Tarkib) of Quranic and classical verses. Click on any word token to inspect its grammatical role, governor (Aamil), case marker, and linguistic justification.'}
          </p>
        </div>
      </div>

      {/* Sentence Selection */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1">
          {language === 'pashto' ? 'جمله وټاکئ:' : language === 'urdu' ? 'جملہ منتخب کریں:' : 'Select Sentence:'}
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {sampleAnalyzedSentences.map((sent) => {
            const isSelected = selectedSentenceId === sent.id;
            return (
              <button
                key={sent.id}
                onClick={() => {
                  setSelectedSentenceId(sent.id);
                  setActiveToken(sent.tokens[0]);
                }}
                className={`p-4 rounded-xl text-center border transition-all ${
                  isSelected
                    ? 'bg-emerald-900 text-white border-emerald-700 shadow-sm ring-2 ring-emerald-500/50'
                    : 'bg-stone-50 text-stone-800 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <span className="font-arabic text-xl font-bold block text-amber-300 mb-1">
                  {sent.arabicText}
                </span>
                <span className="text-xs text-stone-300 block truncate">
                  {getText(sent.sentenceType)}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Sentence Interactive Board */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 space-y-6">
        <div className="text-center py-6 bg-stone-900 rounded-2xl border border-stone-800 text-white relative overflow-hidden">
          <span className="text-xs font-semibold text-amber-400 uppercase tracking-widest block mb-2">
            {currentSentence.source} • {getText(currentSentence.sentenceType)}
          </span>

          <h3 className="font-arabic text-3xl sm:text-5xl font-bold text-amber-200 tracking-wider mb-4 px-4">
            {currentSentence.arabicText}
          </h3>

          <p className="text-sm sm:text-base text-stone-300 max-w-2xl mx-auto px-4 italic">
            "{getText(currentSentence.translation)}"
          </p>
        </div>

        {/* Clickable Word Tokens */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              {language === 'pashto'
                ? 'د هر لفظ اعراب کتلو لپاره ورباندې کلیک وکړئ:'
                : language === 'urdu'
                ? 'تفصیلی اعراب دیکھنے کے لیے لفظ پر کلک کریں:'
                : 'Click any word to inspect its syntactic breakdown:'}
            </span>
            <span className="text-xs text-emerald-700 font-semibold">
              {currentSentence.tokens.length} {language === 'pashto' ? 'کلمې' : language === 'urdu' ? 'کلمات' : 'Tokens'}
            </span>
          </div>

          <div className="flex flex-wrap gap-3 justify-center dir-rtl">
            {currentSentence.tokens.map((token, idx) => {
              const isSelected = activeToken?.word === token.word;
              const badge = getCaseStateBadge(token.caseState);
              return (
                <button
                  key={idx}
                  onClick={() => setActiveToken(token)}
                  className={`flex flex-col items-center p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-800 text-white border-emerald-600 shadow-md ring-2 ring-amber-400'
                      : 'bg-stone-50 text-stone-900 border-stone-200 hover:bg-stone-100 hover:border-emerald-300'
                  }`}
                >
                  <span className="font-arabic text-2xl font-bold tracking-wide">
                    {token.word}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold mt-1.5 border ${
                      isSelected ? 'bg-amber-400 text-stone-950 border-amber-300' : badge.bg
                    }`}
                  >
                    {token.roleArabic}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Word Token Deep Inspector */}
        {activeToken && (
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-stone-50 rounded-2xl p-6 border border-emerald-200 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-200/60 pb-3">
              <div className="flex items-center gap-3">
                <span className="font-arabic text-3xl font-bold text-emerald-950">
                  {activeToken.word}
                </span>
                <span className="font-arabic text-base font-semibold text-emerald-800">
                  [{activeToken.roleArabic}]
                </span>
              </div>

              <div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getCaseStateBadge(activeToken.caseState).bg}`}>
                  {getCaseStateBadge(activeToken.caseState).label}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
              <div className="bg-white p-4 rounded-xl border border-emerald-100 shadow-xs">
                <span className="text-xs font-bold text-emerald-900 uppercase block mb-1">
                  {language === 'pashto' ? 'د اعراب علامت (نښه):' : language === 'urdu' ? 'علامتِ اعراب:' : 'Inflectional Sign (I\'rab Marker):'}
                </span>
                <p className="font-medium text-stone-800">
                  {getText(activeToken.caseSign)}
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-emerald-100 shadow-xs">
                <span className="text-xs font-bold text-emerald-900 uppercase block mb-1">
                  {language === 'pashto' ? 'تفصیلي نحوي وضاحت:' : language === 'urdu' ? 'تفصیلی نحوی تشریح:' : 'Syntactic Justification:'}
                </span>
                <p className="font-medium text-stone-800">
                  {getText(activeToken.explanation)}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tarkib Complete Sentence Synthesis */}
        <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200">
          <h4 className="text-sm font-bold text-stone-800 flex items-center gap-2 mb-2">
            <Layers className="w-4 h-4 text-amber-600" />
            <span>
              {language === 'pashto' ? 'د ټولې جملې د ترکیب لنډیز:' : language === 'urdu' ? 'پوری جملے کی مجموعی ترکیبِ نحوی:' : 'Overall Structural Parsing Synthesis (Tarkib):'}
            </span>
          </h4>
          <p className="text-stone-700 text-xs sm:text-sm leading-relaxed font-mono bg-white p-3.5 rounded-xl border border-stone-200">
            {getText(currentSentence.tarkibSummary)}
          </p>
        </div>
      </div>
    </div>
  );
};
