import React, { useState, useEffect, useRef } from 'react';
import { Heart, Globe, CreditCard, ShieldCheck, CheckCircle2, ArrowRight, Smartphone, Sparkles, Send, ExternalLink, Target, MessageSquare, Award, PieChart as PieChartIcon, HelpCircle, QrCode, Clock, RefreshCw, Calendar, ChevronRight, Copy, Maximize2, Minimize2, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { QRCodeSVG } from 'qrcode.react';
import { offlineCache } from '../lib/offlineCache';

interface SupportOfferingsViewProps {
  onReturnToApp?: () => void;
}

interface GratitudePost {
  id: string;
  name: string;
  message: string;
  date: string;
  amount: string;
}

const INITIAL_GRATITUDE_POSTS: GratitudePost[] = [
  { id: 'g-1', name: 'Brother Emmanuel K.', message: 'Praise God! After sowing my prophetic seed for the ministry broadcast, my family received unexpected financial turnaround within 48 hours!', date: '2026-08-02', amount: '$100 USD' },
  { id: 'g-2', name: 'Sister Deborah A.', message: 'The 528Hz soaking worship and daily devotionals have brought profound inner peace. Sowing here is my greatest joy.', date: '2026-08-01', amount: '25,000 NGN' },
  { id: 'g-3', name: 'Pastor Michael O.', message: 'Thank you Prophet Juhnkrix for your uncompromising fidelity to the Word. May the Lord multiply this global altar!', date: '2026-07-29', amount: '$250 USD' },
];

const IMPACT_DATA = [
  { name: 'Global Evangelism & Crusades', value: 35, color: '#f59e0b' },
  { name: 'Live Broadcast Infrastructure', value: 30, color: '#3b82f6' },
  { name: 'Charity, Widows & Orphanages', value: 20, color: '#10b981' },
  { name: 'Worship Music & 528Hz Soaking', value: 15, color: '#8b5cf6' },
];

export const SupportOfferingsView: React.FC<SupportOfferingsViewProps> = ({ onReturnToApp }) => {
  const [selectedGateway, setSelectedGateway] = useState<string>('opay');
  const [supportAmount, setSupportAmount] = useState<string>('5000');
  const [donorName, setDonorName] = useState<string>('');
  const [donorEmail, setDonorEmail] = useState<string>('');
  const [successSubmitted, setSuccessSubmitted] = useState<boolean>(false);
  const [gatewayCurrency, setGatewayCurrency] = useState<string>('NGN');
  const [detectedCountry, setDetectedCountry] = useState<string>('Nigeria');

  useEffect(() => {
    // Automatically detect user's current residential country and currency based on browser locale or timezone
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      const lang = navigator.language || 'en-US';
      if (tz.includes('Lagos') || tz.includes('Africa') || lang.includes('en-NG')) {
        setGatewayCurrency('NGN');
        setDetectedCountry('Nigeria');
      } else if (tz.includes('London') || lang.includes('en-GB')) {
        setGatewayCurrency('GBP');
        setDetectedCountry('United Kingdom');
      } else if (tz.includes('Europe') || lang.includes('de') || lang.includes('fr')) {
        setGatewayCurrency('EUR');
        setDetectedCountry('Eurozone');
      } else if (tz.includes('America') || lang.includes('en-US')) {
        setGatewayCurrency('USD');
        setDetectedCountry('United States');
      } else if (tz.includes('Accra') || lang.includes('en-GH')) {
        setGatewayCurrency('GHS');
        setDetectedCountry('Ghana');
      } else if (tz.includes('Nairobi') || lang.includes('sw') || lang.includes('en-KE')) {
        setGatewayCurrency('KES');
        setDetectedCountry('Kenya');
      } else if (tz.includes('Johannesburg') || lang.includes('en-ZA')) {
        setGatewayCurrency('ZAR');
        setDetectedCountry('South Africa');
      }
    } catch (e) {
      // fallback default
    }
  }, []);
  
  const [activeAppModal, setActiveAppModal] = useState<{ name: string; accountNo: string; accountName: string } | null>(null);
  const [howToModal, setHowToModal] = useState<{ name: string; desc: string; accountNo: string } | null>(null);
  const [receiptModalData, setReceiptModalData] = useState<{ amount: string; platform: string; date: string; ref: string } | null>(null);
  
  const [recentlyUsed, setRecentlyUsed] = useState<string[]>(['opay', 'minipay', 'moniepoint']);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // New features state
  const [supportSubTab, setSupportSubTab] = useState<'gateways' | 'crypto'>('gateways');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [currencySearchQuery, setCurrencySearchQuery] = useState<string>('');
  const [copiedAddressKey, setCopiedAddressKey] = useState<string | null>(null);
  const [cardAmounts, setCardAmounts] = useState<Record<string, string>>({});
  
  // Fullscreen & Zoom immersion controls
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      if (containerRef.current?.requestFullscreen) {
        containerRef.current.requestFullscreen().catch(() => {});
      } else if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(() => {});
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(1.4, Number((prev + 0.1).toFixed(1))));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(0.7, Number((prev - 0.1).toFixed(1))));
  };

  const handleResetZoom = () => {
    setZoomLevel(1);
  };

  const handleDetectLocationGps = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsLocating(false);
        const { latitude, longitude } = position.coords;
        if (latitude > 4 && latitude < 14 && longitude > 2 && longitude < 15) {
          setGatewayCurrency('NGN');
          setDetectedCountry('Nigeria (GPS Verified)');
        } else if (latitude > 24 && latitude < 50 && longitude > -125 && longitude < -65) {
          setGatewayCurrency('USD');
          setDetectedCountry('United States / North America (GPS Verified)');
        } else if (latitude > 49 && latitude < 60 && longitude > -8 && longitude < 2) {
          setGatewayCurrency('GBP');
          setDetectedCountry('United Kingdom (GPS Verified)');
        } else if (latitude > 35 && latitude < 70 && longitude > -10 && longitude < 40) {
          setGatewayCurrency('EUR');
          setDetectedCountry('Eurozone (GPS Verified)');
        } else {
          setGatewayCurrency('USD');
          setDetectedCountry(`Global Region (${latitude.toFixed(1)}°, ${longitude.toFixed(1)}°) (GPS Verified)`);
        }
        setToastMsg('Successfully detected your geographic location via GPS & auto-selected local currency!');
        setTimeout(() => setToastMsg(null), 4000);
      },
      (error) => {
        setIsLocating(false);
        alert('Unable to retrieve location via GPS. Please select currency manually.');
      },
      { timeout: 10000 }
    );
  };

  const handleCopyCryptoAddress = (address: string, symbol: string) => {
    navigator.clipboard.writeText(address);
    setCopiedAddressKey(symbol);
    setToastMsg(`Copied ${symbol} Ministry Altar Wallet Address to clipboard!`);
    setTimeout(() => {
      setCopiedAddressKey(null);
      setToastMsg(null);
    }, 3000);
  };

  const CRYPTO_ALTAR_WALLETS = [
    { symbol: 'BTC', name: 'Bitcoin (Primary Altar Vault)', network: 'Bitcoin Mainnet / SegWit / Taproot', address: 'bc1qjuhnkrixaltarvaultbitcoin999777888', qr: 'bitcoin:bc1qjuhnkrixaltarvaultbitcoin999777888' },
    { symbol: 'ETH', name: 'Ethereum (ERC20 Glory Network)', network: 'Ethereum Mainnet / Arbitrum / Optimism', address: '0xJUHNKRIX999777888MinistryAltarVaultEthereumNetwork001', qr: 'ethereum:0xJUHNKRIX999777888MinistryAltarVaultEthereumNetwork001' },
    { symbol: 'USDT', name: 'Tether USD (Omni / TRC20 / ERC20 / SOL)', network: 'Tron (TRC20) / Ethereum (ERC20) / Solana', address: 'TXJUHNKRIXaltarUSDTtrc20Vault999777888TreasuryAddress', qr: 'tron:TXJUHNKRIXaltarUSDTtrc20Vault999777888TreasuryAddress' },
    { symbol: 'USDC', name: 'USD Coin Stablecoin', network: 'Ethereum / Polygon / Base / Solana', address: '0xJUHNKRIXUSDCstablecoinMinistryVault777888999', qr: 'ethereum:0xJUHNKRIXUSDCstablecoinMinistryVault777888999' },
    { symbol: 'SOL', name: 'Solana Network', network: 'Solana SPL Token Standard', address: 'JUHNKRIXsolanaAltarVaultNetwork999777888SolanaTokenProtocol', qr: 'solana:JUHNKRIXsolanaAltarVaultNetwork999777888SolanaTokenProtocol' },
    { symbol: 'BNB', name: 'Binance Smart Chain (BEP20)', network: 'BSC (BEP20)', address: '0xJUHNKRIXBinanceSmartChainAltarVault999777888Bsc', qr: 'ethereum:0xJUHNKRIXBinanceSmartChainAltarVault999777888Bsc' },
    { symbol: 'XRP', name: 'Ripple Ledger', network: 'XRP Ledger (Tag required)', address: 'rJUHNKRIXrippleAltarVaultLedger999777888 (Tag: 777)', qr: 'ripple:rJUHNKRIXrippleAltarVaultLedger999777888?dt=777' },
    { symbol: 'ADA', name: 'Cardano Network', network: 'Cardano Shelley Mainnet', address: 'addr1q9juhnkrixaltarcardanomercuryvault999777888', qr: 'cardano:addr1q9juhnkrixaltarcardanomercuryvault999777888' },
    { symbol: 'DOGE', name: 'Dogecoin', network: 'Dogecoin Mainnet', address: 'D8JUHNKRIXdogecoinAltarVaultCommunity999777888', qr: 'dogecoin:D8JUHNKRIXdogecoinAltarVaultCommunity999777888' },
    { symbol: 'TRX', name: 'Tron Network', network: 'Tron Mainnet (TRC20)', address: 'TXJUHNKRIXaltarUSDTtrc20Vault999777888TreasuryAddress', qr: 'tron:TXJUHNKRIXaltarUSDTtrc20Vault999777888TreasuryAddress' },
    { symbol: 'MATIC', name: 'Polygon Network', network: 'Polygon PoS / zkEVM', address: '0xJUHNKRIXPolygonAltarVaultNetwork999777888Matic', qr: 'ethereum:0xJUHNKRIXPolygonAltarVaultNetwork999777888Matic' },
    { symbol: 'LTC', name: 'Litecoin', network: 'Litecoin Mainnet', address: 'ltc1qjuhnkrixaltarvaultlitecoin999777888', qr: 'litecoin:ltc1qjuhnkrixaltarvaultlitecoin999777888' },
    { symbol: 'AVAX', name: 'Avalanche C-Chain', network: 'Avalanche C-Chain', address: '0xJUHNKRIXAvalancheAltarVaultCchain999777888', qr: 'ethereum:0xJUHNKRIXAvalancheAltarVaultCchain999777888' },
    { symbol: 'DOT', name: 'Polkadot', network: 'Polkadot Relay Chain', address: '16JUHNKRIXpolkadotAltarVaultNetwork999777888', qr: 'polkadot:16JUHNKRIXpolkadotAltarVaultNetwork999777888' },
    { symbol: 'LINK', name: 'Chainlink', network: 'Ethereum ERC20', address: '0xJUHNKRIXChainlinkAltarVaultERC20999777888', qr: 'ethereum:0xJUHNKRIXChainlinkAltarVaultERC20999777888' },
    { symbol: 'UNI', name: 'Uniswap', network: 'Ethereum ERC20', address: '0xJUHNKRIXUniswapAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXUniswapAltarVaultProtocol999777888' },
    { symbol: 'XLM', name: 'Stellar Lumens', network: 'Stellar Network (Memo required)', address: 'GJUHNKRIXstellarAltarVaultNetwork999777888 (Memo: 888)', qr: 'stellar:GJUHNKRIXstellarAltarVaultNetwork999777888?memo=888' },
    { symbol: 'ATOM', name: 'Cosmos Hub', network: 'Cosmos Mainnet', address: 'cosmos1juhnkrixaltarcosmosvault999777888', qr: 'cosmos:cosmos1juhnkrixaltarcosmosvault999777888' },
    { symbol: 'NEAR', name: 'NEAR Protocol', network: 'NEAR Mainnet', address: 'juhnkrix.near', qr: 'near:juhnkrix.near' },
    { symbol: 'ALGO', name: 'Algorand', network: 'Algorand Mainnet', address: 'JUHNKRIXalgorandAltarVaultNetwork999777888Algo', qr: 'algorand:JUHNKRIXalgorandAltarVaultNetwork999777888Algo' },
    { symbol: 'SHIB', name: 'Shiba Inu', network: 'Ethereum ERC20', address: '0xJUHNKRIXShibaInuAltarVaultERC20999777888', qr: 'ethereum:0xJUHNKRIXShibaInuAltarVaultERC20999777888' },
    { symbol: 'BCH', name: 'Bitcoin Cash', network: 'Bitcoin Cash Mainnet', address: 'bitcoincash:qjuhnkrixaltarbitcoincashvault999777888', qr: 'bitcoincash:qjuhnkrixaltarbitcoincashvault999777888' },
    { symbol: 'ICP', name: 'Internet Computer', network: 'ICP Ledger', address: 'juhnkrix-icp-altar-vault-ledger-999777888-icp', qr: 'icp:juhnkrix-icp-altar-vault-ledger-999777888-icp' },
    { symbol: 'FIL', name: 'Filecoin', network: 'Filecoin Mainnet', address: 'f1juhnkrixaltarfilecoinvault999777888', qr: 'filecoin:f1juhnkrixaltarfilecoinvault999777888' },
    { symbol: 'XMR', name: 'Monero Privacy', network: 'Monero Mainnet', address: '88JUHNKRIXmoneroprivacyaltarvaultnetwork999777888xmr', qr: 'monero:88JUHNKRIXmoneroprivacyaltarvaultnetwork999777888xmr' },
    { symbol: 'KAS', name: 'Kaspa', network: 'Kaspa DAG Mainnet', address: 'kaspa:qzjuhnkrixaltarkaspavault999777888', qr: 'kaspa:qzjuhnkrixaltarkaspavault999777888' },
    { symbol: 'SUI', name: 'Sui Network', network: 'Sui Mainnet', address: '0xJUHNAKRIXsuiAltarVaultNetwork999777888Sui', qr: 'sui:0xJUHNAKRIXsuiAltarVaultNetwork999777888Sui' },
    { symbol: 'APT', name: 'Aptos', network: 'Aptos Mainnet', address: '0xJUHNKRIXaptosAltarVaultNetwork999777888Aptos', qr: 'aptos:0xJUHNKRIXaptosAltarVaultNetwork999777888Aptos' },
    { symbol: 'ARB', name: 'Arbitrum', network: 'Arbitrum One Layer 2', address: '0xJUHNKRIXArbitrumAltarVaultL2999777888', qr: 'ethereum:0xJUHNKRIXArbitrumAltarVaultL2999777888' },
    { symbol: 'OP', name: 'Optimism', network: 'Optimism Layer 2', address: '0xJUHNKRIXOptimismAltarVaultL2999777888', qr: 'ethereum:0xJUHNKRIXOptimismAltarVaultL2999777888' },
    { symbol: 'TON', name: 'Toncoin', network: 'TON Mainnet', address: 'EQJUHNKRIXtoncoinAltarVaultNetwork999777888Ton', qr: 'ton:EQJUHNKRIXtoncoinAltarVaultNetwork999777888Ton' },
    { symbol: 'RENDER', name: 'Render Token', network: 'Solana / Ethereum', address: '0xJUHNKRIXRenderAltarVaultNetwork999777888', qr: 'ethereum:0xJUHNKRIXRenderAltarVaultNetwork999777888' },
    { symbol: 'INJ', name: 'Injective', network: 'Injective Mainnet', address: 'inj1juhnkrixaltarinjectivevault999777888', qr: 'injective:inj1juhnkrixaltarinjectivevault999777888' },
    { symbol: 'TAO', name: 'Bittensor', network: 'Bittensor Subtensor', address: '5JUHNKRIXbittensorAltarVaultNetwork999777888Tao', qr: 'bittensor:5JUHNKRIXbittensorAltarVaultNetwork999777888Tao' },
    { symbol: 'FET', name: 'Artificial Superintelligence', network: 'Fetch.ai Network', address: 'fetch1juhnkrixaltarfetchvault999777888', qr: 'fetch:fetch1juhnkrixaltarfetchvault999777888' },
    { symbol: 'TIA', name: 'Celestia', network: 'Celestia Modular Network', address: 'celestia1juhnkrixaltarcelestiavault999777888', qr: 'celestia:celestia1juhnkrixaltarcelestiavault999777888' },
    { symbol: 'SEI', name: 'Sei Network', network: 'Sei Mainnet', address: 'sei1juhnkrixaltarseivault999777888', qr: 'sei:sei1juhnkrixaltarseivault999777888' },
    { symbol: 'AAVE', name: 'Aave', network: 'Ethereum / Polygon', address: '0xJUHNKRIXAaveAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXAaveAltarVaultProtocol999777888' },
    { symbol: 'MKR', name: 'Maker', network: 'Ethereum MakerDAO', address: '0xJUHNKRIXMakerAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXMakerAltarVaultProtocol999777888' },
    { symbol: 'SNX', name: 'Synthetix', network: 'Ethereum / Optimism', address: '0xJUHNKRIXSynthetixAltarVault999777888', qr: 'ethereum:0xJUHNKRIXSynthetixAltarVault999777888' },
    { symbol: 'CRV', name: 'Curve DAO', network: 'Ethereum', address: '0xJUHNKRIXCurveAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXCurveAltarVaultProtocol999777888' },
    { symbol: 'COMP', name: 'Compound', network: 'Ethereum', address: '0xJUHNKRIXCompoundAltarVault999777888', qr: 'ethereum:0xJUHNKRIXCompoundAltarVault999777888' },
    { symbol: 'GRT', name: 'The Graph', network: 'Ethereum / Arbitrum', address: '0xJUHNKRIXGraphAltarVaultNetwork999777888', qr: 'ethereum:0xJUHNKRIXGraphAltarVaultNetwork999777888' },
    { symbol: 'PEPE', name: 'Pepe', network: 'Ethereum ERC20', address: '0xJUHNKRIXPepeAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXPepeAltarVaultProtocol999777888' },
    { symbol: 'FLOKI', name: 'Floki', network: 'Ethereum / BSC', address: '0xJUHNKRIXFlokiAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXFlokiAltarVaultProtocol999777888' },
    { symbol: 'ICP', name: 'Internet Computer', network: 'ICP Mainnet', address: 'juhnkrix-icp-altar-vault-ledger-999777888', qr: 'icp:juhnkrix-icp-altar-vault-ledger-999777888' },
    { symbol: 'CHZ', name: 'Chiliz', network: 'Chiliz Chain', address: '0xJUHNKRIXChilizAltarVaultProtocol999777888', qr: 'ethereum:0xJUHNKRIXChilizAltarVaultProtocol999777888' },
    { symbol: 'ZEC', name: 'Zcash', network: 'Zcash Privacy Shielded', address: 'zs1juhnkrixaltarzcashvaultshielded999777888', qr: 'zcash:zs1juhnkrixaltarzcashvaultshielded999777888' },
    { symbol: 'DASH', name: 'Dash', network: 'Dash PrivateSend Mainnet', address: 'Xjuhnkrixaltardashvaultnetwork999777888', qr: 'dash:Xjuhnkrixaltardashvaultnetwork999777888' },
    { symbol: 'NEO', name: 'Neo', network: 'Neo N3 Mainnet', address: 'AWJUHNKRIXneowalletaltarvault999777888', qr: 'neo:AWJUHNKRIXneowalletaltarvault999777888' },
  ];

  // Offline Status & USSD / Bank Transfer Codes State
  const [isOffline, setIsOffline] = useState<boolean>(typeof navigator !== 'undefined' ? !navigator.onLine : false);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Monthly Recurring Support State
  const [isRecurringEnabled, setIsRecurringEnabled] = useState<boolean>(false);
  const [recurringDay, setRecurringDay] = useState<string>('1');
  const [recurringAmount, setRecurringAmount] = useState<string>('10000');

  // Help Chat Widget State
  const [isHelpChatOpen, setIsHelpChatOpen] = useState<boolean>(false);
  const [helpChatMsg, setHelpChatMsg] = useState<string>('');
  const [helpChatLog, setHelpChatLog] = useState<{ sender: 'user' | 'support'; text: string }[]>([
    { sender: 'support', text: 'Blessings! Welcome to Prophet Juhnkrix Support Concierge. How can we assist with your seed offering today?' }
  ]);

  // Daily Spiritual Goal State
  const [dailyGoalTarget, setDailyGoalTarget] = useState<number>(100); // $100 USD target
  const [isEditingGoal, setIsEditingGoal] = useState<boolean>(false);
  const [tempGoalInput, setTempGoalInput] = useState<string>('100');

  // Gratitude Wall State
  const [gratitudePosts, setGratitudePosts] = useState<GratitudePost[]>(INITIAL_GRATITUDE_POSTS);
  const [newGratitudeName, setNewGratitudeName] = useState<string>('');
  const [newGratitudeMsg, setNewGratitudeMsg] = useState<string>('');
  const [newGratitudeAmount, setNewGratitudeAmount] = useState<string>('$50 USD');
  const [gratitudeSubmittedMsg, setGratitudeSubmittedMsg] = useState<boolean>(false);

  // Calculate current user total raised or sown today
  const profile = offlineCache.getProfile();
  const sowingHistory = profile.sowingHistory || [];
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySownUSD = sowingHistory
    .filter(r => r.date === todayStr)
    .reduce((acc, curr) => acc + curr.amountUSD, 45); // Default sample base if none today

  const goalProgressPercent = Math.min(100, Math.round((todaySownUSD / dailyGoalTarget) * 100));

  // Community Project Goal (e.g., Building Prophetic Prayer Altar)
  const communityProjectRaised = 42500;
  const communityProjectTarget = 50000;
  const communityProjectPercent = Math.min(100, Math.round((communityProjectRaised / communityProjectTarget) * 100));

  // Bank Search & Favorites State
  const [bankSearchQuery, setBankSearchQuery] = useState<string>('');
  const [favoriteBankIds, setFavoriteBankIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('juhnkrix_fav_banks');
      return saved ? JSON.parse(saved) : ['opay', 'minipay'];
    } catch {
      return ['opay', 'minipay'];
    }
  });
  const [collapsedRegions, setCollapsedRegions] = useState<Record<string, boolean>>({});
  const [storeDownloadModal, setStoreDownloadModal] = useState<any | null>(null);

  const toggleFavoriteBank = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated: string[];
    if (favoriteBankIds.includes(id)) {
      updated = favoriteBankIds.filter(i => i !== id);
    } else {
      updated = [...favoriteBankIds, id];
    }
    setFavoriteBankIds(updated);
    try {
      localStorage.setItem('juhnkrix_fav_banks', JSON.stringify(updated));
    } catch {}
  };

  const gateways = [
    { id: 'opay', name: 'Opay Mobile Bank', accountName: 'JUHNKRIX STEPHEN', accountNo: '7071918280 / 7055737988', desc: 'Instant mobile transfer & USSD', icon: '📱', licensed: 'Central Bank Licensed', region: 'West Africa', country: 'Nigeria', appScheme: 'opay://', storeUrl: 'https://play.google.com/store/apps/details?id=pay.opay' },
    { id: 'minipay', name: 'MiniPay (Opera / Web3)', accountName: 'JUHNKRIX STEPHEN', accountNo: 'juhnkrix@gmail.com / Stablecoin', desc: 'Fast global crypto & stablecoin support', icon: '⚡', licensed: 'Regulated Web3 Gateway', region: 'Crypto & Web3', country: 'Global / Web3', appScheme: 'minipay://', storeUrl: 'https://www.opera.com/minipay' },
    { id: 'moniepoint', name: 'Moniepoint MFB', accountName: 'JUHNKRIX STEPHEN', accountNo: 'Verified Merchant Altar', desc: 'Secure direct bank transfer', icon: '🏦', licensed: 'CBN Licensed MFB', region: 'West Africa', country: 'Nigeria', appScheme: 'moniepoint://', storeUrl: 'https://play.google.com/store/apps/details?id=com.moniepoint.mobile' },
    { id: 'palmpay', name: 'PalmPay', accountName: 'JUHNKRIX STEPHEN', accountNo: '7071918280', desc: 'Instant reward-backed offering', icon: '🌴', licensed: 'CBN Licensed Mobile Wallet', region: 'West Africa', country: 'Nigeria', appScheme: 'palmpay://', storeUrl: 'https://play.google.com/store/apps/details?id=com.palmpay.nigeria' },
    { id: 'stripe_intl', name: 'Stripe International (USD/EUR)', accountName: 'Prophet Juhnkrix Global Ministry', accountNo: 'Global Credit & Debit Cards', desc: 'International currency support worldwide', icon: '💳', licensed: 'PCI-DSS Level 1 Certified', region: 'Global & International', country: 'Worldwide', appScheme: 'stripe://', storeUrl: 'https://stripe.com' },
    { id: 'paypal_intl', name: 'PayPal Global Remittance', accountName: 'juhnkrix.musika@gmail.com', accountNo: 'Secure Worldwide Transfer', desc: 'Accepted in 200+ countries globally', icon: '🅿️', licensed: 'Licensed Global Financial Institution', region: 'Global & International', country: 'Worldwide', appScheme: 'paypal://', storeUrl: 'https://www.paypal.com' },
  ];

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 4000);
  };

  // Deep-link helper with app availability check & store fallback prompt
  const handleTriggerDeepLink = (gw: typeof gateways[0]) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(50);
    }
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    const startTime = Date.now();

    if (isMobile && gw.appScheme) {
      window.location.href = gw.appScheme;
    }

    setTimeout(() => {
      const elapsed = Date.now() - startTime;
      if (elapsed < 1200 && isMobile) {
        // App not detected on device -> Fallback to store download prompt modal
        setStoreDownloadModal(gw);
      } else {
        handleOpenBankApp(gw);
      }
    }, 900);
  };

  const handleOpenBankApp = (gw: { id: string; name: string; accountNo: string; accountName: string }) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(40);
    }
    if (!recentlyUsed.includes(gw.id)) {
      setRecentlyUsed([gw.id, ...recentlyUsed.slice(0, 4)]);
    } else {
      setRecentlyUsed([gw.id, ...recentlyUsed.filter(id => id !== gw.id)]);
    }

    setActiveAppModal(gw);
    triggerToast(`Successfully redirected to ${gw.name}. Please complete transfer.`);
  };

  const handleFinishBankOffering = (platformName: string) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([40, 40, 80]);
    }
    const numericAmt = parseFloat(supportAmount.replace(/[^0-9.]/g, '')) || 50;
    offlineCache.addSowingRecord({
      amountUSD: gatewayCurrency === 'USD' ? numericAmt : Math.round(numericAmt / 1500),
      category: 'Altar Offering',
      platform: platformName
    });

    setActiveAppModal(null);
    setSuccessSubmitted(true);
    
    setReceiptModalData({
      amount: `${supportAmount} ${gatewayCurrency}`,
      platform: platformName,
      date: new Date().toLocaleDateString(),
      ref: `JK-ALTR-${Math.floor(100000 + Math.random() * 900000)}`
    });

    setTimeout(() => {
      if (onReturnToApp) onReturnToApp();
    }, 4500);
  };

  const handleSubmitOffering = (e: React.FormEvent) => {
    e.preventDefault();
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([40, 60, 40]);
    }
    const numericAmt = parseFloat(supportAmount.replace(/[^0-9.]/g, '')) || 50;
    const activeGatewayName = gateways.find(g => g.id === selectedGateway)?.name || 'Opay Mobile Bank';
    
    offlineCache.addSowingRecord({
      amountUSD: gatewayCurrency === 'USD' ? numericAmt : Math.round(numericAmt / 1500),
      category: 'Prophetic Seed',
      platform: activeGatewayName
    });

    setSuccessSubmitted(true);
    setReceiptModalData({
      amount: `${supportAmount} ${gatewayCurrency}`,
      platform: activeGatewayName,
      date: new Date().toLocaleDateString(),
      ref: `JK-SEED-${Math.floor(100000 + Math.random() * 900000)}`
    });

    setTimeout(() => {
      if (onReturnToApp) onReturnToApp();
    }, 4500);
  };

  const handlePostGratitude = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGratitudeName || !newGratitudeMsg) return;
    const newPost: GratitudePost = {
      id: `grat-${Date.now()}`,
      name: newGratitudeName,
      message: newGratitudeMsg,
      date: new Date().toISOString().split('T')[0],
      amount: newGratitudeAmount
    };
    setGratitudePosts([newPost, ...gratitudePosts]);
    setNewGratitudeName('');
    setNewGratitudeMsg('');
    setGratitudeSubmittedMsg(true);
    setTimeout(() => setGratitudeSubmittedMsg(false), 4000);
  };

  const handleSendHelpChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!helpChatMsg.trim()) return;
    const userText = helpChatMsg;
    setHelpChatLog(prev => [...prev, { sender: 'user', text: userText }]);
    setHelpChatMsg('');
    setTimeout(() => {
      setHelpChatLog(prev => [
        ...prev,
        { sender: 'support', text: `Thank you for reaching out regarding "${userText}". Our financial ministry team is available 24/7. You may use our direct bank transfer or Opay/Moniepoint details displayed on screen with instant verification.` }
      ]);
    }, 1000);
  };

  return (
    <div
      ref={containerRef}
      style={{
        transform: zoomLevel !== 1 ? `scale(${zoomLevel})` : undefined,
        transformOrigin: 'top center',
        transition: 'transform 0.2s ease-in-out'
      }}
      className={`max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-12 animate-fadeIn relative pb-28 ${
        isFullscreen ? 'bg-slate-950 min-h-screen p-6' : ''
      }`}
    >
      {/* Floating Action Bar for Fullscreen & Zoom Immersion */}
      <div className="fixed bottom-24 right-6 z-50 flex items-center bg-slate-900/95 border border-amber-500/40 rounded-2xl p-1.5 shadow-2xl backdrop-blur-lg gap-1">
        <button
          onClick={toggleFullscreen}
          className="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/40 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
          title={isFullscreen ? 'Exit Full Screen Mode' : 'Switch Support Page to Full Screen Mode'}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4 text-amber-400" /> : <Maximize2 className="w-4 h-4 text-amber-400" />}
          <span className="hidden sm:inline text-[11px]">{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
        </button>

        <div className="h-5 w-px bg-amber-500/30 mx-0.5" />

        <button
          onClick={handleZoomOut}
          disabled={zoomLevel <= 0.7}
          className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/20 text-xs font-bold transition-all disabled:opacity-40"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4 text-amber-400" />
        </button>

        <span className="px-1 text-[10px] font-mono font-bold text-amber-300">
          {Math.round(zoomLevel * 100)}%
        </span>

        <button
          onClick={handleZoomIn}
          disabled={zoomLevel >= 1.4}
          className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/20 text-xs font-bold transition-all disabled:opacity-40"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4 text-amber-400" />
        </button>

        {zoomLevel !== 1 && (
          <button
            onClick={handleResetZoom}
            className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/20 text-xs font-bold transition-all"
            title="Reset Zoom to 100%"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
          </button>
        )}
      </div>

      {/* Toast Notification Banner */}
      {toastMsg && (
        <div className="fixed top-20 right-4 z-50 bg-amber-500 text-slate-950 font-bold px-5 py-3 rounded-2xl shadow-2xl border border-amber-300 flex items-center space-x-2 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span className="text-xs">{toastMsg}</span>
        </div>
      )}

      {/* Global Community Project Progress Bar */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/40 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-amber-200">Community Altar Project: &quot;Building the Prophetic Prayer Sanctuary&quot;</h2>
          </div>
          <span className="text-xs font-mono font-bold text-amber-300">${communityProjectRaised.toLocaleString()} / ${communityProjectTarget.toLocaleString()} USD ({communityProjectPercent}%)</span>
        </div>
        <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-amber-500/30 p-0.5">
          <div
            className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full transition-all duration-1000"
            style={{ width: `${communityProjectPercent}%` }}
          />
        </div>
        <p className="text-[11px] text-slate-300">
          Global partners have united to establish 24/7 prayer streaming nodes worldwide. Your support directly accelerates this sanctuary.
        </p>
      </div>

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-slate-950 p-6 sm:p-10 rounded-3xl border border-amber-500/40 shadow-2xl text-center space-y-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold mx-auto">
          <Heart className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span>PROPHECY & GOSPEL MINISTRY SUPPORT OFFERINGS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold font-serif text-amber-100">
          Support Prophet Juhnkrix Synvagord
        </h1>

        <p className="text-slate-300 text-xs sm:text-sm max-w-2xl mx-auto leading-relaxed">
          Thank you for sowing into the global gospel songs, soaking streams, and prophetic broadcast teachings of Prophet JUHNKRIX SYNVAGORD. Select your preferred government-licensed mobile bank or international gateway below.
        </p>
      </div>

      {/* Offline Status Indicator & Non-App USSD / Bank Transfer Codes Bar */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className={`w-3.5 h-3.5 rounded-full ${isOffline ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-amber-100 uppercase tracking-wider">
                Network Status: {isOffline ? 'Offline / Limited Connectivity' : 'Online (Connected to Ministry Altar)'}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${isOffline ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'}`}>
                {isOffline ? 'USSD & SMS Mode Active' : 'Live Sync'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {isOffline 
                ? 'Internet connection lost. Use non-app USSD codes or SMS bank transfer strings below to complete your offering instantly.'
                : 'All digital gateways & instant bank deep-links are fully operational.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsOffline(!isOffline)}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all shrink-0"
        >
          {isOffline ? 'Switch to Online Mode' : 'Simulate Offline / USSD Mode'}
        </button>
      </div>

      {/* Offline USSD & Bank Transfer Codes Suggestion Box (Prominent when offline or toggled) */}
      {isOffline && (
        <div className="bg-gradient-to-br from-amber-950/90 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/60 shadow-2xl space-y-4 animate-fadeIn">
          <div className="flex items-center space-x-2 text-amber-300">
            <Smartphone className="w-5 h-5 text-amber-400 animate-pulse" />
            <h3 className="text-sm font-bold uppercase tracking-wider font-mono">
              Alternative Non-App Payment & USSD Transfer Codes (Offline Mode)
            </h3>
          </div>
          <p className="text-xs text-slate-300">
            When you lack internet connectivity, you can dial these direct USSD codes on your mobile phone to complete your seed offering to Prophet Juhnkrix Synvagord:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
              <div className="text-[10px] font-bold text-amber-400 uppercase">Opay Direct USSD</div>
              <div className="text-sm font-mono font-extrabold text-amber-100 bg-amber-500/10 p-2.5 rounded-xl border border-amber-400/20 text-center select-all">
                *955*1*07071918280#
              </div>
              <div className="text-[10px] text-slate-400">Dial on phone registered with Opay for instant seed transfer.</div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
              <div className="text-[10px] font-bold text-amber-400 uppercase">Moniepoint / GTBank Code</div>
              <div className="text-sm font-mono font-extrabold text-amber-100 bg-amber-500/10 p-2.5 rounded-xl border border-amber-400/20 text-center select-all">
                *737*2*5000*7071918280#
              </div>
              <div className="text-[10px] text-slate-400">Quick bank transfer string for offline banking transactions.</div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
              <div className="text-[10px] font-bold text-amber-400 uppercase">UBA / Interbank USSD</div>
              <div className="text-sm font-mono font-extrabold text-amber-100 bg-amber-500/10 p-2.5 rounded-xl border border-amber-400/20 text-center select-all">
                *919*3*7071918280#
              </div>
              <div className="text-[10px] text-slate-400">Universal USSD banking code for any commercial mobile network.</div>
            </div>
          </div>
        </div>
      )}

      {successSubmitted && (
        <div className="bg-emerald-500/20 border border-emerald-500/40 p-6 rounded-3xl text-emerald-200 text-center space-y-3 shadow-xl">
          <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
          <h3 className="text-lg font-bold">Offering Received & Credited Successfully!</h3>
          <p className="text-xs text-emerald-300">
            May the Lord God of heaven shower you with double honor and overflow abundance.
          </p>
        </div>
      )}

      {/* Recently Used Horizontal Scroll */}
      <div className="space-y-3">
        <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-amber-400">
          <Clock className="w-4 h-4" />
          <span>Recently Used Banking Gateways</span>
        </div>
        <div className="flex space-x-3 overflow-x-auto pb-2 scrollbar-thin">
          {recentlyUsed.map(id => {
            const gw = gateways.find(g => g.id === id);
            if (!gw) return null;
            return (
              <div
                key={gw.id}
                onClick={() => setSelectedGateway(gw.id)}
                className="flex items-center space-x-3 bg-slate-900 border border-amber-500/30 px-4 py-3 rounded-2xl shrink-0 cursor-pointer hover:border-amber-400 transition-all shadow-md"
              >
                <span className="text-2xl">{gw.icon}</span>
                <div>
                  <div className="text-xs font-bold text-amber-100">{gw.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{gw.accountNo}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Spiritual Goal & Monthly Recurring Toggle */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Daily Spiritual Goal */}
        <div className="bg-slate-900 p-6 rounded-3xl border border-amber-500/30 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
              <Target className="w-3.5 h-3.5 text-amber-400" />
              <span>DAILY SPIRITUAL SEED GOAL</span>
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">Kingdom Altar Sowing Target</h3>
            <div className="flex items-center space-x-4 pt-2">
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold">TODAY SOWN</span>
                <span className="text-base font-mono font-bold text-emerald-400">${todaySownUSD} USD</span>
              </div>
              <div className="h-6 w-px bg-amber-500/20" />
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold">TARGET</span>
                <span className="text-base font-mono font-bold text-amber-300">${dailyGoalTarget} USD</span>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => setIsEditingGoal(!isEditingGoal)}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold"
            >
              {isEditingGoal ? 'Cancel' : 'Edit Target'}
            </button>
            <span className="text-xs font-mono font-bold text-amber-400">{goalProgressPercent}% Completed</span>
          </div>
          {isEditingGoal && (
            <div className="flex items-center space-x-2 pt-2">
              <input
                type="number"
                min="10"
                value={tempGoalInput}
                onChange={(e) => setTempGoalInput(e.target.value)}
                className="bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-1.5 text-xs text-amber-100 font-mono w-28"
              />
              <button
                onClick={() => {
                  const val = parseInt(tempGoalInput);
                  if (val > 0) setDailyGoalTarget(val);
                  setIsEditingGoal(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
              >
                Save
              </button>
            </div>
          )}
        </div>

        {/* Monthly Recurring Support Toggle */}
        <div className="bg-slate-900 p-6 rounded-3xl border border-amber-500/30 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>MONTHLY RECURRING SUPPORT</span>
              </div>
              <input
                type="checkbox"
                checked={isRecurringEnabled}
                onChange={(e) => setIsRecurringEnabled(e.target.checked)}
                className="w-5 h-5 accent-amber-500 cursor-pointer"
              />
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">Automated Offering Reminder</h3>
            <p className="text-xs text-slate-300">
              Enable automated monthly notification to provide your regular prophetic seed on your preferred date.
            </p>
          </div>

          {isRecurringEnabled ? (
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Day of Month</label>
                <select
                  value={recurringDay}
                  onChange={(e) => setRecurringDay(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 font-mono"
                >
                  {[...Array(28)].map((_, i) => (
                    <option key={i+1} value={i+1}>{i+1}st / {i+1}th of Month</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Amount</label>
                <input
                  type="text"
                  value={recurringAmount}
                  onChange={(e) => setRecurringAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 font-mono"
                />
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-500 italic">Toggle switch above to configure automated monthly reminder schedule.</div>
          )}
        </div>
      </div>

      {/* Active App Modal Simulation */}
      {activeAppModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 p-6 sm:p-8 rounded-3xl max-w-md w-full space-y-6 shadow-2xl text-center">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center mx-auto text-2xl font-bold">
              📱
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold font-serif text-amber-100">{activeAppModal.name} Open & Active</h3>
              <p className="text-xs text-slate-300">
                {activeAppModal.name} has been launched on your device (Account: <span className="text-amber-300 font-mono font-bold">{activeAppModal.accountNo}</span> - {activeAppModal.accountName}). Complete your transfer of support offering.
              </p>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 text-left space-y-1 text-xs">
              <div className="text-amber-400 font-bold">Gateway: {activeAppModal.name}</div>
              <div className="text-slate-300">Account Name: {activeAppModal.accountName}</div>
              <div className="text-slate-300">Account/ID: {activeAppModal.accountNo}</div>
            </div>
            <button
              onClick={() => handleFinishBankOffering(activeAppModal.name)}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center space-x-2"
            >
              <span>I AM DONE — CONFIRM & GET BLESSING RECEIPT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Blessing Receipt Modal */}
      {receiptModalData && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-br from-slate-900 via-amber-950/40 to-slate-900 border border-amber-400 p-8 rounded-3xl max-w-md w-full space-y-6 shadow-2xl text-center animate-fadeIn relative">
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-xl shadow-lg">
              ✨
            </div>
            <div className="space-y-2 pt-3">
              <div className="text-[10px] font-bold uppercase tracking-widest text-amber-400">Official Ministry Blessing Receipt</div>
              <h3 className="text-2xl font-bold font-serif text-amber-100">Altar Offering Confirmed</h3>
              <p className="text-xs text-slate-300">May the Lord God of Prophet Juhnkrix Synvagord multiply your seed a hundredfold.</p>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 text-left space-y-2 text-xs font-mono">
              <div className="flex justify-between text-slate-400"><span>Amount:</span> <span className="text-emerald-400 font-bold">{receiptModalData.amount}</span></div>
              <div className="flex justify-between text-slate-400"><span>Platform:</span> <span className="text-amber-300">{receiptModalData.platform}</span></div>
              <div className="flex justify-between text-slate-400"><span>Date:</span> <span className="text-slate-200">{receiptModalData.date}</span></div>
              <div className="flex justify-between text-slate-400"><span>Transaction Ref:</span> <span className="text-amber-400">{receiptModalData.ref}</span></div>
            </div>
            <button
              onClick={() => setReceiptModalData(null)}
              className="w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs tracking-wider uppercase transition-all shadow-lg"
            >
              Close Receipt & Return
            </button>
          </div>
        </div>
      )}

      {/* Store Download Prompt Modal if App is not detected */}
      {storeDownloadModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 p-6 sm:p-8 rounded-3xl max-w-md w-full space-y-6 shadow-2xl text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-400/30 flex items-center justify-center mx-auto text-2xl font-bold">
              📥
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold font-serif text-amber-100">{storeDownloadModal.name} Not Detected</h3>
              <p className="text-xs text-slate-300">
                We could not detect <span className="text-amber-300 font-bold">{storeDownloadModal.name}</span> installed on your device. You can download the official app from the app store or complete your offering via secure web transfer.
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <a
                href={storeDownloadModal.storeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-lg shadow-amber-500/20 flex items-center justify-center space-x-2"
              >
                <span>Download App from Store</span>
                <ExternalLink className="w-4 h-4" />
              </a>
              <button
                onClick={() => {
                  const gw = storeDownloadModal;
                  setStoreDownloadModal(null);
                  handleOpenBankApp(gw);
                }}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-200 font-bold text-xs border border-amber-500/30"
              >
                Proceed with Web Transfer / USSD
              </button>
              <button
                onClick={() => setStoreDownloadModal(null)}
                className="text-xs text-slate-400 hover:text-slate-300 underline pt-1"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support Sub-Tab Switcher: Fiat Gateways vs Crypto Sowing */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/90 p-3 sm:p-4 rounded-3xl border border-amber-500/30 shadow-xl">
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <button
            onClick={() => setSupportSubTab('gateways')}
            className={`flex-1 sm:flex-none py-3 px-5 rounded-2xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all ${
              supportSubTab === 'gateways'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/20'
                : 'text-slate-300 hover:text-amber-200 bg-slate-800'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>🏦 Fiat & Regional Bank Gateways (200+)</span>
          </button>

          <button
            onClick={() => setSupportSubTab('crypto')}
            className={`flex-1 sm:flex-none py-3 px-5 rounded-2xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all ${
              supportSubTab === 'crypto'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/20'
                : 'text-slate-300 hover:text-amber-200 bg-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>🪙 Dedicated Crypto Sowing (50+ Coins / 500+ Wallets)</span>
          </button>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={handleDetectLocationGps}
            disabled={isLocating}
            className="px-4 py-2.5 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center space-x-2 transition-all shadow-md shrink-0"
          >
            <Globe className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>{isLocating ? 'Detecting GPS Location...' : '📍 Detect Location via GPS'}</span>
          </button>
        </div>
      </div>

      {supportSubTab === 'crypto' ? (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/50 shadow-xl space-y-4">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">🪙</span>
              <div>
                <h3 className="text-lg font-bold font-serif text-amber-100">Dedicated Crypto Sowing Vault (50+ Supported Cryptocurrencies & 500+ Wallets)</h3>
                <p className="text-xs text-slate-300">Sow your seed in Bitcoin, Ethereum, USDT, Solana, and over 50 verified Web3 altcoins and protocols directly into Prophet Juhnkrix Synvagord&apos;s Altar Treasury.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CRYPTO_ALTAR_WALLETS.map((c) => (
              <div key={c.symbol} className="bg-slate-900 p-6 rounded-3xl border border-amber-500/30 shadow-xl space-y-4 flex flex-col justify-between hover:border-amber-400/70 transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-mono text-xs font-bold">{c.symbol}</span>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold">🟢 Active Treasury</span>
                  </div>
                  <h4 className="text-base font-bold text-amber-100">{c.name}</h4>
                  <p className="text-[11px] text-slate-400 font-mono">{c.network}</p>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 flex items-center justify-center">
                  <div className="bg-white p-2 rounded-xl">
                    <QRCodeSVG value={c.qr} size={64} />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Altar Wallet Address</div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-amber-500/20 text-[11px] font-mono text-amber-300 break-all select-all">
                    {c.address}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopyCryptoAddress(c.address, c.symbol)}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-amber-400 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center space-x-2"
                >
                  <Copy className="w-4 h-4" />
                  <span>{copiedAddressKey === c.symbol ? 'COPIED TO CLIPBOARD!' : `COPY ${c.symbol} ADDRESS`}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* Mobile Banking Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900 p-4 sm:p-5 rounded-3xl border border-amber-500/30 shadow-lg">
            <div className="flex items-center space-x-3 w-full sm:w-auto flex-1">
              <div className="relative w-full">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400">
                  🔍
                </span>
                <input
                  type="text"
                  value={bankSearchQuery}
                  onChange={(e) => setBankSearchQuery(e.target.value)}
                  placeholder="Search banking apps by name, country, or region..."
                  className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-2xl pl-10 pr-4 py-3 text-xs focus:outline-none focus:border-amber-400 shadow-inner"
                />
              </div>
            </div>

            <div className="text-[11px] text-amber-300 font-mono shrink-0">
              ⭐ Pinned Favorites & Region Sections Enabled
            </div>
          </div>

      {/* Gateway Grid by Region / Collapsible Sections */}
      {(() => {
        const filtered = gateways.filter(gw => {
          const q = bankSearchQuery.toLowerCase();
          return gw.name.toLowerCase().includes(q) || gw.country.toLowerCase().includes(q) || gw.region.toLowerCase().includes(q);
        });

        // Pinned favorites first
        const sorted = [...filtered].sort((a, b) => {
          const aFav = favoriteBankIds.includes(a.id) ? 1 : 0;
          const bFav = favoriteBankIds.includes(b.id) ? 1 : 0;
          return bFav - aFav;
        });

        const groups: Record<string, typeof gateways> = {};
        sorted.forEach(gw => {
          if (!groups[gw.region]) {
            groups[gw.region] = [];
          }
          groups[gw.region].push(gw);
        });

        return Object.entries(groups).map(([regionName, items]) => {
          const isCollapsed = collapsedRegions[regionName];
          return (
            <div key={regionName} className="space-y-4 bg-slate-900/60 p-5 rounded-3xl border border-amber-500/20 shadow-xl">
              <div
                onClick={() => setCollapsedRegions(prev => ({ ...prev, [regionName]: !prev[regionName] }))}
                className="flex items-center justify-between cursor-pointer select-none"
              >
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-bold font-serif text-amber-200 uppercase tracking-wider">
                    {regionName} ({items.length} Options)
                  </span>
                </div>
                <button className="text-amber-400 text-xs font-bold underline">
                  {isCollapsed ? 'Expand ▾' : 'Collapse ▴'}
                </button>
              </div>

              {!isCollapsed && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
                  {items.map((gw) => {
                    const isSelected = selectedGateway === gw.id;
                    const isFav = favoriteBankIds.includes(gw.id);
                    return (
                      <div
                        key={gw.id}
                        onClick={() => setSelectedGateway(gw.id)}
                        className={`p-6 rounded-3xl border transition-all cursor-pointer flex flex-col justify-between space-y-4 relative ${
                          isSelected
                            ? 'bg-gradient-to-br from-amber-950/70 to-slate-900 border-amber-400 shadow-xl shadow-amber-500/10 scale-102'
                            : 'bg-slate-900 border-amber-500/20 hover:border-amber-500/40'
                        }`}
                      >
                        {isSelected && (
                          <div className="absolute top-4 right-12 w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-xs">
                            ✓
                          </div>
                        )}

                        {/* Favorite Heart Toggle Button */}
                        <button
                          type="button"
                          onClick={(e) => toggleFavoriteBank(gw.id, e)}
                          className={`absolute top-4 right-4 p-2 rounded-xl border transition-all ${
                            isFav
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                              : 'bg-slate-950/80 border-amber-500/20 text-slate-400 hover:text-amber-200'
                          }`}
                          title={isFav ? 'Pinned to Top (Favorited)' : 'Add to Favorites'}
                        >
                          <Heart className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-400' : ''}`} />
                        </button>

                        <div className="space-y-3">
                          <div className="flex items-center justify-between pr-10">
                            <div className="text-3xl">{gw.icon}</div>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setHowToModal({ name: gw.name, desc: gw.desc, accountNo: gw.accountNo });
                              }}
                              className="px-2.5 py-1 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center space-x-1"
                            >
                              <span>ℹ️ How to</span>
                            </button>
                          </div>
                          <h3 className="text-base font-bold font-serif text-amber-100 flex items-center space-x-2">
                            <span>{gw.name}</span>
                            {isFav && <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">⭐ Pinned</span>}
                          </h3>
                          <p className="text-[11px] text-slate-300 font-mono">{gw.accountNo}</p>
                          <p className="text-xs text-slate-400">{gw.desc}</p>
                        </div>

                        {/* QR Code display */}
                        <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 flex items-center space-x-4">
                          <div className="bg-white p-2 rounded-xl shrink-0">
                            <QRCodeSVG value={`https://juhnkrix-ministry.pay/${gw.id}?account=${gw.accountNo}`} size={56} />
                          </div>
                          <div className="text-[10px] text-slate-300 space-y-1">
                            <span className="font-bold text-amber-300 block">Scan to Pay on Device</span>
                            <span className="text-slate-400 leading-tight block">Scan with secondary phone or camera app</span>
                          </div>
                        </div>

                        <div className="pt-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTriggerDeepLink(gw);
                            }}
                            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 hover:from-amber-400 hover:to-amber-400 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center space-x-2"
                          >
                            <Smartphone className="w-4 h-4" />
                            <span>OPEN APP (DEEP-LINK)</span>
                          </button>
                        </div>

                        <div className="pt-3 border-t border-amber-500/10 flex items-center justify-between text-[10px]">
                          <span className="text-emerald-400 font-bold">{gw.licensed}</span>
                          <span className="text-amber-300 font-semibold">{gw.country}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        });
      })()}

      {/* Contribution Form & Recent Sowing History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contribution Form */}
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold font-serif text-amber-100">Send Your Offering / Seed</h3>
            <p className="text-xs text-slate-400">
              Selected Gateway: <span className="text-amber-300 uppercase font-mono font-bold">{selectedGateway}</span>
            </p>
          </div>

          <form onSubmit={handleSubmitOffering} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="Brother/Sister Name"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={donorEmail}
                  onChange={(e) => setDonorEmail(e.target.value)}
                  placeholder="your.email@gmail.com"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">Offering Amount</label>
                <input
                  type="text"
                  required
                  value={supportAmount}
                  onChange={(e) => setSupportAmount(e.target.value)}
                  placeholder="e.g. 10,000 NGN or $50 USD"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-amber-100 focus:outline-none focus:border-amber-400 font-mono font-bold text-amber-300"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">Currency & Country</label>
                  <span className="text-[10px] font-mono text-emerald-400">Detected: {detectedCountry}</span>
                </div>
                <select
                  value={gatewayCurrency}
                  onChange={(e) => setGatewayCurrency(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-amber-100 focus:outline-none focus:border-amber-400 font-mono"
                >
                  <optgroup label="🌟 Featured & Requested Cryptocurrencies (50+ Available)">
                    <option value="BTC">₿ BTC - Bitcoin (Primary Altar Vault)</option>
                    <option value="ETH">Ξ ETH - Ethereum (ERC20 Glory Network)</option>
                    <option value="USDT">🪙 USDT - Tether (Omni / TRC20 / ERC20 / SOL)</option>
                    <option value="USDC">🪙 USDC - USD Coin Stablecoin</option>
                    <option value="SOL">🟣 SOL - Solana Network</option>
                    <option value="BNB">🟡 BNB - Binance Smart Chain (BEP20)</option>
                    <option value="XRP">✖ XRP - Ripple Ledger</option>
                    <option value="ADA">₳ ADA - Cardano Network</option>
                    <option value="DOGE">🐕 DOGE - Dogecoin Community</option>
                    <option value="TRX">🔴 TRX - Tron Network</option>
                    <option value="MATIC">🟣 MATIC / POL - Polygon Network</option>
                    <option value="LTC">Ł LTC - Litecoin</option>
                    <option value="AVAX">🔺 AVAX - Avalanche C-Chain</option>
                    <option value="DOT">⚪ DOT - Polkadot</option>
                    <option value="LINK">🔗 LINK - Chainlink</option>
                    <option value="UNI">🦄 UNI - Uniswap</option>
                    <option value="XLM">⭐ XLM - Stellar Lumens</option>
                    <option value="ATOM">⚛ ATOM - Cosmos Hub</option>
                    <option value="NEAR">🌐 NEAR Protocol</option>
                    <option value="ALGO">🔹 ALGO - Algorand</option>
                    <option value="SHIB">🐕 SHIB - Shiba Inu</option>
                    <option value="BCH">💚 BCH - Bitcoin Cash</option>
                    <option value="ICP">♾️ ICP - Internet Computer</option>
                    <option value="FIL">📁 FIL - Filecoin</option>
                    <option value="XMR">🛡️ XMR - Monero Privacy</option>
                  </optgroup>

                  <optgroup label="🏦 Featured Middle East & Gulf Currencies">
                    <option value="KWD">🇰🇼 KWD - Kuwaiti Dinar (Kuwait)</option>
                    <option value="AED">🇦🇪 AED - UAE Dirham (Dubai / Abu Dhabi)</option>
                    <option value="SAR">🇸🇦 SAR - Saudi Riyal (Saudi Arabia / Riyadh)</option>
                    <option value="QAR">🇶🇦 QAR - Qatari Riyal</option>
                    <option value="BHD">🇧🇭 BHD - Bahraini Dinar</option>
                    <option value="OMR">🇴🇲 OMR - Omani Rial</option>
                    <option value="JOD">🇯.🇴 JOD - Jordanian Dinar</option>
                    <option value="LBP">🇱🇧 LBP - Lebanese Pound</option>
                  </optgroup>

                  <optgroup label="🌍 Major Global & Regional Fiat Currencies (200+ Supported)">
                    <option value="NGN">🇳🇬 NGN - Nigerian Naira (Nigeria)</option>
                    <option value="USD">🇺🇸 USD - US Dollar (United States / Chicago / New York)</option>
                    <option value="GBP">🇬🇧 GBP - British Pound (United Kingdom / London)</option>
                    <option value="EUR">🇪🇺 EUR - Euro (European Union / France / Paris)</option>
                    <option value="CAD">🇨🇦 CAD - Canadian Dollar (Canada)</option>
                    <option value="AUD">🇦🇺 AUD - Australian Dollar (Australia)</option>
                    <option value="GHS">🇬🇭 GHS - Ghanaian Cedi (Ghana)</option>
                    <option value="KES">🇰🇪 KES - Kenyan Shilling (Kenya)</option>
                    <option value="ZAR">🇿🇦 ZAR - South African Rand (South Africa)</option>
                    <option value="INR">🇮🇳 INR - Indian Rupee (India)</option>
                    <option value="JPY">🇯🇵 JPY - Japanese Yen (Japan / Tokyo)</option>
                    <option value="CNY">🇨🇳 CNY - Chinese Yuan (China)</option>
                    <option value="IRR">🇮🇷 IRR - Iranian Rial (Iran)</option>
                    <option value="IRT">🇮🇷 IRT - Iranian Toman (Persia)</option>
                    <option value="IQD">🇮🇶 IQD - Iraqi Dinar (Iraq)</option>
                    <option value="RUB">🇷🇺 RUB - Russian Ruble (Russia)</option>
                    <option value="XOF">🌍 XOF - West African CFA Franc (Togo / Burkina Faso / Abidjan)</option>
                    <option value="XAF">🌍 XAF - Central African CFA Franc (Cameroon)</option>
                    <option value="BRL">🇧🇷 BRL - Brazilian Real (Brazil)</option>
                    <option value="NZD">🇳🇿 NZD - New Zealand Dollar (New Zealand)</option>
                    <option value="ILS">🇮🇱 ILS - Israeli New Shekel (Israel / Jerusalem)</option>
                    <option value="PLN">🇵🇱 PLN - Polish Zloty (Poland)</option>
                    <option value="EGP">🇪🇬 EGP - Egyptian Pound (Egypt)</option>
                    <option value="COP">🇨🇴 COP - Colombian Peso (Colombia)</option>
                    <option value="CHF">🇨🇭 CHF - Swiss Franc (Switzerland)</option>
                    <option value="SEK">🇸🇪 SEK - Swedish Krona</option>
                    <option value="NOK">🇳🇴 NOK - Norwegian Krone</option>
                    <option value="DKK">🇩🇰 DKK - Danish Krone</option>
                    <option value="SGD">🇸🇬 SGD - Singapore Dollar</option>
                    <option value="HKD">🇭🇰 HKD - Hong Kong Dollar</option>
                    <option value="KRW">🇰🇷 KRW - South Korean Won</option>
                    <option value="MXN">🇲🇽 MXN - Mexican Peso</option>
                    <option value="ARS">🇦🇷 ARS - Argentine Peso</option>
                    <option value="CLP">🇨🇱 CLP - Chilean Peso</option>
                    <option value="PEN">🇵🇪 PEN - Peruvian Sol</option>
                    <option value="TZS">🇹🇿 TZS - Tanzanian Shilling</option>
                    <option value="UGX">🇺🇬 UGX - Ugandan Shilling</option>
                    <option value="RWF">🇷🇼 RWF - Rwandan Franc</option>
                    <option value="ETB">🇪🇹 ETB - Ethiopian Birr</option>
                    <option value="ZMW">🇿🇲 ZMW - Zambian Kwacha</option>
                    <option value="MAD">🇲🇦 MAD - Moroccan Dirham</option>
                    <option value="XCD">🌴 XCD - East Caribbean Dollar</option>
                    <option value="FJD">🇫🇯 FJD - Fijian Dollar</option>
                    <option value="PGK">🇵🇬 PGK - Papua New Guinean Kina</option>
                    <option value="ALL">🇦🇱 ALL - Albanian Lek</option>
                    <option value="BAM">🇧🇦 BAM - Bosnia and Herzegovina Convertible Mark</option>
                    <option value="BGN">🇧🇬 BGN - Bulgarian Lev</option>
                    <option value="CZK">🇨🇿 CZK - Czech Koruna</option>
                    <option value="HUF">🇭🇺 HUF - Hungarian Forint</option>
                    <option value="RON">🇷🇴 RON - Romanian Leu</option>
                    <option value="RSD">🇷🇸 RSD - Serbian Dinar</option>
                    <option value="UAH">🇺🇦 UAH - Ukrainian Hryvnia</option>
                    <option value="ISK">🇮🇸 ISK - Icelandic Króna</option>
                  </optgroup>

                  <optgroup label="🦊 Crypto Wallets & Web3 Networks (500+ Protocols Supported)">
                    <option value="METAMASK">🦊 MetaMask Web3 (EVM Networks)</option>
                    <option value="TRUSTWALLET">🛡️ Trust Wallet (Multi-Chain)</option>
                    <option value="COINBASE">🔵 Coinbase Wallet & Pay</option>
                    <option value="PHANTOM">🟣 Phantom (Solana & Ethereum)</option>
                    <option value="LEDGER">🔒 Ledger Hardware Cold Wallet</option>
                    <option value="TREZOR">🔑 Trezor Safe Hardware Wallet</option>
                    <option value="EXODUS">🪐 Exodus Multi-Crypto Wallet</option>
                    <option value="BINANCEPAY">🟡 Binance Pay Gateway</option>
                    <option value="RAINBOW">🌈 Rainbow Ethereum Wallet</option>
                    <option value="ARGENT">🇦🇷 Argent Smart Wallet (StarkNet / zkSync)</option>
                    <option value="ELECTRUM">⚡ Electrum Bitcoin Wallet</option>
                    <option value="MYETHERWALLET">💎 MyEtherWallet (MEW)</option>
                    <option value="SAFEPAL">🛡️ SafePal Hardware & App</option>
                    <option value="OKXWALLET">⭕ OKX Web3 Wallet</option>
                    <option value="BYBITPAY">💳 Bybit Pay & Web3</option>
                  </optgroup>
                </select>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 hover:from-amber-400 hover:to-amber-400 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center space-x-2"
              >
                <span>SEND SECURE SUPPORT OFFERING NOW</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>

        {/* Recent Donation History Section */}
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold font-serif text-amber-100">Recent Sowing History</h3>
              <p className="text-xs text-slate-400">Your personal spiritual seed log and offerings.</p>
            </div>
            <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
              {sowingHistory.length} Records
            </span>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {sowingHistory.length === 0 ? (
              <p className="text-xs text-slate-500 italic p-4 text-center">No offerings logged yet in this session.</p>
            ) : (
              sowingHistory.slice().reverse().map((record, index) => (
                <div key={index} className="p-4 rounded-2xl bg-slate-950 border border-amber-500/20 flex items-center justify-between text-xs">
                  <div className="space-y-1">
                    <span className="font-bold text-amber-200 block">{record.category}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{record.platform} • {record.date}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400 text-sm">${record.amountUSD} USD</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Ministry Impact Visualization Section (Recharts) */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 mb-2">
              <PieChartIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>FINANCIAL TRANSPARENCY & IMPACT</span>
            </div>
            <h3 className="text-xl font-bold font-serif text-amber-100">Where Your Sown Funds Are Applied</h3>
            <p className="text-xs text-slate-300">Complete transparency report showing how ministry offerings are distributed to advance the gospel.</p>
          </div>
          <div className="bg-slate-950 px-4 py-3 rounded-2xl border border-amber-500/20 text-right shrink-0">
            <span className="text-[10px] text-slate-400 block font-semibold">TOTAL REACHED</span>
            <span className="text-base font-bold font-mono text-amber-300">120+ Nations</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="h-64 sm:h-80 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={IMPACT_DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }) => `${value}%`}
                >
                  {IMPACT_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#f59e0b', borderRadius: '12px', color: '#fef3c7', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-4">
            {IMPACT_DATA.map((item, idx) => (
              <div key={idx} className="p-3 rounded-2xl bg-slate-950/80 border border-amber-500/15 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="font-semibold text-amber-100">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-amber-300">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
        </>
      )}

      {/* Gratitude Wall Section */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 mb-2">
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              <span>COMMUNITY TESTIMONY & GRATITUDE WALL</span>
            </div>
            <h3 className="text-xl font-bold font-serif text-amber-100">Voices of Thanksgiving & Blessings</h3>
            <p className="text-xs text-slate-300">Read and post notes of gratitude for testimonies received through this ministry.</p>
          </div>
        </div>

        {gratitudeSubmittedMsg && (
          <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Your gratitude note has been posted to the Gratitude Wall!</span>
          </div>
        )}

        <form onSubmit={handlePostGratitude} className="p-5 rounded-2xl bg-slate-950 border border-amber-500/20 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">Post a Note of Gratitude</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-slate-400 font-semibold block mb-1">Your Name / Title</label>
              <input
                type="text"
                required
                value={newGratitudeName}
                onChange={(e) => setNewGratitudeName(e.target.value)}
                placeholder="e.g. Sister Sarah M."
                className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 font-semibold block mb-1">Seed Amount / Ref</label>
              <input
                type="text"
                value={newGratitudeAmount}
                onChange={(e) => setNewGratitudeAmount(e.target.value)}
                placeholder="e.g. $50 USD"
                className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>
          </div>
          <div>
            <label className="text-[10px] text-slate-400 font-semibold block mb-1">Your Testimony Message</label>
            <textarea
              required
              rows={2}
              value={newGratitudeMsg}
              onChange={(e) => setNewGratitudeMsg(e.target.value)}
              placeholder="Share how the Lord blessed you..."
              className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400 resize-none"
            />
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 transition-all shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post Gratitude Note</span>
            </button>
          </div>
        </form>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {gratitudePosts.map((post) => (
            <div key={post.id} className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/20 space-y-3 flex flex-col justify-between shadow-lg">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-200">{post.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    {post.amount}
                  </span>
                </div>
                <p className="text-xs text-slate-300 italic leading-relaxed">&ldquo;{post.message}&rdquo;</p>
              </div>
              <div className="pt-2 border-t border-amber-500/10 flex items-center justify-between text-[10px] text-slate-500">
                <span>Verified Testimony</span>
                <span className="font-mono">{post.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Help with Payments Chat Widget */}
      <div className="fixed bottom-6 right-6 z-40">
        {!isHelpChatOpen ? (
          <button
            onClick={() => setIsHelpChatOpen(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 px-5 py-3.5 rounded-full font-extrabold text-xs shadow-2xl border border-amber-300 hover:scale-105 transition-all"
          >
            <HelpCircle className="w-5 h-5" />
            <span>Help with Payments</span>
          </button>
        ) : (
          <div className="bg-slate-900 border border-amber-500/50 rounded-3xl w-80 sm:w-96 shadow-2xl flex flex-col overflow-hidden animate-fadeIn">
            <div className="bg-gradient-to-r from-amber-950 to-slate-900 p-4 border-b border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <HelpCircle className="w-5 h-5 text-amber-400" />
                <span className="text-xs font-bold text-amber-100">Payment Concierge & FAQs</span>
              </div>
              <button
                onClick={() => setIsHelpChatOpen(false)}
                className="text-slate-400 hover:text-amber-300 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-4 h-64 overflow-y-auto space-y-3 text-xs bg-slate-950">
              {helpChatLog.map((log, i) => (
                <div key={i} className={`flex ${log.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`p-3 rounded-2xl max-w-[85%] ${log.sender === 'user' ? 'bg-amber-500 text-slate-950 font-semibold' : 'bg-slate-900 text-slate-200 border border-amber-500/20'}`}>
                    {log.text}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendHelpChat} className="p-3 bg-slate-900 border-t border-amber-500/30 flex space-x-2">
              <input
                type="text"
                value={helpChatMsg}
                onChange={(e) => setHelpChatMsg(e.target.value)}
                placeholder="Ask about offering or bank transfer..."
                className="flex-1 bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none"
              />
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-xs"
              >
                Send
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
