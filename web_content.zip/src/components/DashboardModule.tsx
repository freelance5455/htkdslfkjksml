import React, { useMemo } from 'react';
import {
  Plus,
  ArrowUpRight,
  ArrowRight,
  Wallet,
  CalendarClock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import {
  Account,
  ActiveTab,
  DebtRecord,
  SubscriptionRecord,
  TransactionRecord,
  TransactionType,
} from '../types/finance';
import {
  formatBDT,
  formatDateBnEn,
  getCurrentYearMonth,
  getTodayISO,
} from '../utils/money';
import { buildUnifiedLedger } from '../utils/unifiedLedger';
import { getThisMonthPayment } from './SubscriptionsModule';

interface DashboardModuleProps {
  accounts: Account[];
  accountBalances: Record<string, number>;
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  useBengaliDigits: boolean;
  onQuickAddTransaction: (type?: TransactionType) => void;
  onNavigateTab: (tab: ActiveTab) => void;
  onRequestPaySubscription: (sub: SubscriptionRecord) => void;
}

export const DashboardModule: React.FC<DashboardModuleProps> = ({
  accounts,
  accountBalances,
  transactions,
  debts,
  subscriptions,
  useBengaliDigits,
  onQuickAddTransaction,
  onNavigateTab,
  onRequestPaySubscription,
}) => {
  const todayISO = getTodayISO();
  const currentYM = getCurrentYearMonth();

  const unifiedLedger = useMemo(
    () =>
      buildUnifiedLedger({
        transactions,
        debts,
        subscriptions,
        accounts,
      }),
    [transactions, debts, subscriptions, accounts]
  );

  const getAccountName = (accId?: string) => {
    if (!accId) return 'নগদ ক্যাশ';
    return accounts.find((a) => a.id === accId)?.nameBn ?? 'নগদ ক্যাশ';
  };

  let todayIncomePaisa = 0;
  let todayExpensePaisa = 0;

  let monthIncomePaisa = 0;
  let monthExpensePaisa = 0;

  for (const tx of transactions) {
    if (tx.type === 'TRANSFER') continue;

    const isInflow = tx.type === 'INCOME' || tx.type === 'SALE';
    const isOutflow = tx.type === 'EXPENSE' || tx.type === 'PURCHASE';

    if (tx.date === todayISO) {
      if (isInflow) todayIncomePaisa += tx.amountPaisa;
      else if (isOutflow) todayExpensePaisa += tx.amountPaisa;
    }

    if (tx.date.startsWith(currentYM)) {
      if (isInflow) monthIncomePaisa += tx.amountPaisa;
      else if (isOutflow) monthExpensePaisa += tx.amountPaisa;
    }
  }

  const monthNetCashflowPaisa = monthIncomePaisa - monthExpensePaisa;

  let totalReceivablePaisa = 0;
  let totalPayablePaisa = 0;
  let overdueDebtsCount = 0;

  for (const debt of debts) {
    const repaidPaisa = debt.repayments.reduce((sum, r) => sum + r.amountPaisa, 0);
    const remainingPaisa = Math.max(0, debt.principalPaisa - repaidPaisa);
    if (remainingPaisa <= 0) continue;

    if (debt.direction === 'LENT' || debt.direction === 'RECEIVABLE_OTHER') {
      totalReceivablePaisa += remainingPaisa;
    } else {
      totalPayablePaisa += remainingPaisa;
    }

    if (debt.dueDate && debt.dueDate < todayISO) {
      overdueDebtsCount += 1;
    }
  }

  const totalBalancePaisa = accounts.reduce(
    (sum, acc) => sum + (accountBalances[acc.id] ?? acc.openingBalancePaisa),
    0
  );

  const activeSubscriptions = subscriptions
    .filter((s) => s.active)
    .sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate));

  const categoryTotalsMap: Record<string, number> = {};
  for (const item of unifiedLedger) {
    if (
      item.date.startsWith(currentYM) &&
      item.flowDirection === 'OUT'
    ) {
      categoryTotalsMap[item.categoryBn] =
        (categoryTotalsMap[item.categoryBn] ?? 0) + item.amountPaisa;
    }
  }
  const topCategories = Object.entries(categoryTotalsMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const maxBarValue = Math.max(monthIncomePaisa, monthExpensePaisa, 100);

  return (
    <div className="space-y-8">
      {/* Top Action & Primary Balance Banner */}
      <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              সকল হিসাবের সম্মিলিত ব্যালেন্স ({formatDateBnEn(todayISO, useBengaliDigits)})
            </p>
            <h1 className="mt-1 text-3xl sm:text-4xl font-bold tracking-tight font-mono tabular-nums text-slate-900 dark:text-white">
              {formatBDT(totalBalancePaisa, { useBengaliDigits })}
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>চলতি মাসের নিট উদ্বৃত্ত:</span>
              <span
                className={`font-mono tabular-nums font-semibold ${
                  monthNetCashflowPaisa >= 0
                    ? 'text-emerald-700 dark:text-emerald-400'
                    : 'text-red-600 dark:text-red-400'
                }`}
              >
                {formatBDT(monthNetCashflowPaisa, {
                  useBengaliDigits,
                  showSign: true,
                })}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onQuickAddTransaction('INCOME')}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন আয়</span>
            </button>
            <button
              type="button"
              onClick={() => onQuickAddTransaction('EXPENSE')}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন ব্যয়</span>
            </button>
          </div>
        </div>

        {/* 4-Column KPI Summary Strip */}
        <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">আজকের আয়</p>
            <p className="mt-1 text-xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
              <ArrowUpRight className="w-4 h-4 shrink-0" />
              {formatBDT(todayIncomePaisa, { useBengaliDigits })}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              আজকের ব্যয়:{' '}
              <span className="font-mono tabular-nums text-red-600 dark:text-red-400 font-medium">
                {formatBDT(todayExpensePaisa, { useBengaliDigits })}
              </span>
            </p>
          </div>

          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              চলতি মাসের মোট আয়
            </p>
            <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
              {formatBDT(monthIncomePaisa, { useBengaliDigits })}
            </p>
          </div>

          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              চলতি মাসের মোট ব্যয়
            </p>
            <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
              {formatBDT(monthExpensePaisa, { useBengaliDigits })}
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                মোট পাওনা ও দেনা
              </p>
              <button
                type="button"
                onClick={() => onNavigateTab('DEBTS')}
                className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
              >
                বিস্তারিত
              </button>
            </div>
            <p className="mt-1 text-xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
              পাওনা {formatBDT(totalReceivablePaisa, { useBengaliDigits })}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              দেনা:{' '}
              <span className="font-mono tabular-nums font-medium text-amber-700 dark:text-amber-400">
                {formatBDT(totalPayablePaisa, { useBengaliDigits })}
              </span>
              {overdueDebtsCount > 0 && ` · মেয়াদোত্তীর্ণ: ${overdueDebtsCount}টি`}
            </p>
          </div>
        </div>
      </section>

      {/* Middle 2-Column Split: Accounts Overview & Monthly Visual Summary Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <section className="lg:col-span-5 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  হিসাবসমূহের ব্যালেন্স
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  নগদ ক্যাশ, বিকাশ, নগদ, রকেট ও ব্যাংক
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('MORE')}
                className="min-h-[40px] px-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                <span>হিসাব ব্যবস্থাপনা</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/80 mt-2">
              {accounts.map((acc) => {
                const liveBalance =
                  accountBalances[acc.id] ?? acc.openingBalancePaisa;
                return (
                  <div
                    key={acc.id}
                    className="py-3 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {acc.nameBn}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                        {formatBDT(liveBalance, { useBengaliDigits })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="lg:col-span-7 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  চলতি মাসের আর্থিক চিত্র
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  মোট আয় ও মোট ব্যয়ের তুলনামূলক অনুপাত
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('TRANSACTIONS')}
                className="min-h-[40px] px-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                <span>সকল লেনদেন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-5 space-y-4">
              {[
                {
                  labelBn: 'চলতি মাসের আয়',
                  amount: monthIncomePaisa,
                  barClass: 'bg-emerald-600 dark:bg-emerald-500',
                },
                {
                  labelBn: 'চলতি মাসের ব্যয়',
                  amount: monthExpensePaisa,
                  barClass: 'bg-rose-500 dark:bg-rose-400',
                },
              ].map((row) => {
                const widthPct = Math.max(
                  2,
                  Math.round((row.amount / maxBarValue) * 100)
                );
                return (
                  <div key={row.labelBn} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {row.labelBn}
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {formatBDT(row.amount, { useBengaliDigits })}
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-200 ${row.barClass}`}
                        style={{ width: `${row.amount === 0 ? 0 : widthPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 pt-5 border-t border-slate-200 dark:border-slate-800">
              <h3 className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-3">
                চলতি মাসের প্রধান খরচের খাতসমূহ
              </h3>
              {topCategories.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-2">
                  এই মাসে এখনো কোনো খরচ লিপিবদ্ধ হয়নি।
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                  {topCategories.map(([catName, catAmount]) => (
                    <div
                      key={catName}
                      className="flex items-center justify-between py-1.5 border-b border-slate-100 dark:border-slate-800/60 text-xs"
                    >
                      <span className="text-slate-700 dark:text-slate-300 truncate pr-2">
                        {catName}
                      </span>
                      <span className="font-mono tabular-nums font-medium text-slate-900 dark:text-slate-100 shrink-0">
                        {formatBDT(catAmount, { useBengaliDigits })}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      </div>

      {/* Bottom 2-Column Split: Upcoming Bills & Unified Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <section className="lg:col-span-5 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                আসন্ন নিয়মিত বিল
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                ভাড়া, ইন্টারনেট, বিদ্যুৎ এবং নিয়মিত বিলসমূহ
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('SUBSCRIPTIONS')}
              className="min-h-[40px] px-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <span>সব দেখুন</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {activeSubscriptions.length === 0 ? (
            <div className="py-8 text-center">
              <CalendarClock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                কোনো চলমান বিল নেই
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/80 mt-2">
              {activeSubscriptions.slice(0, 4).map((sub) => {
                const thisMonthPayment = getThisMonthPayment(sub, currentYM);
                const isLockedForThisMonth = Boolean(thisMonthPayment);
                const paidMedium = thisMonthPayment
                  ? getAccountName(
                      thisMonthPayment.accountId ?? sub.defaultAccountId
                    )
                  : null;
                const isOverdue = !isLockedForThisMonth && sub.nextDueDate < todayISO;

                return (
                  <div
                    key={sub.id}
                    className="py-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {sub.nameBn}
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        <span>পরবর্তী তারিখ: {formatDateBnEn(sub.nextDueDate, useBengaliDigits)}</span>
                        <span aria-hidden="true">·</span>
                        {isLockedForThisMonth ? (
                          <span className="text-emerald-700 dark:text-emerald-400 font-medium inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> পরিশোধিত ({paidMedium})
                          </span>
                        ) : isOverdue ? (
                          <span className="text-red-600 dark:text-red-400 font-medium inline-flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> মেয়াদোত্তীর্ণ
                          </span>
                        ) : (
                          <span className="text-amber-700 dark:text-amber-400 font-medium">
                            পরিশোধ বাকি
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                        {formatBDT(sub.amountPaisa, { useBengaliDigits })}
                      </span>
                      {isLockedForThisMonth ? (
                        <button
                          type="button"
                          disabled
                          className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 text-xs font-semibold cursor-not-allowed whitespace-nowrap shrink-0"
                        >
                          পরিশোধিত
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onRequestPaySubscription(sub)}
                          className="min-h-[38px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                        >
                          পরিশোধ
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <section className="lg:col-span-7 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                সাম্প্রতিক সকল লেনদেন
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                আয়, ব্যয়, দেনা-পাওনা ও বিলের সর্বশেষ ৬টি হিসাব
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('TRANSACTIONS')}
              className="min-h-[40px] px-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <span>সব লেনদেন দেখুন</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {unifiedLedger.length === 0 ? (
            <div className="py-8 text-center">
              <Wallet className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                এখনো কোনো লেনদেন যোগ করা হয়নি
              </p>
              <button
                type="button"
                onClick={() => onQuickAddTransaction('INCOME')}
                className="mt-3 min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-medium"
              >
                + প্রথম লেনদেন যোগ করুন
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/80 mt-2">
              {unifiedLedger.slice(0, 6).map((item) => {
                const isInflow = item.flowDirection === 'IN';
                return (
                  <div
                    key={item.id}
                    className="py-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {item.titleBn}
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          {item.typeLabelBn}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{item.categoryBn}</span>
                        <span aria-hidden="true">·</span>
                        <span>মাধ্যম: {item.accountNameBn}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatDateBnEn(item.date, useBengaliDigits)}</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p
                        className={`text-sm font-bold font-mono tabular-nums ${
                          isInflow
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {isInflow ? '+' : '-'}
                        {formatBDT(item.amountPaisa, { useBengaliDigits })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
