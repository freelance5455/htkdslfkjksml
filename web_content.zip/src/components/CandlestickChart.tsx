import React, { useMemo, useState } from 'react';
import { Candle, Asset, TradeOrder } from '../types/trading';
import {
  calculateBollingerBands,
  calculateEMA,
  calculateRSI,
  calculateSupportAndResistance,
  calculateOrderFlowPressure,
} from '../utils/technicalAnalysis';
import { RefreshCw, Edit3, Check, Zap, Layers, Camera, Radio } from 'lucide-react';
import { soundManager } from '../utils/soundEffects';

interface CandlestickChartProps {
  candles: Candle[];
  asset: Asset;
  activeTrade?: TradeOrder | null;
  candleSecondsLeft: number;
  onSyncLiveRate?: () => void;
  onCalibratePrice?: (newPrice: number) => void;
  onSetMarketTrend?: (trend: 'BULLISH' | 'BEARISH' | 'RANGE') => void;
  onOpenPhotoAnalysis?: () => void;
  onOpenScanner?: () => void;
  isSyncingRates?: boolean;
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  candles,
  asset,
  activeTrade,
  candleSecondsLeft,
  onSyncLiveRate,
  onCalibratePrice,
  onSetMarketTrend,
  onOpenPhotoAnalysis,
  onOpenScanner,
  isSyncingRates = false,
}) => {
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [customPriceInput, setCustomPriceInput] = useState('');
  const [showSRLevels, setShowSRLevels] = useState(true);

  const visibleCandles = useMemo(() => candles.slice(-28), [candles]);

  const { minPrice, maxPrice, currentPrice } = useMemo(() => {
    if (visibleCandles.length === 0) {
      return { minPrice: 1, maxPrice: 1.01, currentPrice: 1.005 };
    }
    let min = Infinity;
    let max = -Infinity;
    for (const c of visibleCandles) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    }
    const cur = visibleCandles[visibleCandles.length - 1].close;
    // Add 10% breathing room padding on top and bottom
    const range = max - min || cur * 0.002;
    return {
      minPrice: min - range * 0.08,
      maxPrice: max + range * 0.08,
      currentPrice: cur,
    };
  }, [visibleCandles]);

  const closes = useMemo(() => visibleCandles.map((c) => c.close), [visibleCandles]);
  const bb = useMemo(() => calculateBollingerBands(closes, 14, 2.0), [closes]);
  const emaFast = useMemo(() => calculateEMA(closes, 7), [closes]);
  const emaSlow = useMemo(() => calculateEMA(closes, 14), [closes]);
  const currentRSI = useMemo(() => calculateRSI(closes, 14), [closes]);

  // Support & Resistance and Order Flow Pressure
  const { support, resistance } = useMemo(
    () => calculateSupportAndResistance(visibleCandles, asset.decimals),
    [visibleCandles, asset.decimals]
  );
  const { buyerPressure, sellerPressure, bias: orderFlowBias } = useMemo(
    () => calculateOrderFlowPressure(visibleCandles),
    [visibleCandles]
  );

  // Dimensions
  const width = 640;
  const height = 230;
  const chartBottom = height - 35; // Leave bottom 35px for RSI strip
  const chartHeight = chartBottom - 15;

  const getY = (price: number) => {
    if (maxPrice === minPrice) return chartHeight / 2;
    const ratio = (price - minPrice) / (maxPrice - minPrice);
    return chartHeight - ratio * chartHeight + 10;
  };

  const candleSpacing = width / Math.max(visibleCandles.length, 1);
  const candleBodyWidth = Math.max(candleSpacing * 0.65, 4);

  // EMA paths
  const emaFastPath = useMemo(() => {
    if (emaFast.length === 0) return '';
    return emaFast
      .map((val, idx) => {
        const x = idx * candleSpacing + candleSpacing / 2;
        const y = getY(val);
        return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }, [emaFast, candleSpacing, minPrice, maxPrice]);

  const emaSlowPath = useMemo(() => {
    if (emaSlow.length === 0) return '';
    return emaSlow
      .map((val, idx) => {
        const x = idx * candleSpacing + candleSpacing / 2;
        const y = getY(val);
        return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }, [emaSlow, candleSpacing, minPrice, maxPrice]);

  const currentPriceY = getY(currentPrice);
  const resistanceY = getY(resistance);
  const supportY = getY(support);

  const handleApplyCustomPrice = () => {
    const val = parseFloat(customPriceInput);
    if (!isNaN(val) && val > 0 && onCalibratePrice) {
      soundManager.playPip();
      onCalibratePrice(val);
      setIsEditingPrice(false);
    }
  };

  return (
    <div className="w-full bg-[#12060c] border border-[#2b0d1a] rounded-xl p-2.5 relative overflow-hidden shadow-inner">
      {/* Chart Top Bar with Asset and Indicator Values */}
      <div className="flex items-center justify-between text-xs mb-1.5 px-1 flex-wrap gap-1">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="font-bold text-slate-100 font-mono tracking-tight">{asset.symbol}</span>
          <span className="text-[11px] font-mono px-1.5 py-0.2 bg-emerald-950/70 text-emerald-400 border border-emerald-800/50 rounded font-semibold">
            {asset.payout}% PAYOUT
          </span>

          {/* Sync Real Quotex Live Rates button */}
          {onSyncLiveRate && (
            <button
              onClick={() => {
                soundManager.playPip();
                onSyncLiveRate();
              }}
              disabled={isSyncingRates}
              className="flex items-center gap-1 px-1.5 py-0.5 bg-[#220a16] hover:bg-[#300e1f] text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-mono transition-colors"
              title="Sync with real-time Quotex exchange feed"
            >
              <RefreshCw className={`w-2.5 h-2.5 ${isSyncingRates ? 'animate-spin' : ''}`} />
              <span>LIVE SYNC</span>
            </button>
          )}

          {/* S/R Layer toggle */}
          <button
            onClick={() => setShowSRLevels(!showSRLevels)}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono border transition-colors ${
              showSRLevels
                ? 'bg-red-950/60 text-red-300 border-red-500/40'
                : 'bg-[#1a0812] text-zinc-500 border-zinc-800'
            }`}
            title="Toggle institutional Support & Resistance lines"
          >
            <Layers className="w-2.5 h-2.5" />
            <span>S/R MAP</span>
          </button>

          {/* Sync from Quotex screenshot button */}
          {onOpenPhotoAnalysis && (
            <button
              onClick={() => {
                soundManager.playPip();
                onOpenPhotoAnalysis();
              }}
              className="flex items-center gap-1 px-1.5 py-0.5 bg-gradient-to-r from-red-950 to-rose-950 hover:from-red-900 hover:to-rose-900 text-rose-300 border border-rose-500/50 rounded text-[10px] font-mono font-bold shadow-sm transition-colors"
              title="Upload Quotex screenshot to match 100%"
            >
              <Camera className="w-2.5 h-2.5 text-rose-400" />
              <span>📸 MATCH QUOTEX</span>
            </button>
          )}

          {/* Quotex Market Scanner Floating Panel Button */}
          {onOpenScanner && (
            <button
              onClick={() => {
                soundManager.playPip();
                onOpenScanner();
              }}
              className="flex items-center gap-1 px-1.5 py-0.5 bg-[#07132c] hover:bg-[#0b1c44] text-[#00ff88] border border-[#00ff88]/50 rounded text-[10px] font-mono font-bold shadow-[0_0_8px_rgba(0,255,136,0.3)] transition-colors"
              title="Launch Quotex Market Scanner Floating Panel"
            >
              <Radio className="w-2.5 h-2.5 text-[#00ff88] animate-pulse" />
              <span>📡 SCANNER</span>
            </button>
          )}
        </div>

        {/* Live Candle Countdown & Current Price Calibrator */}
        <div className="flex items-center gap-2 font-mono">
          <div className="flex items-center gap-1 text-[11px] text-amber-400/90 font-medium">
            <span>Close:</span>
            <span className="font-bold tabular-nums text-white bg-[#250d18] px-1 rounded border border-amber-500/30">
              {candleSecondsLeft}s
            </span>
          </div>

          {/* Price display with 1-click Calibrator */}
          {isEditingPrice ? (
            <div className="flex items-center gap-1">
              <input
                type="number"
                step="any"
                value={customPriceInput}
                onChange={(e) => setCustomPriceInput(e.target.value)}
                placeholder={currentPrice.toFixed(asset.decimals)}
                className="w-24 bg-black border border-red-500 rounded px-1.5 py-0.5 text-xs text-white font-mono outline-none"
                autoFocus
                onKeyDown={(e) => e.key === 'Enter' && handleApplyCustomPrice()}
              />
              <button
                onClick={handleApplyCustomPrice}
                className="p-1 bg-emerald-600 rounded text-white hover:bg-emerald-500"
              >
                <Check className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => {
                setCustomPriceInput(currentPrice.toFixed(asset.decimals));
                setIsEditingPrice(true);
              }}
              className="group flex items-center gap-1 cursor-pointer"
              title="Tap to calibrate exact Quotex broker price"
            >
              <div className="text-sm font-bold text-emerald-400 tabular-nums">
                {currentPrice.toFixed(asset.decimals)}
              </div>
              <Edit3 className="w-2.5 h-2.5 text-zinc-500 group-hover:text-amber-400 transition-colors" />
            </div>
          )}
        </div>
      </div>

      {/* Quotex Market Trend Direction Matcher */}
      {onSetMarketTrend && (
        <div className="flex items-center justify-between text-[11px] bg-[#180712] border border-[#331122] rounded-lg px-2.5 py-1 mb-2 font-mono">
          <div className="flex items-center gap-1.5 text-zinc-300">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[10px] font-semibold text-zinc-300">Quotex Trend:</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onSetMarketTrend('BULLISH')}
              className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 transition-all active:scale-95 flex items-center gap-1 shadow-sm"
              title="Align chart with Quotex Bullish Uptrend"
            >
              <span>🟢 UPTREND (CALL)</span>
            </button>
            <button
              onClick={() => onSetMarketTrend('BEARISH')}
              className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950/80 hover:bg-red-900 border border-red-500/50 text-red-300 transition-all active:scale-95 flex items-center gap-1 shadow-sm"
              title="Align chart with Quotex Bearish Downtrend"
            >
              <span>🔴 DOWNTREND (PUT)</span>
            </button>
          </div>
        </div>
      )}

      {/* SVG Canvas for Chart */}
      <div className="relative w-full aspect-[2.6/1] min-h-[190px] max-h-[250px]">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full select-none"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="bbGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.01" />
            </linearGradient>
            <linearGradient id="rsiGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ec4899" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#ec4899" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line x1="0" y1={chartHeight * 0.25} x2={width} y2={chartHeight * 0.25} stroke="#2a0d1a" strokeDasharray="3 3" />
          <line x1="0" y1={chartHeight * 0.5} x2={width} y2={chartHeight * 0.5} stroke="#2a0d1a" strokeDasharray="3 3" />
          <line x1="0" y1={chartHeight * 0.75} x2={width} y2={chartHeight * 0.75} stroke="#2a0d1a" strokeDasharray="3 3" />

          {/* Institutional Support and Resistance Lines */}
          {showSRLevels && (
            <g>
              {/* Resistance line */}
              {resistanceY >= 10 && resistanceY <= chartHeight && (
                <g>
                  <line
                    x1="0"
                    y1={resistanceY}
                    x2={width}
                    y2={resistanceY}
                    stroke="#ef4444"
                    strokeWidth="1.2"
                    strokeDasharray="4 3"
                    opacity="0.8"
                  />
                  <rect
                    x={width - 105}
                    y={Math.max(resistanceY - 14, 2)}
                    width="100"
                    height="14"
                    rx="3"
                    fill="#260b17"
                    stroke="#ef4444"
                    strokeWidth="0.8"
                  />
                  <text
                    x={width - 55}
                    y={Math.max(resistanceY - 4, 12)}
                    textAnchor="middle"
                    fill="#ef4444"
                    fontSize="8.5"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    RES {resistance.toFixed(asset.decimals)}
                  </text>
                </g>
              )}

              {/* Support line */}
              {supportY >= 10 && supportY <= chartHeight && (
                <g>
                  <line
                    x1="0"
                    y1={supportY}
                    x2={width}
                    y2={supportY}
                    stroke="#10b981"
                    strokeWidth="1.2"
                    strokeDasharray="4 3"
                    opacity="0.8"
                  />
                  <rect
                    x={width - 105}
                    y={Math.min(supportY + 2, chartHeight - 16)}
                    width="100"
                    height="14"
                    rx="3"
                    fill="#0a2115"
                    stroke="#10b981"
                    strokeWidth="0.8"
                  />
                  <text
                    x={width - 55}
                    y={Math.min(supportY + 12, chartHeight - 6)}
                    textAnchor="middle"
                    fill="#10b981"
                    fontSize="8.5"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    SUP {support.toFixed(asset.decimals)}
                  </text>
                </g>
              )}
            </g>
          )}

          {/* Bollinger Bands Envelopes */}
          <line x1="0" y1={getY(bb.upper)} x2={width} y2={getY(bb.upper)} stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 2" opacity="0.6" />
          <line x1="0" y1={getY(bb.middle)} x2={width} y2={getY(bb.middle)} stroke="#38bdf8" strokeWidth="0.8" opacity="0.3" />
          <line x1="0" y1={getY(bb.lower)} x2={width} y2={getY(bb.lower)} stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 2" opacity="0.6" />

          {/* EMA Lines */}
          {emaFastPath && <path d={emaFastPath} fill="none" stroke="#22d3ee" strokeWidth="1.5" opacity="0.85" />}
          {emaSlowPath && <path d={emaSlowPath} fill="none" stroke="#f97316" strokeWidth="1.5" opacity="0.85" />}

          {/* Candlesticks */}
          {visibleCandles.map((c, i) => {
            const x = i * candleSpacing + candleSpacing / 2;
            const openY = getY(c.open);
            const closeY = getY(c.close);
            const highY = getY(c.high);
            const lowY = getY(c.low);
            const isGreen = c.close >= c.open;
            const candleTop = Math.min(openY, closeY);
            const candleHeight = Math.max(Math.abs(closeY - openY), 1.5);
            const color = isGreen ? '#10b981' : '#ef4444';

            return (
              <g key={c.time} className="transition-all duration-150">
                {/* Wick */}
                <line
                  x1={x}
                  y1={highY}
                  x2={x}
                  y2={lowY}
                  stroke={color}
                  strokeWidth="1.2"
                  opacity="0.8"
                />
                {/* Body */}
                <rect
                  x={x - candleBodyWidth / 2}
                  y={candleTop}
                  width={candleBodyWidth}
                  height={candleHeight}
                  fill={color}
                  rx="1"
                />
              </g>
            );
          })}

          {/* Current Price Horizontal Ray & Pulsing Ping */}
          <line
            x1="0"
            y1={currentPriceY}
            x2={width}
            y2={currentPriceY}
            stroke="#10b981"
            strokeWidth="1"
            strokeDasharray="2 2"
            opacity="0.8"
          />
          <circle cx={width - 5} cy={currentPriceY} r="3" fill="#10b981" className="animate-ping" />
          <circle cx={width - 5} cy={currentPriceY} r="2.5" fill="#10b981" />

          {/* Active Trade Entry Level Marker (if trade currently active) */}
          {activeTrade && activeTrade.status === 'OPEN' && (
            <g>
              <line
                x1="0"
                y1={getY(activeTrade.entryPrice)}
                x2={width}
                y2={getY(activeTrade.entryPrice)}
                stroke={activeTrade.direction === 'UP' ? '#00f5c4' : '#ff2a5f'}
                strokeWidth="1.8"
                strokeDasharray="4 3"
              />
              <rect
                x="8"
                y={getY(activeTrade.entryPrice) - 10}
                width="140"
                height="20"
                rx="4"
                fill="#180712"
                stroke={activeTrade.direction === 'UP' ? '#00f5c4' : '#ff2a5f'}
                strokeWidth="1"
              />
              <text
                x="14"
                y={getY(activeTrade.entryPrice) + 4}
                fill={activeTrade.direction === 'UP' ? '#00f5c4' : '#ff2a5f'}
                fontSize="10"
                fontWeight="bold"
                fontFamily="monospace"
              >
                {activeTrade.action}: {activeTrade.entryPrice.toFixed(asset.decimals)} ({activeTrade.secondsRemaining}s)
              </text>
            </g>
          )}

          {/* RSI Sub-Strip Area at bottom */}
          <line x1="0" y1={chartBottom} x2={width} y2={chartBottom} stroke="#2b0d1a" strokeWidth="1" />
          {/* 70 Overbought and 30 Oversold bounds */}
          <line x1="0" y1={height - 24} x2={width} y2={height - 24} stroke="#ef4444" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.4" />
          <line x1="0" y1={height - 10} x2={width} y2={height - 10} stroke="#10b981" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.4" />
          <text x="6" y={height - 8} fill="#71717a" fontSize="8" fontFamily="monospace">
            RSI (14): {currentRSI} {currentRSI <= 30 ? '• OVERSOLD' : currentRSI >= 70 ? '• OVERBOUGHT' : ''}
          </text>
          <text x={width - 55} y={height - 8} fill="#71717a" fontSize="8" fontFamily="monospace">
            BB (20, 2)
          </text>
        </svg>
      </div>

      {/* Live Order Flow Volume Pressure Meter */}
      <div className="mt-2 bg-[#170610] border border-[#300e1e] rounded-lg p-2">
        <div className="flex items-center justify-between text-[10px] font-mono font-bold mb-1">
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            BUYERS {buyerPressure}%
          </span>
          <span className="text-zinc-400 text-[9px] uppercase tracking-wider">
            {orderFlowBias}
          </span>
          <span className="text-red-400 flex items-center gap-1">
            SELLERS {sellerPressure}%
            <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
          </span>
        </div>
        <div className="w-full h-1.5 bg-[#2b0c1b] rounded-full overflow-hidden flex">
          <div
            className="h-full bg-emerald-500 transition-all duration-300"
            style={{ width: `${buyerPressure}%` }}
          />
          <div
            className="h-full bg-red-500 transition-all duration-300"
            style={{ width: `${sellerPressure}%` }}
          />
        </div>
      </div>

      {/* Indicator Legend Strip */}
      <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono pt-1.5 border-t border-[#250a16] px-1 mt-1">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1">
            <span className="w-2 h-0.5 bg-[#22d3ee] inline-block"></span> EMA 7
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-0.5 bg-[#f97316] inline-block"></span> EMA 14
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-0.5 bg-[#38bdf8] inline-block"></span> BB (20, 2)
          </span>
          <span className="flex items-center gap-1 text-red-400">
            <span className="w-2 h-0.5 bg-red-500 inline-block"></span> RES: {resistance.toFixed(asset.decimals)}
          </span>
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-0.5 bg-emerald-500 inline-block"></span> SUP: {support.toFixed(asset.decimals)}
          </span>
        </div>
        <div className="text-[10px] text-zinc-500 font-sans hidden sm:block">
          Quotex Server Sync: Optimal
        </div>
      </div>
    </div>
  );
};
