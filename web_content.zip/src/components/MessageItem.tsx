import React, { useState } from 'react';
import {
  GraduationCap,
  User,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Sparkles,
  HelpCircle,
  Footprints,
  Compass,
} from 'lucide-react';
import { ChatMessage } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { TUTOR_PERSONAS } from '../utils/tutor-prompts';

interface MessageItemProps {
  message: ChatMessage;
  onQuickFollowUp: (prompt: string) => void;
  onGenerateQuizFromTopic: (topic: string) => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  onQuickFollowUp,
  onGenerateQuizFromTopic,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const isUser = message.role === 'user';
  const persona = message.persona ? TUTOR_PERSONAS[message.persona] : null;

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean text of markdown characters for speech
    const cleanText = message.content
      .replace(/\$\$[\s\S]*?\$\$/g, ' mathematical equation ')
      .replace(/\$[^\$]+\$/g, ' equation ')
      .replace(/```[\s\S]*?```/g, ' code block omitted ')
      .replace(/[#*`_]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div
      className={`flex items-start space-x-3 md:space-x-4 max-w-4xl mx-auto py-2 ${
        isUser ? 'flex-row-reverse space-x-reverse' : ''
      }`}
    >
      {/* Avatar */}
      <div
        className={`w-8 h-8 rounded-xl shrink-0 flex items-center justify-center shadow-2xs ${
          isUser
            ? 'bg-slate-200 text-slate-700'
            : 'bg-slate-900 text-white'
        }`}
      >
        {isUser ? (
          <User className="w-4 h-4" />
        ) : (
          <GraduationCap className="w-4 h-4 text-indigo-400" />
        )}
      </div>

      {/* Message Box */}
      <div
        className={`flex-1 rounded-2xl p-4 transition ${
          isUser
            ? 'bg-slate-100 text-slate-800 border border-slate-200/80 rounded-tr-xs'
            : 'bg-white text-slate-800 border border-slate-200 shadow-2xs rounded-tl-xs'
        }`}
      >
        {/* Header line for tutor messages */}
        {!isUser && (
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-slate-800">
                {persona?.name || 'MindSparq Tutor'}
              </span>
              <span className="text-[10px] text-slate-400">
                {new Date(message.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>

            <div className="flex items-center space-x-1">
              <button
                onClick={handleSpeak}
                aria-label={isSpeaking ? 'Stop speaking' : 'Read message aloud'}
                className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition"
                title={isSpeaking ? 'Stop audio' : 'Listen with TTS'}
              >
                {isSpeaking ? (
                  <VolumeX className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5" />
                )}
              </button>
              <button
                onClick={handleCopy}
                aria-label="Copy message text"
                className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition"
                title="Copy response"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Content body */}
        <div className="break-words">
          {isUser ? (
            <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-slate-800">
              {message.content}
            </p>
          ) : (
            <>
              <MarkdownRenderer content={message.content} />
              {message.isStreaming && (
                <span className="inline-flex items-center space-x-1 ml-1 text-indigo-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce"
                    style={{ animationDelay: '0.15s' }}
                  />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce"
                    style={{ animationDelay: '0.3s' }}
                  />
                </span>
              )}
            </>
          )}
        </div>

        {/* Quick follow-up action buttons for tutor messages (when not streaming) */}
        {!isUser && !message.isStreaming && message.content.length > 50 && (
          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap gap-1.5">
            <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-400 py-1 mr-1">
              Follow-up:
            </span>
            <button
              type="button"
              onClick={() => onQuickFollowUp('Can you explain this in even simpler, plain English?')}
              aria-label="Ask tutor to explain simpler"
              className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
            >
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>Simpler</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onQuickFollowUp('Can you walk me through the solution step-by-step with numbered logic?')
              }
              aria-label="Ask tutor for step-by-step walkthrough"
              className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
            >
              <Footprints className="w-3 h-3 text-blue-500" />
              <span>Step-by-Step</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onQuickFollowUp('Can you provide an intuitive real-world analogy to help me visualize this?')
              }
              aria-label="Ask tutor for an intuitive analogy"
              className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
            >
              <Compass className="w-3 h-3 text-emerald-500" />
              <span>Analogy</span>
            </button>
            <button
              type="button"
              onClick={() => {
                const topicExcerpt = message.content.substring(0, 80).replace(/[#*`_]/g, '');
                onGenerateQuizFromTopic(topicExcerpt);
              }}
              aria-label="Generate practice quiz on this topic"
              className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition cursor-pointer"
            >
              <HelpCircle className="w-3 h-3 text-indigo-600" />
              <span>Quiz Me on This</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
