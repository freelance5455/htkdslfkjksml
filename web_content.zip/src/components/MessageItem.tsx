import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Copy, Check, Volume2, VolumeX, Sparkles, User, AlertCircle, RotateCcw } from 'lucide-react';
import { ChatMessage } from '../types';

interface MessageItemProps {
  message: ChatMessage;
  onRetry?: (messageId: string) => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({ message, onRetry }) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy message:', err);
    }
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message.content);
    // Find Malay or Indonesian voice if available
    const voices = window.speechSynthesis.getVoices();
    const msVoice = voices.find(
      (v) => v.lang.startsWith('ms') || v.lang.startsWith('id')
    );
    if (msVoice) {
      utterance.voice = msVoice;
    }
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  if (isUser) {
    return (
      <div className="flex justify-end gap-2.5 sm:gap-3 my-3 sm:my-4 group">
        <div className="flex flex-col items-end max-w-[85%] sm:max-w-[75%]">
          <div className="rounded-2xl rounded-tr-sm bg-gradient-to-r from-purple-700 to-fuchsia-700 text-white px-4 py-3 shadow-[0_4px_16px_rgba(147,51,234,0.3)] border border-purple-400/30">
            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words font-medium">
              {message.content}
            </p>
          </div>
          <div className="flex items-center gap-1.5 mt-1 px-1">
            <span className="text-[10px] text-purple-300/60 font-mono">{formattedTime}</span>
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-800 to-purple-950 border border-purple-500/40 flex items-center justify-center shrink-0 shadow-md">
          <User className="w-4 h-4 text-purple-200" />
        </div>
      </div>
    );
  }

  // Thinking State Indicator
  if (message.isThinking) {
    return (
      <div className="flex justify-start gap-2.5 sm:gap-3 my-3 sm:my-4">
        <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-purple-800 via-fuchsia-600 to-violet-500 border border-purple-400/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.35)] mt-0.5 animate-pulse">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div className="flex flex-col items-start max-w-[88%] sm:max-w-[80%]">
          <div className="flex items-center gap-2 mb-1 px-1">
            <span className="text-xs font-bold text-purple-200 tracking-wide">HANN AI</span>
            <span className="text-[10px] text-purple-300/50 font-mono">Sedang berfikir...</span>
          </div>
          <div className="rounded-2xl rounded-tl-sm bg-[#130728]/90 border border-purple-500/30 text-purple-200 px-4 py-3 shadow-[0_8px_24px_rgba(0,0,0,0.4)] backdrop-blur-sm flex items-center gap-3">
            <div className="flex items-center gap-1.5 py-1">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce [animation-delay:-0.3s]"></span>
              <span className="w-2 h-2 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:-0.15s]"></span>
              <span className="w-2 h-2 rounded-full bg-violet-400 animate-bounce"></span>
            </div>
            <span className="text-xs text-purple-300 font-medium">HANN AI dok karang jawapan...</span>
          </div>
        </div>
      </div>
    );
  }

  // Error State Bubble
  if (message.isError) {
    return (
      <div className="flex justify-start gap-2.5 sm:gap-3 my-3 sm:my-4">
        <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-red-950/80 border border-red-500/50 flex items-center justify-center shrink-0 text-red-400 mt-0.5 shadow-lg shadow-red-950/50">
          <AlertCircle className="w-4 h-4" />
        </div>
        <div className="flex flex-col items-start max-w-[88%] sm:max-w-[80%]">
          <div className="flex items-center gap-2 mb-1 px-1">
            <span className="text-xs font-bold text-red-300 tracking-wide">HANN AI (Ralat)</span>
            <span className="text-[10px] text-red-400/60 font-mono">{formattedTime}</span>
          </div>
          <div className="rounded-2xl rounded-tl-sm bg-red-950/40 border border-red-500/40 text-red-200 p-4 shadow-[0_8px_24px_rgba(0,0,0,0.4)] backdrop-blur-sm space-y-2">
            <p className="text-xs sm:text-sm leading-relaxed">{message.content}</p>
            {onRetry && (
              <button
                onClick={() => onRetry(message.id)}
                className="mt-2 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-900/40 hover:bg-red-800/60 text-white text-xs font-semibold border border-red-500/40 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Cuba Hantar Semula</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start gap-2.5 sm:gap-3 my-3 sm:my-4 group">
      {/* Bot Avatar */}
      <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-purple-800 via-fuchsia-600 to-violet-500 border border-purple-400/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.35)] mt-0.5">
        <Sparkles className="w-4 h-4 text-white" />
      </div>

      <div className="flex flex-col items-start max-w-[88%] sm:max-w-[80%] min-w-[200px]">
        {/* Bot Name and Tag */}
        <div className="flex items-center gap-2 mb-1 px-1">
          <span className="text-xs font-bold text-purple-200 tracking-wide">HANN AI</span>
          <span className="text-[9px] font-semibold px-1.5 py-0.2 rounded-full bg-purple-950/80 text-purple-300 border border-purple-700/40">
            Gemini AI
          </span>
          <span className="text-[10px] text-purple-300/50 font-mono ml-auto">{formattedTime}</span>
        </div>

        {/* Bubble */}
        <div className="relative w-full rounded-2xl rounded-tl-sm bg-[#130728]/90 border border-purple-500/25 text-slate-100 p-4 shadow-[0_8px_24px_rgba(0,0,0,0.4)] backdrop-blur-sm">
          <div className="prose-hann break-words">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                a: ({ ...props }) => (
                  <a
                    {...props}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-400 hover:text-purple-300 underline font-medium"
                  />
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>

          {/* Action buttons bar */}
          <div className="flex items-center justify-end gap-1.5 mt-3 pt-2 border-t border-purple-900/30">
            <button
              onClick={handleSpeak}
              className="p-1.5 rounded-lg text-purple-300/70 hover:text-purple-200 hover:bg-purple-900/30 transition-colors"
              title={isSpeaking ? 'Hentikan Suara' : 'Dengar Jawapan'}
            >
              {isSpeaking ? (
                <VolumeX className="w-3.5 h-3.5 text-fuchsia-400 animate-pulse" />
              ) : (
                <Volume2 className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg text-purple-300/70 hover:text-purple-200 hover:bg-purple-900/30 transition-colors flex items-center gap-1 text-[11px]"
              title="Salin Teks"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Disalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
