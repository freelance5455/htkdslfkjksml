import React, { useState } from 'react';
import {
  Coins,
  Gem,
  Sparkles,
  ArrowLeft,
  Check,
  RotateCcw,
  FileCode,
  Sliders,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { IdentifiedResource, CurrencyType } from '../types';

interface ManualEditorProps {
  resources: IdentifiedResource[];
  packageName: string;
  onApplyManualChanges: (updatedResources: IdentifiedResource[]) => void;
  onBack: () => void;
}

export const ManualEditor: React.FC<ManualEditorProps> = ({
  resources,
  packageName,
  onApplyManualChanges,
  onBack
}) => {
  const [items, setItems] = useState<IdentifiedResource[]>(resources);
  const [expandedSnippets, setExpandedSnippets] = useState<Record<string, boolean>>({});

  const handleValueChange = (id: string, valString: string) => {
    const num = parseInt(valString.replace(/[^0-9]/g, ''), 10) || 0;
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentValue: num } : item))
    );
  };

  const handleQuickAdd = (id: string, amount: number) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, currentValue: item.currentValue + amount } : item
      )
    );
  };

  const handleSetPreset = (id: string, presetValue: number) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentValue: presetValue } : item))
    );
  };

  const handleResetItem = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, currentValue: item.originalValue } : item
      )
    );
  };

  const handleResetAll = () => {
    setItems((prev) =>
      prev.map((item) => ({ ...item, currentValue: item.originalValue }))
    );
  };

  const toggleSnippet = (id: string) => {
    setExpandedSnippets((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const getCurrencyIcon = (type: CurrencyType) => {
    switch (type) {
      case 'coins':
        return <Coins className="w-4 h-4 text-amber-400" />;
      case 'gems':
        return <Gem className="w-4 h-4 text-emerald-400" />;
      case 'diamonds':
        return <Sparkles className="w-4 h-4 text-cyan-400" />;
      default:
        return <Coins className="w-4 h-4 text-purple-400" />;
    }
  };

  const modifiedCount = items.filter((item) => item.currentValue !== item.originalValue).length;

  return (
    <div className="flex flex-col w-full max-w-4xl mx-auto py-2">
      {/* Top Bar Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider font-mono">
                Manual Modification Mode
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                {modifiedCount} / {items.length} edited
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
              Edit Identified Files &amp; Values
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleResetAll}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-400 hover:text-slate-200 border border-slate-800 flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All</span>
          </button>
          <button
            onClick={() => onApplyManualChanges(items)}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Apply Modifications &amp; Recompile</span>
          </button>
        </div>
      </div>

      {/* Editor Guide Banner */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 mb-6 flex items-start gap-3">
        <Sliders className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <span className="font-bold text-white">Manual Editing active:</span> You can independently adjust the value for each identified resource key. Use the numeric input or quick buttons (+10k, +100k, 999k) to specify desired quantities. Once satisfied, click <strong>Apply Modifications &amp; Recompile</strong>.
        </div>
      </div>

      {/* Resource Cards */}
      <div className="space-y-4">
        {items.map((item) => {
          const isModified = item.currentValue !== item.originalValue;
          const isExpanded = !!expandedSnippets[item.id];

          return (
            <div
              key={item.id}
              className={`rounded-2xl p-4 sm:p-5 transition-all border ${
                isModified
                  ? 'bg-slate-900/90 border-emerald-500/50 shadow-lg shadow-emerald-950/20'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* File info and key details */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-slate-400">
                      <FileCode className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-mono text-xs font-bold text-slate-200 truncate max-w-sm sm:max-w-md">
                      {item.filePath}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/60">
                      Line {item.lineNumber}
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5 mt-2 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-slate-200 border border-slate-700">
                      {getCurrencyIcon(item.currencyType)}
                      <span className="capitalize">{item.currencyType}</span>
                    </span>

                    <span className="text-xs font-mono text-slate-400">
                      Key: <span className="text-emerald-400 font-bold">{item.keyName}</span>
                    </span>

                    <span className="text-xs font-mono text-slate-400">
                      Original: <span className="text-slate-300">{item.originalValue.toLocaleString()}</span>
                    </span>

                    {isModified && (
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        Modified
                      </span>
                    )}
                  </div>
                </div>

                {/* Edit Controls */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 flex-shrink-0">
                  {/* Numeric Input */}
                  <div className="relative">
                    <input
                      type="text"
                      value={item.currentValue.toLocaleString()}
                      onChange={(e) => handleValueChange(item.id, e.target.value)}
                      className={`w-full sm:w-40 px-3 py-2 rounded-xl text-sm font-mono font-bold text-right focus:outline-none transition border ${
                        isModified
                          ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/60 focus:border-emerald-400'
                          : 'bg-slate-950 text-white border-slate-700 focus:border-amber-400'
                      }`}
                    />
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleQuickAdd(item.id, 10000)}
                      className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-slate-300 transition"
                      title="Add 10,000"
                    >
                      +10k
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickAdd(item.id, 100000)}
                      className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-slate-300 transition"
                      title="Add 100,000"
                    >
                      +100k
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSetPreset(item.id, 999999)}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-[11px] font-mono text-emerald-400 border border-emerald-500/30 transition font-bold"
                      title="Set to 999,999"
                    >
                      999k
                    </button>
                    {isModified && (
                      <button
                        type="button"
                        onClick={() => handleResetItem(item.id)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                        title="Reset to original value"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* View context snippet toggle */}
              <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <button
                  type="button"
                  onClick={() => toggleSnippet(item.id)}
                  className="text-slate-400 hover:text-slate-200 flex items-center gap-1 transition"
                >
                  <span>{isExpanded ? 'Hide Code Location' : 'Inspect Code Location'}</span>
                  {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>

                <span className="text-slate-400 font-mono text-[10px]">
                  File format: {item.fileType.toUpperCase()}
                </span>
              </div>

              {isExpanded && (
                <pre className="mt-2 p-2.5 rounded-lg bg-slate-950 border border-slate-800/90 text-[11px] font-mono text-emerald-300 overflow-x-auto leading-relaxed">
                  {item.contextSnippet}
                </pre>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Action Footer */}
      <div className="sticky bottom-4 mt-8 p-4 rounded-2xl bg-slate-900/95 backdrop-blur border border-slate-800 flex items-center justify-between shadow-2xl">
        <div className="text-xs text-slate-400">
          <span className="font-bold text-white">{modifiedCount}</span> of {items.length} values will be patched in the package.
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition"
          >
            Cancel
          </button>
          <button
            onClick={() => onApplyManualChanges(items)}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Save &amp; Start Recompilation</span>
          </button>
        </div>
      </div>
    </div>
  );
};
