import React from 'react';
import { Calendar, Radio, Trophy, CheckCircle2 } from 'lucide-react';

interface DateTabsProps {
  dayGroup: 'today' | 'tomorrow' | 'yesterday';
  setDayGroup: (group: 'today' | 'tomorrow' | 'yesterday') => void;
  selectedLeague: string;
  setSelectedLeague: (league: string) => void;
  onlyLive: boolean;
  setOnlyLive: (onlyLive: boolean) => void;
  liveCount: number;
  availableLeagues: string[];
}

export const DateTabs: React.FC<DateTabsProps> = ({
  dayGroup,
  setDayGroup,
  selectedLeague,
  setSelectedLeague,
  onlyLive,
  setOnlyLive,
  liveCount,
  availableLeagues,
}) => {
  return (
    <div className="space-y-3 mb-6">
      {/* Day Selector Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#111726] p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-lg transition-colors">
        <div className="grid grid-cols-3 gap-1 w-full sm:w-auto">
          <button
            id="day-yesterday-btn"
            onClick={() => {
              setDayGroup('yesterday');
              setOnlyLive(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all text-center cursor-pointer ${
              dayGroup === 'yesterday'
                ? 'bg-gradient-to-r from-rose-700 to-rose-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            مباريات الأمس
          </button>

          <button
            id="day-today-btn"
            onClick={() => setDayGroup('today')}
            className={`relative px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
              dayGroup === 'today'
                ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-lg shadow-rose-600/30'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <span>مباريات اليوم</span>
            {liveCount > 0 && (
              <span className="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-black bg-white text-rose-600 rounded-full animate-pulse">
                {liveCount} مباشر
              </span>
            )}
          </button>

          <button
            id="day-tomorrow-btn"
            onClick={() => {
              setDayGroup('tomorrow');
              setOnlyLive(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all text-center cursor-pointer ${
              dayGroup === 'tomorrow'
                ? 'bg-gradient-to-r from-rose-700 to-rose-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            مباريات الغد
          </button>
        </div>

        {/* Live Only Filter Toggle (Only shown on Today) */}
        {dayGroup === 'today' && (
          <button
            id="toggle-live-only-btn"
            onClick={() => setOnlyLive(!onlyLive)}
            className={`w-full sm:w-auto px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all border cursor-pointer ${
              onlyLive
                ? 'bg-rose-500/15 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-400 dark:border-rose-500/50 shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${onlyLive ? 'bg-rose-500 animate-ping' : 'bg-slate-400 dark:bg-slate-500'}`} />
            <span>عرض المباشر فقط</span>
            {onlyLive && <CheckCircle2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />}
          </button>
        )}
      </div>

      {/* League Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
        <span className="text-slate-500 dark:text-slate-400 font-medium shrink-0 flex items-center gap-1 pl-1">
          <Trophy className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
          البطولة:
        </span>

        <button
          id="league-filter-all"
          onClick={() => setSelectedLeague('all')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all shrink-0 border cursor-pointer ${
            selectedLeague === 'all'
              ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-white shadow-sm'
              : 'bg-white dark:bg-[#141a29] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs'
          }`}
        >
          جميع البطولات
        </button>

        {availableLeagues.map((league) => (
          <button
            key={league}
            id={`league-filter-${league}`}
            onClick={() => setSelectedLeague(league)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all shrink-0 border cursor-pointer ${
              selectedLeague === league
                ? 'bg-rose-600 text-white border-rose-500 shadow-sm'
                : 'bg-white dark:bg-[#141a29] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:text-slate-900 dark:hover:text-white shadow-xs'
            }`}
          >
            {league}
          </button>
        ))}
      </div>
    </div>
  );
};
