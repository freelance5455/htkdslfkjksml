import React from 'react';
import { motion } from 'motion/react';
import { Timer, RotateCcw, Video, Home } from 'lucide-react';
import { Language } from '../types';
import { getTranslations } from '../services/i18n';
import { BannerAd } from './BannerAd';

interface TimesUpModalProps {
  onRetry: () => void;
  onWatchAdToContinue: () => void;
  onHome: () => void;
  language?: Language;
}

export const TimesUpModal: React.FC<TimesUpModalProps> = ({
  onRetry,
  onWatchAdToContinue,
  onHome,
  language = 'en',
}) => {
  const t = getTranslations(language);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.85, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-700 p-6 flex flex-col items-center text-center relative overflow-hidden"
      >
        {/* Top Warning Accent */}
        <div className="w-16 h-16 rounded-3xl bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 text-rose-500 flex items-center justify-center mb-3 shadow-inner">
          <Timer className="w-8 h-8 animate-pulse" />
        </div>

        <h2 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight">
          {t.timesUp}
        </h2>
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
          {t.timesUpSub}
        </p>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5 mt-5">
          {/* 1. WATCH AD & CONTINUE */}
          <button
            id="btn-timed-continue-ad"
            type="button"
            onClick={onWatchAdToContinue}
            className="w-full h-13 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-black text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 active:scale-98 transition"
          >
            <Video className="w-4 h-4" />
            <span>{t.continueWatchAd}</span>
          </button>

          {/* 2. RETRY */}
          <button
            id="btn-timed-retry"
            type="button"
            onClick={onRetry}
            className="w-full h-11 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-2 active:scale-98 transition border border-slate-200 dark:border-slate-700"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.replay}</span>
          </button>

          {/* Return to Home */}
          <button
            id="btn-timed-home"
            type="button"
            onClick={onHome}
            className="w-full h-9 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <Home className="w-3.5 h-3.5" />
            <span>{t.home}</span>
          </button>
        </div>

        {/* Banner Ad at bottom of modal */}
        <div className="w-full mt-4 -mx-6 -mb-6 overflow-hidden rounded-b-3xl">
          <BannerAd />
        </div>
      </motion.div>
    </div>
  );
};
