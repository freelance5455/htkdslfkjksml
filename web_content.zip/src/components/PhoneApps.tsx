import { useEffect, useRef, useState } from "react";
import { store, useStore, CRASH_MIN, CRASH_MAX, type StoreAppId } from "../lib/store";
import { toFa } from "../lib/fa";
import { boop, chirp, fanfare } from "../lib/sound";

/* ================================================================== */
/*  shared bits                                                        */
/* ================================================================== */
export function PBtn({
  children,
  onClick,
  tone = "primary",
  disabled,
}: {
  children: React.ReactNode;
  onClick: () => void;
  tone?: "primary" | "ghost" | "danger" | "go";
  disabled?: boolean;
}) {
  const tones = {
    primary: "bg-gradient-to-b from-amber-400 to-amber-500 text-amber-950",
    ghost: "bg-slate-100 text-slate-700 ring-1 ring-slate-900/8",
    danger: "bg-gradient-to-b from-rose-500 to-rose-600 text-white",
    go: "bg-gradient-to-b from-emerald-500 to-emerald-600 text-white",
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        boop();
        onClick();
      }}
      className={`w-full rounded-xl px-3 py-2 text-[11.5px] font-extrabold transition active:scale-[0.97] ${
        disabled ? "bg-slate-200 text-slate-400" : tones[tone]
      }`}
    >
      {children}
    </button>
  );
}

function Note({ children, tone = "warn" }: { children: React.ReactNode; tone?: "warn" | "info" }) {
  return (
    <div
      className={`rounded-xl px-2.5 py-2 text-[10.5px] leading-4 font-bold ${
        tone === "warn" ? "bg-rose-100 text-rose-700" : "bg-sky-100 text-sky-800"
      }`}
    >
      {children}
    </div>
  );
}

/** formats MB → "۱٫۲ گیگ" / "۵۴۰ مگ" */
export function fmtData(mb: number) {
  if (mb >= 1024) return `${toFa((mb / 1024).toFixed(1).replace(".", "٫"))} گیگ`;
  return `${toFa(Math.round(mb))} مگ`;
}

/* ================================================================== */
/*  📶 DATA — buy mobile internet                                      */
/* ================================================================== */
const BUNDLES = [
  { mb: 200, price: 150, label: "۲۰۰ مگ" },
  { mb: 1024, price: 600, label: "۱ گیگ" },
  { mb: 5120, price: 2500, label: "۵ گیگ" },
  { mb: 20480, price: 8000, label: "۲۰ گیگ" },
];

export function DataApp() {
  const data = useStore((s) => s.data);
  const points = useStore((s) => s.points);

  return (
    <div className="flex flex-col gap-2">
      <div className="rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 p-3 text-white">
        <div className="text-[9.5px] font-bold opacity-80">اینترنت باقی‌مانده</div>
        <div className="text-2xl font-black tabular-nums">{fmtData(data)}</div>
        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/25">
          <div
            className="h-full rounded-full bg-white"
            style={{ width: `${Math.min(100, (data / 20480) * 100)}%` }}
          />
        </div>
      </div>

      {data < 50 && <Note>بدون اینترنت نمی‌تونی برنامه دانلود کنی یا بازی آنلاین بزنی.</Note>}

      <div className="text-[10.5px] font-black text-slate-600">بسته‌های اینترنت</div>
      {BUNDLES.map((b) => (
        <button
          key={b.mb}
          type="button"
          disabled={points < b.price}
          onClick={() => {
            store.buyData(b.mb, b.price);
            boop();
          }}
          className={`flex items-center gap-2 rounded-xl bg-white p-2.5 text-right ring-1 ring-slate-900/8 transition active:scale-[0.98] ${
            points < b.price ? "opacity-45" : ""
          }`}
        >
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-teal-100 text-base">
            📶
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[11.5px] font-black text-slate-900">{b.label}</span>
            <span className="block text-[9.5px] font-bold text-slate-500">بدون محدودیت زمانی</span>
          </span>
          <span className="text-[11px] font-black text-amber-600">{toFa(b.price)}</span>
        </button>
      ))}
    </div>
  );
}

/* ================================================================== */
/*  🏪 APP STORE                                                       */
/* ================================================================== */
type StoreEntry = {
  id: StoreAppId;
  name: string;
  dev: string;
  emoji: string;
  size: number;
  price: number;
  rating: number;
  desc: string;
  tint: string;
  filtered?: boolean;
};

export const STORE_APPS: StoreEntry[] = [
  {
    id: "crash",
    name: "انفجار بت",
    dev: "Jeeko Games",
    emoji: "🚀",
    size: 320,
    price: 0,
    rating: 4.6,
    desc: "شرط ببند، ضریب بالا می‌ره… قبل از انفجار برداشت کن!",
    tint: "linear-gradient(160deg,#FF7A59,#D7263D)",
  },
  {
    id: "match",
    name: "حدس مسابقات",
    dev: "Jeeko Sports",
    emoji: "⚽",
    size: 260,
    price: 0,
    rating: 4.3,
    desc: "برنده‌ی بازی رو حدس بزن و دو برابر کن.",
    tint: "linear-gradient(160deg,#34D399,#059669)",
  },
  {
    id: "vpn",
    name: "جیکو VPN",
    dev: "Free Net",
    emoji: "🛡️",
    size: 120,
    price: 500,
    rating: 4.8,
    desc: "فیلترشکن پرسرعت برای باز کردن سایت‌های مسدود.",
    tint: "linear-gradient(160deg,#818CF8,#4338CA)",
  },
  {
    id: "aparat",
    name: "آپارات",
    dev: "Sabaidea",
    emoji: "🎬",
    size: 380,
    price: 0,
    rating: 4.1,
    desc: "سرویس اشتراک ویدیوی ایرانی — بدون فیلترشکن باز می‌شه.",
    tint: "linear-gradient(160deg,#F87171,#DC2626)",
  },
];

export function StoreApp() {
  const installed = useStore((s) => s.installed);
  const downloading = useStore((s) => s.downloading);
  const data = useStore((s) => s.data);
  const points = useStore((s) => s.points);
  const [, force] = useState(0);

  useEffect(() => {
    if (!downloading) return;
    const id = window.setInterval(() => force((v) => v + 1), 100);
    return () => window.clearInterval(id);
  }, [downloading]);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2 rounded-2xl bg-white p-2.5 ring-1 ring-slate-900/8">
        <span className="text-xl">🏪</span>
        <div className="min-w-0 flex-1">
          <div className="text-[11.5px] font-black text-slate-900">جیکو پلی</div>
          <div className="text-[9.5px] font-bold text-slate-500">
            اینترنت: {fmtData(data)}
          </div>
        </div>
      </div>

      {data < 100 && (
        <Note>
          برای دانلود اینترنت لازمه — از برنامه‌ی 📶 بسته بخر.
        </Note>
      )}

      {STORE_APPS.map((a) => {
        const isInstalled = installed.includes(a.id);
        const dl = downloading?.id === a.id ? downloading : null;
        const pct = dl ? Math.min(100, ((Date.now() - dl.started) / dl.ms) * 100) : 0;
        const cantData = data < a.size;
        const cantPoints = points < a.price;

        return (
          <div key={a.id} className="rounded-2xl bg-white p-2.5 ring-1 ring-slate-900/8">
            <div className="flex items-center gap-2">
              <span
                className="grid size-11 shrink-0 place-items-center rounded-[26%] text-xl shadow-sm"
                style={{ background: a.tint }}
              >
                {a.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="truncate text-[11.5px] font-black text-slate-900">{a.name}</span>
                  {a.filtered && (
                    <span className="shrink-0 rounded bg-rose-100 px-1 text-[8px] font-black text-rose-600">
                      فیلتر
                    </span>
                  )}
                </div>
                <div className="text-[9px] font-bold text-slate-500">{a.dev}</div>
                <div className="text-[9px] font-bold text-slate-400">
                  ⭐ {toFa(String(a.rating).replace(".", "٫"))} · {fmtData(a.size)}
                </div>
              </div>

              {isInstalled ? (
                <button
                  type="button"
                  onClick={() => {
                    store.openApp(a.id);
                    boop();
                  }}
                  className="shrink-0 rounded-lg bg-emerald-500 px-2.5 py-1.5 text-[10px] font-black text-white active:scale-95"
                >
                  اجرا
                </button>
              ) : dl ? (
                <span className="shrink-0 text-[10px] font-black text-sky-600 tabular-nums">
                  {toFa(Math.round(pct))}٪
                </span>
              ) : (
                <button
                  type="button"
                  disabled={cantData || cantPoints || !!downloading}
                  onClick={() => {
                    store.download(a.id, a.size, a.price);
                    boop();
                  }}
                  className={`shrink-0 rounded-lg px-2.5 py-1.5 text-[10px] font-black active:scale-95 ${
                    cantData || cantPoints || !!downloading
                      ? "bg-slate-200 text-slate-400"
                      : "bg-sky-500 text-white"
                  }`}
                >
                  {a.price > 0 ? `${toFa(a.price)}` : "نصب"}
                </button>
              )}
            </div>

            <p className="mt-1.5 text-[9.5px] leading-4 font-medium text-slate-500">{a.desc}</p>

            {dl && (
              <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-sky-500 transition-[width] duration-100"
                  style={{ width: `${pct}%` }}
                />
              </div>
            )}

            {isInstalled && (
              <button
                type="button"
                onClick={() => {
                  store.uninstall(a.id);
                  boop();
                }}
                className="mt-1.5 text-[9px] font-black text-rose-500"
              >
                حذف نصب
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ================================================================== */
/*  🛡️ VPN                                                            */
/* ================================================================== */
export function VpnApp() {
  const on = useStore((s) => s.vpnOn);
  const data = useStore((s) => s.data);

  return (
    <div className="flex flex-col items-center gap-3 py-2">
      <button
        type="button"
        onClick={() => {
          store.toggleVpn();
          boop();
        }}
        className={`relative grid size-32 place-items-center rounded-full transition ${
          on
            ? "bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-[0_0_40px_-6px_rgba(16,185,129,0.8)]"
            : "bg-gradient-to-br from-slate-300 to-slate-500"
        }`}
      >
        <span className="text-5xl">{on ? "🔓" : "🔒"}</span>
        {on && <span className="absolute inset-0 animate-ping rounded-full bg-emerald-400/30" />}
      </button>

      <div className={`text-[13px] font-black ${on ? "text-emerald-600" : "text-slate-500"}`}>
        {on ? "متصل — آی‌پی: آلمان 🇩🇪" : "قطع است"}
      </div>

      <div className="w-full rounded-xl bg-white p-2.5 text-center ring-1 ring-slate-900/8">
        <div className="text-[9.5px] font-bold text-slate-500">اینترنت باقی‌مانده</div>
        <div className="text-[13px] font-black text-slate-900">{fmtData(data)}</div>
      </div>

      <Note tone="info">
        بعضی برنامه‌ها (مثل یوتیوب) فیلترن و فقط با روشن بودن فیلترشکن باز می‌شن.
      </Note>
    </div>
  );
}

/* ================================================================== */
/*  🚀 CRASH (انفجار)                                                  */
/* ================================================================== */
export function CrashApp() {
  const crash = useStore((s) => s.crash);
  const points = useStore((s) => s.points);
  const data = useStore((s) => s.data);
  const [bet, setBet] = useState(CRASH_MIN);

  useEffect(() => {
    if (crash?.state !== "flying") return;
    const id = window.setInterval(() => store.crashTick(), 80);
    return () => window.clearInterval(id);
  }, [crash?.state]);

  useEffect(() => {
    if (crash?.state === "busted") chirp(0.4);
  }, [crash?.state]);

  const flying = crash?.state === "flying";
  const mult = crash?.mult ?? 1;
  // rocket climbs with the multiplier
  const climb = Math.min(88, Math.log(Math.max(1, mult)) * 52);

  return (
    <div className="flex flex-col gap-2">
      {/* chart */}
      <div
        className={`relative h-40 overflow-hidden rounded-2xl transition-colors ${
          crash?.state === "busted"
            ? "bg-gradient-to-b from-rose-300 to-rose-500"
            : "bg-gradient-to-b from-slate-800 to-indigo-900"
        }`}
      >
        {/* grid */}
        {[20, 40, 60, 80].map((y) => (
          <span key={y} className="absolute inset-x-0 h-px bg-white/10" style={{ bottom: `${y}%` }} />
        ))}

        <span
          className="absolute text-3xl transition-all duration-75"
          style={{ bottom: `${climb}%`, left: `${8 + climb * 0.7}%` }}
        >
          {crash?.state === "busted" ? "💥" : "🚀"}
        </span>

        <div className="absolute inset-0 grid place-items-center">
          <div
            className={`text-4xl font-black tabular-nums drop-shadow-lg ${
              crash?.state === "busted" ? "text-white" : "text-emerald-300"
            }`}
            dir="ltr"
          >
            {mult.toFixed(2)}×
          </div>
        </div>

        {crash?.state === "cashed" && (
          <div className="absolute inset-x-0 bottom-2 text-center text-[11px] font-black text-emerald-300">
            برداشت شد: {toFa(crash.payout)} پوینت
          </div>
        )}
        {crash?.state === "busted" && (
          <div className="absolute inset-x-0 bottom-2 text-center text-[11px] font-black text-white">
            منفجر شد! {toFa(crash.bet)} پوینت سوخت
          </div>
        )}
      </div>

      {flying ? (
        <PBtn tone="go" onClick={() => store.crashCashout()}>
          💰 برداشت — {toFa(Math.floor((crash?.bet ?? 0) * mult))}
        </PBtn>
      ) : crash && crash.state !== "idle" ? (
        <PBtn onClick={() => store.crashReset()}>دست جدید</PBtn>
      ) : (
        <>
          <div className="rounded-xl bg-white p-2.5 ring-1 ring-slate-900/8">
            <div className="mb-1.5 flex justify-between text-[10.5px] font-bold text-slate-500">
              <span>مبلغ شرط</span>
              <span className="text-slate-900 tabular-nums">{toFa(bet)}</span>
            </div>
            <input
              type="range"
              min={CRASH_MIN}
              max={CRASH_MAX}
              step={50000}
              value={bet}
              onChange={(e) => setBet(Number(e.target.value))}
              className="w-full accent-rose-500"
            />
            <div className="mt-1 flex justify-between text-[9px] font-bold text-slate-400">
              <span>{toFa(CRASH_MIN)}</span>
              <span>{toFa(CRASH_MAX)}</span>
            </div>
          </div>
          {data < 5 && <Note>برای بازی آنلاین اینترنت لازمه.</Note>}
          <PBtn
            tone="danger"
            disabled={points < bet || data < 5}
            onClick={() => store.crashStart(bet)}
          >
            🚀 شروع پرواز
          </PBtn>
        </>
      )}

      <Note tone="info">
        هر ثانیه ضریب بالا می‌ره ولی هر لحظه ممکنه منفجر شه. قبل از انفجار برداشت کن!
      </Note>
    </div>
  );
}

/* ================================================================== */
/*  ⚽ MATCH PREDICTION                                                */
/* ================================================================== */
export function MatchApp() {
  const m = useStore((s) => s.match);
  const points = useStore((s) => s.points);
  const data = useStore((s) => s.data);
  const [bet, setBet] = useState(CRASH_MIN);
  const tickRef = useRef(0);

  useEffect(() => {
    if (!m) store.matchNew();
  }, [m]);

  useEffect(() => {
    if (m?.state !== "live") return;
    const id = window.setInterval(() => {
      store.matchTick();
      tickRef.current++;
    }, 500);
    return () => window.clearInterval(id);
  }, [m?.state]);

  useEffect(() => {
    if (m?.state === "done" && m.won) fanfare();
  }, [m?.state, m?.won]);

  if (!m) return null;

  const secs = m.state === "live" ? Math.min(13, Math.floor((Date.now() - m.startedAt) / 1000)) : 0;

  return (
    <div className="flex flex-col gap-2">
      {/* scoreboard */}
      <div className="overflow-hidden rounded-2xl bg-gradient-to-b from-emerald-700 to-emerald-900 text-white">
        <div className="flex items-center justify-between px-2 py-1 text-[9px] font-black">
          <span className="flex items-center gap-1">
            {m.state === "live" && <span className="size-1.5 animate-pulse rounded-full bg-rose-400" />}
            {m.state === "live" ? "LIVE" : m.state === "done" ? "پایان" : "قبل از بازی"}
          </span>
          <span className="tabular-nums">{m.state === "live" ? `${toFa(secs)}'` : "--"}</span>
        </div>

        <div className="flex items-center justify-around px-2 pb-2">
          <div className="flex flex-col items-center gap-0.5">
            <span className="text-2xl">{m.homeEmoji}</span>
            <span className="text-[9.5px] font-black">{m.home}</span>
          </div>
          <div className="text-2xl font-black tabular-nums" dir="ltr">
            {toFa(m.scoreH)} : {toFa(m.scoreA)}
          </div>
          <div className="flex flex-col items-center gap-0.5">
            <span className="text-2xl">{m.awayEmoji}</span>
            <span className="text-[9.5px] font-black">{m.away}</span>
          </div>
        </div>

        {/* pitch with running players */}
        <div className="relative h-16 overflow-hidden bg-emerald-600">
          <span className="absolute inset-y-0 left-1/2 w-px bg-white/40" />
          <span className="absolute top-1/2 left-1/2 size-8 -translate-x-1/2 -translate-y-1/2 rounded-full ring-1 ring-white/40" />
          {m.state === "live" &&
            Array.from({ length: 6 }).map((_, i) => (
              <span
                key={i}
                className="absolute text-sm"
                style={{
                  bottom: `${12 + ((i * 37) % 46)}%`,
                  left: `${((secs * (11 + i * 4) + i * 27) % 86) + 5}%`,
                  transition: "left 0.5s linear",
                }}
              >
                {i % 2 === 0 ? "🏃" : "🏃‍♂️"}
              </span>
            ))}
          {m.state === "live" && <span className="absolute bottom-2 left-1/3 text-xs">⚽</span>}
          {m.state !== "live" && (
            <span className="absolute inset-0 grid place-items-center text-[10px] font-black text-white/80">
              {m.state === "betting" ? "🎟️ شرط‌بندی باز است" : "🏁 بازی تموم شد"}
            </span>
          )}
        </div>

        {/* crowd */}
        <div className="bg-emerald-950/60 py-0.5 text-center text-[9px] tracking-widest">
          👥👥👥👥👥👥👥👥
        </div>
      </div>

      {m.state === "betting" && (
        <>
          <div className="rounded-xl bg-white p-2.5 ring-1 ring-slate-900/8">
            <div className="mb-1.5 flex justify-between text-[10.5px] font-bold text-slate-500">
              <span>مبلغ شرط</span>
              <span className="text-slate-900 tabular-nums">{toFa(bet)}</span>
            </div>
            <input
              type="range"
              min={CRASH_MIN}
              max={CRASH_MAX}
              step={50000}
              value={bet}
              onChange={(e) => setBet(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
          </div>

          <div className="text-center text-[10.5px] font-black text-slate-600">
            کدوم تیم می‌بره؟
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              disabled={points < bet || data < 5}
              onClick={() => {
                store.matchBet(bet, "home");
                boop();
              }}
              className="rounded-xl bg-white p-2.5 ring-1 ring-slate-900/8 transition active:scale-95 disabled:opacity-45"
            >
              <div className="text-xl">{m.homeEmoji}</div>
              <div className="text-[10.5px] font-black text-slate-900">{m.home}</div>
              <div className="text-[9px] font-black text-emerald-600">×۲</div>
            </button>
            <button
              type="button"
              disabled={points < bet || data < 5}
              onClick={() => {
                store.matchBet(bet, "away");
                boop();
              }}
              className="rounded-xl bg-white p-2.5 ring-1 ring-slate-900/8 transition active:scale-95 disabled:opacity-45"
            >
              <div className="text-xl">{m.awayEmoji}</div>
              <div className="text-[10.5px] font-black text-slate-900">{m.away}</div>
              <div className="text-[9px] font-black text-emerald-600">×۲</div>
            </button>
          </div>
          {data < 5 && <Note>برای شرط‌بندی آنلاین اینترنت لازمه.</Note>}
        </>
      )}

      {m.state === "live" && (
        <div className="rounded-xl bg-amber-100 px-3 py-2 text-center text-[11px] font-black text-amber-800">
          روی {m.pick === "home" ? m.home : m.away} شرط بستی — {toFa(m.bet)} پوینت
        </div>
      )}

      {m.state === "done" && (
        <>
          <div
            className={`rounded-xl px-3 py-2.5 text-center text-[12px] font-black ${
              m.won ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
            }`}
          >
            {m.won ? `بردی! +${toFa(m.bet * 2)} پوینت` : `باختی — ${toFa(m.bet)} پوینت سوخت`}
          </div>
          <PBtn onClick={() => store.matchNew()}>مسابقه‌ی بعدی</PBtn>
        </>
      )}
    </div>
  );
}

/* ================================================================== */
/*  🌐 BROWSER APPS — real embedded web content                        */
/* ================================================================== */

/**
 * A real <iframe> viewport inside the phone.
 *
 * Some sites refuse to be framed via `X-Frame-Options` / CSP, and that is not
 * detectable cross-origin. Aparat is framed directly; if a browser blocks it a
 * manual escape hatch is always shown underneath.
 */
function WebFrame({ src, title }: { src: string; title: string }) {
  const [loaded, setLoaded] = useState(false);
  const [slow, setSlow] = useState(false);

  useEffect(() => {
    setLoaded(false);
    setSlow(false);
    const id = window.setTimeout(() => setSlow(true), 4000);
    return () => window.clearTimeout(id);
  }, [src]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl bg-black ring-1 ring-slate-900/15">
      <div className="relative aspect-video w-full">
        <iframe
          key={src}
          src={src}
          title={title}
          onLoad={() => setLoaded(true)}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
          className="absolute inset-0 size-full border-0"
        />
        {!loaded && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center bg-slate-900">
            <div className="flex flex-col items-center gap-1.5">
              <span className="text-2xl">{slow ? "📡" : "⏳"}</span>
              <span className="text-[9.5px] font-bold text-slate-300">
                {slow ? "اگه باز نشد، از دکمه‌ی پایین برو" : "در حال بارگذاری…"}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function AparatApp() {
  const data = useStore((s) => s.data);
  const [open, setOpen] = useState(false);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-1.5 rounded-xl bg-slate-200 p-1.5">
        <span className="text-sm">🌐</span>
        <div className="min-w-0 flex-1 truncate rounded-lg bg-white px-2 py-1 text-[9.5px] font-bold text-slate-600" dir="ltr">
          aparat.com/home
        </div>
        {open && (
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              boop();
            }}
            className="shrink-0 rounded-md bg-white px-1.5 py-1 text-[9px] font-black text-slate-600"
          >
            ✕
          </button>
        )}
      </div>

      {open ? (
        <WebFrame src="https://www.aparat.com/home" title="آپارات" />
      ) : (
        <div
          className="flex flex-col items-center gap-2 rounded-2xl p-4 text-center text-white"
          style={{ background: "linear-gradient(160deg,#F87171,#DC2626)" }}
        >
          <span className="text-4xl">🎬</span>
          <div className="text-[13px] font-black">آپارات</div>
          <div className="text-[9.5px] font-bold opacity-85" dir="ltr">
            www.aparat.com/home
          </div>
        </div>
      )}

      {data < 20 && <Note>اینترنتت کمه، ویدیو ممکنه قطع‌قطع بشه.</Note>}

      {!open && (
        <PBtn
          tone="danger"
          disabled={data < 20}
          onClick={() => {
            store.useData(20);
            setOpen(true);
          }}
        >
          🎬 باز کردن سایت داخل گوشی
        </PBtn>
      )}

      <a
        href="https://www.aparat.com/home"
        target="_blank"
        rel="noreferrer noopener"
        onClick={() => boop()}
        className="w-full rounded-xl bg-slate-100 px-3 py-2 text-center text-[11px] font-extrabold text-slate-700 ring-1 ring-slate-900/8 transition active:scale-[0.97]"
      >
        باز کردن در مرورگر ↗
      </a>
    </div>
  );
}
