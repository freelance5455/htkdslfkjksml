import React, { useState } from 'react';
import {
  TrendingUp,
  BarChart2,
  Calendar,
  Filter,
  Flame,
  Award,
} from 'lucide-react';
import type { Season, DailyRecord, Category } from '../types/index.ts';

interface EvolutionChartsProps {
  playerId: string;
  categories: Category[];
  seasons: Season[];
  dailyRecords: DailyRecord[];
}

export const EvolutionCharts: React.FC<EvolutionChartsProps> = ({
  playerId,
  categories,
  seasons,
  dailyRecords,
}) => {
  const activeCategories = categories.filter((c) => c.status === 'active');
  const [selectedCatId, setSelectedCatId] = useState<string>(activeCategories[0]?.id || 'cat-200g');
  const [selectedPeriod, setSelectedPeriod] = useState<'4' | '8' | 'all'>('all');
  const [activeChartTab, setActiveChartTab] = useState<'average' | 'streak' | 'frequency'>('average');

  // Sort seasons chronologically
  const sortedSeasons = [...seasons].sort((a, b) => a.startDate.localeCompare(b.startDate));
  const filteredSeasons =
    selectedPeriod === '4'
      ? sortedSeasons.slice(-4)
      : selectedPeriod === '8'
      ? sortedSeasons.slice(-8)
      : sortedSeasons;

  // Process data points for each season
  const chartData = filteredSeasons.map((season) => {
    // Records of this player for this season & category
    const seasonRecords = dailyRecords.filter(
      (r) =>
        r.playerId === playerId &&
        r.categoryId === selectedCatId &&
        r.localDate >= season.startDate &&
        r.localDate <= season.endDate &&
        r.trained
    );

    const trainedDays = seasonRecords.length;
    const bestStreak = trainedDays > 0 ? Math.max(...seasonRecords.map((r) => r.bestStreak)) : null;

    // Check if official snapshot exists
    let officialAvg: number | null = null;
    if (season.snapshots && season.snapshots[selectedCatId]) {
      const pRes = season.snapshots[selectedCatId].find((r) => r.playerId === playerId);
      if (pRes && pRes.daysTrained >= 1) {
        officialAvg = pRes.rawAverage;
      }
    } else if (trainedDays > 0) {
      const sum = seasonRecords.reduce((acc, r) => acc + r.bestStreak, 0);
      officialAvg = sum / trainedDays;
    }

    return {
      seasonId: season.id,
      seasonName: season.name.replace('Semana ', ''),
      startDate: season.startDate,
      average: officialAvg,
      bestStreak: bestStreak,
      trainedDays: trainedDays,
    };
  });

  // Calculate SVG dimensions
  const svgWidth = 600;
  const svgHeight = 220;
  const paddingX = 45;
  const paddingY = 30;
  const innerWidth = svgWidth - paddingX * 2;
  const innerHeight = svgHeight - paddingY * 2;

  // Max values for scale
  const maxAverage = Math.max(
    10,
    ...chartData.map((d) => (d.average !== null ? d.average : 0))
  );
  const maxStreak = Math.max(
    10,
    ...chartData.map((d) => (d.bestStreak !== null ? d.bestStreak : 0))
  );

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-4">
      {/* Title & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
        <div>
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Gráficos de Evolução Esportiva</span>
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Acompanhe sua consistência, médias semanais e recordes pessoais
          </p>
        </div>

        {/* Filters: Category & Period */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Category dropdown */}
          <select
            value={selectedCatId}
            onChange={(e) => setSelectedCatId(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-neutral-800 border border-neutral-700 rounded-lg text-white font-medium focus:outline-none focus:border-emerald-500"
            aria-label="Filtrar por categoria"
          >
            {activeCategories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name.split(' ')[0]} {c.name.split(' ')[1]} ({c.weightGrams}g)
              </option>
            ))}
          </select>

          {/* Period selector */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
            <button
              onClick={() => setSelectedPeriod('4')}
              className={`px-2 py-1 rounded font-bold transition-colors ${
                selectedPeriod === '4' ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-500 hover:text-white'
              }`}
            >
              4 Sem
            </button>
            <button
              onClick={() => setSelectedPeriod('8')}
              className={`px-2 py-1 rounded font-bold transition-colors ${
                selectedPeriod === '8' ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-500 hover:text-white'
              }`}
            >
              8 Sem
            </button>
            <button
              onClick={() => setSelectedPeriod('all')}
              className={`px-2 py-1 rounded font-bold transition-colors ${
                selectedPeriod === 'all' ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-500 hover:text-white'
              }`}
            >
              Todas
            </button>
          </div>
        </div>
      </div>

      {/* Metric Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setActiveChartTab('average')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border ${
            activeChartTab === 'average'
              ? 'bg-emerald-950/40 border-emerald-500 text-white'
              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          <span>Média Semanal</span>
        </button>
        <button
          onClick={() => setActiveChartTab('streak')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border ${
            activeChartTab === 'streak'
              ? 'bg-amber-950/40 border-amber-500 text-white'
              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>Recorde Diário</span>
        </button>
        <button
          onClick={() => setActiveChartTab('frequency')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border ${
            activeChartTab === 'frequency'
              ? 'bg-blue-950/40 border-blue-500 text-white'
              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Flame className="w-3.5 h-3.5 text-blue-400" />
          <span>Frequência (Dias)</span>
        </button>
      </div>

      {/* SVG Rendering Container */}
      <div className="bg-neutral-950/80 rounded-xl p-4 border border-neutral-800/80 overflow-x-auto">
        {chartData.length === 0 ? (
          <div className="py-12 text-center text-xs text-neutral-500">
            Nenhuma temporada registrada no período selecionado.
          </div>
        ) : (
          <div className="min-w-[480px]">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto overflow-visible select-none"
            >
              {/* Horizontal Grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((pct, idx) => {
                const y = paddingY + innerHeight * (1 - pct);
                let valLabel = '';
                if (activeChartTab === 'average') {
                  valLabel = (maxAverage * pct).toFixed(1);
                } else if (activeChartTab === 'streak') {
                  valLabel = Math.round(maxStreak * pct).toString();
                } else {
                  valLabel = Math.round(7 * pct).toString();
                }

                return (
                  <g key={idx}>
                    <line
                      x1={paddingX}
                      y1={y}
                      x2={svgWidth - paddingX}
                      y2={y}
                      stroke="#262626"
                      strokeDasharray="3 3"
                    />
                    <text
                      x={paddingX - 8}
                      y={y + 3}
                      fill="#737373"
                      fontSize="9"
                      fontFamily="JetBrains Mono"
                      textAnchor="end"
                    >
                      {valLabel}
                    </text>
                  </g>
                );
              })}

              {/* Chart Content based on tab */}
              {activeChartTab === 'average' && (
                <g>
                  {/* Connect points that have data, leave gaps for null */}
                  {chartData.map((d, i) => {
                    if (i === 0 || d.average === null) return null;
                    const prev = chartData[i - 1];
                    if (prev.average === null) return null; // Gap: do not draw line to null week

                    const x1 = paddingX + (i - 1) * (innerWidth / Math.max(1, chartData.length - 1));
                    const y1 = paddingY + innerHeight * (1 - prev.average / maxAverage);
                    const x2 = paddingX + i * (innerWidth / Math.max(1, chartData.length - 1));
                    const y2 = paddingY + innerHeight * (1 - d.average / maxAverage);

                    return (
                      <line
                        key={`line-${i}`}
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}
                        stroke="#10b981"
                        strokeWidth="2.5"
                      />
                    );
                  })}

                  {/* Points and value tags */}
                  {chartData.map((d, i) => {
                    const x =
                      chartData.length === 1
                        ? svgWidth / 2
                        : paddingX + i * (innerWidth / Math.max(1, chartData.length - 1));

                    if (d.average === null) {
                      return (
                        <g key={`point-empty-${i}`}>
                          <circle
                            cx={x}
                            cy={paddingY + innerHeight}
                            r="3"
                            fill="#404040"
                            stroke="#262626"
                          />
                          <text
                            x={x}
                            y={paddingY + innerHeight + 16}
                            fill="#737373"
                            fontSize="9"
                            textAnchor="middle"
                          >
                            Sem dados
                          </text>
                        </g>
                      );
                    }

                    const y = paddingY + innerHeight * (1 - d.average / maxAverage);

                    return (
                      <g key={`point-${i}`}>
                        <circle
                          cx={x}
                          cy={y}
                          r="5"
                          fill="#10b981"
                          stroke="#042f2e"
                          strokeWidth="2"
                        />
                        <text
                          x={x}
                          y={y - 10}
                          fill="#34d399"
                          fontSize="10"
                          fontWeight="bold"
                          fontFamily="JetBrains Mono"
                          textAnchor="middle"
                        >
                          {d.average.toFixed(2).replace('.', ',')}
                        </text>
                      </g>
                    );
                  })}
                </g>
              )}

              {activeChartTab === 'streak' && (
                <g>
                  {chartData.map((d, i) => {
                    if (i === 0 || d.bestStreak === null) return null;
                    const prev = chartData[i - 1];
                    if (prev.bestStreak === null) return null;

                    const x1 = paddingX + (i - 1) * (innerWidth / Math.max(1, chartData.length - 1));
                    const y1 = paddingY + innerHeight * (1 - prev.bestStreak / maxStreak);
                    const x2 = paddingX + i * (innerWidth / Math.max(1, chartData.length - 1));
                    const y2 = paddingY + innerHeight * (1 - d.bestStreak / maxStreak);

                    return (
                      <line
                        key={`sline-${i}`}
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}
                        stroke="#f59e0b"
                        strokeWidth="2.5"
                      />
                    );
                  })}

                  {chartData.map((d, i) => {
                    const x =
                      chartData.length === 1
                        ? svgWidth / 2
                        : paddingX + i * (innerWidth / Math.max(1, chartData.length - 1));

                    if (d.bestStreak === null) return null;
                    const y = paddingY + innerHeight * (1 - d.bestStreak / maxStreak);

                    return (
                      <g key={`spoint-${i}`}>
                        <circle
                          cx={x}
                          cy={y}
                          r="5"
                          fill="#f59e0b"
                          stroke="#451a03"
                          strokeWidth="2"
                        />
                        <text
                          x={x}
                          y={y - 10}
                          fill="#fbbf24"
                          fontSize="10"
                          fontWeight="bold"
                          fontFamily="JetBrains Mono"
                          textAnchor="middle"
                        >
                          {d.bestStreak}
                        </text>
                      </g>
                    );
                  })}
                </g>
              )}

              {activeChartTab === 'frequency' && (
                <g>
                  {chartData.map((d, i) => {
                    const totalSlots = chartData.length;
                    const slotWidth = innerWidth / totalSlots;
                    const barWidth = Math.min(36, slotWidth * 0.6);
                    const x = paddingX + i * slotWidth + (slotWidth - barWidth) / 2;
                    const barHeight = (d.trainedDays / 7) * innerHeight;
                    const y = paddingY + innerHeight - barHeight;

                    return (
                      <g key={`bar-${i}`}>
                        <rect
                          x={x}
                          y={y}
                          width={barWidth}
                          height={barHeight}
                          rx="4"
                          fill={d.trainedDays >= 5 ? '#3b82f6' : d.trainedDays >= 3 ? '#60a5fa' : '#1e3a8a'}
                        />
                        <text
                          x={x + barWidth / 2}
                          y={y - 8}
                          fill="#93c5fd"
                          fontSize="10"
                          fontWeight="bold"
                          fontFamily="JetBrains Mono"
                          textAnchor="middle"
                        >
                          {d.trainedDays}d
                        </text>
                      </g>
                    );
                  })}
                </g>
              )}

              {/* X Axis Labels (Season Names) */}
              {chartData.map((d, i) => {
                const x =
                  chartData.length === 1
                    ? svgWidth / 2
                    : paddingX + i * (innerWidth / Math.max(1, chartData.length - 1));
                return (
                  <text
                    key={`xlabel-${i}`}
                    x={x}
                    y={svgHeight - 6}
                    fill="#a3a3a3"
                    fontSize="9"
                    fontWeight="500"
                    textAnchor="middle"
                  >
                    {d.seasonName}
                  </text>
                );
              })}
            </svg>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-[11px] text-neutral-500 px-1">
        <span>* Semanas sem treino ficam como lacunas sem conexão para não distorcer a consistência.</span>
        <span className="font-mono-numbers">Escala: 0 a {activeChartTab === 'frequency' ? '7 dias' : 'Máximo'}</span>
      </div>
    </div>
  );
};
