import { allSearchablePages } from '../policeContent';
import PoliceIcon from './PoliceIcon';

const Breadcrumb = ({ section }: { section: string }) => {
  const page = allSearchablePages.find((item) => item.id === section);
  return (
    <nav className="breadcrumb" aria-label="Breadcrumb">
      <PoliceIcon name="home" className="h-4 w-4" /><span>Knowledge Base</span><PoliceIcon name="chevron" className="h-3 w-3" />
      <strong>{page?.category ?? 'Reference'}</strong><PoliceIcon name="chevron" className="h-3 w-3" /><span>{page?.title ?? section}</span>
    </nav>
  );
};

export default Breadcrumb;