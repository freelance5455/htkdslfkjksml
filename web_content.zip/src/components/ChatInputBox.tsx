import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import {
  AlertCircle,
  ArrowUp,
  CheckCircle2,
  Code,
  FileSpreadsheet,
  FileText,
  Globe,
  Headphones,
  Image as ImageIcon,
  Layers,
  Mic,
  MicOff,
  Plus,
  Radio,
  Sparkles,
  StopCircle,
  Upload,
  Video,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';

export type VoiceState =
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'INTERRUPTED'
  | 'OFF'
  | 'UNAVAILABLE';

export type VoiceChatSessionState =
  | 'idle'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'interrupted'
  | 'stopped';

export interface ChatAttachmentItem {
  id: string;
  originalName: string;
  fileCategory: string;
  sizeBytes: number;
  extractionStatus?: string;
  isExtracted?: boolean;
  summary?: string;
  isUploading?: boolean;
  error?: string;
}

export interface ChatInputBoxHandle {
  focus: () => void;
  setValue: (value: string) => void;
  appendValue: (chunk: string) => void;
  clear: () => void;
}

interface ChatInputBoxProps {
  onSendMessage: (text: string) => void;
  isExecuting: boolean;
  isListening: boolean;
  isContinuousVoice: boolean;
  voiceState?: VoiceState;
  voiceChatState?: VoiceChatSessionState;
  interimTranscript: string;
  onToggleMic: () => void;
  onToggleContinuous: () => void;
  onToggleVoiceChat?: () => void;
  onUploadFile?: (file: File) => Promise<void>;
  attachedFiles?: ChatAttachmentItem[];
  onRemoveAttachment?: (id: string) => void;
}

function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileIcon(category: string) {
  switch (category?.toLowerCase()) {
    case 'pdf':
      return <FileText className="w-3.5 h-3.5 text-rose-600 shrink-0" />;
    case 'code':
      return <Code className="w-3.5 h-3.5 text-emerald-600 shrink-0" />;
    case 'image':
      return <ImageIcon className="w-3.5 h-3.5 text-purple-600 shrink-0" />;
    case 'document':
      return <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600 shrink-0" />;
    default:
      return <FileText className="w-3.5 h-3.5 text-sky-600 shrink-0" />;
  }
}

export const ChatInputBox = forwardRef<ChatInputBoxHandle, ChatInputBoxProps>(
  (
    {
      onSendMessage,
      isExecuting,
      isListening,
      isContinuousVoice,
      voiceState = 'OFF',
      voiceChatState = 'idle',
      interimTranscript,
      onToggleMic,
      onToggleContinuous,
      onToggleVoiceChat,
      onUploadFile,
      attachedFiles = [],
      onRemoveAttachment,
    },
    ref
  ) => {
    const [localText, setLocalText] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const [uploadError, setUploadError] = useState<string | null>(null);
    const [isPlusMenuOpen, setIsPlusMenuOpen] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const plusMenuRef = useRef<HTMLDivElement>(null);

    // Dismiss Plus menu on outside click
    useEffect(() => {
      const handleClickOutside = (e: MouseEvent) => {
        if (plusMenuRef.current && !plusMenuRef.current.contains(e.target as Node)) {
          setIsPlusMenuOpen(false);
        }
      };
      if (isPlusMenuOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isPlusMenuOpen]);

    const handleTriggerAttachment = (acceptFilter: string = '*/*') => {
      setIsPlusMenuOpen(false);
      if (fileInputRef.current) {
        fileInputRef.current.accept = acceptFilter;
        fileInputRef.current.click();
      }
    };

    const handleSelectCreationOption = (starterPrompt: string) => {
      setIsPlusMenuOpen(false);
      setLocalText((prev) => {
        const next = prev ? `${prev}\n${starterPrompt} ` : `${starterPrompt} `;
        if (textareaRef.current) {
          textareaRef.current.value = next;
          adjustHeight(textareaRef.current);
        }
        return next;
      });
      textareaRef.current?.focus();
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files || files.length === 0 || !onUploadFile) return;
      setIsUploading(true);
      setUploadError(null);
      try {
        for (let i = 0; i < files.length; i++) {
          await onUploadFile(files[i]);
        }
      } catch (err: any) {
        setUploadError(err?.message || 'File upload failed');
        setTimeout(() => setUploadError(null), 5000);
      } finally {
        setIsUploading(false);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };

    useImperativeHandle(ref, () => ({
      focus: () => {
        textareaRef.current?.focus();
      },
      setValue: (val: string) => {
        setLocalText(val);
        if (textareaRef.current) {
          textareaRef.current.value = val;
          adjustHeight(textareaRef.current);
        }
      },
      appendValue: (chunk: string) => {
        setLocalText((prev) => {
          const next = prev ? `${prev} ${chunk}` : chunk;
          if (textareaRef.current) {
            textareaRef.current.value = next;
            adjustHeight(textareaRef.current);
          }
          return next;
        });
      },
      clear: () => {
        setLocalText('');
        if (textareaRef.current) {
          textareaRef.current.value = '';
          textareaRef.current.style.height = '48px';
        }
      },
    }));

    const adjustHeight = (el: HTMLTextAreaElement) => {
      if (!el.value.includes('\n') && el.scrollHeight <= 50) {
        if (el.style.height !== '48px') {
          el.style.height = '48px';
        }
        return;
      }
      el.style.height = 'auto';
      const newHeight = Math.min(el.scrollHeight, 160);
      el.style.height = `${Math.max(48, newHeight)}px`;
    };

    const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setLocalText(e.target.value);
      adjustHeight(e.target);
    };

    const handleSend = useCallback(() => {
      const trimmed = (localText + (interimTranscript ? ` ${interimTranscript}` : '')).trim();
      if (!trimmed || isExecuting) return;

      onSendMessage(trimmed);
      setLocalText('');
      if (textareaRef.current) {
        textareaRef.current.value = '';
        textareaRef.current.style.height = '48px';
      }
      textareaRef.current?.focus();
    }, [localText, interimTranscript, isExecuting, onSendMessage]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      // Respect IME composition (Hindi/Hinglish/virtual keyboard composition)
      if (e.nativeEvent.isComposing || (e as any).isComposing || e.keyCode === 229) {
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    };

    const canSubmit = (localText.trim().length > 0 || interimTranscript.trim().length > 0) && !isExecuting;

    // Determine voice UI styling
    const effectiveVoiceState = isListening
      ? 'LISTENING'
      : isExecuting
      ? 'THINKING'
      : voiceState;

    return (
      <div className="bg-white border-t border-slate-200 shadow-xs">
        {/* Real Attachment Chips / Cards Bar */}
        {(attachedFiles.length > 0 || isUploading || uploadError) && (
          <div className="px-3.5 pt-2.5 pb-2 flex flex-wrap items-center gap-2 border-b border-slate-100 bg-slate-50/70">
            <span className="text-[11px] font-mono text-slate-500 font-semibold uppercase tracking-wider mr-1">
              Attachments ({attachedFiles.length}):
            </span>

            {attachedFiles.map((file) => {
              const isError = file.extractionStatus === 'FAILED' || !!file.error;
              const isParsed = file.extractionStatus === 'EXTRACTED' || file.isExtracted;
              const isOcr = file.extractionStatus === 'OCR_REQUIRED';

              return (
                <div
                  key={file.id}
                  id={`attachment-chip-${file.id}`}
                  className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl border text-xs shadow-2xs transition-all ${
                    isError
                      ? 'bg-rose-50 border-rose-200 text-rose-800'
                      : 'bg-white border-slate-200 hover:border-sky-300 text-slate-800'
                  }`}
                  title={`${file.originalName} (${formatBytes(file.sizeBytes)}) - ${file.summary || file.extractionStatus || 'Ready'}`}
                >
                  {getFileIcon(file.fileCategory)}

                  <div className="flex flex-col min-w-0 max-w-[170px]">
                    <span className="font-medium text-[11px] truncate leading-tight text-slate-800">
                      {file.originalName}
                    </span>
                    <div className="flex items-center gap-1 text-[9px] text-slate-500 font-mono">
                      <span>{formatBytes(file.sizeBytes)}</span>
                      <span>•</span>
                      <span className="uppercase">{file.fileCategory}</span>
                    </div>
                  </div>

                  {/* Status Badge */}
                  {isParsed ? (
                    <span className="px-1.5 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-700 text-[9px] font-mono font-bold flex items-center gap-0.5">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      PARSED
                    </span>
                  ) : isOcr ? (
                    <span className="px-1.5 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-amber-700 text-[9px] font-mono font-bold">
                      OCR REQ
                    </span>
                  ) : isError ? (
                    <span className="px-1.5 py-0.5 rounded-md bg-rose-50 border border-rose-200 text-rose-700 text-[9px] font-mono font-bold flex items-center gap-0.5">
                      <AlertCircle className="w-2.5 h-2.5" />
                      ERROR
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[9px] font-mono">
                      ATTACHED
                    </span>
                  )}

                  {/* Remove Button */}
                  {onRemoveAttachment && (
                    <button
                      type="button"
                      onClick={() => onRemoveAttachment(file.id)}
                      className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors ml-0.5"
                      title="Remove attachment"
                      aria-label={`Remove ${file.originalName}`}
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}

            {/* Uploading progress indicator */}
            {isUploading && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 rounded-xl text-xs font-mono animate-pulse">
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-ping" />
                <span>Uploading & parsing file...</span>
              </div>
            )}

            {/* Upload error notice */}
            {uploadError && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-mono">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                <span>{uploadError}</span>
              </div>
            )}
          </div>
        )}

        {/* Input Form Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 flex items-end gap-2.5 shrink-0"
        >
          {/* Native Hidden File Picker */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
            accept=".pdf,.doc,.docx,.txt,.md,.json,.csv,.tsv,.py,.ts,.tsx,.js,.jsx,.png,.jpg,.jpeg,.webp"
          />

          {/* Prominent Plus Button with Real Attachment / Creation Popover Menu */}
          <div className="relative shrink-0" ref={plusMenuRef}>
            <button
              type="button"
              id="chat-plus-attachment-btn"
              onClick={() => setIsPlusMenuOpen((prev) => !prev)}
              disabled={isUploading || isExecuting}
              className={`min-w-[44px] min-h-[44px] p-2.5 rounded-xl border flex items-center justify-center transition-all shadow-2xs shrink-0 disabled:opacity-40 group cursor-pointer ${
                isPlusMenuOpen
                  ? 'bg-sky-50 border-sky-400 text-sky-700 ring-2 ring-sky-200'
                  : 'border-slate-200 bg-white hover:bg-sky-50 hover:border-sky-300 text-slate-700 hover:text-sky-700'
              }`}
              title="Add attachment or generate (PDF, Document, Code, Image, Website, App)"
              aria-label="Add attachment or create"
              aria-expanded={isPlusMenuOpen}
            >
              <Plus
                className={`w-5 h-5 stroke-[2.2] transition-transform duration-200 ${
                  isPlusMenuOpen ? 'rotate-45 text-sky-600' : 'group-hover:rotate-90'
                }`}
              />
            </button>

            {/* Real Creation & Attachment Popover Menu */}
            {isPlusMenuOpen && (
              <div
                id="plus-action-menu"
                className="absolute bottom-13 left-0 z-50 w-72 bg-white rounded-2xl border border-slate-300/90 shadow-2xl p-2 font-sans text-xs space-y-2 animate-in fade-in slide-in-from-bottom-2 duration-150"
              >
                {/* Section 1: Uploads & Attachments */}
                <div>
                  <div className="px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                    Upload & Attach
                  </div>
                  <div className="space-y-0.5">
                    <button
                      type="button"
                      onClick={() => handleTriggerAttachment('*/*')}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-sky-50 text-sky-600 border border-sky-200">
                        <Upload className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Upload Any File
                        </span>
                        <span className="text-[10px] text-slate-500">
                          All formats supported
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleTriggerAttachment('.pdf,.doc,.docx,.txt,.md')}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Attach Document / PDF
                        </span>
                        <span className="text-[10px] text-slate-500">
                          PDF, Word, Text, Markdown
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleTriggerAttachment('.png,.jpg,.jpeg,.webp')}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600 border border-purple-200">
                        <ImageIcon className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Attach Image
                        </span>
                        <span className="text-[10px] text-slate-500">
                          PNG, JPG, WebP photos
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleTriggerAttachment('.csv,.tsv,.json,.xlsx')}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600 border border-blue-200">
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Spreadsheet / Data
                        </span>
                        <span className="text-[10px] text-slate-500">
                          CSV, TSV, JSON tables
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleTriggerAttachment('.ts,.tsx,.js,.jsx,.py,.json,.html,.css,.zip')}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
                        <Code className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Code / Script
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Python, TS, JS, Zip project
                        </span>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Divider */}
                <div className="border-t border-slate-200/80 my-1" />

                {/* Section 2: Generation Shortcuts */}
                <div>
                  <div className="px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                    Create &amp; Generate
                  </div>
                  <div className="space-y-0.5">
                    <button
                      type="button"
                      onClick={() =>
                        handleSelectCreationOption(
                          'Ek modern, responsive website generate karo:'
                        )
                      }
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-sky-50 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-sky-50 text-sky-600 border border-sky-200">
                        <Globe className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Create Website
                        </span>
                        <span className="text-[10px] text-slate-500">
                          HTML/Tailwind responsive site
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleSelectCreationOption(
                          'Is topic ka downloadable PDF document generate karo:'
                        )
                      }
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-rose-50 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Generate Document / PDF
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Valid PDF-1.4 report or doc
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleSelectCreationOption(
                          'Ek full application scaffold aur logic generate karo:'
                        )
                      }
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-purple-50 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600 border border-purple-200">
                        <Layers className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Create App
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Full-stack or React app
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleSelectCreationOption(
                          'Ek visual architecture diagram generate karo:'
                        )
                      }
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-pink-50 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-pink-50 text-pink-600 border border-pink-200">
                        <ImageIcon className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Generate Image
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Visual asset, SVG, or graphic
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleSelectCreationOption(
                          'Ek video storyboard aur generation plan bana do:'
                        )
                      }
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-amber-50 text-slate-800 transition-colors group cursor-pointer"
                    >
                      <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600 border border-amber-200">
                        <Video className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-semibold block text-[11px] leading-tight text-slate-900">
                          Generate Video
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Orchestrate video storyboard
                        </span>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Voice Mode Toggle & Push-to-Talk / Continuous Mic */}
          <div className="flex flex-col items-center gap-1 shrink-0">
            <button
              type="button"
              id="voice-mic-input-btn"
              onClick={onToggleMic}
              aria-label={isListening ? 'Stop microphone' : 'Start microphone'}
              title={
                isListening
                  ? 'Listening active. Click to pause microphone.'
                  : isContinuousVoice
                  ? 'Continuous Voice Session (listening through natural pauses)'
                  : 'Push-to-Talk voice recognition'
              }
              className={`min-w-[44px] min-h-[44px] p-2.5 rounded-xl border flex items-center justify-center transition-all shadow-2xs relative cursor-pointer ${
                isListening
                  ? 'bg-rose-50 border-rose-400 text-rose-700 animate-pulse ring-2 ring-rose-200'
                  : 'bg-white border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {isListening ? (
                <Mic className="w-4 h-4 text-rose-600 animate-bounce" />
              ) : (
                <MicOff className="w-4 h-4 text-slate-500" />
              )}
              {isListening && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
              )}
            </button>
            <button
              type="button"
              onClick={onToggleContinuous}
              className={`text-[9px] font-mono px-1.5 py-0.5 rounded transition-colors font-bold ${
                isContinuousVoice
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'text-slate-400 hover:text-slate-600 bg-slate-100'
              }`}
              title="Toggle between single phrase dictation and continuous voice stream"
            >
              {isContinuousVoice ? 'CONT' : 'PUSH'}
            </button>
          </div>

          {/* Real-time Unhindered Textarea */}
          <div className="relative flex-1">
            {isListening && (
              <div className="absolute top-2 right-3 flex items-center gap-0.5 z-10">
                <span className="w-1 h-3.5 bg-rose-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1 h-4.5 bg-rose-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1 h-2.5 bg-rose-400 rounded-full animate-bounce" />
              </div>
            )}
            <textarea
              ref={textareaRef}
              id="jarvis-prompt-input"
              rows={1}
              value={localText}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder={
                isListening
                  ? 'Listening to your voice stream... (Enter sends, Shift+Enter for newline)'
                  : 'Ask JARVIS 5.1 (Enter sends, Shift+Enter for newline)...'
              }
              disabled={isExecuting}
              autoComplete="off"
              autoCorrect="off"
              spellCheck="false"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 text-base sm:text-sm focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100 transition-all font-sans resize-none leading-relaxed block max-h-40 min-h-[48px]"
            />
            {interimTranscript && (
              <div className="absolute left-3 bottom-2 flex items-center gap-2 text-xs bg-sky-50/98 px-2.5 py-1 rounded-lg border border-sky-300 shadow-xs z-10 max-w-[calc(100%-16px)]">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping shrink-0" />
                <span className="text-sky-900 font-medium truncate italic text-[11px]">
                  &quot;{interimTranscript}&quot;
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setLocalText((prev) => (prev ? `${prev} ${interimTranscript}` : interimTranscript));
                  }}
                  className="px-1.5 py-0.5 rounded bg-sky-100 hover:bg-sky-200 text-sky-800 font-mono text-[9px] font-bold cursor-pointer transition-colors shrink-0"
                  title="Insert recognized speech into text area"
                >
                  Insert
                </button>
              </div>
            )}
          </div>

          {/* SEPARATE DEDICATED VOICE CHAT BUTTON (Visually Distinct from Dictation Mic) */}
          <button
            type="button"
            id="separate-voice-chat-btn"
            onClick={onToggleVoiceChat}
            aria-label={`Voice Chat: ${voiceChatState}`}
            title={
              voiceChatState === 'speaking'
                ? 'Speaking - Click to Interrupt'
                : voiceChatState === 'listening'
                ? 'Listening - Click to Stop'
                : voiceChatState === 'processing'
                ? 'Thinking...'
                : voiceChatState === 'interrupted'
                ? 'Voice Interrupted'
                : voiceChatState === 'stopped'
                ? 'Voice Stopped - Click to Start'
                : 'Start Voice Chat session'
            }
            className={`min-h-[44px] px-3 py-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all shadow-2xs font-mono text-xs cursor-pointer shrink-0 ${
              voiceChatState === 'listening'
                ? 'bg-rose-50 border-rose-400 text-rose-700 ring-2 ring-rose-200 animate-pulse font-bold'
                : voiceChatState === 'speaking'
                ? 'bg-sky-50 border-sky-400 text-sky-800 ring-2 ring-sky-200 animate-pulse font-bold'
                : voiceChatState === 'processing'
                ? 'bg-amber-50 border-amber-300 text-amber-800 animate-pulse font-medium'
                : voiceChatState === 'interrupted'
                ? 'bg-orange-50 border-orange-300 text-orange-800 font-bold'
                : voiceChatState === 'stopped'
                ? 'bg-slate-100 border-slate-300 text-slate-600 font-medium'
                : 'bg-gradient-to-r from-indigo-50 to-sky-50 hover:from-indigo-100 hover:to-sky-100 border-indigo-200 text-indigo-900 font-semibold'
            }`}
          >
            {voiceChatState === 'listening' ? (
              <>
                <Radio className="w-4 h-4 text-rose-600 animate-spin" />
                <span className="hidden sm:inline">Listening</span>
              </>
            ) : voiceChatState === 'speaking' ? (
              <>
                <Volume2 className="w-4 h-4 text-sky-600 animate-bounce" />
                <span className="hidden sm:inline">Speaking</span>
                <span className="text-[10px] px-1 py-0.2 rounded bg-sky-200 text-sky-900 font-bold">Stop</span>
              </>
            ) : voiceChatState === 'processing' ? (
              <>
                <Radio className="w-4 h-4 text-amber-600 animate-pulse" />
                <span className="hidden sm:inline">Thinking</span>
              </>
            ) : voiceChatState === 'interrupted' ? (
              <>
                <VolumeX className="w-4 h-4 text-orange-600" />
                <span className="hidden sm:inline">Interrupted</span>
              </>
            ) : voiceChatState === 'stopped' ? (
              <>
                <StopCircle className="w-4 h-4 text-slate-500" />
                <span className="hidden sm:inline">Stopped</span>
              </>
            ) : (
              <>
                <Headphones className="w-4 h-4 text-indigo-600" />
                <span className="hidden sm:inline">Voice Chat</span>
              </>
            )}
          </button>

          {/* Submit Execution Action Button */}
          <button
            id="jarvis-send-prompt-btn"
            type="submit"
            disabled={!canSubmit}
            className="min-w-[44px] min-h-[44px] px-4 py-3 rounded-xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs shrink-0 cursor-pointer"
            title="Execute prompt (Enter)"
            aria-label="Send message"
          >
            <span className="hidden sm:inline tracking-wider font-mono">EXECUTE</span>
            <ArrowUp className="w-4 h-4 stroke-[2.5]" />
          </button>
        </form>
      </div>
    );
  }
);

ChatInputBox.displayName = 'ChatInputBox';
