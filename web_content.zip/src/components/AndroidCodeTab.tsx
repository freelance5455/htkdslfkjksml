import React, { useState } from 'react';
import {
  Download,
  Folder,
  FileCode,
  Copy,
  Check,
  Smartphone,
  Terminal,
  ShieldCheck,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES, AndroidProjectFile } from '../data/androidProjectFiles';

interface AndroidCodeTabProps {
  onOpenAPKModal?: () => void;
}

export const AndroidCodeTab: React.FC<AndroidCodeTabProps> = ({ onOpenAPKModal }) => {
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_PROJECT_FILES[4]); // AndroidManifest.xml
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add each file to the zip maintaining relative paths
      ANDROID_PROJECT_FILES.forEach((f) => {
        zip.file(f.path, f.content);
      });

      // Generate zip blob
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'dost-ai-android-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('ZIP generation failed:', err);
      alert('Failed to generate ZIP archive.');
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      {/* Header & ZIP Download Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div>
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">Native Android Studio Project</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            100% production-ready Kotlin + Jetpack Compose source code & Gradle build files.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>{isZipping ? 'Packaging ZIP...' : 'Download Project (.ZIP)'}</span>
        </button>
      </div>

      {/* Direct Mobile APK & PWA Banner */}
      <div className="flex items-center justify-between p-3.5 bg-gradient-to-r from-cyan-950/60 to-slate-900 border border-cyan-500/40 rounded-2xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-sm font-bold">
            📱
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Direct Phone Install (WebAPK & PWA)</h4>
            <p className="text-[11px] text-slate-300">
              Android phone par bina Android Studio ke seedha install karein.
            </p>
          </div>
        </div>
        <button
          onClick={onOpenAPKModal}
          className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Install APK</span>
        </button>
      </div>

      {/* Explorer: File list + Code view */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Left: File Tree */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2 max-h-[500px] overflow-y-auto">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1 flex items-center gap-1.5">
            <Folder className="w-3.5 h-3.5 text-cyan-400" />
            <span>Project Explorer</span>
          </div>

          <div className="space-y-1">
            {ANDROID_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-2 transition-colors ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                  <span className="truncate">{file.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer */}
        <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-xs font-mono font-bold text-cyan-300 block">{selectedFile.path}</span>
              <span className="text-[11px] text-slate-400">{selectedFile.description}</span>
            </div>
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-colors"
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <pre className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-[400px] leading-relaxed selection:bg-cyan-500/30">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>

      {/* Android Studio Step-By-Step Setup Guide */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-cyan-400" />
          <span>How to Run in Android Studio</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
            <span className="text-cyan-400 font-bold block">1. Extract & Open</span>
            <p className="text-slate-400 leading-relaxed">
              Extract the downloaded zip, open Android Studio, and select <strong>File &gt; Open</strong> on the folder.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
            <span className="text-cyan-400 font-bold block">2. Configure API Key</span>
            <p className="text-slate-400 leading-relaxed">
              Add your Gemini key in <code className="text-cyan-300">local.properties</code>:
              <br />
              <code className="text-[10px] text-slate-300">GEMINI_API_KEY=AIzaSy...</code>
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
            <span className="text-cyan-400 font-bold block">3. Build APK</span>
            <p className="text-slate-400 leading-relaxed">
              Select <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> or press <strong>Run (Shift+F10)</strong> on physical device.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
