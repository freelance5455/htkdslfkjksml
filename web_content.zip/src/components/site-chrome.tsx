import { Link, useRouterState } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { cn } from "@/lib/cn";
import { usePublicProfile } from "@/lib/vitrine-context";

export function SiteHeader() {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const profile = usePublicProfile();
  const place = profile.ready && profile.city ? profile.city : "sua região";

  return (
    <header className="no-print sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="flex min-h-11 items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-fg">
            <Check className="size-5" strokeWidth={2.5} />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-xl font-semibold italic">Precisa</span>
            <span className="block text-xs text-muted">em {place}</span>
          </span>
        </Link>
        <nav className="flex items-center gap-2">
          <Link
            to="/negocio"
            className={cn(
              "inline-flex min-h-11 items-center rounded-md px-3 text-sm font-semibold",
              path.startsWith("/negocio") ? "bg-surface-2" : "hover:bg-surface-2",
            )}
          >
            Caixa
          </Link>
          <Link
            to="/agendar"
            className="inline-flex min-h-11 items-center rounded-md bg-primary px-3 text-sm font-semibold text-primary-fg hover:bg-primary-deep"
          >
            Agendar
          </Link>
        </nav>
      </div>
      {profile.fromLink ? (
        <div className="border-t border-line bg-surface">
          <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-2 text-sm">
            <p>
              Vitrine de{" "}
              <span className="font-semibold">{profile.receiverName || "um profissional"}</span>
              {profile.city ? ` · ${profile.city}` : ""}
            </p>
            <button type="button" className="font-semibold text-primary" onClick={profile.clearRemote}>
              Sair desta vitrine
            </button>
          </div>
        </div>
      ) : null}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="no-print mt-16 border-t border-line">
      <div className="mx-auto grid max-w-5xl gap-6 px-4 py-10 sm:grid-cols-2">
        <div>
          <p className="font-display text-2xl italic">Precisa</p>
          <p className="mt-2 max-w-sm text-sm text-muted">
            Preço escrito antes. PIX direto para quem faz o serviço. O site não fica com o dinheiro no meio.
          </p>
        </div>
        <div className="flex flex-col gap-2 text-sm sm:items-end">
          <Link to="/agendar" className="min-h-11 font-semibold">
            Agendar um serviço
          </Link>
          <Link to="/negocio" className="min-h-11 text-muted">
            Área de quem faz o serviço
          </Link>
        </div>
      </div>
    </footer>
  );
}
