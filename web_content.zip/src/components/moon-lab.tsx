import { useEffect, useRef, useState } from "react";
import { drawMoonDisk } from "@/lib/moon-draw";
import { useVespera } from "@/lib/store";

function phaseName(elong: number): string {
  const e = ((elong % 360) + 360) % 360;
  if (e < 22 || e > 338) return "New moon";
  if (e < 68) return "Waxing crescent";
  if (e < 112) return "First quarter";
  if (e < 158) return "Waxing gibbous";
  if (e < 202) return "Full moon";
  if (e < 248) return "Waning gibbous";
  if (e < 292) return "Last quarter";
  return "Waning crescent";
}

function whenToLook(elong: number): string {
  const e = ((elong % 360) + 360) % 360;
  if (e < 22 || e > 338) return "Up in the daytime, next to the Sun. You will not see it.";
  if (e < 68) return "West, shortly after sunset. Sets early.";
  if (e < 112) return "High at sunset, gone by midnight.";
  if (e < 158) return "Rises in the afternoon. Most of the night is lit.";
  if (e < 202) return "Rises at sunset, opposite the Sun. Up all night.";
  if (e < 248) return "Rises after sunset and is still up at dawn.";
  if (e < 292) return "Rises around midnight. High at dawn.";
  return "East, in the hour before sunrise.";
}

export function MoonLab() {
  const lat = useVespera((s) => s.lat);
  const [elong, setElong] = useState(90);
  const orbitRef = useRef<HTMLDivElement>(null);
  const diskRef = useRef<HTMLCanvasElement>(null);
  const dragging = useRef(false);

  const fraction = (1 - Math.cos((elong * Math.PI) / 180)) / 2;
  const southern = lat < 0;

  useEffect(() => {
    const canvas = diskRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const size = 160;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size, size);
    drawMoonDisk(ctx, size / 2, size / 2, 70, elong, southern);
  }, [elong, southern]);

  function setFromPointer(clientX: number, clientY: number) {
    const el = orbitRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const dx = clientX - (r.left + r.width / 2);
    const dy = clientY - (r.top + r.height / 2);
    let deg = (Math.atan2(-dy, dx) * 180) / Math.PI;
    if (deg < 0) deg += 360;
    setElong(deg);
  }

  return (
    <figure className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
      <figcaption className="text-xs uppercase tracking-widest text-gold">Drag the Moon around Earth</figcaption>
      <div className="mt-4 grid items-center gap-6 md:grid-cols-[minmax(0,280px)_1fr]">
        <div
          ref={orbitRef}
          className="relative mx-auto aspect-square w-full max-w-[280px] touch-none select-none"
          onPointerDown={(e) => {
            dragging.current = true;
            e.currentTarget.setPointerCapture(e.pointerId);
            setFromPointer(e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (!dragging.current) return;
            setFromPointer(e.clientX, e.clientY);
          }}
          onPointerUp={() => {
            dragging.current = false;
          }}
          role="slider"
          aria-valuemin={0}
          aria-valuemax={360}
          aria-valuenow={Math.round(elong)}
          aria-label="Moon position around Earth"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "ArrowRight" || e.key === "ArrowUp") setElong((v) => (v + 8) % 360);
            if (e.key === "ArrowLeft" || e.key === "ArrowDown") setElong((v) => (v + 352) % 360);
          }}
        >
          <svg viewBox="0 0 200 200" className="h-full w-full">
            <circle cx="100" cy="100" r="78" fill="none" stroke="#2c3a48" />
            <g stroke="#e2b15a" strokeOpacity="0.7">
              <line x1="168" y1="100" x2="196" y2="100" />
              <line x1="188" y1="94" x2="196" y2="100" />
              <line x1="188" y1="106" x2="196" y2="100" />
            </g>
            <text x="188" y="88" fill="#e2b15a" fontSize="10">
              Sun
            </text>
            <circle cx="100" cy="100" r="10" fill="#3d6b8a" />
            <text x="100" y="128" textAnchor="middle" fill="#7d8b9c" fontSize="10">
              Earth
            </text>
            {(() => {
              const a = (elong * Math.PI) / 180;
              const mx = 100 + Math.cos(a) * 78;
              const my = 100 - Math.sin(a) * 78;
              return <circle cx={mx} cy={my} r="7" fill="#f4ead2" />;
            })()}
          </svg>
        </div>
        <div>
          <p className="font-display text-3xl text-fg">{phaseName(elong)}</p>
          <p className="mt-1 text-sm text-muted tabular-nums">{Math.round(fraction * 100)}% of the disk lit</p>
          <p className="mt-3 text-sm text-fg">{whenToLook(elong)}</p>
          <p className="mt-3 text-sm text-faint">
            {southern
              ? "Southern latitude is set, so the bright side is mirrored — waxing moons are lit on the left."
              : "Northern view: a waxing moon is bright on the right. Set a southern latitude and this flips."}
          </p>
          <div className="mt-4 flex items-center gap-4">
            <canvas ref={diskRef} className="shrink-0" />
          </div>
        </div>
      </div>
    </figure>
  );
}
