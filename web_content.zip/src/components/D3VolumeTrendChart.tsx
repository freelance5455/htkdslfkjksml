import React, { useMemo, useState, useRef } from 'react';
import * as d3 from 'd3';
import { TrendingUp, Calendar, Activity, Flame } from 'lucide-react';
import { Workout } from '../types';
import { playPopSound } from '../utils/audio';

export type VolumeTimeframe = '7d' | '30d' | '3m' | '1y';

interface D3VolumeTrendChartProps {
  workoutHistory: Workout[];
  unitLabel: 'kg' | 'lbs';
  timeframe: VolumeTimeframe;
  onTimeframeChange: (tf: VolumeTimeframe) => void;
  soundEnabled?: boolean;
}

interface VolumeDataPoint {
  date: Date;
  label: string;
  fullLabel: string;
  volume: number;
  loadedVolume: number;
  reps: number;
  sets: number;
  workouts: number;
  trendAvg: number;
}

const TIMEFRAME_OPTIONS: { id: VolumeTimeframe; label: string; shortLabel: string; days: number }[] = [
  { id: '7d', label: 'Last 7 Days', shortLabel: '7D', days: 7 },
  { id: '30d', label: 'Last 30 Days', shortLabel: '30D', days: 30 },
  { id: '3m', label: 'Last 3 Months', shortLabel: '3M', days: 90 },
  { id: '1y', label: 'Last 12 Months', shortLabel: '1Y', days: 365 }
];

function computeWorkoutVolume(w: Workout): {
  volume: number;
  loadedVolume: number;
  reps: number;
  sets: number;
} {
  let volume = 0;
  let loadedVolume = 0;
  let reps = 0;
  let sets = 0;

  w.exercises.forEach((ex) => {
    ex.sets.forEach((s) => {
      const effectiveReps =
        s.reps && s.reps > 0
          ? s.reps
          : s.durationSec && s.durationSec > 0
          ? Math.max(1, Math.round(s.durationSec / 5))
          : 0;
      const weightVal = s.weightKg && s.weightKg > 0 ? s.weightKg : 0;

      if (effectiveReps > 0) {
        reps += effectiveReps;
        sets += 1;
        const setVol = weightVal > 0 ? effectiveReps * weightVal : effectiveReps;
        volume += setVol;
        loadedVolume += effectiveReps * weightVal;
      }
    });
  });

  // Fallback if sets weren't itemized
  if (volume === 0 && w.totalReps > 0) {
    volume = w.totalReps;
    reps = w.totalReps;
    sets = w.totalSets || 1;
  }

  return {
    volume: Math.round(volume),
    loadedVolume: Math.round(loadedVolume),
    reps,
    sets
  };
}

export const D3VolumeTrendChart: React.FC<D3VolumeTrendChartProps> = ({
  workoutHistory,
  unitLabel,
  timeframe,
  onTimeframeChange,
  soundEnabled = true
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Build time-series buckets according to selected timeframe
  const dataPoints = useMemo<VolumeDataPoint[]>(() => {
    const now = new Date();
    now.setHours(23, 59, 59, 999);

    const rawPoints: Omit<VolumeDataPoint, 'trendAvg'>[] = [];

    if (timeframe === '7d' || timeframe === '30d') {
      const numDays = timeframe === '7d' ? 7 : 30;
      const dayFmt = d3.timeFormat(timeframe === '7d' ? '%a' : '%b %d');
      const fullFmt = d3.timeFormat('%a, %b %d');

      for (let i = numDays - 1; i >= 0; i--) {
        const start = new Date(now);
        start.setHours(0, 0, 0, 0);
        start.setDate(start.getDate() - i);

        const end = new Date(start);
        end.setDate(end.getDate() + 1);

        const matching = workoutHistory.filter((w) => {
          const t = new Date(w.date).getTime();
          return t >= start.getTime() && t < end.getTime();
        });

        let vol = 0;
        let loaded = 0;
        let reps = 0;
        let sets = 0;

        matching.forEach((w) => {
          const stats = computeWorkoutVolume(w);
          vol += stats.volume;
          loaded += stats.loadedVolume;
          reps += stats.reps;
          sets += stats.sets;
        });

        rawPoints.push({
          date: start,
          label: dayFmt(start),
          fullLabel: fullFmt(start),
          volume: vol,
          loadedVolume: loaded,
          reps,
          sets,
          workouts: matching.length
        });
      }
    } else if (timeframe === '3m') {
      // 12 weekly buckets covering the last ~3 months (84 days)
      const numWeeks = 12;
      const shortFmt = d3.timeFormat('%b %d');

      for (let wIdx = numWeeks - 1; wIdx >= 0; wIdx--) {
        const end = new Date(now);
        end.setHours(23, 59, 59, 999);
        end.setDate(end.getDate() - wIdx * 7);

        const start = new Date(end);
        start.setHours(0, 0, 0, 0);
        start.setDate(start.getDate() - 6);

        const matching = workoutHistory.filter((w) => {
          const t = new Date(w.date).getTime();
          return t >= start.getTime() && t <= end.getTime();
        });

        let vol = 0;
        let loaded = 0;
        let reps = 0;
        let sets = 0;

        matching.forEach((w) => {
          const stats = computeWorkoutVolume(w);
          vol += stats.volume;
          loaded += stats.loadedVolume;
          reps += stats.reps;
          sets += stats.sets;
        });

        rawPoints.push({
          date: start,
          label: shortFmt(start),
          fullLabel: `Week of ${shortFmt(start)} – ${shortFmt(end)}`,
          volume: vol,
          loadedVolume: loaded,
          reps,
          sets,
          workouts: matching.length
        });
      }
    } else {
      // '1y' -> 12 monthly buckets
      const monthFmt = d3.timeFormat('%b');
      const fullMonthFmt = d3.timeFormat('%B %Y');

      for (let mIdx = 11; mIdx >= 0; mIdx--) {
        const start = new Date(now.getFullYear(), now.getMonth() - mIdx, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth() - mIdx + 1, 0, 23, 59, 59, 999);

        const matching = workoutHistory.filter((w) => {
          const t = new Date(w.date).getTime();
          return t >= start.getTime() && t <= end.getTime();
        });

        let vol = 0;
        let loaded = 0;
        let reps = 0;
        let sets = 0;

        matching.forEach((w) => {
          const stats = computeWorkoutVolume(w);
          vol += stats.volume;
          loaded += stats.loadedVolume;
          reps += stats.reps;
          sets += stats.sets;
        });

        rawPoints.push({
          date: start,
          label: monthFmt(start),
          fullLabel: fullMonthFmt(start),
          volume: vol,
          loadedVolume: loaded,
          reps,
          sets,
          workouts: matching.length
        });
      }
    }

    // Compute 3-point rolling strength trend average using d3.mean
    return rawPoints.map((pt, idx, arr) => {
      const windowSlice = arr.slice(Math.max(0, idx - 2), idx + 1);
      const avg = d3.mean(windowSlice, (d) => d.volume) ?? 0;
      return {
        ...pt,
        trendAvg: Math.round(avg)
      };
    });
  }, [workoutHistory, timeframe]);

  // Summary metrics for the selected timeframe
  const totalPeriodVolume = useMemo(
    () => d3.sum(dataPoints, (d) => d.volume),
    [dataPoints]
  );
  const peakVolumePoint = useMemo(() => {
    if (dataPoints.length === 0) return null;
    return dataPoints.reduce((best, cur) => (cur.volume > best.volume ? cur : best), dataPoints[0]);
  }, [dataPoints]);
  const activeBucketsCount = useMemo(
    () => dataPoints.filter((d) => d.volume > 0).length,
    [dataPoints]
  );

  // Calculate strength trend change (second half of timeframe vs first half)
  const strengthTrendDeltaPercent = useMemo(() => {
    if (dataPoints.length < 2) return 0;
    const mid = Math.floor(dataPoints.length / 2);
    const firstHalfAvg = d3.mean(dataPoints.slice(0, mid), (d) => d.volume) || 0;
    const secondHalfAvg = d3.mean(dataPoints.slice(mid), (d) => d.volume) || 0;
    if (firstHalfAvg === 0) return secondHalfAvg > 0 ? 100 : 0;
    return Math.round(((secondHalfAvg - firstHalfAvg) / firstHalfAvg) * 100);
  }, [dataPoints]);

  // SVG coordinate system dimensions
  const width = 560;
  const height = 230;
  const margin = { top: 20, right: 18, bottom: 32, left: 44 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  // D3 Scales & Path Generators
  const { xScale, yScale, linePath, areaPath, trendLinePath, yTicks, xTickIndices } = useMemo(() => {
    const x = d3
      .scaleLinear()
      .domain([0, Math.max(1, dataPoints.length - 1)])
      .range([0, innerWidth]);

    const maxVol = d3.max(dataPoints, (d) => Math.max(d.volume, d.trendAvg)) || 0;
    const yMax = maxVol > 0 ? Math.ceil(maxVol * 1.18) : 100;

    const y = d3.scaleLinear().domain([0, yMax]).nice(4).range([innerHeight, 0]);

    const lineGen = d3
      .line<VolumeDataPoint>()
      .x((_, i) => x(i))
      .y((d) => y(d.volume))
      .curve(d3.curveMonotoneX);

    const areaGen = d3
      .area<VolumeDataPoint>()
      .x((_, i) => x(i))
      .y0(innerHeight)
      .y1((d) => y(d.volume))
      .curve(d3.curveMonotoneX);

    const trendGen = d3
      .line<VolumeDataPoint>()
      .x((_, i) => x(i))
      .y((d) => y(d.trendAvg))
      .curve(d3.curveMonotoneX);

    // Choose 5–7 evenly spaced X axis label indices so labels never overlap
    const count = dataPoints.length;
    const step = count <= 7 ? 1 : count <= 12 ? 2 : 5;
    const indices: number[] = [];
    for (let i = 0; i < count; i += step) {
      indices.push(i);
    }
    if (count > 1 && indices[indices.length - 1] !== count - 1) {
      indices.push(count - 1);
    }

    return {
      xScale: x,
      yScale: y,
      linePath: lineGen(dataPoints) || '',
      areaPath: areaGen(dataPoints) || '',
      trendLinePath: trendGen(dataPoints) || '',
      yTicks: y.ticks(4),
      xTickIndices: indices
    };
  }, [dataPoints, innerWidth, innerHeight]);

  // Interactive pointer / touch scrubbing on the D3 SVG
  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!svgRef.current || dataPoints.length === 0) return;
    const rect = svgRef.current.getBoundingClientRect();
    const relX = ((e.clientX - rect.left) / rect.width) * width - margin.left;
    const rawIdx = Math.round(xScale.invert(relX));
    const boundedIdx = Math.max(0, Math.min(dataPoints.length - 1, rawIdx));
    setHoveredIndex(boundedIdx);
  };

  const activePoint =
    hoveredIndex !== null && dataPoints[hoveredIndex]
      ? dataPoints[hoveredIndex]
      : dataPoints[dataPoints.length - 1] || null;

  const currentTfMeta =
    TIMEFRAME_OPTIONS.find((t) => t.id === timeframe) || TIMEFRAME_OPTIONS[1];

  return (
    <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3.5 shadow-sm">
      {/* Header & Timeframe Selector Pills */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div>
          <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            <span>D3 Strength & Volume Trend Engine</span>
          </span>
          <h3 className="text-sm font-bold text-white mt-0.5">
            Total Volume Over Time ({currentTfMeta.label})
          </h3>
          <p className="text-[11px] text-slate-400">
            Interactive D3 curve tracking cumulative workload ({unitLabel}·reps) & rolling strength trend
          </p>
        </div>

        {/* Timeframe Selector Buttons */}
        <div className="flex items-center gap-1 bg-neutral-900/90 border border-neutral-800 rounded-xl p-1 self-start sm:self-auto">
          {TIMEFRAME_OPTIONS.map((opt) => {
            const active = timeframe === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  if (soundEnabled) playPopSound('soft');
                  setHoveredIndex(null);
                  onTimeframeChange(opt.id);
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                  active
                    ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title={opt.label}
              >
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* KPI Strip + Interactive Scrubbing Readout */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800/90">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Activity className="w-3 h-3 text-cyan-400" />
            <span>{currentTfMeta.shortLabel} Total Volume</span>
          </div>
          <div className="text-base font-extrabold text-white font-mono mt-0.5">
            {totalPeriodVolume.toLocaleString()}{' '}
            <span className="text-[10px] font-sans font-semibold text-cyan-400">vol</span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800/90">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Flame className="w-3 h-3 text-amber-400" />
            <span>Peak {timeframe === '3m' ? 'Week' : timeframe === '1y' ? 'Month' : 'Day'}</span>
          </div>
          <div className="text-base font-extrabold text-white font-mono mt-0.5">
            {(peakVolumePoint?.volume || 0).toLocaleString()}{' '}
            <span className="text-[10px] font-sans font-normal text-slate-400">
              {peakVolumePoint && peakVolumePoint.volume > 0 ? `(${peakVolumePoint.label})` : ''}
            </span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800/90">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-cyan-400" />
            <span>Strength Trend</span>
          </div>
          <div
            className={`text-base font-extrabold font-mono mt-0.5 ${
              strengthTrendDeltaPercent >= 0 ? 'text-cyan-400' : 'text-amber-400'
            }`}
          >
            {strengthTrendDeltaPercent >= 0 ? `+${strengthTrendDeltaPercent}%` : `${strengthTrendDeltaPercent}%`}
            <span className="text-[10px] font-sans font-normal text-slate-400 ml-1">
              ({activeBucketsCount} active)
            </span>
          </div>
        </div>
      </div>

      {/* Interactive D3 SVG Canvas */}
      <div className="relative select-none pt-1">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-56 overflow-visible touch-pan-y cursor-crosshair"
          onPointerMove={handlePointerMove}
          onPointerDown={handlePointerMove}
          onPointerLeave={() => setHoveredIndex(null)}
        >
          <defs>
            <linearGradient id="d3VolumeAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.38" />
              <stop offset="65%" stopColor="#0891b2" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#0891b2" stopOpacity="0.0" />
            </linearGradient>
            <filter id="d3CyanGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g transform={`translate(${margin.left},${margin.top})`}>
            {/* Horizontal Y-Axis Gridlines & Labels */}
            {yTicks.map((tickVal) => {
              const yPos = yScale(tickVal);
              return (
                <g key={tickVal} transform={`translate(0,${yPos})`}>
                  <line
                    x1={0}
                    x2={innerWidth}
                    stroke="#1e293b"
                    strokeDasharray="3 3"
                    strokeWidth={1}
                  />
                  <text
                    x={-8}
                    y={3.5}
                    textAnchor="end"
                    className="fill-slate-500 text-[10px] font-mono"
                  >
                    {tickVal >= 1000 ? `${(tickVal / 1000).toFixed(1)}k` : tickVal}
                  </text>
                </g>
              );
            })}

            {/* D3 Area Under Curve */}
            <path d={areaPath} fill="url(#d3VolumeAreaGrad)" />

            {/* 3-Point Rolling Average Trendline (Dashed Amber/Sky Line) */}
            <path
              d={trendLinePath}
              fill="none"
              stroke="#fbbf24"
              strokeWidth={1.75}
              strokeDasharray="4 4"
              opacity={0.75}
            />

            {/* Primary D3 Monotone Volume Line */}
            <path
              d={linePath}
              fill="none"
              stroke="#22d3ee"
              strokeWidth={2.75}
              strokeLinecap="round"
              filter="url(#d3CyanGlow)"
            />

            {/* Interactive Vertical Crosshair Guide */}
            {hoveredIndex !== null && dataPoints[hoveredIndex] && (
              <line
                x1={xScale(hoveredIndex)}
                x2={xScale(hoveredIndex)}
                y1={0}
                y2={innerHeight}
                stroke="#22d3ee"
                strokeWidth={1.2}
                strokeDasharray="2 2"
                opacity={0.75}
              />
            )}

            {/* Data Nodes */}
            {dataPoints.map((pt, idx) => {
              const cx = xScale(idx);
              const cy = yScale(pt.volume);
              const isHovered = hoveredIndex === idx;
              const showDot =
                dataPoints.length <= 14 || pt.volume > 0 || isHovered || idx === dataPoints.length - 1;

              if (!showDot) return null;

              return (
                <g key={`${pt.label}-${idx}`}>
                  {isHovered && (
                    <circle
                      cx={cx}
                      cy={cy}
                      r={8}
                      fill="#22d3ee"
                      fillOpacity={0.22}
                    />
                  )}
                  <circle
                    cx={cx}
                    cy={cy}
                    r={isHovered ? 5 : pt.volume > 0 ? 3.5 : 2.2}
                    fill={pt.volume > 0 ? '#22d3ee' : '#0f172a'}
                    stroke={isHovered ? '#ffffff' : '#22d3ee'}
                    strokeWidth={isHovered ? 2 : 1.5}
                  />
                </g>
              );
            })}

            {/* X-Axis Tick Labels */}
            {xTickIndices.map((idx) => {
              const pt = dataPoints[idx];
              if (!pt) return null;
              return (
                <text
                  key={`x-${idx}`}
                  x={xScale(idx)}
                  y={innerHeight + 20}
                  textAnchor="middle"
                  className="fill-slate-400 text-[10px] font-mono"
                >
                  {pt.label}
                </text>
              );
            })}
          </g>
        </svg>

        {/* Active / Hovered Point Detail Bar */}
        {activePoint && (
          <div className="mt-1 px-3 py-2 rounded-xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between gap-2 text-[11px]">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
              <span className="font-bold text-white truncate">{activePoint.fullLabel}</span>
              <span className="text-slate-400 hidden sm:inline">
                ({activePoint.workouts} workout{activePoint.workouts === 1 ? '' : 's'})
              </span>
            </div>
            <div className="flex items-center gap-3 font-mono shrink-0">
              <span className="text-cyan-300 font-bold">
                {activePoint.volume.toLocaleString()} vol
              </span>
              <span className="text-slate-400">
                {activePoint.reps} reps · {activePoint.sets} sets
              </span>
              <span className="text-amber-300 hidden sm:inline">
                Trend Avg: {activePoint.trendAvg.toLocaleString()}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Legend Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80 text-[10px] text-slate-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-cyan-400 inline-block rounded" />
            <span>Total Volume ({unitLabel}·reps)</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-amber-400 inline-block rounded border-b border-dashed" />
            <span>3-Point Moving Strength Trend</span>
          </span>
        </div>
        <span className="font-mono text-cyan-400">Drag / Hover chart to inspect</span>
      </div>
    </div>
  );
};
