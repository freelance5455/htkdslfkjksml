import { useState } from 'react';
import type { ReactNode } from 'react';
import { cn } from '../utils/cn';

interface Props {
  onDown?: () => void;
  onUp?: () => void;
  className?: string;
  children: ReactNode;
  active?: boolean;
  label?: string;
}

export function HoldButton({ onDown, onUp, className, children, active, label }: Props) {
  const [pressed, setPressed] = useState(false);

  const release = () => {
    if (!pressed) return;
    setPressed(false);
    onUp?.();
  };

  return (
    <button
      type="button"
      aria-label={label}
      className={cn(
        'flex touch-none select-none items-center justify-center rounded-full border-2 border-white/45 bg-black/30 text-white shadow-lg backdrop-blur-[2px] transition-transform',
        (pressed || active) && 'scale-95 border-white/90 bg-white/35',
        className,
      )}
      onPointerDown={(e) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        setPressed(true);
        onDown?.();
      }}
      onPointerUp={release}
      onPointerCancel={release}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}
