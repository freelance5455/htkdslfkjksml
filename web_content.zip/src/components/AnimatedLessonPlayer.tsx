import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  Pause,
  Play,
  RotateCcw,
  SkipBack,
  SkipForward,
  X,
} from 'lucide-react';
import { ChapterVideo, LanguageCode, VisualSceneKind } from '../types/edutoon';
import { Logo } from './Logo';

interface AnimatedLessonPlayerProps {
  video: ChapterVideo;
  subjectName: string;
  initialProgress: number;
  isCompleted: boolean;
  language: LanguageCode;
  onSaveProgress: (progressPercent: number, completed: boolean) => void;
  onToggleCompleted: () => void;
  onClose: () => void;
}

const SceneVisualStage: React.FC<{
  kind: VisualSceneKind;
  highlightValue: string;
  playing: boolean;
  sceneProgress: number;
}> = ({ kind, highlightValue, playing, sceneProgress }) => {
  const pulseOffset = Math.round(sceneProgress * 100);

  return (
    <div className="relative w-full h-56 sm:h-72 rounded-2xl bg-[#0B1633] border border-slate-700/70 overflow-hidden flex items-center justify-center p-4">
      {kind === 'numberline' && (
        <svg viewBox="0 0 420 160" className="w-full h-full max-w-md">
          <line x1="30" y1="96" x2="390" y2="96" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" />
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => {
            const x = 40 + n * 34;
            return (
              <g key={n}>
                <line x1={x} y1="86" x2={x} y2="106" stroke="#94A3B8" strokeWidth="2" />
                <text x={x} y="128" textAnchor="middle" fill="#E2E8F0" fontSize="13" fontFamily="monospace">
                  {n}
                </text>
              </g>
            );
          })}
          <motion.path
            d="M 210 86 Q 278 24 346 86"
            fill="none"
            stroke="#FBBF24"
            strokeWidth="3"
            strokeDasharray="6 4"
            animate={{ strokeDashoffset: playing ? [0, -20] : 0 }}
            transition={{ repeat: Infinity, duration: 1.2, ease: 'linear' }}
          />
          <motion.circle
            cx={176 + Math.min(170, pulseOffset * 1.7)}
            cy="96"
            r="9"
            fill="#38BDF8"
            stroke="#FFFFFF"
            strokeWidth="2.5"
          />
        </svg>
      )}

      {kind === 'geometry' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <motion.polygon
            points="90,145 270,145 270,40"
            fill="rgba(56, 189, 248, 0.16)"
            stroke="#38BDF8"
            strokeWidth="3"
            animate={{ scale: playing ? [0.98, 1.02, 0.98] : 1 }}
            transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
          />
          <rect x="252" y="127" width="18" height="18" fill="none" stroke="#FBBF24" strokeWidth="2" />
          <text x="180" y="165" textAnchor="middle" fill="#CBD5E1" fontSize="13">Base</text>
          <text x="292" y="96" fill="#CBD5E1" fontSize="13">Height</text>
          <text x="155" y="82" fill="#38BDF8" fontSize="13" fontWeight="bold">Hypotenuse</text>
        </svg>
      )}

      {kind === 'fraction' && (
        <svg viewBox="0 0 360 160" className="w-full h-full max-w-sm">
          {[0, 1, 2, 3].map((idx) => {
            const filled = idx < 3;
            return (
              <motion.rect
                key={idx}
                x={44 + idx * 70}
                y={48}
                width="62"
                height="62"
                rx="10"
                fill={filled ? '#0EA5E9' : '#1E293B'}
                stroke="#7DD3FC"
                strokeWidth="2.5"
                animate={{ opacity: playing && filled ? [0.78, 1, 0.78] : 1 }}
                transition={{ repeat: Infinity, duration: 2, delay: idx * 0.25 }}
              />
            );
          })}
        </svg>
      )}

      {kind === 'plant' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <circle cx="62" cy="42" r="22" fill="#FBBF24" />
          <line x1="180" y1="150" x2="180" y2="54" stroke="#22C55E" strokeWidth="6" strokeLinecap="round" />
          <motion.ellipse
            cx="140"
            cy="88"
            rx="34"
            ry="15"
            transform="rotate(-24 140 88)"
            fill="#16A34A"
            animate={{ rotate: playing ? [-26, -20, -26] : -24 }}
            transition={{ repeat: Infinity, duration: 2.5 }}
          />
          <motion.ellipse
            cx="220"
            cy="78"
            rx="34"
            ry="15"
            transform="rotate(24 220 78)"
            fill="#22C55E"
            animate={{ rotate: playing ? [26, 20, 26] : 24 }}
            transition={{ repeat: Infinity, duration: 2.5 }}
          />
          <path d="M 180 150 L 155 170 M 180 150 L 205 170 M 180 150 L 180 172" stroke="#D97706" strokeWidth="3" />
          <motion.circle
            cx="180"
            cy={148 - (pulseOffset % 80)}
            r="4.5"
            fill="#38BDF8"
          />
        </svg>
      )}

      {kind === 'solar' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <circle cx="180" cy="90" r="24" fill="#F59E0B" />
          <circle cx="180" cy="90" r="54" fill="none" stroke="#334155" strokeDasharray="4 4" strokeWidth="1.5" />
          <circle cx="180" cy="90" r="80" fill="none" stroke="#334155" strokeDasharray="4 4" strokeWidth="1.5" />
          <motion.g
            animate={{ rotate: playing ? 360 : 0 }}
            transition={{ repeat: Infinity, duration: 9, ease: 'linear' }}
            style={{ originX: '180px', originY: '90px' }}
          >
            <circle cx="234" cy="90" r="8" fill="#38BDF8" />
          </motion.g>
          <motion.g
            animate={{ rotate: playing ? -360 : 0 }}
            transition={{ repeat: Infinity, duration: 14, ease: 'linear' }}
            style={{ originX: '180px', originY: '90px' }}
          >
            <circle cx="100" cy="90" r="10" fill="#EF4444" />
          </motion.g>
        </svg>
      )}

      {kind === 'atom' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <circle cx="180" cy="90" r="14" fill="#F43F5E" />
          <ellipse cx="180" cy="90" rx="76" ry="28" fill="none" stroke="#38BDF8" strokeWidth="2" transform="rotate(28 180 90)" />
          <ellipse cx="180" cy="90" rx="76" ry="28" fill="none" stroke="#38BDF8" strokeWidth="2" transform="rotate(-28 180 90)" />
          <motion.circle
            cx="248"
            cy="90"
            r="6"
            fill="#FBBF24"
            animate={{ rotate: playing ? 360 : 0 }}
            transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
            style={{ originX: '180px', originY: '90px' }}
          />
        </svg>
      )}

      {kind === 'force' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <line x1="25" y1="138" x2="335" y2="138" stroke="#475569" strokeWidth="3" />
          <motion.g
            animate={{ x: playing ? [0, 90, 0] : 20 }}
            transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut' }}
          >
            <rect x="70" y="88" width="58" height="48" rx="8" fill="#0EA5E9" stroke="#BAE6FD" strokeWidth="2" />
            <text x="99" y="117" textAnchor="middle" fill="#FFFFFF" fontSize="14" fontWeight="bold">m</text>
            <line x1="136" y1="112" x2="188" y2="112" stroke="#FBBF24" strokeWidth="4" />
            <polygon points="188,104 204,112 188,120" fill="#FBBF24" />
          </motion.g>
        </svg>
      )}

      {kind === 'circuit' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <rect x="75" y="42" width="210" height="96" rx="14" fill="none" stroke="#38BDF8" strokeWidth="3" />
          <rect x="58" y="72" width="34" height="36" rx="4" fill="#1E293B" stroke="#FBBF24" strokeWidth="2" />
          <text x="75" y="95" textAnchor="middle" fill="#FBBF24" fontSize="12" fontWeight="bold">+ -</text>
          <motion.circle
            cx="285"
            cy="90"
            r="16"
            fill={playing ? '#FBBF24' : '#334155'}
            animate={{ scale: playing ? [1, 1.12, 1] : 1 }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          />
          <motion.circle
            cx={120 + (pulseOffset % 140)}
            cy="42"
            r="4.5"
            fill="#FFFFFF"
          />
        </svg>
      )}

      {kind === 'grammar' && (
        <div className="flex flex-wrap items-center justify-center gap-3">
          {['Subject', 'Verb', 'Object'].map((word, idx) => (
            <motion.div
              key={word}
              animate={{ y: playing ? [0, -6, 0] : 0 }}
              transition={{ repeat: Infinity, duration: 2.2, delay: idx * 0.35 }}
              className="px-4 py-3 rounded-xl bg-slate-800 border border-sky-400/50 text-sky-200 font-display font-semibold text-base"
            >
              {word}
            </motion.div>
          ))}
        </div>
      )}

      {kind === 'map' && (
        <svg viewBox="0 0 360 180" className="w-full h-full max-w-sm">
          <path
            d="M 155 24 L 205 32 L 245 78 L 210 112 L 185 162 L 152 122 L 122 86 Z"
            fill="rgba(56, 189, 248, 0.16)"
            stroke="#38BDF8"
            strokeWidth="2.5"
          />
          <motion.circle
            cx="178"
            cy="72"
            r="6"
            fill="#FBBF24"
            animate={{ scale: playing ? [1, 1.4, 1] : 1 }}
            transition={{ repeat: Infinity, duration: 2 }}
          />
          <motion.circle
            cx="196"
            cy="112"
            r="5"
            fill="#22C55E"
            animate={{ scale: playing ? [1, 1.4, 1] : 1 }}
            transition={{ repeat: Infinity, duration: 2, delay: 0.6 }}
          />
        </svg>
      )}

      <div className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-slate-900/90 border border-slate-700 text-xs font-mono-num text-sky-300">
        {highlightValue}
      </div>
    </div>
  );
};

export const AnimatedLessonPlayer: React.FC<AnimatedLessonPlayerProps> = ({
  video,
  subjectName,
  initialProgress,
  isCompleted,
  language,
  onSaveProgress,
  onToggleCompleted,
  onClose,
}) => {
  const isHi = language === 'hi';
  const totalSec = Math.max(10, video.durationSec || 40);
  const [elapsedSec, setElapsedSec] = useState<number>(() =>
    Math.round((Math.min(95, Math.max(0, initialProgress)) / 100) * totalSec)
  );
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState<1 | 1.25 | 1.5>(1);
  const lastSavedPctRef = useRef<number>(initialProgress);

  const currentSceneInfo = useMemo(() => {
    let acc = 0;
    for (let i = 0; i < video.scenes.length; i++) {
      const s = video.scenes[i];
      if (elapsedSec <= acc + s.durationSec || i === video.scenes.length - 1) {
        const localProgress = Math.min(1, Math.max(0, (elapsedSec - acc) / s.durationSec));
        return { index: i, scene: s, localProgress };
      }
      acc += s.durationSec;
    }
    return {
      index: 0,
      scene: video.scenes[0],
      localProgress: 0,
    };
  }, [elapsedSec, video.scenes]);

  useEffect(() => {
    if (video.mediaUrl) return; // native video tag manages its own timer
    if (!playing) return;
    const interval = window.setInterval(() => {
      setElapsedSec((prev) => {
        const next = prev + 0.5 * speed;
        if (next >= totalSec) {
          setPlaying(false);
          return totalSec;
        }
        return next;
      });
    }, 500);
    return () => window.clearInterval(interval);
  }, [playing, speed, totalSec, video.mediaUrl]);

  const progressPercent = Math.min(100, Math.round((elapsedSec / totalSec) * 100));

  useEffect(() => {
    if (
      Math.abs(progressPercent - lastSavedPctRef.current) >= 15 ||
      progressPercent === 100
    ) {
      lastSavedPctRef.current = progressPercent;
      onSaveProgress(progressPercent, isCompleted || progressPercent === 100);
    }
  }, [progressPercent, isCompleted, onSaveProgress]);

  const handleClose = () => {
    onSaveProgress(progressPercent, isCompleted || progressPercent === 100);
    onClose();
  };

  const jumpToScene = (idx: number) => {
    let acc = 0;
    for (let i = 0; i < idx; i++) {
      acc += video.scenes[i].durationSec;
    }
    setElapsedSec(acc);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-3xl bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header with official Logo */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3 min-w-0">
            <Logo size="xs" />
            <div className="min-w-0">
              <p className="text-xs text-slate-500 truncate">
                {subjectName} · {isHi ? `अध्याय ${video.chapterNumber}` : `Chapter ${video.chapterNumber}`}
              </p>
              <h2 className="font-display text-sm sm:text-base font-bold text-slate-900 truncate">
                {video.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClose}
            aria-label="Close video player"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-200/70 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {video.mediaUrl ? (
            <video
              src={video.mediaUrl}
              controls
              autoPlay
              onTimeUpdate={(e) => {
                const el = e.currentTarget;
                if (el.duration > 0) {
                  const pct = Math.round((el.currentTime / el.duration) * 100);
                  setElapsedSec(Math.round((pct / 100) * totalSec));
                }
              }}
              onEnded={() => onSaveProgress(100, true)}
              className="w-full rounded-2xl bg-black max-h-80"
            />
          ) : (
            <>
              <SceneVisualStage
                kind={currentSceneInfo.scene.visualKind}
                highlightValue={currentSceneInfo.scene.highlightValue}
                playing={playing}
                sceneProgress={currentSceneInfo.localProgress}
              />

              {/* Caption Box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <p className="text-xs font-semibold text-sky-700">
                  {currentSceneInfo.scene.title}
                </p>
                <p className="mt-1 text-sm sm:text-base text-slate-800 leading-relaxed">
                  {currentSceneInfo.scene.caption}
                </p>
              </div>

              {/* Scrubber & Controls */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono-num text-slate-500 w-10">
                    {Math.floor(elapsedSec)}s
                  </span>
                  <input
                    type="range"
                    aria-label="Video progress timeline"
                    min={0}
                    max={totalSec}
                    value={Math.min(totalSec, elapsedSec)}
                    onChange={(e) => setElapsedSec(Number(e.target.value))}
                    className="flex-1 accent-sky-600 cursor-pointer"
                  />
                  <span className="text-xs font-mono-num text-slate-500 w-10 text-right">
                    {totalSec}s
                  </span>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => jumpToScene(Math.max(0, currentSceneInfo.index - 1))}
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer"
                      aria-label="Previous scene"
                    >
                      <SkipBack className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setPlaying((p) => !p)}
                      className="min-h-[44px] px-5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                    >
                      {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      <span>{playing ? (isHi ? 'रोकें' : 'Pause') : isHi ? 'चलाएँ' : 'Play'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        jumpToScene(Math.min(video.scenes.length - 1, currentSceneInfo.index + 1))
                      }
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer"
                      aria-label="Next scene"
                    >
                      <SkipForward className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setElapsedSec(0);
                        setPlaying(true);
                      }}
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer"
                      aria-label="Restart"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setSpeed((s) => (s === 1 ? 1.25 : s === 1.25 ? 1.5 : 1))
                      }
                      className="min-h-[44px] px-3 rounded-xl border border-slate-200 text-xs font-mono-num font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                    >
                      {speed}x
                    </button>
                    <button
                      type="button"
                      onClick={onToggleCompleted}
                      className={`min-h-[44px] px-4 rounded-xl text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
                        isCompleted
                          ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                          : 'border border-slate-300 text-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>
                        {isCompleted
                          ? isHi
                            ? 'पूर्ण हुआ'
                            : 'Completed'
                          : isHi
                            ? 'पूर्ण चिह्नित करें'
                            : 'Mark Completed'}
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Scene Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                {video.scenes.map((scene, idx) => (
                  <button
                    key={scene.id}
                    type="button"
                    onClick={() => jumpToScene(idx)}
                    className={`p-2.5 rounded-xl text-left border text-xs transition-colors cursor-pointer ${
                      idx === currentSceneInfo.index
                        ? 'border-sky-500 bg-sky-50 text-sky-900 font-semibold'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="block truncate">{scene.title}</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
