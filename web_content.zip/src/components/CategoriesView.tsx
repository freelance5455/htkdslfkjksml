import React, { useState } from 'react';
import type { Category, StoreData } from '../types';
import { uid } from '../utils';
import { Icon } from './Icon';
import { ConfirmModal } from './SharedUI';

interface CategoriesViewProps {
  data: StoreData;
  t: Record<string, string>;
  onSaveCategory: (cat: Category, isEdit?: boolean) => void;
  onDeleteCategory: (id: string) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({ data, t, onSaveCategory, onDeleteCategory }) => {
  const [newCatName, setNewCatName] = useState('');
  const [modelInputs, setModelInputs] = useState<Record<string, string>>({});
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    onSaveCategory({ id: uid(), name: newCatName.trim(), models: [] });
    setNewCatName('');
  };

  const addModel = (cat: Category) => {
    const val = (modelInputs[cat.id] || '').trim();
    if (!val || cat.models.includes(val)) return;
    onSaveCategory({ ...cat, models: [...cat.models, val] }, true);
    setModelInputs({ ...modelInputs, [cat.id]: '' });
  };

  const removeModel = (cat: Category, modelName: string) => {
    onSaveCategory({ ...cat, models: cat.models.filter((m) => m !== modelName) }, true);
  };

  return (
    <div className="space-y-6">
      <form noValidate onSubmit={handleCreateCategory} className="surface-card p-4 flex flex-col sm:flex-row gap-3 max-w-xl">
        <input
          value={newCatName}
          onChange={(e) => setNewCatName(e.target.value)}
          placeholder={t.categoryName}
          className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition"
        />
        <button type="submit" className="btn-primary px-4 py-2.5 text-sm">
          <Icon name="plus" className="w-4 h-4" />
          <span>{t.addCategory}</span>
        </button>
      </form>

      {data.categories.length === 0 ? (
        <div className="surface-card p-10 text-center text-sm text-slate-400">
          {t.noData}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.categories.map((cat) => {
            const linkedCount = data.products.filter((p) => p.category === cat.name).length;
            return (
              <div key={cat.id} className="surface-card p-5 flex flex-col justify-between hover:border-slate-300 transition">
                <div>
                  <div className="flex items-start justify-between mb-3 gap-2">
                    <div>
                      <h4 className="font-bold text-slate-800 text-base">{cat.name}</h4>
                      <p className="text-xs text-slate-400 tabular-nums mt-0.5">{linkedCount} products</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(cat)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 shrink-0"
                    >
                      <Icon name="trash" className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs font-semibold text-slate-500 mb-2">{t.modelsVariants}</p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {cat.models.length === 0 ? (
                      <span className="text-xs text-slate-400">-</span>
                    ) : (
                      cat.models.map((m) => (
                        <span key={m} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium">
                          {m}
                          <button type="button" onClick={() => removeModel(cat, m)} className="text-slate-400 hover:text-rose-600 font-bold">
                            ×
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>
                <div className="flex gap-2 pt-3 border-t border-slate-100">
                  <input
                    value={modelInputs[cat.id] || ''}
                    onChange={(e) => setModelInputs({ ...modelInputs, [cat.id]: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addModel(cat);
                      }
                    }}
                    placeholder={t.addModelPlaceholder}
                    className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition"
                  />
                  <button type="button" onClick={() => addModel(cat)} className="btn-dark px-3.5 py-2 text-xs">
                    {t.addToCart}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ConfirmModal
        open={!!deleteTarget}
        title={t.confirmDeleteTitle}
        message={`${t.confirmDelete} (${deleteTarget?.name || ''})`}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) onDeleteCategory(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};
