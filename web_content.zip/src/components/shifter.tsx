import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";

const KN = 44;
const GC = [30, 70, 110];
const YT = 36;
const YM = 84;
const YB = 132;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const slot = (g: number) => (g ? { x: GC[(g - 1) >> 1]!, y: g % 2 ? YT : YB } : { x: GC[1]!, y: YM });

export function Shifter({ gear, onShift }: { gear: number; onShift: (g: number) => number }) {
  const track = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(() => slot(0));
  const [drag, setDrag] = useState(false);
  const posRef = useRef(pos);
  posRef.current = pos;

  useEffect(() => {
    if (!drag) setPos(slot(gear));
  }, [gear, drag]);

  function move(px: number, py: number) {
    let { x, y } = posRef.current;
    if (Math.abs(y - YM) > 8) {
      y = clamp(py, YT, YB);
      if (Math.abs(y - YM) <= 8) y = YM;
    } else {
      const nc = GC.find((c) => Math.abs(x - c) < 8);
      if (nc !== undefined && Math.abs(py - YM) > 12) {
        x = nc;
        y = clamp(py, YT, YB);
      } else {
        x = clamp(px, GC[0]!, GC[2]!);
        y = YM;
        const c = GC.find((col) => Math.abs(x - col) < 8);
        if (c !== undefined) x = c;
      }
    }
    const next = { x, y };
    posRef.current = next;
    setPos(next);
  }

  function pointer(e: ReactPointerEvent) {
    const r = track.current!.getBoundingClientRect();
    move(e.clientX - r.left, e.clientY - r.top);
  }

  return (
    <div
      ref={track}
      className="shifter relative shrink-0 rounded-xl border border-line bg-panel"
      onPointerDown={(e) => {
        track.current?.setPointerCapture(e.pointerId);
        setDrag(true);
        pointer(e);
      }}
      onPointerMove={(e) => {
        if (drag) pointer(e);
      }}
      onPointerUp={() => {
        if (!drag) return;
        setDrag(false);
        const ci = GC.indexOf(posRef.current.x);
        let g = 0;
        if (ci >= 0) {
          if (posRef.current.y <= YT + 6) g = ci * 2 + 1;
          else if (posRef.current.y >= YB - 6) g = ci * 2 + 2;
        }
        const actual = onShift(g);
        const snapped = slot(actual);
        posRef.current = snapped;
        setPos(snapped);
      }}
      onPointerCancel={() => setDrag(false)}
    >
      <div
        className="absolute h-1.5 rounded-sm bg-line"
        style={{ left: GC[0]! - 3, top: YM - 3, width: GC[2]! - GC[0]! + 6 }}
      />
      {GC.map((c) => (
        <div
          key={c}
          className="absolute w-1.5 rounded-sm bg-line"
          style={{ left: c - 3, top: YT - 3, height: YB - YT + 6 }}
        />
      ))}
      {Array.from({ length: 6 }, (_, i) => i + 1).map((g) => (
        <span
          key={g}
          className="absolute w-4 -translate-x-1/2 text-center text-xs font-semibold text-muted"
          style={{ left: GC[(g - 1) >> 1], top: g % 2 ? 6 : 148 }}
        >
          {g}
        </span>
      ))}
      <div
        className={`knob absolute grid size-11 place-items-center rounded-full bg-accent text-base font-bold text-accent-fg shadow-md ${drag ? "transition-none" : ""}`}
        style={{ left: pos.x - KN / 2, top: pos.y - KN / 2 }}
      >
        {gear || "N"}
      </div>
    </div>
  );
}
