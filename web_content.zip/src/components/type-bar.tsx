import { cn } from "@/lib/utils";
import { POST_TYPES, type TypeFilter } from "@/lib/sort";

export function TypeBar({
  value,
  onChange,
}: {
  value: TypeFilter;
  onChange: (id: TypeFilter) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto px-4 pb-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      {POST_TYPES.map((item) => {
        const active = item.id === value;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onChange(item.id)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3.5 text-xs font-medium transition-colors duration-[var(--motion-quick)]",
              active
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground",
            )}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
}
