import React, { useState } from 'react';
import { LanguageCode, GeneratedImagePayload } from '../types';
import { TRANSLATIONS } from '../translations';
import { GeneratedImageCard } from './GeneratedImageCard';
import { renderHighResVisual } from '../utils/imageGenerator';
import { ImagePlus, Sparkles, Wand2, Download, Share2, Layers, Sliders, Palette, CheckCircle2 } from 'lucide-react';

interface PhotoStudioTabProps {
  language: LanguageCode;
}

export const PhotoStudioTab: React.FC<PhotoStudioTabProps> = ({ language }) => {
  const [prompt, setPrompt] = useState('');
  const [category, setCategory] = useState<'thumbnail' | 'anniversary' | 'food' | 'gaming' | 'tech'>('thumbnail');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '1:1'>('16:9');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState<GeneratedImagePayload | null>({
    prompt: '5 Secret AI Websites That Feel Illegal to Know',
    title: '5 SECRET AI WEBSITES',
    subtitle: 'High CTR YouTube Thumbnail Masterpiece',
    category: 'tech',
    badge: '100% VIRAL',
    aspectRatio: '16:9',
  });

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanPrompt = prompt.trim() || 'Viral YouTube Video Concept';
    setIsGenerating(true);

    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: cleanPrompt,
          category,
          aspectRatio,
        }),
      });

      const data = await res.json();
      if (data.payload) {
        // Pre-render preview dataUrl
        const previewUrl = await renderHighResVisual(data.payload, 'preview');
        setCurrentImage({
          ...data.payload,
          dataUrl: previewUrl,
        });
      }
    } catch {
      // Local fallback
      const fallbackPayload: GeneratedImagePayload = {
        prompt: cleanPrompt,
        title: cleanPrompt.toUpperCase().slice(0, 30),
        subtitle: 'Created by ViralSamrat AI Studio',
        category,
        badge: category === 'anniversary' ? 'HAPPY ANNIVERSARY' : '100% VIRAL',
        aspectRatio,
      };
      const previewUrl = await renderHighResVisual(fallbackPayload, 'preview');
      setCurrentImage({
        ...fallbackPayload,
        dataUrl: previewUrl,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const PRESET_TEMPLATES = [
    { label: '🔥 5 AI Secret Tools (Thumbnail)', prompt: '5 Secret AI Tools That Feel Illegal to Know', category: 'tech' as const },
    { label: '💖 Happy Anniversary Golden Celebration', prompt: 'Happy Anniversary Golden Celebration with Romantic Sparkles', category: 'anniversary' as const },
    { label: '🍔 1000 Parathas Food Street ASMR', prompt: 'Desi Street Food 1000 Parathas ASMR Viral Recipe', category: 'food' as const },
    { label: '🎮 Secret Gaming Room Transformation', prompt: 'Secret PC Gaming Setup Lair with RGB Lighting', category: 'gaming' as const },
    { label: '🏆 1 Million Subscribers Plaque', prompt: 'How I Reached 1 Million Subscribers on YouTube', category: 'thumbnail' as const },
  ];

  return (
    <div className="space-y-6">
      {/* Studio Header Banner */}
      <div className="p-4 rounded-2xl bg-zinc-950/80 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/20">
            <ImagePlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>ViralSamrat AI Visual Studio</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                1080p &amp; 4K ULTRA
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              Create high-CTR YouTube thumbnails, posters, and anniversary photos with 1-click download &amp; share (CRV)
            </p>
          </div>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Creator Control Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-zinc-950/80 border border-white/10 shadow-xl space-y-4">
            <form onSubmit={handleGenerate} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Photo / Thumbnail Topic &amp; Idea *
                </label>
                <textarea
                  rows={3}
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  placeholder="e.g. Mere YouTube channel ke liye ek viral thumbnail photo create karke do: 'How I Built a Secret Gaming Room'..."
                  className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500 resize-none"
                />
              </div>

              {/* Category Picker */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Visual Style &amp; Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'thumbnail', label: 'YouTube Thumbnail' },
                    { id: 'anniversary', label: '💖 Anniversary Special' },
                    { id: 'tech', label: '⚡ AI & Technology' },
                    { id: 'gaming', label: '🎮 Gaming & Setup' },
                    { id: 'food', label: '🍳 Street Food ASMR' },
                  ].map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCategory(c.id as any)}
                      className={`p-2 rounded-xl text-xs font-medium text-left border transition-all ${
                        category === c.id
                          ? 'border-pink-500 bg-pink-950/40 text-pink-300 shadow-sm'
                          : 'border-white/5 bg-zinc-900/60 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Aspect Ratio */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Canvas Aspect Ratio
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setAspectRatio('16:9')}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                      aspectRatio === '16:9'
                        ? 'bg-cyan-500 text-black border-cyan-400 font-bold'
                        : 'bg-zinc-900 text-zinc-400 border-white/5'
                    }`}
                  >
                    16:9 (YouTube 1920x1080)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAspectRatio('1:1')}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                      aspectRatio === '1:1'
                        ? 'bg-cyan-500 text-black border-cyan-400 font-bold'
                        : 'bg-zinc-900 text-zinc-400 border-white/5'
                    }`}
                  >
                    1:1 (Square Post)
                  </button>
                </div>
              </div>

              {/* Generate Button */}
              <button
                type="submit"
                disabled={isGenerating}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 hover:from-pink-400 hover:to-amber-400 text-white font-bold text-xs tracking-wider uppercase shadow-lg shadow-pink-500/25 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <Sparkles className="w-4 h-4 animate-spin text-yellow-200" />
                    <span>Rendering 4K Graphic...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>Generate Photo / Thumbnail</span>
                  </>
                )}
              </button>
            </form>

            {/* Quick 1-Click Inspiration Prompts */}
            <div className="pt-2 border-t border-white/5">
              <span className="block text-[11px] font-semibold text-zinc-400 mb-2">
                1-Click Inspiration Templates:
              </span>
              <div className="space-y-1.5">
                {PRESET_TEMPLATES.map((tmpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPrompt(tmpl.prompt);
                      setCategory(tmpl.category);
                    }}
                    className="w-full text-left p-2 rounded-xl bg-zinc-900/60 hover:bg-zinc-800 text-[11px] text-zinc-300 border border-white/5 truncate transition-all"
                  >
                    {tmpl.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Generated Image Result Display Column */}
        <div className="lg:col-span-7 flex flex-col justify-start">
          {currentImage ? (
            <div className="w-full animate-fade-in-up">
              <GeneratedImageCard
                payload={currentImage}
                onDelete={() => setCurrentImage(null)}
                onRegenerate={() => handleGenerate()}
              />
            </div>
          ) : (
            <div className="h-full min-h-[350px] rounded-2xl bg-zinc-950/40 border border-dashed border-white/10 flex flex-col items-center justify-center p-8 text-center text-zinc-500">
              <ImagePlus className="w-12 h-12 text-zinc-700 mb-3" />
              <h4 className="text-sm font-semibold text-zinc-400 mb-1">
                Visual Studio Ready
              </h4>
              <p className="text-xs max-w-sm">
                Enter your photo or thumbnail prompt on the left to generate and download in 1080p HD or 4K Ultra.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
