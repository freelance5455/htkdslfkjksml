import { useEffect, useRef, useState } from "react";
import { ArrowLeftRight, LineChart, PieChart, TrendingUp, Wallet, RefreshCw } from "lucide-react";
import { AssetsView } from "@/components/assets-view";
import { HomeView } from "@/components/home-view";
import { LedgerView, type TradeRequest } from "@/components/ledger-view";
import { MarketView } from "@/components/market-view";
import { OutlookView } from "@/components/outlook-view";
import { Mark, cn } from "@/components/ui";
import { fetchMarket } from "@/lib/market.functions";
import { formatMan, formatPct } from "@/lib/format";
import { portfolioCost, portfolioValue } from "@/lib/calc";
import { cleanSymbol, isSafeSymbol } from "@/lib/symbols";
import { usePortfolio } from "@/lib/store";
import type { TabId, TxKind } from "@/lib/types";

const TABS: { id: TabId; label: string; icon: typeof PieChart }[] = [
  { id: "home", label: "현황", icon: PieChart },
  { id: "assets", label: "자산", icon: Wallet },
  { id: "ledger", label: "거래", icon: ArrowLeftRight },
  { id: "market", label: "시장", icon: LineChart },
  { id: "outlook", label: "전망", icon: TrendingUp },
];

export function App() {
  const [tab, setTab] = useState<TabId>("home");
  const [request, setRequest] = useState<TradeRequest | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lock = useRef(false);
  const holdings = usePortfolio((state) => state.holdings);
  const market = usePortfolio((state) => state.market);
  const applyMarket = usePortfolio((state) => state.applyMarket);
  const total = portfolioValue(holdings, market.fx);
  const cost = portfolioCost(holdings, market.fx);
  const pnlPct = cost > 0 ? ((total - cost) / cost) * 100 : 0;

  async function refresh(manual = false) {
    if (lock.current) return;
    lock.current = true;
    setLoading(true);
    if (manual) setError(null);
    try {
      const symbols = [
        ...new Set(
          usePortfolio
            .getState()
            .holdings.filter((holding) => holding.priceMode === "auto" && holding.symbol)
            .map((holding) => cleanSymbol(holding.symbol))
            .filter(isSafeSymbol),
        ),
      ];
      const result = await fetchMarket({ data: { symbols } });
      if (!result.ok) {
        if (manual) setError(result.message);
      } else {
        applyMarket(result);
        setError(null);
      }
    } catch {
      if (manual) setError("시세를 가져오지 못했습니다. 잠시 후 다시 눌러 주세요.");
    } finally {
      lock.current = false;
      setLoading(false);
    }
  }

  useEffect(() => {
    let live = true;
    void (async () => {
      try {
        await usePortfolio.persist.rehydrate();
      } catch {
        /* sample stays */
      }
      if (!live) return;
      const updatedAt = usePortfolio.getState().market.updatedAt;
      const stale = !updatedAt || Date.now() - Date.parse(updatedAt) > 6 * 60 * 60 * 1000;
      if (stale) void refresh();
    })();
    return () => {
      live = false;
    };
  }, []);

  function openTrade(kind: TxKind, holdingId: string | null = null) {
    setTab("ledger");
    setRequest({ nonce: Date.now(), kind, holdingId });
  }

  return (
    <div className="min-h-dvh bg-bg">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/95">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-2">
          <div className="flex min-w-0 items-center gap-2">
            <Mark />
            <div className="min-w-0">
              <p className="text-base font-semibold leading-tight">한눈</p>
              <p className="truncate text-xs tabular-nums text-muted">
                {formatMan(total)} · {formatPct(pnlPct)}
              </p>
            </div>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg text-fg"
            onClick={() => void refresh(true)}
            aria-label="시세 새로고침"
            aria-busy={loading}
          >
            <RefreshCw className={cn("size-5", loading && "animate-spin")} />
          </button>
        </div>
        {error ? <p className="mx-auto max-w-5xl px-4 pb-2 text-xs text-down">{error}</p> : null}
      </header>
      <main className="mx-auto max-w-5xl px-4 pt-4 pb-28">
        {tab === "home" ? <HomeView onNavigate={setTab} onTrade={(kind) => openTrade(kind)} /> : null}
        {tab === "assets" ? <AssetsView onTrade={(kind, id) => openTrade(kind, id)} /> : null}
        {tab === "ledger" ? <LedgerView request={request} /> : null}
        {tab === "market" ? <MarketView /> : null}
        {tab === "outlook" ? <OutlookView /> : null}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="mx-auto grid max-w-5xl grid-cols-5">
          {TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className={cn("flex h-16 flex-col items-center justify-center gap-1 text-xs", active ? "text-primary" : "text-muted")}
                aria-current={active ? "page" : undefined}
                onClick={() => setTab(item.id)}
              >
                <Icon className="size-5" strokeWidth={active ? 2.25 : 1.75} />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}