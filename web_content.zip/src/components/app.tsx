import { ActiveCall } from "@/components/active-call";
import { AiCallsView } from "@/components/ai-calls-view";
import { ContactsView } from "@/components/contacts-view";
import { IncomingCall } from "@/components/incoming-call";
import { KeypadView } from "@/components/keypad-view";
import { LisaMark } from "@/components/logo";
import { OverlayHost } from "@/components/overlays";
import { PhoneFrame, PhoneShell } from "@/components/phone-shell";
import { RecentsView } from "@/components/recents-view";
import { SettingsView } from "@/components/settings-view";
import { useAppStore } from "@/lib/store";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";

export function LisaCallApp() {
  const [ready, setReady] = useState(false);
  const tab = useAppStore((s) => s.tab);
  const setTab = useAppStore((s) => s.setTab);
  const overlay = useAppStore((s) => s.overlay);
  const live = useAppStore((s) => s.live);

  useEffect(() => {
    setReady(true);
    const unsub = useAppStore.persist.onFinishHydration(() => {
      useAppStore.getState().pruneExpired();
    });
    if (useAppStore.persist.hasHydrated()) {
      useAppStore.getState().pruneExpired();
    }
    return unsub;
  }, []);

  const onCall =
    overlay.kind === "incoming" ||
    overlay.kind === "active" ||
    live?.status === "ringing" ||
    live?.status === "active" ||
    live?.status === "lisa";

  if (!ready) {
    return (
      <PhoneFrame>
        <div className="flex flex-1 flex-col items-center justify-center gap-3">
          <LisaMark className="size-12" />
          <p className="text-sm text-muted-foreground">Lisa Call</p>
        </div>
      </PhoneFrame>
    );
  }

  return (
    <PhoneFrame>
      <PhoneShell tab={tab} onTab={setTab} hideTabs={onCall}>
        {tab === "keypad" ? <KeypadView /> : null}
        {tab === "recents" ? <RecentsView /> : null}
        {tab === "contacts" ? <ContactsView /> : null}
        {tab === "ai" ? <AiCallsView /> : null}
        {tab === "settings" ? <SettingsView /> : null}
      </PhoneShell>
      {overlay.kind === "incoming" || live?.status === "ringing" ? <IncomingCall /> : null}
      {overlay.kind === "active" || live?.status === "active" || live?.status === "lisa" ? (
        <ActiveCall />
      ) : null}
      <OverlayHost />
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          classNames: {
            toast: "bg-card text-foreground border border-border",
          },
        }}
      />
    </PhoneFrame>
  );
}
