import React, { useState } from 'react';
import { LogIn, KeyRound, User as UserIcon, AlertTriangle, MoreVertical, MessageSquare, ShieldAlert } from 'lucide-react';
import { APP_LOGO, APP_VERSION, WHATSAPP_SERVICE_NUMBER } from '../constants.ts';
import { api } from '../services/api.ts';
import type { User, BanRecord } from '../types/index.ts';

interface LoginScreenProps {
  onLoginSuccess: (user: User, token: string, isTemporaryPassword?: boolean) => void;
  onOpenWhatsApp: () => void;
  onOpenAdminLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  onOpenWhatsApp,
  onOpenAdminLogin,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bannedInfo, setBannedInfo] = useState<BanRecord | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Please enter both username and password');
      return;
    }

    setLoading(true);
    setError(null);
    setBannedInfo(null);

    try {
      const res = await api.login(username.trim(), password);
      if (res.success && res.user && res.token) {
        onLoginSuccess(res.user, res.token, res.isTemporaryPassword);
      } else {
        if (res.banInfo) {
          setBannedInfo(res.banInfo);
        }
        setError(res.error || 'Invalid credentials');
      }
    } catch {
      setError('Failed to reach server. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const fillQuickGamer = (u: string, p = 'gamer123') => {
    setUsername(u);
    setPassword(p);
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between bg-[#080a0f] text-slate-100 relative overflow-hidden select-none">
      {/* Background ambient neon gaming glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-700/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header with 3 Dots Menu */}
      <div className="w-full max-w-md mx-auto p-4 flex items-center justify-between relative z-20">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#00d2ff]" />
          <span className="text-[11px] font-mono tracking-widest text-cyan-400 uppercase">Esports Network</span>
        </div>

        {/* 3 Dots Menu Button */}
        <div className="relative">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:border-cyan-500/40 transition-colors"
            aria-label="Menu"
          >
            <MoreVertical size={18} />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-12 w-48 rounded-xl bg-[#0c121e] border border-cyan-500/30 p-1.5 shadow-2xl z-30 text-xs">
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onOpenWhatsApp();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
              >
                <MessageSquare size={14} className="text-emerald-400" />
                <span>WhatsApp Service</span>
              </button>
              <div className="my-1 border-t border-slate-800" />
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onOpenAdminLogin();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/60 transition-colors text-left font-medium"
              >
                <ShieldAlert size={14} className="text-cyan-400" />
                <span>Admin Login (Secret)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Center Box */}
      <div className="w-full max-w-sm mx-auto px-4 py-6 relative z-10 my-auto">
        {/* Esports Team Brand Logo */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="relative group mb-3">
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 opacity-60 blur-md group-hover:opacity-100 transition-opacity" />
            <img
              src={APP_LOGO}
              alt="Unknown Gamer"
              className="relative w-24 h-24 rounded-2xl object-cover border border-cyan-400/50 shadow-2xl bg-[#0a0f18]"
              referrerPolicy="no-referrer"
            />
          </div>

          <h1 className="text-2xl font-black tracking-wider uppercase text-white font-display flex items-center justify-center gap-1">
            <span>Unknown</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              Gamer
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Dark Gaming & Esports Messaging</p>
        </div>

        {/* Error / Ban Alert */}
        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs space-y-1">
            <div className="flex items-center gap-2 font-bold text-red-400">
              <AlertTriangle size={15} />
              <span>{bannedInfo ? 'Account Suspended' : 'Authentication Failed'}</span>
            </div>
            <p>{error}</p>
            {bannedInfo && (
              <div className="pt-2 text-[11px] text-slate-300 space-y-0.5 border-t border-red-900/60">
                <div>Reason: {bannedInfo.reason}</div>
                {bannedInfo.expiresAt && (
                  <div>Expires: {new Date(bannedInfo.expiresAt).toLocaleDateString()}</div>
                )}
                <button
                  type="button"
                  onClick={onOpenWhatsApp}
                  className="mt-1 text-cyan-400 underline hover:text-cyan-300 block"
                >
                  Contact Admin for Appeal on WhatsApp
                </button>
              </div>
            )}
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-300 flex items-center gap-1.5">
              <UserIcon size={14} className="text-cyan-400" />
              <span>Gaming Username / Tag</span>
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. ShadowSniper"
              autoComplete="username"
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700/80 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-white placeholder-slate-500 text-xs font-mono outline-none transition-all"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-300 flex items-center gap-1.5">
              <KeyRound size={14} className="text-cyan-400" />
              <span>Password</span>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password..."
              autoComplete="current-password"
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700/80 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-white placeholder-slate-500 text-xs outline-none transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs uppercase tracking-wider bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all cursor-pointer disabled:opacity-60 mt-2"
          >
            <LogIn size={16} />
            <span>{loading ? 'Authenticating...' : 'Enter Arena'}</span>
          </button>
        </form>

        {/* Forgot Password / Contact Admin */}
        <div className="mt-5 text-center space-y-2">
          <button
            type="button"
            onClick={onOpenWhatsApp}
            className="text-xs text-slate-400 hover:text-cyan-400 transition-colors inline-block cursor-pointer"
          >
            Forgot Password? / Contact Admin on WhatsApp
          </button>

          {/* Quick Demo Accounts Selection */}
          <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
            <div className="mb-2 text-[10px] uppercase tracking-wider text-slate-500 font-semibold">
              Quick Test Accounts (Pass: gamer123):
            </div>
            <div className="flex flex-wrap items-center justify-center gap-1.5">
              <button
                type="button"
                onClick={() => fillQuickGamer('ShadowSniper')}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 font-mono text-[10px] transition-colors"
              >
                ShadowSniper
              </button>
              <button
                type="button"
                onClick={() => fillQuickGamer('CyberViper')}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-slate-300 font-mono text-[10px] transition-colors"
              >
                CyberViper
              </button>
              <button
                type="button"
                onClick={() => fillQuickGamer('NeonGhost')}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 font-mono text-[10px] transition-colors"
              >
                NeonGhost (Temp Pass)
              </button>
              <button
                type="button"
                onClick={() => fillQuickGamer('AuraQueen')}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-slate-300 font-mono text-[10px] transition-colors"
              >
                AuraQueen
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="w-full max-w-md mx-auto p-4 text-center text-[10px] text-slate-500 font-mono flex items-center justify-between border-t border-slate-900">
        <span>Admin Support: {WHATSAPP_SERVICE_NUMBER}</span>
        <span>{APP_VERSION}</span>
      </div>
    </div>
  );
};
