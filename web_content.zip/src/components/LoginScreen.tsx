import React, { useState } from 'react';
import { GraduationCap, Brain, Sparkles, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (email: string) => void;
  onGuestLogin: () => void;
  apiConnected: boolean;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGuestLogin, apiConnected }) => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      onLogin(email.trim());
    }
  };

  return (
    <div className="max-w-md mx-auto my-auto py-8 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-8 text-center space-y-6">
        {/* Brand Icon */}
        <div className="w-16 h-16 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-3xl flex items-center justify-center mx-auto shadow-lg shadow-blue-500/20 text-white transform hover:scale-105 transition">
          <Brain className="w-8 h-8 text-amber-300" />
        </div>

        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">विद्यार्थी लॉगिन (Student Login)</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5">
            प्रतियोगी परीक्षा टेस्ट सीरीज़ में भाग लेने के लिए अपना ईमेल दर्ज करें।
          </p>
        </div>

        {/* API connection banner */}
        <div className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium">
          <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Gemini AI API स्वचालित रूप से कनेक्टेड है</span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              ईमेल पता (Email Address) <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="student@example.com"
              className="w-full px-4 py-3 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition flex items-center justify-center gap-2"
          >
            <span>लॉगिन करें / रजिस्टर करें</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-slate-200"></div>
          <span className="flex-shrink mx-3 text-xs text-slate-400 uppercase font-bold">या</span>
          <div className="flex-grow border-t border-slate-200"></div>
        </div>

        {/* Guest & Quick Presets */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={onGuestLogin}
            className="w-full py-2.5 border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl transition"
          >
            अतिथि के रूप में प्रवेश करें (Guest Mode)
          </button>

          <button
            type="button"
            onClick={() => onLogin('vishnudayal7415@gmail.com')}
            className="w-full py-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-blue-700 font-semibold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>vishnudayal7415@gmail.com (Admin Quick Login)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
