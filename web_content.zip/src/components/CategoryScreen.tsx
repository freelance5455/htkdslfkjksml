import React, { useState } from 'react';
import { Filter, Star, Check, ArrowUpDown, ChevronRight, ShieldCheck } from 'lucide-react';
import { Product } from '../types/ecommerce';
import { CATEGORIES } from '../data/mockData';

interface CategoryScreenProps {
  products: Product[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  onSelectProduct: (product: Product) => void;
  searchQuery: string;
}

export const CategoryScreen: React.FC<CategoryScreenProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  onSelectProduct,
  searchQuery
}) => {
  const [onlyFreeShipping, setOnlyFreeShipping] = useState(false);
  const [onlyMall, setOnlyMall] = useState(false);
  const [minRating, setMinRating] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'relevance' | 'price_asc' | 'price_desc' | 'rating'>('relevance');

  // Filter products
  let filtered = products.filter((p) => {
    const matchesCategory = 
      selectedCategory === 'all' || 
      p.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchesSearch = 
      !searchQuery || 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesShipping = !onlyFreeShipping || p.freeShipping;
    const matchesMall = !onlyMall || p.vendorId === 'v1';
    const matchesRating = !minRating || p.rating >= minRating;

    return matchesCategory && matchesSearch && matchesShipping && matchesMall && matchesRating;
  });

  // Sort products
  if (sortBy === 'price_asc') {
    filtered = [...filtered].sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price_desc') {
    filtered = [...filtered].sort((a, b) => b.price - a.price);
  } else if (sortBy === 'rating') {
    filtered = [...filtered].sort((a, b) => b.rating - a.rating);
  }

  return (
    <div className="pb-20 bg-slate-50 min-h-screen">
      {/* Category selector strip */}
      <div className="bg-white border-b border-slate-200 px-2 py-2 sticky top-14 z-20 shadow-2xs">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#FF6600] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Faceted Filter Bar */}
        <div className="flex items-center gap-1.5 pt-2 overflow-x-auto scrollbar-none text-[11px]">
          <button
            onClick={() => setOnlyMall(!onlyMall)}
            className={`px-2.5 py-1 rounded-md border flex items-center gap-1 font-medium transition-colors ${
              onlyMall
                ? 'bg-orange-50 border-[#FF6600] text-[#FF6600]'
                : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <ShieldCheck className="w-3 h-3" /> Sewora Mall
          </button>
          <button
            onClick={() => setOnlyFreeShipping(!onlyFreeShipping)}
            className={`px-2.5 py-1 rounded-md border flex items-center gap-1 font-medium transition-colors ${
              onlyFreeShipping
                ? 'bg-emerald-50 border-emerald-600 text-emerald-700'
                : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <Check className="w-3 h-3" /> Free Shipping
          </button>
          <button
            onClick={() => setMinRating(minRating === 4.8 ? null : 4.8)}
            className={`px-2.5 py-1 rounded-md border flex items-center gap-1 font-medium transition-colors ${
              minRating === 4.8
                ? 'bg-amber-50 border-amber-500 text-amber-700'
                : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> 4.8★ & up
          </button>

          <div className="ml-auto flex items-center gap-1">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-slate-200 text-slate-700 text-[11px] rounded-md px-2 py-1 font-medium focus:outline-none"
            >
              <option value="relevance">Top Match</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results Count & Query Notice */}
      <div className="p-3 flex items-center justify-between text-xs text-slate-500">
        <span>
          Showing <strong className="text-slate-900">{filtered.length}</strong> items
          {searchQuery && <span> for &ldquo;{searchQuery}&rdquo;</span>}
        </span>
        {(onlyMall || onlyFreeShipping || minRating || searchQuery) && (
          <button
            onClick={() => {
              setOnlyMall(false);
              setOnlyFreeShipping(false);
              setMinRating(null);
            }}
            className="text-[#FF6600] font-semibold hover:underline"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Products Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white m-3 rounded-2xl p-8 text-center border border-slate-200 shadow-2xs">
          <div className="w-12 h-12 rounded-full bg-orange-50 text-[#FF6600] flex items-center justify-center mx-auto mb-3">
            <Filter className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-slate-900 text-sm">No items found</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            Try adjusting your search terms or relaxing your active filters to see more marketplace deals.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2 px-2">
          {filtered.map((product) => (
            <div
              key={product.id}
              onClick={() => onSelectProduct(product)}
              className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
            >
              <div className="relative aspect-square w-full bg-slate-50 overflow-hidden">
                <img
                  src={product.images[0]}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-1 left-1 bg-[#FF6600] text-white text-[9px] font-extrabold px-1 rounded">
                  -{product.discountPercent}%
                </span>
                {product.freeShipping && (
                  <span className="absolute bottom-1 left-1 bg-emerald-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded shadow-xs">
                    Free Delivery
                  </span>
                )}
              </div>

              <div className="p-2.5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-[#FF6600] transition-colors">
                    {product.title}
                  </h4>
                </div>

                <div className="mt-2 pt-1 border-t border-slate-50">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-sm font-extrabold text-[#FF6600] tabular-nums">
                      Rs. {product.price.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                    <span className="line-through tabular-nums">
                      Rs. {product.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-slate-500 font-medium">
                      ★ {product.rating} ({product.soldCount})
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
