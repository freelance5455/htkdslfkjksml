import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import { ArrowLeft, Send, CheckCircle2, AlertCircle, MapPin, Clock, ShieldCheck, RefreshCw } from 'lucide-react';

interface StartProjectPageProps {
  onBack: () => void;
}

export const StartProjectPage: React.FC<StartProjectPageProps> = ({ onBack }) => {
  const { submitProjectBrief, data } = useData();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    discord: '',
    projectType: '', // FREE-TEXT INPUT as requested
    budget: '',
    timeline: '',
    description: '',
    referenceLinks: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [successSubmissionId, setSuccessSubmissionId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!formData.name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!formData.projectType.trim()) {
      setErrorMessage('Please specify the Project Type (e.g. Website, Discord Bot, Custom Minecraft plugin).');
      return;
    }
    if (!formData.description.trim()) {
      setErrorMessage('Please provide a brief description of your project requirements.');
      return;
    }

    setSubmitting(true);
    const res = await submitProjectBrief(formData);
    setSubmitting(false);

    if (res.success && res.submissionId) {
      setSuccessSubmissionId(res.submissionId);
      setFormData({
        name: '',
        email: '',
        discord: '',
        projectType: '',
        budget: '',
        timeline: '',
        description: '',
        referenceLinks: ''
      });
    } else {
      setErrorMessage(res.error || 'Failed to submit brief. Please check your network connection.');
    }
  };

  return (
    <div className="max-w-[1080px] mx-auto px-4 sm:px-6 py-8 sm:py-12 animate-fadeIn">
      {/* Top Navigation */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-mono text-cyan-400/80 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-500/20">
          Client Project Desk
        </span>
      </div>

      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          START A PROJECT
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-4 mb-3 font-['Plus_Jakarta_Sans']">
          Tell Us What You Want to Build.
        </h1>
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
          Submit your project requirements, scope preferences, budget, and references below. Our engineering team reviews each brief and responds with structured milestones.
        </p>
      </div>

      {/* Wide, Short Map of Gurgaon, Haryana, India */}
      <div className="mb-10 rounded-2xl overflow-hidden border border-cyan-500/25 shadow-[0_10px_30px_rgba(0,0,0,0.5)] bg-[#071322]">
        <div className="flex items-center justify-between px-4 py-2 bg-[#050e1a] border-b border-white/10 text-xs">
          <div className="flex items-center gap-2 text-slate-300 font-medium">
            <MapPin className="w-4 h-4 text-cyan-400" />
            <span>Studio Location: Gurgaon, Haryana, India</span>
          </div>
          <span className="text-[11px] font-mono text-cyan-400/80">Global Client Engagements</span>
        </div>
        {/* Horizontally wide, short map */}
        <div className="w-full h-44 sm:h-52 relative">
          <iframe
            title="Cubix Studio Location - Gurgaon, Haryana, India"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d112318.57242139634!2d76.953179!3d28.4594965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d19d582e38859%3A0x2cf5fe8e5c64b1e!2sGurugram%2C%20Haryana!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) contrast(110%) opacity(0.85)' }}
            allowFullScreen={false}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full h-full"
          />
        </div>
      </div>

      {/* Main Form Box */}
      <div className="max-w-3xl mx-auto">
        {successSubmissionId ? (
          <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-b from-[#081b30] to-[#040e1b] border border-cyan-400/40 shadow-[0_20px_50px_rgba(0,210,255,0.2)] text-center space-y-6 animate-fadeIn">
            <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(0,210,255,0.4)]">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">
                PROJECT BRIEF RECEIVED
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                Brief Registered Successfully
              </h2>
              <p className="text-slate-300 text-sm max-w-md mx-auto">
                Thank you for your submission. The Cubix Studio team will review your specifications and contact you via email shortly.
              </p>
            </div>

            {/* Brief Reference Receipt */}
            <div className="p-4 rounded-xl bg-black/40 border border-cyan-500/30 text-left font-mono text-sm max-w-md mx-auto space-y-2">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-white/10">
                <span className="text-slate-400">REFERENCE ID</span>
                <span className="text-cyan-300 font-bold text-sm tracking-wider">{successSubmissionId}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">STATUS</span>
                <span className="text-emerald-400 font-semibold">● Queued for Review</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">ESTIMATED RESPONSE</span>
                <span className="text-slate-200">Within 2-4 Hours</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setSuccessSubmissionId(null)}
                className="px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-all cursor-pointer"
              >
                Submit Another Project Brief
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 sm:p-9 rounded-3xl bg-[#081528]/90 border border-cyan-500/25 shadow-2xl backdrop-blur-xl">
            {errorMessage && (
              <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Row 1: Full Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="brief-name" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Full Name *
                  </label>
                  <input
                    id="brief-name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Alex Rivera"
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                  />
                </div>

                <div>
                  <label htmlFor="brief-email" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Email Address *
                  </label>
                  <input
                    id="brief-email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. alex@example.com"
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                  />
                </div>
              </div>

              {/* Row 2: Discord Username & Project Type (FREE TEXT!) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="brief-discord" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Discord Username <span className="text-slate-500 font-normal">(optional)</span>
                  </label>
                  <input
                    id="brief-discord"
                    type="text"
                    value={formData.discord}
                    onChange={(e) => setFormData({ ...formData, discord: e.target.value })}
                    placeholder="e.g. alex_username#0000"
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                  />
                </div>

                <div>
                  <label htmlFor="brief-project-type" className="block text-xs font-mono font-bold uppercase tracking-wider text-cyan-300 mb-2">
                    Project Type * <span className="text-slate-400 font-normal">(free text)</span>
                  </label>
                  <input
                    id="brief-project-type"
                    type="text"
                    required
                    value={formData.projectType}
                    onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                    placeholder="Type anything (e.g. Full-Stack Web App, Discord Bot, Minecraft Plugin, Branding)"
                    className="w-full px-4 py-3 rounded-xl bg-[#091728] border border-cyan-500/30 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
                  />
                </div>
              </div>

              {/* Row 3: Budget & Expected Timeline */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="brief-budget" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Budget <span className="text-slate-500 font-normal">(optional, in ₹ INR or $)</span>
                  </label>
                  <input
                    id="brief-budget"
                    type="text"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    placeholder="e.g. ₹50,000 or Flexible"
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                  />
                </div>

                <div>
                  <label htmlFor="brief-timeline" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Expected Timeline <span className="text-slate-500 font-normal">(optional)</span>
                  </label>
                  <input
                    id="brief-timeline"
                    type="text"
                    value={formData.timeline}
                    onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                    placeholder="e.g. 2-3 Weeks / Flexible"
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                  />
                </div>
              </div>

              {/* Row 4: Project Description */}
              <div>
                <label htmlFor="brief-description" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                  Project Description *
                </label>
                <textarea
                  id="brief-description"
                  required
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe your technical requirements, goals, features, and what you want to achieve..."
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all resize-none"
                />
              </div>

              {/* Row 5: Reference Links */}
              <div>
                <label htmlFor="brief-reference-links" className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
                  Reference Links <span className="text-slate-500 font-normal">(optional, designs, repositories, examples)</span>
                </label>
                <input
                  id="brief-reference-links"
                  type="text"
                  value={formData.referenceLinks}
                  onChange={(e) => setFormData({ ...formData, referenceLinks: e.target.value })}
                  placeholder="https://example.com/figma or https://github.com/..."
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all font-mono"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-base shadow-[0_0_25px_rgba(0,210,255,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Transmitting Project Brief...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Submit Project Brief</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-xs text-slate-400 pt-2">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Reviewed by Cubix Studio engineering team within 2-4 hours.</span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
