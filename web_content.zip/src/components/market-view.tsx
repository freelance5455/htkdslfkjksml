import { useMemo, useState } from "react";
import { TrendChart } from "@/components/charts";
import { Segment } from "@/components/ui";
import { portfolioValue } from "@/lib/calc";
import { formatIndex, formatKrw, formatPct, shortMonth } from "@/lib/format";
import { usePortfolio } from "@/lib/store";
import type { MarketPoint, Snapshot } from "@/lib/types";

type Mode = "month" | "year";

function rebase(value: number | null, base: number | null): number | null {
  if (value == null || base == null || base === 0) return null;
  return (value / base) * 100;
}

function yearEnd(points: MarketPoint[], snapshots: Snapshot[]) {
  const months = new Map<string, { fx: number; sp500: number; nasdaq: number; portfolio: number | null }>();
  for (const point of points) {
    months.set(point.month, { fx: point.fx, sp500: point.sp500, nasdaq: point.nasdaq, portfolio: null });
  }
  for (const snap of snapshots) {
    const current = months.get(snap.month) ?? { fx: Number.NaN, sp500: Number.NaN, nasdaq: Number.NaN, portfolio: null };
    current.portfolio = snap.value;
    months.set(snap.month, current);
  }
  const yearly = new Map<string, { month: string; fx: number; sp500: number; nasdaq: number; portfolio: number | null }>();
  for (const month of [...months.keys()].sort()) {
    const row = months.get(month);
    if (!row) continue;
    yearly.set(month.slice(0, 4), { month, ...row });
  }
  return [...yearly.entries()].map(([year, row]) => ({ year, ...row }));
}

function changeOver(series: number[]): number | null {
  if (series.length < 2) return null;
  const last = series[series.length - 1];
  const prev = series[Math.max(0, series.length - 13)];
  if (last == null || prev == null || prev === 0) return null;
  return ((last - prev) / prev) * 100;
}

export function MarketView() {
  const market = usePortfolio((state) => state.market);
  const snapshots = usePortfolio((state) => state.snapshots);
  const holdings = usePortfolio((state) => state.holdings);
  const [mode, setMode] = useState<Mode>("month");
  const total = portfolioValue(holdings, market.fx);
  const rows = useMemo(() => buildRows(market.history, snapshots, mode), [market.history, snapshots, mode]);
  const fxSeries = market.history.map((point) => point.fx);
  const spSeries = market.history.map((point) => point.sp500);
  const nqSeries = market.history.map((point) => point.nasdaq);
  const mineSeries = snapshots.map((point) => point.value);
  const yearly = yearEnd(market.history, snapshots);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-base font-semibold">시장과 내 자산</h2>
        <p className="text-xs text-muted">
          {market.updatedAt
            ? "최신 시세가 반영되어 있습니다."
            : "지금은 예시 시세입니다. 오른쪽 위 새로고침으로 환율, S&P500, 나스닥100, 보유 티커를 가져옵니다."}{" "}
          비교 차트는 시작을 100으로 맞춥니다.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Stat label="환율" value={`${formatIndex(market.fx)}원`} change={changeOver(fxSeries)} />
        <Stat label="S&P500" value={formatIndex(market.sp500)} change={changeOver(spSeries)} />
        <Stat label="나스닥100" value={formatIndex(market.nasdaq)} change={changeOver(nqSeries)} />
        <Stat label="내 자산" value={formatKrw(total)} change={changeOver(mineSeries)} />
      </div>
      <Segment
        value={mode}
        onChange={setMode}
        options={[
          { id: "month", label: "월별" },
          { id: "year", label: "연도별" },
        ]}
      />
      <section className="card p-4">
        <div className="mb-2 flex flex-wrap gap-3 text-xs">
          <Legend color="var(--color-c1)" label="내 자산" />
          <Legend color="var(--color-c8)" label="S&P500" />
          <Legend color="var(--color-c3)" label="나스닥100" />
          <Legend color="var(--color-c5)" label="환율" />
        </div>
        <TrendChart rows={rows} />
        <p className="mt-2 text-xs text-muted">겹치는 구간만 비교합니다. 내 자산은 매매·시세 갱신 때 그달 평가액을 남깁니다.</p>
      </section>
      {mode === "year" && yearly.length > 0 ? (
        <section className="card p-4">
          <h3 className="mb-2 text-sm font-semibold">연도 말 기준</h3>
          <ul className="space-y-3">
            {yearly.map((row, index) => {
              const prev = yearly[index - 1];
              return (
                <li key={row.year}>
                  <p className="text-sm font-medium">{row.year}</p>
                  <p className="text-xs tabular-nums text-muted">
                    환율 {fmtDelta(row.fx, prev?.fx)} · S&P {fmtDelta(row.sp500, prev?.sp500)} · 나스닥 {fmtDelta(row.nasdaq, prev?.nasdaq)}
                    {row.portfolio != null ? ` · 내 자산 ${fmtDelta(row.portfolio, prev?.portfolio ?? null)}` : ""}
                  </p>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

function buildRows(history: MarketPoint[], snapshots: Snapshot[], mode: Mode) {
  const snapMap = new Map(snapshots.map((item) => [item.month, item.value]));
  const sortedSnaps = snapshots.map((item) => item.month).sort();
  const start = sortedSnaps[0];
  const end = sortedSnaps[sortedSnaps.length - 1];
  let source = history;
  if (start && end) source = history.filter((point) => point.month >= start && point.month <= end);
  if (source.length === 0) {
    const base = snapshots[0]?.value ?? null;
    const monthly = snapshots.map((item) => ({
      label: shortMonth(item.month),
      key: item.month,
      fx: null,
      sp500: null,
      nasdaq: null,
      portfolio: rebase(item.value, base),
    }));
    if (mode === "month") return monthly;
    const byYear = new Map<string, (typeof monthly)[number]>();
    monthly.forEach((row) => byYear.set(row.key.slice(0, 4), row));
    return [...byYear.values()].map((row) => ({ ...row, label: row.key.slice(0, 4) }));
  }
  const first = source[0];
  const firstPortfolio = source.map((point) => snapMap.get(point.month)).find((value) => value != null) ?? null;
  const monthly = source.map((point) => ({
    label: shortMonth(point.month),
    key: point.month,
    fx: rebase(point.fx, first?.fx ?? null),
    sp500: rebase(point.sp500, first?.sp500 ?? null),
    nasdaq: rebase(point.nasdaq, first?.nasdaq ?? null),
    portfolio: rebase(snapMap.get(point.month) ?? null, firstPortfolio),
  }));
  if (mode === "month") return monthly;
  const byYear = new Map<string, (typeof monthly)[number]>();
  monthly.forEach((row) => byYear.set(row.key.slice(0, 4), row));
  return [...byYear.entries()].map(([year, row]) => ({ ...row, label: year }));
}

function Stat({ label, value, change }: { label: string; value: string; change: number | null }) {
  return (
    <div className="card px-3 py-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="truncate text-sm font-semibold tabular-nums">{value}</p>
      <p className={`text-xs tabular-nums ${change == null ? "text-muted" : change >= 0 ? "text-up" : "text-down"}`}>
        {change == null ? "1년 비교 없음" : `1년 ${formatPct(change)}`}
      </p>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="h-0.5 w-4" style={{ background: color }} />
      {label}
    </span>
  );
}

function fmtDelta(value: number, prev?: number | null) {
  if (!Number.isFinite(value)) return "-";
  if (prev == null || !Number.isFinite(prev) || prev === 0) return formatIndex(value);
  return formatPct(((value - prev) / prev) * 100);
}
