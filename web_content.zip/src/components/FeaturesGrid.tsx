import React from 'react';
import { SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { 
  ShieldCheck, 
  Zap, 
  Sparkles, 
  Music2, 
  Smartphone, 
  Infinity 
} from 'lucide-react';

interface FeaturesGridProps {
  currentLang: SupportedLanguage;
}

export const FeaturesGrid: React.FC<FeaturesGridProps> = ({ currentLang }) => {
  const t = translations[currentLang];

  const features = [
    {
      title: 'No Watermark Guarantee',
      desc: 'Remove the TikTok watermark logo and creator ID completely from all videos.',
      icon: ShieldCheck,
      color: 'from-cyan-500 to-blue-500',
    },
    {
      title: 'Ultra Fast Conversion',
      desc: 'Instant processing within 1-2 seconds with zero waiting queues or throttling.',
      icon: Zap,
      color: 'from-amber-400 to-orange-500',
    },
    {
      title: 'Original Full HD Quality',
      desc: 'Download videos in crystal clear 1080p and 720p without lossy compression.',
      icon: Sparkles,
      color: 'from-sky-400 to-cyan-500',
    },
    {
      title: 'Extract TikTok MP3 Audio',
      desc: 'Save background music, sounds, and vocal tracks into high quality 320kbps MP3.',
      icon: Music2,
      color: 'from-emerald-400 to-teal-500',
    },
    {
      title: 'Works on All Devices',
      desc: 'Fully compatible with Android, iPhone (iOS), iPad, PC, Mac, and Linux browsers.',
      icon: Smartphone,
      color: 'from-purple-400 to-indigo-500',
    },
    {
      title: '100% Free & Unlimited',
      desc: 'No account registration, no app downloads, and no limits on daily conversions.',
      icon: Infinity,
      color: 'from-rose-400 to-pink-500',
    },
  ];

  return (
    <section id="features" className="py-16 sm:py-24 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-6 hidden">
          <h2 className="hidden text-2xl sm:text-4xl font-black text-white tracking-tight">
            {t.featuresTitle}
          </h2>
          <p className="hidden text-slate-400 text-sm sm:text-base mt-3">
            {t.featuresSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className={`bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700 p-6 rounded-2xl transition-all duration-200 group ${
                  idx === 1 || idx === 4 ? 'hidden' : ''
                }`}
              >
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${feat.color} flex items-center justify-center text-slate-950 font-bold mb-4 shadow-md group-hover:scale-105 transition-transform`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-base font-bold text-white mb-2">
                  {feat.title}
                </h3>
                <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
