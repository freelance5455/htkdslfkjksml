import { Pause, Play, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { playSfx, setMuted, unlockAudio } from "../game/audio";
import { render } from "../game/draw";
import {
  BOARD_H,
  BOARD_W,
  DEATH_Y,
  aimAt,
  canShoot,
  createMatch,
  drainEvents,
  lowestBubbleY,
  persist,
  shoot,
  startLevel,
  swapBalls,
  tick,
  togglePause,
  type GameState,
  type Phase,
} from "../game/engine";

type Hud = {
  phase: Phase;
  score: number;
  best: number;
  level: number;
  shotsLeft: number;
  shotsMax: number;
  current: number;
  next: number;
  left: number;
  danger: boolean;
  hint: boolean;
  rev: number;
};

function snapshot(state: GameState): Hud {
  const low = lowestBubbleY(state);
  return {
    phase: state.phase,
    score: state.score,
    best: state.best,
    level: state.level,
    shotsLeft: state.shotsLeft,
    shotsMax: state.shotsMax,
    current: state.current,
    next: state.next,
    left: state.bubbles.length,
    danger: state.phase === "playing" && low > DEATH_Y - 78,
    hint: state.hint,
    rev: state.rev,
  };
}

type Layout = { scale: number; ox: number; oy: number };

export function BubblePop() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<GameState | null>(null);
  const layoutRef = useRef<Layout>({ scale: 1, ox: 0, oy: 0 });
  const muteRef = useRef(false);
  const armedRef = useRef(false);
  const [hud, setHud] = useState<Hud | null>(null);
  const [mute, setMute] = useState(false);

  useEffect(() => {
    const state = createMatch();
    state.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const savedMute = window.localStorage.getItem("bubble-pop-v1");
    if (savedMute) {
      try {
        const parsed = JSON.parse(savedMute) as { mute?: boolean };
        muteRef.current = parsed.mute === true;
      } catch {
        muteRef.current = false;
      }
    }
    stateRef.current = state;
    setMute(muteRef.current);
    setMuted(muteRef.current);
    setHud(snapshot(state));

    const keys = new Set<string>();
    let frame = 0;
    let last = performance.now();
    let seen = state.rev;
    let alive = true;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.repeat) return;
      keys.add(event.code);
      const current = stateRef.current;
      if (!current) return;
      if (["Space", "ArrowUp", "ArrowLeft", "ArrowRight", "Enter"].includes(event.code)) {
        event.preventDefault();
      }
      if (event.code === "KeyM") {
        flipMute();
        return;
      }
      if (event.code === "KeyP") {
        togglePause(current);
        return;
      }
      if (event.code === "KeyS") {
        unlockAudio();
        swapBalls(current);
        return;
      }
      if (event.code === "Space" || event.code === "Enter" || event.code === "ArrowUp") {
        unlockAudio();
        if (current.phase === "menu" || current.phase === "over") startLevel(current, "new");
        else if (current.phase === "cleared") startLevel(current, "next");
        else if (current.phase === "paused") togglePause(current);
        else shoot(current);
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      keys.delete(event.code);
    };

    const loop = (now: number) => {
      if (!alive) return;
      const current = stateRef.current;
      const canvas = canvasRef.current;
      if (!current || !canvas) {
        frame = requestAnimationFrame(loop);
        return;
      }
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (current.phase === "playing" && canShoot(current)) {
        if (keys.has("ArrowLeft") || keys.has("KeyA")) {
          current.angle = Math.max(-Math.PI + 0.16, current.angle - 1.8 * dt);
        }
        if (keys.has("ArrowRight") || keys.has("KeyD")) {
          current.angle = Math.min(-0.16, current.angle + 1.8 * dt);
        }
      }
      tick(current, dt);
      for (const name of drainEvents(current)) playSfx(name);
      paint(canvas, current);
      if (current.rev !== seen) {
        seen = current.rev;
        setHud(snapshot(current));
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    const api = {
      start: () => {
        const current = stateRef.current;
        if (current) startLevel(current, "new");
      },
      shoot: (degFromUp: number) => {
        const current = stateRef.current;
        if (!current) return false;
        if (current.phase !== "playing") startLevel(current, "new");
        current.angle = -Math.PI / 2 + (degFromUp * Math.PI) / 180;
        return shoot(current);
      },
      tick: (dt: number) => {
        const current = stateRef.current;
        if (current) tick(current, dt);
      },
      get: () => {
        const current = stateRef.current;
        if (!current) return null;
        return {
          phase: current.phase,
          score: current.score,
          bubbles: current.bubbles.length,
          level: current.level,
          shotsLeft: current.shotsLeft,
          flying: Boolean(current.flying),
        };
      },
    };
    (window as unknown as { __bubble?: typeof api }).__bubble = api;

    return () => {
      alive = false;
      cancelAnimationFrame(frame);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, []);

  function flipMute() {
    muteRef.current = !muteRef.current;
    setMute(muteRef.current);
    setMuted(muteRef.current);
    const current = stateRef.current;
    if (current) persist(current.best, muteRef.current);
  }

  function paint(canvas: HTMLCanvasElement, state: GameState) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    if (cssW < 2 || cssH < 2) return;
    const nextW = Math.round(cssW * dpr);
    const nextH = Math.round(cssH * dpr);
    if (canvas.width !== nextW || canvas.height !== nextH) {
      canvas.width = nextW;
      canvas.height = nextH;
    }
    const scale = Math.min(cssW / BOARD_W, cssH / BOARD_H);
    const ox = (cssW - BOARD_W * scale) / 2;
    const oy = (cssH - BOARD_H * scale) / 2;
    layoutRef.current = { scale, ox, oy };
    ctx.setTransform(dpr * scale, 0, 0, dpr * scale, dpr * ox, dpr * oy);
    render(ctx, state);
  }

  function point(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    const layout = layoutRef.current;
    if (!canvas || layout.scale <= 0) return null;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left - layout.ox) / layout.scale,
      y: (event.clientY - rect.top - layout.oy) / layout.scale,
    };
  }

  function onPointerDown(event: React.PointerEvent<HTMLCanvasElement>) {
    if (event.button !== 0) return;
    const state = stateRef.current;
    const at = point(event);
    if (!state || !at) return;
    unlockAudio();
    if (state.phase === "menu") return;
    if (state.phase === "paused") return;
    armedRef.current = true;
    aimAt(state, at.x, at.y);
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onPointerMove(event: React.PointerEvent<HTMLCanvasElement>) {
    const state = stateRef.current;
    const at = point(event);
    if (!state || !at) return;
    if (state.phase !== "playing") return;
    aimAt(state, at.x, at.y);
  }

  function onPointerUp(event: React.PointerEvent<HTMLCanvasElement>) {
    const state = stateRef.current;
    const at = point(event);
    if (!state || !at) return;
    if (armedRef.current && state.phase === "playing") {
      aimAt(state, at.x, at.y);
      shoot(state);
    }
    armedRef.current = false;
  }

  const phase = hud?.phase ?? "menu";

  return (
    <div className="page flex h-full justify-center">
      <div className="flex h-full w-full max-w-md flex-col bg-panel sm:my-3 sm:h-[calc(100%-1.5rem)] sm:overflow-hidden sm:rounded-3xl sm:shadow-xl sm:ring-1 sm:ring-line">
        <header className="flex items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="mark" aria-hidden="true">
              <i />
              <i />
              <i />
            </span>
            <div>
              <h1 className="text-lg leading-none font-extrabold">Bubble Pop</h1>
              <p className="text-xs font-bold text-muted">
                Level {hud?.level ?? 1}
                {hud && (phase === "playing" || phase === "paused")
                  ? ` · ${hud.left} left`
                  : ""}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xl leading-none font-extrabold tabular-nums" aria-live="polite">
              {hud?.score ?? 0}
            </p>
            <p className="text-xs font-bold text-muted">Best {hud?.best ?? 0}</p>
          </div>
        </header>

        <div className="relative min-h-0 flex-1">
          <canvas
            ref={canvasRef}
            className="h-full w-full touch-none"
            aria-label="Bubble board. Aim and release to shoot."
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={() => {
              armedRef.current = false;
            }}
          />
          {hud?.hint && phase === "playing" && (
            <p className="pointer-events-none absolute inset-x-0 top-3 text-center">
              <span className="rounded-full bg-panel px-3 py-1 text-sm font-extrabold text-ink shadow-sm ring-1 ring-line">
                Aim, then release to shoot
              </span>
            </p>
          )}
          {phase !== "playing" && (
            <div className="absolute inset-0 flex items-center justify-center bg-ink/25 p-4">
              <div className="w-full max-w-sm rounded-3xl bg-panel p-5 shadow-lg ring-1 ring-line">
                {phase === "menu" && (
                  <>
                    <h2 className="text-2xl font-extrabold">Bubble Pop</h2>
                    <p className="mt-2 text-sm leading-relaxed font-bold text-muted">
                      Aim, shoot, and match 3 or more of the same color. Clear the
                      board before the bubbles reach the line.
                    </p>
                    <p className="mt-2 text-sm leading-relaxed font-bold text-ink">
                      तीन एक जैसे रंग मिलाओ — गुब्बारे फूट जाएँगे!
                    </p>
                    {(hud?.best ?? 0) > 0 && (
                      <p className="mt-3 text-sm font-extrabold text-accent">
                        Best score {hud?.best}
                      </p>
                    )}
                    <button
                      type="button"
                      className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink"
                      onClick={() => {
                        unlockAudio();
                        const state = stateRef.current;
                        if (state) startLevel(state, "new");
                      }}
                    >
                      <Play className="size-5" aria-hidden="true" />
                      Play
                    </button>
                  </>
                )}
                {phase === "paused" && (
                  <>
                    <h2 className="text-2xl font-extrabold">Paused</h2>
                    <p className="mt-2 text-sm font-bold text-muted">
                      Score {hud?.score ?? 0}
                    </p>
                    <button
                      type="button"
                      className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink"
                      onClick={() => {
                        const state = stateRef.current;
                        if (state) togglePause(state);
                      }}
                    >
                      <Play className="size-5" aria-hidden="true" />
                      Resume
                    </button>
                  </>
                )}
                {phase === "cleared" && (
                  <>
                    <h2 className="text-2xl font-extrabold text-good">Level clear!</h2>
                    <p className="mt-2 text-sm font-bold text-muted">
                      Score {hud?.score ?? 0}. Bonus added for a clear board.
                    </p>
                    <button
                      type="button"
                      className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink"
                      onClick={() => {
                        unlockAudio();
                        const state = stateRef.current;
                        if (state) startLevel(state, "next");
                      }}
                    >
                      Next level
                    </button>
                  </>
                )}
                {phase === "over" && (
                  <>
                    <h2 className="text-2xl font-extrabold">Board filled up</h2>
                    <p className="mt-2 text-sm font-bold text-muted">
                      The bubbles reached the line. Score {hud?.score ?? 0}.
                    </p>
                    <button
                      type="button"
                      className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink"
                      onClick={() => {
                        unlockAudio();
                        const state = stateRef.current;
                        if (state) startLevel(state, "new");
                      }}
                    >
                      <RotateCcw className="size-5" aria-hidden="true" />
                      Play again
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        <footer className="flex items-center justify-between gap-2 px-3 py-3">
          <button
            type="button"
            className="swatch shrink-0"
            data-color={hud?.next ?? 1}
            aria-label="Swap with the next bubble"
            onClick={() => {
              unlockAudio();
              const state = stateRef.current;
              if (state) swapBalls(state);
            }}
          />
          <div className="flex min-w-0 flex-col items-center gap-1">
            <span className="text-xs font-extrabold text-muted">
              Ceiling in {hud?.shotsLeft ?? 8}
            </span>
            <div className="flex flex-wrap justify-center gap-1" aria-hidden="true">
              {Array.from({ length: hud?.shotsMax ?? 8 }, (_, index) => (
                <span
                  key={index}
                  className={index < (hud?.shotsLeft ?? 0) ? "pip on" : "pip"}
                />
              ))}
            </div>
          </div>
          <div className="flex gap-1">
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-full bg-bg text-ink"
              aria-label={phase === "paused" ? "Resume" : "Pause"}
              onClick={() => {
                const state = stateRef.current;
                if (!state) return;
                if (state.phase === "menu") return;
                if (state.phase === "cleared" || state.phase === "over") return;
                togglePause(state);
              }}
            >
              {phase === "paused" ? (
                <Play className="size-5" aria-hidden="true" />
              ) : (
                <Pause className="size-5" aria-hidden="true" />
              )}
            </button>
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-full bg-bg text-ink"
              aria-label={mute ? "Unmute" : "Mute"}
              onClick={() => {
                unlockAudio();
                flipMute();
              }}
            >
              {mute ? (
                <VolumeX className="size-5" aria-hidden="true" />
              ) : (
                <Volume2 className="size-5" aria-hidden="true" />
              )}
            </button>
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-full bg-bg text-ink"
              aria-label="Restart"
              onClick={() => {
                unlockAudio();
                const state = stateRef.current;
                if (state) startLevel(state, "new");
              }}
            >
              <RotateCcw className="size-5" aria-hidden="true" />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}
