import React, { useState } from 'react';
import { BusinessProfile } from '../types/business';
import { StorageService } from '../db/storage';
import { DEVELOPER_INFO } from '../utils/developerInfo';
import { Building2, User, Phone, MapPin, Upload, Camera, CheckCircle2, ArrowRight } from 'lucide-react';

interface BusinessSetupProps {
  onComplete: (profile: BusinessProfile) => void;
  lang?: 'bn' | 'en';
}

export const BusinessSetup: React.FC<BusinessSetupProps> = ({ onComplete, lang = 'bn' }) => {
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState(DEVELOPER_INFO.nameBn);
  const [phone, setPhone] = useState(DEVELOPER_INFO.contactNumber);
  const [address, setAddress] = useState(DEVELOPER_INFO.addressBn);
  const [ownerPhoto, setOwnerPhoto] = useState('');
  const [businessLogo, setBusinessLogo] = useState('');
  const [error, setError] = useState('');

  // Handle image upload to Base64
  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? 'ছবির সাইজ ২MB এর কম হতে হবে' : 'Image size must be under 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setter(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim()) {
      setError(lang === 'bn' ? 'অনুগ্রহ করে প্রতিষ্ঠানের নাম লিখুন' : 'Please enter business name');
      return;
    }
    if (!phone.trim()) {
      setError(lang === 'bn' ? 'অনুগ্রহ করে মোবাইল নম্বর লিখুন' : 'Please enter phone number');
      return;
    }

    const newProfile: BusinessProfile = {
      id: `profile_${Date.now()}`,
      businessName: businessName.trim(),
      ownerName: ownerName.trim(),
      ownerPhoto: ownerPhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      businessLogo: businessLogo || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
      phone: phone.trim(),
      address: address.trim(),
      currency: '৳',
      isSetupCompleted: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    StorageService.saveBusinessProfile(newProfile);
    // Also preload standard sample LCD parts so the user can immediately experience the app
    if (StorageService.getProducts().length === 0) {
      StorageService.loadSampleMobileParts();
    }
    onComplete(newProfile);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 font-sans">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 p-6 sm:p-8 text-white text-center relative">
          <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 mx-auto flex items-center justify-center mb-3 shadow-inner">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            {lang === 'bn' ? 'ব্যবসায়িক তথ্য সেটআপ' : 'Business Setup'}
          </h1>
          <p className="text-blue-100 text-sm mt-1">
            {lang === 'bn'
              ? 'মোবাইল LCD ও পার্টস ব্যবসার তথ্য ইনভয়েস ও ড্যাশবোর্ডে ব্যবহারের জন্য পূরণ করুন'
              : 'Enter your business details to be used on invoices, receipts & dashboard'}
          </p>

          <div className="mt-3 inline-block px-3.5 py-1 rounded-full bg-white/15 backdrop-blur-sm text-xs font-medium text-blue-50 border border-white/20">
            Developer: {DEVELOPER_INFO.name} • {DEVELOPER_INFO.contactNumber} • {DEVELOPER_INFO.address}
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 sm:p-8 space-y-6">
          {error && (
            <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              {error}
            </div>
          )}

          {/* Photo & Logo Uploads */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Owner Photo */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 text-center">
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                {lang === 'bn' ? 'প্রোপ্রাইটর / মালিকের ছবি' : 'Proprietor / Owner Photo'}
              </label>
              <div className="relative w-24 h-24 mx-auto mb-2 rounded-2xl overflow-hidden bg-white border-2 border-dashed border-indigo-200 flex items-center justify-center group">
                {ownerPhoto ? (
                  <img src={ownerPhoto} alt="Owner" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-10 h-10 text-slate-400 group-hover:text-indigo-500 transition-colors" />
                )}
                <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity text-white text-xs font-medium">
                  <Camera className="w-5 h-5" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, setOwnerPhoto)}
                  />
                </label>
              </div>
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-medium cursor-pointer shadow-sm hover:bg-slate-100">
                <Upload className="w-3.5 h-3.5" />
                {ownerPhoto ? (lang === 'bn' ? 'পরিবর্তন' : 'Change') : (lang === 'bn' ? 'ছবি আপলোড' : 'Upload')}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleImageUpload(e, setOwnerPhoto)}
                />
              </label>
            </div>

            {/* Business Logo */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 text-center">
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                {lang === 'bn' ? 'প্রতিষ্ঠানের লোগো' : 'Business Logo'}
              </label>
              <div className="relative w-24 h-24 mx-auto mb-2 rounded-2xl overflow-hidden bg-white border-2 border-dashed border-blue-200 flex items-center justify-center group">
                {businessLogo ? (
                  <img src={businessLogo} alt="Logo" className="w-full h-full object-contain p-1" />
                ) : (
                  <Building2 className="w-10 h-10 text-slate-400 group-hover:text-blue-500 transition-colors" />
                )}
                <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity text-white text-xs font-medium">
                  <Camera className="w-5 h-5" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, setBusinessLogo)}
                  />
                </label>
              </div>
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-medium cursor-pointer shadow-sm hover:bg-slate-100">
                <Upload className="w-3.5 h-3.5" />
                {businessLogo ? (lang === 'bn' ? 'পরিবর্তন' : 'Change') : (lang === 'bn' ? 'লোগো আপলোড' : 'Upload')}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleImageUpload(e, setBusinessLogo)}
                />
              </label>
            </div>
          </div>

          {/* Business Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {lang === 'bn' ? 'প্রতিষ্ঠানের নাম *' : 'Business Name *'}
            </label>
            <div className="relative">
              <Building2 className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: আহমেদ টেলিকম ও এলসিডি পার্টস' : 'e.g. Ahmed Telecom & LCD Parts'}
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 font-medium text-sm bg-slate-50/50 hover:bg-white transition-colors"
              />
            </div>
          </div>

          {/* Owner Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {lang === 'bn' ? 'মালিক / প্রোপ্রাইটর এর নাম' : 'Owner / Proprietor Name'}
            </label>
            <div className="relative">
              <User className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="জায়েদ আহমেদ"
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 font-medium text-sm bg-slate-50/50 hover:bg-white transition-colors"
              />
            </div>
          </div>

          {/* Phone Number */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Phone Number *'}
            </label>
            <div className="relative">
              <Phone className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017xxxxxxxx"
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 font-medium text-sm bg-slate-50/50 hover:bg-white transition-colors"
              />
            </div>
          </div>

          {/* Address / Location */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {lang === 'bn' ? 'ঠিকানা / লোকেশন' : 'Address / Location'}
            </label>
            <div className="relative">
              <MapPin className="w-5 h-5 absolute left-3.5 top-3.5 text-slate-400" />
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={lang === 'bn' ? 'বালাগঞ্জ, সিলেট, বাংলাদেশ' : 'Balaganj, Sylhet, Bangladesh'}
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 font-medium text-sm bg-slate-50/50 hover:bg-white transition-colors resize-none"
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-base shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
          >
            <span>{lang === 'bn' ? 'সংরক্ষণ করুন / এগিয়ে যান' : 'Save & Continue'}</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
