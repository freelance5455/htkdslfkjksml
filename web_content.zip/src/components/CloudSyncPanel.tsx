import React, { useState } from 'react';
import {
  CheckCircle2,
  Cloud,
  CloudOff,
  Loader2,
  LogOut,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import type { SyncDiffSummary } from '../utils/cloudSync';

interface CloudSyncPanelProps {
  user: User | null;
  hasAccessToken: boolean;
  isOnline: boolean;
  pendingCount: number;
  lastSyncedAt: number | null;
  isSyncing: boolean;
  syncMessage: string | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onCheckAndSync: () => void;
  onRequestDeleteCloud: () => void;
}

export const CloudSyncPanel: React.FC<CloudSyncPanelProps> = ({
  user,
  hasAccessToken,
  isOnline,
  pendingCount,
  lastSyncedAt,
  isSyncing,
  syncMessage,
  onSignIn,
  onSignOut,
  onCheckAndSync,
  onRequestDeleteCloud,
}) => {
  const lastSyncStr = lastSyncedAt
    ? new Date(lastSyncedAt).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : 'Never synced';

  return (
    <section className="space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
            Cross-Device Metadata Sync
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Sync read status, current page, scroll position, and bookmarks via your private Google Drive app folder.
          </p>
        </div>
        <div className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 shrink-0">
          {pendingCount > 0 ? `${pendingCount} queued` : 'In sync'}
        </div>
      </div>

      {!user || !hasAccessToken ? (
        <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/70 border border-zinc-200/80 dark:border-zinc-800 space-y-3">
          <div className="flex items-center gap-2.5 text-sm text-zinc-700 dark:text-zinc-300">
            <Cloud className="w-4 h-4 shrink-0 text-zinc-500" />
            <span>
              {user && !hasAccessToken
                ? `Signed in as ${user.email || user.displayName}. Re-connect Google Drive to resume syncing.`
                : 'Connect Google Drive to keep reading progress and bookmarks synchronized across your devices.'}
            </span>
          </div>

          <button
            type="button"
            onClick={onSignIn}
            disabled={!isOnline}
            className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-xl bg-white text-[#1f1f1f] border border-[#747775]/40 shadow-sm hover:bg-zinc-50 active:scale-[0.99] transition disabled:opacity-50 text-sm font-medium"
          >
            <svg
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 48 48"
              className="w-5 h-5 shrink-0 block"
            >
              <path
                fill="#EA4335"
                d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
              />
              <path
                fill="#4285F4"
                d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
              />
              <path
                fill="#FBBC05"
                d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
              />
              <path
                fill="#34A853"
                d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
              />
              <path fill="none" d="M0 0h48v48H0z" />
            </svg>
            <span>Sign in with Google</span>
          </button>
          {!isOnline && (
            <p className="text-xs text-amber-600 dark:text-amber-400">
              Currently offline. Your local reading progress is queued and ready to sync when online.
            </p>
          )}
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/70 border border-zinc-200/80 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                {user.displayName || user.email}
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono-nums truncate">
                Google Drive App Folder · Last sync: {lastSyncStr}
              </p>
            </div>
            <button
              type="button"
              onClick={onSignOut}
              className="min-h-[40px] px-3 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 inline-flex items-center gap-1.5 shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onCheckAndSync}
              disabled={!isOnline || isSyncing}
              className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-white inline-flex items-center gap-2 transition-opacity hover:opacity-90 disabled:opacity-50"
              style={{ backgroundColor: 'var(--app-accent)' }}
            >
              {isSyncing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isOnline ? (
                <RefreshCw className="w-4 h-4" />
              ) : (
                <CloudOff className="w-4 h-4" />
              )}
              <span>
                {isSyncing
                  ? 'Checking Drive…'
                  : !isOnline
                    ? 'Offline · Queued Locally'
                    : pendingCount > 0
                      ? `Sync Now (${pendingCount} pending)`
                      : 'Sync Now'}
              </span>
            </button>

            <button
              type="button"
              onClick={onRequestDeleteCloud}
              disabled={!isOnline || isSyncing}
              className="min-h-[44px] px-3.5 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Cloud Backup</span>
            </button>
          </div>

          {syncMessage && (
            <div className="flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-300">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--app-accent)' }} />
              <span>{syncMessage}</span>
            </div>
          )}
        </div>
      )}
    </section>
  );
};

interface SyncConfirmDialogProps {
  mode: 'push' | 'delete' | null;
  diff: SyncDiffSummary | null;
  busy: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const SyncConfirmDialog: React.FC<SyncConfirmDialogProps> = ({
  mode,
  diff,
  busy,
  onConfirm,
  onCancel,
}) => {
  const [showTitles, setShowTitles] = useState(false);

  if (!mode) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 shadow-2xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {mode === 'push' && diff ? (
          <>
            <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
              Update Google Drive Sync Data?
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
              {diff.remoteFileId
                ? `Update your existing cloud metadata file (koma-reader-sync-v1.json) in Google Drive with ${diff.pushedCount} local comic update(s)?`
                : `Create koma-reader-sync-v1.json in your private Google Drive app folder with ${diff.pushedCount} comic progress record(s)?`}
            </p>
            {diff.pushedTitles.length > 0 && (
              <div className="rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/70 dark:border-zinc-800 p-3 text-xs text-zinc-600 dark:text-zinc-300 space-y-1">
                <button
                  type="button"
                  onClick={() => setShowTitles((v) => !v)}
                  className="font-medium text-zinc-800 dark:text-zinc-200 underline-offset-2 hover:underline"
                >
                  {showTitles
                    ? 'Hide affected comics'
                    : `View ${diff.pushedTitles.length} affected comic(s)`}
                </button>
                {showTitles && (
                  <ul className="pt-1 space-y-0.5 max-h-32 overflow-y-auto">
                    {diff.pushedTitles.map((t, i) => (
                      <li key={`${t}-${i}`} className="truncate">
                        • {t}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onCancel}
                disabled={busy}
                className="min-h-[44px] px-4 rounded-xl border border-zinc-200 dark:border-zinc-700 text-sm font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={onConfirm}
                disabled={busy}
                className="min-h-[44px] px-4 rounded-xl text-sm font-medium text-white inline-flex items-center gap-2 disabled:opacity-60"
                style={{ backgroundColor: 'var(--app-accent)' }}
              >
                {busy && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Confirm &amp; Sync</span>
              </button>
            </div>
          </>
        ) : (
          <>
            <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
              Delete Cloud Sync Data from Google Drive?
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
              This will permanently remove <strong>koma-reader-sync-v1.json</strong> from your Google Drive app folder. Your local comics, folders, and reading progress on this device will remain untouched.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onCancel}
                disabled={busy}
                className="min-h-[44px] px-4 rounded-xl border border-zinc-200 dark:border-zinc-700 text-sm font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={onConfirm}
                disabled={busy}
                className="min-h-[44px] px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-sm font-medium text-white inline-flex items-center gap-2 disabled:opacity-60"
              >
                {busy && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Delete Cloud Data</span>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
