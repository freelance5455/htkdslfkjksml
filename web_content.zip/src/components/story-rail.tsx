import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { useDesk, useUi } from "@/lib/desk-store";
import {
  GENRES,
  GENRE_LABEL,
  blankStory,
  slugify,
  storyWords,
  uid,
  type Genre,
  type Pov,
  type Pronouns,
  type Story,
  type Tense,
} from "@/lib/story";

function Label({ children }: { children: string }) {
  return <h2 className="font-serif text-lg italic">{children}</h2>;
}

export function StoryRail() {
  const focus = useUi((state) => state.focus);
  const pane = useUi((state) => state.pane);
  const stories = useDesk((state) => state.stories);
  const activeId = useDesk((state) => state.activeId);
  const story = stories.find((item) => item.id === activeId);
  const setActive = useDesk((state) => state.setActive);
  const patchStory = useDesk((state) => state.patchStory);
  const addStory = useDesk((state) => state.addStory);
  const deleteStory = useDesk((state) => state.deleteStory);
  const addCharacter = useDesk((state) => state.addCharacter);
  const patchCharacter = useDesk((state) => state.patchCharacter);
  const removeCharacter = useDesk((state) => state.removeCharacter);
  const addPlace = useDesk((state) => state.addPlace);
  const patchPlace = useDesk((state) => state.patchPlace);
  const removePlace = useDesk((state) => state.removePlace);
  const addThread = useDesk((state) => state.addThread);
  const patchThread = useDesk((state) => state.patchThread);
  const removeThread = useDesk((state) => state.removeThread);

  const fileRef = useRef<HTMLInputElement>(null);
  const [drafting, setDrafting] = useState(false);
  const [title, setTitle] = useState("");
  const [genre, setGenre] = useState<Genre>("literary");
  const [premise, setPremise] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [importNote, setImportNote] = useState("");

  if (!story) return null;

  return (
    <aside
      className={cn(
        "min-h-0 w-full overflow-y-auto border-line lg:w-80 lg:shrink-0 lg:border-r",
        focus ? "hidden" : pane === "desk" ? "block" : "hidden lg:block",
      )}
    >
      <div className="space-y-8 px-4 py-5">
        <section className="space-y-3">
          <Label>Stories</Label>
          <div className="max-h-64 space-y-2 overflow-y-auto">
            {stories.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActive(item.id)}
                className={cn(
                  "w-full rounded-md border px-3 py-3 text-left",
                  item.id === activeId ? "border-wax bg-sheet" : "border-line hover:border-ink",
                )}
              >
                <span className="block truncate font-serif text-lg">{item.title}</span>
                <span className="text-sm text-muted">
                  {GENRE_LABEL[item.genre]} · {storyWords(item).toLocaleString()} words
                </span>
              </button>
            ))}
          </div>
          {drafting ? (
            <form
              className="space-y-3 rounded-lg border border-line bg-sheet p-3"
              onSubmit={(event) => {
                event.preventDefault();
                addStory(blankStory({ title, genre, premise }));
                setTitle("");
                setPremise("");
                setDrafting(false);
              }}
            >
              <input
                className="field"
                aria-label="New story title"
                placeholder="Title"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
              />
              <select
                className="select"
                aria-label="Genre"
                value={genre}
                onChange={(event) => setGenre(event.target.value as Genre)}
              >
                {GENRES.map((item) => (
                  <option key={item} value={item}>
                    {GENRE_LABEL[item]}
                  </option>
                ))}
              </select>
              <textarea
                className="field min-h-24"
                aria-label="Premise"
                placeholder="What is this story about?"
                value={premise}
                onChange={(event) => setPremise(event.target.value)}
              />
              <div className="flex gap-2">
                <Button tone="wax" type="submit">
                  Create
                </Button>
                <Button tone="ghost" onClick={() => setDrafting(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          ) : (
            <Button className="w-full" onClick={() => setDrafting(true)}>
              New story
            </Button>
          )}
        </section>

        <section className="space-y-3">
          <Label>This story</Label>
          <textarea
            className="field min-h-24 font-serif"
            aria-label="Premise"
            placeholder="Premise"
            value={story.premise}
            onChange={(event) => patchStory(story.id, { premise: event.target.value })}
          />
          <select
            className="select"
            aria-label="Genre"
            value={story.genre}
            onChange={(event) => patchStory(story.id, { genre: event.target.value as Genre })}
          >
            {GENRES.map((item) => (
              <option key={item} value={item}>
                {GENRE_LABEL[item]}
              </option>
            ))}
          </select>
          <div className="grid grid-cols-2 gap-2">
            <select
              className="select"
              aria-label="Point of view"
              value={story.pov}
              onChange={(event) => patchStory(story.id, { pov: event.target.value as Pov })}
            >
              <option value="close">Close third</option>
              <option value="first">First person</option>
              <option value="second">Second person</option>
              <option value="omni">Omniscient</option>
            </select>
            <select
              className="select"
              aria-label="Tense"
              value={story.tense}
              onChange={(event) => patchStory(story.id, { tense: event.target.value as Tense })}
            >
              <option value="past">Past</option>
              <option value="present">Present</option>
            </select>
          </div>
          <div className="space-y-1">
            <Dial
              label="Frankness"
              value={story.heat}
              onChange={(heat) => patchStory(story.id, { heat })}
            />
            <Dial
              label="Shadow"
              value={story.shadow}
              onChange={(shadow) => patchStory(story.id, { shadow })}
            />
            <Dial
              label="Lyric"
              value={story.lyric}
              onChange={(lyric) => patchStory(story.id, { lyric })}
            />
            <Dial
              label="Pace"
              value={story.pace}
              onChange={(pace) => patchStory(story.id, { pace })}
            />
            <p className="text-sm leading-relaxed text-muted">
              These shape Ink. They never block the page.
            </p>
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <Label>People</Label>
            <Button tone="ghost" onClick={() => addCharacter(story.id)}>
              Add
            </Button>
          </div>
          {story.characters.map((character) => (
            <div key={character.id} className="space-y-2 rounded-lg border border-line bg-sheet p-3">
              <input
                className="field font-serif"
                aria-label="Name"
                value={character.name}
                onChange={(event) =>
                  patchCharacter(story.id, character.id, { name: event.target.value })
                }
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  className="select"
                  aria-label="Pronouns"
                  value={character.pronouns}
                  onChange={(event) =>
                    patchCharacter(story.id, character.id, {
                      pronouns: event.target.value as Pronouns,
                    })
                  }
                >
                  <option value="she">she/her</option>
                  <option value="he">he/him</option>
                  <option value="they">they/them</option>
                </select>
                <input
                  className="field"
                  aria-label="Age"
                  inputMode="numeric"
                  placeholder="Age"
                  value={character.age ?? ""}
                  onChange={(event) => {
                    const raw = event.target.value.trim();
                    if (raw === "") {
                      patchCharacter(story.id, character.id, { age: null });
                      return;
                    }
                    const age = Number(raw);
                    if (Number.isFinite(age) && age >= 0 && age < 130) {
                      patchCharacter(story.id, character.id, { age });
                    }
                  }}
                />
              </div>
              <input
                className="field"
                aria-label="Role"
                placeholder="Role"
                value={character.role}
                onChange={(event) =>
                  patchCharacter(story.id, character.id, { role: event.target.value })
                }
              />
              <input
                className="field"
                aria-label="Wants"
                placeholder="Wants"
                value={character.desire}
                onChange={(event) =>
                  patchCharacter(story.id, character.id, { desire: event.target.value })
                }
              />
              <input
                className="field"
                aria-label="Fears"
                placeholder="Fears"
                value={character.fear}
                onChange={(event) =>
                  patchCharacter(story.id, character.id, { fear: event.target.value })
                }
              />
              <input
                className="field"
                aria-label="Voice"
                placeholder="Voice — blunt, formal, soft"
                value={character.voice}
                onChange={(event) =>
                  patchCharacter(story.id, character.id, { voice: event.target.value })
                }
              />
              <Button tone="ghost" onClick={() => removeCharacter(story.id, character.id)}>
                Remove
              </Button>
            </div>
          ))}
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <Label>Places</Label>
            <Button tone="ghost" onClick={() => addPlace(story.id)}>
              Add
            </Button>
          </div>
          {story.places.map((place) => (
            <div key={place.id} className="space-y-2 rounded-lg border border-line bg-sheet p-3">
              <input
                className="field font-serif"
                aria-label="Place name"
                value={place.name}
                onChange={(event) => patchPlace(story.id, place.id, { name: event.target.value })}
              />
              <input
                className="field"
                aria-label="Place detail"
                placeholder="What it feels like"
                value={place.detail}
                onChange={(event) => patchPlace(story.id, place.id, { detail: event.target.value })}
              />
              <Button tone="ghost" onClick={() => removePlace(story.id, place.id)}>
                Remove
              </Button>
            </div>
          ))}
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <Label>Threads</Label>
            <Button tone="ghost" onClick={() => addThread(story.id)}>
              Add
            </Button>
          </div>
          {story.threads.map((thread) => (
            <div key={thread.id} className="space-y-2 rounded-lg border border-line bg-sheet p-3">
              <input
                className="field"
                aria-label="Thread"
                placeholder="An open question"
                value={thread.text}
                onChange={(event) => patchThread(story.id, thread.id, { text: event.target.value })}
              />
              <label className="flex min-h-11 items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={thread.open}
                  onChange={(event) =>
                    patchThread(story.id, thread.id, { open: event.target.checked })
                  }
                />
                Still open
              </label>
              <Button tone="ghost" onClick={() => removeThread(story.id, thread.id)}>
                Remove
              </Button>
            </div>
          ))}
        </section>

        <section className="space-y-2 border-t border-line pt-4">
          <Button className="w-full" onClick={() => downloadJson(story)}>
            Download a copy
          </Button>
          <Button className="w-full" onClick={() => fileRef.current?.click()}>
            Open a copy
          </Button>
          <input
            ref={fileRef}
            className="hidden"
            type="file"
            accept="application/json"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              try {
                const data = JSON.parse(await file.text()) as unknown;
                const loaded = storiesFromJson(data);
                if (!loaded.length) {
                  setImportNote("That file was not a Vellum story.");
                  return;
                }
                for (const item of loaded) addStory(item);
                setImportNote(`Opened ${loaded.length === 1 ? loaded[0]!.title : `${loaded.length} stories`}.`);
              } catch {
                setImportNote("Could not read that file.");
              }
            }}
          />
          {importNote ? <p className="text-sm text-muted">{importNote}</p> : null}
          {confirmDelete ? (
            <div className="flex gap-2">
              <Button
                className="flex-1"
                onClick={() => {
                  deleteStory(story.id);
                  setConfirmDelete(false);
                }}
              >
                Delete
              </Button>
              <Button tone="ghost" className="flex-1" onClick={() => setConfirmDelete(false)}>
                Keep
              </Button>
            </div>
          ) : (
            <Button tone="ghost" className="w-full" onClick={() => setConfirmDelete(true)}>
              Delete story
            </Button>
          )}
        </section>
      </div>
    </aside>
  );
}

function Dial({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="flex items-baseline justify-between gap-3 text-sm">
        <span>{label}</span>
        <span className="tabular-nums text-muted">{value}</span>
      </span>
      <input
        className="dial"
        type="range"
        min={0}
        max={100}
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function downloadJson(story: Story) {
  const blob = new Blob([JSON.stringify(story, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${slugify(story.title)}.vellum.json`;
  link.click();
  URL.revokeObjectURL(url);
}

function storiesFromJson(data: unknown): Story[] {
  const list = Array.isArray(data)
    ? data
    : data && typeof data === "object" && Array.isArray((data as { stories?: unknown }).stories)
      ? (data as { stories: unknown[] }).stories
      : [data];
  const stories: Story[] = [];
  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const raw = item as Partial<Story>;
    if (typeof raw.title !== "string" || !Array.isArray(raw.chapters)) continue;
    const story = blankStory({
      title: raw.title,
      genre: raw.genre && GENRES.includes(raw.genre) ? raw.genre : "literary",
      premise: typeof raw.premise === "string" ? raw.premise : "",
    });
    if (raw.pov === "first" || raw.pov === "second" || raw.pov === "close" || raw.pov === "omni") {
      story.pov = raw.pov;
    }
    if (raw.tense === "past" || raw.tense === "present") story.tense = raw.tense;
    story.heat = typeof raw.heat === "number" ? raw.heat : story.heat;
    story.shadow = typeof raw.shadow === "number" ? raw.shadow : story.shadow;
    story.lyric = typeof raw.lyric === "number" ? raw.lyric : story.lyric;
    story.pace = typeof raw.pace === "number" ? raw.pace : story.pace;
    if (raw.chapters.length) {
      story.chapters = raw.chapters.map((chapter, index) => ({
        id: uid(),
        title: chapter.title || `Chapter ${index + 1}`,
        body: chapter.body || "",
      }));
      story.activeChapterId = story.chapters[0]!.id;
    }
    if (Array.isArray(raw.characters)) {
      story.characters = raw.characters.map((character) => ({
        id: uid(),
        name: character.name || "Unnamed",
        pronouns: character.pronouns === "she" || character.pronouns === "he" ? character.pronouns : "they",
        role: character.role || "",
        desire: character.desire || "",
        fear: character.fear || "",
        voice: character.voice || "",
        age: typeof character.age === "number" ? character.age : null,
      }));
    }
    if (Array.isArray(raw.places)) {
      story.places = raw.places.map((place) => ({
        id: uid(),
        name: place.name || "Place",
        detail: place.detail || "",
      }));
    }
    if (Array.isArray(raw.threads)) {
      story.threads = raw.threads.map((thread) => ({
        id: uid(),
        text: thread.text || "",
        open: thread.open !== false,
      }));
    }
    stories.push(story);
  }
  return stories;
}
