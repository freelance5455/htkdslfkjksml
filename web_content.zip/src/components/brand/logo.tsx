import { cn } from "@/lib/utils";

export function NijoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("block", className)} aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="#08090d" />
      <rect x="0.75" y="0.75" width="30.5" height="30.5" rx="7.25" fill="none" stroke="#4d8dff" strokeWidth="1.5" />
      <path
        d="M9.2 23.2V8.8h3.1l7.3 9.6V8.8h3.2v14.4h-3.1l-7.3-9.6v9.6H9.2Z"
        fill="#eef1f6"
      />
      <rect x="22.4" y="21.4" width="1.7" height="4.2" rx="0.6" fill="#4d8dff" />
    </svg>
  );
}

export function NijoWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <NijoMark className={compact ? "size-8" : "size-10"} />
      <div className="leading-tight">
        <p className="font-medium tracking-tight text-fg">{compact ? "NIJO" : "NIJO MOBILE"}</p>
        {!compact ? (
          <p className="text-xs text-muted">Code Anywhere. Build Anywhere.</p>
        ) : (
          <p className="text-[10px] uppercase tracking-[0.16em] text-muted">Mobile</p>
        )}
      </div>
    </div>
  );
}
