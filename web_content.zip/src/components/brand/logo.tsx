import { cn } from "@/lib/utils";

export function BrandMark({ className, gold = true }: { className?: string; gold?: boolean }) {
  const stroke = gold ? "#C9A227" : "currentColor";
  return (
    <svg viewBox="0 0 48 48" className={cn("shrink-0", className)} aria-hidden>
      <rect width="48" height="48" rx="12" fill="#071428" />
      <rect x="1.5" y="1.5" width="45" height="45" rx="11" fill="none" stroke={stroke} strokeWidth="1.4" />
      <path
        d="M12 34 V14 L24 26 L36 14 V34"
        fill="none"
        stroke={stroke}
        strokeWidth="2.4"
        strokeLinejoin="miter"
      />
      <path d="M12 34 H36" stroke={stroke} strokeWidth="1.6" />
    </svg>
  );
}

export function Wordmark({ light = false, stacked = true }: { light?: boolean; stacked?: boolean }) {
  return (
    <div className={stacked ? "text-center" : "flex flex-col"}>
      <div
        className={cn(
          "font-display text-[1.65rem] font-semibold tracking-[0.18em] leading-none",
          light ? "text-cream" : "text-navy",
        )}
      >
        MR,KHORASANI
      </div>
      {stacked ? (
        <div className={cn("mt-2 text-[10px] tracking-[0.28em] uppercase", light ? "text-gold-2" : "text-muted")}>
          Financial Management & Accounting
        </div>
      ) : null}
    </div>
  );
}
