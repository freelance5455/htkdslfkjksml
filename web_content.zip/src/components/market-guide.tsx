import { useState } from "react";
import { ChevronDown, Info } from "lucide-react";
import { cn } from "@/lib/utils";

const TIERS = [
  { tier: "T1", range: "15k – 26k", note: "Free epic / POTW အများစု" },
  { tier: "T2", range: "50k – 70k", note: "Paid epic ၁–၃ ကတ်" },
  { tier: "T3", range: "75k – 100k", note: "Paid ၄–၆ + manager" },
  { tier: "T4", range: "130k – 250k+", note: "Full paid booster XI" },
];

export function MarketGuide() {
  const [open, setOpen] = useState(false);

  return (
    <section className="mb-5 rounded-[var(--radius-xl)] bg-surface p-4 shadow-[var(--shadow-border)]">
      <button
        type="button"
        className="flex w-full items-center justify-between gap-3 text-left"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <span className="flex items-center gap-2 text-sm font-bold text-fg">
          <Info className="size-4 text-accent" aria-hidden />
          ပေါက်စျေးတွက်ချက်မှု စံနှုန်းများ
        </span>
        <ChevronDown
          className={cn(
            "size-4 text-muted transition-transform duration-200 ease-[var(--ease-out)]",
            open && "rotate-180",
          )}
          aria-hidden
        />
      </button>

      <div
        className={cn(
          "grid transition-[grid-template-rows,opacity] duration-200 ease-[var(--ease-out)]",
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
        )}
      >
        <div className="overflow-hidden">
          <div className="mt-3 space-y-3 border-t border-border pt-3 text-sm text-muted">
            <p>
              <span className="font-bold text-fg">Free Double Booster Epics</span>{" "}
              (Costacurta, Cannavaro, Kahn, Ribery, Saviola, Daily Penalty / Event
              ကတ်များ) — အကောင့်အပြည့်ပါသော်လည်း စျေးမရပါ။ ပေါက်စျေး{" "}
              <span className="font-bold text-fg">15,000 – 26,000 MMK</span> သာရှိသည်။
            </p>
            <p>
              <span className="font-bold text-accent">Paid Booster & Special Skills</span>{" "}
              (Treasure Link Ferdinand, Blitz Curler, Bullet Header, Big Time, Capello)
              ငွေသုံးဖွင့်ရသော ကတ်များမှသာ{" "}
              <span className="font-bold text-fg">65,000 – 150,000+ MMK</span> ရရှိသည်။
            </p>
            <ul className="grid grid-cols-2 gap-2">
              {TIERS.map((row) => (
                <li
                  key={row.tier}
                  className="rounded-[var(--radius-md)] bg-surface-2 px-3 py-2"
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-display text-xs font-semibold tracking-wide text-accent">
                      {row.tier}
                    </span>
                    <span className="font-display text-xs tabular-nums text-fg">
                      {row.range}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted">{row.note}</p>
                </li>
              ))}
            </ul>
            <p className="text-xs">
              1,000 coins = +20,000 MMK · Google Dead Link ရှိပါက စျေး 50–75% လျော့သည်။
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
