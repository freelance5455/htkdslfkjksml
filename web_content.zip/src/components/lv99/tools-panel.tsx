import { useMemo, useState, type ReactNode } from "react";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import {
  countText,
  dateSpan,
  formatNumber,
  makePassword,
  prettyJson,
  tryLocal,
  utf8ToBase64,
  base64ToUtf8,
} from "@/lib/local-engine";

const field =
  "w-full rounded-xl border border-line bg-ink px-3 py-3 text-base text-fg outline-none focus-visible:border-cobalt";

function Card({
  title,
  hint,
  children,
}: {
  title: string;
  hint: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-line bg-card p-4">
      <h2 className="text-base font-semibold">{title}</h2>
      <p className="mt-1 text-sm text-muted">{hint}</p>
      <div className="mt-3 space-y-3">{children}</div>
    </section>
  );
}

function Result({ text }: { text: string }) {
  if (!text) return null;
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl bg-ink px-3 py-3 text-sm">
      <p className="whitespace-pre-wrap leading-relaxed">{text}</p>
      <button
        type="button"
        className="inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-muted hover:text-fg"
        aria-label="ফলাফল কপি"
        onClick={() => {
          void navigator.clipboard.writeText(text);
          toast("কপি হয়েছে");
        }}
      >
        <Copy className="size-4" />
      </button>
    </div>
  );
}

const LENGTH = [
  ["mm", "মিলিমিটার"],
  ["cm", "সেমি"],
  ["m", "মিটার"],
  ["km", "কিলোমিটার"],
  ["ft", "ফুট"],
  ["inch", "ইঞ্চি"],
  ["mi", "মাইল"],
] as const;

const WEIGHT = [
  ["g", "গ্রাম"],
  ["kg", "কেজি"],
  ["lb", "পাউন্ড"],
] as const;

const LAND = [
  ["shotok", "শতাংশ"],
  ["katha", "কাঠা"],
  ["bigha", "বিঘা"],
  ["acre", "একর"],
  ["sqft", "বর্গফুট"],
] as const;

export function ToolsPanel() {
  const [expr, setExpr] = useState(" (১২+৮)*৩ ");
  const math = useMemo(() => {
    const cleaned = expr.trim();
    if (!cleaned) return "";
    const hit = tryLocal(cleaned);
    return hit ? hit.replace(/^তাৎক্ষণিক হিসাব \(অনলাইন AI নয়\)\n\n/, "") : "এই অঙ্কটা পড়া যায়নি। যেমন (12+8)*3";
  }, [expr]);

  const [base, setBase] = useState("500");
  const [pct, setPct] = useState("15");
  const [pctMode, setPctMode] = useState<"of" | "off" | "up">("of");

  const [amount, setAmount] = useState("5");
  const [group, setGroup] = useState<"len" | "w" | "land">("land");
  const options = group === "len" ? LENGTH : group === "w" ? WEIGHT : LAND;
  const [fromU, setFromU] = useState("katha");
  const [toU, setToU] = useState("shotok");

  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [sample, setSample] = useState("LV99 AI এখন আরও শক্তিশালী। হিসাব, ছবি, ভয়েস — সব এক জায়গায়।");
  const [blob, setBlob] = useState('{"নাম":"LV99"}');
  const [codec, setCodec] = useState<"pretty" | "b64" | "lines">("pretty");
  const [secret, setSecret] = useState("");
  const [len, setLen] = useState(16);
  const [symbols, setSymbols] = useState(true);

  const percentText = useMemo(() => {
    const b = Number(base);
    const p = Number(pct);
    if (!Number.isFinite(b) || !Number.isFinite(p)) return "সংখ্যা দাও।";
    if (pctMode === "of") return `${formatNumber(b)}-এর ${formatNumber(p)}% = ${formatNumber((b * p) / 100)}`;
    if (pctMode === "off") {
      const saved = (b * p) / 100;
      return `ছাড় ${formatNumber(saved)}। দিতে হবে ${formatNumber(b - saved)}।`;
    }
    return `বাড়লে হবে ${formatNumber(b + (b * p) / 100)}।`;
  }, [base, pct, pctMode]);

  const unitText = useMemo(() => {
    const n = Number(amount);
    if (!Number.isFinite(n)) return "";
    const hit = tryLocal(`${n} ${fromU} to ${toU}`);
    return hit ? hit.replace(/^তাৎক্ষণিক রূপান্তর \(অনলাইন AI নয়\)\n\n/, "") : "";
  }, [amount, fromU, toU]);

  const stats = countText(sample);
  const dates = fromDate && toDate ? dateSpan(fromDate, toDate) : "";

  const transformed = useMemo(() => {
    if (codec === "pretty") {
      const res = prettyJson(blob);
      return res.ok ? res.text : res.error;
    }
    if (codec === "b64") {
      try {
        return blob.trim().match(/^[A-Za-z0-9+/=]+$/) && blob.trim().length % 4 === 0
          ? base64ToUtf8(blob)
          : utf8ToBase64(blob);
      } catch {
        return "Base64 পড়া যায়নি।";
      }
    }
    const lines = blob.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    return Array.from(new Set(lines)).sort((a, b) => a.localeCompare(b, "bn")).join("\n");
  }, [blob, codec]);

  return (
    <div className="scroll-thin flex-1 overflow-y-auto px-4 py-4">
      <div className="mx-auto grid max-w-5xl gap-3 md:grid-cols-2">
        <Card title="হিসাব" hint="যোগ, বিয়োগ, শতাংশ, বর্গমূল। বাংলা সংখ্যা চলে।">
          <input className={field} value={expr} onChange={(e) => setExpr(e.target.value)} aria-label="অঙ্ক" />
          <Result text={math.replace(/^তাৎক্ষণিক হিসাব \(অনলাইন AI নয়\)\n\n/, "")} />
        </Card>

        <Card title="শতাংশ ও ছাড়" hint="কত টাকা, কত ছাড়, কত বাড়ল।">
          <div className="grid grid-cols-2 gap-2">
            <input className={field} inputMode="decimal" value={base} onChange={(e) => setBase(e.target.value)} aria-label="মূল সংখ্যা" />
            <input className={field} inputMode="decimal" value={pct} onChange={(e) => setPct(e.target.value)} aria-label="শতাংশ" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["of", "এর শতাংশ"],
                ["off", "ছাড়"],
                ["up", "বাড়তি"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setPctMode(id)}
                className={
                  "min-h-11 rounded-xl border px-2 text-sm " +
                  (pctMode === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted")
                }
              >
                {label}
              </button>
            ))}
          </div>
          <Result text={percentText} />
        </Card>

        <Card title="একক ও জমি" hint="কাঠা, শতাংশ, বিঘা — ঢাকার ৭২০ বর্গফুট হিসাব।">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["land", "জমি"],
                ["len", "দৈর্ঘ্য"],
                ["w", "ওজন"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                className={
                  "min-h-11 rounded-xl border text-sm " +
                  (group === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted")
                }
                onClick={() => {
                  setGroup(id);
                  const next = id === "land" ? LAND : id === "len" ? LENGTH : WEIGHT;
                  setFromU(next[0][0]);
                  setToU(next[1][0]);
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <input className={field} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} aria-label="পরিমাণ" />
          <div className="grid grid-cols-2 gap-2">
            <select className={field} value={fromU} onChange={(e) => setFromU(e.target.value)} aria-label="থেকে">
              {options.map(([id, label]) => (
                <option key={id} value={id}>
                  {label}
                </option>
              ))}
            </select>
            <select className={field} value={toU} onChange={(e) => setToU(e.target.value)} aria-label="এ">
              {options.map(([id, label]) => (
                <option key={id} value={id}>
                  {label}
                </option>
              ))}
            </select>
          </div>
          <Result text={unitText.replace(/^তাৎক্ষণিক রূপান্তর \(অনলাইন AI নয়\)\n\n/, "")} />
        </Card>

        <Card title="তারিখের ফারাক" hint="দুই তারিখের মাঝে কত দিন।">
          <div className="grid grid-cols-2 gap-2">
            <input className={field} type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} aria-label="শুরু" />
            <input className={field} type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} aria-label="শেষ" />
          </div>
          <Result text={dates ?? ""} />
        </Card>

        <Card title="লেখার হিসাব" hint="শব্দ, অক্ষর, পড়ার সময়।">
          <textarea className={field + " min-h-28"} value={sample} onChange={(e) => setSample(e.target.value)} aria-label="লেখা" />
          <Result
            text={`${formatNumber(stats.words)} শব্দ · ${formatNumber(stats.chars)} অক্ষর · ${formatNumber(stats.lines)} লাইন · পড়তে প্রায় ${formatNumber(stats.minutes)} মিনিট`}
          />
        </Card>

        <Card title="JSON, Base64, তালিকা" hint="গুছিয়ে নাও, এনকোড করো, ডুপ্লিকেট বাদ দাও।">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["pretty", "JSON"],
                ["b64", "Base64"],
                ["lines", "তালিকা"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setCodec(id)}
                className={
                  "min-h-11 rounded-xl border text-sm " +
                  (codec === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted")
                }
              >
                {label}
              </button>
            ))}
          </div>
          <textarea className={field + " min-h-28 font-mono text-sm"} value={blob} onChange={(e) => setBlob(e.target.value)} aria-label="টেক্সট" />
          <Result text={transformed} />
        </Card>

        <Card title="পাসওয়ার্ড" hint="এই ডিভাইসেই তৈরি। কোথাও পাঠানো হয় না।">
          <label className="flex items-center justify-between gap-3 text-sm text-muted">
            দৈর্ঘ্য {len}
            <input
              type="range"
              min={8}
              max={48}
              value={len}
              onChange={(e) => setLen(Number(e.target.value))}
              className="w-40 accent-cobalt"
            />
          </label>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={symbols} onChange={(e) => setSymbols(e.target.checked)} />
            চিহ্ন রাখো
          </label>
          <button
            type="button"
            className="min-h-11 rounded-xl bg-cobalt px-4 text-sm font-semibold text-on-cobalt"
            onClick={() => setSecret(makePassword(len, symbols))}
          >
            নতুন পাসওয়ার্ড
          </button>
          <Result text={secret} />
        </Card>
      </div>
    </div>
  );
}
