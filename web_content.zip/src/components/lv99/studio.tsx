import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast, Toaster } from "sonner";
import {
  Briefcase,
  Calculator,
  Code2,
  Copy,
  Download,
  GraduationCap,
  ImagePlus,
  Languages,
  ListChecks,
  Menu,
  MessageSquare,
  Mic,
  PenLine,
  Plus,
  RefreshCw,
  Scan,
  Search,
  Send,
  Sparkles,
  Trash2,
  Volume2,
  Wand2,
  Wrench,
  X,
} from "lucide-react";
import { askLv99, drawLv99, errorCopy } from "@/lib/lv99-api";
import { tryLocal } from "@/lib/local-engine";
import {
  MODES,
  QUICK,
  STORAGE_KEY,
  greeting,
  homeDeck,
  parseDeck,
  type Deck,
  type ModeId,
  type StoredMsg,
  type Thread,
} from "@/lib/lv99-model";
import { RichText } from "@/components/lv99/markdown";
import { ToolsPanel } from "@/components/lv99/tools-panel";

const MODE_ICON: Record<ModeId, typeof MessageSquare> = {
  chat: MessageSquare,
  code: Code2,
  write: PenLine,
  translate: Languages,
  study: GraduationCap,
  math: Calculator,
  plan: ListChecks,
  business: Briefcase,
  vision: Scan,
  imagine: Wand2,
};

type SpeechRec = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

type Attachment =
  | { kind: "image"; name: string; dataUrl: string; thumb: string; width: number; height: number }
  | { kind: "text"; name: string; text: string };

function uid() {
  return crypto.randomUUID();
}

async function fileToImage(file: File): Promise<Extract<Attachment, { kind: "image" }>> {
  const bitmap = await createImageBitmap(file);
  const width = bitmap.width;
  const height = bitmap.height;
  const draw = (max: number, quality: number) => {
    const scale = Math.min(1, max / Math.max(width, height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas");
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", quality);
  };
  let dataUrl = draw(1280, 0.78);
  if (dataUrl.length > 2_400_000) dataUrl = draw(1024, 0.62);
  const thumb = draw(320, 0.66);
  bitmap.close();
  if (dataUrl.length > 2_500_000) throw new Error("large");
  return { kind: "image", name: file.name || "ছবি", dataUrl, thumb, width, height };
}

export function Studio({ ready }: { ready: boolean }) {
  const ask = useServerFn(askLv99);
  const draw = useServerFn(drawLv99);
  const [deck, setDeck] = useState<Deck>(homeDeck);
  const [tab, setTab] = useState<"chat" | "tools">("chat");
  const [query, setQuery] = useState("");
  const [drawer, setDrawer] = useState(false);
  const [input, setInput] = useState("");
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("AI সহকারী");
  const [listening, setListening] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [showPower, setShowPower] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<SpeechRec | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const images = useRef(new Map<string, string>());

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const parsed = saved ? parseDeck(saved) : null;
      if (parsed) setDeck(parsed);
    } catch {
      /* keep the fresh deck */
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(deck));
    } catch {
      /* storage full — chat still works this session */
    }
  }, [deck]);

  const active = deck.threads.find((t) => t.id === deck.activeId) ?? deck.threads[0]!;

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [active.messages.length, busy, tab]);

  const visibleThreads = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return deck.threads;
    return deck.threads.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.messages.some((m) => m.text.toLowerCase().includes(q)),
    );
  }, [deck.threads, query]);

  function patchActive(fn: (thread: Thread) => Thread) {
    setDeck((d) => ({
      ...d,
      threads: d.threads.map((t) => (t.id === d.activeId ? fn(t) : t)),
    }));
  }

  function setMode(mode: ModeId) {
    patchActive((t) => ({ ...t, mode }));
  }

  async function onPick(file: File) {
    if (file.type.startsWith("image/")) {
      try {
        setStatus("ছবি প্রস্তুত হচ্ছে…");
        setAttachment(await fileToImage(file));
        setStatus("ছবি যোগ করা হয়েছে");
      } catch {
        setStatus("ছবিটি পড়া যায়নি");
        toast("ছবিটি পড়া যায়নি। অন্য একটি JPEG বা PNG দাও।");
      }
      return;
    }
    const text = (await file.text()).slice(0, 12000);
    setAttachment({ kind: "text", name: file.name || "ফাইল", text });
    setStatus("ফাইল যোগ হয়েছে");
  }

  function speak(text: string) {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      setStatus("এই ব্রাউজারে উত্তর শোনানো যায় না");
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text.slice(0, 3500));
    utter.lang = /[\u0980-\u09FF]/.test(text) ? "bn-BD" : "en-US";
    window.speechSynthesis.speak(utter);
  }

  function startVoice() {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRec;
      webkitSpeechRecognition?: new () => SpeechRec;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) {
      setStatus("এই ব্রাউজারে ভয়েস টাইপিং চালু নেই");
      toast("ভয়েস চালু নেই। কিবোর্ডের মাইক্রোফোনও ব্যবহার করতে পারো।");
      return;
    }
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new Ctor();
    rec.lang = "bn-BD";
    rec.interimResults = false;
    rec.continuous = false;
    rec.onresult = (ev) => {
      const spoken = ev.results[0]?.[0]?.transcript ?? "";
      if (spoken) setInput((prev) => [prev, spoken].filter(Boolean).join(" "));
    };
    rec.onerror = () => setStatus("ভয়েস নেওয়া যায়নি");
    rec.onend = () => setListening(false);
    recRef.current = rec;
    try {
      rec.start();
      setListening(true);
      setStatus("শুনছি…");
    } catch {
      setStatus("ভয়েস চালু হয়নি");
    }
  }

  function recentImage() {
    if (active.mode !== "vision") return undefined;
    for (let i = active.messages.length - 1; i >= 0; i--) {
      const msg = active.messages[i]!;
      if (msg.role === "user" && images.current.has(msg.id)) return images.current.get(msg.id);
    }
    return undefined;
  }

  async function send() {
    const typed = input.trim();
    const fileNote =
      attachment?.kind === "text" ? `\n\n[ফাইল: ${attachment.name}]\n${attachment.text}` : "";
    const prompt = (typed + fileNote).trim();
    const image = attachment?.kind === "image" ? attachment : null;
    if ((!prompt && !image) || busy) return;

    const local =
      (active.mode === "chat" || active.mode === "math") && !image && attachment?.kind !== "text"
        ? tryLocal(prompt)
        : null;
    const userText = prompt || "এই ছবিটি দেখে কী আছে তা বাংলায় বুঝিয়ে বলো।";
    const userMsg: StoredMsg = {
      id: uid(),
      role: "user",
      text: typed || (image ? "এই ছবিটি দেখে কী আছে তা বাংলায় বুঝিয়ে বলো।" : prompt),
      thumb: image?.thumb,
    };
    if (image) images.current.set(userMsg.id, image.dataUrl);

    const prior = active.messages.filter((m) => m.id !== "greet" || active.messages.length > 1);
    const history = [...prior.filter((m) => m.id !== "greet"), userMsg].slice(-12);
    const title = active.title === "নতুন কথা" ? userText.slice(0, 42) : active.title;

    setInput("");
    setAttachment(null);
    setBusy(true);
    patchActive((t) => ({
      ...t,
      title,
      updatedAt: Date.now(),
      messages: [...t.messages.filter((m) => !(t.messages.length === 1 && m.id === "greet")), userMsg],
    }));

    if (local) {
      patchActive((t) => ({
        ...t,
        updatedAt: Date.now(),
        messages: [...t.messages, { id: uid(), role: "assistant", text: local }],
      }));
      setBusy(false);
      setStatus("তাৎক্ষণিক হিসাব");
      return;
    }

    setStatus(active.mode === "imagine" ? "ছবি তৈরি হচ্ছে…" : image ? "ছবি বিশ্লেষণ হচ্ছে…" : "উত্তর তৈরি হচ্ছে…");

    try {
      if (active.mode === "imagine") {
        const drawn = await draw({
          data: { prompt: userText, imageDataUrl: image?.dataUrl },
        });
        const text = drawn.ok
          ? image
            ? "ছবিটি বদলে দেওয়া হয়েছে।"
            : "এই ছবিটি তৈরি করা হয়েছে।"
          : errorCopy(drawn.error);
        patchActive((t) => ({
          ...t,
          updatedAt: Date.now(),
          messages: [
            ...t.messages,
            {
              id: uid(),
              role: "assistant",
              text,
              generatedUrl: drawn.ok ? drawn.url : undefined,
              error: !drawn.ok,
            },
          ],
        }));
      } else {
        const lastImage = image?.dataUrl ?? recentImage();
        const turns = history.map((m, i) => ({
          role: m.role,
          text: m.text,
          imageDataUrl: i === history.length - 1 ? lastImage : undefined,
        }));
        const reply = await ask({
          data: {
            mode: active.mode,
            depth: deck.depth,
            lang: deck.lang,
            threadId: /^[0-9a-f-]{36}$/i.test(active.id) ? active.id : undefined,
            turns,
          },
        });
        let text = reply.ok ? reply.text : errorCopy(reply.error);
        if (!reply.ok && reply.error === "credit" && image) {
          const kb = Math.max(1, Math.round((image.dataUrl.length * 0.75) / 1024));
          text += `\n\nছবি লোড হয়েছে: ${image.width}×${image.height}, প্রায় ${kb} KB। দৃশ্য বুঝতে অনলাইন AI দরকার।`;
        }
        patchActive((t) => ({
          ...t,
          updatedAt: Date.now(),
          messages: [...t.messages, { id: uid(), role: "assistant", text, error: !reply.ok }],
        }));
      }
      setStatus(ready ? "AI সহকারী" : "AI এখন অনুপলব্ধ");
    } catch {
      patchActive((t) => ({
        ...t,
        messages: [
          ...t.messages,
          { id: uid(), role: "assistant", text: errorCopy("failed"), error: true },
        ],
      }));
      setStatus("আবার চেষ্টা করো");
    } finally {
      setBusy(false);
    }
  }

  function clearChat() {
    patchActive((t) => ({
      ...t,
      title: "নতুন কথা",
      updatedAt: Date.now(),
      messages: [greeting()],
    }));
    setInput("");
    setAttachment(null);
    setStatus("চ্যাট পরিষ্কার");
  }

  function newChat() {
    const thread: Thread = {
      id: uid(),
      title: "নতুন কথা",
      updatedAt: Date.now(),
      mode: active.mode,
      messages: [greeting()],
    };
    setDeck((d) => ({ ...d, activeId: thread.id, threads: [thread, ...d.threads].slice(0, 30) }));
    setDrawer(false);
    setTab("chat");
  }

  function removeThread(id: string) {
    setDeck((d) => {
      const threads = d.threads.filter((t) => t.id !== id);
      if (threads.length === 0) return homeDeck();
      return { ...d, threads, activeId: d.activeId === id ? threads[0]!.id : d.activeId };
    });
    setConfirmDelete(null);
  }

  function exportChat() {
    const body = active.messages
      .map((m) => `${m.role === "user" ? "আপনি" : "LV99"}: ${m.text}`)
      .join("\n\n");
    const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lv99-chat.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  const showWelcome = active.messages.length <= 1 && !busy;

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg">
      <Toaster theme="dark" position="top-center" />
      <header className="border-b border-line bg-panel px-3 py-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-xl text-fg lg:hidden"
            aria-label="কথোপকথন"
            onClick={() => setDrawer(true)}
          >
            <Menu className="size-5" />
          </button>
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-cobalt text-sm font-bold text-on-cobalt">
            99
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h1 className="truncate text-lg font-bold tracking-tight">LV99 AI</h1>
              <Sparkles className="size-4 shrink-0 text-gold" aria-hidden="true" />
            </div>
            <p className="truncate text-xs text-muted">{listening ? "শুনছি…" : status}</p>
          </div>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-1 rounded-xl border border-line p-1">
          <button
            type="button"
            className={
              "min-h-11 rounded-lg text-sm font-semibold " +
              (tab === "chat" ? "bg-cobalt text-on-cobalt" : "text-muted")
            }
            onClick={() => setTab("chat")}
          >
            চ্যাট
          </button>
          <button
            type="button"
            className={
              "inline-flex min-h-11 items-center justify-center gap-1 rounded-lg text-sm font-semibold " +
              (tab === "tools" ? "bg-cobalt text-on-cobalt" : "text-muted")
            }
            onClick={() => setTab("tools")}
          >
            <Wrench className="size-4" />
            টুলস
          </button>
        </div>
      </header>

      {tab === "tools" ? (
        <ToolsPanel />
      ) : (
        <div className="flex min-h-0 flex-1">
          <ThreadRail
            className="hidden lg:flex"
            threads={visibleThreads}
            activeId={active.id}
            query={query}
            confirmDelete={confirmDelete}
            onQuery={setQuery}
            onOpen={(id) => setDeck((d) => ({ ...d, activeId: id }))}
            onNew={newChat}
            onAskDelete={setConfirmDelete}
            onDelete={removeThread}
          />
          <main className="flex min-w-0 flex-1 flex-col">
            <div className="scroll-thin flex gap-2 overflow-x-auto border-b border-line px-3 py-2">
              {MODES.map((mode) => {
                const Icon = MODE_ICON[mode.id];
                const on = active.mode === mode.id;
                return (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setMode(mode.id)}
                    className={
                      "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-3 text-sm " +
                      (on ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-card text-muted")
                    }
                  >
                    <Icon className="size-4" />
                    {mode.label}
                  </button>
                );
              })}
            </div>

            <div className="scroll-thin flex-1 overflow-y-auto px-3 py-3">
              <div className="mx-auto flex max-w-3xl flex-col gap-3">
                {showWelcome ? (
                  <Welcome
                    onImage={() => {
                      setMode("vision");
                      fileRef.current?.click();
                    }}
                    onVoice={() => {
                      setTab("chat");
                      startVoice();
                    }}
                    onMode={setMode}
                  />
                ) : null}
                {active.messages.map((msg, index) => (
                  <article
                    key={msg.id}
                    className={
                      "max-w-[92%] rounded-2xl px-3.5 py-3 text-sm " +
                      (msg.role === "user"
                        ? "ml-auto bg-cobalt text-on-cobalt"
                        : "mr-auto border border-line bg-card text-fg")
                    }
                  >
                    {msg.thumb ? (
                      <img
                        src={msg.thumb}
                        alt="পাঠানো ছবি"
                        className="mb-2 max-h-56 w-full rounded-xl object-cover"
                      />
                    ) : null}
                    {msg.generatedUrl ? (
                      <img
                        src={msg.generatedUrl}
                        alt="LV99 AI তৈরি করা ছবি"
                        className="mb-2 max-h-80 w-full rounded-xl object-contain"
                      />
                    ) : null}
                    {msg.role === "assistant" ? (
                      <RichText text={msg.text} />
                    ) : (
                      <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                    )}
                    {msg.role === "assistant" ? (
                      <div className="mt-2 flex flex-wrap gap-1">
                        <button
                          type="button"
                          className="inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-gold"
                          onClick={() => speak(msg.text)}
                        >
                          <Volume2 className="size-4" />
                          উত্তর শুনুন
                        </button>
                        <button
                          type="button"
                          className="inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted"
                          onClick={() => {
                            void navigator.clipboard.writeText(msg.text);
                            toast("কপি হয়েছে");
                          }}
                        >
                          <Copy className="size-4" />
                          কপি
                        </button>
                        {index === active.messages.length - 1 && !busy ? (
                          <button
                            type="button"
                            className="inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted"
                            onClick={() => {
                              const msgs = active.messages;
                              let lastUserIndex = -1;
                              msgs.forEach((m, i) => {
                                if (m.role === "user") lastUserIndex = i;
                              });
                              if (lastUserIndex < 0) return;
                              const lastUser = msgs[lastUserIndex]!;
                              patchActive((t) => {
                                const cut = t.messages.slice(0, lastUserIndex);
                                return { ...t, messages: cut.length > 0 ? cut : [greeting()] };
                              });
                              setInput(lastUser.text);
                            }}
                          >
                            <RefreshCw className="size-4" />
                            আবার
                          </button>
                        ) : null}
                      </div>
                    ) : null}
                  </article>
                ))}
                {busy ? (
                  <p className="text-sm text-muted" aria-live="polite">
                    LV99 AI কাজ করছে…
                  </p>
                ) : null}
                <div ref={endRef} />
              </div>
            </div>

            <div className="border-t border-line bg-panel px-3 py-2">
              <div className="mx-auto max-w-3xl">
                {showWelcome ? null : (
                  <div className="mb-2 flex gap-2 overflow-x-auto">
                    {QUICK[active.mode].map((chip) => (
                      <button
                        key={chip}
                        type="button"
                        className="min-h-11 shrink-0 rounded-full border border-line px-3 text-xs text-muted"
                        onClick={() => setInput(chip)}
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                )}
                <button
                  type="button"
                  className="mb-2 text-xs text-muted"
                  onClick={() => setShowPower((v) => !v)}
                >
                  শক্তি নিয়ন্ত্রণ · {deck.depth === "brief" ? "সংক্ষিপ্ত" : deck.depth === "deep" ? "গভীর" : "মাঝারি"} ·{" "}
                  {deck.lang === "bn" ? "বাংলা" : deck.lang === "en" ? "English" : "অটো ভাষা"}
                </button>
                {showPower ? (
                  <div className="mb-2 flex flex-wrap gap-2">
                    {(
                      [
                        ["brief", "সংক্ষিপ্ত"],
                        ["normal", "মাঝারি"],
                        ["deep", "গভীর"],
                      ] as const
                    ).map(([id, label]) => (
                      <button
                        key={id}
                        type="button"
                        className={
                          "min-h-11 rounded-full border px-3 text-xs " +
                          (deck.depth === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line text-muted")
                        }
                        onClick={() => setDeck((d) => ({ ...d, depth: id }))}
                      >
                        {label}
                      </button>
                    ))}
                    {(
                      [
                        ["auto", "অটো"],
                        ["bn", "বাংলা"],
                        ["en", "English"],
                      ] as const
                    ).map(([id, label]) => (
                      <button
                        key={id}
                        type="button"
                        className={
                          "min-h-11 rounded-full border px-3 text-xs " +
                          (deck.lang === id ? "border-gold bg-gold text-ink" : "border-line text-muted")
                        }
                        onClick={() => setDeck((d) => ({ ...d, lang: id }))}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                ) : null}
                {attachment ? (
                  <div className="mb-2 flex items-center gap-3 rounded-xl border border-line bg-card p-2">
                    {attachment.kind === "image" ? (
                      <img src={attachment.thumb} alt="" className="size-14 rounded-lg object-cover" />
                    ) : (
                      <div className="flex size-14 items-center justify-center rounded-lg bg-ink text-xs text-gold">
                        ফাইল
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">
                        {attachment.kind === "image" ? "ছবি পাঠানোর জন্য প্রস্তুত" : attachment.name}
                      </p>
                      <p className="text-xs text-muted">
                        {attachment.kind === "image"
                          ? `${attachment.width}×${attachment.height} · সাথে প্রশ্ন লিখতে পারো`
                          : "ফাইলের লেখা প্রশ্নের সাথে যাবে"}
                      </p>
                    </div>
                    <button
                      type="button"
                      className="inline-flex size-11 items-center justify-center"
                      aria-label="সংযুক্তি সরান"
                      onClick={() => setAttachment(null)}
                    >
                      <X className="size-4" />
                    </button>
                  </div>
                ) : null}
                <div className="flex items-end gap-1">
                  <button
                    type="button"
                    className="inline-flex size-11 items-center justify-center rounded-xl text-cobalt"
                    aria-label="ছবি বা ফাইল"
                    disabled={busy}
                    onClick={() => fileRef.current?.click()}
                  >
                    <ImagePlus className="size-5" />
                  </button>
                  <button
                    type="button"
                    className={
                      "inline-flex size-11 items-center justify-center rounded-xl " +
                      (listening ? "text-gold" : "text-cobalt")
                    }
                    aria-label="ভয়েস ইনপুট"
                    aria-pressed={listening}
                    disabled={busy}
                    onClick={startVoice}
                  >
                    <Mic className="size-5" />
                  </button>
                  <label className="sr-only" htmlFor="lv99-input">
                    প্রশ্ন
                  </label>
                  <textarea
                    id="lv99-input"
                    rows={1}
                    value={input}
                    disabled={busy}
                    placeholder={
                      active.mode === "imagine" ? "কী আঁকতে চাও লিখুন…" : "প্রশ্ন লিখুন… ২+২, ছবি, বা কোড"
                    }
                    className="max-h-36 min-h-11 flex-1 resize-none rounded-2xl border border-line bg-ink px-3 py-3 text-sm outline-none focus-visible:border-cobalt"
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        void send();
                      }
                    }}
                  />
                  <button
                    type="button"
                    className="inline-flex size-11 items-center justify-center rounded-full bg-cobalt text-on-cobalt disabled:opacity-40"
                    aria-label="পাঠান"
                    disabled={busy || (!input.trim() && !attachment)}
                    onClick={() => void send()}
                  >
                    <Send className="size-4" />
                  </button>
                </div>
                <div className="mt-2 flex items-center justify-between gap-2 text-xs text-muted">
                  <p>গুরুত্বপূর্ণ তথ্য যাচাই করো। তাৎক্ষণিক হিসাব লোকাল; বাকি উত্তর অনলাইন AI।</p>
                  <div className="flex shrink-0 gap-1">
                    <button type="button" className="inline-flex size-11 items-center justify-center" aria-label="এক্সপোর্ট" onClick={exportChat}>
                      <Download className="size-4" />
                    </button>
                    <button type="button" className="inline-flex size-11 items-center justify-center" aria-label="চ্যাট পরিষ্কার" onClick={clearChat}>
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      )}

      {drawer ? (
        <div className="fixed inset-0 z-20 lg:hidden">
          <button type="button" className="absolute inset-0 bg-ink/70" aria-label="বন্ধ" onClick={() => setDrawer(false)} />
          <ThreadRail
            className="absolute inset-y-0 left-0 flex w-72"
            threads={visibleThreads}
            activeId={active.id}
            query={query}
            confirmDelete={confirmDelete}
            onQuery={setQuery}
            onOpen={(id) => {
              setDeck((d) => ({ ...d, activeId: id }));
              setDrawer(false);
              setTab("chat");
            }}
            onNew={newChat}
            onAskDelete={setConfirmDelete}
            onDelete={removeThread}
          />
        </div>
      ) : null}
      <input
        ref={fileRef}
        type="file"
        accept="image/*,.txt,.md,.json,.csv,.py,.js,.ts,.tsx,.kt"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void onPick(file);
        }}
      />
    </div>
  );
}

function Welcome({
  onImage,
  onVoice,
  onMode,
}: {
  onImage: () => void;
  onVoice: () => void;
  onMode: (mode: ModeId) => void;
}) {
  return (
    <div className="space-y-3">
      <section className="rounded-3xl bg-hero p-5 text-fg">
        <div className="flex items-center gap-2">
          <Sparkles className="size-5 text-gold" />
          <h2 className="text-xl font-bold">তোমার ব্যক্তিগত AI</h2>
        </div>
        <p className="mt-2 max-w-xl text-sm leading-relaxed">
          প্রশ্ন করো, ছবি দেখাও, বাংলায় কথা বলো — এক জায়গায়। মেমরি, দশটা বিশেষজ্ঞ মোড, আর ক্রেডিট ছাড়াই হিসাব।
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onImage}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-fg px-3 text-sm font-semibold text-ink"
          >
            <ImagePlus className="size-4" />
            ছবি বুঝুন
          </button>
          <button
            type="button"
            onClick={onVoice}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-line px-3 text-sm font-semibold"
          >
            <Mic className="size-4" />
            কথা বলুন
          </button>
        </div>
      </section>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {MODES.map((mode) => {
          const Icon = MODE_ICON[mode.id];
          return (
            <button
              key={mode.id}
              type="button"
              onClick={() => onMode(mode.id)}
              className="rounded-2xl border border-line bg-card p-3 text-left"
            >
              <Icon className="size-5 text-gold" />
              <p className="mt-2 text-sm font-semibold">{mode.label}</p>
              <p className="text-xs text-muted">{mode.hint}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ThreadRail({
  className,
  threads,
  activeId,
  query,
  confirmDelete,
  onQuery,
  onOpen,
  onNew,
  onAskDelete,
  onDelete,
}: {
  className?: string;
  threads: Thread[];
  activeId: string;
  query: string;
  confirmDelete: string | null;
  onQuery: (q: string) => void;
  onOpen: (id: string) => void;
  onNew: () => void;
  onAskDelete: (id: string | null) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <aside className={"w-72 shrink-0 flex-col border-r border-line bg-panel " + (className ?? "")}>
      <div className="flex items-center gap-2 p-3">
        <button
          type="button"
          onClick={onNew}
          className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-cobalt text-sm font-semibold text-on-cobalt"
        >
          <Plus className="size-4" />
          নতুন চ্যাট
        </button>
      </div>
      <div className="px-3 pb-2">
        <div className="flex items-center gap-2 rounded-xl border border-line bg-ink px-3">
          <Search className="size-4 text-muted" />
          <input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="খুঁজুন"
            aria-label="চ্যাট খুঁজুন"
            className="min-h-11 w-full bg-transparent text-sm outline-none"
          />
        </div>
      </div>
      <div className="scroll-thin flex-1 overflow-y-auto px-2 pb-3">
        {threads.map((thread) => (
          <div
            key={thread.id}
            className={
              "mb-1 flex items-center rounded-xl " + (thread.id === activeId ? "bg-card" : "hover:bg-ink")
            }
          >
            <button type="button" onClick={() => onOpen(thread.id)} className="min-h-11 flex-1 truncate px-3 text-left text-sm">
              {thread.title}
            </button>
            {confirmDelete === thread.id ? (
              <button
                type="button"
                className="min-h-11 px-2 text-xs text-gold"
                onClick={() => onDelete(thread.id)}
              >
                মুছুন
              </button>
            ) : (
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center text-muted"
                aria-label="চ্যাট মুছুন"
                onClick={() => onAskDelete(thread.id)}
              >
                <X className="size-4" />
              </button>
            )}
          </div>
        ))}
      </div>
    </aside>
  );
}
