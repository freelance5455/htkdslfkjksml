import { useState, type ReactNode } from "react";
import { Check, Copy } from "lucide-react";

function Inline({ text }: { text: string }) {
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  let key = 0;
  while ((match = re.exec(text))) {
    if (match.index > last) nodes.push(text.slice(last, match.index));
    const token = match[0];
    if (token.startsWith("**")) {
      nodes.push(
        <strong key={key++} className="font-semibold">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("`")) {
      nodes.push(
        <code key={key++} className="rounded-md bg-ink px-1.5 py-0.5">
          {token.slice(1, -1)}
        </code>,
      );
    } else {
      const link = token.match(/^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/);
      if (link) {
        nodes.push(
          <a
            key={key++}
            href={link[2]}
            target="_blank"
            rel="noreferrer"
            className="underline decoration-gold underline-offset-2"
          >
            {link[1]}
          </a>,
        );
      }
    }
    last = match.index + token.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return <>{nodes}</>;
}

function CodeBlock({ code }: { code: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-ink">
      <div className="flex justify-end border-b border-line px-2 py-1">
        <button
          type="button"
          className="inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted hover:text-fg"
          onClick={() => {
            void navigator.clipboard.writeText(code).then(() => {
              setDone(true);
              window.setTimeout(() => setDone(false), 1200);
            });
          }}
        >
          {done ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          {done ? "কপি হয়েছে" : "কপি"}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 text-sm leading-relaxed">
        <code>{code.replace(/\n$/, "")}</code>
      </pre>
    </div>
  );
}

export function RichText({ text }: { text: string }) {
  const chunks = text.split(/```/);
  return (
    <div className="space-y-2 leading-relaxed">
      {chunks.map((chunk, index) => {
        if (index % 2 === 1) {
          const nl = chunk.indexOf("\n");
          const code = nl === -1 ? chunk : chunk.slice(nl + 1);
          return <CodeBlock key={index} code={code} />;
        }
        const lines = chunk.split("\n");
        const blocks: ReactNode[] = [];
        let list: string[] = [];
        const flush = (key: string) => {
          if (list.length === 0) return;
          blocks.push(
            <ul key={key} className="list-disc space-y-1 pl-5">
              {list.map((item, i) => (
                <li key={i}>
                  <Inline text={item} />
                </li>
              ))}
            </ul>,
          );
          list = [];
        };
        lines.forEach((line, lineIndex) => {
          const bullet = line.match(/^\s*(?:[-*]|\d+[.)])\s+(.*)$/);
          if (bullet) {
            list.push(bullet[1] ?? "");
            return;
          }
          flush(`l-${lineIndex}`);
          if (!line.trim()) return;
          const head = line.match(/^(#{1,3})\s+(.*)$/);
          if (head) {
            blocks.push(
              <p key={lineIndex} className="font-semibold text-fg">
                <Inline text={head[2] ?? ""} />
              </p>,
            );
            return;
          }
          blocks.push(
            <p key={lineIndex}>
              <Inline text={line} />
            </p>,
          );
        });
        flush("end");
        return <div key={index} className="space-y-2">{blocks}</div>;
      })}
    </div>
  );
}
