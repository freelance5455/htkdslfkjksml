import React from 'react';
import { FilterStatus } from '../types';

interface StatusFilterTabsProps {
  currentStatus: FilterStatus;
  onChange: (status: FilterStatus) => void;
  counts: {
    all: number;
    today: number;
    overdue: number;
    upcoming: number;
  };
}

export const StatusFilterTabs: React.FC<StatusFilterTabsProps> = ({
  currentStatus,
  onChange,
  counts,
}) => {
  return (
    <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-200/80 rounded-xl text-xs font-bold">
      {/* All */}
      <button
        onClick={() => onChange('all')}
        className={`py-2 px-1.5 rounded-lg flex flex-col items-center justify-center transition cursor-pointer ${
          currentStatus === 'all'
            ? 'bg-white text-slate-900 shadow-xs'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span className="truncate">सभी</span>
        <span className="text-[11px] font-extrabold text-slate-500">{counts.all}</span>
      </button>

      {/* Today */}
      <button
        onClick={() => onChange('today')}
        className={`py-2 px-1.5 rounded-lg flex flex-col items-center justify-center transition cursor-pointer relative ${
          currentStatus === 'today'
            ? 'bg-amber-500 text-white shadow-xs font-black'
            : counts.today > 0
            ? 'text-amber-800 bg-amber-100/70 hover:bg-amber-100'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span className="truncate flex items-center gap-1">
          <span>आज</span>
          {counts.today > 0 && <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping" />}
        </span>
        <span
          className={`text-[11px] font-black ${
            currentStatus === 'today' ? 'text-amber-100' : 'text-amber-700'
          }`}
        >
          {counts.today}
        </span>
      </button>

      {/* Overdue */}
      <button
        onClick={() => onChange('overdue')}
        className={`py-2 px-1.5 rounded-lg flex flex-col items-center justify-center transition cursor-pointer ${
          currentStatus === 'overdue'
            ? 'bg-rose-600 text-white shadow-xs font-black'
            : counts.overdue > 0
            ? 'text-rose-700 bg-rose-100/70 hover:bg-rose-100'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span className="truncate">बीत चुकी</span>
        <span
          className={`text-[11px] font-black ${
            currentStatus === 'overdue' ? 'text-rose-100' : 'text-rose-700'
          }`}
        >
          {counts.overdue}
        </span>
      </button>

      {/* Upcoming */}
      <button
        onClick={() => onChange('upcoming')}
        className={`py-2 px-1.5 rounded-lg flex flex-col items-center justify-center transition cursor-pointer ${
          currentStatus === 'upcoming'
            ? 'bg-emerald-600 text-white shadow-xs'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span className="truncate">आगामी</span>
        <span
          className={`text-[11px] font-extrabold ${
            currentStatus === 'upcoming' ? 'text-emerald-100' : 'text-emerald-700'
          }`}
        >
          {counts.upcoming}
        </span>
      </button>
    </div>
  );
};
