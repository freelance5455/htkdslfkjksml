import React, { useState } from 'react';
import { Alarm, AlarmSoundId, ClockTheme } from '../types/clock';
import { soundService } from '../services/soundService';
import { Plus, Trash2, Volume2, Bell, Clock, Check, X } from 'lucide-react';

interface AlarmManagerProps {
  alarms: Alarm[];
  onAddAlarm: (alarm: Omit<Alarm, 'id' | 'createdAt'>) => void;
  onToggleAlarm: (id: string) => void;
  onDeleteAlarm: (id: string) => void;
  theme: ClockTheme;
  currentTime: Date;
  hour12: boolean;
}

const SOUND_OPTIONS: { id: AlarmSoundId; label: string; desc: string }[] = [
  { id: 'chime', label: 'Harmonic Chime', desc: 'Warm acoustic bell chords' },
  { id: 'digital', label: 'Quartz Digital', desc: 'Classic pulsed alarm buzzer' },
  { id: 'marimba', label: 'Playful Marimba', desc: 'Melodic upbeat arpeggio' },
  { id: 'radar', label: 'Radar Sonar', desc: 'Resonant sonar sweep ping' },
  { id: 'zen', label: 'Zen Gong', desc: 'Singing bowl harmonic drone' },
  { id: 'energetic', label: 'Bright Wakeup', desc: 'High-energy morning fanfare' },
];

const DAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const AlarmManager: React.FC<AlarmManagerProps> = ({
  alarms,
  onAddAlarm,
  onToggleAlarm,
  onDeleteAlarm,
  theme,
  currentTime,
  hour12,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [time, setTime] = useState('07:30');
  const [label, setLabel] = useState('Morning Wakeup');
  const [selectedDays, setSelectedDays] = useState<number[]>([1, 2, 3, 4, 5]); // Weekdays default
  const [sound, setSound] = useState<AlarmSoundId>('chime');
  const [volume, setVolume] = useState(0.8);
  const [snoozeDuration, setSnoozeDuration] = useState(10);
  const [previewingSound, setPreviewingSound] = useState<string | null>(null);

  // Play preview sound
  const handlePreviewSound = (soundId: AlarmSoundId) => {
    setPreviewingSound(soundId);
    soundService.playSound(soundId, volume);
    setTimeout(() => {
      setPreviewingSound(null);
    }, 1500);
  };

  // Toggle single day
  const toggleDay = (dayIndex: number) => {
    if (selectedDays.includes(dayIndex)) {
      setSelectedDays(selectedDays.filter((d) => d !== dayIndex));
    } else {
      setSelectedDays([...selectedDays, dayIndex].sort((a, b) => a - b));
    }
  };

  // Fast preset helper
  const applyPreset = (minutesToAdd: number) => {
    const future = new Date(currentTime.getTime() + minutesToAdd * 60000);
    const hh = future.getHours().toString().padStart(2, '0');
    const mm = future.getMinutes().toString().padStart(2, '0');
    setTime(`${hh}:${mm}`);
  };

  // Submit new alarm
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddAlarm({
      time,
      label: label.trim() || 'Alarm',
      enabled: true,
      days: selectedDays,
      sound,
      volume,
      snoozeDurationMinutes: snoozeDuration,
    });
    setIsAdding(false);
    // Reset defaults for next
    setLabel('Alarm');
  };

  // Format time for 12h display
  const formatAlarmTime = (timeStr: string) => {
    if (!hour12) return timeStr;
    const [h, m] = timeStr.split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH}:${m.toString().padStart(2, '0')} ${period}`;
  };

  // Compute countdown to next alarm
  const getNextAlarmInfo = () => {
    const activeAlarms = alarms.filter((a) => a.enabled);
    if (activeAlarms.length === 0) return null;

    let nearestDiff = Infinity;
    let nearestAlarm: Alarm | null = null;
    const now = currentTime.getTime();

    activeAlarms.forEach((alarm) => {
      const [ah, am] = alarm.time.split(':').map(Number);
      
      // Check next 7 days
      for (let dayOffset = 0; dayOffset <= 7; dayOffset++) {
        const targetDate = new Date(currentTime);
        targetDate.setDate(targetDate.getDate() + dayOffset);
        targetDate.setHours(ah, am, 0, 0);

        if (targetDate.getTime() <= now) continue;

        const dayOfWeek = targetDate.getDay();
        const matchesDay = alarm.days.length === 0 || alarm.days.includes(dayOfWeek);

        if (matchesDay) {
          const diff = targetDate.getTime() - now;
          if (diff < nearestDiff) {
            nearestDiff = diff;
            nearestAlarm = alarm;
          }
          break; // nearest occurrence for this alarm found
        }
      }
    });

    if (!nearestAlarm || nearestDiff === Infinity) return null;

    const foundAlarm: Alarm = nearestAlarm;
    const diffHours = Math.floor(nearestDiff / (1000 * 60 * 60));
    const diffMins = Math.floor((nearestDiff % (1000 * 60 * 60)) / (1000 * 60));

    let countdownStr = '';
    if (diffHours > 0) {
      countdownStr = `${diffHours} hr ${diffMins} min`;
    } else {
      countdownStr = `${diffMins} min`;
    }

    return {
      alarm: foundAlarm,
      countdown: countdownStr,
      formattedTime: formatAlarmTime(foundAlarm.time),
    };
  };

  const nextAlarm = getNextAlarmInfo();

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* Next Alarm Banner */}
      {nextAlarm && (
        <div
          className="flex items-center justify-between px-5 py-3.5 rounded-xl border transition-all"
          style={{
            backgroundColor: theme.surfaceBg,
            borderColor: theme.border,
          }}
        >
          <div className="flex items-center gap-3">
            <Bell className="w-4 h-4 shrink-0" style={{ color: theme.textAccent }} />
            <div>
              <div className="text-xs uppercase tracking-wider font-semibold" style={{ color: theme.textSecondary }}>
                Next Alarm
              </div>
              <div className="text-sm font-medium" style={{ color: theme.textPrimary }}>
                {nextAlarm.formattedTime} — {nextAlarm.alarm.label}
              </div>
            </div>
          </div>
          <div className="text-xs font-mono tabular-nums px-2.5 py-1 rounded-md"
            style={{
              backgroundColor: theme.background,
              color: theme.textAccent,
              border: `1px solid ${theme.border}`,
            }}
          >
            in {nextAlarm.countdown}
          </div>
        </div>
      )}

      {/* Header bar */}
      <div className="flex items-center justify-between border-b pb-4" style={{ borderColor: theme.border }}>
        <div>
          <h2 className="text-lg font-semibold tracking-tight" style={{ color: theme.textPrimary }}>
            Alarms ({alarms.filter((a) => a.enabled).length} Active)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real audio synthesized alarms that run in your browser.
          </p>
        </div>

        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors shadow-sm"
            style={{
              backgroundColor: theme.textAccent,
              color: theme.background === '#ffffff' || theme.background === '#eae6dd' ? '#111' : '#fff',
            }}
          >
            <Plus className="w-4 h-4" />
            <span>New Alarm</span>
          </button>
        )}
      </div>

      {/* Create Alarm Form Modal / Accordion */}
      {isAdding && (
        <form
          onSubmit={handleSubmit}
          className="p-5 rounded-2xl border space-y-5 transition-all animate-fadeIn"
          style={{
            backgroundColor: theme.surfaceBg,
            borderColor: theme.border,
          }}
        >
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold uppercase tracking-wider" style={{ color: theme.textPrimary }}>
              Set New Alarm
            </h3>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="p-1 rounded-lg hover:bg-neutral-800/40 text-slate-400 hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Time Picker & Quick Presets */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-2">Alarm Time</label>
            <div className="flex flex-wrap items-center gap-3">
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="px-4 py-2.5 text-2xl font-mono tabular-nums font-bold rounded-xl border focus:outline-none focus:ring-2"
                style={{
                  backgroundColor: theme.background,
                  borderColor: theme.border,
                  color: theme.textPrimary,
                }}
              />

              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => applyPreset(5)}
                  className="px-2.5 py-1 text-xs rounded-lg border hover:bg-white/5 transition-colors text-slate-300"
                  style={{ borderColor: theme.border }}
                >
                  +5m
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset(15)}
                  className="px-2.5 py-1 text-xs rounded-lg border hover:bg-white/5 transition-colors text-slate-300"
                  style={{ borderColor: theme.border }}
                >
                  +15m
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset(30)}
                  className="px-2.5 py-1 text-xs rounded-lg border hover:bg-white/5 transition-colors text-slate-300"
                  style={{ borderColor: theme.border }}
                >
                  +30m
                </button>
                <button
                  type="button"
                  onClick={() => setTime('07:00')}
                  className="px-2.5 py-1 text-xs rounded-lg border hover:bg-white/5 transition-colors text-slate-300"
                  style={{ borderColor: theme.border }}
                >
                  7:00 AM
                </button>
                <button
                  type="button"
                  onClick={() => setTime('08:00')}
                  className="px-2.5 py-1 text-xs rounded-lg border hover:bg-white/5 transition-colors text-slate-300"
                  style={{ borderColor: theme.border }}
                >
                  8:00 AM
                </button>
              </div>
            </div>
          </div>

          {/* Label Input */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Label</label>
            <input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="e.g. Wake up, Meeting, Coffee"
              maxLength={40}
              className="w-full px-3.5 py-2 text-sm rounded-xl border focus:outline-none focus:ring-2"
              style={{
                backgroundColor: theme.background,
                borderColor: theme.border,
                color: theme.textPrimary,
              }}
            />
          </div>

          {/* Repeat Days */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-slate-400">Repeat Days</label>
              <div className="flex gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedDays([1, 2, 3, 4, 5])}
                  className="text-slate-400 hover:text-slate-200 underline"
                >
                  Weekdays
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => setSelectedDays([0, 1, 2, 3, 4, 5, 6])}
                  className="text-slate-400 hover:text-slate-200 underline"
                >
                  Daily
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => setSelectedDays([])}
                  className="text-slate-400 hover:text-slate-200 underline"
                >
                  Once
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {DAYS_SHORT.map((dayName, idx) => {
                const isSelected = selectedDays.includes(idx);
                return (
                  <button
                    key={dayName}
                    type="button"
                    onClick={() => toggleDay(idx)}
                    className="py-2 text-xs font-semibold rounded-lg border transition-all text-center"
                    style={{
                      backgroundColor: isSelected ? theme.textAccent : theme.background,
                      color: isSelected ? '#ffffff' : theme.textSecondary,
                      borderColor: isSelected ? theme.textAccent : theme.border,
                    }}
                  >
                    {dayName}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sound & Tone Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-2">Alarm Melody & Tone</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SOUND_OPTIONS.map((opt) => (
                <div
                  key={opt.id}
                  onClick={() => setSound(opt.id)}
                  className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-all ${
                    sound === opt.id ? 'ring-2' : 'hover:bg-white/5'
                  }`}
                  style={{
                    backgroundColor: theme.background,
                    borderColor: sound === opt.id ? theme.textAccent : theme.border,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-3 h-3 rounded-full border ${
                        sound === opt.id ? 'border-4' : 'border-slate-500'
                      }`}
                      style={{ borderColor: sound === opt.id ? theme.textAccent : undefined }}
                    />
                    <div>
                      <div className="text-xs font-medium" style={{ color: theme.textPrimary }}>
                        {opt.label}
                      </div>
                      <div className="text-[10px] text-slate-400">{opt.desc}</div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePreviewSound(opt.id);
                    }}
                    title="Preview sound"
                    className="p-1.5 rounded-lg hover:bg-neutral-800 text-slate-300 hover:text-white"
                  >
                    <Volume2 className={`w-3.5 h-3.5 ${previewingSound === opt.id ? 'animate-pulse text-amber-400' : ''}`} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Snooze & Volume */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                Volume ({Math.round(volume * 100)}%)
              </label>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Snooze Duration</label>
              <div className="flex gap-2">
                {[5, 10, 15].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setSnoozeDuration(mins)}
                    className="flex-1 py-1.5 text-xs font-medium rounded-lg border transition-all text-center"
                    style={{
                      backgroundColor: snoozeDuration === mins ? theme.textAccent : theme.background,
                      color: snoozeDuration === mins ? '#fff' : theme.textSecondary,
                      borderColor: snoozeDuration === mins ? theme.textAccent : theme.border,
                    }}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-3 border-t" style={{ borderColor: theme.border }}>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-xs font-medium rounded-lg hover:bg-neutral-800 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold rounded-lg shadow-sm transition-colors"
              style={{
                backgroundColor: theme.textAccent,
                color: theme.background === '#ffffff' || theme.background === '#eae6dd' ? '#111' : '#fff',
              }}
            >
              Save Alarm
            </button>
          </div>
        </form>
      )}

      {/* Alarms List */}
      <div className="space-y-2.5">
        {alarms.length === 0 ? (
          <div
            className="text-center py-12 rounded-2xl border border-dashed"
            style={{
              backgroundColor: theme.surfaceBg,
              borderColor: theme.border,
            }}
          >
            <Clock className="w-8 h-8 mx-auto mb-2 text-slate-500" />
            <h4 className="text-sm font-medium" style={{ color: theme.textPrimary }}>
              No alarms set
            </h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Set custom waking alarms with synthetic acoustic chimes, quartz beepers, or gentle zen tones.
            </p>
            <button
              onClick={() => setIsAdding(true)}
              className="mt-4 px-4 py-1.5 text-xs font-medium rounded-lg shadow-sm"
              style={{
                backgroundColor: theme.textAccent,
                color: '#fff',
              }}
            >
              Create First Alarm
            </button>
          </div>
        ) : (
          alarms.map((alarm) => {
            const daysLabel =
              alarm.days.length === 0
                ? 'Once'
                : alarm.days.length === 7
                ? 'Every day'
                : alarm.days.length === 5 && !alarm.days.includes(0) && !alarm.days.includes(6)
                ? 'Weekdays'
                : alarm.days.map((d) => DAYS_SHORT[d]).join(', ');

            return (
              <div
                key={alarm.id}
                className="flex items-center justify-between p-4 rounded-xl border transition-all"
                style={{
                  backgroundColor: theme.surfaceBg,
                  borderColor: theme.border,
                  opacity: alarm.enabled ? 1 : 0.6,
                }}
              >
                <div className="flex items-center gap-4">
                  {/* Toggle Checkbox / Pill */}
                  <button
                    type="button"
                    onClick={() => onToggleAlarm(alarm.id)}
                    className="w-11 h-6 rounded-full relative transition-colors focus:outline-none"
                    style={{
                      backgroundColor: alarm.enabled ? theme.textAccent : 'rgba(255,255,255,0.15)',
                    }}
                    title={alarm.enabled ? 'Disable alarm' : 'Enable alarm'}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                        alarm.enabled ? 'translate-x-5' : 'translate-x-0.5'
                      } mt-0.5`}
                    />
                  </button>

                  <div>
                    <div className="flex items-baseline gap-2">
                      <span
                        className="text-2xl sm:text-3xl font-mono font-bold tracking-tight tabular-nums"
                        style={{ color: theme.textPrimary }}
                      >
                        {formatAlarmTime(alarm.time)}
                      </span>
                      <span className="text-sm font-medium" style={{ color: theme.textSecondary }}>
                        {alarm.label}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{daysLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{alarm.sound} tone</span>
                      <span aria-hidden="true">·</span>
                      <span>{alarm.snoozeDurationMinutes}m snooze</span>
                    </div>
                  </div>
                </div>

                {/* Right controls */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handlePreviewSound(alarm.sound)}
                    className="p-2 rounded-lg hover:bg-neutral-800 text-slate-400 hover:text-slate-200 transition-colors"
                    title="Test alarm sound"
                  >
                    <Volume2 className={`w-4 h-4 ${previewingSound === alarm.sound ? 'text-amber-400 animate-pulse' : ''}`} />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteAlarm(alarm.id)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-colors"
                    title="Delete alarm"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
