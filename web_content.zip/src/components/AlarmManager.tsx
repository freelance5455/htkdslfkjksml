import React, { useState } from 'react';
import { Bell, Plus, Trash2, Clock, Volume2, ShieldAlert, X } from 'lucide-react';
import { Alarm } from '../types';
import { format12HourTime } from '../services/localCommandParser';

interface AlarmManagerProps {
  isOpen: boolean;
  onClose: () => void;
  alarms: Alarm[];
  onAddAlarm: (time: string, label: string) => void;
  onToggleAlarm: (id: string) => void;
  onDeleteAlarm: (id: string) => void;
  isAlarmRinging: boolean;
  onStopAlarm: () => void;
  onSnoozeAlarm: () => void;
  activeAlarmLabel?: string;
  onTestAlarm?: () => void;
}

export const AlarmManager: React.FC<AlarmManagerProps> = ({
  isOpen,
  onClose,
  alarms,
  onAddAlarm,
  onToggleAlarm,
  onDeleteAlarm,
  isAlarmRinging,
  onStopAlarm,
  onSnoozeAlarm,
  activeAlarmLabel,
  onTestAlarm,
}) => {
  const [newTime, setNewTime] = useState('06:00');
  const [newLabel, setNewLabel] = useState('Wake up, Sir');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTime) return;
    onAddAlarm(newTime, newLabel.trim() || 'Scheduled Alarm');
  };

  if (!isOpen && !isAlarmRinging) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      {/* Active Ringing Alarm Overlay */}
      {isAlarmRinging ? (
        <div className="relative w-full max-w-sm bg-gray-900 border-2 border-red-500 rounded-3xl p-6 shadow-2xl glow-red text-center animate-pulse">
          <div className="w-20 h-20 mx-auto rounded-full bg-red-950/80 border-2 border-red-400 flex items-center justify-center mb-4">
            <ShieldAlert className="w-10 h-10 text-red-400 animate-bounce" />
          </div>
          <h2 className="text-xl font-tech font-bold uppercase text-red-200">
            JARVIS WAKE PROTOCOL
          </h2>
          <p className="text-xs text-red-200/90 mt-1 italic font-medium">
            "माफ कीजिए सर, डिस्टर्ब कर रहा हूँ, पर आपका उठने का टाइम हो गया है।"
          </p>
          <div className="my-4 p-3 bg-red-950/40 rounded-xl border border-red-500/30">
            <span className="font-mono-tech text-2xl font-bold text-red-100">
              {activeAlarmLabel || 'Alarm Ringing'}
            </span>
          </div>

          <div className="flex gap-3 mt-6">
            <button
              onClick={onSnoozeAlarm}
              className="flex-1 py-3 px-4 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 font-tech text-sm uppercase transition-colors cursor-pointer"
            >
              Snooze (+5m)
            </button>
            <button
              onClick={onStopAlarm}
              className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-tech font-bold text-sm uppercase glow-red transition-colors cursor-pointer"
            >
              Dismiss Alarm
            </button>
          </div>
          <p className="text-[11px] text-red-400/80 mt-3 font-mono-tech">
            Voice Stop: "Jarvis, chup kar jao" or "Jarvis, alarm band kar do"
          </p>
        </div>
      ) : (
        /* Alarm Configuration List */
        <div className="relative w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 bg-gray-950/90 border-b border-cyan-500/30">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-cyan-400" />
              <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
                JARVIS CHRONO & ALARM CORE
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* New Alarm Form */}
          <form onSubmit={handleCreate} className="p-4 bg-gray-950/40 border-b border-cyan-500/20">
            <div className="text-xs font-tech text-cyan-300 uppercase mb-2">Configure New Alert</div>
            <div className="grid grid-cols-5 gap-2 mb-2">
              <input
                type="time"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                className="col-span-2 px-3 py-2 bg-gray-950 border border-cyan-500/40 rounded-xl text-cyan-100 font-mono-tech text-sm focus:outline-none focus:border-cyan-400"
                required
              />
              <input
                type="text"
                placeholder="Alert Label (e.g. Wake up)"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                className="col-span-3 px-3 py-2 bg-gray-950 border border-cyan-500/40 rounded-xl text-cyan-100 text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-tech font-bold uppercase text-xs rounded-xl flex items-center justify-center gap-1 glow-cyan-sm transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Alarm Protocol
            </button>
          </form>

          {/* Alarm list */}
          <div className="flex-1 p-4 overflow-y-auto space-y-2.5">
            {alarms.length === 0 ? (
              <div className="text-center py-8 text-cyan-400/50 text-xs">
                No active alarms configured. Use voice: "Jarvis, 6 baje alarm laga do"
              </div>
            ) : (
              alarms.map((alarm) => (
                <div
                  key={alarm.id}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                    alarm.enabled
                      ? 'bg-cyan-950/30 border-cyan-500/40'
                      : 'bg-gray-950/40 border-gray-800 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Clock className={`w-5 h-5 ${alarm.enabled ? 'text-cyan-400' : 'text-gray-500'}`} />
                    <div>
                      <div className="font-mono-tech text-lg font-bold text-cyan-100">
                        {format12HourTime(alarm.time)}
                      </div>
                      <div className="text-xs text-cyan-400/70">{alarm.label}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onToggleAlarm(alarm.id)}
                      className={`px-3 py-1 rounded-full text-xs font-tech font-semibold uppercase transition-colors ${
                        alarm.enabled
                          ? 'bg-cyan-500 text-gray-950'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {alarm.enabled ? 'Active' : 'Off'}
                    </button>
                    <button
                      onClick={() => onDeleteAlarm(alarm.id)}
                      className="p-1.5 text-red-400/70 hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Android limitation info note & Test Trigger */}
          <div className="p-3 bg-gray-950/80 border-t border-cyan-500/20 text-[11px] text-cyan-300/60 leading-relaxed flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div>
              <span className="font-semibold text-cyan-300">Note:</span> In browser mode, alarms require this tab to remain open. When converted to the Android APK, AlarmManager and foreground services schedule true native system alarms even when locked.
            </div>
            {onTestAlarm && (
              <button
                type="button"
                onClick={onTestAlarm}
                className="px-3 py-1.5 rounded-lg bg-red-950/70 hover:bg-red-900 border border-red-500/40 text-red-200 font-tech text-xs uppercase shrink-0 transition-all cursor-pointer flex items-center gap-1 active:scale-95"
              >
                <Volume2 className="w-3.5 h-3.5 text-red-400" />
                Test Alarm Loop
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
