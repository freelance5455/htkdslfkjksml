import React, { useState } from 'react';
import { X, PackageCheck, Printer, Calendar, MapPin } from 'lucide-react';
import { Order, CurrencyCode } from '../types';
import { formatPrice } from '../utils/currency';

interface OrderHistoryModalProps {
  isOpen: boolean;
  orders: Order[];
  activeCurrency: CurrencyCode;
  onClose: () => void;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({
  isOpen,
  orders,
  activeCurrency,
  onClose
}) => {
  if (!isOpen) return null;

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div className="flex items-center gap-2.5">
            <PackageCheck className="w-5 h-5 text-stone-800" />
            <h2 className="font-serif text-2xl font-semibold text-stone-900">
              Your Local Order History
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close orders"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-6 flex-1">
          {orders.length === 0 ? (
            <div className="py-16 text-center text-stone-500">
              <p className="font-serif text-xl text-stone-800 mb-1">No orders placed yet</p>
              <p className="text-xs text-stone-500">
                Any orders you complete using Cash on Delivery or Wire transfer will be safely stored here on your device.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 hover:bg-stone-50 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-stone-200 text-xs">
                    <div>
                      <span className="font-bold text-stone-900">{order.trackingNumber}</span>
                      <span className="text-stone-400 mx-2">·</span>
                      <span className="text-stone-500">{order.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-100 text-emerald-800">
                        {order.status}
                      </span>
                      <span className="text-stone-400">·</span>
                      <span className="font-bold text-stone-900 tabular-nums">
                        {formatPrice(order.total, activeCurrency)}
                      </span>
                    </div>
                  </div>

                  <div className="py-3 text-xs text-stone-600 space-y-1">
                    <p className="font-semibold text-stone-800">
                      {order.items.length} {order.items.length === 1 ? 'item' : 'items'}:
                    </p>
                    <div className="flex flex-wrap gap-2 text-[11px]">
                      {order.items.map((i) => (
                        <span key={i.product.id} className="bg-white border border-stone-200 px-2 py-0.5 rounded text-stone-700">
                          {i.quantity}× {i.product.name}
                        </span>
                      ))}
                    </div>
                    <p className="text-[11px] text-stone-500 pt-1">
                      Shipping to: {order.customer.fullName}, {order.customer.city} · Payment: {order.paymentMethod}
                    </p>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="px-3 py-1.5 bg-white border border-stone-300 text-stone-800 rounded-lg text-xs font-medium hover:bg-stone-100 cursor-pointer flex items-center gap-1.5"
                    >
                      <Printer className="w-3.5 h-3.5 text-stone-600" />
                      <span>View & Print Invoice</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected order print modal overlay if viewing invoice */}
        {selectedOrder && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-900/70">
            <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
              <div className="flex justify-between items-start border-b border-stone-200 pb-3">
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-900">BAIT UL UKASHA</h3>
                  <p className="text-xs text-stone-500">Official Order Invoice</p>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1 text-stone-400 hover:text-stone-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="text-xs space-y-2 text-stone-700">
                <div className="flex justify-between">
                  <span>Tracking Code:</span>
                  <span className="font-mono font-bold text-stone-900">{selectedOrder.trackingNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{selectedOrder.date}</span>
                </div>
                <div className="flex justify-between">
                  <span>Recipient:</span>
                  <span>{selectedOrder.customer.fullName} ({selectedOrder.customer.phone})</span>
                </div>
                <div className="flex justify-between">
                  <span>Address:</span>
                  <span>{selectedOrder.customer.address}, {selectedOrder.customer.city}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment:</span>
                  <span>{selectedOrder.paymentMethod}</span>
                </div>

                <div className="border-t border-stone-200 pt-2 space-y-1">
                  <span className="font-semibold block">Purchased Items:</span>
                  {selectedOrder.items.map((it) => (
                    <div key={it.product.id} className="flex justify-between text-stone-600">
                      <span>{it.quantity}× {it.product.name}</span>
                      <span className="tabular-nums">{formatPrice(it.product.priceUsd * it.quantity, activeCurrency)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-stone-200 pt-2 flex justify-between font-bold text-stone-900 text-sm">
                  <span>Total Paid/Due:</span>
                  <span className="tabular-nums">{formatPrice(selectedOrder.total, activeCurrency)}</span>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Receipt</span>
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
