import React, { useState, useRef } from 'react';
import { SentimentDataPoint } from '../types';
import { Sparkles, TrendingUp, AlertCircle, CheckCircle2, HelpCircle } from 'lucide-react';

interface SentimentGraphProps {
  timeline: SentimentDataPoint[];
  currentTime: number;
  duration: number;
  onSeek: (seconds: number) => void;
}

export const SentimentGraph: React.FC<SentimentGraphProps> = ({
  timeline,
  currentTime,
  duration,
  onSeek,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredPoint, setHoveredPoint] = useState<SentimentDataPoint | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);

  const width = 800;
  const height = 240;
  const padding = { top: 25, right: 30, bottom: 40, left: 45 };
  const graphWidth = width - padding.left - padding.right;
  const graphHeight = height - padding.top - padding.bottom;

  const maxDuration = Math.max(duration, timeline[timeline.length - 1]?.timeSeconds || 1);

  // Map data to SVG coordinates
  const points = timeline.map((d) => {
    const x = padding.left + (d.timeSeconds / maxDuration) * graphWidth;
    // Invert Y so 100 is at the top
    const y = padding.top + (1 - d.engagementScore / 100) * graphHeight;
    return { ...d, x, y };
  });

  // Generate smooth SVG curve path
  const generatePath = () => {
    if (points.length === 0) return '';
    if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;

    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i];
      const p1 = points[i + 1];
      const cpX1 = p0.x + (p1.x - p0.x) * 0.5;
      const cpY1 = p0.y;
      const cpX2 = p0.x + (p1.x - p0.x) * 0.5;
      const cpY2 = p1.y;
      d += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${p1.x} ${p1.y}`;
    }
    return d;
  };

  const linePath = generatePath();
  const areaPath = points.length > 0
    ? `${linePath} L ${points[points.length - 1].x} ${height - padding.bottom} L ${points[0].x} ${height - padding.bottom} Z`
    : '';

  // Current scrubber position in pixels
  const scrubberX = padding.left + Math.min(1, Math.max(0, currentTime / maxDuration)) * graphWidth;

  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const normalizedX = (clickX - padding.left) / graphWidth;
    const clampedRatio = Math.max(0, Math.min(1, normalizedX));
    const targetSeconds = clampedRatio * maxDuration;
    onSeek(targetSeconds);
  };

  const formatSec = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl relative overflow-hidden backdrop-blur-md">
      {/* Header & Meta */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">Call Sentiment & Engagement Trajectory</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time conversational momentum mapping between Sales Rep & Prospect. Click anywhere to jump playback.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-xs font-medium">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50" />
            <span>High Engagement (&gt;65%)</span>
          </div>
          <div className="flex items-center gap-1.5 text-amber-400">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50" />
            <span>Neutral / Discovery (45-65%)</span>
          </div>
          <div className="flex items-center gap-1.5 text-rose-400">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
            <span>Friction / Objection (&lt;45%)</span>
          </div>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div ref={containerRef} className="relative w-full aspect-[16/6] min-h-[220px]">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full cursor-pointer select-none"
          onClick={handleSvgClick}
        >
          <defs>
            {/* Area gradient */}
            <linearGradient id="sentimentGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
              <stop offset="50%" stopColor="#6366f1" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#ef4444" stopOpacity="0.0" />
            </linearGradient>

            {/* Line stroke gradient */}
            <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#6366f1" />
              <stop offset="35%" stopColor="#10b981" />
              <stop offset="70%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>

          {/* Horizontal Zones and Gridlines */}
          {/* High Zone: 65% to 100% */}
          <line
            x1={padding.left}
            y1={padding.top + (1 - 0.65) * graphHeight}
            x2={width - padding.right}
            y2={padding.top + (1 - 0.65) * graphHeight}
            stroke="#10b981"
            strokeDasharray="4 4"
            strokeOpacity="0.25"
          />
          {/* Neutral Baseline: 50% */}
          <line
            x1={padding.left}
            y1={padding.top + (1 - 0.5) * graphHeight}
            x2={width - padding.right}
            y2={padding.top + (1 - 0.5) * graphHeight}
            stroke="#64748b"
            strokeDasharray="2 2"
            strokeOpacity="0.2"
          />
          {/* Low Zone: 40% */}
          <line
            x1={padding.left}
            y1={padding.top + (1 - 0.4) * graphHeight}
            x2={width - padding.right}
            y2={padding.top + (1 - 0.4) * graphHeight}
            stroke="#ef4444"
            strokeDasharray="4 4"
            strokeOpacity="0.25"
          />

          {/* Y Axis Labels */}
          <text x={padding.left - 8} y={padding.top + 5} fill="#10b981" fontSize="10" textAnchor="end" className="font-mono">
            100%
          </text>
          <text x={padding.left - 8} y={padding.top + (1 - 0.65) * graphHeight + 3} fill="#94a3b8" fontSize="10" textAnchor="end" className="font-mono">
            65%
          </text>
          <text x={padding.left - 8} y={padding.top + (1 - 0.4) * graphHeight + 3} fill="#ef4444" fontSize="10" textAnchor="end" className="font-mono">
            40%
          </text>
          <text x={padding.left - 8} y={height - padding.bottom} fill="#64748b" fontSize="10" textAnchor="end" className="font-mono">
            0%
          </text>

          {/* X Axis Time Marks */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const timeSec = ratio * maxDuration;
            const x = padding.left + ratio * graphWidth;
            return (
              <g key={ratio}>
                <line
                  x1={x}
                  y1={height - padding.bottom}
                  x2={x}
                  y2={height - padding.bottom + 6}
                  stroke="#475569"
                />
                <text
                  x={x}
                  y={height - padding.bottom + 18}
                  fill="#94a3b8"
                  fontSize="11"
                  textAnchor="middle"
                  className="font-mono"
                >
                  {formatSec(timeSec)}
                </text>
              </g>
            );
          })}

          {/* Shaded Area */}
          <path d={areaPath} fill="url(#sentimentGradient)" />

          {/* Spline Path */}
          <path
            d={linePath}
            fill="none"
            stroke="url(#lineGradient)"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="filter drop-shadow-[0_2px_8px_rgba(99,102,241,0.4)]"
          />

          {/* Key Event / Data Point Markers */}
          {points.map((p, index) => {
            const isHovered = hoveredPoint?.timestamp === p.timestamp;
            const isFriction = p.engagementScore < 45;
            const isHigh = p.engagementScore >= 65;
            const pointColor = isHigh ? '#10b981' : isFriction ? '#ef4444' : '#f59e0b';

            return (
              <g
                key={index}
                className="transition-transform duration-200"
                onMouseEnter={(e) => {
                  setHoveredPoint(p);
                  const rect = containerRef.current?.getBoundingClientRect();
                  if (rect) {
                    setTooltipPos({
                      x: (p.x / width) * rect.width,
                      y: (p.y / height) * rect.height,
                    });
                  }
                }}
                onMouseLeave={() => setHoveredPoint(null)}
                onClick={(e) => {
                  e.stopPropagation();
                  onSeek(p.timeSeconds);
                }}
              >
                {/* Glow ring on hover */}
                {isHovered && (
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r="12"
                    fill={pointColor}
                    fillOpacity="0.25"
                    className="animate-ping"
                  />
                )}

                {/* Outer badge */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isHovered ? 7 : p.keyEvent ? 5.5 : 4}
                  fill="#0f172a"
                  stroke={pointColor}
                  strokeWidth={isHovered ? 3 : 2}
                />

                {/* Inner center dot */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isHovered ? 3.5 : 2}
                  fill={pointColor}
                />

                {/* Event Tag Pill if notable */}
                {p.keyEvent && (
                  <g className="pointer-events-none">
                    <rect
                      x={p.x - 30}
                      y={p.y - 24}
                      width="60"
                      height="15"
                      rx="3"
                      fill="#1e293b"
                      stroke={pointColor}
                      strokeWidth="0.8"
                      strokeOpacity="0.7"
                    />
                    <text
                      x={p.x}
                      y={p.y - 13}
                      fill="#e2e8f0"
                      fontSize="8.5"
                      fontWeight="600"
                      textAnchor="middle"
                    >
                      {p.keyEvent.length > 10 ? p.keyEvent.slice(0, 9) + '…' : p.keyEvent}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Current Playback Scrubber Line */}
          <line
            x1={scrubberX}
            y1={padding.top - 5}
            x2={scrubberX}
            y2={height - padding.bottom + 4}
            stroke="#ffffff"
            strokeWidth="2"
            strokeDasharray="3 3"
            className="filter drop-shadow-[0_0_6px_rgba(255,255,255,0.8)] pointer-events-none"
          />
          <circle
            cx={scrubberX}
            cy={padding.top - 5}
            r="4.5"
            fill="#ffffff"
            className="filter drop-shadow-[0_0_8px_rgba(255,255,255,0.9)] pointer-events-none"
          />
        </svg>

        {/* Floating Tooltip */}
        {hoveredPoint && tooltipPos && (
          <div
            className="absolute z-30 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
            style={{ left: `${tooltipPos.x}px`, top: `${tooltipPos.y}px` }}
          >
            <div className="bg-slate-900/95 border border-slate-700/80 rounded-xl p-3 shadow-2xl backdrop-blur-xl w-64 text-left">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-mono text-indigo-400 font-bold">{hoveredPoint.timestamp}</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide ${
                    hoveredPoint.engagementScore >= 65
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : hoveredPoint.engagementScore < 45
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  Score: {hoveredPoint.engagementScore}%
                </span>
              </div>
              {hoveredPoint.keyEvent && (
                <div className="font-semibold text-slate-100 text-xs flex items-center gap-1.5 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  {hoveredPoint.keyEvent}
                </div>
              )}
              <div className="text-[11px] text-slate-300 line-clamp-2 italic">
                "{hoveredPoint.quoteSnippet || 'Active dialogue engagement point'}"
              </div>
              <div className="mt-2 text-[10px] text-slate-500 flex items-center justify-between pt-1.5 border-t border-slate-800">
                <span>Speaker: {hoveredPoint.speaker}</span>
                <span className="text-indigo-400 font-medium">Click to jump ➔</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Trajectory Insights Footer */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-300">Peak Moment:</span>
            <span className="text-emerald-400 font-mono">07:21 (90% Commitment)</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-300">Key Friction:</span>
            <span className="text-rose-400 font-mono">04:46 (CISO Gatekeeper)</span>
          </span>
        </div>
        <div className="text-slate-500 text-[11px]">
          Current playhead: <span className="font-mono text-white font-medium">{formatSec(currentTime)}</span> / {formatSec(maxDuration)}
        </div>
      </div>
    </div>
  );
};
