import React, { useMemo, useState } from 'react';
import { PackageOpen, Sparkles, ArrowUpDown, Coins } from 'lucide-react';
import { FUT_PACKS } from '../data/clubs';
import { soundEngine } from '../audio/soundEngine';
import { TRANSLATIONS } from '../i18n/translations';
import { Club, FutState, Language, Player } from '../types/game';
import { ClubCrest } from './ClubCrest';

interface UltimateTeamProps {
  clubs: Club[];
  fut: FutState;
  language: Language;
  onUpdateFut: (next: FutState) => void;
}

export const UltimateTeam: React.FC<UltimateTeamProps> = ({
  clubs,
  fut,
  language,
  onUpdateFut,
}) => {
  const t = TRANSLATIONS[language];
  const [subTab, setSubTab] = useState<'squad' | 'packs' | 'roster'>('squad');
  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);
  const [revealedCards, setRevealedCards] = useState<FutState['inventory'] | null>(null);

  const startingXI = useMemo(() => {
    return fut.lineupIds
      .map((id) => fut.inventory.find((p) => p.id === id))
      .filter((p): p is FutState['inventory'][number] => Boolean(p));
  }, [fut.lineupIds, fut.inventory]);

  const squadStats = useMemo(() => {
    if (startingXI.length === 0) return { rating: 80, chem: 0 };
    const rating = Math.round(startingXI.reduce((s, p) => s + p.ovr, 0) / startingXI.length);

    // Calculate FC-style Chemistry (/33): up to 3 points per player based on shared club/league/nationality
    let chem = 0;
    for (const p of startingXI) {
      const sameClub = startingXI.filter((o) => o.clubId === p.clubId).length - 1;
      const sameLeague = startingXI.filter((o) => o.league === p.league).length - 1;
      const sameNat = startingXI.filter((o) => o.nationality === p.nationality).length - 1;
      const pChem = Math.min(3, (sameClub >= 1 ? 2 : 0) + (sameLeague >= 2 ? 1 : 0) + (sameNat >= 2 ? 1 : 0));
      chem += pChem;
    }
    return { rating, chem: Math.min(33, chem) };
  }, [startingXI]);

  const allPoolPlayers = useMemo(() => {
    const list: FutState['inventory'] = [];
    for (const c of clubs) {
      for (const p of c.players) {
        list.push({ ...p, clubId: c.id, clubName: c.name, league: c.league });
      }
    }
    return list;
  }, [clubs]);

  const handleOpenPack = (packId: string) => {
    const pack = FUT_PACKS.find((pk) => pk.id === packId);
    if (!pack || fut.coins < pack.cost) return;

    const eligible = allPoolPlayers.filter((p) => p.ovr >= pack.minOvr && p.ovr <= pack.maxOvr);
    const pool = eligible.length >= 3 ? eligible : allPoolPlayers;
    const pulled: FutState['inventory'] = [];

    for (let i = 0; i < pack.cardsCount; i++) {
      const pick = pool[Math.floor(Math.random() * pool.length)];
      const uniqueCopy: FutState['inventory'][number] = {
        ...pick,
        id: `${pick.id}_fut_${Date.now()}_${i}`,
        cardTier: pack.id === 'ultimate_pack' && i === 0 ? 'icon' : pick.ovr >= 88 ? 'totw' : 'gold',
      };
      pulled.push(uniqueCopy);
    }

    soundEngine.playPackReveal();
    setRevealedCards(pulled);
    onUpdateFut({
      ...fut,
      coins: fut.coins - pack.cost,
      inventory: [...pulled, ...fut.inventory],
    });
  };

  const handleSwapIntoSlot = (playerId: string) => {
    if (selectedSlotIdx === null) return;
    const nextLineup = [...fut.lineupIds];
    const existingIdx = nextLineup.indexOf(playerId);
    if (existingIdx !== -1) {
      const temp = nextLineup[selectedSlotIdx];
      nextLineup[selectedSlotIdx] = playerId;
      nextLineup[existingIdx] = temp;
    } else {
      nextLineup[selectedSlotIdx] = playerId;
    }
    onUpdateFut({ ...fut, lineupIds: nextLineup });
    setSelectedSlotIdx(null);
  };

  const renderCardStyle = (tier?: Player['cardTier']) => {
    if (tier === 'icon') return 'from-slate-100 via-amber-100 to-amber-300 text-slate-950 border-amber-400';
    if (tier === 'totw') return 'from-slate-900 via-[#172554] to-slate-950 text-amber-300 border-amber-400';
    if (tier === 'hero') return 'from-rose-900 via-indigo-950 to-slate-950 text-white border-rose-400';
    return 'from-amber-200 via-amber-300 to-yellow-500 text-slate-950 border-amber-500';
  };

  return (
    <div className="relative z-10 h-full overflow-y-auto px-4 sm:px-8 py-5 max-w-6xl mx-auto">
      {/* Header Bar */}
      <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">
            Arena Football Ultimate Team
          </div>
          <h2 className="font-display font-extrabold text-3xl text-slate-900 dark:text-white">
            {fut.clubName}
          </h2>
          <div className="mt-1 flex items-center gap-4 font-mono-num text-xs font-bold text-slate-600 dark:text-slate-300">
            <span>{t.futRating}: {squadStats.rating}</span>
            <span>·</span>
            <span className="text-emerald-600 dark:text-emerald-400">
              {t.futChemistry}: {squadStats.chem}/33
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-num text-sm font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
            <Coins className="w-4 h-4" />
            <span>{fut.coins.toLocaleString()}</span>
          </div>
          {fut.coins < 1500 && (
            <button
              onClick={() => onUpdateFut({ ...fut, coins: fut.coins + 3000 })}
              className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
            >
              +3.000 Bonus
            </button>
          )}
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="mt-4 flex gap-1.5 p-1 bg-white/90 dark:bg-[#0B1120]/90 border border-slate-200 dark:border-slate-800 rounded-xl w-fit">
        {(
          [
            ['squad', t.futSquad],
            ['packs', t.futPacks],
            ['roster', t.futClub],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            onClick={() => setSubTab(k)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              subTab === k
                ? 'bg-amber-400 text-slate-950'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* SQUAD VIEW */}
      {subTab === 'squad' && (
        <div className="mt-4 grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-8 bg-[#0f4c28] border-2 border-emerald-700/80 rounded-2xl p-5 shadow-xl">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {startingXI.map((player, idx) => {
                const clubObj = clubs.find((c) => c.id === player.clubId) || clubs[0];
                const isSelected = selectedSlotIdx === idx;
                return (
                  <button
                    key={player.id}
                    onClick={() => setSelectedSlotIdx(isSelected ? null : idx)}
                    className={`relative rounded-xl p-3 bg-gradient-to-br border-2 text-left transition-transform hover:-translate-y-0.5 ${renderCardStyle(
                      player.cardTier
                    )} ${isSelected ? 'ring-4 ring-white scale-[1.03]' : ''}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-mono-num font-extrabold text-2xl leading-none">
                          {player.ovr}
                        </div>
                        <div className="text-[11px] font-bold uppercase opacity-80">{player.position}</div>
                      </div>
                      <ClubCrest club={clubObj} size={26} />
                    </div>
                    <div className="mt-2 font-display font-bold text-base truncate">{player.name}</div>
                    <div className="mt-1 grid grid-cols-3 gap-1 text-[10px] font-mono-num opacity-85">
                      <span>PAC {player.pac}</span>
                      <span>SHO {player.sho}</span>
                      <span>PAS {player.pas}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Swap Panel */}
          <div className="lg:col-span-4 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white mb-3">
              <ArrowUpDown className="w-4 h-4 text-amber-500" />
              <span>
                {selectedSlotIdx !== null
                  ? `${t.sendToSquad} (#${selectedSlotIdx + 1})`
                  : t.futClub}
              </span>
            </div>
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {fut.inventory.map((pl) => {
                const inXI = fut.lineupIds.includes(pl.id);
                return (
                  <div
                    key={pl.id}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {pl.name}
                      </div>
                      <div className="font-mono-num text-[11px] text-slate-500 dark:text-slate-400">
                        {pl.position} · OVR {pl.ovr} · {pl.clubName}
                      </div>
                    </div>
                    {selectedSlotIdx !== null && (
                      <button
                        onClick={() => handleSwapIntoSlot(pl.id)}
                        className="shrink-0 px-2.5 py-1 rounded bg-amber-400 text-slate-950 font-bold text-[11px]"
                      >
                        {inXI ? 'Swap' : 'In'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* PACK STORE */}
      {subTab === 'packs' && (
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {FUT_PACKS.map((pk) => (
            <div
              key={pk.id}
              className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${pk.accent}22`, color: pk.accent }}
                >
                  <PackageOpen className="w-6 h-6" />
                </div>
                <h3 className="font-display font-extrabold text-2xl text-slate-900 dark:text-white">
                  {pk.name}
                </h3>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-mono-num">
                  {pk.cardsCount} Cards · OVR {pk.minOvr}–{pk.maxOvr}
                </p>
              </div>
              <button
                disabled={fut.coins < pk.cost}
                onClick={() => handleOpenPack(pk.id)}
                className="mt-6 w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-40 text-slate-950 font-bold text-sm font-mono-num transition-colors"
              >
                {t.openPack} · {pk.cost.toLocaleString()}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* FULL ROSTER */}
      {subTab === 'roster' && (
        <div className="mt-4 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {fut.inventory.map((pl) => {
            const clubObj = clubs.find((c) => c.id === pl.clubId) || clubs[0];
            return (
              <div
                key={pl.id}
                className={`rounded-xl p-3 bg-gradient-to-br border ${renderCardStyle(pl.cardTier)}`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono-num font-extrabold text-xl">{pl.ovr}</span>
                  <ClubCrest club={clubObj} size={24} />
                </div>
                <div className="mt-1 font-display font-bold text-lg truncate">{pl.name}</div>
                <div className="text-[11px] font-semibold opacity-80">
                  {pl.position} · {pl.clubName}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ANIMATED PACK WALKOUT MODAL */}
      {revealedCards && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-[#0D1426] border-2 border-amber-400 rounded-2xl p-6 text-center shadow-2xl">
            <div className="inline-flex items-center gap-2 text-amber-400 font-display font-bold text-xl uppercase tracking-wider">
              <Sparkles className="w-5 h-5" />
              <span>Arena Football Pack Walkout</span>
            </div>
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {revealedCards.map((card) => {
                const clubObj = clubs.find((c) => c.id === card.clubId) || clubs[0];
                return (
                  <div
                    key={card.id}
                    className={`rounded-xl p-4 bg-gradient-to-br border-2 text-left shadow-xl ${renderCardStyle(
                      card.cardTier
                    )}`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-mono-num font-extrabold text-3xl leading-none">
                          {card.ovr}
                        </div>
                        <div className="text-xs font-bold uppercase">{card.position}</div>
                      </div>
                      <ClubCrest club={clubObj} size={32} />
                    </div>
                    <div className="mt-3 font-display font-extrabold text-xl truncate">{card.name}</div>
                    <div className="text-xs opacity-80">{card.clubName}</div>
                    <div className="mt-3 grid grid-cols-3 gap-1 text-[11px] font-mono-num font-bold">
                      <span>PAC {card.pac}</span>
                      <span>SHO {card.sho}</span>
                      <span>PAS {card.pas}</span>
                      <span>DRI {card.dri}</span>
                      <span>DEF {card.def}</span>
                      <span>PHY {card.phy}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <button
              onClick={() => setRevealedCards(null)}
              className="mt-6 px-8 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
