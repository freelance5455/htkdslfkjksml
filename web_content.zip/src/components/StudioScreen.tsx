import React, { useState } from 'react';
import {
  Info,
  ChevronDown,
  TrendingUp,
  Award,
  ArrowUpRight,
  Eye,
  Heart,
  Share2,
  Users,
  ChevronLeft,
} from 'lucide-react';
import { Post, StudioAnalytics } from '../types';
import { calculateStudioAnalytics, issueInfluencerCertificate } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface StudioScreenProps {
  posts: Post[];
  onBack: () => void;
  onOpenCertificate: (certId: string) => void;
}

export const StudioScreen: React.FC<StudioScreenProps> = ({
  posts,
  onBack,
  onOpenCertificate,
}) => {
  const { userProfile, updateProfileData } = useAuth();
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('7d');
  const [showDropdown, setShowDropdown] = useState(false);
  const [issuingCert, setIssuingCert] = useState(false);
  const myPosts = posts.filter(
    (p) => p.userId === userProfile?.id || (userProfile?.username && p.username === userProfile.username)
  );
  const analytics = calculateStudioAnalytics(myPosts, period);

  // Sparkline SVG renderer
  const renderSparkline = (data: number[], color: string) => {
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const width = 120;
    const height = 36;

    const points = data
      .map((val, idx) => {
        const x = (idx / (data.length - 1)) * width;
        const y = height - ((val - min) / range) * (height - 8) - 4;
        return `${x},${y}`;
      })
      .join(' ');

    return (
      <svg className="w-full h-9 overflow-visible" viewBox={`0 0 ${width} ${height}`}>
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />
      </svg>
    );
  };

  const handleClaimCertificate = async () => {
    if (!userProfile) return;
    setIssuingCert(true);
    try {
      const cert = await issueInfluencerCertificate(userProfile);
      await updateProfileData({
        hasInfluencerCertificate: true,
        certificateId: cert.id,
      });
      onOpenCertificate(cert.id);
    } finally {
      setIssuingCert(false);
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen bg-[#050505] text-white px-5 pt-4 pb-24 md:pb-12 animate-fade-in select-none">
      {/* Header matching reference image Screen 8:
          ‹ Estatísticas + (i) Info icon */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1 -ml-1 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F] transition-colors"
          >
            <ChevronLeft size={22} />
          </button>
          <h1 className="text-xl font-extrabold text-white">Estatísticas</h1>
        </div>

        <button
          onClick={() => alert('ClipShare Studio: Métricas de desempenho calculadas em tempo real.')}
          className="p-1.5 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F] transition-colors"
        >
          <Info size={20} />
        </button>
      </div>

      {/* Period Dropdown: "Últimos 7 dias ⌵" */}
      <div className="relative mb-5">
        <button
          onClick={() => setShowDropdown((v) => !v)}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#101014] border border-[#19191F] text-xs font-semibold text-white/90 hover:text-white transition-colors cursor-pointer"
        >
          <span>
            {period === '7d'
              ? 'Últimos 7 dias'
              : period === '30d'
              ? 'Últimos 30 dias'
              : 'Últimos 90 dias'}
          </span>
          <ChevronDown size={14} className="text-[#A1A1AA]" />
        </button>

        {showDropdown && (
          <div className="absolute left-0 top-10 z-30 w-44 bg-[#101014] border border-[#272730] rounded-2xl p-1.5 shadow-2xl">
            {[
              { id: '7d', label: 'Últimos 7 dias' },
              { id: '30d', label: 'Últimos 30 dias' },
              { id: '90d', label: 'Últimos 90 dias' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setPeriod(p.id as any);
                  setShowDropdown(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium ${
                  period === p.id ? 'bg-[#19191F] text-[#FF008C]' : 'text-white hover:bg-[#19191F]'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 3 Metric Cards matching reference image:
          Visualizações | Alcance | Engajamento */}
      <div className="grid grid-cols-3 gap-2.5 mb-7">
        {/* Visualizações */}
        <div className="p-3 rounded-2xl bg-[#101014] border border-[#19191F] flex flex-col justify-between">
          <div>
            <span className="text-[11px] text-[#A1A1AA] block mb-1">Visualizações</span>
            <span className="text-base md:text-lg font-black text-white block">
              {analytics.views.value}
            </span>
            <span className="text-[11px] font-bold text-[#20E060] flex items-center gap-0.5 mt-0.5">
              +{analytics.views.changePercent.toString().replace('.', ',')}%
            </span>
          </div>
          <div className="mt-3">
            {renderSparkline(analytics.views.trend, '#FF008C')}
          </div>
        </div>

        {/* Alcance */}
        <div className="p-3 rounded-2xl bg-[#101014] border border-[#19191F] flex flex-col justify-between">
          <div>
            <span className="text-[11px] text-[#A1A1AA] block mb-1">Alcance</span>
            <span className="text-base md:text-lg font-black text-white block">
              {analytics.reach.value}
            </span>
            <span className="text-[11px] font-bold text-[#20E060] flex items-center gap-0.5 mt-0.5">
              +{analytics.reach.changePercent.toString().replace('.', ',')}%
            </span>
          </div>
          <div className="mt-3">
            {renderSparkline(analytics.reach.trend, '#9900FF')}
          </div>
        </div>

        {/* Engajamento */}
        <div className="p-3 rounded-2xl bg-[#101014] border border-[#19191F] flex flex-col justify-between">
          <div>
            <span className="text-[11px] text-[#A1A1AA] block mb-1">Engajamento</span>
            <span className="text-base md:text-lg font-black text-white block">
              {analytics.engagement.value}
            </span>
            <span className="text-[11px] font-bold text-[#20E060] flex items-center gap-0.5 mt-0.5">
              +{analytics.engagement.changePercent.toString().replace('.', ',')}%
            </span>
          </div>
          <div className="mt-3">
            {renderSparkline(analytics.engagement.trend, '#FF4038')}
          </div>
        </div>
      </div>

      {/* Influencer Certificate Special Milestone Section */}
      <div className="mb-7 p-4 rounded-3xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-purple-500/10 border border-amber-500/30">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Award size={20} className="text-amber-400" />
            <h3 className="text-xs font-bold text-amber-300">
              Certificado de Influenciador ClipShare
            </h3>
          </div>
          <span className="text-[11px] font-bold text-white bg-amber-500/20 px-2 py-0.5 rounded-full">
            10 Seguidores
          </span>
        </div>
        <p className="text-xs text-[#A1A1AA] leading-relaxed mb-3">
          Ao alcançar 10 seguidores reais, você conquista o certificado oficial autenticado com identificador único.
        </p>

        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-2">
            <Users size={16} className="text-[#FF008C]" />
            <span className="text-xs font-semibold text-white">
              {userProfile?.followersCount || 0} seguidores alcançados
            </span>
          </div>
          <button
            onClick={handleClaimCertificate}
            disabled={issuingCert || (userProfile?.followersCount || 0) < 10}
            className="px-4 py-2 rounded-full text-xs font-bold text-black bg-gradient-to-r from-amber-400 to-yellow-300 hover:opacity-95 shadow-lg active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            {(userProfile?.followersCount || 0) >= 10 ? (issuingCert ? 'Gerando...' : 'Visualizar Certificado') : 'Necessário 10 seguidores'}
          </button>
        </div>
      </div>

      {/* Section: Desempenho de vídeos with "Ver tudo" matching reference image */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-white">Desempenho de vídeos</h2>
          {analytics.topVideos.length > 0 && (
            <button className="text-xs font-semibold text-[#FF008C] hover:underline cursor-pointer">
              Ver tudo
            </button>
          )}
        </div>

        {analytics.topVideos.length === 0 ? (
          <div className="p-6 rounded-2xl bg-[#101014] border border-[#19191F] text-center text-xs text-[#A1A1AA]">
            Nenhum vídeo publicado ainda. Publique seus clipes para ver o engajamento e métricas em tempo real!
          </div>
        ) : (
          <div className="space-y-2.5">
            {analytics.topVideos.map((vid) => (
              <div
                key={vid.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-[#101014] border border-[#19191F] transition-colors"
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <img
                    src={vid.coverUrl}
                    alt={vid.title}
                    className="w-12 h-16 rounded-xl object-cover shrink-0 border border-[#272730]"
                  />
                  <div className="truncate text-left">
                    <h3 className="text-xs font-bold text-white truncate">{vid.title}</h3>
                    <span className="text-[11px] text-[#A1A1AA] block mt-0.5">
                      {vid.views}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-xs font-bold text-[#20E060] shrink-0 bg-[#20E060]/10 px-2.5 py-1 rounded-full">
                  <ArrowUpRight size={14} />
                  <span>+{vid.growthPercent.toString().replace('.', ',')}%</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
