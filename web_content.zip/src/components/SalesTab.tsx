import React, { useState, useRef } from 'react';
import {
  Plus,
  Search,
  Camera,
  Barcode,
  Calendar,
  Trash2,
  ShoppingBag,
  X,
  Check,
  Building2,
  AlertTriangle,
  Clock,
  TrendingUp,
  Layers,
  List,
  PackagePlus,
  CheckCircle2,
  AlertCircle,
  Printer,
} from 'lucide-react';
import type { SaleItem, MedicineStock, MedicineItem } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic, getNearestExpiryForSale } from '../utils/calculations.ts';
import {
  buildPrintableFromSalesGroup,
  type PrintableInvoiceConfig,
} from '../utils/invoicePrint.ts';
import { parseAndNormalizeBarcode, findMatchingBarcodeKey } from '../utils/barcodeUtils.ts';

interface DraftSaleLine {
  tempId: string;
  barcode: string;
  medicineName: string;
  qty: number;
  unitPrice: number;
  avgCostAtSale: number;
  nearestExpiryBatch?: string;
}

interface SalesTabProps {
  sales: SaleItem[];
  medicines: MedicineItem[];
  stocks: Record<string, MedicineStock>;
  onAddSale: (sale: Omit<SaleItem, 'id' | 'createdAt'>) => void;
  onAddSaleBatch?: (items: Array<Omit<SaleItem, 'id' | 'createdAt'>>) => void;
  onDeleteSale: (id: string) => void;
  onOpenScanner: (callback: (code: string) => void) => void;
  onOpenCatalogModal?: () => void;
  onPrintInvoice?: (config: PrintableInvoiceConfig) => void;
  initialBarcode?: string | null;
  onClearInitialBarcode?: () => void;
}

export const SalesTab: React.FC<SalesTabProps> = ({
  sales,
  medicines,
  stocks,
  onAddSale,
  onAddSaleBatch,
  onDeleteSale,
  onOpenScanner,
  onOpenCatalogModal,
  onPrintInvoice,
  initialBarcode,
  onClearInitialBarcode,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBuyer, setSelectedBuyer] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grouped' | 'items'>('grouped');

  const todayStr = new Date().toISOString().split('T')[0];

  // Invoice Header State (filled ONCE per sale invoice)
  const [date, setDate] = useState(todayStr);
  const [buyer, setBuyer] = useState('');
  const [notes, setNotes] = useState('');

  // Multi-item sale cart state
  const [invoiceItems, setInvoiceItems] = useState<DraftSaleLine[]>([]);

  // Current item entry inputs
  const [barcode, setBarcode] = useState('');
  const [medicineName, setMedicineName] = useState('');
  const [qty, setQty] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [matchedFromSystem, setMatchedFromSystem] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Invoice-level payment state
  const [isPaidInFull, setIsPaidInFull] = useState(true);
  const [amountPaid, setAmountPaid] = useState('');

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const qtyInputRef = useRef<HTMLInputElement>(null);

  // Merge catalog medicines + stock items for instant lookup
  const catalogMap = React.useMemo(() => {
    const map = new Map<
      string,
      { barcode: string; name: string; suggestedSalePrice: number; avgCost: number }
    >();

    for (const m of medicines) {
      const st = stocks[m.barcode];
      const lastS = sales.find((s) => s.barcode === m.barcode);
      const avgCost = st?.averageCost ?? 0;
      const suggested =
        lastS?.unitPrice || (avgCost > 0 ? Math.round((avgCost * 1.25) / 250) * 250 : 0);
      map.set(m.barcode, {
        barcode: m.barcode,
        name: m.name,
        suggestedSalePrice: suggested,
        avgCost,
      });
    }

    for (const st of Object.values(stocks)) {
      if (!map.has(st.barcode)) {
        const lastS = sales.find((s) => s.barcode === st.barcode);
        const avgCost = st.averageCost ?? 0;
        const suggested =
          lastS?.unitPrice || (avgCost > 0 ? Math.round((avgCost * 1.25) / 250) * 250 : 0);
        map.set(st.barcode, {
          barcode: st.barcode,
          name: st.name,
          suggestedSalePrice: suggested,
          avgCost,
        });
      }
    }

    return map;
  }, [medicines, stocks, sales]);

  // If passed an initial barcode from Details screen
  React.useEffect(() => {
    if (initialBarcode) {
      handleSelectBarcode(initialBarcode);
      setShowAddModal(true);
      if (onClearInitialBarcode) onClearInitialBarcode();
    }
  }, [initialBarcode]);

  const handleSelectBarcode = (code: string) => {
    const parsed = parseAndNormalizeBarcode(code);
    const normalized = parsed.normalizedBarcode || code.trim();
    setBarcode(normalized);
    setFormError(null);
    if (!normalized) {
      setMatchedFromSystem(false);
      return;
    }
    const matchedKey = findMatchingBarcodeKey(normalized, medicines, stocks);
    const found = catalogMap.get(matchedKey || normalized);
    if (found) {
      setBarcode(found.barcode);
      setMedicineName(found.name);
      setMatchedFromSystem(true);
      if (found.suggestedSalePrice > 0) {
        setUnitPrice(String(found.suggestedSalePrice));
      }
      setTimeout(() => qtyInputRef.current?.focus(), 60);
    } else {
      if (matchedFromSystem) {
        setMedicineName('');
        setUnitPrice('');
      }
      setMatchedFromSystem(false);
    }
  };

  const handleSelectMedicineByName = (val: string) => {
    setMedicineName(val);
    setFormError(null);
    const match = Array.from(catalogMap.values()).find(
      (item) => item.name.toLowerCase() === val.trim().toLowerCase()
    );
    if (match) {
      setBarcode(match.barcode);
      setMatchedFromSystem(true);
      if (match.suggestedSalePrice > 0 && !unitPrice) {
        setUnitPrice(String(match.suggestedSalePrice));
      }
    }
  };

  // Stock & Expiry Advisory for currently selected medicine
  const selectedStock = barcode ? stocks[barcode] : undefined;
  const alreadyInCartQty = invoiceItems
    .filter((i) => i.barcode === barcode)
    .reduce((sum, i) => sum + i.qty, 0);
  const currentAvailableQty = Math.max(0, (selectedStock?.remaining ?? 0) - alreadyInCartQty);
  const nearestExpiryAdvice = barcode ? getNearestExpiryForSale(barcode, stocks) : null;

  const enteredQty = parseInt(qty, 10) || 0;
  const isStockExceeded = Boolean(selectedStock && enteredQty > currentAvailableQty);

  const unitAvgCost = selectedStock?.averageCost ?? 0;

  const handleAddLineToInvoice = () => {
    if (!medicineName.trim()) {
      setFormError('يرجى مسح الباركود أو اختيار اسم المادة أولاً');
      return;
    }
    const q = Math.max(1, parseInt(qty, 10) || 0);
    const price = Math.max(0, parseFloat(unitPrice) || 0);
    if (q <= 0 || price <= 0) {
      setFormError('يرجى إدخال الكمية وسعر البيع للوحدة بشكل صحيح');
      return;
    }

    const finalCode = barcode.trim() || `629${Date.now().toString().slice(-9)}`;

    setInvoiceItems((prev) => [
      ...prev,
      {
        tempId: `sline-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        barcode: finalCode,
        medicineName: medicineName.trim(),
        qty: q,
        unitPrice: price,
        avgCostAtSale: unitAvgCost,
        nearestExpiryBatch: nearestExpiryAdvice?.nearestExpiry || undefined,
      },
    ]);

    // Clear line inputs for the next item on the SAME invoice!
    setBarcode('');
    setMedicineName('');
    setQty('1');
    setUnitPrice('');
    setMatchedFromSystem(false);
    setFormError(null);
    setTimeout(() => barcodeInputRef.current?.focus(), 50);
  };

  const handleRemoveLine = (tempId: string) => {
    setInvoiceItems((prev) => prev.filter((item) => item.tempId !== tempId));
  };

  const handleUpdateLine = (tempId: string, field: 'qty' | 'unitPrice', val: string) => {
    setInvoiceItems((prev) =>
      prev.map((item) => {
        if (item.tempId !== tempId) return item;
        if (field === 'qty') return { ...item, qty: Math.max(1, parseInt(val, 10) || 1) };
        return { ...item, unitPrice: Math.max(0, parseFloat(val) || 0) };
      })
    );
  };

  // Pending draft item if user didn't click "إضافة للقائمة +" yet
  const pendingDraftValid =
    medicineName.trim().length > 0 && (parseFloat(qty) || 0) > 0 && (parseFloat(unitPrice) || 0) > 0;
  const pendingDraftTotal = pendingDraftValid
    ? (parseFloat(qty) || 0) * (parseFloat(unitPrice) || 0)
    : 0;
  const pendingDraftProfit = pendingDraftValid
    ? (parseFloat(qty) || 0) * ((parseFloat(unitPrice) || 0) - unitAvgCost)
    : 0;

  const cartItemsTotal = invoiceItems.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  const cartItemsProfit = invoiceItems.reduce(
    (sum, item) => sum + item.qty * (item.unitPrice - item.avgCostAtSale),
    0
  );

  const grandTotal = cartItemsTotal + (invoiceItems.length === 0 ? pendingDraftTotal : 0);
  const grandEstimatedProfit =
    cartItemsProfit + (invoiceItems.length === 0 ? pendingDraftProfit : 0);

  React.useEffect(() => {
    if (isPaidInFull) {
      setAmountPaid(grandTotal > 0 ? String(grandTotal) : '');
    }
  }, [grandTotal, isPaidInFull]);

  const saveInvoiceInternal = (openPrintAfter: boolean) => {
    setFormError(null);

    if (!buyer.trim()) {
      setFormError('يرجى إدخال اسم الصيدلية / المشتري في أعلى الفاتورة');
      return;
    }

    const finalLines: DraftSaleLine[] = [...invoiceItems];
    if (pendingDraftValid) {
      finalLines.push({
        tempId: `sline-${Date.now()}`,
        barcode: barcode.trim() || `629${Date.now().toString().slice(-9)}`,
        medicineName: medicineName.trim(),
        qty: Math.max(1, parseInt(qty, 10) || 1),
        unitPrice: Math.max(0, parseFloat(unitPrice) || 0),
        avgCostAtSale: unitAvgCost,
        nearestExpiryBatch: nearestExpiryAdvice?.nearestExpiry || undefined,
      });
    }

    if (finalLines.length === 0) {
      setFormError('يرجى إضافة مادة واحدة على الأقل إلى فاتورة البيع');
      return;
    }

    const totalInvoiceSum = finalLines.reduce((sum, l) => sum + l.qty * l.unitPrice, 0);
    const totalPaid = isPaidInFull
      ? totalInvoiceSum
      : Math.min(totalInvoiceSum, Math.max(0, parseFloat(amountPaid) || 0));

    const invoiceCode = `SINV-${Date.now().toString().slice(-5)}`;
    const invoiceNote = notes.trim()
      ? `[${invoiceCode}] ${notes.trim()}`
      : finalLines.length > 1
      ? `[${invoiceCode}] قائمة بيع مجمعة (${finalLines.length} مواد)`
      : undefined;

    let remainingPaidToAllocate = totalPaid;
    const payloads: Array<Omit<SaleItem, 'id' | 'createdAt'>> = finalLines.map((line, index) => {
      const lineTotal = line.qty * line.unitPrice;
      let linePaid = 0;
      if (isPaidInFull) {
        linePaid = lineTotal;
      } else if (index === finalLines.length - 1) {
        linePaid = Math.min(lineTotal, Math.max(0, remainingPaidToAllocate));
      } else if (totalInvoiceSum > 0) {
        linePaid = Math.min(lineTotal, Math.round((lineTotal / totalInvoiceSum) * totalPaid));
        remainingPaidToAllocate -= linePaid;
      }

      return {
        date,
        buyer: buyer.trim(),
        barcode: line.barcode,
        medicineName: line.medicineName,
        qty: line.qty,
        unitPrice: line.unitPrice,
        totalAmount: lineTotal,
        avgCostAtSale: line.avgCostAtSale,
        amountPaid: linePaid,
        remainingUnpaid: Math.max(0, lineTotal - linePaid),
        nearestExpiryBatch: line.nearestExpiryBatch,
        notes: invoiceNote,
      };
    });

    if (onAddSaleBatch) {
      onAddSaleBatch(payloads);
    } else {
      payloads.forEach((s) => onAddSale(s));
    }

    if (openPrintAfter && onPrintInvoice) {
      const syntheticItems: SaleItem[] = payloads.map((p, idx) => ({
        ...p,
        id: `temp_s_${idx}`,
        createdAt: Date.now() + idx,
      }));
      onPrintInvoice(
        buildPrintableFromSalesGroup({
          date,
          buyer: buyer.trim(),
          invoiceTag: invoiceCode,
          items: syntheticItems,
          totalAmount: totalInvoiceSum,
          amountPaid: totalPaid,
        })
      );
    }

    setShowAddModal(false);
    setInvoiceItems([]);
    setBarcode('');
    setMedicineName('');
    setQty('1');
    setUnitPrice('');
    setAmountPaid('');
    setNotes('');
    setMatchedFromSystem(false);
    setFormError(null);
  };

  const handleSubmitInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    saveInvoiceInternal(false);
  };

  const buyers = Array.from(new Set(sales.map((s) => s.buyer))).filter(Boolean);

  const filtered = sales
    .filter((s) => {
      const matchSearch =
        !searchQuery ||
        s.medicineName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.barcode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.buyer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (s.notes && s.notes.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchBuyer = selectedBuyer === 'all' || s.buyer === selectedBuyer;
      return matchSearch && matchBuyer;
    })
    .sort(
      (a, b) =>
        new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt
    );

  // Group filtered sales into Unified Sale Invoices
  const groupedInvoices = React.useMemo(() => {
    const groups = new Map<
      string,
      {
        groupKey: string;
        date: string;
        buyer: string;
        addedByName: string;
        invoiceTag?: string;
        items: SaleItem[];
        totalAmount: number;
        amountPaid: number;
        remainingUnpaid: number;
        totalProfit: number;
        latestCreatedAt: number;
      }
    >();

    for (const item of filtered) {
      const tagMatch = item.notes?.match(/^\[(SINV-[A-Za-z0-9_-]+)\]/);
      const timeBucket = Math.floor((item.createdAt || 0) / 120000);
      const key = tagMatch
        ? `${item.buyer}_${item.date}_${tagMatch[1]}`
        : `${item.buyer}_${item.date}_${timeBucket}`;

      const cost =
        item.avgCostAtSale > 0 ? item.avgCostAtSale : (stocks[item.barcode]?.averageCost ?? 0);
      const itemProfit = (item.unitPrice - cost) * item.qty;

      const existing = groups.get(key);
      if (existing) {
        existing.items.push(item);
        existing.totalAmount += item.totalAmount;
        existing.amountPaid += item.amountPaid;
        existing.remainingUnpaid += item.remainingUnpaid;
        existing.totalProfit += itemProfit;
      } else {
        groups.set(key, {
          groupKey: key,
          date: item.date,
          buyer: item.buyer,
          addedByName: item.addedByName || 'فريق المبيعات',
          invoiceTag: tagMatch ? tagMatch[1] : undefined,
          items: [item],
          totalAmount: item.totalAmount,
          amountPaid: item.amountPaid,
          remainingUnpaid: item.remainingUnpaid,
          totalProfit: itemProfit,
          latestCreatedAt: item.createdAt,
        });
      }
    }

    return Array.from(groups.values()).sort((a, b) => b.latestCreatedAt - a.latestCreatedAt);
  }, [filtered, stocks]);

  const totalFilteredSales = filtered.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalFilteredPaid = filtered.reduce((sum, s) => sum + s.amountPaid, 0);
  const totalFilteredDebt = filtered.reduce((sum, s) => sum + s.remainingUnpaid, 0);

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Top Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <ShoppingBag className="h-6 w-6 text-indigo-700" />
            سجل المبيعات وقوائم الصيدليات
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            إنشاء قوائم بيع متعددة المواد على نفس الفاتورة مع قراءة الباركود وفحص الصلاحية والرصيد
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onPrintInvoice && (
            <button
              type="button"
              onClick={() => {
                if (groupedInvoices.length > 0) {
                  onPrintInvoice(buildPrintableFromSalesGroup(groupedInvoices[0]));
                } else {
                  onPrintInvoice(
                    buildPrintableFromSalesGroup({
                      date: todayStr,
                      buyer: '',
                      items: [],
                      totalAmount: 0,
                      amountPaid: 0,
                    })
                  );
                }
              }}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 px-3.5 py-2.5 text-xs font-black transition active:scale-95"
            >
              <Printer className="h-4 w-4" />
              <span>ترتيب وطباعة فاتورة</span>
            </button>
          )}

          {onOpenCatalogModal && (
            <button
              onClick={onOpenCatalogModal}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 px-3 py-2.5 text-xs font-black transition active:scale-95"
            >
              <PackagePlus className="h-4 w-4 text-indigo-700" />
              <span>تعريف مواد</span>
            </button>
          )}

          <button
            onClick={() => {
              setDate(todayStr);
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-indigo-700 px-4 py-2.5 text-xs font-black text-white shadow-xs hover:bg-indigo-800 active:scale-98 transition"
          >
            <Plus className="h-4 w-4" />
            <span>قائمة بيع جديدة</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-white p-3 border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold text-slate-500">إجمالي المبيعات</div>
          <div className="text-sm sm:text-base font-black text-slate-900 mt-1">
            {formatIQD(totalFilteredSales)}
          </div>
        </div>
        <div className="rounded-xl bg-emerald-50/70 p-3 border border-emerald-200/70 shadow-xs">
          <div className="text-[11px] font-bold text-emerald-800">المقبوض نقداً</div>
          <div className="text-sm sm:text-base font-black text-emerald-700 mt-1">
            {formatIQD(totalFilteredPaid)}
          </div>
        </div>
        <div className="rounded-xl bg-indigo-50/70 p-3 border border-indigo-200/70 shadow-xs">
          <div className="text-[11px] font-bold text-indigo-800">دين على الزبائن</div>
          <div className="text-sm sm:text-base font-black text-indigo-700 mt-1">
            {formatIQD(totalFilteredDebt)}
          </div>
        </div>
      </div>

      {/* Search, Filters & View Mode */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث باسم الدواء، الصيدلية، أو الباركود..."
            className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pr-10 pl-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-hidden"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <select
          value={selectedBuyer}
          onChange={(e) => setSelectedBuyer(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-indigo-500 focus:outline-hidden"
        >
          <option value="all">جميع الصيدليات والعملاء ({buyers.length})</option>
          {buyers.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </select>

        {/* View Toggle */}
        <div className="inline-flex rounded-xl bg-slate-200/80 p-1 shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('grouped')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'grouped'
                ? 'bg-white text-indigo-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>كفواتير ({groupedInvoices.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode('items')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'items'
                ? 'bg-white text-indigo-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <List className="h-3.5 w-3.5" />
            <span>بالمواد ({filtered.length})</span>
          </button>
        </div>
      </div>

      {/* Sales List */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-400">
          <ShoppingBag className="mx-auto h-8 w-8 text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">لا توجد قوائم بيع مطابقة</p>
          <p className="text-xs text-slate-400 mt-1">
            اضغط على &quot;قائمة بيع جديدة (عدة مواد)&quot; لتوثيق فاتورة بيع.
          </p>
        </div>
      ) : viewMode === 'grouped' ? (
        <div className="space-y-3">
          {groupedInvoices.map((inv) => (
            <div
              key={inv.groupKey}
              className="rounded-2xl bg-white border border-slate-200/90 shadow-xs overflow-hidden hover:border-indigo-300 transition"
            >
              {/* Invoice Header */}
              <div className="bg-slate-50/90 px-4 py-3 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1 text-xs font-black text-indigo-950">
                      <Building2 className="h-4 w-4 text-indigo-600" />
                      {inv.buyer}
                    </span>
                    <span className="text-[11px] font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-md">
                      {inv.items.length} {inv.items.length === 1 ? 'مادة' : 'مواد'}
                    </span>
                    <span className="text-[10px] font-bold bg-slate-900 text-amber-300 px-2 py-0.5 rounded-md">
                      بواسطة: {inv.addedByName}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500 mt-1">
                    <Calendar className="h-3 w-3 text-slate-400" />
                    <span>تاريخ الفاتورة: {formatDateArabic(inv.date)}</span>
                    <span className="text-emerald-700 font-bold flex items-center gap-0.5">
                      <TrendingUp className="h-3 w-3" />
                      ربح القائمة: {formatIQD(inv.totalProfit)}
                    </span>
                  </div>
                </div>

                <div className="text-left flex flex-col items-end gap-1.5">
                  <div className="text-base font-black font-mono text-indigo-950">
                    {formatIQD(inv.totalAmount)}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 justify-end">
                    {inv.remainingUnpaid > 0 ? (
                      <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60">
                        باقي: {formatIQD(inv.remainingUnpaid)}
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        واصل كاش
                      </span>
                    )}
                    {onPrintInvoice && (
                      <button
                        type="button"
                        onClick={() => onPrintInvoice(buildPrintableFromSalesGroup(inv))}
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 px-2.5 py-1 text-[11px] font-black transition active:scale-95"
                        title="ترتيب الفاتورة واختيار الاسم وطباعتها"
                      >
                        <Printer className="h-3 w-3" />
                        <span>ترتيب وطباعة</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Invoice Line Items */}
              <div className="divide-y divide-slate-100 px-4 py-1">
                {inv.items.map((item) => (
                  <div
                    key={item.id}
                    className="py-2.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 truncate">
                          {item.medicineName}
                        </span>
                        <span className="font-mono text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          {item.barcode}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
                        <span>
                          الكمية: <strong className="text-slate-800">{item.qty}</strong> ×{' '}
                          {formatIQD(item.unitPrice)}
                        </span>
                        {item.nearestExpiryBatch && (
                          <>
                            <span>•</span>
                            <span>وجبة: {formatDateArabic(item.nearestExpiryBatch)}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-black text-slate-800">{formatIQD(item.totalAmount)}</span>
                      <button
                        onClick={() => onDeleteSale(item.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded-lg hover:bg-rose-50 transition"
                        title="حذف هذه المادة من الفاتورة"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((item) => {
            const cost =
              item.avgCostAtSale > 0 ? item.avgCostAtSale : (stocks[item.barcode]?.averageCost ?? 0);
            const totalProfit = (item.unitPrice - cost) * item.qty;

            return (
              <div
                key={item.id}
                className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-indigo-300 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <Barcode className="h-3 w-3 text-slate-400" />
                        {item.barcode}
                      </span>
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-slate-400" />
                        {formatDateArabic(item.date)}
                      </span>
                      <span className="text-[10px] font-bold bg-slate-900 text-amber-300 px-2 py-0.5 rounded-md">
                        بواسطة: {item.addedByName || 'فريق المبيعات'}
                      </span>
                    </div>
                    <h3 className="text-sm font-black text-slate-900 mt-1">{item.medicineName}</h3>
                    <p className="text-xs text-indigo-700 font-semibold mt-0.5 flex items-center gap-1">
                      <Building2 className="h-3 w-3 text-indigo-500" />
                      {item.buyer}
                    </p>
                  </div>

                  <div className="text-left">
                    <div className="text-base font-black text-indigo-950">
                      {formatIQD(item.totalAmount)}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {item.qty} باكيت × {formatIQD(item.unitPrice)}
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      صافي ربح: {formatIQD(totalProfit)}
                    </span>

                    {item.remainingUnpaid > 0 ? (
                      <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
                        باقي دين على الصيدلية: {formatIQD(item.remainingUnpaid)}
                      </span>
                    ) : (
                      <span className="text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                        واصل بالكامل كاش
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => onDeleteSale(item.id)}
                    className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition"
                    title="حذف"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Multi-Item Sale Invoice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 p-0 sm:p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full sm:max-w-3xl max-h-[94vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-4 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-indigo-800">
                  <ShoppingBag className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-base font-black text-slate-900">
                    إنشاء فاتورة بيع موحدة (عدة مواد بنفس القائمة)
                  </h2>
                  <p className="text-[11px] text-slate-500">
                    حدد الصيدلية أو العميل مرة واحدة، ثم امسح باركود المواد لإضافتها لنفس الفاتورة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-3 rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-bold text-rose-800 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitInvoice} className="space-y-4">
              {/* STEP 1: Buyer & Date (filled ONCE per invoice) */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200/90 p-3.5 space-y-3">
                <div className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                  <Building2 className="h-4 w-4 text-indigo-700" />
                  <span>1. بيانات الصيدلية / المشتري (تُكتب مرة واحدة لجميع المواد)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-6">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      اسم الصيدلية أو المذخر المشتري *
                    </label>
                    <input
                      type="text"
                      list="buyers-list"
                      required
                      value={buyer}
                      onChange={(e) => setBuyer(e.target.value)}
                      placeholder="مثال: صيدلية الشفاء - المنصور"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                    />
                    <datalist id="buyers-list">
                      {buyers.map((b) => (
                        <option key={b} value={b} />
                      ))}
                    </datalist>
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      تاريخ الفاتورة *
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رقم القائمة / ملاحظة
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="مثال: قائمة تجهيز صباحي"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* STEP 2: Rapid Item Entry by Barcode / Catalog Lookup */}
              <div className="rounded-2xl bg-indigo-50/50 border-2 border-indigo-200/80 p-3.5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                    <Barcode className="h-4 w-4 text-indigo-700" />
                    <span>2. إضافة مادة إلى فاتورة البيع (امسح الباركود لقراءة الاسم والسعر)</span>
                  </div>

                  {matchedFromSystem && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 text-emerald-800 px-2.5 py-0.5 text-[11px] font-black">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      تم التعرف على المادة تلقائياً
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                  {/* Barcode Input + Camera */}
                  <div className="sm:col-span-5">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      الباركود (كاميرا / جهاز ليزر / يدوي)
                    </label>
                    <div className="flex gap-1.5">
                      <input
                        ref={barcodeInputRef}
                        type="text"
                        value={barcode}
                        onChange={(e) => handleSelectBarcode(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSelectBarcode(barcode);
                          }
                        }}
                        placeholder="امسح الباركود هنا..."
                        className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-mono font-bold focus:border-indigo-600 focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          onOpenScanner((code) => {
                            handleSelectBarcode(code);
                          })
                        }
                        className="flex items-center gap-1 rounded-xl bg-indigo-700 px-3 py-2 text-xs font-bold text-white hover:bg-indigo-800 transition shrink-0"
                      >
                        <Camera className="h-4 w-4" />
                        <span>مسح</span>
                      </button>
                    </div>
                  </div>

                  {/* Medicine Name */}
                  <div className="sm:col-span-7">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      اسم المادة / الدواء (يُقرأ تلقائياً أو اختر من القائمة) *
                    </label>
                    <input
                      type="text"
                      list="medicines-catalog-sale"
                      value={medicineName}
                      onChange={(e) => handleSelectMedicineByName(e.target.value)}
                      placeholder="يظهر تلقائياً عند مسح الباركود أو اختر..."
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                    />
                    <datalist id="medicines-catalog-sale">
                      {Array.from(catalogMap.values()).map((m) => (
                        <option key={m.barcode} value={m.name}>
                          {m.barcode} (المتوفر: {stocks[m.barcode]?.remaining ?? 0})
                        </option>
                      ))}
                    </datalist>
                  </div>

                  {/* Quantity */}
                  <div className="sm:col-span-4">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      الكمية المباعة *
                    </label>
                    <input
                      ref={qtyInputRef}
                      type="number"
                      min="1"
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                      placeholder="مثال: 20"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Unit Sale Price */}
                  <div className="sm:col-span-4">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      سعر البيع للمادة (د.ع) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      placeholder="مثال: 3000"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Add to Invoice Button */}
                  <div className="sm:col-span-4 flex items-end">
                    <button
                      type="button"
                      onClick={handleAddLineToInvoice}
                      className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 py-2 px-3 text-xs font-black shadow-xs transition active:scale-95"
                    >
                      <Plus className="h-4 w-4" />
                      <span>إضافة للقائمة +</span>
                    </button>
                  </div>
                </div>

                {/* Live Stock & FEFO Nearest Expiry Advisory */}
                {selectedStock && (
                  <div className="rounded-xl bg-white/90 border border-indigo-200/80 p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex flex-wrap items-center gap-3">
                      <span>
                        الرصيد المتوفر:{' '}
                        <strong
                          className={
                            currentAvailableQty === 0
                              ? 'text-rose-600 font-black'
                              : 'text-emerald-700 font-black'
                          }
                        >
                          {currentAvailableQty} {selectedStock.unit}
                        </strong>
                      </span>
                      <span>
                        متوسط الكلفة: <strong>{formatIQD(selectedStock.averageCost)}</strong>
                      </span>
                      {nearestExpiryAdvice?.nearestExpiry && (
                        <span className="inline-flex items-center gap-1 text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
                          <Clock className="h-3 w-3" />
                          أقرب وجبة للصرف: {formatDateArabic(nearestExpiryAdvice.nearestExpiry)}
                        </span>
                      )}
                    </div>

                    {isStockExceeded && (
                      <span className="inline-flex items-center gap-1 text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md font-black">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        الكمية المطلوبة ({enteredQty}) تتجاوز المتوفر ({currentAvailableQty})!
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* STEP 3: Added Items Table in Current Sale Invoice */}
              {invoiceItems.length > 0 && (
                <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
                  <div className="bg-slate-100 px-3.5 py-2 flex items-center justify-between text-xs font-black text-slate-800">
                    <span>مواد فاتورة البيع الحالية ({invoiceItems.length} مواد)</span>
                    <span className="text-indigo-800">المجموع: {formatIQD(cartItemsTotal)}</span>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-52 overflow-y-auto">
                    {invoiceItems.map((line, idx) => (
                      <div
                        key={line.tempId}
                        className="p-3 sm:px-3.5 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <div className="font-black text-slate-900 truncate">
                              {idx + 1}. {line.medicineName}
                            </div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-2">
                              <span className="font-mono">{line.barcode}</span>
                              {line.nearestExpiryBatch && (
                                <span>• صلاحية: {formatDateArabic(line.nearestExpiryBatch)}</span>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span className="font-black text-indigo-950 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200/70">
                              {formatIQD(line.qty * line.unitPrice)}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleRemoveLine(line.tempId)}
                              className="text-rose-500 hover:bg-rose-50 p-1 rounded-lg"
                              title="إزالة من الفاتورة"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 items-center">
                          <div>
                            <label className="block text-[10px] text-slate-400 mb-0.5">الكمية</label>
                            <input
                              type="number"
                              min="1"
                              value={line.qty}
                              onChange={(e) => handleUpdateLine(line.tempId, 'qty', e.target.value)}
                              className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-400 mb-0.5">سعر البيع</label>
                            <input
                              type="number"
                              min="0"
                              value={line.unitPrice}
                              onChange={(e) =>
                                handleUpdateLine(line.tempId, 'unitPrice', e.target.value)
                              }
                              className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-bold"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 4: Invoice Grand Total, Profit Preview & Payment */}
              <div className="rounded-2xl bg-slate-50 p-3.5 border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-bold">
                    إجمالي مبلغ فاتورة البيع ({invoiceItems.length || (pendingDraftValid ? 1 : 0)}{' '}
                    مادة):
                  </span>
                  <span className="text-base font-black text-indigo-950">
                    {formatIQD(grandTotal)}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">الربح الصافي التقديري لهذه الفاتورة:</span>
                  <span
                    className={`font-black ${
                      grandEstimatedProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'
                    }`}
                  >
                    {formatIQD(grandEstimatedProfit)}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/70">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isPaidInFull}
                      onChange={(e) => setIsPaidInFull(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                    />
                    الفاتورة مدفوعة بالكامل (واصل نقداً كاش)
                  </label>
                </div>

                {!isPaidInFull && (
                  <div className="pt-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      المبلغ المقبوض نقداً من إجمالي الفاتورة (الباقي يُسجل دين على الصيدلية)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={grandTotal}
                      value={amountPaid}
                      onChange={(e) => setAmountPaid(e.target.value)}
                      placeholder="0 إذا كانت القائمة آجل بالكامل"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold focus:border-indigo-600 focus:outline-hidden"
                    />
                    <div className="text-[11px] text-amber-700 font-bold mt-1">
                      المتبقي دين على الصيدلية:{' '}
                      {formatIQD(Math.max(0, grandTotal - (parseFloat(amountPaid) || 0)))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 rounded-xl bg-indigo-700 py-3 px-3 text-xs font-black text-white shadow-sm hover:bg-indigo-800 transition"
                >
                  <Check className="h-4 w-4 shrink-0" />
                  <span>
                    حفظ الفاتورة ({invoiceItems.length + (pendingDraftValid ? 1 : 0)})
                  </span>
                </button>
                {onPrintInvoice && (
                  <button
                    type="button"
                    onClick={() => saveInvoiceInternal(true)}
                    className="flex-1 min-w-[160px] flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 py-3 px-3 text-xs font-black text-amber-300 shadow-sm transition"
                  >
                    <Printer className="h-4 w-4 shrink-0" />
                    <span>حفظ وترتيب للطباعة</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl bg-slate-100 px-4 py-3 text-xs font-bold text-slate-600 hover:bg-slate-200 transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
