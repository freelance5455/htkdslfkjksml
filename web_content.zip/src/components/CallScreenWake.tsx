import React, { useState, useEffect, useRef } from 'react';
import { 
  Eye, 
  EyeOff, 
  PhoneCall, 
  PhoneOff, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  ShieldCheck, 
  Smartphone, 
  Flame, 
  Sparkles, 
  Info, 
  Mic, 
  Volume2, 
  Grid3X3,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  requestScreenWakeLock, 
  releaseScreenWakeLock, 
  isWakeLockActive, 
  isWakeLockSupported 
} from '../utils/wakeLock';

export const CallScreenWake: React.FC = () => {
  // Persistent toggle state from localStorage
  const [isEnabled, setIsEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('screensound_keep_screen_on_call');
    return saved ? JSON.parse(saved) : true;
  });

  const [wakeLockStatus, setWakeLockStatus] = useState<string>('');
  const [isSystemActive, setIsSystemActive] = useState<boolean>(false);
  const [showCallSimulator, setShowCallSimulator] = useState<boolean>(false);
  const [simCallState, setSimCallState] = useState<'idle' | 'calling' | 'active'>('idle');
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isSpeakerOn, setIsSpeakerOn] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [simulatedProximityCovered, setSimulatedProximityCovered] = useState<boolean>(false);
  const [expandedSection, setExpandedSection] = useState<string | null>('calibration');

  const timerRef = useRef<number | null>(null);

  // Initialize and persist toggle
  useEffect(() => {
    localStorage.setItem('screensound_keep_screen_on_call', JSON.stringify(isEnabled));

    if (isEnabled) {
      applyWakeLock();
    } else {
      removeWakeLock();
    }
  }, [isEnabled]);

  // Handle visibility change (re-acquire wake lock if active)
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'visible' && isEnabled) {
        applyWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [isEnabled]);

  const applyWakeLock = async () => {
    const res = await requestScreenWakeLock();
    setWakeLockStatus(res.message);
    setIsSystemActive(isWakeLockActive());
  };

  const removeWakeLock = async () => {
    await releaseScreenWakeLock();
    setWakeLockStatus('تم إيقاف إبقاء الشاشة. ستخضع الشاشة لمهلة الإغلاق الافتراضية للجهاز.');
    setIsSystemActive(false);
  };

  const handleToggle = () => {
    setIsEnabled((prev) => !prev);
  };

  // Call simulation timers
  useEffect(() => {
    if (simCallState === 'active') {
      timerRef.current = window.setInterval(() => {
        setCallDuration((c) => c + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setCallDuration(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [simCallState]);

  const startSimCall = () => {
    setSimCallState('calling');
    setTimeout(() => {
      setSimCallState('active');
    }, 1500);
  };

  const endSimCall = () => {
    setSimCallState('idle');
    setSimulatedProximityCovered(false);
  };

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Header and intro */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-500 mb-1">
              <Sparkles className="w-4 h-4" />
              <span>ميزة إصلاح مشاكل حساس القرب (Proximity Sensor)</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white font-heading">
              إبقاء الشاشة أثناء المكالمة
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              تساعد هذه الخاصية في منع انطفاء الشاشة المفاجئ أثناء إجراء واستقبال المكالمات، وخاصة عندما يتعطل حساس القرب بسبب تراكم الغبار، أو لاصقات الحماية الرديئة، أو العيوب المصنعية.
            </p>
          </div>

          {/* Quick Hardware Status Indicator */}
          <div className="flex items-center gap-2 bg-slate-950/80 px-4 py-2.5 rounded-2xl border border-slate-800 self-start sm:self-auto shrink-0">
            <span className={`w-2.5 h-2.5 rounded-full ${isSystemActive ? 'bg-emerald-500 ring-4 ring-emerald-500/20' : 'bg-slate-500'}`} />
            <span className="text-xs font-medium text-slate-200">
              {isSystemActive ? 'الحماية نشطة حالياً' : 'الحماية متوقفة'}
            </span>
          </div>
        </div>

        {/* The Master Toggle Switch */}
        <div className="mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-950 border-2 border-red-900/40 hover:border-red-600/70 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4 transition-all">
            <div className="space-y-1">
              <label htmlFor="wake-toggle" className="text-base sm:text-lg font-bold text-white cursor-pointer select-none">
                إبقاء الهاتف شغّالًا أثناء المكالمة
              </label>
              <p className="text-xs text-slate-400">
                {isEnabled 
                  ? 'الخيار مفعّل ومحفوظ. يمنع خمول الشاشة ويحاول إجبار النظام على إبقاء الشاشة مضاءة.' 
                  : 'الخيار معطل. انقر للتفعيل والحفظ الدائم حتى توقفه بنفسك.'}
              </p>
            </div>

            {/* Custom High Contrast Big Switch */}
            <button
              id="wake-toggle"
              type="button"
              role="switch"
              aria-checked={isEnabled}
              onClick={handleToggle}
              className={`relative inline-flex h-9 w-16 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2 focus:ring-offset-slate-950 ${
                isEnabled ? 'bg-red-600' : 'bg-slate-800'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-8 w-8 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  isEnabled ? '-translate-x-7' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Status Message */}
          <div className="mt-3 flex items-start gap-2 text-xs text-slate-400 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
            <Info className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold text-slate-200">حالة الواجهة البرمجية: </span>
              <span>{wakeLockStatus || (isWakeLockSupported() ? 'النظام جاهز لدعم Screen Wake Lock' : 'سيتم تطبيق خوارزمية التنشيط الدوري للمتصفح')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Call & Proximity Sensor Simulator */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-red-600/10 text-red-500 flex items-center justify-center font-bold">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                محاكي واختبار المكالمات الحية
              </h3>
              <p className="text-xs text-slate-400">
                اختبر استجابة الشاشة وسلوك حساس القرب أثناء محاكاة مكالمة هاتفية حقيقية
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowCallSimulator(!showCallSimulator)}
            className="text-xs font-bold text-red-400 hover:text-red-300 bg-red-950/40 border border-red-900/50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
          >
            {showCallSimulator ? 'إخفاء المحاكي' : 'فتح واجهة الاختبار'}
          </button>
        </div>

        {showCallSimulator && (
          <div className="mt-4 pt-4 border-t border-slate-800">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Phone Calling Frame */}
              <div className="relative bg-black border-2 border-slate-700 rounded-3xl p-5 overflow-hidden flex flex-col justify-between min-h-[340px]">
                {/* Simulated Screen Shutoff Overlay if Proximity is blocked and wake lock wasn't forced */}
                {simulatedProximityCovered && !isEnabled && (
                  <div className="absolute inset-0 bg-black z-30 flex flex-col items-center justify-center p-6 text-center">
                    <EyeOff className="w-10 h-10 text-slate-600 mb-2" />
                    <p className="text-sm font-bold text-slate-400">
                      الشاشة انطفأت بالكامل! (سلوك الحساس المعطل)
                    </p>
                    <p className="text-xs text-slate-600 mt-1">
                      لا يمكنك الضغط على زر إنهاء المكالمة أو لوحة الأرقام! قم بتفعيل زر «إبقاء الهاتف شغّالاً» لمنع هذه المشكلة.
                    </p>
                    <button
                      onClick={() => setSimulatedProximityCovered(false)}
                      className="mt-4 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg"
                    >
                      إبعاد اليد يدوياً
                    </button>
                  </div>
                )}

                {/* Simulated Proximity Protected Badge */}
                {simulatedProximityCovered && isEnabled && (
                  <div className="absolute top-2 inset-x-2 z-20 bg-emerald-600 text-white text-[11px] font-bold py-1 px-3 rounded-lg flex items-center justify-between shadow-lg">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      الحماية تعمل: تم منع الشاشة من الانطفاء رغم انسداد الحساس!
                    </span>
                    <button
                      onClick={() => setSimulatedProximityCovered(false)}
                      className="text-emerald-100 hover:text-white underline text-[10px]"
                    >
                      إلغاء الانسداد
                    </button>
                  </div>
                )}

                {/* Top Notch & Earpiece Sensor */}
                <div className="flex flex-col items-center">
                  <div className="w-20 h-1.5 bg-slate-800 rounded-full mb-3" />
                  <div className="text-center">
                    <p className="text-xs text-slate-400">
                      {simCallState === 'idle' ? 'جاهز للمكالمة' : simCallState === 'calling' ? 'جارٍ الاتصال...' : 'مكالمة جارية'}
                    </p>
                    <p className="text-lg font-bold text-white mt-0.5">
                      خدمة الدعم الفني - العجردي
                    </p>
                    {simCallState === 'active' && (
                      <p className="text-xs font-mono text-emerald-400 font-bold mt-1">
                        {formatDuration(callDuration)}
                      </p>
                    )}
                  </div>
                </div>

                {/* Mid controls */}
                <div className="grid grid-cols-3 gap-3 my-4">
                  <button
                    disabled={simCallState !== 'active'}
                    onClick={() => setIsMuted(!isMuted)}
                    className={`p-3 rounded-2xl flex flex-col items-center justify-center transition-all ${
                      isMuted ? 'bg-red-600 text-white' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                    } ${simCallState !== 'active' ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
                  >
                    <Mic className="w-5 h-5 mb-1" />
                    <span className="text-[10px]">كتم الصوت</span>
                  </button>

                  <button
                    disabled={simCallState !== 'active'}
                    className={`p-3 rounded-2xl flex flex-col items-center justify-center bg-slate-900 text-slate-300 hover:bg-slate-800 ${
                      simCallState !== 'active' ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
                    }`}
                  >
                    <Grid3X3 className="w-5 h-5 mb-1" />
                    <span className="text-[10px]">لوحة الأرقام</span>
                  </button>

                  <button
                    disabled={simCallState !== 'active'}
                    onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                    className={`p-3 rounded-2xl flex flex-col items-center justify-center transition-all ${
                      isSpeakerOn ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                    } ${simCallState !== 'active' ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
                  >
                    <Volume2 className="w-5 h-5 mb-1" />
                    <span className="text-[10px]">مكبر الصوت</span>
                  </button>
                </div>

                {/* Bottom Call Action buttons */}
                <div className="flex items-center justify-center gap-4">
                  {simCallState === 'idle' ? (
                    <button
                      onClick={startSimCall}
                      className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-all cursor-pointer"
                    >
                      <PhoneCall className="w-6 h-6" />
                    </button>
                  ) : (
                    <button
                      onClick={endSimCall}
                      className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-all cursor-pointer"
                    >
                      <PhoneOff className="w-6 h-6" />
                    </button>
                  )}
                </div>
              </div>

              {/* Sensor Test Trigger Controls */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Eye className="w-4 h-4 text-red-500" />
                    اختبار استجابة حساس القرب الافتراضي
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    اضغط على الزر أدناه لمحاكاة وضع الهاتف على أذنك أو تراكم الغبار على الحساس العلوي لترى كيف يتصرف التطبيق:
                  </p>

                  <div className="mt-4 space-y-2">
                    <button
                      onClick={() => setSimulatedProximityCovered(true)}
                      className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-medium text-xs p-3 rounded-xl flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>محاكاة: تقريب الهاتف من الأذن / غبار على الحساس</span>
                      <span className="text-red-400 font-bold">تغطية الحساس</span>
                    </button>

                    <button
                      onClick={() => setSimulatedProximityCovered(false)}
                      className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-medium text-xs p-3 rounded-xl flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>محاكاة: إبعاد الهاتف عن الأذن</span>
                      <span className="text-emerald-400 font-bold">كشف الحساس</span>
                    </button>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-red-950/30 border border-red-900/40 rounded-xl text-xs text-red-200">
                  <span className="font-bold">الملاحظة الفنية: </span>
                  عند تفعيل الزر الرئيسي، يُصدر التطبيق إشارة قفل شاشة دائمة لمنع إيقاف العرض العشوائي، مما يتيح لك رؤية أزرار المكالمة دائماً.
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Android Limitations & Official Solutions Guide */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">
              القيود الرسمية في نظام أندرويد والحلول البديلة المضمونة
            </h3>
            <p className="text-xs text-slate-400">
              دليل تقني صريح من فريق العجردي لكيفية التغلب على عطل الحساس في مختلف الأجهزة
            </p>
          </div>
        </div>

        {/* Collapsible Explanations and Instructions */}
        <div className="space-y-3 pt-2">
          {/* Solution 1: Android System Limitation Explanation */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
            <button
              onClick={() => setExpandedSection(expandedSection === 'limits' ? null : 'limits')}
              className="w-full p-4 flex items-center justify-between text-right font-bold text-sm text-slate-200 hover:bg-slate-900/50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-red-500" />
                لماذا يفرض نظام أندرويد قيوداً أثناء المكالمات العادية؟
              </span>
              {expandedSection === 'limits' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {expandedSection === 'limits' && (
              <div className="p-4 pt-0 text-xs text-slate-300 space-y-2 border-t border-slate-900 leading-relaxed">
                <p>
                  بداية من نظام أندرويد 8.1 (Oreo) والإصدارات الأحدث، تمنح شركة Google تطبيق الاتصال الافتراضي (InCallService / Telecom Framework) صلاحيات أمان عليا تجعله يتحكم مباشرة في حساس القرب لشاشة القفل دون السماح لأي تطبيق خارجي بإلغاء إطفاء الشاشة بالقوة التامة أثناء وضع الهاتف بمحاذاة الرأس.
                </p>
                <p>
                  لذلك، إذا كان حساس هاتفك معطلاً مادياً (Hardware Glitch) أو مسدوداً تماماً، فإليك أدناه الحلول الرسمية المجربة في ورشة العجردي لحل المشكلة جذرياً.
                </p>
              </div>
            )}
          </div>

          {/* Solution 2: Secret Codes & Hardware Calibration */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
            <button
              onClick={() => setExpandedSection(expandedSection === 'calibration' ? null : 'calibration')}
              className="w-full p-4 flex items-center justify-between text-right font-bold text-sm text-slate-200 hover:bg-slate-900/50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                أكواد المعايرة الرسمية لحساس القرب (سامسونج، شاومي، هواوي)
              </span>
              {expandedSection === 'calibration' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {expandedSection === 'calibration' && (
              <div className="p-4 pt-0 text-xs text-slate-300 space-y-3 border-t border-slate-900 leading-relaxed">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="font-bold text-white block mb-1">هواتف Samsung:</span>
                    <p className="text-slate-400">افتح لوحة الاتصال واطلب الكود:</p>
                    <div className="mt-1 font-mono text-red-400 font-bold bg-slate-950 p-1.5 rounded text-center text-sm">
                      *#77692# أو *#0*#
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      اختر <span className="text-slate-200 font-semibold">Sensor</span> ثم اضغط <span className="text-slate-200 font-semibold">Proximity Sensor Calibration</span>.
                    </p>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="font-bold text-white block mb-1">هواتف Xiaomi / Redmi / POCO:</span>
                    <p className="text-slate-400">افتح الإعدادات &gt; حول الهاتف &gt; انقر على "إصدار النواة (Kernel)" 5 مرات متتالية:</p>
                    <div className="mt-1 font-mono text-emerald-400 font-bold bg-slate-950 p-1.5 rounded text-center text-sm">
                      CIT Test &gt; Proximity Sensor
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      ضع الهاتف مستوياً واضغط <span className="text-slate-200 font-semibold">Calibrate</span>.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="font-bold text-white block mb-1">هواتف Huawei / Honor / Oppo:</span>
                  <p className="text-slate-400">
                    اطلب الكود <code className="text-amber-400 font-mono">*#*#2846579#*#*</code> أو ادخل إلى <code className="text-amber-400 font-mono">*#899#</code> للدخول إلى قائمة المهندسين ومعايرة الحساس.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Solution 3: Power button ends call (Never get stuck) */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
            <button
              onClick={() => setExpandedSection(expandedSection === 'powerbutton' ? null : 'powerbutton')}
              className="w-full p-4 flex items-center justify-between text-right font-bold text-sm text-slate-200 hover:bg-slate-900/50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-blue-400" />
                الحل المنقذ: تفعيل «زر التشغيل لإنهاء المكالمة»
              </span>
              {expandedSection === 'powerbutton' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {expandedSection === 'powerbutton' && (
              <div className="p-4 pt-0 text-xs text-slate-300 space-y-2 border-t border-slate-900 leading-relaxed">
                <p>
                  إذا انطفأت شاشتك ولم تستجب للمس أثناء مكالمة مهمة أو الرد الآلي، فإن تفعيل هذا الخيار في أندرويد يضمن لك إنهاء المكالمة فوراً بضغطة واحدة على زر التشغيل الجانبي:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 bg-slate-900 p-3 rounded-xl">
                  <li>افتح <span className="font-bold text-white">إعدادات الهاتف (Settings)</span>.</li>
                  <li>توجه إلى <span className="font-bold text-white">إمكانية الوصول (Accessibility)</span>.</li>
                  <li>فعّل خيار <span className="font-bold text-emerald-400">زر التشغيل ينهي المكالمة (Power button ends call)</span>.</li>
                </ol>
              </div>
            )}
          </div>

          {/* Solution 4: Physical Cleaning Guide */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
            <button
              onClick={() => setExpandedSection(expandedSection === 'cleaning' ? null : 'cleaning')}
              className="w-full p-4 flex items-center justify-between text-right font-bold text-sm text-slate-200 hover:bg-slate-900/50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-500" />
                طريقة تنظيف مكان الحساس المادي بدون فك الهاتف
              </span>
              {expandedSection === 'cleaning' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {expandedSection === 'cleaning' && (
              <div className="p-4 pt-0 text-xs text-slate-300 space-y-2 border-t border-slate-900 leading-relaxed">
                <p>
                  في 80% من الهواتف التي تصل إلى ورشة <span className="font-bold text-white">العجردي</span>، يكون سبب عطل الحساس هو:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-300 bg-slate-900 p-3 rounded-xl">
                  <li>تراكم وبر الجيب وأتربة العرق في شبكة سماعة المكالمات العلوية الصغيرة (Earpiece Grill).</li>
                  <li>تركيب لاصقة حماية زجاجية رخيصة بدون فتحة مخصصة لمستشعر الأشعة تحت الحمراء.</li>
                  <li>حل الفني: استخدم فرشاة أسنان جافة وناعمة جداً مع قطرة كحول إيزوبروبيلي (99%) ومررها برفق شديد على الشق العلوي للهاتف.</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
