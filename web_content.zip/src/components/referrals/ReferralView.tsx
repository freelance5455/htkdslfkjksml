import React, { useState } from 'react';
import { 
  Users, 
  Copy, 
  Check, 
  Share2, 
  Gift, 
  Sparkles, 
  Coins 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ReferralView: React.FC = () => {
  const { 
    currentUser, 
    allUsers, 
    systemSettings, 
    language, 
    t 
  } = useApp();

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const refCode = currentUser?.referralCode || 'TASKPRO';
  const appUrl = window.location.origin;
  const referralLink = `${appUrl}?ref=${refCode}`;

  // Find users referred by current user
  const referredUsers = allUsers.filter(u => u.referredBy?.toUpperCase() === refCode.toUpperCase());
  const totalRefCoins = referredUsers.length * systemSettings.referralBonusCoins;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(refCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `Earn rewards for completing daily tasks & syncing Google Tasks on Task Earn Pro! Use my invite code: ${refCode} to get 50 bonus coins: ${referralLink}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleShareTelegram = () => {
    const text = encodeURIComponent(
      `Join Task Earn Pro & earn coins daily! Use code ${refCode} for welcome bonus.`
    );
    window.open(`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${text}`, '_blank');
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
          <Gift className="w-3.5 h-3.5" />
          <span>Referral Program</span>
        </div>
        <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
          {t('referralTitle')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          {t('referralSubtitle')}
        </p>
      </div>

      {/* Exact User Requested Bengali Notice & Action Buttons Card */}
      <div className="max-w-2xl mx-auto p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/80 to-slate-950 border border-amber-500/40 shadow-xl space-y-3 text-xs text-slate-200">
        <div className="space-y-1">
          <h4 className="text-sm font-black text-amber-400 flex items-center gap-1.5">
            <span>🎁</span>
            <span>বন্ধুকে Invite করুন, ₹50 Bonus পান!</span>
          </h4>
          <p className="text-slate-300 leading-relaxed">
            আপনার Referral Link শেয়ার করুন। আপনার বন্ধু সেই লিংক ব্যবহার করে ₹200-এর VIP Plan কিনে সফলভাবে payment করলে আপনি পাবেন ₹50 Referral Bonus।
          </p>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-1.5 text-[11px]">
          <div className="font-bold text-amber-300">💳 VIP Payment (VIP Plan: ₹200)</div>
          <p className="text-slate-400">
            Payment করার পর চাইলে Gallery থেকে Payment Screenshot আপলোড করে Payment Proof Submit করতে পারবেন।
          </p>
          <p className="text-rose-400 text-[10px] font-semibold">
            Important: Screenshot upload করলেই payment automatically verified হবে না। Admin/payment gateway verification সফল হওয়ার পরেই VIP activation এবং ₹50 referral bonus credit হবে।
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
          <button
            type="button"
            onClick={handleCopyLink}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
          >
            <span>[Buy VIP ₹200]</span>
          </button>

          <button
            type="button"
            onClick={handleCopyLink}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-amber-300 font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
          >
            <span>[Upload Screenshot]</span>
          </button>

          <button
            type="button"
            onClick={handleCopyLink}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-emerald-400 font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
          >
            <span>[Submit Proof]</span>
          </button>

          <button
            type="button"
            onClick={handleCopyLink}
            className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
          >
            <span>[My Referral Link]</span>
          </button>
        </div>
      </div>

      {/* Referral Code & Link Box */}
      <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-emerald-900 via-slate-900 to-slate-900 text-white border border-emerald-800/60 shadow-xl space-y-6">
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Code */}
          <div className="p-4 rounded-2xl bg-black/30 border border-emerald-500/30 space-y-1.5">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
              {t('yourReferralCode')}
            </span>
            <div className="flex items-center justify-between gap-2">
              <span className="text-2xl font-black tracking-wider text-amber-300 font-mono">
                {refCode}
              </span>
              <button
                onClick={handleCopyCode}
                className="p-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 transition-colors cursor-pointer"
                title="Copy code"
              >
                {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Bonus Info */}
          <div className="p-4 rounded-2xl bg-black/30 border border-emerald-500/30 space-y-1">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
              Reward per Friend
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-white">
                +{systemSettings.referralBonusCoins}
              </span>
              <span className="text-xs text-slate-300">Coins each</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Friend also gets +{systemSettings.referredUserBonusCoins} Coins on registration!
            </p>
          </div>

        </div>

        {/* Link Input & Copy */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">
            {t('referralLink')}
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              readOnly
              value={referralLink}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/40 border border-slate-700 text-xs font-mono text-slate-200 select-all"
            />
            <button
              onClick={handleCopyLink}
              className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? t('copied') : t('copy')}</span>
            </button>
          </div>
        </div>

        {/* Social Share Buttons */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            onClick={handleShareWhatsApp}
            className="flex-1 py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>{t('shareViaWhatsapp')}</span>
          </button>
          <button
            onClick={handleShareTelegram}
            className="flex-1 py-2.5 px-4 rounded-xl bg-[#229ED9] hover:bg-[#1e8ec3] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>{t('shareViaTelegram')}</span>
          </button>
        </div>

      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400">{t('friendsReferred')}</span>
            <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {referredUsers.length}
            </p>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400">{t('referralEarnings')}</span>
            <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              🪙 {totalRefCoins.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* Referred Users List */}
      <div className="max-w-2xl mx-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
          {t('referredUsersList')} ({referredUsers.length})
        </h3>

        {referredUsers.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-6">
            No friends joined using your code yet. Share your code to earn your first bonus!
          </p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {referredUsers.map((u) => (
              <div key={u.id} className="py-3 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <p className="font-bold text-slate-800 dark:text-slate-200">{u.name}</p>
                  <p className="text-[11px] text-slate-400">Joined: {new Date(u.joinedAt).toLocaleDateString()}</p>
                </div>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  +{systemSettings.referralBonusCoins} Coins
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
