"use client";

import React, { useState } from "react";
import {
  CoinTechnicalAnalysis,
  formatPriceNumber,
} from "@/services/technicalEngine";
import { Gauge, Flame, TrendingUp, TrendingDown, BarChart3 } from "lucide-react";

interface HeatmapCoin extends CoinTechnicalAnalysis {
  nameHe: string;
  sectorHe: string;
  marketCapBillions: number;
}

interface FinvizHeatmapModuleProps {
  coins: HeatmapCoin[];
  fearGreed: {
    value: number;
    labelHe: string;
    yesterdayValue: number;
    lastWeekValue: number;
  };
  onSelectCoin: (symbol: string) => void;
}

export function FinvizHeatmapModule({
  coins,
  fearGreed,
  onSelectCoin,
}: FinvizHeatmapModuleProps) {
  const [selectedSector, setSelectedSector] = useState<string>("ALL");

  const safeCoins = Array.isArray(coins) ? coins : [];
  const sectors = ["ALL", ...Array.from(new Set(safeCoins.map((c) => c.sectorHe)))];

  const filteredCoins =
    selectedSector === "ALL"
      ? safeCoins
      : safeCoins.filter((c) => c.sectorHe === selectedSector);

  const getTileBgColor = (pct: number) => {
    if (pct >= 3.5) return "bg-[#00C853] border-[#00E676] text-[#0B0E14]";
    if (pct >= 1.2) return "bg-[#00E676]/80 border-[#00E676] text-[#0B0E14]";
    if (pct >= 0) return "bg-[#00E676]/30 border-[#00E676]/50 text-[#F1F5F9]";
    if (pct >= -1.5) return "bg-[#FF3B69]/30 border-[#FF3B69]/50 text-[#F1F5F9]";
    if (pct >= -3.5) return "bg-[#FF3B69]/75 border-[#FF3B69] text-white";
    return "bg-[#D50000] border-[#FF3B69] text-white";
  };

  return (
    <div dir="rtl" className="space-y-6">
      {/* Top Row: Fear & Greed Gauge + Market Breadth Stats */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Fear & Greed Index Widget (5 cols) */}
        <div className="lg:col-span-5 rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gauge className="h-5 w-5 text-[#F59E0B]" />
              <h3 className="text-base font-bold text-[#F1F5F9]">
                מדד הפחד ותאוות הבצע (Fear &amp; Greed Index)
              </h3>
            </div>
            <span className="rounded-full bg-[#F59E0B]/15 px-2.5 py-0.5 font-mono text-xs font-bold text-[#F59E0B]">
              LIVE
            </span>
          </div>

          <div className="mt-4 flex items-center justify-between gap-4">
            <div>
              <div className="font-mono text-4xl font-extrabold text-[#F1F5F9]">
                {fearGreed?.value || 62}
                <span className="text-lg text-[#64748B]">/100</span>
              </div>
              <div className="mt-1 text-sm font-bold text-[#00E676]">
                {fearGreed?.labelHe || "תאוות בצע (Greed)"}
              </div>
              <div className="mt-3 flex gap-4 text-xs text-[#94A3B8]">
                <span>
                  אתמול:{" "}
                  <strong className="font-mono text-[#F1F5F9]">
                    {fearGreed?.yesterdayValue || 59}
                  </strong>
                </span>
                <span>
                  שבוע שעבר:{" "}
                  <strong className="font-mono text-[#F1F5F9]">
                    {fearGreed?.lastWeekValue || 55}
                  </strong>
                </span>
              </div>
            </div>

            {/* Semi-Circular Gauge Progress */}
            <div className="w-44">
              <div className="mb-1.5 flex justify-between text-[10px] font-bold text-[#94A3B8]">
                <span className="text-[#FF3B69]">פחד קיצוני (0)</span>
                <span className="text-[#00E676]">תאוות בצע (100)</span>
              </div>
              <div className="h-3.5 w-full overflow-hidden rounded-full bg-gradient-to-l from-[#00E676] via-[#F59E0B] to-[#FF3B69] p-0.5">
                <div
                  className="h-full rounded-full bg-white shadow"
                  style={{
                    width: "8px",
                    marginRight: `${Math.min(95, Math.max(4, fearGreed?.value || 62))}%`,
                  }}
                />
              </div>
              <p className="mt-2 text-[11px] text-[#64748B]">
                מחושב לפי מומנטום RSI מצרפי, יחס נפחי קנייה/מכירה ורוחב שוק.
              </p>
            </div>
          </div>
        </div>

        {/* Market Dominance & Sector Filter (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Flame className="h-5 w-5 text-[#00E676]" />
              <h3 className="text-base font-bold text-[#F1F5F9]">
                מפת חום Finviz מוסדית (לפי שווי שוק ושינוי 24 שעות)
              </h3>
            </div>
            <span className="text-xs text-[#94A3B8]">
              לחץ על כל משבצת לפתיחת ניתוח עומק וגרף נרות
            </span>
          </div>

          {/* Sector Filter Pills */}
          <div className="mt-4 flex flex-wrap gap-2">
            {sectors.map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => setSelectedSector(sec)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  selectedSector === sec
                    ? "bg-[#3B82F6] text-white"
                    : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                }`}
              >
                {sec === "ALL" ? "כל הסקטורים (12 נכסים מובילים)" : sec}
              </button>
            ))}
          </div>

          {/* Color Scale Legend */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#222B3A] pt-3 text-xs">
            <span className="text-[#94A3B8]">מקרא תשואה יומית:</span>
            <div className="flex items-center gap-1.5 font-mono text-[11px]">
              <span className="rounded bg-[#D50000] px-2 py-0.5 text-white">
                -5%
              </span>
              <span className="rounded bg-[#FF3B69]/75 px-2 py-0.5 text-white">
                -2.5%
              </span>
              <span className="rounded bg-[#181F2C] px-2 py-0.5 text-[#94A3B8]">
                0%
              </span>
              <span className="rounded bg-[#00E676]/80 px-2 py-0.5 text-[#0B0E14] font-bold">
                +2.5%
              </span>
              <span className="rounded bg-[#00C853] px-2 py-0.5 text-[#0B0E14] font-bold">
                +5%+
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Finviz Proportional Treemap Grid */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-12">
        {filteredCoins.map((coin) => {
          // Proportional column & row spans based on Market Cap weight (BTC & ETH largest)
          let colSpanClass = "lg:col-span-3 sm:col-span-2 col-span-1 min-h-[135px]";
          if (coin.symbol === "BTCUSDT") {
            colSpanClass = "lg:col-span-5 sm:col-span-2 col-span-2 min-h-[210px]";
          } else if (coin.symbol === "ETHUSDT") {
            colSpanClass = "lg:col-span-4 sm:col-span-2 col-span-2 min-h-[210px]";
          } else if (coin.symbol === "SOLUSDT" || coin.symbol === "XRPUSDT") {
            colSpanClass = "lg:col-span-3 sm:col-span-2 col-span-1 min-h-[175px]";
          }

          return (
            <button
              key={coin.symbol}
              type="button"
              onClick={() => onSelectCoin(coin.symbol)}
              className={`${colSpanClass} ${getTileBgColor(
                coin.change24hPct
              )} group relative flex flex-col justify-between rounded-xl border p-4 text-right transition hover:scale-[1.01] hover:shadow-xl`}
            >
              <div className="flex w-full items-start justify-between">
                <div>
                  <span className="font-mono text-xl font-extrabold tracking-tight">
                    {coin.baseAsset}
                  </span>
                  <span className="block text-xs opacity-85">{coin.nameHe}</span>
                </div>
                <span className="rounded bg-black/25 px-2 py-0.5 font-mono text-xs font-bold">
                  RSI {coin.rsi14}
                </span>
              </div>

              <div className="my-2">
                <div className="font-mono text-2xl font-extrabold">
                  ${formatPriceNumber(coin.currentPrice)}
                </div>
                <div className="mt-0.5 inline-flex items-center gap-1 font-mono text-sm font-bold">
                  {coin.change24hPct >= 0 ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  <span>
                    {coin.change24hPct >= 0 ? "+" : ""}
                    {coin.change24hPct}%
                  </span>
                </div>
              </div>

              <div className="flex w-full items-center justify-between border-t border-black/15 pt-2 text-[11px] font-semibold opacity-90">
                <span>שווי שוק: ${coin.marketCapBillions}B</span>
                <span className="inline-flex items-center gap-1">
                  <BarChart3 className="h-3 w-3" />
                  {coin.recommendationLabelHe}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
