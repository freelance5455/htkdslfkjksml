import React, { useState } from 'react';
import { ShieldCheck, UserPlus, Sparkles, CheckCircle2, Phone, Mail, User } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { membersRegistryService } from '../lib/membersRegistryService';

interface SignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const SignupModal: React.FC<SignupModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [name, setName] = useState<string>('Prophetic Believer');
  const [email, setEmail] = useState<string>('believer@juhnkrixmusika.com');
  const [phone, setPhone] = useState<string>('+2347071918280');
  const [tier, setTier] = useState<string>('Anointed Member');
  const [successMsg, setSuccessMsg] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newMember = membersRegistryService.registerNewMember({
        fullName: name,
        email,
        phoneNumber: phone,
        membershipTier: tier as any
      });
      const memberData = {
        id: newMember.id,
        name,
        email,
        phone,
        tier,
        registeredAt: newMember.registeredAt,
        isRegisteredMember: true
      };
      localStorage.setItem('juhnkrix_registered_member', 'true');
      localStorage.setItem('juhnkrix_member_profile', JSON.stringify(memberData));
      offlineCache.saveProfile?.(memberData);
    } catch (err) {
      console.error(err);
    }

    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      onSuccess();
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/50 border-2 border-amber-500/50 rounded-3xl w-full max-w-md p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
        
        {/* Glow effect */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between border-b border-amber-500/30 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-amber-500/20">
              <UserPlus className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-serif text-amber-100">JUHNKRIX MUSIKA Signup</h2>
              <p className="text-xs text-amber-300/80 font-mono">Official Member Registration Portal</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition-colors"
          >
            ✕
          </button>
        </div>

        {successMsg ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-emerald-300 font-serif">Welcome to JUHNKRIX MUSIKA!</h3>
            <p className="text-xs text-slate-300">Your membership has been successfully registered. Access to Text Messages, WhatsApp, and Downloads is now unlocked.</p>
          </div>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs text-amber-200 font-bold flex items-center space-x-1.5">
                <User className="w-3.5 h-3.5 text-amber-400" />
                <span>Full Name / Prophetic Name</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-slate-100 text-xs focus:border-amber-400 focus:outline-none"
                placeholder="Enter your full name"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-amber-200 font-bold flex items-center space-x-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>Email Address</span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-slate-100 text-xs focus:border-amber-400 focus:outline-none"
                placeholder="Enter your email"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-amber-200 font-bold flex items-center space-x-1.5">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Mobile Phone Number (SIM Carrier)</span>
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-slate-100 text-xs focus:border-amber-400 focus:outline-none font-mono"
                placeholder="+2347071918280"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-amber-200 font-bold flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Membership Tier</span>
              </label>
              <select
                value={tier}
                onChange={(e) => setTier(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-slate-100 text-xs focus:border-amber-400 focus:outline-none"
              >
                <option value="Anointed Member">Anointed Member (Standard)</option>
                <option value="Prophetic Partner">Prophetic Partner (VIP)</option>
                <option value="Sanctuary Elder">Sanctuary Elder</option>
              </select>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed italic">
              By signing up, you gain full member access to JUHNKRIX MUSIKA Text Messages, WhatsApp hotline (+2347071918280), and Download repositories.
            </p>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:scale-[1.02] transition-all flex items-center justify-center space-x-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>COMPLETE REGISTRATION & JOIN</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
