import React, { useState, useEffect, useCallback } from 'react';
import { 
  X, 
  Bell, 
  CheckCheck, 
  Trash2, 
  Sparkles, 
  Award, 
  ClipboardList, 
  BookOpen, 
  Info, 
  ExternalLink, 
  RefreshCw, 
  Filter, 
  Check, 
  ChevronRight,
  Volume2,
  Settings
} from 'lucide-react';
import { AppNotification, Language } from '../types';
import { requestPushPermission, getPushPermissionStatus } from '../services/notificationService';

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userId?: string;
  userExam?: string;
  onNavigateTab?: (tab: string) => void;
  onUnreadCountChange?: (count: number) => void;
}

export default function NotificationCenterModal({
  isOpen,
  onClose,
  language,
  userId = 'guest_user',
  userExam,
  onNavigateTab,
  onUnreadCountChange
}: NotificationCenterModalProps) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [pushStatus, setPushStatus] = useState<string>('default');
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  // Check push permission on mount
  useEffect(() => {
    if (isOpen) {
      setPushStatus(getPushPermissionStatus());
    }
  }, [isOpen]);

  // Fetch notifications
  const fetchNotifications = useCallback(async (pageNum = 1, append = false) => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        userId,
        ...(userExam && { userExam }),
        ...(language && { userLanguage: language }),
        page: String(pageNum),
        limit: '20'
      });

      const res = await fetch(`/api/notifications?${query.toString()}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setNotifications(prev => append ? [...prev, ...data.items] : data.items);
          setHasMore(data.hasMore);
          setPage(data.page);
          setUnreadCount(data.unreadCount || 0);
          onUnreadCountChange?.(data.unreadCount || 0);
        }
      }
    } catch (err) {
      console.error('Error fetching notifications:', err);
    } finally {
      setLoading(false);
    }
  }, [userId, userExam, language, onUnreadCountChange]);

  useEffect(() => {
    if (isOpen) {
      fetchNotifications(1, false);
    }
  }, [isOpen, fetchNotifications]);

  // Mark single notification as read
  const handleMarkAsRead = async (notificationId: string) => {
    try {
      const notif = notifications.find(n => n.notificationId === notificationId);
      if (notif?.read) return;

      // Optimistic update
      setNotifications(prev =>
        prev.map(n => n.notificationId === notificationId ? { ...n, read: true } : n)
      );
      const newCount = Math.max(0, unreadCount - 1);
      setUnreadCount(newCount);
      onUnreadCountChange?.(newCount);

      await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
    } catch (e) {
      console.error('Error marking as read:', e);
    }
  };

  // Mark all as read
  const handleMarkAllAsRead = async () => {
    if (unreadCount === 0) return;
    setActionLoading(true);
    try {
      // Optimistic update
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
      onUnreadCountChange?.(0);

      await fetch('/api/notifications/read-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, userExam, userLanguage: language })
      });
    } catch (e) {
      console.error('Error marking all as read:', e);
    } finally {
      setActionLoading(false);
    }
  };

  // Delete single notification
  const handleDeleteNotification = async (notificationId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const target = notifications.find(n => n.notificationId === notificationId);
      setNotifications(prev => prev.filter(n => n.notificationId !== notificationId));
      if (target && !target.read) {
        const newCount = Math.max(0, unreadCount - 1);
        setUnreadCount(newCount);
        onUnreadCountChange?.(newCount);
      }

      await fetch(`/api/notifications/${notificationId}?userId=${encodeURIComponent(userId)}`, {
        method: 'DELETE'
      });
    } catch (e) {
      console.error('Error deleting notification:', e);
    }
  };

  // Clear all notification history
  const handleClearHistory = async () => {
    const confirmMsg = language === 'bn' 
      ? 'আপনি কি সমস্ত নোটিফিকেশন হিস্ট্রি মুছে ফেলতে চান?' 
      : 'Are you sure you want to clear all notification history?';
    if (!window.confirm(confirmMsg)) return;

    setActionLoading(true);
    try {
      setNotifications([]);
      setUnreadCount(0);
      onUnreadCountChange?.(0);

      await fetch('/api/notifications/clear-history', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
    } catch (e) {
      console.error('Error clearing history:', e);
    } finally {
      setActionLoading(false);
    }
  };

  // Enable push notifications
  const handleEnablePush = async () => {
    const perm = await requestPushPermission({
      userId,
      examTarget: userExam,
      language
    });
    setPushStatus(perm);
  };

  // Action / Deep Link click
  const handleNotificationClick = (notif: AppNotification) => {
    handleMarkAsRead(notif.notificationId);
    if (notif.actionTab && onNavigateTab) {
      onNavigateTab(notif.actionTab);
      onClose();
    } else if (notif.actionUrl) {
      window.open(notif.actionUrl, '_blank');
    }
  };

  // Helper for category badge styling and icons
  const getCategoryMeta = (category: string) => {
    switch (category) {
      case 'weekly_quiz':
        return {
          label: language === 'bn' ? 'সাপ্তাহিক কুইজ' : 'Weekly Quiz',
          icon: Award,
          bg: 'bg-amber-500/10 text-amber-300 border-amber-500/20'
        };
      case 'exam_alert':
        return {
          label: language === 'bn' ? 'পরীক্ষা অ্যালার্ট' : 'Exam Alert',
          icon: ClipboardList,
          bg: 'bg-purple-500/10 text-purple-300 border-purple-500/20'
        };
      case 'daily_questions':
        return {
          label: language === 'bn' ? 'দৈনিক টার্গেট' : 'Daily Target',
          icon: BookOpen,
          bg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
        };
      case 'study_reminder':
        return {
          label: language === 'bn' ? 'স্টাডি টিপস' : 'Study Reminder',
          icon: Sparkles,
          bg: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20'
        };
      default:
        return {
          label: language === 'bn' ? 'ঘোষণা' : 'Announcement',
          icon: Bell,
          bg: 'bg-sky-500/10 text-sky-300 border-sky-500/20'
        };
    }
  };

  // Relative time helper
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (diffMins < 1) return language === 'bn' ? 'এইমাত্র' : 'Just now';
      if (diffMins < 60) return language === 'bn' ? `${diffMins} মিনিট আগে` : `${diffMins}m ago`;
      if (diffHours < 24) return language === 'bn' ? `${diffHours} ঘণ্টা আগে` : `${diffHours}h ago`;
      if (diffDays < 7) return language === 'bn' ? `${diffDays} দিন আগে` : `${diffDays}d ago`;
      
      return date.toLocaleDateString(language === 'bn' ? 'bn-IN' : 'en-US', {
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Background click to dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Main Drawer Container */}
      <div 
        id="notification-center-drawer"
        className="relative z-10 w-full sm:max-w-md h-full sm:h-[92vh] sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col overflow-hidden text-slate-100 animate-in slide-in-from-right duration-300"
      >
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-600/30">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold text-white font-display">
                  {language === 'bn' ? 'নোটিফিকেশন সেন্টার' : 'Notification Center'}
                </h2>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 text-[11px] font-black rounded-full bg-rose-500 text-white">
                    {unreadCount} {language === 'bn' ? 'নতুন' : 'new'}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                {language === 'bn' ? 'লাইভ আপডেট ও পরীক্ষা সংক্রান্ত খবর' : 'Live updates & exam alerts'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Push Notification Permission Banner (If not yet enabled) */}
        {pushStatus === 'default' && (
          <div className="mx-4 mt-3 p-3 bg-gradient-to-r from-indigo-950/80 to-purple-950/80 border border-indigo-500/30 rounded-2xl flex items-center justify-between gap-2 shadow-sm shrink-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <Volume2 className="w-4 h-4 text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-xs font-bold text-indigo-200 truncate">
                  {language === 'bn' ? 'ব্রাউজার পুশ নোটিফিকেশন চালু করুন' : 'Enable Push Alerts'}
                </p>
                <p className="text-[10px] text-slate-400 truncate">
                  {language === 'bn' ? 'কুইজ ও রেজাল্টের তাৎক্ষণিক খবর পেতে' : 'Never miss quizzes & exam results'}
                </p>
              </div>
            </div>
            <button
              onClick={handleEnablePush}
              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg cursor-pointer shrink-0 transition-colors shadow-sm"
            >
              {language === 'bn' ? 'অনুমতি দিন' : 'Allow'}
            </button>
          </div>
        )}

        {/* Action Bar (Mark all as read & Clear History) */}
        <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between text-xs shrink-0">
          <button
            onClick={handleMarkAllAsRead}
            disabled={unreadCount === 0 || actionLoading}
            className={`flex items-center gap-1.5 font-bold transition-colors cursor-pointer ${
              unreadCount > 0 
                ? 'text-indigo-400 hover:text-indigo-300' 
                : 'text-slate-500 cursor-not-allowed'
            }`}
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'সব পঠিত হিসেবে চিহ্নিত করুন' : 'Mark all as read'}</span>
          </button>

          <button
            onClick={handleClearHistory}
            disabled={notifications.length === 0 || actionLoading}
            className={`flex items-center gap-1.5 font-bold transition-colors cursor-pointer ${
              notifications.length > 0 
                ? 'text-slate-400 hover:text-rose-400' 
                : 'text-slate-600 cursor-not-allowed'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'হিস্ট্রি ক্লিয়ার' : 'Clear all'}</span>
          </button>
        </div>

        {/* Notification Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {loading && notifications.length === 0 ? (
            <div className="py-16 flex flex-col items-center justify-center text-center space-y-3">
              <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
              <p className="text-xs text-slate-400 font-medium">
                {language === 'bn' ? 'নোটিফিকেশন লোড হচ্ছে...' : 'Loading notifications...'}
              </p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="py-16 flex flex-col items-center justify-center text-center px-4 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-800 border border-slate-700/80 flex items-center justify-center text-slate-400">
                <Bell className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-200">
                  {language === 'bn' ? 'কোনো নোটিফিকেশন নেই' : 'No notifications yet'}
                </h4>
                <p className="text-xs text-slate-400 max-w-xs">
                  {language === 'bn' 
                    ? 'এডমিন কর্তৃক প্রেরিত নতুন আপডেট বা জরুরি বার্তা এলে এখানে দেখতে পাবেন।' 
                    : 'Important announcements sent by admin will appear here.'}
                </p>
              </div>
            </div>
          ) : (
            notifications.map((notif) => {
              const meta = getCategoryMeta(notif.category);
              const CategoryIcon = meta.icon;
              const isUnread = !notif.read;

              return (
                <div
                  key={notif.notificationId}
                  onClick={() => handleNotificationClick(notif)}
                  className={`group relative p-4 rounded-2xl border transition-all duration-200 cursor-pointer ${
                    isUnread
                      ? 'bg-slate-800/90 hover:bg-slate-800 border-indigo-500/40 shadow-lg shadow-indigo-950/50 ring-1 ring-indigo-500/20'
                      : 'bg-slate-900/60 hover:bg-slate-800/60 border-slate-800/80 text-slate-300'
                  }`}
                >
                  {/* Unread Glowing Pulse Dot */}
                  {isUnread && (
                    <span className="absolute top-4 right-4 w-2.5 h-2.5 bg-indigo-400 rounded-full ring-4 ring-indigo-400/20 animate-pulse" />
                  )}

                  <div className="flex items-start gap-3">
                    {/* Category Icon */}
                    <div className={`p-2 rounded-xl border shrink-0 mt-0.5 ${meta.bg}`}>
                      <CategoryIcon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0 pr-4">
                      {/* Header Badge & Relative Time */}
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${meta.bg}`}>
                          {meta.label}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {formatTime(notif.createdAt)}
                        </span>
                      </div>

                      {/* Title */}
                      <h4 className={`text-sm font-extrabold leading-snug mb-1 ${
                        isUnread ? 'text-white' : 'text-slate-200'
                      }`}>
                        {notif.title}
                      </h4>

                      {/* Message */}
                      <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                        {notif.message}
                      </p>

                      {/* Optional Image Banner if provided */}
                      {notif.imageUrl && (
                        <div className="mt-2.5 rounded-xl overflow-hidden border border-slate-700/60 max-h-32">
                          <img
                            src={notif.imageUrl}
                            alt={notif.title}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </div>
                      )}

                      {/* Action Button if provided */}
                      {(notif.actionText || notif.actionTab) && (
                        <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/60">
                          <span className="text-xs font-bold text-indigo-400 group-hover:text-indigo-300 flex items-center gap-1">
                            {notif.actionText || (language === 'bn' ? 'দেখুন' : 'Open')}
                            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                          </span>

                          <button
                            type="button"
                            onClick={(e) => handleDeleteNotification(notif.notificationId, e)}
                            className="text-slate-500 hover:text-rose-400 p-1 rounded-lg hover:bg-slate-700/40 transition-colors"
                            title="Delete notification"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Load More Pagination */}
          {hasMore && (
            <div className="pt-2 text-center">
              <button
                onClick={() => fetchNotifications(page + 1, true)}
                disabled={loading}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-indigo-300 rounded-xl cursor-pointer transition-colors"
              >
                {loading 
                  ? (language === 'bn' ? 'লোড হচ্ছে...' : 'Loading...') 
                  : (language === 'bn' ? 'আরও দেখুন' : 'Load more')}
              </button>
            </div>
          )}
        </div>

        {/* Drawer Bottom Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-center shrink-0">
          <p className="text-[11px] text-slate-500">
            {language === 'bn' 
              ? 'StudySkill AI • সুরক্ষিত রিয়েল-টাইম পুশ অ্যালার্ট সিস্টেম' 
              : 'StudySkill AI • High-Speed Topic Push Notification Architecture'}
          </p>
        </div>

      </div>
    </div>
  );
}
