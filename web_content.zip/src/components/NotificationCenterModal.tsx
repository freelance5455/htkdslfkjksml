import React, { useState } from 'react';
import { 
  Bell, 
  X, 
  Sun, 
  Moon, 
  Clock, 
  Volume2, 
  VolumeX, 
  Vibrate, 
  Play, 
  Check, 
  Sparkles,
  Calendar,
  AlertCircle,
  RotateCcw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatArabicTimeString } from '../utils/notificationService';

export const NotificationCenterModal: React.FC = () => {
  const { 
    showNotificationCenter, 
    setShowNotificationCenter, 
    settings, 
    updateSettings,
    toggleNotifications,
    nextReminderInfo,
    triggerTestReminder,
    notificationHistory,
    clearNotificationHistory,
    showToast 
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'schedule' | 'history'>('schedule');

  if (!showNotificationCenter) return null;

  const morningPresets = [
    { time: '05:30', label: 'بعد الفجر (٠٥:٣٠ ص)' },
    { time: '06:30', label: 'الشروق (٠٦:٣٠ ص)' },
    { time: '07:30', label: 'صباحاً (٠٧:٣٠ ص)' },
    { time: '08:30', label: 'الضحى (٠٨:٣٠ ص)' },
  ];

  const eveningPresets = [
    { time: '16:30', label: 'بعد العصر (٠٤:٣٠ م)' },
    { time: '17:30', label: 'قبل المغرب (٠٥:٣٠ م)' },
    { time: '18:30', label: 'بعد المغرب (٠٦:٣٠ م)' },
    { time: '20:00', label: 'بعد العشاء (٠٨:٠٠ م)' },
  ];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150 select-none text-right"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md max-h-[90vh] bg-[#032017] border-2 border-emerald-600/50 dark:border-amber-500/40 rounded-3xl p-5 shadow-2xl flex flex-col space-y-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-emerald-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 border border-emerald-500/40 flex items-center justify-center text-amber-300 shadow-xs">
              <Bell className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-[#e8f5ee] font-cairo">
                جدولة تذكيرات الأذكار
              </h2>
              <p className="text-[11px] text-[#84b8a0] font-tajawal">
                تنبيهات يومية داخل التطبيق لأذكار الصباح والمساء
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowNotificationCenter(false)}
            className="p-1.5 rounded-full text-[#84b8a0] hover:text-white hover:bg-emerald-900/60 transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Next Scheduled Reminder Countdown Banner */}
        {settings.notificationsEnabled && nextReminderInfo && (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-[#063826] to-[#04281b] border border-amber-400/40 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                {nextReminderInfo.category === 'morning' ? (
                  <Sun className="w-4 h-4 animate-pulse" />
                ) : (
                  <Moon className="w-4 h-4 animate-pulse fill-amber-200/30" />
                )}
              </div>
              <div>
                <p className="text-xs font-bold font-cairo text-[#e8f5ee]">
                  التذكير القادم: {nextReminderInfo.title}
                </p>
                <p className="text-[11px] text-amber-300 font-tajawal">
                  الساعة {nextReminderInfo.timeFormatted} ({nextReminderInfo.timeText})
                </p>
              </div>
            </div>

            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-900/90 text-emerald-300 border border-emerald-700/60 font-tajawal">
              مجدول ⏰
            </span>
          </div>
        )}

        {/* Master Active Toggle */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-[#062c20] border border-emerald-800">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4.5 h-4.5 text-amber-300" />
            <div>
              <p className="text-xs font-bold text-[#e8f5ee] font-cairo">
                تفعيل نظام التنبيهات
              </p>
              <p className="text-[10px] text-[#84b8a0] font-tajawal">
                تنبيهات داخل التطبيق بمواعيد الأذكار المحددة
              </p>
            </div>
          </div>

          <button
            onClick={() => toggleNotifications(!settings.notificationsEnabled)}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.notificationsEnabled ? 'bg-emerald-600' : 'bg-[#093526] border border-emerald-700/50'
            }`}
            aria-label="تفعيل أو إيقاف التنبيهات"
          >
            <div
              className={`w-4.5 h-4.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                settings.notificationsEnabled ? 'right-7' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Sub-Tabs: Schedule vs History */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#062c20] rounded-xl border border-emerald-800 text-xs font-bold font-cairo">
          <button
            onClick={() => setActiveSubTab('schedule')}
            className={`py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeSubTab === 'schedule'
                ? 'bg-[#093526] text-amber-200 border border-emerald-600/50 shadow-xs'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            جدول المواعيد ⏰
          </button>
          <button
            onClick={() => setActiveSubTab('history')}
            className={`py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeSubTab === 'history'
                ? 'bg-[#093526] text-amber-200 border border-emerald-600/50 shadow-xs'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            سجل التنبيهات ({notificationHistory.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-3.5 max-h-[50vh]">
          {activeSubTab === 'schedule' ? (
            <>
              {/* Morning Adhkar Scheduling Card */}
              <div className="p-3.5 rounded-2xl bg-[#042017] border border-emerald-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-400/40 flex items-center justify-center">
                      <Sun className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-extrabold text-[#e8f5ee] font-cairo">
                        تذكير أذكار الصباح
                      </h3>
                      <p className="text-[10px] text-amber-300 font-tajawal">
                        الموعد الحالي: {formatArabicTimeString(settings.morningNotificationTime)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={settings.morningNotificationTime}
                      onChange={(e) => updateSettings({ morningNotificationTime: e.target.value })}
                      className="px-2 py-1 text-xs bg-[#062c20] border border-emerald-700 rounded-lg text-amber-200 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                    />
                    <button
                      onClick={() => updateSettings({ morningNotification: !settings.morningNotification })}
                      className={`w-8 h-5 rounded-full transition-colors relative cursor-pointer ${
                        settings.morningNotification ? 'bg-emerald-600' : 'bg-[#093526]'
                      }`}
                      title="تفعيل تذكير الصباح"
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                          settings.morningNotification ? 'right-4' : 'right-0.5'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Quick Presets for Morning */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {morningPresets.map((preset) => (
                    <button
                      key={preset.time}
                      onClick={() => {
                        updateSettings({ morningNotificationTime: preset.time, morningNotification: true });
                        showToast(`تم ضبط أذكار الصباح على ${preset.time}`);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-tajawal font-bold border transition-colors cursor-pointer ${
                        settings.morningNotificationTime === preset.time
                          ? 'bg-amber-500/20 border-amber-400/60 text-amber-200'
                          : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Evening Adhkar Scheduling Card */}
              <div className="p-3.5 rounded-2xl bg-[#042017] border border-emerald-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-indigo-950 text-amber-200 border border-emerald-500/40 flex items-center justify-center">
                      <Moon className="w-4 h-4 fill-amber-200/30" />
                    </div>
                    <div>
                      <h3 className="text-xs font-extrabold text-[#e8f5ee] font-cairo">
                        تذكير أذكار المساء
                      </h3>
                      <p className="text-[10px] text-amber-300 font-tajawal">
                        الموعد الحالي: {formatArabicTimeString(settings.eveningNotificationTime)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={settings.eveningNotificationTime}
                      onChange={(e) => updateSettings({ eveningNotificationTime: e.target.value })}
                      className="px-2 py-1 text-xs bg-[#062c20] border border-emerald-700 rounded-lg text-amber-200 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                    />
                    <button
                      onClick={() => updateSettings({ eveningNotification: !settings.eveningNotification })}
                      className={`w-8 h-5 rounded-full transition-colors relative cursor-pointer ${
                        settings.eveningNotification ? 'bg-emerald-600' : 'bg-[#093526]'
                      }`}
                      title="تفعيل تذكير المساء"
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                          settings.eveningNotification ? 'right-4' : 'right-0.5'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Quick Presets for Evening */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {eveningPresets.map((preset) => (
                    <button
                      key={preset.time}
                      onClick={() => {
                        updateSettings({ eveningNotificationTime: preset.time, eveningNotification: true });
                        showToast(`تم ضبط أذكار المساء على ${preset.time}`);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-tajawal font-bold border transition-colors cursor-pointer ${
                        settings.eveningNotificationTime === preset.time
                          ? 'bg-amber-500/20 border-amber-400/60 text-amber-200'
                          : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Instant Test Buttons (تجربة الإشعار فوراً) */}
              <div className="p-3 rounded-2xl bg-[#062c20] border border-emerald-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-[#e8f5ee] font-cairo">
                  <span>تجربة الإشعار الفوري الآن:</span>
                  <span className="text-[10px] text-[#84b8a0] font-tajawal">اختبار الصوت والتنبيه</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => triggerTestReminder('morning')}
                    className="py-2 px-3 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-amber-300 font-bold text-xs font-cairo flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Sun className="w-3.5 h-3.5" />
                    <span>تجربة إشعار الصباح ☀️</span>
                  </button>

                  <button
                    onClick={() => triggerTestReminder('evening')}
                    className="py-2 px-3 rounded-xl bg-indigo-950/70 hover:bg-indigo-900 border border-emerald-600/50 text-amber-200 font-bold text-xs font-cairo flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Moon className="w-3.5 h-3.5 fill-amber-200/30" />
                    <span>تجربة إشعار المساء 🌙</span>
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* History Sub-Tab */
            <div className="space-y-2">
              {notificationHistory.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#84b8a0] font-tajawal space-y-2">
                  <Bell className="w-6 h-6 mx-auto text-emerald-600 opacity-60" />
                  <p>لا توجد تنبيهات سابقة بعد</p>
                  <p className="text-[11px] text-emerald-400">ستظهر التنبيهات اليومية هنا تلقائياً عند حلول موعدها</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between text-xs pb-1">
                    <span className="text-[#84b8a0] font-tajawal">التنبيهات المسجلة ({notificationHistory.length}):</span>
                    <button
                      onClick={clearNotificationHistory}
                      className="text-[11px] text-red-400 hover:text-red-300 font-tajawal cursor-pointer"
                    >
                      مسح السجل
                    </button>
                  </div>
                  {notificationHistory.map((item) => (
                    <div 
                      key={item.id}
                      className="p-3 rounded-xl bg-[#042017] border border-emerald-800/80 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        {item.category === 'morning' ? (
                          <Sun className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Moon className="w-4 h-4 text-amber-200" />
                        )}
                        <div>
                          <p className="font-bold font-cairo text-[#e8f5ee]">{item.title}</p>
                          <p className="text-[10px] text-[#84b8a0] font-tajawal">{item.body.slice(0, 42)}...</p>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono">{item.time}</span>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer Confirmation */}
        <button
          onClick={() => {
            setShowNotificationCenter(false);
            showToast('تم حفظ إعدادات تذكيرات الأذكار بنجاح ✓');
          }}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs font-cairo transition-transform active:scale-98 shadow-md cursor-pointer"
        >
          حفظ وإغلاق
        </button>
      </div>
    </div>
  );
};
