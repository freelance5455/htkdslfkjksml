/**
 * HELENA - Admin Panel (2 Cérebros: Gemini + Groq)
 * Protected owner settings:
 * - Cérebro 1: Gemini (Key, Model) + Testar Conexão
 * - Cérebro 2: Groq (Key, Model Texto, Model Visão) + Testar Conexão
 * - Lista de Autores Confiáveis do Sketchfab (vet3d, university, faculdade, etc.)
 * - Palavra de Ativação (Wake Word)
 * - Alterar Senha & Sair
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  X, 
  Key, 
  Check, 
  Activity, 
  Sparkles, 
  HelpCircle,
  Eye,
  EyeOff,
  LogOut,
  ShieldCheck,
  Cpu,
  Eye as VisionIcon,
  Users
} from 'lucide-react';
import { AppSettings } from '../types';
import { maskKey } from '../services/storage';
import { callGemini, callGroq } from '../services/brains';

interface AdminModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onSaveSettings: (updated: AppSettings) => void;
  onChangePassword: () => void;
  onLogout: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  settings,
  isOpen,
  onClose,
  onSaveSettings,
  onChangePassword,
  onLogout,
}) => {
  // State variables for form fields
  const [geminiKey, setGeminiKey] = useState(settings.geminiKey);
  const [geminiModel, setGeminiModel] = useState(settings.geminiModel);

  const [groqKey, setGroqKey] = useState(settings.groqKey);
  const [groqModel, setGroqModel] = useState(settings.groqModel);
  const [groqVisionModel, setGroqVisionModel] = useState(settings.groqVisionModel);

  const [trustedAuthorsInput, setTrustedAuthorsInput] = useState(
    (settings.trustedAuthors || []).join(', ')
  );
  const [wakeWord, setWakeWord] = useState(settings.wakeWord);

  // Connection testing states
  const [testResults, setTestResults] = useState<Record<string, { ok: boolean; message: string; loading?: boolean }>>({});
  const [visibleKeyFields, setVisibleKeyFields] = useState<Record<string, boolean>>({});
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync state with settings when modal is opened or settings change
  useEffect(() => {
    if (isOpen) {
      setGeminiKey(settings.geminiKey);
      setGeminiModel(settings.geminiModel);
      setGroqKey(settings.groqKey);
      setGroqModel(settings.groqModel);
      setGroqVisionModel(settings.groqVisionModel);
      setTrustedAuthorsInput((settings.trustedAuthors || []).join(', '));
      setWakeWord(settings.wakeWord);
      setTestResults({});
    }
  }, [settings, isOpen]);

  if (!isOpen) return null;

  const toggleVisibility = (field: string) => {
    setVisibleKeyFields((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const handleSave = () => {
    const authors = trustedAuthorsInput
      .split(',')
      .map((a) => a.trim().toLowerCase())
      .filter((a) => a.length > 0);

    const updated: AppSettings = {
      ...settings,
      geminiKey: geminiKey.trim(),
      geminiModel: geminiModel.trim(),
      groqKey: groqKey.trim(),
      groqModel: groqModel.trim(),
      groqVisionModel: groqVisionModel.trim(),
      trustedAuthors: authors.length > 0 ? authors : settings.trustedAuthors,
      wakeWord: wakeWord.trim() || 'Helena',
    };

    onSaveSettings(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  // Test Gemini connection
  const handleTestGemini = async () => {
    if (!geminiKey.trim()) {
      setTestResults((prev) => ({
        ...prev,
        gemini: { ok: false, message: 'Chave Gemini não fornecida.' },
      }));
      return;
    }

    setTestResults((prev) => ({
      ...prev,
      gemini: { ok: false, message: 'Testando comunicação...', loading: true },
    }));

    try {
      const resp = await callGemini('Olá Helena, confirme conexão em uma palavra.', geminiKey, geminiModel);
      setTestResults((prev) => ({
        ...prev,
        gemini: { ok: true, message: `Conectado! Resposta: "${resp.slice(0, 40)}..."`, loading: false },
      }));
    } catch (err: any) {
      setTestResults((prev) => ({
        ...prev,
        gemini: { ok: false, message: `Falha: ${err.message || 'Erro de rede ou chave inválida'}`, loading: false },
      }));
    }
  };

  // Test Groq connection
  const handleTestGroq = async () => {
    if (!groqKey.trim()) {
      setTestResults((prev) => ({
        ...prev,
        groq: { ok: false, message: 'Chave Groq não fornecida.' },
      }));
      return;
    }

    setTestResults((prev) => ({
      ...prev,
      groq: { ok: false, message: 'Testando comunicação...', loading: true },
    }));

    try {
      const resp = await callGroq('Olá Helena, confirme conexão em uma palavra.', groqKey, groqModel);
      setTestResults((prev) => ({
        ...prev,
        groq: { ok: true, message: `Conectado! Resposta: "${resp.slice(0, 40)}..."`, loading: false },
      }));
    } catch (err: any) {
      setTestResults((prev) => ({
        ...prev,
        groq: { ok: false, message: `Falha: ${err.message || 'Erro de rede ou chave inválida'}`, loading: false },
      }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-[#030d06] border border-[#14502D] text-[#CDEBD8] shadow-2xl overflow-hidden"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#14502D]/60 bg-[#06180c]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F]">
              <Lock size={20} />
            </div>
            <div>
              <h2 className="text-base font-semibold tracking-wide text-white flex items-center gap-2">
                Painel do Administrador
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#0E7A3D]/30 text-[#2FD16F] border border-[#0E7A3D]/50">
                  2 Cérebros Ativos
                </span>
              </h2>
              <p className="text-xs text-[#CDEBD8]/70">
                Gerenciamento de chaves, modelos de IA e diretrizes da HELENA
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-lg text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/40 transition min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* CÉREBRO 1: GEMINI */}
          <div className="p-4 rounded-xl border border-[#14502D] bg-[#05140a] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-medium text-sm">
                <Cpu size={16} className="text-[#2FD16F]" />
                <span>Cérebro 1: Google Gemini</span>
              </div>
              <span className="text-[11px] text-[#2FD16F] bg-[#0E7A3D]/30 px-2 py-0.5 rounded border border-[#0E7A3D]">
                Principal & Multimodal
              </span>
            </div>

            {/* Gemini API Key */}
            <div>
              <label className="block text-xs text-[#CDEBD8]/70 mb-1">Chave de API Gemini</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type={visibleKeyFields.gemini ? 'text' : 'password'}
                    value={geminiKey}
                    onChange={(e) => setGeminiKey(e.target.value)}
                    placeholder="AQ.Ab8RN..."
                    className="w-full px-3 py-2 pr-10 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
                  />
                  <button
                    type="button"
                    onClick={() => toggleVisibility('gemini')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
                  >
                    {visibleKeyFields.gemini ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={handleTestGemini}
                  disabled={testResults.gemini?.loading}
                  className="px-3.5 py-2 rounded-xl bg-[#0E7A3D]/30 border border-[#0E7A3D] hover:bg-[#0E7A3D]/60 text-xs font-medium text-white transition shrink-0 min-h-[44px]"
                >
                  {testResults.gemini?.loading ? 'Testando...' : 'Testar Conexão'}
                </button>
              </div>

              {testResults.gemini && (
                <div className={`mt-1.5 text-xs px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 ${
                  testResults.gemini.ok 
                    ? 'bg-green-950/40 border-green-700 text-green-300' 
                    : 'bg-red-950/40 border-red-800 text-red-300'
                }`}>
                  <Activity size={12} />
                  <span>{testResults.gemini.message}</span>
                </div>
              )}
            </div>

            {/* Gemini Model */}
            <div>
              <label className="block text-xs text-[#CDEBD8]/70 mb-1">Nome do Modelo</label>
              <input
                type="text"
                value={geminiModel}
                onChange={(e) => setGeminiModel(e.target.value)}
                placeholder="gemini-3.1-flash-lite"
                className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
              />
              <p className="text-[11px] text-[#CDEBD8]/50 mt-1">
                Padrão: gemini-3.1-flash-lite (com fallback automático para gemini-3.8-flash)
              </p>
            </div>
          </div>

          {/* CÉREBRO 2: GROQ */}
          <div className="p-4 rounded-xl border border-[#14502D] bg-[#05140a] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-medium text-sm">
                <Cpu size={16} className="text-[#2FD16F]" />
                <span>Cérebro 2: Groq</span>
              </div>
              <span className="text-[11px] text-[#2FD16F] bg-[#0E7A3D]/30 px-2 py-0.5 rounded border border-[#0E7A3D]">
                Consenso & Visão
              </span>
            </div>

            {/* Groq API Key */}
            <div>
              <label className="block text-xs text-[#CDEBD8]/70 mb-1">Chave de API Groq</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type={visibleKeyFields.groq ? 'text' : 'password'}
                    value={groqKey}
                    onChange={(e) => setGroqKey(e.target.value)}
                    placeholder="gsk_..."
                    className="w-full px-3 py-2 pr-10 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
                  />
                  <button
                    type="button"
                    onClick={() => toggleVisibility('groq')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
                  >
                    {visibleKeyFields.groq ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={handleTestGroq}
                  disabled={testResults.groq?.loading}
                  className="px-3.5 py-2 rounded-xl bg-[#0E7A3D]/30 border border-[#0E7A3D] hover:bg-[#0E7A3D]/60 text-xs font-medium text-white transition shrink-0 min-h-[44px]"
                >
                  {testResults.groq?.loading ? 'Testando...' : 'Testar Conexão'}
                </button>
              </div>

              {testResults.groq && (
                <div className={`mt-1.5 text-xs px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 ${
                  testResults.groq.ok 
                    ? 'bg-green-950/40 border-green-700 text-green-300' 
                    : 'bg-red-950/40 border-red-800 text-red-300'
                }`}>
                  <Activity size={12} />
                  <span>{testResults.groq.message}</span>
                </div>
              )}
            </div>

            {/* Groq Models (Text + Vision) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#CDEBD8]/70 mb-1">Modelo de Texto</label>
                <input
                  type="text"
                  value={groqModel}
                  onChange={(e) => setGroqModel(e.target.value)}
                  placeholder="llama-3.3-70b-versatile"
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#CDEBD8]/70 mb-1 flex items-center gap-1">
                  <VisionIcon size={12} className="text-[#2FD16F]" /> Modelo de Visão (Campo)
                </label>
                <input
                  type="text"
                  value={groqVisionModel}
                  onChange={(e) => setGroqVisionModel(e.target.value)}
                  placeholder="llama-3.2-11b-vision-preview"
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
                />
              </div>
            </div>
          </div>

          {/* AUTORES CONFIÁVEIS DO SKETCHFAB */}
          <div className="p-4 rounded-xl border border-[#14502D] bg-[#05140a] space-y-2">
            <div className="flex items-center gap-2 text-white font-medium text-sm">
              <Users size={16} className="text-[#2FD16F]" />
              <span>Autores Confiáveis de Modelos 3D (Sketchfab)</span>
            </div>
            <p className="text-xs text-[#CDEBD8]/70">
              Autores ou palavras-chave com pontuação adicional (+20) na confiabilidade anatômica:
            </p>
            <input
              type="text"
              value={trustedAuthorsInput}
              onChange={(e) => setTrustedAuthorsInput(e.target.value)}
              placeholder="vet3d, university, veterinary, anatomy, faculdade, usp, ufmg"
              className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] font-mono focus:outline-none focus:border-[#2FD16F]"
            />
            <p className="text-[11px] text-[#CDEBD8]/50">Separados por vírgula</p>
          </div>

          {/* PALAVRA DE ATIVAÇÃO & CONTA */}
          <div className="p-4 rounded-xl border border-[#14502D] bg-[#05140a] space-y-4">
            <div>
              <label className="block text-xs text-[#CDEBD8]/70 mb-1">Palavra de Ativação (Wake Word)</label>
              <input
                type="text"
                value={wakeWord}
                onChange={(e) => setWakeWord(e.target.value)}
                placeholder="Helena"
                className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-sm text-[#CDEBD8] focus:outline-none focus:border-[#2FD16F]"
              />
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-[#14502D]/60">
              <button
                type="button"
                onClick={onChangePassword}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-[#14502D] bg-black/40 hover:bg-[#14502D]/40 text-xs text-white transition min-h-[44px]"
              >
                Alterar Senha do Administrador
              </button>

              <button
                type="button"
                onClick={onLogout}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-red-900/60 bg-red-950/20 hover:bg-red-900/40 text-xs text-red-300 transition flex items-center justify-center gap-1.5 min-h-[44px]"
              >
                <LogOut size={14} />
                <span>Encerrar Sessão</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-4 border-t border-[#14502D]/60 bg-[#06180c]">
          {saveSuccess ? (
            <span className="text-xs text-[#2FD16F] flex items-center gap-1 font-medium">
              <Check size={16} /> Configurações salvas com sucesso!
            </span>
          ) : (
            <span className="text-xs text-[#CDEBD8]/50">
              Salvo localmente no aparelho
            </span>
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-[#14502D] hover:bg-[#14502D]/40 text-xs text-[#CDEBD8] transition min-h-[44px]"
            >
              Cancelar
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2.5 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-xs font-semibold text-white shadow-lg shadow-[#0E7A3D]/25 transition min-h-[44px]"
            >
              Salvar Alterações
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
